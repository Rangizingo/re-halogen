0000000000133800 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 000000133800: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 000000133804: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 00000013380C: F4080500 F8000050
	v_and_b32_e32 v130, 31, v0                                 // 000000133814: 3704009F
	v_lshrrev_b32_e32 v157, 5, v0                              // 000000133818: 333A0085
	s_mov_b32 s24, s3                                          // 00000013381C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000133820: BF870112
	.long 0xd44c0003                                           // 000000133824: D44C0003
	v_cndmask_b32_e32 v1, 16, v130, vcc_lo                     // 000000133828: 02030490
	v_lshlrev_b32_e32 v131, 6, v157                            // 00000013382C: 31073A86
	s_waitcnt lgkmcnt(0)                                       // 000000133830: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 000000133834: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 00000013383C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 000000133840: BF870001
	v_lshl_add_u32 v1, v130, 2, v131                           // 000000133844: D6460001 060D0582
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 00000013384C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:231 offset1:243// 000000133858: D83CF3E7 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 000000133860: 8C7E047E
	v_mul_u32_u24_e32 v1, 0x2ab, v0                            // 000000133864: 160200FF 000002AB
	s_clause 0x1                                               // 00000013386C: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000133870: F40C0100 F8000000
	s_load_b128 s[16:19], s[0:1], 0x20                         // 000000133878: F4080400 F8000020
	s_lshl_b32 s27, s2, 5                                      // 000000133880: 841B8502
	v_dual_mov_b32 v144, 0 :: v_dual_and_b32 v159, 15, v0      // 000000133884: CA240080 909E008F
	.long 0xd7381001                                           // 00000013388C: D7381001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000133890: 02020282
	.long 0x7f023880                                           // 000000133894: 7F023880
	s_cmp_eq_u64 s[14:15], 0                                   // 000000133898: BF10800E
	v_mov_b32_e32 v145, 0                                      // 00000013389C: 7F220280
	s_cselect_b32 s25, -1, 0                                   // 0000001338A0: 981980C1
	.long 0xd7620001                                           // 0000001338A4: D7620001
	v_cndmask_b32_e32 v0, v1, v176, vcc_lo                     // 0000001338A8: 02016101
	s_and_b32 vcc_lo, exec_lo, s25                             // 0000001338AC: 8B6A197E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001338B0: BF870091
	v_add_nc_u32_e32 v158, s27, v1                             // 0000001338B4: 4B3C021B
	v_or_b32_e32 v128, v158, v159                              // 0000001338B8: 39013F9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001338BC: BF870001
	v_ashrrev_i32_e32 v129, 31, v128                           // 0000001338C0: 3503009F
	s_cbranch_vccnz 10                                         // 0000001338C4: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf0>
	v_mad_i64_i32 v[1:2], null, s23, v128, 0                   // 0000001338C8: D6FF7C01 02030017
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001338D0: BF870091
	.long 0xd73c0001                                           // 0000001338D4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000001338D8: 02020282
	.long 0xd7006a90                                           // 0000001338DC: D7006A90
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000001338E0: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001338E4: BF870001
	v_add_co_ci_u32_e64 v145, null, s15, v2, vcc_lo            // 0000001338E8: D5207C91 01AA040F
	s_load_b64 s[14:15], s[0:1], 0x38                          // 0000001338F0: F4040380 F8000038
	v_mov_b32_e32 v161, 0                                      // 0000001338F8: 7F420280
	s_xor_b32 s0, s25, -1                                      // 0000001338FC: 8D00C119
	s_waitcnt lgkmcnt(0)                                       // 000000133900: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v128                         // 000000133904: 7C89000E
	s_and_b32 s23, s0, vcc_lo                                  // 000000133908: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000013390C: BF870009
	s_and_saveexec_b32 s0, s23                                 // 000000133910: BE802017
	s_cbranch_execz 9                                          // 000000133914: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13c>
	.long 0xd73c0001                                           // 000000133918: D73C0001
	v_cndmask_b32_e32 v1, 2, v128, vcc_lo                      // 00000013391C: 02030082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133920: BF870091
	.long 0xd7006a01                                           // 000000133924: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 000000133928: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 00000013392C: D5207C02 01AA0415
	global_load_b32 v161, v[1:2], off                          // 000000133934: DC520000 A17C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013393C: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 000000133940: BF10800C
	s_mov_b64 s[20:21], 0                                      // 000000133944: BE940180
	s_cbranch_scc1 10                                          // 000000133948: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x174>
	s_ashr_i32 s0, s22, 31                                     // 00000013394C: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 000000133950: 96810216
	s_mul_i32 s0, s0, s2                                       // 000000133954: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000133958: BF8704A9
	s_add_i32 s1, s1, s0                                       // 00000013395C: 81010001
	s_mul_i32 s0, s22, s2                                      // 000000133960: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 000000133964: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000133968: BF870009
	s_add_u32 s20, s12, s0                                     // 00000013396C: 8014000C
	s_addc_u32 s21, s13, s1                                    // 000000133970: 8215010D
	v_lshrrev_b32_e32 v1, 1, v0                                // 000000133974: 32020081
	v_mov_b32_e32 v7, 0                                        // 000000133978: 7E0E0280
	.long 0xd44c0000                                           // 00000013397C: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000133980: 020200FF 00000200
	v_dual_mov_b32 v137, 0 :: v_dual_lshlrev_b32 v0, 3, v130   // 000000133988: CA220080 89010483
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000133990: BF8701A3
	v_dual_mov_b32 v10, v7 :: v_dual_and_b32 v133, 0x1f8, v1   // 000000133994: CA240107 0A8402FF 000001F8
	v_mov_b32_e32 v8, v7                                       // 0000001339A0: 7E100307
	v_dual_mov_b32 v9, v7 :: v_dual_lshlrev_b32 v132, 1, v0    // 0000001339A4: CA220107 09840081
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001339AC: BF870003
	v_dual_mov_b32 v138, 0 :: v_dual_lshlrev_b32 v129, 1, v133 // 0000001339B0: CA220080 8A810A81
	v_dual_mov_b32 v139, 0 :: v_dual_mov_b32 v140, 0           // 0000001339B8: CA100080 8B8C0080
	scratch_store_b128 off, v[7:10], off                       // 0000001339C0: DC750000 007C0700
	s_and_saveexec_b32 s1, s0                                  // 0000001339C8: BE812000
	s_cbranch_execz 67                                         // 0000001339CC: BFA50043 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2dc>
	s_add_i32 s2, s15, -1                                      // 0000001339D0: 8102C10F
	s_ashr_i32 s25, s24, 31                                    // 0000001339D4: 86199F18
	v_min_i32_e32 v0, s2, v157                                 // 0000001339D8: 22013A02
	v_min_i32_e32 v2, s2, v159                                 // 0000001339DC: 22053E02
	s_lshl_b64 s[12:13], s[24:25], 9                           // 0000001339E0: 848C8918
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001339E4: BF870112
	v_ashrrev_i32_e32 v3, 31, v0                               // 0000001339E8: 3406009F
	v_ashrrev_i32_e32 v5, 31, v2                               // 0000001339EC: 340A049F
	.long 0xd72c0004                                           // 0000001339F0: D72C0004
	v_cndmask_b32_e32 v1, s11, v0, vcc_lo                      // 0000001339F4: 0202000B
	v_mad_u64_u32 v[0:1], null, s10, v0, 0                     // 0000001339F8: D6FE7C00 0202000A
	.long 0xd72c0008                                           // 000000133A00: D72C0008
	v_cndmask_b32_e32 v1, s11, v2, vcc_lo                      // 000000133A04: 0202040B
	.long 0xd72c0006                                           // 000000133A08: D72C0006
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 000000133A0C: 0202060A
	v_mad_u64_u32 v[2:3], null, s10, v2, 0                     // 000000133A10: D6FE7C02 0202040A
	.long 0xd72c0005                                           // 000000133A18: D72C0005
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000133A1C: 02020A0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000133A20: BF870113
	v_add3_u32 v1, v1, v6, v4                                  // 000000133A24: D6550001 04120D01
	v_add3_u32 v3, v3, v5, v8                                  // 000000133A2C: D6550003 04220B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000133A34: BF870112
	.long 0xd73c0000                                           // 000000133A38: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000133A3C: 02020081
	.long 0xd73c0002                                           // 000000133A40: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 000000133A44: 02020481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133A48: BF870092
	.long 0xd7006a00                                           // 000000133A4C: D7006A00
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 000000133A50: 02020006
	v_add_co_ci_u32_e64 v1, null, s7, v1, vcc_lo               // 000000133A54: D5207C01 01AA0207
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133A5C: BF870093
	.long 0xd7006a02                                           // 000000133A60: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 000000133A64: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 000000133A68: D5207C03 01AA0609
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133A70: BF870094
	.long 0xd7006a00                                           // 000000133A74: D7006A00
	v_cndmask_b32_e32 v0, v0, v12, vcc_lo                      // 000000133A78: 02001900
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 000000133A7C: D5207C01 01AA020D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133A84: BF870094
	.long 0xd7006a02                                           // 000000133A88: D7006A02
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 000000133A8C: 02001902
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000133A90: D5207C03 01AA060D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133A98: BF870094
	.long 0xd7006a00                                           // 000000133A9C: D7006A00
	v_cndmask_b32_e32 v1, v0, v132, vcc_lo                     // 000000133AA0: 02030900
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000133AA4: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133AAC: BF870094
	.long 0xd7006a04                                           // 000000133AB0: D7006A04
	v_cndmask_b32_e32 v1, v2, v129, vcc_lo                     // 000000133AB4: 02030302
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000133AB8: D5207C05 01AA0680
	global_load_b128 v[0:3], v[0:1], off                       // 000000133AC0: DC5E0000 007C0000
	global_load_b128 v[137:140], v[4:5], off                   // 000000133AC8: DC5E0000 897C0004
	s_waitcnt vmcnt(1)                                         // 000000133AD0: BF8907F7
	scratch_store_b128 off, v[0:3], off                        // 000000133AD4: DC750000 007C0000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000133ADC: 8C7E017E
	.long 0xd7050000                                           // 000000133AE0: D7050000
	v_cndmask_b32_e32 v0, v157, v150, vcc_lo                   // 000000133AE4: 02012D9D
	s_or_b32 s27, s27, 31                                      // 000000133AE8: 8C1B9F1B
	s_add_i32 s1, s14, -1                                      // 000000133AEC: 8101C10E
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v5, 0               // 000000133AF0: CA100080 06040080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000133AF8: BF8701C2
	.long 0xd7390000                                           // 000000133AFC: D7390000
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 000000133B00: 02020088
	s_min_i32 s1, s27, s1                                      // 000000133B04: 8901011B
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 000000133B08: CA100080 04020080
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 000000133B10: CA100080 02000080
	.long 0xd7050008                                           // 000000133B18: D7050008
	v_cndmask_b32_e32 v0, v0, v140, vcc_lo                     // 000000133B1C: 02011900
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v15, 0              // 000000133B20: CA100080 000E0080
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 000000133B28: CA100080 0E0C0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000133B30: BF8701B3
	.long 0xd7040008                                           // 000000133B34: D7040008
	v_cndmask_b32_e32 v1, v157, v8, vcc_lo                     // 000000133B38: 0202119D
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 000000133B3C: CA100080 0C0A0080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 000000133B44: CA100080 0A080080
	v_dual_mov_b32 v23, 0 :: v_dual_and_b32 v16, 0xff, v8      // 000000133B4C: CA240080 171010FF 000000FF
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v21, 0              // 000000133B58: CA100080 08140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v19, 0             // 000000133B60: CA100080 16120080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000133B68: BF870243
	v_mad_u64_u32 v[141:142], null, s24, 12, v[16:17]          // 000000133B6C: D6FE7C8D 04411818
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v17, 0             // 000000133B74: CA100080 14100080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v31, 0             // 000000133B7C: CA100080 121E0080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v29, 0             // 000000133B84: CA100080 101C0080
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v32, 8, v141   // 000000133B8C: CA220080 19211A88
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v27, 0             // 000000133B94: CA100080 1E1A0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v39, 0             // 000000133B9C: CA100080 1C260080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000133BA4: BF8701B3
	v_ashrrev_i32_e32 v33, 31, v32                             // 000000133BA8: 3442409F
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v37, 0             // 000000133BAC: CA100080 1A240080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v35, 0             // 000000133BB4: CA100080 18220080
	.long 0xd73c008e                                           // 000000133BBC: D73C008E
	v_cndmask_b32_e32 v1, 1, v32, vcc_lo                       // 000000133BC0: 02024081
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v33, 0             // 000000133BC4: CA100080 26200080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v47, 0             // 000000133BCC: CA100080 242E0080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v45, 0             // 000000133BD4: CA100080 222C0080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v43, 0             // 000000133BDC: CA100080 202A0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v41, 0             // 000000133BE4: CA100080 2E280080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v55, 0             // 000000133BEC: CA100080 2C360080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v53, 0             // 000000133BF4: CA100080 2A340080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v51, 0             // 000000133BFC: CA100080 28320080
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v49, 0             // 000000133C04: CA100080 36300080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v63, 0             // 000000133C0C: CA100080 343E0080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v61, 0             // 000000133C14: CA100080 323C0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v59, 0             // 000000133C1C: CA100080 303A0080
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v57, 0             // 000000133C24: CA100080 3E380080
	v_dual_mov_b32 v60, 0 :: v_dual_mov_b32 v71, 0             // 000000133C2C: CA100080 3C460080
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v69, 0             // 000000133C34: CA100080 3A440080
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v67, 0             // 000000133C3C: CA100080 38420080
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v65, 0             // 000000133C44: CA100080 46400080
	v_dual_mov_b32 v68, 0 :: v_dual_mov_b32 v79, 0             // 000000133C4C: CA100080 444E0080
	v_dual_mov_b32 v66, 0 :: v_dual_mov_b32 v77, 0             // 000000133C54: CA100080 424C0080
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v75, 0             // 000000133C5C: CA100080 404A0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v73, 0             // 000000133C64: CA100080 4E480080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v87, 0             // 000000133C6C: CA100080 4C560080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v85, 0             // 000000133C74: CA100080 4A540080
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v83, 0             // 000000133C7C: CA100080 48520080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v81, 0             // 000000133C84: CA100080 56500080
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v95, 0             // 000000133C8C: CA100080 545E0080
	v_dual_mov_b32 v82, 0 :: v_dual_mov_b32 v93, 0             // 000000133C94: CA100080 525C0080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v91, 0             // 000000133C9C: CA100080 505A0080
	v_dual_mov_b32 v94, 0 :: v_dual_mov_b32 v89, 0             // 000000133CA4: CA100080 5E580080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v103, 0            // 000000133CAC: CA100080 5C660080
	v_dual_mov_b32 v90, 0 :: v_dual_mov_b32 v101, 0            // 000000133CB4: CA100080 5A640080
	v_dual_mov_b32 v88, 0 :: v_dual_mov_b32 v99, 0             // 000000133CBC: CA100080 58620080
	v_dual_mov_b32 v102, 0 :: v_dual_mov_b32 v97, 0            // 000000133CC4: CA100080 66600080
	v_dual_mov_b32 v100, 0 :: v_dual_mov_b32 v111, 0           // 000000133CCC: CA100080 646E0080
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v109, 0            // 000000133CD4: CA100080 626C0080
	v_dual_mov_b32 v96, 0 :: v_dual_mov_b32 v107, 0            // 000000133CDC: CA100080 606A0080
	v_dual_mov_b32 v110, 0 :: v_dual_mov_b32 v105, 0           // 000000133CE4: CA100080 6E680080
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v119, 0           // 000000133CEC: CA100080 6C760080
	v_dual_mov_b32 v106, 0 :: v_dual_mov_b32 v117, 0           // 000000133CF4: CA100080 6A740080
	v_dual_mov_b32 v104, 0 :: v_dual_mov_b32 v115, 0           // 000000133CFC: CA100080 68720080
	v_dual_mov_b32 v118, 0 :: v_dual_mov_b32 v113, 0           // 000000133D04: CA100080 76700080
	v_dual_mov_b32 v116, 0 :: v_dual_mov_b32 v127, 0           // 000000133D0C: CA100080 747E0080
	v_dual_mov_b32 v114, 0 :: v_dual_mov_b32 v125, 0           // 000000133D14: CA100080 727C0080
	v_dual_mov_b32 v112, 0 :: v_dual_mov_b32 v123, 0           // 000000133D1C: CA100080 707A0080
	v_dual_mov_b32 v126, 0 :: v_dual_mov_b32 v121, 0           // 000000133D24: CA100080 7E780080
	v_mov_b32_e32 v124, 0                                      // 000000133D2C: 7EF80280
	v_mov_b32_e32 v122, 0                                      // 000000133D30: 7EF40280
	v_mov_b32_e32 v120, 0                                      // 000000133D34: 7EF00280
	v_lshrrev_b32_e32 v162, 4, v130                            // 000000133D38: 33450484
	v_lshlrev_b32_e32 v160, 1, v159                            // 000000133D3C: 31413E81
	s_add_i32 s1, s26, s1                                      // 000000133D40: 8101011A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000133D44: BF870009
	s_cmp_lt_i32 s1, -15                                       // 000000133D48: BF04CF01
	s_cbranch_scc1 2876                                        // 000000133D4C: BFA20B3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3240>
	v_mad_i64_i32 v[0:1], null, 0x3000, v128, s[4:5]           // 000000133D50: D6FF7C00 001300FF 00003000
	s_ashr_i32 s2, s1, 31                                      // 000000133D5C: 86029F01
	v_mul_u32_u24_e32 v2, 0x210, v157                          // 000000133D60: 16053AFF 00000210
	s_lshr_b32 s2, s2, 28                                      // 000000133D68: 85029C02
	v_mad_u32_u24 v181, v159, 48, 0x9600                       // 000000133D6C: D60B00B5 03FD619F 00009600
	s_add_i32 s1, s1, s2                                       // 000000133D78: 81010201
	v_add_nc_u32_e32 v167, s26, v158                           // 000000133D7C: 4B4F3C1A
	s_ashr_i32 s5, s1, 4                                       // 000000133D80: 86058401
	.long 0xd7006a92                                           // 000000133D84: D7006A92
	v_cndmask_b32_e32 v1, v0, v142, vcc_lo                     // 000000133D88: 02031D00
	s_cmp_eq_u64 s[20:21], 0                                   // 000000133D8C: BF108014
	v_add_co_ci_u32_e64 v147, null, v1, v143, vcc_lo           // 000000133D90: D5207C93 01AB1F01
	v_mul_u32_u24_e32 v0, 48, v133                             // 000000133D98: 16010AB0
	v_add3_u32 v1, v128, s26, 1                                // 000000133D9C: D6550001 02043580
	s_cselect_b32 s12, -1, 0                                   // 000000133DA4: 980C80C1
	s_cmp_lg_u64 s[20:21], 0                                   // 000000133DA8: BF118014
	v_add3_u32 v163, v2, v132, 0xc600                          // 000000133DAC: D65500A3 03FF0902 0000C600
	s_cselect_b32 s13, -1, 0                                   // 000000133DB8: 980D80C1
	s_ashr_i32 s25, s24, 31                                    // 000000133DBC: 86199F18
	v_add3_u32 v164, v0, v160, 0x9600                          // 000000133DC0: D65500A4 03FF4100 00009600
	v_ashrrev_i32_e32 v0, 31, v1                               // 000000133DCC: 3400029F
	s_lshl_b64 s[24:25], s[24:25], 9                           // 000000133DD0: 84988918
	s_add_i32 s15, s15, -1                                     // 000000133DD4: 810FC10F
	s_add_u32 s2, s6, s24                                      // 000000133DD8: 80021806
	s_movk_i32 s6, 0x440                                       // 000000133DDC: B0060440
	v_lshrrev_b32_e32 v0, 30, v0                               // 000000133DE0: 3200009E
	v_mad_u32_u24 v2, v157, s6, 0x3000                         // 000000133DE4: D60B0002 03FC0D9D 00003000
	v_mov_b32_e32 v128, 0                                      // 000000133DF0: 7F000280
	v_lshlrev_b32_e32 v4, 2, v130                              // 000000133DF4: 30090482
	s_addc_u32 s4, s7, s25                                     // 000000133DF8: 82041907
	v_add_nc_u32_e32 v0, v1, v0                                // 000000133DFC: 4A000101
	v_mad_u32_u24 v3, 0x44, v162, v2                           // 000000133E00: D60B0003 040B44FF 00000044
	.long 0xd70002a5                                           // 000000133E0C: D70002A5
	v_cndmask_b32_e32 v1, s2, v132, vcc_lo                     // 000000133E10: 02030802
	v_mov_b32_e32 v121, v128                                   // 000000133E14: 7EF20380
	v_dual_mov_b32 v120, 0 :: v_dual_add_nc_u32 v1, v131, v4   // 000000133E18: CA200080 78000983
	s_delay_alu instid0(VALU_DEP_4)                            // 000000133E20: BF870004
	v_lshl_add_u32 v168, v159, 2, v3                           // 000000133E24: D64600A8 040D059F
	v_dual_mov_b32 v122, v128 :: v_dual_add_nc_u32 v3, 0xed00, v131// 000000133E2C: CA200180 7A0306FF 0000ED00
	v_mov_b32_e32 v123, v128                                   // 000000133E38: 7EF60380
	v_ashrrev_i32_e32 v169, 2, v0                              // 000000133E3C: 35520082
	v_dual_mov_b32 v125, v128 :: v_dual_lshlrev_b32 v0, 9, v157// 000000133E40: CA220180 7D013A89
	v_add_co_ci_u32_e64 v166, null, s4, 0, s2                  // 000000133E48: D5207CA6 00090004
	s_add_u32 s2, s8, s24                                      // 000000133E50: 80021808
	s_mov_b32 s1, 0xc600                                       // 000000133E54: BE8100FF 0000C600
	s_addc_u32 s4, s9, s25                                     // 000000133E5C: 82041909
	.long 0xd70002b2                                           // 000000133E60: D70002B2
	v_cndmask_b32_e32 v1, s2, v129, vcc_lo                     // 000000133E64: 02030202
	v_dual_mov_b32 v127, v128 :: v_dual_add_nc_u32 v170, v167, v130// 000000133E68: CA200180 7FAB05A7
	v_dual_mov_b32 v124, v128 :: v_dual_add_nc_u32 v171, 0xe700, v1// 000000133E70: CA200180 7CAA02FF 0000E700
	v_mad_u32_u24 v172, 0x44, v130, v2                         // 000000133E7C: D60B00AC 040B04FF 00000044
	v_lshl_add_u32 v173, v130, 5, v0                           // 000000133E88: D64600AD 04010B82
	v_dual_mov_b32 v113, v128 :: v_dual_add_nc_u32 v174, 0xf300, v1// 000000133E90: CA200180 71AE02FF 0000F300
	v_dual_mov_b32 v126, v128 :: v_dual_add_nc_u32 v175, v3, v4// 000000133E9C: CA200180 7EAE0903
	v_lshl_or_b32 v176, v162, 2, v3                            // 000000133EA4: D65600B0 040D05A2
	v_lshl_or_b32 v177, v159, 5, v0                            // 000000133EAC: D65600B1 04010B9F
	v_dual_mov_b32 v112, 0 :: v_dual_mov_b32 v115, v128        // 000000133EB4: CA100080 70720180
	v_mov_b32_e32 v114, v128                                   // 000000133EBC: 7EE40380
	v_mov_b32_e32 v116, v128                                   // 000000133EC0: 7EE80380
	v_dual_mov_b32 v117, v128 :: v_dual_mov_b32 v104, 0        // 000000133EC4: CA100180 75680080
	v_mov_b32_e32 v118, v128                                   // 000000133ECC: 7EEC0380
	v_dual_mov_b32 v119, v128 :: v_dual_mov_b32 v96, 0         // 000000133ED0: CA100180 77600080
	v_dual_mov_b32 v105, v128 :: v_dual_mov_b32 v88, 0         // 000000133ED8: CA100180 69580080
	v_mov_b32_e32 v106, v128                                   // 000000133EE0: 7ED40380
	v_dual_mov_b32 v107, v128 :: v_dual_mov_b32 v80, 0         // 000000133EE4: CA100180 6B500080
	v_mov_b32_e32 v108, v128                                   // 000000133EEC: 7ED80380
	v_dual_mov_b32 v109, v128 :: v_dual_mov_b32 v72, 0         // 000000133EF0: CA100180 6D480080
	v_mov_b32_e32 v110, v128                                   // 000000133EF8: 7EDC0380
	v_dual_mov_b32 v111, v128 :: v_dual_mov_b32 v64, 0         // 000000133EFC: CA100180 6F400080
	v_dual_mov_b32 v97, v128 :: v_dual_mov_b32 v56, 0          // 000000133F04: CA100180 61380080
	v_mov_b32_e32 v98, v128                                    // 000000133F0C: 7EC40380
	v_dual_mov_b32 v99, v128 :: v_dual_mov_b32 v48, 0          // 000000133F10: CA100180 63300080
	v_mov_b32_e32 v100, v128                                   // 000000133F18: 7EC80380
	v_dual_mov_b32 v101, v128 :: v_dual_mov_b32 v40, 0         // 000000133F1C: CA100180 65280080
	v_mov_b32_e32 v102, v128                                   // 000000133F24: 7ECC0380
	v_dual_mov_b32 v103, v128 :: v_dual_mov_b32 v32, 0         // 000000133F28: CA100180 67200080
	v_dual_mov_b32 v89, v128 :: v_dual_mov_b32 v24, 0          // 000000133F30: CA100180 59180080
	v_mov_b32_e32 v90, v128                                    // 000000133F38: 7EB40380
	v_dual_mov_b32 v91, v128 :: v_dual_mov_b32 v16, 0          // 000000133F3C: CA100180 5B100080
	v_mov_b32_e32 v92, v128                                    // 000000133F44: 7EB80380
	v_dual_mov_b32 v93, v128 :: v_dual_mov_b32 v8, 0           // 000000133F48: CA100180 5D080080
	v_mov_b32_e32 v94, v128                                    // 000000133F50: 7EBC0380
	v_dual_mov_b32 v95, v128 :: v_dual_mov_b32 v0, 0           // 000000133F54: CA100180 5F000080
	v_dual_mov_b32 v81, v128 :: v_dual_mov_b32 v148, 0         // 000000133F5C: CA100180 51940080
	v_mov_b32_e32 v82, v128                                    // 000000133F64: 7EA40380
	v_mov_b32_e32 v83, v128                                    // 000000133F68: 7EA60380
	v_mov_b32_e32 v84, v128                                    // 000000133F6C: 7EA80380
	v_mov_b32_e32 v85, v128                                    // 000000133F70: 7EAA0380
	v_mov_b32_e32 v86, v128                                    // 000000133F74: 7EAC0380
	v_mov_b32_e32 v87, v128                                    // 000000133F78: 7EAE0380
	v_mov_b32_e32 v73, v128                                    // 000000133F7C: 7E920380
	v_mov_b32_e32 v74, v128                                    // 000000133F80: 7E940380
	v_mov_b32_e32 v75, v128                                    // 000000133F84: 7E960380
	v_mov_b32_e32 v76, v128                                    // 000000133F88: 7E980380
	v_mov_b32_e32 v77, v128                                    // 000000133F8C: 7E9A0380
	v_mov_b32_e32 v78, v128                                    // 000000133F90: 7E9C0380
	v_mov_b32_e32 v79, v128                                    // 000000133F94: 7E9E0380
	v_mov_b32_e32 v65, v128                                    // 000000133F98: 7E820380
	v_mov_b32_e32 v66, v128                                    // 000000133F9C: 7E840380
	v_mov_b32_e32 v67, v128                                    // 000000133FA0: 7E860380
	v_mov_b32_e32 v68, v128                                    // 000000133FA4: 7E880380
	v_mov_b32_e32 v69, v128                                    // 000000133FA8: 7E8A0380
	v_mov_b32_e32 v70, v128                                    // 000000133FAC: 7E8C0380
	v_mov_b32_e32 v71, v128                                    // 000000133FB0: 7E8E0380
	v_mov_b32_e32 v57, v128                                    // 000000133FB4: 7E720380
	v_mov_b32_e32 v58, v128                                    // 000000133FB8: 7E740380
	v_mov_b32_e32 v59, v128                                    // 000000133FBC: 7E760380
	v_mov_b32_e32 v60, v128                                    // 000000133FC0: 7E780380
	v_mov_b32_e32 v61, v128                                    // 000000133FC4: 7E7A0380
	v_mov_b32_e32 v62, v128                                    // 000000133FC8: 7E7C0380
	v_mov_b32_e32 v63, v128                                    // 000000133FCC: 7E7E0380
	v_mov_b32_e32 v49, v128                                    // 000000133FD0: 7E620380
	v_mov_b32_e32 v50, v128                                    // 000000133FD4: 7E640380
	v_mov_b32_e32 v51, v128                                    // 000000133FD8: 7E660380
	v_mov_b32_e32 v52, v128                                    // 000000133FDC: 7E680380
	v_mov_b32_e32 v53, v128                                    // 000000133FE0: 7E6A0380
	v_mov_b32_e32 v54, v128                                    // 000000133FE4: 7E6C0380
	v_mov_b32_e32 v55, v128                                    // 000000133FE8: 7E6E0380
	v_mov_b32_e32 v41, v128                                    // 000000133FEC: 7E520380
	v_mov_b32_e32 v42, v128                                    // 000000133FF0: 7E540380
	v_mov_b32_e32 v43, v128                                    // 000000133FF4: 7E560380
	v_mov_b32_e32 v44, v128                                    // 000000133FF8: 7E580380
	v_mov_b32_e32 v45, v128                                    // 000000133FFC: 7E5A0380
	v_mov_b32_e32 v46, v128                                    // 000000134000: 7E5C0380
	v_mov_b32_e32 v47, v128                                    // 000000134004: 7E5E0380
	v_mov_b32_e32 v33, v128                                    // 000000134008: 7E420380
	v_mov_b32_e32 v34, v128                                    // 00000013400C: 7E440380
	v_mov_b32_e32 v35, v128                                    // 000000134010: 7E460380
	v_mov_b32_e32 v36, v128                                    // 000000134014: 7E480380
	v_mov_b32_e32 v37, v128                                    // 000000134018: 7E4A0380
	v_mov_b32_e32 v38, v128                                    // 00000013401C: 7E4C0380
	v_mov_b32_e32 v39, v128                                    // 000000134020: 7E4E0380
	v_mov_b32_e32 v25, v128                                    // 000000134024: 7E320380
	v_mov_b32_e32 v26, v128                                    // 000000134028: 7E340380
	v_mov_b32_e32 v27, v128                                    // 00000013402C: 7E360380
	v_mov_b32_e32 v28, v128                                    // 000000134030: 7E380380
	v_mov_b32_e32 v29, v128                                    // 000000134034: 7E3A0380
	v_mov_b32_e32 v30, v128                                    // 000000134038: 7E3C0380
	v_mov_b32_e32 v31, v128                                    // 00000013403C: 7E3E0380
	v_mov_b32_e32 v17, v128                                    // 000000134040: 7E220380
	v_mov_b32_e32 v18, v128                                    // 000000134044: 7E240380
	v_mov_b32_e32 v19, v128                                    // 000000134048: 7E260380
	v_mov_b32_e32 v20, v128                                    // 00000013404C: 7E280380
	v_mov_b32_e32 v21, v128                                    // 000000134050: 7E2A0380
	v_mov_b32_e32 v22, v128                                    // 000000134054: 7E2C0380
	v_mov_b32_e32 v23, v128                                    // 000000134058: 7E2E0380
	v_mov_b32_e32 v9, v128                                     // 00000013405C: 7E120380
	v_mov_b32_e32 v10, v128                                    // 000000134060: 7E140380
	v_mov_b32_e32 v11, v128                                    // 000000134064: 7E160380
	v_mov_b32_e32 v12, v128                                    // 000000134068: 7E180380
	v_mov_b32_e32 v13, v128                                    // 00000013406C: 7E1A0380
	v_mov_b32_e32 v14, v128                                    // 000000134070: 7E1C0380
	v_mov_b32_e32 v15, v128                                    // 000000134074: 7E1E0380
	v_mov_b32_e32 v1, v128                                     // 000000134078: 7E020380
	v_mov_b32_e32 v2, v128                                     // 00000013407C: 7E040380
	v_mov_b32_e32 v3, v128                                     // 000000134080: 7E060380
	v_mov_b32_e32 v4, v128                                     // 000000134084: 7E080380
	v_mov_b32_e32 v5, v128                                     // 000000134088: 7E0A0380
	v_mov_b32_e32 v6, v128                                     // 00000013408C: 7E0C0380
	v_mov_b32_e32 v7, v128                                     // 000000134090: 7E0E0380
	v_add_co_ci_u32_e64 v179, null, s4, 0, s2                  // 000000134094: D5207CB3 00090004
	v_mad_u32_u24 v180, 0x210, v159, s1                        // 00000013409C: D60B00B4 00073EFF 00000210
	s_mov_b32 s6, 0                                            // 0000001340A8: BE860080
	s_branch 116                                               // 0000001340AC: BFA00074 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa80>
	ds_load_b128 v[149:152], v181                              // 0000001340B0: DBFC0000 950000B5
	ds_load_b128 v[153:156], v181 offset:16                    // 0000001340B8: DBFC0010 990000B5
	s_waitcnt lgkmcnt(0)                                       // 0000001340C0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[120:127], v[129:136], v[149:156], v[120:127]// 0000001340C4: CC414078 1DE32B81
	ds_load_b128 v[153:156], v181 offset:784                   // 0000001340CC: DBFC0310 990000B5
	ds_load_b128 v[149:152], v181 offset:768                   // 0000001340D4: DBFC0300 950000B5
	s_waitcnt lgkmcnt(0)                                       // 0000001340DC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[112:119], v[129:136], v[149:156], v[112:119]// 0000001340E0: CC414070 1DC32B81
	ds_load_b128 v[153:156], v181 offset:1552                  // 0000001340E8: DBFC0610 990000B5
	ds_load_b128 v[149:152], v181 offset:1536                  // 0000001340F0: DBFC0600 950000B5
	s_waitcnt lgkmcnt(0)                                       // 0000001340F8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[104:111], v[129:136], v[149:156], v[104:111]// 0000001340FC: CC414068 1DA32B81
	ds_load_b128 v[153:156], v181 offset:2320                  // 000000134104: DBFC0910 990000B5
	ds_load_b128 v[149:152], v181 offset:2304                  // 00000013410C: DBFC0900 950000B5
	s_waitcnt lgkmcnt(0)                                       // 000000134114: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[96:103], v[129:136], v[149:156], v[96:103]// 000000134118: CC414060 1D832B81
	ds_load_b128 v[153:156], v181 offset:3088                  // 000000134120: DBFC0C10 990000B5
	ds_load_b128 v[149:152], v181 offset:3072                  // 000000134128: DBFC0C00 950000B5
	s_waitcnt lgkmcnt(0)                                       // 000000134130: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[88:95], v[129:136], v[149:156], v[88:95]// 000000134134: CC414058 1D632B81
	ds_load_b128 v[153:156], v181 offset:3856                  // 00000013413C: DBFC0F10 990000B5
	ds_load_b128 v[149:152], v181 offset:3840                  // 000000134144: DBFC0F00 950000B5
	s_waitcnt lgkmcnt(0)                                       // 00000013414C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[80:87], v[129:136], v[149:156], v[80:87]// 000000134150: CC414050 1D432B81
	ds_load_b128 v[153:156], v181 offset:4624                  // 000000134158: DBFC1210 990000B5
	ds_load_b128 v[149:152], v181 offset:4608                  // 000000134160: DBFC1200 950000B5
	s_waitcnt lgkmcnt(0)                                       // 000000134168: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[72:79], v[129:136], v[149:156], v[72:79]// 00000013416C: CC414048 1D232B81
	ds_load_b128 v[153:156], v181 offset:5392                  // 000000134174: DBFC1510 990000B5
	ds_load_b128 v[149:152], v181 offset:5376                  // 00000013417C: DBFC1500 950000B5
	s_waitcnt lgkmcnt(0)                                       // 000000134184: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[64:71], v[129:136], v[149:156], v[64:71]// 000000134188: CC414040 1D032B81
	ds_load_b128 v[153:156], v181 offset:6160                  // 000000134190: DBFC1810 990000B5
	ds_load_b128 v[149:152], v181 offset:6144                  // 000000134198: DBFC1800 950000B5
	s_waitcnt lgkmcnt(0)                                       // 0000001341A0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[56:63], v[129:136], v[149:156], v[56:63]// 0000001341A4: CC414038 1CE32B81
	ds_load_b128 v[153:156], v181 offset:6928                  // 0000001341AC: DBFC1B10 990000B5
	ds_load_b128 v[149:152], v181 offset:6912                  // 0000001341B4: DBFC1B00 950000B5
	s_waitcnt lgkmcnt(0)                                       // 0000001341BC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[48:55], v[129:136], v[149:156], v[48:55]// 0000001341C0: CC414030 1CC32B81
	ds_load_b128 v[153:156], v181 offset:7696                  // 0000001341C8: DBFC1E10 990000B5
	ds_load_b128 v[149:152], v181 offset:7680                  // 0000001341D0: DBFC1E00 950000B5
	s_waitcnt lgkmcnt(0)                                       // 0000001341D8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[40:47], v[129:136], v[149:156], v[40:47]// 0000001341DC: CC414028 1CA32B81
	ds_load_b128 v[153:156], v181 offset:8464                  // 0000001341E4: DBFC2110 990000B5
	ds_load_b128 v[149:152], v181 offset:8448                  // 0000001341EC: DBFC2100 950000B5
	s_waitcnt lgkmcnt(0)                                       // 0000001341F4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[32:39], v[129:136], v[149:156], v[32:39]// 0000001341F8: CC414020 1C832B81
	ds_load_b128 v[153:156], v181 offset:9232                  // 000000134200: DBFC2410 990000B5
	ds_load_b128 v[149:152], v181 offset:9216                  // 000000134208: DBFC2400 950000B5
	s_waitcnt lgkmcnt(0)                                       // 000000134210: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[24:31], v[129:136], v[149:156], v[24:31]// 000000134214: CC414018 1C632B81
	ds_load_b128 v[153:156], v181 offset:10000                 // 00000013421C: DBFC2710 990000B5
	ds_load_b128 v[149:152], v181 offset:9984                  // 000000134224: DBFC2700 950000B5
	s_waitcnt lgkmcnt(0)                                       // 00000013422C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[16:23], v[129:136], v[149:156], v[16:23]// 000000134230: CC414010 1C432B81
	ds_load_b128 v[153:156], v181 offset:10768                 // 000000134238: DBFC2A10 990000B5
	ds_load_b128 v[149:152], v181 offset:10752                 // 000000134240: DBFC2A00 950000B5
	s_waitcnt lgkmcnt(0)                                       // 000000134248: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[8:15], v[129:136], v[149:156], v[8:15]// 00000013424C: CC414008 1C232B81
	ds_load_b128 v[153:156], v181 offset:11536                 // 000000134254: DBFC2D10 990000B5
	ds_load_b128 v[149:152], v181 offset:11520                 // 00000013425C: DBFC2D00 950000B5
	s_waitcnt lgkmcnt(0)                                       // 000000134264: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[0:7], v[129:136], v[149:156], v[0:7]// 000000134268: CC414000 1C032B81
	s_add_i32 s1, s6, 1                                        // 000000134270: 81018106
	s_cmp_eq_u32 s6, s5                                        // 000000134274: BF060506
	s_mov_b32 s6, s1                                           // 000000134278: BE860001
	s_cbranch_scc1 2544                                        // 00000013427C: BFA209F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3240>
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 000000134280: 916A0D7E
	s_mov_b32 s1, s12                                          // 000000134284: BE81000C
	s_cbranch_vccz 3                                           // 000000134288: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa98>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000013428C: 916A017E
	s_cbranch_vccnz 65527                                      // 000000134290: BFA4FFF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa70>
	s_branch 15                                                // 000000134294: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xad4>
	s_lshr_b32 s1, s6, 3                                       // 000000134298: 85018306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000013429C: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 0000001342A0: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v129, s1                                     // 0000001342A8: 7F020201
	global_load_b32 v129, v129, s[20:21]                       // 0000001342AC: DC520000 81140081
	s_waitcnt vmcnt(0)                                         // 0000001342B4: BF8903F7
	v_lshrrev_b32_e32 v129, s6, v129                           // 0000001342B8: 33030206
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001342BC: BF870091
	v_and_b32_e32 v129, 1, v129                                // 0000001342C0: 37030281
	.long 0xd44a0001                                           // 0000001342C4: D44A0001
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000001342C8: 02030281
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000001342CC: 916A017E
	s_cbranch_vccnz 65511                                      // 0000001342D0: BFA4FFE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa70>
	s_lshl_b32 s2, s6, 4                                       // 0000001342D4: 84028406
	s_waitcnt vmcnt(0)                                         // 0000001342D8: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 0000001342DC: BC7C0000
	s_barrier                                                  // 0000001342E0: BFBD0000
	buffer_gl0_inv                                             // 0000001342E4: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000001342EC: BE812000
	s_cbranch_execz 72                                         // 0000001342F0: BFA50048 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc14>
	scratch_load_b128 v[129:132], off, off                     // 0000001342F4: DC5D0000 817C0000
	s_cmp_ge_i32 s6, s5                                        // 0000001342FC: BF030506
	s_waitcnt vmcnt(0)                                         // 000000134300: BF8903F7
	ds_store_b128 v163, v[129:132]                             // 000000134304: DB7C0000 000081A3
	ds_store_b16 v164, v137                                    // 00000013430C: D87C0000 000089A4
	ds_store_b16_d16_hi v164, v137 offset:48                   // 000000134314: DA840030 000089A4
	ds_store_b16 v164, v138 offset:96                          // 00000013431C: D87C0060 00008AA4
	ds_store_b16_d16_hi v164, v138 offset:144                  // 000000134324: DA840090 00008AA4
	ds_store_b16 v164, v139 offset:192                         // 00000013432C: D87C00C0 00008BA4
	ds_store_b16_d16_hi v164, v139 offset:240                  // 000000134334: DA8400F0 00008BA4
	ds_store_b16 v164, v140 offset:288                         // 00000013433C: D87C0120 00008CA4
	ds_store_b16_d16_hi v164, v140 offset:336                  // 000000134344: DA840150 00008CA4
	s_cbranch_scc1 49                                          // 00000013434C: BFA20031 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc14>
	s_add_i32 s4, s2, 16                                       // 000000134350: 81049002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000134354: BF870129
	v_or_b32_e32 v129, s4, v157                                // 000000134358: 39033A04
	v_or_b32_e32 v130, s4, v159                                // 00000013435C: 39053E04
	v_min_i32_e32 v129, s15, v129                              // 000000134360: 2303020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000134364: BF870112
	v_min_i32_e32 v131, s15, v130                              // 000000134368: 2307040F
	v_ashrrev_i32_e32 v132, 31, v129                           // 00000013436C: 3509029F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000134370: BF870002
	v_ashrrev_i32_e32 v134, 31, v131                           // 000000134374: 350D069F
	.long 0xd72c0085                                           // 000000134378: D72C0085
	v_cndmask_b32_e32 v1, s11, v129, vcc_lo                    // 00000013437C: 0203020B
	v_mad_u64_u32 v[129:130], null, s10, v129, 0               // 000000134380: D6FE7C81 0203020A
	.long 0xd72c0088                                           // 000000134388: D72C0088
	v_cndmask_b32_e32 v1, s11, v131, vcc_lo                    // 00000013438C: 0203060B
	.long 0xd72c0087                                           // 000000134390: D72C0087
	v_cndmask_b32_e32 v1, s10, v132, vcc_lo                    // 000000134394: 0203080A
	v_mad_u64_u32 v[131:132], null, s10, v131, 0               // 000000134398: D6FE7C83 0203060A
	.long 0xd72c0086                                           // 0000001343A0: D72C0086
	v_cndmask_b32_e32 v1, s10, v134, vcc_lo                    // 0000001343A4: 02030C0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001343A8: BF870113
	v_add3_u32 v130, v130, v135, v133                          // 0000001343AC: D6550082 06170F82
	v_add3_u32 v132, v132, v134, v136                          // 0000001343B4: D6550084 06230D84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001343BC: BF870112
	.long 0xd73c0081                                           // 0000001343C0: D73C0081
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000001343C4: 02030281
	.long 0xd73c0083                                           // 0000001343C8: D73C0083
	v_cndmask_b32_e32 v1, 1, v131, vcc_lo                      // 0000001343CC: 02030681
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001343D0: BF870092
	.long 0xd7006a81                                           // 0000001343D4: D7006A81
	v_cndmask_b32_e32 v1, v165, v129, vcc_lo                   // 0000001343D8: 020303A5
	v_add_co_ci_u32_e64 v130, null, v166, v130, vcc_lo         // 0000001343DC: D5207C82 01AB05A6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001343E4: BF870093
	.long 0xd7006a85                                           // 0000001343E8: D7006A85
	v_cndmask_b32_e32 v1, v178, v131, vcc_lo                   // 0000001343EC: 020307B2
	v_add_co_ci_u32_e64 v134, null, v179, v132, vcc_lo         // 0000001343F0: D5207C86 01AB09B3
	global_load_b128 v[129:132], v[129:130], off               // 0000001343F8: DC5E0000 817C0081
	global_load_b128 v[137:140], v[133:134], off               // 000000134400: DC5E0000 897C0085
	s_waitcnt vmcnt(1)                                         // 000000134408: BF8907F7
	scratch_store_b128 off, v[129:132], off                    // 00000013440C: DC750000 007C8100
	s_or_b32 exec_lo, exec_lo, s1                              // 000000134414: 8C7E017E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000134418: BF890007
	s_waitcnt_vscnt null, 0x0                                  // 00000013441C: BC7C0000
	s_barrier                                                  // 000000134420: BFBD0000
	buffer_gl0_inv                                             // 000000134424: E0AC0000 00000000
	s_clause 0x1                                               // 00000013442C: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:16     // 000000134430: DC5E0010 997C0092
	global_load_b128 v[149:152], v[146:147], off               // 000000134438: DC5E0000 957C0092
	ds_load_b128 v[182:185], v180                              // 000000134440: DBFC0000 B60000B4
	ds_load_b128 v[186:189], v180 offset:16                    // 000000134448: DBFC0010 BA0000B4
	v_mov_b32_e32 v135, v128                                   // 000000134450: 7F0E0380
	v_mov_b32_e32 v129, v128                                   // 000000134454: 7F020380
	v_mov_b32_e32 v130, v128                                   // 000000134458: 7F040380
	v_mov_b32_e32 v131, v128                                   // 00000013445C: 7F060380
	v_mov_b32_e32 v132, v128                                   // 000000134460: 7F080380
	v_mov_b32_e32 v133, v128                                   // 000000134464: 7F0A0380
	v_mov_b32_e32 v134, v128                                   // 000000134468: 7F0C0380
	v_mov_b32_e32 v136, v135                                   // 00000013446C: 7F100387
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000134470: BF870212
	v_mov_b32_e32 v135, v134                                   // 000000134474: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 000000134478: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 00000013447C: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 000000134480: 7F080383
	v_mov_b32_e32 v131, v130                                   // 000000134484: 7F060382
	v_mov_b32_e32 v130, v129                                   // 000000134488: 7F040381
	v_mov_b32_e32 v129, v128                                   // 00000013448C: 7F020380
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000134490: BF890007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134494: BF870001
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000134498: CC414081 1E076D95
	s_clause 0x1                                               // 0000001344A0: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:48     // 0000001344A4: DC5E0030 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:32     // 0000001344AC: DC5E0020 957C0092
	ds_load_b128 v[182:185], v180 offset:32                    // 0000001344B4: DBFC0020 B60000B4
	ds_load_b128 v[186:189], v180 offset:48                    // 0000001344BC: DBFC0030 BA0000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001344C4: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 0000001344C8: CC414081 1E076D95
	s_clause 0x1                                               // 0000001344D0: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:80     // 0000001344D4: DC5E0050 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:64     // 0000001344DC: DC5E0040 957C0092
	ds_load_b128 v[186:189], v180 offset:80                    // 0000001344E4: DBFC0050 BA0000B4
	ds_load_b128 v[182:185], v180 offset:64                    // 0000001344EC: DBFC0040 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001344F4: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 0000001344F8: CC414081 1E076D95
	s_clause 0x1                                               // 000000134500: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:112    // 000000134504: DC5E0070 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:96     // 00000013450C: DC5E0060 957C0092
	ds_load_b128 v[186:189], v180 offset:112                   // 000000134514: DBFC0070 BA0000B4
	ds_load_b128 v[182:185], v180 offset:96                    // 00000013451C: DBFC0060 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000134524: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000134528: CC414081 1E076D95
	s_clause 0x1                                               // 000000134530: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:144    // 000000134534: DC5E0090 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:128    // 00000013453C: DC5E0080 957C0092
	ds_load_b128 v[186:189], v180 offset:144                   // 000000134544: DBFC0090 BA0000B4
	ds_load_b128 v[182:185], v180 offset:128                   // 00000013454C: DBFC0080 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000134554: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000134558: CC414081 1E076D95
	s_clause 0x1                                               // 000000134560: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:176    // 000000134564: DC5E00B0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:160    // 00000013456C: DC5E00A0 957C0092
	ds_load_b128 v[186:189], v180 offset:176                   // 000000134574: DBFC00B0 BA0000B4
	ds_load_b128 v[182:185], v180 offset:160                   // 00000013457C: DBFC00A0 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000134584: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000134588: CC414081 1E076D95
	s_clause 0x1                                               // 000000134590: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:208    // 000000134594: DC5E00D0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:192    // 00000013459C: DC5E00C0 957C0092
	ds_load_b128 v[186:189], v180 offset:208                   // 0000001345A4: DBFC00D0 BA0000B4
	ds_load_b128 v[182:185], v180 offset:192                   // 0000001345AC: DBFC00C0 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001345B4: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 0000001345B8: CC414081 1E076D95
	s_clause 0x1                                               // 0000001345C0: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:240    // 0000001345C4: DC5E00F0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:224    // 0000001345CC: DC5E00E0 957C0092
	ds_load_b128 v[186:189], v180 offset:240                   // 0000001345D4: DBFC00F0 BA0000B4
	ds_load_b128 v[182:185], v180 offset:224                   // 0000001345DC: DBFC00E0 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001345E4: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 0000001345E8: CC414081 1E076D95
	s_clause 0x1                                               // 0000001345F0: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:272    // 0000001345F4: DC5E0110 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:256    // 0000001345FC: DC5E0100 957C0092
	ds_load_b128 v[186:189], v180 offset:272                   // 000000134604: DBFC0110 BA0000B4
	ds_load_b128 v[182:185], v180 offset:256                   // 00000013460C: DBFC0100 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000134614: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000134618: CC414081 1E076D95
	s_clause 0x1                                               // 000000134620: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:304    // 000000134624: DC5E0130 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:288    // 00000013462C: DC5E0120 957C0092
	ds_load_b128 v[186:189], v180 offset:304                   // 000000134634: DBFC0130 BA0000B4
	ds_load_b128 v[182:185], v180 offset:288                   // 00000013463C: DBFC0120 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000134644: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000134648: CC414081 1E076D95
	s_clause 0x1                                               // 000000134650: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:336    // 000000134654: DC5E0150 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:320    // 00000013465C: DC5E0140 957C0092
	ds_load_b128 v[186:189], v180 offset:336                   // 000000134664: DBFC0150 BA0000B4
	ds_load_b128 v[182:185], v180 offset:320                   // 00000013466C: DBFC0140 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000134674: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000134678: CC414081 1E076D95
	s_clause 0x1                                               // 000000134680: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:368    // 000000134684: DC5E0170 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:352    // 00000013468C: DC5E0160 957C0092
	ds_load_b128 v[186:189], v180 offset:368                   // 000000134694: DBFC0170 BA0000B4
	ds_load_b128 v[182:185], v180 offset:352                   // 00000013469C: DBFC0160 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001346A4: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 0000001346A8: CC414081 1E076D95
	s_clause 0x1                                               // 0000001346B0: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:400    // 0000001346B4: DC5E0190 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:384    // 0000001346BC: DC5E0180 957C0092
	ds_load_b128 v[186:189], v180 offset:400                   // 0000001346C4: DBFC0190 BA0000B4
	ds_load_b128 v[182:185], v180 offset:384                   // 0000001346CC: DBFC0180 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001346D4: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 0000001346D8: CC414081 1E076D95
	s_clause 0x1                                               // 0000001346E0: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:432    // 0000001346E4: DC5E01B0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:416    // 0000001346EC: DC5E01A0 957C0092
	ds_load_b128 v[186:189], v180 offset:432                   // 0000001346F4: DBFC01B0 BA0000B4
	ds_load_b128 v[182:185], v180 offset:416                   // 0000001346FC: DBFC01A0 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000134704: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000134708: CC414081 1E076D95
	s_clause 0x1                                               // 000000134710: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:464    // 000000134714: DC5E01D0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:448    // 00000013471C: DC5E01C0 957C0092
	ds_load_b128 v[186:189], v180 offset:464                   // 000000134724: DBFC01D0 BA0000B4
	ds_load_b128 v[182:185], v180 offset:448                   // 00000013472C: DBFC01C0 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000134734: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000134738: CC414081 1E076D95
	s_clause 0x1                                               // 000000134740: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:496    // 000000134744: DC5E01F0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:480    // 00000013474C: DC5E01E0 957C0092
	ds_load_b128 v[186:189], v180 offset:496                   // 000000134754: DBFC01F0 BA0000B4
	ds_load_b128 v[182:185], v180 offset:480                   // 00000013475C: DBFC01E0 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000134764: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000134768: CC414081 1E076D95
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000134770: BF870111
	v_dual_mul_f32 v129, 0x3d800000, v129 :: v_dual_mul_f32 v130, 0x3d800000, v130// 000000134774: C8C702FF 818304FF 3D800000
	v_mul_f32_e32 v149, 0x3d800000, v133                       // 000000134780: 112B0AFF 3D800000
	v_mov_b32_e32 v133, 0xffff                                 // 000000134788: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000134790: BF870004
	v_dual_mul_f32 v131, 0x3d800000, v131 :: v_dual_mul_f32 v132, 0x3d800000, v132// 000000134794: C8C706FF 838508FF 3D800000
	v_dual_mul_f32 v134, 0x3d800000, v134 :: v_dual_mul_f32 v135, 0x3d800000, v135// 0000001347A0: C8C70CFF 86870EFF 3D800000
	v_mul_f32_e32 v136, 0x3d800000, v136                       // 0000001347AC: 111110FF 3D800000
	ds_store_2addr_b32 v168, v129, v130 offset1:34             // 0000001347B4: D8382200 008281A8
	ds_store_2addr_b32 v168, v131, v132 offset0:68 offset1:102 // 0000001347BC: D8386644 008483A8
	ds_store_2addr_b32 v168, v149, v134 offset0:136 offset1:170// 0000001347C4: D838AA88 008695A8
	ds_store_2addr_b32 v168, v135, v136 offset0:204 offset1:238// 0000001347CC: D838EECC 008887A8
	s_and_saveexec_b32 s4, s23                                 // 0000001347D4: BE842017
	s_cbranch_execz 365                                        // 0000001347D8: BFA5016D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1590>
	s_lshl_b32 s7, s6, 2                                       // 0000001347DC: 84078206
	s_mov_b32 s8, exec_lo                                      // 0000001347E0: BE88007E
	.long 0xd4c1007e                                           // 0000001347E4: D4C1007E
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 0000001347E8: 02034394
	s_cbranch_execz 50                                         // 0000001347EC: BFA50032 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10b8>
	v_ashrrev_i32_e32 v149, 31, v148                           // 0000001347F0: 352B289F
	s_mov_b32 s9, 0                                            // 0000001347F4: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001347F8: BF870091
	.long 0xd73c0081                                           // 0000001347FC: D73C0081
	v_cndmask_b32_e32 v1, 2, v148, vcc_lo                      // 000000134800: 02032882
	.long 0xd7006a81                                           // 000000134804: D7006A81
	v_cndmask_b32_e32 v1, v144, v129, vcc_lo                   // 000000134808: 02030390
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013480C: BF870001
	v_add_co_ci_u32_e64 v130, null, v145, v130, vcc_lo         // 000000134810: D5207C82 01AB0591
	s_branch 17                                                // 000000134818: BFA00011 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1060>
	s_nop 0                                                    // 00000013481C: BF800000
	s_nop 0                                                    // 000000134820: BF800000
	s_nop 0                                                    // 000000134824: BF800000
	s_nop 0                                                    // 000000134828: BF800000
	s_nop 0                                                    // 00000013482C: BF800000
	s_nop 0                                                    // 000000134830: BF800000
	s_nop 0                                                    // 000000134834: BF800000
	s_nop 0                                                    // 000000134838: BF800000
	s_nop 0                                                    // 00000013483C: BF800000
	s_or_b32 exec_lo, exec_lo, s24                             // 000000134840: 8C7E187E
	v_mov_b32_e32 v132, v148                                   // 000000134844: 7F080394
	v_mov_b32_e32 v148, v131                                   // 000000134848: 7F280383
	s_and_b32 s1, exec_lo, s22                                 // 00000013484C: 8B01167E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000134850: BF870499
	s_or_b32 s9, s1, s9                                        // 000000134854: 8C090901
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 000000134858: 917E097E
	s_cbranch_execz 20                                         // 00000013485C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10b0>
	global_load_b32 v131, v[129:130], off                      // 000000134860: DC520000 837C0081
	s_or_b32 s22, s22, exec_lo                                 // 000000134868: 8C167E16
	s_waitcnt vmcnt(0)                                         // 00000013486C: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s7, v131                          // 000000134870: 7C890607
	s_and_saveexec_b32 s24, vcc_lo                             // 000000134874: BE98206A
	s_cbranch_execz 65521                                      // 000000134878: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	v_dual_mov_b32 v148, v161 :: v_dual_add_nc_u32 v131, 1, v148// 00000013487C: CA2001A1 94832881
	.long 0xd7000181                                           // 000000134884: D7000181
	v_cndmask_b32_e32 v0, v129, v132, vcc_lo                   // 000000134888: 02010981
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013488C: BF870191
	v_add_co_ci_u32_e64 v130, null, 0, v130, s1                // 000000134890: D5207C82 00070480
	v_cmp_eq_u32_e32 vcc_lo, v161, v131                        // 000000134898: 7C9507A1
	s_and_not1_b32 s1, s22, exec_lo                            // 00000013489C: 91017E16
	s_and_b32 s22, vcc_lo, exec_lo                             // 0000001348A0: 8B167E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001348A4: BF870009
	s_or_b32 s22, s1, s22                                      // 0000001348A8: 8C161601
	s_branch 65508                                             // 0000001348AC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000001348B0: 8C7E097E
	v_mov_b32_e32 v148, v132                                   // 0000001348B4: 7F280384
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001348B8: 8C7E087E
	v_mov_b32_e32 v133, 15                                     // 0000001348BC: 7F0A028F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001348C0: BF870002
	v_mov_b32_e32 v129, v148                                   // 0000001348C4: 7F020394
	s_mov_b32 s1, exec_lo                                      // 0000001348C8: BE81007E
	.long 0xd4c1007e                                           // 0000001348CC: D4C1007E
	v_cndmask_b32_e32 v1, s7, v169, vcc_lo                     // 0000001348D0: 02035207
	s_cbranch_execz 62                                         // 0000001348D4: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11d0>
	v_mov_b32_e32 v133, 0                                      // 0000001348D8: 7F0A0280
	v_mov_b32_e32 v129, v148                                   // 0000001348DC: 7F020394
	s_mov_b32 s8, exec_lo                                      // 0000001348E0: BE88007E
	.long 0xd4c1007e                                           // 0000001348E4: D4C1007E
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 0000001348E8: 02034394
	s_cbranch_execz 54                                         // 0000001348EC: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11c8>
	v_mov_b32_e32 v129, v148                                   // 0000001348F0: 7F020394
	s_mov_b32 s22, 0                                           // 0000001348F4: BE960080
	s_set_inst_prefetch_distance 0x1                           // 0000001348F8: BF840001
	s_branch 10                                                // 0000001348FC: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1128>
	s_or_b32 exec_lo, exec_lo, s26                             // 000000134900: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000134904: BF870499
	s_and_b32 s26, exec_lo, s25                                // 000000134908: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 00000013490C: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 000000134910: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 000000134914: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134918: BF870009
	s_or_b32 s9, s9, s26                                       // 00000013491C: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 000000134920: 917E167E
	s_cbranch_execz 28                                         // 000000134924: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1198>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000134928: BF8700C1
	v_mov_b32_e32 v130, v129                                   // 00000013492C: 7F040381
	s_or_b32 s24, s24, exec_lo                                 // 000000134930: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 000000134934: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 000000134938: BE9A007E
	v_ashrrev_i32_e32 v131, 31, v130                           // 00000013493C: 3507049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134940: BF870091
	.long 0xd73c0083                                           // 000000134944: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 000000134948: 02030482
	.long 0xd7006a83                                           // 00000013494C: D7006A83
	v_cndmask_b32_e32 v1, v144, v131, vcc_lo                   // 000000134950: 02030790
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134954: BF870001
	v_add_co_ci_u32_e64 v132, null, v145, v132, vcc_lo         // 000000134958: D5207C84 01AB0991
	global_load_b32 v131, v[131:132], off                      // 000000134960: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 000000134968: BF8903F7
	.long 0xd4c4007e                                           // 00000013496C: D4C4007E
	v_cndmask_b32_e32 v1, s7, v131, vcc_lo                     // 000000134970: 02030607
	s_cbranch_execz 65506                                      // 000000134974: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1100>
	v_add_nc_u32_e32 v129, 1, v130                             // 000000134978: 4B030481
	s_and_not1_b32 s25, s25, exec_lo                           // 00000013497C: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 000000134980: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000134984: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 000000134988: 7C9503A1
	s_and_b32 s27, vcc_lo, exec_lo                             // 00000013498C: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 000000134990: 8C191B19
	s_branch 65498                                             // 000000134994: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1100>
	s_set_inst_prefetch_distance 0x2                           // 000000134998: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 00000013499C: 8C7E167E
	v_mov_b32_e32 v133, 0                                      // 0000001349A0: 7F0A0280
	v_mov_b32_e32 v129, v161                                   // 0000001349A4: 7F0203A1
	s_and_saveexec_b32 s22, s9                                 // 0000001349A8: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001349AC: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 0000001349B0: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v131                          // 0000001349B4: 7C950607
	v_mov_b32_e32 v129, v130                                   // 0000001349B8: 7F020382
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 0000001349BC: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s9                              // 0000001349C4: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001349C8: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001349CC: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001349D0: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001349D4: 8C7E017E
	s_or_b32 s8, s7, 1                                         // 0000001349D8: 8C088107
	s_mov_b32 s1, exec_lo                                      // 0000001349DC: BE81007E
	.long 0xd4c6007e                                           // 0000001349E0: D4C6007E
	v_cndmask_b32_e32 v1, s8, v169, vcc_lo                     // 0000001349E4: 02035208
	s_xor_b32 s1, exec_lo, s1                                  // 0000001349E8: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 0000001349EC: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 0000001349F4: BE813001
	s_cbranch_execz 70                                         // 0000001349F8: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1314>
	s_mov_b32 s9, exec_lo                                      // 0000001349FC: BE89007E
	.long 0xd4c1007e                                           // 000000134A00: D4C1007E
	v_cndmask_b32_e32 v1, v129, v161, vcc_lo                   // 000000134A04: 02034381
	s_cbranch_execz 64                                         // 000000134A08: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x130c>
	s_mov_b32 s24, 0                                           // 000000134A0C: BE980080
	s_set_inst_prefetch_distance 0x1                           // 000000134A10: BF840001
	s_branch 20                                                // 000000134A14: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1268>
	s_nop 0                                                    // 000000134A18: BF800000
	s_nop 0                                                    // 000000134A1C: BF800000
	s_nop 0                                                    // 000000134A20: BF800000
	s_nop 0                                                    // 000000134A24: BF800000
	s_nop 0                                                    // 000000134A28: BF800000
	s_nop 0                                                    // 000000134A2C: BF800000
	s_nop 0                                                    // 000000134A30: BF800000
	s_nop 0                                                    // 000000134A34: BF800000
	s_nop 0                                                    // 000000134A38: BF800000
	s_nop 0                                                    // 000000134A3C: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 000000134A40: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000134A44: BF870499
	s_and_b32 s27, exec_lo, s26                                // 000000134A48: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 000000134A4C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 000000134A50: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 000000134A54: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134A58: BF870009
	s_or_b32 s22, s22, s27                                     // 000000134A5C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 000000134A60: 917E187E
	s_cbranch_execz 27                                         // 000000134A64: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12d4>
	v_mov_b32_e32 v130, v129                                   // 000000134A68: 7F040381
	s_or_b32 s25, s25, exec_lo                                 // 000000134A6C: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 000000134A70: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 000000134A74: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134A78: BF870091
	v_ashrrev_i32_e32 v131, 31, v130                           // 000000134A7C: 3507049F
	.long 0xd73c0083                                           // 000000134A80: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 000000134A84: 02030482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134A88: BF870091
	.long 0xd7006a83                                           // 000000134A8C: D7006A83
	v_cndmask_b32_e32 v1, v144, v131, vcc_lo                   // 000000134A90: 02030790
	v_add_co_ci_u32_e64 v132, null, v145, v132, vcc_lo         // 000000134A94: D5207C84 01AB0991
	global_load_b32 v131, v[131:132], off                      // 000000134A9C: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 000000134AA4: BF8903F7
	.long 0xd4c6007e                                           // 000000134AA8: D4C6007E
	v_cndmask_b32_e32 v1, s7, v131, vcc_lo                     // 000000134AAC: 02030607
	s_cbranch_execz 65507                                      // 000000134AB0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	v_add_nc_u32_e32 v129, 1, v130                             // 000000134AB4: 4B030481
	s_and_not1_b32 s26, s26, exec_lo                           // 000000134AB8: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 000000134ABC: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000134AC0: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 000000134AC4: 7C9503A1
	s_and_b32 s28, vcc_lo, exec_lo                             // 000000134AC8: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 000000134ACC: 8C1A1C1A
	s_branch 65499                                             // 000000134AD0: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	s_set_inst_prefetch_distance 0x2                           // 000000134AD4: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 000000134AD8: 8C7E187E
	v_mov_b32_e32 v129, v161                                   // 000000134ADC: 7F0203A1
	s_and_saveexec_b32 s24, s22                                // 000000134AE0: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134AE4: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 000000134AE8: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v131                          // 000000134AEC: 7C950608
	v_cndmask_b32_e64 v129, 0, 0xf0, vcc_lo                    // 000000134AF0: D5010081 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134AFC: BF870001
	v_or_b32_e32 v133, v129, v133                              // 000000134B00: 390B0B81
	v_mov_b32_e32 v129, v130                                   // 000000134B04: 7F020382
	s_or_b32 exec_lo, exec_lo, s22                             // 000000134B08: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134B0C: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 000000134B10: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134B14: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000134B18: 8C7E017E
	s_or_b32 s8, s7, 2                                         // 000000134B1C: 8C088207
	s_mov_b32 s1, exec_lo                                      // 000000134B20: BE81007E
	.long 0xd4c6007e                                           // 000000134B24: D4C6007E
	v_cndmask_b32_e32 v1, s8, v169, vcc_lo                     // 000000134B28: 02035208
	s_xor_b32 s1, exec_lo, s1                                  // 000000134B2C: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 000000134B30: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 000000134B38: BE813001
	s_cbranch_execz 69                                         // 000000134B3C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1454>
	s_mov_b32 s9, exec_lo                                      // 000000134B40: BE89007E
	.long 0xd4c1007e                                           // 000000134B44: D4C1007E
	v_cndmask_b32_e32 v1, v129, v161, vcc_lo                   // 000000134B48: 02034381
	s_cbranch_execz 63                                         // 000000134B4C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x144c>
	s_mov_b32 s24, 0                                           // 000000134B50: BE980080
	s_set_inst_prefetch_distance 0x1                           // 000000134B54: BF840001
	s_branch 19                                                // 000000134B58: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13a8>
	s_nop 0                                                    // 000000134B5C: BF800000
	s_nop 0                                                    // 000000134B60: BF800000
	s_nop 0                                                    // 000000134B64: BF800000
	s_nop 0                                                    // 000000134B68: BF800000
	s_nop 0                                                    // 000000134B6C: BF800000
	s_nop 0                                                    // 000000134B70: BF800000
	s_nop 0                                                    // 000000134B74: BF800000
	s_nop 0                                                    // 000000134B78: BF800000
	s_nop 0                                                    // 000000134B7C: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 000000134B80: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000134B84: BF870499
	s_and_b32 s27, exec_lo, s26                                // 000000134B88: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 000000134B8C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 000000134B90: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 000000134B94: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134B98: BF870009
	s_or_b32 s22, s22, s27                                     // 000000134B9C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 000000134BA0: 917E187E
	s_cbranch_execz 27                                         // 000000134BA4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1414>
	v_mov_b32_e32 v130, v129                                   // 000000134BA8: 7F040381
	s_or_b32 s25, s25, exec_lo                                 // 000000134BAC: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 000000134BB0: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 000000134BB4: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134BB8: BF870091
	v_ashrrev_i32_e32 v131, 31, v130                           // 000000134BBC: 3507049F
	.long 0xd73c0083                                           // 000000134BC0: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 000000134BC4: 02030482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134BC8: BF870091
	.long 0xd7006a83                                           // 000000134BCC: D7006A83
	v_cndmask_b32_e32 v1, v144, v131, vcc_lo                   // 000000134BD0: 02030790
	v_add_co_ci_u32_e64 v132, null, v145, v132, vcc_lo         // 000000134BD4: D5207C84 01AB0991
	global_load_b32 v131, v[131:132], off                      // 000000134BDC: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 000000134BE4: BF8903F7
	.long 0xd4c4007e                                           // 000000134BE8: D4C4007E
	v_cndmask_b32_e32 v1, s8, v131, vcc_lo                     // 000000134BEC: 02030608
	s_cbranch_execz 65507                                      // 000000134BF0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1380>
	v_add_nc_u32_e32 v129, 1, v130                             // 000000134BF4: 4B030481
	s_and_not1_b32 s26, s26, exec_lo                           // 000000134BF8: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 000000134BFC: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000134C00: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 000000134C04: 7C9503A1
	s_and_b32 s28, vcc_lo, exec_lo                             // 000000134C08: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 000000134C0C: 8C1A1C1A
	s_branch 65499                                             // 000000134C10: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1380>
	s_set_inst_prefetch_distance 0x2                           // 000000134C14: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 000000134C18: 8C7E187E
	v_mov_b32_e32 v129, v161                                   // 000000134C1C: 7F0203A1
	s_and_saveexec_b32 s24, s22                                // 000000134C20: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134C24: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 000000134C28: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v131                          // 000000134C2C: 7C950608
	v_cndmask_b32_e64 v129, 0, 0xf00, vcc_lo                   // 000000134C30: D5010081 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134C3C: BF870001
	v_or_b32_e32 v133, v129, v133                              // 000000134C40: 390B0B81
	v_mov_b32_e32 v129, v130                                   // 000000134C44: 7F020382
	s_or_b32 exec_lo, exec_lo, s22                             // 000000134C48: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134C4C: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 000000134C50: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134C54: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000134C58: 8C7E017E
	s_or_b32 s7, s7, 3                                         // 000000134C5C: 8C078307
	s_mov_b32 s1, exec_lo                                      // 000000134C60: BE81007E
	.long 0xd4c6007e                                           // 000000134C64: D4C6007E
	v_cndmask_b32_e32 v1, s7, v169, vcc_lo                     // 000000134C68: 02035207
	s_xor_b32 s1, exec_lo, s1                                  // 000000134C6C: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 000000134C70: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 000000134C78: BE813001
	s_cbranch_execz 66                                         // 000000134C7C: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1588>
	s_mov_b32 s8, exec_lo                                      // 000000134C80: BE88007E
	.long 0xd4c1007e                                           // 000000134C84: D4C1007E
	v_cndmask_b32_e32 v1, v129, v161, vcc_lo                   // 000000134C88: 02034381
	s_cbranch_execz 60                                         // 000000134C8C: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1580>
	s_mov_b32 s22, 0                                           // 000000134C90: BE960080
	s_set_inst_prefetch_distance 0x1                           // 000000134C94: BF840001
	s_branch 19                                                // 000000134C98: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14e8>
	s_nop 0                                                    // 000000134C9C: BF800000
	s_nop 0                                                    // 000000134CA0: BF800000
	s_nop 0                                                    // 000000134CA4: BF800000
	s_nop 0                                                    // 000000134CA8: BF800000
	s_nop 0                                                    // 000000134CAC: BF800000
	s_nop 0                                                    // 000000134CB0: BF800000
	s_nop 0                                                    // 000000134CB4: BF800000
	s_nop 0                                                    // 000000134CB8: BF800000
	s_nop 0                                                    // 000000134CBC: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 000000134CC0: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000134CC4: BF870499
	s_and_b32 s26, exec_lo, s25                                // 000000134CC8: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 000000134CCC: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 000000134CD0: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 000000134CD4: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134CD8: BF870009
	s_or_b32 s9, s9, s26                                       // 000000134CDC: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 000000134CE0: 917E167E
	s_cbranch_execz 26                                         // 000000134CE4: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1550>
	v_ashrrev_i32_e32 v130, 31, v129                           // 000000134CE8: 3505029F
	s_or_b32 s24, s24, exec_lo                                 // 000000134CEC: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 000000134CF0: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 000000134CF4: BE9A007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134CF8: BF870091
	.long 0xd73c0082                                           // 000000134CFC: D73C0082
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 000000134D00: 02030282
	.long 0xd7006a82                                           // 000000134D04: D7006A82
	v_cndmask_b32_e32 v1, v144, v130, vcc_lo                   // 000000134D08: 02030590
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134D0C: BF870001
	v_add_co_ci_u32_e64 v131, null, v145, v131, vcc_lo         // 000000134D10: D5207C83 01AB0791
	global_load_b32 v130, v[130:131], off                      // 000000134D18: DC520000 827C0082
	s_waitcnt vmcnt(0)                                         // 000000134D20: BF8903F7
	.long 0xd4c4007e                                           // 000000134D24: D4C4007E
	v_cndmask_b32_e32 v1, s7, v130, vcc_lo                     // 000000134D28: 02030407
	s_cbranch_execz 65508                                      // 000000134D2C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	v_add_nc_u32_e32 v129, 1, v129                             // 000000134D30: 4B030281
	s_and_not1_b32 s25, s25, exec_lo                           // 000000134D34: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 000000134D38: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000134D3C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 000000134D40: 7C9503A1
	s_and_b32 s27, vcc_lo, exec_lo                             // 000000134D44: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 000000134D48: 8C191B19
	s_branch 65500                                             // 000000134D4C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	s_set_inst_prefetch_distance 0x2                           // 000000134D50: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 000000134D54: 8C7E167E
	s_and_saveexec_b32 s22, s9                                 // 000000134D58: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134D5C: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 000000134D60: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v130                          // 000000134D64: 7C950407
	v_cndmask_b32_e64 v129, 0, 0xf000, vcc_lo                  // 000000134D68: D5010081 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134D74: BF870001
	v_or_b32_e32 v133, v129, v133                              // 000000134D78: 390B0B81
	s_or_b32 exec_lo, exec_lo, s9                              // 000000134D7C: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134D80: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 000000134D84: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134D88: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000134D8C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000134D90: BF8704C9
	s_or_b32 exec_lo, exec_lo, s4                              // 000000134D94: 8C7E047E
	v_cmp_eq_u32_e32 vcc_lo, 0xffff, v133                      // 000000134D98: 7C950AFF 0000FFFF
	s_cmp_eq_u32 vcc_lo, -1                                    // 000000134DA0: BF06C16A
	s_cselect_b32 s1, -1, 0                                    // 000000134DA4: 980180C1
	v_cndmask_b32_e64 v129, 0, 1, s1                           // 000000134DA8: D5010081 00050280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134DB0: BF870001
	v_readfirstlane_b32 s1, v129                               // 000000134DB4: 7E020581
	s_bitcmp0_b32 s1, 0                                        // 000000134DB8: BF0C8001
	s_mov_b32 s1, 0                                            // 000000134DBC: BE810080
	s_cbranch_scc1 8                                           // 000000134DC0: BFA20008 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15e4>
	s_or_b32 s1, s2, 15                                        // 000000134DC4: 8C018F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000134DC8: BF8700A9
	v_cmp_le_i32_e32 vcc_lo, s1, v167                          // 000000134DCC: 7C874E01
	v_cndmask_b32_e64 v129, 0, 1, vcc_lo                       // 000000134DD0: D5010081 01A90280
	v_readfirstlane_b32 s1, v129                               // 000000134DD8: 7E020581
	s_bitcmp1_b32 s1, 0                                        // 000000134DDC: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 000000134DE0: 980180C1
	s_and_saveexec_b32 s4, s3                                  // 000000134DE4: BE842003
	s_cbranch_execz 1631                                       // 000000134DE8: BFA5065F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2f68>
	ds_load_b32 v131, v171                                     // 000000134DEC: D8D80000 830000AB
	s_xor_b32 s1, s1, -1                                       // 000000134DF4: 8D01C101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134DF8: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000134DFC: 916A017E
	s_mov_b32 s1, -1                                           // 000000134E00: BE8100C1
	s_cbranch_vccnz 987                                        // 000000134E04: BFA403DB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2574>
	s_waitcnt lgkmcnt(0)                                       // 000000134E08: BF89FC07
	v_dual_mov_b32 v132, v131 :: v_dual_and_b32 v129, 1, v133  // 000000134E0C: CA240183 84810A81
	v_cmp_le_i32_e32 vcc_lo, s2, v170                          // 000000134E14: 7C875402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000134E18: BF8704A2
	.long 0xd44a0001                                           // 000000134E1C: D44A0001
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 000000134E20: 02030281
	s_and_b32 s35, vcc_lo, s1                                  // 000000134E24: 8B23016A
	s_and_saveexec_b32 s1, s35                                 // 000000134E28: BE812023
	s_cbranch_execz 7                                          // 000000134E2C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x164c>
	ds_load_b32 v129, v172                                     // 000000134E30: D8D80000 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000134E38: BF89FC07
	v_dual_max_f32 v130, v131, v131 :: v_dual_max_f32 v129, v129, v129// 000000134E3C: CA950783 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134E44: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000134E48: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000134E4C: 8C7E017E
	v_and_b32_e32 v129, 2, v133                                // 000000134E50: 37030A82
	v_cmp_lt_i32_e32 vcc_lo, s2, v170                          // 000000134E54: 7C835402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000134E58: BF8704A2
	.long 0xd44d0001                                           // 000000134E5C: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000134E60: 02030280
	s_and_b32 s34, vcc_lo, s1                                  // 000000134E64: 8B22016A
	s_and_saveexec_b32 s1, s34                                 // 000000134E68: BE812022
	s_cbranch_execz 7                                          // 000000134E6C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x168c>
	ds_load_b32 v129, v172 offset:4                            // 000000134E70: D8D80004 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000134E78: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000134E7C: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134E84: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000134E88: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000134E8C: 8C7E017E
	v_and_b32_e32 v129, 4, v133                                // 000000134E90: 37030A84
	s_or_b32 s1, s2, 2                                         // 000000134E94: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000134E98: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 000000134E9C: 7C875401
	.long 0xd44d0001                                           // 000000134EA0: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000134EA4: 02030280
	s_and_b32 s33, vcc_lo, s1                                  // 000000134EA8: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134EAC: BF870009
	s_and_saveexec_b32 s1, s33                                 // 000000134EB0: BE812021
	s_cbranch_execz 7                                          // 000000134EB4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16d4>
	ds_load_b32 v129, v172 offset:8                            // 000000134EB8: D8D80008 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000134EC0: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000134EC4: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134ECC: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000134ED0: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000134ED4: 8C7E017E
	v_and_b32_e32 v129, 8, v133                                // 000000134ED8: 37030A88
	s_or_b32 s1, s2, 3                                         // 000000134EDC: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000134EE0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 000000134EE4: 7C875401
	.long 0xd44d0001                                           // 000000134EE8: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000134EEC: 02030280
	s_and_b32 s31, vcc_lo, s1                                  // 000000134EF0: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134EF4: BF870009
	s_and_saveexec_b32 s1, s31                                 // 000000134EF8: BE81201F
	s_cbranch_execz 7                                          // 000000134EFC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x171c>
	ds_load_b32 v129, v172 offset:12                           // 000000134F00: D8D8000C 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000134F08: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000134F0C: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134F14: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000134F18: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000134F1C: 8C7E017E
	v_and_b32_e32 v129, 16, v133                               // 000000134F20: 37030A90
	s_or_b32 s1, s2, 4                                         // 000000134F24: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000134F28: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 000000134F2C: 7C875401
	.long 0xd44d0001                                           // 000000134F30: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000134F34: 02030280
	s_and_b32 s30, vcc_lo, s1                                  // 000000134F38: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134F3C: BF870009
	s_and_saveexec_b32 s1, s30                                 // 000000134F40: BE81201E
	s_cbranch_execz 7                                          // 000000134F44: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1764>
	ds_load_b32 v129, v172 offset:16                           // 000000134F48: D8D80010 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000134F50: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000134F54: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134F5C: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000134F60: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000134F64: 8C7E017E
	v_and_b32_e32 v129, 32, v133                               // 000000134F68: 37030AA0
	s_or_b32 s1, s2, 5                                         // 000000134F6C: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000134F70: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 000000134F74: 7C875401
	.long 0xd44d0001                                           // 000000134F78: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000134F7C: 02030280
	s_and_b32 s29, vcc_lo, s1                                  // 000000134F80: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134F84: BF870009
	s_and_saveexec_b32 s1, s29                                 // 000000134F88: BE81201D
	s_cbranch_execz 7                                          // 000000134F8C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17ac>
	ds_load_b32 v129, v172 offset:20                           // 000000134F90: D8D80014 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000134F98: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000134F9C: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134FA4: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000134FA8: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000134FAC: 8C7E017E
	v_and_b32_e32 v129, 64, v133                               // 000000134FB0: 37030AC0
	s_or_b32 s1, s2, 6                                         // 000000134FB4: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000134FB8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 000000134FBC: 7C875401
	.long 0xd44d0001                                           // 000000134FC0: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000134FC4: 02030280
	s_and_b32 s28, vcc_lo, s1                                  // 000000134FC8: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000134FCC: BF870009
	s_and_saveexec_b32 s1, s28                                 // 000000134FD0: BE81201C
	s_cbranch_execz 7                                          // 000000134FD4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17f4>
	ds_load_b32 v129, v172 offset:24                           // 000000134FD8: D8D80018 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000134FE0: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000134FE4: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000134FEC: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000134FF0: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000134FF4: 8C7E017E
	v_and_b32_e32 v129, 0x80, v133                             // 000000134FF8: 37030AFF 00000080
	s_or_b32 s1, s2, 7                                         // 000000135000: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000135004: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 000000135008: 7C875401
	.long 0xd44d0001                                           // 00000013500C: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000135010: 02030280
	s_and_b32 s27, vcc_lo, s1                                  // 000000135014: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000135018: BF870009
	s_and_saveexec_b32 s1, s27                                 // 00000013501C: BE81201B
	s_cbranch_execz 7                                          // 000000135020: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1840>
	ds_load_b32 v129, v172 offset:28                           // 000000135024: D8D8001C 810000AC
	s_waitcnt lgkmcnt(0)                                       // 00000013502C: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000135030: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000135038: BF870001
	v_max_f32_e32 v132, v130, v129                             // 00000013503C: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000135040: 8C7E017E
	v_and_b32_e32 v129, 0x100, v133                            // 000000135044: 37030AFF 00000100
	s_or_b32 s1, s2, 8                                         // 00000013504C: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000135050: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 000000135054: 7C875401
	.long 0xd44d0001                                           // 000000135058: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 00000013505C: 02030280
	s_and_b32 s26, vcc_lo, s1                                  // 000000135060: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000135064: BF870009
	s_and_saveexec_b32 s1, s26                                 // 000000135068: BE81201A
	s_cbranch_execz 7                                          // 00000013506C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x188c>
	ds_load_b32 v129, v172 offset:32                           // 000000135070: D8D80020 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000135078: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 00000013507C: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000135084: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000135088: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013508C: 8C7E017E
	v_and_b32_e32 v129, 0x200, v133                            // 000000135090: 37030AFF 00000200
	s_or_b32 s1, s2, 9                                         // 000000135098: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013509C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 0000001350A0: 7C875401
	.long 0xd44d0001                                           // 0000001350A4: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 0000001350A8: 02030280
	s_and_b32 s25, vcc_lo, s1                                  // 0000001350AC: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001350B0: BF870009
	s_and_saveexec_b32 s1, s25                                 // 0000001350B4: BE812019
	s_cbranch_execz 7                                          // 0000001350B8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18d8>
	ds_load_b32 v129, v172 offset:36                           // 0000001350BC: D8D80024 810000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001350C4: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 0000001350C8: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001350D0: BF870001
	v_max_f32_e32 v132, v130, v129                             // 0000001350D4: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001350D8: 8C7E017E
	v_and_b32_e32 v129, 0x400, v133                            // 0000001350DC: 37030AFF 00000400
	s_or_b32 s1, s2, 10                                        // 0000001350E4: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001350E8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 0000001350EC: 7C875401
	.long 0xd44d0001                                           // 0000001350F0: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 0000001350F4: 02030280
	s_and_b32 s24, vcc_lo, s1                                  // 0000001350F8: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001350FC: BF870009
	s_and_saveexec_b32 s1, s24                                 // 000000135100: BE812018
	s_cbranch_execz 7                                          // 000000135104: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1924>
	ds_load_b32 v129, v172 offset:40                           // 000000135108: D8D80028 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000135110: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000135114: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013511C: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000135120: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000135124: 8C7E017E
	v_and_b32_e32 v129, 0x800, v133                            // 000000135128: 37030AFF 00000800
	s_or_b32 s1, s2, 11                                        // 000000135130: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000135134: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 000000135138: 7C875401
	.long 0xd44d0001                                           // 00000013513C: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000135140: 02030280
	s_and_b32 s22, vcc_lo, s1                                  // 000000135144: 8B16016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000135148: BF870009
	s_and_saveexec_b32 s1, s22                                 // 00000013514C: BE812016
	s_cbranch_execz 7                                          // 000000135150: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1970>
	ds_load_b32 v129, v172 offset:44                           // 000000135154: D8D8002C 810000AC
	s_waitcnt lgkmcnt(0)                                       // 00000013515C: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000135160: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000135168: BF870001
	v_max_f32_e32 v132, v130, v129                             // 00000013516C: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000135170: 8C7E017E
	v_and_b32_e32 v129, 0x1000, v133                           // 000000135174: 37030AFF 00001000
	s_or_b32 s1, s2, 12                                        // 00000013517C: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000135180: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 000000135184: 7C875401
	.long 0xd44d0001                                           // 000000135188: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 00000013518C: 02030280
	s_and_b32 s9, vcc_lo, s1                                   // 000000135190: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000135194: BF870009
	s_and_saveexec_b32 s1, s9                                  // 000000135198: BE812009
	s_cbranch_execz 7                                          // 00000013519C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19bc>
	ds_load_b32 v129, v172 offset:48                           // 0000001351A0: D8D80030 810000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001351A8: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 0000001351AC: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001351B4: BF870001
	v_max_f32_e32 v132, v130, v129                             // 0000001351B8: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001351BC: 8C7E017E
	v_and_b32_e32 v129, 0x2000, v133                           // 0000001351C0: 37030AFF 00002000
	s_or_b32 s1, s2, 13                                        // 0000001351C8: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001351CC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 0000001351D0: 7C875401
	.long 0xd44d0001                                           // 0000001351D4: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 0000001351D8: 02030280
	s_and_b32 s8, vcc_lo, s1                                   // 0000001351DC: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001351E0: BF870009
	s_and_saveexec_b32 s1, s8                                  // 0000001351E4: BE812008
	s_cbranch_execz 7                                          // 0000001351E8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a08>
	ds_load_b32 v129, v172 offset:52                           // 0000001351EC: D8D80034 810000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001351F4: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 0000001351F8: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000135200: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000135204: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000135208: 8C7E017E
	v_and_b32_e32 v129, 0x4000, v133                           // 00000013520C: 37030AFF 00004000
	s_or_b32 s1, s2, 14                                        // 000000135214: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000135218: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 00000013521C: 7C875401
	.long 0xd44d0001                                           // 000000135220: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000135224: 02030280
	s_and_b32 s7, vcc_lo, s1                                   // 000000135228: 8B07016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000013522C: BF870009
	s_and_saveexec_b32 s1, s7                                  // 000000135230: BE812007
	s_cbranch_execz 7                                          // 000000135234: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a54>
	ds_load_b32 v129, v172 offset:56                           // 000000135238: D8D80038 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000135240: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000135244: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013524C: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000135250: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000135254: 8C7E017E
	v_and_b32_e32 v129, 0x8000, v133                           // 000000135258: 37030AFF 00008000
	s_or_b32 s2, s2, 15                                        // 000000135260: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000135264: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v170                          // 000000135268: 7C875402
	.long 0xd44d0001                                           // 00000013526C: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000135270: 02030280
	s_and_b32 s1, vcc_lo, s1                                   // 000000135274: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000135278: BF870009
	s_and_saveexec_b32 s2, s1                                  // 00000013527C: BE822001
	s_cbranch_execz 7                                          // 000000135280: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1aa0>
	ds_load_b32 v129, v172 offset:60                           // 000000135284: D8D8003C 810000AC
	s_waitcnt lgkmcnt(0)                                       // 00000013528C: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000135290: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000135298: BF870001
	v_max_f32_e32 v132, v130, v129                             // 00000013529C: 21090382
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001352A0: 8C7E027E
	v_dual_mov_b32 v129, 0 :: v_dual_mov_b32 v130, 0           // 0000001352A4: CA100080 81820080
	s_and_saveexec_b32 s2, s35                                 // 0000001352AC: BE822023
	s_cbranch_execz 30                                         // 0000001352B0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b2c>
	ds_load_b32 v130, v172                                     // 0000001352B4: D8D80000 820000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001352BC: BF89FC07
	v_sub_f32_e32 v130, v130, v132                             // 0000001352C0: 09050982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001352C4: BF870091
	v_mul_f32_e32 v133, 0x3fb8aa3b, v130                       // 0000001352C8: 110B04FF 3FB8AA3B
	v_fma_f32 v134, 0x3fb8aa3b, v130, -v133                    // 0000001352D0: D6130086 861704FF 3FB8AA3B
	v_rndne_f32_e32 v135, v133                                 // 0000001352DC: 7F0E4785
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001352E0: BF870221
	v_sub_f32_e32 v133, v133, v135                             // 0000001352E4: 090B0F85
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 0000001352E8: 7C3704FF C2CE8ED0
	v_fmac_f32_e32 v134, 0x32a5705f, v130                      // 0000001352F0: 570D04FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001352F8: BF870121
	v_add_f32_e32 v133, v133, v134                             // 0000001352FC: 070B0D85
	v_cvt_i32_f32_e32 v134, v135                               // 000000135300: 7F0C1187
	v_exp_f32_e32 v133, v133                                   // 000000135304: 7F0A4B85
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135308: BF870095
	.long 0xd71c0085                                           // 00000013530C: D71C0085
	v_cndmask_b32_e32 v1, v133, v134, vcc_lo                   // 000000135310: 02030D85
	v_cndmask_b32_e32 v133, 0, v133, vcc_lo                    // 000000135314: 030B0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 000000135318: 7C3D04FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000135320: BF870002
	v_cndmask_b32_e32 v130, 0x7f800000, v133, vcc_lo           // 000000135324: 03050AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000013532C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135330: BF870091
	v_bfe_u32 v133, v130, 16, 1                                // 000000135334: D6100085 02052182
	v_add3_u32 v133, v130, v133, 0x7fff                        // 00000013533C: D6550085 03FF0B82 00007FFF
	ds_store_b16_d16_hi v173, v133                             // 000000135348: DA840000 000085AD
	s_and_saveexec_b32 s2, s34                                 // 000000135350: BE822022
	s_cbranch_execz 29                                         // 000000135354: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1bcc>
	ds_load_b32 v129, v172 offset:4                            // 000000135358: D8D80004 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000135360: BF89FC07
	v_sub_f32_e32 v129, v129, v132                             // 000000135364: 09030981
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135368: BF870121
	v_mul_f32_e32 v133, 0x3fb8aa3b, v129                       // 00000013536C: 110B02FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v129                 // 000000135374: 7C3702FF C2CE8ED0
	v_fma_f32 v134, 0x3fb8aa3b, v129, -v133                    // 00000013537C: D6130086 861702FF 3FB8AA3B
	v_rndne_f32_e32 v135, v133                                 // 000000135388: 7F0E4785
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013538C: BF870091
	v_dual_fmac_f32 v134, 0x32a5705f, v129 :: v_dual_sub_f32 v133, v133, v135// 000000135390: C80B02FF 86850F85 32A5705F
	v_add_f32_e32 v133, v133, v134                             // 00000013539C: 070B0D85
	v_cvt_i32_f32_e32 v134, v135                               // 0000001353A0: 7F0C1187
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001353A4: BF870292
	v_exp_f32_e32 v133, v133                                   // 0000001353A8: 7F0A4B85
	.long 0xd71c0085                                           // 0000001353AC: D71C0085
	v_cndmask_b32_e32 v1, v133, v134, vcc_lo                   // 0000001353B0: 02030D85
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001353B4: BF870121
	v_cndmask_b32_e32 v133, 0, v133, vcc_lo                    // 0000001353B8: 030B0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v129                 // 0000001353BC: 7C3D02FF 42B17218
	v_cndmask_b32_e32 v129, 0x7f800000, v133, vcc_lo           // 0000001353C4: 03030AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001353CC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001353D0: BF870121
	v_bfe_u32 v133, v129, 16, 1                                // 0000001353D4: D6100085 02052181
	v_mov_b32_e32 v134, 0                                      // 0000001353DC: 7F0C0280
	v_add3_u32 v135, v129, v133, 0x7fff                        // 0000001353E0: D6550087 03FF0B81 00007FFF
	v_mov_b32_e32 v133, 0                                      // 0000001353EC: 7F0A0280
	ds_store_b16_d16_hi v173, v135 offset:2                    // 0000001353F0: DA840002 000087AD
	s_and_saveexec_b32 s2, s33                                 // 0000001353F8: BE822021
	s_cbranch_execz 30                                         // 0000001353FC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c78>
	ds_load_b32 v134, v172 offset:8                            // 000000135400: D8D80008 860000AC
	s_waitcnt lgkmcnt(0)                                       // 000000135408: BF89FC07
	v_sub_f32_e32 v134, v134, v132                             // 00000013540C: 090D0986
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135410: BF870091
	v_mul_f32_e32 v135, 0x3fb8aa3b, v134                       // 000000135414: 110F0CFF 3FB8AA3B
	v_fma_f32 v136, 0x3fb8aa3b, v134, -v135                    // 00000013541C: D6130088 861F0CFF 3FB8AA3B
	v_rndne_f32_e32 v149, v135                                 // 000000135428: 7F2A4787
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013542C: BF870221
	v_sub_f32_e32 v135, v135, v149                             // 000000135430: 090F2B87
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 000000135434: 7C370CFF C2CE8ED0
	v_fmac_f32_e32 v136, 0x32a5705f, v134                      // 00000013543C: 57110CFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135444: BF870121
	v_add_f32_e32 v135, v135, v136                             // 000000135448: 070F1187
	v_cvt_i32_f32_e32 v136, v149                               // 00000013544C: 7F101195
	v_exp_f32_e32 v135, v135                                   // 000000135450: 7F0E4B87
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135454: BF870095
	.long 0xd71c0087                                           // 000000135458: D71C0087
	v_cndmask_b32_e32 v1, v135, v136, vcc_lo                   // 00000013545C: 02031187
	v_cndmask_b32_e32 v135, 0, v135, vcc_lo                    // 000000135460: 030F0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 000000135464: 7C3D0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000013546C: BF870002
	v_cndmask_b32_e32 v134, 0x7f800000, v135, vcc_lo           // 000000135470: 030D0EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000135478: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013547C: BF870091
	v_bfe_u32 v135, v134, 16, 1                                // 000000135480: D6100087 02052186
	v_add3_u32 v135, v134, v135, 0x7fff                        // 000000135488: D6550087 03FF0F86 00007FFF
	ds_store_b16_d16_hi v173, v135 offset:4                    // 000000135494: DA840004 000087AD
	s_and_saveexec_b32 s2, s31                                 // 00000013549C: BE82201F
	s_cbranch_execz 30                                         // 0000001354A0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d1c>
	ds_load_b32 v133, v172 offset:12                           // 0000001354A4: D8D8000C 850000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001354AC: BF89FC07
	v_sub_f32_e32 v133, v133, v132                             // 0000001354B0: 090B0985
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001354B4: BF870121
	v_mul_f32_e32 v135, 0x3fb8aa3b, v133                       // 0000001354B8: 110F0AFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 0000001354C0: 7C370AFF C2CE8ED0
	v_fma_f32 v136, 0x3fb8aa3b, v133, -v135                    // 0000001354C8: D6130088 861F0AFF 3FB8AA3B
	v_rndne_f32_e32 v149, v135                                 // 0000001354D4: 7F2A4787
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001354D8: BF870112
	v_fmac_f32_e32 v136, 0x32a5705f, v133                      // 0000001354DC: 57110AFF 32A5705F
	v_sub_f32_e32 v135, v135, v149                             // 0000001354E4: 090F2B87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001354E8: BF870121
	v_add_f32_e32 v135, v135, v136                             // 0000001354EC: 070F1187
	v_cvt_i32_f32_e32 v136, v149                               // 0000001354F0: 7F101195
	v_exp_f32_e32 v135, v135                                   // 0000001354F4: 7F0E4B87
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001354F8: BF870095
	.long 0xd71c0087                                           // 0000001354FC: D71C0087
	v_cndmask_b32_e32 v1, v135, v136, vcc_lo                   // 000000135500: 02031187
	v_cndmask_b32_e32 v135, 0, v135, vcc_lo                    // 000000135504: 030F0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 000000135508: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000135510: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v135, vcc_lo           // 000000135514: 030B0EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000013551C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135520: BF870121
	v_bfe_u32 v135, v133, 16, 1                                // 000000135524: D6100087 02052185
	v_mov_b32_e32 v136, 0                                      // 00000013552C: 7F100280
	v_add3_u32 v149, v133, v135, 0x7fff                        // 000000135530: D6550095 03FF0F85 00007FFF
	v_mov_b32_e32 v135, 0                                      // 00000013553C: 7F0E0280
	ds_store_b16_d16_hi v173, v149 offset:6                    // 000000135540: DA840006 000095AD
	s_and_saveexec_b32 s2, s30                                 // 000000135548: BE82201E
	s_cbranch_execz 30                                         // 00000013554C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1dc8>
	ds_load_b32 v136, v172 offset:16                           // 000000135550: D8D80010 880000AC
	s_waitcnt lgkmcnt(0)                                       // 000000135558: BF89FC07
	v_sub_f32_e32 v136, v136, v132                             // 00000013555C: 09110988
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135560: BF870091
	v_mul_f32_e32 v149, 0x3fb8aa3b, v136                       // 000000135564: 112B10FF 3FB8AA3B
	v_fma_f32 v150, 0x3fb8aa3b, v136, -v149                    // 00000013556C: D6130096 865710FF 3FB8AA3B
	v_rndne_f32_e32 v151, v149                                 // 000000135578: 7F2E4795
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013557C: BF870221
	v_sub_f32_e32 v149, v149, v151                             // 000000135580: 092B2F95
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 000000135584: 7C3710FF C2CE8ED0
	v_fmac_f32_e32 v150, 0x32a5705f, v136                      // 00000013558C: 572D10FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135594: BF870121
	v_add_f32_e32 v149, v149, v150                             // 000000135598: 072B2D95
	v_cvt_i32_f32_e32 v150, v151                               // 00000013559C: 7F2C1197
	v_exp_f32_e32 v149, v149                                   // 0000001355A0: 7F2A4B95
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001355A4: BF870095
	.long 0xd71c0095                                           // 0000001355A8: D71C0095
	v_cndmask_b32_e32 v1, v149, v150, vcc_lo                   // 0000001355AC: 02032D95
	v_cndmask_b32_e32 v149, 0, v149, vcc_lo                    // 0000001355B0: 032B2A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 0000001355B4: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001355BC: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v149, vcc_lo           // 0000001355C0: 03112AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001355C8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001355CC: BF870091
	v_bfe_u32 v149, v136, 16, 1                                // 0000001355D0: D6100095 02052188
	v_add3_u32 v149, v136, v149, 0x7fff                        // 0000001355D8: D6550095 03FF2B88 00007FFF
	ds_store_b16_d16_hi v173, v149 offset:8                    // 0000001355E4: DA840008 000095AD
	s_and_saveexec_b32 s2, s29                                 // 0000001355EC: BE82201D
	s_cbranch_execz 30                                         // 0000001355F0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e6c>
	ds_load_b32 v135, v172 offset:20                           // 0000001355F4: D8D80014 870000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001355FC: BF89FC07
	v_sub_f32_e32 v135, v135, v132                             // 000000135600: 090F0987
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135604: BF870121
	v_mul_f32_e32 v149, 0x3fb8aa3b, v135                       // 000000135608: 112B0EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 000000135610: 7C370EFF C2CE8ED0
	v_fma_f32 v150, 0x3fb8aa3b, v135, -v149                    // 000000135618: D6130096 86570EFF 3FB8AA3B
	v_rndne_f32_e32 v151, v149                                 // 000000135624: 7F2E4795
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000135628: BF870112
	v_fmac_f32_e32 v150, 0x32a5705f, v135                      // 00000013562C: 572D0EFF 32A5705F
	v_sub_f32_e32 v149, v149, v151                             // 000000135634: 092B2F95
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135638: BF870121
	v_add_f32_e32 v149, v149, v150                             // 00000013563C: 072B2D95
	v_cvt_i32_f32_e32 v150, v151                               // 000000135640: 7F2C1197
	v_exp_f32_e32 v149, v149                                   // 000000135644: 7F2A4B95
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135648: BF870095
	.long 0xd71c0095                                           // 00000013564C: D71C0095
	v_cndmask_b32_e32 v1, v149, v150, vcc_lo                   // 000000135650: 02032D95
	v_cndmask_b32_e32 v149, 0, v149, vcc_lo                    // 000000135654: 032B2A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 000000135658: 7C3D0EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000135660: BF870002
	v_cndmask_b32_e32 v135, 0x7f800000, v149, vcc_lo           // 000000135664: 030F2AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000013566C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135670: BF870121
	v_bfe_u32 v149, v135, 16, 1                                // 000000135674: D6100095 02052187
	v_mov_b32_e32 v150, 0                                      // 00000013567C: 7F2C0280
	v_add3_u32 v151, v135, v149, 0x7fff                        // 000000135680: D6550097 03FF2B87 00007FFF
	v_mov_b32_e32 v149, 0                                      // 00000013568C: 7F2A0280
	ds_store_b16_d16_hi v173, v151 offset:10                   // 000000135690: DA84000A 000097AD
	s_and_saveexec_b32 s2, s28                                 // 000000135698: BE82201C
	s_cbranch_execz 30                                         // 00000013569C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f18>
	ds_load_b32 v150, v172 offset:24                           // 0000001356A0: D8D80018 960000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001356A8: BF89FC07
	v_sub_f32_e32 v150, v150, v132                             // 0000001356AC: 092D0996
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001356B0: BF870091
	v_mul_f32_e32 v151, 0x3fb8aa3b, v150                       // 0000001356B4: 112F2CFF 3FB8AA3B
	v_fma_f32 v152, 0x3fb8aa3b, v150, -v151                    // 0000001356BC: D6130098 865F2CFF 3FB8AA3B
	v_rndne_f32_e32 v153, v151                                 // 0000001356C8: 7F324797
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001356CC: BF870221
	v_sub_f32_e32 v151, v151, v153                             // 0000001356D0: 092F3397
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 0000001356D4: 7C372CFF C2CE8ED0
	v_fmac_f32_e32 v152, 0x32a5705f, v150                      // 0000001356DC: 57312CFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001356E4: BF870121
	v_add_f32_e32 v151, v151, v152                             // 0000001356E8: 072F3197
	v_cvt_i32_f32_e32 v152, v153                               // 0000001356EC: 7F301199
	v_exp_f32_e32 v151, v151                                   // 0000001356F0: 7F2E4B97
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001356F4: BF870095
	.long 0xd71c0097                                           // 0000001356F8: D71C0097
	v_cndmask_b32_e32 v1, v151, v152, vcc_lo                   // 0000001356FC: 02033197
	v_cndmask_b32_e32 v151, 0, v151, vcc_lo                    // 000000135700: 032F2E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 000000135704: 7C3D2CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000013570C: BF870002
	v_cndmask_b32_e32 v150, 0x7f800000, v151, vcc_lo           // 000000135710: 032D2EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000135718: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013571C: BF870091
	v_bfe_u32 v151, v150, 16, 1                                // 000000135720: D6100097 02052196
	v_add3_u32 v151, v150, v151, 0x7fff                        // 000000135728: D6550097 03FF2F96 00007FFF
	ds_store_b16_d16_hi v173, v151 offset:12                   // 000000135734: DA84000C 000097AD
	s_and_saveexec_b32 s2, s27                                 // 00000013573C: BE82201B
	s_cbranch_execz 30                                         // 000000135740: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1fbc>
	ds_load_b32 v149, v172 offset:28                           // 000000135744: D8D8001C 950000AC
	s_waitcnt lgkmcnt(0)                                       // 00000013574C: BF89FC07
	v_sub_f32_e32 v149, v149, v132                             // 000000135750: 092B0995
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135754: BF870121
	v_mul_f32_e32 v151, 0x3fb8aa3b, v149                       // 000000135758: 112F2AFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 000000135760: 7C372AFF C2CE8ED0
	v_fma_f32 v152, 0x3fb8aa3b, v149, -v151                    // 000000135768: D6130098 865F2AFF 3FB8AA3B
	v_rndne_f32_e32 v153, v151                                 // 000000135774: 7F324797
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000135778: BF870112
	v_fmac_f32_e32 v152, 0x32a5705f, v149                      // 00000013577C: 57312AFF 32A5705F
	v_sub_f32_e32 v151, v151, v153                             // 000000135784: 092F3397
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135788: BF870121
	v_add_f32_e32 v151, v151, v152                             // 00000013578C: 072F3197
	v_cvt_i32_f32_e32 v152, v153                               // 000000135790: 7F301199
	v_exp_f32_e32 v151, v151                                   // 000000135794: 7F2E4B97
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135798: BF870095
	.long 0xd71c0097                                           // 00000013579C: D71C0097
	v_cndmask_b32_e32 v1, v151, v152, vcc_lo                   // 0000001357A0: 02033197
	v_cndmask_b32_e32 v151, 0, v151, vcc_lo                    // 0000001357A4: 032F2E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 0000001357A8: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001357B0: BF870002
	v_cndmask_b32_e32 v149, 0x7f800000, v151, vcc_lo           // 0000001357B4: 032B2EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001357BC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001357C0: BF870121
	v_bfe_u32 v151, v149, 16, 1                                // 0000001357C4: D6100097 02052195
	v_mov_b32_e32 v152, 0                                      // 0000001357CC: 7F300280
	v_add3_u32 v153, v149, v151, 0x7fff                        // 0000001357D0: D6550099 03FF2F95 00007FFF
	v_mov_b32_e32 v151, 0                                      // 0000001357DC: 7F2E0280
	ds_store_b16_d16_hi v173, v153 offset:14                   // 0000001357E0: DA84000E 000099AD
	s_and_saveexec_b32 s2, s26                                 // 0000001357E8: BE82201A
	s_cbranch_execz 30                                         // 0000001357EC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2068>
	ds_load_b32 v152, v172 offset:32                           // 0000001357F0: D8D80020 980000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001357F8: BF89FC07
	v_sub_f32_e32 v152, v152, v132                             // 0000001357FC: 09310998
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135800: BF870091
	v_mul_f32_e32 v153, 0x3fb8aa3b, v152                       // 000000135804: 113330FF 3FB8AA3B
	v_fma_f32 v154, 0x3fb8aa3b, v152, -v153                    // 00000013580C: D613009A 866730FF 3FB8AA3B
	v_rndne_f32_e32 v155, v153                                 // 000000135818: 7F364799
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013581C: BF870221
	v_sub_f32_e32 v153, v153, v155                             // 000000135820: 09333799
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 000000135824: 7C3730FF C2CE8ED0
	v_fmac_f32_e32 v154, 0x32a5705f, v152                      // 00000013582C: 573530FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135834: BF870121
	v_add_f32_e32 v153, v153, v154                             // 000000135838: 07333599
	v_cvt_i32_f32_e32 v154, v155                               // 00000013583C: 7F34119B
	v_exp_f32_e32 v153, v153                                   // 000000135840: 7F324B99
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135844: BF870095
	.long 0xd71c0099                                           // 000000135848: D71C0099
	v_cndmask_b32_e32 v1, v153, v154, vcc_lo                   // 00000013584C: 02033599
	v_cndmask_b32_e32 v153, 0, v153, vcc_lo                    // 000000135850: 03333280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 000000135854: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000013585C: BF870002
	v_cndmask_b32_e32 v152, 0x7f800000, v153, vcc_lo           // 000000135860: 033132FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000135868: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013586C: BF870091
	v_bfe_u32 v153, v152, 16, 1                                // 000000135870: D6100099 02052198
	v_add3_u32 v153, v152, v153, 0x7fff                        // 000000135878: D6550099 03FF3398 00007FFF
	ds_store_b16_d16_hi v173, v153 offset:16                   // 000000135884: DA840010 000099AD
	s_and_saveexec_b32 s2, s25                                 // 00000013588C: BE822019
	s_cbranch_execz 30                                         // 000000135890: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x210c>
	ds_load_b32 v151, v172 offset:36                           // 000000135894: D8D80024 970000AC
	s_waitcnt lgkmcnt(0)                                       // 00000013589C: BF89FC07
	v_sub_f32_e32 v151, v151, v132                             // 0000001358A0: 092F0997
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001358A4: BF870121
	v_mul_f32_e32 v153, 0x3fb8aa3b, v151                       // 0000001358A8: 11332EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 0000001358B0: 7C372EFF C2CE8ED0
	v_fma_f32 v154, 0x3fb8aa3b, v151, -v153                    // 0000001358B8: D613009A 86672EFF 3FB8AA3B
	v_rndne_f32_e32 v155, v153                                 // 0000001358C4: 7F364799
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001358C8: BF870112
	v_fmac_f32_e32 v154, 0x32a5705f, v151                      // 0000001358CC: 57352EFF 32A5705F
	v_sub_f32_e32 v153, v153, v155                             // 0000001358D4: 09333799
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001358D8: BF870121
	v_add_f32_e32 v153, v153, v154                             // 0000001358DC: 07333599
	v_cvt_i32_f32_e32 v154, v155                               // 0000001358E0: 7F34119B
	v_exp_f32_e32 v153, v153                                   // 0000001358E4: 7F324B99
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001358E8: BF870095
	.long 0xd71c0099                                           // 0000001358EC: D71C0099
	v_cndmask_b32_e32 v1, v153, v154, vcc_lo                   // 0000001358F0: 02033599
	v_cndmask_b32_e32 v153, 0, v153, vcc_lo                    // 0000001358F4: 03333280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 0000001358F8: 7C3D2EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000135900: BF870002
	v_cndmask_b32_e32 v151, 0x7f800000, v153, vcc_lo           // 000000135904: 032F32FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000013590C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135910: BF870121
	v_bfe_u32 v153, v151, 16, 1                                // 000000135914: D6100099 02052197
	v_mov_b32_e32 v154, 0                                      // 00000013591C: 7F340280
	v_add3_u32 v155, v151, v153, 0x7fff                        // 000000135920: D655009B 03FF3397 00007FFF
	v_mov_b32_e32 v153, 0                                      // 00000013592C: 7F320280
	ds_store_b16_d16_hi v173, v155 offset:18                   // 000000135930: DA840012 00009BAD
	s_and_saveexec_b32 s2, s24                                 // 000000135938: BE822018
	s_cbranch_execz 30                                         // 00000013593C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21b8>
	ds_load_b32 v154, v172 offset:40                           // 000000135940: D8D80028 9A0000AC
	s_waitcnt lgkmcnt(0)                                       // 000000135948: BF89FC07
	v_sub_f32_e32 v154, v154, v132                             // 00000013594C: 0935099A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135950: BF870091
	v_mul_f32_e32 v155, 0x3fb8aa3b, v154                       // 000000135954: 113734FF 3FB8AA3B
	v_fma_f32 v156, 0x3fb8aa3b, v154, -v155                    // 00000013595C: D613009C 866F34FF 3FB8AA3B
	v_rndne_f32_e32 v182, v155                                 // 000000135968: 7F6C479B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013596C: BF870221
	v_sub_f32_e32 v155, v155, v182                             // 000000135970: 09376D9B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v154                 // 000000135974: 7C3734FF C2CE8ED0
	v_fmac_f32_e32 v156, 0x32a5705f, v154                      // 00000013597C: 573934FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135984: BF870121
	v_add_f32_e32 v155, v155, v156                             // 000000135988: 0737399B
	v_cvt_i32_f32_e32 v156, v182                               // 00000013598C: 7F3811B6
	v_exp_f32_e32 v155, v155                                   // 000000135990: 7F364B9B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135994: BF870095
	.long 0xd71c009b                                           // 000000135998: D71C009B
	v_cndmask_b32_e32 v1, v155, v156, vcc_lo                   // 00000013599C: 0203399B
	v_cndmask_b32_e32 v155, 0, v155, vcc_lo                    // 0000001359A0: 03373680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v154                 // 0000001359A4: 7C3D34FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001359AC: BF870002
	v_cndmask_b32_e32 v154, 0x7f800000, v155, vcc_lo           // 0000001359B0: 033536FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001359B8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001359BC: BF870091
	v_bfe_u32 v155, v154, 16, 1                                // 0000001359C0: D610009B 0205219A
	v_add3_u32 v155, v154, v155, 0x7fff                        // 0000001359C8: D655009B 03FF379A 00007FFF
	ds_store_b16_d16_hi v173, v155 offset:20                   // 0000001359D4: DA840014 00009BAD
	s_and_saveexec_b32 s2, s22                                 // 0000001359DC: BE822016
	s_cbranch_execz 29                                         // 0000001359E0: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2258>
	ds_load_b32 v153, v172 offset:44                           // 0000001359E4: D8D8002C 990000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001359EC: BF89FC07
	v_sub_f32_e32 v153, v153, v132                             // 0000001359F0: 09330999
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001359F4: BF870121
	v_mul_f32_e32 v155, 0x3fb8aa3b, v153                       // 0000001359F8: 113732FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 000000135A00: 7C3732FF C2CE8ED0
	v_fma_f32 v156, 0x3fb8aa3b, v153, -v155                    // 000000135A08: D613009C 866F32FF 3FB8AA3B
	v_rndne_f32_e32 v182, v155                                 // 000000135A14: 7F6C479B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135A18: BF870091
	v_dual_fmac_f32 v156, 0x32a5705f, v153 :: v_dual_sub_f32 v155, v155, v182// 000000135A1C: C80B32FF 9C9B6D9B 32A5705F
	v_add_f32_e32 v155, v155, v156                             // 000000135A28: 0737399B
	v_cvt_i32_f32_e32 v156, v182                               // 000000135A2C: 7F3811B6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000135A30: BF870292
	v_exp_f32_e32 v155, v155                                   // 000000135A34: 7F364B9B
	.long 0xd71c009b                                           // 000000135A38: D71C009B
	v_cndmask_b32_e32 v1, v155, v156, vcc_lo                   // 000000135A3C: 0203399B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135A40: BF870121
	v_cndmask_b32_e32 v155, 0, v155, vcc_lo                    // 000000135A44: 03373680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 000000135A48: 7C3D32FF 42B17218
	v_cndmask_b32_e32 v153, 0x7f800000, v155, vcc_lo           // 000000135A50: 033336FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000135A58: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135A5C: BF870121
	v_bfe_u32 v155, v153, 16, 1                                // 000000135A60: D610009B 02052199
	v_mov_b32_e32 v156, 0                                      // 000000135A68: 7F380280
	v_add3_u32 v182, v153, v155, 0x7fff                        // 000000135A6C: D65500B6 03FF3799 00007FFF
	v_mov_b32_e32 v155, 0                                      // 000000135A78: 7F360280
	ds_store_b16_d16_hi v173, v182 offset:22                   // 000000135A7C: DA840016 0000B6AD
	s_and_saveexec_b32 s2, s9                                  // 000000135A84: BE822009
	s_cbranch_execz 30                                         // 000000135A88: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2304>
	ds_load_b32 v156, v172 offset:48                           // 000000135A8C: D8D80030 9C0000AC
	s_waitcnt lgkmcnt(0)                                       // 000000135A94: BF89FC07
	v_sub_f32_e32 v156, v156, v132                             // 000000135A98: 0939099C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135A9C: BF870121
	v_mul_f32_e32 v182, 0x3fb8aa3b, v156                       // 000000135AA0: 116D38FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v156                 // 000000135AA8: 7C3738FF C2CE8ED0
	v_fma_f32 v183, 0x3fb8aa3b, v156, -v182                    // 000000135AB0: D61300B7 86DB38FF 3FB8AA3B
	v_rndne_f32_e32 v184, v182                                 // 000000135ABC: 7F7047B6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000135AC0: BF870112
	v_fmac_f32_e32 v183, 0x32a5705f, v156                      // 000000135AC4: 576F38FF 32A5705F
	v_sub_f32_e32 v182, v182, v184                             // 000000135ACC: 096D71B6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135AD0: BF870121
	v_add_f32_e32 v182, v182, v183                             // 000000135AD4: 076D6FB6
	v_cvt_i32_f32_e32 v183, v184                               // 000000135AD8: 7F6E11B8
	v_exp_f32_e32 v182, v182                                   // 000000135ADC: 7F6C4BB6
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135AE0: BF870095
	.long 0xd71c00b6                                           // 000000135AE4: D71C00B6
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                   // 000000135AE8: 02036FB6
	v_cndmask_b32_e32 v182, 0, v182, vcc_lo                    // 000000135AEC: 036D6C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v156                 // 000000135AF0: 7C3D38FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000135AF8: BF870002
	v_cndmask_b32_e32 v156, 0x7f800000, v182, vcc_lo           // 000000135AFC: 03396CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000135B04: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135B08: BF870091
	v_bfe_u32 v182, v156, 16, 1                                // 000000135B0C: D61000B6 0205219C
	v_add3_u32 v182, v156, v182, 0x7fff                        // 000000135B14: D65500B6 03FF6D9C 00007FFF
	ds_store_b16_d16_hi v173, v182 offset:24                   // 000000135B20: DA840018 0000B6AD
	s_and_saveexec_b32 s2, s8                                  // 000000135B28: BE822008
	s_cbranch_execz 29                                         // 000000135B2C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x23a4>
	ds_load_b32 v155, v172 offset:52                           // 000000135B30: D8D80034 9B0000AC
	s_waitcnt lgkmcnt(0)                                       // 000000135B38: BF89FC07
	v_sub_f32_e32 v155, v155, v132                             // 000000135B3C: 0937099B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135B40: BF870091
	v_mul_f32_e32 v182, 0x3fb8aa3b, v155                       // 000000135B44: 116D36FF 3FB8AA3B
	v_fma_f32 v183, 0x3fb8aa3b, v155, -v182                    // 000000135B4C: D61300B7 86DB36FF 3FB8AA3B
	v_rndne_f32_e32 v184, v182                                 // 000000135B58: 7F7047B6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135B5C: BF870091
	v_dual_fmac_f32 v183, 0x32a5705f, v155 :: v_dual_sub_f32 v182, v182, v184// 000000135B60: C80B36FF B7B771B6 32A5705F
	v_add_f32_e32 v182, v182, v183                             // 000000135B6C: 076D6FB6
	v_cvt_i32_f32_e32 v183, v184                               // 000000135B70: 7F6E11B8
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v155                 // 000000135B74: 7C3736FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000135B7C: BF870293
	v_exp_f32_e32 v182, v182                                   // 000000135B80: 7F6C4BB6
	.long 0xd71c00b6                                           // 000000135B84: D71C00B6
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                   // 000000135B88: 02036FB6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135B8C: BF870121
	v_cndmask_b32_e32 v182, 0, v182, vcc_lo                    // 000000135B90: 036D6C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v155                 // 000000135B94: 7C3D36FF 42B17218
	v_cndmask_b32_e32 v155, 0x7f800000, v182, vcc_lo           // 000000135B9C: 03376CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000135BA4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135BA8: BF870121
	v_bfe_u32 v182, v155, 16, 1                                // 000000135BAC: D61000B6 0205219B
	v_mov_b32_e32 v183, 0                                      // 000000135BB4: 7F6E0280
	v_add3_u32 v184, v155, v182, 0x7fff                        // 000000135BB8: D65500B8 03FF6D9B 00007FFF
	v_mov_b32_e32 v182, 0                                      // 000000135BC4: 7F6C0280
	ds_store_b16_d16_hi v173, v184 offset:26                   // 000000135BC8: DA84001A 0000B8AD
	s_and_saveexec_b32 s2, s7                                  // 000000135BD0: BE822007
	s_cbranch_execz 30                                         // 000000135BD4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2450>
	ds_load_b32 v183, v172 offset:56                           // 000000135BD8: D8D80038 B70000AC
	s_waitcnt lgkmcnt(0)                                       // 000000135BE0: BF89FC07
	v_sub_f32_e32 v183, v183, v132                             // 000000135BE4: 096F09B7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135BE8: BF870091
	v_mul_f32_e32 v184, 0x3fb8aa3b, v183                       // 000000135BEC: 11716EFF 3FB8AA3B
	v_fma_f32 v185, 0x3fb8aa3b, v183, -v184                    // 000000135BF4: D61300B9 86E36EFF 3FB8AA3B
	v_rndne_f32_e32 v186, v184                                 // 000000135C00: 7F7447B8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000135C04: BF870221
	v_sub_f32_e32 v184, v184, v186                             // 000000135C08: 097175B8
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v183                 // 000000135C0C: 7C376EFF C2CE8ED0
	v_fmac_f32_e32 v185, 0x32a5705f, v183                      // 000000135C14: 57736EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135C1C: BF870121
	v_add_f32_e32 v184, v184, v185                             // 000000135C20: 077173B8
	v_cvt_i32_f32_e32 v185, v186                               // 000000135C24: 7F7211BA
	v_exp_f32_e32 v184, v184                                   // 000000135C28: 7F704BB8
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135C2C: BF870095
	.long 0xd71c00b8                                           // 000000135C30: D71C00B8
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                   // 000000135C34: 020373B8
	v_cndmask_b32_e32 v184, 0, v184, vcc_lo                    // 000000135C38: 03717080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v183                 // 000000135C3C: 7C3D6EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000135C44: BF870002
	v_cndmask_b32_e32 v183, 0x7f800000, v184, vcc_lo           // 000000135C48: 036F70FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000135C50: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135C54: BF870091
	v_bfe_u32 v184, v183, 16, 1                                // 000000135C58: D61000B8 020521B7
	v_add3_u32 v184, v183, v184, 0x7fff                        // 000000135C60: D65500B8 03FF71B7 00007FFF
	ds_store_b16_d16_hi v173, v184 offset:28                   // 000000135C6C: DA84001C 0000B8AD
	s_and_saveexec_b32 s2, s1                                  // 000000135C74: BE822001
	s_cbranch_execz 30                                         // 000000135C78: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x24f4>
	ds_load_b32 v182, v172 offset:60                           // 000000135C7C: D8D8003C B60000AC
	s_waitcnt lgkmcnt(0)                                       // 000000135C84: BF89FC07
	v_sub_f32_e32 v182, v182, v132                             // 000000135C88: 096D09B6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135C8C: BF870121
	v_mul_f32_e32 v184, 0x3fb8aa3b, v182                       // 000000135C90: 11716CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v182                 // 000000135C98: 7C376CFF C2CE8ED0
	v_fma_f32 v185, 0x3fb8aa3b, v182, -v184                    // 000000135CA0: D61300B9 86E36CFF 3FB8AA3B
	v_rndne_f32_e32 v186, v184                                 // 000000135CAC: 7F7447B8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000135CB0: BF870112
	v_fmac_f32_e32 v185, 0x32a5705f, v182                      // 000000135CB4: 57736CFF 32A5705F
	v_sub_f32_e32 v184, v184, v186                             // 000000135CBC: 097175B8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135CC0: BF870121
	v_add_f32_e32 v184, v184, v185                             // 000000135CC4: 077173B8
	v_cvt_i32_f32_e32 v185, v186                               // 000000135CC8: 7F7211BA
	v_exp_f32_e32 v184, v184                                   // 000000135CCC: 7F704BB8
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135CD0: BF870095
	.long 0xd71c00b8                                           // 000000135CD4: D71C00B8
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                   // 000000135CD8: 020373B8
	v_cndmask_b32_e32 v184, 0, v184, vcc_lo                    // 000000135CDC: 03717080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v182                 // 000000135CE0: 7C3D6CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000135CE8: BF870002
	v_cndmask_b32_e32 v182, 0x7f800000, v184, vcc_lo           // 000000135CEC: 036D70FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000135CF4: 8C7E027E
	v_add_f32_e32 v129, v130, v129                             // 000000135CF8: 07030382
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000135CFC: BF870122
	v_bfe_u32 v130, v182, 16, 1                                // 000000135D00: D6100082 020521B6
	s_mov_b32 s1, 0                                            // 000000135D08: BE810080
	v_add_f32_e32 v129, v129, v134                             // 000000135D0C: 07030D81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000135D10: BF870112
	v_add3_u32 v130, v182, v130, 0x7fff                        // 000000135D14: D6550082 03FF05B6 00007FFF
	v_add_f32_e32 v129, v129, v133                             // 000000135D20: 07030B81
	ds_store_b16_d16_hi v173, v130 offset:30                   // 000000135D24: DA84001E 000082AD
	v_add_f32_e32 v129, v129, v136                             // 000000135D2C: 07031181
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135D30: BF870091
	v_add_f32_e32 v129, v129, v135                             // 000000135D34: 07030F81
	v_add_f32_e32 v129, v129, v150                             // 000000135D38: 07032D81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135D3C: BF870091
	v_add_f32_e32 v129, v129, v149                             // 000000135D40: 07032B81
	v_add_f32_e32 v129, v129, v152                             // 000000135D44: 07033181
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135D48: BF870091
	v_add_f32_e32 v129, v129, v151                             // 000000135D4C: 07032F81
	v_add_f32_e32 v129, v129, v154                             // 000000135D50: 07033581
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135D54: BF870091
	v_add_f32_e32 v129, v129, v153                             // 000000135D58: 07033381
	v_add_f32_e32 v129, v129, v156                             // 000000135D5C: 07033981
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000135D60: BF870091
	v_add_f32_e32 v129, v129, v155                             // 000000135D64: 07033781
	v_add_f32_e32 v129, v129, v183                             // 000000135D68: 07036F81
	s_delay_alu instid0(VALU_DEP_1)                            // 000000135D6C: BF870001
	v_add_f32_e32 v129, v129, v182                             // 000000135D70: 07036D81
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000135D74: 8B6A017E
	s_cbranch_vccz 591                                         // 000000135D78: BFA3024F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2eb8>
	ds_load_2addr_b32 v[134:135], v172 offset1:1               // 000000135D7C: D8DC0100 860000AC
	ds_load_2addr_b32 v[149:150], v172 offset0:2 offset1:3     // 000000135D84: D8DC0302 950000AC
	ds_load_2addr_b32 v[151:152], v172 offset0:4 offset1:5     // 000000135D8C: D8DC0504 970000AC
	ds_load_2addr_b32 v[153:154], v172 offset0:6 offset1:7     // 000000135D94: D8DC0706 990000AC
	ds_load_2addr_b32 v[155:156], v172 offset0:8 offset1:9     // 000000135D9C: D8DC0908 9B0000AC
	ds_load_2addr_b32 v[182:183], v172 offset0:10 offset1:11   // 000000135DA4: D8DC0B0A B60000AC
	.long 0xd59c4085                                           // 000000135DAC: D59C4085
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 000000135DB0: 02010080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000135DB4: BF8700D1
	.long 0xd59c4888                                           // 000000135DB8: D59C4888
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 000000135DBC: 02010185
	.long 0xd59c48ba                                           // 000000135DC0: D59C48BA
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 000000135DC4: 02010185
	s_waitcnt lgkmcnt(5)                                       // 000000135DC8: BF89FC57
	v_max3_f32 v129, v131, v134, v135                          // 000000135DCC: D61C0081 061F0D83
	s_waitcnt lgkmcnt(4)                                       // 000000135DD4: BF89FC47
	v_max3_f32 v129, v129, v149, v150                          // 000000135DD8: D61C0081 065B2B81
	s_waitcnt lgkmcnt(3)                                       // 000000135DE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 000000135DE4: BF870001
	v_max3_f32 v132, v129, v151, v152                          // 000000135DE8: D61C0084 06632F81
	ds_load_2addr_b32 v[184:185], v172 offset0:12 offset1:13   // 000000135DF0: D8DC0D0C B80000AC
	ds_load_2addr_b32 v[129:130], v172 offset0:14 offset1:15   // 000000135DF8: D8DC0F0E 810000AC
	s_waitcnt lgkmcnt(4)                                       // 000000135E00: BF89FC47
	v_max3_f32 v132, v132, v153, v154                          // 000000135E04: D61C0084 066B3384
	s_waitcnt lgkmcnt(3)                                       // 000000135E0C: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000135E10: BF8700A1
	v_max3_f32 v132, v132, v155, v156                          // 000000135E14: D61C0084 06733784
	s_waitcnt lgkmcnt(2)                                       // 000000135E1C: BF89FC27
	v_max3_f32 v132, v132, v182, v183                          // 000000135E20: D61C0084 06DF6D84
	s_waitcnt lgkmcnt(1)                                       // 000000135E28: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000135E2C: BF8700A1
	v_max3_f32 v132, v132, v184, v185                          // 000000135E30: D61C0084 06E77184
	s_waitcnt lgkmcnt(0)                                       // 000000135E38: BF89FC07
	v_max3_f32 v132, v132, v129, v130                          // 000000135E3C: D61C0084 060B0384
	s_delay_alu instid0(VALU_DEP_1)                            // 000000135E44: BF870001
	v_sub_f32_e32 v150, v150, v132                             // 000000135E48: 092D0996
	v_sub_f32_e32 v134, v134, v132                             // 000000135E4C: 090D0986
	v_sub_f32_e32 v149, v149, v132                             // 000000135E50: 092B0995
	v_sub_f32_e32 v135, v135, v132                             // 000000135E54: 090F0987
	v_sub_f32_e32 v153, v153, v132                             // 000000135E58: 09330999
	v_mul_f32_e32 v189, 0x3fb8aa3b, v150                       // 000000135E5C: 117B2CFF 3FB8AA3B
	v_mul_f32_e32 v187, 0x3fb8aa3b, v134                       // 000000135E64: 11770CFF 3FB8AA3B
	v_dual_sub_f32 v151, v151, v132 :: v_dual_mul_f32 v190, 0x3fb8aa3b, v149// 000000135E6C: C9470997 97BF2AFF 3FB8AA3B
	v_mul_f32_e32 v188, 0x3fb8aa3b, v135                       // 000000135E78: 11790EFF 3FB8AA3B
	v_mul_f32_e32 v194, 0x3fb8aa3b, v153                       // 000000135E80: 118532FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000135E88: BF870004
	v_fma_f32 v195, 0x3fb8aa3b, v134, -v187                    // 000000135E8C: D61300C3 86EF0CFF 3FB8AA3B
	v_rndne_f32_e32 v196, v187                                 // 000000135E98: 7F8847BB
	v_sub_f32_e32 v154, v154, v132                             // 000000135E9C: 0935099A
	v_mul_f32_e32 v192, 0x3fb8aa3b, v151                       // 000000135EA0: 11812EFF 3FB8AA3B
	v_fma_f32 v197, 0x3fb8aa3b, v135, -v188                    // 000000135EA8: D61300C5 86F30EFF 3FB8AA3B
	v_rndne_f32_e32 v198, v188                                 // 000000135EB4: 7F8C47BC
	v_rndne_f32_e32 v202, v190                                 // 000000135EB8: 7F9447BE
	v_dual_fmac_f32 v195, 0x32a5705f, v134 :: v_dual_sub_f32 v152, v152, v132// 000000135EBC: C80B0CFF C3990998 32A5705F
	v_mul_f32_e32 v193, 0x3fb8aa3b, v154                       // 000000135EC8: 118334FF 3FB8AA3B
	v_sub_f32_e32 v187, v187, v196                             // 000000135ED0: 097789BB
	v_fma_f32 v199, 0x3fb8aa3b, v150, -v189                    // 000000135ED4: D61300C7 86F72CFF 3FB8AA3B
	v_rndne_f32_e32 v200, v189                                 // 000000135EE0: 7F9047BD
	v_dual_mul_f32 v191, 0x3fb8aa3b, v152 :: v_dual_sub_f32 v188, v188, v198// 000000135EE4: C8CB30FF BFBD8DBC 3FB8AA3B
	v_fma_f32 v201, 0x3fb8aa3b, v149, -v190                    // 000000135EF0: D61300C9 86FB2AFF 3FB8AA3B
	v_rndne_f32_e32 v206, v192                                 // 000000135EFC: 7F9C47C0
	v_rndne_f32_e32 v210, v194                                 // 000000135F00: 7FA447C2
	v_dual_fmac_f32 v197, 0x32a5705f, v135 :: v_dual_sub_f32 v190, v190, v202// 000000135F04: C80B0EFF C5BF95BE 32A5705F
	v_add_f32_e32 v187, v187, v195                             // 000000135F10: 077787BB
	v_fma_f32 v205, 0x3fb8aa3b, v151, -v192                    // 000000135F14: D61300CD 87032EFF 3FB8AA3B
	v_fma_f32 v209, 0x3fb8aa3b, v153, -v194                    // 000000135F20: D61300D1 870B32FF 3FB8AA3B
	v_dual_fmac_f32 v201, 0x32a5705f, v149 :: v_dual_sub_f32 v194, v194, v210// 000000135F2C: C80B2AFF C9C3A5C2 32A5705F
	v_dual_sub_f32 v189, v189, v200 :: v_dual_sub_f32 v192, v192, v206// 000000135F38: C94B91BD BDC19DC0
	v_dual_fmac_f32 v199, 0x32a5705f, v150 :: v_dual_add_f32 v188, v188, v197// 000000135F40: C8092CFF C7BD8BBC 32A5705F
	v_exp_f32_e32 v187, v187                                   // 000000135F4C: 7F764BBB
	v_cvt_i32_f32_e32 v196, v196                               // 000000135F50: 7F8811C4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000135F54: BF870192
	v_dual_add_f32 v190, v190, v201 :: v_dual_add_f32 v189, v189, v199// 000000135F58: C90993BE BEBD8FBD
	v_exp_f32_e32 v188, v188                                   // 000000135F60: 7F784BBC
	v_cvt_i32_f32_e32 v198, v198                               // 000000135F64: 7F8C11C6
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 000000135F68: 7C370CFF C2CE8ED0
	v_cvt_i32_f32_e32 v200, v200                               // 000000135F70: 7F9011C8
	v_exp_f32_e32 v189, v189                                   // 000000135F74: 7F7A4BBD
	v_exp_f32_e32 v190, v190                                   // 000000135F78: 7F7C4BBE
	.long 0xd71c00bb                                           // 000000135F7C: D71C00BB
	v_cndmask_b32_e32 v1, v187, v196, vcc_lo                   // 000000135F80: 020389BB
	v_fma_f32 v203, 0x3fb8aa3b, v152, -v191                    // 000000135F84: D61300CB 86FF30FF 3FB8AA3B
	v_rndne_f32_e32 v204, v191                                 // 000000135F90: 7F9847BF
	v_cvt_i32_f32_e32 v202, v202                               // 000000135F94: 7F9411CA
	.long 0xd71c00bc                                           // 000000135F98: D71C00BC
	v_cndmask_b32_e32 v1, v188, v198, vcc_lo                   // 000000135F9C: 02038DBC
	v_cndmask_b32_e32 v187, 0, v187, vcc_lo                    // 000000135FA0: 03777680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 000000135FA4: 7C370EFF C2CE8ED0
	v_fmac_f32_e32 v205, 0x32a5705f, v151                      // 000000135FAC: 579B2EFF 32A5705F
	.long 0xd71c00bd                                           // 000000135FB4: D71C00BD
	v_cndmask_b32_e32 v1, v189, v200, vcc_lo                   // 000000135FB8: 020391BD
	.long 0xd71c00be                                           // 000000135FBC: D71C00BE
	v_cndmask_b32_e32 v1, v190, v202, vcc_lo                   // 000000135FC0: 020395BE
	v_rndne_f32_e32 v208, v193                                 // 000000135FC4: 7FA047C1
	v_cndmask_b32_e32 v188, 0, v188, vcc_lo                    // 000000135FC8: 03797880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 000000135FCC: 7C372CFF C2CE8ED0
	v_dual_fmac_f32 v203, 0x32a5705f, v152 :: v_dual_add_f32 v192, v192, v205// 000000135FD4: C80930FF CBC19BC0 32A5705F
	v_fma_f32 v207, 0x3fb8aa3b, v154, -v193                    // 000000135FE0: D61300CF 870734FF 3FB8AA3B
	v_cvt_i32_f32_e32 v206, v206                               // 000000135FEC: 7F9C11CE
	v_cndmask_b32_e32 v189, 0, v189, vcc_lo                    // 000000135FF0: 037B7A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 000000135FF4: 7C372AFF C2CE8ED0
	v_sub_f32_e32 v191, v191, v204                             // 000000135FFC: 097F99BF
	v_cvt_i32_f32_e32 v204, v204                               // 000000136000: 7F9811CC
	v_exp_f32_e32 v192, v192                                   // 000000136004: 7F804BC0
	v_dual_sub_f32 v129, v129, v132 :: v_dual_cndmask_b32 v190, 0, v190// 000000136008: C9530981 81BF7C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000136010: BF8701B3
	v_add_f32_e32 v191, v191, v203                             // 000000136014: 077F97BF
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 000000136018: 7C3730FF C2CE8ED0
	v_sub_f32_e32 v156, v156, v132                             // 000000136020: 0939099C
	v_exp_f32_e32 v191, v191                                   // 000000136024: 7F7E4BBF
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000136028: BF870296
	.long 0xd71c00c0                                           // 00000013602C: D71C00C0
	v_cndmask_b32_e32 v1, v192, v206, vcc_lo                   // 000000136030: 02039DC0
	.long 0xd71c00bf                                           // 000000136034: D71C00BF
	v_cndmask_b32_e32 v1, v191, v204, vcc_lo                   // 000000136038: 020399BF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000013603C: BF8701D1
	v_cndmask_b32_e32 v191, 0, v191, vcc_lo                    // 000000136040: 037F7E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 000000136044: 7C3D0EFF 42B17218
	v_cndmask_b32_e32 v135, 0x7f800000, v188, vcc_lo           // 00000013604C: 030F78FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 000000136054: 7C3D0CFF 42B17218
	v_sub_f32_e32 v193, v193, v208                             // 00000013605C: 0983A1C1
	.long 0xd59c0885                                           // 000000136060: D59C0885
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 000000136064: 02010187
	v_cndmask_b32_e32 v134, 0x7f800000, v187, vcc_lo           // 000000136068: 030D76FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 000000136070: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000136078: BF870002
	v_add_f32_e32 v149, v134, v135                             // 00000013607C: 072B0F86
	v_cndmask_b32_e32 v187, 0x7f800000, v190, vcc_lo           // 000000136080: 03777CFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 000000136088: 7C3D2CFF 42B17218
	v_and_b32_e32 v150, 1, v133                                // 000000136090: 372D0A81
	.long 0xd59c0888                                           // 000000136094: D59C0888
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 000000136098: 02010186
	v_cndmask_b32_e32 v188, 0x7f800000, v189, vcc_lo           // 00000013609C: 03797AFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 0000001360A4: 7C372EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001360AC: BF870193
	v_and_b32_e32 v136, 1, v136                                // 0000001360B0: 37111081
	.long 0xd59c0885                                           // 0000001360B4: D59C0885
	v_cndmask_b32_e32 v0, v188, v128, vcc_lo                   // 0000001360B8: 020101BC
	v_fmac_f32_e32 v207, 0x32a5705f, v154                      // 0000001360BC: 579F34FF 32A5705F
	v_dual_cndmask_b32 v189, 0, v192 :: v_dual_add_f32 v192, v149, v187// 0000001360C4: CA498080 BDC17795
	v_add3_u32 v149, v135, v150, 0x7fff                        // 0000001360CC: D6550095 03FF2D87 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001360D8: BF8701B4
	v_and_b32_e32 v190, 1, v133                                // 0000001360DC: 377D0A81
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 0000001360E0: 7C3D2EFF 42B17218
	v_add3_u32 v134, v134, v136, 0x7fff                        // 0000001360E8: D6550086 03FF1186 00007FFF
	v_add3_u32 v150, v188, v190, 0x7fff                        // 0000001360F4: D6550096 03FF7DBC 00007FFF
	v_add_f32_e32 v188, v192, v188                             // 000000136100: 077979C0
	.long 0xd59c08ba                                           // 000000136104: D59C08BA
	v_cndmask_b32_e32 v0, v187, v128, vcc_lo                   // 000000136108: 020101BB
	v_fmac_f32_e32 v209, 0x32a5705f, v153                      // 00000013610C: 57A332FF 32A5705F
	v_dual_cndmask_b32 v136, 0x7f800000, v189 :: v_dual_add_f32 v151, v193, v207// 000000136114: CA497AFF 88979FC1 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 000000136120: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000136128: BF870224
	v_and_b32_e32 v186, 1, v186                                // 00000013612C: 37757481
	v_cvt_i32_f32_e32 v189, v208                               // 000000136130: 7F7A11D0
	v_add_f32_e32 v188, v188, v136                             // 000000136134: 077911BC
	v_exp_f32_e32 v151, v151                                   // 000000136138: 7F2E4B97
	.long 0xd59c0895                                           // 00000013613C: D59C0895
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 000000136140: 02010186
	v_add3_u32 v135, v187, v186, 0x7fff                        // 000000136144: D6550087 03FF75BB 00007FFF
	v_add_f32_e32 v186, v194, v209                             // 000000136150: 0775A3C2
	.long 0xd59c08bb                                           // 000000136154: D59C08BB
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 000000136158: 02010188
	.long 0xd59c48bb                                           // 00000013615C: D59C48BB
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 000000136160: 02010185
	v_cndmask_b32_e32 v152, 0x7f800000, v191, vcc_lo           // 000000136164: 03317EFF 7F800000
	v_cvt_i32_f32_e32 v191, v210                               // 00000013616C: 7F7E11D2
	v_exp_f32_e32 v186, v186                                   // 000000136170: 7F744BBA
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v154                 // 000000136174: 7C3734FF C2CE8ED0
	v_and_b32_e32 v187, 1, v187                                // 00000013617C: 37777681
	.long 0xd71c00bd                                           // 000000136180: D71C00BD
	v_cndmask_b32_e32 v1, v151, v189, vcc_lo                   // 000000136184: 02037B97
	.long 0xd59c0885                                           // 000000136188: D59C0885
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 00000013618C: 02010198
	.long 0xd59c0896                                           // 000000136190: D59C0896
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 000000136194: 02010187
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000136198: BF870214
	v_add3_u32 v136, v136, v187, 0x7fff                        // 00000013619C: D6550088 03FF7788 00007FFF
	v_cndmask_b32_e32 v187, 0, v189, vcc_lo                    // 0000001361A8: 03777A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 0000001361AC: 7C3732FF C2CE8ED0
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001361B4: BF8701B5
	.long 0xd71c00ba                                           // 0000001361B8: D71C00BA
	v_cndmask_b32_e32 v1, v186, v191, vcc_lo                   // 0000001361BC: 02037FBA
	v_and_b32_e32 v190, 1, v133                                // 0000001361C0: 377D0A81
	.long 0xd59c48bd                                           // 0000001361C4: D59C48BD
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 0000001361C8: 02010185
	v_cndmask_b32_e32 v186, 0, v186, vcc_lo                    // 0000001361CC: 03757480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v154                 // 0000001361D0: 7C3D34FF 42B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001361D8: BF870004
	v_add3_u32 v151, v152, v190, 0x7fff                        // 0000001361DC: D6550097 03FF7D98 00007FFF
	v_add_f32_e32 v152, v188, v152                             // 0000001361E8: 073131BC
	.long 0xd59c0897                                           // 0000001361EC: D59C0897
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 0000001361F0: 02010188
	v_cndmask_b32_e32 v154, 0x7f800000, v187, vcc_lo           // 0000001361F4: 033576FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 0000001361FC: 7C3D32FF 42B17218
	v_cndmask_b32_e32 v153, 0x7f800000, v186, vcc_lo           // 000000136204: 033374FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000013620C: BF8701A3
	.long 0xd59c0885                                           // 000000136210: D59C0885
	v_cndmask_b32_e32 v0, v154, v128, vcc_lo                   // 000000136214: 0201019A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v156                 // 000000136218: 7C3738FF C2CE8ED0
	.long 0xd59c08bd                                           // 000000136220: D59C08BD
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                   // 000000136224: 02010199
	v_sub_f32_e32 v155, v155, v132                             // 000000136228: 0937099B
	v_add_f32_e32 v191, v152, v153                             // 00000013622C: 077F3398
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000136230: BF870193
	v_dual_mul_f32 v187, 0x3fb8aa3b, v156 :: v_dual_and_b32 v152, 1, v189// 000000136234: C8E538FF BB997A81 3FB8AA3B
	v_dual_mul_f32 v190, 0x3fb8aa3b, v155 :: v_dual_and_b32 v189, 1, v133// 000000136240: C8E536FF BEBD0A81 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013624C: BF870192
	v_add3_u32 v153, v153, v152, 0x7fff                        // 000000136250: D6550099 03FF3199 00007FFF
	v_fma_f32 v186, 0x3fb8aa3b, v156, -v187                    // 00000013625C: D61300BA 86EF38FF 3FB8AA3B
	v_rndne_f32_e32 v188, v187                                 // 000000136268: 7F7847BB
	s_delay_alu instid0(VALU_DEP_4)                            // 00000013626C: BF870004
	v_add3_u32 v152, v154, v189, 0x7fff                        // 000000136270: D6550098 03FF7B9A 00007FFF
	v_rndne_f32_e32 v192, v190                                 // 00000013627C: 7F8047BE
	.long 0xd59c0898                                           // 000000136280: D59C0898
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                   // 000000136284: 02010199
	v_fmac_f32_e32 v186, 0x32a5705f, v156                      // 000000136288: 577538FF 32A5705F
	v_sub_f32_e32 v153, v182, v132                             // 000000136290: 093309B6
	v_sub_f32_e32 v187, v187, v188                             // 000000136294: 097779BB
	v_cvt_i32_f32_e32 v135, v188                               // 000000136298: 7F0E11BC
	v_sub_f32_e32 v182, v183, v132                             // 00000013629C: 096D09B7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001362A0: BF8701A3
	v_add_f32_e32 v186, v187, v186                             // 0000001362A4: 077575BB
	v_fma_f32 v187, 0x3fb8aa3b, v155, -v190                    // 0000001362A8: D61300BB 86FB36FF 3FB8AA3B
	v_mul_f32_e32 v183, 0x3fb8aa3b, v182                       // 0000001362B4: 116F6CFF 3FB8AA3B
	v_add_f32_e32 v154, v191, v154                             // 0000001362BC: 073535BF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001362C0: BF870194
	v_exp_f32_e32 v186, v186                                   // 0000001362C4: 7F744BBA
	v_fmac_f32_e32 v187, 0x32a5705f, v155                      // 0000001362C8: 577736FF 32A5705F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001362D0: BF870245
	.long 0xd71c0086                                           // 0000001362D4: D71C0086
	v_cndmask_b32_e32 v1, v186, v135, vcc_lo                   // 0000001362D8: 02030FBA
	v_sub_f32_e32 v189, v190, v192                             // 0000001362DC: 097B81BE
	v_cvt_i32_f32_e32 v186, v192                               // 0000001362E0: 7F7411C0
	v_rndne_f32_e32 v190, v183                                 // 0000001362E4: 7F7C47B7
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000001362E8: 030D0C80
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001362EC: BF870244
	v_add_f32_e32 v136, v189, v187                             // 0000001362F0: 071177BD
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v155                 // 0000001362F4: 7C3736FF C2CE8ED0
	v_fma_f32 v189, 0x3fb8aa3b, v182, -v183                    // 0000001362FC: D61300BD 86DF6CFF 3FB8AA3B
	v_sub_f32_e32 v183, v183, v190                             // 000000136308: 096F7DB7
	v_exp_f32_e32 v135, v136                                   // 00000013630C: 7F0E4B88
	v_mul_f32_e32 v136, 0x3fb8aa3b, v153                       // 000000136310: 111132FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000136318: BF8702A1
	v_fma_f32 v187, 0x3fb8aa3b, v153, -v136                    // 00000013631C: D61300BB 862332FF 3FB8AA3B
	v_rndne_f32_e32 v188, v136                                 // 000000136328: 7F784788
	.long 0xd71c0087                                           // 00000013632C: D71C0087
	v_cndmask_b32_e32 v1, v135, v186, vcc_lo                   // 000000136330: 02037587
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000136334: BF8701A2
	v_dual_fmac_f32 v187, 0x32a5705f, v153 :: v_dual_sub_f32 v136, v136, v188// 000000136338: C80B32FF BB897988 32A5705F
	v_cvt_i32_f32_e32 v186, v190                               // 000000136344: 7F7411BE
	v_cndmask_b32_e32 v135, 0, v135, vcc_lo                    // 000000136348: 030F0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v156                 // 00000013634C: 7C3D38FF 42B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000136354: BF8701B4
	v_add_f32_e32 v136, v136, v187                             // 000000136358: 07117788
	v_cndmask_b32_e32 v134, 0x7f800000, v134, vcc_lo           // 00000013635C: 030D0CFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v155                 // 000000136364: 7C3D36FF 42B17218
	v_exp_f32_e32 v136, v136                                   // 00000013636C: 7F104B88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000136370: BF8701C2
	.long 0xd59c0885                                           // 000000136374: D59C0885
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 000000136378: 02010186
	v_cndmask_b32_e32 v135, 0x7f800000, v135, vcc_lo           // 00000013637C: 030F0EFF 7F800000
	v_fmac_f32_e32 v189, 0x32a5705f, v182                      // 000000136384: 577B6CFF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 00000013638C: 7C3732FF C2CE8ED0
	v_add_f32_e32 v154, v154, v135                             // 000000136394: 07350F9A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000136398: BF870233
	v_add_f32_e32 v156, v183, v189                             // 00000013639C: 07397BB7
	v_cvt_i32_f32_e32 v183, v188                               // 0000001363A0: 7F6E11BC
	v_and_b32_e32 v187, 1, v133                                // 0000001363A4: 37770A81
	v_dual_mul_f32 v189, 0x3fb8aa3b, v129 :: v_dual_add_f32 v154, v154, v134// 0000001363A8: C8C902FF BD9B0D9A 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001363B4: BF870194
	v_exp_f32_e32 v155, v156                                   // 0000001363B8: 7F364B9C
	.long 0xd71c0088                                           // 0000001363BC: D71C0088
	v_cndmask_b32_e32 v1, v136, v183, vcc_lo                   // 0000001363C0: 02036F88
	.long 0xd59c089c                                           // 0000001363C4: D59C089C
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 0000001363C8: 02010187
	.long 0xd59c489c                                           // 0000001363CC: D59C489C
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 0000001363D0: 02010185
	v_fma_f32 v191, 0x3fb8aa3b, v129, -v189                    // 0000001363D4: D61300BF 86F702FF 3FB8AA3B
	v_sub_f32_e32 v184, v184, v132                             // 0000001363E0: 097109B8
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000001363E4: 03111080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v182                 // 0000001363E8: 7C376CFF C2CE8ED0
	v_and_b32_e32 v156, 1, v156                                // 0000001363F0: 37393881
	v_rndne_f32_e32 v192, v189                                 // 0000001363F4: 7F8047BD
	.long 0xd71c009b                                           // 0000001363F8: D71C009B
	v_cndmask_b32_e32 v1, v155, v186, vcc_lo                   // 0000001363FC: 0203759B
	v_dual_fmac_f32 v191, 0x32a5705f, v129 :: v_dual_sub_f32 v130, v130, v132// 000000136400: C80B02FF BF830982 32A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013640C: BF870194
	v_add3_u32 v135, v135, v156, 0x7fff                        // 000000136410: D6550087 03FF3987 00007FFF
	v_cndmask_b32_e32 v155, 0, v155, vcc_lo                    // 00000013641C: 03373680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 000000136420: 7C3D32FF 42B17218
	v_add3_u32 v153, v134, v187, 0x7fff                        // 000000136428: D6550099 03FF7786 00007FFF
	v_mul_f32_e32 v187, 0x3fb8aa3b, v184                       // 000000136434: 117770FF 3FB8AA3B
	.long 0xd59c0899                                           // 00000013643C: D59C0899
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 000000136440: 02010187
	v_mul_f32_e32 v190, 0x3fb8aa3b, v130                       // 000000136444: 117D04FF 3FB8AA3B
	v_cndmask_b32_e32 v136, 0x7f800000, v136, vcc_lo           // 00000013644C: 031110FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v182                 // 000000136454: 7C3D6CFF 42B17218
	v_rndne_f32_e32 v188, v187                                 // 00000013645C: 7F7847BB
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000136460: BF870124
	v_fma_f32 v193, 0x3fb8aa3b, v130, -v190                    // 000000136464: D61300C1 86FB04FF 3FB8AA3B
	v_cndmask_b32_e32 v155, 0x7f800000, v155, vcc_lo           // 000000136470: 033736FF 7F800000
	v_fmac_f32_e32 v193, 0x32a5705f, v130                      // 000000136478: 578304FF 32A5705F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000136480: BF870242
	.long 0xd59c0885                                           // 000000136484: D59C0885
	v_cndmask_b32_e32 v0, v155, v128, vcc_lo                   // 000000136488: 0201019B
	v_sub_f32_e32 v183, v185, v132                             // 00000013648C: 096F09B9
	.long 0xd59c08b9                                           // 000000136490: D59C08B9
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 000000136494: 02010188
	.long 0xd59c48b9                                           // 000000136498: D59C48B9
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 00000013649C: 02010185
	v_and_b32_e32 v186, 1, v133                                // 0000001364A0: 37750A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001364A4: BF870224
	v_mul_f32_e32 v182, 0x3fb8aa3b, v183                       // 0000001364A8: 116D6EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v183                 // 0000001364B0: 7C376EFF C2CE8ED0
	v_dual_add_f32 v134, v154, v136 :: v_dual_and_b32 v185, 1, v185// 0000001364B8: C925119A 86B97281
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001364C0: BF8701A3
	v_fma_f32 v154, 0x3fb8aa3b, v183, -v182                    // 0000001364C4: D613009A 86DB6EFF 3FB8AA3B
	v_rndne_f32_e32 v156, v182                                 // 0000001364D0: 7F3847B6
	v_add3_u32 v136, v136, v185, 0x7fff                        // 0000001364D4: D6550088 03FF7388 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001364E0: BF870193
	v_fmac_f32_e32 v154, 0x32a5705f, v183                      // 0000001364E4: 57356EFF 32A5705F
	v_sub_f32_e32 v182, v182, v156                             // 0000001364EC: 096D39B6
	v_cvt_i32_f32_e32 v156, v156                               // 0000001364F0: 7F38119C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001364F4: BF8701B2
	v_add_f32_e32 v154, v182, v154                             // 0000001364F8: 073535B6
	v_fma_f32 v182, 0x3fb8aa3b, v184, -v187                    // 0000001364FC: D61300B6 86EF70FF 3FB8AA3B
	v_sub_f32_e32 v187, v187, v188                             // 000000136508: 097779BB
	v_exp_f32_e32 v154, v154                                   // 00000013650C: 7F344B9A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136510: BF870092
	v_fmac_f32_e32 v182, 0x32a5705f, v184                      // 000000136514: 576D70FF 32A5705F
	v_dual_add_f32 v182, v187, v182 :: v_dual_sub_f32 v187, v189, v192// 00000013651C: C90B6DBB B6BB81BD
	v_rndne_f32_e32 v194, v190                                 // 000000136524: 7F8447BE
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000136528: BF870195
	.long 0xd71c009a                                           // 00000013652C: D71C009A
	v_cndmask_b32_e32 v1, v154, v156, vcc_lo                   // 000000136530: 0203399A
	v_add_f32_e32 v185, v187, v191                             // 000000136534: 07737FBB
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000136538: BF870193
	v_sub_f32_e32 v189, v190, v194                             // 00000013653C: 097B85BE
	v_cndmask_b32_e32 v154, 0, v154, vcc_lo                    // 000000136540: 03353480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v183                 // 000000136544: 7C3D6EFF 42B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013654C: BF870194
	v_exp_f32_e32 v156, v185                                   // 000000136550: 7F384BB9
	v_add_f32_e32 v187, v189, v193                             // 000000136554: 077783BD
	v_exp_f32_e32 v182, v182                                   // 000000136558: 7F6C4BB6
	v_cvt_i32_f32_e32 v185, v188                               // 00000013655C: 7F7211BC
	v_dual_add_f32 v134, v134, v155 :: v_dual_cndmask_b32 v183, 0x7f800000, v154// 000000136560: C9133786 86B734FF 7F800000
	v_cvt_i32_f32_e32 v188, v192                               // 00000013656C: 7F7811C0
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v184                 // 000000136570: 7C3770FF C2CE8ED0
	v_exp_f32_e32 v187, v187                                   // 000000136578: 7F764BBB
	s_delay_alu instid0(VALU_DEP_3)                            // 00000013657C: BF870003
	.long 0xd59c0885                                           // 000000136580: D59C0885
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                   // 000000136584: 020101B7
	s_delay_alu instid0(TRANS32_DEP_3) | instid1(VALU_DEP_3)   // 000000136588: BF870187
	.long 0xd71c009a                                           // 00000013658C: D71C009A
	v_cndmask_b32_e32 v1, v156, v188, vcc_lo                   // 000000136590: 0203799C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000136594: BF870126
	.long 0xd71c00b6                                           // 000000136598: D71C00B6
	v_cndmask_b32_e32 v1, v182, v185, vcc_lo                   // 00000013659C: 020373B6
	v_cvt_i32_f32_e32 v185, v194                               // 0000001365A0: 7F7211C2
	v_cndmask_b32_e32 v156, 0, v182, vcc_lo                    // 0000001365A4: 03396C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v129                 // 0000001365A8: 7C3702FF C2CE8ED0
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001365B0: BF870185
	.long 0xd71c00b6                                           // 0000001365B4: D71C00B6
	v_cndmask_b32_e32 v1, v187, v185, vcc_lo                   // 0000001365B8: 020373BB
	v_cndmask_b32_e32 v154, 0, v154, vcc_lo                    // 0000001365BC: 03353480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v184                 // 0000001365C0: 7C3D70FF 42B17218
	v_cndmask_b32_e32 v156, 0x7f800000, v156, vcc_lo           // 0000001365C8: 033938FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 0000001365D0: 7C3704FF C2CE8ED0
	v_cndmask_b32_e32 v182, 0, v182, vcc_lo                    // 0000001365D8: 036D6C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v129                 // 0000001365DC: 7C3D02FF 42B17218
	v_cndmask_b32_e32 v129, 0x7f800000, v154, vcc_lo           // 0000001365E4: 030334FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 0000001365EC: 7C3D04FF 42B17218
	.long 0xd59c089a                                           // 0000001365F4: D59C089A
	v_cndmask_b32_e32 v0, v156, v128, vcc_lo                   // 0000001365F8: 0201019C
	.long 0xd59c489a                                           // 0000001365FC: D59C489A
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 000000136600: 02010185
	v_add_f32_e32 v134, v134, v156                             // 000000136604: 070D3986
	v_cndmask_b32_e32 v130, 0x7f800000, v182, vcc_lo           // 000000136608: 03056CFF 7F800000
	.long 0xd59c08b6                                           // 000000136610: D59C08B6
	v_cndmask_b32_e32 v0, v129, v128, vcc_lo                   // 000000136614: 02010181
	.long 0xd59c48b6                                           // 000000136618: D59C48B6
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 00000013661C: 02010185
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000136620: BF870234
	v_dual_add_f32 v134, v134, v183 :: v_dual_and_b32 v185, 1, v154// 000000136624: C9256F86 86B93481
	v_add3_u32 v154, v155, v186, 0x7fff                        // 00000013662C: D655009A 03FF759B 00007FFF
	.long 0xd59c089a                                           // 000000136638: D59C089A
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 00000013663C: 02010188
	v_and_b32_e32 v182, 1, v182                                // 000000136640: 376D6C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000136644: BF870114
	v_add3_u32 v185, v156, v185, 0x7fff                        // 000000136648: D65500B9 03FF739C 00007FFF
	v_add3_u32 v182, v129, v182, 0x7fff                        // 000000136654: D65500B6 03FF6D81 00007FFF
	v_add_f32_e32 v129, v134, v129                             // 000000136660: 07030386
	v_and_b32_e32 v184, 1, v133                                // 000000136664: 37710A81
	.long 0xd59c0885                                           // 000000136668: D59C0885
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                   // 00000013666C: 02010182
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000136670: BF870193
	v_add_f32_e32 v129, v129, v130                             // 000000136674: 07030581
	v_add3_u32 v155, v183, v184, 0x7fff                        // 000000136678: D655009B 03FF71B7 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000136684: BF870123
	v_and_b32_e32 v133, 1, v133                                // 000000136688: 370B0A81
	.long 0xd59c089b                                           // 00000013668C: D59C089B
	v_cndmask_b32_e32 v0, v185, v128, vcc_lo                   // 000000136690: 020101B9
	v_add3_u32 v156, v130, v133, 0x7fff                        // 000000136694: D655009C 03FF0B82 00007FFF
	.long 0xd59c089c                                           // 0000001366A0: D59C089C
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                   // 0000001366A4: 020101B6
	ds_store_b128 v173, v[149:152]                             // 0000001366A8: DB7C0000 000095AD
	ds_store_b128 v173, v[153:156] offset:16                   // 0000001366B0: DB7C0010 000099AD
	v_mov_b32_e32 v130, 0                                      // 0000001366B8: 7F040280
	s_mov_b32 s1, exec_lo                                      // 0000001366BC: BE81007E
	s_waitcnt lgkmcnt(0)                                       // 0000001366C0: BF89FC07
	v_cmpx_lt_f32_e32 0xefa18f08, v131                         // 0000001366C4: 7D2306FF EFA18F08
	s_cbranch_execz 27                                         // 0000001366CC: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2f3c>
	v_sub_f32_e32 v130, v131, v132                             // 0000001366D0: 09050983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001366D4: BF870121
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 0000001366D8: 110704FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 0000001366E0: 7C3704FF C2CE8ED0
	v_fma_f32 v133, 0x3fb8aa3b, v130, -v131                    // 0000001366E8: D6130085 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v134, v131                                 // 0000001366F4: 7F0C4783
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001366F8: BF870112
	v_fmac_f32_e32 v133, 0x32a5705f, v130                      // 0000001366FC: 570B04FF 32A5705F
	v_sub_f32_e32 v131, v131, v134                             // 000000136704: 09070D83
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000136708: BF870121
	v_add_f32_e32 v131, v131, v133                             // 00000013670C: 07070B83
	v_cvt_i32_f32_e32 v133, v134                               // 000000136710: 7F0A1186
	v_exp_f32_e32 v131, v131                                   // 000000136714: 7F064B83
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136718: BF870095
	.long 0xd71c0083                                           // 00000013671C: D71C0083
	v_cndmask_b32_e32 v1, v131, v133, vcc_lo                   // 000000136720: 02030B83
	v_cndmask_b32_e32 v131, 0, v131, vcc_lo                    // 000000136724: 03070680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 000000136728: 7C3D04FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000136730: BF870002
	v_cndmask_b32_e32 v130, 0x7f800000, v131, vcc_lo           // 000000136734: 030506FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013673C: 8C7E017E
	ds_load_b32 v131, v174                                     // 000000136740: D8D80000 830000AE
	s_waitcnt lgkmcnt(0)                                       // 000000136748: BF89FC07
	v_fmac_f32_e32 v129, v130, v131                            // 00000013674C: 57030782
	ds_store_b32 v171, v132                                    // 000000136750: D8340000 000084AB
	ds_store_b32 v174, v129                                    // 000000136758: D8340000 000081AE
	ds_store_b32 v175, v130                                    // 000000136760: D8340000 000082AF
	s_or_b32 exec_lo, exec_lo, s4                              // 000000136768: 8C7E047E
	ds_load_2addr_b32 v[155:156], v176 offset1:2               // 00000013676C: D8DC0200 9B0000B0
	ds_load_2addr_b32 v[153:154], v176 offset0:4 offset1:6     // 000000136774: D8DC0604 990000B0
	ds_load_2addr_b32 v[151:152], v176 offset0:8 offset1:10    // 00000013677C: D8DC0A08 970000B0
	ds_load_2addr_b32 v[149:150], v176 offset0:12 offset1:14   // 000000136784: D8DC0E0C 950000B0
	s_waitcnt lgkmcnt(3)                                       // 00000013678C: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v155                         // 000000136790: 7C2536F2
	.long 0xd4120001                                           // 000000136794: D4120001
	v_cndmask_b32_e32 v1, 1.0, v156, vcc_lo                    // 000000136798: 020338F2
	s_waitcnt lgkmcnt(2)                                       // 00000013679C: BF89FC27
	.long 0xd4120002                                           // 0000001367A0: D4120002
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 0000001367A4: 020332F2
	.long 0xd4120004                                           // 0000001367A8: D4120004
	v_cndmask_b32_e32 v1, 1.0, v154, vcc_lo                    // 0000001367AC: 020334F2
	s_and_b32 s1, vcc_lo, s1                                   // 0000001367B0: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 0000001367B4: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v151                         // 0000001367B8: 7C252EF2
	s_and_b32 s2, s1, s2                                       // 0000001367BC: 8B020201
	.long 0xd4120001                                           // 0000001367C0: D4120001
	v_cndmask_b32_e32 v1, 1.0, v152, vcc_lo                    // 0000001367C4: 020330F2
	s_and_b32 s4, s2, s4                                       // 0000001367C8: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 0000001367CC: BF89FC07
	.long 0xd4120002                                           // 0000001367D0: D4120002
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 0000001367D4: 02032AF2
	s_and_b32 s4, s4, vcc_lo                                   // 0000001367D8: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v150                         // 0000001367DC: 7C252CF2
	s_and_b32 s1, s4, s1                                       // 0000001367E0: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001367E4: BF870499
	s_and_b32 s1, s1, s2                                       // 0000001367E8: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 0000001367EC: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001367F0: BF870099
	v_cndmask_b32_e64 v129, 0, 1, s1                           // 0000001367F4: D5010081 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v129                           // 0000001367FC: 7C9B0280
	ds_load_b128 v[129:132], v177                              // 000000136800: DBFC0000 810000B1
	ds_load_b128 v[133:136], v177 offset:16                    // 000000136808: DBFC0010 850000B1
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 000000136810: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 000000136814: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136818: BF870099
	v_cndmask_b32_e64 v182, 0, 1, s1                           // 00000013681C: D50100B6 00050280
	v_readfirstlane_b32 s1, v182                               // 000000136824: 7E0205B6
	s_bitcmp1_b32 s1, 0                                        // 000000136828: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 00000013682C: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000136830: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000136834: 8B6A017E
	s_cbranch_vccnz 63005                                      // 000000136838: BFA4F61D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b0>
	v_dual_mul_f32 v120, v155, v120 :: v_dual_mul_f32 v121, v156, v121// 00000013683C: C8C6F19B 7878F39C
	v_dual_mul_f32 v122, v153, v122 :: v_dual_mul_f32 v123, v154, v123// 000000136844: C8C6F599 7A7AF79A
	v_dual_mul_f32 v124, v151, v124 :: v_dual_mul_f32 v125, v152, v125// 00000013684C: C8C6F997 7C7CFB98
	v_dual_mul_f32 v126, v149, v126 :: v_dual_mul_f32 v127, v150, v127// 000000136854: C8C6FD95 7E7EFF96
	v_dual_mul_f32 v112, v155, v112 :: v_dual_mul_f32 v113, v156, v113// 00000013685C: C8C6E19B 7070E39C
	v_dual_mul_f32 v114, v153, v114 :: v_dual_mul_f32 v115, v154, v115// 000000136864: C8C6E599 7272E79A
	v_dual_mul_f32 v116, v151, v116 :: v_dual_mul_f32 v117, v152, v117// 00000013686C: C8C6E997 7474EB98
	v_dual_mul_f32 v118, v149, v118 :: v_dual_mul_f32 v119, v150, v119// 000000136874: C8C6ED95 7676EF96
	v_dual_mul_f32 v104, v155, v104 :: v_dual_mul_f32 v105, v156, v105// 00000013687C: C8C6D19B 6868D39C
	v_dual_mul_f32 v106, v153, v106 :: v_dual_mul_f32 v107, v154, v107// 000000136884: C8C6D599 6A6AD79A
	v_dual_mul_f32 v108, v151, v108 :: v_dual_mul_f32 v109, v152, v109// 00000013688C: C8C6D997 6C6CDB98
	v_dual_mul_f32 v110, v149, v110 :: v_dual_mul_f32 v111, v150, v111// 000000136894: C8C6DD95 6E6EDF96
	v_dual_mul_f32 v96, v155, v96 :: v_dual_mul_f32 v97, v156, v97// 00000013689C: C8C6C19B 6060C39C
	v_dual_mul_f32 v98, v153, v98 :: v_dual_mul_f32 v99, v154, v99// 0000001368A4: C8C6C599 6262C79A
	v_dual_mul_f32 v100, v151, v100 :: v_dual_mul_f32 v101, v152, v101// 0000001368AC: C8C6C997 6464CB98
	v_dual_mul_f32 v102, v149, v102 :: v_dual_mul_f32 v103, v150, v103// 0000001368B4: C8C6CD95 6666CF96
	v_dual_mul_f32 v88, v155, v88 :: v_dual_mul_f32 v89, v156, v89// 0000001368BC: C8C6B19B 5858B39C
	v_dual_mul_f32 v90, v153, v90 :: v_dual_mul_f32 v91, v154, v91// 0000001368C4: C8C6B599 5A5AB79A
	v_dual_mul_f32 v92, v151, v92 :: v_dual_mul_f32 v93, v152, v93// 0000001368CC: C8C6B997 5C5CBB98
	v_dual_mul_f32 v94, v149, v94 :: v_dual_mul_f32 v95, v150, v95// 0000001368D4: C8C6BD95 5E5EBF96
	v_dual_mul_f32 v80, v155, v80 :: v_dual_mul_f32 v81, v156, v81// 0000001368DC: C8C6A19B 5050A39C
	v_dual_mul_f32 v82, v153, v82 :: v_dual_mul_f32 v83, v154, v83// 0000001368E4: C8C6A599 5252A79A
	v_dual_mul_f32 v84, v151, v84 :: v_dual_mul_f32 v85, v152, v85// 0000001368EC: C8C6A997 5454AB98
	v_dual_mul_f32 v86, v149, v86 :: v_dual_mul_f32 v87, v150, v87// 0000001368F4: C8C6AD95 5656AF96
	v_dual_mul_f32 v72, v155, v72 :: v_dual_mul_f32 v73, v156, v73// 0000001368FC: C8C6919B 4848939C
	v_dual_mul_f32 v74, v153, v74 :: v_dual_mul_f32 v75, v154, v75// 000000136904: C8C69599 4A4A979A
	v_dual_mul_f32 v76, v151, v76 :: v_dual_mul_f32 v77, v152, v77// 00000013690C: C8C69997 4C4C9B98
	v_dual_mul_f32 v78, v149, v78 :: v_dual_mul_f32 v79, v150, v79// 000000136914: C8C69D95 4E4E9F96
	v_dual_mul_f32 v64, v155, v64 :: v_dual_mul_f32 v65, v156, v65// 00000013691C: C8C6819B 4040839C
	v_dual_mul_f32 v66, v153, v66 :: v_dual_mul_f32 v67, v154, v67// 000000136924: C8C68599 4242879A
	v_dual_mul_f32 v68, v151, v68 :: v_dual_mul_f32 v69, v152, v69// 00000013692C: C8C68997 44448B98
	v_dual_mul_f32 v70, v149, v70 :: v_dual_mul_f32 v71, v150, v71// 000000136934: C8C68D95 46468F96
	v_dual_mul_f32 v56, v155, v56 :: v_dual_mul_f32 v57, v156, v57// 00000013693C: C8C6719B 3838739C
	v_dual_mul_f32 v58, v153, v58 :: v_dual_mul_f32 v59, v154, v59// 000000136944: C8C67599 3A3A779A
	v_dual_mul_f32 v60, v151, v60 :: v_dual_mul_f32 v61, v152, v61// 00000013694C: C8C67997 3C3C7B98
	v_dual_mul_f32 v62, v149, v62 :: v_dual_mul_f32 v63, v150, v63// 000000136954: C8C67D95 3E3E7F96
	v_dual_mul_f32 v48, v155, v48 :: v_dual_mul_f32 v49, v156, v49// 00000013695C: C8C6619B 3030639C
	v_dual_mul_f32 v50, v153, v50 :: v_dual_mul_f32 v51, v154, v51// 000000136964: C8C66599 3232679A
	v_dual_mul_f32 v52, v151, v52 :: v_dual_mul_f32 v53, v152, v53// 00000013696C: C8C66997 34346B98
	v_dual_mul_f32 v54, v149, v54 :: v_dual_mul_f32 v55, v150, v55// 000000136974: C8C66D95 36366F96
	v_dual_mul_f32 v40, v155, v40 :: v_dual_mul_f32 v41, v156, v41// 00000013697C: C8C6519B 2828539C
	v_dual_mul_f32 v42, v153, v42 :: v_dual_mul_f32 v43, v154, v43// 000000136984: C8C65599 2A2A579A
	v_dual_mul_f32 v44, v151, v44 :: v_dual_mul_f32 v45, v152, v45// 00000013698C: C8C65997 2C2C5B98
	v_dual_mul_f32 v46, v149, v46 :: v_dual_mul_f32 v47, v150, v47// 000000136994: C8C65D95 2E2E5F96
	v_dual_mul_f32 v32, v155, v32 :: v_dual_mul_f32 v33, v156, v33// 00000013699C: C8C6419B 2020439C
	v_dual_mul_f32 v34, v153, v34 :: v_dual_mul_f32 v35, v154, v35// 0000001369A4: C8C64599 2222479A
	v_dual_mul_f32 v36, v151, v36 :: v_dual_mul_f32 v37, v152, v37// 0000001369AC: C8C64997 24244B98
	v_dual_mul_f32 v38, v149, v38 :: v_dual_mul_f32 v39, v150, v39// 0000001369B4: C8C64D95 26264F96
	v_dual_mul_f32 v24, v155, v24 :: v_dual_mul_f32 v25, v156, v25// 0000001369BC: C8C6319B 1818339C
	v_dual_mul_f32 v26, v153, v26 :: v_dual_mul_f32 v27, v154, v27// 0000001369C4: C8C63599 1A1A379A
	v_dual_mul_f32 v28, v151, v28 :: v_dual_mul_f32 v29, v152, v29// 0000001369CC: C8C63997 1C1C3B98
	v_dual_mul_f32 v30, v149, v30 :: v_dual_mul_f32 v31, v150, v31// 0000001369D4: C8C63D95 1E1E3F96
	v_dual_mul_f32 v16, v155, v16 :: v_dual_mul_f32 v17, v156, v17// 0000001369DC: C8C6219B 1010239C
	v_dual_mul_f32 v18, v153, v18 :: v_dual_mul_f32 v19, v154, v19// 0000001369E4: C8C62599 1212279A
	v_dual_mul_f32 v20, v151, v20 :: v_dual_mul_f32 v21, v152, v21// 0000001369EC: C8C62997 14142B98
	v_dual_mul_f32 v22, v149, v22 :: v_dual_mul_f32 v23, v150, v23// 0000001369F4: C8C62D95 16162F96
	v_dual_mul_f32 v8, v155, v8 :: v_dual_mul_f32 v9, v156, v9 // 0000001369FC: C8C6119B 0808139C
	v_dual_mul_f32 v10, v153, v10 :: v_dual_mul_f32 v11, v154, v11// 000000136A04: C8C61599 0A0A179A
	v_dual_mul_f32 v12, v151, v12 :: v_dual_mul_f32 v13, v152, v13// 000000136A0C: C8C61997 0C0C1B98
	v_dual_mul_f32 v14, v149, v14 :: v_dual_mul_f32 v15, v150, v15// 000000136A14: C8C61D95 0E0E1F96
	v_dual_mul_f32 v0, v155, v0 :: v_dual_mul_f32 v1, v156, v1 // 000000136A1C: C8C6019B 0000039C
	v_dual_mul_f32 v2, v153, v2 :: v_dual_mul_f32 v3, v154, v3 // 000000136A24: C8C60599 0202079A
	v_dual_mul_f32 v4, v151, v4 :: v_dual_mul_f32 v5, v152, v5 // 000000136A2C: C8C60997 04040B98
	v_dual_mul_f32 v6, v149, v6 :: v_dual_mul_f32 v7, v150, v7 // 000000136A34: C8C60D95 06060F96
	s_branch 62876                                             // 000000136A3C: BFA0F59C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b0>
	v_lshlrev_b32_e32 v128, 2, v162                            // 000000136A40: 31014482
	.long 0xd700008e                                           // 000000136A44: D700008E
	v_cndmask_b32_e32 v1, s18, v142, vcc_lo                    // 000000136A48: 02031C12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000136A4C: BF870191
	v_add_co_ci_u32_e64 v143, null, s19, v143, s0              // 000000136A50: D5207C8F 00031E13
	v_lshl_or_b32 v128, v157, 6, v128                          // 000000136A58: D6560080 06010D9D
	s_waitcnt vmcnt(0)                                         // 000000136A60: BF8903F7
	v_or_b32_e32 v140, v158, v162                              // 000000136A64: 3919459E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000136A68: BF870002
	v_add_nc_u32_e32 v132, 0xf000, v128                        // 000000136A6C: 4B0900FF 0000F000
	v_lshlrev_b32_e32 v128, 9, v141                            // 000000136A74: 31011A89
	ds_load_2addr_b32 v[138:139], v132 offset0:192 offset1:194 // 000000136A78: D8DCC2C0 8A000084
	ds_load_2addr_b32 v[136:137], v132 offset0:196 offset1:198 // 000000136A80: D8DCC6C4 88000084
	ds_load_2addr_b32 v[134:135], v132 offset0:200 offset1:202 // 000000136A88: D8DCCAC8 86000084
	ds_load_2addr_b32 v[132:133], v132 offset0:204 offset1:206 // 000000136A90: D8DCCECC 84000084
	s_waitcnt lgkmcnt(3)                                       // 000000136A98: BF89FC37
	v_div_scale_f32 v144, null, v138, v138, 1.0                // 000000136A9C: D6FC7C90 03CB158A
	v_div_scale_f32 v141, vcc_lo, 1.0, v138, 1.0               // 000000136AA4: D6FC6A8D 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000136AAC: BF870292
	v_rcp_f32_e32 v145, v144                                   // 000000136AB0: 7F225590
	v_fma_f32 v129, -v144, v145, 1.0                           // 000000136AB4: D6130081 23CB2390
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000136ABC: BF870121
	v_fmac_f32_e32 v145, v129, v145                            // 000000136AC0: 57232381
	v_ashrrev_i32_e32 v129, 31, v128                           // 000000136AC4: 3503009F
	v_mul_f32_e32 v146, v141, v145                             // 000000136AC8: 1125238D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000136ACC: BF8700A2
	.long 0xd73c0082                                           // 000000136AD0: D73C0082
	v_cndmask_b32_e32 v1, 1, v128, vcc_lo                      // 000000136AD4: 02030081
	.long 0xd7000080                                           // 000000136AD8: D7000080
	v_cndmask_b32_e32 v1, v142, v160, vcc_lo                   // 000000136ADC: 0203418E
	v_add_co_ci_u32_e64 v129, null, 0, v143, s0                // 000000136AE0: D5207C81 00031E80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000136AE8: BF870214
	v_fma_f32 v147, -v144, v146, v141                          // 000000136AEC: D6130093 26372590
	.long 0xd7000082                                           // 000000136AF4: D7000082
	v_cndmask_b32_e32 v1, s16, v130, vcc_lo                    // 000000136AF8: 02030410
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000136AFC: BF870191
	v_add_co_ci_u32_e64 v131, null, s17, v131, s0              // 000000136B00: D5207C83 00030611
	v_fmac_f32_e32 v146, v147, v145                            // 000000136B08: 57252393
	.long 0xd4440000                                           // 000000136B0C: D4440000
	v_cndmask_b32_e32 v1, s14, v140, vcc_lo                    // 000000136B10: 0203180E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136B14: BF870092
	v_fma_f32 v141, -v144, v146, v141                          // 000000136B18: D613008D 26372590
	v_div_fmas_f32 v141, v141, v145, v146                      // 000000136B20: D637008D 064B238D
	.long 0xd7006a82                                           // 000000136B28: D7006A82
	v_cndmask_b32_e32 v1, v130, v160, vcc_lo                   // 000000136B2C: 02034182
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000136B30: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, vcc_lo            // 000000136B34: D5207C83 01AB0680
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 000000136B3C: D627008A 03CB158D
	s_and_saveexec_b32 s1, s0                                  // 000000136B44: BE812000
	s_cbranch_execz 70                                         // 000000136B48: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3464>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000136B4C: BF870112
	v_mad_i64_i32 v[141:142], null, 0x6000, v140, v[130:131]   // 000000136B50: D6FF7C8D 060B18FF 00006000
	v_mul_f32_e32 v120, v138, v120                             // 000000136B5C: 10F0F18A
	global_load_u16 v141, v[141:142], off offset:512           // 000000136B60: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000136B68: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000136B6C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136B70: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000136B74: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000136B7C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000136B88: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000136B8C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000136B90: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000136B94: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000136B9C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000136BA4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000136BA8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000136BAC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000136BB0: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136BB4: BF870095
	.long 0xd71c008e                                           // 000000136BB8: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000136BBC: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000136BC0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000136BC4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136BCC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000136BD0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000136BD8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136BDC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v120               // 000000136BE0: D6FC7C8E 05E31B8D
	v_rcp_f32_e32 v143, v142                                   // 000000136BE8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136BEC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000136BF0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000136BF8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v120, v141, v120             // 000000136BFC: D6FC6A90 05E31B78
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136C04: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000136C08: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000136C0C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136C14: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000136C18: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000136C1C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136C24: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000136C28: D637008E 06471F8E
	v_div_fixup_f32 v120, v142, v141, v120                     // 000000136C30: D6270078 05E31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v140, v[128:129]   // 000000136C38: D6FF7C8D 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136C44: BF870092
	v_bfe_u32 v143, v120, 16, 1                                // 000000136C48: D610008F 02052178
	v_add3_u32 v120, v120, v143, 0x7fff                        // 000000136C50: D6550078 03FF1F78 00007FFF
	global_store_d16_hi_b16 v[141:142], v120, off              // 000000136C5C: DC960000 007C788D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000136C64: 8C7E017E
	v_div_scale_f32 v120, null, v139, v139, 1.0                // 000000136C68: D6FC7C78 03CB178B
	v_div_scale_f32 v143, vcc_lo, 1.0, v139, 1.0               // 000000136C70: D6FC6A8F 03CB16F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000136C78: BF870292
	v_rcp_f32_e32 v141, v120                                   // 000000136C7C: 7F1A5578
	v_fma_f32 v142, -v120, v141, 1.0                           // 000000136C80: D613008E 23CB1B78
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136C88: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000136C8C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000136C90: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136C94: BF870091
	v_fma_f32 v144, -v120, v142, v143                          // 000000136C98: D6130090 263F1D78
	v_fmac_f32_e32 v142, v144, v141                            // 000000136CA0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136CA4: BF870091
	v_fma_f32 v120, -v120, v142, v143                          // 000000136CA8: D6130078 263F1D78
	v_div_fmas_f32 v141, v120, v141, v142                      // 000000136CB0: D637008D 063B1B78
	v_or_b32_e32 v120, 2, v140                                 // 000000136CB8: 38F11882
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000136CBC: BF870112
	v_div_fixup_f32 v139, v141, v139, 1.0                      // 000000136CC0: D627008B 03CB178D
	.long 0xd4440001                                           // 000000136CC8: D4440001
	v_cndmask_b32_e32 v1, s14, v120, vcc_lo                    // 000000136CCC: 0202F00E
	s_and_saveexec_b32 s2, s1                                  // 000000136CD0: BE822001
	s_cbranch_execz 69                                         // 000000136CD4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35ec>
	v_mad_i64_i32 v[141:142], null, 0x6000, v120, v[130:131]   // 000000136CD8: D6FF7C8D 060AF0FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 000000136CE4: 10F2F38B
	global_load_u16 v141, v[141:142], off offset:512           // 000000136CE8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000136CF0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000136CF4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136CF8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000136CFC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000136D04: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000136D10: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000136D14: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000136D18: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000136D1C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000136D24: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000136D2C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000136D30: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000136D34: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000136D38: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136D3C: BF870095
	.long 0xd71c008e                                           // 000000136D40: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000136D44: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000136D48: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000136D4C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136D54: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000136D58: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000136D60: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136D64: BF870091
	v_div_scale_f32 v142, null, v141, v141, v121               // 000000136D68: D6FC7C8E 05E71B8D
	v_rcp_f32_e32 v143, v142                                   // 000000136D70: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136D74: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000136D78: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000136D80: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v141, v121             // 000000136D84: D6FC6A90 05E71B79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136D8C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000136D90: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000136D94: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136D9C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000136DA0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000136DA4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136DAC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000136DB0: D637008E 06471F8E
	v_div_fixup_f32 v121, v142, v141, v121                     // 000000136DB8: D6270079 05E71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v120, v[128:129]   // 000000136DC0: D6FF7C8D 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136DCC: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 000000136DD0: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 000000136DD8: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[141:142], v121, off              // 000000136DE4: DC960000 007C798D
	s_or_b32 exec_lo, exec_lo, s2                              // 000000136DEC: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 000000136DF0: BF89FC27
	v_div_scale_f32 v121, null, v136, v136, 1.0                // 000000136DF4: D6FC7C79 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 000000136DFC: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000136E04: BF870292
	v_rcp_f32_e32 v141, v121                                   // 000000136E08: 7F1A5579
	v_fma_f32 v142, -v121, v141, 1.0                           // 000000136E0C: D613008E 23CB1B79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136E14: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000136E18: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000136E1C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136E20: BF870091
	v_fma_f32 v144, -v121, v142, v143                          // 000000136E24: D6130090 263F1D79
	v_fmac_f32_e32 v142, v144, v141                            // 000000136E2C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136E30: BF870091
	v_fma_f32 v121, -v121, v142, v143                          // 000000136E34: D6130079 263F1D79
	v_div_fmas_f32 v141, v121, v141, v142                      // 000000136E3C: D637008D 063B1B79
	v_or_b32_e32 v121, 4, v140                                 // 000000136E44: 38F31884
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000136E48: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 000000136E4C: D6270088 03CB118D
	.long 0xd4440002                                           // 000000136E54: D4440002
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 000000136E58: 0202F20E
	s_and_saveexec_b32 s3, s2                                  // 000000136E5C: BE832002
	s_cbranch_execz 69                                         // 000000136E60: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3778>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[130:131]   // 000000136E64: D6FF7C8D 060AF2FF 00006000
	v_mul_f32_e32 v122, v136, v122                             // 000000136E70: 10F4F588
	global_load_u16 v141, v[141:142], off offset:512           // 000000136E74: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000136E7C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000136E80: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136E84: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000136E88: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000136E90: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000136E9C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000136EA0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000136EA4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000136EA8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000136EB0: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000136EB8: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000136EBC: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000136EC0: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000136EC4: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136EC8: BF870095
	.long 0xd71c008e                                           // 000000136ECC: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000136ED0: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000136ED4: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000136ED8: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136EE0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000136EE4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000136EEC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136EF0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 000000136EF4: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000136EFC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136F00: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000136F04: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000136F0C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 000000136F10: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136F18: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000136F1C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000136F20: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136F28: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000136F2C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000136F30: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136F38: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000136F3C: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 000000136F44: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[128:129]   // 000000136F4C: D6FF7C8D 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136F58: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 000000136F5C: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 000000136F64: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 000000136F70: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s3                              // 000000136F78: 8C7E037E
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 000000136F7C: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 000000136F84: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000136F8C: BF870292
	v_rcp_f32_e32 v141, v122                                   // 000000136F90: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 000000136F94: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136F9C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000136FA0: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000136FA4: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136FA8: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 000000136FAC: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 000000136FB4: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000136FB8: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 000000136FBC: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 000000136FC4: D637008D 063B1B7A
	v_or_b32_e32 v122, 6, v140                                 // 000000136FCC: 38F51886
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000136FD0: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 000000136FD4: D6270089 03CB138D
	.long 0xd4440003                                           // 000000136FDC: D4440003
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 000000136FE0: 0202F40E
	s_and_saveexec_b32 s4, s3                                  // 000000136FE4: BE842003
	s_cbranch_execz 69                                         // 000000136FE8: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3900>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[130:131]   // 000000136FEC: D6FF7C8D 060AF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 000000136FF8: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 000000136FFC: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000137004: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000137008: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013700C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000137010: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000137018: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000137024: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000137028: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000013702C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000137030: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000137038: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000137040: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000137044: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000137048: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000013704C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137050: BF870095
	.long 0xd71c008e                                           // 000000137054: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000137058: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000013705C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000137060: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137068: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000013706C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000137074: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137078: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 00000013707C: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000137084: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137088: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000013708C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000137094: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 000000137098: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001370A0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000001370A4: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000001370A8: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001370B0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000001370B4: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000001370B8: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001370C0: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000001370C4: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 0000001370CC: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[128:129]   // 0000001370D4: D6FF7C8D 0602F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001370E0: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 0000001370E4: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 0000001370EC: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 0000001370F8: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s4                              // 000000137100: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 000000137104: BF89FC17
	v_div_scale_f32 v123, null, v134, v134, 1.0                // 000000137108: D6FC7C7B 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 000000137110: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000137118: BF870292
	v_rcp_f32_e32 v141, v123                                   // 00000013711C: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 000000137120: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137128: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000013712C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000137130: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137134: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 000000137138: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 000000137140: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137144: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 000000137148: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 000000137150: D637008D 063B1B7B
	v_or_b32_e32 v123, 8, v140                                 // 000000137158: 38F71888
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013715C: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 000000137160: D6270086 03CB0D8D
	.long 0xd4440004                                           // 000000137168: D4440004
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 00000013716C: 0202F60E
	s_and_saveexec_b32 s5, s4                                  // 000000137170: BE852004
	s_cbranch_execz 69                                         // 000000137174: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a8c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[130:131]   // 000000137178: D6FF7C8D 060AF6FF 00006000
	v_mul_f32_e32 v124, v134, v124                             // 000000137184: 10F8F986
	global_load_u16 v141, v[141:142], off offset:512           // 000000137188: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000137190: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000137194: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137198: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000013719C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000001371A4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000001371B0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001371B4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000001371B8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000001371BC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000001371C4: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001371CC: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000001371D0: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000001371D4: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000001371D8: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001371DC: BF870095
	.long 0xd71c008e                                           // 0000001371E0: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000001371E4: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000001371E8: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000001371EC: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001371F4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000001371F8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000137200: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137204: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 000000137208: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 000000137210: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137214: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000137218: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000137220: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 000000137224: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013722C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000137230: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000137234: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013723C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000137240: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000137244: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013724C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000137250: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 000000137258: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[128:129]   // 000000137260: D6FF7C8D 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013726C: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 000000137270: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 000000137278: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 000000137284: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s5                              // 00000013728C: 8C7E057E
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 000000137290: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 000000137298: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001372A0: BF870292
	v_rcp_f32_e32 v141, v124                                   // 0000001372A4: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 0000001372A8: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001372B0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000001372B4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000001372B8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001372BC: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 0000001372C0: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 0000001372C8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001372CC: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 0000001372D0: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 0000001372D8: D637008D 063B1B7C
	v_or_b32_e32 v124, 10, v140                                // 0000001372E0: 38F9188A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001372E4: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 0000001372E8: D6270087 03CB0F8D
	.long 0xd4440005                                           // 0000001372F0: D4440005
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 0000001372F4: 0202F80E
	s_and_saveexec_b32 s6, s5                                  // 0000001372F8: BE862005
	s_cbranch_execz 69                                         // 0000001372FC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c14>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[130:131]   // 000000137300: D6FF7C8D 060AF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 00000013730C: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 000000137310: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000137318: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000013731C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137320: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000137324: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000013732C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000137338: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013733C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000137340: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000137344: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000013734C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000137354: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000137358: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000013735C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000137360: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137364: BF870095
	.long 0xd71c008e                                           // 000000137368: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000013736C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000137370: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000137374: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013737C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000137380: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000137388: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013738C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 000000137390: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 000000137398: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013739C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000001373A0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000001373A8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 0000001373AC: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001373B4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000001373B8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000001373BC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001373C4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000001373C8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000001373CC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001373D4: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000001373D8: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 0000001373E0: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[128:129]   // 0000001373E8: D6FF7C8D 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001373F4: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 0000001373F8: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 000000137400: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 00000013740C: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s6                              // 000000137414: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000137418: BF89FC07
	v_div_scale_f32 v125, null, v132, v132, 1.0                // 00000013741C: D6FC7C7D 03CB0984
	v_div_scale_f32 v143, vcc_lo, 1.0, v132, 1.0               // 000000137424: D6FC6A8F 03CB08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013742C: BF870292
	v_rcp_f32_e32 v141, v125                                   // 000000137430: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 000000137434: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013743C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000137440: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000137444: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137448: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 00000013744C: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 000000137454: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137458: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 00000013745C: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 000000137464: D637008D 063B1B7D
	v_or_b32_e32 v125, 12, v140                                // 00000013746C: 38FB188C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000137470: BF870112
	v_div_fixup_f32 v132, v141, v132, 1.0                      // 000000137474: D6270084 03CB098D
	.long 0xd4440006                                           // 00000013747C: D4440006
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 000000137480: 0202FA0E
	s_and_saveexec_b32 s7, s6                                  // 000000137484: BE872006
	s_cbranch_execz 69                                         // 000000137488: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3da0>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[130:131]   // 00000013748C: D6FF7C8D 060AFAFF 00006000
	v_mul_f32_e32 v126, v132, v126                             // 000000137498: 10FCFD84
	global_load_u16 v141, v[141:142], off offset:512           // 00000013749C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000001374A4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000001374A8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001374AC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000001374B0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000001374B8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000001374C4: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001374C8: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000001374CC: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000001374D0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000001374D8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001374E0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000001374E4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000001374E8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000001374EC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001374F0: BF870095
	.long 0xd71c008e                                           // 0000001374F4: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000001374F8: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000001374FC: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000137500: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137508: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000013750C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000137514: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137518: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 00000013751C: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000137524: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137528: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000013752C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000137534: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 000000137538: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137540: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000137544: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000137548: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137550: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000137554: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000137558: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137560: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000137564: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 00000013756C: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[128:129]   // 000000137574: D6FF7C8D 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137580: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 000000137584: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 00000013758C: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 000000137598: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001375A0: 8C7E077E
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 0000001375A4: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 0000001375AC: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001375B4: BF870292
	v_rcp_f32_e32 v141, v126                                   // 0000001375B8: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 0000001375BC: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001375C4: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000001375C8: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000001375CC: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001375D0: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 0000001375D4: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 0000001375DC: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001375E0: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 0000001375E4: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 0000001375EC: D637008D 063B1B7E
	v_or_b32_e32 v126, 14, v140                                // 0000001375F4: 38FD188E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001375F8: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 0000001375FC: D6270085 03CB0B8D
	.long 0xd4440007                                           // 000000137604: D4440007
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 000000137608: 0202FC0E
	s_and_saveexec_b32 s8, s7                                  // 00000013760C: BE882007
	s_cbranch_execnz 361                                       // 000000137610: BFA60169 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x43b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137614: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000137618: BE882000
	s_cbranch_execnz 430                                       // 00000013761C: BFA601AE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x44d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137620: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000137624: BE882001
	s_cbranch_execnz 499                                       // 000000137628: BFA601F3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x45f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013762C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000137630: BE882002
	s_cbranch_execnz 568                                       // 000000137634: BFA60238 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4718>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137638: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013763C: BE882003
	s_cbranch_execnz 637                                       // 000000137640: BFA6027D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4838>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137644: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000137648: BE882004
	s_cbranch_execnz 706                                       // 00000013764C: BFA602C2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4958>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137650: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000137654: BE882005
	s_cbranch_execnz 775                                       // 000000137658: BFA60307 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4a78>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013765C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000137660: BE882006
	s_cbranch_execnz 844                                       // 000000137664: BFA6034C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4b98>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137668: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013766C: BE882007
	s_cbranch_execnz 913                                       // 000000137670: BFA60391 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4cb8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137674: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000137678: BE882000
	s_cbranch_execnz 982                                       // 00000013767C: BFA603D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4dd8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137680: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000137684: BE882001
	s_cbranch_execnz 1051                                      // 000000137688: BFA6041B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4ef8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013768C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000137690: BE882002
	s_cbranch_execnz 1120                                      // 000000137694: BFA60460 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5018>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137698: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013769C: BE882003
	s_cbranch_execnz 1189                                      // 0000001376A0: BFA604A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5138>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001376A4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001376A8: BE882004
	s_cbranch_execnz 1258                                      // 0000001376AC: BFA604EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5258>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001376B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001376B4: BE882005
	s_cbranch_execnz 1327                                      // 0000001376B8: BFA6052F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5378>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001376BC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001376C0: BE882006
	s_cbranch_execnz 1396                                      // 0000001376C4: BFA60574 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5498>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001376C8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001376CC: BE882007
	s_cbranch_execnz 1465                                      // 0000001376D0: BFA605B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x55b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001376D4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001376D8: BE882000
	s_cbranch_execnz 1534                                      // 0000001376DC: BFA605FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x56d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001376E0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001376E4: BE882001
	s_cbranch_execnz 1603                                      // 0000001376E8: BFA60643 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x57f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001376EC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001376F0: BE882002
	s_cbranch_execnz 1672                                      // 0000001376F4: BFA60688 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5918>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001376F8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001376FC: BE882003
	s_cbranch_execnz 1741                                      // 000000137700: BFA606CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5a38>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137704: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000137708: BE882004
	s_cbranch_execnz 1810                                      // 00000013770C: BFA60712 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5b58>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137710: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000137714: BE882005
	s_cbranch_execnz 1879                                      // 000000137718: BFA60757 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5c78>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013771C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000137720: BE882006
	s_cbranch_execnz 1948                                      // 000000137724: BFA6079C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5d98>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137728: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013772C: BE882007
	s_cbranch_execnz 2017                                      // 000000137730: BFA607E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5eb8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137734: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000137738: BE882000
	s_cbranch_execnz 2086                                      // 00000013773C: BFA60826 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5fd8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137740: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000137744: BE882001
	s_cbranch_execnz 2155                                      // 000000137748: BFA6086B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x60f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013774C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000137750: BE882002
	s_cbranch_execnz 2224                                      // 000000137754: BFA608B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6218>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137758: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013775C: BE882003
	s_cbranch_execnz 2293                                      // 000000137760: BFA608F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6338>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137764: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000137768: BE882004
	s_cbranch_execnz 2362                                      // 00000013776C: BFA6093A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6458>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137770: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000137774: BE882005
	s_cbranch_execnz 2431                                      // 000000137778: BFA6097F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6578>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013777C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000137780: BE882006
	s_cbranch_execnz 2500                                      // 000000137784: BFA609C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6698>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137788: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013778C: BE882007
	s_cbranch_execnz 2569                                      // 000000137790: BFA60A09 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x67b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137794: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000137798: BE882000
	s_cbranch_execnz 2638                                      // 00000013779C: BFA60A4E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x68d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001377A0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001377A4: BE882001
	s_cbranch_execnz 2707                                      // 0000001377A8: BFA60A93 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x69f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001377AC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001377B0: BE882002
	s_cbranch_execnz 2776                                      // 0000001377B4: BFA60AD8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6b18>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001377B8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001377BC: BE882003
	s_cbranch_execnz 2845                                      // 0000001377C0: BFA60B1D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6c38>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001377C4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001377C8: BE882004
	s_cbranch_execnz 2914                                      // 0000001377CC: BFA60B62 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6d58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001377D0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001377D4: BE882005
	s_cbranch_execnz 2983                                      // 0000001377D8: BFA60BA7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6e78>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001377DC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001377E0: BE882006
	s_cbranch_execnz 3052                                      // 0000001377E4: BFA60BEC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6f98>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001377E8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001377EC: BE882007
	s_cbranch_execnz 3121                                      // 0000001377F0: BFA60C31 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x70b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001377F4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001377F8: BE882000
	s_cbranch_execnz 3190                                      // 0000001377FC: BFA60C76 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x71d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137800: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000137804: BE882001
	s_cbranch_execnz 3259                                      // 000000137808: BFA60CBB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x72f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013780C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000137810: BE882002
	s_cbranch_execnz 3328                                      // 000000137814: BFA60D00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7418>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137818: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013781C: BE882003
	s_cbranch_execnz 3397                                      // 000000137820: BFA60D45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7538>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137824: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000137828: BE882004
	s_cbranch_execnz 3466                                      // 00000013782C: BFA60D8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7658>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137830: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000137834: BE882005
	s_cbranch_execnz 3535                                      // 000000137838: BFA60DCF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7778>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013783C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000137840: BE882006
	s_cbranch_execnz 3604                                      // 000000137844: BFA60E14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7898>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137848: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013784C: BE882007
	s_cbranch_execnz 3673                                      // 000000137850: BFA60E59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x79b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137854: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000137858: BE882000
	s_cbranch_execnz 3742                                      // 00000013785C: BFA60E9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7ad8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137860: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000137864: BE882001
	s_cbranch_execnz 3811                                      // 000000137868: BFA60EE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7bf8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013786C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000137870: BE882002
	s_cbranch_execnz 3880                                      // 000000137874: BFA60F28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7d18>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137878: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013787C: BE882003
	s_cbranch_execnz 3949                                      // 000000137880: BFA60F6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7e38>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137884: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000137888: BE882004
	s_cbranch_execnz 4018                                      // 00000013788C: BFA60FB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7f58>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137890: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000137894: BE882005
	s_cbranch_execnz 4087                                      // 000000137898: BFA60FF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8078>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013789C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001378A0: BE882006
	s_cbranch_execnz 4156                                      // 0000001378A4: BFA6103C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8198>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001378A8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001378AC: BE882007
	s_cbranch_execnz 4225                                      // 0000001378B0: BFA61081 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x82b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001378B4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001378B8: BE882000
	s_cbranch_execnz 4294                                      // 0000001378BC: BFA610C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x83d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001378C0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001378C4: BE882001
	s_cbranch_execnz 4363                                      // 0000001378C8: BFA6110B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x84f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001378CC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001378D0: BE882002
	s_cbranch_execnz 4432                                      // 0000001378D4: BFA61150 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8618>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001378D8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001378DC: BE882003
	s_cbranch_execnz 4501                                      // 0000001378E0: BFA61195 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8738>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001378E4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001378E8: BE882004
	s_cbranch_execnz 4570                                      // 0000001378EC: BFA611DA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8858>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001378F0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001378F4: BE882005
	s_cbranch_execnz 4639                                      // 0000001378F8: BFA6121F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8978>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001378FC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000137900: BE882006
	s_cbranch_execnz 4708                                      // 000000137904: BFA61264 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8a98>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137908: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013790C: BE882007
	s_cbranch_execnz 4777                                      // 000000137910: BFA612A9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8bb8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137914: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000137918: BE882000
	s_cbranch_execnz 4846                                      // 00000013791C: BFA612EE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8cd8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137920: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000137924: BE882001
	s_cbranch_execnz 4915                                      // 000000137928: BFA61333 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8df8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013792C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000137930: BE882002
	s_cbranch_execnz 4984                                      // 000000137934: BFA61378 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8f18>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137938: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013793C: BE882003
	s_cbranch_execnz 5053                                      // 000000137940: BFA613BD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9038>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137944: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000137948: BE882004
	s_cbranch_execnz 5122                                      // 00000013794C: BFA61402 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9158>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137950: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000137954: BE882005
	s_cbranch_execnz 5191                                      // 000000137958: BFA61447 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9278>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013795C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000137960: BE882006
	s_cbranch_execnz 5260                                      // 000000137964: BFA6148C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9398>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137968: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013796C: BE882007
	s_cbranch_execnz 5329                                      // 000000137970: BFA614D1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x94b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137974: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000137978: BE882000
	s_cbranch_execnz 5398                                      // 00000013797C: BFA61516 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x95d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137980: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000137984: BE882001
	s_cbranch_execnz 5467                                      // 000000137988: BFA6155B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x96f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013798C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000137990: BE882002
	s_cbranch_execnz 5536                                      // 000000137994: BFA615A0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9818>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137998: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013799C: BE882003
	s_cbranch_execnz 5605                                      // 0000001379A0: BFA615E5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9938>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001379A4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001379A8: BE882004
	s_cbranch_execnz 5674                                      // 0000001379AC: BFA6162A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9a58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001379B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001379B4: BE882005
	s_cbranch_execnz 5743                                      // 0000001379B8: BFA6166F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9b78>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001379BC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001379C0: BE882006
	s_cbranch_execnz 5812                                      // 0000001379C4: BFA616B4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c98>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001379C8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001379CC: BE882007
	s_cbranch_execnz 5881                                      // 0000001379D0: BFA616F9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9db8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001379D4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001379D8: BE882000
	s_cbranch_execnz 5950                                      // 0000001379DC: BFA6173E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9ed8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001379E0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001379E4: BE882001
	s_cbranch_execnz 6019                                      // 0000001379E8: BFA61783 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9ff8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001379EC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001379F0: BE882002
	s_cbranch_execnz 6088                                      // 0000001379F4: BFA617C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa118>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001379F8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001379FC: BE882003
	s_cbranch_execnz 6157                                      // 000000137A00: BFA6180D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa238>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137A04: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000137A08: BE882004
	s_cbranch_execnz 6226                                      // 000000137A0C: BFA61852 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa358>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137A10: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000137A14: BE882005
	s_cbranch_execnz 6295                                      // 000000137A18: BFA61897 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa478>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137A1C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000137A20: BE882006
	s_cbranch_execnz 6364                                      // 000000137A24: BFA618DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa598>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137A28: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000137A2C: BE882007
	s_cbranch_execnz 6433                                      // 000000137A30: BFA61921 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa6b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137A34: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000137A38: BE882000
	s_cbranch_execnz 6502                                      // 000000137A3C: BFA61966 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa7d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137A40: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000137A44: BE882001
	s_cbranch_execnz 6571                                      // 000000137A48: BFA619AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa8f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137A4C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000137A50: BE882002
	s_cbranch_execnz 6640                                      // 000000137A54: BFA619F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaa18>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137A58: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000137A5C: BE882003
	s_cbranch_execnz 6709                                      // 000000137A60: BFA61A35 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xab38>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137A64: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000137A68: BE882004
	s_cbranch_execnz 6778                                      // 000000137A6C: BFA61A7A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac58>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137A70: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000137A74: BE882005
	s_cbranch_execnz 6847                                      // 000000137A78: BFA61ABF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xad78>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137A7C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000137A80: BE882006
	s_cbranch_execnz 6916                                      // 000000137A84: BFA61B04 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xae98>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137A88: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000137A8C: BE882007
	s_cbranch_execnz 6985                                      // 000000137A90: BFA61B49 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xafb8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137A94: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000137A98: BE882000
	s_cbranch_execnz 7054                                      // 000000137A9C: BFA61B8E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb0d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137AA0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000137AA4: BE882001
	s_cbranch_execnz 7123                                      // 000000137AA8: BFA61BD3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb1f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137AAC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000137AB0: BE882002
	s_cbranch_execnz 7192                                      // 000000137AB4: BFA61C18 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb318>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137AB8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000137ABC: BE882003
	s_cbranch_execnz 7261                                      // 000000137AC0: BFA61C5D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb438>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137AC4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000137AC8: BE882004
	s_cbranch_execnz 7330                                      // 000000137ACC: BFA61CA2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb558>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137AD0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000137AD4: BE882005
	s_cbranch_execnz 7399                                      // 000000137AD8: BFA61CE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb678>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137ADC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000137AE0: BE882006
	s_cbranch_execnz 7468                                      // 000000137AE4: BFA61D2C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb798>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137AE8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000137AEC: BE882007
	s_cbranch_execnz 7537                                      // 000000137AF0: BFA61D71 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb8b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137AF4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000137AF8: BE882000
	s_cbranch_execnz 7606                                      // 000000137AFC: BFA61DB6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb9d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137B00: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000137B04: BE882001
	s_cbranch_execnz 7675                                      // 000000137B08: BFA61DFB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbaf8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137B0C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000137B10: BE882002
	s_cbranch_execnz 7744                                      // 000000137B14: BFA61E40 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbc18>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137B18: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000137B1C: BE882003
	s_cbranch_execnz 7813                                      // 000000137B20: BFA61E85 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbd38>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137B24: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000137B28: BE882004
	s_cbranch_execnz 7882                                      // 000000137B2C: BFA61ECA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbe58>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137B30: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000137B34: BE882005
	s_cbranch_execnz 7951                                      // 000000137B38: BFA61F0F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbf78>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137B3C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000137B40: BE882006
	s_cbranch_execnz 8020                                      // 000000137B44: BFA61F54 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc098>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137B48: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000137B4C: BE882007
	s_cbranch_execnz 8089                                      // 000000137B50: BFA61F99 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc1b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137B54: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000137B58: BE882000
	s_cbranch_execnz 8158                                      // 000000137B5C: BFA61FDE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc2d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137B60: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000137B64: BE802001
	s_cbranch_execnz 8227                                      // 000000137B68: BFA62023 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc3f8>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000137B6C: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 000000137B70: BE802002
	s_cbranch_execnz 8296                                      // 000000137B74: BFA62068 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc518>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000137B78: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 000000137B7C: BE802003
	s_cbranch_execnz 8365                                      // 000000137B80: BFA620AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc638>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000137B84: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000137B88: BE802004
	s_cbranch_execnz 8434                                      // 000000137B8C: BFA620F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc758>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000137B90: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000137B94: BE802005
	s_cbranch_execnz 8503                                      // 000000137B98: BFA62137 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc878>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000137B9C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000137BA0: BE802006
	s_cbranch_execnz 8572                                      // 000000137BA4: BFA6217C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc998>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000137BA8: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000137BAC: BE802007
	s_cbranch_execnz 8641                                      // 000000137BB0: BFA621C1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xcab8>
	s_endpgm                                                   // 000000137BB4: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[130:131]   // 000000137BB8: D6FF7C8D 060AFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 000000137BC4: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 000000137BC8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000137BD0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000137BD4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137BD8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000137BDC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000137BE4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000137BF0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000137BF4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000137BF8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000137BFC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000137C04: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000137C0C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000137C10: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000137C14: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000137C18: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137C1C: BF870095
	.long 0xd71c008e                                           // 000000137C20: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000137C24: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000137C28: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000137C2C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137C34: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000137C38: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000137C40: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137C44: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 000000137C48: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000137C50: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137C54: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000137C58: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000137C60: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 000000137C64: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137C6C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000137C70: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000137C74: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137C7C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000137C80: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000137C84: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137C8C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000137C90: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 000000137C98: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[128:129]   // 000000137CA0: D6FF7C8D 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137CAC: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 000000137CB0: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 000000137CB8: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 000000137CC4: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137CCC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000137CD0: BE882000
	s_cbranch_execz 65106                                      // 000000137CD4: BFA5FE52 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e20>
	v_mad_i64_i32 v[141:142], null, 0x6000, v140, v[130:131]   // 000000137CD8: D6FF7C8D 060B18FF 00006000
	v_mul_f32_e32 v112, v138, v112                             // 000000137CE4: 10E0E18A
	global_load_u16 v127, v[141:142], off offset:544           // 000000137CE8: DC4A0220 7F7C008D
	s_waitcnt vmcnt(0)                                         // 000000137CF0: BF8903F7
	v_lshlrev_b32_e32 v127, 16, v127                           // 000000137CF4: 30FEFE90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000137CF8: BF870121
	v_mul_f32_e32 v141, 0xbfb8aa3b, v127                       // 000000137CFC: 111AFEFF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v127                 // 000000137D04: 7C3CFEFF 42CE8ED0
	v_fma_f32 v142, 0xbfb8aa3b, v127, -v141                    // 000000137D0C: D613008E 8636FEFF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 000000137D18: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137D1C: BF870091
	v_dual_fmamk_f32 v142, v127, 0xb2a5705f, v142 :: v_dual_sub_f32 v141, v141, v143// 000000137D20: C88B1D7F 8E8D1F8D B2A5705F
	v_add_f32_e32 v141, v141, v142                             // 000000137D2C: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 000000137D30: 7F1C118F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000137D34: BF870292
	v_exp_f32_e32 v141, v141                                   // 000000137D38: 7F1A4B8D
	.long 0xd71c008d                                           // 000000137D3C: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 000000137D40: 02031D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000137D44: BF870121
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 000000137D48: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v127                 // 000000137D4C: 7C36FEFF C2B17218
	v_cndmask_b32_e32 v127, 0x7f800000, v141, vcc_lo           // 000000137D54: 02FF1AFF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137D5C: BF870091
	v_add_f32_e32 v127, 1.0, v127                              // 000000137D60: 06FEFEF2
	v_div_scale_f32 v141, null, v127, v127, v112               // 000000137D64: D6FC7C8D 05C2FF7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000137D6C: BF870291
	v_rcp_f32_e32 v142, v141                                   // 000000137D70: 7F1C558D
	v_fma_f32 v143, -v141, v142, 1.0                           // 000000137D74: D613008F 23CB1D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000137D7C: BF8700A1
	v_fmac_f32_e32 v142, v143, v142                            // 000000137D80: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v112, v127, v112             // 000000137D84: D6FC6A8F 05C2FF70
	v_mul_f32_e32 v144, v143, v142                             // 000000137D8C: 11211D8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137D90: BF870091
	v_fma_f32 v145, -v141, v144, v143                          // 000000137D94: D6130091 263F218D
	v_fmac_f32_e32 v144, v145, v142                            // 000000137D9C: 57211D91
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137DA0: BF870091
	v_fma_f32 v141, -v141, v144, v143                          // 000000137DA4: D613008D 263F218D
	v_div_fmas_f32 v141, v141, v142, v144                      // 000000137DAC: D637008D 06431D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000137DB4: BF870121
	v_div_fixup_f32 v112, v141, v127, v112                     // 000000137DB8: D6270070 05C2FF8D
	v_mad_i64_i32 v[141:142], null, 0x3000, v140, v[128:129]   // 000000137DC0: D6FF7C8D 060318FF 00003000
	v_bfe_u32 v127, v112, 16, 1                                // 000000137DCC: D610007F 02052170
	s_delay_alu instid0(VALU_DEP_1)                            // 000000137DD4: BF870001
	v_add3_u32 v112, v112, v127, 0x7fff                        // 000000137DD8: D6550070 03FEFF70 00007FFF
	global_store_d16_hi_b16 v[141:142], v112, off offset:32    // 000000137DE4: DC960020 007C708D
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137DEC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000137DF0: BE882001
	s_cbranch_execz 65037                                      // 000000137DF4: BFA5FE0D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e2c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v120, v[130:131]   // 000000137DF8: D6FF7C8D 060AF0FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 000000137E04: 10E2E38B
	global_load_u16 v112, v[141:142], off offset:544           // 000000137E08: DC4A0220 707C008D
	s_waitcnt vmcnt(0)                                         // 000000137E10: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 000000137E14: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137E18: BF870091
	v_mul_f32_e32 v127, 0xbfb8aa3b, v112                       // 000000137E1C: 10FEE0FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v112, -v127                    // 000000137E24: D613008D 85FEE0FF BFB8AA3B
	v_rndne_f32_e32 v142, v127                                 // 000000137E30: 7F1C477F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000137E34: BF870191
	v_sub_f32_e32 v127, v127, v142                             // 000000137E38: 08FF1D7F
	v_fmamk_f32 v141, v112, 0xb2a5705f, v141                   // 000000137E3C: 591B1B70 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 000000137E44: 7C3CE0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000137E4C: BF870122
	v_add_f32_e32 v127, v127, v141                             // 000000137E50: 06FF1B7F
	v_cvt_i32_f32_e32 v141, v142                               // 000000137E54: 7F1A118E
	v_exp_f32_e32 v127, v127                                   // 000000137E58: 7EFE4B7F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137E5C: BF870095
	.long 0xd71c007f                                           // 000000137E60: D71C007F
	v_cndmask_b32_e32 v1, v127, v141, vcc_lo                   // 000000137E64: 02031B7F
	v_cndmask_b32_e32 v127, 0, v127, vcc_lo                    // 000000137E68: 02FEFE80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 000000137E6C: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137E74: BF870092
	v_cndmask_b32_e32 v112, 0x7f800000, v127, vcc_lo           // 000000137E78: 02E0FEFF 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 000000137E80: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137E84: BF870091
	v_div_scale_f32 v127, null, v112, v112, v113               // 000000137E88: D6FC7C7F 05C6E170
	v_rcp_f32_e32 v141, v127                                   // 000000137E90: 7F1A557F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137E94: BF870095
	v_fma_f32 v142, -v127, v141, 1.0                           // 000000137E98: D613008E 23CB1B7F
	v_fmac_f32_e32 v141, v142, v141                            // 000000137EA0: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v113, v112, v113             // 000000137EA4: D6FC6A8E 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137EAC: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 000000137EB0: 111F1B8E
	v_fma_f32 v144, -v127, v143, v142                          // 000000137EB4: D6130090 263B1F7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137EBC: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 000000137EC0: 571F1B90
	v_fma_f32 v127, -v127, v143, v142                          // 000000137EC4: D613007F 263B1F7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137ECC: BF870091
	v_div_fmas_f32 v127, v127, v141, v143                      // 000000137ED0: D637007F 063F1B7F
	v_div_fixup_f32 v127, v127, v112, v113                     // 000000137ED8: D627007F 05C6E17F
	v_mad_i64_i32 v[112:113], null, 0x3000, v120, v[128:129]   // 000000137EE0: D6FF7C70 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137EEC: BF870092
	v_bfe_u32 v141, v127, 16, 1                                // 000000137EF0: D610008D 0205217F
	v_add3_u32 v127, v127, v141, 0x7fff                        // 000000137EF8: D655007F 03FF1B7F 00007FFF
	global_store_d16_hi_b16 v[112:113], v127, off offset:32    // 000000137F04: DC960020 007C7F70
	s_or_b32 exec_lo, exec_lo, s8                              // 000000137F0C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000137F10: BE882002
	s_cbranch_execz 64968                                      // 000000137F14: BFA5FDC8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e38>
	v_mad_i64_i32 v[112:113], null, 0x6000, v121, v[130:131]   // 000000137F18: D6FF7C70 060AF2FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 000000137F24: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 000000137F2C: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 000000137F30: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137F34: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 000000137F38: 10E2E0FF BFB8AA3B
	v_fma_f32 v127, 0xbfb8aa3b, v112, -v113                    // 000000137F40: D613007F 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v141, v113                                 // 000000137F4C: 7F1A4771
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000137F50: BF870191
	v_sub_f32_e32 v113, v113, v141                             // 000000137F54: 08E31B71
	v_fmamk_f32 v127, v112, 0xb2a5705f, v127                   // 000000137F58: 58FEFF70 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 000000137F60: 7C3CE0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000137F68: BF870122
	v_add_f32_e32 v113, v113, v127                             // 000000137F6C: 06E2FF71
	v_cvt_i32_f32_e32 v127, v141                               // 000000137F70: 7EFE118D
	v_exp_f32_e32 v113, v113                                   // 000000137F74: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137F78: BF870095
	.long 0xd71c0071                                           // 000000137F7C: D71C0071
	v_cndmask_b32_e32 v1, v113, v127, vcc_lo                   // 000000137F80: 0202FF71
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 000000137F84: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 000000137F88: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137F90: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v136, v114// 000000137F94: CA46E2FF 7070E588 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 000000137FA0: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137FA4: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 000000137FA8: D6FC7C72 05C6E170
	v_rcp_f32_e32 v127, v114                                   // 000000137FB0: 7EFE5572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137FB4: BF870095
	v_fma_f32 v141, -v114, v127, 1.0                           // 000000137FB8: D613008D 23CAFF72
	v_fmac_f32_e32 v127, v141, v127                            // 000000137FC0: 56FEFF8D
	v_div_scale_f32 v141, vcc_lo, v113, v112, v113             // 000000137FC4: D6FC6A8D 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137FCC: BF870091
	v_mul_f32_e32 v142, v141, v127                             // 000000137FD0: 111CFF8D
	v_fma_f32 v143, -v114, v142, v141                          // 000000137FD4: D613008F 26371D72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137FDC: BF870091
	v_fmac_f32_e32 v142, v143, v127                            // 000000137FE0: 571CFF8F
	v_fma_f32 v114, -v114, v142, v141                          // 000000137FE4: D6130072 26371D72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000137FEC: BF870091
	v_div_fmas_f32 v114, v114, v127, v142                      // 000000137FF0: D6370072 063AFF72
	v_div_fixup_f32 v114, v114, v112, v113                     // 000000137FF8: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v121, v[128:129]   // 000000138000: D6FF7C70 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013800C: BF870092
	v_bfe_u32 v127, v114, 16, 1                                // 000000138010: D610007F 02052172
	v_add3_u32 v114, v114, v127, 0x7fff                        // 000000138018: D6550072 03FEFF72 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 000000138024: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013802C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000138030: BE882003
	s_cbranch_execz 64899                                      // 000000138034: BFA5FD83 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e44>
	v_mad_i64_i32 v[112:113], null, 0x6000, v122, v[130:131]   // 000000138038: D6FF7C70 060AF4FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 000000138044: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 00000013804C: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 000000138050: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138054: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 000000138058: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 000000138060: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v127, v113                                 // 00000013806C: 7EFE4771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000138070: BF870221
	v_sub_f32_e32 v113, v113, v127                             // 000000138074: 08E2FF71
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 000000138078: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 000000138080: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000138088: BF870121
	v_add_f32_e32 v113, v113, v114                             // 00000013808C: 06E2E571
	v_cvt_i32_f32_e32 v114, v127                               // 000000138090: 7EE4117F
	v_exp_f32_e32 v113, v113                                   // 000000138094: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138098: BF870095
	.long 0xd71c0071                                           // 00000013809C: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000001380A0: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000001380A4: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 0000001380A8: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001380B0: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v137, v115// 0000001380B4: CA46E2FF 7070E789 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 0000001380C0: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001380C4: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 0000001380C8: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 0000001380D0: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001380D4: BF870095
	v_fma_f32 v127, -v114, v115, 1.0                           // 0000001380D8: D613007F 23CAE772
	v_fmac_f32_e32 v115, v127, v115                            // 0000001380E0: 56E6E77F
	v_div_scale_f32 v127, vcc_lo, v113, v112, v113             // 0000001380E4: D6FC6A7F 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001380EC: BF870091
	v_mul_f32_e32 v141, v127, v115                             // 0000001380F0: 111AE77F
	v_fma_f32 v142, -v114, v141, v127                          // 0000001380F4: D613008E 25FF1B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001380FC: BF870091
	v_fmac_f32_e32 v141, v142, v115                            // 000000138100: 571AE78E
	v_fma_f32 v114, -v114, v141, v127                          // 000000138104: D6130072 25FF1B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013810C: BF870091
	v_div_fmas_f32 v114, v114, v115, v141                      // 000000138110: D6370072 0636E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 000000138118: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v122, v[128:129]   // 000000138120: D6FF7C70 0602F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013812C: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 000000138130: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 000000138138: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 000000138144: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013814C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000138150: BE882004
	s_cbranch_execz 64830                                      // 000000138154: BFA5FD3E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e50>
	v_mad_i64_i32 v[112:113], null, 0x6000, v123, v[130:131]   // 000000138158: D6FF7C70 060AF6FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 000000138164: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 00000013816C: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 000000138170: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138174: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 000000138178: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 000000138180: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 00000013818C: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000138190: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 000000138194: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 000000138198: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 0000001381A0: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001381A8: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000001381AC: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000001381B0: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000001381B4: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001381B8: BF870095
	.long 0xd71c0071                                           // 0000001381BC: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000001381C0: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000001381C4: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 0000001381C8: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001381D0: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v134, v116// 0000001381D4: CA46E2FF 7070E986 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 0000001381E0: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001381E4: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 0000001381E8: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 0000001381F0: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001381F4: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 0000001381F8: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 000000138200: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 000000138204: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013820C: BF870091
	v_mul_f32_e32 v127, v116, v115                             // 000000138210: 10FEE774
	v_fma_f32 v141, -v114, v127, v116                          // 000000138214: D613008D 25D2FF72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013821C: BF870091
	v_fmac_f32_e32 v127, v141, v115                            // 000000138220: 56FEE78D
	v_fma_f32 v114, -v114, v127, v116                          // 000000138224: D6130072 25D2FF72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013822C: BF870091
	v_div_fmas_f32 v114, v114, v115, v127                      // 000000138230: D6370072 05FEE772
	v_div_fixup_f32 v114, v114, v112, v113                     // 000000138238: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v123, v[128:129]   // 000000138240: D6FF7C70 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013824C: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 000000138250: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 000000138258: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 000000138264: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013826C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000138270: BE882005
	s_cbranch_execz 64761                                      // 000000138274: BFA5FCF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e5c>
	v_mad_i64_i32 v[112:113], null, 0x6000, v124, v[130:131]   // 000000138278: D6FF7C70 060AF8FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 000000138284: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 00000013828C: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 000000138290: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138294: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 000000138298: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 0000001382A0: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000001382AC: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001382B0: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 0000001382B4: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 0000001382B8: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 0000001382C0: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001382C8: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000001382CC: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000001382D0: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000001382D4: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001382D8: BF870095
	.long 0xd71c0071                                           // 0000001382DC: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000001382E0: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000001382E4: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 0000001382E8: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001382F0: BF870092
	v_cndmask_b32_e32 v112, 0x7f800000, v113, vcc_lo           // 0000001382F4: 02E0E2FF 7F800000
	v_dual_mul_f32 v113, v135, v117 :: v_dual_add_f32 v112, 1.0, v112// 0000001382FC: C8C8EB87 7170E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138304: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 000000138308: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 000000138310: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138314: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 000000138318: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 000000138320: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 000000138324: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013832C: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 000000138330: 10EAE774
	v_fma_f32 v127, -v114, v117, v116                          // 000000138334: D613007F 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013833C: BF870091
	v_fmac_f32_e32 v117, v127, v115                            // 000000138340: 56EAE77F
	v_fma_f32 v114, -v114, v117, v116                          // 000000138344: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013834C: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 000000138350: D6370072 05D6E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 000000138358: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v124, v[128:129]   // 000000138360: D6FF7C70 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013836C: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 000000138370: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 000000138378: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 000000138384: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013838C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000138390: BE882006
	s_cbranch_execz 64692                                      // 000000138394: BFA5FCB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e68>
	v_mad_i64_i32 v[112:113], null, 0x6000, v125, v[130:131]   // 000000138398: D6FF7C70 060AFAFF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 0000001383A4: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 0000001383AC: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 0000001383B0: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001383B4: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 0000001383B8: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 0000001383C0: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000001383CC: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001383D0: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 0000001383D4: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 0000001383D8: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 0000001383E0: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001383E8: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000001383EC: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000001383F0: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000001383F4: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001383F8: BF870095
	.long 0xd71c0071                                           // 0000001383FC: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 000000138400: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 000000138404: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 000000138408: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138410: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v132, v118// 000000138414: CA46E2FF 7070ED84 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 000000138420: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138424: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 000000138428: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 000000138430: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138434: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 000000138438: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 000000138440: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 000000138444: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013844C: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 000000138450: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 000000138454: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013845C: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 000000138460: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 000000138464: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013846C: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 000000138470: D6370072 05D6E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 000000138478: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v125, v[128:129]   // 000000138480: D6FF7C70 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013848C: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 000000138490: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 000000138498: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 0000001384A4: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001384AC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001384B0: BE882007
	s_cbranch_execz 64623                                      // 0000001384B4: BFA5FC6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e74>
	v_mad_i64_i32 v[112:113], null, 0x6000, v126, v[130:131]   // 0000001384B8: D6FF7C70 060AFCFF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 0000001384C4: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 0000001384CC: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 0000001384D0: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001384D4: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 0000001384D8: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 0000001384E0: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000001384EC: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001384F0: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 0000001384F4: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 0000001384F8: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 000000138500: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000138508: BF870121
	v_add_f32_e32 v113, v113, v114                             // 00000013850C: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 000000138510: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 000000138514: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138518: BF870095
	.long 0xd71c0071                                           // 00000013851C: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 000000138520: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 000000138524: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 000000138528: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138530: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v133, v119// 000000138534: CA46E2FF 7070EF85 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 000000138540: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138544: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 000000138548: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 000000138550: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138554: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 000000138558: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 000000138560: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 000000138564: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013856C: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 000000138570: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 000000138574: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013857C: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 000000138580: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 000000138584: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013858C: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 000000138590: D6370072 05D6E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 000000138598: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v126, v[128:129]   // 0000001385A0: D6FF7C70 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001385AC: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 0000001385B0: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 0000001385B8: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 0000001385C4: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001385CC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001385D0: BE882000
	s_cbranch_execz 64554                                      // 0000001385D4: BFA5FC2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e80>
	v_mad_i64_i32 v[112:113], null, 0x6000, v140, v[130:131]   // 0000001385D8: D6FF7C70 060B18FF 00006000
	v_mul_f32_e32 v104, v138, v104                             // 0000001385E4: 10D0D18A
	global_load_u16 v112, v[112:113], off offset:576           // 0000001385E8: DC4A0240 707C0070
	s_waitcnt vmcnt(0)                                         // 0000001385F0: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 0000001385F4: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001385F8: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 0000001385FC: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 000000138604: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 000000138610: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000138614: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 000000138618: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 00000013861C: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 000000138624: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013862C: BF870121
	v_add_f32_e32 v113, v113, v114                             // 000000138630: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 000000138634: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 000000138638: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013863C: BF870095
	.long 0xd71c0071                                           // 000000138640: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 000000138644: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 000000138648: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 00000013864C: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138654: BF870092
	v_cndmask_b32_e32 v112, 0x7f800000, v113, vcc_lo           // 000000138658: 02E0E2FF 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 000000138660: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138664: BF870091
	v_div_scale_f32 v113, null, v112, v112, v104               // 000000138668: D6FC7C71 05A2E170
	v_rcp_f32_e32 v114, v113                                   // 000000138670: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138674: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 000000138678: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 000000138680: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v104, v112, v104             // 000000138684: D6FC6A73 05A2E168
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013868C: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 000000138690: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 000000138694: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013869C: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 0000001386A0: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 0000001386A4: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001386AC: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 0000001386B0: D6370071 05D2E571
	v_div_fixup_f32 v104, v113, v112, v104                     // 0000001386B8: D6270068 05A2E171
	v_mad_i64_i32 v[112:113], null, 0x3000, v140, v[128:129]   // 0000001386C0: D6FF7C70 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001386CC: BF870092
	v_bfe_u32 v114, v104, 16, 1                                // 0000001386D0: D6100072 02052168
	v_add3_u32 v104, v104, v114, 0x7fff                        // 0000001386D8: D6550068 03FEE568 00007FFF
	global_store_d16_hi_b16 v[112:113], v104, off offset:64    // 0000001386E4: DC960040 007C6870
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001386EC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001386F0: BE882001
	s_cbranch_execz 64485                                      // 0000001386F4: BFA5FBE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e8c>
	v_mad_i64_i32 v[112:113], null, 0x6000, v120, v[130:131]   // 0000001386F8: D6FF7C70 060AF0FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 000000138704: 10D2D38B
	global_load_u16 v104, v[112:113], off offset:576           // 000000138708: DC4A0240 687C0070
	s_waitcnt vmcnt(0)                                         // 000000138710: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 000000138714: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000138718: BF870121
	v_mul_f32_e32 v112, 0xbfb8aa3b, v104                       // 00000013871C: 10E0D0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 000000138724: 7C3CD0FF 42CE8ED0
	v_fma_f32 v113, 0xbfb8aa3b, v104, -v112                    // 00000013872C: D6130071 85C2D0FF BFB8AA3B
	v_rndne_f32_e32 v114, v112                                 // 000000138738: 7EE44770
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013873C: BF870112
	v_fmamk_f32 v113, v104, 0xb2a5705f, v113                   // 000000138740: 58E2E368 B2A5705F
	v_sub_f32_e32 v112, v112, v114                             // 000000138748: 08E0E570
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013874C: BF870121
	v_add_f32_e32 v112, v112, v113                             // 000000138750: 06E0E370
	v_cvt_i32_f32_e32 v113, v114                               // 000000138754: 7EE21172
	v_exp_f32_e32 v112, v112                                   // 000000138758: 7EE04B70
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013875C: BF870095
	.long 0xd71c0070                                           // 000000138760: D71C0070
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                   // 000000138764: 0202E370
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 000000138768: 02E0E080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 00000013876C: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138774: BF870092
	v_cndmask_b32_e32 v104, 0x7f800000, v112, vcc_lo           // 000000138778: 02D0E0FF 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 000000138780: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138784: BF870091
	v_div_scale_f32 v112, null, v104, v104, v105               // 000000138788: D6FC7C70 05A6D168
	v_rcp_f32_e32 v113, v112                                   // 000000138790: 7EE25570
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138794: BF870095
	v_fma_f32 v114, -v112, v113, 1.0                           // 000000138798: D6130072 23CAE370
	v_fmac_f32_e32 v113, v114, v113                            // 0000001387A0: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v105, v104, v105             // 0000001387A4: D6FC6A72 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001387AC: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 0000001387B0: 10E6E372
	v_fma_f32 v116, -v112, v115, v114                          // 0000001387B4: D6130074 25CAE770
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001387BC: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 0000001387C0: 56E6E374
	v_fma_f32 v112, -v112, v115, v114                          // 0000001387C4: D6130070 25CAE770
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001387CC: BF870091
	v_div_fmas_f32 v112, v112, v113, v115                      // 0000001387D0: D6370070 05CEE370
	v_div_fixup_f32 v112, v112, v104, v105                     // 0000001387D8: D6270070 05A6D170
	v_mad_i64_i32 v[104:105], null, 0x3000, v120, v[128:129]   // 0000001387E0: D6FF7C68 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001387EC: BF870092
	v_bfe_u32 v113, v112, 16, 1                                // 0000001387F0: D6100071 02052170
	v_add3_u32 v112, v112, v113, 0x7fff                        // 0000001387F8: D6550070 03FEE370 00007FFF
	global_store_d16_hi_b16 v[104:105], v112, off offset:64    // 000000138804: DC960040 007C7068
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013880C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000138810: BE882002
	s_cbranch_execz 64416                                      // 000000138814: BFA5FBA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e98>
	v_mad_i64_i32 v[104:105], null, 0x6000, v121, v[130:131]   // 000000138818: D6FF7C68 060AF2FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 000000138824: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 00000013882C: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 000000138830: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138834: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 000000138838: 10D2D0FF BFB8AA3B
	v_fma_f32 v112, 0xbfb8aa3b, v104, -v105                    // 000000138840: D6130070 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v113, v105                                 // 00000013884C: 7EE24769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000138850: BF870221
	v_sub_f32_e32 v105, v105, v113                             // 000000138854: 08D2E369
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 000000138858: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v112, v104, 0xb2a5705f, v112                   // 000000138860: 58E0E168 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000138868: BF870121
	v_add_f32_e32 v105, v105, v112                             // 00000013886C: 06D2E169
	v_cvt_i32_f32_e32 v112, v113                               // 000000138870: 7EE01171
	v_exp_f32_e32 v105, v105                                   // 000000138874: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138878: BF870095
	.long 0xd71c0069                                           // 00000013887C: D71C0069
	v_cndmask_b32_e32 v1, v105, v112, vcc_lo                   // 000000138880: 0202E169
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000138884: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 000000138888: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138890: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v136, v106// 000000138894: CA46D2FF 6868D588 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 0000001388A0: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001388A4: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 0000001388A8: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v112, v106                                   // 0000001388B0: 7EE0556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001388B4: BF870095
	v_fma_f32 v113, -v106, v112, 1.0                           // 0000001388B8: D6130071 23CAE16A
	v_fmac_f32_e32 v112, v113, v112                            // 0000001388C0: 56E0E171
	v_div_scale_f32 v113, vcc_lo, v105, v104, v105             // 0000001388C4: D6FC6A71 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001388CC: BF870091
	v_mul_f32_e32 v114, v113, v112                             // 0000001388D0: 10E4E171
	v_fma_f32 v115, -v106, v114, v113                          // 0000001388D4: D6130073 25C6E56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001388DC: BF870091
	v_fmac_f32_e32 v114, v115, v112                            // 0000001388E0: 56E4E173
	v_fma_f32 v106, -v106, v114, v113                          // 0000001388E4: D613006A 25C6E56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001388EC: BF870091
	v_div_fmas_f32 v106, v106, v112, v114                      // 0000001388F0: D637006A 05CAE16A
	v_div_fixup_f32 v106, v106, v104, v105                     // 0000001388F8: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v121, v[128:129]   // 000000138900: D6FF7C68 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013890C: BF870092
	v_bfe_u32 v112, v106, 16, 1                                // 000000138910: D6100070 0205216A
	v_add3_u32 v106, v106, v112, 0x7fff                        // 000000138918: D655006A 03FEE16A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 000000138924: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013892C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000138930: BE882003
	s_cbranch_execz 64347                                      // 000000138934: BFA5FB5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ea4>
	v_mad_i64_i32 v[104:105], null, 0x6000, v122, v[130:131]   // 000000138938: D6FF7C68 060AF4FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 000000138944: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 00000013894C: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 000000138950: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138954: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 000000138958: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 000000138960: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v112, v105                                 // 00000013896C: 7EE04769
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138970: BF870091
	v_dual_fmamk_f32 v106, v104, 0xb2a5705f, v106 :: v_dual_sub_f32 v105, v105, v112// 000000138974: C88AD568 6A68E169 B2A5705F
	v_add_f32_e32 v105, v105, v106                             // 000000138980: 06D2D569
	v_cvt_i32_f32_e32 v106, v112                               // 000000138984: 7ED41170
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 000000138988: 7C3CD0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000138990: BF870293
	v_exp_f32_e32 v105, v105                                   // 000000138994: 7ED24B69
	.long 0xd71c0069                                           // 000000138998: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 00000013899C: 0202D569
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001389A0: BF870121
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000001389A4: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 0000001389A8: 7C36D0FF C2B17218
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v137, v107// 0000001389B0: CA46D2FF 6868D789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001389BC: BF870091
	v_add_f32_e32 v104, 1.0, v104                              // 0000001389C0: 06D0D0F2
	v_div_scale_f32 v106, null, v104, v104, v105               // 0000001389C4: D6FC7C6A 05A6D168
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001389CC: BF870291
	v_rcp_f32_e32 v107, v106                                   // 0000001389D0: 7ED6556A
	v_fma_f32 v112, -v106, v107, 1.0                           // 0000001389D4: D6130070 23CAD76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001389DC: BF8700A1
	v_fmac_f32_e32 v107, v112, v107                            // 0000001389E0: 56D6D770
	v_div_scale_f32 v112, vcc_lo, v105, v104, v105             // 0000001389E4: D6FC6A70 05A6D169
	v_mul_f32_e32 v113, v112, v107                             // 0000001389EC: 10E2D770
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001389F0: BF870091
	v_fma_f32 v114, -v106, v113, v112                          // 0000001389F4: D6130072 25C2E36A
	v_fmac_f32_e32 v113, v114, v107                            // 0000001389FC: 56E2D772
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138A00: BF870091
	v_fma_f32 v106, -v106, v113, v112                          // 000000138A04: D613006A 25C2E36A
	v_div_fmas_f32 v106, v106, v107, v113                      // 000000138A0C: D637006A 05C6D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000138A14: BF870121
	v_div_fixup_f32 v106, v106, v104, v105                     // 000000138A18: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v122, v[128:129]   // 000000138A20: D6FF7C68 0602F4FF 00003000
	v_bfe_u32 v107, v106, 16, 1                                // 000000138A2C: D610006B 0205216A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000138A34: BF870001
	v_add3_u32 v106, v106, v107, 0x7fff                        // 000000138A38: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 000000138A44: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 000000138A4C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000138A50: BE882004
	s_cbranch_execz 64278                                      // 000000138A54: BFA5FB16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eb0>
	v_mad_i64_i32 v[104:105], null, 0x6000, v123, v[130:131]   // 000000138A58: D6FF7C68 060AF6FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 000000138A64: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 000000138A6C: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 000000138A70: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138A74: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 000000138A78: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 000000138A80: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 000000138A8C: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000138A90: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 000000138A94: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 000000138A98: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 000000138AA0: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000138AA8: BF870121
	v_add_f32_e32 v105, v105, v106                             // 000000138AAC: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 000000138AB0: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 000000138AB4: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138AB8: BF870095
	.long 0xd71c0069                                           // 000000138ABC: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 000000138AC0: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000138AC4: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 000000138AC8: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138AD0: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v134, v108// 000000138AD4: CA46D2FF 6868D986 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 000000138AE0: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138AE4: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 000000138AE8: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 000000138AF0: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138AF4: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 000000138AF8: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 000000138B00: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 000000138B04: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138B0C: BF870091
	v_mul_f32_e32 v112, v108, v107                             // 000000138B10: 10E0D76C
	v_fma_f32 v113, -v106, v112, v108                          // 000000138B14: D6130071 25B2E16A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138B1C: BF870091
	v_fmac_f32_e32 v112, v113, v107                            // 000000138B20: 56E0D771
	v_fma_f32 v106, -v106, v112, v108                          // 000000138B24: D613006A 25B2E16A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138B2C: BF870091
	v_div_fmas_f32 v106, v106, v107, v112                      // 000000138B30: D637006A 05C2D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 000000138B38: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v123, v[128:129]   // 000000138B40: D6FF7C68 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138B4C: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 000000138B50: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 000000138B58: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 000000138B64: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 000000138B6C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000138B70: BE882005
	s_cbranch_execz 64209                                      // 000000138B74: BFA5FAD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ebc>
	v_mad_i64_i32 v[104:105], null, 0x6000, v124, v[130:131]   // 000000138B78: D6FF7C68 060AF8FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 000000138B84: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 000000138B8C: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 000000138B90: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138B94: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 000000138B98: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 000000138BA0: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 000000138BAC: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000138BB0: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 000000138BB4: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 000000138BB8: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 000000138BC0: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000138BC8: BF870121
	v_add_f32_e32 v105, v105, v106                             // 000000138BCC: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 000000138BD0: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 000000138BD4: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138BD8: BF870095
	.long 0xd71c0069                                           // 000000138BDC: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 000000138BE0: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000138BE4: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 000000138BE8: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138BF0: BF870092
	v_cndmask_b32_e32 v104, 0x7f800000, v105, vcc_lo           // 000000138BF4: 02D0D2FF 7F800000
	v_dual_mul_f32 v105, v135, v109 :: v_dual_add_f32 v104, 1.0, v104// 000000138BFC: C8C8DB87 6968D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138C04: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 000000138C08: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 000000138C10: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138C14: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 000000138C18: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 000000138C20: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 000000138C24: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138C2C: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 000000138C30: 10DAD76C
	v_fma_f32 v112, -v106, v109, v108                          // 000000138C34: D6130070 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138C3C: BF870091
	v_fmac_f32_e32 v109, v112, v107                            // 000000138C40: 56DAD770
	v_fma_f32 v106, -v106, v109, v108                          // 000000138C44: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138C4C: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 000000138C50: D637006A 05B6D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 000000138C58: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v124, v[128:129]   // 000000138C60: D6FF7C68 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138C6C: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 000000138C70: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 000000138C78: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 000000138C84: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 000000138C8C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000138C90: BE882006
	s_cbranch_execz 64140                                      // 000000138C94: BFA5FA8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ec8>
	v_mad_i64_i32 v[104:105], null, 0x6000, v125, v[130:131]   // 000000138C98: D6FF7C68 060AFAFF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 000000138CA4: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 000000138CAC: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 000000138CB0: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138CB4: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 000000138CB8: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 000000138CC0: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 000000138CCC: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000138CD0: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 000000138CD4: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 000000138CD8: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 000000138CE0: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000138CE8: BF870121
	v_add_f32_e32 v105, v105, v106                             // 000000138CEC: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 000000138CF0: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 000000138CF4: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138CF8: BF870095
	.long 0xd71c0069                                           // 000000138CFC: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 000000138D00: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000138D04: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 000000138D08: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138D10: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v132, v110// 000000138D14: CA46D2FF 6868DD84 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 000000138D20: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138D24: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 000000138D28: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 000000138D30: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138D34: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 000000138D38: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 000000138D40: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 000000138D44: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138D4C: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 000000138D50: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 000000138D54: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138D5C: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 000000138D60: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 000000138D64: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138D6C: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 000000138D70: D637006A 05B6D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 000000138D78: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v125, v[128:129]   // 000000138D80: D6FF7C68 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138D8C: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 000000138D90: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 000000138D98: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 000000138DA4: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 000000138DAC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000138DB0: BE882007
	s_cbranch_execz 64071                                      // 000000138DB4: BFA5FA47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ed4>
	v_mad_i64_i32 v[104:105], null, 0x6000, v126, v[130:131]   // 000000138DB8: D6FF7C68 060AFCFF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 000000138DC4: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 000000138DCC: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 000000138DD0: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138DD4: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 000000138DD8: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 000000138DE0: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 000000138DEC: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000138DF0: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 000000138DF4: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 000000138DF8: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 000000138E00: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000138E08: BF870121
	v_add_f32_e32 v105, v105, v106                             // 000000138E0C: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 000000138E10: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 000000138E14: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138E18: BF870095
	.long 0xd71c0069                                           // 000000138E1C: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 000000138E20: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000138E24: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 000000138E28: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138E30: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v133, v111// 000000138E34: CA46D2FF 6868DF85 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 000000138E40: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138E44: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 000000138E48: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 000000138E50: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138E54: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 000000138E58: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 000000138E60: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 000000138E64: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138E6C: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 000000138E70: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 000000138E74: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138E7C: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 000000138E80: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 000000138E84: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138E8C: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 000000138E90: D637006A 05B6D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 000000138E98: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v126, v[128:129]   // 000000138EA0: D6FF7C68 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138EAC: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 000000138EB0: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 000000138EB8: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 000000138EC4: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 000000138ECC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000138ED0: BE882000
	s_cbranch_execz 64002                                      // 000000138ED4: BFA5FA02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ee0>
	v_mad_i64_i32 v[104:105], null, 0x6000, v140, v[130:131]   // 000000138ED8: D6FF7C68 060B18FF 00006000
	v_mul_f32_e32 v96, v138, v96                               // 000000138EE4: 10C0C18A
	global_load_u16 v104, v[104:105], off offset:608           // 000000138EE8: DC4A0260 687C0068
	s_waitcnt vmcnt(0)                                         // 000000138EF0: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 000000138EF4: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138EF8: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 000000138EFC: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 000000138F04: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 000000138F10: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000138F14: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 000000138F18: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 000000138F1C: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 000000138F24: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000138F2C: BF870121
	v_add_f32_e32 v105, v105, v106                             // 000000138F30: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 000000138F34: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 000000138F38: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138F3C: BF870095
	.long 0xd71c0069                                           // 000000138F40: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 000000138F44: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000138F48: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 000000138F4C: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138F54: BF870092
	v_cndmask_b32_e32 v104, 0x7f800000, v105, vcc_lo           // 000000138F58: 02D0D2FF 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 000000138F60: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138F64: BF870091
	v_div_scale_f32 v105, null, v104, v104, v96                // 000000138F68: D6FC7C69 0582D168
	v_rcp_f32_e32 v106, v105                                   // 000000138F70: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138F74: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 000000138F78: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 000000138F80: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v96, v104, v96               // 000000138F84: D6FC6A6B 0582D160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138F8C: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 000000138F90: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 000000138F94: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138F9C: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 000000138FA0: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 000000138FA4: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138FAC: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 000000138FB0: D6370069 05B2D569
	v_div_fixup_f32 v96, v105, v104, v96                       // 000000138FB8: D6270060 0582D169
	v_mad_i64_i32 v[104:105], null, 0x3000, v140, v[128:129]   // 000000138FC0: D6FF7C68 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000138FCC: BF870092
	v_bfe_u32 v106, v96, 16, 1                                 // 000000138FD0: D610006A 02052160
	v_add3_u32 v96, v96, v106, 0x7fff                          // 000000138FD8: D6550060 03FED560 00007FFF
	global_store_d16_hi_b16 v[104:105], v96, off offset:96     // 000000138FE4: DC960060 007C6068
	s_or_b32 exec_lo, exec_lo, s8                              // 000000138FEC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000138FF0: BE882001
	s_cbranch_execz 63933                                      // 000000138FF4: BFA5F9BD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eec>
	v_mad_i64_i32 v[104:105], null, 0x6000, v120, v[130:131]   // 000000138FF8: D6FF7C68 060AF0FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 000000139004: 10C2C38B
	global_load_u16 v96, v[104:105], off offset:608            // 000000139008: DC4A0260 607C0068
	s_waitcnt vmcnt(0)                                         // 000000139010: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000139014: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139018: BF870121
	v_mul_f32_e32 v104, 0xbfb8aa3b, v96                        // 00000013901C: 10D0C0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 000000139024: 7C3CC0FF 42CE8ED0
	v_fma_f32 v105, 0xbfb8aa3b, v96, -v104                     // 00000013902C: D6130069 85A2C0FF BFB8AA3B
	v_rndne_f32_e32 v106, v104                                 // 000000139038: 7ED44768
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013903C: BF870112
	v_fmamk_f32 v105, v96, 0xb2a5705f, v105                    // 000000139040: 58D2D360 B2A5705F
	v_sub_f32_e32 v104, v104, v106                             // 000000139048: 08D0D568
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013904C: BF870121
	v_add_f32_e32 v104, v104, v105                             // 000000139050: 06D0D368
	v_cvt_i32_f32_e32 v105, v106                               // 000000139054: 7ED2116A
	v_exp_f32_e32 v104, v104                                   // 000000139058: 7ED04B68
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013905C: BF870095
	.long 0xd71c0068                                           // 000000139060: D71C0068
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                   // 000000139064: 0202D368
	v_cndmask_b32_e32 v104, 0, v104, vcc_lo                    // 000000139068: 02D0D080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 00000013906C: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139074: BF870092
	v_cndmask_b32_e32 v96, 0x7f800000, v104, vcc_lo            // 000000139078: 02C0D0FF 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 000000139080: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139084: BF870091
	v_div_scale_f32 v104, null, v96, v96, v97                  // 000000139088: D6FC7C68 0586C160
	v_rcp_f32_e32 v105, v104                                   // 000000139090: 7ED25568
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139094: BF870095
	v_fma_f32 v106, -v104, v105, 1.0                           // 000000139098: D613006A 23CAD368
	v_fmac_f32_e32 v105, v106, v105                            // 0000001390A0: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v97, v96, v97                // 0000001390A4: D6FC6A6A 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001390AC: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 0000001390B0: 10D6D36A
	v_fma_f32 v108, -v104, v107, v106                          // 0000001390B4: D613006C 25AAD768
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001390BC: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 0000001390C0: 56D6D36C
	v_fma_f32 v104, -v104, v107, v106                          // 0000001390C4: D6130068 25AAD768
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001390CC: BF870091
	v_div_fmas_f32 v104, v104, v105, v107                      // 0000001390D0: D6370068 05AED368
	v_div_fixup_f32 v104, v104, v96, v97                       // 0000001390D8: D6270068 0586C168
	v_mad_i64_i32 v[96:97], null, 0x3000, v120, v[128:129]     // 0000001390E0: D6FF7C60 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001390EC: BF870092
	v_bfe_u32 v105, v104, 16, 1                                // 0000001390F0: D6100069 02052168
	v_add3_u32 v104, v104, v105, 0x7fff                        // 0000001390F8: D6550068 03FED368 00007FFF
	global_store_d16_hi_b16 v[96:97], v104, off offset:96      // 000000139104: DC960060 007C6860
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013910C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000139110: BE882002
	s_cbranch_execz 63864                                      // 000000139114: BFA5F978 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ef8>
	v_mad_i64_i32 v[96:97], null, 0x6000, v121, v[130:131]     // 000000139118: D6FF7C60 060AF2FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 000000139124: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 00000013912C: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000139130: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139134: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 000000139138: 10C2C0FF BFB8AA3B
	v_fma_f32 v104, 0xbfb8aa3b, v96, -v97                      // 000000139140: D6130068 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v105, v97                                  // 00000013914C: 7ED24761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000139150: BF870221
	v_sub_f32_e32 v97, v97, v105                               // 000000139154: 08C2D361
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 000000139158: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v104, v96, 0xb2a5705f, v104                    // 000000139160: 58D0D160 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139168: BF870121
	v_add_f32_e32 v97, v97, v104                               // 00000013916C: 06C2D161
	v_cvt_i32_f32_e32 v104, v105                               // 000000139170: 7ED01169
	v_exp_f32_e32 v97, v97                                     // 000000139174: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139178: BF870095
	.long 0xd71c0061                                           // 00000013917C: D71C0061
	v_cndmask_b32_e32 v1, v97, v104, vcc_lo                    // 000000139180: 0202D161
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 000000139184: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 000000139188: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139190: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v136, v98// 000000139194: CA46C2FF 6060C588 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 0000001391A0: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001391A4: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 0000001391A8: D6FC7C62 0586C160
	v_rcp_f32_e32 v104, v98                                    // 0000001391B0: 7ED05562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001391B4: BF870095
	v_fma_f32 v105, -v98, v104, 1.0                            // 0000001391B8: D6130069 23CAD162
	v_fmac_f32_e32 v104, v105, v104                            // 0000001391C0: 56D0D169
	v_div_scale_f32 v105, vcc_lo, v97, v96, v97                // 0000001391C4: D6FC6A69 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001391CC: BF870091
	v_mul_f32_e32 v106, v105, v104                             // 0000001391D0: 10D4D169
	v_fma_f32 v107, -v98, v106, v105                           // 0000001391D4: D613006B 25A6D562
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001391DC: BF870091
	v_fmac_f32_e32 v106, v107, v104                            // 0000001391E0: 56D4D16B
	v_fma_f32 v98, -v98, v106, v105                            // 0000001391E4: D6130062 25A6D562
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001391EC: BF870091
	v_div_fmas_f32 v98, v98, v104, v106                        // 0000001391F0: D6370062 05AAD162
	v_div_fixup_f32 v98, v98, v96, v97                         // 0000001391F8: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v121, v[128:129]     // 000000139200: D6FF7C60 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013920C: BF870092
	v_bfe_u32 v104, v98, 16, 1                                 // 000000139210: D6100068 02052162
	v_add3_u32 v98, v98, v104, 0x7fff                          // 000000139218: D6550062 03FED162 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 000000139224: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013922C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000139230: BE882003
	s_cbranch_execz 63795                                      // 000000139234: BFA5F933 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f04>
	v_mad_i64_i32 v[96:97], null, 0x6000, v122, v[130:131]     // 000000139238: D6FF7C60 060AF4FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 000000139244: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 00000013924C: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000139250: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139254: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 000000139258: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 000000139260: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v104, v97                                  // 00000013926C: 7ED04761
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139270: BF870091
	v_dual_fmamk_f32 v98, v96, 0xb2a5705f, v98 :: v_dual_sub_f32 v97, v97, v104// 000000139274: C88AC560 6260D161 B2A5705F
	v_add_f32_e32 v97, v97, v98                                // 000000139280: 06C2C561
	v_cvt_i32_f32_e32 v98, v104                                // 000000139284: 7EC41168
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 000000139288: 7C3CC0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000139290: BF870293
	v_exp_f32_e32 v97, v97                                     // 000000139294: 7EC24B61
	.long 0xd71c0061                                           // 000000139298: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 00000013929C: 0202C561
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001392A0: BF870121
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000001392A4: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 0000001392A8: 7C36C0FF C2B17218
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v137, v99// 0000001392B0: CA46C2FF 6060C789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001392BC: BF870091
	v_add_f32_e32 v96, 1.0, v96                                // 0000001392C0: 06C0C0F2
	v_div_scale_f32 v98, null, v96, v96, v97                   // 0000001392C4: D6FC7C62 0586C160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001392CC: BF870291
	v_rcp_f32_e32 v99, v98                                     // 0000001392D0: 7EC65562
	v_fma_f32 v104, -v98, v99, 1.0                             // 0000001392D4: D6130068 23CAC762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001392DC: BF8700A1
	v_fmac_f32_e32 v99, v104, v99                              // 0000001392E0: 56C6C768
	v_div_scale_f32 v104, vcc_lo, v97, v96, v97                // 0000001392E4: D6FC6A68 0586C161
	v_mul_f32_e32 v105, v104, v99                              // 0000001392EC: 10D2C768
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001392F0: BF870091
	v_fma_f32 v106, -v98, v105, v104                           // 0000001392F4: D613006A 25A2D362
	v_fmac_f32_e32 v105, v106, v99                             // 0000001392FC: 56D2C76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139300: BF870091
	v_fma_f32 v98, -v98, v105, v104                            // 000000139304: D6130062 25A2D362
	v_div_fmas_f32 v98, v98, v99, v105                         // 00000013930C: D6370062 05A6C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139314: BF870121
	v_div_fixup_f32 v98, v98, v96, v97                         // 000000139318: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v122, v[128:129]     // 000000139320: D6FF7C60 0602F4FF 00003000
	v_bfe_u32 v99, v98, 16, 1                                  // 00000013932C: D6100063 02052162
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139334: BF870001
	v_add3_u32 v98, v98, v99, 0x7fff                           // 000000139338: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 000000139344: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013934C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000139350: BE882004
	s_cbranch_execz 63726                                      // 000000139354: BFA5F8EE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f10>
	v_mad_i64_i32 v[96:97], null, 0x6000, v123, v[130:131]     // 000000139358: D6FF7C60 060AF6FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 000000139364: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 00000013936C: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000139370: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139374: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 000000139378: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 000000139380: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 00000013938C: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000139390: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 000000139394: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 000000139398: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 0000001393A0: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001393A8: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000001393AC: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000001393B0: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000001393B4: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001393B8: BF870095
	.long 0xd71c0061                                           // 0000001393BC: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000001393C0: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000001393C4: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 0000001393C8: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001393D0: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v134, v100// 0000001393D4: CA46C2FF 6060C986 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 0000001393E0: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001393E4: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 0000001393E8: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 0000001393F0: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001393F4: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000001393F8: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 000000139400: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 000000139404: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013940C: BF870091
	v_mul_f32_e32 v104, v100, v99                              // 000000139410: 10D0C764
	v_fma_f32 v105, -v98, v104, v100                           // 000000139414: D6130069 2592D162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013941C: BF870091
	v_fmac_f32_e32 v104, v105, v99                             // 000000139420: 56D0C769
	v_fma_f32 v98, -v98, v104, v100                            // 000000139424: D6130062 2592D162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013942C: BF870091
	v_div_fmas_f32 v98, v98, v99, v104                         // 000000139430: D6370062 05A2C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 000000139438: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v123, v[128:129]     // 000000139440: D6FF7C60 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013944C: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 000000139450: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 000000139458: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 000000139464: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013946C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000139470: BE882005
	s_cbranch_execz 63657                                      // 000000139474: BFA5F8A9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f1c>
	v_mad_i64_i32 v[96:97], null, 0x6000, v124, v[130:131]     // 000000139478: D6FF7C60 060AF8FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 000000139484: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 00000013948C: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000139490: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139494: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 000000139498: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 0000001394A0: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000001394AC: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001394B0: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 0000001394B4: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000001394B8: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 0000001394C0: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001394C8: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000001394CC: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000001394D0: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000001394D4: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001394D8: BF870095
	.long 0xd71c0061                                           // 0000001394DC: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000001394E0: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000001394E4: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 0000001394E8: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001394F0: BF870092
	v_cndmask_b32_e32 v96, 0x7f800000, v97, vcc_lo             // 0000001394F4: 02C0C2FF 7F800000
	v_dual_mul_f32 v97, v135, v101 :: v_dual_add_f32 v96, 1.0, v96// 0000001394FC: C8C8CB87 6160C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139504: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 000000139508: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 000000139510: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139514: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 000000139518: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 000000139520: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 000000139524: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013952C: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 000000139530: 10CAC764
	v_fma_f32 v104, -v98, v101, v100                           // 000000139534: D6130068 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013953C: BF870091
	v_fmac_f32_e32 v101, v104, v99                             // 000000139540: 56CAC768
	v_fma_f32 v98, -v98, v101, v100                            // 000000139544: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013954C: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 000000139550: D6370062 0596C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 000000139558: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v124, v[128:129]     // 000000139560: D6FF7C60 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013956C: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 000000139570: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 000000139578: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 000000139584: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013958C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000139590: BE882006
	s_cbranch_execz 63588                                      // 000000139594: BFA5F864 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f28>
	v_mad_i64_i32 v[96:97], null, 0x6000, v125, v[130:131]     // 000000139598: D6FF7C60 060AFAFF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 0000001395A4: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 0000001395AC: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000001395B0: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001395B4: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 0000001395B8: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 0000001395C0: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000001395CC: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001395D0: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 0000001395D4: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000001395D8: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 0000001395E0: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001395E8: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000001395EC: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000001395F0: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000001395F4: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001395F8: BF870095
	.long 0xd71c0061                                           // 0000001395FC: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 000000139600: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 000000139604: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 000000139608: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139610: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v132, v102// 000000139614: CA46C2FF 6060CD84 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 000000139620: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139624: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 000000139628: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 000000139630: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139634: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 000000139638: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 000000139640: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 000000139644: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013964C: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 000000139650: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 000000139654: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013965C: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 000000139660: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 000000139664: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013966C: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 000000139670: D6370062 0596C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 000000139678: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v125, v[128:129]     // 000000139680: D6FF7C60 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013968C: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 000000139690: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 000000139698: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 0000001396A4: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001396AC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001396B0: BE882007
	s_cbranch_execz 63519                                      // 0000001396B4: BFA5F81F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f34>
	v_mad_i64_i32 v[96:97], null, 0x6000, v126, v[130:131]     // 0000001396B8: D6FF7C60 060AFCFF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 0000001396C4: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 0000001396CC: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000001396D0: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001396D4: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 0000001396D8: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 0000001396E0: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000001396EC: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001396F0: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 0000001396F4: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000001396F8: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 000000139700: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139708: BF870121
	v_add_f32_e32 v97, v97, v98                                // 00000013970C: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 000000139710: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 000000139714: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139718: BF870095
	.long 0xd71c0061                                           // 00000013971C: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 000000139720: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 000000139724: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 000000139728: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139730: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v133, v103// 000000139734: CA46C2FF 6060CF85 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 000000139740: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139744: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 000000139748: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 000000139750: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139754: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 000000139758: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 000000139760: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 000000139764: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013976C: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 000000139770: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 000000139774: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013977C: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 000000139780: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 000000139784: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013978C: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 000000139790: D6370062 0596C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 000000139798: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v126, v[128:129]     // 0000001397A0: D6FF7C60 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001397AC: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 0000001397B0: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 0000001397B8: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 0000001397C4: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001397CC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001397D0: BE882000
	s_cbranch_execz 63450                                      // 0000001397D4: BFA5F7DA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f40>
	v_mad_i64_i32 v[96:97], null, 0x6000, v140, v[130:131]     // 0000001397D8: D6FF7C60 060B18FF 00006000
	v_mul_f32_e32 v88, v138, v88                               // 0000001397E4: 10B0B18A
	global_load_u16 v96, v[96:97], off offset:640              // 0000001397E8: DC4A0280 607C0060
	s_waitcnt vmcnt(0)                                         // 0000001397F0: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000001397F4: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001397F8: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 0000001397FC: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 000000139804: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 000000139810: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000139814: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 000000139818: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 00000013981C: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 000000139824: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013982C: BF870121
	v_add_f32_e32 v97, v97, v98                                // 000000139830: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 000000139834: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 000000139838: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013983C: BF870095
	.long 0xd71c0061                                           // 000000139840: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 000000139844: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 000000139848: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 00000013984C: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139854: BF870092
	v_cndmask_b32_e32 v96, 0x7f800000, v97, vcc_lo             // 000000139858: 02C0C2FF 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 000000139860: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139864: BF870091
	v_div_scale_f32 v97, null, v96, v96, v88                   // 000000139868: D6FC7C61 0562C160
	v_rcp_f32_e32 v98, v97                                     // 000000139870: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139874: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 000000139878: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 000000139880: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v88, v96, v88                 // 000000139884: D6FC6A63 0562C158
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013988C: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 000000139890: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 000000139894: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013989C: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 0000001398A0: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 0000001398A4: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001398AC: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 0000001398B0: D6370061 0592C561
	v_div_fixup_f32 v88, v97, v96, v88                         // 0000001398B8: D6270058 0562C161
	v_mad_i64_i32 v[96:97], null, 0x3000, v140, v[128:129]     // 0000001398C0: D6FF7C60 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001398CC: BF870092
	v_bfe_u32 v98, v88, 16, 1                                  // 0000001398D0: D6100062 02052158
	v_add3_u32 v88, v88, v98, 0x7fff                           // 0000001398D8: D6550058 03FEC558 00007FFF
	global_store_d16_hi_b16 v[96:97], v88, off offset:128      // 0000001398E4: DC960080 007C5860
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001398EC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001398F0: BE882001
	s_cbranch_execz 63381                                      // 0000001398F4: BFA5F795 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f4c>
	v_mad_i64_i32 v[96:97], null, 0x6000, v120, v[130:131]     // 0000001398F8: D6FF7C60 060AF0FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 000000139904: 10B2B38B
	global_load_u16 v88, v[96:97], off offset:640              // 000000139908: DC4A0280 587C0060
	s_waitcnt vmcnt(0)                                         // 000000139910: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000139914: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139918: BF870121
	v_mul_f32_e32 v96, 0xbfb8aa3b, v88                         // 00000013991C: 10C0B0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 000000139924: 7C3CB0FF 42CE8ED0
	v_fma_f32 v97, 0xbfb8aa3b, v88, -v96                       // 00000013992C: D6130061 8582B0FF BFB8AA3B
	v_rndne_f32_e32 v98, v96                                   // 000000139938: 7EC44760
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013993C: BF870112
	v_fmamk_f32 v97, v88, 0xb2a5705f, v97                      // 000000139940: 58C2C358 B2A5705F
	v_sub_f32_e32 v96, v96, v98                                // 000000139948: 08C0C560
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013994C: BF870121
	v_add_f32_e32 v96, v96, v97                                // 000000139950: 06C0C360
	v_cvt_i32_f32_e32 v97, v98                                 // 000000139954: 7EC21162
	v_exp_f32_e32 v96, v96                                     // 000000139958: 7EC04B60
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013995C: BF870095
	.long 0xd71c0060                                           // 000000139960: D71C0060
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                     // 000000139964: 0202C360
	v_cndmask_b32_e32 v96, 0, v96, vcc_lo                      // 000000139968: 02C0C080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 00000013996C: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139974: BF870092
	v_cndmask_b32_e32 v88, 0x7f800000, v96, vcc_lo             // 000000139978: 02B0C0FF 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 000000139980: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139984: BF870091
	v_div_scale_f32 v96, null, v88, v88, v89                   // 000000139988: D6FC7C60 0566B158
	v_rcp_f32_e32 v97, v96                                     // 000000139990: 7EC25560
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139994: BF870095
	v_fma_f32 v98, -v96, v97, 1.0                              // 000000139998: D6130062 23CAC360
	v_fmac_f32_e32 v97, v98, v97                               // 0000001399A0: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v89, v88, v89                 // 0000001399A4: D6FC6A62 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001399AC: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 0000001399B0: 10C6C362
	v_fma_f32 v100, -v96, v99, v98                             // 0000001399B4: D6130064 258AC760
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001399BC: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 0000001399C0: 56C6C364
	v_fma_f32 v96, -v96, v99, v98                              // 0000001399C4: D6130060 258AC760
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001399CC: BF870091
	v_div_fmas_f32 v96, v96, v97, v99                          // 0000001399D0: D6370060 058EC360
	v_div_fixup_f32 v96, v96, v88, v89                         // 0000001399D8: D6270060 0566B160
	v_mad_i64_i32 v[88:89], null, 0x3000, v120, v[128:129]     // 0000001399E0: D6FF7C58 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001399EC: BF870092
	v_bfe_u32 v97, v96, 16, 1                                  // 0000001399F0: D6100061 02052160
	v_add3_u32 v96, v96, v97, 0x7fff                           // 0000001399F8: D6550060 03FEC360 00007FFF
	global_store_d16_hi_b16 v[88:89], v96, off offset:128      // 000000139A04: DC960080 007C6058
	s_or_b32 exec_lo, exec_lo, s8                              // 000000139A0C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000139A10: BE882002
	s_cbranch_execz 63312                                      // 000000139A14: BFA5F750 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f58>
	v_mad_i64_i32 v[88:89], null, 0x6000, v121, v[130:131]     // 000000139A18: D6FF7C58 060AF2FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 000000139A24: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 000000139A2C: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000139A30: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139A34: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 000000139A38: 10B2B0FF BFB8AA3B
	v_fma_f32 v96, 0xbfb8aa3b, v88, -v89                       // 000000139A40: D6130060 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v97, v89                                   // 000000139A4C: 7EC24759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000139A50: BF870221
	v_sub_f32_e32 v89, v89, v97                                // 000000139A54: 08B2C359
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 000000139A58: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v96, v88, 0xb2a5705f, v96                      // 000000139A60: 58C0C158 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139A68: BF870121
	v_add_f32_e32 v89, v89, v96                                // 000000139A6C: 06B2C159
	v_cvt_i32_f32_e32 v96, v97                                 // 000000139A70: 7EC01161
	v_exp_f32_e32 v89, v89                                     // 000000139A74: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139A78: BF870095
	.long 0xd71c0059                                           // 000000139A7C: D71C0059
	v_cndmask_b32_e32 v1, v89, v96, vcc_lo                     // 000000139A80: 0202C159
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 000000139A84: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 000000139A88: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139A90: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v136, v90// 000000139A94: CA46B2FF 5858B588 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 000000139AA0: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139AA4: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 000000139AA8: D6FC7C5A 0566B158
	v_rcp_f32_e32 v96, v90                                     // 000000139AB0: 7EC0555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139AB4: BF870095
	v_fma_f32 v97, -v90, v96, 1.0                              // 000000139AB8: D6130061 23CAC15A
	v_fmac_f32_e32 v96, v97, v96                               // 000000139AC0: 56C0C161
	v_div_scale_f32 v97, vcc_lo, v89, v88, v89                 // 000000139AC4: D6FC6A61 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139ACC: BF870091
	v_mul_f32_e32 v98, v97, v96                                // 000000139AD0: 10C4C161
	v_fma_f32 v99, -v90, v98, v97                              // 000000139AD4: D6130063 2586C55A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139ADC: BF870091
	v_fmac_f32_e32 v98, v99, v96                               // 000000139AE0: 56C4C163
	v_fma_f32 v90, -v90, v98, v97                              // 000000139AE4: D613005A 2586C55A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139AEC: BF870091
	v_div_fmas_f32 v90, v90, v96, v98                          // 000000139AF0: D637005A 058AC15A
	v_div_fixup_f32 v90, v90, v88, v89                         // 000000139AF8: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v121, v[128:129]     // 000000139B00: D6FF7C58 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139B0C: BF870092
	v_bfe_u32 v96, v90, 16, 1                                  // 000000139B10: D6100060 0205215A
	v_add3_u32 v90, v90, v96, 0x7fff                           // 000000139B18: D655005A 03FEC15A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 000000139B24: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 000000139B2C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000139B30: BE882003
	s_cbranch_execz 63243                                      // 000000139B34: BFA5F70B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f64>
	v_mad_i64_i32 v[88:89], null, 0x6000, v122, v[130:131]     // 000000139B38: D6FF7C58 060AF4FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 000000139B44: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 000000139B4C: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000139B50: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139B54: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 000000139B58: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 000000139B60: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v96, v89                                   // 000000139B6C: 7EC04759
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139B70: BF870091
	v_dual_fmamk_f32 v90, v88, 0xb2a5705f, v90 :: v_dual_sub_f32 v89, v89, v96// 000000139B74: C88AB558 5A58C159 B2A5705F
	v_add_f32_e32 v89, v89, v90                                // 000000139B80: 06B2B559
	v_cvt_i32_f32_e32 v90, v96                                 // 000000139B84: 7EB41160
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 000000139B88: 7C3CB0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000139B90: BF870293
	v_exp_f32_e32 v89, v89                                     // 000000139B94: 7EB24B59
	.long 0xd71c0059                                           // 000000139B98: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 000000139B9C: 0202B559
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139BA0: BF870121
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 000000139BA4: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 000000139BA8: 7C36B0FF C2B17218
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v137, v91// 000000139BB0: CA46B2FF 5858B789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139BBC: BF870091
	v_add_f32_e32 v88, 1.0, v88                                // 000000139BC0: 06B0B0F2
	v_div_scale_f32 v90, null, v88, v88, v89                   // 000000139BC4: D6FC7C5A 0566B158
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000139BCC: BF870291
	v_rcp_f32_e32 v91, v90                                     // 000000139BD0: 7EB6555A
	v_fma_f32 v96, -v90, v91, 1.0                              // 000000139BD4: D6130060 23CAB75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000139BDC: BF8700A1
	v_fmac_f32_e32 v91, v96, v91                               // 000000139BE0: 56B6B760
	v_div_scale_f32 v96, vcc_lo, v89, v88, v89                 // 000000139BE4: D6FC6A60 0566B159
	v_mul_f32_e32 v97, v96, v91                                // 000000139BEC: 10C2B760
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139BF0: BF870091
	v_fma_f32 v98, -v90, v97, v96                              // 000000139BF4: D6130062 2582C35A
	v_fmac_f32_e32 v97, v98, v91                               // 000000139BFC: 56C2B762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139C00: BF870091
	v_fma_f32 v90, -v90, v97, v96                              // 000000139C04: D613005A 2582C35A
	v_div_fmas_f32 v90, v90, v91, v97                          // 000000139C0C: D637005A 0586B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139C14: BF870121
	v_div_fixup_f32 v90, v90, v88, v89                         // 000000139C18: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v122, v[128:129]     // 000000139C20: D6FF7C58 0602F4FF 00003000
	v_bfe_u32 v91, v90, 16, 1                                  // 000000139C2C: D610005B 0205215A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000139C34: BF870001
	v_add3_u32 v90, v90, v91, 0x7fff                           // 000000139C38: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 000000139C44: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 000000139C4C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000139C50: BE882004
	s_cbranch_execz 63174                                      // 000000139C54: BFA5F6C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f70>
	v_mad_i64_i32 v[88:89], null, 0x6000, v123, v[130:131]     // 000000139C58: D6FF7C58 060AF6FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 000000139C64: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 000000139C6C: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000139C70: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139C74: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 000000139C78: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 000000139C80: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 000000139C8C: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000139C90: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 000000139C94: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 000000139C98: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 000000139CA0: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139CA8: BF870121
	v_add_f32_e32 v89, v89, v90                                // 000000139CAC: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 000000139CB0: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 000000139CB4: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139CB8: BF870095
	.long 0xd71c0059                                           // 000000139CBC: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 000000139CC0: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 000000139CC4: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 000000139CC8: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139CD0: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v134, v92// 000000139CD4: CA46B2FF 5858B986 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 000000139CE0: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139CE4: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 000000139CE8: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 000000139CF0: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139CF4: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 000000139CF8: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 000000139D00: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 000000139D04: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139D0C: BF870091
	v_mul_f32_e32 v96, v92, v91                                // 000000139D10: 10C0B75C
	v_fma_f32 v97, -v90, v96, v92                              // 000000139D14: D6130061 2572C15A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139D1C: BF870091
	v_fmac_f32_e32 v96, v97, v91                               // 000000139D20: 56C0B761
	v_fma_f32 v90, -v90, v96, v92                              // 000000139D24: D613005A 2572C15A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139D2C: BF870091
	v_div_fmas_f32 v90, v90, v91, v96                          // 000000139D30: D637005A 0582B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 000000139D38: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v123, v[128:129]     // 000000139D40: D6FF7C58 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139D4C: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 000000139D50: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 000000139D58: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 000000139D64: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 000000139D6C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000139D70: BE882005
	s_cbranch_execz 63105                                      // 000000139D74: BFA5F681 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f7c>
	v_mad_i64_i32 v[88:89], null, 0x6000, v124, v[130:131]     // 000000139D78: D6FF7C58 060AF8FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 000000139D84: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 000000139D8C: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000139D90: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139D94: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 000000139D98: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 000000139DA0: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 000000139DAC: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000139DB0: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 000000139DB4: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 000000139DB8: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 000000139DC0: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139DC8: BF870121
	v_add_f32_e32 v89, v89, v90                                // 000000139DCC: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 000000139DD0: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 000000139DD4: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139DD8: BF870095
	.long 0xd71c0059                                           // 000000139DDC: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 000000139DE0: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 000000139DE4: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 000000139DE8: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139DF0: BF870092
	v_cndmask_b32_e32 v88, 0x7f800000, v89, vcc_lo             // 000000139DF4: 02B0B2FF 7F800000
	v_dual_mul_f32 v89, v135, v93 :: v_dual_add_f32 v88, 1.0, v88// 000000139DFC: C8C8BB87 5958B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139E04: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 000000139E08: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 000000139E10: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139E14: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 000000139E18: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 000000139E20: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 000000139E24: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139E2C: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 000000139E30: 10BAB75C
	v_fma_f32 v96, -v90, v93, v92                              // 000000139E34: D6130060 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139E3C: BF870091
	v_fmac_f32_e32 v93, v96, v91                               // 000000139E40: 56BAB760
	v_fma_f32 v90, -v90, v93, v92                              // 000000139E44: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139E4C: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 000000139E50: D637005A 0576B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 000000139E58: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v124, v[128:129]     // 000000139E60: D6FF7C58 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139E6C: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 000000139E70: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 000000139E78: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 000000139E84: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 000000139E8C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000139E90: BE882006
	s_cbranch_execz 63036                                      // 000000139E94: BFA5F63C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f88>
	v_mad_i64_i32 v[88:89], null, 0x6000, v125, v[130:131]     // 000000139E98: D6FF7C58 060AFAFF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 000000139EA4: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 000000139EAC: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000139EB0: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139EB4: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 000000139EB8: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 000000139EC0: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 000000139ECC: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000139ED0: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 000000139ED4: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 000000139ED8: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 000000139EE0: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000139EE8: BF870121
	v_add_f32_e32 v89, v89, v90                                // 000000139EEC: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 000000139EF0: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 000000139EF4: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139EF8: BF870095
	.long 0xd71c0059                                           // 000000139EFC: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 000000139F00: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 000000139F04: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 000000139F08: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139F10: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v132, v94// 000000139F14: CA46B2FF 5858BD84 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 000000139F20: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139F24: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 000000139F28: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 000000139F30: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139F34: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 000000139F38: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 000000139F40: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 000000139F44: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139F4C: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 000000139F50: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 000000139F54: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139F5C: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 000000139F60: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 000000139F64: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139F6C: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 000000139F70: D637005A 0576B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 000000139F78: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v125, v[128:129]     // 000000139F80: D6FF7C58 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139F8C: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 000000139F90: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 000000139F98: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 000000139FA4: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 000000139FAC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000139FB0: BE882007
	s_cbranch_execz 62967                                      // 000000139FB4: BFA5F5F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f94>
	v_mad_i64_i32 v[88:89], null, 0x6000, v126, v[130:131]     // 000000139FB8: D6FF7C58 060AFCFF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 000000139FC4: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 000000139FCC: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000139FD0: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000139FD4: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 000000139FD8: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 000000139FE0: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 000000139FEC: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000139FF0: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 000000139FF4: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 000000139FF8: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 00000013A000: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A008: BF870121
	v_add_f32_e32 v89, v89, v90                                // 00000013A00C: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 00000013A010: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 00000013A014: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A018: BF870095
	.long 0xd71c0059                                           // 00000013A01C: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 00000013A020: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000013A024: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 00000013A028: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A030: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v133, v95// 00000013A034: CA46B2FF 5858BF85 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 00000013A040: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A044: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 00000013A048: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 00000013A050: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A054: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 00000013A058: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 00000013A060: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 00000013A064: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A06C: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 00000013A070: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 00000013A074: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A07C: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 00000013A080: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 00000013A084: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A08C: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 00000013A090: D637005A 0576B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 00000013A098: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v126, v[128:129]     // 00000013A0A0: D6FF7C58 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A0AC: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 00000013A0B0: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 00000013A0B8: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 00000013A0C4: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013A0CC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000013A0D0: BE882000
	s_cbranch_execz 62898                                      // 00000013A0D4: BFA5F5B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fa0>
	v_mad_i64_i32 v[88:89], null, 0x6000, v140, v[130:131]     // 00000013A0D8: D6FF7C58 060B18FF 00006000
	v_mul_f32_e32 v80, v138, v80                               // 00000013A0E4: 10A0A18A
	global_load_u16 v88, v[88:89], off offset:672              // 00000013A0E8: DC4A02A0 587C0058
	s_waitcnt vmcnt(0)                                         // 00000013A0F0: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 00000013A0F4: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A0F8: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 00000013A0FC: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 00000013A104: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 00000013A110: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013A114: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 00000013A118: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 00000013A11C: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 00000013A124: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A12C: BF870121
	v_add_f32_e32 v89, v89, v90                                // 00000013A130: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 00000013A134: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 00000013A138: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A13C: BF870095
	.long 0xd71c0059                                           // 00000013A140: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 00000013A144: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000013A148: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 00000013A14C: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A154: BF870092
	v_cndmask_b32_e32 v88, 0x7f800000, v89, vcc_lo             // 00000013A158: 02B0B2FF 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 00000013A160: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A164: BF870091
	v_div_scale_f32 v89, null, v88, v88, v80                   // 00000013A168: D6FC7C59 0542B158
	v_rcp_f32_e32 v90, v89                                     // 00000013A170: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A174: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 00000013A178: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 00000013A180: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v80, v88, v80                 // 00000013A184: D6FC6A5B 0542B150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A18C: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 00000013A190: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 00000013A194: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A19C: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 00000013A1A0: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 00000013A1A4: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A1AC: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 00000013A1B0: D6370059 0572B559
	v_div_fixup_f32 v80, v89, v88, v80                         // 00000013A1B8: D6270050 0542B159
	v_mad_i64_i32 v[88:89], null, 0x3000, v140, v[128:129]     // 00000013A1C0: D6FF7C58 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A1CC: BF870092
	v_bfe_u32 v90, v80, 16, 1                                  // 00000013A1D0: D610005A 02052150
	v_add3_u32 v80, v80, v90, 0x7fff                           // 00000013A1D8: D6550050 03FEB550 00007FFF
	global_store_d16_hi_b16 v[88:89], v80, off offset:160      // 00000013A1E4: DC9600A0 007C5058
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013A1EC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000013A1F0: BE882001
	s_cbranch_execz 62829                                      // 00000013A1F4: BFA5F56D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fac>
	v_mad_i64_i32 v[88:89], null, 0x6000, v120, v[130:131]     // 00000013A1F8: D6FF7C58 060AF0FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 00000013A204: 10A2A38B
	global_load_u16 v80, v[88:89], off offset:672              // 00000013A208: DC4A02A0 507C0058
	s_waitcnt vmcnt(0)                                         // 00000013A210: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000013A214: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A218: BF870121
	v_mul_f32_e32 v88, 0xbfb8aa3b, v80                         // 00000013A21C: 10B0A0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000013A224: 7C3CA0FF 42CE8ED0
	v_fma_f32 v89, 0xbfb8aa3b, v80, -v88                       // 00000013A22C: D6130059 8562A0FF BFB8AA3B
	v_rndne_f32_e32 v90, v88                                   // 00000013A238: 7EB44758
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013A23C: BF870112
	v_fmamk_f32 v89, v80, 0xb2a5705f, v89                      // 00000013A240: 58B2B350 B2A5705F
	v_sub_f32_e32 v88, v88, v90                                // 00000013A248: 08B0B558
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A24C: BF870121
	v_add_f32_e32 v88, v88, v89                                // 00000013A250: 06B0B358
	v_cvt_i32_f32_e32 v89, v90                                 // 00000013A254: 7EB2115A
	v_exp_f32_e32 v88, v88                                     // 00000013A258: 7EB04B58
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A25C: BF870095
	.long 0xd71c0058                                           // 00000013A260: D71C0058
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                     // 00000013A264: 0202B358
	v_cndmask_b32_e32 v88, 0, v88, vcc_lo                      // 00000013A268: 02B0B080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000013A26C: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A274: BF870092
	v_cndmask_b32_e32 v80, 0x7f800000, v88, vcc_lo             // 00000013A278: 02A0B0FF 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 00000013A280: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A284: BF870091
	v_div_scale_f32 v88, null, v80, v80, v81                   // 00000013A288: D6FC7C58 0546A150
	v_rcp_f32_e32 v89, v88                                     // 00000013A290: 7EB25558
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A294: BF870095
	v_fma_f32 v90, -v88, v89, 1.0                              // 00000013A298: D613005A 23CAB358
	v_fmac_f32_e32 v89, v90, v89                               // 00000013A2A0: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v81, v80, v81                 // 00000013A2A4: D6FC6A5A 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A2AC: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 00000013A2B0: 10B6B35A
	v_fma_f32 v92, -v88, v91, v90                              // 00000013A2B4: D613005C 256AB758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A2BC: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 00000013A2C0: 56B6B35C
	v_fma_f32 v88, -v88, v91, v90                              // 00000013A2C4: D6130058 256AB758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A2CC: BF870091
	v_div_fmas_f32 v88, v88, v89, v91                          // 00000013A2D0: D6370058 056EB358
	v_div_fixup_f32 v88, v88, v80, v81                         // 00000013A2D8: D6270058 0546A158
	v_mad_i64_i32 v[80:81], null, 0x3000, v120, v[128:129]     // 00000013A2E0: D6FF7C50 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A2EC: BF870092
	v_bfe_u32 v89, v88, 16, 1                                  // 00000013A2F0: D6100059 02052158
	v_add3_u32 v88, v88, v89, 0x7fff                           // 00000013A2F8: D6550058 03FEB358 00007FFF
	global_store_d16_hi_b16 v[80:81], v88, off offset:160      // 00000013A304: DC9600A0 007C5850
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013A30C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000013A310: BE882002
	s_cbranch_execz 62760                                      // 00000013A314: BFA5F528 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fb8>
	v_mad_i64_i32 v[80:81], null, 0x6000, v121, v[130:131]     // 00000013A318: D6FF7C50 060AF2FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 00000013A324: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000013A32C: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000013A330: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A334: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 00000013A338: 10A2A0FF BFB8AA3B
	v_fma_f32 v88, 0xbfb8aa3b, v80, -v81                       // 00000013A340: D6130058 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v89, v81                                   // 00000013A34C: 7EB24751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013A350: BF870221
	v_sub_f32_e32 v81, v81, v89                                // 00000013A354: 08A2B351
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000013A358: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v88, v80, 0xb2a5705f, v88                      // 00000013A360: 58B0B150 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A368: BF870121
	v_add_f32_e32 v81, v81, v88                                // 00000013A36C: 06A2B151
	v_cvt_i32_f32_e32 v88, v89                                 // 00000013A370: 7EB01159
	v_exp_f32_e32 v81, v81                                     // 00000013A374: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A378: BF870095
	.long 0xd71c0051                                           // 00000013A37C: D71C0051
	v_cndmask_b32_e32 v1, v81, v88, vcc_lo                     // 00000013A380: 0202B151
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000013A384: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000013A388: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A390: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v136, v82// 00000013A394: CA46A2FF 5050A588 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 00000013A3A0: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A3A4: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 00000013A3A8: D6FC7C52 0546A150
	v_rcp_f32_e32 v88, v82                                     // 00000013A3B0: 7EB05552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A3B4: BF870095
	v_fma_f32 v89, -v82, v88, 1.0                              // 00000013A3B8: D6130059 23CAB152
	v_fmac_f32_e32 v88, v89, v88                               // 00000013A3C0: 56B0B159
	v_div_scale_f32 v89, vcc_lo, v81, v80, v81                 // 00000013A3C4: D6FC6A59 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A3CC: BF870091
	v_mul_f32_e32 v90, v89, v88                                // 00000013A3D0: 10B4B159
	v_fma_f32 v91, -v82, v90, v89                              // 00000013A3D4: D613005B 2566B552
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A3DC: BF870091
	v_fmac_f32_e32 v90, v91, v88                               // 00000013A3E0: 56B4B15B
	v_fma_f32 v82, -v82, v90, v89                              // 00000013A3E4: D6130052 2566B552
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A3EC: BF870091
	v_div_fmas_f32 v82, v82, v88, v90                          // 00000013A3F0: D6370052 056AB152
	v_div_fixup_f32 v82, v82, v80, v81                         // 00000013A3F8: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v121, v[128:129]     // 00000013A400: D6FF7C50 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A40C: BF870092
	v_bfe_u32 v88, v82, 16, 1                                  // 00000013A410: D6100058 02052152
	v_add3_u32 v82, v82, v88, 0x7fff                           // 00000013A418: D6550052 03FEB152 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 00000013A424: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013A42C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013A430: BE882003
	s_cbranch_execz 62691                                      // 00000013A434: BFA5F4E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fc4>
	v_mad_i64_i32 v[80:81], null, 0x6000, v122, v[130:131]     // 00000013A438: D6FF7C50 060AF4FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 00000013A444: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000013A44C: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000013A450: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A454: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 00000013A458: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 00000013A460: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v88, v81                                   // 00000013A46C: 7EB04751
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A470: BF870091
	v_dual_fmamk_f32 v82, v80, 0xb2a5705f, v82 :: v_dual_sub_f32 v81, v81, v88// 00000013A474: C88AA550 5250B151 B2A5705F
	v_add_f32_e32 v81, v81, v82                                // 00000013A480: 06A2A551
	v_cvt_i32_f32_e32 v82, v88                                 // 00000013A484: 7EA41158
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000013A488: 7C3CA0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013A490: BF870293
	v_exp_f32_e32 v81, v81                                     // 00000013A494: 7EA24B51
	.long 0xd71c0051                                           // 00000013A498: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000013A49C: 0202A551
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A4A0: BF870121
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000013A4A4: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000013A4A8: 7C36A0FF C2B17218
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v137, v83// 00000013A4B0: CA46A2FF 5050A789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A4BC: BF870091
	v_add_f32_e32 v80, 1.0, v80                                // 00000013A4C0: 06A0A0F2
	v_div_scale_f32 v82, null, v80, v80, v81                   // 00000013A4C4: D6FC7C52 0546A150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013A4CC: BF870291
	v_rcp_f32_e32 v83, v82                                     // 00000013A4D0: 7EA65552
	v_fma_f32 v88, -v82, v83, 1.0                              // 00000013A4D4: D6130058 23CAA752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013A4DC: BF8700A1
	v_fmac_f32_e32 v83, v88, v83                               // 00000013A4E0: 56A6A758
	v_div_scale_f32 v88, vcc_lo, v81, v80, v81                 // 00000013A4E4: D6FC6A58 0546A151
	v_mul_f32_e32 v89, v88, v83                                // 00000013A4EC: 10B2A758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A4F0: BF870091
	v_fma_f32 v90, -v82, v89, v88                              // 00000013A4F4: D613005A 2562B352
	v_fmac_f32_e32 v89, v90, v83                               // 00000013A4FC: 56B2A75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A500: BF870091
	v_fma_f32 v82, -v82, v89, v88                              // 00000013A504: D6130052 2562B352
	v_div_fmas_f32 v82, v82, v83, v89                          // 00000013A50C: D6370052 0566A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A514: BF870121
	v_div_fixup_f32 v82, v82, v80, v81                         // 00000013A518: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v122, v[128:129]     // 00000013A520: D6FF7C50 0602F4FF 00003000
	v_bfe_u32 v83, v82, 16, 1                                  // 00000013A52C: D6100053 02052152
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013A534: BF870001
	v_add3_u32 v82, v82, v83, 0x7fff                           // 00000013A538: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 00000013A544: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013A54C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000013A550: BE882004
	s_cbranch_execz 62622                                      // 00000013A554: BFA5F49E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fd0>
	v_mad_i64_i32 v[80:81], null, 0x6000, v123, v[130:131]     // 00000013A558: D6FF7C50 060AF6FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 00000013A564: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000013A56C: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000013A570: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A574: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 00000013A578: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 00000013A580: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000013A58C: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013A590: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 00000013A594: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000013A598: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 00000013A5A0: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A5A8: BF870121
	v_add_f32_e32 v81, v81, v82                                // 00000013A5AC: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 00000013A5B0: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000013A5B4: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A5B8: BF870095
	.long 0xd71c0051                                           // 00000013A5BC: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000013A5C0: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000013A5C4: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000013A5C8: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A5D0: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v134, v84// 00000013A5D4: CA46A2FF 5050A986 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 00000013A5E0: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A5E4: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 00000013A5E8: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 00000013A5F0: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A5F4: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 00000013A5F8: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 00000013A600: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 00000013A604: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A60C: BF870091
	v_mul_f32_e32 v88, v84, v83                                // 00000013A610: 10B0A754
	v_fma_f32 v89, -v82, v88, v84                              // 00000013A614: D6130059 2552B152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A61C: BF870091
	v_fmac_f32_e32 v88, v89, v83                               // 00000013A620: 56B0A759
	v_fma_f32 v82, -v82, v88, v84                              // 00000013A624: D6130052 2552B152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A62C: BF870091
	v_div_fmas_f32 v82, v82, v83, v88                          // 00000013A630: D6370052 0562A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 00000013A638: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v123, v[128:129]     // 00000013A640: D6FF7C50 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A64C: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 00000013A650: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 00000013A658: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 00000013A664: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013A66C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000013A670: BE882005
	s_cbranch_execz 62553                                      // 00000013A674: BFA5F459 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fdc>
	v_mad_i64_i32 v[80:81], null, 0x6000, v124, v[130:131]     // 00000013A678: D6FF7C50 060AF8FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 00000013A684: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000013A68C: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000013A690: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A694: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 00000013A698: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 00000013A6A0: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000013A6AC: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013A6B0: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 00000013A6B4: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000013A6B8: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 00000013A6C0: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A6C8: BF870121
	v_add_f32_e32 v81, v81, v82                                // 00000013A6CC: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 00000013A6D0: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000013A6D4: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A6D8: BF870095
	.long 0xd71c0051                                           // 00000013A6DC: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000013A6E0: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000013A6E4: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000013A6E8: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A6F0: BF870092
	v_cndmask_b32_e32 v80, 0x7f800000, v81, vcc_lo             // 00000013A6F4: 02A0A2FF 7F800000
	v_dual_mul_f32 v81, v135, v85 :: v_dual_add_f32 v80, 1.0, v80// 00000013A6FC: C8C8AB87 5150A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A704: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 00000013A708: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 00000013A710: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A714: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 00000013A718: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 00000013A720: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 00000013A724: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A72C: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 00000013A730: 10AAA754
	v_fma_f32 v88, -v82, v85, v84                              // 00000013A734: D6130058 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A73C: BF870091
	v_fmac_f32_e32 v85, v88, v83                               // 00000013A740: 56AAA758
	v_fma_f32 v82, -v82, v85, v84                              // 00000013A744: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A74C: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 00000013A750: D6370052 0556A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 00000013A758: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v124, v[128:129]     // 00000013A760: D6FF7C50 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A76C: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 00000013A770: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 00000013A778: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 00000013A784: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013A78C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000013A790: BE882006
	s_cbranch_execz 62484                                      // 00000013A794: BFA5F414 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fe8>
	v_mad_i64_i32 v[80:81], null, 0x6000, v125, v[130:131]     // 00000013A798: D6FF7C50 060AFAFF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 00000013A7A4: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000013A7AC: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000013A7B0: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A7B4: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 00000013A7B8: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 00000013A7C0: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000013A7CC: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013A7D0: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 00000013A7D4: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000013A7D8: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 00000013A7E0: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A7E8: BF870121
	v_add_f32_e32 v81, v81, v82                                // 00000013A7EC: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 00000013A7F0: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000013A7F4: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A7F8: BF870095
	.long 0xd71c0051                                           // 00000013A7FC: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000013A800: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000013A804: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000013A808: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A810: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v132, v86// 00000013A814: CA46A2FF 5050AD84 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 00000013A820: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A824: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 00000013A828: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 00000013A830: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A834: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 00000013A838: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 00000013A840: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 00000013A844: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A84C: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 00000013A850: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 00000013A854: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A85C: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 00000013A860: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 00000013A864: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A86C: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 00000013A870: D6370052 0556A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 00000013A878: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v125, v[128:129]     // 00000013A880: D6FF7C50 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A88C: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 00000013A890: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 00000013A898: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 00000013A8A4: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013A8AC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013A8B0: BE882007
	s_cbranch_execz 62415                                      // 00000013A8B4: BFA5F3CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ff4>
	v_mad_i64_i32 v[80:81], null, 0x6000, v126, v[130:131]     // 00000013A8B8: D6FF7C50 060AFCFF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 00000013A8C4: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000013A8CC: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000013A8D0: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A8D4: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 00000013A8D8: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 00000013A8E0: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000013A8EC: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013A8F0: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 00000013A8F4: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000013A8F8: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 00000013A900: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013A908: BF870121
	v_add_f32_e32 v81, v81, v82                                // 00000013A90C: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 00000013A910: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000013A914: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A918: BF870095
	.long 0xd71c0051                                           // 00000013A91C: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000013A920: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000013A924: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000013A928: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A930: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v133, v87// 00000013A934: CA46A2FF 5050AF85 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 00000013A940: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A944: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 00000013A948: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 00000013A950: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A954: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 00000013A958: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 00000013A960: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 00000013A964: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A96C: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 00000013A970: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 00000013A974: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A97C: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 00000013A980: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 00000013A984: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A98C: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 00000013A990: D6370052 0556A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 00000013A998: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v126, v[128:129]     // 00000013A9A0: D6FF7C50 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A9AC: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 00000013A9B0: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 00000013A9B8: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 00000013A9C4: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013A9CC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000013A9D0: BE882000
	s_cbranch_execz 62346                                      // 00000013A9D4: BFA5F38A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4000>
	v_mad_i64_i32 v[80:81], null, 0x6000, v140, v[130:131]     // 00000013A9D8: D6FF7C50 060B18FF 00006000
	v_mul_f32_e32 v72, v138, v72                               // 00000013A9E4: 1090918A
	global_load_u16 v80, v[80:81], off offset:704              // 00000013A9E8: DC4A02C0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000013A9F0: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000013A9F4: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013A9F8: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 00000013A9FC: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 00000013AA04: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000013AA10: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013AA14: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 00000013AA18: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000013AA1C: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 00000013AA24: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013AA2C: BF870121
	v_add_f32_e32 v81, v81, v82                                // 00000013AA30: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 00000013AA34: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000013AA38: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AA3C: BF870095
	.long 0xd71c0051                                           // 00000013AA40: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000013AA44: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000013AA48: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000013AA4C: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AA54: BF870092
	v_cndmask_b32_e32 v80, 0x7f800000, v81, vcc_lo             // 00000013AA58: 02A0A2FF 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 00000013AA60: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AA64: BF870091
	v_div_scale_f32 v81, null, v80, v80, v72                   // 00000013AA68: D6FC7C51 0522A150
	v_rcp_f32_e32 v82, v81                                     // 00000013AA70: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AA74: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 00000013AA78: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 00000013AA80: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v72, v80, v72                 // 00000013AA84: D6FC6A53 0522A148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AA8C: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 00000013AA90: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 00000013AA94: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AA9C: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 00000013AAA0: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 00000013AAA4: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AAAC: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 00000013AAB0: D6370051 0552A551
	v_div_fixup_f32 v72, v81, v80, v72                         // 00000013AAB8: D6270048 0522A151
	v_mad_i64_i32 v[80:81], null, 0x3000, v140, v[128:129]     // 00000013AAC0: D6FF7C50 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AACC: BF870092
	v_bfe_u32 v82, v72, 16, 1                                  // 00000013AAD0: D6100052 02052148
	v_add3_u32 v72, v72, v82, 0x7fff                           // 00000013AAD8: D6550048 03FEA548 00007FFF
	global_store_d16_hi_b16 v[80:81], v72, off offset:192      // 00000013AAE4: DC9600C0 007C4850
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013AAEC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000013AAF0: BE882001
	s_cbranch_execz 62277                                      // 00000013AAF4: BFA5F345 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x400c>
	v_mad_i64_i32 v[80:81], null, 0x6000, v120, v[130:131]     // 00000013AAF8: D6FF7C50 060AF0FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 00000013AB04: 1092938B
	global_load_u16 v72, v[80:81], off offset:704              // 00000013AB08: DC4A02C0 487C0050
	s_waitcnt vmcnt(0)                                         // 00000013AB10: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000013AB14: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013AB18: BF870121
	v_mul_f32_e32 v80, 0xbfb8aa3b, v72                         // 00000013AB1C: 10A090FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000013AB24: 7C3C90FF 42CE8ED0
	v_fma_f32 v81, 0xbfb8aa3b, v72, -v80                       // 00000013AB2C: D6130051 854290FF BFB8AA3B
	v_rndne_f32_e32 v82, v80                                   // 00000013AB38: 7EA44750
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013AB3C: BF870112
	v_fmamk_f32 v81, v72, 0xb2a5705f, v81                      // 00000013AB40: 58A2A348 B2A5705F
	v_sub_f32_e32 v80, v80, v82                                // 00000013AB48: 08A0A550
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013AB4C: BF870121
	v_add_f32_e32 v80, v80, v81                                // 00000013AB50: 06A0A350
	v_cvt_i32_f32_e32 v81, v82                                 // 00000013AB54: 7EA21152
	v_exp_f32_e32 v80, v80                                     // 00000013AB58: 7EA04B50
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AB5C: BF870095
	.long 0xd71c0050                                           // 00000013AB60: D71C0050
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                     // 00000013AB64: 0202A350
	v_cndmask_b32_e32 v80, 0, v80, vcc_lo                      // 00000013AB68: 02A0A080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000013AB6C: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AB74: BF870092
	v_cndmask_b32_e32 v72, 0x7f800000, v80, vcc_lo             // 00000013AB78: 0290A0FF 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 00000013AB80: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AB84: BF870091
	v_div_scale_f32 v80, null, v72, v72, v73                   // 00000013AB88: D6FC7C50 05269148
	v_rcp_f32_e32 v81, v80                                     // 00000013AB90: 7EA25550
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AB94: BF870095
	v_fma_f32 v82, -v80, v81, 1.0                              // 00000013AB98: D6130052 23CAA350
	v_fmac_f32_e32 v81, v82, v81                               // 00000013ABA0: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v73, v72, v73                 // 00000013ABA4: D6FC6A52 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ABAC: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 00000013ABB0: 10A6A352
	v_fma_f32 v84, -v80, v83, v82                              // 00000013ABB4: D6130054 254AA750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ABBC: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 00000013ABC0: 56A6A354
	v_fma_f32 v80, -v80, v83, v82                              // 00000013ABC4: D6130050 254AA750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ABCC: BF870091
	v_div_fmas_f32 v80, v80, v81, v83                          // 00000013ABD0: D6370050 054EA350
	v_div_fixup_f32 v80, v80, v72, v73                         // 00000013ABD8: D6270050 05269150
	v_mad_i64_i32 v[72:73], null, 0x3000, v120, v[128:129]     // 00000013ABE0: D6FF7C48 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ABEC: BF870092
	v_bfe_u32 v81, v80, 16, 1                                  // 00000013ABF0: D6100051 02052150
	v_add3_u32 v80, v80, v81, 0x7fff                           // 00000013ABF8: D6550050 03FEA350 00007FFF
	global_store_d16_hi_b16 v[72:73], v80, off offset:192      // 00000013AC04: DC9600C0 007C5048
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013AC0C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000013AC10: BE882002
	s_cbranch_execz 62208                                      // 00000013AC14: BFA5F300 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4018>
	v_mad_i64_i32 v[72:73], null, 0x6000, v121, v[130:131]     // 00000013AC18: D6FF7C48 060AF2FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 00000013AC24: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000013AC2C: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000013AC30: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AC34: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000013AC38: 109290FF BFB8AA3B
	v_fma_f32 v80, 0xbfb8aa3b, v72, -v73                       // 00000013AC40: D6130050 852690FF BFB8AA3B
	v_rndne_f32_e32 v81, v73                                   // 00000013AC4C: 7EA24749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013AC50: BF870221
	v_sub_f32_e32 v73, v73, v81                                // 00000013AC54: 0892A349
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000013AC58: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v80, v72, 0xb2a5705f, v80                      // 00000013AC60: 58A0A148 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013AC68: BF870121
	v_add_f32_e32 v73, v73, v80                                // 00000013AC6C: 0692A149
	v_cvt_i32_f32_e32 v80, v81                                 // 00000013AC70: 7EA01151
	v_exp_f32_e32 v73, v73                                     // 00000013AC74: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AC78: BF870095
	.long 0xd71c0049                                           // 00000013AC7C: D71C0049
	v_cndmask_b32_e32 v1, v73, v80, vcc_lo                     // 00000013AC80: 0202A149
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000013AC84: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000013AC88: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AC90: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v136, v74// 00000013AC94: CA4692FF 48489588 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 00000013ACA0: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ACA4: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 00000013ACA8: D6FC7C4A 05269148
	v_rcp_f32_e32 v80, v74                                     // 00000013ACB0: 7EA0554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ACB4: BF870095
	v_fma_f32 v81, -v74, v80, 1.0                              // 00000013ACB8: D6130051 23CAA14A
	v_fmac_f32_e32 v80, v81, v80                               // 00000013ACC0: 56A0A151
	v_div_scale_f32 v81, vcc_lo, v73, v72, v73                 // 00000013ACC4: D6FC6A51 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ACCC: BF870091
	v_mul_f32_e32 v82, v81, v80                                // 00000013ACD0: 10A4A151
	v_fma_f32 v83, -v74, v82, v81                              // 00000013ACD4: D6130053 2546A54A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ACDC: BF870091
	v_fmac_f32_e32 v82, v83, v80                               // 00000013ACE0: 56A4A153
	v_fma_f32 v74, -v74, v82, v81                              // 00000013ACE4: D613004A 2546A54A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ACEC: BF870091
	v_div_fmas_f32 v74, v74, v80, v82                          // 00000013ACF0: D637004A 054AA14A
	v_div_fixup_f32 v74, v74, v72, v73                         // 00000013ACF8: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v121, v[128:129]     // 00000013AD00: D6FF7C48 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AD0C: BF870092
	v_bfe_u32 v80, v74, 16, 1                                  // 00000013AD10: D6100050 0205214A
	v_add3_u32 v74, v74, v80, 0x7fff                           // 00000013AD18: D655004A 03FEA14A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 00000013AD24: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013AD2C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013AD30: BE882003
	s_cbranch_execz 62139                                      // 00000013AD34: BFA5F2BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4024>
	v_mad_i64_i32 v[72:73], null, 0x6000, v122, v[130:131]     // 00000013AD38: D6FF7C48 060AF4FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 00000013AD44: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000013AD4C: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000013AD50: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AD54: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000013AD58: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 00000013AD60: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v80, v73                                   // 00000013AD6C: 7EA04749
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AD70: BF870091
	v_dual_fmamk_f32 v74, v72, 0xb2a5705f, v74 :: v_dual_sub_f32 v73, v73, v80// 00000013AD74: C88A9548 4A48A149 B2A5705F
	v_add_f32_e32 v73, v73, v74                                // 00000013AD80: 06929549
	v_cvt_i32_f32_e32 v74, v80                                 // 00000013AD84: 7E941150
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000013AD88: 7C3C90FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013AD90: BF870293
	v_exp_f32_e32 v73, v73                                     // 00000013AD94: 7E924B49
	.long 0xd71c0049                                           // 00000013AD98: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000013AD9C: 02029549
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013ADA0: BF870121
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000013ADA4: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000013ADA8: 7C3690FF C2B17218
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v137, v75// 00000013ADB0: CA4692FF 48489789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ADBC: BF870091
	v_add_f32_e32 v72, 1.0, v72                                // 00000013ADC0: 069090F2
	v_div_scale_f32 v74, null, v72, v72, v73                   // 00000013ADC4: D6FC7C4A 05269148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013ADCC: BF870291
	v_rcp_f32_e32 v75, v74                                     // 00000013ADD0: 7E96554A
	v_fma_f32 v80, -v74, v75, 1.0                              // 00000013ADD4: D6130050 23CA974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013ADDC: BF8700A1
	v_fmac_f32_e32 v75, v80, v75                               // 00000013ADE0: 56969750
	v_div_scale_f32 v80, vcc_lo, v73, v72, v73                 // 00000013ADE4: D6FC6A50 05269149
	v_mul_f32_e32 v81, v80, v75                                // 00000013ADEC: 10A29750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ADF0: BF870091
	v_fma_f32 v82, -v74, v81, v80                              // 00000013ADF4: D6130052 2542A34A
	v_fmac_f32_e32 v81, v82, v75                               // 00000013ADFC: 56A29752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AE00: BF870091
	v_fma_f32 v74, -v74, v81, v80                              // 00000013AE04: D613004A 2542A34A
	v_div_fmas_f32 v74, v74, v75, v81                          // 00000013AE0C: D637004A 0546974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013AE14: BF870121
	v_div_fixup_f32 v74, v74, v72, v73                         // 00000013AE18: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v122, v[128:129]     // 00000013AE20: D6FF7C48 0602F4FF 00003000
	v_bfe_u32 v75, v74, 16, 1                                  // 00000013AE2C: D610004B 0205214A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013AE34: BF870001
	v_add3_u32 v74, v74, v75, 0x7fff                           // 00000013AE38: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 00000013AE44: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013AE4C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000013AE50: BE882004
	s_cbranch_execz 62070                                      // 00000013AE54: BFA5F276 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4030>
	v_mad_i64_i32 v[72:73], null, 0x6000, v123, v[130:131]     // 00000013AE58: D6FF7C48 060AF6FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 00000013AE64: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000013AE6C: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000013AE70: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AE74: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000013AE78: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 00000013AE80: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000013AE8C: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013AE90: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 00000013AE94: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000013AE98: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 00000013AEA0: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013AEA8: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000013AEAC: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 00000013AEB0: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000013AEB4: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AEB8: BF870095
	.long 0xd71c0049                                           // 00000013AEBC: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000013AEC0: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000013AEC4: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000013AEC8: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AED0: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v134, v76// 00000013AED4: CA4692FF 48489986 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 00000013AEE0: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AEE4: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 00000013AEE8: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 00000013AEF0: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AEF4: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 00000013AEF8: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 00000013AF00: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 00000013AF04: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AF0C: BF870091
	v_mul_f32_e32 v80, v76, v75                                // 00000013AF10: 10A0974C
	v_fma_f32 v81, -v74, v80, v76                              // 00000013AF14: D6130051 2532A14A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AF1C: BF870091
	v_fmac_f32_e32 v80, v81, v75                               // 00000013AF20: 56A09751
	v_fma_f32 v74, -v74, v80, v76                              // 00000013AF24: D613004A 2532A14A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AF2C: BF870091
	v_div_fmas_f32 v74, v74, v75, v80                          // 00000013AF30: D637004A 0542974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 00000013AF38: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v123, v[128:129]     // 00000013AF40: D6FF7C48 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AF4C: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 00000013AF50: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 00000013AF58: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 00000013AF64: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013AF6C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000013AF70: BE882005
	s_cbranch_execz 62001                                      // 00000013AF74: BFA5F231 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x403c>
	v_mad_i64_i32 v[72:73], null, 0x6000, v124, v[130:131]     // 00000013AF78: D6FF7C48 060AF8FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 00000013AF84: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000013AF8C: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000013AF90: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AF94: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000013AF98: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 00000013AFA0: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000013AFAC: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013AFB0: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 00000013AFB4: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000013AFB8: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 00000013AFC0: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013AFC8: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000013AFCC: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 00000013AFD0: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000013AFD4: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AFD8: BF870095
	.long 0xd71c0049                                           // 00000013AFDC: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000013AFE0: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000013AFE4: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000013AFE8: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013AFF0: BF870092
	v_cndmask_b32_e32 v72, 0x7f800000, v73, vcc_lo             // 00000013AFF4: 029092FF 7F800000
	v_dual_mul_f32 v73, v135, v77 :: v_dual_add_f32 v72, 1.0, v72// 00000013AFFC: C8C89B87 494890F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B004: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 00000013B008: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 00000013B010: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B014: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 00000013B018: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 00000013B020: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 00000013B024: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B02C: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 00000013B030: 109A974C
	v_fma_f32 v80, -v74, v77, v76                              // 00000013B034: D6130050 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B03C: BF870091
	v_fmac_f32_e32 v77, v80, v75                               // 00000013B040: 569A9750
	v_fma_f32 v74, -v74, v77, v76                              // 00000013B044: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B04C: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 00000013B050: D637004A 0536974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 00000013B058: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v124, v[128:129]     // 00000013B060: D6FF7C48 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B06C: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 00000013B070: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 00000013B078: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 00000013B084: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013B08C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000013B090: BE882006
	s_cbranch_execz 61932                                      // 00000013B094: BFA5F1EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4048>
	v_mad_i64_i32 v[72:73], null, 0x6000, v125, v[130:131]     // 00000013B098: D6FF7C48 060AFAFF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 00000013B0A4: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000013B0AC: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000013B0B0: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B0B4: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000013B0B8: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 00000013B0C0: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000013B0CC: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013B0D0: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 00000013B0D4: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000013B0D8: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 00000013B0E0: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013B0E8: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000013B0EC: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 00000013B0F0: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000013B0F4: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B0F8: BF870095
	.long 0xd71c0049                                           // 00000013B0FC: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000013B100: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000013B104: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000013B108: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B110: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v132, v78// 00000013B114: CA4692FF 48489D84 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 00000013B120: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B124: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 00000013B128: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 00000013B130: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B134: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 00000013B138: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 00000013B140: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 00000013B144: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B14C: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 00000013B150: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 00000013B154: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B15C: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 00000013B160: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 00000013B164: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B16C: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 00000013B170: D637004A 0536974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 00000013B178: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v125, v[128:129]     // 00000013B180: D6FF7C48 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B18C: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 00000013B190: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 00000013B198: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 00000013B1A4: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013B1AC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013B1B0: BE882007
	s_cbranch_execz 61863                                      // 00000013B1B4: BFA5F1A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4054>
	v_mad_i64_i32 v[72:73], null, 0x6000, v126, v[130:131]     // 00000013B1B8: D6FF7C48 060AFCFF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 00000013B1C4: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000013B1CC: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000013B1D0: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B1D4: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000013B1D8: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 00000013B1E0: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000013B1EC: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013B1F0: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 00000013B1F4: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000013B1F8: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 00000013B200: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013B208: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000013B20C: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 00000013B210: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000013B214: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B218: BF870095
	.long 0xd71c0049                                           // 00000013B21C: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000013B220: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000013B224: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000013B228: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B230: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v133, v79// 00000013B234: CA4692FF 48489F85 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 00000013B240: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B244: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 00000013B248: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 00000013B250: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B254: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 00000013B258: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 00000013B260: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 00000013B264: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B26C: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 00000013B270: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 00000013B274: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B27C: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 00000013B280: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 00000013B284: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B28C: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 00000013B290: D637004A 0536974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 00000013B298: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v126, v[128:129]     // 00000013B2A0: D6FF7C48 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B2AC: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 00000013B2B0: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 00000013B2B8: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 00000013B2C4: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013B2CC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000013B2D0: BE882000
	s_cbranch_execz 61794                                      // 00000013B2D4: BFA5F162 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4060>
	v_mad_i64_i32 v[72:73], null, 0x6000, v140, v[130:131]     // 00000013B2D8: D6FF7C48 060B18FF 00006000
	v_mul_f32_e32 v64, v138, v64                               // 00000013B2E4: 1080818A
	global_load_u16 v72, v[72:73], off offset:736              // 00000013B2E8: DC4A02E0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000013B2F0: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000013B2F4: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B2F8: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000013B2FC: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 00000013B304: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000013B310: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013B314: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 00000013B318: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000013B31C: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 00000013B324: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013B32C: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000013B330: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 00000013B334: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000013B338: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B33C: BF870095
	.long 0xd71c0049                                           // 00000013B340: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000013B344: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000013B348: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000013B34C: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B354: BF870092
	v_cndmask_b32_e32 v72, 0x7f800000, v73, vcc_lo             // 00000013B358: 029092FF 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 00000013B360: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B364: BF870091
	v_div_scale_f32 v73, null, v72, v72, v64                   // 00000013B368: D6FC7C49 05029148
	v_rcp_f32_e32 v74, v73                                     // 00000013B370: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B374: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 00000013B378: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 00000013B380: 5694954B
	v_div_scale_f32 v75, vcc_lo, v64, v72, v64                 // 00000013B384: D6FC6A4B 05029140
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B38C: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 00000013B390: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 00000013B394: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B39C: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 00000013B3A0: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 00000013B3A4: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B3AC: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 00000013B3B0: D6370049 05329549
	v_div_fixup_f32 v64, v73, v72, v64                         // 00000013B3B8: D6270040 05029149
	v_mad_i64_i32 v[72:73], null, 0x3000, v140, v[128:129]     // 00000013B3C0: D6FF7C48 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B3CC: BF870092
	v_bfe_u32 v74, v64, 16, 1                                  // 00000013B3D0: D610004A 02052140
	v_add3_u32 v64, v64, v74, 0x7fff                           // 00000013B3D8: D6550040 03FE9540 00007FFF
	global_store_d16_hi_b16 v[72:73], v64, off offset:224      // 00000013B3E4: DC9600E0 007C4048
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013B3EC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000013B3F0: BE882001
	s_cbranch_execz 61725                                      // 00000013B3F4: BFA5F11D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x406c>
	v_mad_i64_i32 v[72:73], null, 0x6000, v120, v[130:131]     // 00000013B3F8: D6FF7C48 060AF0FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 00000013B404: 1082838B
	global_load_u16 v64, v[72:73], off offset:736              // 00000013B408: DC4A02E0 407C0048
	s_waitcnt vmcnt(0)                                         // 00000013B410: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000013B414: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013B418: BF870121
	v_mul_f32_e32 v72, 0xbfb8aa3b, v64                         // 00000013B41C: 109080FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000013B424: 7C3C80FF 42CE8ED0
	v_fma_f32 v73, 0xbfb8aa3b, v64, -v72                       // 00000013B42C: D6130049 852280FF BFB8AA3B
	v_rndne_f32_e32 v74, v72                                   // 00000013B438: 7E944748
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013B43C: BF870112
	v_fmamk_f32 v73, v64, 0xb2a5705f, v73                      // 00000013B440: 58929340 B2A5705F
	v_sub_f32_e32 v72, v72, v74                                // 00000013B448: 08909548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013B44C: BF870121
	v_add_f32_e32 v72, v72, v73                                // 00000013B450: 06909348
	v_cvt_i32_f32_e32 v73, v74                                 // 00000013B454: 7E92114A
	v_exp_f32_e32 v72, v72                                     // 00000013B458: 7E904B48
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B45C: BF870095
	.long 0xd71c0048                                           // 00000013B460: D71C0048
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                     // 00000013B464: 02029348
	v_cndmask_b32_e32 v72, 0, v72, vcc_lo                      // 00000013B468: 02909080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000013B46C: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B474: BF870092
	v_cndmask_b32_e32 v64, 0x7f800000, v72, vcc_lo             // 00000013B478: 028090FF 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 00000013B480: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B484: BF870091
	v_div_scale_f32 v72, null, v64, v64, v65                   // 00000013B488: D6FC7C48 05068140
	v_rcp_f32_e32 v73, v72                                     // 00000013B490: 7E925548
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B494: BF870095
	v_fma_f32 v74, -v72, v73, 1.0                              // 00000013B498: D613004A 23CA9348
	v_fmac_f32_e32 v73, v74, v73                               // 00000013B4A0: 5692934A
	v_div_scale_f32 v74, vcc_lo, v65, v64, v65                 // 00000013B4A4: D6FC6A4A 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B4AC: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 00000013B4B0: 1096934A
	v_fma_f32 v76, -v72, v75, v74                              // 00000013B4B4: D613004C 252A9748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B4BC: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 00000013B4C0: 5696934C
	v_fma_f32 v72, -v72, v75, v74                              // 00000013B4C4: D6130048 252A9748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B4CC: BF870091
	v_div_fmas_f32 v72, v72, v73, v75                          // 00000013B4D0: D6370048 052E9348
	v_div_fixup_f32 v72, v72, v64, v65                         // 00000013B4D8: D6270048 05068148
	v_mad_i64_i32 v[64:65], null, 0x3000, v120, v[128:129]     // 00000013B4E0: D6FF7C40 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B4EC: BF870092
	v_bfe_u32 v73, v72, 16, 1                                  // 00000013B4F0: D6100049 02052148
	v_add3_u32 v72, v72, v73, 0x7fff                           // 00000013B4F8: D6550048 03FE9348 00007FFF
	global_store_d16_hi_b16 v[64:65], v72, off offset:224      // 00000013B504: DC9600E0 007C4840
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013B50C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000013B510: BE882002
	s_cbranch_execz 61656                                      // 00000013B514: BFA5F0D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4078>
	v_mad_i64_i32 v[64:65], null, 0x6000, v121, v[130:131]     // 00000013B518: D6FF7C40 060AF2FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 00000013B524: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 00000013B52C: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000013B530: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B534: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000013B538: 108280FF BFB8AA3B
	v_fma_f32 v72, 0xbfb8aa3b, v64, -v65                       // 00000013B540: D6130048 850680FF BFB8AA3B
	v_rndne_f32_e32 v73, v65                                   // 00000013B54C: 7E924741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013B550: BF870221
	v_sub_f32_e32 v65, v65, v73                                // 00000013B554: 08829341
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000013B558: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v72, v64, 0xb2a5705f, v72                      // 00000013B560: 58909140 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013B568: BF870121
	v_add_f32_e32 v65, v65, v72                                // 00000013B56C: 06829141
	v_cvt_i32_f32_e32 v72, v73                                 // 00000013B570: 7E901149
	v_exp_f32_e32 v65, v65                                     // 00000013B574: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B578: BF870095
	.long 0xd71c0041                                           // 00000013B57C: D71C0041
	v_cndmask_b32_e32 v1, v65, v72, vcc_lo                     // 00000013B580: 02029141
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000013B584: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000013B588: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B590: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v136, v66// 00000013B594: CA4682FF 40408588 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 00000013B5A0: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B5A4: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 00000013B5A8: D6FC7C42 05068140
	v_rcp_f32_e32 v72, v66                                     // 00000013B5B0: 7E905542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B5B4: BF870095
	v_fma_f32 v73, -v66, v72, 1.0                              // 00000013B5B8: D6130049 23CA9142
	v_fmac_f32_e32 v72, v73, v72                               // 00000013B5C0: 56909149
	v_div_scale_f32 v73, vcc_lo, v65, v64, v65                 // 00000013B5C4: D6FC6A49 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B5CC: BF870091
	v_mul_f32_e32 v74, v73, v72                                // 00000013B5D0: 10949149
	v_fma_f32 v75, -v66, v74, v73                              // 00000013B5D4: D613004B 25269542
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B5DC: BF870091
	v_fmac_f32_e32 v74, v75, v72                               // 00000013B5E0: 5694914B
	v_fma_f32 v66, -v66, v74, v73                              // 00000013B5E4: D6130042 25269542
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B5EC: BF870091
	v_div_fmas_f32 v66, v66, v72, v74                          // 00000013B5F0: D6370042 052A9142
	v_div_fixup_f32 v66, v66, v64, v65                         // 00000013B5F8: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v121, v[128:129]     // 00000013B600: D6FF7C40 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B60C: BF870092
	v_bfe_u32 v72, v66, 16, 1                                  // 00000013B610: D6100048 02052142
	v_add3_u32 v66, v66, v72, 0x7fff                           // 00000013B618: D6550042 03FE9142 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 00000013B624: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013B62C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013B630: BE882003
	s_cbranch_execz 61587                                      // 00000013B634: BFA5F093 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4084>
	v_mad_i64_i32 v[64:65], null, 0x6000, v122, v[130:131]     // 00000013B638: D6FF7C40 060AF4FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 00000013B644: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 00000013B64C: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000013B650: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B654: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000013B658: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 00000013B660: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v72, v65                                   // 00000013B66C: 7E904741
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B670: BF870091
	v_dual_fmamk_f32 v66, v64, 0xb2a5705f, v66 :: v_dual_sub_f32 v65, v65, v72// 00000013B674: C88A8540 42409141 B2A5705F
	v_add_f32_e32 v65, v65, v66                                // 00000013B680: 06828541
	v_cvt_i32_f32_e32 v66, v72                                 // 00000013B684: 7E841148
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000013B688: 7C3C80FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013B690: BF870293
	v_exp_f32_e32 v65, v65                                     // 00000013B694: 7E824B41
	.long 0xd71c0041                                           // 00000013B698: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000013B69C: 02028541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013B6A0: BF870121
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000013B6A4: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000013B6A8: 7C3680FF C2B17218
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v137, v67// 00000013B6B0: CA4682FF 40408789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B6BC: BF870091
	v_add_f32_e32 v64, 1.0, v64                                // 00000013B6C0: 068080F2
	v_div_scale_f32 v66, null, v64, v64, v65                   // 00000013B6C4: D6FC7C42 05068140
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013B6CC: BF870291
	v_rcp_f32_e32 v67, v66                                     // 00000013B6D0: 7E865542
	v_fma_f32 v72, -v66, v67, 1.0                              // 00000013B6D4: D6130048 23CA8742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013B6DC: BF8700A1
	v_fmac_f32_e32 v67, v72, v67                               // 00000013B6E0: 56868748
	v_div_scale_f32 v72, vcc_lo, v65, v64, v65                 // 00000013B6E4: D6FC6A48 05068141
	v_mul_f32_e32 v73, v72, v67                                // 00000013B6EC: 10928748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B6F0: BF870091
	v_fma_f32 v74, -v66, v73, v72                              // 00000013B6F4: D613004A 25229342
	v_fmac_f32_e32 v73, v74, v67                               // 00000013B6FC: 5692874A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B700: BF870091
	v_fma_f32 v66, -v66, v73, v72                              // 00000013B704: D6130042 25229342
	v_div_fmas_f32 v66, v66, v67, v73                          // 00000013B70C: D6370042 05268742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013B714: BF870121
	v_div_fixup_f32 v66, v66, v64, v65                         // 00000013B718: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v122, v[128:129]     // 00000013B720: D6FF7C40 0602F4FF 00003000
	v_bfe_u32 v67, v66, 16, 1                                  // 00000013B72C: D6100043 02052142
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B734: BF870001
	v_add3_u32 v66, v66, v67, 0x7fff                           // 00000013B738: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 00000013B744: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013B74C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000013B750: BE882004
	s_cbranch_execz 61518                                      // 00000013B754: BFA5F04E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4090>
	v_mad_i64_i32 v[64:65], null, 0x6000, v123, v[130:131]     // 00000013B758: D6FF7C40 060AF6FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 00000013B764: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 00000013B76C: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000013B770: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B774: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000013B778: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 00000013B780: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000013B78C: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013B790: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 00000013B794: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000013B798: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 00000013B7A0: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013B7A8: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000013B7AC: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000013B7B0: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000013B7B4: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B7B8: BF870095
	.long 0xd71c0041                                           // 00000013B7BC: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000013B7C0: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000013B7C4: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000013B7C8: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B7D0: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v134, v68// 00000013B7D4: CA4682FF 40408986 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 00000013B7E0: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B7E4: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 00000013B7E8: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 00000013B7F0: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B7F4: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 00000013B7F8: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 00000013B800: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 00000013B804: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B80C: BF870091
	v_mul_f32_e32 v72, v68, v67                                // 00000013B810: 10908744
	v_fma_f32 v73, -v66, v72, v68                              // 00000013B814: D6130049 25129142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B81C: BF870091
	v_fmac_f32_e32 v72, v73, v67                               // 00000013B820: 56908749
	v_fma_f32 v66, -v66, v72, v68                              // 00000013B824: D6130042 25129142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B82C: BF870091
	v_div_fmas_f32 v66, v66, v67, v72                          // 00000013B830: D6370042 05228742
	v_div_fixup_f32 v66, v66, v64, v65                         // 00000013B838: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v123, v[128:129]     // 00000013B840: D6FF7C40 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B84C: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 00000013B850: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 00000013B858: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 00000013B864: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013B86C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000013B870: BE882005
	s_cbranch_execz 61449                                      // 00000013B874: BFA5F009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x409c>
	v_mad_i64_i32 v[64:65], null, 0x6000, v124, v[130:131]     // 00000013B878: D6FF7C40 060AF8FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 00000013B884: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 00000013B88C: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000013B890: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B894: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000013B898: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 00000013B8A0: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000013B8AC: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013B8B0: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 00000013B8B4: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000013B8B8: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 00000013B8C0: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013B8C8: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000013B8CC: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000013B8D0: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000013B8D4: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B8D8: BF870095
	.long 0xd71c0041                                           // 00000013B8DC: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000013B8E0: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000013B8E4: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000013B8E8: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B8F0: BF870092
	v_cndmask_b32_e32 v64, 0x7f800000, v65, vcc_lo             // 00000013B8F4: 028082FF 7F800000
	v_dual_mul_f32 v65, v135, v69 :: v_dual_add_f32 v64, 1.0, v64// 00000013B8FC: C8C88B87 414080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B904: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 00000013B908: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 00000013B910: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B914: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 00000013B918: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 00000013B920: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 00000013B924: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B92C: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 00000013B930: 108A8744
	v_fma_f32 v72, -v66, v69, v68                              // 00000013B934: D6130048 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B93C: BF870091
	v_fmac_f32_e32 v69, v72, v67                               // 00000013B940: 568A8748
	v_fma_f32 v66, -v66, v69, v68                              // 00000013B944: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B94C: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 00000013B950: D6370042 05168742
	v_div_fixup_f32 v66, v66, v64, v65                         // 00000013B958: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v124, v[128:129]     // 00000013B960: D6FF7C40 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B96C: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 00000013B970: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 00000013B978: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 00000013B984: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013B98C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000013B990: BE882006
	s_cbranch_execz 61380                                      // 00000013B994: BFA5EFC4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40a8>
	v_mad_i64_i32 v[64:65], null, 0x6000, v125, v[130:131]     // 00000013B998: D6FF7C40 060AFAFF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 00000013B9A4: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 00000013B9AC: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000013B9B0: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B9B4: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000013B9B8: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 00000013B9C0: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000013B9CC: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013B9D0: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 00000013B9D4: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000013B9D8: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 00000013B9E0: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013B9E8: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000013B9EC: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000013B9F0: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000013B9F4: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B9F8: BF870095
	.long 0xd71c0041                                           // 00000013B9FC: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000013BA00: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000013BA04: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000013BA08: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BA10: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v132, v70// 00000013BA14: CA4682FF 40408D84 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 00000013BA20: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BA24: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 00000013BA28: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 00000013BA30: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BA34: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 00000013BA38: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 00000013BA40: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 00000013BA44: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BA4C: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 00000013BA50: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 00000013BA54: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BA5C: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 00000013BA60: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 00000013BA64: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BA6C: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 00000013BA70: D6370042 05168742
	v_div_fixup_f32 v66, v66, v64, v65                         // 00000013BA78: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v125, v[128:129]     // 00000013BA80: D6FF7C40 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BA8C: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 00000013BA90: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 00000013BA98: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 00000013BAA4: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013BAAC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013BAB0: BE882007
	s_cbranch_execz 61311                                      // 00000013BAB4: BFA5EF7F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40b4>
	v_mad_i64_i32 v[64:65], null, 0x6000, v126, v[130:131]     // 00000013BAB8: D6FF7C40 060AFCFF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 00000013BAC4: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 00000013BACC: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000013BAD0: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BAD4: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000013BAD8: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 00000013BAE0: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000013BAEC: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013BAF0: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 00000013BAF4: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000013BAF8: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 00000013BB00: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013BB08: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000013BB0C: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000013BB10: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000013BB14: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BB18: BF870095
	.long 0xd71c0041                                           // 00000013BB1C: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000013BB20: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000013BB24: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000013BB28: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BB30: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v133, v71// 00000013BB34: CA4682FF 40408F85 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 00000013BB40: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BB44: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 00000013BB48: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 00000013BB50: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BB54: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 00000013BB58: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 00000013BB60: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 00000013BB64: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BB6C: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 00000013BB70: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 00000013BB74: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BB7C: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 00000013BB80: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 00000013BB84: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BB8C: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 00000013BB90: D6370042 05168742
	v_div_fixup_f32 v66, v66, v64, v65                         // 00000013BB98: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v126, v[128:129]     // 00000013BBA0: D6FF7C40 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BBAC: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 00000013BBB0: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 00000013BBB8: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 00000013BBC4: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013BBCC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000013BBD0: BE882000
	s_cbranch_execz 61242                                      // 00000013BBD4: BFA5EF3A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40c0>
	v_mad_i64_i32 v[64:65], null, 0x6000, v140, v[130:131]     // 00000013BBD8: D6FF7C40 060B18FF 00006000
	v_mul_f32_e32 v56, v138, v56                               // 00000013BBE4: 1070718A
	global_load_u16 v64, v[64:65], off offset:768              // 00000013BBE8: DC4A0300 407C0040
	s_waitcnt vmcnt(0)                                         // 00000013BBF0: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000013BBF4: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BBF8: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000013BBFC: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 00000013BC04: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000013BC10: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013BC14: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 00000013BC18: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000013BC1C: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 00000013BC24: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013BC2C: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000013BC30: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000013BC34: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000013BC38: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BC3C: BF870095
	.long 0xd71c0041                                           // 00000013BC40: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000013BC44: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000013BC48: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000013BC4C: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BC54: BF870092
	v_cndmask_b32_e32 v64, 0x7f800000, v65, vcc_lo             // 00000013BC58: 028082FF 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 00000013BC60: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BC64: BF870091
	v_div_scale_f32 v65, null, v64, v64, v56                   // 00000013BC68: D6FC7C41 04E28140
	v_rcp_f32_e32 v66, v65                                     // 00000013BC70: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BC74: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 00000013BC78: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 00000013BC80: 56848543
	v_div_scale_f32 v67, vcc_lo, v56, v64, v56                 // 00000013BC84: D6FC6A43 04E28138
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BC8C: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 00000013BC90: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 00000013BC94: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BC9C: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 00000013BCA0: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 00000013BCA4: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BCAC: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 00000013BCB0: D6370041 05128541
	v_div_fixup_f32 v56, v65, v64, v56                         // 00000013BCB8: D6270038 04E28141
	v_mad_i64_i32 v[64:65], null, 0x3000, v140, v[128:129]     // 00000013BCC0: D6FF7C40 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BCCC: BF870092
	v_bfe_u32 v66, v56, 16, 1                                  // 00000013BCD0: D6100042 02052138
	v_add3_u32 v56, v56, v66, 0x7fff                           // 00000013BCD8: D6550038 03FE8538 00007FFF
	global_store_d16_hi_b16 v[64:65], v56, off offset:256      // 00000013BCE4: DC960100 007C3840
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013BCEC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000013BCF0: BE882001
	s_cbranch_execz 61173                                      // 00000013BCF4: BFA5EEF5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40cc>
	v_mad_i64_i32 v[64:65], null, 0x6000, v120, v[130:131]     // 00000013BCF8: D6FF7C40 060AF0FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 00000013BD04: 1072738B
	global_load_u16 v56, v[64:65], off offset:768              // 00000013BD08: DC4A0300 387C0040
	s_waitcnt vmcnt(0)                                         // 00000013BD10: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000013BD14: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013BD18: BF870121
	v_mul_f32_e32 v64, 0xbfb8aa3b, v56                         // 00000013BD1C: 108070FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000013BD24: 7C3C70FF 42CE8ED0
	v_fma_f32 v65, 0xbfb8aa3b, v56, -v64                       // 00000013BD2C: D6130041 850270FF BFB8AA3B
	v_rndne_f32_e32 v66, v64                                   // 00000013BD38: 7E844740
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013BD3C: BF870112
	v_fmamk_f32 v65, v56, 0xb2a5705f, v65                      // 00000013BD40: 58828338 B2A5705F
	v_sub_f32_e32 v64, v64, v66                                // 00000013BD48: 08808540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013BD4C: BF870121
	v_add_f32_e32 v64, v64, v65                                // 00000013BD50: 06808340
	v_cvt_i32_f32_e32 v65, v66                                 // 00000013BD54: 7E821142
	v_exp_f32_e32 v64, v64                                     // 00000013BD58: 7E804B40
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BD5C: BF870095
	.long 0xd71c0040                                           // 00000013BD60: D71C0040
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                     // 00000013BD64: 02028340
	v_cndmask_b32_e32 v64, 0, v64, vcc_lo                      // 00000013BD68: 02808080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000013BD6C: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BD74: BF870092
	v_cndmask_b32_e32 v56, 0x7f800000, v64, vcc_lo             // 00000013BD78: 027080FF 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000013BD80: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BD84: BF870091
	v_div_scale_f32 v64, null, v56, v56, v57                   // 00000013BD88: D6FC7C40 04E67138
	v_rcp_f32_e32 v65, v64                                     // 00000013BD90: 7E825540
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BD94: BF870095
	v_fma_f32 v66, -v64, v65, 1.0                              // 00000013BD98: D6130042 23CA8340
	v_fmac_f32_e32 v65, v66, v65                               // 00000013BDA0: 56828342
	v_div_scale_f32 v66, vcc_lo, v57, v56, v57                 // 00000013BDA4: D6FC6A42 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BDAC: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 00000013BDB0: 10868342
	v_fma_f32 v68, -v64, v67, v66                              // 00000013BDB4: D6130044 250A8740
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BDBC: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 00000013BDC0: 56868344
	v_fma_f32 v64, -v64, v67, v66                              // 00000013BDC4: D6130040 250A8740
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BDCC: BF870091
	v_div_fmas_f32 v64, v64, v65, v67                          // 00000013BDD0: D6370040 050E8340
	v_div_fixup_f32 v64, v64, v56, v57                         // 00000013BDD8: D6270040 04E67140
	v_mad_i64_i32 v[56:57], null, 0x3000, v120, v[128:129]     // 00000013BDE0: D6FF7C38 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BDEC: BF870092
	v_bfe_u32 v65, v64, 16, 1                                  // 00000013BDF0: D6100041 02052140
	v_add3_u32 v64, v64, v65, 0x7fff                           // 00000013BDF8: D6550040 03FE8340 00007FFF
	global_store_d16_hi_b16 v[56:57], v64, off offset:256      // 00000013BE04: DC960100 007C4038
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013BE0C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000013BE10: BE882002
	s_cbranch_execz 61104                                      // 00000013BE14: BFA5EEB0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40d8>
	v_mad_i64_i32 v[56:57], null, 0x6000, v121, v[130:131]     // 00000013BE18: D6FF7C38 060AF2FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000013BE24: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000013BE2C: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000013BE30: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BE34: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000013BE38: 107270FF BFB8AA3B
	v_fma_f32 v64, 0xbfb8aa3b, v56, -v57                       // 00000013BE40: D6130040 84E670FF BFB8AA3B
	v_rndne_f32_e32 v65, v57                                   // 00000013BE4C: 7E824739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013BE50: BF870221
	v_sub_f32_e32 v57, v57, v65                                // 00000013BE54: 08728339
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000013BE58: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v64, v56, 0xb2a5705f, v64                      // 00000013BE60: 58808138 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013BE68: BF870121
	v_add_f32_e32 v57, v57, v64                                // 00000013BE6C: 06728139
	v_cvt_i32_f32_e32 v64, v65                                 // 00000013BE70: 7E801141
	v_exp_f32_e32 v57, v57                                     // 00000013BE74: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BE78: BF870095
	.long 0xd71c0039                                           // 00000013BE7C: D71C0039
	v_cndmask_b32_e32 v1, v57, v64, vcc_lo                     // 00000013BE80: 02028139
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000013BE84: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000013BE88: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BE90: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v136, v58// 00000013BE94: CA4672FF 38387588 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000013BEA0: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BEA4: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000013BEA8: D6FC7C3A 04E67138
	v_rcp_f32_e32 v64, v58                                     // 00000013BEB0: 7E80553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BEB4: BF870095
	v_fma_f32 v65, -v58, v64, 1.0                              // 00000013BEB8: D6130041 23CA813A
	v_fmac_f32_e32 v64, v65, v64                               // 00000013BEC0: 56808141
	v_div_scale_f32 v65, vcc_lo, v57, v56, v57                 // 00000013BEC4: D6FC6A41 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BECC: BF870091
	v_mul_f32_e32 v66, v65, v64                                // 00000013BED0: 10848141
	v_fma_f32 v67, -v58, v66, v65                              // 00000013BED4: D6130043 2506853A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BEDC: BF870091
	v_fmac_f32_e32 v66, v67, v64                               // 00000013BEE0: 56848143
	v_fma_f32 v58, -v58, v66, v65                              // 00000013BEE4: D613003A 2506853A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BEEC: BF870091
	v_div_fmas_f32 v58, v58, v64, v66                          // 00000013BEF0: D637003A 050A813A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000013BEF8: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v121, v[128:129]     // 00000013BF00: D6FF7C38 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BF0C: BF870092
	v_bfe_u32 v64, v58, 16, 1                                  // 00000013BF10: D6100040 0205213A
	v_add3_u32 v58, v58, v64, 0x7fff                           // 00000013BF18: D655003A 03FE813A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000013BF24: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013BF2C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013BF30: BE882003
	s_cbranch_execz 61035                                      // 00000013BF34: BFA5EE6B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40e4>
	v_mad_i64_i32 v[56:57], null, 0x6000, v122, v[130:131]     // 00000013BF38: D6FF7C38 060AF4FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000013BF44: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000013BF4C: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000013BF50: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BF54: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000013BF58: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000013BF60: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v64, v57                                   // 00000013BF6C: 7E804739
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BF70: BF870091
	v_dual_fmamk_f32 v58, v56, 0xb2a5705f, v58 :: v_dual_sub_f32 v57, v57, v64// 00000013BF74: C88A7538 3A388139 B2A5705F
	v_add_f32_e32 v57, v57, v58                                // 00000013BF80: 06727539
	v_cvt_i32_f32_e32 v58, v64                                 // 00000013BF84: 7E741140
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000013BF88: 7C3C70FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013BF90: BF870293
	v_exp_f32_e32 v57, v57                                     // 00000013BF94: 7E724B39
	.long 0xd71c0039                                           // 00000013BF98: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000013BF9C: 02027539
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013BFA0: BF870121
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000013BFA4: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000013BFA8: 7C3670FF C2B17218
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v137, v59// 00000013BFB0: CA4672FF 38387789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BFBC: BF870091
	v_add_f32_e32 v56, 1.0, v56                                // 00000013BFC0: 067070F2
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000013BFC4: D6FC7C3A 04E67138
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013BFCC: BF870291
	v_rcp_f32_e32 v59, v58                                     // 00000013BFD0: 7E76553A
	v_fma_f32 v64, -v58, v59, 1.0                              // 00000013BFD4: D6130040 23CA773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013BFDC: BF8700A1
	v_fmac_f32_e32 v59, v64, v59                               // 00000013BFE0: 56767740
	v_div_scale_f32 v64, vcc_lo, v57, v56, v57                 // 00000013BFE4: D6FC6A40 04E67139
	v_mul_f32_e32 v65, v64, v59                                // 00000013BFEC: 10827740
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013BFF0: BF870091
	v_fma_f32 v66, -v58, v65, v64                              // 00000013BFF4: D6130042 2502833A
	v_fmac_f32_e32 v65, v66, v59                               // 00000013BFFC: 56827742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C000: BF870091
	v_fma_f32 v58, -v58, v65, v64                              // 00000013C004: D613003A 2502833A
	v_div_fmas_f32 v58, v58, v59, v65                          // 00000013C00C: D637003A 0506773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013C014: BF870121
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000013C018: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v122, v[128:129]     // 00000013C020: D6FF7C38 0602F4FF 00003000
	v_bfe_u32 v59, v58, 16, 1                                  // 00000013C02C: D610003B 0205213A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C034: BF870001
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000013C038: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000013C044: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013C04C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000013C050: BE882004
	s_cbranch_execz 60966                                      // 00000013C054: BFA5EE26 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40f0>
	v_mad_i64_i32 v[56:57], null, 0x6000, v123, v[130:131]     // 00000013C058: D6FF7C38 060AF6FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000013C064: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000013C06C: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000013C070: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C074: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000013C078: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000013C080: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000013C08C: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013C090: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000013C094: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000013C098: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000013C0A0: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013C0A8: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000013C0AC: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000013C0B0: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000013C0B4: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C0B8: BF870095
	.long 0xd71c0039                                           // 00000013C0BC: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000013C0C0: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000013C0C4: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000013C0C8: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C0D0: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v134, v60// 00000013C0D4: CA4672FF 38387986 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000013C0E0: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C0E4: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000013C0E8: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 00000013C0F0: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C0F4: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000013C0F8: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000013C100: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 00000013C104: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C10C: BF870091
	v_mul_f32_e32 v64, v60, v59                                // 00000013C110: 1080773C
	v_fma_f32 v65, -v58, v64, v60                              // 00000013C114: D6130041 24F2813A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C11C: BF870091
	v_fmac_f32_e32 v64, v65, v59                               // 00000013C120: 56807741
	v_fma_f32 v58, -v58, v64, v60                              // 00000013C124: D613003A 24F2813A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C12C: BF870091
	v_div_fmas_f32 v58, v58, v59, v64                          // 00000013C130: D637003A 0502773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000013C138: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v123, v[128:129]     // 00000013C140: D6FF7C38 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C14C: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 00000013C150: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000013C158: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000013C164: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013C16C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000013C170: BE882005
	s_cbranch_execz 60897                                      // 00000013C174: BFA5EDE1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40fc>
	v_mad_i64_i32 v[56:57], null, 0x6000, v124, v[130:131]     // 00000013C178: D6FF7C38 060AF8FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000013C184: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000013C18C: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000013C190: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C194: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000013C198: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000013C1A0: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000013C1AC: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013C1B0: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000013C1B4: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000013C1B8: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000013C1C0: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013C1C8: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000013C1CC: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000013C1D0: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000013C1D4: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C1D8: BF870095
	.long 0xd71c0039                                           // 00000013C1DC: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000013C1E0: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000013C1E4: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000013C1E8: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C1F0: BF870092
	v_cndmask_b32_e32 v56, 0x7f800000, v57, vcc_lo             // 00000013C1F4: 027072FF 7F800000
	v_dual_mul_f32 v57, v135, v61 :: v_dual_add_f32 v56, 1.0, v56// 00000013C1FC: C8C87B87 393870F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C204: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000013C208: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 00000013C210: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C214: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000013C218: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000013C220: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 00000013C224: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C22C: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 00000013C230: 107A773C
	v_fma_f32 v64, -v58, v61, v60                              // 00000013C234: D6130040 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C23C: BF870091
	v_fmac_f32_e32 v61, v64, v59                               // 00000013C240: 567A7740
	v_fma_f32 v58, -v58, v61, v60                              // 00000013C244: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C24C: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 00000013C250: D637003A 04F6773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000013C258: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v124, v[128:129]     // 00000013C260: D6FF7C38 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C26C: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 00000013C270: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000013C278: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000013C284: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013C28C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000013C290: BE882006
	s_cbranch_execz 60828                                      // 00000013C294: BFA5ED9C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4108>
	v_mad_i64_i32 v[56:57], null, 0x6000, v125, v[130:131]     // 00000013C298: D6FF7C38 060AFAFF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000013C2A4: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000013C2AC: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000013C2B0: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C2B4: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000013C2B8: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000013C2C0: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000013C2CC: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013C2D0: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000013C2D4: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000013C2D8: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000013C2E0: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013C2E8: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000013C2EC: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000013C2F0: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000013C2F4: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C2F8: BF870095
	.long 0xd71c0039                                           // 00000013C2FC: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000013C300: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000013C304: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000013C308: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C310: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v132, v62// 00000013C314: CA4672FF 38387D84 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000013C320: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C324: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000013C328: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 00000013C330: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C334: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000013C338: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000013C340: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 00000013C344: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C34C: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 00000013C350: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 00000013C354: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C35C: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 00000013C360: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 00000013C364: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C36C: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 00000013C370: D637003A 04F6773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000013C378: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v125, v[128:129]     // 00000013C380: D6FF7C38 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C38C: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 00000013C390: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000013C398: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000013C3A4: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013C3AC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013C3B0: BE882007
	s_cbranch_execz 60759                                      // 00000013C3B4: BFA5ED57 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4114>
	v_mad_i64_i32 v[56:57], null, 0x6000, v126, v[130:131]     // 00000013C3B8: D6FF7C38 060AFCFF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000013C3C4: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000013C3CC: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000013C3D0: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C3D4: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000013C3D8: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000013C3E0: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000013C3EC: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013C3F0: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000013C3F4: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000013C3F8: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000013C400: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013C408: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000013C40C: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000013C410: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000013C414: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C418: BF870095
	.long 0xd71c0039                                           // 00000013C41C: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000013C420: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000013C424: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000013C428: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C430: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v133, v63// 00000013C434: CA4672FF 38387F85 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000013C440: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C444: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000013C448: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 00000013C450: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C454: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000013C458: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000013C460: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 00000013C464: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C46C: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 00000013C470: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 00000013C474: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C47C: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 00000013C480: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 00000013C484: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C48C: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 00000013C490: D637003A 04F6773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000013C498: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v126, v[128:129]     // 00000013C4A0: D6FF7C38 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C4AC: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 00000013C4B0: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000013C4B8: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000013C4C4: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013C4CC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000013C4D0: BE882000
	s_cbranch_execz 60690                                      // 00000013C4D4: BFA5ED12 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4120>
	v_mad_i64_i32 v[56:57], null, 0x6000, v140, v[130:131]     // 00000013C4D8: D6FF7C38 060B18FF 00006000
	v_mul_f32_e32 v48, v138, v48                               // 00000013C4E4: 1060618A
	global_load_u16 v56, v[56:57], off offset:800              // 00000013C4E8: DC4A0320 387C0038
	s_waitcnt vmcnt(0)                                         // 00000013C4F0: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000013C4F4: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C4F8: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000013C4FC: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000013C504: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000013C510: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013C514: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000013C518: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000013C51C: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000013C524: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013C52C: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000013C530: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000013C534: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000013C538: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C53C: BF870095
	.long 0xd71c0039                                           // 00000013C540: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000013C544: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000013C548: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000013C54C: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C554: BF870092
	v_cndmask_b32_e32 v56, 0x7f800000, v57, vcc_lo             // 00000013C558: 027072FF 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000013C560: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C564: BF870091
	v_div_scale_f32 v57, null, v56, v56, v48                   // 00000013C568: D6FC7C39 04C27138
	v_rcp_f32_e32 v58, v57                                     // 00000013C570: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C574: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 00000013C578: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 00000013C580: 5674753B
	v_div_scale_f32 v59, vcc_lo, v48, v56, v48                 // 00000013C584: D6FC6A3B 04C27130
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C58C: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 00000013C590: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 00000013C594: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C59C: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 00000013C5A0: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 00000013C5A4: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C5AC: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 00000013C5B0: D6370039 04F27539
	v_div_fixup_f32 v48, v57, v56, v48                         // 00000013C5B8: D6270030 04C27139
	v_mad_i64_i32 v[56:57], null, 0x3000, v140, v[128:129]     // 00000013C5C0: D6FF7C38 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C5CC: BF870092
	v_bfe_u32 v58, v48, 16, 1                                  // 00000013C5D0: D610003A 02052130
	v_add3_u32 v48, v48, v58, 0x7fff                           // 00000013C5D8: D6550030 03FE7530 00007FFF
	global_store_d16_hi_b16 v[56:57], v48, off offset:288      // 00000013C5E4: DC960120 007C3038
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013C5EC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000013C5F0: BE882001
	s_cbranch_execz 60621                                      // 00000013C5F4: BFA5ECCD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x412c>
	v_mad_i64_i32 v[56:57], null, 0x6000, v120, v[130:131]     // 00000013C5F8: D6FF7C38 060AF0FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 00000013C604: 1062638B
	global_load_u16 v48, v[56:57], off offset:800              // 00000013C608: DC4A0320 307C0038
	s_waitcnt vmcnt(0)                                         // 00000013C610: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000013C614: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013C618: BF870121
	v_mul_f32_e32 v56, 0xbfb8aa3b, v48                         // 00000013C61C: 107060FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000013C624: 7C3C60FF 42CE8ED0
	v_fma_f32 v57, 0xbfb8aa3b, v48, -v56                       // 00000013C62C: D6130039 84E260FF BFB8AA3B
	v_rndne_f32_e32 v58, v56                                   // 00000013C638: 7E744738
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013C63C: BF870112
	v_fmamk_f32 v57, v48, 0xb2a5705f, v57                      // 00000013C640: 58727330 B2A5705F
	v_sub_f32_e32 v56, v56, v58                                // 00000013C648: 08707538
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013C64C: BF870121
	v_add_f32_e32 v56, v56, v57                                // 00000013C650: 06707338
	v_cvt_i32_f32_e32 v57, v58                                 // 00000013C654: 7E72113A
	v_exp_f32_e32 v56, v56                                     // 00000013C658: 7E704B38
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C65C: BF870095
	.long 0xd71c0038                                           // 00000013C660: D71C0038
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                     // 00000013C664: 02027338
	v_cndmask_b32_e32 v56, 0, v56, vcc_lo                      // 00000013C668: 02707080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000013C66C: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C674: BF870092
	v_cndmask_b32_e32 v48, 0x7f800000, v56, vcc_lo             // 00000013C678: 026070FF 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000013C680: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C684: BF870091
	v_div_scale_f32 v56, null, v48, v48, v49                   // 00000013C688: D6FC7C38 04C66130
	v_rcp_f32_e32 v57, v56                                     // 00000013C690: 7E725538
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C694: BF870095
	v_fma_f32 v58, -v56, v57, 1.0                              // 00000013C698: D613003A 23CA7338
	v_fmac_f32_e32 v57, v58, v57                               // 00000013C6A0: 5672733A
	v_div_scale_f32 v58, vcc_lo, v49, v48, v49                 // 00000013C6A4: D6FC6A3A 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C6AC: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 00000013C6B0: 1076733A
	v_fma_f32 v60, -v56, v59, v58                              // 00000013C6B4: D613003C 24EA7738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C6BC: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 00000013C6C0: 5676733C
	v_fma_f32 v56, -v56, v59, v58                              // 00000013C6C4: D6130038 24EA7738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C6CC: BF870091
	v_div_fmas_f32 v56, v56, v57, v59                          // 00000013C6D0: D6370038 04EE7338
	v_div_fixup_f32 v56, v56, v48, v49                         // 00000013C6D8: D6270038 04C66138
	v_mad_i64_i32 v[48:49], null, 0x3000, v120, v[128:129]     // 00000013C6E0: D6FF7C30 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C6EC: BF870092
	v_bfe_u32 v57, v56, 16, 1                                  // 00000013C6F0: D6100039 02052138
	v_add3_u32 v56, v56, v57, 0x7fff                           // 00000013C6F8: D6550038 03FE7338 00007FFF
	global_store_d16_hi_b16 v[48:49], v56, off offset:288      // 00000013C704: DC960120 007C3830
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013C70C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000013C710: BE882002
	s_cbranch_execz 60552                                      // 00000013C714: BFA5EC88 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4138>
	v_mad_i64_i32 v[48:49], null, 0x6000, v121, v[130:131]     // 00000013C718: D6FF7C30 060AF2FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000013C724: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000013C72C: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000013C730: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C734: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000013C738: 106260FF BFB8AA3B
	v_fma_f32 v56, 0xbfb8aa3b, v48, -v49                       // 00000013C740: D6130038 84C660FF BFB8AA3B
	v_rndne_f32_e32 v57, v49                                   // 00000013C74C: 7E724731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013C750: BF870221
	v_sub_f32_e32 v49, v49, v57                                // 00000013C754: 08627331
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000013C758: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v56, v48, 0xb2a5705f, v56                      // 00000013C760: 58707130 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013C768: BF870121
	v_add_f32_e32 v49, v49, v56                                // 00000013C76C: 06627131
	v_cvt_i32_f32_e32 v56, v57                                 // 00000013C770: 7E701139
	v_exp_f32_e32 v49, v49                                     // 00000013C774: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C778: BF870095
	.long 0xd71c0031                                           // 00000013C77C: D71C0031
	v_cndmask_b32_e32 v1, v49, v56, vcc_lo                     // 00000013C780: 02027131
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000013C784: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000013C788: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C790: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v136, v50// 00000013C794: CA4662FF 30306588 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000013C7A0: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C7A4: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000013C7A8: D6FC7C32 04C66130
	v_rcp_f32_e32 v56, v50                                     // 00000013C7B0: 7E705532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C7B4: BF870095
	v_fma_f32 v57, -v50, v56, 1.0                              // 00000013C7B8: D6130039 23CA7132
	v_fmac_f32_e32 v56, v57, v56                               // 00000013C7C0: 56707139
	v_div_scale_f32 v57, vcc_lo, v49, v48, v49                 // 00000013C7C4: D6FC6A39 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C7CC: BF870091
	v_mul_f32_e32 v58, v57, v56                                // 00000013C7D0: 10747139
	v_fma_f32 v59, -v50, v58, v57                              // 00000013C7D4: D613003B 24E67532
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C7DC: BF870091
	v_fmac_f32_e32 v58, v59, v56                               // 00000013C7E0: 5674713B
	v_fma_f32 v50, -v50, v58, v57                              // 00000013C7E4: D6130032 24E67532
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C7EC: BF870091
	v_div_fmas_f32 v50, v50, v56, v58                          // 00000013C7F0: D6370032 04EA7132
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000013C7F8: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v121, v[128:129]     // 00000013C800: D6FF7C30 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C80C: BF870092
	v_bfe_u32 v56, v50, 16, 1                                  // 00000013C810: D6100038 02052132
	v_add3_u32 v50, v50, v56, 0x7fff                           // 00000013C818: D6550032 03FE7132 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000013C824: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013C82C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013C830: BE882003
	s_cbranch_execz 60483                                      // 00000013C834: BFA5EC43 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4144>
	v_mad_i64_i32 v[48:49], null, 0x6000, v122, v[130:131]     // 00000013C838: D6FF7C30 060AF4FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000013C844: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000013C84C: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000013C850: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C854: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000013C858: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000013C860: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v56, v49                                   // 00000013C86C: 7E704731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C870: BF870091
	v_dual_fmamk_f32 v50, v48, 0xb2a5705f, v50 :: v_dual_sub_f32 v49, v49, v56// 00000013C874: C88A6530 32307131 B2A5705F
	v_add_f32_e32 v49, v49, v50                                // 00000013C880: 06626531
	v_cvt_i32_f32_e32 v50, v56                                 // 00000013C884: 7E641138
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000013C888: 7C3C60FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013C890: BF870293
	v_exp_f32_e32 v49, v49                                     // 00000013C894: 7E624B31
	.long 0xd71c0031                                           // 00000013C898: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000013C89C: 02026531
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013C8A0: BF870121
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000013C8A4: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000013C8A8: 7C3660FF C2B17218
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v137, v51// 00000013C8B0: CA4662FF 30306789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C8BC: BF870091
	v_add_f32_e32 v48, 1.0, v48                                // 00000013C8C0: 066060F2
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000013C8C4: D6FC7C32 04C66130
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013C8CC: BF870291
	v_rcp_f32_e32 v51, v50                                     // 00000013C8D0: 7E665532
	v_fma_f32 v56, -v50, v51, 1.0                              // 00000013C8D4: D6130038 23CA6732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013C8DC: BF8700A1
	v_fmac_f32_e32 v51, v56, v51                               // 00000013C8E0: 56666738
	v_div_scale_f32 v56, vcc_lo, v49, v48, v49                 // 00000013C8E4: D6FC6A38 04C66131
	v_mul_f32_e32 v57, v56, v51                                // 00000013C8EC: 10726738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C8F0: BF870091
	v_fma_f32 v58, -v50, v57, v56                              // 00000013C8F4: D613003A 24E27332
	v_fmac_f32_e32 v57, v58, v51                               // 00000013C8FC: 5672673A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C900: BF870091
	v_fma_f32 v50, -v50, v57, v56                              // 00000013C904: D6130032 24E27332
	v_div_fmas_f32 v50, v50, v51, v57                          // 00000013C90C: D6370032 04E66732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013C914: BF870121
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000013C918: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v122, v[128:129]     // 00000013C920: D6FF7C30 0602F4FF 00003000
	v_bfe_u32 v51, v50, 16, 1                                  // 00000013C92C: D6100033 02052132
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C934: BF870001
	v_add3_u32 v50, v50, v51, 0x7fff                           // 00000013C938: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000013C944: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013C94C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000013C950: BE882004
	s_cbranch_execz 60414                                      // 00000013C954: BFA5EBFE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4150>
	v_mad_i64_i32 v[48:49], null, 0x6000, v123, v[130:131]     // 00000013C958: D6FF7C30 060AF6FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000013C964: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000013C96C: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000013C970: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C974: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000013C978: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000013C980: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000013C98C: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013C990: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 00000013C994: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000013C998: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 00000013C9A0: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013C9A8: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000013C9AC: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000013C9B0: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000013C9B4: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C9B8: BF870095
	.long 0xd71c0031                                           // 00000013C9BC: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000013C9C0: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000013C9C4: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000013C9C8: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C9D0: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v134, v52// 00000013C9D4: CA4662FF 30306986 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000013C9E0: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C9E4: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000013C9E8: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 00000013C9F0: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013C9F4: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000013C9F8: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000013CA00: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 00000013CA04: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CA0C: BF870091
	v_mul_f32_e32 v56, v52, v51                                // 00000013CA10: 10706734
	v_fma_f32 v57, -v50, v56, v52                              // 00000013CA14: D6130039 24D27132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CA1C: BF870091
	v_fmac_f32_e32 v56, v57, v51                               // 00000013CA20: 56706739
	v_fma_f32 v50, -v50, v56, v52                              // 00000013CA24: D6130032 24D27132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CA2C: BF870091
	v_div_fmas_f32 v50, v50, v51, v56                          // 00000013CA30: D6370032 04E26732
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000013CA38: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v123, v[128:129]     // 00000013CA40: D6FF7C30 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CA4C: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 00000013CA50: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 00000013CA58: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000013CA64: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013CA6C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000013CA70: BE882005
	s_cbranch_execz 60345                                      // 00000013CA74: BFA5EBB9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x415c>
	v_mad_i64_i32 v[48:49], null, 0x6000, v124, v[130:131]     // 00000013CA78: D6FF7C30 060AF8FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000013CA84: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000013CA8C: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000013CA90: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CA94: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000013CA98: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000013CAA0: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000013CAAC: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013CAB0: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 00000013CAB4: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000013CAB8: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 00000013CAC0: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013CAC8: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000013CACC: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000013CAD0: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000013CAD4: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CAD8: BF870095
	.long 0xd71c0031                                           // 00000013CADC: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000013CAE0: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000013CAE4: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000013CAE8: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CAF0: BF870092
	v_cndmask_b32_e32 v48, 0x7f800000, v49, vcc_lo             // 00000013CAF4: 026062FF 7F800000
	v_dual_mul_f32 v49, v135, v53 :: v_dual_add_f32 v48, 1.0, v48// 00000013CAFC: C8C86B87 313060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CB04: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000013CB08: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 00000013CB10: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CB14: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000013CB18: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000013CB20: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 00000013CB24: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CB2C: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 00000013CB30: 106A6734
	v_fma_f32 v56, -v50, v53, v52                              // 00000013CB34: D6130038 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CB3C: BF870091
	v_fmac_f32_e32 v53, v56, v51                               // 00000013CB40: 566A6738
	v_fma_f32 v50, -v50, v53, v52                              // 00000013CB44: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CB4C: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 00000013CB50: D6370032 04D66732
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000013CB58: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v124, v[128:129]     // 00000013CB60: D6FF7C30 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CB6C: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 00000013CB70: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 00000013CB78: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000013CB84: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013CB8C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000013CB90: BE882006
	s_cbranch_execz 60276                                      // 00000013CB94: BFA5EB74 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4168>
	v_mad_i64_i32 v[48:49], null, 0x6000, v125, v[130:131]     // 00000013CB98: D6FF7C30 060AFAFF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000013CBA4: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000013CBAC: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000013CBB0: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CBB4: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000013CBB8: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000013CBC0: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000013CBCC: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013CBD0: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 00000013CBD4: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000013CBD8: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 00000013CBE0: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013CBE8: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000013CBEC: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000013CBF0: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000013CBF4: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CBF8: BF870095
	.long 0xd71c0031                                           // 00000013CBFC: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000013CC00: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000013CC04: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000013CC08: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CC10: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v132, v54// 00000013CC14: CA4662FF 30306D84 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000013CC20: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CC24: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000013CC28: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 00000013CC30: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CC34: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000013CC38: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000013CC40: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 00000013CC44: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CC4C: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 00000013CC50: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 00000013CC54: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CC5C: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 00000013CC60: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 00000013CC64: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CC6C: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 00000013CC70: D6370032 04D66732
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000013CC78: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v125, v[128:129]     // 00000013CC80: D6FF7C30 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CC8C: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 00000013CC90: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 00000013CC98: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000013CCA4: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013CCAC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013CCB0: BE882007
	s_cbranch_execz 60207                                      // 00000013CCB4: BFA5EB2F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4174>
	v_mad_i64_i32 v[48:49], null, 0x6000, v126, v[130:131]     // 00000013CCB8: D6FF7C30 060AFCFF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000013CCC4: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000013CCCC: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000013CCD0: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CCD4: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000013CCD8: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000013CCE0: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000013CCEC: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013CCF0: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 00000013CCF4: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000013CCF8: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 00000013CD00: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013CD08: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000013CD0C: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000013CD10: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000013CD14: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CD18: BF870095
	.long 0xd71c0031                                           // 00000013CD1C: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000013CD20: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000013CD24: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000013CD28: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CD30: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v133, v55// 00000013CD34: CA4662FF 30306F85 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000013CD40: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CD44: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000013CD48: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 00000013CD50: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CD54: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000013CD58: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000013CD60: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 00000013CD64: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CD6C: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 00000013CD70: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 00000013CD74: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CD7C: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 00000013CD80: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 00000013CD84: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CD8C: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 00000013CD90: D6370032 04D66732
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000013CD98: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v126, v[128:129]     // 00000013CDA0: D6FF7C30 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CDAC: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 00000013CDB0: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 00000013CDB8: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000013CDC4: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013CDCC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000013CDD0: BE882000
	s_cbranch_execz 60138                                      // 00000013CDD4: BFA5EAEA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4180>
	v_mad_i64_i32 v[48:49], null, 0x6000, v140, v[130:131]     // 00000013CDD8: D6FF7C30 060B18FF 00006000
	v_mul_f32_e32 v40, v138, v40                               // 00000013CDE4: 1050518A
	global_load_u16 v48, v[48:49], off offset:832              // 00000013CDE8: DC4A0340 307C0030
	s_waitcnt vmcnt(0)                                         // 00000013CDF0: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000013CDF4: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CDF8: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000013CDFC: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000013CE04: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000013CE10: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013CE14: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 00000013CE18: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000013CE1C: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 00000013CE24: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013CE2C: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000013CE30: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000013CE34: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000013CE38: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CE3C: BF870095
	.long 0xd71c0031                                           // 00000013CE40: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000013CE44: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000013CE48: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000013CE4C: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CE54: BF870092
	v_cndmask_b32_e32 v48, 0x7f800000, v49, vcc_lo             // 00000013CE58: 026062FF 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000013CE60: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CE64: BF870091
	v_div_scale_f32 v49, null, v48, v48, v40                   // 00000013CE68: D6FC7C31 04A26130
	v_rcp_f32_e32 v50, v49                                     // 00000013CE70: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CE74: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 00000013CE78: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 00000013CE80: 56646533
	v_div_scale_f32 v51, vcc_lo, v40, v48, v40                 // 00000013CE84: D6FC6A33 04A26128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CE8C: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 00000013CE90: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 00000013CE94: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CE9C: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 00000013CEA0: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 00000013CEA4: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CEAC: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 00000013CEB0: D6370031 04D26531
	v_div_fixup_f32 v40, v49, v48, v40                         // 00000013CEB8: D6270028 04A26131
	v_mad_i64_i32 v[48:49], null, 0x3000, v140, v[128:129]     // 00000013CEC0: D6FF7C30 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CECC: BF870092
	v_bfe_u32 v50, v40, 16, 1                                  // 00000013CED0: D6100032 02052128
	v_add3_u32 v40, v40, v50, 0x7fff                           // 00000013CED8: D6550028 03FE6528 00007FFF
	global_store_d16_hi_b16 v[48:49], v40, off offset:320      // 00000013CEE4: DC960140 007C2830
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013CEEC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000013CEF0: BE882001
	s_cbranch_execz 60069                                      // 00000013CEF4: BFA5EAA5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x418c>
	v_mad_i64_i32 v[48:49], null, 0x6000, v120, v[130:131]     // 00000013CEF8: D6FF7C30 060AF0FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 00000013CF04: 1052538B
	global_load_u16 v40, v[48:49], off offset:832              // 00000013CF08: DC4A0340 287C0030
	s_waitcnt vmcnt(0)                                         // 00000013CF10: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000013CF14: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013CF18: BF870121
	v_mul_f32_e32 v48, 0xbfb8aa3b, v40                         // 00000013CF1C: 106050FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000013CF24: 7C3C50FF 42CE8ED0
	v_fma_f32 v49, 0xbfb8aa3b, v40, -v48                       // 00000013CF2C: D6130031 84C250FF BFB8AA3B
	v_rndne_f32_e32 v50, v48                                   // 00000013CF38: 7E644730
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013CF3C: BF870112
	v_fmamk_f32 v49, v40, 0xb2a5705f, v49                      // 00000013CF40: 58626328 B2A5705F
	v_sub_f32_e32 v48, v48, v50                                // 00000013CF48: 08606530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013CF4C: BF870121
	v_add_f32_e32 v48, v48, v49                                // 00000013CF50: 06606330
	v_cvt_i32_f32_e32 v49, v50                                 // 00000013CF54: 7E621132
	v_exp_f32_e32 v48, v48                                     // 00000013CF58: 7E604B30
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CF5C: BF870095
	.long 0xd71c0030                                           // 00000013CF60: D71C0030
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                     // 00000013CF64: 02026330
	v_cndmask_b32_e32 v48, 0, v48, vcc_lo                      // 00000013CF68: 02606080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000013CF6C: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CF74: BF870092
	v_cndmask_b32_e32 v40, 0x7f800000, v48, vcc_lo             // 00000013CF78: 025060FF 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000013CF80: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CF84: BF870091
	v_div_scale_f32 v48, null, v40, v40, v41                   // 00000013CF88: D6FC7C30 04A65128
	v_rcp_f32_e32 v49, v48                                     // 00000013CF90: 7E625530
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CF94: BF870095
	v_fma_f32 v50, -v48, v49, 1.0                              // 00000013CF98: D6130032 23CA6330
	v_fmac_f32_e32 v49, v50, v49                               // 00000013CFA0: 56626332
	v_div_scale_f32 v50, vcc_lo, v41, v40, v41                 // 00000013CFA4: D6FC6A32 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CFAC: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 00000013CFB0: 10666332
	v_fma_f32 v52, -v48, v51, v50                              // 00000013CFB4: D6130034 24CA6730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CFBC: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 00000013CFC0: 56666334
	v_fma_f32 v48, -v48, v51, v50                              // 00000013CFC4: D6130030 24CA6730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CFCC: BF870091
	v_div_fmas_f32 v48, v48, v49, v51                          // 00000013CFD0: D6370030 04CE6330
	v_div_fixup_f32 v48, v48, v40, v41                         // 00000013CFD8: D6270030 04A65130
	v_mad_i64_i32 v[40:41], null, 0x3000, v120, v[128:129]     // 00000013CFE0: D6FF7C28 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CFEC: BF870092
	v_bfe_u32 v49, v48, 16, 1                                  // 00000013CFF0: D6100031 02052130
	v_add3_u32 v48, v48, v49, 0x7fff                           // 00000013CFF8: D6550030 03FE6330 00007FFF
	global_store_d16_hi_b16 v[40:41], v48, off offset:320      // 00000013D004: DC960140 007C3028
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013D00C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000013D010: BE882002
	s_cbranch_execz 60000                                      // 00000013D014: BFA5EA60 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4198>
	v_mad_i64_i32 v[40:41], null, 0x6000, v121, v[130:131]     // 00000013D018: D6FF7C28 060AF2FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 00000013D024: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 00000013D02C: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000013D030: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D034: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 00000013D038: 105250FF BFB8AA3B
	v_fma_f32 v48, 0xbfb8aa3b, v40, -v41                       // 00000013D040: D6130030 84A650FF BFB8AA3B
	v_rndne_f32_e32 v49, v41                                   // 00000013D04C: 7E624729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013D050: BF870221
	v_sub_f32_e32 v41, v41, v49                                // 00000013D054: 08526329
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000013D058: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v48, v40, 0xb2a5705f, v48                      // 00000013D060: 58606128 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013D068: BF870121
	v_add_f32_e32 v41, v41, v48                                // 00000013D06C: 06526129
	v_cvt_i32_f32_e32 v48, v49                                 // 00000013D070: 7E601131
	v_exp_f32_e32 v41, v41                                     // 00000013D074: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D078: BF870095
	.long 0xd71c0029                                           // 00000013D07C: D71C0029
	v_cndmask_b32_e32 v1, v41, v48, vcc_lo                     // 00000013D080: 02026129
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000013D084: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000013D088: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D090: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v136, v42// 00000013D094: CA4652FF 28285588 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000013D0A0: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D0A4: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 00000013D0A8: D6FC7C2A 04A65128
	v_rcp_f32_e32 v48, v42                                     // 00000013D0B0: 7E60552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D0B4: BF870095
	v_fma_f32 v49, -v42, v48, 1.0                              // 00000013D0B8: D6130031 23CA612A
	v_fmac_f32_e32 v48, v49, v48                               // 00000013D0C0: 56606131
	v_div_scale_f32 v49, vcc_lo, v41, v40, v41                 // 00000013D0C4: D6FC6A31 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D0CC: BF870091
	v_mul_f32_e32 v50, v49, v48                                // 00000013D0D0: 10646131
	v_fma_f32 v51, -v42, v50, v49                              // 00000013D0D4: D6130033 24C6652A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D0DC: BF870091
	v_fmac_f32_e32 v50, v51, v48                               // 00000013D0E0: 56646133
	v_fma_f32 v42, -v42, v50, v49                              // 00000013D0E4: D613002A 24C6652A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D0EC: BF870091
	v_div_fmas_f32 v42, v42, v48, v50                          // 00000013D0F0: D637002A 04CA612A
	v_div_fixup_f32 v42, v42, v40, v41                         // 00000013D0F8: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v121, v[128:129]     // 00000013D100: D6FF7C28 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D10C: BF870092
	v_bfe_u32 v48, v42, 16, 1                                  // 00000013D110: D6100030 0205212A
	v_add3_u32 v42, v42, v48, 0x7fff                           // 00000013D118: D655002A 03FE612A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 00000013D124: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013D12C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013D130: BE882003
	s_cbranch_execz 59931                                      // 00000013D134: BFA5EA1B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41a4>
	v_mad_i64_i32 v[40:41], null, 0x6000, v122, v[130:131]     // 00000013D138: D6FF7C28 060AF4FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 00000013D144: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 00000013D14C: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000013D150: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D154: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 00000013D158: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 00000013D160: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v48, v41                                   // 00000013D16C: 7E604729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D170: BF870091
	v_dual_fmamk_f32 v42, v40, 0xb2a5705f, v42 :: v_dual_sub_f32 v41, v41, v48// 00000013D174: C88A5528 2A286129 B2A5705F
	v_add_f32_e32 v41, v41, v42                                // 00000013D180: 06525529
	v_cvt_i32_f32_e32 v42, v48                                 // 00000013D184: 7E541130
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000013D188: 7C3C50FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013D190: BF870293
	v_exp_f32_e32 v41, v41                                     // 00000013D194: 7E524B29
	.long 0xd71c0029                                           // 00000013D198: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000013D19C: 02025529
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013D1A0: BF870121
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000013D1A4: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000013D1A8: 7C3650FF C2B17218
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v137, v43// 00000013D1B0: CA4652FF 28285789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D1BC: BF870091
	v_add_f32_e32 v40, 1.0, v40                                // 00000013D1C0: 065050F2
	v_div_scale_f32 v42, null, v40, v40, v41                   // 00000013D1C4: D6FC7C2A 04A65128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013D1CC: BF870291
	v_rcp_f32_e32 v43, v42                                     // 00000013D1D0: 7E56552A
	v_fma_f32 v48, -v42, v43, 1.0                              // 00000013D1D4: D6130030 23CA572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013D1DC: BF8700A1
	v_fmac_f32_e32 v43, v48, v43                               // 00000013D1E0: 56565730
	v_div_scale_f32 v48, vcc_lo, v41, v40, v41                 // 00000013D1E4: D6FC6A30 04A65129
	v_mul_f32_e32 v49, v48, v43                                // 00000013D1EC: 10625730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D1F0: BF870091
	v_fma_f32 v50, -v42, v49, v48                              // 00000013D1F4: D6130032 24C2632A
	v_fmac_f32_e32 v49, v50, v43                               // 00000013D1FC: 56625732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D200: BF870091
	v_fma_f32 v42, -v42, v49, v48                              // 00000013D204: D613002A 24C2632A
	v_div_fmas_f32 v42, v42, v43, v49                          // 00000013D20C: D637002A 04C6572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013D214: BF870121
	v_div_fixup_f32 v42, v42, v40, v41                         // 00000013D218: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v122, v[128:129]     // 00000013D220: D6FF7C28 0602F4FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 00000013D22C: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D234: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000013D238: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 00000013D244: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013D24C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000013D250: BE882004
	s_cbranch_execz 59862                                      // 00000013D254: BFA5E9D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41b0>
	v_mad_i64_i32 v[40:41], null, 0x6000, v123, v[130:131]     // 00000013D258: D6FF7C28 060AF6FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 00000013D264: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 00000013D26C: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000013D270: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D274: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 00000013D278: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 00000013D280: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000013D28C: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013D290: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 00000013D294: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000013D298: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 00000013D2A0: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013D2A8: BF870121
	v_add_f32_e32 v41, v41, v42                                // 00000013D2AC: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000013D2B0: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000013D2B4: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D2B8: BF870095
	.long 0xd71c0029                                           // 00000013D2BC: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000013D2C0: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000013D2C4: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000013D2C8: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D2D0: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v134, v44// 00000013D2D4: CA4652FF 28285986 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000013D2E0: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D2E4: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 00000013D2E8: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 00000013D2F0: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D2F4: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 00000013D2F8: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000013D300: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 00000013D304: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D30C: BF870091
	v_mul_f32_e32 v48, v44, v43                                // 00000013D310: 1060572C
	v_fma_f32 v49, -v42, v48, v44                              // 00000013D314: D6130031 24B2612A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D31C: BF870091
	v_fmac_f32_e32 v48, v49, v43                               // 00000013D320: 56605731
	v_fma_f32 v42, -v42, v48, v44                              // 00000013D324: D613002A 24B2612A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D32C: BF870091
	v_div_fmas_f32 v42, v42, v43, v48                          // 00000013D330: D637002A 04C2572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 00000013D338: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v123, v[128:129]     // 00000013D340: D6FF7C28 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D34C: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 00000013D350: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000013D358: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 00000013D364: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013D36C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000013D370: BE882005
	s_cbranch_execz 59793                                      // 00000013D374: BFA5E991 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41bc>
	v_mad_i64_i32 v[40:41], null, 0x6000, v124, v[130:131]     // 00000013D378: D6FF7C28 060AF8FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 00000013D384: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 00000013D38C: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000013D390: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D394: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 00000013D398: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 00000013D3A0: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000013D3AC: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013D3B0: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 00000013D3B4: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000013D3B8: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 00000013D3C0: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013D3C8: BF870121
	v_add_f32_e32 v41, v41, v42                                // 00000013D3CC: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000013D3D0: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000013D3D4: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D3D8: BF870095
	.long 0xd71c0029                                           // 00000013D3DC: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000013D3E0: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000013D3E4: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000013D3E8: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D3F0: BF870092
	v_cndmask_b32_e32 v40, 0x7f800000, v41, vcc_lo             // 00000013D3F4: 025052FF 7F800000
	v_dual_mul_f32 v41, v135, v45 :: v_dual_add_f32 v40, 1.0, v40// 00000013D3FC: C8C85B87 292850F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D404: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 00000013D408: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 00000013D410: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D414: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 00000013D418: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000013D420: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 00000013D424: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D42C: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 00000013D430: 105A572C
	v_fma_f32 v48, -v42, v45, v44                              // 00000013D434: D6130030 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D43C: BF870091
	v_fmac_f32_e32 v45, v48, v43                               // 00000013D440: 565A5730
	v_fma_f32 v42, -v42, v45, v44                              // 00000013D444: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D44C: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 00000013D450: D637002A 04B6572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 00000013D458: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v124, v[128:129]     // 00000013D460: D6FF7C28 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D46C: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 00000013D470: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000013D478: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 00000013D484: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013D48C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000013D490: BE882006
	s_cbranch_execz 59724                                      // 00000013D494: BFA5E94C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41c8>
	v_mad_i64_i32 v[40:41], null, 0x6000, v125, v[130:131]     // 00000013D498: D6FF7C28 060AFAFF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 00000013D4A4: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 00000013D4AC: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000013D4B0: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D4B4: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 00000013D4B8: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 00000013D4C0: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000013D4CC: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013D4D0: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 00000013D4D4: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000013D4D8: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 00000013D4E0: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013D4E8: BF870121
	v_add_f32_e32 v41, v41, v42                                // 00000013D4EC: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000013D4F0: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000013D4F4: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D4F8: BF870095
	.long 0xd71c0029                                           // 00000013D4FC: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000013D500: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000013D504: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000013D508: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D510: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v132, v46// 00000013D514: CA4652FF 28285D84 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000013D520: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D524: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 00000013D528: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 00000013D530: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D534: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 00000013D538: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000013D540: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 00000013D544: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D54C: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 00000013D550: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 00000013D554: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D55C: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 00000013D560: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 00000013D564: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D56C: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 00000013D570: D637002A 04B6572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 00000013D578: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v125, v[128:129]     // 00000013D580: D6FF7C28 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D58C: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 00000013D590: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000013D598: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 00000013D5A4: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013D5AC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013D5B0: BE882007
	s_cbranch_execz 59655                                      // 00000013D5B4: BFA5E907 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41d4>
	v_mad_i64_i32 v[40:41], null, 0x6000, v126, v[130:131]     // 00000013D5B8: D6FF7C28 060AFCFF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 00000013D5C4: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 00000013D5CC: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000013D5D0: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D5D4: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 00000013D5D8: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 00000013D5E0: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000013D5EC: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013D5F0: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 00000013D5F4: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000013D5F8: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 00000013D600: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013D608: BF870121
	v_add_f32_e32 v41, v41, v42                                // 00000013D60C: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000013D610: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000013D614: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D618: BF870095
	.long 0xd71c0029                                           // 00000013D61C: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000013D620: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000013D624: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000013D628: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D630: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v133, v47// 00000013D634: CA4652FF 28285F85 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000013D640: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D644: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 00000013D648: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 00000013D650: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D654: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 00000013D658: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000013D660: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 00000013D664: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D66C: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 00000013D670: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 00000013D674: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D67C: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 00000013D680: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 00000013D684: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D68C: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 00000013D690: D637002A 04B6572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 00000013D698: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v126, v[128:129]     // 00000013D6A0: D6FF7C28 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D6AC: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 00000013D6B0: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000013D6B8: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 00000013D6C4: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013D6CC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000013D6D0: BE882000
	s_cbranch_execz 59586                                      // 00000013D6D4: BFA5E8C2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41e0>
	v_mad_i64_i32 v[40:41], null, 0x6000, v140, v[130:131]     // 00000013D6D8: D6FF7C28 060B18FF 00006000
	v_mul_f32_e32 v32, v138, v32                               // 00000013D6E4: 1040418A
	global_load_u16 v40, v[40:41], off offset:864              // 00000013D6E8: DC4A0360 287C0028
	s_waitcnt vmcnt(0)                                         // 00000013D6F0: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000013D6F4: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D6F8: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 00000013D6FC: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 00000013D704: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000013D710: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013D714: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 00000013D718: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000013D71C: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 00000013D724: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013D72C: BF870121
	v_add_f32_e32 v41, v41, v42                                // 00000013D730: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000013D734: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000013D738: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D73C: BF870095
	.long 0xd71c0029                                           // 00000013D740: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000013D744: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000013D748: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000013D74C: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D754: BF870092
	v_cndmask_b32_e32 v40, 0x7f800000, v41, vcc_lo             // 00000013D758: 025052FF 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000013D760: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D764: BF870091
	v_div_scale_f32 v41, null, v40, v40, v32                   // 00000013D768: D6FC7C29 04825128
	v_rcp_f32_e32 v42, v41                                     // 00000013D770: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D774: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 00000013D778: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 00000013D780: 5654552B
	v_div_scale_f32 v43, vcc_lo, v32, v40, v32                 // 00000013D784: D6FC6A2B 04825120
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D78C: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 00000013D790: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 00000013D794: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D79C: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 00000013D7A0: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 00000013D7A4: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D7AC: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 00000013D7B0: D6370029 04B25529
	v_div_fixup_f32 v32, v41, v40, v32                         // 00000013D7B8: D6270020 04825129
	v_mad_i64_i32 v[40:41], null, 0x3000, v140, v[128:129]     // 00000013D7C0: D6FF7C28 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D7CC: BF870092
	v_bfe_u32 v42, v32, 16, 1                                  // 00000013D7D0: D610002A 02052120
	v_add3_u32 v32, v32, v42, 0x7fff                           // 00000013D7D8: D6550020 03FE5520 00007FFF
	global_store_d16_hi_b16 v[40:41], v32, off offset:352      // 00000013D7E4: DC960160 007C2028
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013D7EC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000013D7F0: BE882001
	s_cbranch_execz 59517                                      // 00000013D7F4: BFA5E87D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41ec>
	v_mad_i64_i32 v[40:41], null, 0x6000, v120, v[130:131]     // 00000013D7F8: D6FF7C28 060AF0FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 00000013D804: 1042438B
	global_load_u16 v32, v[40:41], off offset:864              // 00000013D808: DC4A0360 207C0028
	s_waitcnt vmcnt(0)                                         // 00000013D810: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000013D814: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013D818: BF870121
	v_mul_f32_e32 v40, 0xbfb8aa3b, v32                         // 00000013D81C: 105040FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000013D824: 7C3C40FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v32, -v40                       // 00000013D82C: D6130029 84A240FF BFB8AA3B
	v_rndne_f32_e32 v42, v40                                   // 00000013D838: 7E544728
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013D83C: BF870112
	v_fmamk_f32 v41, v32, 0xb2a5705f, v41                      // 00000013D840: 58525320 B2A5705F
	v_sub_f32_e32 v40, v40, v42                                // 00000013D848: 08505528
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013D84C: BF870121
	v_add_f32_e32 v40, v40, v41                                // 00000013D850: 06505328
	v_cvt_i32_f32_e32 v41, v42                                 // 00000013D854: 7E52112A
	v_exp_f32_e32 v40, v40                                     // 00000013D858: 7E504B28
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D85C: BF870095
	.long 0xd71c0028                                           // 00000013D860: D71C0028
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                     // 00000013D864: 02025328
	v_cndmask_b32_e32 v40, 0, v40, vcc_lo                      // 00000013D868: 02505080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000013D86C: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D874: BF870092
	v_cndmask_b32_e32 v32, 0x7f800000, v40, vcc_lo             // 00000013D878: 024050FF 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 00000013D880: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D884: BF870091
	v_div_scale_f32 v40, null, v32, v32, v33                   // 00000013D888: D6FC7C28 04864120
	v_rcp_f32_e32 v41, v40                                     // 00000013D890: 7E525528
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D894: BF870095
	v_fma_f32 v42, -v40, v41, 1.0                              // 00000013D898: D613002A 23CA5328
	v_fmac_f32_e32 v41, v42, v41                               // 00000013D8A0: 5652532A
	v_div_scale_f32 v42, vcc_lo, v33, v32, v33                 // 00000013D8A4: D6FC6A2A 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D8AC: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 00000013D8B0: 1056532A
	v_fma_f32 v44, -v40, v43, v42                              // 00000013D8B4: D613002C 24AA5728
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D8BC: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 00000013D8C0: 5656532C
	v_fma_f32 v40, -v40, v43, v42                              // 00000013D8C4: D6130028 24AA5728
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D8CC: BF870091
	v_div_fmas_f32 v40, v40, v41, v43                          // 00000013D8D0: D6370028 04AE5328
	v_div_fixup_f32 v40, v40, v32, v33                         // 00000013D8D8: D6270028 04864128
	v_mad_i64_i32 v[32:33], null, 0x3000, v120, v[128:129]     // 00000013D8E0: D6FF7C20 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D8EC: BF870092
	v_bfe_u32 v41, v40, 16, 1                                  // 00000013D8F0: D6100029 02052128
	v_add3_u32 v40, v40, v41, 0x7fff                           // 00000013D8F8: D6550028 03FE5328 00007FFF
	global_store_d16_hi_b16 v[32:33], v40, off offset:352      // 00000013D904: DC960160 007C2820
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013D90C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000013D910: BE882002
	s_cbranch_execz 59448                                      // 00000013D914: BFA5E838 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41f8>
	v_mad_i64_i32 v[32:33], null, 0x6000, v121, v[130:131]     // 00000013D918: D6FF7C20 060AF2FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 00000013D924: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 00000013D92C: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000013D930: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D934: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 00000013D938: 104240FF BFB8AA3B
	v_fma_f32 v40, 0xbfb8aa3b, v32, -v33                       // 00000013D940: D6130028 848640FF BFB8AA3B
	v_rndne_f32_e32 v41, v33                                   // 00000013D94C: 7E524721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013D950: BF870221
	v_sub_f32_e32 v33, v33, v41                                // 00000013D954: 08425321
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000013D958: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v40, v32, 0xb2a5705f, v40                      // 00000013D960: 58505120 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013D968: BF870121
	v_add_f32_e32 v33, v33, v40                                // 00000013D96C: 06425121
	v_cvt_i32_f32_e32 v40, v41                                 // 00000013D970: 7E501129
	v_exp_f32_e32 v33, v33                                     // 00000013D974: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D978: BF870095
	.long 0xd71c0021                                           // 00000013D97C: D71C0021
	v_cndmask_b32_e32 v1, v33, v40, vcc_lo                     // 00000013D980: 02025121
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000013D984: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000013D988: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D990: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v136, v34// 00000013D994: CA4642FF 20204588 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 00000013D9A0: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D9A4: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 00000013D9A8: D6FC7C22 04864120
	v_rcp_f32_e32 v40, v34                                     // 00000013D9B0: 7E505522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D9B4: BF870095
	v_fma_f32 v41, -v34, v40, 1.0                              // 00000013D9B8: D6130029 23CA5122
	v_fmac_f32_e32 v40, v41, v40                               // 00000013D9C0: 56505129
	v_div_scale_f32 v41, vcc_lo, v33, v32, v33                 // 00000013D9C4: D6FC6A29 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D9CC: BF870091
	v_mul_f32_e32 v42, v41, v40                                // 00000013D9D0: 10545129
	v_fma_f32 v43, -v34, v42, v41                              // 00000013D9D4: D613002B 24A65522
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D9DC: BF870091
	v_fmac_f32_e32 v42, v43, v40                               // 00000013D9E0: 5654512B
	v_fma_f32 v34, -v34, v42, v41                              // 00000013D9E4: D6130022 24A65522
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013D9EC: BF870091
	v_div_fmas_f32 v34, v34, v40, v42                          // 00000013D9F0: D6370022 04AA5122
	v_div_fixup_f32 v34, v34, v32, v33                         // 00000013D9F8: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v121, v[128:129]     // 00000013DA00: D6FF7C20 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DA0C: BF870092
	v_bfe_u32 v40, v34, 16, 1                                  // 00000013DA10: D6100028 02052122
	v_add3_u32 v34, v34, v40, 0x7fff                           // 00000013DA18: D6550022 03FE5122 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 00000013DA24: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013DA2C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013DA30: BE882003
	s_cbranch_execz 59379                                      // 00000013DA34: BFA5E7F3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4204>
	v_mad_i64_i32 v[32:33], null, 0x6000, v122, v[130:131]     // 00000013DA38: D6FF7C20 060AF4FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 00000013DA44: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 00000013DA4C: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000013DA50: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DA54: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 00000013DA58: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 00000013DA60: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v40, v33                                   // 00000013DA6C: 7E504721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DA70: BF870091
	v_dual_fmamk_f32 v34, v32, 0xb2a5705f, v34 :: v_dual_sub_f32 v33, v33, v40// 00000013DA74: C88A4520 22205121 B2A5705F
	v_add_f32_e32 v33, v33, v34                                // 00000013DA80: 06424521
	v_cvt_i32_f32_e32 v34, v40                                 // 00000013DA84: 7E441128
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000013DA88: 7C3C40FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013DA90: BF870293
	v_exp_f32_e32 v33, v33                                     // 00000013DA94: 7E424B21
	.long 0xd71c0021                                           // 00000013DA98: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000013DA9C: 02024521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013DAA0: BF870121
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000013DAA4: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000013DAA8: 7C3640FF C2B17218
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v137, v35// 00000013DAB0: CA4642FF 20204789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DABC: BF870091
	v_add_f32_e32 v32, 1.0, v32                                // 00000013DAC0: 064040F2
	v_div_scale_f32 v34, null, v32, v32, v33                   // 00000013DAC4: D6FC7C22 04864120
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013DACC: BF870291
	v_rcp_f32_e32 v35, v34                                     // 00000013DAD0: 7E465522
	v_fma_f32 v40, -v34, v35, 1.0                              // 00000013DAD4: D6130028 23CA4722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013DADC: BF8700A1
	v_fmac_f32_e32 v35, v40, v35                               // 00000013DAE0: 56464728
	v_div_scale_f32 v40, vcc_lo, v33, v32, v33                 // 00000013DAE4: D6FC6A28 04864121
	v_mul_f32_e32 v41, v40, v35                                // 00000013DAEC: 10524728
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DAF0: BF870091
	v_fma_f32 v42, -v34, v41, v40                              // 00000013DAF4: D613002A 24A25322
	v_fmac_f32_e32 v41, v42, v35                               // 00000013DAFC: 5652472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DB00: BF870091
	v_fma_f32 v34, -v34, v41, v40                              // 00000013DB04: D6130022 24A25322
	v_div_fmas_f32 v34, v34, v35, v41                          // 00000013DB0C: D6370022 04A64722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013DB14: BF870121
	v_div_fixup_f32 v34, v34, v32, v33                         // 00000013DB18: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v122, v[128:129]     // 00000013DB20: D6FF7C20 0602F4FF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 00000013DB2C: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013DB34: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000013DB38: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 00000013DB44: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013DB4C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000013DB50: BE882004
	s_cbranch_execz 59310                                      // 00000013DB54: BFA5E7AE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4210>
	v_mad_i64_i32 v[32:33], null, 0x6000, v123, v[130:131]     // 00000013DB58: D6FF7C20 060AF6FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 00000013DB64: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 00000013DB6C: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000013DB70: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DB74: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 00000013DB78: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 00000013DB80: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000013DB8C: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013DB90: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 00000013DB94: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000013DB98: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 00000013DBA0: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013DBA8: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000013DBAC: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000013DBB0: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000013DBB4: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DBB8: BF870095
	.long 0xd71c0021                                           // 00000013DBBC: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000013DBC0: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000013DBC4: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000013DBC8: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DBD0: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v134, v36// 00000013DBD4: CA4642FF 20204986 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 00000013DBE0: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DBE4: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 00000013DBE8: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 00000013DBF0: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DBF4: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 00000013DBF8: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 00000013DC00: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 00000013DC04: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DC0C: BF870091
	v_mul_f32_e32 v40, v36, v35                                // 00000013DC10: 10504724
	v_fma_f32 v41, -v34, v40, v36                              // 00000013DC14: D6130029 24925122
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DC1C: BF870091
	v_fmac_f32_e32 v40, v41, v35                               // 00000013DC20: 56504729
	v_fma_f32 v34, -v34, v40, v36                              // 00000013DC24: D6130022 24925122
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DC2C: BF870091
	v_div_fmas_f32 v34, v34, v35, v40                          // 00000013DC30: D6370022 04A24722
	v_div_fixup_f32 v34, v34, v32, v33                         // 00000013DC38: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v123, v[128:129]     // 00000013DC40: D6FF7C20 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DC4C: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 00000013DC50: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000013DC58: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 00000013DC64: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013DC6C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000013DC70: BE882005
	s_cbranch_execz 59241                                      // 00000013DC74: BFA5E769 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x421c>
	v_mad_i64_i32 v[32:33], null, 0x6000, v124, v[130:131]     // 00000013DC78: D6FF7C20 060AF8FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 00000013DC84: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 00000013DC8C: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000013DC90: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DC94: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 00000013DC98: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 00000013DCA0: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000013DCAC: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013DCB0: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 00000013DCB4: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000013DCB8: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 00000013DCC0: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013DCC8: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000013DCCC: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000013DCD0: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000013DCD4: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DCD8: BF870095
	.long 0xd71c0021                                           // 00000013DCDC: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000013DCE0: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000013DCE4: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000013DCE8: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DCF0: BF870092
	v_cndmask_b32_e32 v32, 0x7f800000, v33, vcc_lo             // 00000013DCF4: 024042FF 7F800000
	v_dual_mul_f32 v33, v135, v37 :: v_dual_add_f32 v32, 1.0, v32// 00000013DCFC: C8C84B87 212040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DD04: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 00000013DD08: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 00000013DD10: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DD14: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 00000013DD18: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 00000013DD20: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 00000013DD24: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DD2C: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 00000013DD30: 104A4724
	v_fma_f32 v40, -v34, v37, v36                              // 00000013DD34: D6130028 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DD3C: BF870091
	v_fmac_f32_e32 v37, v40, v35                               // 00000013DD40: 564A4728
	v_fma_f32 v34, -v34, v37, v36                              // 00000013DD44: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DD4C: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 00000013DD50: D6370022 04964722
	v_div_fixup_f32 v34, v34, v32, v33                         // 00000013DD58: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v124, v[128:129]     // 00000013DD60: D6FF7C20 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DD6C: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 00000013DD70: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000013DD78: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 00000013DD84: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013DD8C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000013DD90: BE882006
	s_cbranch_execz 59172                                      // 00000013DD94: BFA5E724 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4228>
	v_mad_i64_i32 v[32:33], null, 0x6000, v125, v[130:131]     // 00000013DD98: D6FF7C20 060AFAFF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 00000013DDA4: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 00000013DDAC: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000013DDB0: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DDB4: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 00000013DDB8: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 00000013DDC0: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000013DDCC: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013DDD0: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 00000013DDD4: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000013DDD8: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 00000013DDE0: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013DDE8: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000013DDEC: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000013DDF0: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000013DDF4: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DDF8: BF870095
	.long 0xd71c0021                                           // 00000013DDFC: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000013DE00: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000013DE04: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000013DE08: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DE10: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v132, v38// 00000013DE14: CA4642FF 20204D84 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 00000013DE20: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DE24: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 00000013DE28: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 00000013DE30: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DE34: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 00000013DE38: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 00000013DE40: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 00000013DE44: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DE4C: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 00000013DE50: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 00000013DE54: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DE5C: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 00000013DE60: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 00000013DE64: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DE6C: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 00000013DE70: D6370022 04964722
	v_div_fixup_f32 v34, v34, v32, v33                         // 00000013DE78: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v125, v[128:129]     // 00000013DE80: D6FF7C20 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DE8C: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 00000013DE90: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000013DE98: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 00000013DEA4: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013DEAC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013DEB0: BE882007
	s_cbranch_execz 59103                                      // 00000013DEB4: BFA5E6DF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4234>
	v_mad_i64_i32 v[32:33], null, 0x6000, v126, v[130:131]     // 00000013DEB8: D6FF7C20 060AFCFF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 00000013DEC4: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 00000013DECC: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000013DED0: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DED4: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 00000013DED8: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 00000013DEE0: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000013DEEC: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013DEF0: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 00000013DEF4: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000013DEF8: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 00000013DF00: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013DF08: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000013DF0C: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000013DF10: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000013DF14: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DF18: BF870095
	.long 0xd71c0021                                           // 00000013DF1C: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000013DF20: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000013DF24: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000013DF28: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DF30: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v133, v39// 00000013DF34: CA4642FF 20204F85 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 00000013DF40: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DF44: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 00000013DF48: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 00000013DF50: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DF54: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 00000013DF58: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 00000013DF60: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 00000013DF64: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DF6C: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 00000013DF70: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 00000013DF74: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DF7C: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 00000013DF80: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 00000013DF84: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DF8C: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 00000013DF90: D6370022 04964722
	v_div_fixup_f32 v34, v34, v32, v33                         // 00000013DF98: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v126, v[128:129]     // 00000013DFA0: D6FF7C20 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DFAC: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 00000013DFB0: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000013DFB8: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 00000013DFC4: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013DFCC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000013DFD0: BE882000
	s_cbranch_execz 59034                                      // 00000013DFD4: BFA5E69A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4240>
	v_mad_i64_i32 v[32:33], null, 0x6000, v140, v[130:131]     // 00000013DFD8: D6FF7C20 060B18FF 00006000
	v_mul_f32_e32 v24, v138, v24                               // 00000013DFE4: 1030318A
	global_load_u16 v32, v[32:33], off offset:896              // 00000013DFE8: DC4A0380 207C0020
	s_waitcnt vmcnt(0)                                         // 00000013DFF0: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000013DFF4: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013DFF8: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 00000013DFFC: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 00000013E004: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000013E010: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013E014: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 00000013E018: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000013E01C: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 00000013E024: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013E02C: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000013E030: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000013E034: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000013E038: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E03C: BF870095
	.long 0xd71c0021                                           // 00000013E040: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000013E044: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000013E048: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000013E04C: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E054: BF870092
	v_cndmask_b32_e32 v32, 0x7f800000, v33, vcc_lo             // 00000013E058: 024042FF 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 00000013E060: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E064: BF870091
	v_div_scale_f32 v33, null, v32, v32, v24                   // 00000013E068: D6FC7C21 04624120
	v_rcp_f32_e32 v34, v33                                     // 00000013E070: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E074: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 00000013E078: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 00000013E080: 56444523
	v_div_scale_f32 v35, vcc_lo, v24, v32, v24                 // 00000013E084: D6FC6A23 04624118
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E08C: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 00000013E090: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 00000013E094: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E09C: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 00000013E0A0: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 00000013E0A4: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E0AC: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 00000013E0B0: D6370021 04924521
	v_div_fixup_f32 v24, v33, v32, v24                         // 00000013E0B8: D6270018 04624121
	v_mad_i64_i32 v[32:33], null, 0x3000, v140, v[128:129]     // 00000013E0C0: D6FF7C20 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E0CC: BF870092
	v_bfe_u32 v34, v24, 16, 1                                  // 00000013E0D0: D6100022 02052118
	v_add3_u32 v24, v24, v34, 0x7fff                           // 00000013E0D8: D6550018 03FE4518 00007FFF
	global_store_d16_hi_b16 v[32:33], v24, off offset:384      // 00000013E0E4: DC960180 007C1820
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013E0EC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000013E0F0: BE882001
	s_cbranch_execz 58965                                      // 00000013E0F4: BFA5E655 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x424c>
	v_mad_i64_i32 v[32:33], null, 0x6000, v120, v[130:131]     // 00000013E0F8: D6FF7C20 060AF0FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 00000013E104: 1032338B
	global_load_u16 v24, v[32:33], off offset:896              // 00000013E108: DC4A0380 187C0020
	s_waitcnt vmcnt(0)                                         // 00000013E110: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000013E114: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013E118: BF870121
	v_mul_f32_e32 v32, 0xbfb8aa3b, v24                         // 00000013E11C: 104030FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000013E124: 7C3C30FF 42CE8ED0
	v_fma_f32 v33, 0xbfb8aa3b, v24, -v32                       // 00000013E12C: D6130021 848230FF BFB8AA3B
	v_rndne_f32_e32 v34, v32                                   // 00000013E138: 7E444720
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013E13C: BF870112
	v_fmamk_f32 v33, v24, 0xb2a5705f, v33                      // 00000013E140: 58424318 B2A5705F
	v_sub_f32_e32 v32, v32, v34                                // 00000013E148: 08404520
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013E14C: BF870121
	v_add_f32_e32 v32, v32, v33                                // 00000013E150: 06404320
	v_cvt_i32_f32_e32 v33, v34                                 // 00000013E154: 7E421122
	v_exp_f32_e32 v32, v32                                     // 00000013E158: 7E404B20
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E15C: BF870095
	.long 0xd71c0020                                           // 00000013E160: D71C0020
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                     // 00000013E164: 02024320
	v_cndmask_b32_e32 v32, 0, v32, vcc_lo                      // 00000013E168: 02404080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000013E16C: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E174: BF870092
	v_cndmask_b32_e32 v24, 0x7f800000, v32, vcc_lo             // 00000013E178: 023040FF 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 00000013E180: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E184: BF870091
	v_div_scale_f32 v32, null, v24, v24, v25                   // 00000013E188: D6FC7C20 04663118
	v_rcp_f32_e32 v33, v32                                     // 00000013E190: 7E425520
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E194: BF870095
	v_fma_f32 v34, -v32, v33, 1.0                              // 00000013E198: D6130022 23CA4320
	v_fmac_f32_e32 v33, v34, v33                               // 00000013E1A0: 56424322
	v_div_scale_f32 v34, vcc_lo, v25, v24, v25                 // 00000013E1A4: D6FC6A22 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E1AC: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 00000013E1B0: 10464322
	v_fma_f32 v36, -v32, v35, v34                              // 00000013E1B4: D6130024 248A4720
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E1BC: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 00000013E1C0: 56464324
	v_fma_f32 v32, -v32, v35, v34                              // 00000013E1C4: D6130020 248A4720
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E1CC: BF870091
	v_div_fmas_f32 v32, v32, v33, v35                          // 00000013E1D0: D6370020 048E4320
	v_div_fixup_f32 v32, v32, v24, v25                         // 00000013E1D8: D6270020 04663120
	v_mad_i64_i32 v[24:25], null, 0x3000, v120, v[128:129]     // 00000013E1E0: D6FF7C18 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E1EC: BF870092
	v_bfe_u32 v33, v32, 16, 1                                  // 00000013E1F0: D6100021 02052120
	v_add3_u32 v32, v32, v33, 0x7fff                           // 00000013E1F8: D6550020 03FE4320 00007FFF
	global_store_d16_hi_b16 v[24:25], v32, off offset:384      // 00000013E204: DC960180 007C2018
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013E20C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000013E210: BE882002
	s_cbranch_execz 58896                                      // 00000013E214: BFA5E610 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4258>
	v_mad_i64_i32 v[24:25], null, 0x6000, v121, v[130:131]     // 00000013E218: D6FF7C18 060AF2FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 00000013E224: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 00000013E22C: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000013E230: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E234: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 00000013E238: 103230FF BFB8AA3B
	v_fma_f32 v32, 0xbfb8aa3b, v24, -v25                       // 00000013E240: D6130020 846630FF BFB8AA3B
	v_rndne_f32_e32 v33, v25                                   // 00000013E24C: 7E424719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013E250: BF870221
	v_sub_f32_e32 v25, v25, v33                                // 00000013E254: 08324319
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000013E258: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v32, v24, 0xb2a5705f, v32                      // 00000013E260: 58404118 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013E268: BF870121
	v_add_f32_e32 v25, v25, v32                                // 00000013E26C: 06324119
	v_cvt_i32_f32_e32 v32, v33                                 // 00000013E270: 7E401121
	v_exp_f32_e32 v25, v25                                     // 00000013E274: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E278: BF870095
	.long 0xd71c0019                                           // 00000013E27C: D71C0019
	v_cndmask_b32_e32 v1, v25, v32, vcc_lo                     // 00000013E280: 02024119
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000013E284: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000013E288: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E290: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v136, v26// 00000013E294: CA4632FF 18183588 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 00000013E2A0: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E2A4: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 00000013E2A8: D6FC7C1A 04663118
	v_rcp_f32_e32 v32, v26                                     // 00000013E2B0: 7E40551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E2B4: BF870095
	v_fma_f32 v33, -v26, v32, 1.0                              // 00000013E2B8: D6130021 23CA411A
	v_fmac_f32_e32 v32, v33, v32                               // 00000013E2C0: 56404121
	v_div_scale_f32 v33, vcc_lo, v25, v24, v25                 // 00000013E2C4: D6FC6A21 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E2CC: BF870091
	v_mul_f32_e32 v34, v33, v32                                // 00000013E2D0: 10444121
	v_fma_f32 v35, -v26, v34, v33                              // 00000013E2D4: D6130023 2486451A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E2DC: BF870091
	v_fmac_f32_e32 v34, v35, v32                               // 00000013E2E0: 56444123
	v_fma_f32 v26, -v26, v34, v33                              // 00000013E2E4: D613001A 2486451A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E2EC: BF870091
	v_div_fmas_f32 v26, v26, v32, v34                          // 00000013E2F0: D637001A 048A411A
	v_div_fixup_f32 v26, v26, v24, v25                         // 00000013E2F8: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v121, v[128:129]     // 00000013E300: D6FF7C18 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E30C: BF870092
	v_bfe_u32 v32, v26, 16, 1                                  // 00000013E310: D6100020 0205211A
	v_add3_u32 v26, v26, v32, 0x7fff                           // 00000013E318: D655001A 03FE411A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 00000013E324: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013E32C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013E330: BE882003
	s_cbranch_execz 58827                                      // 00000013E334: BFA5E5CB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4264>
	v_mad_i64_i32 v[24:25], null, 0x6000, v122, v[130:131]     // 00000013E338: D6FF7C18 060AF4FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 00000013E344: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 00000013E34C: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000013E350: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E354: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 00000013E358: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 00000013E360: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v32, v25                                   // 00000013E36C: 7E404719
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E370: BF870091
	v_dual_fmamk_f32 v26, v24, 0xb2a5705f, v26 :: v_dual_sub_f32 v25, v25, v32// 00000013E374: C88A3518 1A184119 B2A5705F
	v_add_f32_e32 v25, v25, v26                                // 00000013E380: 06323519
	v_cvt_i32_f32_e32 v26, v32                                 // 00000013E384: 7E341120
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000013E388: 7C3C30FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013E390: BF870293
	v_exp_f32_e32 v25, v25                                     // 00000013E394: 7E324B19
	.long 0xd71c0019                                           // 00000013E398: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000013E39C: 02023519
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013E3A0: BF870121
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000013E3A4: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000013E3A8: 7C3630FF C2B17218
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v137, v27// 00000013E3B0: CA4632FF 18183789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E3BC: BF870091
	v_add_f32_e32 v24, 1.0, v24                                // 00000013E3C0: 063030F2
	v_div_scale_f32 v26, null, v24, v24, v25                   // 00000013E3C4: D6FC7C1A 04663118
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013E3CC: BF870291
	v_rcp_f32_e32 v27, v26                                     // 00000013E3D0: 7E36551A
	v_fma_f32 v32, -v26, v27, 1.0                              // 00000013E3D4: D6130020 23CA371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013E3DC: BF8700A1
	v_fmac_f32_e32 v27, v32, v27                               // 00000013E3E0: 56363720
	v_div_scale_f32 v32, vcc_lo, v25, v24, v25                 // 00000013E3E4: D6FC6A20 04663119
	v_mul_f32_e32 v33, v32, v27                                // 00000013E3EC: 10423720
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E3F0: BF870091
	v_fma_f32 v34, -v26, v33, v32                              // 00000013E3F4: D6130022 2482431A
	v_fmac_f32_e32 v33, v34, v27                               // 00000013E3FC: 56423722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E400: BF870091
	v_fma_f32 v26, -v26, v33, v32                              // 00000013E404: D613001A 2482431A
	v_div_fmas_f32 v26, v26, v27, v33                          // 00000013E40C: D637001A 0486371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013E414: BF870121
	v_div_fixup_f32 v26, v26, v24, v25                         // 00000013E418: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v122, v[128:129]     // 00000013E420: D6FF7C18 0602F4FF 00003000
	v_bfe_u32 v27, v26, 16, 1                                  // 00000013E42C: D610001B 0205211A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E434: BF870001
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000013E438: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 00000013E444: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013E44C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000013E450: BE882004
	s_cbranch_execz 58758                                      // 00000013E454: BFA5E586 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4270>
	v_mad_i64_i32 v[24:25], null, 0x6000, v123, v[130:131]     // 00000013E458: D6FF7C18 060AF6FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 00000013E464: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 00000013E46C: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000013E470: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E474: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 00000013E478: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 00000013E480: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000013E48C: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013E490: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 00000013E494: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000013E498: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 00000013E4A0: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013E4A8: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000013E4AC: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000013E4B0: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000013E4B4: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E4B8: BF870095
	.long 0xd71c0019                                           // 00000013E4BC: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000013E4C0: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000013E4C4: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000013E4C8: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E4D0: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v134, v28// 00000013E4D4: CA4632FF 18183986 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 00000013E4E0: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E4E4: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 00000013E4E8: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 00000013E4F0: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E4F4: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 00000013E4F8: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 00000013E500: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 00000013E504: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E50C: BF870091
	v_mul_f32_e32 v32, v28, v27                                // 00000013E510: 1040371C
	v_fma_f32 v33, -v26, v32, v28                              // 00000013E514: D6130021 2472411A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E51C: BF870091
	v_fmac_f32_e32 v32, v33, v27                               // 00000013E520: 56403721
	v_fma_f32 v26, -v26, v32, v28                              // 00000013E524: D613001A 2472411A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E52C: BF870091
	v_div_fmas_f32 v26, v26, v27, v32                          // 00000013E530: D637001A 0482371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 00000013E538: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v123, v[128:129]     // 00000013E540: D6FF7C18 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E54C: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 00000013E550: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000013E558: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 00000013E564: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013E56C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000013E570: BE882005
	s_cbranch_execz 58689                                      // 00000013E574: BFA5E541 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x427c>
	v_mad_i64_i32 v[24:25], null, 0x6000, v124, v[130:131]     // 00000013E578: D6FF7C18 060AF8FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 00000013E584: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 00000013E58C: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000013E590: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E594: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 00000013E598: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 00000013E5A0: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000013E5AC: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013E5B0: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 00000013E5B4: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000013E5B8: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 00000013E5C0: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013E5C8: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000013E5CC: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000013E5D0: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000013E5D4: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E5D8: BF870095
	.long 0xd71c0019                                           // 00000013E5DC: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000013E5E0: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000013E5E4: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000013E5E8: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E5F0: BF870092
	v_cndmask_b32_e32 v24, 0x7f800000, v25, vcc_lo             // 00000013E5F4: 023032FF 7F800000
	v_dual_mul_f32 v25, v135, v29 :: v_dual_add_f32 v24, 1.0, v24// 00000013E5FC: C8C83B87 191830F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E604: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 00000013E608: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 00000013E610: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E614: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 00000013E618: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 00000013E620: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 00000013E624: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E62C: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 00000013E630: 103A371C
	v_fma_f32 v32, -v26, v29, v28                              // 00000013E634: D6130020 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E63C: BF870091
	v_fmac_f32_e32 v29, v32, v27                               // 00000013E640: 563A3720
	v_fma_f32 v26, -v26, v29, v28                              // 00000013E644: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E64C: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 00000013E650: D637001A 0476371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 00000013E658: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v124, v[128:129]     // 00000013E660: D6FF7C18 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E66C: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 00000013E670: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000013E678: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 00000013E684: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013E68C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000013E690: BE882006
	s_cbranch_execz 58620                                      // 00000013E694: BFA5E4FC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4288>
	v_mad_i64_i32 v[24:25], null, 0x6000, v125, v[130:131]     // 00000013E698: D6FF7C18 060AFAFF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 00000013E6A4: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 00000013E6AC: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000013E6B0: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E6B4: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 00000013E6B8: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 00000013E6C0: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000013E6CC: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013E6D0: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 00000013E6D4: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000013E6D8: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 00000013E6E0: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013E6E8: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000013E6EC: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000013E6F0: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000013E6F4: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E6F8: BF870095
	.long 0xd71c0019                                           // 00000013E6FC: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000013E700: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000013E704: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000013E708: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E710: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v132, v30// 00000013E714: CA4632FF 18183D84 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 00000013E720: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E724: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 00000013E728: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 00000013E730: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E734: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 00000013E738: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 00000013E740: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 00000013E744: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E74C: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 00000013E750: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 00000013E754: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E75C: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 00000013E760: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 00000013E764: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E76C: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 00000013E770: D637001A 0476371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 00000013E778: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v125, v[128:129]     // 00000013E780: D6FF7C18 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E78C: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 00000013E790: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000013E798: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 00000013E7A4: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013E7AC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013E7B0: BE882007
	s_cbranch_execz 58551                                      // 00000013E7B4: BFA5E4B7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4294>
	v_mad_i64_i32 v[24:25], null, 0x6000, v126, v[130:131]     // 00000013E7B8: D6FF7C18 060AFCFF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 00000013E7C4: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 00000013E7CC: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000013E7D0: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E7D4: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 00000013E7D8: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 00000013E7E0: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000013E7EC: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013E7F0: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 00000013E7F4: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000013E7F8: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 00000013E800: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013E808: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000013E80C: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000013E810: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000013E814: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E818: BF870095
	.long 0xd71c0019                                           // 00000013E81C: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000013E820: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000013E824: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000013E828: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E830: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v133, v31// 00000013E834: CA4632FF 18183F85 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 00000013E840: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E844: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 00000013E848: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 00000013E850: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E854: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 00000013E858: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 00000013E860: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 00000013E864: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E86C: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 00000013E870: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 00000013E874: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E87C: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 00000013E880: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 00000013E884: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E88C: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 00000013E890: D637001A 0476371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 00000013E898: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v126, v[128:129]     // 00000013E8A0: D6FF7C18 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E8AC: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 00000013E8B0: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000013E8B8: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 00000013E8C4: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013E8CC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000013E8D0: BE882000
	s_cbranch_execz 58482                                      // 00000013E8D4: BFA5E472 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42a0>
	v_mad_i64_i32 v[24:25], null, 0x6000, v140, v[130:131]     // 00000013E8D8: D6FF7C18 060B18FF 00006000
	v_mul_f32_e32 v16, v138, v16                               // 00000013E8E4: 1020218A
	global_load_u16 v24, v[24:25], off offset:928              // 00000013E8E8: DC4A03A0 187C0018
	s_waitcnt vmcnt(0)                                         // 00000013E8F0: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000013E8F4: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E8F8: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 00000013E8FC: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 00000013E904: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000013E910: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013E914: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 00000013E918: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000013E91C: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 00000013E924: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013E92C: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000013E930: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000013E934: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000013E938: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E93C: BF870095
	.long 0xd71c0019                                           // 00000013E940: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000013E944: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000013E948: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000013E94C: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E954: BF870092
	v_cndmask_b32_e32 v24, 0x7f800000, v25, vcc_lo             // 00000013E958: 023032FF 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 00000013E960: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E964: BF870091
	v_div_scale_f32 v25, null, v24, v24, v16                   // 00000013E968: D6FC7C19 04423118
	v_rcp_f32_e32 v26, v25                                     // 00000013E970: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E974: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 00000013E978: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 00000013E980: 5634351B
	v_div_scale_f32 v27, vcc_lo, v16, v24, v16                 // 00000013E984: D6FC6A1B 04423110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E98C: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 00000013E990: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 00000013E994: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E99C: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 00000013E9A0: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 00000013E9A4: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E9AC: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 00000013E9B0: D6370019 04723519
	v_div_fixup_f32 v16, v25, v24, v16                         // 00000013E9B8: D6270010 04423119
	v_mad_i64_i32 v[24:25], null, 0x3000, v140, v[128:129]     // 00000013E9C0: D6FF7C18 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013E9CC: BF870092
	v_bfe_u32 v26, v16, 16, 1                                  // 00000013E9D0: D610001A 02052110
	v_add3_u32 v16, v16, v26, 0x7fff                           // 00000013E9D8: D6550010 03FE3510 00007FFF
	global_store_d16_hi_b16 v[24:25], v16, off offset:416      // 00000013E9E4: DC9601A0 007C1018
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013E9EC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000013E9F0: BE882001
	s_cbranch_execz 58413                                      // 00000013E9F4: BFA5E42D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42ac>
	v_mad_i64_i32 v[24:25], null, 0x6000, v120, v[130:131]     // 00000013E9F8: D6FF7C18 060AF0FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 00000013EA04: 1022238B
	global_load_u16 v16, v[24:25], off offset:928              // 00000013EA08: DC4A03A0 107C0018
	s_waitcnt vmcnt(0)                                         // 00000013EA10: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000013EA14: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013EA18: BF870121
	v_mul_f32_e32 v24, 0xbfb8aa3b, v16                         // 00000013EA1C: 103020FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000013EA24: 7C3C20FF 42CE8ED0
	v_fma_f32 v25, 0xbfb8aa3b, v16, -v24                       // 00000013EA2C: D6130019 846220FF BFB8AA3B
	v_rndne_f32_e32 v26, v24                                   // 00000013EA38: 7E344718
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013EA3C: BF870112
	v_fmamk_f32 v25, v16, 0xb2a5705f, v25                      // 00000013EA40: 58323310 B2A5705F
	v_sub_f32_e32 v24, v24, v26                                // 00000013EA48: 08303518
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013EA4C: BF870121
	v_add_f32_e32 v24, v24, v25                                // 00000013EA50: 06303318
	v_cvt_i32_f32_e32 v25, v26                                 // 00000013EA54: 7E32111A
	v_exp_f32_e32 v24, v24                                     // 00000013EA58: 7E304B18
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EA5C: BF870095
	.long 0xd71c0018                                           // 00000013EA60: D71C0018
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000013EA64: 02023318
	v_cndmask_b32_e32 v24, 0, v24, vcc_lo                      // 00000013EA68: 02303080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000013EA6C: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EA74: BF870092
	v_cndmask_b32_e32 v16, 0x7f800000, v24, vcc_lo             // 00000013EA78: 022030FF 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000013EA80: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EA84: BF870091
	v_div_scale_f32 v24, null, v16, v16, v17                   // 00000013EA88: D6FC7C18 04462110
	v_rcp_f32_e32 v25, v24                                     // 00000013EA90: 7E325518
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EA94: BF870095
	v_fma_f32 v26, -v24, v25, 1.0                              // 00000013EA98: D613001A 23CA3318
	v_fmac_f32_e32 v25, v26, v25                               // 00000013EAA0: 5632331A
	v_div_scale_f32 v26, vcc_lo, v17, v16, v17                 // 00000013EAA4: D6FC6A1A 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EAAC: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 00000013EAB0: 1036331A
	v_fma_f32 v28, -v24, v27, v26                              // 00000013EAB4: D613001C 246A3718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EABC: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 00000013EAC0: 5636331C
	v_fma_f32 v24, -v24, v27, v26                              // 00000013EAC4: D6130018 246A3718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EACC: BF870091
	v_div_fmas_f32 v24, v24, v25, v27                          // 00000013EAD0: D6370018 046E3318
	v_div_fixup_f32 v24, v24, v16, v17                         // 00000013EAD8: D6270018 04462118
	v_mad_i64_i32 v[16:17], null, 0x3000, v120, v[128:129]     // 00000013EAE0: D6FF7C10 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EAEC: BF870092
	v_bfe_u32 v25, v24, 16, 1                                  // 00000013EAF0: D6100019 02052118
	v_add3_u32 v24, v24, v25, 0x7fff                           // 00000013EAF8: D6550018 03FE3318 00007FFF
	global_store_d16_hi_b16 v[16:17], v24, off offset:416      // 00000013EB04: DC9601A0 007C1810
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013EB0C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000013EB10: BE882002
	s_cbranch_execz 58344                                      // 00000013EB14: BFA5E3E8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42b8>
	v_mad_i64_i32 v[16:17], null, 0x6000, v121, v[130:131]     // 00000013EB18: D6FF7C10 060AF2FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 00000013EB24: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000013EB2C: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000013EB30: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EB34: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 00000013EB38: 102220FF BFB8AA3B
	v_fma_f32 v24, 0xbfb8aa3b, v16, -v17                       // 00000013EB40: D6130018 844620FF BFB8AA3B
	v_rndne_f32_e32 v25, v17                                   // 00000013EB4C: 7E324711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013EB50: BF870221
	v_sub_f32_e32 v17, v17, v25                                // 00000013EB54: 08223311
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000013EB58: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v24, v16, 0xb2a5705f, v24                      // 00000013EB60: 58303110 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013EB68: BF870121
	v_add_f32_e32 v17, v17, v24                                // 00000013EB6C: 06223111
	v_cvt_i32_f32_e32 v24, v25                                 // 00000013EB70: 7E301119
	v_exp_f32_e32 v17, v17                                     // 00000013EB74: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EB78: BF870095
	.long 0xd71c0011                                           // 00000013EB7C: D71C0011
	v_cndmask_b32_e32 v1, v17, v24, vcc_lo                     // 00000013EB80: 02023111
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000013EB84: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000013EB88: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EB90: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v136, v18// 00000013EB94: CA4622FF 10102588 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000013EBA0: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EBA4: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 00000013EBA8: D6FC7C12 04462110
	v_rcp_f32_e32 v24, v18                                     // 00000013EBB0: 7E305512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EBB4: BF870095
	v_fma_f32 v25, -v18, v24, 1.0                              // 00000013EBB8: D6130019 23CA3112
	v_fmac_f32_e32 v24, v25, v24                               // 00000013EBC0: 56303119
	v_div_scale_f32 v25, vcc_lo, v17, v16, v17                 // 00000013EBC4: D6FC6A19 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EBCC: BF870091
	v_mul_f32_e32 v26, v25, v24                                // 00000013EBD0: 10343119
	v_fma_f32 v27, -v18, v26, v25                              // 00000013EBD4: D613001B 24663512
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EBDC: BF870091
	v_fmac_f32_e32 v26, v27, v24                               // 00000013EBE0: 5634311B
	v_fma_f32 v18, -v18, v26, v25                              // 00000013EBE4: D6130012 24663512
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EBEC: BF870091
	v_div_fmas_f32 v18, v18, v24, v26                          // 00000013EBF0: D6370012 046A3112
	v_div_fixup_f32 v18, v18, v16, v17                         // 00000013EBF8: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v121, v[128:129]     // 00000013EC00: D6FF7C10 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EC0C: BF870092
	v_bfe_u32 v24, v18, 16, 1                                  // 00000013EC10: D6100018 02052112
	v_add3_u32 v18, v18, v24, 0x7fff                           // 00000013EC18: D6550012 03FE3112 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 00000013EC24: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013EC2C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013EC30: BE882003
	s_cbranch_execz 58275                                      // 00000013EC34: BFA5E3A3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42c4>
	v_mad_i64_i32 v[16:17], null, 0x6000, v122, v[130:131]     // 00000013EC38: D6FF7C10 060AF4FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 00000013EC44: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000013EC4C: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000013EC50: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EC54: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 00000013EC58: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000013EC60: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v24, v17                                   // 00000013EC6C: 7E304711
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EC70: BF870091
	v_dual_fmamk_f32 v18, v16, 0xb2a5705f, v18 :: v_dual_sub_f32 v17, v17, v24// 00000013EC74: C88A2510 12103111 B2A5705F
	v_add_f32_e32 v17, v17, v18                                // 00000013EC80: 06222511
	v_cvt_i32_f32_e32 v18, v24                                 // 00000013EC84: 7E241118
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000013EC88: 7C3C20FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013EC90: BF870293
	v_exp_f32_e32 v17, v17                                     // 00000013EC94: 7E224B11
	.long 0xd71c0011                                           // 00000013EC98: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000013EC9C: 02022511
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013ECA0: BF870121
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000013ECA4: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000013ECA8: 7C3620FF C2B17218
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v137, v19// 00000013ECB0: CA4622FF 10102789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ECBC: BF870091
	v_add_f32_e32 v16, 1.0, v16                                // 00000013ECC0: 062020F2
	v_div_scale_f32 v18, null, v16, v16, v17                   // 00000013ECC4: D6FC7C12 04462110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013ECCC: BF870291
	v_rcp_f32_e32 v19, v18                                     // 00000013ECD0: 7E265512
	v_fma_f32 v24, -v18, v19, 1.0                              // 00000013ECD4: D6130018 23CA2712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013ECDC: BF8700A1
	v_fmac_f32_e32 v19, v24, v19                               // 00000013ECE0: 56262718
	v_div_scale_f32 v24, vcc_lo, v17, v16, v17                 // 00000013ECE4: D6FC6A18 04462111
	v_mul_f32_e32 v25, v24, v19                                // 00000013ECEC: 10322718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ECF0: BF870091
	v_fma_f32 v26, -v18, v25, v24                              // 00000013ECF4: D613001A 24623312
	v_fmac_f32_e32 v25, v26, v19                               // 00000013ECFC: 5632271A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ED00: BF870091
	v_fma_f32 v18, -v18, v25, v24                              // 00000013ED04: D6130012 24623312
	v_div_fmas_f32 v18, v18, v19, v25                          // 00000013ED0C: D6370012 04662712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013ED14: BF870121
	v_div_fixup_f32 v18, v18, v16, v17                         // 00000013ED18: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v122, v[128:129]     // 00000013ED20: D6FF7C10 0602F4FF 00003000
	v_bfe_u32 v19, v18, 16, 1                                  // 00000013ED2C: D6100013 02052112
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013ED34: BF870001
	v_add3_u32 v18, v18, v19, 0x7fff                           // 00000013ED38: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 00000013ED44: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013ED4C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000013ED50: BE882004
	s_cbranch_execz 58206                                      // 00000013ED54: BFA5E35E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42d0>
	v_mad_i64_i32 v[16:17], null, 0x6000, v123, v[130:131]     // 00000013ED58: D6FF7C10 060AF6FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 00000013ED64: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000013ED6C: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000013ED70: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ED74: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 00000013ED78: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000013ED80: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000013ED8C: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013ED90: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 00000013ED94: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000013ED98: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000013EDA0: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013EDA8: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000013EDAC: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000013EDB0: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000013EDB4: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EDB8: BF870095
	.long 0xd71c0011                                           // 00000013EDBC: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000013EDC0: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000013EDC4: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000013EDC8: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EDD0: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v134, v20// 00000013EDD4: CA4622FF 10102986 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000013EDE0: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EDE4: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 00000013EDE8: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000013EDF0: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EDF4: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 00000013EDF8: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000013EE00: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 00000013EE04: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EE0C: BF870091
	v_mul_f32_e32 v24, v20, v19                                // 00000013EE10: 10302714
	v_fma_f32 v25, -v18, v24, v20                              // 00000013EE14: D6130019 24523112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EE1C: BF870091
	v_fmac_f32_e32 v24, v25, v19                               // 00000013EE20: 56302719
	v_fma_f32 v18, -v18, v24, v20                              // 00000013EE24: D6130012 24523112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EE2C: BF870091
	v_div_fmas_f32 v18, v18, v19, v24                          // 00000013EE30: D6370012 04622712
	v_div_fixup_f32 v18, v18, v16, v17                         // 00000013EE38: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v123, v[128:129]     // 00000013EE40: D6FF7C10 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EE4C: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 00000013EE50: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 00000013EE58: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 00000013EE64: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013EE6C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000013EE70: BE882005
	s_cbranch_execz 58137                                      // 00000013EE74: BFA5E319 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42dc>
	v_mad_i64_i32 v[16:17], null, 0x6000, v124, v[130:131]     // 00000013EE78: D6FF7C10 060AF8FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 00000013EE84: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000013EE8C: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000013EE90: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EE94: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 00000013EE98: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000013EEA0: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000013EEAC: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013EEB0: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 00000013EEB4: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000013EEB8: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000013EEC0: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013EEC8: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000013EECC: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000013EED0: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000013EED4: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EED8: BF870095
	.long 0xd71c0011                                           // 00000013EEDC: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000013EEE0: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000013EEE4: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000013EEE8: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EEF0: BF870092
	v_cndmask_b32_e32 v16, 0x7f800000, v17, vcc_lo             // 00000013EEF4: 022022FF 7F800000
	v_dual_mul_f32 v17, v135, v21 :: v_dual_add_f32 v16, 1.0, v16// 00000013EEFC: C8C82B87 111020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EF04: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 00000013EF08: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000013EF10: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EF14: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 00000013EF18: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000013EF20: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 00000013EF24: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EF2C: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 00000013EF30: 102A2714
	v_fma_f32 v24, -v18, v21, v20                              // 00000013EF34: D6130018 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EF3C: BF870091
	v_fmac_f32_e32 v21, v24, v19                               // 00000013EF40: 562A2718
	v_fma_f32 v18, -v18, v21, v20                              // 00000013EF44: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EF4C: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 00000013EF50: D6370012 04562712
	v_div_fixup_f32 v18, v18, v16, v17                         // 00000013EF58: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v124, v[128:129]     // 00000013EF60: D6FF7C10 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EF6C: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 00000013EF70: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 00000013EF78: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 00000013EF84: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013EF8C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000013EF90: BE882006
	s_cbranch_execz 58068                                      // 00000013EF94: BFA5E2D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42e8>
	v_mad_i64_i32 v[16:17], null, 0x6000, v125, v[130:131]     // 00000013EF98: D6FF7C10 060AFAFF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 00000013EFA4: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000013EFAC: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000013EFB0: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EFB4: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 00000013EFB8: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000013EFC0: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000013EFCC: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013EFD0: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 00000013EFD4: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000013EFD8: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000013EFE0: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013EFE8: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000013EFEC: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000013EFF0: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000013EFF4: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EFF8: BF870095
	.long 0xd71c0011                                           // 00000013EFFC: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000013F000: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000013F004: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000013F008: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F010: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v132, v22// 00000013F014: CA4622FF 10102D84 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000013F020: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F024: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 00000013F028: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000013F030: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F034: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 00000013F038: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000013F040: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 00000013F044: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F04C: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 00000013F050: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 00000013F054: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F05C: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 00000013F060: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 00000013F064: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F06C: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 00000013F070: D6370012 04562712
	v_div_fixup_f32 v18, v18, v16, v17                         // 00000013F078: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v125, v[128:129]     // 00000013F080: D6FF7C10 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F08C: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 00000013F090: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 00000013F098: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 00000013F0A4: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013F0AC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013F0B0: BE882007
	s_cbranch_execz 57999                                      // 00000013F0B4: BFA5E28F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42f4>
	v_mad_i64_i32 v[16:17], null, 0x6000, v126, v[130:131]     // 00000013F0B8: D6FF7C10 060AFCFF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 00000013F0C4: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000013F0CC: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000013F0D0: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F0D4: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 00000013F0D8: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000013F0E0: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000013F0EC: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013F0F0: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 00000013F0F4: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000013F0F8: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000013F100: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013F108: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000013F10C: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000013F110: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000013F114: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F118: BF870095
	.long 0xd71c0011                                           // 00000013F11C: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000013F120: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000013F124: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000013F128: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F130: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v133, v23// 00000013F134: CA4622FF 10102F85 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000013F140: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F144: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 00000013F148: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000013F150: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F154: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 00000013F158: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000013F160: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 00000013F164: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F16C: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 00000013F170: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 00000013F174: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F17C: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 00000013F180: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 00000013F184: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F18C: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 00000013F190: D6370012 04562712
	v_div_fixup_f32 v18, v18, v16, v17                         // 00000013F198: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v126, v[128:129]     // 00000013F1A0: D6FF7C10 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F1AC: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 00000013F1B0: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 00000013F1B8: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 00000013F1C4: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013F1CC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000013F1D0: BE882000
	s_cbranch_execz 57930                                      // 00000013F1D4: BFA5E24A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4300>
	v_mad_i64_i32 v[16:17], null, 0x6000, v140, v[130:131]     // 00000013F1D8: D6FF7C10 060B18FF 00006000
	v_mul_f32_e32 v8, v138, v8                                 // 00000013F1E4: 1010118A
	global_load_u16 v16, v[16:17], off offset:960              // 00000013F1E8: DC4A03C0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000013F1F0: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000013F1F4: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F1F8: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 00000013F1FC: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000013F204: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000013F210: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013F214: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 00000013F218: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000013F21C: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000013F224: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013F22C: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000013F230: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000013F234: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000013F238: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F23C: BF870095
	.long 0xd71c0011                                           // 00000013F240: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000013F244: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000013F248: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000013F24C: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F254: BF870092
	v_cndmask_b32_e32 v16, 0x7f800000, v17, vcc_lo             // 00000013F258: 022022FF 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000013F260: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F264: BF870091
	v_div_scale_f32 v17, null, v16, v16, v8                    // 00000013F268: D6FC7C11 04222110
	v_rcp_f32_e32 v18, v17                                     // 00000013F270: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F274: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 00000013F278: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 00000013F280: 56242513
	v_div_scale_f32 v19, vcc_lo, v8, v16, v8                   // 00000013F284: D6FC6A13 04222108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F28C: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 00000013F290: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 00000013F294: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F29C: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 00000013F2A0: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 00000013F2A4: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F2AC: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 00000013F2B0: D6370011 04522511
	v_div_fixup_f32 v8, v17, v16, v8                           // 00000013F2B8: D6270008 04222111
	v_mad_i64_i32 v[16:17], null, 0x3000, v140, v[128:129]     // 00000013F2C0: D6FF7C10 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F2CC: BF870092
	v_bfe_u32 v18, v8, 16, 1                                   // 00000013F2D0: D6100012 02052108
	v_add3_u32 v8, v8, v18, 0x7fff                             // 00000013F2D8: D6550008 03FE2508 00007FFF
	global_store_d16_hi_b16 v[16:17], v8, off offset:448       // 00000013F2E4: DC9601C0 007C0810
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013F2EC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000013F2F0: BE882001
	s_cbranch_execz 57861                                      // 00000013F2F4: BFA5E205 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x430c>
	v_mad_i64_i32 v[16:17], null, 0x6000, v120, v[130:131]     // 00000013F2F8: D6FF7C10 060AF0FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 00000013F304: 1012138B
	global_load_u16 v8, v[16:17], off offset:960               // 00000013F308: DC4A03C0 087C0010
	s_waitcnt vmcnt(0)                                         // 00000013F310: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000013F314: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013F318: BF870121
	v_mul_f32_e32 v16, 0xbfb8aa3b, v8                          // 00000013F31C: 102010FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000013F324: 7C3C10FF 42CE8ED0
	v_fma_f32 v17, 0xbfb8aa3b, v8, -v16                        // 00000013F32C: D6130011 844210FF BFB8AA3B
	v_rndne_f32_e32 v18, v16                                   // 00000013F338: 7E244710
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013F33C: BF870112
	v_fmamk_f32 v17, v8, 0xb2a5705f, v17                       // 00000013F340: 58222308 B2A5705F
	v_sub_f32_e32 v16, v16, v18                                // 00000013F348: 08202510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013F34C: BF870121
	v_add_f32_e32 v16, v16, v17                                // 00000013F350: 06202310
	v_cvt_i32_f32_e32 v17, v18                                 // 00000013F354: 7E221112
	v_exp_f32_e32 v16, v16                                     // 00000013F358: 7E204B10
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F35C: BF870095
	.long 0xd71c0010                                           // 00000013F360: D71C0010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                     // 00000013F364: 02022310
	v_cndmask_b32_e32 v16, 0, v16, vcc_lo                      // 00000013F368: 02202080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000013F36C: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F374: BF870092
	v_cndmask_b32_e32 v8, 0x7f800000, v16, vcc_lo              // 00000013F378: 021020FF 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 00000013F380: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F384: BF870091
	v_div_scale_f32 v16, null, v8, v8, v9                      // 00000013F388: D6FC7C10 04261108
	v_rcp_f32_e32 v17, v16                                     // 00000013F390: 7E225510
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F394: BF870095
	v_fma_f32 v18, -v16, v17, 1.0                              // 00000013F398: D6130012 23CA2310
	v_fmac_f32_e32 v17, v18, v17                               // 00000013F3A0: 56222312
	v_div_scale_f32 v18, vcc_lo, v9, v8, v9                    // 00000013F3A4: D6FC6A12 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F3AC: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 00000013F3B0: 10262312
	v_fma_f32 v20, -v16, v19, v18                              // 00000013F3B4: D6130014 244A2710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F3BC: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 00000013F3C0: 56262314
	v_fma_f32 v16, -v16, v19, v18                              // 00000013F3C4: D6130010 244A2710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F3CC: BF870091
	v_div_fmas_f32 v16, v16, v17, v19                          // 00000013F3D0: D6370010 044E2310
	v_div_fixup_f32 v16, v16, v8, v9                           // 00000013F3D8: D6270010 04261110
	v_mad_i64_i32 v[8:9], null, 0x3000, v120, v[128:129]       // 00000013F3E0: D6FF7C08 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F3EC: BF870092
	v_bfe_u32 v17, v16, 16, 1                                  // 00000013F3F0: D6100011 02052110
	v_add3_u32 v16, v16, v17, 0x7fff                           // 00000013F3F8: D6550010 03FE2310 00007FFF
	global_store_d16_hi_b16 v[8:9], v16, off offset:448        // 00000013F404: DC9601C0 007C1008
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013F40C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000013F410: BE882002
	s_cbranch_execz 57792                                      // 00000013F414: BFA5E1C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4318>
	v_mad_i64_i32 v[8:9], null, 0x6000, v121, v[130:131]       // 00000013F418: D6FF7C08 060AF2FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 00000013F424: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000013F42C: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000013F430: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F434: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000013F438: 101210FF BFB8AA3B
	v_fma_f32 v16, 0xbfb8aa3b, v8, -v9                         // 00000013F440: D6130010 842610FF BFB8AA3B
	v_rndne_f32_e32 v17, v9                                    // 00000013F44C: 7E224709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013F450: BF870221
	v_sub_f32_e32 v9, v9, v17                                  // 00000013F454: 08122309
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000013F458: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v16, v8, 0xb2a5705f, v16                       // 00000013F460: 58202108 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013F468: BF870121
	v_add_f32_e32 v9, v9, v16                                  // 00000013F46C: 06122109
	v_cvt_i32_f32_e32 v16, v17                                 // 00000013F470: 7E201111
	v_exp_f32_e32 v9, v9                                       // 00000013F474: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F478: BF870095
	.long 0xd71c0009                                           // 00000013F47C: D71C0009
	v_cndmask_b32_e32 v1, v9, v16, vcc_lo                      // 00000013F480: 02022109
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000013F484: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000013F488: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F490: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v136, v10// 00000013F494: CA4612FF 08081588 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 00000013F4A0: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F4A4: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 00000013F4A8: D6FC7C0A 04261108
	v_rcp_f32_e32 v16, v10                                     // 00000013F4B0: 7E20550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F4B4: BF870095
	v_fma_f32 v17, -v10, v16, 1.0                              // 00000013F4B8: D6130011 23CA210A
	v_fmac_f32_e32 v16, v17, v16                               // 00000013F4C0: 56202111
	v_div_scale_f32 v17, vcc_lo, v9, v8, v9                    // 00000013F4C4: D6FC6A11 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F4CC: BF870091
	v_mul_f32_e32 v18, v17, v16                                // 00000013F4D0: 10242111
	v_fma_f32 v19, -v10, v18, v17                              // 00000013F4D4: D6130013 2446250A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F4DC: BF870091
	v_fmac_f32_e32 v18, v19, v16                               // 00000013F4E0: 56242113
	v_fma_f32 v10, -v10, v18, v17                              // 00000013F4E4: D613000A 2446250A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F4EC: BF870091
	v_div_fmas_f32 v10, v10, v16, v18                          // 00000013F4F0: D637000A 044A210A
	v_div_fixup_f32 v10, v10, v8, v9                           // 00000013F4F8: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v121, v[128:129]       // 00000013F500: D6FF7C08 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F50C: BF870092
	v_bfe_u32 v16, v10, 16, 1                                  // 00000013F510: D6100010 0205210A
	v_add3_u32 v10, v10, v16, 0x7fff                           // 00000013F518: D655000A 03FE210A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 00000013F524: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013F52C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013F530: BE882003
	s_cbranch_execz 57723                                      // 00000013F534: BFA5E17B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4324>
	v_mad_i64_i32 v[8:9], null, 0x6000, v122, v[130:131]       // 00000013F538: D6FF7C08 060AF4FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 00000013F544: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000013F54C: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000013F550: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F554: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000013F558: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 00000013F560: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v16, v9                                    // 00000013F56C: 7E204709
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F570: BF870091
	v_dual_fmamk_f32 v10, v8, 0xb2a5705f, v10 :: v_dual_sub_f32 v9, v9, v16// 00000013F574: C88A1508 0A082109 B2A5705F
	v_add_f32_e32 v9, v9, v10                                  // 00000013F580: 06121509
	v_cvt_i32_f32_e32 v10, v16                                 // 00000013F584: 7E141110
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000013F588: 7C3C10FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013F590: BF870293
	v_exp_f32_e32 v9, v9                                       // 00000013F594: 7E124B09
	.long 0xd71c0009                                           // 00000013F598: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000013F59C: 02021509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013F5A0: BF870121
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000013F5A4: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000013F5A8: 7C3610FF C2B17218
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v137, v11// 00000013F5B0: CA4612FF 08081789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F5BC: BF870091
	v_add_f32_e32 v8, 1.0, v8                                  // 00000013F5C0: 061010F2
	v_div_scale_f32 v10, null, v8, v8, v9                      // 00000013F5C4: D6FC7C0A 04261108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013F5CC: BF870291
	v_rcp_f32_e32 v11, v10                                     // 00000013F5D0: 7E16550A
	v_fma_f32 v16, -v10, v11, 1.0                              // 00000013F5D4: D6130010 23CA170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013F5DC: BF8700A1
	v_fmac_f32_e32 v11, v16, v11                               // 00000013F5E0: 56161710
	v_div_scale_f32 v16, vcc_lo, v9, v8, v9                    // 00000013F5E4: D6FC6A10 04261109
	v_mul_f32_e32 v17, v16, v11                                // 00000013F5EC: 10221710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F5F0: BF870091
	v_fma_f32 v18, -v10, v17, v16                              // 00000013F5F4: D6130012 2442230A
	v_fmac_f32_e32 v17, v18, v11                               // 00000013F5FC: 56221712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F600: BF870091
	v_fma_f32 v10, -v10, v17, v16                              // 00000013F604: D613000A 2442230A
	v_div_fmas_f32 v10, v10, v11, v17                          // 00000013F60C: D637000A 0446170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013F614: BF870121
	v_div_fixup_f32 v10, v10, v8, v9                           // 00000013F618: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v122, v[128:129]       // 00000013F620: D6FF7C08 0602F4FF 00003000
	v_bfe_u32 v11, v10, 16, 1                                  // 00000013F62C: D610000B 0205210A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013F634: BF870001
	v_add3_u32 v10, v10, v11, 0x7fff                           // 00000013F638: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 00000013F644: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013F64C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000013F650: BE882004
	s_cbranch_execz 57654                                      // 00000013F654: BFA5E136 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4330>
	v_mad_i64_i32 v[8:9], null, 0x6000, v123, v[130:131]       // 00000013F658: D6FF7C08 060AF6FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 00000013F664: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000013F66C: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000013F670: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F674: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000013F678: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 00000013F680: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 00000013F68C: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013F690: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 00000013F694: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000013F698: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 00000013F6A0: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013F6A8: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 00000013F6AC: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 00000013F6B0: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 00000013F6B4: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F6B8: BF870095
	.long 0xd71c0009                                           // 00000013F6BC: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000013F6C0: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000013F6C4: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000013F6C8: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F6D0: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v134, v12// 00000013F6D4: CA4612FF 08081986 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 00000013F6E0: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F6E4: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 00000013F6E8: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 00000013F6F0: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F6F4: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 00000013F6F8: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000013F700: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 00000013F704: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F70C: BF870091
	v_mul_f32_e32 v16, v12, v11                                // 00000013F710: 1020170C
	v_fma_f32 v17, -v10, v16, v12                              // 00000013F714: D6130011 2432210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F71C: BF870091
	v_fmac_f32_e32 v16, v17, v11                               // 00000013F720: 56201711
	v_fma_f32 v10, -v10, v16, v12                              // 00000013F724: D613000A 2432210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F72C: BF870091
	v_div_fmas_f32 v10, v10, v11, v16                          // 00000013F730: D637000A 0442170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 00000013F738: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v123, v[128:129]       // 00000013F740: D6FF7C08 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F74C: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 00000013F750: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 00000013F758: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 00000013F764: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013F76C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000013F770: BE882005
	s_cbranch_execz 57585                                      // 00000013F774: BFA5E0F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x433c>
	v_mad_i64_i32 v[8:9], null, 0x6000, v124, v[130:131]       // 00000013F778: D6FF7C08 060AF8FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 00000013F784: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000013F78C: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000013F790: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F794: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000013F798: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 00000013F7A0: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 00000013F7AC: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013F7B0: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 00000013F7B4: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000013F7B8: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 00000013F7C0: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013F7C8: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 00000013F7CC: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 00000013F7D0: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 00000013F7D4: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F7D8: BF870095
	.long 0xd71c0009                                           // 00000013F7DC: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000013F7E0: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000013F7E4: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000013F7E8: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F7F0: BF870092
	v_cndmask_b32_e32 v8, 0x7f800000, v9, vcc_lo               // 00000013F7F4: 021012FF 7F800000
	v_dual_mul_f32 v9, v135, v13 :: v_dual_add_f32 v8, 1.0, v8 // 00000013F7FC: C8C81B87 090810F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F804: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 00000013F808: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 00000013F810: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F814: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 00000013F818: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000013F820: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 00000013F824: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F82C: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 00000013F830: 101A170C
	v_fma_f32 v16, -v10, v13, v12                              // 00000013F834: D6130010 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F83C: BF870091
	v_fmac_f32_e32 v13, v16, v11                               // 00000013F840: 561A1710
	v_fma_f32 v10, -v10, v13, v12                              // 00000013F844: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F84C: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 00000013F850: D637000A 0436170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 00000013F858: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v124, v[128:129]       // 00000013F860: D6FF7C08 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F86C: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 00000013F870: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 00000013F878: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 00000013F884: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013F88C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000013F890: BE882006
	s_cbranch_execz 57516                                      // 00000013F894: BFA5E0AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4348>
	v_mad_i64_i32 v[8:9], null, 0x6000, v125, v[130:131]       // 00000013F898: D6FF7C08 060AFAFF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 00000013F8A4: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000013F8AC: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000013F8B0: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F8B4: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000013F8B8: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 00000013F8C0: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 00000013F8CC: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013F8D0: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 00000013F8D4: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000013F8D8: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 00000013F8E0: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013F8E8: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 00000013F8EC: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 00000013F8F0: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 00000013F8F4: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F8F8: BF870095
	.long 0xd71c0009                                           // 00000013F8FC: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000013F900: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000013F904: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000013F908: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F910: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v132, v14// 00000013F914: CA4612FF 08081D84 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 00000013F920: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F924: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 00000013F928: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 00000013F930: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F934: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 00000013F938: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000013F940: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 00000013F944: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F94C: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 00000013F950: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 00000013F954: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F95C: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 00000013F960: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 00000013F964: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F96C: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 00000013F970: D637000A 0436170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 00000013F978: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v125, v[128:129]       // 00000013F980: D6FF7C08 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F98C: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 00000013F990: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 00000013F998: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 00000013F9A4: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013F9AC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000013F9B0: BE882007
	s_cbranch_execz 57447                                      // 00000013F9B4: BFA5E067 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4354>
	v_mad_i64_i32 v[8:9], null, 0x6000, v126, v[130:131]       // 00000013F9B8: D6FF7C08 060AFCFF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 00000013F9C4: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000013F9CC: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000013F9D0: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F9D4: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000013F9D8: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 00000013F9E0: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 00000013F9EC: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013F9F0: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 00000013F9F4: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000013F9F8: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 00000013FA00: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013FA08: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 00000013FA0C: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 00000013FA10: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 00000013FA14: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FA18: BF870095
	.long 0xd71c0009                                           // 00000013FA1C: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000013FA20: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000013FA24: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000013FA28: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FA30: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v133, v15// 00000013FA34: CA4612FF 08081F85 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 00000013FA40: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FA44: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 00000013FA48: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 00000013FA50: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FA54: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 00000013FA58: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000013FA60: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 00000013FA64: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FA6C: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 00000013FA70: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 00000013FA74: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FA7C: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 00000013FA80: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 00000013FA84: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FA8C: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 00000013FA90: D637000A 0436170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 00000013FA98: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v126, v[128:129]       // 00000013FAA0: D6FF7C08 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FAAC: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 00000013FAB0: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 00000013FAB8: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 00000013FAC4: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013FACC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000013FAD0: BE882000
	s_cbranch_execz 57378                                      // 00000013FAD4: BFA5E022 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4360>
	v_mad_i64_i32 v[8:9], null, 0x6000, v140, v[130:131]       // 00000013FAD8: D6FF7C08 060B18FF 00006000
	v_mul_f32_e32 v0, v138, v0                                 // 00000013FAE4: 1000018A
	global_load_u16 v8, v[8:9], off offset:992                 // 00000013FAE8: DC4A03E0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000013FAF0: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000013FAF4: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FAF8: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000013FAFC: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 00000013FB04: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 00000013FB10: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013FB14: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 00000013FB18: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000013FB1C: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 00000013FB24: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013FB2C: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 00000013FB30: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 00000013FB34: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 00000013FB38: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FB3C: BF870095
	.long 0xd71c0009                                           // 00000013FB40: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000013FB44: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000013FB48: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000013FB4C: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FB54: BF870092
	v_cndmask_b32_e32 v8, 0x7f800000, v9, vcc_lo               // 00000013FB58: 021012FF 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 00000013FB60: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FB64: BF870091
	v_div_scale_f32 v9, null, v8, v8, v0                       // 00000013FB68: D6FC7C09 04021108
	v_rcp_f32_e32 v10, v9                                      // 00000013FB70: 7E145509
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FB74: BF870095
	v_fma_f32 v11, -v9, v10, 1.0                               // 00000013FB78: D613000B 23CA1509
	v_fmac_f32_e32 v10, v11, v10                               // 00000013FB80: 5614150B
	v_div_scale_f32 v11, vcc_lo, v0, v8, v0                    // 00000013FB84: D6FC6A0B 04021100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FB8C: BF870091
	v_mul_f32_e32 v12, v11, v10                                // 00000013FB90: 1018150B
	v_fma_f32 v13, -v9, v12, v11                               // 00000013FB94: D613000D 242E1909
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FB9C: BF870091
	v_fmac_f32_e32 v12, v13, v10                               // 00000013FBA0: 5618150D
	v_fma_f32 v9, -v9, v12, v11                                // 00000013FBA4: D6130009 242E1909
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FBAC: BF870091
	v_div_fmas_f32 v9, v9, v10, v12                            // 00000013FBB0: D6370009 04321509
	v_div_fixup_f32 v0, v9, v8, v0                             // 00000013FBB8: D6270000 04021109
	v_mad_i64_i32 v[8:9], null, 0x3000, v140, v[128:129]       // 00000013FBC0: D6FF7C08 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FBCC: BF870092
	v_bfe_u32 v10, v0, 16, 1                                   // 00000013FBD0: D610000A 02052100
	v_add3_u32 v0, v0, v10, 0x7fff                             // 00000013FBD8: D6550000 03FE1500 00007FFF
	global_store_d16_hi_b16 v[8:9], v0, off offset:480         // 00000013FBE4: DC9601E0 007C0008
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013FBEC: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000013FBF0: BE802001
	s_cbranch_execz 57309                                      // 00000013FBF4: BFA5DFDD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x436c>
	v_mad_i64_i32 v[8:9], null, 0x6000, v120, v[130:131]       // 00000013FBF8: D6FF7C08 060AF0FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 00000013FC04: 1002038B
	global_load_u16 v0, v[8:9], off offset:992                 // 00000013FC08: DC4A03E0 007C0008
	s_waitcnt vmcnt(0)                                         // 00000013FC10: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000013FC14: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013FC18: BF870121
	v_mul_f32_e32 v8, 0xbfb8aa3b, v0                           // 00000013FC1C: 101000FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000013FC24: 7C3C00FF 42CE8ED0
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v8                          // 00000013FC2C: D6130009 842200FF BFB8AA3B
	v_rndne_f32_e32 v10, v8                                    // 00000013FC38: 7E144708
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013FC3C: BF870112
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 00000013FC40: 58121300 B2A5705F
	v_sub_f32_e32 v8, v8, v10                                  // 00000013FC48: 08101508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013FC4C: BF870121
	v_add_f32_e32 v8, v8, v9                                   // 00000013FC50: 06101308
	v_cvt_i32_f32_e32 v9, v10                                  // 00000013FC54: 7E12110A
	v_exp_f32_e32 v8, v8                                       // 00000013FC58: 7E104B08
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FC5C: BF870095
	.long 0xd71c0008                                           // 00000013FC60: D71C0008
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 00000013FC64: 02021308
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo                        // 00000013FC68: 02101080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000013FC6C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FC74: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v8, vcc_lo               // 00000013FC78: 020010FF 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000013FC80: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FC84: BF870091
	v_div_scale_f32 v8, null, v0, v0, v1                       // 00000013FC88: D6FC7C08 04060100
	v_rcp_f32_e32 v9, v8                                       // 00000013FC90: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FC94: BF870095
	v_fma_f32 v10, -v8, v9, 1.0                                // 00000013FC98: D613000A 23CA1308
	v_fmac_f32_e32 v9, v10, v9                                 // 00000013FCA0: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 00000013FCA4: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FCAC: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 00000013FCB0: 1016130A
	v_fma_f32 v12, -v8, v11, v10                               // 00000013FCB4: D613000C 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FCBC: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 00000013FCC0: 5616130C
	v_fma_f32 v8, -v8, v11, v10                                // 00000013FCC4: D6130008 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FCCC: BF870091
	v_div_fmas_f32 v8, v8, v9, v11                             // 00000013FCD0: D6370008 042E1308
	v_div_fixup_f32 v8, v8, v0, v1                             // 00000013FCD8: D6270008 04060108
	v_mad_i64_i32 v[0:1], null, 0x3000, v120, v[128:129]       // 00000013FCE0: D6FF7C00 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FCEC: BF870092
	v_bfe_u32 v9, v8, 16, 1                                    // 00000013FCF0: D6100009 02052108
	v_add3_u32 v8, v8, v9, 0x7fff                              // 00000013FCF8: D6550008 03FE1308 00007FFF
	global_store_d16_hi_b16 v[0:1], v8, off offset:480         // 00000013FD04: DC9601E0 007C0800
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013FD0C: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000013FD10: BE802002
	s_cbranch_execz 57240                                      // 00000013FD14: BFA5DF98 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4378>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[130:131]       // 00000013FD18: D6FF7C00 060AF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000013FD24: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000013FD2C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000013FD30: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FD34: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000013FD38: 100200FF BFB8AA3B
	v_fma_f32 v8, 0xbfb8aa3b, v0, -v1                          // 00000013FD40: D6130008 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 00000013FD4C: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013FD50: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 00000013FD54: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000013FD58: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v8, v0, 0xb2a5705f, v8                         // 00000013FD60: 58101100 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013FD68: BF870121
	v_add_f32_e32 v1, v1, v8                                   // 00000013FD6C: 06021101
	v_cvt_i32_f32_e32 v8, v9                                   // 00000013FD70: 7E101109
	v_exp_f32_e32 v1, v1                                       // 00000013FD74: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FD78: BF870095
	.long 0xd71c0001                                           // 00000013FD7C: D71C0001
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 00000013FD80: 02021101
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000013FD84: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000013FD88: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FD90: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v2// 00000013FD94: CA4602FF 00000588 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000013FDA0: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FDA4: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000013FDA8: D6FC7C02 04060100
	v_rcp_f32_e32 v8, v2                                       // 00000013FDB0: 7E105502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FDB4: BF870095
	v_fma_f32 v9, -v2, v8, 1.0                                 // 00000013FDB8: D6130009 23CA1102
	v_fmac_f32_e32 v8, v9, v8                                  // 00000013FDC0: 56101109
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 00000013FDC4: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FDCC: BF870091
	v_mul_f32_e32 v10, v9, v8                                  // 00000013FDD0: 10141109
	v_fma_f32 v11, -v2, v10, v9                                // 00000013FDD4: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FDDC: BF870091
	v_fmac_f32_e32 v10, v11, v8                                // 00000013FDE0: 5614110B
	v_fma_f32 v2, -v2, v10, v9                                 // 00000013FDE4: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FDEC: BF870091
	v_div_fmas_f32 v2, v2, v8, v10                             // 00000013FDF0: D6370002 042A1102
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000013FDF8: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[128:129]       // 00000013FE00: D6FF7C00 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FE0C: BF870092
	v_bfe_u32 v8, v2, 16, 1                                    // 00000013FE10: D6100008 02052102
	v_add3_u32 v2, v2, v8, 0x7fff                              // 00000013FE18: D6550002 03FE1102 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000013FE24: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013FE2C: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000013FE30: BE802003
	s_cbranch_execz 57171                                      // 00000013FE34: BFA5DF53 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4384>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[130:131]       // 00000013FE38: D6FF7C00 060AF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000013FE44: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000013FE4C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000013FE50: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FE54: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000013FE58: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000013FE60: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v8, v1                                     // 00000013FE6C: 7E104701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FE70: BF870091
	v_dual_fmamk_f32 v2, v0, 0xb2a5705f, v2 :: v_dual_sub_f32 v1, v1, v8// 00000013FE74: C88A0500 02001101 B2A5705F
	v_add_f32_e32 v1, v1, v2                                   // 00000013FE80: 06020501
	v_cvt_i32_f32_e32 v2, v8                                   // 00000013FE84: 7E041108
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000013FE88: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013FE90: BF870293
	v_exp_f32_e32 v1, v1                                       // 00000013FE94: 7E024B01
	.long 0xd71c0001                                           // 00000013FE98: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000013FE9C: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013FEA0: BF870121
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000013FEA4: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000013FEA8: 7C3600FF C2B17218
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 00000013FEB0: CA4602FF 00000789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FEBC: BF870091
	v_add_f32_e32 v0, 1.0, v0                                  // 00000013FEC0: 060000F2
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000013FEC4: D6FC7C02 04060100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013FECC: BF870291
	v_rcp_f32_e32 v3, v2                                       // 00000013FED0: 7E065502
	v_fma_f32 v8, -v2, v3, 1.0                                 // 00000013FED4: D6130008 23CA0702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013FEDC: BF8700A1
	v_fmac_f32_e32 v3, v8, v3                                  // 00000013FEE0: 56060708
	v_div_scale_f32 v8, vcc_lo, v1, v0, v1                     // 00000013FEE4: D6FC6A08 04060101
	v_mul_f32_e32 v9, v8, v3                                   // 00000013FEEC: 10120708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FEF0: BF870091
	v_fma_f32 v10, -v2, v9, v8                                 // 00000013FEF4: D613000A 24221302
	v_fmac_f32_e32 v9, v10, v3                                 // 00000013FEFC: 5612070A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FF00: BF870091
	v_fma_f32 v2, -v2, v9, v8                                  // 00000013FF04: D6130002 24221302
	v_div_fmas_f32 v2, v2, v3, v9                              // 00000013FF0C: D6370002 04260702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013FF14: BF870121
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000013FF18: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[128:129]       // 00000013FF20: D6FF7C00 0602F4FF 00003000
	v_bfe_u32 v3, v2, 16, 1                                    // 00000013FF2C: D6100003 02052102
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013FF34: BF870001
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000013FF38: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000013FF44: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013FF4C: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000013FF50: BE802004
	s_cbranch_execz 57102                                      // 00000013FF54: BFA5DF0E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4390>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[130:131]       // 00000013FF58: D6FF7C00 060AF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000013FF64: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000013FF6C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000013FF70: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FF74: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000013FF78: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000013FF80: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000013FF8C: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013FF90: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000013FF94: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000013FF98: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000013FFA0: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013FFA8: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000013FFAC: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000013FFB0: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000013FFB4: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FFB8: BF870095
	.long 0xd71c0001                                           // 00000013FFBC: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000013FFC0: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000013FFC4: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000013FFC8: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FFD0: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v4// 00000013FFD4: CA4602FF 00000986 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000013FFE0: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FFE4: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000013FFE8: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000013FFF0: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013FFF4: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000013FFF8: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000140000: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000140004: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014000C: BF870091
	v_mul_f32_e32 v8, v4, v3                                   // 000000140010: 10100704
	v_fma_f32 v9, -v2, v8, v4                                  // 000000140014: D6130009 24121102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014001C: BF870091
	v_fmac_f32_e32 v8, v9, v3                                  // 000000140020: 56100709
	v_fma_f32 v2, -v2, v8, v4                                  // 000000140024: D6130002 24121102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014002C: BF870091
	v_div_fmas_f32 v2, v2, v3, v8                              // 000000140030: D6370002 04220702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000140038: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[128:129]       // 000000140040: D6FF7C00 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014004C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000140050: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000140058: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000140064: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014006C: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000140070: BE802005
	s_cbranch_execz 57033                                      // 000000140074: BFA5DEC9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x439c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[130:131]       // 000000140078: D6FF7C00 060AF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000140084: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000014008C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000140090: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000140094: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000140098: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000001400A0: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000001400AC: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001400B0: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000001400B4: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000001400B8: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000001400C0: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001400C8: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000001400CC: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000001400D0: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000001400D4: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001400D8: BF870095
	.long 0xd71c0001                                           // 0000001400DC: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000001400E0: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000001400E4: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000001400E8: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001400F0: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 0000001400F4: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 0000001400FC: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000140104: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000140108: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000140110: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000140114: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000140118: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000140120: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000140124: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014012C: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000140130: 100A0704
	v_fma_f32 v8, -v2, v5, v4                                  // 000000140134: D6130008 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014013C: BF870091
	v_fmac_f32_e32 v5, v8, v3                                  // 000000140140: 560A0708
	v_fma_f32 v2, -v2, v5, v4                                  // 000000140144: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014014C: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000140150: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000140158: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[128:129]       // 000000140160: D6FF7C00 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014016C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000140170: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000140178: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000140184: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014018C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000140190: BE802006
	s_cbranch_execz 56964                                      // 000000140194: BFA5DE84 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x43a8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[130:131]       // 000000140198: D6FF7C00 060AFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000001401A4: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000001401AC: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000001401B0: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001401B4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000001401B8: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000001401C0: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000001401CC: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001401D0: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000001401D4: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000001401D8: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000001401E0: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001401E8: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000001401EC: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000001401F0: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000001401F4: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001401F8: BF870095
	.long 0xd71c0001                                           // 0000001401FC: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000140200: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000140204: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000140208: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000140210: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v132, v6// 000000140214: CA4602FF 00000D84 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000140220: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000140224: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000140228: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000140230: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000140234: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000140238: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000140240: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000140244: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014024C: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000140250: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 000000140254: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014025C: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 000000140260: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 000000140264: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014026C: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000140270: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000140278: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[128:129]       // 000000140280: D6FF7C00 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014028C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000140290: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000140298: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001402A4: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001402AC: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001402B0: BE802007
	s_cbranch_execz 56895                                      // 0000001402B4: BFA5DE3F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi7ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x43b4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[130:131]       // 0000001402B8: D6FF7C00 060AFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000001402C4: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000001402CC: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000001402D0: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001402D4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000001402D8: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000001402E0: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000001402EC: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001402F0: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000001402F4: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000001402F8: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000140300: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000140308: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000014030C: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000140310: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000140314: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000140318: BF870095
	.long 0xd71c0001                                           // 00000014031C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000140320: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000140324: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000140328: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000140330: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 000000140334: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000140340: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000140344: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000140348: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000140350: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000140354: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000140358: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000140360: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000140364: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014036C: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000140370: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 000000140374: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014037C: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 000000140380: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 000000140384: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014038C: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000140390: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000140398: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[128:129]       // 0000001403A0: D6FF7C00 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001403AC: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000001403B0: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000001403B8: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001403C4: DC9601E0 007C0200
	s_endpgm                                                   // 0000001403CC: BFB00000
		...

