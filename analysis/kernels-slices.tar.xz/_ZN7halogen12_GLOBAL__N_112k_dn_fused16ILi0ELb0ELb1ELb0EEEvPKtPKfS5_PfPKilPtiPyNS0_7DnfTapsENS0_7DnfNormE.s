0000000000019f00 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE>:
; _ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE():
	s_clause 0x1                                               // 000000019F00: BF850001
	s_load_b256 s[20:27], s[0:1], 0x20                         // 000000019F04: F40C0500 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 000000019F0C: F40C0200 F8000000
	v_dual_mov_b32 v144, 0 :: v_dual_lshlrev_b32 v1, 5, v0     // 000000019F14: CA220080 90000085
	s_ashr_i32 s3, s2, 31                                      // 000000019F1C: 86039F02
	v_lshrrev_b32_e32 v74, 4, v0                               // 000000019F20: 32940084
	s_load_b32 s31, s[0:1], 0x38                               // 000000019F24: F40007C0 F8000038
	v_lshlrev_b32_e32 v66, 4, v0                               // 000000019F2C: 30840084
	v_and_b32_e32 v3, 0x200, v1                                // 000000019F30: 360602FF 00000200
	s_delay_alu instid0(VALU_DEP_3)                            // 000000019F38: BF870003
	v_lshlrev_b32_e32 v65, 9, v74                              // 000000019F3C: 30829489
	s_waitcnt lgkmcnt(0)                                       // 000000019F40: BF89FC07
	s_load_b32 s6, s[20:21], null                              // 000000019F44: F400018A F8000000
	v_readfirstlane_b32 s20, v0                                // 000000019F4C: 7E280500
	s_lshl_b64 s[4:5], s[22:23], 2                             // 000000019F50: 84848216
	s_lshr_b32 s21, s20, 5                                     // 000000019F54: 85158514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000019F58: BF8704D9
	s_lshl_b32 s30, s21, 4                                     // 000000019F5C: 841E8415
	s_add_u32 s4, s14, s4                                      // 000000019F60: 8004040E
	v_and_or_b32 v143, v0, 15, s30                             // 000000019F64: D657008F 00791F00
	s_addc_u32 s5, s15, s5                                     // 000000019F6C: 8205050F
	s_lshl_b64 s[22:23], s[2:3], 16                            // 000000019F70: 84969002
	s_add_u32 s4, s4, s22                                      // 000000019F74: 80041604
	s_delay_alu instid0(VALU_DEP_1)                            // 000000019F78: BF870001
	.long 0xd73c0001                                           // 000000019F7C: D73C0001
	v_cndmask_b32_e32 v1, 2, v143, vcc_lo                      // 000000019F80: 02031E82
	s_addc_u32 s5, s5, s23                                     // 000000019F84: 82051705
	s_waitcnt lgkmcnt(0)                                       // 000000019F88: BF89FC07
	s_mul_i32 s7, s6, 0x9000000                                // 000000019F8C: 9607FF06 09000000
	s_mul_hi_i32 s6, s6, 0x9000000                             // 000000019F94: 9706FF06 09000000
	s_add_u32 s4, s4, s7                                       // 000000019F9C: 80040704
	s_addc_u32 s5, s5, s6                                      // 000000019FA0: 82050605
	.long 0xd7006a3f                                           // 000000019FA4: D7006A3F
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000019FA8: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000019FAC: BF8700B1
	v_add_co_ci_u32_e64 v64, null, s5, v2, vcc_lo              // 000000019FB0: D5207C40 01AA0405
	s_add_i32 s33, s31, -1                                     // 000000019FB8: 8121C11F
	.long 0xd7006a8d                                           // 000000019FBC: D7006A8D
	v_cndmask_b32_e32 v1, v63, v3, vcc_lo                      // 000000019FC0: 0202073F
	v_add_co_ci_u32_e64 v142, null, 0, v64, vcc_lo             // 000000019FC4: D5207C8E 01AA8080
	s_mul_hi_i32 s4, s2, 0x55555556                            // 000000019FCC: 9704FF02 55555556
	.long 0xd7006a01                                           // 000000019FD4: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v141, vcc_lo                 // 000000019FD8: 02031AFF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000019FE0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, 0, v142, vcc_lo              // 000000019FE4: D5207C02 01AB1C80
	.long 0xd7006a11                                           // 000000019FEC: D7006A11
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 000000019FF0: 0201FF8D
	.long 0x00002000                                           // 000000019FF4: 00002000
	v_add_co_ci_u32_e64 v18, null, 0, v142, vcc_lo             // 000000019FF8: D5207C12 01AB1C80
	.long 0xd7006a07                                           // 00000001A000: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v141, vcc_lo                 // 00000001A004: 02031AFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A00C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v142, vcc_lo              // 00000001A010: D5207C08 01AB1C80
	.long 0xd7006a09                                           // 00000001A018: D7006A09
	v_cndmask_b32_e32 v1, 0x3000, v141, vcc_lo                 // 00000001A01C: 02031AFF 00003000
	v_add_co_ci_u32_e64 v10, null, 0, v142, vcc_lo             // 00000001A024: D5207C0A 01AB1C80
	.long 0xd7006a13                                           // 00000001A02C: D7006A13
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 00000001A030: 0201FF8D
	.long 0x00004000                                           // 00000001A034: 00004000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A038: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v142, vcc_lo             // 00000001A03C: D5207C14 01AB1C80
	.long 0xd7006a15                                           // 00000001A044: D7006A15
	v_cndmask_b32_e32 v1, 0x4000, v141, vcc_lo                 // 00000001A048: 02031AFF 00004000
	v_add_co_ci_u32_e64 v22, null, 0, v142, vcc_lo             // 00000001A050: D5207C16 01AB1C80
	.long 0xd7006a17                                           // 00000001A058: D7006A17
	v_cndmask_b32_e32 v1, 0x5000, v141, vcc_lo                 // 00000001A05C: 02031AFF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A064: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v142, vcc_lo             // 00000001A068: D5207C18 01AB1C80
	.long 0xd7006a19                                           // 00000001A070: D7006A19
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 00000001A074: 0201FF8D
	.long 0x00006000                                           // 00000001A078: 00006000
	v_add_co_ci_u32_e64 v26, null, 0, v142, vcc_lo             // 00000001A07C: D5207C1A 01AB1C80
	.long 0xd7006a1b                                           // 00000001A084: D7006A1B
	v_cndmask_b32_e32 v1, 0x6000, v141, vcc_lo                 // 00000001A088: 02031AFF 00006000
	s_clause 0x7                                               // 00000001A090: BF850007
	global_load_b32 v4, v[1:2], off offset:1024                // 00000001A094: DC520400 047C0001
	global_load_b32 v5, v[1:2], off offset:2048                // 00000001A09C: DC520800 057C0001
	global_load_b32 v6, v[1:2], off offset:3072                // 00000001A0A4: DC520C00 067C0001
	global_load_b32 v1, v[7:8], off offset:1024                // 00000001A0AC: DC520400 017C0007
	global_load_b32 v2, v[7:8], off offset:2048                // 00000001A0B4: DC520800 027C0007
	global_load_b32 v3, v[7:8], off offset:3072                // 00000001A0BC: DC520C00 037C0007
	global_load_b32 v7, v[9:10], off offset:1024               // 00000001A0C4: DC520400 077C0009
	global_load_b32 v8, v[9:10], off offset:2048               // 00000001A0CC: DC520800 087C0009
	v_add_co_ci_u32_e64 v28, null, 0, v142, vcc_lo             // 00000001A0D4: D5207C1C 01AB1C80
	s_clause 0x7                                               // 00000001A0DC: BF850007
	global_load_b32 v15, v[9:10], off offset:3072              // 00000001A0E0: DC520C00 0F7C0009
	global_load_b32 v12, v[21:22], off offset:1024             // 00000001A0E8: DC520400 0C7C0015
	global_load_b32 v13, v[21:22], off offset:2048             // 00000001A0F0: DC520800 0D7C0015
	global_load_b32 v14, v[21:22], off offset:3072             // 00000001A0F8: DC520C00 0E7C0015
	global_load_b32 v9, v[23:24], off offset:1024              // 00000001A100: DC520400 097C0017
	global_load_b32 v10, v[23:24], off offset:2048             // 00000001A108: DC520800 0A7C0017
	global_load_b32 v11, v[23:24], off offset:3072             // 00000001A110: DC520C00 0B7C0017
	global_load_b32 v16, v[27:28], off offset:1024             // 00000001A118: DC520400 107C001B
	v_or_b32_e32 v21, 0x7c00, v65                              // 00000001A120: 382A82FF 00007C00
	.long 0xd7006a17                                           // 00000001A128: D7006A17
	v_cndmask_b32_e32 v1, 0x7000, v141, vcc_lo                 // 00000001A12C: 02031AFF 00007000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A134: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v142, vcc_lo             // 00000001A138: D5207C18 01AB1C80
	.long 0xd7006a1e                                           // 00000001A140: D7006A1E
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 00000001A144: 0201FF8D
	.long 0x00008000                                           // 00000001A148: 00008000
	v_add_co_ci_u32_e64 v31, null, 0, v142, vcc_lo             // 00000001A14C: D5207C1F 01AB1C80
	.long 0xd7006a4e                                           // 00000001A154: D7006A4E
	v_cndmask_b32_e32 v1, v63, v21, vcc_lo                     // 00000001A158: 02022B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A15C: BF8700A1
	v_add_co_ci_u32_e64 v79, null, 0, v64, vcc_lo              // 00000001A160: D5207C4F 01AA8080
	.long 0xd7006a21                                           // 00000001A168: D7006A21
	v_cndmask_b32_e32 v1, 0x8000, v141, vcc_lo                 // 00000001A16C: 02031AFF 00008000
	v_add_co_ci_u32_e64 v34, null, 0, v142, vcc_lo             // 00000001A174: D5207C22 01AB1C80
	.long 0xd7006a25                                           // 00000001A17C: D7006A25
	v_cndmask_b32_e32 v1, 0x9000, v141, vcc_lo                 // 00000001A180: 02031AFF 00009000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A188: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v142, vcc_lo             // 00000001A18C: D5207C26 01AB1C80
	.long 0xd7006a29                                           // 00000001A194: D7006A29
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 00000001A198: 0201FF8D
	.long 0x0000a000                                           // 00000001A19C: 0000A000
	v_add_co_ci_u32_e64 v42, null, 0, v142, vcc_lo             // 00000001A1A0: D5207C2A 01AB1C80
	.long 0xd7006a27                                           // 00000001A1A8: D7006A27
	v_cndmask_b32_e32 v1, 0xa000, v141, vcc_lo                 // 00000001A1AC: 02031AFF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A1B4: BF8700A1
	v_add_co_ci_u32_e64 v40, null, 0, v142, vcc_lo             // 00000001A1B8: D5207C28 01AB1C80
	.long 0xd7006a2b                                           // 00000001A1C0: D7006A2B
	v_cndmask_b32_e32 v1, 0xb000, v141, vcc_lo                 // 00000001A1C4: 02031AFF 0000B000
	v_add_co_ci_u32_e64 v44, null, 0, v142, vcc_lo             // 00000001A1CC: D5207C2C 01AB1C80
	.long 0xd7006a2f                                           // 00000001A1D4: D7006A2F
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 00000001A1D8: 0201FF8D
	.long 0x0000c000                                           // 00000001A1DC: 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A1E0: BF8700A1
	v_add_co_ci_u32_e64 v48, null, 0, v142, vcc_lo             // 00000001A1E4: D5207C30 01AB1C80
	.long 0xd7006a31                                           // 00000001A1EC: D7006A31
	v_cndmask_b32_e32 v1, 0xc000, v141, vcc_lo                 // 00000001A1F0: 02031AFF 0000C000
	v_add_co_ci_u32_e64 v50, null, 0, v142, vcc_lo             // 00000001A1F8: D5207C32 01AB1C80
	.long 0xd7006a37                                           // 00000001A200: D7006A37
	v_cndmask_b32_e32 v1, 0xd000, v141, vcc_lo                 // 00000001A204: 02031AFF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A20C: BF8700A1
	v_add_co_ci_u32_e64 v56, null, 0, v142, vcc_lo             // 00000001A210: D5207C38 01AB1C80
	.long 0xd7006a33                                           // 00000001A218: D7006A33
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 00000001A21C: 0201FF8D
	.long 0x0000e000                                           // 00000001A220: 0000E000
	v_add_co_ci_u32_e64 v52, null, 0, v142, vcc_lo             // 00000001A224: D5207C34 01AB1C80
	.long 0xd7006a39                                           // 00000001A22C: D7006A39
	v_cndmask_b32_e32 v1, 0xe000, v141, vcc_lo                 // 00000001A230: 02031AFF 0000E000
	s_clause 0x17                                              // 00000001A238: BF850017
	global_load_b32 v32, v[17:18], off offset:-4096            // 00000001A23C: DC521000 207C0011
	global_load_b32 v29, v[17:18], off                         // 00000001A244: DC520000 1D7C0011
	global_load_b32 v22, v[19:20], off offset:-4096            // 00000001A24C: DC521000 167C0013
	global_load_b32 v21, v[19:20], off                         // 00000001A254: DC520000 157C0013
	global_load_b32 v20, v[25:26], off offset:-4096            // 00000001A25C: DC521000 147C0019
	global_load_b32 v19, v[25:26], off                         // 00000001A264: DC520000 137C0019
	global_load_b32 v18, v[30:31], off offset:-4096            // 00000001A26C: DC521000 127C001E
	global_load_b32 v17, v[30:31], off                         // 00000001A274: DC520000 117C001E
	global_load_b32 v30, v[27:28], off offset:2048             // 00000001A27C: DC520800 1E7C001B
	global_load_b32 v31, v[27:28], off offset:3072             // 00000001A284: DC520C00 1F7C001B
	global_load_b32 v26, v[23:24], off offset:1024             // 00000001A28C: DC520400 1A7C0017
	global_load_b32 v27, v[23:24], off offset:2048             // 00000001A294: DC520800 1B7C0017
	global_load_b32 v23, v[33:34], off offset:1024             // 00000001A29C: DC520400 177C0021
	global_load_b32 v24, v[33:34], off offset:2048             // 00000001A2A4: DC520800 187C0021
	global_load_b32 v25, v[33:34], off offset:3072             // 00000001A2AC: DC520C00 197C0021
	global_load_b32 v28, v[37:38], off offset:1024             // 00000001A2B4: DC520400 1C7C0025
	global_load_b32 v36, v[37:38], off offset:2048             // 00000001A2BC: DC520800 247C0025
	global_load_b32 v37, v[37:38], off offset:3072             // 00000001A2C4: DC520C00 257C0025
	global_load_b32 v33, v[39:40], off offset:1024             // 00000001A2CC: DC520400 217C0027
	global_load_b32 v34, v[39:40], off offset:2048             // 00000001A2D4: DC520800 227C0027
	global_load_b32 v35, v[39:40], off offset:3072             // 00000001A2DC: DC520C00 237C0027
	global_load_b32 v38, v[43:44], off offset:1024             // 00000001A2E4: DC520400 267C002B
	global_load_b32 v39, v[43:44], off offset:2048             // 00000001A2EC: DC520800 277C002B
	global_load_b32 v40, v[43:44], off offset:3072             // 00000001A2F4: DC520C00 287C002B
	v_add_co_ci_u32_e64 v58, null, 0, v142, vcc_lo             // 00000001A2FC: D5207C3A 01AB1C80
	s_clause 0xd                                               // 00000001A304: BF85000D
	global_load_b32 v46, v[41:42], off offset:-4096            // 00000001A308: DC521000 2E7C0029
	global_load_b32 v45, v[41:42], off                         // 00000001A310: DC520000 2D7C0029
	global_load_b32 v44, v[47:48], off offset:-4096            // 00000001A318: DC521000 2C7C002F
	global_load_b32 v43, v[47:48], off                         // 00000001A320: DC520000 2B7C002F
	global_load_b32 v42, v[51:52], off offset:-4096            // 00000001A328: DC521000 2A7C0033
	global_load_b32 v41, v[51:52], off                         // 00000001A330: DC520000 297C0033
	global_load_b32 v52, v[49:50], off offset:1024             // 00000001A338: DC520400 347C0031
	global_load_b32 v53, v[49:50], off offset:2048             // 00000001A340: DC520800 357C0031
	global_load_b32 v54, v[49:50], off offset:3072             // 00000001A348: DC520C00 367C0031
	global_load_b32 v49, v[55:56], off offset:1024             // 00000001A350: DC520400 317C0037
	global_load_b32 v50, v[55:56], off offset:2048             // 00000001A358: DC520800 327C0037
	global_load_b32 v51, v[55:56], off offset:3072             // 00000001A360: DC520C00 337C0037
	global_load_b32 v47, v[57:58], off offset:1024             // 00000001A368: DC520400 2F7C0039
	global_load_b32 v48, v[57:58], off offset:2048             // 00000001A370: DC520800 307C0039
	v_min_i32_e32 v55, s33, v74                                // 00000001A378: 226E9421
	s_lshr_b32 s5, s4, 31                                      // 00000001A37C: 85059F04
	.long 0xd7006a3b                                           // 00000001A380: D7006A3B
	v_cndmask_b32_e32 v1, 0xf000, v141, vcc_lo                 // 00000001A384: 02031AFF 0000F000
	s_add_i32 s4, s4, s5                                       // 00000001A38C: 81040504
	v_mad_i64_i32 v[61:62], null, 0x5000, v55, s[8:9]          // 00000001A390: D6FF7C3D 00226EFF 00005000
	s_lshl_b32 s4, s4, 7                                       // 00000001A39C: 84048704
	v_add_co_ci_u32_e64 v60, null, 0, v142, vcc_lo             // 00000001A3A0: D5207C3C 01AB1C80
	s_ashr_i32 s5, s4, 31                                      // 00000001A3A8: 86059F04
	s_clause 0x3                                               // 00000001A3AC: BF850003
	global_load_b32 v55, v[57:58], off offset:3072             // 00000001A3B0: DC520C00 377C0039
	global_load_b32 v56, v[59:60], off                         // 00000001A3B8: DC520000 387C003B
	global_load_b32 v57, v[59:60], off offset:1024             // 00000001A3C0: DC520400 397C003B
	global_load_b32 v58, v[59:60], off offset:2048             // 00000001A3C8: DC520800 3A7C003B
	s_lshl_b64 s[6:7], s[4:5], 1                               // 00000001A3D0: 84868104
	v_and_b32_e32 v59, 0xf0, v66                               // 00000001A3D4: 367684FF 000000F0
	.long 0xd7006a3c                                           // 00000001A3DC: D7006A3C
	v_cndmask_b32_e32 v0, v61, v6, vcc_lo                      // 00000001A3E0: 02000D3D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001A3E4: BF8701A1
	v_add_co_ci_u32_e64 v61, null, s7, v62, vcc_lo             // 00000001A3E8: D5207C3D 01AA7C07
	v_or_b32_e32 v62, 0xfc00, v65                              // 00000001A3F0: 387C82FF 0000FC00
	.long 0xd7006a41                                           // 00000001A3F8: D7006A41
	v_cndmask_b32_e32 v1, v60, v59, vcc_lo                     // 00000001A3FC: 0202773C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001A400: BF870191
	v_add_co_ci_u32_e64 v66, null, 0, v61, vcc_lo              // 00000001A404: D5207C42 01AA7A80
	.long 0xd7006a50                                           // 00000001A40C: D7006A50
	v_cndmask_b32_e32 v1, v63, v62, vcc_lo                     // 00000001A410: 02027D3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001A414: BF870211
	v_add_co_ci_u32_e64 v81, null, 0, v64, vcc_lo              // 00000001A418: D5207C51 01AA8080
	.long 0xd7006a46                                           // 00000001A420: D7006A46
	v_cndmask_b32_e32 v1, 0x1000, v65, vcc_lo                  // 00000001A424: 020282FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001A42C: BF870001
	v_add_co_ci_u32_e64 v71, null, 0, v66, vcc_lo              // 00000001A430: D5207C47 01AA8480
	s_clause 0x5                                               // 00000001A438: BF850005
	global_load_b32 v61, v[141:142], off                       // 00000001A43C: DC520000 3D7C008D
	global_load_b32 v62, v[141:142], off offset:1024           // 00000001A444: DC520400 3E7C008D
	global_load_b32 v63, v[141:142], off offset:2048           // 00000001A44C: DC520800 3F7C008D
	global_load_b32 v64, v[141:142], off offset:3072           // 00000001A454: DC520C00 407C008D
	global_load_b32 v60, v[78:79], off                         // 00000001A45C: DC520000 3C7C004E
	global_load_b32 v59, v[80:81], off                         // 00000001A464: DC520000 3B7C0050
	s_clause 0x1                                               // 00000001A46C: BF850001
	global_load_b128 v[66:69], v[65:66], off                   // 00000001A470: DC5E0000 427C0041
	global_load_b128 v[70:73], v[70:71], off                   // 00000001A478: DC5E0000 467C0046
	s_mov_b32 s4, exec_lo                                      // 00000001A480: BE84007E
	.long 0xd4c3007e                                           // 00000001A484: D4C3007E
	v_cndmask_b32_e32 v1, s31, v74, vcc_lo                     // 00000001A488: 0202941F
	s_cbranch_execz 11                                         // 00000001A48C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5bc>
	s_waitcnt vmcnt(1)                                         // 00000001A490: BF8907F7
	v_mov_b32_e32 v66, 0                                       // 00000001A494: 7E840280
	s_waitcnt vmcnt(0)                                         // 00000001A498: BF8903F7
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001A49C: BF870001
	v_mov_b32_e32 v73, v66                                     // 00000001A4A0: 7E920342
	v_mov_b32_e32 v72, v66                                     // 00000001A4A4: 7E900342
	v_mov_b32_e32 v71, v66                                     // 00000001A4A8: 7E8E0342
	v_mov_b32_e32 v70, v66                                     // 00000001A4AC: 7E8C0342
	v_mov_b32_e32 v67, v66                                     // 00000001A4B0: 7E860342
	v_mov_b32_e32 v68, v66                                     // 00000001A4B4: 7E880342
	v_mov_b32_e32 v69, v66                                     // 00000001A4B8: 7E8A0342
	s_or_b32 exec_lo, exec_lo, s4                              // 00000001A4BC: 8C7E047E
	v_cmp_gt_u32_e32 vcc_lo, 16, v0                            // 00000001A4C0: 7C980090
	.long 0xd4440004                                           // 00000001A4C4: D4440004
	v_cndmask_b32_e32 v1, s31, v0, vcc_lo                      // 00000001A4C8: 0202001F
	v_mov_b32_e32 v137, 0                                      // 00000001A4CC: 7F120280
	s_and_b32 s5, vcc_lo, s4                                   // 00000001A4D0: 8B05046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001A4D4: BF870009
	s_and_saveexec_b32 s4, s5                                  // 00000001A4D8: BE842005
	s_cbranch_execz 27                                         // 00000001A4DC: BFA5001B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x64c>
	v_mul_u32_u24_e32 v65, 0xc0, v0                            // 00000001A4E0: 168200FF 000000C0
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000001A4E8: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001A4EC: BF870091
	.long 0xd700054a                                           // 00000001A4F0: D700054A
	v_cndmask_b32_e32 v1, s10, v65, vcc_lo                     // 00000001A4F4: 0202820A
	v_add_co_ci_u32_e64 v75, null, s11, 0, s5                  // 00000001A4F8: D5207C4B 0015000B
	.long 0xd7000541                                           // 00000001A500: D7000541
	v_cndmask_b32_e32 v1, s12, v65, vcc_lo                     // 00000001A504: 0202820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001A508: BF870211
	v_add_co_ci_u32_e64 v77, null, s13, 0, s5                  // 00000001A50C: D5207C4D 0015000D
	.long 0xd7006a4a                                           // 00000001A514: D7006A4A
	v_cndmask_b32_e32 v0, v74, v14, vcc_lo                     // 00000001A518: 02001D4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001A51C: BF870211
	v_add_co_ci_u32_e64 v75, null, s15, v75, vcc_lo            // 00000001A520: D5207C4B 01AA960F
	.long 0xd7006a4c                                           // 00000001A528: D7006A4C
	v_cndmask_b32_e32 v0, v65, v14, vcc_lo                     // 00000001A52C: 02001D41
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001A530: BF870001
	v_add_co_ci_u32_e64 v77, null, s15, v77, vcc_lo            // 00000001A534: D5207C4D 01AA9A0F
	global_load_b32 v137, v[74:75], off                        // 00000001A53C: DC520000 897C004A
	global_load_b32 v144, v[76:77], off                        // 00000001A544: DC520000 907C004C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000001A54C: 8C7E047E
	s_waitcnt vmcnt(6)                                         // 00000001A550: BF891BF7
	v_dual_mul_f32 v136, 0x43800000, v61 :: v_dual_mul_f32 v135, 0x43800000, v62// 00000001A554: C8C67AFF 88867CFF 43800000
	s_waitcnt vmcnt(4)                                         // 00000001A560: BF8913F7
	v_dual_mul_f32 v134, 0x43800000, v63 :: v_dual_mul_f32 v133, 0x43800000, v64// 00000001A564: C8C67EFF 868480FF 43800000
	v_dual_mul_f32 v132, 0x43800000, v32 :: v_dual_mul_f32 v129, 0x43800000, v29// 00000001A570: C8C640FF 84803AFF 43800000
	v_dual_mul_f32 v131, 0x43800000, v4 :: v_dual_mul_f32 v130, 0x43800000, v5// 00000001A57C: C8C608FF 83820AFF 43800000
	v_dual_mul_f32 v154, 0x43800000, v6 :: v_dual_mul_f32 v123, 0x43800000, v8// 00000001A588: C8C60CFF 9A7A10FF 43800000
	v_dual_mul_f32 v128, 0x43800000, v1 :: v_dual_mul_f32 v127, 0x43800000, v2// 00000001A594: C8C602FF 807E04FF 43800000
	v_dual_mul_f32 v126, 0x43800000, v3 :: v_dual_mul_f32 v125, 0x43800000, v22// 00000001A5A0: C8C606FF 7E7C2CFF 43800000
	v_dual_mul_f32 v124, 0x43800000, v7 :: v_dual_mul_f32 v121, 0x43800000, v12// 00000001A5AC: C8C60EFF 7C7818FF 43800000
	v_dual_mul_f32 v153, 0x43800000, v15 :: v_dual_mul_f32 v122, 0x43800000, v21// 00000001A5B8: C8C61EFF 997A2AFF 43800000
	v_dual_mul_f32 v120, 0x43800000, v13 :: v_dual_mul_f32 v119, 0x43800000, v14// 00000001A5C4: C8C61AFF 78761CFF 43800000
	v_dual_mul_f32 v118, 0x43800000, v20 :: v_dual_mul_f32 v117, 0x43800000, v9// 00000001A5D0: C8C628FF 767412FF 43800000
	v_dual_mul_f32 v116, 0x43800000, v10 :: v_dual_mul_f32 v115, 0x43800000, v19// 00000001A5DC: C8C614FF 747226FF 43800000
	v_dual_mul_f32 v152, 0x43800000, v11 :: v_dual_mul_f32 v113, 0x43800000, v30// 00000001A5E8: C8C616FF 98703CFF 43800000
	v_dual_mul_f32 v114, 0x43800000, v16 :: v_dual_mul_f32 v111, 0x43800000, v18// 00000001A5F4: C8C620FF 726E24FF 43800000
	s_waitcnt vmcnt(3)                                         // 00000001A600: BF890FF7
	v_dual_mul_f32 v112, 0x43800000, v31 :: v_dual_mul_f32 v151, 0x43800000, v60// 00000001A604: C8C63EFF 709678FF 43800000
	v_dual_mul_f32 v110, 0x43800000, v26 :: v_dual_mul_f32 v109, 0x43800000, v27// 00000001A610: C8C634FF 6E6C36FF 43800000
	v_dual_mul_f32 v108, 0x43800000, v17 :: v_dual_mul_f32 v107, 0x43800000, v23// 00000001A61C: C8C622FF 6C6A2EFF 43800000
	v_dual_mul_f32 v106, 0x43800000, v24 :: v_dual_mul_f32 v105, 0x43800000, v25// 00000001A628: C8C630FF 6A6832FF 43800000
	v_dual_mul_f32 v104, 0x43800000, v46 :: v_dual_mul_f32 v103, 0x43800000, v28// 00000001A634: C8C65CFF 686638FF 43800000
	v_dual_mul_f32 v102, 0x43800000, v36 :: v_dual_mul_f32 v101, 0x43800000, v45// 00000001A640: C8C648FF 66645AFF 43800000
	v_dual_mul_f32 v150, 0x43800000, v37 :: v_dual_mul_f32 v99, 0x43800000, v34// 00000001A64C: C8C64AFF 966244FF 43800000
	v_dual_mul_f32 v100, 0x43800000, v33 :: v_dual_mul_f32 v97, 0x43800000, v44// 00000001A658: C8C642FF 646058FF 43800000
	v_dual_mul_f32 v98, 0x43800000, v35 :: v_dual_mul_f32 v149, 0x43800000, v40// 00000001A664: C8C646FF 629450FF 43800000
	v_dual_mul_f32 v96, 0x43800000, v38 :: v_dual_mul_f32 v95, 0x43800000, v39// 00000001A670: C8C64CFF 605E4EFF 43800000
	v_dual_mul_f32 v94, 0x43800000, v43 :: v_dual_mul_f32 v93, 0x43800000, v52// 00000001A67C: C8C656FF 5E5C68FF 43800000
	v_dual_mul_f32 v92, 0x43800000, v53 :: v_dual_mul_f32 v91, 0x43800000, v54// 00000001A688: C8C66AFF 5C5A6CFF 43800000
	v_dual_mul_f32 v90, 0x43800000, v42 :: v_dual_mul_f32 v89, 0x43800000, v49// 00000001A694: C8C654FF 5A5862FF 43800000
	v_dual_mul_f32 v88, 0x43800000, v50 :: v_dual_mul_f32 v87, 0x43800000, v41// 00000001A6A0: C8C664FF 585652FF 43800000
	v_dual_mul_f32 v148, 0x43800000, v51 :: v_dual_mul_f32 v85, 0x43800000, v48// 00000001A6AC: C8C666FF 945460FF 43800000
	v_dual_mul_f32 v86, 0x43800000, v47 :: v_dual_mul_f32 v83, 0x43800000, v56// 00000001A6B8: C8C65EFF 565270FF 43800000
	v_dual_mul_f32 v84, 0x43800000, v55 :: v_dual_mul_f32 v143, 0x43800000, v58// 00000001A6C4: C8C66EFF 548E74FF 43800000
	s_waitcnt vmcnt(2)                                         // 00000001A6D0: BF890BF7
	v_dual_mul_f32 v82, 0x43800000, v57 :: v_dual_mul_f32 v147, 0x43800000, v59// 00000001A6D4: C8C672FF 529276FF 43800000
	s_cmp_lt_i32 s31, 1                                        // 00000001A6E0: BF04811F
	s_cbranch_scc1 5593                                        // 00000001A6E4: BFA215D9 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5f4c>
	s_add_u32 s4, s8, s6                                       // 00000001A6E8: 80040608
	s_addc_u32 s5, s9, s7                                      // 00000001A6EC: 82050709
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000001A6F0: 848E8202
	s_load_b64 s[40:41], s[0:1], 0x68                          // 00000001A6F4: F4040A00 F8000068
	s_add_u32 s6, s10, s14                                     // 00000001A6FC: 80060E0A
	s_addc_u32 s7, s11, s15                                    // 00000001A700: 82070F0B
	s_add_u32 s10, s12, s14                                    // 00000001A704: 800A0E0C
	s_addc_u32 s11, s13, s15                                   // 00000001A708: 820B0F0D
	s_add_i32 s3, s31, 15                                      // 00000001A70C: 81038F1F
	s_load_b256 s[12:19], s[0:1], 0x48                         // 00000001A710: F40C0300 F8000048
	s_ashr_i32 s26, s3, 31                                     // 00000001A718: 861A9F03
	.long 0xd71f008b                                           // 00000001A71C: D71F008B
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000001A720: 020100C1
	s_waitcnt lgkmcnt(0)                                       // 00000001A724: BF89FC07
	s_lshr_b32 s15, s26, 28                                    // 00000001A728: 850F9C1A
	s_lshl_b32 s26, s2, 7                                      // 00000001A72C: 841A8702
	s_add_i32 s3, s3, s15                                      // 00000001A730: 81030F03
	s_ashr_i32 s27, s26, 31                                    // 00000001A734: 861B9F1A
	s_ashr_i32 s3, s3, 4                                       // 00000001A738: 86038403
	s_cmp_lg_u32 s21, 0                                        // 00000001A73C: BF078015
	s_movk_i32 s1, 0x5f40                                      // 00000001A740: B0015F40
	s_cselect_b32 s15, -1, 0                                   // 00000001A744: 980F80C1
	s_cmp_gt_u32 s20, 63                                       // 00000001A748: BF08BF14
	v_dual_mov_b32 v1, 0 :: v_dual_and_b32 v2, 16, v139        // 00000001A74C: CA240080 01031690
	s_cselect_b32 s34, -1, 0                                   // 00000001A754: 982280C1
	s_cmp_eq_u32 s21, 0                                        // 00000001A758: BF068015
	v_xor_b32_e32 v138, 1, v139                                // 00000001A75C: 3B151681
	s_cselect_b32 s0, -1, 0                                    // 00000001A760: 980080C1
	v_dual_mov_b32 v145, 0x1000504 :: v_dual_add_nc_u32 v140, 16, v2// 00000001A764: CA2000FF 918C0490 01000504
	s_and_b32 s2, s0, exec_lo                                  // 00000001A770: 8B027E00
	s_cselect_b32 s35, s1, 0x5f80                              // 00000001A774: 9823FF01 00005F80
	s_lshl_b64 s[28:29], s[26:27], 1                           // 00000001A77C: 849C811A
	v_xor_b32_e32 v146, 2, v139                                // 00000001A780: 3B251682
	s_add_u32 s36, s24, s28                                    // 00000001A784: 80241C18
	s_addc_u32 s37, s25, s29                                   // 00000001A788: 82251D19
	s_max_i32 s38, s3, 1                                       // 00000001A78C: 8A268103
	s_add_u32 s16, s16, s22                                    // 00000001A790: 80101610
	s_addc_u32 s17, s17, s23                                   // 00000001A794: 82111711
	s_add_u32 s18, s18, s22                                    // 00000001A798: 80121612
	v_xor_b32_e32 v190, 4, v139                                // 00000001A79C: 3B7D1684
	v_xor_b32_e32 v191, 8, v139                                // 00000001A7A0: 3B7F1688
	s_mov_b32 s20, 0                                           // 00000001A7A4: BE940080
	s_addc_u32 s19, s19, s23                                   // 00000001A7A8: 82131713
	s_add_u32 s39, s40, s22                                    // 00000001A7AC: 80271628
	s_addc_u32 s40, s41, s23                                   // 00000001A7B0: 82281729
	s_mov_b32 s41, 0x41800000                                  // 00000001A7B4: BEA900FF 41800000
	s_movk_i32 s42, 0x1800                                     // 00000001A7BC: B02A1800
	s_movk_i32 s43, 0x2900                                     // 00000001A7C0: B02B2900
	s_mov_b32 s21, s20                                         // 00000001A7C4: BE950014
	s_mov_b32 s22, s20                                         // 00000001A7C8: BE960014
	s_mov_b32 s23, s20                                         // 00000001A7CC: BE970014
	s_mov_b32 s24, s20                                         // 00000001A7D0: BE980014
	s_mov_b32 s25, s20                                         // 00000001A7D4: BE990014
	s_mov_b32 s26, s20                                         // 00000001A7D8: BE9A0014
	s_mov_b32 s27, s20                                         // 00000001A7DC: BE9B0014
	s_mov_b32 s44, 0x76543210                                  // 00000001A7E0: BEAC00FF 76543210
	s_mov_b32 s45, s20                                         // 00000001A7E8: BEAD0014
	s_clause 0x1                                               // 00000001A7EC: BF850001
	scratch_store_b64 off, v[80:81], off offset:8              // 00000001A7F0: DC6D0008 007C5000
	scratch_store_b64 off, v[78:79], off                       // 00000001A7F8: DC6D0000 007C4E00
	s_branch 10                                                // 00000001A800: BFA0000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x92c>
	v_dual_mov_b32 v147, v33 :: v_dual_mov_b32 v152, v38       // 00000001A804: CA100121 93980126
	v_dual_mov_b32 v148, v37 :: v_dual_mov_b32 v153, v46       // 00000001A80C: CA100125 9498012E
	v_dual_mov_b32 v149, v25 :: v_dual_mov_b32 v154, v54       // 00000001A814: CA100119 959A0136
	v_mov_b32_e32 v150, v9                                     // 00000001A81C: 7F2C0309
	v_mov_b32_e32 v151, v17                                    // 00000001A820: 7F2E0311
	s_cmp_eq_u32 s45, s38                                      // 00000001A824: BF06262D
	s_cbranch_scc1 5506                                        // 00000001A828: BFA21582 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5f34>
	v_mov_b32_e32 v44, v0                                      // 00000001A82C: 7E580300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000001A830: BF8701B1
	v_ashrrev_i32_e32 v2, 4, v44                               // 00000001A834: 34045884
	v_and_b32_e32 v156, 15, v44                                // 00000001A838: 3738588F
	.long 0xd4440001                                           // 00000001A83C: D4440001
	v_cndmask_b32_e32 v1, 16, v44, vcc_lo                      // 00000001A840: 02025890
	.long 0xd72c0003                                           // 00000001A844: D72C0003
	v_cndmask_b32_e32 v1, 0x110, v2, vcc_lo                    // 00000001A848: 020204FF 00000110
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001A850: BF870001
	v_lshl_add_u32 v3, v156, 4, v3                             // 00000001A854: D6460003 040D099C
	s_waitcnt vmcnt(1)                                         // 00000001A85C: BF8907F7
	ds_store_b128 v3, v[66:69] offset:10496                    // 00000001A860: DB7C2900 00004203
	s_waitcnt vmcnt(0)                                         // 00000001A868: BF8903F7
	ds_store_b128 v3, v[70:73] offset:6144                     // 00000001A86C: DB7C1800 00004603
	s_and_saveexec_b32 s2, s1                                  // 00000001A874: BE822001
	v_lshlrev_b32_e32 v3, 2, v44                               // 00000001A878: 30065882
	ds_store_b32 v3, v144 offset:24064                         // 00000001A87C: D8345E00 00009003
	s_or_b32 exec_lo, exec_lo, s2                              // 00000001A884: 8C7E027E
	v_and_b32_e32 v34, 1, v44                                  // 00000001A888: 36445881
	s_lshl_b32 s46, s45, 4                                     // 00000001A88C: 842E842D
	v_or_b32_e32 v155, s30, v156                               // 00000001A890: 3937381E
	s_mov_b32 s47, exec_lo                                     // 00000001A894: BEAF007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001A898: BF870112
	v_or_b32_e32 v15, s46, v34                                 // 00000001A89C: 381E442E
	v_and_b32_e32 v6, 0x7ffffffe, v155                         // 00000001A8A0: 360D36FF 7FFFFFFE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000001A8A8: BF870232
	v_min_i32_e32 v3, s33, v15                                 // 00000001A8AC: 22061E21
	v_or_b32_e32 v5, 2, v15                                    // 00000001A8B0: 380A1E82
	v_or_b32_e32 v7, 4, v15                                    // 00000001A8B4: 380E1E84
	v_lshlrev_b32_e32 v19, 1, v6                               // 00000001A8B8: 30260C81
	v_or_b32_e32 v8, 6, v15                                    // 00000001A8BC: 38101E86
	v_mad_i64_i32 v[3:4], null, 0x5000, v3, s[8:9]             // 00000001A8C0: D6FF7C03 002206FF 00005000
	v_min_i32_e32 v5, s33, v5                                  // 00000001A8CC: 220A0A21
	v_min_i32_e32 v7, s33, v7                                  // 00000001A8D0: 220E0E21
	v_or_b32_e32 v17, 12, v15                                  // 00000001A8D4: 38221E8C
	v_min_i32_e32 v8, s33, v8                                  // 00000001A8D8: 22101021
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A8DC: BF8700A4
	v_mad_i64_i32 v[5:6], null, 0x5000, v5, s[8:9]             // 00000001A8E0: D6FF7C05 00220AFF 00005000
	.long 0xd7006a09                                           // 00000001A8EC: D7006A09
	v_cndmask_b32_e32 v0, v3, v28, vcc_lo                      // 00000001A8F0: 02003903
	v_add_co_ci_u32_e64 v10, null, s29, v4, vcc_lo             // 00000001A8F4: D5207C0A 01AA081D
	v_mad_i64_i32 v[3:4], null, 0x5000, v7, s[8:9]             // 00000001A8FC: D6FF7C03 00220EFF 00005000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001A908: BF870093
	.long 0xd7006a07                                           // 00000001A90C: D7006A07
	v_cndmask_b32_e32 v1, v9, v19, vcc_lo                      // 00000001A910: 02022709
	v_add_co_ci_u32_e64 v9, null, 0, v10, vcc_lo               // 00000001A914: D5207C09 01AA1480
	.long 0xd7006a0a                                           // 00000001A91C: D7006A0A
	v_cndmask_b32_e32 v0, v5, v28, vcc_lo                      // 00000001A920: 02003905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001A924: BF870211
	v_add_co_ci_u32_e64 v11, null, s29, v6, vcc_lo             // 00000001A928: D5207C0B 01AA0C1D
	.long 0xd7006a05                                           // 00000001A930: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 00000001A934: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001A93C: BF870211
	v_add_co_ci_u32_e64 v6, null, 0, v9, vcc_lo                // 00000001A940: D5207C06 01AA1280
	.long 0xd7006a07                                           // 00000001A948: D7006A07
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 00000001A94C: 0202270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A950: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v11, vcc_lo               // 00000001A954: D5207C09 01AA1680
	.long 0xd7006a0a                                           // 00000001A95C: D7006A0A
	v_cndmask_b32_e32 v0, v3, v28, vcc_lo                      // 00000001A960: 02003903
	v_add_co_ci_u32_e64 v11, null, s29, v4, vcc_lo             // 00000001A964: D5207C0B 01AA081D
	v_mad_i64_i32 v[3:4], null, 0x5000, v8, s[8:9]             // 00000001A96C: D6FF7C03 002210FF 00005000
	.long 0xd7006a07                                           // 00000001A978: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 00000001A97C: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A984: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v9, vcc_lo                // 00000001A988: D5207C08 01AA1280
	.long 0xd7006a09                                           // 00000001A990: D7006A09
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 00000001A994: 0202270A
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo              // 00000001A998: D5207C0A 01AA1680
	v_or_b32_e32 v11, 8, v15                                   // 00000001A9A0: 38161E88
	.long 0xd7006a03                                           // 00000001A9A4: D7006A03
	v_cndmask_b32_e32 v0, v3, v28, vcc_lo                      // 00000001A9A8: 02003903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001A9AC: BF870191
	v_add_co_ci_u32_e64 v4, null, s29, v4, vcc_lo              // 00000001A9B0: D5207C04 01AA081D
	v_min_i32_e32 v11, s33, v11                                // 00000001A9B8: 22161621
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001A9BC: BF870093
	.long 0xd7006a0c                                           // 00000001A9C0: D7006A0C
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000001A9C4: 02022703
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000001A9C8: D5207C0D 01AA0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A9D0: BF8700A3
	v_mad_i64_i32 v[3:4], null, 0x5000, v11, s[8:9]            // 00000001A9D4: D6FF7C03 002216FF 00005000
	.long 0xd7006a09                                           // 00000001A9E0: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v9, vcc_lo                   // 00000001A9E4: 020212FF 00002000
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 00000001A9EC: D5207C0A 01AA1480
	.long 0xd7006a0b                                           // 00000001A9F4: D7006A0B
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 00000001A9F8: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000001AA00: BF8700B1
	v_add_co_ci_u32_e64 v12, null, 0, v13, vcc_lo              // 00000001AA04: D5207C0C 01AA1A80
	v_or_b32_e32 v13, 10, v15                                  // 00000001AA0C: 381A1E8A
	.long 0xd7006a03                                           // 00000001AA10: D7006A03
	v_cndmask_b32_e32 v0, v3, v28, vcc_lo                      // 00000001AA14: 02003903
	v_add_co_ci_u32_e64 v4, null, s29, v4, vcc_lo              // 00000001AA18: D5207C04 01AA081D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001AA20: BF870193
	v_min_i32_e32 v13, s33, v13                                // 00000001AA24: 221A1A21
	.long 0xd7006a0e                                           // 00000001AA28: D7006A0E
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000001AA2C: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001AA30: BF870191
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000001AA34: D5207C10 01AA0880
	v_mad_i64_i32 v[3:4], null, 0x5000, v13, s[8:9]            // 00000001AA3C: D6FF7C03 00221AFF 00005000
	v_or_b32_e32 v15, 14, v15                                  // 00000001AA48: 381E1E8E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001AA4C: BF870094
	.long 0xd7006a0d                                           // 00000001AA50: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v14, vcc_lo                  // 00000001AA54: 02021CFF 00002000
	v_add_co_ci_u32_e64 v14, null, 0, v16, vcc_lo              // 00000001AA5C: D5207C0E 01AA2080
	v_min_i32_e32 v16, s33, v17                                // 00000001AA64: 22202221
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001AA68: BF8700A4
	v_min_i32_e32 v15, s33, v15                                // 00000001AA6C: 221E1E21
	.long 0xd7006a11                                           // 00000001AA70: D7006A11
	v_cndmask_b32_e32 v0, v3, v28, vcc_lo                      // 00000001AA74: 02003903
	v_add_co_ci_u32_e64 v18, null, s29, v4, vcc_lo             // 00000001AA78: D5207C12 01AA081D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001AA80: BF870194
	v_mad_i64_i32 v[3:4], null, 0x5000, v16, s[8:9]            // 00000001AA84: D6FF7C03 002220FF 00005000
	.long 0xd7006a11                                           // 00000001AA90: D7006A11
	v_cndmask_b32_e32 v1, v17, v19, vcc_lo                     // 00000001AA94: 02022711
	v_mad_i64_i32 v[15:16], null, 0x5000, v15, s[8:9]          // 00000001AA98: D6FF7C0F 00221EFF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001AAA4: BF870194
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 00000001AAA8: D5207C12 01AA2480
	.long 0xd7006a11                                           // 00000001AAB0: D7006A11
	v_cndmask_b32_e32 v1, 0x2000, v17, vcc_lo                  // 00000001AAB4: 020222FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001AABC: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 00000001AAC0: D5207C12 01AA2480
	.long 0xd7006a03                                           // 00000001AAC8: D7006A03
	v_cndmask_b32_e32 v0, v3, v28, vcc_lo                      // 00000001AACC: 02003903
	v_add_co_ci_u32_e64 v4, null, s29, v4, vcc_lo              // 00000001AAD0: D5207C04 01AA081D
	.long 0xd7006a0f                                           // 00000001AAD8: D7006A0F
	v_cndmask_b32_e32 v0, v15, v28, vcc_lo                     // 00000001AADC: 0200390F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001AAE0: BF870211
	v_add_co_ci_u32_e64 v16, null, s29, v16, vcc_lo            // 00000001AAE4: D5207C10 01AA201D
	.long 0xd7006a03                                           // 00000001AAEC: D7006A03
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000001AAF0: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001AAF4: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000001AAF8: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 00000001AB00: D7006A0F
	v_cndmask_b32_e32 v1, v15, v19, vcc_lo                     // 00000001AB04: 0202270F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001AB08: BF870211
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 00000001AB0C: D5207C10 01AA2080
	.long 0xd7006a03                                           // 00000001AB14: D7006A03
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 00000001AB18: 020206FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001AB20: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000001AB24: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 00000001AB2C: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v15, vcc_lo                  // 00000001AB30: 02021EFF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001AB38: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 00000001AB3C: D5207C10 01AA2080
	s_clause 0x7                                               // 00000001AB44: BF850007
	global_load_b32 v42, v[5:6], off                           // 00000001AB48: DC520000 2A7C0005
	global_load_b32 v41, v[7:8], off                           // 00000001AB50: DC520000 297C0007
	global_load_b32 v40, v[9:10], off                          // 00000001AB58: DC520000 287C0009
	global_load_b32 v39, v[11:12], off                         // 00000001AB60: DC520000 277C000B
	global_load_b32 v38, v[13:14], off                         // 00000001AB68: DC520000 267C000D
	global_load_b32 v37, v[17:18], off                         // 00000001AB70: DC520000 257C0011
	global_load_b32 v36, v[3:4], off                           // 00000001AB78: DC520000 247C0003
	global_load_b32 v35, v[15:16], off                         // 00000001AB80: DC520000 237C000F
	v_lshlrev_b32_e32 v5, 16, v70                              // 00000001AB88: 300A8C90
	v_and_b32_e32 v8, 0xffff0000, v67                          // 00000001AB8C: 361086FF FFFF0000
	v_lshlrev_b32_e32 v3, 16, v66                              // 00000001AB94: 30068490
	v_lshlrev_b32_e32 v12, 16, v72                             // 00000001AB98: 30189090
	v_and_b32_e32 v13, 0xffff0000, v72                         // 00000001AB9C: 361A90FF FFFF0000
	v_mul_f32_e32 v5, v5, v5                                   // 00000001ABA4: 100A0B05
	v_lshlrev_b32_e32 v7, 16, v67                              // 00000001ABA8: 300E8690
	v_dual_mul_f32 v3, v3, v3 :: v_dual_and_b32 v4, 0xffff0000, v66// 00000001ABAC: C8E40703 030484FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001ABB8: BF8701A4
	v_dual_mul_f32 v13, v13, v13 :: v_dual_and_b32 v10, 0xffff0000, v68// 00000001ABBC: C8E41B0D 0D0A88FF FFFF0000
	v_dual_mul_f32 v12, v12, v12 :: v_dual_and_b32 v11, 0xffff0000, v69// 00000001ABC8: C8E4190C 0C0A8AFF FFFF0000
	v_mul_f32_e32 v4, v4, v4                                   // 00000001ABD4: 10080904
	v_and_b32_e32 v6, 0xffff0000, v70                          // 00000001ABD8: 360C8CFF FFFF0000
	v_lshlrev_b32_e32 v9, 16, v68                              // 00000001ABE0: 30128890
	v_and_b32_e32 v14, 0xffff0000, v73                         // 00000001ABE4: 361C92FF FFFF0000
	v_cmp_lt_u32_e32 vcc_lo, v138, v140                        // 00000001ABEC: 7C93198A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001ABF0: BF870094
	v_dual_add_f32 v3, v3, v4 :: v_dual_mul_f32 v6, v6, v6     // 00000001ABF4: C9060903 03060D06
	v_dual_add_f32 v4, v5, v6 :: v_dual_mul_f32 v5, v7, v7     // 00000001ABFC: C9060D05 04040F07
	v_dual_mul_f32 v6, v8, v8 :: v_dual_lshlrev_b32 v7, 16, v71// 00000001AC04: C8E21108 06068E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001AC0C: BF870091
	v_dual_add_f32 v5, v5, v6 :: v_dual_and_b32 v8, 0xffff0000, v71// 00000001AC10: C9240D05 05088EFF FFFF0000
	v_dual_mul_f32 v6, v7, v7 :: v_dual_mul_f32 v7, v8, v8     // 00000001AC1C: C8C60F07 06061108
	v_dual_mul_f32 v8, v9, v9 :: v_dual_mul_f32 v9, v10, v10   // 00000001AC24: C8C61309 0808150A
	v_lshlrev_b32_e32 v10, 16, v69                             // 00000001AC2C: 30148A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001AC30: BF870113
	v_dual_add_f32 v6, v6, v7 :: v_dual_add_f32 v7, v12, v13   // 00000001AC34: C9080F06 06061B0C
	v_dual_add_f32 v8, v8, v9 :: v_dual_mul_f32 v9, v10, v10   // 00000001AC3C: C9061308 0808150A
	v_dual_mul_f32 v10, v11, v11 :: v_dual_lshlrev_b32 v11, 16, v73// 00000001AC44: C8E2170B 0A0A9290
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001AC4C: BF870113
	v_add_f32_e32 v4, v4, v6                                   // 00000001AC50: 06080D04
	v_dual_add_f32 v9, v9, v10 :: v_dual_mul_f32 v10, v11, v11 // 00000001AC54: C9061509 090A170B
	v_mul_f32_e32 v11, v14, v14                                // 00000001AC5C: 10161D0E
	v_add_f32_e32 v3, v3, v5                                   // 00000001AC60: 06060B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001AC64: BF870092
	v_dual_add_f32 v5, v8, v9 :: v_dual_add_f32 v8, v10, v11   // 00000001AC68: C9081308 0508170A
	v_add_f32_e32 v3, v3, v5                                   // 00000001AC70: 06060B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000001AC74: BF8701B2
	v_add_f32_e32 v5, v7, v8                                   // 00000001AC78: 060A1107
	v_cndmask_b32_e32 v9, v139, v138, vcc_lo                   // 00000001AC7C: 0213158B
	v_cmp_lt_u32_e32 vcc_lo, v146, v140                        // 00000001AC80: 7C931992
	v_add_f32_e32 v4, v4, v5                                   // 00000001AC84: 06080B04
	s_delay_alu instid0(VALU_DEP_3)                            // 00000001AC88: BF870003
	v_lshlrev_b32_e32 v6, 2, v9                                // 00000001AC8C: 300C1282
	ds_bpermute_b32 v5, v6, v3                                 // 00000001AC90: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 00000001AC98: DACC0000 06000406
	s_waitcnt lgkmcnt(0)                                       // 00000001ACA0: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000001ACA4: C9080B03 03040D04
	v_cndmask_b32_e32 v7, v139, v146, vcc_lo                   // 00000001ACAC: 020F258B
	v_cmp_lt_u32_e32 vcc_lo, v190, v140                        // 00000001ACB0: 7C9319BE
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001ACB4: BF870002
	v_lshlrev_b32_e32 v5, 2, v7                                // 00000001ACB8: 300A0E82
	v_cndmask_b32_e32 v7, v139, v190, vcc_lo                   // 00000001ACBC: 020F7D8B
	v_cmp_lt_u32_e32 vcc_lo, v191, v140                        // 00000001ACC0: 7C9319BF
	ds_bpermute_b32 v6, v5, v3                                 // 00000001ACC4: DACC0000 06000305
	ds_bpermute_b32 v5, v5, v4                                 // 00000001ACCC: DACC0000 05000405
	s_waitcnt lgkmcnt(1)                                       // 00000001ACD4: BF89FC17
	v_dual_add_f32 v3, v3, v6 :: v_dual_lshlrev_b32 v6, 2, v7  // 00000001ACD8: C9220D03 03060E82
	s_waitcnt lgkmcnt(0)                                       // 00000001ACE0: BF89FC07
	v_dual_add_f32 v4, v4, v5 :: v_dual_cndmask_b32 v7, v139, v191// 00000001ACE4: C9120B04 04077F8B
	ds_bpermute_b32 v5, v6, v3                                 // 00000001ACEC: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 00000001ACF4: DACC0000 06000406
	v_lshlrev_b32_e32 v7, 2, v7                                // 00000001ACFC: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 00000001AD00: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000001AD04: C9080B03 03040D04
	ds_bpermute_b32 v5, v7, v3                                 // 00000001AD0C: DACC0000 05000307
	ds_bpermute_b32 v6, v7, v4                                 // 00000001AD14: DACC0000 06000407
	v_cmpx_eq_u32_e32 0, v156                                  // 00000001AD1C: 7D953880
	s_cbranch_execz 41                                         // 00000001AD20: BFA50029 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xec8>
	s_waitcnt lgkmcnt(0)                                       // 00000001AD24: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000001AD28: C9080B03 03040D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001AD30: BF870091
	v_dual_add_f32 v3, 0x358637bd, v3 :: v_dual_add_f32 v4, 0x358637bd, v4// 00000001AD34: C90806FF 030408FF 358637BD
	v_dual_mul_f32 v5, 0x4b800000, v3 :: v_dual_mul_f32 v6, 0x4b800000, v4// 00000001AD40: C8C606FF 050608FF 4B800000
	.long 0xd4140002                                           // 00000001AD4C: D4140002
	v_cndmask_b32_e32 v1, 0x800000, v4, vcc_lo                 // 00000001AD50: 020208FF 00800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v3                      // 00000001AD58: 7C2806FF 00800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001AD60: BF870092
	v_cndmask_b32_e64 v4, v4, v6, s2                           // 00000001AD64: D5010004 000A0D04
	v_rsq_f32_e32 v4, v4                                       // 00000001AD6C: 7E085D04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001AD70: BF870095
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_mul_f32 v6, 0x45800000, v4// 00000001AD74: CA460B03 030608FF 45800000
	v_rsq_f32_e32 v3, v3                                       // 00000001AD80: 7E065D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 00000001AD84: BF870321
	v_cndmask_b32_e64 v4, v4, v6, s2                           // 00000001AD88: D5010004 000A0D04
	v_rsq_f32_e32 v6, 0x43000000                               // 00000001AD90: 7E0C5CFF 43000000
	v_mul_f32_e32 v5, 0x45800000, v3                           // 00000001AD98: 100A06FF 45800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001ADA0: BF870001
	v_cndmask_b32_e32 v3, v3, v5, vcc_lo                       // 00000001ADA4: 02060B03
	v_lshlrev_b32_e32 v5, 2, v2                                // 00000001ADA8: 300A0482
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 00000001ADAC: BF870105
	v_mul_f32_e32 v3, v6, v3                                   // 00000001ADB0: 10060706
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001ADB4: BF870002
	v_add_nc_u32_e32 v5, 0x5c00, v5                            // 00000001ADB8: 4A0A0AFF 00005C00
	ds_store_2addr_b32 v5, v4, v3 offset0:208 offset1:224      // 00000001ADC0: D838E0D0 00030405
	s_or_b32 exec_lo, exec_lo, s47                             // 00000001ADC8: 8C7E2F7E
	v_and_b32_e32 v43, 31, v44                                 // 00000001ADCC: 3656589F
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000001ADD0: 916A007E
	s_cbranch_vccnz 119                                        // 00000001ADD4: BFA40077 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10b4>
	.long 0xd760003e                                           // 00000001ADD8: D760003E
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 00000001ADDC: 02010189
	.long 0xd760003d                                           // 00000001ADE0: D760003D
	v_cndmask_b32_e32 v0, v137, v129, vcc_lo                   // 00000001ADE4: 02010389
	.long 0xd760003c                                           // 00000001ADE8: D760003C
	v_cndmask_b32_e32 v0, v137, v130, vcc_lo                   // 00000001ADEC: 02010589
	.long 0xd760003b                                           // 00000001ADF0: D760003B
	v_cndmask_b32_e32 v0, v137, v131, vcc_lo                   // 00000001ADF4: 02010789
	.long 0xd760003a                                           // 00000001ADF8: D760003A
	v_cndmask_b32_e32 v0, v137, v132, vcc_lo                   // 00000001ADFC: 02010989
	.long 0xd7600039                                           // 00000001AE00: D7600039
	v_cndmask_b32_e32 v0, v137, v133, vcc_lo                   // 00000001AE04: 02010B89
	.long 0xd7600038                                           // 00000001AE08: D7600038
	v_cndmask_b32_e32 v0, v137, v134, vcc_lo                   // 00000001AE0C: 02010D89
	.long 0xd7600037                                           // 00000001AE10: D7600037
	v_cndmask_b32_e32 v0, v137, v135, vcc_lo                   // 00000001AE14: 02010F89
	.long 0xd7600036                                           // 00000001AE18: D7600036
	v_cndmask_b32_e32 v0, v137, v136, vcc_lo                   // 00000001AE1C: 02011189
	.long 0xd7600035                                           // 00000001AE20: D7600035
	v_cndmask_b32_e32 v0, v137, v137, vcc_lo                   // 00000001AE24: 02011389
	.long 0xd7600034                                           // 00000001AE28: D7600034
	v_cndmask_b32_e32 v0, v137, v138, vcc_lo                   // 00000001AE2C: 02011589
	.long 0xd7600033                                           // 00000001AE30: D7600033
	v_cndmask_b32_e32 v0, v137, v139, vcc_lo                   // 00000001AE34: 02011789
	.long 0xd7600032                                           // 00000001AE38: D7600032
	v_cndmask_b32_e32 v0, v137, v140, vcc_lo                   // 00000001AE3C: 02011989
	.long 0xd7600031                                           // 00000001AE40: D7600031
	v_cndmask_b32_e32 v0, v137, v141, vcc_lo                   // 00000001AE44: 02011B89
	.long 0xd7600030                                           // 00000001AE48: D7600030
	v_cndmask_b32_e32 v0, v137, v142, vcc_lo                   // 00000001AE4C: 02011D89
	.long 0xd760002f                                           // 00000001AE50: D760002F
	v_cndmask_b32_e32 v0, v137, v143, vcc_lo                   // 00000001AE54: 02011F89
	s_mov_b32 s2, exec_lo                                      // 00000001AE58: BE82007E
	v_cmpx_gt_u32_e32 16, v43                                  // 00000001AE5C: 7D985690
	s_cbranch_execz 83                                         // 00000001AE60: BFA50053 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10b0>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000001AE64: 7C945680
	s_add_f32 s62, s62, 0                                      // 00000001AE68: A03E803E
	v_lshlrev_b32_e32 v4, 2, v43                               // 00000001AE6C: 30085682
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000001AE70: BF8704BA
	s_add_f32 s61, s62, s61                                    // 00000001AE74: A03D3D3E
	v_cndmask_b32_e64 v3, 0, s62, vcc_lo                       // 00000001AE78: D5010003 01A87C80
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 00000001AE80: 7C945681
	s_add_f32 s60, s61, s60                                    // 00000001AE84: A03C3C3D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001AE88: BF8704A2
	v_cndmask_b32_e64 v3, v3, s61, vcc_lo                      // 00000001AE8C: D5010003 01A87B03
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 00000001AE94: 7C945682
	s_add_f32 s59, s60, s59                                    // 00000001AE98: A03B3B3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001AE9C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s60, vcc_lo                      // 00000001AEA0: D5010003 01A87903
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 00000001AEA8: 7C945683
	s_add_f32 s58, s59, s58                                    // 00000001AEAC: A03A3A3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001AEB0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s59, vcc_lo                      // 00000001AEB4: D5010003 01A87703
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 00000001AEBC: 7C945684
	s_add_f32 s57, s58, s57                                    // 00000001AEC0: A039393A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001AEC4: BF8704A2
	v_cndmask_b32_e64 v3, v3, s58, vcc_lo                      // 00000001AEC8: D5010003 01A87503
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 00000001AED0: 7C945685
	s_add_f32 s56, s57, s56                                    // 00000001AED4: A0383839
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001AED8: BF8704A2
	v_cndmask_b32_e64 v3, v3, s57, vcc_lo                      // 00000001AEDC: D5010003 01A87303
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 00000001AEE4: 7C945686
	s_add_f32 s55, s56, s55                                    // 00000001AEE8: A0373738
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001AEEC: BF8704A2
	v_cndmask_b32_e64 v3, v3, s56, vcc_lo                      // 00000001AEF0: D5010003 01A87103
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 00000001AEF8: 7C945687
	s_add_f32 s54, s55, s54                                    // 00000001AEFC: A0363637
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001AF00: BF8704A2
	v_cndmask_b32_e64 v3, v3, s55, vcc_lo                      // 00000001AF04: D5010003 01A86F03
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 00000001AF0C: 7C945688
	s_add_f32 s53, s54, s53                                    // 00000001AF10: A0353536
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001AF14: BF8704A2
	v_cndmask_b32_e64 v3, v3, s54, vcc_lo                      // 00000001AF18: D5010003 01A86D03
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 00000001AF20: 7C945689
	s_add_f32 s52, s53, s52                                    // 00000001AF24: A0343435
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001AF28: BF8704A2
	v_cndmask_b32_e64 v3, v3, s53, vcc_lo                      // 00000001AF2C: D5010003 01A86B03
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000001AF34: 7C94568A
	s_add_f32 s51, s52, s51                                    // 00000001AF38: A0333334
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001AF3C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s52, vcc_lo                      // 00000001AF40: D5010003 01A86903
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 00000001AF48: 7C94568B
	s_add_f32 s50, s51, s50                                    // 00000001AF4C: A0323233
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001AF50: BF8704A2
	v_cndmask_b32_e64 v3, v3, s51, vcc_lo                      // 00000001AF54: D5010003 01A86703
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 00000001AF5C: 7C94568C
	s_add_f32 s49, s50, s49                                    // 00000001AF60: A0313132
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001AF64: BF8704A2
	v_cndmask_b32_e64 v3, v3, s50, vcc_lo                      // 00000001AF68: D5010003 01A86503
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 00000001AF70: 7C94568D
	s_add_f32 s48, s49, s48                                    // 00000001AF74: A0303031
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001AF78: BF8704A2
	v_cndmask_b32_e64 v3, v3, s49, vcc_lo                      // 00000001AF7C: D5010003 01A86303
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 00000001AF84: 7C94568E
	s_add_f32 s47, s48, s47                                    // 00000001AF88: A02F2F30
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001AF8C: BF870002
	v_cndmask_b32_e64 v3, v3, s48, vcc_lo                      // 00000001AF90: D5010003 01A86103
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 00000001AF98: 7C94568F
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 00000001AF9C: BF870482
	v_cndmask_b32_e64 v3, v3, s47, vcc_lo                      // 00000001AFA0: D5010003 01A85F03
	ds_store_b32 v4, v3 offset:24128                           // 00000001AFA8: D8345E40 00000304
	s_or_b32 exec_lo, exec_lo, s2                              // 00000001AFB0: 8C7E027E
	s_add_i32 s45, s45, 1                                      // 00000001AFB4: 812D812D
	s_waitcnt lgkmcnt(0)                                       // 00000001AFB8: BF89FC07
	s_barrier                                                  // 00000001AFBC: BFBD0000
	s_cmp_ge_i32 s45, s3                                       // 00000001AFC0: BF03032D
	s_cbranch_scc1 67                                          // 00000001AFC4: BFA20043 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11d4>
	s_lshl_b32 s2, s45, 4                                      // 00000001AFC8: 8402842D
	v_lshlrev_b32_e32 v4, 4, v44                               // 00000001AFCC: 30085884
	s_waitcnt lgkmcnt(0)                                       // 00000001AFD0: BF89FC07
	v_add_nc_u32_e32 v6, s2, v2                                // 00000001AFD4: 4A0C0402
	s_mov_b32 s47, exec_lo                                     // 00000001AFD8: BEAF007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001AFDC: BF870112
	v_and_b32_e32 v4, 0xf0, v4                                 // 00000001AFE0: 360808FF 000000F0
	v_min_i32_e32 v2, s33, v6                                  // 00000001AFE8: 22040C21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001AFEC: BF870091
	v_mad_i64_i32 v[2:3], null, 0x5000, v2, s[4:5]             // 00000001AFF0: D6FF7C02 001204FF 00005000
	.long 0xd7006a02                                           // 00000001AFFC: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000001B000: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001B004: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000001B008: D5207C03 01AA0680
	.long 0xd7006a04                                           // 00000001B010: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000001B014: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B01C: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 00000001B020: D5207C05 01AA0680
	s_clause 0x1                                               // 00000001B028: BF850001
	global_load_b128 v[66:69], v[2:3], off                     // 00000001B02C: DC5E0000 427C0002
	global_load_b128 v[70:73], v[4:5], off                     // 00000001B034: DC5E0000 467C0004
	.long 0xd4c3007e                                           // 00000001B03C: D4C3007E
	v_cndmask_b32_e32 v1, s31, v6, vcc_lo                      // 00000001B040: 02020C1F
	s_cbranch_execz 11                                         // 00000001B044: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1174>
	s_waitcnt vmcnt(1)                                         // 00000001B048: BF8907F7
	v_mov_b32_e32 v66, 0                                       // 00000001B04C: 7E840280
	s_waitcnt vmcnt(0)                                         // 00000001B050: BF8903F7
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B054: BF870001
	v_mov_b32_e32 v73, v66                                     // 00000001B058: 7E920342
	v_mov_b32_e32 v72, v66                                     // 00000001B05C: 7E900342
	v_mov_b32_e32 v71, v66                                     // 00000001B060: 7E8E0342
	v_mov_b32_e32 v70, v66                                     // 00000001B064: 7E8C0342
	v_mov_b32_e32 v67, v66                                     // 00000001B068: 7E860342
	v_mov_b32_e32 v68, v66                                     // 00000001B06C: 7E880342
	v_mov_b32_e32 v69, v66                                     // 00000001B070: 7E8A0342
	s_or_b32 exec_lo, exec_lo, s47                             // 00000001B074: 8C7E2F7E
	s_and_saveexec_b32 s47, s1                                 // 00000001B078: BEAF2001
	s_cbranch_execz 19                                         // 00000001B07C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11cc>
	v_dual_mov_b32 v137, 0 :: v_dual_add_nc_u32 v2, s2, v44    // 00000001B080: CA200080 89025802
	v_mov_b32_e32 v144, 0                                      // 00000001B088: 7F200280
	s_mov_b32 s1, exec_lo                                      // 00000001B08C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001B090: BF870002
	.long 0xd4c4007e                                           // 00000001B094: D4C4007E
	v_cndmask_b32_e32 v1, s31, v2, vcc_lo                      // 00000001B098: 0202041F
	s_cbranch_execz 10                                         // 00000001B09C: BFA5000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11c8>
	v_mad_i64_i32 v[3:4], null, 0xc0, v2, s[6:7]               // 00000001B0A0: D6FF7C03 001A04FF 000000C0
	v_mad_i64_i32 v[5:6], null, 0xc0, v2, s[10:11]             // 00000001B0AC: D6FF7C05 002A04FF 000000C0
	global_load_b32 v137, v[3:4], off                          // 00000001B0B8: DC520000 897C0003
	global_load_b32 v144, v[5:6], off                          // 00000001B0C0: DC520000 907C0005
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001B0C8: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B0CC: BF870009
	s_or_b32 exec_lo, exec_lo, s47                             // 00000001B0D0: 8C7E2F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B0D4: BF870009
	s_and_b32 vcc_lo, exec_lo, s34                             // 00000001B0D8: 8B6A227E
	s_mov_b32 s1, -1                                           // 00000001B0DC: BE8100C1
	s_cbranch_vccz 81                                          // 00000001B0E0: BFA30051 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1328>
	v_and_b32_e32 v2, -16, v44                                 // 00000001B0E4: 360458D0
	s_mov_b32 s1, exec_lo                                      // 00000001B0E8: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B0EC: BF870001
	v_cmpx_eq_u32_e32 64, v2                                   // 00000001B0F0: 7D9404C0
	s_cbranch_execz 74                                         // 00000001B0F4: BFA5004A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1320>
	v_lshlrev_b32_e32 v4, 2, v44                               // 00000001B0F8: 30085882
	s_waitcnt lgkmcnt(1)                                       // 00000001B0FC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B100: BF870001
	v_add_nc_u32_e32 v5, 0x5c00, v4                            // 00000001B104: 4A0A08FF 00005C00
	ds_load_2addr_b32 v[2:3], v5 offset0:64 offset1:80         // 00000001B10C: D8DC5040 02000005
	s_waitcnt lgkmcnt(1)                                       // 00000001B114: BF89FC17
	ds_load_b32 v6, v1 offset:24188                            // 00000001B118: D8D85E7C 06000001
	s_waitcnt lgkmcnt(1)                                       // 00000001B120: BF89FC17
	v_mul_f32_e32 v7, 0x3fb8aa3b, v3                           // 00000001B124: 100E06FF 3FB8AA3B
	ds_load_b32 v8, v4 offset:24128                            // 00000001B12C: D8D85E40 08000004
	s_waitcnt lgkmcnt(1)                                       // 00000001B134: BF89FC17
	v_sub_f32_e32 v6, v6, v3                                   // 00000001B138: 080C0706
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000001B13C: 7C3606FF C2CE8ED0
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v7                          // 00000001B144: D6130009 841E06FF 3FB8AA3B
	v_rndne_f32_e32 v10, v7                                    // 00000001B150: 7E144707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001B154: BF870114
	v_mul_f32_e32 v11, 0x3fb8aa3b, v6                          // 00000001B158: 10160CFF 3FB8AA3B
	v_sub_f32_e32 v7, v7, v10                                  // 00000001B160: 080E1507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000001B164: BF8701C2
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v11                        // 00000001B168: D613000C 842E0CFF 3FB8AA3B
	v_fmac_f32_e32 v9, 0x32a5705f, v3                          // 00000001B174: 561206FF 32A5705F
	v_cvt_i32_f32_e32 v10, v10                                 // 00000001B17C: 7E14110A
	v_rndne_f32_e32 v13, v11                                   // 00000001B180: 7E1A470B
	v_dual_fmac_f32 v12, 0x32a5705f, v6 :: v_dual_add_f32 v7, v7, v9// 00000001B184: C8080CFF 0C061307 32A5705F
	s_waitcnt lgkmcnt(0)                                       // 00000001B190: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001B194: BF870112
	v_dual_sub_f32 v9, v11, v13 :: v_dual_mul_f32 v2, v8, v2   // 00000001B198: C9461B0B 09020508
	v_exp_f32_e32 v7, v7                                       // 00000001B1A0: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B1A4: BF870125
	.long 0xd71c0007                                           // 00000001B1A8: D71C0007
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 00000001B1AC: 02021507
	v_cvt_i32_f32_e32 v10, v13                                 // 00000001B1B0: 7E14110D
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 00000001B1B4: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000001B1B8: 7C3C06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000001B1C0: BF8701B2
	v_cndmask_b32_e32 v3, 0x7f800000, v7, vcc_lo               // 00000001B1C4: 02060EFF 7F800000
	v_add_f32_e32 v9, v9, v12                                  // 00000001B1CC: 06121909
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 00000001B1D0: 7C360CFF C2CE8ED0
	v_mul_f32_e32 v2, v3, v2                                   // 00000001B1D8: 10040503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B1DC: BF870093
	v_exp_f32_e32 v9, v9                                       // 00000001B1E0: 7E124B09
	v_mul_f32_e32 v2, 0x41800000, v2                           // 00000001B1E4: 100404FF 41800000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B1EC: BF870095
	.long 0xd71c0009                                           // 00000001B1F0: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000001B1F4: 02021509
	v_cndmask_b32_e32 v7, 0, v9, vcc_lo                        // 00000001B1F8: 020E1280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 00000001B1FC: 7C3C0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001B204: BF870002
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 00000001B208: 020C0EFF 7F800000
	ds_store_b32 v4, v3 offset:24064                           // 00000001B210: D8345E00 00000304
	ds_store_2addr_b32 v5, v6, v2 offset0:96 offset1:112       // 00000001B218: D8387060 00020605
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001B220: 8C7E017E
	s_mov_b32 s1, 0                                            // 00000001B224: BE810080
	v_lshrrev_b32_e32 v157, 4, v43                             // 00000001B228: 333A5684
	v_mul_u32_u24_e32 v159, 0x110, v156                        // 00000001B22C: 173F38FF 00000110
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000001B234: 916A017E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001B238: BF870002
	v_lshlrev_b32_e32 v158, 2, v157                            // 00000001B23C: 313D3A82
	s_cbranch_vccnz 876                                        // 00000001B240: BFA4036C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x20f4>
	v_mad_u32_u24 v2, 0x110, v156, s42                         // 00000001B244: D60B0002 00AB38FF 00000110
	s_and_b32 s1, s0, exec_lo                                  // 00000001B250: 8B017E00
	s_cselect_b32 s1, 0, 0x1100                                // 00000001B254: 9801FF80 00001100
	v_mad_u32_u24 v3, 0x110, v156, s43                         // 00000001B25C: D60B0003 00AF38FF 00000110
	ds_load_b128 v[10:13], v159 offset:6144                    // 00000001B268: DBFC1800 0A00009F
	ds_load_b128 v[14:17], v159 offset:6160                    // 00000001B270: DBFC1810 0E00009F
	v_add_nc_u32_e32 v4, s1, v2                                // 00000001B278: 4A080401
	v_mov_b32_e32 v8, v1                                       // 00000001B27C: 7E100301
	s_waitcnt lgkmcnt(3)                                       // 00000001B280: BF89FC37
	v_mov_b32_e32 v5, v1                                       // 00000001B284: 7E0A0301
	v_cndmask_b32_e64 v61, v3, v2, s0                          // 00000001B288: D501003D 00020503
	v_mov_b32_e32 v3, v1                                       // 00000001B290: 7E060301
	ds_load_b128 v[18:21], v4                                  // 00000001B294: DBFC0000 12000004
	ds_load_b128 v[22:25], v4 offset:16                        // 00000001B29C: DBFC0010 16000004
	ds_load_b128 v[26:29], v159 offset:6176                    // 00000001B2A4: DBFC1820 1A00009F
	ds_load_b128 v[30:33], v159 offset:6192                    // 00000001B2AC: DBFC1830 1E00009F
	ds_load_b128 v[45:48], v61 offset:32                       // 00000001B2B4: DBFC0020 2D00003D
	ds_load_b128 v[49:52], v61 offset:48                       // 00000001B2BC: DBFC0030 3100003D
	ds_load_b128 v[53:56], v61 offset:64                       // 00000001B2C4: DBFC0040 3500003D
	ds_load_b128 v[57:60], v61 offset:80                       // 00000001B2CC: DBFC0050 3900003D
	ds_load_b128 v[164:167], v159 offset:6224                  // 00000001B2D4: DBFC1850 A400009F
	ds_load_b128 v[160:163], v159 offset:6208                  // 00000001B2DC: DBFC1840 A000009F
	v_mov_b32_e32 v2, v1                                       // 00000001B2E4: 7E040301
	v_mov_b32_e32 v4, v1                                       // 00000001B2E8: 7E080301
	s_waitcnt lgkmcnt(12)                                      // 00000001B2EC: BF89FCC7
	v_mov_b32_e32 v6, v1                                       // 00000001B2F0: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000001B2F4: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 00000001B2F8: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001B2FC: BF870212
	v_mov_b32_e32 v8, v7                                       // 00000001B300: 7E100307
	v_mov_b32_e32 v7, v6                                       // 00000001B304: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 00000001B308: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 00000001B30C: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 00000001B310: 7E080303
	v_mov_b32_e32 v3, v2                                       // 00000001B314: 7E060302
	v_mov_b32_e32 v2, v1                                       // 00000001B318: 7E040301
	ds_load_b128 v[172:175], v159 offset:6256                  // 00000001B31C: DBFC1870 AC00009F
	ds_load_b128 v[168:171], v159 offset:6240                  // 00000001B324: DBFC1860 A800009F
	ds_load_b128 v[180:183], v61 offset:112                    // 00000001B32C: DBFC0070 B400003D
	ds_load_b128 v[176:179], v61 offset:96                     // 00000001B334: DBFC0060 B000003D
	v_dual_mov_b32 v63, v191 :: v_dual_mov_b32 v62, v190       // 00000001B33C: CA1001BF 3F3E01BE
	s_and_not1_b32 vcc_lo, exec_lo, s15                        // 00000001B344: 916A0F7E
	s_waitcnt lgkmcnt(12)                                      // 00000001B348: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 00000001B34C: CC414002 1C0A1512
	ds_load_b128 v[14:17], v159 offset:6288                    // 00000001B354: DBFC1890 0E00009F
	ds_load_b128 v[10:13], v159 offset:6272                    // 00000001B35C: DBFC1880 0A00009F
	ds_load_b128 v[22:25], v61 offset:144                      // 00000001B364: DBFC0090 1600003D
	ds_load_b128 v[18:21], v61 offset:128                      // 00000001B36C: DBFC0080 1200003D
	s_mov_b32 s1, -1                                           // 00000001B374: BE8100C1
	s_waitcnt lgkmcnt(12)                                      // 00000001B378: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[45:52], v[26:33], v[2:9]// 00000001B37C: CC414002 1C0A352D
	ds_load_b128 v[30:33], v159 offset:6320                    // 00000001B384: DBFC18B0 1E00009F
	ds_load_b128 v[26:29], v159 offset:6304                    // 00000001B38C: DBFC18A0 1A00009F
	ds_load_b128 v[188:191], v61 offset:176                    // 00000001B394: DBFC00B0 BC00003D
	ds_load_b128 v[184:187], v61 offset:160                    // 00000001B39C: DBFC00A0 B800003D
	v_lshlrev_b32_e32 v51, 2, v156                             // 00000001B3A4: 30673882
	v_or_b32_e32 v50, 4, v157                                  // 00000001B3A8: 38653A84
	v_or_b32_e32 v49, 6, v157                                  // 00000001B3AC: 38633A86
	s_waitcnt lgkmcnt(12)                                      // 00000001B3B0: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[53:60], v[160:167], v[2:9]// 00000001B3B4: CC414002 1C0B4135
	ds_load_b128 v[56:59], v159 offset:6352                    // 00000001B3BC: DBFC18D0 3800009F
	ds_load_b128 v[52:55], v159 offset:6336                    // 00000001B3C4: DBFC18C0 3400009F
	v_add_nc_u32_e32 v45, 64, v51                              // 00000001B3CC: 4A5A66C0
	ds_load_b128 v[164:167], v159 offset:6384                  // 00000001B3D0: DBFC18F0 A400009F
	ds_load_b128 v[160:163], v159 offset:6368                  // 00000001B3D8: DBFC18E0 A000009F
	v_or_b32_e32 v48, 8, v157                                  // 00000001B3E0: 38613A88
	v_or_b32_e32 v47, 10, v157                                 // 00000001B3E4: 385F3A8A
	s_waitcnt lgkmcnt(12)                                      // 00000001B3E8: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[176:183], v[168:175], v[2:9]// 00000001B3EC: CC414002 1C0B51B0
	ds_load_b128 v[172:175], v61 offset:208                    // 00000001B3F4: DBFC00D0 AC00003D
	ds_load_b128 v[168:171], v61 offset:192                    // 00000001B3FC: DBFC00C0 A800003D
	v_or_b32_e32 v46, 12, v157                                 // 00000001B404: 385D3A8C
	s_waitcnt lgkmcnt(10)                                      // 00000001B408: BF89FCA7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 00000001B40C: CC414002 1C0A1512
	v_add_nc_u32_e32 v10, 0x5c00, v158                         // 00000001B414: 4A153CFF 00005C00
	v_add_nc_u32_e32 v11, s35, v158                            // 00000001B41C: 4A173C23
	ds_load_b128 v[180:183], v61 offset:240                    // 00000001B420: DBFC00F0 B400003D
	ds_load_b128 v[176:179], v61 offset:224                    // 00000001B428: DBFC00E0 B000003D
	ds_load_2addr_stride64_b32 v[12:13], v45 offset0:94 offset1:95// 00000001B430: D8E05F5E 0C00002D
	v_or_b32_e32 v45, 14, v157                                 // 00000001B438: 385B3A8E
	s_waitcnt lgkmcnt(9)                                       // 00000001B43C: BF89FC97
	v_wmma_f32_16x16x16_bf16 v[2:9], v[184:191], v[26:33], v[2:9]// 00000001B440: CC414002 1C0A35B8
	ds_load_2addr_b32 v[28:29], v10 offset0:144 offset1:146    // 00000001B448: D8DC9290 1C00000A
	ds_load_2addr_b32 v[24:25], v10 offset0:148 offset1:150    // 00000001B450: D8DC9694 1800000A
	ds_load_2addr_b32 v[20:21], v10 offset0:152 offset1:154    // 00000001B458: D8DC9A98 1400000A
	ds_load_2addr_b32 v[16:17], v10 offset0:156 offset1:158    // 00000001B460: D8DC9E9C 1000000A
	ds_load_2addr_b32 v[26:27], v11 offset1:2                  // 00000001B468: D8DC0200 1A00000B
	ds_load_2addr_b32 v[22:23], v11 offset0:4 offset1:6        // 00000001B470: D8DC0604 1600000B
	ds_load_2addr_b32 v[18:19], v11 offset0:8 offset1:10       // 00000001B478: D8DC0A08 1200000B
	ds_load_2addr_b32 v[14:15], v11 offset0:12 offset1:14      // 00000001B480: D8DC0E0C 0E00000B
	s_waitcnt lgkmcnt(11)                                      // 00000001B488: BF89FCB7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[168:175], v[52:59], v[2:9]// 00000001B48C: CC414002 1C0A69A8
	v_or_b32_e32 v52, 2, v157                                  // 00000001B494: 38693A82
	s_waitcnt lgkmcnt(9)                                       // 00000001B498: BF89FC97
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001B49C: BF870002
	v_wmma_f32_16x16x16_bf16 v[2:9], v[176:183], v[160:167], v[2:9]// 00000001B4A0: CC414002 1C0B41B0
	s_cbranch_vccnz 353                                        // 00000001B4A8: BFA40161 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b30>
	.long 0x7e143880                                           // 00000001B4AC: 7E143880
	s_mov_b32 s1, exec_lo                                      // 00000001B4B0: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B4B4: BF870001
	.long 0x7f14390a                                           // 00000001B4B8: 7F14390A
	.long 0xd4cb007e                                           // 00000001B4BC: D4CB007E
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                   // 00000001B4C0: 02033B9C
	s_cbranch_execz 34                                         // 00000001B4C4: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1650>
	s_waitcnt lgkmcnt(7)                                       // 00000001B4C8: BF89FC77
	v_sub_f32_e32 v11, v28, v12                                // 00000001B4CC: 0816191C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B4D0: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v11                         // 00000001B4D4: 103C16FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v11, -v30                       // 00000001B4DC: D613001F 847A16FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 00000001B4E8: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B4EC: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v11 :: v_dual_sub_f32 v30, v30, v32// 00000001B4F0: C80A16FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 00000001B4FC: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 00000001B500: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000001B504: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001B50C: BF870293
	v_exp_f32_e32 v30, v30                                     // 00000001B510: 7E3C4B1E
	.long 0xd71c001e                                           // 00000001B514: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 00000001B518: 02023F1E
	s_waitcnt lgkmcnt(3)                                       // 00000001B51C: BF89FC37
	v_mul_f32_e32 v31, v2, v26                                 // 00000001B520: 103E3502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B524: BF870122
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 00000001B528: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000001B52C: 7C3C16FF 42B17218
	v_dual_cndmask_b32 v11, 0x7f800000, v30 :: v_dual_mul_f32 v30, v13, v31// 00000001B534: CA463CFF 0B1E3F0D 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B540: BF870091
	v_mul_f32_e32 v11, v11, v30                                // 00000001B544: 10163D0B
	v_fma_mixhi_f16 v10, v11, s41, 0                           // 00000001B548: CC22000A 0200530B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001B550: 8C7E017E
	v_mul_u32_u24_e32 v11, 48, v157                            // 00000001B554: 16173AB0
	s_mov_b32 s1, exec_lo                                      // 00000001B558: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B55C: BF870001
	v_lshl_add_u32 v11, v156, 1, v11                           // 00000001B560: D646000B 042D039C
	ds_store_b16_d16_hi v11, v10 offset:23296                  // 00000001B568: DA845B00 00000A0B
	.long 0xd4cb007e                                           // 00000001B570: D4CB007E
	v_cndmask_b32_e32 v1, v156, v52, vcc_lo                    // 00000001B574: 0202699C
	s_cbranch_execz 34                                         // 00000001B578: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1704>
	s_waitcnt lgkmcnt(8)                                       // 00000001B57C: BF89FC87
	v_sub_f32_e32 v10, v29, v12                                // 00000001B580: 0814191D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B584: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v10                         // 00000001B588: 103C14FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v30                       // 00000001B590: D613001F 847A14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 00000001B59C: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B5A0: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v10 :: v_dual_sub_f32 v30, v30, v32// 00000001B5A4: C80A14FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 00000001B5B0: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 00000001B5B4: 7E3E1120
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001B5B8: BF870292
	v_exp_f32_e32 v30, v30                                     // 00000001B5BC: 7E3C4B1E
	.long 0xd71c001e                                           // 00000001B5C0: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 00000001B5C4: 02023F1E
	s_waitcnt lgkmcnt(4)                                       // 00000001B5C8: BF89FC47
	v_mul_f32_e32 v31, v3, v27                                 // 00000001B5CC: 103E3703
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000001B5D0: 7C3614FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B5D8: BF870123
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 00000001B5DC: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000001B5E0: 7C3C14FF 42B17218
	v_cndmask_b32_e32 v10, 0x7f800000, v30, vcc_lo             // 00000001B5E8: 02143CFF 7F800000
	v_mul_f32_e32 v30, v13, v31                                // 00000001B5F0: 103C3F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B5F4: BF870091
	v_mul_f32_e32 v10, v10, v30                                // 00000001B5F8: 10143D0A
	v_fma_mixlo_f16 v10, v10, s41, 0                           // 00000001B5FC: CC21000A 0200530A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001B604: 8C7E017E
	.long 0x7f143880                                           // 00000001B608: 7F143880
	v_or_b32_e32 v30, 0x5b00, v11                              // 00000001B60C: 383C16FF 00005B00
	s_mov_b32 s1, exec_lo                                      // 00000001B614: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001B618: BF870002
	.long 0x7e16398a                                           // 00000001B61C: 7E16398A
	ds_store_b16 v30, v10 offset:96                            // 00000001B620: D87C0060 00000A1E
	.long 0xd4cb007e                                           // 00000001B628: D4CB007E
	v_cndmask_b32_e32 v1, v156, v50, vcc_lo                    // 00000001B62C: 0202659C
	s_cbranch_execz 35                                         // 00000001B630: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x17c0>
	s_waitcnt lgkmcnt(8)                                       // 00000001B634: BF89FC87
	v_sub_f32_e32 v11, v24, v12                                // 00000001B638: 08161918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B63C: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000001B640: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000001B648: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000001B650: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000001B65C: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B660: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000001B664: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000001B670: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000001B674: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001B678: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000001B67C: 7E3E4B1F
	.long 0xd71c001f                                           // 00000001B680: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000001B684: 0202411F
	s_waitcnt lgkmcnt(4)                                       // 00000001B688: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B68C: BF870121
	v_dual_mul_f32 v32, v4, v22 :: v_dual_cndmask_b32 v31, 0, v31// 00000001B690: C8D22D04 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000001B698: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000001B6A0: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B6A8: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 00000001B6AC: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 00000001B6B0: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B6B4: BF870001
	v_fma_mixlo_f16 v11, v11, s41, 0                           // 00000001B6B8: CC21000B 0200530B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001B6C0: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B6C4: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000001B6C8: BE81007E
	ds_store_b16 v30, v11 offset:192                           // 00000001B6CC: D87C00C0 00000B1E
	.long 0xd4cb007e                                           // 00000001B6D4: D4CB007E
	v_cndmask_b32_e32 v1, v156, v49, vcc_lo                    // 00000001B6D8: 0202639C
	s_cbranch_execz 35                                         // 00000001B6DC: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x186c>
	s_waitcnt lgkmcnt(9)                                       // 00000001B6E0: BF89FC97
	v_sub_f32_e32 v10, v25, v12                                // 00000001B6E4: 08141919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B6E8: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000001B6EC: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000001B6F4: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000001B700: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001B704: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000001B708: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000001B710: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000001B714: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000001B718: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000001B71C: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000001B720: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000001B728: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001B72C: BF870135
	.long 0xd71c000b                                           // 00000001B730: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000001B734: 02023F0B
	s_waitcnt lgkmcnt(5)                                       // 00000001B738: BF89FC57
	v_mul_f32_e32 v31, v5, v23                                 // 00000001B73C: 103E2F05
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000001B740: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000001B744: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001B74C: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000001B750: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000001B758: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B75C: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000001B760: 1014170A
	v_fma_mixhi_f16 v10, v10, s41, 0                           // 00000001B764: CC22000A 0200530A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001B76C: 8C7E017E
	.long 0x7e143880                                           // 00000001B770: 7E143880
	s_mov_b32 s1, exec_lo                                      // 00000001B774: BE81007E
	ds_store_b16_d16_hi v30, v10 offset:288                    // 00000001B778: DA840120 00000A1E
	.long 0x7e16390a                                           // 00000001B780: 7E16390A
	.long 0xd4cb007e                                           // 00000001B784: D4CB007E
	v_cndmask_b32_e32 v1, v156, v48, vcc_lo                    // 00000001B788: 0202619C
	s_cbranch_execz 34                                         // 00000001B78C: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1918>
	s_waitcnt lgkmcnt(9)                                       // 00000001B790: BF89FC97
	v_sub_f32_e32 v11, v20, v12                                // 00000001B794: 08161914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B798: BF870091
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000001B79C: 103E16FF 3FB8AA3B
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000001B7A4: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000001B7B0: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B7B4: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000001B7B8: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000001B7C4: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000001B7C8: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001B7CC: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000001B7D0: 7E3E4B1F
	.long 0xd71c001f                                           // 00000001B7D4: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000001B7D8: 0202411F
	s_waitcnt lgkmcnt(5)                                       // 00000001B7DC: BF89FC57
	v_mul_f32_e32 v32, v6, v18                                 // 00000001B7E0: 10402506
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000001B7E4: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B7EC: BF870123
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 00000001B7F0: 023E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000001B7F4: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000001B7FC: 02163EFF 7F800000
	v_mul_f32_e32 v31, v13, v32                                // 00000001B804: 103E410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B808: BF870091
	v_mul_f32_e32 v11, v11, v31                                // 00000001B80C: 10163F0B
	v_fma_mixlo_f16 v11, v11, s41, 0                           // 00000001B810: CC21000B 0200530B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001B818: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B81C: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000001B820: BE81007E
	ds_store_b16 v30, v11 offset:384                           // 00000001B824: D87C0180 00000B1E
	.long 0xd4cb007e                                           // 00000001B82C: D4CB007E
	v_cndmask_b32_e32 v1, v156, v47, vcc_lo                    // 00000001B830: 02025F9C
	s_cbranch_execz 35                                         // 00000001B834: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x19c4>
	s_waitcnt lgkmcnt(10)                                      // 00000001B838: BF89FCA7
	v_sub_f32_e32 v10, v21, v12                                // 00000001B83C: 08141915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B840: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000001B844: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000001B84C: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000001B858: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001B85C: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000001B860: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000001B868: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000001B86C: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000001B870: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000001B874: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000001B878: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000001B880: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001B884: BF870135
	.long 0xd71c000b                                           // 00000001B888: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000001B88C: 02023F0B
	s_waitcnt lgkmcnt(6)                                       // 00000001B890: BF89FC67
	v_mul_f32_e32 v31, v7, v19                                 // 00000001B894: 103E2707
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000001B898: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000001B89C: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001B8A4: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000001B8A8: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000001B8B0: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B8B4: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000001B8B8: 1014170A
	v_fma_mixlo_f16 v10, v10, s41, 0                           // 00000001B8BC: CC21000A 0200530A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001B8C4: 8C7E017E
	.long 0x7f143880                                           // 00000001B8C8: 7F143880
	s_mov_b32 s1, exec_lo                                      // 00000001B8CC: BE81007E
	ds_store_b16 v30, v10 offset:480                           // 00000001B8D0: D87C01E0 00000A1E
	.long 0x7e16398a                                           // 00000001B8D8: 7E16398A
	.long 0xd4cb007e                                           // 00000001B8DC: D4CB007E
	v_cndmask_b32_e32 v1, v156, v46, vcc_lo                    // 00000001B8E0: 02025D9C
	s_cbranch_execz 35                                         // 00000001B8E4: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1a74>
	s_waitcnt lgkmcnt(10)                                      // 00000001B8E8: BF89FCA7
	v_sub_f32_e32 v11, v16, v12                                // 00000001B8EC: 08161910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B8F0: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000001B8F4: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000001B8FC: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000001B904: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000001B910: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B914: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000001B918: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000001B924: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000001B928: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001B92C: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000001B930: 7E3E4B1F
	.long 0xd71c001f                                           // 00000001B934: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000001B938: 0202411F
	s_waitcnt lgkmcnt(6)                                       // 00000001B93C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B940: BF870121
	v_dual_mul_f32 v32, v8, v14 :: v_dual_cndmask_b32 v31, 0, v31// 00000001B944: C8D21D08 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000001B94C: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000001B954: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B95C: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 00000001B960: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 00000001B964: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B968: BF870001
	v_fma_mixlo_f16 v11, v11, s41, 0                           // 00000001B96C: CC21000B 0200530B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001B974: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B978: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000001B97C: BE81007E
	ds_store_b16 v30, v11 offset:576                           // 00000001B980: D87C0240 00000B1E
	.long 0xd4cb007e                                           // 00000001B988: D4CB007E
	v_cndmask_b32_e32 v1, v156, v45, vcc_lo                    // 00000001B98C: 02025B9C
	s_cbranch_execz 35                                         // 00000001B990: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b20>
	s_waitcnt lgkmcnt(11)                                      // 00000001B994: BF89FCB7
	v_sub_f32_e32 v10, v17, v12                                // 00000001B998: 08141911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B99C: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000001B9A0: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000001B9A8: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000001B9B4: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001B9B8: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000001B9BC: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000001B9C4: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000001B9C8: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000001B9CC: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000001B9D0: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000001B9D4: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000001B9DC: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001B9E0: BF870135
	.long 0xd71c000b                                           // 00000001B9E4: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000001B9E8: 02023F0B
	s_waitcnt lgkmcnt(7)                                       // 00000001B9EC: BF89FC77
	v_mul_f32_e32 v31, v9, v15                                 // 00000001B9F0: 103E1F09
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000001B9F4: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000001B9F8: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001BA00: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000001BA04: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000001BA0C: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BA10: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000001BA14: 1014170A
	v_fma_mixhi_f16 v10, v10, s41, 0                           // 00000001BA18: CC22000A 0200530A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001BA20: 8C7E017E
	s_mov_b32 s1, 0                                            // 00000001BA24: BE810080
	ds_store_b16_d16_hi v30, v10 offset:672                    // 00000001BA28: DA8402A0 00000A1E
	v_dual_mov_b32 v190, v62 :: v_dual_mov_b32 v191, v63       // 00000001BA30: CA10013E BEBE013F
	s_and_b32 vcc_lo, exec_lo, s1                              // 00000001BA38: 8B6A017E
	s_cbranch_vccz 365                                         // 00000001BA3C: BFA3016D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x20f4>
	v_or_b32_e32 v10, 0x5e40, v158                             // 00000001BA40: 38153CFF 00005E40
	v_mov_b32_e32 v54, 0                                       // 00000001BA48: 7E6C0280
	v_mov_b32_e32 v56, 0                                       // 00000001BA4C: 7E700280
	s_mov_b32 s1, exec_lo                                      // 00000001BA50: BE81007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000001BA54: BF870003
	v_subrev_nc_u32_e32 v55, 64, v10                           // 00000001BA58: 4E6E14C0
	ds_load_2addr_b32 v[32:33], v55 offset0:2 offset1:4        // 00000001BA5C: D8DC0402 20000037
	ds_load_2addr_b32 v[30:31], v55 offset0:6 offset1:8        // 00000001BA64: D8DC0806 1E000037
	ds_load_2addr_b32 v[10:11], v55 offset0:10 offset1:12      // 00000001BA6C: D8DC0C0A 0A000037
	ds_load_b32 v53, v55 offset:56                             // 00000001BA74: D8D80038 35000037
	.long 0xd4c9007e                                           // 00000001BA7C: D4C9007E
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                   // 00000001BA80: 02033B9C
	s_cbranch_execz 37                                         // 00000001BA84: BFA50025 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1c1c>
	s_waitcnt lgkmcnt(11)                                      // 00000001BA88: BF89FCB7
	v_sub_f32_e32 v28, v28, v12                                // 00000001BA8C: 0838191C
	ds_load_b32 v55, v55                                       // 00000001BA90: D8D80000 37000037
	s_waitcnt lgkmcnt(8)                                       // 00000001BA98: BF89FC87
	v_mul_f32_e32 v2, v2, v26                                  // 00000001BA9C: 10043502
	v_mul_f32_e32 v56, 0x3fb8aa3b, v28                         // 00000001BAA0: 107038FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v28                  // 00000001BAA8: 7C3638FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001BAB0: BF870193
	v_mul_f32_e32 v2, v13, v2                                  // 00000001BAB4: 1004050D
	v_fma_f32 v57, 0x3fb8aa3b, v28, -v56                       // 00000001BAB8: D6130039 84E238FF 3FB8AA3B
	v_rndne_f32_e32 v58, v56                                   // 00000001BAC4: 7E744738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BAC8: BF870091
	v_dual_fmac_f32 v57, 0x32a5705f, v28 :: v_dual_sub_f32 v56, v56, v58// 00000001BACC: C80A38FF 39387538 32A5705F
	v_add_f32_e32 v56, v56, v57                                // 00000001BAD8: 06707338
	v_cvt_i32_f32_e32 v57, v58                                 // 00000001BADC: 7E72113A
	s_waitcnt lgkmcnt(0)                                       // 00000001BAE0: BF89FC07
	v_mul_f32_e32 v2, v55, v2                                  // 00000001BAE4: 10040537
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001BAE8: BF870293
	v_exp_f32_e32 v56, v56                                     // 00000001BAEC: 7E704B38
	.long 0xd71c0038                                           // 00000001BAF0: D71C0038
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                     // 00000001BAF4: 02027338
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BAF8: BF870121
	v_cndmask_b32_e32 v26, 0, v56, vcc_lo                      // 00000001BAFC: 02347080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v28                  // 00000001BB00: 7C3C38FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 00000001BB08: 023434FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001BB10: BF870001
	.long 0xd5080038                                           // 00000001BB14: D5080038
	v_sub_co_ci_u32_e32 v1, vcc_lo, v2, v26, vcc_lo            // 00000001BB18: 42023502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001BB1C: 8C7E017E
	v_or_b32_e32 v2, 0x5e40, v51                               // 00000001BB20: 380466FF 00005E40
	s_waitcnt lgkmcnt(7)                                       // 00000001BB28: BF89FC77
	v_lshlrev_b32_e32 v26, 6, v157                             // 00000001BB2C: 30353A86
	s_mov_b32 s1, exec_lo                                      // 00000001BB30: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001BB34: BF870001
	v_add3_u32 v2, v2, v26, 0xfffff8c0                         // 00000001BB38: D6550002 03FE3502 FFFFF8C0
	ds_store_b32 v2, v56                                       // 00000001BB44: D8340000 00003802
	.long 0xd4c9007e                                           // 00000001BB4C: D4C9007E
	v_cndmask_b32_e32 v1, v156, v52, vcc_lo                    // 00000001BB50: 0202699C
	s_cbranch_execz 33                                         // 00000001BB54: BFA50021 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1cdc>
	v_dual_sub_f32 v26, v29, v12 :: v_dual_mul_f32 v3, v3, v27 // 00000001BB58: C946191D 1A023703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BB60: BF870121
	v_dual_mul_f32 v28, 0x3fb8aa3b, v26 :: v_dual_mul_f32 v3, v13, v3// 00000001BB64: C8C634FF 1C02070D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v26                  // 00000001BB70: 7C3634FF C2CE8ED0
	v_fma_f32 v29, 0x3fb8aa3b, v26, -v28                       // 00000001BB78: D613001D 847234FF 3FB8AA3B
	v_rndne_f32_e32 v51, v28                                   // 00000001BB84: 7E66471C
	s_waitcnt lgkmcnt(4)                                       // 00000001BB88: BF89FC47
	v_mul_f32_e32 v3, v32, v3                                  // 00000001BB8C: 10060720
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BB90: BF870092
	v_dual_fmac_f32 v29, 0x32a5705f, v26 :: v_dual_sub_f32 v28, v28, v51// 00000001BB94: C80A34FF 1D1C671C 32A5705F
	v_add_f32_e32 v28, v28, v29                                // 00000001BBA0: 06383B1C
	v_cvt_i32_f32_e32 v29, v51                                 // 00000001BBA4: 7E3A1133
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001BBA8: BF870292
	v_exp_f32_e32 v28, v28                                     // 00000001BBAC: 7E384B1C
	.long 0xd71c001c                                           // 00000001BBB0: D71C001C
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                     // 00000001BBB4: 02023B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BBB8: BF870121
	v_cndmask_b32_e32 v27, 0, v28, vcc_lo                      // 00000001BBBC: 02363880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v26                  // 00000001BBC0: 7C3C34FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v27, vcc_lo             // 00000001BBC8: 023436FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001BBD0: BF870001
	.long 0xd5080036                                           // 00000001BBD4: D5080036
	v_sub_co_ci_u32_e32 v1, vcc_lo, v3, v26, vcc_lo            // 00000001BBD8: 42023503
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001BBDC: 8C7E017E
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v26, 0              // 00000001BBE0: CA100080 031A0080
	s_mov_b32 s1, exec_lo                                      // 00000001BBE8: BE81007E
	ds_store_b32 v2, v54 offset:128                            // 00000001BBEC: D8340080 00003602
	.long 0xd4c9007e                                           // 00000001BBF4: D4C9007E
	v_cndmask_b32_e32 v1, v156, v50, vcc_lo                    // 00000001BBF8: 0202659C
	s_cbranch_execz 35                                         // 00000001BBFC: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1d8c>
	v_sub_f32_e32 v24, v24, v12                                // 00000001BC00: 08301918
	s_waitcnt lgkmcnt(8)                                       // 00000001BC04: BF89FC87
	v_mul_f32_e32 v4, v4, v22                                  // 00000001BC08: 10082D04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001BC0C: BF8701A2
	v_mul_f32_e32 v26, 0x3fb8aa3b, v24                         // 00000001BC10: 103430FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v24                  // 00000001BC18: 7C3630FF C2CE8ED0
	v_mul_f32_e32 v4, v13, v4                                  // 00000001BC20: 1008090D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000001BC24: BF8701B3
	v_fma_f32 v27, 0x3fb8aa3b, v24, -v26                       // 00000001BC28: D613001B 846A30FF 3FB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000001BC34: 7E38471A
	s_waitcnt lgkmcnt(5)                                       // 00000001BC38: BF89FC57
	v_mul_f32_e32 v4, v33, v4                                  // 00000001BC3C: 10080921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001BC40: BF870193
	v_fmac_f32_e32 v27, 0x32a5705f, v24                        // 00000001BC44: 563630FF 32A5705F
	v_sub_f32_e32 v26, v26, v28                                // 00000001BC4C: 0834391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BC50: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000001BC54: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000001BC58: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000001BC5C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BC60: BF870095
	.long 0xd71c001a                                           // 00000001BC64: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000001BC68: 0202371A
	v_cndmask_b32_e32 v22, 0, v26, vcc_lo                      // 00000001BC6C: 022C3480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v24                  // 00000001BC70: 7C3C30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BC78: BF870092
	v_cndmask_b32_e32 v22, 0x7f800000, v22, vcc_lo             // 00000001BC7C: 022C2CFF 7F800000
	.long 0xd508001a                                           // 00000001BC84: D508001A
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v22, vcc_lo            // 00000001BC88: 42022D04
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001BC8C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001BC90: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000001BC94: BE81007E
	ds_store_b32 v2, v26 offset:256                            // 00000001BC98: D8340100 00001A02
	.long 0xd4c9007e                                           // 00000001BCA0: D4C9007E
	v_cndmask_b32_e32 v1, v156, v49, vcc_lo                    // 00000001BCA4: 0202639C
	s_cbranch_execz 34                                         // 00000001BCA8: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1e34>
	v_sub_f32_e32 v3, v25, v12                                 // 00000001BCAC: 08061919
	s_waitcnt lgkmcnt(9)                                       // 00000001BCB0: BF89FC97
	v_mul_f32_e32 v5, v5, v23                                  // 00000001BCB4: 100A2F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BCB8: BF870091
	v_dual_mul_f32 v4, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, v13, v5// 00000001BCBC: C8C606FF 04040B0D 3FB8AA3B
	v_fma_f32 v22, 0x3fb8aa3b, v3, -v4                         // 00000001BCC8: D6130016 841206FF 3FB8AA3B
	v_rndne_f32_e32 v24, v4                                    // 00000001BCD4: 7E304704
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001BCD8: BF870112
	v_fmac_f32_e32 v22, 0x32a5705f, v3                         // 00000001BCDC: 562C06FF 32A5705F
	v_sub_f32_e32 v4, v4, v24                                  // 00000001BCE4: 08083104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000001BCE8: BF8701B1
	v_add_f32_e32 v4, v4, v22                                  // 00000001BCEC: 06082D04
	v_cvt_i32_f32_e32 v22, v24                                 // 00000001BCF0: 7E2C1118
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000001BCF4: 7C3606FF C2CE8ED0
	v_exp_f32_e32 v4, v4                                       // 00000001BCFC: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BD00: BF870095
	.long 0xd71c0004                                           // 00000001BD04: D71C0004
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 00000001BD08: 02022D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 00000001BD0C: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000001BD10: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(5)                                       // 00000001BD18: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BD1C: BF870092
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v30, v5// 00000001BD20: CA4608FF 03040B1E 7F800000
	.long 0xd5080003                                           // 00000001BD2C: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000001BD30: 42020704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001BD34: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000001BD38: CA100080 04040080
	s_mov_b32 s1, exec_lo                                      // 00000001BD40: BE81007E
	ds_store_b32 v2, v3 offset:384                             // 00000001BD44: D8340180 00000302
	.long 0xd4c9007e                                           // 00000001BD4C: D4C9007E
	v_cndmask_b32_e32 v1, v156, v48, vcc_lo                    // 00000001BD50: 0202619C
	s_cbranch_execz 34                                         // 00000001BD54: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1ee0>
	s_waitcnt lgkmcnt(9)                                       // 00000001BD58: BF89FC97
	v_dual_sub_f32 v3, v20, v12 :: v_dual_mul_f32 v6, v6, v18  // 00000001BD5C: C9461914 03062506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BD64: BF870121
	v_dual_mul_f32 v5, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v6, v13, v6// 00000001BD68: C8C606FF 05060D0D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000001BD74: 7C3606FF C2CE8ED0
	v_fma_f32 v20, 0x3fb8aa3b, v3, -v5                         // 00000001BD7C: D6130014 841606FF 3FB8AA3B
	v_rndne_f32_e32 v22, v5                                    // 00000001BD88: 7E2C4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BD8C: BF870091
	v_dual_fmac_f32 v20, 0x32a5705f, v3 :: v_dual_sub_f32 v5, v5, v22// 00000001BD90: C80A06FF 14042D05 32A5705F
	v_add_f32_e32 v5, v5, v20                                  // 00000001BD9C: 060A2905
	v_cvt_i32_f32_e32 v20, v22                                 // 00000001BDA0: 7E281116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001BDA4: BF870292
	v_exp_f32_e32 v5, v5                                       // 00000001BDA8: 7E0A4B05
	.long 0xd71c0005                                           // 00000001BDAC: D71C0005
	v_cndmask_b32_e32 v1, v5, v20, vcc_lo                      // 00000001BDB0: 02022905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BDB4: BF870121
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 00000001BDB8: 020A0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000001BDBC: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v3, 0x7f800000, v5, vcc_lo               // 00000001BDC4: 02060AFF 7F800000
	s_waitcnt lgkmcnt(6)                                       // 00000001BDCC: BF89FC67
	v_mul_f32_e32 v5, v31, v6                                  // 00000001BDD0: 100A0D1F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001BDD4: BF870001
	.long 0xd5080005                                           // 00000001BDD8: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v3, vcc_lo             // 00000001BDDC: 42020705
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001BDE0: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001BDE4: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000001BDE8: BE81007E
	ds_store_b32 v2, v5 offset:512                             // 00000001BDEC: D8340200 00000502
	.long 0xd4c9007e                                           // 00000001BDF4: D4C9007E
	v_cndmask_b32_e32 v1, v156, v47, vcc_lo                    // 00000001BDF8: 02025F9C
	s_cbranch_execz 35                                         // 00000001BDFC: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1f8c>
	v_sub_f32_e32 v3, v21, v12                                 // 00000001BE00: 08061915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BE04: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000001BE08: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 00000001BE10: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 00000001BE1C: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001BE20: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000001BE24: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000001BE28: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 00000001BE30: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BE38: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 00000001BE3C: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 00000001BE40: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000001BE44: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001BE48: BF8700A5
	.long 0xd71c0004                                           // 00000001BE4C: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000001BE50: 02020B04
	s_waitcnt lgkmcnt(10)                                      // 00000001BE54: BF89FCA7
	v_dual_mul_f32 v5, v7, v19 :: v_dual_cndmask_b32 v4, 0, v4 // 00000001BE58: C8D22707 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001BE60: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000001BE64: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000001BE68: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(6)                                       // 00000001BE70: BF89FC67
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v10, v5// 00000001BE74: CA4608FF 03040B0A 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001BE80: BF870001
	.long 0xd5080004                                           // 00000001BE84: D5080004
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000001BE88: 42020704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001BE8C: 8C7E017E
	v_mov_b32_e32 v3, 0                                        // 00000001BE90: 7E060280
	v_mov_b32_e32 v5, 0                                        // 00000001BE94: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 00000001BE98: BE81007E
	ds_store_b32 v2, v4 offset:640                             // 00000001BE9C: D8340280 00000402
	.long 0xd4c9007e                                           // 00000001BEA4: D4C9007E
	v_cndmask_b32_e32 v1, v156, v46, vcc_lo                    // 00000001BEA8: 02025D9C
	s_cbranch_execz 35                                         // 00000001BEAC: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x203c>
	v_sub_f32_e32 v4, v16, v12                                 // 00000001BEB0: 08081910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BEB4: BF870091
	v_mul_f32_e32 v5, 0x3fb8aa3b, v4                           // 00000001BEB8: 100A08FF 3FB8AA3B
	v_fma_f32 v6, 0x3fb8aa3b, v4, -v5                          // 00000001BEC0: D6130006 841608FF 3FB8AA3B
	v_rndne_f32_e32 v7, v5                                     // 00000001BECC: 7E0E4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001BED0: BF870221
	v_sub_f32_e32 v5, v5, v7                                   // 00000001BED4: 080A0F05
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 00000001BED8: 7C3608FF C2CE8ED0
	v_fmac_f32_e32 v6, 0x32a5705f, v4                          // 00000001BEE0: 560C08FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BEE8: BF870121
	v_add_f32_e32 v5, v5, v6                                   // 00000001BEEC: 060A0D05
	v_cvt_i32_f32_e32 v6, v7                                   // 00000001BEF0: 7E0C1107
	v_exp_f32_e32 v5, v5                                       // 00000001BEF4: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001BEF8: BF8700A5
	.long 0xd71c0005                                           // 00000001BEFC: D71C0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 00000001BF00: 02020D05
	s_waitcnt lgkmcnt(10)                                      // 00000001BF04: BF89FCA7
	v_dual_mul_f32 v6, v8, v14 :: v_dual_cndmask_b32 v5, 0, v5 // 00000001BF08: C8D21D08 06040A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001BF10: BF870131
	v_mul_f32_e32 v6, v13, v6                                  // 00000001BF14: 100C0D0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 00000001BF18: 7C3C08FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 00000001BF20: BF89FC77
	v_dual_cndmask_b32 v4, 0x7f800000, v5 :: v_dual_mul_f32 v5, v11, v6// 00000001BF24: CA460AFF 04040D0B 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001BF30: BF870001
	.long 0xd5080005                                           // 00000001BF34: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v4, vcc_lo             // 00000001BF38: 42020905
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001BF3C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001BF40: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000001BF44: BE81007E
	ds_store_b32 v2, v5 offset:768                             // 00000001BF48: D8340300 00000502
	.long 0xd4c9007e                                           // 00000001BF50: D4C9007E
	v_cndmask_b32_e32 v1, v156, v45, vcc_lo                    // 00000001BF54: 02025B9C
	s_cbranch_execz 35                                         // 00000001BF58: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x20e8>
	v_sub_f32_e32 v3, v17, v12                                 // 00000001BF5C: 08061911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BF60: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000001BF64: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 00000001BF6C: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 00000001BF78: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001BF7C: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000001BF80: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000001BF84: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 00000001BF8C: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BF94: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 00000001BF98: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 00000001BF9C: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000001BFA0: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001BFA4: BF8700A5
	.long 0xd71c0004                                           // 00000001BFA8: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000001BFAC: 02020B04
	s_waitcnt lgkmcnt(11)                                      // 00000001BFB0: BF89FCB7
	v_dual_mul_f32 v5, v9, v15 :: v_dual_cndmask_b32 v4, 0, v4 // 00000001BFB4: C8D21F09 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001BFBC: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000001BFC0: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000001BFC4: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 00000001BFCC: BF89FC77
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v53, v5// 00000001BFD0: CA4608FF 03040B35 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001BFDC: BF870001
	.long 0xd5080003                                           // 00000001BFE0: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000001BFE4: 42020704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001BFE8: 8C7E017E
	ds_store_b32 v2, v3 offset:896                             // 00000001BFEC: D8340380 00000302
	s_waitcnt lgkmcnt(0)                                       // 00000001BFF4: BF89FC07
	s_barrier                                                  // 00000001BFF8: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s15                             // 00000001BFFC: 8B6A0F7E
	s_mov_b32 s1, -1                                           // 00000001C000: BE8100C1
	s_cbranch_vccz 176                                         // 00000001C004: BFA300B0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x23c8>
	s_mov_b32 s1, exec_lo                                      // 00000001C008: BE81007E
	v_cmpx_gt_i32_e32 0x120, v44                               // 00000001C00C: 7D8858FF 00000120
	s_cbranch_execz 170                                        // 00000001C014: BFA500AA <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x23c0>
	v_add_nc_u32_e32 v2, 0xffffff00, v44                       // 00000001C018: 4A0458FF FFFFFF00
	s_mov_b32 s2, 0                                            // 00000001C020: BE820080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001C024: BF870001
	v_mov_b32_e32 v3, v2                                       // 00000001C028: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001C02C: BF8700A1
	v_add_nc_u32_e32 v3, 0xe0, v3                              // 00000001C030: 4A0606FF 000000E0
	s_waitcnt lgkmcnt(4)                                       // 00000001C038: BF89FC47
	v_ashrrev_i32_e32 v16, 7, v3                               // 00000001C03C: 34200687
	v_and_b32_e32 v12, 0x7f, v3                                // 00000001C040: 361806FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C048: BF870092
	.long 0xd72c0004                                           // 00000001C04C: D72C0004
	v_cndmask_b32_e32 v1, 0x880, v16, vcc_lo                   // 00000001C050: 020220FF 00000880
	v_lshl_add_u32 v4, v12, 1, v4                              // 00000001C058: D6460004 0411030C
	ds_load_u16 v20, v4 offset:7776                            // 00000001C060: D8F01E60 14000004
	ds_load_u16 v21, v4 offset:7232                            // 00000001C068: D8F01C40 15000004
	s_waitcnt lgkmcnt(4)                                       // 00000001C070: BF89FC47
	ds_load_u16 v22, v4 offset:6688                            // 00000001C074: D8F01A20 16000004
	ds_load_u16 v23, v4 offset:6144                            // 00000001C07C: D8F01800 17000004
	ds_load_u16 v24, v4 offset:6416                            // 00000001C084: D8F01910 18000004
	s_waitcnt lgkmcnt(3)                                       // 00000001C08C: BF89FC37
	v_lshlrev_b32_e32 v21, 16, v21                             // 00000001C090: 302A2A90
	s_waitcnt lgkmcnt(1)                                       // 00000001C094: BF89FC17
	v_lshlrev_b32_e32 v23, 16, v23                             // 00000001C098: 302E2E90
	v_lshlrev_b32_e32 v17, 5, v16                              // 00000001C09C: 30222085
	ds_load_u16 v25, v4 offset:6960                            // 00000001C0A0: D8F01B30 19000004
	ds_load_u16 v26, v4 offset:7504                            // 00000001C0A8: D8F01D50 1A000004
	ds_load_u16 v27, v4 offset:8048                            // 00000001C0B0: D8F01F70 1B000004
	ds_load_b128 v[4:7], v17 offset:24384                      // 00000001C0B8: DBFC5F40 04000011
	ds_load_b128 v[8:11], v17 offset:24400                     // 00000001C0C0: DBFC5F50 08000011
	v_lshlrev_b32_e32 v20, 16, v20                             // 00000001C0C8: 30282890
	s_waitcnt lgkmcnt(0)                                       // 00000001C0CC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C0D0: BF870091
	v_dual_mul_f32 v10, v10, v20 :: v_dual_lshlrev_b32 v25, 16, v25// 00000001C0D4: C8E2290A 0A183290
	v_dual_mul_f32 v7, v7, v25 :: v_dual_lshlrev_b32 v24, 16, v24// 00000001C0DC: C8E23307 07183090
	v_mul_f32_e32 v8, v8, v21                                  // 00000001C0E4: 10102B08
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001C0E8: BF870002
	v_dual_mul_f32 v4, v4, v23 :: v_dual_mul_f32 v5, v5, v24   // 00000001C0EC: C8C62F04 04043105
	v_mul_u32_u24_e32 v18, 48, v12                             // 00000001C0F4: 162418B0
	ds_load_b128 v[12:15], v17 offset:24192                    // 00000001C0F8: DBFC5E80 0C000011
	v_lshlrev_b32_e32 v26, 16, v26                             // 00000001C100: 30343490
	v_lshlrev_b32_e32 v27, 16, v27                             // 00000001C104: 30363690
	v_lshl_add_u32 v28, v16, 4, v18                            // 00000001C108: D646001C 04490910
	ds_load_b128 v[16:19], v17 offset:24208                    // 00000001C110: DBFC5E90 10000011
	s_waitcnt lgkmcnt(1)                                       // 00000001C118: BF89FC17
	v_mul_f32_e32 v12, v12, v4                                 // 00000001C11C: 1018090C
	v_mul_f32_e32 v4, v13, v5                                  // 00000001C120: 10080B0D
	v_dual_mul_f32 v11, v11, v27 :: v_dual_lshlrev_b32 v22, 16, v22// 00000001C124: C8E2370B 0B162C90
	v_mul_f32_e32 v5, v15, v7                                  // 00000001C12C: 100A0F0F
	v_mul_f32_e32 v9, v9, v26                                  // 00000001C130: 10123509
	s_waitcnt lgkmcnt(0)                                       // 00000001C134: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000001C138: BF870243
	v_dual_mul_f32 v7, v16, v8 :: v_dual_mul_f32 v6, v6, v22   // 00000001C13C: C8C61110 07062D06
	v_cmp_lt_i32_e32 vcc_lo, 31, v3                            // 00000001C144: 7C82069F
	v_fma_mixhi_f16 v4, v4, s41, 0                             // 00000001C148: CC220004 02005304
	v_dual_mul_f32 v8, v17, v9 :: v_dual_mul_f32 v9, v18, v10  // 00000001C150: C8C61311 08081512
	v_mul_f32_e32 v6, v14, v6                                  // 00000001C158: 100C0D0E
	v_mul_f32_e32 v10, v19, v11                                // 00000001C15C: 10141713
	v_fma_mixlo_f16 v4, v12, s41, 0                            // 00000001C160: CC210004 0200530C
	v_fma_mixhi_f16 v5, v5, s41, 0                             // 00000001C168: CC220005 02005305
	s_or_b32 s2, vcc_lo, s2                                    // 00000001C170: 8C02026A
	v_fma_mixlo_f16 v5, v6, s41, 0                             // 00000001C174: CC210005 02005306
	v_fma_mixhi_f16 v6, v8, s41, 0                             // 00000001C17C: CC220006 02005308
	v_fma_mixlo_f16 v6, v7, s41, 0                             // 00000001C184: CC210006 02005307
	v_fma_mixhi_f16 v7, v10, s41, 0                            // 00000001C18C: CC220007 0200530A
	v_fma_mixlo_f16 v7, v9, s41, 0                             // 00000001C194: CC210007 02005309
	ds_store_b128 v28, v[4:7]                                  // 00000001C19C: DB7C0000 0000041C
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 00000001C1A4: 917E027E
	s_cbranch_execnz 65440                                     // 00000001C1A8: BFA6FFA0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x212c>
	s_or_b32 exec_lo, exec_lo, s2                              // 00000001C1AC: 8C7E027E
	v_lshl_add_u32 v3, v44, 3, 0xffffff00                      // 00000001C1B0: D6460003 03FD072C FFFFFF00
	s_mov_b32 s2, 0                                            // 00000001C1BC: BE820080
	v_add_nc_u32_e32 v2, 0xe0, v2                              // 00000001C1C0: 4A0404FF 000000E0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001C1C8: BF8701A2
	v_and_b32_e32 v4, 0x78, v3                                 // 00000001C1CC: 360806FF 00000078
	v_add_nc_u32_e32 v3, 0x700, v3                             // 00000001C1D4: 4A0606FF 00000700
	v_ashrrev_i32_e32 v5, 4, v2                                // 00000001C1DC: 340A0484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001C1E0: BF870121
	.long 0xd72c0006                                           // 00000001C1E4: D72C0006
	v_cndmask_b32_e32 v1, 0x110, v5, vcc_lo                    // 00000001C1E8: 02020AFF 00000110
	v_lshlrev_b32_e32 v8, 2, v5                                // 00000001C1F0: 30100A82
	v_lshl_add_u32 v9, v4, 1, v6                               // 00000001C1F4: D6460009 04190304
	ds_load_b128 v[4:7], v9 offset:10496                       // 00000001C1FC: DBFC2900 04000009
	ds_load_b32 v8, v8 offset:24448                            // 00000001C204: D8D85F80 08000008
	s_waitcnt lgkmcnt(1)                                       // 00000001C20C: BF89FC17
	v_and_b32_e32 v12, 0xffff0000, v6                          // 00000001C210: 36180CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000001C218: 300C0C90
	v_and_b32_e32 v13, 0xffff0000, v7                          // 00000001C21C: 361A0EFF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v4                          // 00000001C224: 361408FF FFFF0000
	v_lshlrev_b32_e32 v4, 16, v4                               // 00000001C22C: 30080890
	v_and_b32_e32 v11, 0xffff0000, v5                          // 00000001C230: 36160AFF FFFF0000
	v_lshlrev_b32_e32 v5, 16, v5                               // 00000001C238: 300A0A90
	s_waitcnt lgkmcnt(0)                                       // 00000001C23C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001C240: BF8701A3
	v_dual_mul_f32 v14, v8, v4 :: v_dual_lshlrev_b32 v7, 16, v7// 00000001C244: C8E20908 0E060E90
	v_mul_f32_e32 v4, v8, v10                                  // 00000001C24C: 10081508
	v_mul_f32_e32 v10, v8, v5                                  // 00000001C250: 10140B08
	v_mul_f32_e32 v5, v8, v11                                  // 00000001C254: 100A1708
	v_mul_f32_e32 v11, v8, v6                                  // 00000001C258: 10160D08
	v_mul_f32_e32 v6, v8, v12                                  // 00000001C25C: 100C1908
	v_mul_f32_e32 v12, v8, v7                                  // 00000001C260: 10180F08
	v_mul_f32_e32 v7, v8, v13                                  // 00000001C264: 100E1B08
	v_cmp_lt_i32_e32 vcc_lo, 31, v2                            // 00000001C268: 7C82049F
	v_fma_mixhi_f16 v4, v4, s41, 0                             // 00000001C26C: CC220004 02005304
	v_fma_mixlo_f16 v4, v14, s41, 0                            // 00000001C274: CC210004 0200530E
	v_fma_mixhi_f16 v5, v5, s41, 0                             // 00000001C27C: CC220005 02005305
	v_fma_mixlo_f16 v5, v10, s41, 0                            // 00000001C284: CC210005 0200530A
	v_fma_mixhi_f16 v6, v6, s41, 0                             // 00000001C28C: CC220006 02005306
	v_fma_mixlo_f16 v6, v11, s41, 0                            // 00000001C294: CC210006 0200530B
	v_fma_mixhi_f16 v7, v7, s41, 0                             // 00000001C29C: CC220007 02005307
	v_fma_mixlo_f16 v7, v12, s41, 0                            // 00000001C2A4: CC210007 0200530C
	s_or_b32 s2, vcc_lo, s2                                    // 00000001C2AC: 8C02026A
	ds_store_b128 v9, v[4:7] offset:10496                      // 00000001C2B0: DB7C2900 00000409
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 00000001C2B8: 917E027E
	s_cbranch_execnz 65472                                     // 00000001C2BC: BFA6FFC0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x22c0>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001C2C0: 8C7E017E
	s_mov_b32 s1, 0                                            // 00000001C2C4: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001C2C8: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000001C2CC: 916A017E
	s_cbranch_vccnz 533                                        // 00000001C2D0: BFA40215 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c28>
	s_mov_b32 s1, exec_lo                                      // 00000001C2D4: BE81007E
	v_cmpx_gt_u32_e32 16, v43                                  // 00000001C2D8: 7D985690
	s_cbranch_execz 529                                        // 00000001C2DC: BFA50211 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c24>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000001C2E0: 7C945680
	ds_load_b128 v[49:52], v1 offset:23248                     // 00000001C2E4: DBFC5AD0 31000001
	s_waitcnt lgkmcnt(9)                                       // 00000001C2EC: BF89FC97
	ds_load_b128 v[53:56], v1 offset:23264                     // 00000001C2F0: DBFC5AE0 35000001
	s_waitcnt lgkmcnt(2)                                       // 00000001C2F8: BF89FC27
	ds_load_b96 v[14:16], v1 offset:23280                      // 00000001C2FC: DBF85AF0 0E000001
	ds_load_b128 v[10:13], v1 offset:23168                     // 00000001C304: DBFC5A80 0A000001
	ds_load_b128 v[6:9], v1 offset:23184                       // 00000001C30C: DBFC5A90 06000001
	ds_load_b128 v[2:5], v1 offset:23200                       // 00000001C314: DBFC5AA0 02000001
	ds_load_b64 v[17:18], v1 offset:23216                      // 00000001C31C: D9D85AB0 11000001
	v_cndmask_b32_e64 v44, 0, 1.0, vcc_lo                      // 00000001C324: D501002C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 00000001C32C: 7C945681
	ds_load_b128 v[45:48], v1 offset:23232                     // 00000001C330: DBFC5AC0 2D000001
	v_cndmask_b32_e64 v33, 0, 1.0, vcc_lo                      // 00000001C338: D5010021 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 00000001C340: 7C945682
	v_cndmask_b32_e64 v32, 0, 1.0, vcc_lo                      // 00000001C344: D5010020 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 00000001C34C: 7C945683
	v_cndmask_b32_e64 v31, 0, 1.0, vcc_lo                      // 00000001C350: D501001F 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 00000001C358: 7C945684
	v_cndmask_b32_e64 v29, 0, 1.0, vcc_lo                      // 00000001C35C: D501001D 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 00000001C364: 7C945685
	v_cndmask_b32_e64 v30, 0, 1.0, vcc_lo                      // 00000001C368: D501001E 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 00000001C370: 7C945686
	v_cndmask_b32_e64 v28, 0, 1.0, vcc_lo                      // 00000001C374: D501001C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 00000001C37C: 7C945687
	v_cndmask_b32_e64 v27, 0, 1.0, vcc_lo                      // 00000001C380: D501001B 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 00000001C388: 7C945688
	v_cndmask_b32_e64 v25, 0, 1.0, vcc_lo                      // 00000001C38C: D5010019 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 00000001C394: 7C945689
	v_cndmask_b32_e64 v23, 0, 1.0, vcc_lo                      // 00000001C398: D5010017 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000001C3A0: 7C94568A
	v_cndmask_b32_e64 v26, 0, 1.0, vcc_lo                      // 00000001C3A4: D501001A 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 00000001C3AC: 7C94568B
	v_cndmask_b32_e64 v24, 0, 1.0, vcc_lo                      // 00000001C3B0: D5010018 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 00000001C3B8: 7C94568C
	v_cndmask_b32_e64 v20, 0, 1.0, vcc_lo                      // 00000001C3BC: D5010014 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 00000001C3C4: 7C94568D
	v_cndmask_b32_e64 v22, 0, 1.0, vcc_lo                      // 00000001C3C8: D5010016 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 00000001C3D0: 7C94568E
	v_cndmask_b32_e64 v21, 0, 1.0, vcc_lo                      // 00000001C3D4: D5010015 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 00000001C3DC: 7C94568F
	v_cndmask_b32_e64 v19, 0, 1.0, vcc_lo                      // 00000001C3E0: D5010013 01A9E480
	s_waitcnt lgkmcnt(5)                                       // 00000001C3E8: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000001C3EC: BF8700B1
	v_fmac_f32_e32 v21, v19, v16                               // 00000001C3F0: 562A2113
	v_fmac_f32_e32 v24, v19, v56                               // 00000001C3F4: 56307113
	s_waitcnt lgkmcnt(2)                                       // 00000001C3F8: BF89FC27
	v_dual_fmac_f32 v27, v19, v52 :: v_dual_fmac_f32 v24, v21, v5// 00000001C3FC: C8006913 1B180B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C404: BF870091
	v_dual_fmac_f32 v30, v19, v50 :: v_dual_fmac_f32 v27, v21, v9// 00000001C408: C8006513 1E1A1315
	v_dual_fmac_f32 v29, v19, v49 :: v_dual_fmac_f32 v30, v21, v7// 00000001C410: C8006313 1D1E0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C418: BF870091
	v_dual_fmac_f32 v28, v19, v51 :: v_dual_fmac_f32 v29, v21, v6// 00000001C41C: C8006713 1C1C0D15
	v_dual_fmac_f32 v25, v19, v53 :: v_dual_fmac_f32 v28, v21, v8// 00000001C424: C8006B13 191C1115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C42C: BF870091
	v_dual_fmac_f32 v26, v19, v55 :: v_dual_fmac_f32 v25, v21, v2// 00000001C430: C8006F13 1A180515
	v_dual_fmac_f32 v23, v19, v54 :: v_dual_fmac_f32 v26, v21, v4// 00000001C438: C8006D13 171A0915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000001C440: BF870151
	v_fmac_f32_e32 v23, v21, v3                                // 00000001C444: 562E0715
	ds_load_b128 v[2:5], v1 offset:23040                       // 00000001C448: DBFC5A00 02000001
	s_waitcnt lgkmcnt(1)                                       // 00000001C450: BF89FC17
	v_fmac_f32_e32 v31, v19, v48                               // 00000001C454: 563E6113
	v_fmac_f32_e32 v22, v19, v15                               // 00000001C458: 562C1F13
	v_dual_fmac_f32 v32, v19, v47 :: v_dual_fmac_f32 v31, v21, v13// 00000001C45C: C8005F13 201E1B15
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001C464: BF870002
	v_fmac_f32_e32 v22, v21, v18                               // 00000001C468: 562C2515
	v_fmac_f32_e32 v20, v19, v14                               // 00000001C46C: 56281D13
	ds_load_b128 v[49:52], v1 offset:23104                     // 00000001C470: DBFC5A40 31000001
	ds_load_b128 v[53:56], v1 offset:23120                     // 00000001C478: DBFC5A50 35000001
	ds_load_b128 v[57:60], v1 offset:23136                     // 00000001C480: DBFC5A60 39000001
	ds_load_b32 v14, v1 offset:23152                           // 00000001C488: D8D85A70 0E000001
	v_dual_fmac_f32 v33, v19, v46 :: v_dual_fmac_f32 v32, v21, v12// 00000001C490: C8005D13 21201915
	v_fmac_f32_e32 v44, v19, v45                               // 00000001C498: 56585B13
	ds_load_b128 v[45:48], v1 offset:24064                     // 00000001C49C: DBFC5E00 2D000001
	ds_load_b32 v18, v1 offset:22880                           // 00000001C4A4: D8D85960 12000001
	v_fmac_f32_e32 v33, v21, v11                               // 00000001C4AC: 56421715
	v_fmac_f32_e32 v44, v21, v10                               // 00000001C4B0: 56581515
	ds_load_b128 v[6:9], v1 offset:23056                       // 00000001C4B4: DBFC5A10 06000001
	ds_load_b128 v[10:13], v1 offset:23072                     // 00000001C4BC: DBFC5A20 0A000001
	s_waitcnt lgkmcnt(7)                                       // 00000001C4C4: BF89FC77
	v_fmac_f32_e32 v44, v22, v49                               // 00000001C4C8: 56586316
	v_dual_fmac_f32 v31, v22, v52 :: v_dual_fmac_f32 v20, v21, v17// 00000001C4CC: C8006916 1F142315
	v_fmac_f32_e32 v33, v22, v50                               // 00000001C4D4: 56426516
	s_waitcnt lgkmcnt(4)                                       // 00000001C4D8: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001C4DC: BF870002
	v_fmac_f32_e32 v20, v22, v14                               // 00000001C4E0: 56281D16
	ds_load_b128 v[14:17], v1 offset:22976                     // 00000001C4E4: DBFC59C0 0E000001
	v_fmac_f32_e32 v44, v20, v2                                // 00000001C4EC: 56580514
	v_fmac_f32_e32 v33, v20, v3                                // 00000001C4F0: 56420714
	v_fmac_f32_e32 v29, v22, v53                               // 00000001C4F4: 563A6B16
	v_fmac_f32_e32 v32, v22, v51                               // 00000001C4F8: 56406716
	v_dual_fmac_f32 v24, v22, v60 :: v_dual_fmac_f32 v31, v20, v5// 00000001C4FC: C8007916 181E0B14
	s_waitcnt lgkmcnt(2)                                       // 00000001C504: BF89FC27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001C508: BF870193
	v_fmac_f32_e32 v29, v20, v6                                // 00000001C50C: 563A0D14
	v_dual_fmac_f32 v25, v22, v57 :: v_dual_fmac_f32 v32, v20, v4// 00000001C510: C8007316 19200914
	ds_load_b128 v[2:5], v1 offset:22912                       // 00000001C518: DBFC5980 02000001
	s_waitcnt lgkmcnt(2)                                       // 00000001C520: BF89FC27
	v_fmac_f32_e32 v24, v20, v13                               // 00000001C524: 56301B14
	s_waitcnt lgkmcnt(1)                                       // 00000001C528: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001C52C: BF870001
	v_dual_fmac_f32 v26, v22, v59 :: v_dual_fmac_f32 v31, v24, v17// 00000001C530: C8007716 1A1E2318
	v_fmac_f32_e32 v33, v24, v15                               // 00000001C538: 56421F18
	v_dual_fmac_f32 v28, v22, v55 :: v_dual_fmac_f32 v25, v20, v10// 00000001C53C: C8006F16 1C181514
	v_fmac_f32_e32 v27, v22, v56                               // 00000001C544: 56367116
	v_fmac_f32_e32 v30, v22, v54                               // 00000001C548: 563C6D16
	ds_load_b128 v[49:52], v1 offset:22992                     // 00000001C54C: DBFC59D0 31000001
	ds_load_b96 v[53:55], v1 offset:23008                      // 00000001C554: DBF859E0 35000001
	v_dual_fmac_f32 v23, v22, v58 :: v_dual_fmac_f32 v28, v20, v8// 00000001C55C: C8007516 171C1114
	v_fmac_f32_e32 v27, v20, v9                                // 00000001C564: 56361314
	v_fmac_f32_e32 v30, v20, v7                                // 00000001C568: 563C0F14
	ds_load_b128 v[6:9], v1 offset:22928                       // 00000001C56C: DBFC5990 06000001
	ds_load_b64 v[56:57], v1 offset:22944                      // 00000001C574: D9D859A0 38000001
	v_fmac_f32_e32 v23, v20, v11                               // 00000001C57C: 562E1714
	v_fmac_f32_e32 v26, v20, v12                               // 00000001C580: 56341914
	ds_load_b128 v[10:13], v1 offset:22848                     // 00000001C584: DBFC5940 0A000001
	s_waitcnt lgkmcnt(3)                                       // 00000001C58C: BF89FC37
	v_fmac_f32_e32 v26, v24, v55                               // 00000001C590: 56346F18
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001C594: BF870001
	v_fmac_f32_e32 v33, v26, v3                                // 00000001C598: 5642071A
	v_fmac_f32_e32 v23, v24, v54                               // 00000001C59C: 562E6D18
	v_dual_fmac_f32 v44, v24, v14 :: v_dual_fmac_f32 v31, v26, v5// 00000001C5A0: C8001D18 2C1E0B1A
	v_fmac_f32_e32 v30, v24, v50                               // 00000001C5A8: 563C6518
	v_fmac_f32_e32 v29, v24, v49                               // 00000001C5AC: 563A6318
	s_waitcnt lgkmcnt(1)                                       // 00000001C5B0: BF89FC17
	v_fmac_f32_e32 v23, v26, v57                               // 00000001C5B4: 562E731A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000001C5B8: BF870003
	v_dual_fmac_f32 v27, v24, v52 :: v_dual_fmac_f32 v30, v26, v7// 00000001C5BC: C8006918 1B1E0F1A
	v_fmac_f32_e32 v28, v24, v51                               // 00000001C5C4: 56386718
	ds_load_b128 v[49:52], v1 offset:22800                     // 00000001C5C8: DBFC5910 31000001
	s_waitcnt lgkmcnt(1)                                       // 00000001C5D0: BF89FC17
	v_dual_fmac_f32 v31, v23, v13 :: v_dual_fmac_f32 v44, v26, v2// 00000001C5D4: C8001B17 1F2C051A
	v_dual_fmac_f32 v32, v24, v16 :: v_dual_fmac_f32 v29, v26, v6// 00000001C5DC: C8002118 201C0D1A
	ds_load_b128 v[14:17], v1 offset:22864                     // 00000001C5E4: DBFC5950 0E000001
	v_fmac_f32_e32 v25, v24, v53                               // 00000001C5EC: 56326B18
	ds_load_b96 v[53:55], v1 offset:22736                      // 00000001C5F0: DBF858D0 35000001
	v_fmac_f32_e32 v32, v26, v4                                // 00000001C5F8: 5640091A
	ds_load_b128 v[2:5], v1 offset:22784                       // 00000001C5FC: DBFC5900 02000001
	v_fmac_f32_e32 v27, v26, v9                                // 00000001C604: 5636131A
	v_fmac_f32_e32 v28, v26, v8                                // 00000001C608: 5638111A
	v_dual_fmac_f32 v25, v26, v56 :: v_dual_fmac_f32 v44, v23, v10// 00000001C60C: C800711A 192C1517
	ds_load_b128 v[6:9], v1 offset:22720                       // 00000001C614: DBFC58C0 06000001
	ds_load_b64 v[56:57], v1 offset:22672                      // 00000001C61C: D9D85890 38000001
	v_fmac_f32_e32 v33, v23, v11                               // 00000001C624: 56421717
	v_fmac_f32_e32 v25, v23, v18                               // 00000001C628: 56322517
	s_waitcnt lgkmcnt(4)                                       // 00000001C62C: BF89FC47
	v_fmac_f32_e32 v30, v23, v15                               // 00000001C630: 563C1F17
	v_fmac_f32_e32 v28, v23, v16                               // 00000001C634: 56382117
	v_fmac_f32_e32 v27, v23, v17                               // 00000001C638: 56362317
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001C63C: BF870191
	v_fmac_f32_e32 v27, v25, v52                               // 00000001C640: 56366919
	v_fmac_f32_e32 v28, v25, v51                               // 00000001C644: 56386719
	v_fmac_f32_e32 v30, v25, v50                               // 00000001C648: 563C6519
	s_waitcnt lgkmcnt(3)                                       // 00000001C64C: BF89FC37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001C650: BF870112
	v_fmac_f32_e32 v28, v27, v55                               // 00000001C654: 56386F1B
	v_fmac_f32_e32 v30, v27, v54                               // 00000001C658: 563C6D1B
	s_waitcnt lgkmcnt(0)                                       // 00000001C65C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001C660: BF870001
	v_fmac_f32_e32 v30, v28, v57                               // 00000001C664: 563C731C
	v_dual_fmac_f32 v32, v23, v12 :: v_dual_fmac_f32 v33, v25, v3// 00000001C668: C8001917 20200719
	ds_load_b128 v[10:13], v1 offset:22656                     // 00000001C670: DBFC5880 0A000001
	v_fmac_f32_e32 v29, v23, v14                               // 00000001C678: 563A1D17
	v_fmac_f32_e32 v44, v25, v2                                // 00000001C67C: 56580519
	v_fmac_f32_e32 v32, v25, v4                                // 00000001C680: 56400919
	v_fmac_f32_e32 v31, v25, v5                                // 00000001C684: 563E0B19
	ds_load_b128 v[2:5], v1 offset:22592                       // 00000001C688: DBFC5840 02000001
	ds_load_b32 v18, v1 offset:22608                           // 00000001C690: D8D85850 12000001
	v_fmac_f32_e32 v29, v25, v49                               // 00000001C698: 563A6319
	ds_load_b128 v[14:17], v1 offset:22528                     // 00000001C69C: DBFC5800 0E000001
	v_fmac_f32_e32 v44, v27, v6                                // 00000001C6A4: 56580D1B
	ds_load_b128 v[49:52], v1 offset:24288                     // 00000001C6A8: DBFC5EE0 31000001
	s_waitcnt lgkmcnt(4)                                       // 00000001C6B0: BF89FC47
	v_dual_fmac_f32 v44, v28, v10 :: v_dual_fmac_f32 v29, v27, v53// 00000001C6B4: C800151C 2C1C6B1B
	v_fmac_f32_e32 v33, v27, v7                                // 00000001C6BC: 56420F1B
	v_fmac_f32_e32 v31, v27, v9                                // 00000001C6C0: 563E131B
	ds_load_b64 v[9:10], v1 offset:22400                       // 00000001C6C4: D9D85780 09000001
	v_fmac_f32_e32 v29, v28, v56                               // 00000001C6CC: 563A711C
	ds_load_b128 v[53:56], v1 offset:24304                     // 00000001C6D0: DBFC5EF0 35000001
	s_waitcnt lgkmcnt(2)                                       // 00000001C6D8: BF89FC27
	v_fma_mixlo_f16 v60, v50, v23, 0                           // 00000001C6DC: CC21003C 02022F32
	v_dual_fmac_f32 v29, v30, v18 :: v_dual_fmac_f32 v32, v27, v8// 00000001C6E4: C800251E 1D20111B
	v_fmac_f32_e32 v31, v28, v13                               // 00000001C6EC: 563E1B1C
	ds_load_b96 v[6:8], v1 offset:22464                        // 00000001C6F0: DBF857C0 06000001
	v_fmac_f32_e32 v33, v28, v11                               // 00000001C6F8: 5642171C
	ds_load_b32 v11, v1 offset:22336                           // 00000001C6FC: D8D85740 0B000001
	v_dual_fmac_f32 v32, v28, v12 :: v_dual_fmac_f32 v33, v30, v3// 00000001C704: C800191C 2020071E
	v_fmac_f32_e32 v44, v30, v2                                // 00000001C70C: 5658051E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001C710: BF870002
	v_fmac_f32_e32 v32, v30, v4                                // 00000001C714: 5640091E
	v_fmac_f32_e32 v31, v30, v5                                // 00000001C718: 563E0B1E
	ds_load_b128 v[2:5], v1 offset:24256                       // 00000001C71C: DBFC5EC0 02000001
	v_fmac_f32_e32 v33, v29, v15                               // 00000001C724: 56421F1D
	v_fmac_f32_e32 v44, v29, v14                               // 00000001C728: 56581D1D
	v_fmac_f32_e32 v32, v29, v16                               // 00000001C72C: 5640211D
	v_fmac_f32_e32 v31, v29, v17                               // 00000001C730: 563E231D
	s_waitcnt lgkmcnt(2)                                       // 00000001C734: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001C738: BF8700A1
	v_fmac_f32_e32 v32, v31, v8                                // 00000001C73C: 5640111F
	v_fmac_f32_e32 v44, v31, v6                                // 00000001C740: 56580D1F
	v_dual_fmac_f32 v33, v31, v7 :: v_dual_fmac_f32 v44, v32, v9// 00000001C744: C8000F1F 212C1320
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001C74C: BF870131
	v_fmac_f32_e32 v33, v32, v10                               // 00000001C750: 56421520
	s_waitcnt lgkmcnt(0)                                       // 00000001C754: BF89FC07
	v_fma_mixlo_f16 v57, v5, v31, 0                            // 00000001C758: CC210039 02023F05
	v_fmac_f32_e32 v44, v33, v11                               // 00000001C760: 56581721
	ds_load_b128 v[6:9], v1 offset:24272                       // 00000001C764: DBFC5ED0 06000001
	ds_load_b128 v[10:13], v1 offset:24112                     // 00000001C76C: DBFC5E30 0A000001
	v_dual_mul_f32 v14, v2, v44 :: v_dual_mul_f32 v15, v3, v33 // 00000001C774: C8C65902 0E0E4303
	v_fma_mixlo_f16 v2, v2, v44, 0                             // 00000001C77C: CC210002 02025902
	v_fma_mixlo_f16 v18, v3, v33, 0                            // 00000001C784: CC210012 02024303
	v_mul_f32_e32 v63, v55, v21                                // 00000001C78C: 107E2B37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001C790: BF870193
	v_fma_mix_f32 v3, v2, -1.0, v14 op_sel_hi:[1,1,0]          // 00000001C794: CC200003 1C39E702
	v_fma_mix_f32 v15, v18, -1.0, v15 op_sel_hi:[1,1,0]        // 00000001C79C: CC20000F 1C3DE712
	.long 0x7f043912                                           // 00000001C7A4: 7F043912
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001C7A8: BF870193
	v_cvt_f16_f32_e32 v14, v3                                  // 00000001C7AC: 7E1C1503
	.long 0x7f1c150f                                           // 00000001C7B0: 7F1C150F
	v_mul_f32_e32 v15, v4, v32                                 // 00000001C7B4: 101E4104
	v_fma_mixlo_f16 v3, v4, v32, 0                             // 00000001C7B8: CC210003 02024104
	v_mul_f32_e32 v4, v5, v31                                  // 00000001C7C0: 10083F05
	s_waitcnt lgkmcnt(1)                                       // 00000001C7C4: BF89FC17
	v_mul_f32_e32 v16, v7, v30                                 // 00000001C7C8: 10203D07
	v_fma_mixlo_f16 v58, v7, v30, 0                            // 00000001C7CC: CC21003A 02023D07
	v_mul_f32_e32 v5, v6, v29                                  // 00000001C7D4: 100A3B06
	v_fma_mix_f32 v7, v3, -1.0, v15 op_sel_hi:[1,1,0]          // 00000001C7D8: CC200007 1C3DE703
	v_fma_mixlo_f16 v59, v9, v27, 0                            // 00000001C7E0: CC21003B 02023709
	.long 0x7f063939                                           // 00000001C7E8: 7F063939
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000001C7EC: BF8701D3
	v_cvt_f16_f32_e32 v15, v7                                  // 00000001C7F0: 7E1E1507
	v_mul_f32_e32 v7, v8, v28                                  // 00000001C7F4: 100E3908
	v_fma_mix_f32 v17, v57, -1.0, v4 op_sel_hi:[1,1,0]         // 00000001C7F8: CC200011 1C11E739
	v_fma_mixlo_f16 v4, v6, v29, 0                             // 00000001C800: CC210004 02023B06
	v_fma_mix_f32 v6, v58, -1.0, v16 op_sel_hi:[1,1,0]         // 00000001C808: CC200006 1C41E73A
	.long 0x7f1e1511                                           // 00000001C810: 7F1E1511
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001C814: BF870193
	v_fma_mix_f32 v5, v4, -1.0, v5 op_sel_hi:[1,1,0]           // 00000001C818: CC200005 1C15E704
	.long 0x7f201506                                           // 00000001C820: 7F201506
	v_fma_mixlo_f16 v6, v49, v25, 0                            // 00000001C824: CC210006 02023331
	.long 0x7f08393a                                           // 00000001C82C: 7F08393A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000001C830: BF870254
	v_cvt_f16_f32_e32 v16, v5                                  // 00000001C834: 7E201505
	v_fma_mixlo_f16 v5, v8, v28, 0                             // 00000001C838: CC210005 02023908
	v_mul_f32_e32 v8, v9, v27                                  // 00000001C840: 10103709
	v_mul_f32_e32 v9, v49, v25                                 // 00000001C844: 10123331
	v_dual_mul_f32 v49, v50, v23 :: v_dual_mul_f32 v50, v51, v26// 00000001C848: C8C62F32 31323533
	v_fma_mix_f32 v7, v5, -1.0, v7 op_sel_hi:[1,1,0]           // 00000001C850: CC200007 1C1DE705
	.long 0x7f0a393b                                           // 00000001C858: 7F0A393B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001C85C: BF870214
	v_fma_mix_f32 v9, v6, -1.0, v9 op_sel_hi:[1,1,0]           // 00000001C860: CC200009 1C25E706
	v_fma_mix_f32 v61, v60, -1.0, v49 op_sel_hi:[1,1,0]        // 00000001C868: CC20003D 1CC5E73C
	.long 0x7f0c393c                                           // 00000001C870: 7F0C393C
	v_cvt_f16_f32_e32 v17, v7                                  // 00000001C874: 7E221507
	v_fma_mixlo_f16 v7, v51, v26, 0                            // 00000001C878: CC210007 02023533
	v_cvt_f16_f32_e32 v49, v9                                  // 00000001C880: 7E621509
	v_mul_f32_e32 v9, v52, v24                                 // 00000001C884: 10123134
	v_fma_mix_f32 v8, v59, -1.0, v8 op_sel_hi:[1,1,0]          // 00000001C888: CC200008 1C21E73B
	.long 0x7f62153d                                           // 00000001C890: 7F62153D
	v_fma_mixlo_f16 v61, v52, v24, 0                           // 00000001C894: CC21003D 02023134
	v_dual_mul_f32 v51, v53, v20 :: v_dual_mul_f32 v52, v54, v22// 00000001C89C: C8C62935 33342D36
	s_delay_alu instid0(VALU_DEP_4)                            // 00000001C8A4: BF870004
	.long 0x7f221508                                           // 00000001C8A8: 7F221508
	v_fma_mix_f32 v8, v7, -1.0, v50 op_sel_hi:[1,1,0]          // 00000001C8AC: CC200008 1CC9E707
	v_fma_mixlo_f16 v54, v54, v22, 0                           // 00000001C8B4: CC210036 02022D36
	v_fma_mix_f32 v62, v61, -1.0, v9 op_sel_hi:[1,1,0]         // 00000001C8BC: CC20003E 1C25E73D
	v_fma_mixlo_f16 v9, v55, v21, 0                            // 00000001C8C4: CC210009 02022B37
	v_mul_f32_e32 v55, v56, v19                                // 00000001C8CC: 106E2738
	v_cvt_f16_f32_e32 v50, v8                                  // 00000001C8D0: 7E641508
	v_fma_mixlo_f16 v8, v53, v20, 0                            // 00000001C8D4: CC210008 02022935
	v_fma_mix_f32 v52, v54, -1.0, v52 op_sel_hi:[1,1,0]        // 00000001C8DC: CC200034 1CD1E736
	v_fma_mix_f32 v53, v9, -1.0, v63 op_sel_hi:[1,1,0]         // 00000001C8E4: CC200035 1CFDE709
	v_fma_mixlo_f16 v56, v56, v19, 0                           // 00000001C8EC: CC210038 02022738
	.long 0x7f64153e                                           // 00000001C8F4: 7F64153E
	v_fma_mix_f32 v51, v8, -1.0, v51 op_sel_hi:[1,1,0]         // 00000001C8F8: CC200033 1CCDE708
	.long 0x7f103936                                           // 00000001C900: 7F103936
	v_mul_u32_u24_e32 v63, 48, v43                             // 00000001C904: 167E56B0
	v_fma_mix_f32 v62, v56, -1.0, v55 op_sel_hi:[1,1,0]        // 00000001C908: CC20003E 1CDDE738
	.long 0x7f123938                                           // 00000001C910: 7F123938
	v_cvt_f16_f32_e32 v51, v51                                 // 00000001C914: 7E661533
	.long 0x7f661534                                           // 00000001C918: 7F661534
	v_cvt_f16_f32_e32 v52, v53                                 // 00000001C91C: 7E681535
	ds_load_b128 v[53:56], v1 offset:24080                     // 00000001C920: DBFC5E10 35000001
	.long 0x7f0e393d                                           // 00000001C928: 7F0E393D
	v_mul_f32_e32 v18, v45, v44                                // 00000001C92C: 1024592D
	v_fma_mixlo_f16 v43, v45, v44, 0                           // 00000001C930: CC21002B 0202592D
	v_mul_f32_e32 v44, v46, v33                                // 00000001C938: 1058432E
	v_fma_mixlo_f16 v33, v46, v33, 0                           // 00000001C93C: CC210021 0202432E
	ds_store_b128 v63, v[6:9] offset:19216                     // 00000001C944: DB7C4B10 0000063F
	ds_store_b128 v63, v[2:5] offset:19200                     // 00000001C94C: DB7C4B00 0000023F
	ds_load_b128 v[2:5], v1 offset:24096                       // 00000001C954: DBFC5E20 02000001
	v_fma_mix_f32 v18, v43, -1.0, v18 op_sel_hi:[1,1,0]        // 00000001C95C: CC200012 1C49E72B
	v_dual_mul_f32 v7, v47, v32 :: v_dual_mul_f32 v8, v48, v31 // 00000001C964: C8C6412F 07083F30
	v_fma_mix_f32 v44, v33, -1.0, v44 op_sel_hi:[1,1,0]        // 00000001C96C: CC20002C 1CB1E721
	.long 0x7f68153e                                           // 00000001C974: 7F68153E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000001C978: BF870254
	v_cvt_f16_f32_e32 v6, v18                                  // 00000001C97C: 7E0C1512
	v_fma_mixlo_f16 v18, v48, v31, 0                           // 00000001C980: CC210012 02023F30
	.long 0x7f563921                                           // 00000001C988: 7F563921
	.long 0x7f0c152c                                           // 00000001C98C: 7F0C152C
	v_fma_mixlo_f16 v44, v47, v32, 0                           // 00000001C990: CC21002C 0202412F
	v_fma_mix_f32 v8, v18, -1.0, v8 op_sel_hi:[1,1,0]          // 00000001C998: CC200008 1C21E712
	s_waitcnt lgkmcnt(3)                                       // 00000001C9A0: BF89FC37
	v_mul_f32_e32 v9, v53, v29                                 // 00000001C9A4: 10123B35
	v_mul_f32_e32 v31, v54, v30                                // 00000001C9A8: 103E3D36
	v_fma_mixlo_f16 v30, v54, v30, 0                           // 00000001C9AC: CC21001E 02023D36
	v_fma_mixlo_f16 v45, v53, v29, 0                           // 00000001C9B4: CC21002D 02023B35
	v_fma_mix_f32 v7, v44, -1.0, v7 op_sel_hi:[1,1,0]          // 00000001C9BC: CC200007 1C1DE72C
	v_fma_mixlo_f16 v46, v55, v28, 0                           // 00000001C9C4: CC21002E 02023937
	.long 0x7f583912                                           // 00000001C9CC: 7F583912
	v_fma_mix_f32 v29, v30, -1.0, v31 op_sel_hi:[1,1,0]        // 00000001C9D0: CC20001D 1C7DE71E
	v_dual_mul_f32 v31, v55, v28 :: v_dual_mul_f32 v28, v56, v27// 00000001C9D8: C8C63937 1F1C3738
	v_fma_mix_f32 v9, v45, -1.0, v9 op_sel_hi:[1,1,0]          // 00000001C9E0: CC200009 1C25E72D
	v_fma_mixlo_f16 v27, v56, v27, 0                           // 00000001C9E8: CC21001B 02023738
	v_cvt_f16_f32_e32 v7, v7                                   // 00000001C9F0: 7E0E1507
	.long 0x7f0e1508                                           // 00000001C9F4: 7F0E1508
	.long 0x7f10151d                                           // 00000001C9F8: 7F10151D
	v_cvt_f16_f32_e32 v8, v9                                   // 00000001C9FC: 7E101509
	v_fma_mix_f32 v9, v46, -1.0, v31 op_sel_hi:[1,1,0]         // 00000001CA00: CC200009 1C7DE72E
	s_waitcnt lgkmcnt(0)                                       // 00000001CA08: BF89FC07
	v_mul_f32_e32 v29, v2, v25                                 // 00000001CA0C: 103A3302
	v_fma_mixlo_f16 v2, v2, v25, 0                             // 00000001CA10: CC210002 02023302
	v_mul_f32_e32 v25, v3, v23                                 // 00000001CA18: 10322F03
	v_fma_mixlo_f16 v31, v3, v23, 0                            // 00000001CA1C: CC21001F 02022F03
	v_fma_mix_f32 v3, v27, -1.0, v28 op_sel_hi:[1,1,0]         // 00000001CA24: CC200003 1C71E71B
	v_cvt_f16_f32_e32 v9, v9                                   // 00000001CA2C: 7E121509
	v_mul_f32_e32 v23, v4, v26                                 // 00000001CA30: 102E3504
	.long 0x7f5a391e                                           // 00000001CA34: 7F5A391E
	v_fma_mix_f32 v25, v31, -1.0, v25 op_sel_hi:[1,1,0]        // 00000001CA38: CC200019 1C65E71F
	.long 0x7f121503                                           // 00000001CA40: 7F121503
	v_fma_mixlo_f16 v3, v4, v26, 0                             // 00000001CA44: CC210003 02023504
	v_mul_f32_e32 v26, v11, v22                                // 00000001CA4C: 10342D0B
	v_fma_mix_f32 v28, v2, -1.0, v29 op_sel_hi:[1,1,0]         // 00000001CA50: CC20001C 1C75E702
	v_fma_mixlo_f16 v11, v11, v22, 0                           // 00000001CA58: CC21000B 02022D0B
	.long 0x7f04391f                                           // 00000001CA60: 7F04391F
	v_fma_mix_f32 v4, v3, -1.0, v23 op_sel_hi:[1,1,0]          // 00000001CA64: CC200004 1C5DE703
	.long 0x7f2e1519                                           // 00000001CA6C: 7F2E1519
	v_cvt_f16_f32_e32 v23, v28                                 // 00000001CA70: 7E2E151C
	v_mul_f32_e32 v25, v5, v24                                 // 00000001CA74: 10323105
	v_fma_mixlo_f16 v28, v5, v24, 0                            // 00000001CA78: CC21001C 02023105
	v_cvt_f16_f32_e32 v24, v4                                  // 00000001CA80: 7E301504
	v_mul_f32_e32 v5, v10, v20                                 // 00000001CA84: 100A290A
	v_fma_mixlo_f16 v4, v10, v20, 0                            // 00000001CA88: CC210004 0202290A
	v_fma_mix_f32 v20, v11, -1.0, v26 op_sel_hi:[1,1,0]        // 00000001CA90: CC200014 1C69E70B
	v_fma_mix_f32 v22, v28, -1.0, v25 op_sel_hi:[1,1,0]        // 00000001CA98: CC200016 1C65E71C
	v_mul_f32_e32 v25, v12, v21                                // 00000001CAA0: 10322B0C
	.long 0x7f06391c                                           // 00000001CAA4: 7F06391C
	v_fma_mix_f32 v10, v4, -1.0, v5 op_sel_hi:[1,1,0]          // 00000001CAA8: CC20000A 1C15E704
	v_fma_mixlo_f16 v5, v12, v21, 0                            // 00000001CAB0: CC210005 02022B0C
	v_mul_f32_e32 v21, v13, v19                                // 00000001CAB8: 102A270D
	v_fma_mixlo_f16 v13, v13, v19, 0                           // 00000001CABC: CC21000D 0202270D
	.long 0x7f08390b                                           // 00000001CAC4: 7F08390B
	.long 0x7f5c391b                                           // 00000001CAC8: 7F5C391B
	v_fma_mix_f32 v12, v5, -1.0, v25 op_sel_hi:[1,1,0]         // 00000001CACC: CC20000C 1C65E705
	v_cvt_f16_f32_e32 v25, v10                                 // 00000001CAD4: 7E32150A
	v_fma_mix_f32 v10, v13, -1.0, v21 op_sel_hi:[1,1,0]        // 00000001CAD8: CC20000A 1C55E70D
	.long 0x7f0a390d                                           // 00000001CAE0: 7F0A390D
	.long 0x7f301516                                           // 00000001CAE4: 7F301516
	.long 0x7f321514                                           // 00000001CAE8: 7F321514
	v_cvt_f16_f32_e32 v26, v12                                 // 00000001CAEC: 7E34150C
	.long 0x7f34150a                                           // 00000001CAF0: 7F34150A
	ds_store_b128 v63, v[49:52] offset:19984                   // 00000001CAF4: DB7C4E10 0000313F
	ds_store_b128 v63, v[14:17] offset:19968                   // 00000001CAFC: DB7C4E00 00000E3F
	ds_store_b128 v63, v[2:5] offset:20752                     // 00000001CB04: DB7C5110 0000023F
	ds_store_b128 v63, v[43:46] offset:20736                   // 00000001CB0C: DB7C5100 00002B3F
	ds_store_b128 v63, v[23:26] offset:21520                   // 00000001CB14: DB7C5410 0000173F
	ds_store_b128 v63, v[6:9] offset:21504                     // 00000001CB1C: DB7C5400 0000063F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001CB24: 8C7E017E
	v_cmp_eq_u32_e32 vcc_lo, 0, v34                            // 00000001CB28: 7C944480
	v_mov_b32_e32 v4, 0                                        // 00000001CB2C: 7E080280
	s_waitcnt lgkmcnt(0)                                       // 00000001CB30: BF89FC07
	s_barrier                                                  // 00000001CB34: BFBD0000
	s_cmp_lt_i32 s46, s31                                      // 00000001CB38: BF041F2E
	v_mul_u32_u24_e32 v161, 48, v156                           // 00000001CB3C: 174338B0
	s_waitcnt lgkmcnt(9)                                       // 00000001CB40: BF89FC97
	v_dual_cndmask_b32 v10, 0x7060302, v145 :: v_dual_mov_b32 v11, 0// 00000001CB44: CA5122FF 0A0A0080 07060302
	s_waitcnt vmcnt(6)                                         // 00000001CB50: BF891BF7
	v_mov_b32_dpp v4, v41 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000001CB54: 7E0802FA FF00B129
	v_cmp_eq_u32_e32 vcc_lo, 0, v157                           // 00000001CB5C: 7C953A80
	s_cselect_b32 s1, -1, 0                                    // 00000001CB60: 980180C1
	s_or_b32 s2, s46, 1                                        // 00000001CB64: 8C02812E
	s_waitcnt vmcnt(3)                                         // 00000001CB68: BF890FF7
	v_mov_b32_dpp v11, v38 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000001CB6C: 7E1602FA FF00B126
	v_perm_b32 v4, v41, v4, v10                                // 00000001CB74: D6440004 042A0929
	v_mov_b32_e32 v2, 0                                        // 00000001CB7C: 7E040280
	s_cmp_lt_i32 s2, s31                                       // 00000001CB80: BF041F02
	v_lshlrev_b32_e32 v160, 1, v155                            // 00000001CB84: 31413681
	s_waitcnt lgkmcnt(2)                                       // 00000001CB88: BF89FC27
	v_perm_b32 v22, v38, v11, v10                              // 00000001CB8C: D6440016 042A1726
	v_mov_b32_e32 v11, 0                                       // 00000001CB94: 7E160280
	s_waitcnt lgkmcnt(1)                                       // 00000001CB98: BF89FC17
	v_and_b32_e32 v5, 0xffff0000, v4                           // 00000001CB9C: 360A08FF FFFF0000
	v_mov_b32_dpp v2, v42 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000001CBA4: 7E0402FA FF00B12A
	v_dual_mov_b32 v8, 0 :: v_dual_and_b32 v23, 0xffff0000, v22// 00000001CBAC: CA240080 08162CFF FFFF0000
	s_waitcnt vmcnt(2)                                         // 00000001CBB8: BF890BF7
	v_mov_b32_dpp v11, v37 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000001CBBC: 7E1602FA FF00B125
	s_cselect_b32 s2, -1, 0                                    // 00000001CBC4: 980280C1
	v_perm_b32 v2, v42, v2, v10                                // 00000001CBC8: D6440002 042A052A
	s_waitcnt lgkmcnt(0)                                       // 00000001CBD0: BF89FC07
	v_mov_b32_e32 v6, 0                                        // 00000001CBD4: 7E0C0280
	v_mov_b32_dpp v8, v39 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000001CBD8: 7E1002FA FF00B127
	v_perm_b32 v24, v37, v11, v10                              // 00000001CBE0: D6440018 042A1725
	v_mov_b32_e32 v11, 0                                       // 00000001CBE8: 7E160280
	v_and_b32_e32 v3, 0xffff0000, v2                           // 00000001CBEC: 360604FF FFFF0000
	v_mov_b32_dpp v6, v40 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000001CBF4: 7E0C02FA FF00B128
	v_perm_b32 v8, v39, v8, v10                                // 00000001CBFC: D6440008 042A1127
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000001CC04: 30040490
	s_waitcnt vmcnt(1)                                         // 00000001CC08: BF8907F7
	v_mov_b32_dpp v11, v36 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000001CC0C: 7E1602FA FF00B124
	s_or_b32 s47, s46, 2                                       // 00000001CC14: 8C2F822E
	v_perm_b32 v6, v40, v6, v10                                // 00000001CC18: D6440006 042A0D28
	s_cmp_lt_i32 s47, s31                                      // 00000001CC20: BF041F2F
	v_cvt_f16_f32_e32 v2, v2                                   // 00000001CC24: 7E041502
	v_perm_b32 v26, v36, v11, v10                              // 00000001CC28: D644001A 042A1724
	v_mov_b32_e32 v11, 0                                       // 00000001CC30: 7E160280
	s_cselect_b32 s47, -1, 0                                   // 00000001CC34: 982F80C1
	s_or_b32 s48, s46, 3                                       // 00000001CC38: 8C30832E
	v_and_b32_e32 v7, 0xffff0000, v6                           // 00000001CC3C: 360E0CFF FFFF0000
	s_cmp_lt_i32 s48, s31                                      // 00000001CC44: BF041F30
	s_waitcnt vmcnt(0)                                         // 00000001CC48: BF8903F7
	v_mov_b32_dpp v11, v35 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000001CC4C: 7E1602FA FF00B123
	s_cselect_b32 s48, -1, 0                                   // 00000001CC54: 983080C1
	s_or_b32 s49, s46, 4                                       // 00000001CC58: 8C31842E
	v_and_b32_e32 v9, 0xffff0000, v8                           // 00000001CC5C: 361210FF FFFF0000
	s_cmp_lt_i32 s49, s31                                      // 00000001CC64: BF041F31
	v_perm_b32 v28, v35, v11, v10                              // 00000001CC68: D644001C 042A1723
	ds_load_u16 v10, v160 offset:6416                          // 00000001CC70: D8F01910 0A0000A0
	ds_load_u16 v11, v160 offset:6144                          // 00000001CC78: D8F01800 0B0000A0
	s_cselect_b32 s49, -1, 0                                   // 00000001CC80: 983180C1
	s_or_b32 s50, s46, 5                                       // 00000001CC84: 8C32852E
	v_and_b32_e32 v25, 0xffff0000, v24                         // 00000001CC88: 363230FF FFFF0000
	s_cmp_lt_i32 s50, s31                                      // 00000001CC90: BF041F32
	v_and_b32_e32 v27, 0xffff0000, v26                         // 00000001CC94: 363634FF FFFF0000
	s_cselect_b32 s50, -1, 0                                   // 00000001CC9C: 983280C1
	s_or_b32 s51, s46, 6                                       // 00000001CCA0: 8C33862E
	v_and_b32_e32 v29, 0xffff0000, v28                         // 00000001CCA4: 363A38FF FFFF0000
	s_cmp_lt_i32 s51, s31                                      // 00000001CCAC: BF041F33
	s_cselect_b32 s51, -1, 0                                   // 00000001CCB0: 983380C1
	s_or_b32 s52, s46, 7                                       // 00000001CCB4: 8C34872E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001CCB8: BF870009
	s_cmp_lt_i32 s52, s31                                      // 00000001CCBC: BF041F34
	s_cselect_b32 s52, -1, 0                                   // 00000001CCC0: 983480C1
	s_or_b32 s53, s46, 8                                       // 00000001CCC4: 8C35882E
	s_waitcnt lgkmcnt(1)                                       // 00000001CCC8: BF89FC17
	v_lshlrev_b32_e32 v10, 16, v10                             // 00000001CCCC: 30141490
	s_waitcnt lgkmcnt(0)                                       // 00000001CCD0: BF89FC07
	v_lshlrev_b32_e32 v11, 16, v11                             // 00000001CCD4: 30161690
	s_cmp_lt_i32 s53, s31                                      // 00000001CCD8: BF041F35
	s_cselect_b32 s53, -1, 0                                   // 00000001CCDC: 983580C1
	.long 0x7f14150a                                           // 00000001CCE0: 7F14150A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000001CCE4: BF8704C2
	v_cvt_f16_f32_e32 v10, v11                                 // 00000001CCE8: 7E14150B
	ds_load_u16 v11, v160 offset:6960                          // 00000001CCEC: D8F01B30 0B0000A0
	ds_load_u16 v12, v160 offset:6688                          // 00000001CCF4: D8F01A20 0C0000A0
	s_or_b32 s54, s46, 9                                       // 00000001CCFC: 8C36892E
	s_cmp_lt_i32 s54, s31                                      // 00000001CD00: BF041F36
	s_cselect_b32 s54, -1, 0                                   // 00000001CD04: 983680C1
	s_or_b32 s55, s46, 10                                      // 00000001CD08: 8C378A2E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000001CD0C: BF8704B9
	s_cmp_lt_i32 s55, s31                                      // 00000001CD10: BF041F37
	s_cselect_b32 s55, -1, 0                                   // 00000001CD14: 983780C1
	s_or_b32 s56, s46, 11                                      // 00000001CD18: 8C388B2E
	s_cmp_lt_i32 s56, s31                                      // 00000001CD1C: BF041F38
	s_cselect_b32 s56, -1, 0                                   // 00000001CD20: 983880C1
	s_or_b32 s57, s46, 12                                      // 00000001CD24: 8C398C2E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001CD28: BF870009
	s_cmp_lt_i32 s57, s31                                      // 00000001CD2C: BF041F39
	s_waitcnt lgkmcnt(1)                                       // 00000001CD30: BF89FC17
	v_lshlrev_b32_e32 v11, 16, v11                             // 00000001CD34: 30161690
	s_waitcnt lgkmcnt(0)                                       // 00000001CD38: BF89FC07
	v_lshlrev_b32_e32 v12, 16, v12                             // 00000001CD3C: 30181890
	s_cselect_b32 s57, -1, 0                                   // 00000001CD40: 983980C1
	s_or_b32 s58, s46, 13                                      // 00000001CD44: 8C3A8D2E
	.long 0x7f16150b                                           // 00000001CD48: 7F16150B
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001CD4C: BF870002
	v_cvt_f16_f32_e32 v11, v12                                 // 00000001CD50: 7E16150C
	ds_load_u16 v12, v160 offset:7504                          // 00000001CD54: D8F01D50 0C0000A0
	ds_load_u16 v13, v160 offset:7232                          // 00000001CD5C: D8F01C40 0D0000A0
	s_cmp_lt_i32 s58, s31                                      // 00000001CD64: BF041F3A
	s_cselect_b32 s58, -1, 0                                   // 00000001CD68: 983A80C1
	s_or_b32 s59, s46, 14                                      // 00000001CD6C: 8C3B8E2E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000001CD70: BF8704B9
	s_cmp_lt_i32 s59, s31                                      // 00000001CD74: BF041F3B
	s_cselect_b32 s59, -1, 0                                   // 00000001CD78: 983B80C1
	s_or_b32 s60, s46, 15                                      // 00000001CD7C: 8C3C8F2E
	s_cmp_lt_i32 s60, s31                                      // 00000001CD80: BF041F3C
	s_cselect_b32 s60, -1, 0                                   // 00000001CD84: 983C80C1
	s_waitcnt lgkmcnt(1)                                       // 00000001CD88: BF89FC17
	v_lshlrev_b32_e32 v12, 16, v12                             // 00000001CD8C: 30181890
	s_waitcnt lgkmcnt(0)                                       // 00000001CD90: BF89FC07
	v_lshlrev_b32_e32 v13, 16, v13                             // 00000001CD94: 301A1A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001CD98: BF870112
	.long 0x7f18150c                                           // 00000001CD9C: 7F18150C
	v_cvt_f16_f32_e32 v12, v13                                 // 00000001CDA0: 7E18150D
	ds_load_u16 v13, v160 offset:8048                          // 00000001CDA4: D8F01F70 0D0000A0
	ds_load_u16 v14, v160 offset:7776                          // 00000001CDAC: D8F01E60 0E0000A0
	s_waitcnt lgkmcnt(1)                                       // 00000001CDB4: BF89FC17
	v_lshlrev_b32_e32 v13, 16, v13                             // 00000001CDB8: 301A1A90
	s_waitcnt lgkmcnt(0)                                       // 00000001CDBC: BF89FC07
	v_lshlrev_b32_e32 v14, 16, v14                             // 00000001CDC0: 301C1C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001CDC4: BF870112
	.long 0x7f1a150d                                           // 00000001CDC8: 7F1A150D
	v_cvt_f16_f32_e32 v13, v14                                 // 00000001CDCC: 7E1A150E
	ds_load_u16 v14, v160 offset:8592                          // 00000001CDD0: D8F02190 0E0000A0
	ds_load_u16 v15, v160 offset:8320                          // 00000001CDD8: D8F02080 0F0000A0
	s_waitcnt lgkmcnt(1)                                       // 00000001CDE0: BF89FC17
	v_lshlrev_b32_e32 v14, 16, v14                             // 00000001CDE4: 301C1C90
	s_waitcnt lgkmcnt(0)                                       // 00000001CDE8: BF89FC07
	v_lshlrev_b32_e32 v15, 16, v15                             // 00000001CDEC: 301E1E90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001CDF0: BF870112
	.long 0x7f1c150e                                           // 00000001CDF4: 7F1C150E
	v_cvt_f16_f32_e32 v14, v15                                 // 00000001CDF8: 7E1C150F
	ds_load_u16 v15, v160 offset:9136                          // 00000001CDFC: D8F023B0 0F0000A0
	ds_load_u16 v16, v160 offset:8864                          // 00000001CE04: D8F022A0 100000A0
	s_waitcnt lgkmcnt(1)                                       // 00000001CE0C: BF89FC17
	v_lshlrev_b32_e32 v15, 16, v15                             // 00000001CE10: 301E1E90
	s_waitcnt lgkmcnt(0)                                       // 00000001CE14: BF89FC07
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000001CE18: 30202090
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001CE1C: BF870112
	.long 0x7f1e150f                                           // 00000001CE20: 7F1E150F
	v_cvt_f16_f32_e32 v15, v16                                 // 00000001CE24: 7E1E1510
	ds_load_u16 v16, v160 offset:9680                          // 00000001CE28: D8F025D0 100000A0
	ds_load_u16 v17, v160 offset:9408                          // 00000001CE30: D8F024C0 110000A0
	s_waitcnt lgkmcnt(1)                                       // 00000001CE38: BF89FC17
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000001CE3C: 30202090
	s_waitcnt lgkmcnt(0)                                       // 00000001CE40: BF89FC07
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000001CE44: 30222290
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001CE48: BF870112
	.long 0x7f201510                                           // 00000001CE4C: 7F201510
	v_cvt_f16_f32_e32 v16, v17                                 // 00000001CE50: 7E201511
	ds_load_u16 v17, v160 offset:10224                         // 00000001CE54: D8F027F0 110000A0
	ds_load_u16 v18, v160 offset:9952                          // 00000001CE5C: D8F026E0 120000A0
	s_waitcnt lgkmcnt(1)                                       // 00000001CE64: BF89FC17
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000001CE68: 30222290
	s_waitcnt lgkmcnt(0)                                       // 00000001CE6C: BF89FC07
	v_lshlrev_b32_e32 v18, 16, v18                             // 00000001CE70: 30242490
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001CE74: BF870112
	.long 0x7f221511                                           // 00000001CE78: 7F221511
	v_cvt_f16_f32_e32 v17, v18                                 // 00000001CE7C: 7E221512
	v_cndmask_b16 v18, 0, v2, s1                               // 00000001CE80: D65D0012 00060480
	v_cvt_f16_f32_e32 v2, v3                                   // 00000001CE88: 7E041503
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001CE8C: BF8700A1
	v_cndmask_b16 v18, 0, v2, s2                               // 00000001CE90: D65D4012 000A0480
	v_lshlrev_b32_e32 v2, 16, v4                               // 00000001CE98: 30040890
	v_cvt_f16_f32_e32 v2, v2                                   // 00000001CE9C: 7E041502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001CEA0: BF8700A1
	v_cndmask_b16 v19, 0, v2, s47                              // 00000001CEA4: D65D0013 00BE0480
	v_cvt_f16_f32_e32 v2, v5                                   // 00000001CEAC: 7E041505
	v_cndmask_b16 v19, 0, v2, s48                              // 00000001CEB0: D65D4013 00C20480
	v_lshlrev_b32_e32 v2, 16, v6                               // 00000001CEB8: 30040C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001CEBC: BF870091
	v_cvt_f16_f32_e32 v2, v2                                   // 00000001CEC0: 7E041502
	v_cndmask_b16 v20, 0, v2, s49                              // 00000001CEC4: D65D0014 00C60480
	v_cvt_f16_f32_e32 v2, v7                                   // 00000001CECC: 7E041507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001CED0: BF8700A1
	v_cndmask_b16 v20, 0, v2, s50                              // 00000001CED4: D65D4014 00CA0480
	v_lshlrev_b32_e32 v2, 16, v8                               // 00000001CEDC: 30041090
	v_cvt_f16_f32_e32 v2, v2                                   // 00000001CEE0: 7E041502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001CEE4: BF8700A1
	v_cndmask_b16 v21, 0, v2, s51                              // 00000001CEE8: D65D0015 00CE0480
	v_cvt_f16_f32_e32 v2, v9                                   // 00000001CEF0: 7E041509
	v_cndmask_b16 v21, 0, v2, s52                              // 00000001CEF4: D65D4015 00D20480
	v_lshlrev_b32_e32 v2, 16, v22                              // 00000001CEFC: 30042C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001CF00: BF870091
	v_cvt_f16_f32_e32 v2, v2                                   // 00000001CF04: 7E041502
	v_cndmask_b16 v22, 0, v2, s53                              // 00000001CF08: D65D0016 00D60480
	v_cvt_f16_f32_e32 v2, v23                                  // 00000001CF10: 7E041517
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001CF14: BF8700A1
	v_cndmask_b16 v22, 0, v2, s54                              // 00000001CF18: D65D4016 00DA0480
	v_lshlrev_b32_e32 v2, 16, v24                              // 00000001CF20: 30043090
	v_cvt_f16_f32_e32 v2, v2                                   // 00000001CF24: 7E041502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001CF28: BF8700A1
	v_cndmask_b16 v23, 0, v2, s55                              // 00000001CF2C: D65D0017 00DE0480
	v_cvt_f16_f32_e32 v2, v25                                  // 00000001CF34: 7E041519
	v_cndmask_b16 v23, 0, v2, s56                              // 00000001CF38: D65D4017 00E20480
	v_lshlrev_b32_e32 v2, 16, v26                              // 00000001CF40: 30043490
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001CF44: BF870091
	v_cvt_f16_f32_e32 v2, v2                                   // 00000001CF48: 7E041502
	v_cndmask_b16 v24, 0, v2, s57                              // 00000001CF4C: D65D0018 00E60480
	v_cvt_f16_f32_e32 v2, v27                                  // 00000001CF54: 7E04151B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001CF58: BF8700A1
	v_cndmask_b16 v24, 0, v2, s58                              // 00000001CF5C: D65D4018 00EA0480
	v_lshlrev_b32_e32 v2, 16, v28                              // 00000001CF64: 30043890
	v_cvt_f16_f32_e32 v2, v2                                   // 00000001CF68: 7E041502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001CF6C: BF870001
	v_cndmask_b16 v25, 0, v2, s59                              // 00000001CF70: D65D0019 00EE0480
	v_cvt_f16_f32_e32 v2, v29                                  // 00000001CF78: 7E04151D
	ds_load_b128 v[30:33], v161 offset:19984                   // 00000001CF7C: DBFC4E10 1E0000A1
	ds_load_b128 v[26:29], v161 offset:19968                   // 00000001CF84: DBFC4E00 1A0000A1
	v_cndmask_b16 v25, 0, v2, s60                              // 00000001CF8C: D65D4019 00F20480
	v_dual_mov_b32 v2, s20 :: v_dual_mov_b32 v3, s21           // 00000001CF94: CA100014 02020015
	v_dual_mov_b32 v4, s22 :: v_dual_mov_b32 v5, s23           // 00000001CF9C: CA100016 04040017
	v_dual_mov_b32 v6, s24 :: v_dual_mov_b32 v7, s25           // 00000001CFA4: CA100018 06060019
	v_dual_mov_b32 v8, s26 :: v_dual_mov_b32 v9, s27           // 00000001CFAC: CA10001A 0808001B
	s_waitcnt lgkmcnt(0)                                       // 00000001CFB4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001CFB8: BF870001
	v_wmma_f32_16x16x16_f16 v[34:41], v[26:33], v[10:17], v[2:9]// 00000001CFBC: CC404022 1C0A151A
	ds_load_b128 v[26:29], v161 offset:19200                   // 00000001CFC4: DBFC4B00 1A0000A1
	ds_load_b128 v[30:33], v161 offset:19216                   // 00000001CFCC: DBFC4B10 1E0000A1
	s_waitcnt lgkmcnt(0)                                       // 00000001CFD4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[34:41], v[26:33], v[10:17], v[34:41]// 00000001CFD8: CC404022 1C8A151A
	ds_load_b128 v[30:33], v161 offset:21520                   // 00000001CFE0: DBFC5410 1E0000A1
	ds_load_b128 v[26:29], v161 offset:21504                   // 00000001CFE8: DBFC5400 1A0000A1
	s_waitcnt lgkmcnt(0)                                       // 00000001CFF0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[18:25], v[2:9]// 00000001CFF4: CC40400A 1C0A251A
	ds_load_b128 v[30:33], v161 offset:20752                   // 00000001CFFC: DBFC5110 1E0000A1
	ds_load_b128 v[26:29], v161 offset:20736                   // 00000001D004: DBFC5100 1A0000A1
	s_waitcnt lgkmcnt(0)                                       // 00000001D00C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[18:25], v[10:17]// 00000001D010: CC40400A 1C2A251A
	v_dual_mul_f32 v33, 0x3b800000, v136 :: v_dual_mul_f32 v32, 0x3b800000, v135// 00000001D018: C8C710FF 21210EFF 3B800000
	v_mul_f32_e32 v29, 0x3b800000, v132                        // 00000001D024: 103B08FF 3B800000
	v_dual_mul_f32 v31, 0x3b800000, v134 :: v_dual_mul_f32 v30, 0x3b800000, v133// 00000001D02C: C8C70CFF 1F1F0AFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000001D038: BF870243
	v_mov_b32_e32 v50, v33                                     // 00000001D03C: 7E640321
	v_dual_mul_f32 v28, 0x3b800000, v131 :: v_dual_mul_f32 v27, 0x3b800000, v130// 00000001D040: C8C706FF 1C1B04FF 3B800000
	v_mul_f32_e32 v26, 0x3b800000, v154                        // 00000001D04C: 103534FF 3B800000
	v_mad_u32_u24 v19, 0x110, v157, v160                       // 00000001D054: D60B0013 06833AFF 00000110
	v_permlanex16_b32 v50, v50, s44, 0xfedcba98                // 00000001D060: D65C0032 03FC5932 FEDCBA98
	v_cvt_f16_f32_e32 v18, v34                                 // 00000001D06C: 7E241522
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001D070: BF870002
	v_cndmask_b32_e32 v51, v50, v33, vcc_lo                    // 00000001D074: 02664332
	v_cndmask_b32_e32 v33, v33, v50, vcc_lo                    // 00000001D078: 02426521
	ds_store_b16 v19, v18 offset:14848                         // 00000001D07C: D87C3A00 00001213
	v_cvt_f16_f32_e32 v18, v35                                 // 00000001D084: 7E241523
	v_fma_mixlo_f16 v50, v51, s41, 0                           // 00000001D088: CC210032 02005333
	v_fma_mixlo_f16 v65, v33, s41, 0                           // 00000001D090: CC210041 02005321
	ds_store_b16 v19, v18 offset:15392                         // 00000001D098: D87C3C20 00001213
	v_cvt_f16_f32_e32 v18, v36                                 // 00000001D0A0: 7E241524
	v_fma_mixlo_f16 v58, v51, s41, -v50 op_sel_hi:[0,0,1]      // 00000001D0A4: CC21403A 84C85333
	v_fma_mixhi_f16 v58, v33, s41, -v65 op_sel_hi:[0,0,1]      // 00000001D0AC: CC22403A 85045321
	v_mov_b32_e32 v33, v32                                     // 00000001D0B4: 7E420320
	.long 0x7f643941                                           // 00000001D0B8: 7F643941
	ds_store_b16 v19, v18 offset:15936                         // 00000001D0BC: D87C3E40 00001213
	v_cvt_f16_f32_e32 v18, v37                                 // 00000001D0C4: 7E241525
	v_permlanex16_b32 v33, v33, s44, 0xfedcba98                // 00000001D0C8: D65C0021 03FC5921 FEDCBA98
	ds_store_b16 v19, v18 offset:16480                         // 00000001D0D4: D87C4060 00001213
	v_cvt_f16_f32_e32 v18, v38                                 // 00000001D0DC: 7E241526
	v_cndmask_b32_e32 v52, v33, v32, vcc_lo                    // 00000001D0E0: 02684121
	v_cndmask_b32_e32 v32, v32, v33, vcc_lo                    // 00000001D0E4: 02404320
	ds_store_b16 v19, v18 offset:17024                         // 00000001D0E8: D87C4280 00001213
	v_fma_mixlo_f16 v51, v52, s41, 0                           // 00000001D0F0: CC210033 02005334
	v_fma_mixlo_f16 v33, v32, s41, 0                           // 00000001D0F8: CC210021 02005320
	v_cvt_f16_f32_e32 v18, v39                                 // 00000001D100: 7E241527
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001D104: BF870193
	v_fma_mixlo_f16 v59, v52, s41, -v51 op_sel_hi:[0,0,1]      // 00000001D108: CC21403B 84CC5334
	v_fma_mixhi_f16 v59, v32, s41, -v33 op_sel_hi:[0,0,1]      // 00000001D110: CC22403B 84845320
	v_mov_b32_e32 v32, v31                                     // 00000001D118: 7E40031F
	ds_store_b16 v19, v18 offset:17568                         // 00000001D11C: D87C44A0 00001213
	v_cvt_f16_f32_e32 v18, v40                                 // 00000001D124: 7E241528
	.long 0x7f663921                                           // 00000001D128: 7F663921
	v_permlanex16_b32 v32, v32, s44, 0xfedcba98                // 00000001D12C: D65C0020 03FC5920 FEDCBA98
	ds_store_b16 v19, v18 offset:18112                         // 00000001D138: D87C46C0 00001213
	v_cvt_f16_f32_e32 v18, v41                                 // 00000001D140: 7E241529
	v_cndmask_b32_e32 v53, v32, v31, vcc_lo                    // 00000001D144: 026A3F20
	v_cndmask_b32_e32 v31, v31, v32, vcc_lo                    // 00000001D148: 023E411F
	ds_store_b16 v19, v18 offset:18656                         // 00000001D14C: D87C48E0 00001213
	s_waitcnt lgkmcnt(0)                                       // 00000001D154: BF89FC07
	s_barrier                                                  // 00000001D158: BFBD0000
	v_fma_mixlo_f16 v52, v53, s41, 0                           // 00000001D15C: CC210034 02005335
	v_fma_mixlo_f16 v32, v31, s41, 0                           // 00000001D164: CC210020 0200531F
	ds_load_b128 v[22:25], v159 offset:14864                   // 00000001D16C: DBFC3A10 1600009F
	ds_load_b128 v[18:21], v159 offset:14848                   // 00000001D174: DBFC3A00 1200009F
	ds_load_b128 v[42:45], v159 offset:10496                   // 00000001D17C: DBFC2900 2A00009F
	ds_load_b128 v[46:49], v159 offset:10512                   // 00000001D184: DBFC2910 2E00009F
	ds_load_b128 v[34:37], v159 offset:10528                   // 00000001D18C: DBFC2920 2200009F
	ds_load_b128 v[38:41], v159 offset:10544                   // 00000001D194: DBFC2930 2600009F
	v_fma_mixlo_f16 v60, v53, s41, -v52 op_sel_hi:[0,0,1]      // 00000001D19C: CC21403C 84D05335
	v_fma_mixhi_f16 v60, v31, s41, -v32 op_sel_hi:[0,0,1]      // 00000001D1A4: CC22403C 8480531F
	v_mov_b32_e32 v31, v30                                     // 00000001D1AC: 7E3E031E
	.long 0x7f683920                                           // 00000001D1B0: 7F683920
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D1B4: BF870092
	v_permlanex16_b32 v31, v31, s44, 0xfedcba98                // 00000001D1B8: D65C001F 03FC591F FEDCBA98
	v_cndmask_b32_e32 v54, v31, v30, vcc_lo                    // 00000001D1C4: 026C3D1F
	v_cndmask_b32_e32 v30, v30, v31, vcc_lo                    // 00000001D1C8: 023C3F1E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D1CC: BF870112
	v_fma_mixlo_f16 v53, v54, s41, 0                           // 00000001D1D0: CC210035 02005336
	v_fma_mixlo_f16 v31, v30, s41, 0                           // 00000001D1D8: CC21001F 0200531E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D1E0: BF870112
	v_fma_mixlo_f16 v61, v54, s41, -v53 op_sel_hi:[0,0,1]      // 00000001D1E4: CC21403D 84D45336
	v_fma_mixhi_f16 v61, v30, s41, -v31 op_sel_hi:[0,0,1]      // 00000001D1EC: CC22403D 847C531E
	v_mov_b32_e32 v30, v29                                     // 00000001D1F4: 7E3C031D
	.long 0x7f6a391f                                           // 00000001D1F8: 7F6A391F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D1FC: BF870092
	v_permlanex16_b32 v30, v30, s44, 0xfedcba98                // 00000001D200: D65C001E 03FC591E FEDCBA98
	v_cndmask_b32_e32 v55, v30, v29, vcc_lo                    // 00000001D20C: 026E3B1E
	v_cndmask_b32_e32 v29, v29, v30, vcc_lo                    // 00000001D210: 023A3D1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D214: BF870091
	v_fma_mixlo_f16 v30, v29, s41, 0                           // 00000001D218: CC21001E 0200531D
	v_fma_mixhi_f16 v62, v29, s41, -v30 op_sel_hi:[0,0,1]      // 00000001D220: CC22403E 8478531D
	v_mov_b32_e32 v29, v28                                     // 00000001D228: 7E3A031C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D22C: BF870091
	v_permlanex16_b32 v29, v29, s44, 0xfedcba98                // 00000001D230: D65C001D 03FC591D FEDCBA98
	v_cndmask_b32_e32 v56, v29, v28, vcc_lo                    // 00000001D23C: 0270391D
	v_cndmask_b32_e32 v28, v28, v29, vcc_lo                    // 00000001D240: 02383B1C
	v_fma_mixlo_f16 v54, v55, s41, 0                           // 00000001D244: CC210036 02005337
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D24C: BF870112
	v_fma_mixlo_f16 v29, v28, s41, 0                           // 00000001D250: CC21001D 0200531C
	v_fma_mixlo_f16 v62, v55, s41, -v54 op_sel_hi:[0,0,1]      // 00000001D258: CC21403E 84D85337
	v_fma_mixlo_f16 v55, v56, s41, 0                           // 00000001D260: CC210037 02005338
	.long 0x7f6c391e                                           // 00000001D268: 7F6C391E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001D26C: BF870224
	v_fma_mixhi_f16 v63, v28, s41, -v29 op_sel_hi:[0,0,1]      // 00000001D270: CC22403F 8474531C
	v_mov_b32_e32 v28, v27                                     // 00000001D278: 7E38031B
	v_fma_mixlo_f16 v63, v56, s41, -v55 op_sel_hi:[0,0,1]      // 00000001D27C: CC21403F 84DC5338
	.long 0x7f6e391d                                           // 00000001D284: 7F6E391D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D288: BF870093
	v_permlanex16_b32 v28, v28, s44, 0xfedcba98                // 00000001D28C: D65C001C 03FC591C FEDCBA98
	v_cndmask_b32_e32 v57, v28, v27, vcc_lo                    // 00000001D298: 0272371C
	v_cndmask_b32_e32 v27, v27, v28, vcc_lo                    // 00000001D29C: 0236391B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D2A0: BF870112
	v_fma_mixlo_f16 v56, v57, s41, 0                           // 00000001D2A4: CC210038 02005339
	v_fma_mixlo_f16 v28, v27, s41, 0                           // 00000001D2AC: CC21001C 0200531B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D2B4: BF870112
	v_fma_mixlo_f16 v64, v57, s41, -v56 op_sel_hi:[0,0,1]      // 00000001D2B8: CC214040 84E05339
	v_fma_mixhi_f16 v64, v27, s41, -v28 op_sel_hi:[0,0,1]      // 00000001D2C0: CC224040 8470531B
	v_mov_b32_e32 v27, v26                                     // 00000001D2C8: 7E36031A
	.long 0x7f70391c                                           // 00000001D2CC: 7F70391C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D2D0: BF870092
	v_permlanex16_b32 v27, v27, s44, 0xfedcba98                // 00000001D2D4: D65C001B 03FC591B FEDCBA98
	v_cndmask_b32_e32 v74, v27, v26, vcc_lo                    // 00000001D2E0: 0294351B
	v_cndmask_b32_e32 v26, v26, v27, vcc_lo                    // 00000001D2E4: 0234371A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D2E8: BF870112
	v_fma_mixlo_f16 v57, v74, s41, 0                           // 00000001D2EC: CC210039 0200534A
	v_fma_mixhi_f16 v57, v26, s41, 0                           // 00000001D2F4: CC220039 0200531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001D2FC: BF870191
	.long 0x7e3639b9                                           // 00000001D300: 7E3639B9
	v_fma_mixlo_f16 v65, v74, s41, -v57 op_sel_hi:[0,0,1]      // 00000001D304: CC214041 84E4534A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001D30C: BF8700A2
	v_fma_mixhi_f16 v65, v26, s41, -v27 op_sel_hi:[0,0,1]      // 00000001D310: CC224041 846C531A
	s_waitcnt lgkmcnt(4)                                       // 00000001D318: BF89FC47
	v_wmma_f32_16x16x16_f16 v[26:33], v[18:25], v[58:65], v[2:9]// 00000001D31C: CC40401A 1C0A7512
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000001D324: BF8700B1
	v_wmma_f32_16x16x16_f16 v[26:33], v[18:25], v[50:57], v[26:33]// 00000001D328: CC40401A 1C6A6512
	s_waitcnt lgkmcnt(2)                                       // 00000001D330: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[58:65], v[2:9]// 00000001D334: CC404012 1C0A752A
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[50:57], v[18:25]// 00000001D33C: CC404012 1C4A652A
	v_dual_mul_f32 v54, 0x3b800000, v125 :: v_dual_mul_f32 v51, 0x3b800000, v128// 00000001D344: C8C6FAFF 363300FF 3B800000
	v_dual_mul_f32 v50, 0x3b800000, v129 :: v_dual_mul_f32 v53, 0x3b800000, v126// 00000001D350: C8C702FF 3234FCFF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v124 :: v_dual_mul_f32 v56, 0x3b800000, v123// 00000001D35C: C8C6F8FF 3738F6FF 3B800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000001D368: BF8700C2
	v_dual_mul_f32 v57, 0x3b800000, v153 :: v_dual_mov_b32 v58, v50// 00000001D36C: C8D132FF 393A0132 3B800000
	ds_load_b128 v[46:49], v159 offset:14896                   // 00000001D378: DBFC3A30 2E00009F
	ds_load_b128 v[42:45], v159 offset:14880                   // 00000001D380: DBFC3A20 2A00009F
	v_permlanex16_b32 v58, v58, s44, 0xfedcba98                // 00000001D388: D65C003A 03FC593A FEDCBA98
	v_dual_mul_f32 v52, 0x3b800000, v127 :: v_dual_cndmask_b32 v59, v58, v50// 00000001D394: C8D2FEFF 343A653A 3B800000
	v_cndmask_b32_e32 v60, v50, v58, vcc_lo                    // 00000001D3A0: 02787532
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D3A4: BF870112
	v_fma_mixlo_f16 v50, v59, s41, 0                           // 00000001D3A8: CC210032 0200533B
	v_fma_mixlo_f16 v65, v60, s41, 0                           // 00000001D3B0: CC210041 0200533C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D3B8: BF8701A2
	v_fma_mixlo_f16 v58, v59, s41, -v50 op_sel_hi:[0,0,1]      // 00000001D3BC: CC21403A 84C8533B
	v_mov_b32_e32 v59, v51                                     // 00000001D3C4: 7E760333
	v_fma_mixhi_f16 v58, v60, s41, -v65 op_sel_hi:[0,0,1]      // 00000001D3C8: CC22403A 8504533C
	.long 0x7f643941                                           // 00000001D3D0: 7F643941
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D3D4: BF870093
	v_permlanex16_b32 v59, v59, s44, 0xfedcba98                // 00000001D3D8: D65C003B 03FC593B FEDCBA98
	v_cndmask_b32_e32 v60, v59, v51, vcc_lo                    // 00000001D3E4: 0278673B
	v_cndmask_b32_e32 v61, v51, v59, vcc_lo                    // 00000001D3E8: 027A7733
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D3EC: BF870112
	v_fma_mixlo_f16 v51, v60, s41, 0                           // 00000001D3F0: CC210033 0200533C
	v_fma_mixlo_f16 v74, v61, s41, 0                           // 00000001D3F8: CC21004A 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D400: BF8701A2
	v_fma_mixlo_f16 v59, v60, s41, -v51 op_sel_hi:[0,0,1]      // 00000001D404: CC21403B 84CC533C
	v_mov_b32_e32 v60, v52                                     // 00000001D40C: 7E780334
	v_fma_mixhi_f16 v59, v61, s41, -v74 op_sel_hi:[0,0,1]      // 00000001D410: CC22403B 8528533D
	.long 0x7f66394a                                           // 00000001D418: 7F66394A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D41C: BF870093
	v_permlanex16_b32 v60, v60, s44, 0xfedcba98                // 00000001D420: D65C003C 03FC593C FEDCBA98
	v_cndmask_b32_e32 v61, v60, v52, vcc_lo                    // 00000001D42C: 027A693C
	v_cndmask_b32_e32 v62, v52, v60, vcc_lo                    // 00000001D430: 027C7934
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D434: BF870112
	v_fma_mixlo_f16 v52, v61, s41, 0                           // 00000001D438: CC210034 0200533D
	v_fma_mixlo_f16 v75, v62, s41, 0                           // 00000001D440: CC21004B 0200533E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D448: BF8701A2
	v_fma_mixlo_f16 v60, v61, s41, -v52 op_sel_hi:[0,0,1]      // 00000001D44C: CC21403C 84D0533D
	v_mov_b32_e32 v61, v53                                     // 00000001D454: 7E7A0335
	v_fma_mixhi_f16 v60, v62, s41, -v75 op_sel_hi:[0,0,1]      // 00000001D458: CC22403C 852C533E
	.long 0x7f68394b                                           // 00000001D460: 7F68394B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D464: BF870093
	v_permlanex16_b32 v61, v61, s44, 0xfedcba98                // 00000001D468: D65C003D 03FC593D FEDCBA98
	v_cndmask_b32_e32 v62, v61, v53, vcc_lo                    // 00000001D474: 027C6B3D
	v_cndmask_b32_e32 v63, v53, v61, vcc_lo                    // 00000001D478: 027E7B35
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D47C: BF870112
	v_fma_mixlo_f16 v53, v62, s41, 0                           // 00000001D480: CC210035 0200533E
	v_fma_mixlo_f16 v76, v63, s41, 0                           // 00000001D488: CC21004C 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D490: BF8701A2
	v_fma_mixlo_f16 v61, v62, s41, -v53 op_sel_hi:[0,0,1]      // 00000001D494: CC21403D 84D4533E
	v_mov_b32_e32 v62, v54                                     // 00000001D49C: 7E7C0336
	v_fma_mixhi_f16 v61, v63, s41, -v76 op_sel_hi:[0,0,1]      // 00000001D4A0: CC22403D 8530533F
	.long 0x7f6a394c                                           // 00000001D4A8: 7F6A394C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D4AC: BF870093
	v_permlanex16_b32 v62, v62, s44, 0xfedcba98                // 00000001D4B0: D65C003E 03FC593E FEDCBA98
	v_cndmask_b32_e32 v63, v62, v54, vcc_lo                    // 00000001D4BC: 027E6D3E
	v_cndmask_b32_e32 v64, v54, v62, vcc_lo                    // 00000001D4C0: 02807D36
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D4C4: BF870112
	v_fma_mixlo_f16 v54, v63, s41, 0                           // 00000001D4C8: CC210036 0200533F
	v_fma_mixlo_f16 v77, v64, s41, 0                           // 00000001D4D0: CC21004D 02005340
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D4D8: BF8701A2
	v_fma_mixlo_f16 v62, v63, s41, -v54 op_sel_hi:[0,0,1]      // 00000001D4DC: CC21403E 84D8533F
	v_mov_b32_e32 v63, v55                                     // 00000001D4E4: 7E7E0337
	v_fma_mixhi_f16 v62, v64, s41, -v77 op_sel_hi:[0,0,1]      // 00000001D4E8: CC22403E 85345340
	.long 0x7f6c394d                                           // 00000001D4F0: 7F6C394D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D4F4: BF870093
	v_permlanex16_b32 v63, v63, s44, 0xfedcba98                // 00000001D4F8: D65C003F 03FC593F FEDCBA98
	v_cndmask_b32_e32 v64, v63, v55, vcc_lo                    // 00000001D504: 02806F3F
	v_cndmask_b32_e32 v78, v55, v63, vcc_lo                    // 00000001D508: 029C7F37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D50C: BF870112
	v_fma_mixlo_f16 v55, v64, s41, 0                           // 00000001D510: CC210037 02005340
	v_fma_mixlo_f16 v79, v78, s41, 0                           // 00000001D518: CC21004F 0200534E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D520: BF8701A2
	v_fma_mixlo_f16 v63, v64, s41, -v55 op_sel_hi:[0,0,1]      // 00000001D524: CC21403F 84DC5340
	v_mov_b32_e32 v64, v56                                     // 00000001D52C: 7E800338
	v_fma_mixhi_f16 v63, v78, s41, -v79 op_sel_hi:[0,0,1]      // 00000001D530: CC22403F 853C534E
	.long 0x7f6e394f                                           // 00000001D538: 7F6E394F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D53C: BF870093
	v_permlanex16_b32 v64, v64, s44, 0xfedcba98                // 00000001D540: D65C0040 03FC5940 FEDCBA98
	v_cndmask_b32_e32 v78, v64, v56, vcc_lo                    // 00000001D54C: 029C7140
	v_cndmask_b32_e32 v80, v56, v64, vcc_lo                    // 00000001D550: 02A08138
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D554: BF870112
	v_fma_mixlo_f16 v56, v78, s41, 0                           // 00000001D558: CC210038 0200534E
	v_fma_mixlo_f16 v81, v80, s41, 0                           // 00000001D560: CC210051 02005350
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D568: BF8701A2
	v_fma_mixlo_f16 v64, v78, s41, -v56 op_sel_hi:[0,0,1]      // 00000001D56C: CC214040 84E0534E
	v_mov_b32_e32 v78, v57                                     // 00000001D574: 7E9C0339
	v_fma_mixhi_f16 v64, v80, s41, -v81 op_sel_hi:[0,0,1]      // 00000001D578: CC224040 85445350
	.long 0x7f703951                                           // 00000001D580: 7F703951
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D584: BF870093
	v_permlanex16_b32 v78, v78, s44, 0xfedcba98                // 00000001D588: D65C004E 03FC594E FEDCBA98
	v_cndmask_b32_e32 v80, v78, v57, vcc_lo                    // 00000001D594: 02A0734E
	v_cndmask_b32_e32 v78, v57, v78, vcc_lo                    // 00000001D598: 029C9D39
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D59C: BF870112
	v_fma_mixlo_f16 v57, v80, s41, 0                           // 00000001D5A0: CC210039 02005350
	v_fma_mixhi_f16 v57, v78, s41, 0                           // 00000001D5A8: CC220039 0200534E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001D5B0: BF870191
	.long 0xd59c08a2                                           // 00000001D5B4: D59C08A2
	v_cndmask_b32_e32 v0, v57, v128, vcc_lo                    // 00000001D5B8: 02010139
	v_fma_mixlo_f16 v65, v80, s41, -v57 op_sel_hi:[0,0,1]      // 00000001D5BC: CC214041 84E45350
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001D5C4: BF8700A2
	v_fma_mixhi_f16 v65, v78, s41, -v162 op_sel_hi:[0,0,1]     // 00000001D5C8: CC224041 8688534E
	s_waitcnt lgkmcnt(0)                                       // 00000001D5D0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[26:33], v[42:49], v[58:65], v[26:33]// 00000001D5D4: CC40401A 1C6A752A
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[58:65], v[18:25]// 00000001D5DC: CC404012 1C4A7522
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D5E4: BF870112
	v_wmma_f32_16x16x16_f16 v[26:33], v[42:49], v[50:57], v[26:33]// 00000001D5E8: CC40401A 1C6A652A
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[50:57], v[18:25]// 00000001D5F0: CC404012 1C4A6522
	v_dual_mul_f32 v50, 0x3b800000, v122 :: v_dual_mul_f32 v51, 0x3b800000, v121// 00000001D5F8: C8C6F4FF 3232F2FF 3B800000
	v_mul_f32_e32 v54, 0x3b800000, v118                        // 00000001D604: 106CECFF 3B800000
	v_dual_mul_f32 v52, 0x3b800000, v120 :: v_dual_mul_f32 v53, 0x3b800000, v119// 00000001D60C: C8C6F0FF 3434EEFF 3B800000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000001D618: BF870003
	v_dual_mov_b32 v58, v50 :: v_dual_mul_f32 v55, 0x3b800000, v117// 00000001D61C: CA060132 3A36EAFF 3B800000
	v_mul_f32_e32 v57, 0x3b800000, v152                        // 00000001D628: 107330FF 3B800000
	ds_load_b128 v[46:49], v159 offset:14928                   // 00000001D630: DBFC3A50 2E00009F
	ds_load_b128 v[42:45], v159 offset:14912                   // 00000001D638: DBFC3A40 2A00009F
	ds_load_b128 v[38:41], v159 offset:10576                   // 00000001D640: DBFC2950 2600009F
	ds_load_b128 v[34:37], v159 offset:10560                   // 00000001D648: DBFC2940 2200009F
	v_permlanex16_b32 v58, v58, s44, 0xfedcba98                // 00000001D650: D65C003A 03FC593A FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D65C: BF870121
	v_cndmask_b32_e32 v59, v58, v50, vcc_lo                    // 00000001D660: 0276653A
	v_cndmask_b32_e32 v60, v50, v58, vcc_lo                    // 00000001D664: 02787532
	v_fma_mixlo_f16 v50, v59, s41, 0                           // 00000001D668: CC210032 0200533B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D670: BF870112
	v_fma_mixlo_f16 v65, v60, s41, 0                           // 00000001D674: CC210041 0200533C
	v_fma_mixlo_f16 v58, v59, s41, -v50 op_sel_hi:[0,0,1]      // 00000001D67C: CC21403A 84C8533B
	v_mov_b32_e32 v59, v51                                     // 00000001D684: 7E760333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D688: BF8701A3
	v_fma_mixhi_f16 v58, v60, s41, -v65 op_sel_hi:[0,0,1]      // 00000001D68C: CC22403A 8504533C
	.long 0x7f643941                                           // 00000001D694: 7F643941
	v_permlanex16_b32 v59, v59, s44, 0xfedcba98                // 00000001D698: D65C003B 03FC593B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D6A4: BF870121
	v_cndmask_b32_e32 v60, v59, v51, vcc_lo                    // 00000001D6A8: 0278673B
	v_cndmask_b32_e32 v61, v51, v59, vcc_lo                    // 00000001D6AC: 027A7733
	v_fma_mixlo_f16 v51, v60, s41, 0                           // 00000001D6B0: CC210033 0200533C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D6B8: BF870112
	v_fma_mixlo_f16 v74, v61, s41, 0                           // 00000001D6BC: CC21004A 0200533D
	v_fma_mixlo_f16 v59, v60, s41, -v51 op_sel_hi:[0,0,1]      // 00000001D6C4: CC21403B 84CC533C
	v_mov_b32_e32 v60, v52                                     // 00000001D6CC: 7E780334
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D6D0: BF8701A3
	v_fma_mixhi_f16 v59, v61, s41, -v74 op_sel_hi:[0,0,1]      // 00000001D6D4: CC22403B 8528533D
	.long 0x7f66394a                                           // 00000001D6DC: 7F66394A
	v_permlanex16_b32 v60, v60, s44, 0xfedcba98                // 00000001D6E0: D65C003C 03FC593C FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D6EC: BF870121
	v_cndmask_b32_e32 v61, v60, v52, vcc_lo                    // 00000001D6F0: 027A693C
	v_cndmask_b32_e32 v62, v52, v60, vcc_lo                    // 00000001D6F4: 027C7934
	v_fma_mixlo_f16 v52, v61, s41, 0                           // 00000001D6F8: CC210034 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D700: BF870112
	v_fma_mixlo_f16 v75, v62, s41, 0                           // 00000001D704: CC21004B 0200533E
	v_fma_mixlo_f16 v60, v61, s41, -v52 op_sel_hi:[0,0,1]      // 00000001D70C: CC21403C 84D0533D
	v_mov_b32_e32 v61, v53                                     // 00000001D714: 7E7A0335
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D718: BF8701A3
	v_fma_mixhi_f16 v60, v62, s41, -v75 op_sel_hi:[0,0,1]      // 00000001D71C: CC22403C 852C533E
	.long 0x7f68394b                                           // 00000001D724: 7F68394B
	v_permlanex16_b32 v61, v61, s44, 0xfedcba98                // 00000001D728: D65C003D 03FC593D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D734: BF870121
	v_dual_mul_f32 v56, 0x3b800000, v116 :: v_dual_cndmask_b32 v63, v53, v61// 00000001D738: C8D2E8FF 383E7B35 3B800000
	v_cndmask_b32_e32 v62, v61, v53, vcc_lo                    // 00000001D744: 027C6B3D
	v_fma_mixlo_f16 v76, v63, s41, 0                           // 00000001D748: CC21004C 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D750: BF870112
	v_fma_mixlo_f16 v53, v62, s41, 0                           // 00000001D754: CC210035 0200533E
	v_fma_mixhi_f16 v61, v63, s41, -v76 op_sel_hi:[0,0,1]      // 00000001D75C: CC22403D 8530533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001D764: BF870132
	v_fma_mixlo_f16 v61, v62, s41, -v53 op_sel_hi:[0,0,1]      // 00000001D768: CC21403D 84D4533E
	v_mov_b32_e32 v62, v54                                     // 00000001D770: 7E7C0336
	.long 0x7f6a394c                                           // 00000001D774: 7F6A394C
	v_permlanex16_b32 v62, v62, s44, 0xfedcba98                // 00000001D778: D65C003E 03FC593E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D784: BF870121
	v_cndmask_b32_e32 v63, v62, v54, vcc_lo                    // 00000001D788: 027E6D3E
	v_cndmask_b32_e32 v64, v54, v62, vcc_lo                    // 00000001D78C: 02807D36
	v_fma_mixlo_f16 v54, v63, s41, 0                           // 00000001D790: CC210036 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D798: BF870112
	v_fma_mixlo_f16 v77, v64, s41, 0                           // 00000001D79C: CC21004D 02005340
	v_fma_mixlo_f16 v62, v63, s41, -v54 op_sel_hi:[0,0,1]      // 00000001D7A4: CC21403E 84D8533F
	v_mov_b32_e32 v63, v55                                     // 00000001D7AC: 7E7E0337
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D7B0: BF8701A3
	v_fma_mixhi_f16 v62, v64, s41, -v77 op_sel_hi:[0,0,1]      // 00000001D7B4: CC22403E 85345340
	.long 0x7f6c394d                                           // 00000001D7BC: 7F6C394D
	v_permlanex16_b32 v63, v63, s44, 0xfedcba98                // 00000001D7C0: D65C003F 03FC593F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D7CC: BF870121
	v_cndmask_b32_e32 v64, v63, v55, vcc_lo                    // 00000001D7D0: 02806F3F
	v_cndmask_b32_e32 v78, v55, v63, vcc_lo                    // 00000001D7D4: 029C7F37
	v_fma_mixlo_f16 v55, v64, s41, 0                           // 00000001D7D8: CC210037 02005340
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D7E0: BF870112
	v_fma_mixlo_f16 v79, v78, s41, 0                           // 00000001D7E4: CC21004F 0200534E
	v_fma_mixlo_f16 v63, v64, s41, -v55 op_sel_hi:[0,0,1]      // 00000001D7EC: CC21403F 84DC5340
	v_mov_b32_e32 v64, v56                                     // 00000001D7F4: 7E800338
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D7F8: BF8701A3
	v_fma_mixhi_f16 v63, v78, s41, -v79 op_sel_hi:[0,0,1]      // 00000001D7FC: CC22403F 853C534E
	.long 0x7f6e394f                                           // 00000001D804: 7F6E394F
	v_permlanex16_b32 v64, v64, s44, 0xfedcba98                // 00000001D808: D65C0040 03FC5940 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D814: BF870121
	v_cndmask_b32_e32 v78, v64, v56, vcc_lo                    // 00000001D818: 029C7140
	v_cndmask_b32_e32 v80, v56, v64, vcc_lo                    // 00000001D81C: 02A08138
	v_fma_mixlo_f16 v56, v78, s41, 0                           // 00000001D820: CC210038 0200534E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D828: BF870112
	v_fma_mixlo_f16 v81, v80, s41, 0                           // 00000001D82C: CC210051 02005350
	v_fma_mixlo_f16 v64, v78, s41, -v56 op_sel_hi:[0,0,1]      // 00000001D834: CC214040 84E0534E
	v_mov_b32_e32 v78, v57                                     // 00000001D83C: 7E9C0339
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D840: BF8701A3
	v_fma_mixhi_f16 v64, v80, s41, -v81 op_sel_hi:[0,0,1]      // 00000001D844: CC224040 85445350
	.long 0x7f703951                                           // 00000001D84C: 7F703951
	v_permlanex16_b32 v78, v78, s44, 0xfedcba98                // 00000001D850: D65C004E 03FC594E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D85C: BF870121
	v_cndmask_b32_e32 v80, v78, v57, vcc_lo                    // 00000001D860: 02A0734E
	v_cndmask_b32_e32 v78, v57, v78, vcc_lo                    // 00000001D864: 029C9D39
	v_fma_mixlo_f16 v57, v80, s41, 0                           // 00000001D868: CC210039 02005350
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D870: BF870092
	v_fma_mixhi_f16 v57, v78, s41, 0                           // 00000001D874: CC220039 0200534E
	.long 0xd59c08a2                                           // 00000001D87C: D59C08A2
	v_cndmask_b32_e32 v0, v57, v128, vcc_lo                    // 00000001D880: 02010139
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D884: BF870113
	v_fma_mixlo_f16 v65, v80, s41, -v57 op_sel_hi:[0,0,1]      // 00000001D888: CC214041 84E45350
	v_fma_mixhi_f16 v65, v78, s41, -v162 op_sel_hi:[0,0,1]     // 00000001D890: CC224041 8688534E
	s_waitcnt lgkmcnt(2)                                       // 00000001D898: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001D89C: BF870131
	v_wmma_f32_16x16x16_f16 v[26:33], v[42:49], v[58:65], v[26:33]// 00000001D8A0: CC40401A 1C6A752A
	s_waitcnt lgkmcnt(0)                                       // 00000001D8A8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[58:65], v[18:25]// 00000001D8AC: CC404012 1C4A7522
	v_wmma_f32_16x16x16_f16 v[26:33], v[42:49], v[50:57], v[26:33]// 00000001D8B4: CC40401A 1C6A652A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000001D8BC: BF8701C2
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[50:57], v[18:25]// 00000001D8C0: CC404012 1C4A6522
	v_dual_mul_f32 v50, 0x3b800000, v115 :: v_dual_mul_f32 v51, 0x3b800000, v114// 00000001D8C8: C8C6E6FF 3232E4FF 3B800000
	v_dual_mul_f32 v52, 0x3b800000, v113 :: v_dual_mul_f32 v53, 0x3b800000, v112// 00000001D8D4: C8C6E2FF 3434E0FF 3B800000
	v_mul_f32_e32 v54, 0x3b800000, v111                        // 00000001D8E0: 106CDEFF 3B800000
	v_dual_mov_b32 v58, v50 :: v_dual_mul_f32 v55, 0x3b800000, v110// 00000001D8E8: CA060132 3A36DCFF 3B800000
	v_dual_mul_f32 v56, 0x3b800000, v109 :: v_dual_mul_f32 v57, 0x3b800000, v151// 00000001D8F4: C8C6DAFF 38392EFF 3B800000
	ds_load_b128 v[46:49], v159 offset:14960                   // 00000001D900: DBFC3A70 2E00009F
	ds_load_b128 v[42:45], v159 offset:14944                   // 00000001D908: DBFC3A60 2A00009F
	ds_load_b128 v[38:41], v159 offset:10608                   // 00000001D910: DBFC2970 2600009F
	ds_load_b128 v[34:37], v159 offset:10592                   // 00000001D918: DBFC2960 2200009F
	v_permlanex16_b32 v58, v58, s44, 0xfedcba98                // 00000001D920: D65C003A 03FC593A FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D92C: BF870121
	v_cndmask_b32_e32 v59, v58, v50, vcc_lo                    // 00000001D930: 0276653A
	v_cndmask_b32_e32 v60, v50, v58, vcc_lo                    // 00000001D934: 02787532
	v_fma_mixlo_f16 v50, v59, s41, 0                           // 00000001D938: CC210032 0200533B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D940: BF870112
	v_fma_mixlo_f16 v65, v60, s41, 0                           // 00000001D944: CC210041 0200533C
	v_fma_mixlo_f16 v58, v59, s41, -v50 op_sel_hi:[0,0,1]      // 00000001D94C: CC21403A 84C8533B
	v_mov_b32_e32 v59, v51                                     // 00000001D954: 7E760333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D958: BF8701A3
	v_fma_mixhi_f16 v58, v60, s41, -v65 op_sel_hi:[0,0,1]      // 00000001D95C: CC22403A 8504533C
	.long 0x7f643941                                           // 00000001D964: 7F643941
	v_permlanex16_b32 v59, v59, s44, 0xfedcba98                // 00000001D968: D65C003B 03FC593B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D974: BF870121
	v_cndmask_b32_e32 v60, v59, v51, vcc_lo                    // 00000001D978: 0278673B
	v_cndmask_b32_e32 v61, v51, v59, vcc_lo                    // 00000001D97C: 027A7733
	v_fma_mixlo_f16 v51, v60, s41, 0                           // 00000001D980: CC210033 0200533C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D988: BF870112
	v_fma_mixlo_f16 v74, v61, s41, 0                           // 00000001D98C: CC21004A 0200533D
	v_fma_mixlo_f16 v59, v60, s41, -v51 op_sel_hi:[0,0,1]      // 00000001D994: CC21403B 84CC533C
	v_mov_b32_e32 v60, v52                                     // 00000001D99C: 7E780334
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D9A0: BF8701A3
	v_fma_mixhi_f16 v59, v61, s41, -v74 op_sel_hi:[0,0,1]      // 00000001D9A4: CC22403B 8528533D
	.long 0x7f66394a                                           // 00000001D9AC: 7F66394A
	v_permlanex16_b32 v60, v60, s44, 0xfedcba98                // 00000001D9B0: D65C003C 03FC593C FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D9BC: BF870121
	v_cndmask_b32_e32 v61, v60, v52, vcc_lo                    // 00000001D9C0: 027A693C
	v_cndmask_b32_e32 v62, v52, v60, vcc_lo                    // 00000001D9C4: 027C7934
	v_fma_mixlo_f16 v52, v61, s41, 0                           // 00000001D9C8: CC210034 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D9D0: BF870112
	v_fma_mixlo_f16 v75, v62, s41, 0                           // 00000001D9D4: CC21004B 0200533E
	v_fma_mixlo_f16 v60, v61, s41, -v52 op_sel_hi:[0,0,1]      // 00000001D9DC: CC21403C 84D0533D
	v_mov_b32_e32 v61, v53                                     // 00000001D9E4: 7E7A0335
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001D9E8: BF8701A3
	v_fma_mixhi_f16 v60, v62, s41, -v75 op_sel_hi:[0,0,1]      // 00000001D9EC: CC22403C 852C533E
	.long 0x7f68394b                                           // 00000001D9F4: 7F68394B
	v_permlanex16_b32 v61, v61, s44, 0xfedcba98                // 00000001D9F8: D65C003D 03FC593D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DA04: BF870121
	v_cndmask_b32_e32 v62, v61, v53, vcc_lo                    // 00000001DA08: 027C6B3D
	v_cndmask_b32_e32 v63, v53, v61, vcc_lo                    // 00000001DA0C: 027E7B35
	v_fma_mixlo_f16 v53, v62, s41, 0                           // 00000001DA10: CC210035 0200533E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DA18: BF870112
	v_fma_mixlo_f16 v76, v63, s41, 0                           // 00000001DA1C: CC21004C 0200533F
	v_fma_mixlo_f16 v61, v62, s41, -v53 op_sel_hi:[0,0,1]      // 00000001DA24: CC21403D 84D4533E
	v_mov_b32_e32 v62, v54                                     // 00000001DA2C: 7E7C0336
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DA30: BF8701A3
	v_fma_mixhi_f16 v61, v63, s41, -v76 op_sel_hi:[0,0,1]      // 00000001DA34: CC22403D 8530533F
	.long 0x7f6a394c                                           // 00000001DA3C: 7F6A394C
	v_permlanex16_b32 v62, v62, s44, 0xfedcba98                // 00000001DA40: D65C003E 03FC593E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DA4C: BF870121
	v_cndmask_b32_e32 v63, v62, v54, vcc_lo                    // 00000001DA50: 027E6D3E
	v_cndmask_b32_e32 v64, v54, v62, vcc_lo                    // 00000001DA54: 02807D36
	v_fma_mixlo_f16 v54, v63, s41, 0                           // 00000001DA58: CC210036 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DA60: BF870112
	v_fma_mixlo_f16 v77, v64, s41, 0                           // 00000001DA64: CC21004D 02005340
	v_fma_mixlo_f16 v62, v63, s41, -v54 op_sel_hi:[0,0,1]      // 00000001DA6C: CC21403E 84D8533F
	v_mov_b32_e32 v63, v55                                     // 00000001DA74: 7E7E0337
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DA78: BF8701A3
	v_fma_mixhi_f16 v62, v64, s41, -v77 op_sel_hi:[0,0,1]      // 00000001DA7C: CC22403E 85345340
	.long 0x7f6c394d                                           // 00000001DA84: 7F6C394D
	v_permlanex16_b32 v63, v63, s44, 0xfedcba98                // 00000001DA88: D65C003F 03FC593F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DA94: BF870121
	v_cndmask_b32_e32 v64, v63, v55, vcc_lo                    // 00000001DA98: 02806F3F
	v_cndmask_b32_e32 v78, v55, v63, vcc_lo                    // 00000001DA9C: 029C7F37
	v_fma_mixlo_f16 v55, v64, s41, 0                           // 00000001DAA0: CC210037 02005340
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DAA8: BF870112
	v_fma_mixlo_f16 v79, v78, s41, 0                           // 00000001DAAC: CC21004F 0200534E
	v_fma_mixlo_f16 v63, v64, s41, -v55 op_sel_hi:[0,0,1]      // 00000001DAB4: CC21403F 84DC5340
	v_mov_b32_e32 v64, v56                                     // 00000001DABC: 7E800338
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DAC0: BF8701A3
	v_fma_mixhi_f16 v63, v78, s41, -v79 op_sel_hi:[0,0,1]      // 00000001DAC4: CC22403F 853C534E
	.long 0x7f6e394f                                           // 00000001DACC: 7F6E394F
	v_permlanex16_b32 v64, v64, s44, 0xfedcba98                // 00000001DAD0: D65C0040 03FC5940 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DADC: BF870121
	v_cndmask_b32_e32 v78, v64, v56, vcc_lo                    // 00000001DAE0: 029C7140
	v_cndmask_b32_e32 v80, v56, v64, vcc_lo                    // 00000001DAE4: 02A08138
	v_fma_mixlo_f16 v56, v78, s41, 0                           // 00000001DAE8: CC210038 0200534E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DAF0: BF870112
	v_fma_mixlo_f16 v81, v80, s41, 0                           // 00000001DAF4: CC210051 02005350
	v_fma_mixlo_f16 v64, v78, s41, -v56 op_sel_hi:[0,0,1]      // 00000001DAFC: CC214040 84E0534E
	v_mov_b32_e32 v78, v57                                     // 00000001DB04: 7E9C0339
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DB08: BF8701A3
	v_fma_mixhi_f16 v64, v80, s41, -v81 op_sel_hi:[0,0,1]      // 00000001DB0C: CC224040 85445350
	.long 0x7f703951                                           // 00000001DB14: 7F703951
	v_permlanex16_b32 v78, v78, s44, 0xfedcba98                // 00000001DB18: D65C004E 03FC594E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DB24: BF870121
	v_cndmask_b32_e32 v80, v78, v57, vcc_lo                    // 00000001DB28: 02A0734E
	v_cndmask_b32_e32 v78, v57, v78, vcc_lo                    // 00000001DB2C: 029C9D39
	v_fma_mixlo_f16 v57, v80, s41, 0                           // 00000001DB30: CC210039 02005350
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DB38: BF870092
	v_fma_mixhi_f16 v57, v78, s41, 0                           // 00000001DB3C: CC220039 0200534E
	.long 0xd59c08a2                                           // 00000001DB44: D59C08A2
	v_cndmask_b32_e32 v0, v57, v128, vcc_lo                    // 00000001DB48: 02010139
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DB4C: BF870113
	v_fma_mixlo_f16 v65, v80, s41, -v57 op_sel_hi:[0,0,1]      // 00000001DB50: CC214041 84E45350
	v_fma_mixhi_f16 v65, v78, s41, -v162 op_sel_hi:[0,0,1]     // 00000001DB58: CC224041 8688534E
	s_waitcnt lgkmcnt(2)                                       // 00000001DB60: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001DB64: BF870131
	v_wmma_f32_16x16x16_f16 v[26:33], v[42:49], v[58:65], v[26:33]// 00000001DB68: CC40401A 1C6A752A
	s_waitcnt lgkmcnt(0)                                       // 00000001DB70: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[58:65], v[18:25]// 00000001DB74: CC404012 1C4A7522
	v_wmma_f32_16x16x16_f16 v[26:33], v[42:49], v[50:57], v[26:33]// 00000001DB7C: CC40401A 1C6A652A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000001DB84: BF8701C2
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[50:57], v[18:25]// 00000001DB88: CC404012 1C4A6522
	v_dual_mul_f32 v50, 0x3b800000, v108 :: v_dual_mul_f32 v51, 0x3b800000, v107// 00000001DB90: C8C6D8FF 3232D6FF 3B800000
	v_dual_mul_f32 v52, 0x3b800000, v106 :: v_dual_mul_f32 v53, 0x3b800000, v105// 00000001DB9C: C8C6D4FF 3434D2FF 3B800000
	v_mul_f32_e32 v54, 0x3b800000, v104                        // 00000001DBA8: 106CD0FF 3B800000
	v_dual_mov_b32 v58, v50 :: v_dual_mul_f32 v55, 0x3b800000, v103// 00000001DBB0: CA060132 3A36CEFF 3B800000
	v_mul_f32_e32 v56, 0x3b800000, v102                        // 00000001DBBC: 1070CCFF 3B800000
	v_mul_f32_e32 v57, 0x3b800000, v150                        // 00000001DBC4: 10732CFF 3B800000
	ds_load_b128 v[46:49], v159 offset:14992                   // 00000001DBCC: DBFC3A90 2E00009F
	ds_load_b128 v[42:45], v159 offset:14976                   // 00000001DBD4: DBFC3A80 2A00009F
	ds_load_b128 v[38:41], v159 offset:10640                   // 00000001DBDC: DBFC2990 2600009F
	ds_load_b128 v[34:37], v159 offset:10624                   // 00000001DBE4: DBFC2980 2200009F
	v_permlanex16_b32 v58, v58, s44, 0xfedcba98                // 00000001DBEC: D65C003A 03FC593A FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DBF8: BF870121
	v_cndmask_b32_e32 v59, v58, v50, vcc_lo                    // 00000001DBFC: 0276653A
	v_cndmask_b32_e32 v60, v50, v58, vcc_lo                    // 00000001DC00: 02787532
	v_fma_mixlo_f16 v50, v59, s41, 0                           // 00000001DC04: CC210032 0200533B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DC0C: BF870112
	v_fma_mixlo_f16 v65, v60, s41, 0                           // 00000001DC10: CC210041 0200533C
	v_fma_mixlo_f16 v58, v59, s41, -v50 op_sel_hi:[0,0,1]      // 00000001DC18: CC21403A 84C8533B
	v_mov_b32_e32 v59, v51                                     // 00000001DC20: 7E760333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DC24: BF8701A3
	v_fma_mixhi_f16 v58, v60, s41, -v65 op_sel_hi:[0,0,1]      // 00000001DC28: CC22403A 8504533C
	.long 0x7f643941                                           // 00000001DC30: 7F643941
	v_permlanex16_b32 v59, v59, s44, 0xfedcba98                // 00000001DC34: D65C003B 03FC593B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DC40: BF870121
	v_cndmask_b32_e32 v60, v59, v51, vcc_lo                    // 00000001DC44: 0278673B
	v_cndmask_b32_e32 v61, v51, v59, vcc_lo                    // 00000001DC48: 027A7733
	v_fma_mixlo_f16 v51, v60, s41, 0                           // 00000001DC4C: CC210033 0200533C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DC54: BF870112
	v_fma_mixlo_f16 v74, v61, s41, 0                           // 00000001DC58: CC21004A 0200533D
	v_fma_mixlo_f16 v59, v60, s41, -v51 op_sel_hi:[0,0,1]      // 00000001DC60: CC21403B 84CC533C
	v_mov_b32_e32 v60, v52                                     // 00000001DC68: 7E780334
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DC6C: BF8701A3
	v_fma_mixhi_f16 v59, v61, s41, -v74 op_sel_hi:[0,0,1]      // 00000001DC70: CC22403B 8528533D
	.long 0x7f66394a                                           // 00000001DC78: 7F66394A
	v_permlanex16_b32 v60, v60, s44, 0xfedcba98                // 00000001DC7C: D65C003C 03FC593C FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DC88: BF870121
	v_cndmask_b32_e32 v61, v60, v52, vcc_lo                    // 00000001DC8C: 027A693C
	v_cndmask_b32_e32 v62, v52, v60, vcc_lo                    // 00000001DC90: 027C7934
	v_fma_mixlo_f16 v52, v61, s41, 0                           // 00000001DC94: CC210034 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DC9C: BF870112
	v_fma_mixlo_f16 v75, v62, s41, 0                           // 00000001DCA0: CC21004B 0200533E
	v_fma_mixlo_f16 v60, v61, s41, -v52 op_sel_hi:[0,0,1]      // 00000001DCA8: CC21403C 84D0533D
	v_mov_b32_e32 v61, v53                                     // 00000001DCB0: 7E7A0335
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DCB4: BF8701A3
	v_fma_mixhi_f16 v60, v62, s41, -v75 op_sel_hi:[0,0,1]      // 00000001DCB8: CC22403C 852C533E
	.long 0x7f68394b                                           // 00000001DCC0: 7F68394B
	v_permlanex16_b32 v61, v61, s44, 0xfedcba98                // 00000001DCC4: D65C003D 03FC593D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DCD0: BF870121
	v_cndmask_b32_e32 v62, v61, v53, vcc_lo                    // 00000001DCD4: 027C6B3D
	v_cndmask_b32_e32 v63, v53, v61, vcc_lo                    // 00000001DCD8: 027E7B35
	v_fma_mixlo_f16 v53, v62, s41, 0                           // 00000001DCDC: CC210035 0200533E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DCE4: BF870112
	v_fma_mixlo_f16 v76, v63, s41, 0                           // 00000001DCE8: CC21004C 0200533F
	v_fma_mixlo_f16 v61, v62, s41, -v53 op_sel_hi:[0,0,1]      // 00000001DCF0: CC21403D 84D4533E
	v_mov_b32_e32 v62, v54                                     // 00000001DCF8: 7E7C0336
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DCFC: BF8701A3
	v_fma_mixhi_f16 v61, v63, s41, -v76 op_sel_hi:[0,0,1]      // 00000001DD00: CC22403D 8530533F
	.long 0x7f6a394c                                           // 00000001DD08: 7F6A394C
	v_permlanex16_b32 v62, v62, s44, 0xfedcba98                // 00000001DD0C: D65C003E 03FC593E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DD18: BF870121
	v_cndmask_b32_e32 v63, v62, v54, vcc_lo                    // 00000001DD1C: 027E6D3E
	v_cndmask_b32_e32 v64, v54, v62, vcc_lo                    // 00000001DD20: 02807D36
	v_fma_mixlo_f16 v54, v63, s41, 0                           // 00000001DD24: CC210036 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DD2C: BF870112
	v_fma_mixlo_f16 v77, v64, s41, 0                           // 00000001DD30: CC21004D 02005340
	v_fma_mixlo_f16 v62, v63, s41, -v54 op_sel_hi:[0,0,1]      // 00000001DD38: CC21403E 84D8533F
	v_mov_b32_e32 v63, v55                                     // 00000001DD40: 7E7E0337
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DD44: BF8701A3
	v_fma_mixhi_f16 v62, v64, s41, -v77 op_sel_hi:[0,0,1]      // 00000001DD48: CC22403E 85345340
	.long 0x7f6c394d                                           // 00000001DD50: 7F6C394D
	v_permlanex16_b32 v63, v63, s44, 0xfedcba98                // 00000001DD54: D65C003F 03FC593F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DD60: BF870121
	v_cndmask_b32_e32 v64, v63, v55, vcc_lo                    // 00000001DD64: 02806F3F
	v_cndmask_b32_e32 v78, v55, v63, vcc_lo                    // 00000001DD68: 029C7F37
	v_fma_mixlo_f16 v55, v64, s41, 0                           // 00000001DD6C: CC210037 02005340
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DD74: BF870112
	v_fma_mixlo_f16 v79, v78, s41, 0                           // 00000001DD78: CC21004F 0200534E
	v_fma_mixlo_f16 v63, v64, s41, -v55 op_sel_hi:[0,0,1]      // 00000001DD80: CC21403F 84DC5340
	v_mov_b32_e32 v64, v56                                     // 00000001DD88: 7E800338
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DD8C: BF8701A3
	v_fma_mixhi_f16 v63, v78, s41, -v79 op_sel_hi:[0,0,1]      // 00000001DD90: CC22403F 853C534E
	.long 0x7f6e394f                                           // 00000001DD98: 7F6E394F
	v_permlanex16_b32 v64, v64, s44, 0xfedcba98                // 00000001DD9C: D65C0040 03FC5940 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DDA8: BF870121
	v_cndmask_b32_e32 v78, v64, v56, vcc_lo                    // 00000001DDAC: 029C7140
	v_cndmask_b32_e32 v80, v56, v64, vcc_lo                    // 00000001DDB0: 02A08138
	v_fma_mixlo_f16 v56, v78, s41, 0                           // 00000001DDB4: CC210038 0200534E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DDBC: BF870112
	v_fma_mixlo_f16 v81, v80, s41, 0                           // 00000001DDC0: CC210051 02005350
	v_fma_mixlo_f16 v64, v78, s41, -v56 op_sel_hi:[0,0,1]      // 00000001DDC8: CC214040 84E0534E
	v_mov_b32_e32 v78, v57                                     // 00000001DDD0: 7E9C0339
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DDD4: BF8701A3
	v_fma_mixhi_f16 v64, v80, s41, -v81 op_sel_hi:[0,0,1]      // 00000001DDD8: CC224040 85445350
	.long 0x7f703951                                           // 00000001DDE0: 7F703951
	v_permlanex16_b32 v78, v78, s44, 0xfedcba98                // 00000001DDE4: D65C004E 03FC594E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DDF0: BF870121
	v_cndmask_b32_e32 v80, v78, v57, vcc_lo                    // 00000001DDF4: 02A0734E
	v_cndmask_b32_e32 v78, v57, v78, vcc_lo                    // 00000001DDF8: 029C9D39
	v_fma_mixlo_f16 v57, v80, s41, 0                           // 00000001DDFC: CC210039 02005350
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DE04: BF870092
	v_fma_mixhi_f16 v57, v78, s41, 0                           // 00000001DE08: CC220039 0200534E
	.long 0xd59c08a2                                           // 00000001DE10: D59C08A2
	v_cndmask_b32_e32 v0, v57, v128, vcc_lo                    // 00000001DE14: 02010139
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DE18: BF870113
	v_fma_mixlo_f16 v65, v80, s41, -v57 op_sel_hi:[0,0,1]      // 00000001DE1C: CC214041 84E45350
	v_fma_mixhi_f16 v65, v78, s41, -v162 op_sel_hi:[0,0,1]     // 00000001DE24: CC224041 8688534E
	s_waitcnt lgkmcnt(2)                                       // 00000001DE2C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001DE30: BF870131
	v_wmma_f32_16x16x16_f16 v[26:33], v[42:49], v[58:65], v[26:33]// 00000001DE34: CC40401A 1C6A752A
	s_waitcnt lgkmcnt(0)                                       // 00000001DE3C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[58:65], v[18:25]// 00000001DE40: CC404012 1C4A7522
	v_wmma_f32_16x16x16_f16 v[26:33], v[42:49], v[50:57], v[26:33]// 00000001DE48: CC40401A 1C6A652A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000001DE50: BF8701C2
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[50:57], v[18:25]// 00000001DE54: CC404012 1C4A6522
	v_dual_mul_f32 v50, 0x3b800000, v101 :: v_dual_mul_f32 v51, 0x3b800000, v100// 00000001DE5C: C8C6CAFF 3232C8FF 3B800000
	v_dual_mul_f32 v52, 0x3b800000, v99 :: v_dual_mul_f32 v53, 0x3b800000, v98// 00000001DE68: C8C6C6FF 3434C4FF 3B800000
	v_mul_f32_e32 v54, 0x3b800000, v97                         // 00000001DE74: 106CC2FF 3B800000
	v_dual_mov_b32 v58, v50 :: v_dual_mul_f32 v55, 0x3b800000, v96// 00000001DE7C: CA060132 3A36C0FF 3B800000
	v_dual_mul_f32 v56, 0x3b800000, v95 :: v_dual_mul_f32 v57, 0x3b800000, v149// 00000001DE88: C8C6BEFF 38392AFF 3B800000
	ds_load_b128 v[46:49], v159 offset:15024                   // 00000001DE94: DBFC3AB0 2E00009F
	ds_load_b128 v[42:45], v159 offset:15008                   // 00000001DE9C: DBFC3AA0 2A00009F
	ds_load_b128 v[38:41], v159 offset:10672                   // 00000001DEA4: DBFC29B0 2600009F
	ds_load_b128 v[34:37], v159 offset:10656                   // 00000001DEAC: DBFC29A0 2200009F
	v_permlanex16_b32 v58, v58, s44, 0xfedcba98                // 00000001DEB4: D65C003A 03FC593A FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DEC0: BF870121
	v_cndmask_b32_e32 v59, v58, v50, vcc_lo                    // 00000001DEC4: 0276653A
	v_cndmask_b32_e32 v60, v50, v58, vcc_lo                    // 00000001DEC8: 02787532
	v_fma_mixlo_f16 v50, v59, s41, 0                           // 00000001DECC: CC210032 0200533B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DED4: BF870112
	v_fma_mixlo_f16 v65, v60, s41, 0                           // 00000001DED8: CC210041 0200533C
	v_fma_mixlo_f16 v58, v59, s41, -v50 op_sel_hi:[0,0,1]      // 00000001DEE0: CC21403A 84C8533B
	v_mov_b32_e32 v59, v51                                     // 00000001DEE8: 7E760333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DEEC: BF8701A3
	v_fma_mixhi_f16 v58, v60, s41, -v65 op_sel_hi:[0,0,1]      // 00000001DEF0: CC22403A 8504533C
	.long 0x7f643941                                           // 00000001DEF8: 7F643941
	v_permlanex16_b32 v59, v59, s44, 0xfedcba98                // 00000001DEFC: D65C003B 03FC593B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DF08: BF870121
	v_cndmask_b32_e32 v60, v59, v51, vcc_lo                    // 00000001DF0C: 0278673B
	v_cndmask_b32_e32 v61, v51, v59, vcc_lo                    // 00000001DF10: 027A7733
	v_fma_mixlo_f16 v51, v60, s41, 0                           // 00000001DF14: CC210033 0200533C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DF1C: BF870112
	v_fma_mixlo_f16 v74, v61, s41, 0                           // 00000001DF20: CC21004A 0200533D
	v_fma_mixlo_f16 v59, v60, s41, -v51 op_sel_hi:[0,0,1]      // 00000001DF28: CC21403B 84CC533C
	v_mov_b32_e32 v60, v52                                     // 00000001DF30: 7E780334
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DF34: BF8701A3
	v_fma_mixhi_f16 v59, v61, s41, -v74 op_sel_hi:[0,0,1]      // 00000001DF38: CC22403B 8528533D
	.long 0x7f66394a                                           // 00000001DF40: 7F66394A
	v_permlanex16_b32 v60, v60, s44, 0xfedcba98                // 00000001DF44: D65C003C 03FC593C FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DF50: BF870121
	v_cndmask_b32_e32 v61, v60, v52, vcc_lo                    // 00000001DF54: 027A693C
	v_cndmask_b32_e32 v62, v52, v60, vcc_lo                    // 00000001DF58: 027C7934
	v_fma_mixlo_f16 v52, v61, s41, 0                           // 00000001DF5C: CC210034 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DF64: BF870112
	v_fma_mixlo_f16 v75, v62, s41, 0                           // 00000001DF68: CC21004B 0200533E
	v_fma_mixlo_f16 v60, v61, s41, -v52 op_sel_hi:[0,0,1]      // 00000001DF70: CC21403C 84D0533D
	v_mov_b32_e32 v61, v53                                     // 00000001DF78: 7E7A0335
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DF7C: BF8701A3
	v_fma_mixhi_f16 v60, v62, s41, -v75 op_sel_hi:[0,0,1]      // 00000001DF80: CC22403C 852C533E
	.long 0x7f68394b                                           // 00000001DF88: 7F68394B
	v_permlanex16_b32 v61, v61, s44, 0xfedcba98                // 00000001DF8C: D65C003D 03FC593D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DF98: BF870121
	v_cndmask_b32_e32 v62, v61, v53, vcc_lo                    // 00000001DF9C: 027C6B3D
	v_cndmask_b32_e32 v63, v53, v61, vcc_lo                    // 00000001DFA0: 027E7B35
	v_fma_mixlo_f16 v53, v62, s41, 0                           // 00000001DFA4: CC210035 0200533E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DFAC: BF870112
	v_fma_mixlo_f16 v76, v63, s41, 0                           // 00000001DFB0: CC21004C 0200533F
	v_fma_mixlo_f16 v61, v62, s41, -v53 op_sel_hi:[0,0,1]      // 00000001DFB8: CC21403D 84D4533E
	v_mov_b32_e32 v62, v54                                     // 00000001DFC0: 7E7C0336
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001DFC4: BF8701A3
	v_fma_mixhi_f16 v61, v63, s41, -v76 op_sel_hi:[0,0,1]      // 00000001DFC8: CC22403D 8530533F
	.long 0x7f6a394c                                           // 00000001DFD0: 7F6A394C
	v_permlanex16_b32 v62, v62, s44, 0xfedcba98                // 00000001DFD4: D65C003E 03FC593E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DFE0: BF870121
	v_cndmask_b32_e32 v63, v62, v54, vcc_lo                    // 00000001DFE4: 027E6D3E
	v_cndmask_b32_e32 v64, v54, v62, vcc_lo                    // 00000001DFE8: 02807D36
	v_fma_mixlo_f16 v54, v63, s41, 0                           // 00000001DFEC: CC210036 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DFF4: BF870112
	v_fma_mixlo_f16 v77, v64, s41, 0                           // 00000001DFF8: CC21004D 02005340
	v_fma_mixlo_f16 v62, v63, s41, -v54 op_sel_hi:[0,0,1]      // 00000001E000: CC21403E 84D8533F
	v_mov_b32_e32 v63, v55                                     // 00000001E008: 7E7E0337
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E00C: BF8701A3
	v_fma_mixhi_f16 v62, v64, s41, -v77 op_sel_hi:[0,0,1]      // 00000001E010: CC22403E 85345340
	.long 0x7f6c394d                                           // 00000001E018: 7F6C394D
	v_permlanex16_b32 v63, v63, s44, 0xfedcba98                // 00000001E01C: D65C003F 03FC593F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E028: BF870121
	v_cndmask_b32_e32 v64, v63, v55, vcc_lo                    // 00000001E02C: 02806F3F
	v_cndmask_b32_e32 v78, v55, v63, vcc_lo                    // 00000001E030: 029C7F37
	v_fma_mixlo_f16 v55, v64, s41, 0                           // 00000001E034: CC210037 02005340
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E03C: BF870112
	v_fma_mixlo_f16 v79, v78, s41, 0                           // 00000001E040: CC21004F 0200534E
	v_fma_mixlo_f16 v63, v64, s41, -v55 op_sel_hi:[0,0,1]      // 00000001E048: CC21403F 84DC5340
	v_mov_b32_e32 v64, v56                                     // 00000001E050: 7E800338
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E054: BF8701A3
	v_fma_mixhi_f16 v63, v78, s41, -v79 op_sel_hi:[0,0,1]      // 00000001E058: CC22403F 853C534E
	.long 0x7f6e394f                                           // 00000001E060: 7F6E394F
	v_permlanex16_b32 v64, v64, s44, 0xfedcba98                // 00000001E064: D65C0040 03FC5940 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E070: BF870121
	v_cndmask_b32_e32 v78, v64, v56, vcc_lo                    // 00000001E074: 029C7140
	v_cndmask_b32_e32 v80, v56, v64, vcc_lo                    // 00000001E078: 02A08138
	v_fma_mixlo_f16 v56, v78, s41, 0                           // 00000001E07C: CC210038 0200534E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E084: BF870112
	v_fma_mixlo_f16 v81, v80, s41, 0                           // 00000001E088: CC210051 02005350
	v_fma_mixlo_f16 v64, v78, s41, -v56 op_sel_hi:[0,0,1]      // 00000001E090: CC214040 84E0534E
	v_mov_b32_e32 v78, v57                                     // 00000001E098: 7E9C0339
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E09C: BF8701A3
	v_fma_mixhi_f16 v64, v80, s41, -v81 op_sel_hi:[0,0,1]      // 00000001E0A0: CC224040 85445350
	.long 0x7f703951                                           // 00000001E0A8: 7F703951
	v_permlanex16_b32 v78, v78, s44, 0xfedcba98                // 00000001E0AC: D65C004E 03FC594E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E0B8: BF870121
	v_cndmask_b32_e32 v80, v78, v57, vcc_lo                    // 00000001E0BC: 02A0734E
	v_cndmask_b32_e32 v78, v57, v78, vcc_lo                    // 00000001E0C0: 029C9D39
	v_fma_mixlo_f16 v57, v80, s41, 0                           // 00000001E0C4: CC210039 02005350
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E0CC: BF870092
	v_fma_mixhi_f16 v57, v78, s41, 0                           // 00000001E0D0: CC220039 0200534E
	.long 0xd59c08a2                                           // 00000001E0D8: D59C08A2
	v_cndmask_b32_e32 v0, v57, v128, vcc_lo                    // 00000001E0DC: 02010139
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E0E0: BF870113
	v_fma_mixlo_f16 v65, v80, s41, -v57 op_sel_hi:[0,0,1]      // 00000001E0E4: CC214041 84E45350
	v_fma_mixhi_f16 v65, v78, s41, -v162 op_sel_hi:[0,0,1]     // 00000001E0EC: CC224041 8688534E
	s_waitcnt lgkmcnt(2)                                       // 00000001E0F4: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001E0F8: BF870131
	v_wmma_f32_16x16x16_f16 v[26:33], v[42:49], v[58:65], v[26:33]// 00000001E0FC: CC40401A 1C6A752A
	s_waitcnt lgkmcnt(0)                                       // 00000001E104: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[58:65], v[18:25]// 00000001E108: CC404012 1C4A7522
	v_wmma_f32_16x16x16_f16 v[26:33], v[42:49], v[50:57], v[26:33]// 00000001E110: CC40401A 1C6A652A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000001E118: BF8701C2
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[50:57], v[18:25]// 00000001E11C: CC404012 1C4A6522
	v_dual_mul_f32 v50, 0x3b800000, v94 :: v_dual_mul_f32 v51, 0x3b800000, v93// 00000001E124: C8C6BCFF 3232BAFF 3B800000
	v_dual_mul_f32 v52, 0x3b800000, v92 :: v_dual_mul_f32 v53, 0x3b800000, v91// 00000001E130: C8C6B8FF 3434B6FF 3B800000
	v_mul_f32_e32 v54, 0x3b800000, v90                         // 00000001E13C: 106CB4FF 3B800000
	v_dual_mov_b32 v58, v50 :: v_dual_mul_f32 v55, 0x3b800000, v89// 00000001E144: CA060132 3A36B2FF 3B800000
	v_mul_f32_e32 v56, 0x3b800000, v88                         // 00000001E150: 1070B0FF 3B800000
	v_mul_f32_e32 v57, 0x3b800000, v148                        // 00000001E158: 107328FF 3B800000
	ds_load_b128 v[46:49], v159 offset:15056                   // 00000001E160: DBFC3AD0 2E00009F
	ds_load_b128 v[42:45], v159 offset:15040                   // 00000001E168: DBFC3AC0 2A00009F
	ds_load_b128 v[38:41], v159 offset:10704                   // 00000001E170: DBFC29D0 2600009F
	ds_load_b128 v[34:37], v159 offset:10688                   // 00000001E178: DBFC29C0 2200009F
	v_permlanex16_b32 v58, v58, s44, 0xfedcba98                // 00000001E180: D65C003A 03FC593A FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E18C: BF870121
	v_cndmask_b32_e32 v59, v58, v50, vcc_lo                    // 00000001E190: 0276653A
	v_cndmask_b32_e32 v60, v50, v58, vcc_lo                    // 00000001E194: 02787532
	v_fma_mixlo_f16 v50, v59, s41, 0                           // 00000001E198: CC210032 0200533B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E1A0: BF870112
	v_fma_mixlo_f16 v65, v60, s41, 0                           // 00000001E1A4: CC210041 0200533C
	v_fma_mixlo_f16 v58, v59, s41, -v50 op_sel_hi:[0,0,1]      // 00000001E1AC: CC21403A 84C8533B
	v_mov_b32_e32 v59, v51                                     // 00000001E1B4: 7E760333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E1B8: BF8701A3
	v_fma_mixhi_f16 v58, v60, s41, -v65 op_sel_hi:[0,0,1]      // 00000001E1BC: CC22403A 8504533C
	.long 0x7f643941                                           // 00000001E1C4: 7F643941
	v_permlanex16_b32 v59, v59, s44, 0xfedcba98                // 00000001E1C8: D65C003B 03FC593B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E1D4: BF870121
	v_cndmask_b32_e32 v60, v59, v51, vcc_lo                    // 00000001E1D8: 0278673B
	v_cndmask_b32_e32 v61, v51, v59, vcc_lo                    // 00000001E1DC: 027A7733
	v_fma_mixlo_f16 v51, v60, s41, 0                           // 00000001E1E0: CC210033 0200533C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E1E8: BF870112
	v_fma_mixlo_f16 v74, v61, s41, 0                           // 00000001E1EC: CC21004A 0200533D
	v_fma_mixlo_f16 v59, v60, s41, -v51 op_sel_hi:[0,0,1]      // 00000001E1F4: CC21403B 84CC533C
	v_mov_b32_e32 v60, v52                                     // 00000001E1FC: 7E780334
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E200: BF8701A3
	v_fma_mixhi_f16 v59, v61, s41, -v74 op_sel_hi:[0,0,1]      // 00000001E204: CC22403B 8528533D
	.long 0x7f66394a                                           // 00000001E20C: 7F66394A
	v_permlanex16_b32 v60, v60, s44, 0xfedcba98                // 00000001E210: D65C003C 03FC593C FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E21C: BF870121
	v_cndmask_b32_e32 v61, v60, v52, vcc_lo                    // 00000001E220: 027A693C
	v_cndmask_b32_e32 v62, v52, v60, vcc_lo                    // 00000001E224: 027C7934
	v_fma_mixlo_f16 v52, v61, s41, 0                           // 00000001E228: CC210034 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E230: BF870112
	v_fma_mixlo_f16 v75, v62, s41, 0                           // 00000001E234: CC21004B 0200533E
	v_fma_mixlo_f16 v60, v61, s41, -v52 op_sel_hi:[0,0,1]      // 00000001E23C: CC21403C 84D0533D
	v_mov_b32_e32 v61, v53                                     // 00000001E244: 7E7A0335
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E248: BF8701A3
	v_fma_mixhi_f16 v60, v62, s41, -v75 op_sel_hi:[0,0,1]      // 00000001E24C: CC22403C 852C533E
	.long 0x7f68394b                                           // 00000001E254: 7F68394B
	v_permlanex16_b32 v61, v61, s44, 0xfedcba98                // 00000001E258: D65C003D 03FC593D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E264: BF870121
	v_cndmask_b32_e32 v62, v61, v53, vcc_lo                    // 00000001E268: 027C6B3D
	v_cndmask_b32_e32 v63, v53, v61, vcc_lo                    // 00000001E26C: 027E7B35
	v_fma_mixlo_f16 v53, v62, s41, 0                           // 00000001E270: CC210035 0200533E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E278: BF870112
	v_fma_mixlo_f16 v76, v63, s41, 0                           // 00000001E27C: CC21004C 0200533F
	v_fma_mixlo_f16 v61, v62, s41, -v53 op_sel_hi:[0,0,1]      // 00000001E284: CC21403D 84D4533E
	v_mov_b32_e32 v62, v54                                     // 00000001E28C: 7E7C0336
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E290: BF8701A3
	v_fma_mixhi_f16 v61, v63, s41, -v76 op_sel_hi:[0,0,1]      // 00000001E294: CC22403D 8530533F
	.long 0x7f6a394c                                           // 00000001E29C: 7F6A394C
	v_permlanex16_b32 v62, v62, s44, 0xfedcba98                // 00000001E2A0: D65C003E 03FC593E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E2AC: BF870121
	v_cndmask_b32_e32 v63, v62, v54, vcc_lo                    // 00000001E2B0: 027E6D3E
	v_cndmask_b32_e32 v64, v54, v62, vcc_lo                    // 00000001E2B4: 02807D36
	v_fma_mixlo_f16 v54, v63, s41, 0                           // 00000001E2B8: CC210036 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E2C0: BF870112
	v_fma_mixlo_f16 v77, v64, s41, 0                           // 00000001E2C4: CC21004D 02005340
	v_fma_mixlo_f16 v62, v63, s41, -v54 op_sel_hi:[0,0,1]      // 00000001E2CC: CC21403E 84D8533F
	v_mov_b32_e32 v63, v55                                     // 00000001E2D4: 7E7E0337
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E2D8: BF8701A3
	v_fma_mixhi_f16 v62, v64, s41, -v77 op_sel_hi:[0,0,1]      // 00000001E2DC: CC22403E 85345340
	.long 0x7f6c394d                                           // 00000001E2E4: 7F6C394D
	v_permlanex16_b32 v63, v63, s44, 0xfedcba98                // 00000001E2E8: D65C003F 03FC593F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E2F4: BF870121
	v_cndmask_b32_e32 v64, v63, v55, vcc_lo                    // 00000001E2F8: 02806F3F
	v_cndmask_b32_e32 v78, v55, v63, vcc_lo                    // 00000001E2FC: 029C7F37
	v_fma_mixlo_f16 v55, v64, s41, 0                           // 00000001E300: CC210037 02005340
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E308: BF870112
	v_fma_mixlo_f16 v79, v78, s41, 0                           // 00000001E30C: CC21004F 0200534E
	v_fma_mixlo_f16 v63, v64, s41, -v55 op_sel_hi:[0,0,1]      // 00000001E314: CC21403F 84DC5340
	v_mov_b32_e32 v64, v56                                     // 00000001E31C: 7E800338
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E320: BF8701A3
	v_fma_mixhi_f16 v63, v78, s41, -v79 op_sel_hi:[0,0,1]      // 00000001E324: CC22403F 853C534E
	.long 0x7f6e394f                                           // 00000001E32C: 7F6E394F
	v_permlanex16_b32 v64, v64, s44, 0xfedcba98                // 00000001E330: D65C0040 03FC5940 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E33C: BF870121
	v_cndmask_b32_e32 v78, v64, v56, vcc_lo                    // 00000001E340: 029C7140
	v_cndmask_b32_e32 v80, v56, v64, vcc_lo                    // 00000001E344: 02A08138
	v_fma_mixlo_f16 v56, v78, s41, 0                           // 00000001E348: CC210038 0200534E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E350: BF870112
	v_fma_mixlo_f16 v81, v80, s41, 0                           // 00000001E354: CC210051 02005350
	v_fma_mixlo_f16 v64, v78, s41, -v56 op_sel_hi:[0,0,1]      // 00000001E35C: CC214040 84E0534E
	v_mov_b32_e32 v78, v57                                     // 00000001E364: 7E9C0339
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E368: BF8701A3
	v_fma_mixhi_f16 v64, v80, s41, -v81 op_sel_hi:[0,0,1]      // 00000001E36C: CC224040 85445350
	.long 0x7f703951                                           // 00000001E374: 7F703951
	v_permlanex16_b32 v78, v78, s44, 0xfedcba98                // 00000001E378: D65C004E 03FC594E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E384: BF870121
	v_cndmask_b32_e32 v80, v78, v57, vcc_lo                    // 00000001E388: 02A0734E
	v_cndmask_b32_e32 v78, v57, v78, vcc_lo                    // 00000001E38C: 029C9D39
	v_fma_mixlo_f16 v57, v80, s41, 0                           // 00000001E390: CC210039 02005350
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E398: BF870092
	v_fma_mixhi_f16 v57, v78, s41, 0                           // 00000001E39C: CC220039 0200534E
	.long 0xd59c08a2                                           // 00000001E3A4: D59C08A2
	v_cndmask_b32_e32 v0, v57, v128, vcc_lo                    // 00000001E3A8: 02010139
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E3AC: BF870113
	v_fma_mixlo_f16 v65, v80, s41, -v57 op_sel_hi:[0,0,1]      // 00000001E3B0: CC214041 84E45350
	v_fma_mixhi_f16 v65, v78, s41, -v162 op_sel_hi:[0,0,1]     // 00000001E3B8: CC224041 8688534E
	s_waitcnt lgkmcnt(2)                                       // 00000001E3C0: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001E3C4: BF870131
	v_wmma_f32_16x16x16_f16 v[26:33], v[42:49], v[58:65], v[26:33]// 00000001E3C8: CC40401A 1C6A752A
	s_waitcnt lgkmcnt(0)                                       // 00000001E3D0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[58:65], v[18:25]// 00000001E3D4: CC404012 1C4A7522
	v_wmma_f32_16x16x16_f16 v[26:33], v[42:49], v[50:57], v[26:33]// 00000001E3DC: CC40401A 1C6A652A
	v_dual_mul_f32 v42, 0x3b800000, v87 :: v_dual_mul_f32 v43, 0x3b800000, v86// 00000001E3E4: C8C6AEFF 2A2AACFF 3B800000
	v_dual_mul_f32 v44, 0x3b800000, v85 :: v_dual_mul_f32 v45, 0x3b800000, v84// 00000001E3F0: C8C6AAFF 2C2CA8FF 3B800000
	v_mul_f32_e32 v46, 0x3b800000, v83                         // 00000001E3FC: 105CA6FF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000001E404: BF870243
	v_dual_mov_b32 v58, v42 :: v_dual_mul_f32 v47, 0x3b800000, v82// 00000001E408: CA06012A 3A2EA4FF 3B800000
	v_mul_f32_e32 v48, 0x3b800000, v143                        // 00000001E414: 10611EFF 3B800000
	v_mul_f32_e32 v49, 0x3b800000, v147                        // 00000001E41C: 106326FF 3B800000
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[50:57], v[18:25]// 00000001E424: CC404012 1C4A6522
	v_permlanex16_b32 v58, v58, s44, 0xfedcba98                // 00000001E42C: D65C003A 03FC593A FEDCBA98
	ds_load_b128 v[54:57], v159 offset:15088                   // 00000001E438: DBFC3AF0 3600009F
	ds_load_b128 v[50:53], v159 offset:15072                   // 00000001E440: DBFC3AE0 3200009F
	ds_load_b128 v[38:41], v159 offset:10736                   // 00000001E448: DBFC29F0 2600009F
	ds_load_b128 v[34:37], v159 offset:10720                   // 00000001E450: DBFC29E0 2200009F
	v_cndmask_b32_e32 v59, v58, v42, vcc_lo                    // 00000001E458: 0276553A
	v_cndmask_b32_e32 v60, v42, v58, vcc_lo                    // 00000001E45C: 0278752A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E460: BF870112
	v_fma_mixlo_f16 v42, v59, s41, 0                           // 00000001E464: CC21002A 0200533B
	v_fma_mixlo_f16 v65, v60, s41, 0                           // 00000001E46C: CC210041 0200533C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E474: BF8701A2
	v_fma_mixlo_f16 v58, v59, s41, -v42 op_sel_hi:[0,0,1]      // 00000001E478: CC21403A 84A8533B
	v_mov_b32_e32 v59, v43                                     // 00000001E480: 7E76032B
	v_fma_mixhi_f16 v58, v60, s41, -v65 op_sel_hi:[0,0,1]      // 00000001E484: CC22403A 8504533C
	.long 0x7f543941                                           // 00000001E48C: 7F543941
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E490: BF870093
	v_permlanex16_b32 v59, v59, s44, 0xfedcba98                // 00000001E494: D65C003B 03FC593B FEDCBA98
	v_cndmask_b32_e32 v60, v59, v43, vcc_lo                    // 00000001E4A0: 0278573B
	v_cndmask_b32_e32 v61, v43, v59, vcc_lo                    // 00000001E4A4: 027A772B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E4A8: BF870112
	v_fma_mixlo_f16 v43, v60, s41, 0                           // 00000001E4AC: CC21002B 0200533C
	v_fma_mixlo_f16 v74, v61, s41, 0                           // 00000001E4B4: CC21004A 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E4BC: BF8701A2
	v_fma_mixlo_f16 v59, v60, s41, -v43 op_sel_hi:[0,0,1]      // 00000001E4C0: CC21403B 84AC533C
	v_mov_b32_e32 v60, v44                                     // 00000001E4C8: 7E78032C
	v_fma_mixhi_f16 v59, v61, s41, -v74 op_sel_hi:[0,0,1]      // 00000001E4CC: CC22403B 8528533D
	.long 0x7f56394a                                           // 00000001E4D4: 7F56394A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E4D8: BF870093
	v_permlanex16_b32 v60, v60, s44, 0xfedcba98                // 00000001E4DC: D65C003C 03FC593C FEDCBA98
	v_cndmask_b32_e32 v61, v60, v44, vcc_lo                    // 00000001E4E8: 027A593C
	v_cndmask_b32_e32 v62, v44, v60, vcc_lo                    // 00000001E4EC: 027C792C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E4F0: BF870112
	v_fma_mixlo_f16 v44, v61, s41, 0                           // 00000001E4F4: CC21002C 0200533D
	v_fma_mixlo_f16 v75, v62, s41, 0                           // 00000001E4FC: CC21004B 0200533E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E504: BF8701A2
	v_fma_mixlo_f16 v60, v61, s41, -v44 op_sel_hi:[0,0,1]      // 00000001E508: CC21403C 84B0533D
	v_mov_b32_e32 v61, v45                                     // 00000001E510: 7E7A032D
	v_fma_mixhi_f16 v60, v62, s41, -v75 op_sel_hi:[0,0,1]      // 00000001E514: CC22403C 852C533E
	.long 0x7f58394b                                           // 00000001E51C: 7F58394B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E520: BF870093
	v_permlanex16_b32 v61, v61, s44, 0xfedcba98                // 00000001E524: D65C003D 03FC593D FEDCBA98
	v_cndmask_b32_e32 v62, v61, v45, vcc_lo                    // 00000001E530: 027C5B3D
	v_cndmask_b32_e32 v63, v45, v61, vcc_lo                    // 00000001E534: 027E7B2D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E538: BF870112
	v_fma_mixlo_f16 v45, v62, s41, 0                           // 00000001E53C: CC21002D 0200533E
	v_fma_mixlo_f16 v76, v63, s41, 0                           // 00000001E544: CC21004C 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E54C: BF8701A2
	v_fma_mixlo_f16 v61, v62, s41, -v45 op_sel_hi:[0,0,1]      // 00000001E550: CC21403D 84B4533E
	v_mov_b32_e32 v62, v46                                     // 00000001E558: 7E7C032E
	v_fma_mixhi_f16 v61, v63, s41, -v76 op_sel_hi:[0,0,1]      // 00000001E55C: CC22403D 8530533F
	.long 0x7f5a394c                                           // 00000001E564: 7F5A394C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E568: BF870093
	v_permlanex16_b32 v62, v62, s44, 0xfedcba98                // 00000001E56C: D65C003E 03FC593E FEDCBA98
	v_cndmask_b32_e32 v63, v62, v46, vcc_lo                    // 00000001E578: 027E5D3E
	v_cndmask_b32_e32 v64, v46, v62, vcc_lo                    // 00000001E57C: 02807D2E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E580: BF870112
	v_fma_mixlo_f16 v46, v63, s41, 0                           // 00000001E584: CC21002E 0200533F
	v_fma_mixlo_f16 v77, v64, s41, 0                           // 00000001E58C: CC21004D 02005340
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E594: BF8701A2
	v_fma_mixlo_f16 v62, v63, s41, -v46 op_sel_hi:[0,0,1]      // 00000001E598: CC21403E 84B8533F
	v_mov_b32_e32 v63, v47                                     // 00000001E5A0: 7E7E032F
	v_fma_mixhi_f16 v62, v64, s41, -v77 op_sel_hi:[0,0,1]      // 00000001E5A4: CC22403E 85345340
	.long 0x7f5c394d                                           // 00000001E5AC: 7F5C394D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E5B0: BF870093
	v_permlanex16_b32 v63, v63, s44, 0xfedcba98                // 00000001E5B4: D65C003F 03FC593F FEDCBA98
	v_cndmask_b32_e32 v64, v63, v47, vcc_lo                    // 00000001E5C0: 02805F3F
	v_cndmask_b32_e32 v78, v47, v63, vcc_lo                    // 00000001E5C4: 029C7F2F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E5C8: BF870112
	v_fma_mixlo_f16 v47, v64, s41, 0                           // 00000001E5CC: CC21002F 02005340
	v_fma_mixlo_f16 v79, v78, s41, 0                           // 00000001E5D4: CC21004F 0200534E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E5DC: BF8701A2
	v_fma_mixlo_f16 v63, v64, s41, -v47 op_sel_hi:[0,0,1]      // 00000001E5E0: CC21403F 84BC5340
	v_mov_b32_e32 v64, v48                                     // 00000001E5E8: 7E800330
	v_fma_mixhi_f16 v63, v78, s41, -v79 op_sel_hi:[0,0,1]      // 00000001E5EC: CC22403F 853C534E
	.long 0x7f5e394f                                           // 00000001E5F4: 7F5E394F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E5F8: BF870093
	v_permlanex16_b32 v64, v64, s44, 0xfedcba98                // 00000001E5FC: D65C0040 03FC5940 FEDCBA98
	v_cndmask_b32_e32 v78, v64, v48, vcc_lo                    // 00000001E608: 029C6140
	v_cndmask_b32_e32 v80, v48, v64, vcc_lo                    // 00000001E60C: 02A08130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E610: BF870112
	v_fma_mixlo_f16 v48, v78, s41, 0                           // 00000001E614: CC210030 0200534E
	v_fma_mixlo_f16 v81, v80, s41, 0                           // 00000001E61C: CC210051 02005350
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E624: BF8701A2
	v_fma_mixlo_f16 v64, v78, s41, -v48 op_sel_hi:[0,0,1]      // 00000001E628: CC214040 84C0534E
	v_mov_b32_e32 v78, v49                                     // 00000001E630: 7E9C0331
	v_fma_mixhi_f16 v64, v80, s41, -v81 op_sel_hi:[0,0,1]      // 00000001E634: CC224040 85445350
	.long 0x7f603951                                           // 00000001E63C: 7F603951
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E640: BF870093
	v_permlanex16_b32 v78, v78, s44, 0xfedcba98                // 00000001E644: D65C004E 03FC594E FEDCBA98
	v_cndmask_b32_e32 v80, v78, v49, vcc_lo                    // 00000001E650: 02A0634E
	v_cndmask_b32_e32 v78, v49, v78, vcc_lo                    // 00000001E654: 029C9D31
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E658: BF870112
	v_fma_mixlo_f16 v49, v80, s41, 0                           // 00000001E65C: CC210031 02005350
	v_fma_mixhi_f16 v49, v78, s41, 0                           // 00000001E664: CC220031 0200534E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001E66C: BF870191
	.long 0xd59c089f                                           // 00000001E670: D59C089F
	v_cndmask_b32_e32 v0, v49, v128, vcc_lo                    // 00000001E674: 02010131
	v_fma_mixlo_f16 v65, v80, s41, -v49 op_sel_hi:[0,0,1]      // 00000001E678: CC214041 84C45350
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001E680: BF8700A2
	v_fma_mixhi_f16 v65, v78, s41, -v159 op_sel_hi:[0,0,1]     // 00000001E684: CC224041 867C534E
	s_waitcnt lgkmcnt(2)                                       // 00000001E68C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[58:65], v[26:33]// 00000001E690: CC40401A 1C6A7532
	s_waitcnt lgkmcnt(0)                                       // 00000001E698: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[58:65], v[18:25]// 00000001E69C: CC404012 1C4A7522
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E6A4: BF8701A2
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[42:49], v[26:33]// 00000001E6A8: CC40401A 1C6A5532
	v_or_b32_e32 v50, s46, v157                                // 00000001E6B0: 38653A2E
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[42:49], v[18:25]// 00000001E6B4: CC404012 1C4A5522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001E6BC: BF870193
	v_mul_f32_e32 v26, 0x3b800000, v26                         // 00000001E6C0: 103434FF 3B800000
	.long 0xd4440001                                           // 00000001E6C8: D4440001
	v_cndmask_b32_e32 v1, s31, v50, vcc_lo                     // 00000001E6CC: 0202641F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E6D0: BF870092
	v_sub_f32_e32 v10, v10, v26                                // 00000001E6D4: 0814350A
	v_fma_mixlo_f16 v10, v10, s41, 0                           // 00000001E6D8: CC21000A 0200530A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001E6E0: BF8700A1
	v_cndmask_b16 v26, 0, v10, s1                              // 00000001E6E4: D65D001A 00061480
	v_or_b32_e32 v10, 2, v50                                   // 00000001E6EC: 38146482
	.long 0xd4440002                                           // 00000001E6F0: D4440002
	v_cndmask_b32_e32 v1, s31, v10, vcc_lo                     // 00000001E6F4: 0202141F
	v_mul_f32_e32 v10, 0x3b800000, v27                         // 00000001E6F8: 101436FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E700: BF870091
	v_sub_f32_e32 v10, v11, v10                                // 00000001E704: 0814150B
	v_fma_mixlo_f16 v10, v10, s41, 0                           // 00000001E708: CC21000A 0200530A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001E710: BF8700A1
	v_cndmask_b16 v26, 0, v10, s2                              // 00000001E714: D65D401A 000A1480
	v_or_b32_e32 v10, 4, v50                                   // 00000001E71C: 38146484
	.long 0xd4440002                                           // 00000001E720: D4440002
	v_cndmask_b32_e32 v1, s31, v10, vcc_lo                     // 00000001E724: 0202141F
	v_mul_f32_e32 v10, 0x3b800000, v28                         // 00000001E728: 101438FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E730: BF870091
	v_sub_f32_e32 v10, v12, v10                                // 00000001E734: 0814150C
	v_fma_mixlo_f16 v10, v10, s41, 0                           // 00000001E738: CC21000A 0200530A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001E740: BF8700A1
	v_cndmask_b16 v11, 0, v10, s2                              // 00000001E744: D65D000B 000A1480
	v_or_b32_e32 v10, 6, v50                                   // 00000001E74C: 38146486
	.long 0xd4440002                                           // 00000001E750: D4440002
	v_cndmask_b32_e32 v1, s31, v10, vcc_lo                     // 00000001E754: 0202141F
	v_mul_f32_e32 v10, 0x3b800000, v29                         // 00000001E758: 10143AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E760: BF870091
	v_sub_f32_e32 v10, v13, v10                                // 00000001E764: 0814150D
	v_fma_mixlo_f16 v10, v10, s41, 0                           // 00000001E768: CC21000A 0200530A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001E770: BF8700A1
	v_cndmask_b16 v11, 0, v10, s2                              // 00000001E774: D65D400B 000A1480
	v_or_b32_e32 v10, 8, v50                                   // 00000001E77C: 38146488
	.long 0xd4440002                                           // 00000001E780: D4440002
	v_cndmask_b32_e32 v1, s31, v10, vcc_lo                     // 00000001E784: 0202141F
	v_mul_f32_e32 v10, 0x3b800000, v30                         // 00000001E788: 10143CFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E790: BF870121
	v_sub_f32_e32 v10, v14, v10                                // 00000001E794: 0814150E
	v_mov_b32_e32 v14, 0x3020706                               // 00000001E798: 7E1C02FF 03020706
	v_fma_mixlo_f16 v10, v10, s41, 0                           // 00000001E7A0: CC21000A 0200530A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E7A8: BF870112
	v_cndmask_b32_e32 v14, 0x7060302, v14, vcc_lo              // 00000001E7AC: 021C1CFF 07060302
	v_cndmask_b16 v12, 0, v10, s2                              // 00000001E7B4: D65D000C 000A1480
	v_or_b32_e32 v10, 10, v50                                  // 00000001E7BC: 3814648A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001E7C0: BF8700A1
	.long 0xd4440002                                           // 00000001E7C4: D4440002
	v_cndmask_b32_e32 v1, s31, v10, vcc_lo                     // 00000001E7C8: 0202141F
	v_mul_f32_e32 v10, 0x3b800000, v31                         // 00000001E7CC: 10143EFF 3B800000
	v_dual_sub_f32 v10, v15, v10 :: v_dual_mov_b32 v15, v26    // 00000001E7D4: C950150F 0A0E011A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E7DC: BF870111
	v_fma_mixlo_f16 v10, v10, s41, 0                           // 00000001E7E0: CC21000A 0200530A
	v_permlanex16_b32 v15, v15, s44, 0xfedcba98                // 00000001E7E8: D65C000F 03FC590F FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001E7F4: BF8701A2
	v_cndmask_b16 v12, 0, v10, s2                              // 00000001E7F8: D65D400C 000A1480
	v_or_b32_e32 v10, 12, v50                                  // 00000001E800: 3814648C
	v_perm_b32 v56, v26, v15, v14                              // 00000001E804: D6440038 043A1F1A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001E80C: BF8700A2
	.long 0xd4440002                                           // 00000001E810: D4440002
	v_cndmask_b32_e32 v1, s31, v10, vcc_lo                     // 00000001E814: 0202141F
	v_mul_f32_e32 v10, 0x3b800000, v32                         // 00000001E818: 101440FF 3B800000
	v_sub_f32_e32 v10, v16, v10                                // 00000001E820: 08141510
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E824: BF870091
	v_fma_mixlo_f16 v10, v10, s41, 0                           // 00000001E828: CC21000A 0200530A
	v_cndmask_b16 v13, 0, v10, s2                              // 00000001E830: D65D000D 000A1480
	v_or_b32_e32 v10, 14, v50                                  // 00000001E838: 3814648E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001E83C: BF8700A1
	.long 0xd4440002                                           // 00000001E840: D4440002
	v_cndmask_b32_e32 v1, s31, v10, vcc_lo                     // 00000001E844: 0202141F
	v_mul_f32_e32 v10, 0x3b800000, v33                         // 00000001E848: 101442FF 3B800000
	v_sub_f32_e32 v10, v17, v10                                // 00000001E850: 08141511
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E854: BF870091
	v_fma_mixlo_f16 v10, v10, s41, 0                           // 00000001E858: CC21000A 0200530A
	v_cndmask_b16 v13, 0, v10, s2                              // 00000001E860: D65D400D 000A1480
	v_cndmask_b32_e32 v10, 0x5040100, v145, vcc_lo             // 00000001E868: 021522FF 05040100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000001E870: BF8700D1
	v_perm_b32 v55, v26, v15, v10                              // 00000001E874: D6440037 042A1F1A
	v_mov_b32_e32 v15, v11                                     // 00000001E87C: 7E1E030B
	ds_load_b128 v[26:29], v161 offset:23296                   // 00000001E880: DBFC5B00 1A0000A1
	ds_load_b128 v[30:33], v161 offset:23312                   // 00000001E888: DBFC5B10 1E0000A1
	v_permlanex16_b32 v15, v15, s44, 0xfedcba98                // 00000001E890: D65C000F 03FC590F FEDCBA98
	v_perm_b32 v57, v11, v15, v10                              // 00000001E89C: D6440039 042A1F0B
	v_perm_b32 v58, v11, v15, v14                              // 00000001E8A4: D644003A 043A1F0B
	v_mov_b32_e32 v11, v12                                     // 00000001E8AC: 7E16030C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E8B0: BF870091
	v_permlanex16_b32 v11, v11, s44, 0xfedcba98                // 00000001E8B4: D65C000B 03FC590B FEDCBA98
	v_perm_b32 v59, v12, v11, v10                              // 00000001E8C0: D644003B 042A170C
	v_perm_b32 v60, v12, v11, v14                              // 00000001E8C8: D644003C 043A170C
	v_mov_b32_e32 v11, v13                                     // 00000001E8D0: 7E16030D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E8D4: BF870091
	v_permlanex16_b32 v11, v11, s44, 0xfedcba98                // 00000001E8D8: D65C000B 03FC590B FEDCBA98
	v_perm_b32 v61, v13, v11, v10                              // 00000001E8E4: D644003D 042A170D
	v_perm_b32 v62, v13, v11, v14                              // 00000001E8EC: D644003E 043A170D
	s_waitcnt lgkmcnt(0)                                       // 00000001E8F4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001E8F8: BF8700A1
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[55:62], v[2:9]// 00000001E8FC: CC40400A 1C0A6F1A
	.long 0xd7000202                                           // 00000001E904: D7000202
	v_cndmask_b32_e32 v1, s36, v160, vcc_lo                    // 00000001E908: 02034024
	v_add_co_ci_u32_e64 v3, null, s37, 0, s2                   // 00000001E90C: D5207C03 00090025
	s_and_saveexec_b32 s2, s1                                  // 00000001E914: BE822001
	s_cbranch_execz 19                                         // 00000001E918: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4a68>
	ds_load_b32 v4, v158 offset:24320                          // 00000001E91C: D8D85F00 0400009E
	s_waitcnt lgkmcnt(0)                                       // 00000001E924: BF89FC07
	v_mul_f32_e32 v4, v18, v4                                  // 00000001E928: 10080912
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E92C: BF870091
	v_add_f32_e32 v4, v10, v4                                  // 00000001E930: 0608090A
	v_mul_f32_e32 v6, 0x3b800000, v4                           // 00000001E934: 100C08FF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v50, v[2:3]            // 00000001E93C: D6FE7C04 040A64FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E948: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000001E94C: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000001E954: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000001E960: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s2                              // 00000001E968: 8C7E027E
	v_or3_b32 v4, v157, s46, 2                                 // 00000001E96C: D6580004 02085D9D
	s_mov_b32 s1, exec_lo                                      // 00000001E974: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001E978: BF870001
	.long 0xd4c4007e                                           // 00000001E97C: D4C4007E
	v_cndmask_b32_e32 v1, s31, v4, vcc_lo                      // 00000001E980: 0202081F
	s_cbranch_execz 19                                         // 00000001E984: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4ad4>
	ds_load_b32 v5, v158 offset:24328                          // 00000001E988: D8D85F08 0500009E
	s_waitcnt lgkmcnt(0)                                       // 00000001E990: BF89FC07
	v_mul_f32_e32 v5, v19, v5                                  // 00000001E994: 100A0B13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E998: BF870091
	v_add_f32_e32 v5, v11, v5                                  // 00000001E99C: 060A0B0B
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000001E9A0: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000001E9A8: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E9B4: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000001E9B8: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000001E9C0: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000001E9CC: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001E9D4: 8C7E017E
	v_or3_b32 v4, v157, s46, 4                                 // 00000001E9D8: D6580004 02105D9D
	s_mov_b32 s1, exec_lo                                      // 00000001E9E0: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001E9E4: BF870001
	.long 0xd4c4007e                                           // 00000001E9E8: D4C4007E
	v_cndmask_b32_e32 v1, s31, v4, vcc_lo                      // 00000001E9EC: 0202081F
	s_cbranch_execz 19                                         // 00000001E9F0: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4b40>
	ds_load_b32 v5, v158 offset:24336                          // 00000001E9F4: D8D85F10 0500009E
	s_waitcnt lgkmcnt(0)                                       // 00000001E9FC: BF89FC07
	v_mul_f32_e32 v5, v20, v5                                  // 00000001EA00: 100A0B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EA04: BF870091
	v_add_f32_e32 v5, v12, v5                                  // 00000001EA08: 060A0B0C
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000001EA0C: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000001EA14: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EA20: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000001EA24: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000001EA2C: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000001EA38: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001EA40: 8C7E017E
	v_or3_b32 v4, v157, s46, 6                                 // 00000001EA44: D6580004 02185D9D
	s_mov_b32 s1, exec_lo                                      // 00000001EA4C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001EA50: BF870001
	.long 0xd4c4007e                                           // 00000001EA54: D4C4007E
	v_cndmask_b32_e32 v1, s31, v4, vcc_lo                      // 00000001EA58: 0202081F
	s_cbranch_execz 19                                         // 00000001EA5C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4bac>
	ds_load_b32 v5, v158 offset:24344                          // 00000001EA60: D8D85F18 0500009E
	s_waitcnt lgkmcnt(0)                                       // 00000001EA68: BF89FC07
	v_mul_f32_e32 v5, v21, v5                                  // 00000001EA6C: 100A0B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EA70: BF870091
	v_add_f32_e32 v5, v13, v5                                  // 00000001EA74: 060A0B0D
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000001EA78: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000001EA80: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EA8C: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000001EA90: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000001EA98: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000001EAA4: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001EAAC: 8C7E017E
	v_or3_b32 v4, v157, s46, 8                                 // 00000001EAB0: D6580004 02205D9D
	s_mov_b32 s1, exec_lo                                      // 00000001EAB8: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001EABC: BF870001
	.long 0xd4c4007e                                           // 00000001EAC0: D4C4007E
	v_cndmask_b32_e32 v1, s31, v4, vcc_lo                      // 00000001EAC4: 0202081F
	s_cbranch_execz 19                                         // 00000001EAC8: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4c18>
	ds_load_b32 v5, v158 offset:24352                          // 00000001EACC: D8D85F20 0500009E
	s_waitcnt lgkmcnt(0)                                       // 00000001EAD4: BF89FC07
	v_mul_f32_e32 v5, v22, v5                                  // 00000001EAD8: 100A0B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EADC: BF870091
	v_add_f32_e32 v5, v14, v5                                  // 00000001EAE0: 060A0B0E
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000001EAE4: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000001EAEC: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EAF8: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000001EAFC: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000001EB04: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000001EB10: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001EB18: 8C7E017E
	v_or3_b32 v4, v157, s46, 10                                // 00000001EB1C: D6580004 02285D9D
	s_mov_b32 s1, exec_lo                                      // 00000001EB24: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001EB28: BF870001
	.long 0xd4c4007e                                           // 00000001EB2C: D4C4007E
	v_cndmask_b32_e32 v1, s31, v4, vcc_lo                      // 00000001EB30: 0202081F
	s_cbranch_execz 19                                         // 00000001EB34: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4c84>
	ds_load_b32 v5, v158 offset:24360                          // 00000001EB38: D8D85F28 0500009E
	s_waitcnt lgkmcnt(0)                                       // 00000001EB40: BF89FC07
	v_mul_f32_e32 v5, v23, v5                                  // 00000001EB44: 100A0B17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EB48: BF870091
	v_add_f32_e32 v5, v15, v5                                  // 00000001EB4C: 060A0B0F
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000001EB50: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000001EB58: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EB64: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000001EB68: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000001EB70: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000001EB7C: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001EB84: 8C7E017E
	v_or3_b32 v4, v157, s46, 12                                // 00000001EB88: D6580004 02305D9D
	s_mov_b32 s1, exec_lo                                      // 00000001EB90: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001EB94: BF870001
	.long 0xd4c4007e                                           // 00000001EB98: D4C4007E
	v_cndmask_b32_e32 v1, s31, v4, vcc_lo                      // 00000001EB9C: 0202081F
	s_cbranch_execz 19                                         // 00000001EBA0: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4cf0>
	ds_load_b32 v5, v158 offset:24368                          // 00000001EBA4: D8D85F30 0500009E
	s_waitcnt lgkmcnt(0)                                       // 00000001EBAC: BF89FC07
	v_mul_f32_e32 v5, v24, v5                                  // 00000001EBB0: 100A0B18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EBB4: BF870091
	v_add_f32_e32 v5, v16, v5                                  // 00000001EBB8: 060A0B10
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000001EBBC: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000001EBC4: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EBD0: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000001EBD4: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000001EBDC: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000001EBE8: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001EBF0: 8C7E017E
	v_or3_b32 v4, v157, s46, 14                                // 00000001EBF4: D6580004 02385D9D
	s_mov_b32 s1, exec_lo                                      // 00000001EBFC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001EC00: BF870001
	.long 0xd4c4007e                                           // 00000001EC04: D4C4007E
	v_cndmask_b32_e32 v1, s31, v4, vcc_lo                      // 00000001EC08: 0202081F
	s_cbranch_execz 19                                         // 00000001EC0C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4d5c>
	ds_load_b32 v5, v158 offset:24376                          // 00000001EC10: D8D85F38 0500009E
	v_mad_u64_u32 v[2:3], null, 0x3000, v4, v[2:3]             // 00000001EC18: D6FE7C02 040A08FF 00003000
	s_waitcnt lgkmcnt(0)                                       // 00000001EC24: BF89FC07
	v_mul_f32_e32 v5, v25, v5                                  // 00000001EC28: 100A0B19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EC2C: BF870091
	v_add_f32_e32 v5, v17, v5                                  // 00000001EC30: 060A0B11
	v_mul_f32_e32 v5, 0x3b800000, v5                           // 00000001EC34: 100A0AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EC3C: BF870091
	v_bfe_u32 v6, v5, 16, 1                                    // 00000001EC40: D6100006 02052105
	v_add3_u32 v4, v5, v6, 0x7fff                              // 00000001EC48: D6550004 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000001EC54: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001EC5C: 8C7E017E
	ds_load_b32 v26, v1 offset:24188                           // 00000001EC60: D8D85E7C 1A000001
	v_mad_u32_u24 v2, v156, 48, 0x4b00                         // 00000001EC68: D60B0002 03FD619C 00004B00
	v_dual_mov_b32 v181, s27 :: v_dual_mov_b32 v178, s24       // 00000001EC74: CA10001B B5B20018
	v_dual_mov_b32 v176, s22 :: v_dual_mov_b32 v175, s21       // 00000001EC7C: CA100016 B0AE0015
	s_delay_alu instid0(VALU_DEP_3)                            // 00000001EC84: BF870003
	v_dual_mov_b32 v180, s26 :: v_dual_add_nc_u32 v27, 0xffffb500, v2// 00000001EC88: CA20001A B41A04FF FFFFB500
	v_mov_b32_e32 v174, s20                                    // 00000001EC94: 7F5C0214
	s_add_i32 s46, s46, 16                                     // 00000001EC98: 812E902E
	ds_load_b128 v[162:165], v27 offset:2320                   // 00000001EC9C: DBFC0910 A200001B
	ds_load_b128 v[158:161], v27 offset:2304                   // 00000001ECA4: DBFC0900 9E00001B
	ds_load_b128 v[170:173], v27 offset:3088                   // 00000001ECAC: DBFC0C10 AA00001B
	ds_load_b128 v[166:169], v27 offset:3072                   // 00000001ECB4: DBFC0C00 A600001B
	ds_load_b128 v[2:5], v27                                   // 00000001ECBC: DBFC0000 0200001B
	ds_load_b128 v[6:9], v27 offset:16                         // 00000001ECC4: DBFC0010 0600001B
	ds_load_b128 v[74:77], v27 offset:4608                     // 00000001ECCC: DBFC1200 4A00001B
	ds_load_b128 v[78:81], v27 offset:4624                     // 00000001ECD4: DBFC1210 4E00001B
	ds_load_b128 v[186:189], v27 offset:3856                   // 00000001ECDC: DBFC0F10 BA00001B
	ds_load_b128 v[182:185], v27 offset:3840                   // 00000001ECE4: DBFC0F00 B600001B
	v_mov_b32_e32 v179, s25                                    // 00000001ECEC: 7F660219
	v_mov_b32_e32 v177, s23                                    // 00000001ECF0: 7F620217
	s_waitcnt lgkmcnt(10)                                      // 00000001ECF4: BF89FCA7
	v_readfirstlane_b32 s1, v26                                // 00000001ECF8: 7E02051A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v26                  // 00000001ECFC: 7C3634FF C2CE8ED0
	s_mul_f32 s1, s1, 0x3fb8aa3b                               // 00000001ED04: A201FF01 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 00000001ED0C: BF87000B
	s_xor_b32 s2, s1, 0x80000000                               // 00000001ED10: 8D02FF01 80000000
	s_cmp_lg_u32 s12, s46                                      // 00000001ED18: BF072E0C
	v_fma_f32 v10, 0x3fb8aa3b, v26, s2                         // 00000001ED1C: D613000A 000A34FF 3FB8AA3B
	s_rndne_f32 s2, s1                                         // 00000001ED28: BE826301
	s_waitcnt lgkmcnt(4)                                       // 00000001ED2C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[47:54], v[2:9], v[55:62], v[174:181]// 00000001ED30: CC40402F 1EBA6F02
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001ED38: BF870002
	v_fmac_f32_e32 v10, 0x32a5705f, v26                        // 00000001ED3C: 561434FF 32A5705F
	s_sub_f32 s1, s1, s2                                       // 00000001ED44: A0810201
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_3)    // 00000001ED48: BF870581
	v_add_f32_e32 v28, s1, v10                                 // 00000001ED4C: 06381401
	ds_load_b128 v[14:17], v27 offset:784                      // 00000001ED50: DBFC0310 0E00001B
	ds_load_b128 v[10:13], v27 offset:768                      // 00000001ED58: DBFC0300 0A00001B
	ds_load_b128 v[22:25], v27 offset:1552                     // 00000001ED60: DBFC0610 1600001B
	ds_load_b128 v[18:21], v27 offset:1536                     // 00000001ED68: DBFC0600 1200001B
	s_cvt_i32_f32 s1, s2                                       // 00000001ED70: BE816602
	v_exp_f32_e32 v28, v28                                     // 00000001ED74: 7E384B1C
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_2) // 00000001ED78: BF870505
	.long 0xd71c001c                                           // 00000001ED7C: D71C001C
	v_cndmask_b32_e32 v0, v28, v1, vcc_lo                      // 00000001ED80: 0200031C
	s_waitcnt lgkmcnt(2)                                       // 00000001ED84: BF89FC27
	v_wmma_f32_16x16x16_f16 v[39:46], v[10:17], v[55:62], v[174:181]// 00000001ED88: CC404027 1EBA6F0A
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001ED90: BF870002
	v_cndmask_b32_e32 v2, 0, v28, vcc_lo                       // 00000001ED94: 02043880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v26                  // 00000001ED98: 7C3C34FF 42B17218
	v_wmma_f32_16x16x16_f16 v[10:17], v[158:165], v[55:62], v[174:181]// 00000001EDA0: CC40400A 1EBA6F9E
	ds_load_b128 v[162:165], v27 offset:5392                   // 00000001EDA8: DBFC1510 A200001B
	ds_load_b128 v[158:161], v27 offset:5376                   // 00000001EDB0: DBFC1500 9E00001B
	s_waitcnt lgkmcnt(0)                                       // 00000001EDB8: BF89FC07
	s_barrier                                                  // 00000001EDBC: BFBD0000
	v_cndmask_b32_e32 v63, 0x7f800000, v2, vcc_lo              // 00000001EDC0: 027E04FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000001EDC8: BF8701D1
	v_fmac_f32_e32 v17, v151, v63                              // 00000001EDCC: 56227F97
	s_waitcnt lgkmcnt(2)                                       // 00000001EDD0: BF89FC27
	v_wmma_f32_16x16x16_f16 v[31:38], v[18:25], v[55:62], v[174:181]// 00000001EDD4: CC40401F 1EBA6F12
	v_wmma_f32_16x16x16_f16 v[2:9], v[166:173], v[55:62], v[174:181]// 00000001EDDC: CC404002 1EBA6FA6
	v_wmma_f32_16x16x16_f16 v[18:25], v[182:189], v[55:62], v[174:181]// 00000001EDE4: CC404012 1EBA6FB6
	v_fma_f32 v122, v122, v63, v31                             // 00000001EDEC: D613007A 047E7F7A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000001EDF4: BF870004
	v_fma_f32 v121, v121, v63, v32                             // 00000001EDF8: D6130079 04827F79
	v_fma_f32 v120, v120, v63, v33                             // 00000001EE00: D6130078 04867F78
	v_fma_f32 v119, v119, v63, v34                             // 00000001EE08: D6130077 048A7F77
	v_fma_f32 v118, v118, v63, v35                             // 00000001EE10: D6130076 048E7F76
	v_fma_f32 v117, v117, v63, v36                             // 00000001EE18: D6130075 04927F75
	v_fma_f32 v116, v116, v63, v37                             // 00000001EE20: D6130074 04967F74
	v_wmma_f32_16x16x16_f16 v[30:37], v[74:81], v[55:62], v[174:181]// 00000001EE28: CC40401E 1EBA6F4A
	v_fma_f32 v136, v136, v63, v47                             // 00000001EE30: D6130088 04BE7F88
	v_fma_f32 v135, v135, v63, v48                             // 00000001EE38: D6130087 04C27F87
	v_fma_f32 v134, v134, v63, v49                             // 00000001EE40: D6130086 04C67F86
	s_delay_alu instid0(VALU_DEP_4)                            // 00000001EE48: BF870004
	v_fma_f32 v94, v94, v63, v30                               // 00000001EE4C: D613005E 047A7F5E
	v_fma_f32 v93, v93, v63, v31                               // 00000001EE54: D613005D 047E7F5D
	v_fma_f32 v92, v92, v63, v32                               // 00000001EE5C: D613005C 04827F5C
	v_fma_f32 v91, v91, v63, v33                               // 00000001EE64: D613005B 04867F5B
	s_waitcnt lgkmcnt(0)                                       // 00000001EE6C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[26:33], v[158:165], v[55:62], v[174:181]// 00000001EE70: CC40401A 1EBA6F9E
	v_fma_f32 v133, v133, v63, v50                             // 00000001EE78: D6130085 04CA7F85
	v_fma_f32 v132, v132, v63, v51                             // 00000001EE80: D6130084 04CE7F84
	v_fma_f32 v131, v131, v63, v52                             // 00000001EE88: D6130083 04D27F83
	v_fma_f32 v130, v130, v63, v53                             // 00000001EE90: D6130082 04D67F82
	v_fmac_f32_e32 v54, v154, v63                              // 00000001EE98: 566C7F9A
	v_fma_f32 v129, v129, v63, v39                             // 00000001EE9C: D6130081 049E7F81
	v_fma_f32 v128, v128, v63, v40                             // 00000001EEA4: D6130080 04A27F80
	v_fma_f32 v127, v127, v63, v41                             // 00000001EEAC: D613007F 04A67F7F
	v_fma_f32 v126, v126, v63, v42                             // 00000001EEB4: D613007E 04AA7F7E
	v_fma_f32 v125, v125, v63, v43                             // 00000001EEBC: D613007D 04AE7F7D
	v_fma_f32 v124, v124, v63, v44                             // 00000001EEC4: D613007C 04B27F7C
	v_fma_f32 v123, v123, v63, v45                             // 00000001EECC: D613007B 04B67F7B
	v_fmac_f32_e32 v46, v153, v63                              // 00000001EED4: 565C7F99
	v_fmac_f32_e32 v38, v152, v63                              // 00000001EED8: 564C7F98
	v_fma_f32 v115, v115, v63, v10                             // 00000001EEDC: D6130073 042A7F73
	v_fma_f32 v114, v114, v63, v11                             // 00000001EEE4: D6130072 042E7F72
	v_fma_f32 v113, v113, v63, v12                             // 00000001EEEC: D6130071 04327F71
	v_fma_f32 v112, v112, v63, v13                             // 00000001EEF4: D6130070 04367F70
	v_fma_f32 v111, v111, v63, v14                             // 00000001EEFC: D613006F 043A7F6F
	v_fma_f32 v110, v110, v63, v15                             // 00000001EF04: D613006E 043E7F6E
	v_fma_f32 v109, v109, v63, v16                             // 00000001EF0C: D613006D 04427F6D
	v_fma_f32 v108, v108, v63, v2                              // 00000001EF14: D613006C 040A7F6C
	v_fma_f32 v107, v107, v63, v3                              // 00000001EF1C: D613006B 040E7F6B
	v_fma_f32 v106, v106, v63, v4                              // 00000001EF24: D613006A 04127F6A
	v_fma_f32 v105, v105, v63, v5                              // 00000001EF2C: D6130069 04167F69
	v_fma_f32 v104, v104, v63, v6                              // 00000001EF34: D6130068 041A7F68
	v_fma_f32 v103, v103, v63, v7                              // 00000001EF3C: D6130067 041E7F67
	v_fma_f32 v102, v102, v63, v8                              // 00000001EF44: D6130066 04227F66
	v_fmac_f32_e32 v9, v150, v63                               // 00000001EF4C: 56127F96
	v_fma_f32 v101, v101, v63, v18                             // 00000001EF50: D6130065 044A7F65
	v_fma_f32 v100, v100, v63, v19                             // 00000001EF58: D6130064 044E7F64
	v_fma_f32 v99, v99, v63, v20                               // 00000001EF60: D6130063 04527F63
	v_fma_f32 v98, v98, v63, v21                               // 00000001EF68: D6130062 04567F62
	v_fma_f32 v97, v97, v63, v22                               // 00000001EF70: D6130061 045A7F61
	v_fma_f32 v96, v96, v63, v23                               // 00000001EF78: D6130060 045E7F60
	v_fma_f32 v95, v95, v63, v24                               // 00000001EF80: D613005F 04627F5F
	v_dual_fmac_f32 v25, v149, v63 :: v_dual_mul_f32 v150, 0x3b800000, v136// 00000001EF88: C8067F95 199710FF 3B800000
	v_fma_f32 v90, v90, v63, v34                               // 00000001EF94: D613005A 048A7F5A
	v_fma_f32 v89, v89, v63, v35                               // 00000001EF9C: D6130059 048E7F59
	v_fma_f32 v88, v88, v63, v36                               // 00000001EFA4: D6130058 04927F58
	v_dual_fmac_f32 v37, v148, v63 :: v_dual_mul_f32 v152, 0x3b800000, v134// 00000001EFAC: C8067F94 25990CFF 3B800000
	v_fma_f32 v87, v87, v63, v26                               // 00000001EFB8: D6130057 046A7F57
	v_fma_f32 v86, v86, v63, v27                               // 00000001EFC0: D6130056 046E7F56
	v_fma_f32 v85, v85, v63, v28                               // 00000001EFC8: D6130055 04727F55
	v_fma_f32 v84, v84, v63, v29                               // 00000001EFD0: D6130054 04767F54
	v_fma_f32 v83, v83, v63, v30                               // 00000001EFD8: D6130053 047A7F53
	v_fma_f32 v82, v82, v63, v31                               // 00000001EFE0: D6130052 047E7F52
	v_fma_f32 v143, v143, v63, v32                             // 00000001EFE8: D613008F 04827F8F
	v_dual_fmac_f32 v33, v147, v63 :: v_dual_mul_f32 v4, 0x3b800000, v132// 00000001EFF0: C8067F93 210508FF 3B800000
	v_lshl_add_u32 v2, v157, 7, v155                           // 00000001EFFC: D6460002 066D0F9D
	v_mul_f32_e32 v153, 0x3b800000, v133                       // 00000001F004: 11330AFF 3B800000
	v_dual_mul_f32 v151, 0x3b800000, v135 :: v_dual_mul_f32 v156, 0x3b800000, v54// 00000001F00C: C8C70EFF 979C6CFF 3B800000
	v_dual_mul_f32 v154, 0x3b800000, v131 :: v_dual_mul_f32 v149, 0x3b800000, v128// 00000001F018: C8C706FF 9A9500FF 3B800000
	v_mul_f32_e32 v155, 0x3b800000, v130                       // 00000001F024: 113704FF 3B800000
	v_mul_f32_e32 v5, 0x3b800000, v129                         // 00000001F02C: 100B02FF 3B800000
	v_dual_mul_f32 v63, 0x3b800000, v127 :: v_dual_mul_f32 v64, 0x3b800000, v126// 00000001F034: C8C6FEFF 3F40FCFF 3B800000
	v_dual_mul_f32 v6, 0x3b800000, v125 :: v_dual_mul_f32 v65, 0x3b800000, v124// 00000001F040: C8C6FAFF 0640F8FF 3B800000
	v_dual_mul_f32 v147, 0x3b800000, v123 :: v_dual_mul_f32 v148, 0x3b800000, v46// 00000001F04C: C8C6F6FF 93945CFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v122 :: v_dual_mul_f32 v60, 0x3b800000, v121// 00000001F058: C8C6F4FF 073CF2FF 3B800000
	v_dual_mul_f32 v61, 0x3b800000, v120 :: v_dual_mul_f32 v62, 0x3b800000, v119// 00000001F064: C8C6F0FF 3D3EEEFF 3B800000
	v_dual_mul_f32 v8, 0x3b800000, v118 :: v_dual_mul_f32 v53, 0x3b800000, v117// 00000001F070: C8C6ECFF 0834EAFF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v116 :: v_dual_mul_f32 v56, 0x3b800000, v38// 00000001F07C: C8C6E8FF 37384CFF 3B800000
	v_dual_mul_f32 v10, 0x3b800000, v115 :: v_dual_mul_f32 v57, 0x3b800000, v114// 00000001F088: C8C6E6FF 0A38E4FF 3B800000
	v_dual_mul_f32 v58, 0x3b800000, v113 :: v_dual_mul_f32 v59, 0x3b800000, v112// 00000001F094: C8C6E2FF 3A3AE0FF 3B800000
	v_dual_mul_f32 v11, 0x3b800000, v111 :: v_dual_mul_f32 v52, 0x3b800000, v109// 00000001F0A0: C8C6DEFF 0B34DAFF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v110 :: v_dual_mul_f32 v42, 0x3b800000, v17// 00000001F0AC: C8C6DCFF 332A22FF 3B800000
	v_dual_mul_f32 v12, 0x3b800000, v108 :: v_dual_mul_f32 v45, 0x3b800000, v106// 00000001F0B8: C8C6D8FF 0C2CD4FF 3B800000
	v_dual_mul_f32 v44, 0x3b800000, v107 :: v_dual_mul_f32 v47, 0x3b800000, v105// 00000001F0C4: C8C6D6FF 2C2ED2FF 3B800000
	v_dual_mul_f32 v14, 0x3b800000, v104 :: v_dual_mul_f32 v49, 0x3b800000, v102// 00000001F0D0: C8C6D0FF 0E30CCFF 3B800000
	v_dual_mul_f32 v48, 0x3b800000, v103 :: v_dual_mul_f32 v15, 0x3b800000, v101// 00000001F0DC: C8C6CEFF 300ECAFF 3B800000
	v_dual_mul_f32 v50, 0x3b800000, v9 :: v_dual_mul_f32 v43, 0x3b800000, v100// 00000001F0E8: C8C612FF 322AC8FF 3B800000
	v_dual_mul_f32 v35, 0x3b800000, v99 :: v_dual_mul_f32 v36, 0x3b800000, v98// 00000001F0F4: C8C6C6FF 2324C4FF 3B800000
	v_dual_mul_f32 v27, 0x3b800000, v97 :: v_dual_mul_f32 v40, 0x3b800000, v95// 00000001F100: C8C6C2FF 1B28BEFF 3B800000
	v_dual_mul_f32 v39, 0x3b800000, v96 :: v_dual_mul_f32 v28, 0x3b800000, v94// 00000001F10C: C8C6C0FF 271CBCFF 3B800000
	v_dual_mul_f32 v41, 0x3b800000, v25 :: v_dual_mul_f32 v32, 0x3b800000, v92// 00000001F118: C8C632FF 2920B8FF 3B800000
	v_dual_mul_f32 v31, 0x3b800000, v93 :: v_dual_mul_f32 v34, 0x3b800000, v91// 00000001F124: C8C6BAFF 1F22B6FF 3B800000
	v_dual_mul_f32 v29, 0x3b800000, v90 :: v_dual_mul_f32 v20, 0x3b800000, v89// 00000001F130: C8C6B4FF 1D14B2FF 3B800000
	v_dual_mul_f32 v21, 0x3b800000, v88 :: v_dual_mul_f32 v22, 0x3b800000, v37// 00000001F13C: C8C6B0FF 15164AFF 3B800000
	v_dual_mul_f32 v30, 0x3b800000, v87 :: v_dual_mul_f32 v23, 0x3b800000, v86// 00000001F148: C8C6AEFF 1E16ACFF 3B800000
	v_dual_mul_f32 v24, 0x3b800000, v85 :: v_dual_mul_f32 v19, 0x3b800000, v143// 00000001F154: C8C6AAFF 18131EFF 3B800000
	v_dual_mul_f32 v26, 0x3b800000, v84 :: v_dual_mul_f32 v13, 0x3b800000, v33// 00000001F160: C8C6A8FF 1A0C42FF 3B800000
	v_mul_f32_e32 v16, 0x3b800000, v83                         // 00000001F16C: 1020A6FF 3B800000
	v_mul_f32_e32 v18, 0x3b800000, v82                         // 00000001F174: 1024A4FF 3B800000
	s_cbranch_scc0 5                                           // 00000001F17C: BFA10005 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5294>
	s_cmp_lg_u32 s13, s46                                      // 00000001F180: BF072E0D
	s_cbranch_scc0 273                                         // 00000001F184: BFA10111 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x56cc>
	s_cmp_lg_u32 s14, s46                                      // 00000001F188: BF072E0E
	s_cbranch_scc1 60829                                       // 00000001F18C: BFA2ED9D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x904>
	s_branch 540                                               // 00000001F190: BFA0021C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5b04>
	v_mov_b32_e32 v74, v2                                      // 00000001F194: 7E940302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F198: BF870091
	v_ashrrev_i32_e32 v75, 31, v74                             // 00000001F19C: 3496949F
	.long 0xd73c004a                                           // 00000001F1A0: D73C004A
	v_cndmask_b32_e32 v1, 2, v74, vcc_lo                       // 00000001F1A4: 02029482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F1A8: BF870091
	.long 0xd7006a4a                                           // 00000001F1AC: D7006A4A
	v_cndmask_b32_e32 v1, s16, v74, vcc_lo                     // 00000001F1B0: 02029410
	v_add_co_ci_u32_e64 v75, null, s17, v75, vcc_lo            // 00000001F1B4: D5207C4B 01AA9611
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F1BC: BF870092
	.long 0xd7006a4c                                           // 00000001F1C0: D7006A4C
	v_cndmask_b32_e32 v1, 0x1000, v74, vcc_lo                  // 00000001F1C4: 020294FF 00001000
	v_add_co_ci_u32_e64 v77, null, 0, v75, vcc_lo              // 00000001F1CC: D5207C4D 01AA9680
	.long 0xd7006a4e                                           // 00000001F1D4: D7006A4E
	v_cndmask_b32_e32 v0, v74, v255, vcc_lo                    // 00000001F1D8: 0201FF4A
	.long 0x00002000                                           // 00000001F1DC: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F1E0: BF8700A1
	v_add_co_ci_u32_e64 v79, null, 0, v75, vcc_lo              // 00000001F1E4: D5207C4F 01AA9680
	.long 0xd7006a50                                           // 00000001F1EC: D7006A50
	v_cndmask_b32_e32 v1, 0x2000, v74, vcc_lo                  // 00000001F1F0: 020294FF 00002000
	v_add_co_ci_u32_e64 v81, null, 0, v75, vcc_lo              // 00000001F1F8: D5207C51 01AA9680
	s_clause 0x7                                               // 00000001F200: BF850007
	global_store_b32 v[74:75], v150, off                       // 00000001F204: DC6A0000 007C964A
	global_store_b32 v[74:75], v151, off offset:1024           // 00000001F20C: DC6A0400 007C974A
	global_store_b32 v[74:75], v152, off offset:2048           // 00000001F214: DC6A0800 007C984A
	global_store_b32 v[74:75], v153, off offset:3072           // 00000001F21C: DC6A0C00 007C994A
	global_store_b32 v[76:77], v154, off offset:1024           // 00000001F224: DC6A0400 007C9A4C
	global_store_b32 v[76:77], v155, off offset:2048           // 00000001F22C: DC6A0800 007C9B4C
	global_store_b32 v[76:77], v156, off offset:3072           // 00000001F234: DC6A0C00 007C9C4C
	global_store_b32 v[80:81], v149, off offset:1024           // 00000001F23C: DC6A0400 007C9550
	.long 0xd7006a4c                                           // 00000001F244: D7006A4C
	v_cndmask_b32_e32 v1, 0x3000, v74, vcc_lo                  // 00000001F248: 020294FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F250: BF8700A1
	v_add_co_ci_u32_e64 v77, null, 0, v75, vcc_lo              // 00000001F254: D5207C4D 01AA9680
	.long 0xd7006a9d                                           // 00000001F25C: D7006A9D
	v_cndmask_b32_e32 v0, v74, v255, vcc_lo                    // 00000001F260: 0201FF4A
	.long 0x00004000                                           // 00000001F264: 00004000
	v_add_co_ci_u32_e64 v158, null, 0, v75, vcc_lo             // 00000001F268: D5207C9E 01AA9680
	.long 0xd7006a9f                                           // 00000001F270: D7006A9F
	v_cndmask_b32_e32 v1, 0x4000, v74, vcc_lo                  // 00000001F274: 020294FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001F27C: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v75, vcc_lo             // 00000001F280: D5207CA0 01AA9680
	s_clause 0x7                                               // 00000001F288: BF850007
	global_store_b32 v[80:81], v63, off offset:2048            // 00000001F28C: DC6A0800 007C3F50
	global_store_b32 v[80:81], v64, off offset:3072            // 00000001F294: DC6A0C00 007C4050
	global_store_b32 v[76:77], v65, off offset:1024            // 00000001F29C: DC6A0400 007C414C
	global_store_b32 v[76:77], v147, off offset:2048           // 00000001F2A4: DC6A0800 007C934C
	global_store_b32 v[76:77], v148, off offset:3072           // 00000001F2AC: DC6A0C00 007C944C
	global_store_b32 v[159:160], v60, off offset:1024          // 00000001F2B4: DC6A0400 007C3C9F
	global_store_b32 v[159:160], v61, off offset:2048          // 00000001F2BC: DC6A0800 007C3D9F
	global_store_b32 v[159:160], v62, off offset:3072          // 00000001F2C4: DC6A0C00 007C3E9F
	.long 0xd7006a4c                                           // 00000001F2CC: D7006A4C
	v_cndmask_b32_e32 v1, 0x5000, v74, vcc_lo                  // 00000001F2D0: 020294FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F2D8: BF8700A1
	v_add_co_ci_u32_e64 v77, null, 0, v75, vcc_lo              // 00000001F2DC: D5207C4D 01AA9680
	.long 0xd7006a50                                           // 00000001F2E4: D7006A50
	v_cndmask_b32_e32 v0, v74, v255, vcc_lo                    // 00000001F2E8: 0201FF4A
	.long 0x00006000                                           // 00000001F2EC: 00006000
	v_add_co_ci_u32_e64 v81, null, 0, v75, vcc_lo              // 00000001F2F0: D5207C51 01AA9680
	.long 0xd7006a9f                                           // 00000001F2F8: D7006A9F
	v_cndmask_b32_e32 v1, 0x6000, v74, vcc_lo                  // 00000001F2FC: 020294FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F304: BF8700A1
	v_add_co_ci_u32_e64 v160, null, 0, v75, vcc_lo             // 00000001F308: D5207CA0 01AA9680
	.long 0xd7006aa1                                           // 00000001F310: D7006AA1
	v_cndmask_b32_e32 v1, 0x7000, v74, vcc_lo                  // 00000001F314: 020294FF 00007000
	v_add_co_ci_u32_e64 v162, null, 0, v75, vcc_lo             // 00000001F31C: D5207CA2 01AA9680
	.long 0xd7006aa3                                           // 00000001F324: D7006AA3
	v_cndmask_b32_e32 v0, v74, v255, vcc_lo                    // 00000001F328: 0201FF4A
	.long 0x00008000                                           // 00000001F32C: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001F330: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v75, vcc_lo             // 00000001F334: D5207CA4 01AA9680
	s_clause 0x7                                               // 00000001F33C: BF850007
	global_store_b32 v[76:77], v53, off offset:1024            // 00000001F340: DC6A0400 007C354C
	global_store_b32 v[76:77], v55, off offset:2048            // 00000001F348: DC6A0800 007C374C
	global_store_b32 v[76:77], v56, off offset:3072            // 00000001F350: DC6A0C00 007C384C
	global_store_b32 v[159:160], v57, off offset:1024          // 00000001F358: DC6A0400 007C399F
	global_store_b32 v[159:160], v58, off offset:2048          // 00000001F360: DC6A0800 007C3A9F
	global_store_b32 v[159:160], v59, off offset:3072          // 00000001F368: DC6A0C00 007C3B9F
	global_store_b32 v[161:162], v51, off offset:1024          // 00000001F370: DC6A0400 007C33A1
	global_store_b32 v[161:162], v52, off offset:2048          // 00000001F378: DC6A0800 007C34A1
	.long 0xd7006a4c                                           // 00000001F380: D7006A4C
	v_cndmask_b32_e32 v1, 0x8000, v74, vcc_lo                  // 00000001F384: 020294FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F38C: BF8700A1
	v_add_co_ci_u32_e64 v77, null, 0, v75, vcc_lo              // 00000001F390: D5207C4D 01AA9680
	.long 0xd7006a9f                                           // 00000001F398: D7006A9F
	v_cndmask_b32_e32 v1, 0x9000, v74, vcc_lo                  // 00000001F39C: 020294FF 00009000
	v_add_co_ci_u32_e64 v160, null, 0, v75, vcc_lo             // 00000001F3A4: D5207CA0 01AA9680
	.long 0xd7006aa5                                           // 00000001F3AC: D7006AA5
	v_cndmask_b32_e32 v0, v74, v255, vcc_lo                    // 00000001F3B0: 0201FF4A
	.long 0x0000a000                                           // 00000001F3B4: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F3B8: BF8700A1
	v_add_co_ci_u32_e64 v166, null, 0, v75, vcc_lo             // 00000001F3BC: D5207CA6 01AA9680
	.long 0xd7006aa7                                           // 00000001F3C4: D7006AA7
	v_cndmask_b32_e32 v1, 0xa000, v74, vcc_lo                  // 00000001F3C8: 020294FF 0000A000
	v_add_co_ci_u32_e64 v168, null, 0, v75, vcc_lo             // 00000001F3D0: D5207CA8 01AA9680
	s_clause 0x7                                               // 00000001F3D8: BF850007
	global_store_b32 v[161:162], v42, off offset:3072          // 00000001F3DC: DC6A0C00 007C2AA1
	global_store_b32 v[76:77], v44, off offset:1024            // 00000001F3E4: DC6A0400 007C2C4C
	global_store_b32 v[76:77], v45, off offset:2048            // 00000001F3EC: DC6A0800 007C2D4C
	global_store_b32 v[76:77], v47, off offset:3072            // 00000001F3F4: DC6A0C00 007C2F4C
	global_store_b32 v[159:160], v48, off offset:1024          // 00000001F3FC: DC6A0400 007C309F
	global_store_b32 v[159:160], v49, off offset:2048          // 00000001F404: DC6A0800 007C319F
	global_store_b32 v[159:160], v50, off offset:3072          // 00000001F40C: DC6A0C00 007C329F
	global_store_b32 v[167:168], v43, off offset:1024          // 00000001F414: DC6A0400 007C2BA7
	.long 0xd7006a4c                                           // 00000001F41C: D7006A4C
	v_cndmask_b32_e32 v1, 0xb000, v74, vcc_lo                  // 00000001F420: 020294FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F428: BF8700A1
	v_add_co_ci_u32_e64 v77, null, 0, v75, vcc_lo              // 00000001F42C: D5207C4D 01AA9680
	.long 0xd7006a9f                                           // 00000001F434: D7006A9F
	v_cndmask_b32_e32 v0, v74, v255, vcc_lo                    // 00000001F438: 0201FF4A
	.long 0x0000c000                                           // 00000001F43C: 0000C000
	v_add_co_ci_u32_e64 v160, null, 0, v75, vcc_lo             // 00000001F440: D5207CA0 01AA9680
	.long 0xd7006aa1                                           // 00000001F448: D7006AA1
	v_cndmask_b32_e32 v1, 0xc000, v74, vcc_lo                  // 00000001F44C: 020294FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001F454: BF870001
	v_add_co_ci_u32_e64 v162, null, 0, v75, vcc_lo             // 00000001F458: D5207CA2 01AA9680
	s_clause 0x7                                               // 00000001F460: BF850007
	global_store_b32 v[167:168], v35, off offset:2048          // 00000001F464: DC6A0800 007C23A7
	global_store_b32 v[167:168], v36, off offset:3072          // 00000001F46C: DC6A0C00 007C24A7
	global_store_b32 v[76:77], v39, off offset:1024            // 00000001F474: DC6A0400 007C274C
	global_store_b32 v[76:77], v40, off offset:2048            // 00000001F47C: DC6A0800 007C284C
	global_store_b32 v[76:77], v41, off offset:3072            // 00000001F484: DC6A0C00 007C294C
	global_store_b32 v[161:162], v31, off offset:1024          // 00000001F48C: DC6A0400 007C1FA1
	global_store_b32 v[161:162], v32, off offset:2048          // 00000001F494: DC6A0800 007C20A1
	global_store_b32 v[161:162], v34, off offset:3072          // 00000001F49C: DC6A0C00 007C22A1
	.long 0xd7006a4c                                           // 00000001F4A4: D7006A4C
	v_cndmask_b32_e32 v1, 0xd000, v74, vcc_lo                  // 00000001F4A8: 020294FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F4B0: BF8700A1
	v_add_co_ci_u32_e64 v77, null, 0, v75, vcc_lo              // 00000001F4B4: D5207C4D 01AA9680
	.long 0xd7006aa1                                           // 00000001F4BC: D7006AA1
	v_cndmask_b32_e32 v0, v74, v255, vcc_lo                    // 00000001F4C0: 0201FF4A
	.long 0x0000e000                                           // 00000001F4C4: 0000E000
	v_add_co_ci_u32_e64 v162, null, 0, v75, vcc_lo             // 00000001F4C8: D5207CA2 01AA9680
	.long 0xd7006aa7                                           // 00000001F4D0: D7006AA7
	v_cndmask_b32_e32 v1, 0xe000, v74, vcc_lo                  // 00000001F4D4: 020294FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001F4DC: BF870001
	v_add_co_ci_u32_e64 v168, null, 0, v75, vcc_lo             // 00000001F4E0: D5207CA8 01AA9680
	.long 0xd7006a4a                                           // 00000001F4E8: D7006A4A
	v_cndmask_b32_e32 v1, 0xf000, v74, vcc_lo                  // 00000001F4EC: 020294FF 0000F000
	s_clause 0x7                                               // 00000001F4F4: BF850007
	global_store_b32 v[163:164], v11, off offset:-4096         // 00000001F4F8: DC6A1000 007C0BA3
	global_store_b32 v[163:164], v12, off                      // 00000001F500: DC6A0000 007C0CA3
	global_store_b32 v[165:166], v14, off offset:-4096         // 00000001F508: DC6A1000 007C0EA5
	global_store_b32 v[165:166], v15, off                      // 00000001F510: DC6A0000 007C0FA5
	global_store_b32 v[159:160], v27, off offset:-4096         // 00000001F518: DC6A1000 007C1B9F
	global_store_b32 v[159:160], v28, off                      // 00000001F520: DC6A0000 007C1C9F
	global_store_b32 v[161:162], v29, off offset:-4096         // 00000001F528: DC6A1000 007C1DA1
	global_store_b32 v[161:162], v30, off                      // 00000001F530: DC6A0000 007C1EA1
	v_add_co_ci_u32_e64 v75, null, 0, v75, vcc_lo              // 00000001F538: D5207C4B 01AA9680
	s_clause 0xf                                               // 00000001F540: BF85000F
	global_store_b32 v[76:77], v20, off offset:1024            // 00000001F544: DC6A0400 007C144C
	global_store_b32 v[76:77], v21, off offset:2048            // 00000001F54C: DC6A0800 007C154C
	global_store_b32 v[76:77], v22, off offset:3072            // 00000001F554: DC6A0C00 007C164C
	global_store_b32 v[167:168], v23, off offset:1024          // 00000001F55C: DC6A0400 007C17A7
	global_store_b32 v[167:168], v24, off offset:2048          // 00000001F564: DC6A0800 007C18A7
	global_store_b32 v[167:168], v26, off offset:3072          // 00000001F56C: DC6A0C00 007C1AA7
	global_store_b32 v[74:75], v16, off                        // 00000001F574: DC6A0000 007C104A
	global_store_b32 v[74:75], v18, off offset:1024            // 00000001F57C: DC6A0400 007C124A
	global_store_b32 v[74:75], v19, off offset:2048            // 00000001F584: DC6A0800 007C134A
	global_store_b32 v[78:79], v4, off offset:-4096            // 00000001F58C: DC6A1000 007C044E
	global_store_b32 v[78:79], v5, off                         // 00000001F594: DC6A0000 007C054E
	global_store_b32 v[157:158], v6, off offset:-4096          // 00000001F59C: DC6A1000 007C069D
	global_store_b32 v[157:158], v7, off                       // 00000001F5A4: DC6A0000 007C079D
	global_store_b32 v[80:81], v8, off offset:-4096            // 00000001F5AC: DC6A1000 007C0850
	global_store_b32 v[80:81], v10, off                        // 00000001F5B4: DC6A0000 007C0A50
	global_store_b32 v[74:75], v13, off offset:3072            // 00000001F5BC: DC6A0C00 007C0D4A
	s_cmp_lg_u32 s13, s46                                      // 00000001F5C4: BF072E0D
	s_cbranch_scc1 65263                                       // 00000001F5C8: BFA2FEEF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5288>
	v_mov_b32_e32 v74, v2                                      // 00000001F5CC: 7E940302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F5D0: BF870091
	v_ashrrev_i32_e32 v75, 31, v74                             // 00000001F5D4: 3496949F
	.long 0xd73c004a                                           // 00000001F5D8: D73C004A
	v_cndmask_b32_e32 v1, 2, v74, vcc_lo                       // 00000001F5DC: 02029482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F5E0: BF870091
	.long 0xd7006a4a                                           // 00000001F5E4: D7006A4A
	v_cndmask_b32_e32 v1, s18, v74, vcc_lo                     // 00000001F5E8: 02029412
	v_add_co_ci_u32_e64 v75, null, s19, v75, vcc_lo            // 00000001F5EC: D5207C4B 01AA9613
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F5F4: BF870092
	.long 0xd7006a4c                                           // 00000001F5F8: D7006A4C
	v_cndmask_b32_e32 v1, 0x1000, v74, vcc_lo                  // 00000001F5FC: 020294FF 00001000
	v_add_co_ci_u32_e64 v77, null, 0, v75, vcc_lo              // 00000001F604: D5207C4D 01AA9680
	.long 0xd7006a4e                                           // 00000001F60C: D7006A4E
	v_cndmask_b32_e32 v0, v74, v255, vcc_lo                    // 00000001F610: 0201FF4A
	.long 0x00002000                                           // 00000001F614: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F618: BF8700A1
	v_add_co_ci_u32_e64 v79, null, 0, v75, vcc_lo              // 00000001F61C: D5207C4F 01AA9680
	.long 0xd7006a50                                           // 00000001F624: D7006A50
	v_cndmask_b32_e32 v1, 0x2000, v74, vcc_lo                  // 00000001F628: 020294FF 00002000
	v_add_co_ci_u32_e64 v81, null, 0, v75, vcc_lo              // 00000001F630: D5207C51 01AA9680
	s_clause 0x7                                               // 00000001F638: BF850007
	global_store_b32 v[74:75], v150, off                       // 00000001F63C: DC6A0000 007C964A
	global_store_b32 v[74:75], v151, off offset:1024           // 00000001F644: DC6A0400 007C974A
	global_store_b32 v[74:75], v152, off offset:2048           // 00000001F64C: DC6A0800 007C984A
	global_store_b32 v[74:75], v153, off offset:3072           // 00000001F654: DC6A0C00 007C994A
	global_store_b32 v[76:77], v154, off offset:1024           // 00000001F65C: DC6A0400 007C9A4C
	global_store_b32 v[76:77], v155, off offset:2048           // 00000001F664: DC6A0800 007C9B4C
	global_store_b32 v[76:77], v156, off offset:3072           // 00000001F66C: DC6A0C00 007C9C4C
	global_store_b32 v[80:81], v149, off offset:1024           // 00000001F674: DC6A0400 007C9550
	.long 0xd7006a4c                                           // 00000001F67C: D7006A4C
	v_cndmask_b32_e32 v1, 0x3000, v74, vcc_lo                  // 00000001F680: 020294FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F688: BF8700A1
	v_add_co_ci_u32_e64 v77, null, 0, v75, vcc_lo              // 00000001F68C: D5207C4D 01AA9680
	.long 0xd7006a9d                                           // 00000001F694: D7006A9D
	v_cndmask_b32_e32 v0, v74, v255, vcc_lo                    // 00000001F698: 0201FF4A
	.long 0x00004000                                           // 00000001F69C: 00004000
	v_add_co_ci_u32_e64 v158, null, 0, v75, vcc_lo             // 00000001F6A0: D5207C9E 01AA9680
	.long 0xd7006a9f                                           // 00000001F6A8: D7006A9F
	v_cndmask_b32_e32 v1, 0x4000, v74, vcc_lo                  // 00000001F6AC: 020294FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001F6B4: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v75, vcc_lo             // 00000001F6B8: D5207CA0 01AA9680
	s_clause 0x7                                               // 00000001F6C0: BF850007
	global_store_b32 v[80:81], v63, off offset:2048            // 00000001F6C4: DC6A0800 007C3F50
	global_store_b32 v[80:81], v64, off offset:3072            // 00000001F6CC: DC6A0C00 007C4050
	global_store_b32 v[76:77], v65, off offset:1024            // 00000001F6D4: DC6A0400 007C414C
	global_store_b32 v[76:77], v147, off offset:2048           // 00000001F6DC: DC6A0800 007C934C
	global_store_b32 v[76:77], v148, off offset:3072           // 00000001F6E4: DC6A0C00 007C944C
	global_store_b32 v[159:160], v60, off offset:1024          // 00000001F6EC: DC6A0400 007C3C9F
	global_store_b32 v[159:160], v61, off offset:2048          // 00000001F6F4: DC6A0800 007C3D9F
	global_store_b32 v[159:160], v62, off offset:3072          // 00000001F6FC: DC6A0C00 007C3E9F
	.long 0xd7006a4c                                           // 00000001F704: D7006A4C
	v_cndmask_b32_e32 v1, 0x5000, v74, vcc_lo                  // 00000001F708: 020294FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F710: BF8700A1
	v_add_co_ci_u32_e64 v77, null, 0, v75, vcc_lo              // 00000001F714: D5207C4D 01AA9680
	.long 0xd7006a50                                           // 00000001F71C: D7006A50
	v_cndmask_b32_e32 v0, v74, v255, vcc_lo                    // 00000001F720: 0201FF4A
	.long 0x00006000                                           // 00000001F724: 00006000
	v_add_co_ci_u32_e64 v81, null, 0, v75, vcc_lo              // 00000001F728: D5207C51 01AA9680
	.long 0xd7006a9f                                           // 00000001F730: D7006A9F
	v_cndmask_b32_e32 v1, 0x6000, v74, vcc_lo                  // 00000001F734: 020294FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F73C: BF8700A1
	v_add_co_ci_u32_e64 v160, null, 0, v75, vcc_lo             // 00000001F740: D5207CA0 01AA9680
	.long 0xd7006aa1                                           // 00000001F748: D7006AA1
	v_cndmask_b32_e32 v1, 0x7000, v74, vcc_lo                  // 00000001F74C: 020294FF 00007000
	v_add_co_ci_u32_e64 v162, null, 0, v75, vcc_lo             // 00000001F754: D5207CA2 01AA9680
	.long 0xd7006aa3                                           // 00000001F75C: D7006AA3
	v_cndmask_b32_e32 v0, v74, v255, vcc_lo                    // 00000001F760: 0201FF4A
	.long 0x00008000                                           // 00000001F764: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001F768: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v75, vcc_lo             // 00000001F76C: D5207CA4 01AA9680
	s_clause 0x7                                               // 00000001F774: BF850007
	global_store_b32 v[76:77], v53, off offset:1024            // 00000001F778: DC6A0400 007C354C
	global_store_b32 v[76:77], v55, off offset:2048            // 00000001F780: DC6A0800 007C374C
	global_store_b32 v[76:77], v56, off offset:3072            // 00000001F788: DC6A0C00 007C384C
	global_store_b32 v[159:160], v57, off offset:1024          // 00000001F790: DC6A0400 007C399F
	global_store_b32 v[159:160], v58, off offset:2048          // 00000001F798: DC6A0800 007C3A9F
	global_store_b32 v[159:160], v59, off offset:3072          // 00000001F7A0: DC6A0C00 007C3B9F
	global_store_b32 v[161:162], v51, off offset:1024          // 00000001F7A8: DC6A0400 007C33A1
	global_store_b32 v[161:162], v52, off offset:2048          // 00000001F7B0: DC6A0800 007C34A1
	.long 0xd7006a4c                                           // 00000001F7B8: D7006A4C
	v_cndmask_b32_e32 v1, 0x8000, v74, vcc_lo                  // 00000001F7BC: 020294FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F7C4: BF8700A1
	v_add_co_ci_u32_e64 v77, null, 0, v75, vcc_lo              // 00000001F7C8: D5207C4D 01AA9680
	.long 0xd7006a9f                                           // 00000001F7D0: D7006A9F
	v_cndmask_b32_e32 v1, 0x9000, v74, vcc_lo                  // 00000001F7D4: 020294FF 00009000
	v_add_co_ci_u32_e64 v160, null, 0, v75, vcc_lo             // 00000001F7DC: D5207CA0 01AA9680
	.long 0xd7006aa5                                           // 00000001F7E4: D7006AA5
	v_cndmask_b32_e32 v0, v74, v255, vcc_lo                    // 00000001F7E8: 0201FF4A
	.long 0x0000a000                                           // 00000001F7EC: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F7F0: BF8700A1
	v_add_co_ci_u32_e64 v166, null, 0, v75, vcc_lo             // 00000001F7F4: D5207CA6 01AA9680
	.long 0xd7006aa7                                           // 00000001F7FC: D7006AA7
	v_cndmask_b32_e32 v1, 0xa000, v74, vcc_lo                  // 00000001F800: 020294FF 0000A000
	v_add_co_ci_u32_e64 v168, null, 0, v75, vcc_lo             // 00000001F808: D5207CA8 01AA9680
	s_clause 0x7                                               // 00000001F810: BF850007
	global_store_b32 v[161:162], v42, off offset:3072          // 00000001F814: DC6A0C00 007C2AA1
	global_store_b32 v[76:77], v44, off offset:1024            // 00000001F81C: DC6A0400 007C2C4C
	global_store_b32 v[76:77], v45, off offset:2048            // 00000001F824: DC6A0800 007C2D4C
	global_store_b32 v[76:77], v47, off offset:3072            // 00000001F82C: DC6A0C00 007C2F4C
	global_store_b32 v[159:160], v48, off offset:1024          // 00000001F834: DC6A0400 007C309F
	global_store_b32 v[159:160], v49, off offset:2048          // 00000001F83C: DC6A0800 007C319F
	global_store_b32 v[159:160], v50, off offset:3072          // 00000001F844: DC6A0C00 007C329F
	global_store_b32 v[167:168], v43, off offset:1024          // 00000001F84C: DC6A0400 007C2BA7
	.long 0xd7006a4c                                           // 00000001F854: D7006A4C
	v_cndmask_b32_e32 v1, 0xb000, v74, vcc_lo                  // 00000001F858: 020294FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F860: BF8700A1
	v_add_co_ci_u32_e64 v77, null, 0, v75, vcc_lo              // 00000001F864: D5207C4D 01AA9680
	.long 0xd7006a9f                                           // 00000001F86C: D7006A9F
	v_cndmask_b32_e32 v0, v74, v255, vcc_lo                    // 00000001F870: 0201FF4A
	.long 0x0000c000                                           // 00000001F874: 0000C000
	v_add_co_ci_u32_e64 v160, null, 0, v75, vcc_lo             // 00000001F878: D5207CA0 01AA9680
	.long 0xd7006aa1                                           // 00000001F880: D7006AA1
	v_cndmask_b32_e32 v1, 0xc000, v74, vcc_lo                  // 00000001F884: 020294FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001F88C: BF870001
	v_add_co_ci_u32_e64 v162, null, 0, v75, vcc_lo             // 00000001F890: D5207CA2 01AA9680
	s_clause 0x7                                               // 00000001F898: BF850007
	global_store_b32 v[167:168], v35, off offset:2048          // 00000001F89C: DC6A0800 007C23A7
	global_store_b32 v[167:168], v36, off offset:3072          // 00000001F8A4: DC6A0C00 007C24A7
	global_store_b32 v[76:77], v39, off offset:1024            // 00000001F8AC: DC6A0400 007C274C
	global_store_b32 v[76:77], v40, off offset:2048            // 00000001F8B4: DC6A0800 007C284C
	global_store_b32 v[76:77], v41, off offset:3072            // 00000001F8BC: DC6A0C00 007C294C
	global_store_b32 v[161:162], v31, off offset:1024          // 00000001F8C4: DC6A0400 007C1FA1
	global_store_b32 v[161:162], v32, off offset:2048          // 00000001F8CC: DC6A0800 007C20A1
	global_store_b32 v[161:162], v34, off offset:3072          // 00000001F8D4: DC6A0C00 007C22A1
	.long 0xd7006a4c                                           // 00000001F8DC: D7006A4C
	v_cndmask_b32_e32 v1, 0xd000, v74, vcc_lo                  // 00000001F8E0: 020294FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F8E8: BF8700A1
	v_add_co_ci_u32_e64 v77, null, 0, v75, vcc_lo              // 00000001F8EC: D5207C4D 01AA9680
	.long 0xd7006aa1                                           // 00000001F8F4: D7006AA1
	v_cndmask_b32_e32 v0, v74, v255, vcc_lo                    // 00000001F8F8: 0201FF4A
	.long 0x0000e000                                           // 00000001F8FC: 0000E000
	v_add_co_ci_u32_e64 v162, null, 0, v75, vcc_lo             // 00000001F900: D5207CA2 01AA9680
	.long 0xd7006aa7                                           // 00000001F908: D7006AA7
	v_cndmask_b32_e32 v1, 0xe000, v74, vcc_lo                  // 00000001F90C: 020294FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001F914: BF870001
	v_add_co_ci_u32_e64 v168, null, 0, v75, vcc_lo             // 00000001F918: D5207CA8 01AA9680
	.long 0xd7006a4a                                           // 00000001F920: D7006A4A
	v_cndmask_b32_e32 v1, 0xf000, v74, vcc_lo                  // 00000001F924: 020294FF 0000F000
	s_clause 0x7                                               // 00000001F92C: BF850007
	global_store_b32 v[163:164], v11, off offset:-4096         // 00000001F930: DC6A1000 007C0BA3
	global_store_b32 v[163:164], v12, off                      // 00000001F938: DC6A0000 007C0CA3
	global_store_b32 v[165:166], v14, off offset:-4096         // 00000001F940: DC6A1000 007C0EA5
	global_store_b32 v[165:166], v15, off                      // 00000001F948: DC6A0000 007C0FA5
	global_store_b32 v[159:160], v27, off offset:-4096         // 00000001F950: DC6A1000 007C1B9F
	global_store_b32 v[159:160], v28, off                      // 00000001F958: DC6A0000 007C1C9F
	global_store_b32 v[161:162], v29, off offset:-4096         // 00000001F960: DC6A1000 007C1DA1
	global_store_b32 v[161:162], v30, off                      // 00000001F968: DC6A0000 007C1EA1
	v_add_co_ci_u32_e64 v75, null, 0, v75, vcc_lo              // 00000001F970: D5207C4B 01AA9680
	s_clause 0xf                                               // 00000001F978: BF85000F
	global_store_b32 v[76:77], v20, off offset:1024            // 00000001F97C: DC6A0400 007C144C
	global_store_b32 v[76:77], v21, off offset:2048            // 00000001F984: DC6A0800 007C154C
	global_store_b32 v[76:77], v22, off offset:3072            // 00000001F98C: DC6A0C00 007C164C
	global_store_b32 v[167:168], v23, off offset:1024          // 00000001F994: DC6A0400 007C17A7
	global_store_b32 v[167:168], v24, off offset:2048          // 00000001F99C: DC6A0800 007C18A7
	global_store_b32 v[167:168], v26, off offset:3072          // 00000001F9A4: DC6A0C00 007C1AA7
	global_store_b32 v[74:75], v16, off                        // 00000001F9AC: DC6A0000 007C104A
	global_store_b32 v[74:75], v18, off offset:1024            // 00000001F9B4: DC6A0400 007C124A
	global_store_b32 v[74:75], v19, off offset:2048            // 00000001F9BC: DC6A0800 007C134A
	global_store_b32 v[78:79], v4, off offset:-4096            // 00000001F9C4: DC6A1000 007C044E
	global_store_b32 v[78:79], v5, off                         // 00000001F9CC: DC6A0000 007C054E
	global_store_b32 v[157:158], v6, off offset:-4096          // 00000001F9D4: DC6A1000 007C069D
	global_store_b32 v[157:158], v7, off                       // 00000001F9DC: DC6A0000 007C079D
	global_store_b32 v[80:81], v8, off offset:-4096            // 00000001F9E4: DC6A1000 007C0850
	global_store_b32 v[80:81], v10, off                        // 00000001F9EC: DC6A0000 007C0A50
	global_store_b32 v[74:75], v13, off offset:3072            // 00000001F9F4: DC6A0C00 007C0D4A
	s_cmp_lg_u32 s14, s46                                      // 00000001F9FC: BF072E0E
	s_cbranch_scc1 60288                                       // 00000001FA00: BFA2EB80 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x904>
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000001FA04: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FA08: BF870091
	.long 0xd73c0002                                           // 00000001FA0C: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000001FA10: 02020482
	.long 0xd7006a02                                           // 00000001FA14: D7006A02
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000001FA18: 02020427
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001FA1C: BF870111
	v_add_co_ci_u32_e64 v3, null, s40, v3, vcc_lo              // 00000001FA20: D5207C03 01AA0628
	.long 0xd7006a4a                                           // 00000001FA28: D7006A4A
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000001FA2C: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001FA34: BF8700A1
	v_add_co_ci_u32_e64 v75, null, 0, v3, vcc_lo               // 00000001FA38: D5207C4B 01AA0680
	.long 0xd7006a4c                                           // 00000001FA40: D7006A4C
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000001FA44: 0201FF02
	.long 0x00002000                                           // 00000001FA48: 00002000
	v_add_co_ci_u32_e64 v77, null, 0, v3, vcc_lo               // 00000001FA4C: D5207C4D 01AA0680
	.long 0xd7006a4e                                           // 00000001FA54: D7006A4E
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 00000001FA58: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001FA60: BF870001
	v_add_co_ci_u32_e64 v79, null, 0, v3, vcc_lo               // 00000001FA64: D5207C4F 01AA0680
	s_clause 0x7                                               // 00000001FA6C: BF850007
	global_store_b32 v[2:3], v150, off                         // 00000001FA70: DC6A0000 007C9602
	global_store_b32 v[2:3], v151, off offset:1024             // 00000001FA78: DC6A0400 007C9702
	global_store_b32 v[2:3], v152, off offset:2048             // 00000001FA80: DC6A0800 007C9802
	global_store_b32 v[2:3], v153, off offset:3072             // 00000001FA88: DC6A0C00 007C9902
	global_store_b32 v[74:75], v154, off offset:1024           // 00000001FA90: DC6A0400 007C9A4A
	global_store_b32 v[74:75], v155, off offset:2048           // 00000001FA98: DC6A0800 007C9B4A
	global_store_b32 v[74:75], v156, off offset:3072           // 00000001FAA0: DC6A0C00 007C9C4A
	global_store_b32 v[78:79], v149, off offset:1024           // 00000001FAA8: DC6A0400 007C954E
	.long 0xd7006a4a                                           // 00000001FAB0: D7006A4A
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 00000001FAB4: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001FABC: BF8700A1
	v_add_co_ci_u32_e64 v75, null, 0, v3, vcc_lo               // 00000001FAC0: D5207C4B 01AA0680
	.long 0xd7006a50                                           // 00000001FAC8: D7006A50
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000001FACC: 0201FF02
	.long 0x00004000                                           // 00000001FAD0: 00004000
	v_add_co_ci_u32_e64 v81, null, 0, v3, vcc_lo               // 00000001FAD4: D5207C51 01AA0680
	.long 0xd7006a95                                           // 00000001FADC: D7006A95
	v_cndmask_b32_e32 v1, 0x4000, v2, vcc_lo                   // 00000001FAE0: 020204FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001FAE8: BF870001
	v_add_co_ci_u32_e64 v150, null, 0, v3, vcc_lo              // 00000001FAEC: D5207C96 01AA0680
	s_clause 0x7                                               // 00000001FAF4: BF850007
	global_store_b32 v[78:79], v63, off offset:2048            // 00000001FAF8: DC6A0800 007C3F4E
	global_store_b32 v[78:79], v64, off offset:3072            // 00000001FB00: DC6A0C00 007C404E
	global_store_b32 v[74:75], v65, off offset:1024            // 00000001FB08: DC6A0400 007C414A
	global_store_b32 v[74:75], v147, off offset:2048           // 00000001FB10: DC6A0800 007C934A
	global_store_b32 v[74:75], v148, off offset:3072           // 00000001FB18: DC6A0C00 007C944A
	global_store_b32 v[149:150], v60, off offset:1024          // 00000001FB20: DC6A0400 007C3C95
	global_store_b32 v[149:150], v61, off offset:2048          // 00000001FB28: DC6A0800 007C3D95
	global_store_b32 v[149:150], v62, off offset:3072          // 00000001FB30: DC6A0C00 007C3E95
	.long 0xd7006a3c                                           // 00000001FB38: D7006A3C
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 00000001FB3C: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001FB44: BF8700A1
	v_add_co_ci_u32_e64 v61, null, 0, v3, vcc_lo               // 00000001FB48: D5207C3D 01AA0680
	.long 0xd7006a3e                                           // 00000001FB50: D7006A3E
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000001FB54: 0201FF02
	.long 0x00006000                                           // 00000001FB58: 00006000
	v_add_co_ci_u32_e64 v63, null, 0, v3, vcc_lo               // 00000001FB5C: D5207C3F 01AA0680
	.long 0xd7006a40                                           // 00000001FB64: D7006A40
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 00000001FB68: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001FB70: BF8700A1
	v_add_co_ci_u32_e64 v65, null, 0, v3, vcc_lo               // 00000001FB74: D5207C41 01AA0680
	.long 0xd7006a4a                                           // 00000001FB7C: D7006A4A
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 00000001FB80: 020204FF 00007000
	v_add_co_ci_u32_e64 v75, null, 0, v3, vcc_lo               // 00000001FB88: D5207C4B 01AA0680
	.long 0xd7006a4e                                           // 00000001FB90: D7006A4E
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000001FB94: 0201FF02
	.long 0x00008000                                           // 00000001FB98: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001FB9C: BF870001
	v_add_co_ci_u32_e64 v79, null, 0, v3, vcc_lo               // 00000001FBA0: D5207C4F 01AA0680
	s_clause 0x7                                               // 00000001FBA8: BF850007
	global_store_b32 v[60:61], v53, off offset:1024            // 00000001FBAC: DC6A0400 007C353C
	global_store_b32 v[60:61], v55, off offset:2048            // 00000001FBB4: DC6A0800 007C373C
	global_store_b32 v[60:61], v56, off offset:3072            // 00000001FBBC: DC6A0C00 007C383C
	global_store_b32 v[64:65], v57, off offset:1024            // 00000001FBC4: DC6A0400 007C3940
	global_store_b32 v[64:65], v58, off offset:2048            // 00000001FBCC: DC6A0800 007C3A40
	global_store_b32 v[64:65], v59, off offset:3072            // 00000001FBD4: DC6A0C00 007C3B40
	global_store_b32 v[74:75], v51, off offset:1024            // 00000001FBDC: DC6A0400 007C334A
	global_store_b32 v[74:75], v52, off offset:2048            // 00000001FBE4: DC6A0800 007C344A
	.long 0xd7006a33                                           // 00000001FBEC: D7006A33
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 00000001FBF0: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001FBF8: BF8700A1
	v_add_co_ci_u32_e64 v52, null, 0, v3, vcc_lo               // 00000001FBFC: D5207C34 01AA0680
	.long 0xd7006a37                                           // 00000001FC04: D7006A37
	v_cndmask_b32_e32 v1, 0x9000, v2, vcc_lo                   // 00000001FC08: 020204FF 00009000
	v_add_co_ci_u32_e64 v56, null, 0, v3, vcc_lo               // 00000001FC10: D5207C38 01AA0680
	.long 0xd7006a39                                           // 00000001FC18: D7006A39
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000001FC1C: 0201FF02
	.long 0x0000a000                                           // 00000001FC20: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001FC24: BF8700A1
	v_add_co_ci_u32_e64 v58, null, 0, v3, vcc_lo               // 00000001FC28: D5207C3A 01AA0680
	.long 0xd7006a3b                                           // 00000001FC30: D7006A3B
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 00000001FC34: 020204FF 0000A000
	v_add_co_ci_u32_e64 v60, null, 0, v3, vcc_lo               // 00000001FC3C: D5207C3C 01AA0680
	s_clause 0x7                                               // 00000001FC44: BF850007
	global_store_b32 v[74:75], v42, off offset:3072            // 00000001FC48: DC6A0C00 007C2A4A
	global_store_b32 v[51:52], v44, off offset:1024            // 00000001FC50: DC6A0400 007C2C33
	global_store_b32 v[51:52], v45, off offset:2048            // 00000001FC58: DC6A0800 007C2D33
	global_store_b32 v[51:52], v47, off offset:3072            // 00000001FC60: DC6A0C00 007C2F33
	global_store_b32 v[55:56], v48, off offset:1024            // 00000001FC68: DC6A0400 007C3037
	global_store_b32 v[55:56], v49, off offset:2048            // 00000001FC70: DC6A0800 007C3137
	global_store_b32 v[55:56], v50, off offset:3072            // 00000001FC78: DC6A0C00 007C3237
	global_store_b32 v[59:60], v43, off offset:1024            // 00000001FC80: DC6A0400 007C2B3B
	.long 0xd7006a2a                                           // 00000001FC88: D7006A2A
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 00000001FC8C: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001FC94: BF8700A1
	v_add_co_ci_u32_e64 v43, null, 0, v3, vcc_lo               // 00000001FC98: D5207C2B 01AA0680
	.long 0xd7006a2c                                           // 00000001FCA0: D7006A2C
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000001FCA4: 0201FF02
	.long 0x0000c000                                           // 00000001FCA8: 0000C000
	v_add_co_ci_u32_e64 v45, null, 0, v3, vcc_lo               // 00000001FCAC: D5207C2D 01AA0680
	.long 0xd7006a2f                                           // 00000001FCB4: D7006A2F
	v_cndmask_b32_e32 v1, 0xc000, v2, vcc_lo                   // 00000001FCB8: 020204FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001FCC0: BF870001
	v_add_co_ci_u32_e64 v48, null, 0, v3, vcc_lo               // 00000001FCC4: D5207C30 01AA0680
	s_clause 0x7                                               // 00000001FCCC: BF850007
	global_store_b32 v[59:60], v35, off offset:2048            // 00000001FCD0: DC6A0800 007C233B
	global_store_b32 v[59:60], v36, off offset:3072            // 00000001FCD8: DC6A0C00 007C243B
	global_store_b32 v[42:43], v39, off offset:1024            // 00000001FCE0: DC6A0400 007C272A
	global_store_b32 v[42:43], v40, off offset:2048            // 00000001FCE8: DC6A0800 007C282A
	global_store_b32 v[42:43], v41, off offset:3072            // 00000001FCF0: DC6A0C00 007C292A
	global_store_b32 v[47:48], v31, off offset:1024            // 00000001FCF8: DC6A0400 007C1F2F
	global_store_b32 v[47:48], v32, off offset:2048            // 00000001FD00: DC6A0800 007C202F
	global_store_b32 v[47:48], v34, off offset:3072            // 00000001FD08: DC6A0C00 007C222F
	.long 0xd7006a1f                                           // 00000001FD10: D7006A1F
	v_cndmask_b32_e32 v1, 0xd000, v2, vcc_lo                   // 00000001FD14: 020204FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001FD1C: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v3, vcc_lo               // 00000001FD20: D5207C20 01AA0680
	.long 0xd7006a22                                           // 00000001FD28: D7006A22
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000001FD2C: 0201FF02
	.long 0x0000e000                                           // 00000001FD30: 0000E000
	v_add_co_ci_u32_e64 v35, null, 0, v3, vcc_lo               // 00000001FD34: D5207C23 01AA0680
	.long 0xd7006a27                                           // 00000001FD3C: D7006A27
	v_cndmask_b32_e32 v1, 0xe000, v2, vcc_lo                   // 00000001FD40: 020204FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001FD48: BF870001
	v_add_co_ci_u32_e64 v40, null, 0, v3, vcc_lo               // 00000001FD4C: D5207C28 01AA0680
	.long 0xd7006a02                                           // 00000001FD54: D7006A02
	v_cndmask_b32_e32 v1, 0xf000, v2, vcc_lo                   // 00000001FD58: 020204FF 0000F000
	s_clause 0x7                                               // 00000001FD60: BF850007
	global_store_b32 v[78:79], v11, off offset:-4096           // 00000001FD64: DC6A1000 007C0B4E
	global_store_b32 v[78:79], v12, off                        // 00000001FD6C: DC6A0000 007C0C4E
	global_store_b32 v[57:58], v14, off offset:-4096           // 00000001FD74: DC6A1000 007C0E39
	global_store_b32 v[57:58], v15, off                        // 00000001FD7C: DC6A0000 007C0F39
	global_store_b32 v[44:45], v27, off offset:-4096           // 00000001FD84: DC6A1000 007C1B2C
	global_store_b32 v[44:45], v28, off                        // 00000001FD8C: DC6A0000 007C1C2C
	global_store_b32 v[34:35], v29, off offset:-4096           // 00000001FD94: DC6A1000 007C1D22
	global_store_b32 v[34:35], v30, off                        // 00000001FD9C: DC6A0000 007C1E22
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000001FDA4: D5207C03 01AA0680
	s_clause 0xf                                               // 00000001FDAC: BF85000F
	global_store_b32 v[31:32], v20, off offset:1024            // 00000001FDB0: DC6A0400 007C141F
	global_store_b32 v[31:32], v21, off offset:2048            // 00000001FDB8: DC6A0800 007C151F
	global_store_b32 v[31:32], v22, off offset:3072            // 00000001FDC0: DC6A0C00 007C161F
	global_store_b32 v[39:40], v23, off offset:1024            // 00000001FDC8: DC6A0400 007C1727
	global_store_b32 v[39:40], v24, off offset:2048            // 00000001FDD0: DC6A0800 007C1827
	global_store_b32 v[39:40], v26, off offset:3072            // 00000001FDD8: DC6A0C00 007C1A27
	global_store_b32 v[2:3], v16, off                          // 00000001FDE0: DC6A0000 007C1002
	global_store_b32 v[2:3], v18, off offset:1024              // 00000001FDE8: DC6A0400 007C1202
	global_store_b32 v[2:3], v19, off offset:2048              // 00000001FDF0: DC6A0800 007C1302
	global_store_b32 v[76:77], v4, off offset:-4096            // 00000001FDF8: DC6A1000 007C044C
	global_store_b32 v[76:77], v5, off                         // 00000001FE00: DC6A0000 007C054C
	global_store_b32 v[80:81], v6, off offset:-4096            // 00000001FE08: DC6A1000 007C0650
	global_store_b32 v[80:81], v7, off                         // 00000001FE10: DC6A0000 007C0750
	global_store_b32 v[62:63], v8, off offset:-4096            // 00000001FE18: DC6A1000 007C083E
	global_store_b32 v[62:63], v10, off                        // 00000001FE20: DC6A0000 007C0A3E
	global_store_b32 v[2:3], v13, off offset:3072              // 00000001FE28: DC6A0C00 007C0D02
	s_branch 60020                                             // 00000001FE30: BFA0EA74 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x904>
	s_clause 0x1                                               // 00000001FE34: BF850001
	scratch_load_b64 v[78:79], off, off                        // 00000001FE38: DC550000 4E7C0000
	scratch_load_b64 v[80:81], off, off offset:8               // 00000001FE40: DC550008 507C0000
	s_branch 8                                                 // 00000001FE48: BFA00008 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb0ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5f6c>
	v_dual_mov_b32 v54, v154 :: v_dual_mov_b32 v17, v151       // 00000001FE4C: CA10019A 36100197
	v_dual_mov_b32 v46, v153 :: v_dual_mov_b32 v9, v150        // 00000001FE54: CA100199 2E080196
	v_dual_mov_b32 v38, v152 :: v_dual_mov_b32 v25, v149       // 00000001FE5C: CA100198 26180195
	v_mov_b32_e32 v37, v148                                    // 00000001FE64: 7E4A0394
	v_mov_b32_e32 v33, v147                                    // 00000001FE68: 7E420393
	.long 0xd7006a00                                           // 00000001FE6C: D7006A00
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 00000001FE70: 0201FF8D
	.long 0x00002000                                           // 00000001FE74: 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001FE78: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v142, vcc_lo              // 00000001FE7C: D5207C01 01AB1C80
	v_dual_mul_f32 v4, 0x3b800000, v130 :: v_dual_mul_f32 v15, 0x3b800000, v127// 00000001FE84: C8C704FF 040EFEFF 3B800000
	v_dual_mul_f32 v10, 0x3b800000, v133 :: v_dual_mul_f32 v5, 0x3b800000, v54// 00000001FE90: C8C70AFF 0A046CFF 3B800000
	v_dual_mul_f32 v12, 0x3b800000, v131 :: v_dual_mul_f32 v13, 0x3b800000, v129// 00000001FE9C: C8C706FF 0C0D02FF 3B800000
	v_mul_f32_e32 v14, 0x3b800000, v128                        // 00000001FEA8: 101D00FF 3B800000
	.long 0xd7006a02                                           // 00000001FEB0: D7006A02
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 00000001FEB4: 0201FF8D
	.long 0x00004000                                           // 00000001FEB8: 00004000
	v_dual_mul_f32 v16, 0x3b800000, v126 :: v_dual_mul_f32 v19, 0x3b800000, v124// 00000001FEBC: C8C6FCFF 1012F8FF 3B800000
	v_mul_f32_e32 v18, 0x3b800000, v125                        // 00000001FEC8: 1024FAFF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v142, vcc_lo              // 00000001FED0: D5207C03 01AB1C80
	s_clause 0x7                                               // 00000001FED8: BF850007
	global_store_b32 v[0:1], v4, off offset:-2048              // 00000001FEDC: DC6A1800 007C0400
	global_store_b32 v[0:1], v5, off offset:-1024              // 00000001FEE4: DC6A1C00 007C0500
	global_store_b32 v[0:1], v13, off                          // 00000001FEEC: DC6A0000 007C0D00
	global_store_b32 v[0:1], v14, off offset:1024              // 00000001FEF4: DC6A0400 007C0E00
	global_store_b32 v[0:1], v15, off offset:2048              // 00000001FEFC: DC6A0800 007C0F00
	global_store_b32 v[0:1], v16, off offset:3072              // 00000001FF04: DC6A0C00 007C1000
	global_store_b32 v[2:3], v18, off offset:-4096             // 00000001FF0C: DC6A1000 007C1202
	global_store_b32 v[2:3], v19, off offset:-3072             // 00000001FF14: DC6A1400 007C1302
	v_dual_mul_f32 v13, 0x3b800000, v123 :: v_dual_mul_f32 v14, 0x3b800000, v46// 00000001FF1C: C8C6F6FF 0D0E5CFF 3B800000
	v_mul_f32_e32 v19, 0x3b800000, v119                        // 00000001FF28: 1026EEFF 3B800000
	v_dual_mul_f32 v15, 0x3b800000, v122 :: v_dual_mul_f32 v16, 0x3b800000, v121// 00000001FF30: C8C6F4FF 0F10F2FF 3B800000
	.long 0xd7006a04                                           // 00000001FF3C: D7006A04
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 00000001FF40: 0201FF8D
	.long 0x00006000                                           // 00000001FF44: 00006000
	v_dual_mul_f32 v18, 0x3b800000, v120 :: v_dual_mul_f32 v21, 0x3b800000, v117// 00000001FF48: C8C6F0FF 1214EAFF 3B800000
	v_mul_f32_e32 v20, 0x3b800000, v118                        // 00000001FF54: 1028ECFF 3B800000
	v_add_co_ci_u32_e64 v5, null, 0, v142, vcc_lo              // 00000001FF5C: D5207C05 01AB1C80
	s_clause 0x7                                               // 00000001FF64: BF850007
	global_store_b32 v[2:3], v13, off offset:-2048             // 00000001FF68: DC6A1800 007C0D02
	global_store_b32 v[2:3], v14, off offset:-1024             // 00000001FF70: DC6A1C00 007C0E02
	global_store_b32 v[2:3], v15, off                          // 00000001FF78: DC6A0000 007C0F02
	global_store_b32 v[2:3], v16, off offset:1024              // 00000001FF80: DC6A0400 007C1002
	global_store_b32 v[2:3], v18, off offset:2048              // 00000001FF88: DC6A0800 007C1202
	global_store_b32 v[2:3], v19, off offset:3072              // 00000001FF90: DC6A0C00 007C1302
	global_store_b32 v[4:5], v20, off offset:-4096             // 00000001FF98: DC6A1000 007C1404
	global_store_b32 v[4:5], v21, off offset:-3072             // 00000001FFA0: DC6A1400 007C1504
	v_dual_mul_f32 v13, 0x3b800000, v116 :: v_dual_mul_f32 v14, 0x3b800000, v38// 00000001FFA8: C8C6E8FF 0D0E4CFF 3B800000
	v_mul_f32_e32 v19, 0x3b800000, v112                        // 00000001FFB4: 1026E0FF 3B800000
	v_dual_mul_f32 v15, 0x3b800000, v115 :: v_dual_mul_f32 v16, 0x3b800000, v114// 00000001FFBC: C8C6E6FF 0F10E4FF 3B800000
	.long 0xd7006a02                                           // 00000001FFC8: D7006A02
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 00000001FFCC: 0201FF8D
	.long 0x00008000                                           // 00000001FFD0: 00008000
	v_dual_mul_f32 v18, 0x3b800000, v113 :: v_dual_mul_f32 v21, 0x3b800000, v110// 00000001FFD4: C8C6E2FF 1214DCFF 3B800000
	v_mul_f32_e32 v20, 0x3b800000, v111                        // 00000001FFE0: 1028DEFF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v142, vcc_lo              // 00000001FFE8: D5207C03 01AB1C80
	s_clause 0x7                                               // 00000001FFF0: BF850007
	global_store_b32 v[4:5], v13, off offset:-2048             // 00000001FFF4: DC6A1800 007C0D04
	global_store_b32 v[4:5], v14, off offset:-1024             // 00000001FFFC: DC6A1C00 007C0E04
	global_store_b32 v[4:5], v15, off                          // 000000020004: DC6A0000 007C0F04
	global_store_b32 v[4:5], v16, off offset:1024              // 00000002000C: DC6A0400 007C1004
	global_store_b32 v[4:5], v18, off offset:2048              // 000000020014: DC6A0800 007C1204
	global_store_b32 v[4:5], v19, off offset:3072              // 00000002001C: DC6A0C00 007C1304
	global_store_b32 v[2:3], v20, off offset:-4096             // 000000020024: DC6A1000 007C1402
	global_store_b32 v[2:3], v21, off offset:-3072             // 00000002002C: DC6A1400 007C1502
	v_mul_f32_e32 v13, 0x3b800000, v109                        // 000000020034: 101ADAFF 3B800000
	v_dual_mul_f32 v15, 0x3b800000, v108 :: v_dual_mul_f32 v16, 0x3b800000, v107// 00000002003C: C8C6D8FF 0F10D6FF 3B800000
	v_mul_f32_e32 v19, 0x3b800000, v104                        // 000000020048: 1026D0FF 3B800000
	.long 0xd7006a04                                           // 000000020050: D7006A04
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 000000020054: 0201FF8D
	.long 0x0000a000                                           // 000000020058: 0000A000
	v_dual_mul_f32 v14, 0x3b800000, v17 :: v_dual_mul_f32 v17, 0x3b800000, v106// 00000002005C: C8C622FF 0E10D4FF 3B800000
	v_dual_mul_f32 v18, 0x3b800000, v105 :: v_dual_mul_f32 v21, 0x3b800000, v102// 000000020068: C8C6D2FF 1214CCFF 3B800000
	v_add_co_ci_u32_e64 v5, null, 0, v142, vcc_lo              // 000000020074: D5207C05 01AB1C80
	v_dual_mul_f32 v20, 0x3b800000, v103 :: v_dual_mul_f32 v9, 0x3b800000, v9// 00000002007C: C8C6CEFF 140812FF 3B800000
	s_clause 0x7                                               // 000000020088: BF850007
	global_store_b32 v[2:3], v13, off offset:-2048             // 00000002008C: DC6A1800 007C0D02
	global_store_b32 v[2:3], v15, off                          // 000000020094: DC6A0000 007C0F02
	global_store_b32 v[2:3], v16, off offset:1024              // 00000002009C: DC6A0400 007C1002
	global_store_b32 v[2:3], v17, off offset:2048              // 0000000200A4: DC6A0800 007C1102
	global_store_b32 v[2:3], v18, off offset:3072              // 0000000200AC: DC6A0C00 007C1202
	global_store_b32 v[4:5], v19, off offset:-4096             // 0000000200B4: DC6A1000 007C1304
	global_store_b32 v[4:5], v20, off offset:-3072             // 0000000200BC: DC6A1400 007C1404
	global_store_b32 v[4:5], v21, off offset:-2048             // 0000000200C4: DC6A1800 007C1504
	v_dual_mul_f32 v13, 0x3b800000, v101 :: v_dual_mul_f32 v16, 0x3b800000, v99// 0000000200CC: C8C6CAFF 0D10C6FF 3B800000
	v_dual_mul_f32 v15, 0x3b800000, v100 :: v_dual_mul_f32 v18, 0x3b800000, v97// 0000000200D8: C8C6C8FF 0F12C2FF 3B800000
	.long 0xd7006a02                                           // 0000000200E4: D7006A02
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 0000000200E8: 0201FF8D
	.long 0x0000c000                                           // 0000000200EC: 0000C000
	v_dual_mul_f32 v17, 0x3b800000, v98 :: v_dual_mul_f32 v20, 0x3b800000, v95// 0000000200F0: C8C6C4FF 1114BEFF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v142, vcc_lo              // 0000000200FC: D5207C03 01AB1C80
	v_mul_f32_e32 v19, 0x3b800000, v96                         // 000000020104: 1026C0FF 3B800000
	s_clause 0x7                                               // 00000002010C: BF850007
	global_store_b32 v[4:5], v9, off offset:-1024              // 000000020110: DC6A1C00 007C0904
	global_store_b32 v[4:5], v13, off                          // 000000020118: DC6A0000 007C0D04
	global_store_b32 v[4:5], v15, off offset:1024              // 000000020120: DC6A0400 007C0F04
	global_store_b32 v[4:5], v16, off offset:2048              // 000000020128: DC6A0800 007C1004
	global_store_b32 v[4:5], v17, off offset:3072              // 000000020130: DC6A0C00 007C1104
	global_store_b32 v[2:3], v18, off offset:-4096             // 000000020138: DC6A1000 007C1202
	global_store_b32 v[2:3], v19, off offset:-3072             // 000000020140: DC6A1400 007C1302
	global_store_b32 v[2:3], v20, off offset:-2048             // 000000020148: DC6A1800 007C1402
	v_dual_mul_f32 v9, 0x3b800000, v25 :: v_dual_mul_f32 v16, 0x3b800000, v92// 000000020150: C8C632FF 0910B8FF 3B800000
	v_dual_mul_f32 v13, 0x3b800000, v94 :: v_dual_mul_f32 v20, 0x3b800000, v88// 00000002015C: C8C6BCFF 0D14B0FF 3B800000
	v_mul_f32_e32 v15, 0x3b800000, v93                         // 000000020168: 101EBAFF 3B800000
	.long 0xd7006a04                                           // 000000020170: D7006A04
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 000000020174: 0201FF8D
	.long 0x0000e000                                           // 000000020178: 0000E000
	v_dual_mul_f32 v17, 0x3b800000, v91 :: v_dual_mul_f32 v6, 0x3b800000, v136// 00000002017C: C8C6B6FF 110710FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v135 :: v_dual_mul_f32 v18, 0x3b800000, v90// 000000020188: C8C70EFF 0712B4FF 3B800000
	v_add_co_ci_u32_e64 v5, null, 0, v142, vcc_lo              // 000000020194: D5207C05 01AB1C80
	v_mul_f32_e32 v19, 0x3b800000, v89                         // 00000002019C: 1026B2FF 3B800000
	s_clause 0x7                                               // 0000000201A4: BF850007
	global_store_b32 v[2:3], v9, off offset:-1024              // 0000000201A8: DC6A1C00 007C0902
	global_store_b32 v[2:3], v13, off                          // 0000000201B0: DC6A0000 007C0D02
	global_store_b32 v[2:3], v15, off offset:1024              // 0000000201B8: DC6A0400 007C0F02
	global_store_b32 v[2:3], v16, off offset:2048              // 0000000201C0: DC6A0800 007C1002
	global_store_b32 v[2:3], v17, off offset:3072              // 0000000201C8: DC6A0C00 007C1102
	global_store_b32 v[4:5], v18, off offset:-4096             // 0000000201D0: DC6A1000 007C1204
	global_store_b32 v[4:5], v19, off offset:-3072             // 0000000201D8: DC6A1400 007C1304
	global_store_b32 v[4:5], v20, off offset:-2048             // 0000000201E0: DC6A1800 007C1404
	v_mul_f32_e32 v9, 0x3b800000, v37                          // 0000000201E8: 10124AFF 3B800000
	v_dual_mul_f32 v13, 0x3b800000, v87 :: v_dual_mul_f32 v8, 0x3b800000, v134// 0000000201F0: C8C6AEFF 0D090CFF 3B800000
	v_mul_f32_e32 v11, 0x3b800000, v132                        // 0000000201FC: 101708FF 3B800000
	v_dual_mul_f32 v15, 0x3b800000, v86 :: v_dual_mul_f32 v16, 0x3b800000, v85// 000000020204: C8C6ACFF 0F10AAFF 3B800000
	.long 0xd7006a02                                           // 000000020210: D7006A02
	v_cndmask_b32_e32 v0, v141, v255, vcc_lo                   // 000000020214: 0201FF8D
	.long 0x0000f800                                           // 000000020218: 0000F800
	v_dual_mul_f32 v17, 0x3b800000, v84 :: v_dual_mul_f32 v18, 0x3b800000, v83// 00000002021C: C8C6A8FF 1112A6FF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v142, vcc_lo              // 000000020228: D5207C03 01AB1C80
	v_dual_mul_f32 v19, 0x3b800000, v82 :: v_dual_mul_f32 v20, 0x3b800000, v143// 000000020230: C8C6A4FF 13151EFF 3B800000
	s_clause 0x7                                               // 00000002023C: BF850007
	global_store_b32 v[4:5], v9, off offset:-1024              // 000000020240: DC6A1C00 007C0904
	global_store_b32 v[4:5], v13, off                          // 000000020248: DC6A0000 007C0D04
	global_store_b32 v[4:5], v15, off offset:1024              // 000000020250: DC6A0400 007C0F04
	global_store_b32 v[4:5], v16, off offset:2048              // 000000020258: DC6A0800 007C1004
	global_store_b32 v[4:5], v17, off offset:3072              // 000000020260: DC6A0C00 007C1104
	global_store_b32 v[2:3], v18, off offset:-2048             // 000000020268: DC6A1800 007C1202
	global_store_b32 v[2:3], v19, off offset:-1024             // 000000020270: DC6A1C00 007C1302
	global_store_b32 v[2:3], v20, off                          // 000000020278: DC6A0000 007C1402
	v_mul_f32_e32 v2, 0x3b800000, v33                          // 000000020280: 100442FF 3B800000
	s_clause 0x3                                               // 000000020288: BF850003
	global_store_b32 v[141:142], v6, off                       // 00000002028C: DC6A0000 007C068D
	global_store_b32 v[141:142], v7, off offset:1024           // 000000020294: DC6A0400 007C078D
	global_store_b32 v[141:142], v8, off offset:2048           // 00000002029C: DC6A0800 007C088D
	global_store_b32 v[141:142], v10, off offset:3072          // 0000000202A4: DC6A0C00 007C0A8D
	s_waitcnt vmcnt(1)                                         // 0000000202AC: BF8907F7
	s_clause 0x2                                               // 0000000202B0: BF850002
	global_store_b32 v[78:79], v14, off                        // 0000000202B4: DC6A0000 007C0E4E
	global_store_b32 v[0:1], v11, off offset:-4096             // 0000000202BC: DC6A1000 007C0B00
	global_store_b32 v[0:1], v12, off offset:-3072             // 0000000202C4: DC6A1400 007C0C00
	s_waitcnt vmcnt(0)                                         // 0000000202CC: BF8903F7
	global_store_b32 v[80:81], v2, off                         // 0000000202D0: DC6A0000 007C0250
	s_endpgm                                                   // 0000000202D8: BFB00000
		...

