0000000000226f00 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_():
	s_load_b256 s[16:23], s[0:1], null                         // 000000226F00: F40C0400 F8000000
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 000000226F08: CA240100 040000FF 0000007F
	s_mov_b32 s24, s3                                          // 000000226F14: BE980003
	v_mov_b32_e32 v5, v0                                       // 000000226F18: 7E0A0300
	s_lshl_b32 s26, s2, 5                                      // 000000226F1C: 841A8502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000226F20: BF8700B2
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000226F24: 30020282
	s_ashr_i32 s25, s24, 31                                    // 000000226F28: 86199F18
	s_waitcnt lgkmcnt(0)                                       // 000000226F2C: BF89FC07
	.long 0xd7000302                                           // 000000226F30: D7000302
	v_cndmask_b32_e32 v1, s18, v1, vcc_lo                      // 000000226F34: 02020212
	s_delay_alu instid0(VALU_DEP_1)                            // 000000226F38: BF870001
	v_add_co_ci_u32_e64 v3, null, s19, 0, s3                   // 000000226F3C: D5207C03 000D0013
	s_mov_b32 s3, 0                                            // 000000226F44: BE830080
	s_nop 0                                                    // 000000226F48: BF800000
	s_nop 0                                                    // 000000226F4C: BF800000
	s_nop 0                                                    // 000000226F50: BF800000
	s_nop 0                                                    // 000000226F54: BF800000
	s_nop 0                                                    // 000000226F58: BF800000
	s_nop 0                                                    // 000000226F5C: BF800000
	s_nop 0                                                    // 000000226F60: BF800000
	s_nop 0                                                    // 000000226F64: BF800000
	s_nop 0                                                    // 000000226F68: BF800000
	s_nop 0                                                    // 000000226F6C: BF800000
	s_nop 0                                                    // 000000226F70: BF800000
	s_nop 0                                                    // 000000226F74: BF800000
	s_nop 0                                                    // 000000226F78: BF800000
	s_nop 0                                                    // 000000226F7C: BF800000
	v_lshrrev_b32_e32 v8, 7, v4                                // 000000226F80: 32100887
	v_add_nc_u32_e32 v10, 0x100, v4                            // 000000226F84: 4A1408FF 00000100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226F8C: BF870092
	v_or_b32_e32 v6, s26, v8                                   // 000000226F90: 380C101A
	v_mad_i64_i32 v[6:7], null, v6, 48, s[24:25]               // 000000226F94: D6FF7C06 00616106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226F9C: BF870091
	.long 0xd73c0006                                           // 000000226FA0: D73C0006
	v_cndmask_b32_e32 v1, 9, v6, vcc_lo                        // 000000226FA4: 02020C89
	.long 0xd7006a06                                           // 000000226FA8: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 000000226FAC: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 000000226FB0: BF870001
	v_add_co_ci_u32_e64 v7, null, v3, v7, vcc_lo               // 000000226FB4: D5207C07 01AA0F03
	v_cmp_lt_u32_e32 vcc_lo, 0xeff, v4                         // 000000226FBC: 7C9208FF 00000EFF
	v_mov_b32_e32 v4, v10                                      // 000000226FC4: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 000000226FC8: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x204, v8, v[1:2]              // 000000226FD0: D6FE7C06 040610FF 00000204
	s_or_b32 s3, vcc_lo, s3                                    // 000000226FDC: 8C03036A
	s_waitcnt vmcnt(0)                                         // 000000226FE0: BF8903F7
	ds_store_b32 v6, v9                                        // 000000226FE4: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000226FEC: 917E037E
	s_cbranch_execnz 65507                                     // 000000226FF0: BFA6FFE3 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x80>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000226FF4: 8C7E037E
	s_lshr_b32 s3, s2, 31                                      // 000000226FF8: 85039F02
	s_mov_b32 s4, exec_lo                                      // 000000226FFC: BE84007E
	s_add_i32 s2, s2, s3                                       // 000000227000: 81020302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000227004: BF870499
	s_ashr_i32 s3, s2, 1                                       // 000000227008: 86038102
	s_lshl_b32 s2, s3, 6                                       // 00000022700C: 84028603
	v_cmpx_gt_u32_e32 64, v0                                   // 000000227010: 7D9800C0
	s_cbranch_execz 17                                         // 000000227014: BFA50011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x15c>
	v_or_b32_e32 v1, s2, v0                                    // 000000227018: 38020002
	s_lshl_b64 s[6:7], s[24:25], 2                             // 00000022701C: 84868218
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000227020: BF870091
	v_mad_i64_i32 v[1:2], null, 0xc0, v1, s[20:21]             // 000000227024: D6FF7C01 005202FF 000000C0
	.long 0xd7006a01                                           // 000000227030: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000227034: 02000D01
	s_delay_alu instid0(VALU_DEP_1)                            // 000000227038: BF870001
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 00000022703C: D5207C02 01AA0407
	global_load_b32 v1, v[1:2], off                            // 000000227044: DC520000 017C0001
	v_lshlrev_b32_e32 v2, 2, v0                                // 00000022704C: 30040082
	s_waitcnt vmcnt(0)                                         // 000000227050: BF8903F7
	ds_store_b32 v2, v1 offset:16512                           // 000000227054: D8344080 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 00000022705C: 8C7E047E
	s_mov_b64 s[18:19], 0                                      // 000000227060: BE920180
	s_cmp_eq_u64 s[22:23], 0                                   // 000000227064: BF108016
	s_mul_hi_i32 s4, s3, 48                                    // 000000227068: 9704B003
	s_mul_i32 s3, s3, 48                                       // 00000022706C: 9603B003
	s_mov_b64 s[20:21], 0                                      // 000000227070: BE940180
	s_waitcnt lgkmcnt(0)                                       // 000000227074: BF89FC07
	s_barrier                                                  // 000000227078: BFBD0000
	buffer_gl0_inv                                             // 00000022707C: E0AC0000 00000000
	s_cbranch_scc1 6                                           // 000000227084: BFA20006 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x1a0>
	s_add_u32 s6, s3, s24                                      // 000000227088: 80061803
	s_addc_u32 s7, s4, s25                                     // 00000022708C: 82071904
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000227090: BF870499
	s_lshl_b64 s[6:7], s[6:7], 14                              // 000000227094: 84868E06
	s_add_u32 s20, s22, s6                                     // 000000227098: 80140616
	s_addc_u32 s21, s23, s7                                    // 00000022709C: 82150717
	s_load_b64 s[0:1], s[0:1], 0x28                            // 0000002270A0: F4040000 F8000028
	s_waitcnt lgkmcnt(0)                                       // 0000002270A8: BF89FC07
	s_cmp_eq_u64 s[0:1], 0                                     // 0000002270AC: BF108000
	s_cbranch_scc1 6                                           // 0000002270B0: BFA20006 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x1cc>
	s_add_u32 s6, s3, s24                                      // 0000002270B4: 80061803
	s_addc_u32 s7, s4, s25                                     // 0000002270B8: 82071904
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002270BC: BF870499
	s_lshl_b64 s[4:5], s[6:7], 13                              // 0000002270C0: 84848D06
	s_add_u32 s18, s0, s4                                      // 0000002270C4: 80120400
	s_addc_u32 s19, s1, s5                                     // 0000002270C8: 82130501
	s_sub_i32 s28, s26, s2                                     // 0000002270CC: 819C021A
	v_lshrrev_b32_e32 v6, 5, v0                                // 0000002270D0: 320C0085
	s_lshl_b32 s27, s28, 5                                     // 0000002270D4: 841B851C
	s_mov_b32 s30, exec_lo                                     // 0000002270D8: BE9E007E
	s_sub_i32 s29, 0x800, s27                                  // 0000002270DC: 819D1BFF 00000800
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002270E4: BF870009
	.long 0xd4c4007e                                           // 0000002270E8: D4C4007E
	v_cndmask_b32_e32 v1, s29, v0, vcc_lo                      // 0000002270EC: 0202001D
	s_cbranch_execz 183                                        // 0000002270F0: BFA500B7 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x4d0>
	v_mul_u32_u24_e32 v1, 0x204, v0                            // 0000002270F4: 160200FF 00000204
	v_mul_u32_u24_e32 v2, 0x4080, v6                           // 0000002270FC: 16040CFF 00004080
	s_cmp_lg_u64 s[20:21], 0                                   // 000000227104: BF118014
	s_mov_b32 s34, 0                                           // 000000227108: BEA20080
	s_cselect_b32 s31, -1, 0                                   // 00000022710C: 981F80C1
	s_cmp_lg_u64 s[18:19], 0                                   // 000000227110: BF118012
	v_sub_nc_u32_e32 v7, v1, v2                                // 000000227114: 4C0E0501
	s_cselect_b32 s33, -1, 0                                   // 000000227118: 982180C1
	s_mov_b32 s35, 0x41800000                                  // 00000022711C: BEA300FF 41800000
	s_branch 7                                                 // 000000227124: BFA00007 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x244>
	v_add_nc_u32_e32 v5, 0x100, v5                             // 000000227128: 4A0A0AFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000227130: BF8704A1
	v_cmp_le_i32_e32 vcc_lo, s29, v5                           // 000000227134: 7C860A1D
	s_or_b32 s34, vcc_lo, s34                                  // 000000227138: 8C22226A
	s_and_not1_b32 exec_lo, exec_lo, s34                       // 00000022713C: 917E227E
	s_cbranch_execz 163                                        // 000000227140: BFA500A3 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x4d0>
	v_lshrrev_b32_e32 v2, 5, v5                                // 000000227144: 32040A85
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v1, s28, v5      // 000000227148: CA200080 08000A1C
	v_and_b32_e32 v4, 0x7fffffe0, v5                           // 000000227150: 36080AFF 7FFFFFE0
	s_mov_b32 s36, exec_lo                                     // 000000227158: BEA4007E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022715C: BF870113
	v_add_nc_u32_e32 v3, s28, v2                               // 000000227160: 4A06041C
	v_sub_nc_u32_e32 v1, v1, v4                                // 000000227164: 4C020901
	s_delay_alu instid0(VALU_DEP_1)                            // 000000227168: BF870001
	.long 0xd4c3007e                                           // 00000022716C: D4C3007E
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000227170: 02020701
	s_cbranch_execz 107                                        // 000000227174: BFA5006B <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x424>
	v_add_nc_u32_e32 v2, s26, v2                               // 000000227178: 4A04041A
	v_mov_b32_e32 v4, v7                                       // 00000022717C: 7E080307
	s_mov_b64 s[22:23], 0                                      // 000000227180: BE960180
	s_delay_alu instid0(VALU_DEP_2)                            // 000000227184: BF870002
	v_readfirstlane_b32 s0, v2                                 // 000000227188: 7E000502
	v_mov_b32_e32 v2, 0                                        // 00000022718C: 7E040280
	s_mul_i32 s1, s0, 48                                       // 000000227190: 9601B000
	s_mul_hi_i32 s2, s0, 48                                    // 000000227194: 9702B000
	s_add_u32 s0, s1, s24                                      // 000000227198: 80001801
	s_addc_u32 s1, s2, s25                                     // 00000022719C: 82011902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002271A0: BF870499
	s_lshl_b64 s[0:1], s[0:1], 9                               // 0000002271A4: 84808900
	s_add_u32 s37, s16, s0                                     // 0000002271A8: 80250010
	s_addc_u32 s38, s17, s1                                    // 0000002271AC: 82260111
	s_set_inst_prefetch_distance 0x1                           // 0000002271B0: BF840001
	s_nop 0                                                    // 0000002271B4: BF800000
	s_nop 0                                                    // 0000002271B8: BF800000
	s_nop 0                                                    // 0000002271BC: BF800000
	s_add_u32 s0, s37, s22                                     // 0000002271C0: 80001625
	s_addc_u32 s1, s38, s23                                    // 0000002271C4: 82011726
	ds_load_2addr_b32 v[8:9], v4 offset1:1                     // 0000002271C8: D8DC0100 08000004
	s_load_b512 s[0:15], s[0:1], null                          // 0000002271D0: F4100000 F8000000
	ds_load_2addr_b32 v[10:11], v4 offset0:2 offset1:3         // 0000002271D8: D8DC0302 0A000004
	ds_load_2addr_b32 v[12:13], v4 offset0:4 offset1:5         // 0000002271E0: D8DC0504 0C000004
	ds_load_2addr_b32 v[14:15], v4 offset0:6 offset1:7         // 0000002271E8: D8DC0706 0E000004
	s_add_u32 s22, s22, 64                                     // 0000002271F0: 8016C016
	s_addc_u32 s23, s23, 0                                     // 0000002271F4: 82178017
	s_cmpk_eq_i32 s22, 0x200                                   // 0000002271F8: B1960200
	s_waitcnt lgkmcnt(0)                                       // 0000002271FC: BF89FC07
	v_fmac_f32_e32 v2, s0, v8                                  // 000000227200: 56041000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000227204: BF8700B1
	v_fmac_f32_e32 v2, s1, v9                                  // 000000227208: 56041201
	ds_load_2addr_b32 v[8:9], v4 offset0:8 offset1:9           // 00000022720C: D8DC0908 08000004
	v_fmac_f32_e32 v2, s2, v10                                 // 000000227214: 56041402
	v_fmac_f32_e32 v2, s3, v11                                 // 000000227218: 56041603
	ds_load_2addr_b32 v[10:11], v4 offset0:10 offset1:11       // 00000022721C: D8DC0B0A 0A000004
	v_fmac_f32_e32 v2, s4, v12                                 // 000000227224: 56041804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000227228: BF870091
	v_fmac_f32_e32 v2, s5, v13                                 // 00000022722C: 56041A05
	v_fmac_f32_e32 v2, s6, v14                                 // 000000227230: 56041C06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000227234: BF870001
	v_fmac_f32_e32 v2, s7, v15                                 // 000000227238: 56041E07
	ds_load_2addr_b32 v[12:13], v4 offset0:12 offset1:13       // 00000022723C: D8DC0D0C 0C000004
	ds_load_2addr_b32 v[14:15], v4 offset0:14 offset1:15       // 000000227244: D8DC0F0E 0E000004
	v_add_nc_u32_e32 v4, 64, v4                                // 00000022724C: 4A0808C0
	s_waitcnt lgkmcnt(3)                                       // 000000227250: BF89FC37
	v_fmac_f32_e32 v2, s8, v8                                  // 000000227254: 56041008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000227258: BF8700A1
	v_fmac_f32_e32 v2, s9, v9                                  // 00000022725C: 56041209
	s_waitcnt lgkmcnt(2)                                       // 000000227260: BF89FC27
	v_fmac_f32_e32 v2, s10, v10                                // 000000227264: 5604140A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000227268: BF8700A1
	v_fmac_f32_e32 v2, s11, v11                                // 00000022726C: 5604160B
	s_waitcnt lgkmcnt(1)                                       // 000000227270: BF89FC17
	v_fmac_f32_e32 v2, s12, v12                                // 000000227274: 5604180C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000227278: BF8700A1
	v_fmac_f32_e32 v2, s13, v13                                // 00000022727C: 56041A0D
	s_waitcnt lgkmcnt(0)                                       // 000000227280: BF89FC07
	v_fmac_f32_e32 v2, s14, v14                                // 000000227284: 56041C0E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000227288: BF870001
	v_fmac_f32_e32 v2, s15, v15                                // 00000022728C: 56041E0F
	s_cbranch_scc0 65483                                       // 000000227290: BFA1FFCB <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x2c0>
	s_set_inst_prefetch_distance 0x2                           // 000000227294: BF840002
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000227298: 30080682
	v_lshlrev_b32_e32 v8, 2, v1                                // 00000022729C: 30100282
	ds_load_b32 v4, v4 offset:16512                            // 0000002272A0: D8D84080 04000004
	ds_load_b32 v8, v8 offset:16512                            // 0000002272A8: D8D84080 08000008
	s_waitcnt lgkmcnt(0)                                       // 0000002272B0: BF89FC07
	v_sub_f32_e32 v4, v4, v8                                   // 0000002272B4: 08081104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002272B8: BF870121
	v_mul_f32_e32 v8, 0x3fb8aa3b, v4                           // 0000002272BC: 101008FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 0000002272C4: 7C3608FF C2CE8ED0
	v_fma_f32 v9, 0x3fb8aa3b, v4, -v8                          // 0000002272CC: D6130009 842208FF 3FB8AA3B
	v_rndne_f32_e32 v10, v8                                    // 0000002272D8: 7E144708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002272DC: BF870091
	v_dual_fmac_f32 v9, 0x32a5705f, v4 :: v_dual_sub_f32 v8, v8, v10// 0000002272E0: C80A08FF 09081508 32A5705F
	v_add_f32_e32 v8, v8, v9                                   // 0000002272EC: 06101308
	v_cvt_i32_f32_e32 v9, v10                                  // 0000002272F0: 7E12110A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002272F4: BF870292
	v_exp_f32_e32 v8, v8                                       // 0000002272F8: 7E104B08
	.long 0xd71c0008                                           // 0000002272FC: D71C0008
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 000000227300: 02021308
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000227304: BF870121
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo                        // 000000227308: 02101080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 00000022730C: 7C3C08FF 42B17218
	v_cndmask_b32_e32 v4, 0x7f800000, v8, vcc_lo               // 000000227314: 020810FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022731C: BF870001
	v_mul_f32_e32 v8, v2, v4                                   // 000000227320: 10100902
	s_or_b32 exec_lo, exec_lo, s36                             // 000000227324: 8C7E247E
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000227328: 3408069F
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000022732C: 3404029F
	s_and_not1_b32 vcc_lo, exec_lo, s31                        // 000000227330: 916A1F7E
	s_cbranch_vccnz 17                                         // 000000227334: BFA40011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x47c>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000227338: BF870112
	.long 0xd73c0009                                           // 00000022733C: D73C0009
	v_cndmask_b32_e32 v1, 8, v3, vcc_lo                        // 000000227340: 02020688
	.long 0xd73c000b                                           // 000000227344: D73C000B
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000227348: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022734C: BF870092
	.long 0xd7006a09                                           // 000000227350: D7006A09
	v_cndmask_b32_e32 v1, s20, v9, vcc_lo                      // 000000227354: 02021214
	v_add_co_ci_u32_e64 v10, null, s21, v10, vcc_lo            // 000000227358: D5207C0A 01AA1415
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000227360: BF870092
	.long 0xd7006a09                                           // 000000227364: D7006A09
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 000000227368: 02021709
	v_add_co_ci_u32_e64 v10, null, v10, v12, vcc_lo            // 00000022736C: D5207C0A 01AA190A
	global_store_b32 v[9:10], v8, off                          // 000000227374: DC6A0000 007C0809
	s_and_not1_b32 vcc_lo, exec_lo, s33                        // 00000022737C: 916A217E
	s_cbranch_vccnz 65385                                      // 000000227380: BFA4FF69 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x228>
	.long 0xd73c0003                                           // 000000227384: D73C0003
	v_cndmask_b32_e32 v1, 7, v3, vcc_lo                        // 000000227388: 02020687
	.long 0xd73c0009                                           // 00000022738C: D73C0009
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000227390: 02020281
	v_fma_mixlo_f16 v1, v8, s35, 0                             // 000000227394: CC210001 02004708
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022739C: BF870093
	.long 0xd7006a02                                           // 0000002273A0: D7006A02
	v_cndmask_b32_e32 v1, s18, v3, vcc_lo                      // 0000002273A4: 02020612
	v_add_co_ci_u32_e64 v3, null, s19, v4, vcc_lo              // 0000002273A8: D5207C03 01AA0813
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002273B0: BF870092
	.long 0xd7006a02                                           // 0000002273B4: D7006A02
	v_cndmask_b32_e32 v1, v2, v9, vcc_lo                       // 0000002273B8: 02021302
	v_add_co_ci_u32_e64 v3, null, v3, v10, vcc_lo              // 0000002273BC: D5207C03 01AA1503
	global_store_b16 v[2:3], v1, off                           // 0000002273C4: DC660000 007C0102
	s_branch 65366                                             // 0000002273CC: BFA0FF56 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x228>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000002273D0: 8C7E1E7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002273D4: BF870009
	s_mov_b32 s0, exec_lo                                      // 0000002273D8: BE80007E
	.long 0xd4c4007e                                           // 0000002273DC: D4C4007E
	v_cndmask_b32_e32 v1, s27, v0, vcc_lo                      // 0000002273E0: 0202001B
	s_cbranch_execz 86                                         // 0000002273E4: BFA50056 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x640>
	s_cmp_lg_u64 s[20:21], 0                                   // 0000002273E8: BF118014
	v_and_b32_e32 v1, 0xe0, v0                                 // 0000002273EC: 360200FF 000000E0
	s_cselect_b32 s1, -1, 0                                    // 0000002273F4: 980180C1
	s_ashr_i32 s0, s28, 31                                     // 0000002273F8: 86009F1C
	.long 0xd7000202                                           // 0000002273FC: D7000202
	v_cndmask_b32_e32 v1, s28, v0, vcc_lo                      // 000000227400: 0202001C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000227404: BF8700B1
	v_add_co_ci_u32_e64 v3, null, s0, 0, s2                    // 000000227408: D5207C03 00090000
	s_cmp_lg_u64 s[18:19], 0                                   // 000000227410: BF118012
	.long 0xd7016a02                                           // 000000227414: D7016A02
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000227418: 02020302
	v_subrev_co_ci_u32_e64 v3, null, 0, v3, vcc_lo             // 00000022741C: D5227C03 01AA0680
	v_mov_b32_e32 v1, 0                                        // 000000227424: 7E020280
	v_lshlrev_b32_e32 v7, 8, v6                                // 000000227428: 300E0C88
	v_lshlrev_b32_e32 v6, 7, v6                                // 00000022742C: 300C0C87
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000227430: BF870144
	.long 0xd73c0004                                           // 000000227434: D73C0004
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000227438: 02020482
	.long 0xd73c0002                                           // 00000022743C: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 000000227440: 02020481
	s_cselect_b32 s2, -1, 0                                    // 000000227444: 980280C1
	s_mov_b32 s3, 0                                            // 000000227448: BE830080
	.long 0xd7006a04                                           // 00000022744C: D7006A04
	v_cndmask_b32_e32 v1, v7, v4, vcc_lo                       // 000000227450: 02020907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000227454: BF870191
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo                // 000000227458: D5207C05 01AA0A80
	.long 0xd7006a06                                           // 000000227460: D7006A06
	v_cndmask_b32_e32 v1, v6, v2, vcc_lo                       // 000000227464: 02020506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000227468: BF870211
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 00000022746C: D5207C07 01AA0680
	.long 0xd7006a02                                           // 000000227474: D7006A02
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000227478: 02020814
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022747C: BF870211
	v_add_co_ci_u32_e64 v3, null, s21, v5, vcc_lo              // 000000227480: D5207C03 01AA0A15
	.long 0xd7006a04                                           // 000000227488: D7006A04
	v_cndmask_b32_e32 v1, s18, v6, vcc_lo                      // 00000022748C: 02020C12
	s_delay_alu instid0(VALU_DEP_1)                            // 000000227490: BF870001
	v_add_co_ci_u32_e64 v5, null, s19, v7, vcc_lo              // 000000227494: D5207C05 01AA0E13
	v_dual_mov_b32 v7, v1 :: v_dual_mov_b32 v6, v0             // 00000022749C: CA100101 07060100
	s_set_inst_prefetch_distance 0x1                           // 0000002274A4: BF840001
	s_branch 27                                                // 0000002274A8: BFA0001B <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x618>
	s_nop 0                                                    // 0000002274AC: BF800000
	s_nop 0                                                    // 0000002274B0: BF800000
	s_nop 0                                                    // 0000002274B4: BF800000
	s_nop 0                                                    // 0000002274B8: BF800000
	s_nop 0                                                    // 0000002274BC: BF800000
	.long 0xd7006a06                                           // 0000002274C0: D7006A06
	v_cndmask_b32_e32 v1, 0x100, v6, vcc_lo                    // 0000002274C4: 02020CFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002274CC: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 0000002274D0: D5207C07 01AA0E80
	.long 0xd7006a02                                           // 0000002274D8: D7006A02
	v_cndmask_b32_e32 v1, 0x800, v2, vcc_lo                    // 0000002274DC: 020204FF 00000800
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000002274E4: D5207C03 01AA0680
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002274EC: BF8700A4
	v_cmp_le_i32_e32 vcc_lo, s27, v6                           // 0000002274F0: 7C860C1B
	.long 0xd7000004                                           // 0000002274F4: D7000004
	v_cndmask_b32_e32 v1, 0x400, v4, vcc_lo                    // 0000002274F8: 020208FF 00000400
	v_add_co_ci_u32_e64 v5, null, 0, v5, s0                    // 000000227500: D5207C05 00020A80
	s_or_b32 s3, vcc_lo, s3                                    // 000000227508: 8C03036A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000022750C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000227510: 917E037E
	s_cbranch_execz 10                                         // 000000227514: BFA5000A <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x640>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000227518: 916A017E
	s_cbranch_vccnz 2                                          // 00000022751C: BFA40002 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x628>
	global_store_b32 v[2:3], v1, off                           // 000000227520: DC6A0000 007C0102
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 000000227528: 916A027E
	s_cbranch_vccnz 65508                                      // 00000022752C: BFA4FFE4 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x5c0>
	.long 0x7e003880                                           // 000000227530: 7E003880
	global_store_b16 v[4:5], v0, off                           // 000000227534: DC660000 007C0004
	s_branch 65504                                             // 00000022753C: BFA0FFE0 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x5c0>
	s_set_inst_prefetch_distance 0x2                           // 000000227540: BF840002
	s_endpgm                                                   // 000000227544: BFB00000
		...

