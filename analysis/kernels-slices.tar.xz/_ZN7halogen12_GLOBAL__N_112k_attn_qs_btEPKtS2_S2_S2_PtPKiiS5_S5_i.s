0000000000025e00 <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i>:
; _ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i():
	s_load_b32 s4, s[0:1], 0x30                                // 000000025E00: F4000100 F8000030
	v_lshrrev_b32_e32 v7, 5, v0                                // 000000025E08: 320E0085
	s_mov_b32 s20, s3                                          // 000000025E0C: BE940003
	s_lshl_b32 s3, s2, 2                                       // 000000025E10: 84038202
	s_mov_b32 s2, exec_lo                                      // 000000025E14: BE82007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000025E18: BF8700A1
	v_or_b32_e32 v1, s3, v7                                    // 000000025E1C: 38020E03
	s_waitcnt lgkmcnt(0)                                       // 000000025E20: BF89FC07
	.long 0xd4c4007e                                           // 000000025E24: D4C4007E
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000025E28: 02020204
	s_cbranch_execz 7830                                       // 000000025E2C: BFA51E96 <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x7a88>
	s_clause 0x1                                               // 000000025E30: BF850001
	s_load_b128 s[16:19], s[0:1], 0x38                         // 000000025E34: F4080400 F8000038
	s_load_b128 s[12:15], s[0:1], 0x20                         // 000000025E3C: F4080300 F8000020
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000025E44: 3404029F
	s_clause 0x1                                               // 000000025E48: BF850001
	s_load_b32 s2, s[0:1], 0x48                                // 000000025E4C: F4000080 F8000048
	s_load_b256 s[4:11], s[0:1], null                          // 000000025E54: F40C0100 F8000000
	s_mov_b32 s1, exec_lo                                      // 000000025E5C: BE81007E
	.long 0xd73c0002                                           // 000000025E60: D73C0002
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000025E64: 02020282
	s_waitcnt lgkmcnt(0)                                       // 000000025E68: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025E6C: BF870091
	.long 0xd7006a02                                           // 000000025E70: D7006A02
	v_cndmask_b32_e32 v1, s18, v2, vcc_lo                      // 000000025E74: 02020412
	v_add_co_ci_u32_e64 v3, null, s19, v3, vcc_lo              // 000000025E78: D5207C03 01AA0613
	s_load_b32 s14, s[14:15], null                             // 000000025E80: F4000387 F8000000
	global_load_b32 v15, v[2:3], off                           // 000000025E88: DC520000 0F7C0002
	s_waitcnt lgkmcnt(0)                                       // 000000025E90: BF89FC07
	v_add_nc_u32_e32 v4, s14, v1                               // 000000025E94: 4A08020E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025E98: BF870091
	v_add_nc_u32_e32 v2, 1, v4                                 // 000000025E9C: 4A040881
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000025EA0: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025EA4: BF870091
	v_lshrrev_b32_e32 v3, 30, v3                               // 000000025EA8: 3206069E
	v_add_nc_u32_e32 v5, v2, v3                                // 000000025EAC: 4A0A0702
	v_mad_i64_i32 v[2:3], null, s2, v1, 0                      // 000000025EB0: D6FF7C02 02020202
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000025EB8: BF8701A2
	v_and_b32_e32 v8, -4, v5                                   // 000000025EBC: 36100AC4
	v_ashrrev_i32_e32 v5, 2, v5                                // 000000025EC0: 340A0A82
	.long 0xd73c0002                                           // 000000025EC4: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000025EC8: 02020482
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000025ECC: BF870193
	v_sub_nc_u32_e32 v4, v4, v8                                // 000000025ED0: 4C081104
	v_mov_b32_e32 v6, v5                                       // 000000025ED4: 7E0C0305
	s_delay_alu instid0(VALU_DEP_2)                            // 000000025ED8: BF870002
	v_cmp_lt_i32_e32 vcc_lo, -1, v4                            // 000000025EDC: 7C8208C1
	v_cmpx_gt_i32_e32 0, v4                                    // 000000025EE0: 7D880880
	s_cbranch_execz 17                                         // 000000025EE4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x12c>
	s_waitcnt vmcnt(0)                                         // 000000025EE8: BF8903F7
	v_max_i32_e32 v9, 1, v15                                   // 000000025EEC: 24121E81
	v_mov_b32_e32 v10, 0                                       // 000000025EF0: 7E140280
	.long 0xd7000004                                           // 000000025EF4: D7000004
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 000000025EF8: 02020410
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000025EFC: BF870191
	v_add_co_ci_u32_e64 v6, null, s17, v3, s0                  // 000000025F00: D5207C06 00020611
	.long 0xd73c0009                                           // 000000025F08: D73C0009
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000025F0C: 02021282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025F10: BF870091
	.long 0xd7000009                                           // 000000025F14: D7000009
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 000000025F18: 02021304
	v_add_co_ci_u32_e64 v10, null, v6, v10, s0                 // 000000025F1C: D5207C0A 00021506
	global_load_b32 v6, v[9:10], off offset:-4                 // 000000025F24: DC521FFC 067C0009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000025F2C: 8C7E017E
	v_cndmask_b32_e64 v4, 0, 1, vcc_lo                         // 000000025F30: D5010004 01A90280
	v_mul_u32_u24_e32 v255, 0x2010, v7                         // 000000025F38: 17FE0EFF 00002010
	s_mov_b32 s1, exec_lo                                      // 000000025F40: BE81007E
	s_waitcnt vmcnt(0)                                         // 000000025F44: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000025F48: BF870122
	v_add_nc_u32_e32 v10, v15, v4                              // 000000025F4C: 4A14090F
	v_and_b32_e32 v4, 31, v0                                   // 000000025F50: 3608009F
	v_add_nc_u32_e32 v9, 3, v10                                // 000000025F54: 4A121483
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025F58: BF870091
	v_and_b32_e32 v11, -4, v9                                  // 000000025F5C: 361612C4
	.long 0xd4c1007e                                           // 000000025F60: D4C1007E
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 000000025F64: 02021704
	s_cbranch_execz 50                                         // 000000025F68: BFA50032 <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x234>
	v_lshlrev_b32_e32 v12, 2, v4                               // 000000025F6C: 30180882
	v_mul_u32_u24_e32 v13, 0x2010, v7                          // 000000025F70: 161A0EFF 00002010
	s_mov_b32 s2, 0                                            // 000000025F78: BE820080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025F7C: BF870092
	.long 0xd7006a02                                           // 000000025F80: D7006A02
	v_cndmask_b32_e32 v1, v2, v12, vcc_lo                      // 000000025F84: 02021902
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000025F88: D5207C03 01AA0680
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000025F90: BF870193
	v_lshl_add_u32 v12, v4, 2, v13                             // 000000025F94: D646000C 04350504
	.long 0xd7006a02                                           // 000000025F9C: D7006A02
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 000000025FA0: 02020410
	s_delay_alu instid0(VALU_DEP_1)                            // 000000025FA4: BF870001
	v_add_co_ci_u32_e64 v3, null, s17, v3, vcc_lo              // 000000025FA8: D5207C03 01AA0611
	v_mov_b32_e32 v13, v4                                      // 000000025FB0: 7E1A0304
	s_set_inst_prefetch_distance 0x1                           // 000000025FB4: BF840001
	s_branch 18                                                // 000000025FB8: BFA00012 <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x204>
	s_nop 0                                                    // 000000025FBC: BF800000
	s_or_b32 exec_lo, exec_lo, s0                              // 000000025FC0: 8C7E007E
	v_add_nc_u32_e32 v13, 32, v13                              // 000000025FC4: 4A1A1AA0
	.long 0xd7000002                                           // 000000025FC8: D7000002
	v_cndmask_b32_e32 v1, 0x80, v2, vcc_lo                     // 000000025FCC: 020204FF 00000080
	s_waitcnt vmcnt(0)                                         // 000000025FD4: BF8903F7
	ds_store_b32 v12, v14 offset:2048                          // 000000025FD8: D8340800 00000E0C
	v_add_co_ci_u32_e64 v3, null, 0, v3, s0                    // 000000025FE0: D5207C03 00020680
	v_cmp_ge_i32_e32 vcc_lo, v13, v11                          // 000000025FE8: 7C8C170D
	v_add_nc_u32_e32 v12, 0x80, v12                            // 000000025FEC: 4A1818FF 00000080
	s_or_b32 s2, vcc_lo, s2                                    // 000000025FF4: 8C02026A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000025FF8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 000000025FFC: 917E027E
	s_cbranch_execz 12                                         // 000000026000: BFA5000C <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x234>
	s_mov_b32 s0, exec_lo                                      // 000000026004: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000026008: BF870001
	.long 0xd4c6007e                                           // 00000002600C: D4C6007E
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 000000026010: 02021F0D
	s_xor_b32 s0, exec_lo, s0                                  // 000000026014: 8D00007E
	v_cmp_lt_i32_e32 vcc_lo, v13, v10                          // 000000026018: 7C82150D
	v_cndmask_b32_e32 v14, v6, v5, vcc_lo                      // 00000002601C: 021C0B06
	s_and_not1_saveexec_b32 s0, s0                             // 000000026020: BE803000
	s_cbranch_execz 65510                                      // 000000026024: BFA5FFE6 <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1c0>
	global_load_b32 v14, v[2:3], off                           // 000000026028: DC520000 0E7C0002
	s_branch 65507                                             // 000000026030: BFA0FFE3 <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1c0>
	s_set_inst_prefetch_distance 0x2                           // 000000026034: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 000000026038: 8C7E017E
	v_mad_i64_i32 v[213:214], null, 0x1800, v1, 0              // 00000002603C: D6FF7CD5 020202FF 00001800
	v_ashrrev_i32_e32 v254, 2, v9                              // 000000026048: 35FC1282
	v_and_b32_e32 v253, 15, v0                                 // 00000002604C: 37FA008F
	s_mov_b32 s0, exec_lo                                      // 000000026050: BE80007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000026054: BF870002
	v_cmpx_gt_i32_e32 1, v254                                  // 000000026058: 7D89FC81
	s_xor_b32 s0, exec_lo, s0                                  // 00000002605C: 8D00007E
	v_mov_b32_e32 v129, 0                                      // 000000026060: 7F020280
	s_or_saveexec_b32 s1, s0                                   // 000000026064: BE812200
	v_mov_b32_e32 v6, 0                                        // 000000026068: 7E0C0280
	v_lshrrev_b32_e32 v215, 4, v4                              // 00000002606C: 33AE0884
	s_mul_i32 s2, s20, 12                                      // 000000026070: 96028C14
	s_delay_alu instid0(VALU_DEP_2)                            // 000000026074: BF870002
	v_mov_b32_e32 v5, v6                                       // 000000026078: 7E0A0306
	v_mov_b32_e32 v4, v6                                       // 00000002607C: 7E080306
	v_mov_b32_e32 v3, v6                                       // 000000026080: 7E060306
	v_mov_b32_e32 v2, v6                                       // 000000026084: 7E040306
	v_mov_b32_e32 v1, v6                                       // 000000026088: 7E020306
	v_mov_b32_e32 v14, v6                                      // 00000002608C: 7E1C0306
	v_mov_b32_e32 v13, v6                                      // 000000026090: 7E1A0306
	v_mov_b32_e32 v12, v6                                      // 000000026094: 7E180306
	v_mov_b32_e32 v11, v6                                      // 000000026098: 7E160306
	v_mov_b32_e32 v10, v6                                      // 00000002609C: 7E140306
	v_mov_b32_e32 v9, v6                                       // 0000000260A0: 7E120306
	v_mov_b32_e32 v22, v6                                      // 0000000260A4: 7E2C0306
	v_mov_b32_e32 v21, v6                                      // 0000000260A8: 7E2A0306
	v_mov_b32_e32 v20, v6                                      // 0000000260AC: 7E280306
	v_mov_b32_e32 v19, v6                                      // 0000000260B0: 7E260306
	v_mov_b32_e32 v18, v6                                      // 0000000260B4: 7E240306
	v_mov_b32_e32 v17, v6                                      // 0000000260B8: 7E220306
	v_mov_b32_e32 v30, v6                                      // 0000000260BC: 7E3C0306
	v_mov_b32_e32 v29, v6                                      // 0000000260C0: 7E3A0306
	v_mov_b32_e32 v28, v6                                      // 0000000260C4: 7E380306
	v_mov_b32_e32 v27, v6                                      // 0000000260C8: 7E360306
	v_mov_b32_e32 v26, v6                                      // 0000000260CC: 7E340306
	v_mov_b32_e32 v25, v6                                      // 0000000260D0: 7E320306
	v_mov_b32_e32 v38, v6                                      // 0000000260D4: 7E4C0306
	v_mov_b32_e32 v37, v6                                      // 0000000260D8: 7E4A0306
	v_mov_b32_e32 v36, v6                                      // 0000000260DC: 7E480306
	v_mov_b32_e32 v35, v6                                      // 0000000260E0: 7E460306
	v_mov_b32_e32 v34, v6                                      // 0000000260E4: 7E440306
	v_mov_b32_e32 v33, v6                                      // 0000000260E8: 7E420306
	v_mov_b32_e32 v46, v6                                      // 0000000260EC: 7E5C0306
	v_mov_b32_e32 v45, v6                                      // 0000000260F0: 7E5A0306
	v_mov_b32_e32 v44, v6                                      // 0000000260F4: 7E580306
	v_mov_b32_e32 v43, v6                                      // 0000000260F8: 7E560306
	v_mov_b32_e32 v42, v6                                      // 0000000260FC: 7E540306
	v_mov_b32_e32 v41, v6                                      // 000000026100: 7E520306
	v_mov_b32_e32 v54, v6                                      // 000000026104: 7E6C0306
	v_mov_b32_e32 v53, v6                                      // 000000026108: 7E6A0306
	v_mov_b32_e32 v52, v6                                      // 00000002610C: 7E680306
	v_mov_b32_e32 v51, v6                                      // 000000026110: 7E660306
	v_mov_b32_e32 v50, v6                                      // 000000026114: 7E640306
	v_mov_b32_e32 v49, v6                                      // 000000026118: 7E620306
	v_mov_b32_e32 v62, v6                                      // 00000002611C: 7E7C0306
	v_mov_b32_e32 v61, v6                                      // 000000026120: 7E7A0306
	v_mov_b32_e32 v60, v6                                      // 000000026124: 7E780306
	v_mov_b32_e32 v59, v6                                      // 000000026128: 7E760306
	v_mov_b32_e32 v58, v6                                      // 00000002612C: 7E740306
	v_mov_b32_e32 v57, v6                                      // 000000026130: 7E720306
	v_mov_b32_e32 v70, v6                                      // 000000026134: 7E8C0306
	v_mov_b32_e32 v69, v6                                      // 000000026138: 7E8A0306
	v_mov_b32_e32 v68, v6                                      // 00000002613C: 7E880306
	v_mov_b32_e32 v67, v6                                      // 000000026140: 7E860306
	v_mov_b32_e32 v66, v6                                      // 000000026144: 7E840306
	v_mov_b32_e32 v65, v6                                      // 000000026148: 7E820306
	v_mov_b32_e32 v78, v6                                      // 00000002614C: 7E9C0306
	v_mov_b32_e32 v77, v6                                      // 000000026150: 7E9A0306
	v_mov_b32_e32 v76, v6                                      // 000000026154: 7E980306
	v_mov_b32_e32 v75, v6                                      // 000000026158: 7E960306
	v_mov_b32_e32 v74, v6                                      // 00000002615C: 7E940306
	v_mov_b32_e32 v73, v6                                      // 000000026160: 7E920306
	v_mov_b32_e32 v86, v6                                      // 000000026164: 7EAC0306
	v_mov_b32_e32 v85, v6                                      // 000000026168: 7EAA0306
	v_mov_b32_e32 v84, v6                                      // 00000002616C: 7EA80306
	v_mov_b32_e32 v83, v6                                      // 000000026170: 7EA60306
	v_mov_b32_e32 v82, v6                                      // 000000026174: 7EA40306
	v_mov_b32_e32 v81, v6                                      // 000000026178: 7EA20306
	v_mov_b32_e32 v94, v6                                      // 00000002617C: 7EBC0306
	v_mov_b32_e32 v93, v6                                      // 000000026180: 7EBA0306
	v_mov_b32_e32 v92, v6                                      // 000000026184: 7EB80306
	v_mov_b32_e32 v91, v6                                      // 000000026188: 7EB60306
	v_mov_b32_e32 v90, v6                                      // 00000002618C: 7EB40306
	v_mov_b32_e32 v89, v6                                      // 000000026190: 7EB20306
	v_mov_b32_e32 v102, v6                                     // 000000026194: 7ECC0306
	v_mov_b32_e32 v101, v6                                     // 000000026198: 7ECA0306
	v_mov_b32_e32 v100, v6                                     // 00000002619C: 7EC80306
	v_mov_b32_e32 v99, v6                                      // 0000000261A0: 7EC60306
	v_mov_b32_e32 v98, v6                                      // 0000000261A4: 7EC40306
	v_mov_b32_e32 v97, v6                                      // 0000000261A8: 7EC20306
	v_mov_b32_e32 v110, v6                                     // 0000000261AC: 7EDC0306
	v_mov_b32_e32 v109, v6                                     // 0000000261B0: 7EDA0306
	v_mov_b32_e32 v108, v6                                     // 0000000261B4: 7ED80306
	v_mov_b32_e32 v107, v6                                     // 0000000261B8: 7ED60306
	v_mov_b32_e32 v106, v6                                     // 0000000261BC: 7ED40306
	v_mov_b32_e32 v105, v6                                     // 0000000261C0: 7ED20306
	v_mov_b32_e32 v118, v6                                     // 0000000261C4: 7EEC0306
	v_mov_b32_e32 v117, v6                                     // 0000000261C8: 7EEA0306
	v_mov_b32_e32 v116, v6                                     // 0000000261CC: 7EE80306
	v_mov_b32_e32 v115, v6                                     // 0000000261D0: 7EE60306
	v_mov_b32_e32 v114, v6                                     // 0000000261D4: 7EE40306
	v_mov_b32_e32 v113, v6                                     // 0000000261D8: 7EE20306
	v_mov_b32_e32 v126, v6                                     // 0000000261DC: 7EFC0306
	v_mov_b32_e32 v125, v6                                     // 0000000261E0: 7EFA0306
	v_mov_b32_e32 v124, v6                                     // 0000000261E4: 7EF80306
	v_mov_b32_e32 v123, v6                                     // 0000000261E8: 7EF60306
	v_mov_b32_e32 v122, v6                                     // 0000000261EC: 7EF40306
	v_mov_b32_e32 v121, v6                                     // 0000000261F0: 7EF20306
	v_mov_b32_e32 v167, v6                                     // 0000000261F4: 7F4E0306
	v_mov_b32_e32 v166, v6                                     // 0000000261F8: 7F4C0306
	v_mov_b32_e32 v161, v6                                     // 0000000261FC: 7F420306
	v_mov_b32_e32 v250, v6                                     // 000000026200: 7FF40306
	v_mov_b32_e32 v249, v6                                     // 000000026204: 7FF20306
	v_mov_b32_e32 v136, v6                                     // 000000026208: 7F100306
	s_xor_b32 exec_lo, exec_lo, s1                             // 00000002620C: 8D7E017E
	s_cbranch_execz 1775                                       // 000000026210: BFA506EF <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1fd0>
	v_cmp_gt_u32_e32 vcc_lo, 12, v253                          // 000000026214: 7C99FA8C
	.long 0xd73c0003                                           // 000000026218: D73C0003
	v_cndmask_b32_e32 v1, 1, v213, vcc_lo                      // 00000002621C: 0203AA81
	s_ashr_i32 s21, s20, 31                                    // 000000026220: 86159F14
	v_dual_mov_b32 v121, 0 :: v_dual_lshlrev_b32 v0, 5, v0     // 000000026224: CA220080 79000085
	v_cndmask_b32_e32 v1, 0, v253, vcc_lo                      // 00000002622C: 0203FA80
	v_mov_b32_e32 v129, 0                                      // 000000026230: 7F020280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000026234: BF870094
	.long 0xd7006a03                                           // 000000026238: D7006A03
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 00000002623C: 02020604
	v_add_co_ci_u32_e64 v4, null, s5, v4, vcc_lo               // 000000026240: D5207C04 01AA0805
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000026248: BF870144
	v_add_lshl_u32 v1, v1, s2, 8                               // 00000002624C: D6470001 02200501
	s_lshl_b64 s[4:5], s[20:21], 11                            // 000000026254: 84848B14
	v_dual_mov_b32 v123, v129 :: v_dual_and_b32 v130, 0x60, v0 // 000000026258: CA240181 7B8200FF 00000060
	s_add_u32 s0, s6, s4                                       // 000000026264: 80000406
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000026268: 3404029F
	s_addc_u32 s6, s7, s5                                      // 00000002626C: 82060507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000026270: BF8701A2
	.long 0xd70000a8                                           // 000000026274: D70000A8
	v_cndmask_b32_e32 v1, s0, v130, vcc_lo                     // 000000026278: 02030400
	v_dual_mov_b32 v124, v129 :: v_dual_mov_b32 v113, 0        // 00000002627C: CA100181 7C700080
	.long 0xd73c0001                                           // 000000026284: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000026288: 02020281
	v_dual_mov_b32 v125, v129 :: v_dual_mov_b32 v182, 0xf149f2ca// 00000002628C: CA100181 7DB600FF F149F2CA
	v_dual_mov_b32 v126, v129 :: v_dual_mov_b32 v105, 0        // 000000026298: CA100181 7E680080
	v_dual_mov_b32 v127, v129 :: v_dual_mov_b32 v184, 0xf149f2ca// 0000000262A0: CA100181 7FB800FF F149F2CA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000262AC: BF870094
	.long 0xd7006a01                                           // 0000000262B0: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000000262B4: 02020303
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 0000000262B8: D5207C02 01AA0504
	s_clause 0x1                                               // 0000000262C0: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:16           // 0000000262C4: DC5E0010 147C0001
	global_load_b128 v[16:19], v[1:2], off                     // 0000000262CC: DC5E0000 107C0001
	v_lshlrev_b32_e32 v3, 5, v215                              // 0000000262D4: 3007AE85
	v_lshlrev_b32_e32 v4, 1, v253                              // 0000000262D8: 3009FA81
	v_dual_mov_b32 v128, v129 :: v_dual_mov_b32 v97, 0         // 0000000262DC: CA100181 80600080
	v_dual_mov_b32 v114, v129 :: v_dual_mov_b32 v89, 0         // 0000000262E4: CA100181 72580080
	v_dual_mov_b32 v115, v129 :: v_dual_mov_b32 v186, 0xf149f2ca// 0000000262EC: CA100181 73BA00FF F149F2CA
	v_dual_mov_b32 v116, v129 :: v_dual_mov_b32 v81, 0         // 0000000262F8: CA100181 74500080
	v_dual_mov_b32 v117, v129 :: v_dual_mov_b32 v188, 0xf149f2ca// 000000026300: CA100181 75BC00FF F149F2CA
	v_dual_mov_b32 v118, v129 :: v_dual_mov_b32 v73, 0         // 00000002630C: CA100181 76480080
	v_dual_mov_b32 v119, v129 :: v_dual_mov_b32 v192, 0xf149f2ca// 000000026314: CA100181 77C000FF F149F2CA
	v_dual_mov_b32 v120, v129 :: v_dual_mov_b32 v65, 0         // 000000026320: CA100181 78400080
	v_dual_mov_b32 v106, v129 :: v_dual_mov_b32 v57, 0         // 000000026328: CA100181 6A380080
	v_dual_mov_b32 v107, v129 :: v_dual_mov_b32 v196, 0xf149f2ca// 000000026330: CA100181 6BC400FF F149F2CA
	v_dual_mov_b32 v108, v129 :: v_dual_mov_b32 v49, 0         // 00000002633C: CA100181 6C300080
	v_dual_mov_b32 v109, v129 :: v_dual_mov_b32 v176, 0        // 000000026344: CA100181 6DB00080
	v_dual_mov_b32 v110, v129 :: v_dual_mov_b32 v41, 0         // 00000002634C: CA100181 6E280080
	v_dual_mov_b32 v111, v129 :: v_dual_mov_b32 v174, 0        // 000000026354: CA100181 6FAE0080
	v_dual_mov_b32 v112, v129 :: v_dual_mov_b32 v33, 0         // 00000002635C: CA100181 70200080
	v_dual_mov_b32 v98, v129 :: v_dual_mov_b32 v25, 0          // 000000026364: CA100181 62180080
	v_dual_mov_b32 v99, v129 :: v_dual_mov_b32 v172, 0         // 00000002636C: CA100181 63AC0080
	v_mov_b32_e32 v100, v129                                   // 000000026374: 7EC80381
	v_dual_mov_b32 v101, v129 :: v_dual_mov_b32 v170, 0        // 000000026378: CA100181 65AA0080
	v_dual_mov_b32 v102, v129 :: v_dual_mov_b32 v9, 0          // 000000026380: CA100181 66080080
	v_mov_b32_e32 v103, v129                                   // 000000026388: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 00000002638C: 7ED00381
	v_dual_mov_b32 v90, v129 :: v_dual_mov_b32 v191, 0xf149f2ca// 000000026390: CA100181 5ABE00FF F149F2CA
	v_mov_b32_e32 v91, v129                                    // 00000002639C: 7EB60381
	v_dual_mov_b32 v92, v129 :: v_dual_mov_b32 v195, 0xf149f2ca// 0000000263A0: CA100181 5CC200FF F149F2CA
	v_mov_b32_e32 v93, v129                                    // 0000000263AC: 7EBA0381
	v_dual_mov_b32 v94, v129 :: v_dual_mov_b32 v177, 0         // 0000000263B0: CA100181 5EB00080
	v_mov_b32_e32 v95, v129                                    // 0000000263B8: 7EBE0381
	v_dual_mov_b32 v96, v129 :: v_dual_mov_b32 v175, 0         // 0000000263BC: CA100181 60AE0080
	v_dual_mov_b32 v82, v129 :: v_dual_mov_b32 v173, 0         // 0000000263C4: CA100181 52AC0080
	v_mov_b32_e32 v83, v129                                    // 0000000263CC: 7EA60381
	v_dual_mov_b32 v84, v129 :: v_dual_mov_b32 v171, 0         // 0000000263D0: CA100181 54AA0080
	v_mov_b32_e32 v85, v129                                    // 0000000263D8: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 0000000263DC: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 0000000263E0: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 0000000263E4: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 0000000263E8: 7E940381
	v_mov_b32_e32 v75, v129                                    // 0000000263EC: 7E960381
	v_mov_b32_e32 v76, v129                                    // 0000000263F0: 7E980381
	v_mov_b32_e32 v77, v129                                    // 0000000263F4: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 0000000263F8: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 0000000263FC: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 000000026400: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 000000026404: 7E840381
	v_mov_b32_e32 v67, v129                                    // 000000026408: 7E860381
	v_mov_b32_e32 v68, v129                                    // 00000002640C: 7E880381
	v_mov_b32_e32 v69, v129                                    // 000000026410: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 000000026414: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 000000026418: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 00000002641C: 7E900381
	v_mov_b32_e32 v58, v129                                    // 000000026420: 7E740381
	v_mov_b32_e32 v59, v129                                    // 000000026424: 7E760381
	v_mov_b32_e32 v60, v129                                    // 000000026428: 7E780381
	v_mov_b32_e32 v61, v129                                    // 00000002642C: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 000000026430: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 000000026434: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 000000026438: 7E800381
	v_mov_b32_e32 v50, v129                                    // 00000002643C: 7E640381
	v_mov_b32_e32 v51, v129                                    // 000000026440: 7E660381
	v_mov_b32_e32 v52, v129                                    // 000000026444: 7E680381
	v_mov_b32_e32 v53, v129                                    // 000000026448: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 00000002644C: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 000000026450: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 000000026454: 7E700381
	v_mov_b32_e32 v42, v129                                    // 000000026458: 7E540381
	v_mov_b32_e32 v43, v129                                    // 00000002645C: 7E560381
	v_mov_b32_e32 v44, v129                                    // 000000026460: 7E580381
	v_mov_b32_e32 v45, v129                                    // 000000026464: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 000000026468: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 00000002646C: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 000000026470: 7E600381
	v_mov_b32_e32 v34, v129                                    // 000000026474: 7E440381
	v_mov_b32_e32 v35, v129                                    // 000000026478: 7E460381
	v_mov_b32_e32 v36, v129                                    // 00000002647C: 7E480381
	v_mov_b32_e32 v37, v129                                    // 000000026480: 7E4A0381
	v_mov_b32_e32 v38, v129                                    // 000000026484: 7E4C0381
	v_mov_b32_e32 v39, v129                                    // 000000026488: 7E4E0381
	v_mov_b32_e32 v40, v129                                    // 00000002648C: 7E500381
	v_mov_b32_e32 v26, v129                                    // 000000026490: 7E340381
	v_mov_b32_e32 v27, v129                                    // 000000026494: 7E360381
	v_mov_b32_e32 v28, v129                                    // 000000026498: 7E380381
	v_mov_b32_e32 v29, v129                                    // 00000002649C: 7E3A0381
	v_mov_b32_e32 v30, v129                                    // 0000000264A0: 7E3C0381
	v_mov_b32_e32 v31, v129                                    // 0000000264A4: 7E3E0381
	v_mov_b32_e32 v32, v129                                    // 0000000264A8: 7E400381
	v_mov_b32_e32 v24, v129                                    // 0000000264AC: 7E300381
	v_mov_b32_e32 v10, v129                                    // 0000000264B0: 7E140381
	v_mov_b32_e32 v11, v129                                    // 0000000264B4: 7E160381
	v_mov_b32_e32 v12, v129                                    // 0000000264B8: 7E180381
	v_mov_b32_e32 v13, v129                                    // 0000000264BC: 7E1A0381
	v_mov_b32_e32 v14, v129                                    // 0000000264C0: 7E1C0381
	v_mov_b32_e32 v5, v129                                     // 0000000264C4: 7E0A0381
	v_mov_b32_e32 v6, v129                                     // 0000000264C8: 7E0C0381
	v_add_co_ci_u32_e64 v169, null, s6, 0, s0                  // 0000000264CC: D5207CA9 00010006
	s_waitcnt vmcnt(0)                                         // 0000000264D4: BF8903F7
	s_clause 0x1                                               // 0000000264D8: BF850001
	scratch_store_b128 off, v[16:19], off                      // 0000000264DC: DC750000 007C1000
	scratch_store_b128 off, v[20:23], off offset:16            // 0000000264E4: DC750010 007C1400
	s_clause 0x1                                               // 0000000264EC: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:48           // 0000000264F0: DC5E0030 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:32           // 0000000264F8: DC5E0020 107C0001
	s_waitcnt vmcnt(0)                                         // 000000026500: BF8903F7
	s_clause 0x1                                               // 000000026504: BF850001
	scratch_store_b128 off, v[16:19], off offset:32            // 000000026508: DC750020 007C1000
	scratch_store_b128 off, v[20:23], off offset:48            // 000000026510: DC750030 007C1400
	s_clause 0x1                                               // 000000026518: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:80           // 00000002651C: DC5E0050 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:64           // 000000026524: DC5E0040 107C0001
	s_waitcnt vmcnt(0)                                         // 00000002652C: BF8903F7
	s_clause 0x1                                               // 000000026530: BF850001
	scratch_store_b128 off, v[16:19], off offset:64            // 000000026534: DC750040 007C1000
	scratch_store_b128 off, v[20:23], off offset:80            // 00000002653C: DC750050 007C1400
	s_clause 0x1                                               // 000000026544: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:112          // 000000026548: DC5E0070 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:96           // 000000026550: DC5E0060 107C0001
	s_waitcnt vmcnt(0)                                         // 000000026558: BF8903F7
	s_clause 0x1                                               // 00000002655C: BF850001
	scratch_store_b128 off, v[16:19], off offset:96            // 000000026560: DC750060 007C1000
	scratch_store_b128 off, v[20:23], off offset:112           // 000000026568: DC750070 007C1400
	s_clause 0x1                                               // 000000026570: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:144          // 000000026574: DC5E0090 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:128          // 00000002657C: DC5E0080 107C0001
	s_waitcnt vmcnt(0)                                         // 000000026584: BF8903F7
	s_clause 0x1                                               // 000000026588: BF850001
	scratch_store_b128 off, v[16:19], off offset:128           // 00000002658C: DC750080 007C1000
	scratch_store_b128 off, v[20:23], off offset:144           // 000000026594: DC750090 007C1400
	s_clause 0x1                                               // 00000002659C: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:176          // 0000000265A0: DC5E00B0 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:160          // 0000000265A8: DC5E00A0 107C0001
	s_waitcnt vmcnt(0)                                         // 0000000265B0: BF8903F7
	s_clause 0x1                                               // 0000000265B4: BF850001
	scratch_store_b128 off, v[16:19], off offset:160           // 0000000265B8: DC7500A0 007C1000
	scratch_store_b128 off, v[20:23], off offset:176           // 0000000265C0: DC7500B0 007C1400
	s_clause 0x1                                               // 0000000265C8: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:208          // 0000000265CC: DC5E00D0 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:192          // 0000000265D4: DC5E00C0 107C0001
	s_waitcnt vmcnt(0)                                         // 0000000265DC: BF8903F7
	s_clause 0x1                                               // 0000000265E0: BF850001
	scratch_store_b128 off, v[16:19], off offset:192           // 0000000265E4: DC7500C0 007C1000
	scratch_store_b128 off, v[20:23], off offset:208           // 0000000265EC: DC7500D0 007C1400
	s_clause 0x1                                               // 0000000265F4: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:240          // 0000000265F8: DC5E00F0 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:224          // 000000026600: DC5E00E0 107C0001
	s_waitcnt vmcnt(0)                                         // 000000026608: BF8903F7
	s_clause 0x1                                               // 00000002660C: BF850001
	scratch_store_b128 off, v[16:19], off offset:224           // 000000026610: DC7500E0 007C1000
	scratch_store_b128 off, v[20:23], off offset:240           // 000000026618: DC7500F0 007C1400
	s_clause 0x1                                               // 000000026620: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:272          // 000000026624: DC5E0110 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:256          // 00000002662C: DC5E0100 107C0001
	s_waitcnt vmcnt(0)                                         // 000000026634: BF8903F7
	s_clause 0x1                                               // 000000026638: BF850001
	scratch_store_b128 off, v[16:19], off offset:256           // 00000002663C: DC750100 007C1000
	scratch_store_b128 off, v[20:23], off offset:272           // 000000026644: DC750110 007C1400
	s_clause 0x1                                               // 00000002664C: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:304          // 000000026650: DC5E0130 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:288          // 000000026658: DC5E0120 107C0001
	s_waitcnt vmcnt(0)                                         // 000000026660: BF8903F7
	s_clause 0x1                                               // 000000026664: BF850001
	scratch_store_b128 off, v[16:19], off offset:288           // 000000026668: DC750120 007C1000
	scratch_store_b128 off, v[20:23], off offset:304           // 000000026670: DC750130 007C1400
	s_clause 0xb                                               // 000000026678: BF85000B
	global_load_b128 v[221:224], v[1:2], off offset:336        // 00000002667C: DC5E0150 DD7C0001
	global_load_b128 v[217:220], v[1:2], off offset:320        // 000000026684: DC5E0140 D97C0001
	global_load_b128 v[229:232], v[1:2], off offset:368        // 00000002668C: DC5E0170 E57C0001
	global_load_b128 v[225:228], v[1:2], off offset:352        // 000000026694: DC5E0160 E17C0001
	global_load_b128 v[237:240], v[1:2], off offset:400        // 00000002669C: DC5E0190 ED7C0001
	global_load_b128 v[233:236], v[1:2], off offset:384        // 0000000266A4: DC5E0180 E97C0001
	global_load_b128 v[245:248], v[1:2], off offset:432        // 0000000266AC: DC5E01B0 F57C0001
	global_load_b128 v[241:244], v[1:2], off offset:416        // 0000000266B4: DC5E01A0 F17C0001
	global_load_b128 v[141:144], v[1:2], off offset:464        // 0000000266BC: DC5E01D0 8D7C0001
	global_load_b128 v[137:140], v[1:2], off offset:448        // 0000000266C4: DC5E01C0 897C0001
	global_load_b128 v[149:152], v[1:2], off offset:496        // 0000000266CC: DC5E01F0 957C0001
	global_load_b128 v[145:148], v[1:2], off offset:480        // 0000000266D4: DC5E01E0 917C0001
	v_add3_u32 v1, s3, s14, v7                                 // 0000000266DC: D6550001 041C1C03
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v2, 9, v7      // 0000000266E4: CA220080 11020E89
	v_mov_b32_e32 v18, v129                                    // 0000000266EC: 7E240381
	v_mov_b32_e32 v19, v129                                    // 0000000266F0: 7E260381
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000266F4: BF870214
	v_lshl_add_u32 v1, v15, 2, v1                              // 0000000266F8: D6460001 0405050F
	v_or3_b32 v162, v2, v3, v4                                 // 000000026700: D65800A2 04120702
	v_lshl_or_b32 v0, v253, 5, v2                              // 000000026708: D6560000 04090BFD
	v_lshl_or_b32 v2, v253, 3, s4                              // 000000026710: D6560002 001107FD
	v_mov_b32_e32 v20, v129                                    // 000000026718: 7E280381
	v_sub_nc_u32_e32 v1, v1, v8                                // 00000002671C: 4C021101
	v_mov_b32_e32 v122, v129                                   // 000000026720: 7EF40381
	v_mov_b32_e32 v21, v129                                    // 000000026724: 7E2A0381
	.long 0xd7006aa3                                           // 000000026728: D7006AA3
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 00000002672C: 02020408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000026730: BF870244
	v_dual_mov_b32 v2, s5 :: v_dual_add_nc_u32 v165, 1, v1     // 000000026734: CA200005 02A40281
	v_mov_b32_e32 v22, v129                                    // 00000002673C: 7E2C0381
	v_mov_b32_e32 v23, v129                                    // 000000026740: 7E2E0381
	v_mov_b32_e32 v15, v129                                    // 000000026744: 7E1E0381
	v_add_co_ci_u32_e64 v164, null, s9, v2, vcc_lo             // 000000026748: D5207CA4 01AA0409
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v1, 0           // 000000026750: CA100181 10000080
	v_mov_b32_e32 v2, v129                                     // 000000026758: 7E040381
	v_mov_b32_e32 v3, v129                                     // 00000002675C: 7E060381
	v_mov_b32_e32 v4, v129                                     // 000000026760: 7E080381
	v_mov_b32_e32 v7, v129                                     // 000000026764: 7E0E0381
	v_mov_b32_e32 v8, v129                                     // 000000026768: 7E100381
	s_mov_b32 s3, 0                                            // 00000002676C: BE830080
	s_branch 401                                               // 000000026770: BFA00191 <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0xfb8>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000026774: 8C7E007E
	v_bfe_u32 v130, v192, 16, 1                                // 000000026778: D6100082 020521C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000026780: BF8701A2
	v_dual_mul_f32 v121, v180, v121 :: v_dual_mul_f32 v128, v195, v128// 000000026784: C8C6F3B4 798101C3
	v_dual_mul_f32 v123, v184, v123 :: v_dual_mul_f32 v114, v182, v114// 00000002678C: C8C6F7B8 7B72E5B6
	v_add3_u32 v130, v192, v130, 0x7fff                        // 000000026794: D6550082 03FF05C0 00007FFF
	v_dual_mul_f32 v125, v188, v125 :: v_dual_mul_f32 v116, v186, v116// 0000000267A0: C8C6FBBC 7D74E9BA
	v_dual_mul_f32 v127, v193, v127 :: v_dual_mul_f32 v118, v191, v118// 0000000267A8: C8C6FFC1 7F76EDBF
	ds_store_b16_d16_hi v162, v130 offset:448                  // 0000000267B0: DA8401C0 000082A2
	ds_load_b128 v[130:133], v255 offset:2048                  // 0000000267B8: DBFC0800 820000FF
	v_dual_mul_f32 v113, v180, v113 :: v_dual_mul_f32 v120, v195, v120// 0000000267C0: C8C6E3B4 7178F1C3
	v_dual_mul_f32 v115, v184, v115 :: v_dual_mul_f32 v106, v182, v106// 0000000267C8: C8C6E7B8 736AD5B6
	v_dual_mul_f32 v117, v188, v117 :: v_dual_mul_f32 v108, v186, v108// 0000000267D0: C8C6EBBC 756CD9BA
	v_dual_mul_f32 v119, v193, v119 :: v_dual_mul_f32 v110, v191, v110// 0000000267D8: C8C6EFC1 776EDDBF
	v_dual_mul_f32 v105, v180, v105 :: v_dual_mul_f32 v112, v195, v112// 0000000267E0: C8C6D3B4 6970E1C3
	v_dual_mul_f32 v107, v184, v107 :: v_dual_mul_f32 v98, v182, v98// 0000000267E8: C8C6D7B8 6B62C5B6
	v_dual_mul_f32 v109, v188, v109 :: v_dual_mul_f32 v100, v186, v100// 0000000267F0: C8C6DBBC 6D64C9BA
	v_dual_mul_f32 v111, v193, v111 :: v_dual_mul_f32 v102, v191, v102// 0000000267F8: C8C6DFC1 6F66CDBF
	v_dual_mul_f32 v97, v180, v97 :: v_dual_mul_f32 v104, v195, v104// 000000026800: C8C6C3B4 6168D1C3
	s_waitcnt lgkmcnt(0)                                       // 000000026808: BF89FC07
	v_dual_mul_f32 v126, v191, v126 :: v_dual_mov_b32 v153, v130// 00000002680C: C8D0FDBF 7E980182
	v_ashrrev_i32_e32 v154, 31, v130                           // 000000026814: 3535049F
	v_ashrrev_i32_e32 v134, 31, v133                           // 000000026818: 350D0A9F
	v_ashrrev_i32_e32 v156, 31, v131                           // 00000002681C: 3539069F
	v_dual_mov_b32 v155, v131 :: v_dual_mul_f32 v122, v182, v122// 000000026820: CA060183 9B7AF5B6
	v_ashrrev_i32_e32 v158, 31, v132                           // 000000026828: 353D089F
	v_dual_mov_b32 v157, v132 :: v_dual_mul_f32 v124, v186, v124// 00000002682C: CA060184 9D7CF9BA
	.long 0xd73c0082                                           // 000000026834: D73C0082
	v_cndmask_b32_e32 v1, 12, v153, vcc_lo                     // 000000026838: 0203328C
	.long 0xd73c0084                                           // 00000002683C: D73C0084
	v_cndmask_b32_e32 v1, 12, v133, vcc_lo                     // 000000026840: 02030A8C
	.long 0xd73c0086                                           // 000000026844: D73C0086
	v_cndmask_b32_e32 v1, 12, v155, vcc_lo                     // 000000026848: 0203368C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000002684C: BF8700B4
	.long 0xd73c0099                                           // 000000026850: D73C0099
	v_cndmask_b32_e32 v1, 12, v157, vcc_lo                     // 000000026854: 02033A8C
	v_dual_mul_f32 v99, v184, v99 :: v_dual_mul_f32 v90, v182, v90// 000000026858: C8C6C7B8 635AB5B6
	.long 0xd7006a82                                           // 000000026860: D7006A82
	v_cndmask_b32_e32 v1, v163, v130, vcc_lo                   // 000000026864: 020305A3
	v_add_co_ci_u32_e64 v131, null, v164, v131, vcc_lo         // 000000026868: D5207C83 01AB07A4
	.long 0xd7006a86                                           // 000000026870: D7006A86
	v_cndmask_b32_e32 v1, v163, v134, vcc_lo                   // 000000026874: 02030DA3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000026878: BF8700A1
	v_add_co_ci_u32_e64 v135, null, v164, v135, vcc_lo         // 00000002687C: D5207C87 01AB0FA4
	.long 0xd7006afb                                           // 000000026884: D7006AFB
	v_cndmask_b32_e32 v1, v163, v153, vcc_lo                   // 000000026888: 020333A3
	v_add_co_ci_u32_e64 v252, null, v164, v154, vcc_lo         // 00000002688C: D5207CFC 01AB35A4
	.long 0xd7006a84                                           // 000000026894: D7006A84
	v_cndmask_b32_e32 v1, v163, v132, vcc_lo                   // 000000026898: 020309A3
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002689C: BF870001
	v_add_co_ci_u32_e64 v133, null, v164, v133, vcc_lo         // 0000000268A0: D5207C85 01AB0BA4
	s_clause 0x3                                               // 0000000268A8: BF850003
	global_load_b64 v[196:197], v[130:131], off                // 0000000268AC: DC560000 C47C0082
	global_load_b64 v[198:199], v[134:135], off                // 0000000268B4: DC560000 C67C0086
	global_load_b64 v[200:201], v[251:252], off                // 0000000268BC: DC560000 C87C00FB
	global_load_b64 v[202:203], v[132:133], off                // 0000000268C4: DC560000 CA7C0084
	ds_load_b128 v[153:156], v0                                // 0000000268CC: DBFC0000 99000000
	ds_load_b128 v[157:160], v0 offset:16                      // 0000000268D4: DBFC0010 9D000000
	v_dual_mul_f32 v101, v188, v101 :: v_dual_mul_f32 v92, v186, v92// 0000000268DC: C8C6CBBC 655CB9BA
	v_dual_mul_f32 v103, v193, v103 :: v_dual_mul_f32 v94, v191, v94// 0000000268E4: C8C6CFC1 675EBDBF
	v_dual_mul_f32 v89, v180, v89 :: v_dual_mul_f32 v96, v195, v96// 0000000268EC: C8C6B3B4 5960C1C3
	v_dual_mul_f32 v91, v184, v91 :: v_dual_mul_f32 v82, v182, v82// 0000000268F4: C8C6B7B8 5B52A5B6
	v_dual_mul_f32 v93, v188, v93 :: v_dual_mul_f32 v84, v186, v84// 0000000268FC: C8C6BBBC 5D54A9BA
	v_dual_mul_f32 v95, v193, v95 :: v_dual_mul_f32 v86, v191, v86// 000000026904: C8C6BFC1 5F56ADBF
	v_dual_mul_f32 v81, v180, v81 :: v_dual_mul_f32 v88, v195, v88// 00000002690C: C8C6A3B4 5158B1C3
	v_dual_mul_f32 v83, v184, v83 :: v_dual_mul_f32 v74, v182, v74// 000000026914: C8C6A7B8 534A95B6
	v_dual_mul_f32 v85, v188, v85 :: v_dual_mul_f32 v76, v186, v76// 00000002691C: C8C6ABBC 554C99BA
	v_dual_mul_f32 v87, v193, v87 :: v_dual_mul_f32 v78, v191, v78// 000000026924: C8C6AFC1 574E9DBF
	v_dual_mul_f32 v73, v180, v73 :: v_dual_mul_f32 v80, v195, v80// 00000002692C: C8C693B4 4950A1C3
	v_dual_mul_f32 v75, v184, v75 :: v_dual_mul_f32 v66, v182, v66// 000000026934: C8C697B8 4B4285B6
	v_dual_mul_f32 v77, v188, v77 :: v_dual_mul_f32 v68, v186, v68// 00000002693C: C8C69BBC 4D4489BA
	v_dual_mul_f32 v79, v193, v79 :: v_dual_mul_f32 v70, v191, v70// 000000026944: C8C69FC1 4F468DBF
	v_dual_mul_f32 v65, v180, v65 :: v_dual_mul_f32 v72, v195, v72// 00000002694C: C8C683B4 414891C3
	v_dual_mul_f32 v67, v184, v67 :: v_dual_mul_f32 v58, v182, v58// 000000026954: C8C687B8 433A75B6
	v_dual_mul_f32 v69, v188, v69 :: v_dual_mul_f32 v60, v186, v60// 00000002695C: C8C68BBC 453C79BA
	v_dual_mul_f32 v71, v193, v71 :: v_dual_mul_f32 v62, v191, v62// 000000026964: C8C68FC1 473E7DBF
	v_dual_mul_f32 v57, v180, v57 :: v_dual_mul_f32 v64, v195, v64// 00000002696C: C8C673B4 394081C3
	v_dual_mul_f32 v59, v184, v59 :: v_dual_mul_f32 v50, v182, v50// 000000026974: C8C677B8 3B3265B6
	v_dual_mul_f32 v61, v188, v61 :: v_dual_mul_f32 v52, v186, v52// 00000002697C: C8C67BBC 3D3469BA
	v_dual_mul_f32 v63, v193, v63 :: v_dual_mul_f32 v54, v191, v54// 000000026984: C8C67FC1 3F366DBF
	v_dual_mul_f32 v49, v180, v49 :: v_dual_mul_f32 v56, v195, v56// 00000002698C: C8C663B4 313871C3
	v_dual_mul_f32 v51, v184, v51 :: v_dual_mul_f32 v42, v182, v42// 000000026994: C8C667B8 332A55B6
	v_dual_mul_f32 v53, v188, v53 :: v_dual_mul_f32 v44, v186, v44// 00000002699C: C8C66BBC 352C59BA
	v_dual_mul_f32 v55, v193, v55 :: v_dual_mul_f32 v46, v191, v46// 0000000269A4: C8C66FC1 372E5DBF
	v_dual_mul_f32 v41, v180, v41 :: v_dual_mul_f32 v48, v195, v48// 0000000269AC: C8C653B4 293061C3
	v_dual_mul_f32 v43, v184, v43 :: v_dual_mul_f32 v34, v182, v34// 0000000269B4: C8C657B8 2B2245B6
	v_dual_mul_f32 v45, v188, v45 :: v_dual_mul_f32 v36, v186, v36// 0000000269BC: C8C65BBC 2D2449BA
	v_dual_mul_f32 v47, v193, v47 :: v_dual_mul_f32 v38, v191, v38// 0000000269C4: C8C65FC1 2F264DBF
	v_dual_mul_f32 v33, v180, v33 :: v_dual_mul_f32 v40, v195, v40// 0000000269CC: C8C643B4 212851C3
	v_dual_mul_f32 v35, v184, v35 :: v_dual_mul_f32 v26, v182, v26// 0000000269D4: C8C647B8 231A35B6
	v_dual_mul_f32 v37, v188, v37 :: v_dual_mul_f32 v28, v186, v28// 0000000269DC: C8C64BBC 251C39BA
	v_dual_mul_f32 v39, v193, v39 :: v_dual_mul_f32 v30, v191, v30// 0000000269E4: C8C64FC1 271E3DBF
	v_dual_mul_f32 v25, v180, v25 :: v_dual_mul_f32 v32, v195, v32// 0000000269EC: C8C633B4 192041C3
	v_dual_mul_f32 v27, v184, v27 :: v_dual_mul_f32 v18, v182, v18// 0000000269F4: C8C637B8 1B1225B6
	v_dual_mul_f32 v29, v188, v29 :: v_dual_mul_f32 v20, v186, v20// 0000000269FC: C8C63BBC 1D1429BA
	v_dual_mul_f32 v31, v193, v31 :: v_dual_mul_f32 v22, v191, v22// 000000026A04: C8C63FC1 1F162DBF
	v_dual_mul_f32 v17, v180, v17 :: v_dual_mul_f32 v24, v195, v24// 000000026A0C: C8C623B4 111831C3
	v_dual_mul_f32 v19, v184, v19 :: v_dual_mul_f32 v10, v182, v10// 000000026A14: C8C627B8 130A15B6
	v_dual_mul_f32 v21, v188, v21 :: v_dual_mul_f32 v12, v186, v12// 000000026A1C: C8C62BBC 150C19BA
	v_dual_mul_f32 v23, v193, v23 :: v_dual_mul_f32 v14, v191, v14// 000000026A24: C8C62FC1 170E1DBF
	v_dual_mul_f32 v9, v180, v9 :: v_dual_mul_f32 v16, v195, v16// 000000026A2C: C8C613B4 091021C3
	v_dual_mul_f32 v11, v184, v11 :: v_dual_mul_f32 v2, v182, v2// 000000026A34: C8C617B8 0B0205B6
	v_dual_mul_f32 v13, v188, v13 :: v_dual_mul_f32 v4, v186, v4// 000000026A3C: C8C61BBC 0D0409BA
	v_dual_mul_f32 v15, v193, v15 :: v_dual_mul_f32 v6, v191, v6// 000000026A44: C8C61FC1 0F060DBF
	v_dual_fmac_f32 v167, v173, v191 :: v_dual_add_nc_u32 v254, -1, v254// 000000026A4C: C8217FAD A7FFFCC1
	v_dual_mul_f32 v1, v180, v1 :: v_dual_mul_f32 v8, v195, v8 // 000000026A54: C8C603B4 010811C3
	v_dual_mul_f32 v3, v184, v3 :: v_dual_fmac_f32 v136, v177, v180// 000000026A5C: C8C007B8 038969B1
	v_dual_mul_f32 v5, v188, v5 :: v_dual_fmac_f32 v250, v175, v184// 000000026A64: C8C00BBC 05FB71AF
	v_dual_mul_f32 v7, v193, v7 :: v_dual_fmac_f32 v166, v172, v188// 000000026A6C: C8C00FC1 07A779AC
	v_dual_fmac_f32 v249, v176, v182 :: v_dual_mov_b32 v182, v178// 000000026A74: C8116DB0 F9B601B2
	v_dual_fmac_f32 v161, v174, v186 :: v_dual_mov_b32 v184, v179// 000000026A7C: C81175AE A1B801B3
	v_dual_fmac_f32 v189, v171, v193 :: v_dual_mov_b32 v186, v181// 000000026A84: C81183AB BDBA01B5
	v_cmp_eq_u32_e32 vcc_lo, 0, v254                           // 000000026A8C: 7C95FC80
	v_fma_f32 v170, v170, v195, v192                           // 000000026A90: D61300AA 070387AA
	v_dual_mov_b32 v188, v183 :: v_dual_add_nc_u32 v165, -16, v165// 000000026A98: CA2001B7 BCA54AD0
	v_dual_mov_b32 v191, v185 :: v_dual_mov_b32 v192, v187     // 000000026AA0: CA1001B9 BFC001BB
	v_dual_mov_b32 v195, v190 :: v_dual_mov_b32 v176, v249     // 000000026AA8: CA1001BE C3B001F9
	v_dual_mov_b32 v174, v161 :: v_dual_add_nc_u32 v255, 16, v255// 000000026AB0: CA2001A1 AEFFFE90
	v_dual_mov_b32 v177, v136 :: v_dual_mov_b32 v172, v166     // 000000026AB8: CA100188 B1AC01A6
	v_mov_b32_e32 v175, v250                                   // 000000026AC0: 7F5E03FA
	v_mov_b32_e32 v173, v167                                   // 000000026AC4: 7F5A03A7
	s_or_b32 s3, vcc_lo, s3                                    // 000000026AC8: 8C03036A
	v_mov_b32_e32 v171, v189                                   // 000000026ACC: 7F5603BD
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000026AD0: BF890007
	v_wmma_f32_16x16x16_bf16 v[121:128], v[153:160], v[196:203], v[121:128]// 000000026AD4: CC414079 1DE78999
	s_clause 0x3                                               // 000000026ADC: BF850003
	global_load_b64 v[196:197], v[130:131], off offset:128     // 000000026AE0: DC560080 C47C0082
	global_load_b64 v[198:199], v[134:135], off offset:128     // 000000026AE8: DC560080 C67C0086
	global_load_b64 v[200:201], v[251:252], off offset:128     // 000000026AF0: DC560080 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:128     // 000000026AF8: DC560080 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026B00: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[113:120], v[153:160], v[196:203], v[113:120]// 000000026B04: CC414071 1DC78999
	s_clause 0x3                                               // 000000026B0C: BF850003
	global_load_b64 v[196:197], v[130:131], off offset:256     // 000000026B10: DC560100 C47C0082
	global_load_b64 v[198:199], v[134:135], off offset:256     // 000000026B18: DC560100 C67C0086
	global_load_b64 v[200:201], v[251:252], off offset:256     // 000000026B20: DC560100 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:256     // 000000026B28: DC560100 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026B30: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[153:160], v[196:203], v[105:112]// 000000026B34: CC414069 1DA78999
	s_clause 0x3                                               // 000000026B3C: BF850003
	global_load_b64 v[196:197], v[130:131], off offset:384     // 000000026B40: DC560180 C47C0082
	global_load_b64 v[198:199], v[134:135], off offset:384     // 000000026B48: DC560180 C67C0086
	global_load_b64 v[200:201], v[251:252], off offset:384     // 000000026B50: DC560180 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:384     // 000000026B58: DC560180 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026B60: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[97:104], v[153:160], v[196:203], v[97:104]// 000000026B64: CC414061 1D878999
	s_clause 0x3                                               // 000000026B6C: BF850003
	global_load_b64 v[196:197], v[130:131], off offset:512     // 000000026B70: DC560200 C47C0082
	global_load_b64 v[198:199], v[134:135], off offset:512     // 000000026B78: DC560200 C67C0086
	global_load_b64 v[200:201], v[251:252], off offset:512     // 000000026B80: DC560200 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:512     // 000000026B88: DC560200 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026B90: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[89:96], v[153:160], v[196:203], v[89:96]// 000000026B94: CC414059 1D678999
	s_clause 0x3                                               // 000000026B9C: BF850003
	global_load_b64 v[196:197], v[130:131], off offset:640     // 000000026BA0: DC560280 C47C0082
	global_load_b64 v[198:199], v[134:135], off offset:640     // 000000026BA8: DC560280 C67C0086
	global_load_b64 v[200:201], v[251:252], off offset:640     // 000000026BB0: DC560280 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:640     // 000000026BB8: DC560280 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026BC0: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[81:88], v[153:160], v[196:203], v[81:88]// 000000026BC4: CC414051 1D478999
	s_clause 0x3                                               // 000000026BCC: BF850003
	global_load_b64 v[196:197], v[130:131], off offset:768     // 000000026BD0: DC560300 C47C0082
	global_load_b64 v[198:199], v[134:135], off offset:768     // 000000026BD8: DC560300 C67C0086
	global_load_b64 v[200:201], v[251:252], off offset:768     // 000000026BE0: DC560300 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:768     // 000000026BE8: DC560300 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026BF0: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[73:80], v[153:160], v[196:203], v[73:80]// 000000026BF4: CC414049 1D278999
	s_clause 0x3                                               // 000000026BFC: BF850003
	global_load_b64 v[196:197], v[130:131], off offset:896     // 000000026C00: DC560380 C47C0082
	global_load_b64 v[198:199], v[134:135], off offset:896     // 000000026C08: DC560380 C67C0086
	global_load_b64 v[200:201], v[251:252], off offset:896     // 000000026C10: DC560380 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:896     // 000000026C18: DC560380 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026C20: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[65:72], v[153:160], v[196:203], v[65:72]// 000000026C24: CC414041 1D078999
	s_clause 0x3                                               // 000000026C2C: BF850003
	global_load_b64 v[196:197], v[130:131], off offset:1024    // 000000026C30: DC560400 C47C0082
	global_load_b64 v[198:199], v[134:135], off offset:1024    // 000000026C38: DC560400 C67C0086
	global_load_b64 v[200:201], v[251:252], off offset:1024    // 000000026C40: DC560400 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:1024    // 000000026C48: DC560400 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026C50: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[57:64], v[153:160], v[196:203], v[57:64]// 000000026C54: CC414039 1CE78999
	s_clause 0x3                                               // 000000026C5C: BF850003
	global_load_b64 v[196:197], v[130:131], off offset:1152    // 000000026C60: DC560480 C47C0082
	global_load_b64 v[198:199], v[134:135], off offset:1152    // 000000026C68: DC560480 C67C0086
	global_load_b64 v[200:201], v[251:252], off offset:1152    // 000000026C70: DC560480 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:1152    // 000000026C78: DC560480 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026C80: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[49:56], v[153:160], v[196:203], v[49:56]// 000000026C84: CC414031 1CC78999
	s_clause 0x3                                               // 000000026C8C: BF850003
	global_load_b64 v[196:197], v[130:131], off offset:1280    // 000000026C90: DC560500 C47C0082
	global_load_b64 v[198:199], v[134:135], off offset:1280    // 000000026C98: DC560500 C67C0086
	global_load_b64 v[200:201], v[251:252], off offset:1280    // 000000026CA0: DC560500 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:1280    // 000000026CA8: DC560500 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026CB0: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[41:48], v[153:160], v[196:203], v[41:48]// 000000026CB4: CC414029 1CA78999
	s_clause 0x3                                               // 000000026CBC: BF850003
	global_load_b64 v[196:197], v[130:131], off offset:1408    // 000000026CC0: DC560580 C47C0082
	global_load_b64 v[198:199], v[134:135], off offset:1408    // 000000026CC8: DC560580 C67C0086
	global_load_b64 v[200:201], v[251:252], off offset:1408    // 000000026CD0: DC560580 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:1408    // 000000026CD8: DC560580 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026CE0: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[33:40], v[153:160], v[196:203], v[33:40]// 000000026CE4: CC414021 1C878999
	s_clause 0x3                                               // 000000026CEC: BF850003
	global_load_b64 v[198:199], v[134:135], off offset:1536    // 000000026CF0: DC560600 C67C0086
	global_load_b64 v[196:197], v[130:131], off offset:1536    // 000000026CF8: DC560600 C47C0082
	global_load_b64 v[200:201], v[251:252], off offset:1536    // 000000026D00: DC560600 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:1536    // 000000026D08: DC560600 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026D10: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[153:160], v[196:203], v[25:32]// 000000026D14: CC414019 1C678999
	s_clause 0x3                                               // 000000026D1C: BF850003
	global_load_b64 v[196:197], v[130:131], off offset:1664    // 000000026D20: DC560680 C47C0082
	global_load_b64 v[198:199], v[134:135], off offset:1664    // 000000026D28: DC560680 C67C0086
	global_load_b64 v[200:201], v[251:252], off offset:1664    // 000000026D30: DC560680 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:1664    // 000000026D38: DC560680 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026D40: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[17:24], v[153:160], v[196:203], v[17:24]// 000000026D44: CC414011 1C478999
	s_clause 0x3                                               // 000000026D4C: BF850003
	global_load_b64 v[198:199], v[134:135], off offset:1792    // 000000026D50: DC560700 C67C0086
	global_load_b64 v[196:197], v[130:131], off offset:1792    // 000000026D58: DC560700 C47C0082
	global_load_b64 v[200:201], v[251:252], off offset:1792    // 000000026D60: DC560700 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:1792    // 000000026D68: DC560700 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026D70: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[9:16], v[153:160], v[196:203], v[9:16]// 000000026D74: CC414009 1C278999
	s_clause 0x3                                               // 000000026D7C: BF850003
	global_load_b64 v[196:197], v[130:131], off offset:1920    // 000000026D80: DC560780 C47C0082
	global_load_b64 v[198:199], v[134:135], off offset:1920    // 000000026D88: DC560780 C67C0086
	global_load_b64 v[200:201], v[251:252], off offset:1920    // 000000026D90: DC560780 C87C00FB
	global_load_b64 v[202:203], v[132:133], off offset:1920    // 000000026D98: DC560780 CA7C0084
	s_waitcnt vmcnt(0)                                         // 000000026DA0: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[1:8], v[153:160], v[196:203], v[1:8]// 000000026DA4: CC414001 1C078999
	v_mov_b32_e32 v196, v194                                   // 000000026DAC: 7F8803C2
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000026DB0: 917E037E
	s_cbranch_execz 1029                                       // 000000026DB4: BFA50405 <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1fcc>
	v_and_b32_e32 v130, 12, v253                               // 000000026DB8: 3705FA8C
	s_clause 0x1                                               // 000000026DBC: BF850001
	scratch_load_b128 v[205:208], off, off                     // 000000026DC0: DC5D0000 CD7C0000
	scratch_load_b128 v[209:212], off, off offset:16           // 000000026DC8: DC5D0010 D17C0000
	v_mov_b32_e32 v136, v129                                   // 000000026DD0: 7F100381
	v_mov_b32_e32 v134, v129                                   // 000000026DD4: 7F0C0381
	v_dual_mov_b32 v135, v129 :: v_dual_add_nc_u32 v130, v255, v130// 000000026DD8: CA200181 878305FF
	v_mov_b32_e32 v133, v129                                   // 000000026DE0: 7F0A0381
	ds_load_b32 v130, v130 offset:2048                         // 000000026DE4: D8D80800 82000082
	s_waitcnt lgkmcnt(0)                                       // 000000026DEC: BF89FC07
	v_ashrrev_i32_e32 v131, 31, v130                           // 000000026DF0: 3507049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000026DF4: BF870091
	.long 0xd73c0082                                           // 000000026DF8: D73C0082
	v_cndmask_b32_e32 v1, 12, v130, vcc_lo                     // 000000026DFC: 0203048C
	.long 0xd7006aa6                                           // 000000026E00: D7006AA6
	v_cndmask_b32_e32 v1, v168, v130, vcc_lo                   // 000000026E04: 020305A8
	s_delay_alu instid0(VALU_DEP_1)                            // 000000026E08: BF870001
	v_add_co_ci_u32_e64 v167, null, v169, v131, vcc_lo         // 000000026E0C: D5207CA7 01AB07A9
	v_mov_b32_e32 v130, v129                                   // 000000026E14: 7F040381
	v_mov_b32_e32 v131, v129                                   // 000000026E18: 7F060381
	v_cmp_gt_i32_e32 vcc_lo, v165, v253                        // 000000026E1C: 7C89FBA5
	s_clause 0x1                                               // 000000026E20: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:16     // 000000026E24: DC5E0010 C97C00A6
	global_load_b128 v[197:200], v[166:167], off               // 000000026E2C: DC5E0000 C57C00A6
	v_mov_b32_e32 v132, v129                                   // 000000026E34: 7F080381
	v_dual_mov_b32 v160, v136 :: v_dual_mov_b32 v159, v135     // 000000026E38: CA100188 A09E0187
	v_dual_mov_b32 v158, v134 :: v_dual_mov_b32 v157, v133     // 000000026E40: CA100186 9E9C0185
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000026E48: BF870143
	v_dual_mov_b32 v156, v132 :: v_dual_mov_b32 v155, v131     // 000000026E4C: CA100184 9C9A0183
	v_dual_mov_b32 v154, v130 :: v_dual_mov_b32 v153, v129     // 000000026E54: CA100182 9A980181
	v_mov_b32_e32 v136, 0                                      // 000000026E5C: 7F100280
	s_waitcnt vmcnt(0)                                         // 000000026E60: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[205:212], v[197:204], v[153:160]// 000000026E64: CC414099 1E678BCD
	s_clause 0x1                                               // 000000026E6C: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:144    // 000000026E70: DC5E0090 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:128    // 000000026E78: DC5E0080 C57C00A6
	s_clause 0x1                                               // 000000026E80: BF850001
	scratch_load_b128 v[205:208], off, off offset:32           // 000000026E84: DC5D0020 CD7C0000
	scratch_load_b128 v[209:212], off, off offset:48           // 000000026E8C: DC5D0030 D17C0000
	s_waitcnt vmcnt(0)                                         // 000000026E94: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[205:212], v[197:204], v[153:160]// 000000026E98: CC414099 1E678BCD
	s_clause 0x1                                               // 000000026EA0: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:272    // 000000026EA4: DC5E0110 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:256    // 000000026EAC: DC5E0100 C57C00A6
	s_clause 0x1                                               // 000000026EB4: BF850001
	scratch_load_b128 v[205:208], off, off offset:64           // 000000026EB8: DC5D0040 CD7C0000
	scratch_load_b128 v[209:212], off, off offset:80           // 000000026EC0: DC5D0050 D17C0000
	s_waitcnt vmcnt(0)                                         // 000000026EC8: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[205:212], v[197:204], v[153:160]// 000000026ECC: CC414099 1E678BCD
	s_clause 0x1                                               // 000000026ED4: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:400    // 000000026ED8: DC5E0190 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:384    // 000000026EE0: DC5E0180 C57C00A6
	s_clause 0x1                                               // 000000026EE8: BF850001
	scratch_load_b128 v[205:208], off, off offset:96           // 000000026EEC: DC5D0060 CD7C0000
	scratch_load_b128 v[209:212], off, off offset:112          // 000000026EF4: DC5D0070 D17C0000
	s_waitcnt vmcnt(0)                                         // 000000026EFC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[205:212], v[197:204], v[153:160]// 000000026F00: CC414099 1E678BCD
	s_clause 0x1                                               // 000000026F08: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:528    // 000000026F0C: DC5E0210 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:512    // 000000026F14: DC5E0200 C57C00A6
	s_clause 0x1                                               // 000000026F1C: BF850001
	scratch_load_b128 v[205:208], off, off offset:128          // 000000026F20: DC5D0080 CD7C0000
	scratch_load_b128 v[209:212], off, off offset:144          // 000000026F28: DC5D0090 D17C0000
	s_waitcnt vmcnt(0)                                         // 000000026F30: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[205:212], v[197:204], v[153:160]// 000000026F34: CC414099 1E678BCD
	s_clause 0x1                                               // 000000026F3C: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:656    // 000000026F40: DC5E0290 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:640    // 000000026F48: DC5E0280 C57C00A6
	s_clause 0x1                                               // 000000026F50: BF850001
	scratch_load_b128 v[205:208], off, off offset:160          // 000000026F54: DC5D00A0 CD7C0000
	scratch_load_b128 v[209:212], off, off offset:176          // 000000026F5C: DC5D00B0 D17C0000
	s_waitcnt vmcnt(0)                                         // 000000026F64: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[205:212], v[197:204], v[153:160]// 000000026F68: CC414099 1E678BCD
	s_clause 0x1                                               // 000000026F70: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:784    // 000000026F74: DC5E0310 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:768    // 000000026F7C: DC5E0300 C57C00A6
	s_clause 0x1                                               // 000000026F84: BF850001
	scratch_load_b128 v[205:208], off, off offset:192          // 000000026F88: DC5D00C0 CD7C0000
	scratch_load_b128 v[209:212], off, off offset:208          // 000000026F90: DC5D00D0 D17C0000
	s_waitcnt vmcnt(0)                                         // 000000026F98: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[205:212], v[197:204], v[153:160]// 000000026F9C: CC414099 1E678BCD
	s_clause 0x1                                               // 000000026FA4: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:912    // 000000026FA8: DC5E0390 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:896    // 000000026FB0: DC5E0380 C57C00A6
	s_clause 0x1                                               // 000000026FB8: BF850001
	scratch_load_b128 v[205:208], off, off offset:224          // 000000026FBC: DC5D00E0 CD7C0000
	scratch_load_b128 v[209:212], off, off offset:240          // 000000026FC4: DC5D00F0 D17C0000
	s_waitcnt vmcnt(0)                                         // 000000026FCC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[205:212], v[197:204], v[153:160]// 000000026FD0: CC414099 1E678BCD
	s_clause 0x1                                               // 000000026FD8: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:1040   // 000000026FDC: DC5E0410 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:1024   // 000000026FE4: DC5E0400 C57C00A6
	s_clause 0x1                                               // 000000026FEC: BF850001
	scratch_load_b128 v[205:208], off, off offset:256          // 000000026FF0: DC5D0100 CD7C0000
	scratch_load_b128 v[209:212], off, off offset:272          // 000000026FF8: DC5D0110 D17C0000
	s_waitcnt vmcnt(0)                                         // 000000027000: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[205:212], v[197:204], v[153:160]// 000000027004: CC414099 1E678BCD
	s_clause 0x1                                               // 00000002700C: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:1168   // 000000027010: DC5E0490 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:1152   // 000000027018: DC5E0480 C57C00A6
	s_clause 0x1                                               // 000000027020: BF850001
	scratch_load_b128 v[205:208], off, off offset:288          // 000000027024: DC5D0120 CD7C0000
	scratch_load_b128 v[209:212], off, off offset:304          // 00000002702C: DC5D0130 D17C0000
	s_waitcnt vmcnt(0)                                         // 000000027034: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[205:212], v[197:204], v[153:160]// 000000027038: CC414099 1E678BCD
	s_clause 0x1                                               // 000000027040: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:1296   // 000000027044: DC5E0510 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:1280   // 00000002704C: DC5E0500 C57C00A6
	s_waitcnt vmcnt(0)                                         // 000000027054: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[217:224], v[197:204], v[153:160]// 000000027058: CC414099 1E678BD9
	s_clause 0x1                                               // 000000027060: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:1424   // 000000027064: DC5E0590 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:1408   // 00000002706C: DC5E0580 C57C00A6
	s_waitcnt vmcnt(0)                                         // 000000027074: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[225:232], v[197:204], v[153:160]// 000000027078: CC414099 1E678BE1
	s_clause 0x1                                               // 000000027080: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:1552   // 000000027084: DC5E0610 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:1536   // 00000002708C: DC5E0600 C57C00A6
	s_waitcnt vmcnt(0)                                         // 000000027094: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[233:240], v[197:204], v[153:160]// 000000027098: CC414099 1E678BE9
	s_clause 0x1                                               // 0000000270A0: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:1680   // 0000000270A4: DC5E0690 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:1664   // 0000000270AC: DC5E0680 C57C00A6
	s_waitcnt vmcnt(0)                                         // 0000000270B4: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[241:248], v[197:204], v[153:160]// 0000000270B8: CC414099 1E678BF1
	s_clause 0x1                                               // 0000000270C0: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:1808   // 0000000270C4: DC5E0710 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:1792   // 0000000270CC: DC5E0700 C57C00A6
	s_waitcnt vmcnt(0)                                         // 0000000270D4: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[137:144], v[197:204], v[153:160]// 0000000270D8: CC414099 1E678B89
	s_clause 0x1                                               // 0000000270E0: BF850001
	global_load_b128 v[201:204], v[166:167], off offset:1936   // 0000000270E4: DC5E0790 C97C00A6
	global_load_b128 v[197:200], v[166:167], off offset:1920   // 0000000270EC: DC5E0780 C57C00A6
	s_waitcnt vmcnt(0)                                         // 0000000270F4: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[153:160], v[145:152], v[197:204], v[153:160]// 0000000270F8: CC414099 1E678B91
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027100: BF870091
	v_mul_f32_e32 v130, 0x3d800000, v153                       // 000000027104: 110532FF 3D800000
	v_cndmask_b32_e32 v131, 0xf149f2ca, v130, vcc_lo           // 00000002710C: 030704FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027114: BF870091
	v_mov_b32_dpp v132, v131 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027118: 7F0802FA FF096183
	v_max_f32_e32 v132, v132, v132                             // 000000027120: 21090984
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027124: BF870091
	v_max_f32_e32 v131, v131, v132                             // 000000027128: 21070983
	v_mov_b32_dpp v132, v131 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000002712C: 7F0802FA FF096283
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027134: BF870091
	v_max_f32_e32 v132, v132, v132                             // 000000027138: 21090984
	v_max_f32_e32 v131, v131, v132                             // 00000002713C: 21070983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027140: BF870091
	v_mov_b32_dpp v132, v131 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027144: 7F0802FA FF096483
	v_max_f32_e32 v132, v132, v132                             // 00000002714C: 21090984
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027150: BF870091
	v_max_f32_e32 v131, v131, v132                             // 000000027154: 21070983
	v_mov_b32_dpp v132, v131 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027158: 7F0802FA FF096883
	s_delay_alu instid0(VALU_DEP_1)                            // 000000027160: BF870001
	v_max3_f32 v178, v182, v131, v132                          // 000000027164: D61C00B2 061307B6
	s_and_saveexec_b32 s4, vcc_lo                              // 00000002716C: BE84206A
	s_cbranch_execz 31                                         // 000000027170: BFA5001F <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x13f0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027174: BF870091
	v_sub_f32_e32 v130, v130, v178                             // 000000027178: 09056582
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 00000002717C: 110704FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000027184: BF8700A1
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 000000027188: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 000000027194: 7F0A4783
	v_dual_sub_f32 v131, v131, v133 :: v_dual_fmac_f32 v132, 0x32a5705f, v130// 000000027198: C9410B83 838504FF 32A5705F
	.long 0xd41b0000                                           // 0000000271A4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 0000000271A8: 020304FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000271B0: BF870122
	v_add_f32_e32 v131, v131, v132                             // 0000000271B4: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 0000000271B8: 7F081185
	v_exp_f32_e32 v131, v131                                   // 0000000271BC: 7F064B83
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000271C0: BF870095
	.long 0xd71c0083                                           // 0000000271C4: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 0000000271C8: 02030983
	v_cndmask_b32_e64 v131, 0, v131, s0                        // 0000000271CC: D5010083 00030680
	.long 0xd41e0000                                           // 0000000271D4: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 0000000271D8: 020304FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000271E0: BF870001
	v_cndmask_b32_e64 v136, 0x7f800000, v131, s0               // 0000000271E4: D5010088 000306FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000271F0: 8C7E047E
	v_dual_mov_b32 v249, 0 :: v_dual_mov_b32 v180, 0           // 0000000271F4: CA100080 F9B40080
	s_mov_b32 s4, exec_lo                                      // 0000000271FC: BE84007E
	v_cmpx_lt_f32_e32 0xefa18f08, v182                         // 000000027200: 7D236CFF EFA18F08
	s_cbranch_execz 30                                         // 000000027208: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1484>
	v_sub_f32_e32 v130, v182, v178                             // 00000002720C: 090565B6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027210: BF870091
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 000000027214: 110704FF 3FB8AA3B
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 00000002721C: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 000000027228: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002722C: BF870121
	v_dual_sub_f32 v131, v131, v133 :: v_dual_fmac_f32 v132, 0x32a5705f, v130// 000000027230: C9410B83 838504FF 32A5705F
	.long 0xd41b0000                                           // 00000002723C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 000000027240: 020304FF C2CE8ED0
	v_add_f32_e32 v131, v131, v132                             // 000000027248: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 00000002724C: 7F081185
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000027250: BF870292
	v_exp_f32_e32 v131, v131                                   // 000000027254: 7F064B83
	.long 0xd71c0083                                           // 000000027258: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 00000002725C: 02030983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000027260: BF8700A1
	v_cndmask_b32_e64 v131, 0, v131, s0                        // 000000027264: D5010083 00030680
	.long 0xd41e0000                                           // 00000002726C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 000000027270: 020304FF 42B17218
	v_cndmask_b32_e64 v180, 0x7f800000, v131, s0               // 000000027278: D50100B4 000306FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 000000027284: 8C7E047E
	v_mul_f32_e32 v130, 0x3d800000, v154                       // 000000027288: 110534FF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027290: BF870091
	v_cndmask_b32_e32 v131, 0xf149f2ca, v130, vcc_lo           // 000000027294: 030704FF F149F2CA
	v_mov_b32_dpp v132, v131 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000002729C: 7F0802FA FF096183
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000272A4: BF870091
	v_max_f32_e32 v132, v132, v132                             // 0000000272A8: 21090984
	v_max_f32_e32 v131, v131, v132                             // 0000000272AC: 21070983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000272B0: BF870091
	v_mov_b32_dpp v132, v131 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000272B4: 7F0802FA FF096283
	v_max_f32_e32 v132, v132, v132                             // 0000000272BC: 21090984
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000272C0: BF870091
	v_max_f32_e32 v131, v131, v132                             // 0000000272C4: 21070983
	v_mov_b32_dpp v132, v131 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000272C8: 7F0802FA FF096483
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000272D0: BF870091
	v_max_f32_e32 v132, v132, v132                             // 0000000272D4: 21090984
	v_max_f32_e32 v131, v131, v132                             // 0000000272D8: 21070983
	v_bfe_u32 v132, v136, 16, 1                                // 0000000272DC: D6100084 02052188
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000272E4: BF870112
	v_mov_b32_dpp v133, v131 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000272E8: 7F0A02FA FF096883
	v_add3_u32 v132, v136, v132, 0x7fff                        // 0000000272F0: D6550084 03FF0988 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000272FC: BF870002
	v_max3_f32 v179, v184, v131, v133                          // 000000027300: D61C00B3 061707B8
	ds_store_b16_d16_hi v162, v132                             // 000000027308: DA840000 000084A2
	s_and_saveexec_b32 s4, vcc_lo                              // 000000027310: BE84206A
	s_cbranch_execz 30                                         // 000000027314: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1590>
	v_sub_f32_e32 v130, v130, v179                             // 000000027318: 09056782
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002731C: BF870091
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 000000027320: 110704FF 3FB8AA3B
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 000000027328: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 000000027334: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000027338: BF870121
	v_dual_sub_f32 v131, v131, v133 :: v_dual_fmac_f32 v132, 0x32a5705f, v130// 00000002733C: C9410B83 838504FF 32A5705F
	.long 0xd41b0000                                           // 000000027348: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 00000002734C: 020304FF C2CE8ED0
	v_add_f32_e32 v131, v131, v132                             // 000000027354: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 000000027358: 7F081185
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002735C: BF870292
	v_exp_f32_e32 v131, v131                                   // 000000027360: 7F064B83
	.long 0xd71c0083                                           // 000000027364: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 000000027368: 02030983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002736C: BF8700A1
	v_cndmask_b32_e64 v131, 0, v131, s0                        // 000000027370: D5010083 00030680
	.long 0xd41e0000                                           // 000000027378: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 00000002737C: 020304FF 42B17218
	v_cndmask_b32_e64 v249, 0x7f800000, v131, s0               // 000000027384: D50100F9 000306FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 000000027390: 8C7E047E
	v_mov_b32_e32 v250, 0                                      // 000000027394: 7FF40280
	v_mov_b32_e32 v182, 0                                      // 000000027398: 7F6C0280
	s_mov_b32 s4, exec_lo                                      // 00000002739C: BE84007E
	v_cmpx_lt_f32_e32 0xefa18f08, v184                         // 0000000273A0: 7D2370FF EFA18F08
	s_cbranch_execz 30                                         // 0000000273A8: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1624>
	v_sub_f32_e32 v130, v184, v179                             // 0000000273AC: 090567B8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000273B0: BF870091
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 0000000273B4: 110704FF 3FB8AA3B
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 0000000273BC: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 0000000273C8: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000273CC: BF870121
	v_dual_sub_f32 v131, v131, v133 :: v_dual_fmac_f32 v132, 0x32a5705f, v130// 0000000273D0: C9410B83 838504FF 32A5705F
	.long 0xd41b0000                                           // 0000000273DC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 0000000273E0: 020304FF C2CE8ED0
	v_add_f32_e32 v131, v131, v132                             // 0000000273E8: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 0000000273EC: 7F081185
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000273F0: BF870292
	v_exp_f32_e32 v131, v131                                   // 0000000273F4: 7F064B83
	.long 0xd71c0083                                           // 0000000273F8: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 0000000273FC: 02030983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000027400: BF8700A1
	v_cndmask_b32_e64 v131, 0, v131, s0                        // 000000027404: D5010083 00030680
	.long 0xd41e0000                                           // 00000002740C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 000000027410: 020304FF 42B17218
	v_cndmask_b32_e64 v182, 0x7f800000, v131, s0               // 000000027418: D50100B6 000306FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 000000027424: 8C7E047E
	v_mul_f32_e32 v130, 0x3d800000, v155                       // 000000027428: 110536FF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027430: BF870091
	v_cndmask_b32_e32 v131, 0xf149f2ca, v130, vcc_lo           // 000000027434: 030704FF F149F2CA
	v_mov_b32_dpp v132, v131 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000002743C: 7F0802FA FF096183
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027444: BF870091
	v_max_f32_e32 v132, v132, v132                             // 000000027448: 21090984
	v_max_f32_e32 v131, v131, v132                             // 00000002744C: 21070983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027450: BF870091
	v_mov_b32_dpp v132, v131 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027454: 7F0802FA FF096283
	v_max_f32_e32 v132, v132, v132                             // 00000002745C: 21090984
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027460: BF870091
	v_max_f32_e32 v131, v131, v132                             // 000000027464: 21070983
	v_mov_b32_dpp v132, v131 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027468: 7F0802FA FF096483
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027470: BF870091
	v_max_f32_e32 v132, v132, v132                             // 000000027474: 21090984
	v_max_f32_e32 v131, v131, v132                             // 000000027478: 21070983
	v_bfe_u32 v132, v249, 16, 1                                // 00000002747C: D6100084 020521F9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000027484: BF870112
	v_mov_b32_dpp v133, v131 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027488: 7F0A02FA FF096883
	v_add3_u32 v132, v249, v132, 0x7fff                        // 000000027490: D6550084 03FF09F9 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002749C: BF870002
	v_max3_f32 v181, v186, v131, v133                          // 0000000274A0: D61C00B5 061707BA
	ds_store_b16_d16_hi v162, v132 offset:64                   // 0000000274A8: DA840040 000084A2
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000274B0: BE84206A
	s_cbranch_execz 30                                         // 0000000274B4: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1730>
	v_sub_f32_e32 v130, v130, v181                             // 0000000274B8: 09056B82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000274BC: BF870091
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 0000000274C0: 110704FF 3FB8AA3B
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 0000000274C8: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 0000000274D4: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000274D8: BF870091
	v_dual_fmac_f32 v132, 0x32a5705f, v130 :: v_dual_sub_f32 v131, v131, v133// 0000000274DC: C80B04FF 84830B83 32A5705F
	v_add_f32_e32 v131, v131, v132                             // 0000000274E8: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 0000000274EC: 7F081185
	.long 0xd41b0000                                           // 0000000274F0: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 0000000274F4: 020304FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000274FC: BF870293
	v_exp_f32_e32 v131, v131                                   // 000000027500: 7F064B83
	.long 0xd71c0083                                           // 000000027504: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 000000027508: 02030983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002750C: BF8700A1
	v_cndmask_b32_e64 v131, 0, v131, s0                        // 000000027510: D5010083 00030680
	.long 0xd41e0000                                           // 000000027518: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 00000002751C: 020304FF 42B17218
	v_cndmask_b32_e64 v250, 0x7f800000, v131, s0               // 000000027524: D50100FA 000306FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 000000027530: 8C7E047E
	v_dual_mov_b32 v161, 0 :: v_dual_mov_b32 v184, 0           // 000000027534: CA100080 A1B80080
	s_mov_b32 s4, exec_lo                                      // 00000002753C: BE84007E
	v_cmpx_lt_f32_e32 0xefa18f08, v186                         // 000000027540: 7D2374FF EFA18F08
	s_cbranch_execz 30                                         // 000000027548: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x17c4>
	v_sub_f32_e32 v130, v186, v181                             // 00000002754C: 09056BBA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027550: BF870091
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 000000027554: 110704FF 3FB8AA3B
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 00000002755C: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 000000027568: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002756C: BF870091
	v_dual_fmac_f32 v132, 0x32a5705f, v130 :: v_dual_sub_f32 v131, v131, v133// 000000027570: C80B04FF 84830B83 32A5705F
	v_add_f32_e32 v131, v131, v132                             // 00000002757C: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 000000027580: 7F081185
	.long 0xd41b0000                                           // 000000027584: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 000000027588: 020304FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000027590: BF870293
	v_exp_f32_e32 v131, v131                                   // 000000027594: 7F064B83
	.long 0xd71c0083                                           // 000000027598: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 00000002759C: 02030983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000275A0: BF8700A1
	v_cndmask_b32_e64 v131, 0, v131, s0                        // 0000000275A4: D5010083 00030680
	.long 0xd41e0000                                           // 0000000275AC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 0000000275B0: 020304FF 42B17218
	v_cndmask_b32_e64 v184, 0x7f800000, v131, s0               // 0000000275B8: D50100B8 000306FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000275C4: 8C7E047E
	v_mul_f32_e32 v130, 0x3d800000, v156                       // 0000000275C8: 110538FF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000275D0: BF870091
	v_cndmask_b32_e32 v131, 0xf149f2ca, v130, vcc_lo           // 0000000275D4: 030704FF F149F2CA
	v_mov_b32_dpp v132, v131 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000275DC: 7F0802FA FF096183
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000275E4: BF870091
	v_max_f32_e32 v132, v132, v132                             // 0000000275E8: 21090984
	v_max_f32_e32 v131, v131, v132                             // 0000000275EC: 21070983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000275F0: BF870091
	v_mov_b32_dpp v132, v131 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000275F4: 7F0802FA FF096283
	v_max_f32_e32 v132, v132, v132                             // 0000000275FC: 21090984
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027600: BF870091
	v_max_f32_e32 v131, v131, v132                             // 000000027604: 21070983
	v_mov_b32_dpp v132, v131 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027608: 7F0802FA FF096483
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027610: BF870091
	v_max_f32_e32 v132, v132, v132                             // 000000027614: 21090984
	v_max_f32_e32 v131, v131, v132                             // 000000027618: 21070983
	v_bfe_u32 v132, v250, 16, 1                                // 00000002761C: D6100084 020521FA
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000027624: BF870112
	v_mov_b32_dpp v133, v131 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027628: 7F0A02FA FF096883
	v_add3_u32 v132, v250, v132, 0x7fff                        // 000000027630: D6550084 03FF09FA 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002763C: BF870002
	v_max3_f32 v183, v188, v131, v133                          // 000000027640: D61C00B7 061707BC
	ds_store_b16_d16_hi v162, v132 offset:128                  // 000000027648: DA840080 000084A2
	s_and_saveexec_b32 s4, vcc_lo                              // 000000027650: BE84206A
	s_cbranch_execz 30                                         // 000000027654: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x18d0>
	v_sub_f32_e32 v130, v130, v183                             // 000000027658: 09056F82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002765C: BF870091
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 000000027660: 110704FF 3FB8AA3B
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 000000027668: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 000000027674: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000027678: BF870121
	v_dual_sub_f32 v131, v131, v133 :: v_dual_fmac_f32 v132, 0x32a5705f, v130// 00000002767C: C9410B83 838504FF 32A5705F
	.long 0xd41b0000                                           // 000000027688: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 00000002768C: 020304FF C2CE8ED0
	v_add_f32_e32 v131, v131, v132                             // 000000027694: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 000000027698: 7F081185
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002769C: BF870292
	v_exp_f32_e32 v131, v131                                   // 0000000276A0: 7F064B83
	.long 0xd71c0083                                           // 0000000276A4: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 0000000276A8: 02030983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000276AC: BF8700A1
	v_cndmask_b32_e64 v131, 0, v131, s0                        // 0000000276B0: D5010083 00030680
	.long 0xd41e0000                                           // 0000000276B8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 0000000276BC: 020304FF 42B17218
	v_cndmask_b32_e64 v161, 0x7f800000, v131, s0               // 0000000276C4: D50100A1 000306FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000276D0: 8C7E047E
	v_mov_b32_e32 v166, 0                                      // 0000000276D4: 7F4C0280
	v_mov_b32_e32 v186, 0                                      // 0000000276D8: 7F740280
	s_mov_b32 s4, exec_lo                                      // 0000000276DC: BE84007E
	v_cmpx_lt_f32_e32 0xefa18f08, v188                         // 0000000276E0: 7D2378FF EFA18F08
	s_cbranch_execz 30                                         // 0000000276E8: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1964>
	v_sub_f32_e32 v130, v188, v183                             // 0000000276EC: 09056FBC
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000276F0: BF870091
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 0000000276F4: 110704FF 3FB8AA3B
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 0000000276FC: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 000000027708: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002770C: BF870121
	v_dual_sub_f32 v131, v131, v133 :: v_dual_fmac_f32 v132, 0x32a5705f, v130// 000000027710: C9410B83 838504FF 32A5705F
	.long 0xd41b0000                                           // 00000002771C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 000000027720: 020304FF C2CE8ED0
	v_add_f32_e32 v131, v131, v132                             // 000000027728: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 00000002772C: 7F081185
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000027730: BF870292
	v_exp_f32_e32 v131, v131                                   // 000000027734: 7F064B83
	.long 0xd71c0083                                           // 000000027738: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 00000002773C: 02030983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000027740: BF8700A1
	v_cndmask_b32_e64 v131, 0, v131, s0                        // 000000027744: D5010083 00030680
	.long 0xd41e0000                                           // 00000002774C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 000000027750: 020304FF 42B17218
	v_cndmask_b32_e64 v186, 0x7f800000, v131, s0               // 000000027758: D50100BA 000306FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 000000027764: 8C7E047E
	v_mul_f32_e32 v130, 0x3d800000, v157                       // 000000027768: 11053AFF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027770: BF870091
	v_cndmask_b32_e32 v131, 0xf149f2ca, v130, vcc_lo           // 000000027774: 030704FF F149F2CA
	v_mov_b32_dpp v132, v131 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000002777C: 7F0802FA FF096183
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027784: BF870091
	v_max_f32_e32 v132, v132, v132                             // 000000027788: 21090984
	v_max_f32_e32 v131, v131, v132                             // 00000002778C: 21070983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027790: BF870091
	v_mov_b32_dpp v132, v131 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027794: 7F0802FA FF096283
	v_max_f32_e32 v132, v132, v132                             // 00000002779C: 21090984
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000277A0: BF870091
	v_max_f32_e32 v131, v131, v132                             // 0000000277A4: 21070983
	v_mov_b32_dpp v132, v131 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000277A8: 7F0802FA FF096483
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000277B0: BF870091
	v_max_f32_e32 v132, v132, v132                             // 0000000277B4: 21090984
	v_max_f32_e32 v131, v131, v132                             // 0000000277B8: 21070983
	v_bfe_u32 v132, v161, 16, 1                                // 0000000277BC: D6100084 020521A1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000277C4: BF870112
	v_mov_b32_dpp v133, v131 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000277C8: 7F0A02FA FF096883
	v_add3_u32 v132, v161, v132, 0x7fff                        // 0000000277D0: D6550084 03FF09A1 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000277DC: BF870002
	v_max3_f32 v185, v191, v131, v133                          // 0000000277E0: D61C00B9 061707BF
	ds_store_b16_d16_hi v162, v132 offset:192                  // 0000000277E8: DA8400C0 000084A2
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000277F0: BE84206A
	s_cbranch_execz 30                                         // 0000000277F4: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1a70>
	v_sub_f32_e32 v130, v130, v185                             // 0000000277F8: 09057382
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000277FC: BF870091
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 000000027800: 110704FF 3FB8AA3B
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 000000027808: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 000000027814: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027818: BF870091
	v_dual_fmac_f32 v132, 0x32a5705f, v130 :: v_dual_sub_f32 v131, v131, v133// 00000002781C: C80B04FF 84830B83 32A5705F
	v_add_f32_e32 v131, v131, v132                             // 000000027828: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 00000002782C: 7F081185
	.long 0xd41b0000                                           // 000000027830: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 000000027834: 020304FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002783C: BF870293
	v_exp_f32_e32 v131, v131                                   // 000000027840: 7F064B83
	.long 0xd71c0083                                           // 000000027844: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 000000027848: 02030983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002784C: BF8700A1
	v_cndmask_b32_e64 v131, 0, v131, s0                        // 000000027850: D5010083 00030680
	.long 0xd41e0000                                           // 000000027858: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 00000002785C: 020304FF 42B17218
	v_cndmask_b32_e64 v166, 0x7f800000, v131, s0               // 000000027864: D50100A6 000306FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 000000027870: 8C7E047E
	v_dual_mov_b32 v167, 0 :: v_dual_mov_b32 v188, 0           // 000000027874: CA100080 A7BC0080
	s_mov_b32 s4, exec_lo                                      // 00000002787C: BE84007E
	v_cmpx_lt_f32_e32 0xefa18f08, v191                         // 000000027880: 7D237EFF EFA18F08
	s_cbranch_execz 30                                         // 000000027888: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1b04>
	v_sub_f32_e32 v130, v191, v185                             // 00000002788C: 090573BF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000027890: BF870121
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 000000027894: 110704FF 3FB8AA3B
	.long 0xd41b0000                                           // 00000002789C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 0000000278A0: 020304FF C2CE8ED0
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 0000000278A8: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 0000000278B4: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000278B8: BF870091
	v_dual_fmac_f32 v132, 0x32a5705f, v130 :: v_dual_sub_f32 v131, v131, v133// 0000000278BC: C80B04FF 84830B83 32A5705F
	v_add_f32_e32 v131, v131, v132                             // 0000000278C8: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 0000000278CC: 7F081185
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000278D0: BF870292
	v_exp_f32_e32 v131, v131                                   // 0000000278D4: 7F064B83
	.long 0xd71c0083                                           // 0000000278D8: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 0000000278DC: 02030983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000278E0: BF8700A1
	v_cndmask_b32_e64 v131, 0, v131, s0                        // 0000000278E4: D5010083 00030680
	.long 0xd41e0000                                           // 0000000278EC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 0000000278F0: 020304FF 42B17218
	v_cndmask_b32_e64 v188, 0x7f800000, v131, s0               // 0000000278F8: D50100BC 000306FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 000000027904: 8C7E047E
	v_mul_f32_e32 v130, 0x3d800000, v158                       // 000000027908: 11053CFF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027910: BF870091
	v_cndmask_b32_e32 v131, 0xf149f2ca, v130, vcc_lo           // 000000027914: 030704FF F149F2CA
	v_mov_b32_dpp v132, v131 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000002791C: 7F0802FA FF096183
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027924: BF870091
	v_max_f32_e32 v132, v132, v132                             // 000000027928: 21090984
	v_max_f32_e32 v131, v131, v132                             // 00000002792C: 21070983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027930: BF870091
	v_mov_b32_dpp v132, v131 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027934: 7F0802FA FF096283
	v_max_f32_e32 v132, v132, v132                             // 00000002793C: 21090984
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027940: BF870091
	v_max_f32_e32 v131, v131, v132                             // 000000027944: 21070983
	v_mov_b32_dpp v132, v131 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027948: 7F0802FA FF096483
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027950: BF870091
	v_max_f32_e32 v132, v132, v132                             // 000000027954: 21090984
	v_max_f32_e32 v131, v131, v132                             // 000000027958: 21070983
	v_bfe_u32 v132, v166, 16, 1                                // 00000002795C: D6100084 020521A6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000027964: BF870112
	v_mov_b32_dpp v133, v131 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027968: 7F0A02FA FF096883
	v_add3_u32 v132, v166, v132, 0x7fff                        // 000000027970: D6550084 03FF09A6 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002797C: BF870002
	v_max3_f32 v187, v192, v131, v133                          // 000000027980: D61C00BB 061707C0
	ds_store_b16_d16_hi v162, v132 offset:256                  // 000000027988: DA840100 000084A2
	s_and_saveexec_b32 s4, vcc_lo                              // 000000027990: BE84206A
	s_cbranch_execz 30                                         // 000000027994: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1c10>
	v_sub_f32_e32 v130, v130, v187                             // 000000027998: 09057782
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002799C: BF870091
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 0000000279A0: 110704FF 3FB8AA3B
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 0000000279A8: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 0000000279B4: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000279B8: BF870121
	v_dual_sub_f32 v131, v131, v133 :: v_dual_fmac_f32 v132, 0x32a5705f, v130// 0000000279BC: C9410B83 838504FF 32A5705F
	.long 0xd41b0000                                           // 0000000279C8: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 0000000279CC: 020304FF C2CE8ED0
	v_add_f32_e32 v131, v131, v132                             // 0000000279D4: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 0000000279D8: 7F081185
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000279DC: BF870292
	v_exp_f32_e32 v131, v131                                   // 0000000279E0: 7F064B83
	.long 0xd71c0083                                           // 0000000279E4: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 0000000279E8: 02030983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000279EC: BF8700A1
	v_cndmask_b32_e64 v131, 0, v131, s0                        // 0000000279F0: D5010083 00030680
	.long 0xd41e0000                                           // 0000000279F8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 0000000279FC: 020304FF 42B17218
	v_cndmask_b32_e64 v167, 0x7f800000, v131, s0               // 000000027A04: D50100A7 000306FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 000000027A10: 8C7E047E
	v_mov_b32_e32 v189, 0                                      // 000000027A14: 7F7A0280
	v_mov_b32_e32 v191, 0                                      // 000000027A18: 7F7E0280
	s_mov_b32 s4, exec_lo                                      // 000000027A1C: BE84007E
	v_cmpx_lt_f32_e32 0xefa18f08, v192                         // 000000027A20: 7D2380FF EFA18F08
	s_cbranch_execz 30                                         // 000000027A28: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1ca4>
	v_sub_f32_e32 v130, v192, v187                             // 000000027A2C: 090577C0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027A30: BF870091
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 000000027A34: 110704FF 3FB8AA3B
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 000000027A3C: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 000000027A48: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000027A4C: BF870121
	v_dual_sub_f32 v131, v131, v133 :: v_dual_fmac_f32 v132, 0x32a5705f, v130// 000000027A50: C9410B83 838504FF 32A5705F
	.long 0xd41b0000                                           // 000000027A5C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 000000027A60: 020304FF C2CE8ED0
	v_add_f32_e32 v131, v131, v132                             // 000000027A68: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 000000027A6C: 7F081185
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000027A70: BF870292
	v_exp_f32_e32 v131, v131                                   // 000000027A74: 7F064B83
	.long 0xd71c0083                                           // 000000027A78: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 000000027A7C: 02030983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000027A80: BF8700A1
	v_cndmask_b32_e64 v131, 0, v131, s0                        // 000000027A84: D5010083 00030680
	.long 0xd41e0000                                           // 000000027A8C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 000000027A90: 020304FF 42B17218
	v_cndmask_b32_e64 v191, 0x7f800000, v131, s0               // 000000027A98: D50100BF 000306FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 000000027AA4: 8C7E047E
	v_mul_f32_e32 v130, 0x3d800000, v159                       // 000000027AA8: 11053EFF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027AB0: BF870091
	v_cndmask_b32_e32 v131, 0xf149f2ca, v130, vcc_lo           // 000000027AB4: 030704FF F149F2CA
	v_mov_b32_dpp v132, v131 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027ABC: 7F0802FA FF096183
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027AC4: BF870091
	v_max_f32_e32 v132, v132, v132                             // 000000027AC8: 21090984
	v_max_f32_e32 v131, v131, v132                             // 000000027ACC: 21070983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027AD0: BF870091
	v_mov_b32_dpp v132, v131 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027AD4: 7F0802FA FF096283
	v_max_f32_e32 v132, v132, v132                             // 000000027ADC: 21090984
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027AE0: BF870091
	v_max_f32_e32 v131, v131, v132                             // 000000027AE4: 21070983
	v_mov_b32_dpp v132, v131 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027AE8: 7F0802FA FF096483
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027AF0: BF870091
	v_max_f32_e32 v132, v132, v132                             // 000000027AF4: 21090984
	v_max_f32_e32 v131, v131, v132                             // 000000027AF8: 21070983
	v_bfe_u32 v132, v167, 16, 1                                // 000000027AFC: D6100084 020521A7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000027B04: BF870112
	v_mov_b32_dpp v133, v131 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027B08: 7F0A02FA FF096883
	v_add3_u32 v132, v167, v132, 0x7fff                        // 000000027B10: D6550084 03FF09A7 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000027B1C: BF870002
	v_max3_f32 v190, v195, v131, v133                          // 000000027B20: D61C00BE 061707C3
	ds_store_b16_d16_hi v162, v132 offset:320                  // 000000027B28: DA840140 000084A2
	s_and_saveexec_b32 s4, vcc_lo                              // 000000027B30: BE84206A
	s_cbranch_execz 30                                         // 000000027B34: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1db0>
	v_sub_f32_e32 v130, v130, v190                             // 000000027B38: 09057D82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027B3C: BF870091
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 000000027B40: 110704FF 3FB8AA3B
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 000000027B48: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 000000027B54: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000027B58: BF870121
	v_dual_sub_f32 v131, v131, v133 :: v_dual_fmac_f32 v132, 0x32a5705f, v130// 000000027B5C: C9410B83 838504FF 32A5705F
	.long 0xd41b0000                                           // 000000027B68: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 000000027B6C: 020304FF C2CE8ED0
	v_add_f32_e32 v131, v131, v132                             // 000000027B74: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 000000027B78: 7F081185
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000027B7C: BF870292
	v_exp_f32_e32 v131, v131                                   // 000000027B80: 7F064B83
	.long 0xd71c0083                                           // 000000027B84: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 000000027B88: 02030983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000027B8C: BF8700A1
	v_cndmask_b32_e64 v131, 0, v131, s0                        // 000000027B90: D5010083 00030680
	.long 0xd41e0000                                           // 000000027B98: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 000000027B9C: 020304FF 42B17218
	v_cndmask_b32_e64 v189, 0x7f800000, v131, s0               // 000000027BA4: D50100BD 000306FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 000000027BB0: 8C7E047E
	v_dual_mov_b32 v192, 0 :: v_dual_mov_b32 v193, 0           // 000000027BB4: CA100080 C0C00080
	s_mov_b32 s4, exec_lo                                      // 000000027BBC: BE84007E
	v_cmpx_lt_f32_e32 0xefa18f08, v195                         // 000000027BC0: 7D2386FF EFA18F08
	s_cbranch_execz 30                                         // 000000027BC8: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1e44>
	v_sub_f32_e32 v130, v195, v190                             // 000000027BCC: 09057DC3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000027BD0: BF870121
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 000000027BD4: 110704FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000027BDC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 000000027BE0: 020304FF C2CE8ED0
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 000000027BE8: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 000000027BF4: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027BF8: BF870091
	v_dual_fmac_f32 v132, 0x32a5705f, v130 :: v_dual_sub_f32 v131, v131, v133// 000000027BFC: C80B04FF 84830B83 32A5705F
	v_add_f32_e32 v131, v131, v132                             // 000000027C08: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 000000027C0C: 7F081185
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000027C10: BF870292
	v_exp_f32_e32 v131, v131                                   // 000000027C14: 7F064B83
	.long 0xd71c0083                                           // 000000027C18: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 000000027C1C: 02030983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000027C20: BF8700A1
	v_cndmask_b32_e64 v131, 0, v131, s0                        // 000000027C24: D5010083 00030680
	.long 0xd41e0000                                           // 000000027C2C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 000000027C30: 020304FF 42B17218
	v_cndmask_b32_e64 v193, 0x7f800000, v131, s0               // 000000027C38: D50100C1 000306FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 000000027C44: 8C7E047E
	v_mul_f32_e32 v130, 0x3d800000, v160                       // 000000027C48: 110540FF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027C50: BF870091
	v_cndmask_b32_e32 v131, 0xf149f2ca, v130, vcc_lo           // 000000027C54: 030704FF F149F2CA
	v_mov_b32_dpp v132, v131 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027C5C: 7F0802FA FF096183
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027C64: BF870091
	v_max_f32_e32 v132, v132, v132                             // 000000027C68: 21090984
	v_max_f32_e32 v131, v131, v132                             // 000000027C6C: 21070983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027C70: BF870091
	v_mov_b32_dpp v132, v131 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027C74: 7F0802FA FF096283
	v_max_f32_e32 v132, v132, v132                             // 000000027C7C: 21090984
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027C80: BF870091
	v_max_f32_e32 v131, v131, v132                             // 000000027C84: 21070983
	v_mov_b32_dpp v132, v131 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027C88: 7F0802FA FF096483
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027C90: BF870091
	v_max_f32_e32 v132, v132, v132                             // 000000027C94: 21090984
	v_max_f32_e32 v131, v131, v132                             // 000000027C98: 21070983
	v_bfe_u32 v132, v189, 16, 1                                // 000000027C9C: D6100084 020521BD
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000027CA4: BF870112
	v_mov_b32_dpp v133, v131 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027CA8: 7F0A02FA FF096883
	v_add3_u32 v132, v189, v132, 0x7fff                        // 000000027CB0: D6550084 03FF09BD 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000027CBC: BF870002
	v_max3_f32 v194, v196, v131, v133                          // 000000027CC0: D61C00C2 061707C4
	ds_store_b16_d16_hi v162, v132 offset:384                  // 000000027CC8: DA840180 000084A2
	s_and_saveexec_b32 s0, vcc_lo                              // 000000027CD0: BE80206A
	s_cbranch_execz 27                                         // 000000027CD4: BFA5001B <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x1f44>
	v_sub_f32_e32 v130, v130, v194                             // 000000027CD8: 09058582
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027CDC: BF870091
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 000000027CE0: 110704FF 3FB8AA3B
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 000000027CE8: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 000000027CF4: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000027CF8: BF870221
	v_sub_f32_e32 v131, v131, v133                             // 000000027CFC: 09070B83
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 000000027D00: 7C3704FF C2CE8ED0
	v_fmac_f32_e32 v132, 0x32a5705f, v130                      // 000000027D08: 570904FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000027D10: BF870121
	v_add_f32_e32 v131, v131, v132                             // 000000027D14: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 000000027D18: 7F081185
	v_exp_f32_e32 v131, v131                                   // 000000027D1C: 7F064B83
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027D20: BF870095
	.long 0xd71c0083                                           // 000000027D24: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 000000027D28: 02030983
	v_cndmask_b32_e32 v131, 0, v131, vcc_lo                    // 000000027D2C: 03070680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 000000027D30: 7C3D04FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000027D38: BF870002
	v_cndmask_b32_e32 v192, 0x7f800000, v131, vcc_lo           // 000000027D3C: 038106FF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 000000027D44: 8C7E007E
	v_mov_b32_e32 v195, 0                                      // 000000027D48: 7F860280
	s_mov_b32 s0, exec_lo                                      // 000000027D4C: BE80007E
	v_cmpx_lt_f32_e32 0xefa18f08, v196                         // 000000027D50: 7D2388FF EFA18F08
	s_cbranch_execz 64134                                      // 000000027D58: BFA5FA86 <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x974>
	v_sub_f32_e32 v130, v196, v194                             // 000000027D5C: 090585C4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027D60: BF870091
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 000000027D64: 110704FF 3FB8AA3B
	v_fma_f32 v132, 0x3fb8aa3b, v130, -v131                    // 000000027D6C: D6130084 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v133, v131                                 // 000000027D78: 7F0A4783
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000027D7C: BF870221
	v_sub_f32_e32 v131, v131, v133                             // 000000027D80: 09070B83
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 000000027D84: 7C3704FF C2CE8ED0
	v_fmac_f32_e32 v132, 0x32a5705f, v130                      // 000000027D8C: 570904FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000027D94: BF870121
	v_add_f32_e32 v131, v131, v132                             // 000000027D98: 07070983
	v_cvt_i32_f32_e32 v132, v133                               // 000000027D9C: 7F081185
	v_exp_f32_e32 v131, v131                                   // 000000027DA0: 7F064B83
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000027DA4: BF870095
	.long 0xd71c0083                                           // 000000027DA8: D71C0083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                   // 000000027DAC: 02030983
	v_cndmask_b32_e32 v131, 0, v131, vcc_lo                    // 000000027DB0: 03070680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 000000027DB4: 7C3D04FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000027DBC: BF870002
	v_cndmask_b32_e32 v195, 0x7f800000, v131, vcc_lo           // 000000027DC0: 038706FF 7F800000
	s_branch 64106                                             // 000000027DC8: BFA0FA6A <_ZN7halogen12_GLOBAL__N_112k_attn_qs_btEPKtS2_S2_S2_PtPKiiS5_S5_i+0x974>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000027DCC: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000027DD0: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000027DD4: 8C7E017E
	v_or_b32_e32 v0, s2, v215                                  // 000000027DD8: 3801AE02
	.long 0xd7006a2f                                           // 000000027DDC: D7006A2F
	v_cndmask_b32_e32 v1, v213, v253, vcc_lo                   // 000000027DE0: 0203FBD5
	v_add_co_ci_u32_e64 v48, null, v214, v129, vcc_lo          // 000000027DE4: D5207C30 01AB03D6
	v_mov_b32_dpp v111, v136 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027DEC: 7EDE02FA FF096188
	v_mov_b32_dpp v129, v167 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027DF4: 7F0202FA FF0961A7
	v_lshlrev_b32_e32 v0, 8, v0                                // 000000027DFC: 30000088
	v_mov_b32_dpp v119, v250 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027E00: 7EEE02FA FF0961FA
	v_mov_b32_dpp v112, v249 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027E08: 7EE002FA FF0961F9
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000027E10: BF870214
	v_dual_add_f32 v136, v136, v111 :: v_dual_add_f32 v129, v167, v129// 000000027E14: C908DF88 888103A7
	v_add_nc_u32_e32 v15, 0x400, v0                            // 000000027E1C: 4A1E00FF 00000400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000027E24: BF870194
	v_dual_add_f32 v138, v250, v119 :: v_dual_add_nc_u32 v23, 0x600, v0// 000000027E28: C920EFFA 8A1600FF 00000600
	v_add_f32_dpp v136, v136, v136 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027E34: 071110FA FF096288
	v_ashrrev_i32_e32 v8, 31, v0                               // 000000027E3C: 3410009F
	.long 0xd7006a07                                           // 000000027E40: D7006A07
	v_cndmask_b32_e32 v1, v47, v0, vcc_lo                      // 000000027E44: 0202012F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000027E48: BF870214
	v_add_f32_dpp v138, v138, v138 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027E4C: 071514FA FF09628A
	v_add_f32_dpp v136, v136, v136 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027E54: 071110FA FF096488
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000027E5C: BF870224
	v_add_co_ci_u32_e64 v8, null, v48, v8, vcc_lo              // 000000027E60: D5207C08 01AA1130
	v_ashrrev_i32_e32 v16, 31, v15                             // 000000027E68: 34201E9F
	v_add_f32_dpp v138, v138, v138 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027E6C: 071514FA FF09648A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000027E74: BF870214
	v_add_f32_dpp v156, v136, v136 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027E78: 073910FA FF096888
	.long 0xd73c0007                                           // 000000027E80: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 000000027E84: 02020E81
	.long 0xd7006a0f                                           // 000000027E88: D7006A0F
	v_cndmask_b32_e32 v1, v47, v15, vcc_lo                     // 000000027E8C: 02021F2F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000027E90: BF870214
	v_add_f32_dpp v142, v138, v138 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027E94: 071D14FA FF09688A
	v_div_scale_f32 v158, null, v156, v156, 1.0                // 000000027E9C: D6FC7C9E 03CB399C
	v_add_co_ci_u32_e64 v16, null, v48, v16, vcc_lo            // 000000027EA4: D5207C10 01AA2130
	v_ashrrev_i32_e32 v24, 31, v23                             // 000000027EAC: 34302E9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000027EB0: BF870214
	v_div_scale_f32 v167, null, v142, v142, 1.0                // 000000027EB4: D6FC7CA7 03CB1D8E
	v_rcp_f32_e32 v170, v158                                   // 000000027EBC: 7F54559E
	.long 0xd7006a37                                           // 000000027EC0: D7006A37
	v_cndmask_b32_e32 v1, s10, v7, vcc_lo                      // 000000027EC4: 02020E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000027EC8: BF870191
	v_add_co_ci_u32_e64 v56, null, s11, v8, vcc_lo             // 000000027ECC: D5207C38 01AA100B
	v_rcp_f32_e32 v146, v167                                   // 000000027ED4: 7F2455A7
	.long 0xd7006a17                                           // 000000027ED8: D7006A17
	v_cndmask_b32_e32 v1, v47, v23, vcc_lo                     // 000000027EDC: 02022F2F
	.long 0xd73c000f                                           // 000000027EE0: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 000000027EE4: 02021E81
	v_add_co_ci_u32_e64 v24, null, v48, v24, vcc_lo            // 000000027EE8: D5207C18 01AA3130
	s_delay_alu instid0(TRANS32_DEP_2)                         // 000000027EF0: BF870006
	v_fma_f32 v198, -v158, v170, 1.0                           // 000000027EF4: D61300C6 23CB559E
	v_add_nc_u32_e32 v31, 0x800, v0                            // 000000027EFC: 4A3E00FF 00000800
	s_clause 0x1                                               // 000000027F04: BF850001
	global_load_u16 v103, v[55:56], off                        // 000000027F08: DC4A0000 677C0037
	global_load_u16 v104, v[55:56], off offset:1024            // 000000027F10: DC4A0400 687C0037
	.long 0xd7006a47                                           // 000000027F18: D7006A47
	v_cndmask_b32_e32 v1, s10, v15, vcc_lo                     // 000000027F1C: 02021E0A
	v_fma_f32 v200, -v167, v146, 1.0                           // 000000027F20: D61300C8 23CB25A7
	v_dual_fmac_f32 v170, v198, v170 :: v_dual_add_nc_u32 v39, 0xa00, v0// 000000027F28: C82155C6 AA2600FF 00000A00
	v_ashrrev_i32_e32 v32, 31, v31                             // 000000027F34: 34403E9F
	.long 0xd73c0017                                           // 000000027F38: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 000000027F3C: 02022E81
	v_or_b32_e32 v0, 0x200, v0                                 // 000000027F40: 380000FF 00000200
	v_fmac_f32_e32 v146, v200, v146                            // 000000027F48: 572525C8
	v_ashrrev_i32_e32 v40, 31, v39                             // 000000027F4C: 34504E9F
	v_add_co_ci_u32_e64 v72, null, s11, v16, vcc_lo            // 000000027F50: D5207C48 01AA200B
	.long 0xd7006a1f                                           // 000000027F58: D7006A1F
	v_cndmask_b32_e32 v1, v47, v31, vcc_lo                     // 000000027F5C: 02023F2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000027F60: BF8700D1
	v_add_co_ci_u32_e64 v32, null, v48, v32, vcc_lo            // 000000027F64: D5207C20 01AA4130
	.long 0xd7006a27                                           // 000000027F6C: D7006A27
	v_cndmask_b32_e32 v1, v47, v39, vcc_lo                     // 000000027F70: 02024F2F
	v_ashrrev_i32_e32 v63, 31, v0                              // 000000027F74: 347E009F
	v_add_co_ci_u32_e64 v40, null, v48, v40, vcc_lo            // 000000027F78: D5207C28 01AA5130
	.long 0xd7006a5f                                           // 000000027F80: D7006A5F
	v_cndmask_b32_e32 v1, s10, v23, vcc_lo                     // 000000027F84: 02022E0A
	v_add_co_ci_u32_e64 v96, null, s11, v24, vcc_lo            // 000000027F88: D5207C60 01AA300B
	.long 0xd7006a2f                                           // 000000027F90: D7006A2F
	v_cndmask_b32_e32 v1, v47, v0, vcc_lo                      // 000000027F94: 0202012F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000027F98: BF870001
	v_add_co_ci_u32_e64 v48, null, v48, v63, vcc_lo            // 000000027F9C: D5207C30 01AA7F30
	.long 0xd73c001f                                           // 000000027FA4: D73C001F
	v_cndmask_b32_e32 v1, 1, v31, vcc_lo                       // 000000027FA8: 02023E81
	.long 0xd73c0027                                           // 000000027FAC: D73C0027
	v_cndmask_b32_e32 v1, 1, v39, vcc_lo                       // 000000027FB0: 02024E81
	global_load_u16 v173, v[55:56], off offset:32              // 000000027FB4: DC4A0020 AD7C0037
	.long 0xd73c002f                                           // 000000027FBC: D73C002F
	v_cndmask_b32_e32 v1, 1, v47, vcc_lo                       // 000000027FC0: 02025E81
	v_mov_b32_dpp v127, v166 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027FC4: 7EFE02FA FF0961A6
	v_mov_b32_dpp v120, v161 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000027FCC: 7EF002FA FF0961A1
	.long 0xd7006a57                                           // 000000027FD4: D7006A57
	v_cndmask_b32_e32 v1, s10, v31, vcc_lo                     // 000000027FD8: 02023E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000027FDC: BF8700A1
	v_add_co_ci_u32_e64 v88, null, s11, v32, vcc_lo            // 000000027FE0: D5207C58 01AA400B
	.long 0xd7006a4f                                           // 000000027FE8: D7006A4F
	v_cndmask_b32_e32 v1, s10, v39, vcc_lo                     // 000000027FEC: 02024E0A
	v_add_co_ci_u32_e64 v80, null, s11, v40, vcc_lo            // 000000027FF0: D5207C50 01AA500B
	.long 0xd7006a3f                                           // 000000027FF8: D7006A3F
	v_cndmask_b32_e32 v1, s10, v47, vcc_lo                     // 000000027FFC: 02025E0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000028000: BF870001
	v_add_co_ci_u32_e64 v64, null, s11, v48, vcc_lo            // 000000028004: D5207C40 01AA600B
	s_clause 0xa                                               // 00000002800C: BF85000A
	global_load_u16 v132, v[95:96], off                        // 000000028010: DC4A0000 847C005F
	global_load_u16 v131, v[71:72], off                        // 000000028018: DC4A0000 837C0047
	global_load_u16 v134, v[79:80], off                        // 000000028020: DC4A0000 867C004F
	global_load_u16 v133, v[87:88], off                        // 000000028028: DC4A0000 857C0057
	global_load_u16 v135, v[63:64], off offset:32              // 000000028030: DC4A0020 877C003F
	global_load_u16 v144, v[95:96], off offset:32              // 000000028038: DC4A0020 907C005F
	global_load_u16 v143, v[71:72], off offset:32              // 000000028040: DC4A0020 8F7C0047
	global_load_u16 v151, v[79:80], off offset:32              // 000000028048: DC4A0020 977C004F
	global_load_u16 v150, v[87:88], off offset:32              // 000000028050: DC4A0020 967C0057
	global_load_u16 v152, v[55:56], off offset:64              // 000000028058: DC4A0040 987C0037
	global_load_u16 v149, v[63:64], off offset:64              // 000000028060: DC4A0040 957C003F
	v_dual_add_f32 v130, v249, v112 :: v_dual_add_f32 v127, v166, v127// 000000028068: C908E1F9 827EFFA6
	v_div_scale_f32 v162, vcc_lo, 1.0, v156, 1.0               // 000000028070: D6FC6AA2 03CB38F2
	v_add_f32_e32 v137, v161, v120                             // 000000028078: 0712F1A1
	v_add_f32_dpp v129, v129, v129 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000002807C: 070302FA FF096281
	s_delay_alu instid0(VALU_DEP_4)                            // 000000028084: BF870004
	v_add_f32_dpp v130, v130, v130 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000028088: 070504FA FF096282
	v_add_f32_dpp v127, v127, v127 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000028090: 06FEFEFA FF09627F
	v_mul_f32_e32 v198, v162, v170                             // 000000028098: 118D55A2
	v_add_f32_dpp v137, v137, v137 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000002809C: 071312FA FF096289
	v_add_f32_dpp v129, v129, v129 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000280A4: 070302FA FF096481
	v_add_f32_dpp v130, v130, v130 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000280AC: 070504FA FF096482
	v_add_f32_dpp v127, v127, v127 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000280B4: 06FEFEFA FF09647F
	v_fma_f32 v204, -v158, v198, v162                          // 0000000280BC: D61300CC 268B8D9E
	v_add_f32_dpp v137, v137, v137 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000280C4: 071312FA FF096489
	v_add_f32_dpp v129, v129, v129 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000280CC: 070302FA FF096881
	v_add_f32_dpp v155, v130, v130 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000280D4: 073704FA FF096882
	v_add_f32_dpp v130, v127, v127 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000280DC: 0704FEFA FF09687F
	v_div_scale_f32 v168, s2, 1.0, v142, 1.0                   // 0000000280E4: D6FC02A8 03CB1CF2
	v_add_f32_dpp v141, v137, v137 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000000280EC: 071B12FA FF096889
	v_div_scale_f32 v161, null, v129, v129, 1.0                // 0000000280F4: D6FC7CA1 03CB0381
	v_div_scale_f32 v163, null, v155, v155, 1.0                // 0000000280FC: D6FC7CA3 03CB379B
	v_div_scale_f32 v160, null, v130, v130, 1.0                // 000000028104: D6FC7CA0 03CB0582
	v_div_scale_f32 v164, s0, 1.0, v130, 1.0                   // 00000002810C: D6FC00A4 03CB04F2
	v_div_scale_f32 v157, null, v141, v141, 1.0                // 000000028114: D6FC7C9D 03CB1B8D
	v_div_scale_f32 v166, s4, 1.0, v155, 1.0                   // 00000002811C: D6FC04A6 03CB36F2
	v_rcp_f32_e32 v169, v163                                   // 000000028124: 7F5255A3
	v_rcp_f32_e32 v139, v160                                   // 000000028128: 7F1655A0
	v_fmac_f32_e32 v198, v204, v170                            // 00000002812C: 578D55CC
	v_rcp_f32_e32 v145, v157                                   // 000000028130: 7F22559D
	v_rcp_f32_e32 v137, v161                                   // 000000028134: 7F1255A1
	v_mul_f32_e32 v200, v168, v146                             // 000000028138: 119125A8
	v_div_scale_f32 v159, s3, 1.0, v141, 1.0                   // 00000002813C: D6FC039F 03CB1AF2
	v_fma_f32 v158, -v158, v198, v162                          // 000000028144: D613009E 268B8D9E
	v_div_scale_f32 v165, s1, 1.0, v129, 1.0                   // 00000002814C: D6FC01A5 03CB02F2
	s_clause 0x1f                                              // 000000028154: BF85001F
	global_load_u16 v127, v[55:56], off offset:96              // 000000028158: DC4A0060 7F7C0037
	global_load_u16 v138, v[55:56], off offset:128             // 000000028160: DC4A0080 8A7C0037
	global_load_u16 v140, v[55:56], off offset:160             // 000000028168: DC4A00A0 8C7C0037
	global_load_u16 v147, v[55:56], off offset:192             // 000000028170: DC4A00C0 937C0037
	global_load_u16 v148, v[55:56], off offset:224             // 000000028178: DC4A00E0 947C0037
	global_load_u16 v182, v[71:72], off offset:64              // 000000028180: DC4A0040 B67C0047
	global_load_u16 v180, v[71:72], off offset:96              // 000000028188: DC4A0060 B47C0047
	global_load_u16 v178, v[71:72], off offset:128             // 000000028190: DC4A0080 B27C0047
	global_load_u16 v176, v[71:72], off offset:160             // 000000028198: DC4A00A0 B07C0047
	global_load_u16 v154, v[71:72], off offset:192             // 0000000281A0: DC4A00C0 9A7C0047
	global_load_u16 v181, v[95:96], off offset:64              // 0000000281A8: DC4A0040 B57C005F
	global_load_u16 v179, v[95:96], off offset:96              // 0000000281B0: DC4A0060 B37C005F
	global_load_u16 v177, v[95:96], off offset:128             // 0000000281B8: DC4A0080 B17C005F
	global_load_u16 v175, v[95:96], off offset:160             // 0000000281C0: DC4A00A0 AF7C005F
	global_load_u16 v153, v[95:96], off offset:192             // 0000000281C8: DC4A00C0 997C005F
	global_load_u16 v172, v[71:72], off offset:480             // 0000000281D0: DC4A01E0 AC7C0047
	global_load_u16 v196, v[87:88], off offset:64              // 0000000281D8: DC4A0040 C47C0057
	global_load_u16 v193, v[87:88], off offset:96              // 0000000281E0: DC4A0060 C17C0057
	global_load_u16 v190, v[87:88], off offset:128             // 0000000281E8: DC4A0080 BE7C0057
	global_load_u16 v187, v[87:88], off offset:160             // 0000000281F0: DC4A00A0 BB7C0057
	global_load_u16 v183, v[87:88], off offset:192             // 0000000281F8: DC4A00C0 B77C0057
	global_load_u16 v171, v[95:96], off offset:480             // 000000028200: DC4A01E0 AB7C005F
	global_load_u16 v195, v[79:80], off offset:64              // 000000028208: DC4A0040 C37C004F
	global_load_u16 v192, v[79:80], off offset:96              // 000000028210: DC4A0060 C07C004F
	global_load_u16 v189, v[79:80], off offset:128             // 000000028218: DC4A0080 BD7C004F
	global_load_u16 v186, v[79:80], off offset:160             // 000000028220: DC4A00A0 BA7C004F
	global_load_u16 v184, v[79:80], off offset:192             // 000000028228: DC4A00C0 B87C004F
	global_load_u16 v136, v[87:88], off offset:480             // 000000028230: DC4A01E0 887C0057
	global_load_u16 v197, v[63:64], off offset:96              // 000000028238: DC4A0060 C57C003F
	global_load_u16 v194, v[63:64], off offset:128             // 000000028240: DC4A0080 C27C003F
	global_load_u16 v191, v[63:64], off offset:160             // 000000028248: DC4A00A0 BF7C003F
	global_load_u16 v188, v[63:64], off offset:192             // 000000028250: DC4A00C0 BC7C003F
	s_clause 0x1                                               // 000000028258: BF850001
	global_load_u16 v185, v[63:64], off offset:224             // 00000002825C: DC4A00E0 B97C003F
	global_load_u16 v174, v[79:80], off offset:480             // 000000028264: DC4A01E0 AE7C004F
	v_fma_f32 v199, -v163, v169, 1.0                           // 00000002826C: D61300C7 23CB53A3
	v_fma_f32 v202, -v160, v139, 1.0                           // 000000028274: D61300CA 23CB17A0
	v_fma_f32 v206, -v167, v200, v168                          // 00000002827C: D61300CE 26A391A7
	v_fma_f32 v201, -v157, v145, 1.0                           // 000000028284: D61300C9 23CB239D
	v_fma_f32 v203, -v161, v137, 1.0                           // 00000002828C: D61300CB 23CB13A1
	v_fmac_f32_e32 v169, v199, v169                            // 000000028294: 575353C7
	v_fmac_f32_e32 v139, v202, v139                            // 000000028298: 571717CA
	v_div_fmas_f32 v158, v158, v170, v198                      // 00000002829C: D637009E 071B559E
	v_fmac_f32_e32 v145, v201, v145                            // 0000000282A4: 572323C9
	v_dual_fmac_f32 v137, v203, v137 :: v_dual_fmac_f32 v200, v206, v146// 0000000282A8: C80113CB 89C925CE
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000282B0: BF8701A4
	v_mul_f32_e32 v202, v164, v139                             // 0000000282B4: 119517A4
	s_mov_b32 vcc_lo, s4                                       // 0000000282B8: BEEA0004
	v_mul_f32_e32 v201, v159, v145                             // 0000000282BC: 1193239F
	v_div_fixup_f32 v156, v158, v156, 1.0                      // 0000000282C0: D627009C 03CB399E
	.long 0xd7000507                                           // 0000000282C8: D7000507
	v_cndmask_b32_e32 v1, s12, v7, vcc_lo                      // 0000000282CC: 02020E0C
	v_fma_f32 v208, -v160, v202, v164                          // 0000000282D0: D61300D0 269395A0
	v_mul_f32_e32 v199, v166, v169                             // 0000000282D8: 118F53A6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000282DC: BF870224
	v_mul_f32_e32 v121, v156, v121                             // 0000000282E0: 10F2F39C
	v_add_co_ci_u32_e64 v8, null, s13, v8, s5                  // 0000000282E4: D5207C08 0016100D
	v_fmac_f32_e32 v202, v208, v139                            // 0000000282EC: 579517D0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000282F0: BF8700A4
	v_fma_f32 v205, -v163, v199, v166                          // 0000000282F4: D61300CD 269B8FA3
	.long 0xd700050f                                           // 0000000282FC: D700050F
	v_cndmask_b32_e32 v1, s12, v15, vcc_lo                     // 000000028300: 02021E0C
	v_add_co_ci_u32_e64 v16, null, s13, v16, s5                // 000000028304: D5207C10 0016200D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002830C: BF8700A3
	v_fmac_f32_e32 v199, v205, v169                            // 000000028310: 578F53CD
	.long 0xd7000517                                           // 000000028314: D7000517
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 000000028318: 02022E0C
	v_add_co_ci_u32_e64 v24, null, s13, v24, s5                // 00000002831C: D5207C18 0016300D
	.long 0xd700051f                                           // 000000028324: D700051F
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 000000028328: 02023E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002832C: BF8700A1
	v_add_co_ci_u32_e64 v32, null, s13, v32, s5                // 000000028330: D5207C20 0016400D
	.long 0xd7000527                                           // 000000028338: D7000527
	v_cndmask_b32_e32 v1, s12, v39, vcc_lo                     // 00000002833C: 02024E0C
	v_add_co_ci_u32_e64 v40, null, s13, v40, s5                // 000000028340: D5207C28 0016500D
	.long 0xd700052f                                           // 000000028348: D700052F
	v_cndmask_b32_e32 v1, s12, v47, vcc_lo                     // 00000002834C: 02025E0C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000028350: BF870001
	v_add_co_ci_u32_e64 v48, null, s13, v48, s5                // 000000028354: D5207C30 0016600D
	.long 0x7f003880                                           // 00000002835C: 7F003880
	v_mul_f32_e32 v81, v156, v81                               // 000000028360: 10A2A39C
	v_mul_f32_e32 v73, v156, v73                               // 000000028364: 1092939C
	v_mul_f32_e32 v57, v156, v57                               // 000000028368: 1072739C
	v_mul_f32_e32 v49, v156, v49                               // 00000002836C: 1062639C
	.long 0xd59c4880                                           // 000000028370: D59C4880
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                     // 000000028374: 02010100
	.long 0x7ff03980                                           // 000000028378: 7FF03980
	.long 0x7fe03980                                           // 00000002837C: 7FE03980
	.long 0x7fee3980                                           // 000000028380: 7FEE3980
	.long 0x7fde3980                                           // 000000028384: 7FDE3980
	v_mul_f32_e32 v33, v156, v33                               // 000000028388: 1042439C
	v_mul_f32_e32 v17, v156, v17                               // 00000002838C: 1022239C
	v_mul_f32_e32 v9, v156, v9                                 // 000000028390: 1012139C
	v_mul_f32_e32 v1, v156, v1                                 // 000000028394: 1002039C
	v_mul_f32_e32 v97, v156, v97                               // 000000028398: 10C2C39C
	s_waitcnt vmcnt(47)                                        // 00000002839C: BF89BFF7
	v_lshlrev_b32_e32 v103, 16, v103                           // 0000000283A0: 30CECE90
	s_waitcnt vmcnt(46)                                        // 0000000283A4: BF89BBF7
	v_dual_mul_f32 v203, v165, v137 :: v_dual_lshlrev_b32 v104, 16, v104// 0000000283A8: C8E313A5 CB68D090
	v_fma_f32 v207, -v157, v201, v159                          // 0000000283B0: D61300CF 267F939D
	s_waitcnt vmcnt(44)                                        // 0000000283B8: BF89B3F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000283BC: BF8701C1
	v_dual_fmac_f32 v201, v207, v145 :: v_dual_lshlrev_b32 v132, 16, v132// 0000000283C0: C82323CF C9850890
	v_fma_f32 v162, -v163, v199, v166                          // 0000000283C8: D61300A2 269B8FA3
	s_waitcnt vmcnt(42)                                        // 0000000283D0: BF89ABF7
	v_lshlrev_b32_e32 v134, 16, v134                           // 0000000283D4: 310D0C90
	v_fma_f32 v157, -v157, v201, v159                          // 0000000283D8: D613009D 267F939D
	v_fma_f32 v159, -v160, v202, v164                          // 0000000283E0: D613009F 269395A0
	v_mul_f32_e32 v160, v156, v113                             // 0000000283E8: 1140E39C
	v_div_fmas_f32 v162, v162, v169, v199                      // 0000000283EC: D63700A2 071F53A2
	v_dual_mul_f32 v170, 0xbfb8aa3b, v132 :: v_dual_lshlrev_b32 v113, 16, v173// 0000000283F4: C8E308FF AA715A90 BFB8AA3B
	v_fma_f32 v163, -v167, v200, v168                          // 000000028400: D61300A3 26A391A7
	v_dual_mul_f32 v198, 0xbfb8aa3b, v134 :: v_dual_lshlrev_b32 v131, 16, v131// 000000028408: C8E30CFF C6830690 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000028414: BF870004
	v_div_fixup_f32 v155, v162, v155, 1.0                      // 000000028418: D627009B 03CB37A2
	v_mul_f32_e32 v162, 0xbfb8aa3b, v104                       // 000000028420: 1144D0FF BFB8AA3B
	v_fma_f32 v209, -v161, v203, v165                          // 000000028428: D61300D1 269797A1
	v_mul_f32_e32 v164, 0xbfb8aa3b, v113                       // 000000028430: 1148E2FF BFB8AA3B
	s_waitcnt vmcnt(39)                                        // 000000028438: BF899FF7
	v_lshlrev_b32_e32 v144, 16, v144                           // 00000002843C: 31212090
	s_waitcnt vmcnt(36)                                        // 000000028440: BF8993F7
	v_lshlrev_b32_e32 v150, 16, v150                           // 000000028444: 312D2C90
	v_rndne_f32_e32 v168, v162                                 // 000000028448: 7F5047A2
	v_fmac_f32_e32 v203, v209, v137                            // 00000002844C: 579713D1
	v_lshlrev_b32_e32 v143, 16, v143                           // 000000028450: 311F1E90
	v_fma_f32 v167, 0xbfb8aa3b, v104, -v162                    // 000000028454: D61300A7 868AD0FF BFB8AA3B
	v_rndne_f32_e32 v205, v164                                 // 000000028460: 7F9A47A4
	v_mul_f32_e32 v169, 0xbfb8aa3b, v131                       // 000000028464: 115306FF BFB8AA3B
	v_fma_f32 v158, -v161, v203, v165                          // 00000002846C: D613009E 269797A1
	v_dual_mul_f32 v161, 0xbfb8aa3b, v103 :: v_dual_sub_f32 v162, v162, v168// 000000028474: C8CACEFF A1A351A2 BFB8AA3B
	v_dual_mul_f32 v206, 0xbfb8aa3b, v143 :: v_dual_lshlrev_b32 v133, 16, v133// 000000028480: C8E31EFF CE850A90 BFB8AA3B
	v_dual_mul_f32 v208, 0xbfb8aa3b, v150 :: v_dual_lshlrev_b32 v135, 16, v135// 00000002848C: C8E32CFF D0870E90 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000028498: BF870003
	v_fma_f32 v165, 0xbfb8aa3b, v103, -v161                    // 00000002849C: D61300A5 8686CEFF BFB8AA3B
	v_rndne_f32_e32 v166, v161                                 // 0000000284A8: 7F4C47A1
	v_fma_f32 v204, 0xbfb8aa3b, v113, -v164                    // 0000000284AC: D61300CC 8692E2FF BFB8AA3B
	v_fmac_f32_e32 v167, 0xb2a5705f, v104                      // 0000000284B8: 574ED0FF B2A5705F
	v_mul_f32_e32 v173, 0xbfb8aa3b, v133                       // 0000000284C0: 115B0AFF BFB8AA3B
	v_fma_f32 v212, 0xbfb8aa3b, v132, -v170                    // 0000000284C8: D61300D4 86AB08FF BFB8AA3B
	v_fmac_f32_e32 v165, 0xb2a5705f, v103                      // 0000000284D4: 574ACEFF B2A5705F
	v_rndne_f32_e32 v213, v170                                 // 0000000284DC: 7FAA47AA
	v_sub_f32_e32 v164, v164, v205                             // 0000000284E0: 09499BA4
	v_fma_f32 v210, 0xbfb8aa3b, v131, -v169                    // 0000000284E4: D61300D2 86A706FF BFB8AA3B
	v_sub_f32_e32 v161, v161, v166                             // 0000000284F0: 09434DA1
	v_rndne_f32_e32 v211, v169                                 // 0000000284F4: 7FA647A9
	v_dual_fmac_f32 v204, 0xb2a5705f, v113 :: v_dual_lshlrev_b32 v151, 16, v151// 0000000284F8: C822E2FF CC972E90 B2A5705F
	v_mul_f32_e32 v199, 0xbfb8aa3b, v135                       // 000000028504: 118F0EFF BFB8AA3B
	v_dual_mul_f32 v207, 0xbfb8aa3b, v144 :: v_dual_sub_f32 v170, v170, v213// 00000002850C: C8CB20FF CFABABAA BFB8AA3B
	v_fma_f32 v216, 0xbfb8aa3b, v134, -v198                    // 000000028518: D61300D8 871B0CFF BFB8AA3B
	v_rndne_f32_e32 v217, v198                                 // 000000028524: 7FB247C6
	v_fmac_f32_e32 v210, 0xb2a5705f, v131                      // 000000028528: 57A506FF B2A5705F
	v_add_f32_e32 v162, v162, v167                             // 000000028530: 07454FA2
	v_fma_f32 v214, 0xbfb8aa3b, v133, -v173                    // 000000028534: D61300D6 86B70AFF BFB8AA3B
	v_rndne_f32_e32 v215, v173                                 // 000000028540: 7FAE47AD
	v_dual_fmac_f32 v212, 0xb2a5705f, v132 :: v_dual_add_f32 v161, v161, v165// 000000028544: C80908FF D4A14BA1 B2A5705F
	v_dual_fmac_f32 v216, 0xb2a5705f, v134 :: v_dual_sub_f32 v169, v169, v211// 000000028550: C80B0CFF D8A9A7A9 B2A5705F
	v_dual_mul_f32 v209, 0xbfb8aa3b, v151 :: v_dual_sub_f32 v198, v198, v217// 00000002855C: C8CB2EFF D1C7B3C6 BFB8AA3B
	v_add_f32_e32 v164, v164, v204                             // 000000028568: 074999A4
	v_fma_f32 v165, 0xbfb8aa3b, v135, -v199                    // 00000002856C: D61300A5 871F0EFF BFB8AA3B
	v_rndne_f32_e32 v167, v199                                 // 000000028578: 7F4E47C7
	v_fma_f32 v204, 0xbfb8aa3b, v143, -v206                    // 00000002857C: D61300CC 873B1EFF BFB8AA3B
	v_fmac_f32_e32 v214, 0xb2a5705f, v133                      // 000000028588: 57AD0AFF B2A5705F
	v_dual_add_f32 v170, v170, v212 :: v_dual_add_f32 v169, v169, v210// 000000028590: C909A9AA AAA9A5A9
	v_add_f32_e32 v198, v198, v216                             // 000000028598: 078DB1C6
	v_rndne_f32_e32 v210, v206                                 // 00000002859C: 7FA447CE
	v_sub_f32_e32 v173, v173, v215                             // 0000000285A0: 095BAFAD
	v_exp_f32_e32 v161, v161                                   // 0000000285A4: 7F424BA1
	v_fma_f32 v212, 0xbfb8aa3b, v144, -v207                    // 0000000285A8: D61300D4 873F20FF BFB8AA3B
	v_fmac_f32_e32 v165, 0xb2a5705f, v135                      // 0000000285B4: 574B0EFF B2A5705F
	v_fmac_f32_e32 v204, 0xb2a5705f, v143                      // 0000000285BC: 57991EFF B2A5705F
	v_sub_f32_e32 v206, v206, v210                             // 0000000285C4: 099DA5CE
	v_add_f32_e32 v173, v173, v214                             // 0000000285C8: 075BADAD
	v_rndne_f32_e32 v214, v207                                 // 0000000285CC: 7FAC47CF
	v_sub_f32_e32 v199, v199, v167                             // 0000000285D0: 098F4FC7
	v_exp_f32_e32 v162, v162                                   // 0000000285D4: 7F444BA2
	v_cvt_i32_f32_e32 v166, v166                               // 0000000285D8: 7F4C11A6
	v_fma_f32 v216, 0xbfb8aa3b, v150, -v208                    // 0000000285DC: D61300D8 87432CFF BFB8AA3B
	v_dual_fmac_f32 v212, 0xb2a5705f, v144 :: v_dual_sub_f32 v207, v207, v214// 0000000285E8: C80B20FF D4CFADCF B2A5705F
	s_waitcnt vmcnt(35)                                        // 0000000285F4: BF898FF7
	v_lshlrev_b32_e32 v152, 16, v152                           // 0000000285F8: 31313090
	v_dual_add_f32 v204, v206, v204 :: v_dual_add_f32 v165, v199, v165// 0000000285FC: C90999CE CCA54BC7
	v_fmac_f32_e32 v216, 0xb2a5705f, v150                      // 000000028604: 57B12CFF B2A5705F
	v_rndne_f32_e32 v199, v208                                 // 00000002860C: 7F8E47D0
	v_exp_f32_e32 v164, v164                                   // 000000028610: 7F484BA4
	v_cvt_i32_f32_e32 v168, v168                               // 000000028614: 7F5011A8
	.long 0xd71c00a1                                           // 000000028618: D71C00A1
	v_cndmask_b32_e32 v1, v161, v166, vcc_lo                   // 00000002861C: 02034DA1
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v103                 // 000000028620: 7C3CCEFF 42CE8ED0
	v_dual_add_f32 v207, v207, v212 :: v_dual_sub_f32 v208, v208, v199// 000000028628: C90BA9CF CFD18FD0
	v_mul_f32_e32 v122, v155, v122                             // 000000028630: 10F4F59B
	v_cvt_i32_f32_e32 v205, v205                               // 000000028634: 7F9A11CD
	.long 0xd71c00a2                                           // 000000028638: D71C00A2
	v_cndmask_b32_e32 v1, v162, v168, vcc_lo                   // 00000002863C: 020351A2
	v_exp_f32_e32 v169, v169                                   // 000000028640: 7F524BA9
	v_exp_f32_e32 v170, v170                                   // 000000028644: 7F544BAA
	v_exp_f32_e32 v173, v173                                   // 000000028648: 7F5A4BAD
	v_exp_f32_e32 v198, v198                                   // 00000002864C: 7F8C4BC6
	v_cndmask_b32_e32 v161, 0, v161, vcc_lo                    // 000000028650: 03434280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 000000028654: 7C3CD0FF 42CE8ED0
	v_add_f32_e32 v208, v208, v216                             // 00000002865C: 07A1B1D0
	.long 0xd71c00a4                                           // 000000028660: D71C00A4
	v_cndmask_b32_e32 v1, v164, v205, vcc_lo                   // 000000028664: 02039BA4
	v_mul_f32_e32 v205, v155, v114                             // 000000028668: 119AE59B
	v_cvt_i32_f32_e32 v114, v211                               // 00000002866C: 7EE411D3
	v_cvt_i32_f32_e32 v211, v213                               // 000000028670: 7FA611D5
	v_cvt_i32_f32_e32 v213, v215                               // 000000028674: 7FAA11D7
	v_cvt_i32_f32_e32 v215, v217                               // 000000028678: 7FAE11D9
	v_cndmask_b32_e32 v162, 0, v162, vcc_lo                    // 00000002867C: 03454480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000028680: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v165, v165                                   // 000000028688: 7F4A4BA5
	.long 0xd71c0072                                           // 00000002868C: D71C0072
	v_cndmask_b32_e32 v1, v169, v114, vcc_lo                   // 000000028690: 0202E5A9
	.long 0xd71c00a9                                           // 000000028694: D71C00A9
	v_cndmask_b32_e32 v1, v170, v211, vcc_lo                   // 000000028698: 0203A7AA
	.long 0xd71c00aa                                           // 00000002869C: D71C00AA
	v_cndmask_b32_e32 v1, v173, v213, vcc_lo                   // 0000000286A0: 0203ABAD
	.long 0xd71c00ad                                           // 0000000286A4: D71C00AD
	v_cndmask_b32_e32 v1, v198, v215, vcc_lo                   // 0000000286A8: 0203AFC6
	v_cndmask_b32_e32 v164, 0, v164, vcc_lo                    // 0000000286AC: 03494880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v103                 // 0000000286B0: 7C36CEFF C2B17218
	v_cvt_i32_f32_e32 v167, v167                               // 0000000286B8: 7F4E11A7
	s_waitcnt vmcnt(34)                                        // 0000000286BC: BF898BF7
	v_dual_mul_f32 v216, 0xbfb8aa3b, v152 :: v_dual_lshlrev_b32 v149, 16, v149// 0000000286C0: C8E330FF D8952A90 BFB8AA3B
	v_fma_f32 v206, 0xbfb8aa3b, v151, -v209                    // 0000000286CC: D61300CE 87472EFF BFB8AA3B
	v_cndmask_b32_e32 v103, 0x7f800000, v161, vcc_lo           // 0000000286D8: 02CF42FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 0000000286E0: 7C36D0FF C2B17218
	.long 0xd71c00a5                                           // 0000000286E8: D71C00A5
	v_cndmask_b32_e32 v1, v165, v167, vcc_lo                   // 0000000286EC: 02034FA5
	v_fma_f32 v166, 0xbfb8aa3b, v152, -v216                    // 0000000286F0: D61300A6 876330FF BFB8AA3B
	v_rndne_f32_e32 v212, v209                                 // 0000000286FC: 7FA847D1
	v_exp_f32_e32 v204, v204                                   // 000000028700: 7F984BCC
	v_cndmask_b32_e32 v104, 0x7f800000, v162, vcc_lo           // 000000028704: 02D144FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v131                 // 00000002870C: 7C3D06FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3)                            // 000000028714: BF870003
	v_dual_fmac_f32 v206, 0xb2a5705f, v151 :: v_dual_sub_f32 v209, v209, v212// 000000028718: C80B2EFF CED1A9D1 B2A5705F
	v_cvt_i32_f32_e32 v210, v210                               // 000000028724: 7FA411D2
	v_exp_f32_e32 v207, v207                                   // 000000028728: 7F9E4BCF
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000002872C: 02E4E480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v132                 // 000000028730: 7C3D08FF 42CE8ED0
	v_fmac_f32_e32 v166, 0xb2a5705f, v152                      // 000000028738: 574D30FF B2A5705F
	v_rndne_f32_e32 v168, v216                                 // 000000028740: 7F5047D8
	v_add_f32_e32 v206, v209, v206                             // 000000028744: 079D9DD1
	v_cvt_i32_f32_e32 v214, v214                               // 000000028748: 7FAC11D6
	v_cndmask_b32_e32 v161, 0, v169, vcc_lo                    // 00000002874C: 03435280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v133                 // 000000028750: 7C3D0AFF 42CE8ED0
	v_exp_f32_e32 v208, v208                                   // 000000028758: 7FA04BD0
	.long 0xd71c00a7                                           // 00000002875C: D71C00A7
	v_cndmask_b32_e32 v1, v204, v210, vcc_lo                   // 000000028760: 0203A5CC
	v_sub_f32_e32 v209, v216, v168                             // 000000028764: 09A351D8
	v_cvt_i32_f32_e32 v199, v199                               // 000000028768: 7F8E11C7
	v_cndmask_b32_e32 v162, 0, v170, vcc_lo                    // 00000002876C: 03455480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v134                 // 000000028770: 7C3D0CFF 42CE8ED0
	v_exp_f32_e32 v206, v206                                   // 000000028778: 7F9C4BCE
	.long 0xd71c00c6                                           // 00000002877C: D71C00C6
	v_cndmask_b32_e32 v1, v207, v214, vcc_lo                   // 000000028780: 0203ADCF
	v_cvt_i32_f32_e32 v212, v212                               // 000000028784: 7FA811D4
	.long 0xd41b0005                                           // 000000028788: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v144, vcc_lo             // 00000002878C: 020320FF C2B17218
	v_cndmask_b32_e32 v169, 0, v173, vcc_lo                    // 000000028794: 03535A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v135                 // 000000028798: 7C3D0EFF 42CE8ED0
	.long 0xd71c00c7                                           // 0000000287A0: D71C00C7
	v_cndmask_b32_e32 v1, v208, v199, vcc_lo                   // 0000000287A4: 02038FD0
	v_dual_add_f32 v173, 1.0, v103 :: v_dual_mul_f32 v106, v155, v106// 0000000287A8: C906CEF2 AD6AD59B
	v_dual_mul_f32 v89, v156, v89 :: v_dual_mul_f32 v82, v155, v82// 0000000287B0: C8C6B39C 5952A59B
	v_cndmask_b32_e32 v165, 0, v165, vcc_lo                    // 0000000287B8: 034B4A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000287BC: 7C36E2FF C2B17218
	.long 0xd71c00cc                                           // 0000000287C4: D71C00CC
	v_cndmask_b32_e32 v1, v206, v212, vcc_lo                   // 0000000287C8: 0203A9CE
	v_mul_f32_e32 v26, v155, v26                               // 0000000287CC: 1034359B
	v_mul_f32_e32 v2, v155, v2                                 // 0000000287D0: 1004059B
	v_dual_mul_f32 v98, v155, v98 :: v_dual_cndmask_b32 v113, 0x7f800000, v164// 0000000287D4: C8D2C59B 627148FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v143                 // 0000000287E0: 7C3D1EFF 42CE8ED0
	v_mul_f32_e32 v90, v155, v90                               // 0000000287E8: 10B4B59B
	v_mul_f32_e32 v74, v155, v74                               // 0000000287EC: 1094959B
	v_mul_f32_e32 v58, v155, v58                               // 0000000287F0: 1074759B
	v_mul_f32_e32 v50, v155, v50                               // 0000000287F4: 1064659B
	v_cndmask_b32_e32 v164, 0, v167, vcc_lo                    // 0000000287F8: 03494E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v144                 // 0000000287FC: 7C3D20FF 42CE8ED0
	v_mul_f32_e32 v42, v155, v42                               // 000000028804: 1054559B
	v_mul_f32_e32 v34, v155, v34                               // 000000028808: 1044459B
	v_mul_f32_e32 v18, v155, v18                               // 00000002880C: 1024259B
	v_mul_f32_e32 v10, v155, v10                               // 000000028810: 1014159B
	v_cndmask_b32_e32 v167, 0, v198, vcc_lo                    // 000000028814: 034F8C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v150                 // 000000028818: 7C3D2CFF 42CE8ED0
	v_add_f32_e32 v170, 1.0, v104                              // 000000028820: 0754D0F2
	v_div_scale_f32 v198, null, v173, v173, v121               // 000000028824: D6FC7CC6 05E75BAD
	v_cndmask_b32_e32 v103, 0, v199, vcc_lo                    // 00000002882C: 02CF8E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v151                 // 000000028830: 7C3D2EFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000028838: BF870004
	v_div_scale_f32 v199, null, v170, v170, v122               // 00000002883C: D6FC7CC7 05EB55AA
	v_cndmask_b32_e32 v104, 0, v204, vcc_lo                    // 000000028844: 02D19880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v131                 // 000000028848: 7C3706FF C2B17218
	v_cndmask_b32_e32 v114, 0x7f800000, v114, vcc_lo           // 000000028850: 02E4E4FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v132                 // 000000028858: 7C3708FF C2B17218
	v_rcp_f32_e32 v132, v198                                   // 000000028860: 7F0855C6
	v_cndmask_b32_e32 v131, 0x7f800000, v161, vcc_lo           // 000000028864: 030742FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v133                 // 00000002886C: 7C370AFF C2B17218
	v_rcp_f32_e32 v161, v199                                   // 000000028874: 7F4255C7
	s_delay_alu instid0(VALU_DEP_2)                            // 000000028878: BF870002
	v_add_f32_e32 v131, 1.0, v131                              // 00000002887C: 070706F2
	v_cndmask_b32_e32 v133, 0x7f800000, v162, vcc_lo           // 000000028880: 030B44FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v134                 // 000000028888: 7C370CFF C2B17218
	v_cndmask_b32_e32 v134, 0x7f800000, v169, vcc_lo           // 000000028890: 030D52FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v135                 // 000000028898: 7C370EFF C2B17218
	v_div_scale_f32 v169, s4, v122, v170, v122                 // 0000000288A0: D6FC04A9 05EB557A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000000288A8: BF870253
	v_dual_add_f32 v133, 1.0, v133 :: v_dual_add_f32 v134, 1.0, v134// 0000000288AC: C9090AF2 85870CF2
	v_cndmask_b32_e32 v135, 0x7f800000, v165, vcc_lo           // 0000000288B4: 030F4AFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v143                 // 0000000288BC: 7C371EFF C2B17218
	v_add_f32_e32 v162, 1.0, v113                              // 0000000288C4: 0744E2F2
	v_fma_f32 v143, -v198, v132, 1.0                           // 0000000288C8: D613008F 23CB09C6
	v_dual_add_f32 v210, 1.0, v114 :: v_dual_add_f32 v135, 1.0, v135// 0000000288D0: C908E4F2 D2870EF2
	v_cndmask_b32_e32 v113, 0x7f800000, v164, vcc_lo           // 0000000288D8: 02E348FF 7F800000
	v_fma_f32 v164, -v199, v161, 1.0                           // 0000000288E0: D61300A4 23CB43C7
	v_div_scale_f32 v165, vcc_lo, v121, v173, v121             // 0000000288E8: D6FC6AA5 05E75B79
	v_fmac_f32_e32 v132, v143, v132                            // 0000000288F0: 5709098F
	v_cndmask_b32_e64 v143, 0x7f800000, v167, s5               // 0000000288F4: D501008F 00174EFF 7F800000
	.long 0xd41b0005                                           // 000000028900: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v150, vcc_lo             // 000000028904: 02032CFF C2B17218
	v_fmac_f32_e32 v161, v164, v161                            // 00000002890C: 574343A4
	v_div_scale_f32 v144, null, v162, v162, v160               // 000000028910: D6FC7C90 068345A2
	v_div_scale_f32 v164, null, v135, v135, v205               // 000000028918: D6FC7CA4 07370F87
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000028920: BF870214
	v_cndmask_b32_e64 v150, 0x7f800000, v103, s5               // 000000028924: D5010096 0016CEFF 7F800000
	v_mul_f32_e32 v204, v169, v161                             // 000000028930: 119943A9
	.long 0xd41b0005                                           // 000000028934: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v151, vcc_lo             // 000000028938: 02032EFF C2B17218
	v_rcp_f32_e32 v206, v144                                   // 000000028940: 7F9C5590
	v_rcp_f32_e32 v207, v164                                   // 000000028944: 7F9E55A4
	v_add_f32_e32 v150, 1.0, v150                              // 000000028948: 072D2CF2
	v_fma_f32 v208, -v199, v204, v169                          // 00000002894C: D61300D0 26A799C7
	v_mul_f32_e32 v167, v165, v132                             // 000000028954: 114F09A5
	v_cndmask_b32_e64 v151, 0x7f800000, v104, s5               // 000000028958: D5010097 0016D0FF 7F800000
	v_div_scale_f32 v114, s5, v160, v162, v160                 // 000000028964: D6FC0572 068345A0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002896C: BF870214
	v_fmac_f32_e32 v204, v208, v161                            // 000000028970: 579943D0
	v_fma_f32 v103, -v198, v167, v165                          // 000000028974: D6130067 26974FC6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002897C: BF870112
	v_fma_f32 v169, -v199, v204, v169                          // 000000028980: D61300A9 26A799C7
	v_fmac_f32_e32 v167, v103, v132                            // 000000028988: 574F0967
	v_fma_f32 v103, -v144, v206, 1.0                           // 00000002898C: D6130067 23CB9D90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000028994: BF8701A2
	v_fma_f32 v104, -v198, v167, v165                          // 000000028998: D6130068 26974FC6
	v_fma_f32 v165, -v164, v207, 1.0                           // 0000000289A0: D61300A5 23CB9FA4
	v_fmac_f32_e32 v206, v103, v206                            // 0000000289A8: 579D9D67
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000289AC: BF8701A3
	v_div_fmas_f32 v132, v104, v132, v167                      // 0000000289B0: D6370084 069F0968
	s_mov_b32 vcc_lo, s4                                       // 0000000289B8: BEEA0004
	v_fmac_f32_e32 v207, v165, v207                            // 0000000289BC: 579F9FA5
	v_div_fmas_f32 v161, v169, v161, v204                      // 0000000289C0: D63700A1 073343A9
	s_mov_b32 vcc_lo, s2                                       // 0000000289C8: BEEA0002
	v_div_fixup_f32 v121, v132, v173, v121                     // 0000000289CC: D6270079 05E75B84
	v_div_fmas_f32 v104, v163, v146, v200                      // 0000000289D4: D6370068 072325A3
	s_mov_b32 vcc_lo, s3                                       // 0000000289DC: BEEA0003
	v_div_scale_f32 v146, s2, v205, v135, v205                 // 0000000289E0: D6FC0292 07370FCD
	v_div_fmas_f32 v145, v157, v145, v201                      // 0000000289E8: D6370091 0727239D
	v_div_fixup_f32 v122, v161, v170, v122                     // 0000000289F0: D627007A 05EB55A1
	v_div_fixup_f32 v104, v104, v142, 1.0                      // 0000000289F8: D6270068 03CB1D68
	.long 0xd59c0880                                           // 000000028A00: D59C0880
	v_cndmask_b32_e32 v0, v121, v128, vcc_lo                   // 000000028A04: 02010179
	v_mul_f32_e32 v142, v146, v207                             // 000000028A08: 111D9F92
	v_div_fixup_f32 v103, v145, v141, 1.0                      // 000000028A0C: D6270067 03CB1B91
	v_mul_f32_e32 v141, v114, v206                             // 000000028A14: 111B9D72
	v_mul_f32_e32 v123, v104, v123                             // 000000028A18: 10F6F768
	.long 0x7e0039fa                                           // 000000028A1C: 7E0039FA
	v_fma_f32 v163, -v164, v142, v146                          // 000000028A20: D61300A3 264B1DA4
	v_mul_f32_e32 v124, v103, v124                             // 000000028A28: 10F8F967
	v_fma_f32 v145, -v144, v141, v114                          // 000000028A2C: D6130091 25CB1B90
	v_div_scale_f32 v157, null, v210, v210, v123               // 000000028A34: D6FC7C9D 05EFA5D2
	v_div_scale_f32 v132, vcc_lo, v123, v210, v123             // 000000028A3C: D6FC6A84 05EFA57B
	v_fmac_f32_e32 v142, v163, v207                            // 000000028A44: 571D9FA3
	v_div_scale_f32 v165, null, v131, v131, v124               // 000000028A48: D6FC7CA5 05F30783
	v_fmac_f32_e32 v141, v145, v206                            // 000000028A50: 571B9D91
	v_rcp_f32_e32 v145, v157                                   // 000000028A54: 7F22559D
	v_dual_mul_f32 v115, v104, v115 :: v_dual_and_b32 v128, 1, v128// 000000028A58: C8E4E768 73810081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000028A60: BF870113
	v_rcp_f32_e32 v163, v165                                   // 000000028A64: 7F4655A5
	v_fma_f32 v144, -v144, v141, v114                          // 000000028A68: D6130090 25CB1B90
	v_dual_add_f32 v143, 1.0, v143 :: v_dual_mul_f32 v116, v103, v116// 000000028A70: C9071EF2 8F74E967
	v_fma_f32 v146, -v164, v142, v146                          // 000000028A78: D6130092 264B1DA4
	v_add3_u32 v121, v121, v128, 0x7fff                        // 000000028A80: D6550079 03FF0179 00007FFF
	v_dual_mul_f32 v107, v104, v107 :: v_dual_mul_f32 v100, v103, v100// 000000028A8C: C8C6D768 6B64C967
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000028A94: BF8702A4
	v_div_scale_f32 v161, null, v143, v143, v116               // 000000028A98: D6FC7CA1 05D31F8F
	v_mul_f32_e32 v92, v103, v92                               // 000000028AA0: 10B8B967
	v_fma_f32 v114, -v165, v163, 1.0                           // 000000028AA4: D6130072 23CB47A5
	v_dual_mul_f32 v84, v103, v84 :: v_dual_mul_f32 v91, v104, v91// 000000028AAC: C8C6A967 545AB768
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000028AB4: BF870114
	v_rcp_f32_e32 v173, v161                                   // 000000028AB8: 7F5A55A1
	v_dual_mul_f32 v76, v103, v76 :: v_dual_fmac_f32 v163, v114, v163// 000000028ABC: C8C09967 4CA34772
	v_add_f32_e32 v167, 1.0, v113                              // 000000028AC4: 074EE2F2
	v_fma_f32 v113, -v157, v145, 1.0                           // 000000028AC8: D6130071 23CB239D
	v_mul_f32_e32 v83, v104, v83                               // 000000028AD0: 10A6A768
	v_dual_mul_f32 v75, v104, v75 :: v_dual_mul_f32 v60, v103, v60// 000000028AD4: C8C69768 4B3C7967
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000028ADC: BF8702A3
	v_dual_mul_f32 v52, v103, v52 :: v_dual_fmac_f32 v145, v113, v145// 000000028AE0: C8C06967 34912371
	v_div_scale_f32 v113, s3, v124, v131, v124                 // 000000028AE8: D6FC0371 05F3077C
	v_fma_f32 v201, -v161, v173, 1.0                           // 000000028AF0: D61300C9 23CB5BA1
	v_dual_mul_f32 v59, v104, v59 :: v_dual_mul_f32 v44, v103, v44// 000000028AF8: C8C67768 3B2C5967
	v_mul_f32_e32 v51, v104, v51                               // 000000028B00: 10666768
	s_delay_alu instid0(VALU_DEP_4)                            // 000000028B04: BF870004
	v_mul_f32_e32 v170, v113, v163                             // 000000028B08: 11554771
	v_div_scale_f32 v164, null, v167, v167, v115               // 000000028B0C: D6FC7CA4 05CF4FA7
	v_div_scale_f32 v200, s4, v115, v167, v115                 // 000000028B14: D6FC04C8 05CF4F73
	v_mul_f32_e32 v36, v103, v36                               // 000000028B1C: 10484967
	v_mul_f32_e32 v28, v103, v28                               // 000000028B20: 10383967
	v_fma_f32 v199, -v165, v170, v113                          // 000000028B24: D61300C7 25C755A5
	v_rcp_f32_e32 v169, v164                                   // 000000028B2C: 7F5255A4
	v_dual_mul_f32 v20, v103, v20 :: v_dual_mul_f32 v43, v104, v43// 000000028B30: C8C62967 142A5768
	v_mul_f32_e32 v35, v104, v35                               // 000000028B38: 10464768
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000028B3C: BF870243
	v_fmac_f32_e32 v170, v199, v163                            // 000000028B40: 575547C7
	v_dual_add_f32 v151, 1.0, v151 :: v_dual_mul_f32 v114, v132, v145// 000000028B44: C9072EF2 97732384
	v_div_scale_f32 v199, s6, v116, v143, v116                 // 000000028B4C: D6FC06C7 05D31F74
	v_mul_f32_e32 v27, v104, v27                               // 000000028B54: 10363768
	v_fma_f32 v113, -v165, v170, v113                          // 000000028B58: D6130071 25C755A5
	v_mul_f32_e32 v19, v104, v19                               // 000000028B60: 10262768
	v_fma_f32 v198, -v157, v114, v132                          // 000000028B64: D61300C6 2612E59D
	v_mul_f32_e32 v11, v104, v11                               // 000000028B6C: 10161768
	v_dual_mul_f32 v3, v104, v3 :: v_dual_mul_f32 v12, v103, v12// 000000028B70: C8C60768 030C1967
	v_mul_f32_e32 v4, v103, v4                                 // 000000028B78: 10080967
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000028B7C: BF870124
	v_fmac_f32_e32 v114, v198, v145                            // 000000028B80: 56E523C6
	v_fma_f32 v198, -v164, v169, 1.0                           // 000000028B84: D61300C6 23CB53A4
	v_fma_f32 v132, -v157, v114, v132                          // 000000028B8C: D6130084 2612E59D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000028B94: BF870141
	v_div_fmas_f32 v132, v132, v145, v114                      // 000000028B98: D6370084 05CB2384
	s_mov_b32 vcc_lo, s3                                       // 000000028BA0: BEEA0003
	v_div_fmas_f32 v145, v113, v163, v170                      // 000000028BA4: D6370091 06AB4771
	s_mov_b32 vcc_lo, s0                                       // 000000028BAC: BEEA0000
	v_div_fixup_f32 v123, v132, v210, v123                     // 000000028BB0: D627007B 05EFA584
	v_div_fmas_f32 v113, v159, v139, v202                      // 000000028BB8: D6370071 072B179F
	s_mov_b32 vcc_lo, s1                                       // 000000028BC0: BEEA0001
	v_and_b32_e32 v139, 1, v0                                  // 000000028BC4: 37160081
	v_div_fmas_f32 v137, v158, v137, v203                      // 000000028BC8: D6370089 072F139E
	.long 0x7ef039fb                                           // 000000028BD0: 7EF039FB
	v_div_fixup_f32 v114, v113, v130, 1.0                      // 000000028BD4: D6270072 03CB0571
	v_fmac_f32_e32 v173, v201, v173                            // 000000028BDC: 575B5BC9
	v_add3_u32 v122, v122, v139, 0x7fff                        // 000000028BE0: D655007A 03FF177A 00007FFF
	v_div_fixup_f32 v113, v137, v129, 1.0                      // 000000028BEC: D6270071 03CB0389
	v_fmac_f32_e32 v169, v198, v169                            // 000000028BF4: 575353C6
	v_dual_mul_f32 v125, v114, v125 :: v_dual_and_b32 v120, 1, v120// 000000028BF8: C8E4FB72 7D78F081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000028C00: BF8701A3
	v_dual_mul_f32 v117, v114, v117 :: v_dual_mul_f32 v118, v113, v118// 000000028C04: C8C6EB72 7576ED71
	v_mul_f32_e32 v126, v113, v126                             // 000000028C0C: 10FCFD71
	v_div_scale_f32 v139, null, v133, v133, v125               // 000000028C10: D6FC7C8B 05F70B85
	v_mul_f32_e32 v130, v200, v169                             // 000000028C18: 110553C8
	s_delay_alu instid0(VALU_DEP_4)                            // 000000028C1C: BF870004
	v_div_scale_f32 v158, null, v150, v150, v117               // 000000028C20: D6FC7C9E 05D72D96
	v_div_fixup_f32 v124, v145, v131, v124                     // 000000028C28: D627007C 05F30791
	s_clause 0x1                                               // 000000028C30: BF850001
	global_store_d16_hi_b16 v[7:8], v121, off                  // 000000028C34: DC960000 007C7907
	global_store_d16_hi_b16 v[7:8], v122, off offset:1024      // 000000028C3C: DC960400 007C7A07
	v_rcp_f32_e32 v132, v139                                   // 000000028C44: 7F08558B
	v_mul_f32_e32 v129, v199, v173                             // 000000028C48: 11035BC7
	v_fma_f32 v128, -v164, v130, v200                          // 000000028C4C: D6130080 272305A4
	v_add3_u32 v120, v123, v120, 0x7fff                        // 000000028C54: D6550078 03FEF17B 00007FFF
	v_div_scale_f32 v157, vcc_lo, v125, v133, v125             // 000000028C60: D6FC6A9D 05F70B7D
	.long 0x7e0039fc                                           // 000000028C68: 7E0039FC
	v_fma_f32 v137, -v161, v129, v199                          // 000000028C6C: D6130089 271F03A1
	v_fmac_f32_e32 v130, v128, v169                            // 000000028C74: 57055380
	v_div_scale_f32 v128, null, v134, v134, v126               // 000000028C78: D6FC7C80 05FB0D86
	global_store_d16_hi_b16 v[15:16], v120, off                // 000000028C80: DC960000 007C780F
	v_div_scale_f32 v165, null, v151, v151, v118               // 000000028C88: D6FC7CA5 05DB2F97
	v_fmac_f32_e32 v129, v137, v173                            // 000000028C90: 57035B89
	v_fma_f32 v137, -v139, v132, 1.0                           // 000000028C94: D6130089 23CB098B
	v_rcp_f32_e32 v131, v128                                   // 000000028C9C: 7F065580
	v_mul_f32_e32 v109, v114, v109                             // 000000028CA0: 10DADB72
	v_mul_f32_e32 v101, v114, v101                             // 000000028CA4: 10CACB72
	v_fma_f32 v122, -v161, v129, v199                          // 000000028CA8: D613007A 271F03A1
	v_rcp_f32_e32 v161, v158                                   // 000000028CB0: 7F42559E
	v_fmac_f32_e32 v132, v137, v132                            // 000000028CB4: 57090989
	v_div_scale_f32 v137, s0, v126, v134, v126                 // 000000028CB8: D6FC0089 05FB0D7E
	v_dual_mul_f32 v93, v114, v93 :: v_dual_mul_f32 v78, v113, v78// 000000028CC0: C8C6BB72 5D4E9D71
	v_mul_f32_e32 v85, v114, v85                               // 000000028CC8: 10AAAB72
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 000000028CCC: BF8702C6
	v_fma_f32 v145, -v128, v131, 1.0                           // 000000028CD0: D6130091 23CB0780
	v_mul_f32_e32 v77, v114, v77                               // 000000028CD8: 109A9B72
	v_mul_f32_e32 v61, v114, v61                               // 000000028CDC: 107A7B72
	v_mul_f32_e32 v53, v114, v53                               // 000000028CE0: 106A6B72
	v_fma_f32 v120, -v158, v161, 1.0                           // 000000028CE4: D6130078 23CB439E
	v_fmac_f32_e32 v131, v145, v131                            // 000000028CEC: 57070791
	v_and_b32_e32 v145, 1, v0                                  // 000000028CF0: 37220081
	v_fma_f32 v121, -v164, v130, v200                          // 000000028CF4: D6130079 272305A4
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000028CFC: BF870254
	v_dual_mul_f32 v22, v113, v22 :: v_dual_fmac_f32 v161, v120, v161// 000000028D00: C8C02D71 16A14378
	v_mul_f32_e32 v159, v157, v132                             // 000000028D08: 113F099D
	v_mul_f32_e32 v163, v137, v131                             // 000000028D0C: 11470789
	v_add3_u32 v124, v124, v145, 0x7fff                        // 000000028D10: D655007C 03FF237C 00007FFF
	v_dual_mul_f32 v45, v114, v45 :: v_dual_mul_f32 v14, v113, v14// 000000028D1C: C8C65B72 2D0E1D71
	v_fma_f32 v123, -v139, v159, v157                          // 000000028D24: D613007B 26773F8B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000028D2C: BF870004
	v_fma_f32 v170, -v128, v163, v137                          // 000000028D30: D61300AA 26274780
	global_store_d16_hi_b16 v[23:24], v124, off                // 000000028D38: DC960000 007C7C17
	v_mul_f32_e32 v37, v114, v37                               // 000000028D40: 104A4B72
	v_dual_mul_f32 v25, v156, v25 :: v_dual_mul_f32 v6, v113, v6// 000000028D44: C8C6339C 19060D71
	v_fmac_f32_e32 v159, v123, v132                            // 000000028D4C: 573F097B
	v_fmac_f32_e32 v163, v170, v131                            // 000000028D50: 574707AA
	v_rcp_f32_e32 v123, v165                                   // 000000028D54: 7EF655A5
	v_mul_f32_e32 v29, v114, v29                               // 000000028D58: 103A3B72
	v_mul_f32_e32 v21, v114, v21                               // 000000028D5C: 102A2B72
	v_fma_f32 v124, -v139, v159, v157                          // 000000028D60: D613007C 26773F8B
	v_fma_f32 v120, -v128, v163, v137                          // 000000028D68: D6130078 26274780
	v_mul_f32_e32 v13, v114, v13                               // 000000028D70: 101A1B72
	v_mul_f32_e32 v5, v114, v5                                 // 000000028D74: 100A0B72
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000028D78: BF870144
	v_div_fmas_f32 v124, v124, v132, v159                      // 000000028D7C: D637007C 067F097C
	s_mov_b32 vcc_lo, s0                                       // 000000028D84: BEEA0000
	v_div_fmas_f32 v120, v120, v131, v163                      // 000000028D88: D6370078 068F0778
	s_mov_b32 vcc_lo, s2                                       // 000000028D90: BEEA0002
	v_div_fixup_f32 v124, v124, v133, v125                     // 000000028D94: D627007C 05F70B7C
	v_div_fmas_f32 v128, v146, v207, v142                      // 000000028D9C: D6370080 063B9F92
	s_mov_b32 vcc_lo, s5                                       // 000000028DA4: BEEA0005
	v_div_fixup_f32 v120, v120, v134, v126                     // 000000028DA8: D6270078 05FB0D78
	v_div_fmas_f32 v125, v144, v206, v141                      // 000000028DB0: D637007D 06379D90
	s_mov_b32 vcc_lo, s4                                       // 000000028DB8: BEEA0004
	.long 0x7eee39fc                                           // 000000028DBC: 7EEE39FC
	v_div_fmas_f32 v121, v121, v169, v130                      // 000000028DC0: D6370079 060B5379
	.long 0x7e0039f8                                           // 000000028DC8: 7E0039F8
	v_div_fixup_f32 v125, v125, v162, v160                     // 000000028DCC: D627007D 0683457D
	v_div_fixup_f32 v126, v128, v135, v205                     // 000000028DD4: D627007E 07370F80
	s_mov_b32 vcc_lo, s6                                       // 000000028DDC: BEEA0006
	v_div_fixup_f32 v115, v121, v167, v115                     // 000000028DE0: D6270073 05CF4F79
	v_div_fmas_f32 v122, v122, v173, v129                      // 000000028DE8: D637007A 06075B7A
	v_and_b32_e32 v121, 1, v0                                  // 000000028DF0: 36F20081
	.long 0x7e0039fd                                           // 000000028DF4: 7E0039FD
	v_and_b32_e32 v119, 1, v119                                // 000000028DF8: 36EEEE81
	.long 0x7ee039fe                                           // 000000028DFC: 7EE039FE
	v_div_fixup_f32 v116, v122, v143, v116                     // 000000028E00: D6270074 05D31F7A
	v_add3_u32 v120, v120, v121, 0x7fff                        // 000000028E08: D6550078 03FEF378 00007FFF
	v_and_b32_e32 v122, 1, v0                                  // 000000028E14: 36F40081
	v_add3_u32 v119, v124, v119, 0x7fff                        // 000000028E18: D6550077 03FEEF7C 00007FFF
	v_and_b32_e32 v112, 1, v112                                // 000000028E24: 36E0E081
	s_clause 0x1                                               // 000000028E28: BF850001
	global_store_d16_hi_b16 v[31:32], v119, off                // 000000028E2C: DC960000 007C771F
	global_store_d16_hi_b16 v[39:40], v120, off                // 000000028E34: DC960000 007C7827
	v_add3_u32 v121, v125, v122, 0x7fff                        // 000000028E3C: D6550079 03FEF57D 00007FFF
	v_fma_f32 v120, -v165, v123, 1.0                           // 000000028E48: D6130078 23CAF7A5
	v_add3_u32 v112, v126, v112, 0x7fff                        // 000000028E50: D6550070 03FEE17E 00007FFF
	s_clause 0x1                                               // 000000028E5C: BF850001
	global_store_d16_hi_b16 v[7:8], v121, off offset:32        // 000000028E60: DC960020 007C7907
	global_store_d16_hi_b16 v[47:48], v112, off offset:32      // 000000028E68: DC960020 007C702F
	v_dual_mul_f32 v112, 0xbfb8aa3b, v149 :: v_dual_fmac_f32 v123, v120, v123// 000000028E70: C8C12AFF 707AF778 BFB8AA3B
	v_add_f32_e32 v121, v209, v166                             // 000000028E7C: 06F34DD1
	.long 0x7e0039f4                                           // 000000028E80: 7E0039F4
	v_div_scale_f32 v164, s1, v117, v150, v117                 // 000000028E84: D6FC01A4 05D72D75
	s_delay_alu instid0(VALU_DEP_4)                            // 000000028E8C: BF870004
	v_fma_f32 v124, 0xbfb8aa3b, v149, -v112                    // 000000028E90: D613007C 85C32AFF BFB8AA3B
	v_rndne_f32_e32 v125, v112                                 // 000000028E9C: 7EFA4770
	v_exp_f32_e32 v120, v121                                   // 000000028EA0: 7EF04B79
	v_div_scale_f32 v121, s0, v118, v151, v118                 // 000000028EA4: D6FC0079 05DB2F76
	.long 0x7ede39f3                                           // 000000028EAC: 7EDE39F3
	v_dual_fmac_f32 v124, 0xb2a5705f, v149 :: v_dual_and_b32 v119, 1, v0// 000000028EB0: C8252AFF 7C760081 B2A5705F
	v_sub_f32_e32 v112, v112, v125                             // 000000028EBC: 08E0FB70
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000028EC0: BF870214
	v_mul_f32_e32 v128, v121, v123                             // 000000028EC4: 1100F779
	v_dual_mul_f32 v122, v164, v161 :: v_dual_and_b32 v111, 1, v111// 000000028EC8: C8E543A4 7A6EDE81
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000028ED0: BF870234
	v_add3_u32 v116, v116, v119, 0x7fff                        // 000000028ED4: D6550074 03FEEF74 00007FFF
	v_cvt_i32_f32_e32 v119, v168                               // 000000028EE0: 7EEE11A8
	v_add_f32_e32 v112, v112, v124                             // 000000028EE4: 06E0F970
	v_fma_f32 v126, -v158, v122, v164                          // 000000028EE8: D613007E 2692F59E
	v_add3_u32 v111, v115, v111, 0x7fff                        // 000000028EF0: D655006F 03FEDF73 00007FFF
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v152                 // 000000028EFC: 7C3D30FF 42CE8ED0
	.long 0xd71c0073                                           // 000000028F04: D71C0073
	v_cndmask_b32_e32 v1, v120, v119, vcc_lo                   // 000000028F08: 0202EF78
	v_fma_f32 v119, -v165, v128, v121                          // 000000028F0C: D6130077 25E701A5
	v_fmac_f32_e32 v122, v126, v161                            // 000000028F14: 56F5437E
	v_exp_f32_e32 v112, v112                                   // 000000028F18: 7EE04B70
	global_store_d16_hi_b16 v[15:16], v111, off offset:32      // 000000028F1C: DC960020 007C6F0F
	v_cndmask_b32_e32 v115, 0, v115, vcc_lo                    // 000000028F24: 02E6E680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v152                 // 000000028F28: 7C3730FF C2B17218
	v_fma_f32 v120, -v158, v122, v164                          // 000000028F30: D6130078 2692F59E
	v_fmac_f32_e32 v128, v119, v123                            // 000000028F38: 5700F777
	v_cvt_i32_f32_e32 v119, v125                               // 000000028F3C: 7EEE117D
	global_store_d16_hi_b16 v[23:24], v116, off offset:32      // 000000028F40: DC960020 007C7417
	v_cndmask_b32_e32 v115, 0x7f800000, v115, vcc_lo           // 000000028F48: 02E6E6FF 7F800000
	s_mov_b32 vcc_lo, s1                                       // 000000028F50: BEEA0001
	v_div_fmas_f32 v120, v120, v161, v122                      // 000000028F54: D6370078 05EB4378
	.long 0xd71c0070                                           // 000000028F5C: D71C0070
	v_cndmask_b32_e32 v1, v112, v119, vcc_lo                   // 000000028F60: 0202EF70
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v149                 // 000000028F64: 7C3D2AFF 42CE8ED0
	v_fma_f32 v119, -v165, v128, v121                          // 000000028F6C: D6130077 25E701A5
	.long 0x7ff43980                                           // 000000028F74: 7FF43980
	v_div_fixup_f32 v117, v120, v150, v117                     // 000000028F78: D6270075 05D72D78
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 000000028F80: 02E0E080
	s_mov_b32 vcc_lo, s0                                       // 000000028F84: BEEA0000
	v_div_fmas_f32 v119, v119, v123, v128                      // 000000028F88: D6370077 0602F777
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v149                 // 000000028F90: 7C372AFF C2B17218
	.long 0x7ef439f5                                           // 000000028F98: 7EF439F5
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000028F9C: BF8701A3
	v_div_fixup_f32 v111, v119, v151, v118                     // 000000028FA0: D627006F 05DB2F77
	v_cndmask_b32_e32 v112, 0x7f800000, v112, vcc_lo           // 000000028FA8: 02E0E0FF 7F800000
	v_and_b32_e32 v122, 1, v122                                // 000000028FB0: 36F4F481
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000028FB4: BF870193
	.long 0x7e0039ef                                           // 000000028FB8: 7E0039EF
	v_add_f32_e32 v112, 1.0, v112                              // 000000028FBC: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000028FC0: BF870193
	v_add3_u32 v117, v117, v122, 0x7fff                        // 000000028FC4: D6550075 03FEF575 00007FFF
	v_and_b32_e32 v128, 1, v0                                  // 000000028FD0: 37000081
	s_delay_alu instid0(VALU_DEP_3)                            // 000000028FD4: BF870003
	v_div_scale_f32 v116, null, v112, v112, v106               // 000000028FD8: D6FC7C74 05AAE170
	global_store_d16_hi_b16 v[31:32], v117, off offset:32      // 000000028FE0: DC960020 007C751F
	s_waitcnt vmcnt(17)                                        // 000000028FE8: BF8947F7
	v_lshlrev_b32_e32 v117, 16, v196                           // 000000028FEC: 30EB8890
	v_add3_u32 v111, v111, v128, 0x7fff                        // 000000028FF0: D655006F 03FF016F 00007FFF
	v_rcp_f32_e32 v124, v116                                   // 000000028FFC: 7EF85574
	global_store_d16_hi_b16 v[39:40], v111, off offset:32      // 000000029000: DC960020 007C6F27
	v_fma_f32 v131, -v116, v124, 1.0                           // 000000029008: D6130083 23CAF974
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000029010: BF870091
	v_dual_fmac_f32 v124, v131, v124 :: v_dual_lshlrev_b32 v129, 16, v181// 000000029014: C822F983 7C816A90
	v_dual_mul_f32 v130, 0xbfb8aa3b, v129 :: v_dual_lshlrev_b32 v119, 16, v182// 00000002901C: C8E302FF 82776C90 BFB8AA3B
	v_mul_f32_e32 v105, v156, v105                             // 000000029028: 10D2D39C
	v_div_scale_f32 v131, s0, v106, v112, v106                 // 00000002902C: D6FC0083 05AAE16A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000029034: BF870213
	v_mul_f32_e32 v120, 0xbfb8aa3b, v119                       // 000000029038: 10F0EEFF BFB8AA3B
	v_fma_f32 v132, 0xbfb8aa3b, v129, -v130                    // 000000029040: D6130084 860B02FF BFB8AA3B
	v_rndne_f32_e32 v133, v130                                 // 00000002904C: 7F0A4782
	.long 0xd41e0001                                           // 000000029050: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v119, vcc_lo             // 000000029054: 0202EEFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000002905C: BF870244
	v_rndne_f32_e32 v126, v120                                 // 000000029060: 7EFC4778
	v_add_f32_e32 v115, 1.0, v115                              // 000000029064: 06E6E6F2
	v_fma_f32 v125, 0xbfb8aa3b, v119, -v120                    // 000000029068: D613007D 85E2EEFF BFB8AA3B
	v_sub_f32_e32 v130, v130, v133                             // 000000029074: 09050B82
	v_sub_f32_e32 v120, v120, v126                             // 000000029078: 08F0FD78
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002907C: BF870214
	v_div_scale_f32 v121, null, v115, v115, v105               // 000000029080: D6FC7C79 05A6E773
	v_fmac_f32_e32 v125, 0xb2a5705f, v119                      // 000000029088: 56FAEEFF B2A5705F
	v_cvt_i32_f32_e32 v126, v126                               // 000000029090: 7EFC117E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000029094: BF870293
	v_rcp_f32_e32 v118, v121                                   // 000000029098: 7EEC5579
	v_fma_f32 v123, -v121, v118, 1.0                           // 00000002909C: D613007B 23CAED79
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000290A4: BF8700A1
	v_fmac_f32_e32 v118, v123, v118                            // 0000000290A8: 56ECED7B
	v_div_scale_f32 v123, vcc_lo, v105, v115, v105             // 0000000290AC: D6FC6A7B 05A6E769
	v_dual_add_f32 v120, v120, v125 :: v_dual_mul_f32 v125, v123, v118// 0000000290B4: C906FB78 787CED7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000290BC: BF870091
	v_exp_f32_e32 v120, v120                                   // 0000000290C0: 7EF04B78
	v_fma_f32 v128, -v121, v125, v123                          // 0000000290C4: D6130080 25EEFB79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000290CC: BF870291
	v_dual_fmac_f32 v132, 0xb2a5705f, v129 :: v_dual_fmac_f32 v125, v128, v118// 0000000290D0: C80102FF 847CED80 B2A5705F
	.long 0xd71c0078                                           // 0000000290DC: D71C0078
	v_cndmask_b32_e32 v1, v120, v126, vcc_lo                   // 0000000290E0: 0202FD78
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000290E4: BF870192
	v_add_f32_e32 v130, v130, v132                             // 0000000290E8: 07050982
	v_fma_f32 v121, -v121, v125, v123                          // 0000000290EC: D6130079 25EEFB79
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000290F4: BF8701A3
	v_cndmask_b32_e64 v120, 0, v120, s1                        // 0000000290F8: D5010078 0006F080
	.long 0xd41b0001                                           // 000000029100: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v119, vcc_lo             // 000000029104: 0202EEFF C2B17218
	v_div_fmas_f32 v118, v121, v118, v125                      // 00000002910C: D6370076 05F6ED79
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v129                 // 000000029114: 7C3D02FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002911C: BF870223
	v_cndmask_b32_e64 v119, 0x7f800000, v120, s1               // 000000029120: D5010077 0006F0FF 7F800000
	v_mul_f32_e32 v134, v131, v124                             // 00000002912C: 110CF983
	v_div_fixup_f32 v105, v118, v115, v105                     // 000000029130: D6270069 05A6E776
	v_mul_f32_e32 v115, 0xbfb8aa3b, v117                       // 000000029138: 10E6EAFF BFB8AA3B
	v_exp_f32_e32 v126, v130                                   // 000000029140: 7EFC4B82
	v_add_f32_e32 v119, 1.0, v119                              // 000000029144: 06EEEEF2
	v_fma_f32 v122, -v116, v134, v131                          // 000000029148: D613007A 260F0D74
	.long 0x7eec39e9                                           // 000000029150: 7EEC39E9
	v_fma_f32 v123, 0xbfb8aa3b, v117, -v115                    // 000000029154: D613007B 85CEEAFF BFB8AA3B
	.long 0x7fec3980                                           // 000000029160: 7FEC3980
	v_div_scale_f32 v121, null, v119, v119, v107               // 000000029164: D6FC7C79 05AEEF77
	v_fmac_f32_e32 v134, v122, v124                            // 00000002916C: 570CF97A
	v_cvt_i32_f32_e32 v122, v133                               // 000000029170: 7EF41185
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 000000029174: BF870085
	.long 0xd71c0078                                           // 000000029178: D71C0078
	v_cndmask_b32_e32 v1, v126, v122, vcc_lo                   // 00000002917C: 0202F57E
	s_waitcnt vmcnt(11)                                        // 000000029180: BF892FF7
	v_lshlrev_b32_e32 v126, 16, v195                           // 000000029184: 30FD8690
	s_delay_alu instid0(VALU_DEP_1)                            // 000000029188: BF870001
	v_mul_f32_e32 v128, 0xbfb8aa3b, v126                       // 00000002918C: 1100FCFF BFB8AA3B
	v_fmac_f32_e32 v123, 0xb2a5705f, v117                      // 000000029194: 56F6EAFF B2A5705F
	v_fma_f32 v116, -v116, v134, v131                          // 00000002919C: D6130074 260F0D74
	v_cndmask_b32_e32 v120, 0, v120, vcc_lo                    // 0000000291A4: 02F0F080
	s_mov_b32 vcc_lo, s0                                       // 0000000291A8: BEEA0000
	.long 0xd41e0001                                           // 0000000291AC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v117, vcc_lo             // 0000000291B0: 0202EAFF 42CE8ED0
	v_rndne_f32_e32 v131, v128                                 // 0000000291B8: 7F064780
	v_div_fmas_f32 v116, v116, v124, v134                      // 0000000291BC: D6370074 061AF974
	v_rndne_f32_e32 v124, v115                                 // 0000000291C4: 7EF84773
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v129                 // 0000000291C8: 7C3702FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000291D0: BF870193
	v_div_fixup_f32 v106, v116, v112, v106                     // 0000000291D4: D627006A 05AAE174
	v_sub_f32_e32 v115, v115, v124                             // 0000000291DC: 08E6F973
	v_cvt_i32_f32_e32 v124, v124                               // 0000000291E0: 7EF8117C
	v_rcp_f32_e32 v112, v121                                   // 0000000291E4: 7EE05579
	v_fma_f32 v130, 0xbfb8aa3b, v126, -v128                    // 0000000291E8: D6130082 8602FCFF BFB8AA3B
	.long 0x7e0039ea                                           // 0000000291F4: 7E0039EA
	v_dual_add_f32 v115, v115, v123 :: v_dual_cndmask_b32 v120, 0x7f800000, v120// 0000000291F8: C912F773 7378F0FF 7F800000
	v_sub_f32_e32 v128, v128, v131                             // 000000029204: 09010780
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000029208: BF870112
	v_exp_f32_e32 v115, v115                                   // 00000002920C: 7EE64B73
	v_add_f32_e32 v116, 1.0, v120                              // 000000029210: 06E8F0F2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000029214: BF870096
	v_fma_f32 v120, -v121, v112, 1.0                           // 000000029218: D6130078 23CAE179
	v_fmac_f32_e32 v112, v120, v112                            // 000000029220: 56E0E178
	v_div_scale_f32 v120, vcc_lo, v107, v119, v107             // 000000029224: D6FC6A78 05AEEF6B
	v_and_b32_e32 v118, 1, v118                                // 00000002922C: 36ECEC81
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000029230: BF870195
	.long 0xd71c0073                                           // 000000029234: D71C0073
	v_cndmask_b32_e32 v1, v115, v124, vcc_lo                   // 000000029238: 0202F973
	v_mul_f32_e32 v123, v120, v112                             // 00000002923C: 10F6E178
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000029240: BF870193
	v_add3_u32 v105, v105, v118, 0x7fff                        // 000000029244: D6550069 03FEED69 00007FFF
	v_cndmask_b32_e64 v115, 0, v115, s1                        // 000000029250: D5010073 0006E680
	.long 0xd41b0001                                           // 000000029258: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v117, vcc_lo             // 00000002925C: 0202EAFF C2B17218
	global_store_d16_hi_b16 v[7:8], v105, off offset:64        // 000000029264: DC960040 007C6907
	v_cndmask_b32_e64 v115, 0x7f800000, v115, s1               // 00000002926C: D5010073 0006E6FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000029278: BF870091
	v_dual_mul_f32 v108, v103, v108 :: v_dual_add_f32 v115, 1.0, v115// 00000002927C: C8C8D967 6C72E6F2
	v_div_scale_f32 v111, null, v116, v116, v108               // 000000029284: D6FC7C6F 05B2E974
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002928C: BF870291
	v_rcp_f32_e32 v122, v111                                   // 000000029290: 7EF4556F
	v_fma_f32 v129, -v111, v122, 1.0                           // 000000029294: D6130081 23CAF56F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002929C: BF870121
	v_dual_fmac_f32 v122, v129, v122 :: v_dual_and_b32 v125, 1, v0// 0000000292A0: C824F581 7A7C0081
	v_div_scale_f32 v129, s0, v108, v116, v108                 // 0000000292A8: D6FC0081 05B2E96C
	v_add3_u32 v106, v106, v125, 0x7fff                        // 0000000292B0: D655006A 03FEFB6A 00007FFF
	v_fma_f32 v125, -v121, v123, v120                          // 0000000292BC: D613007D 25E2F779
	v_fmac_f32_e32 v130, 0xb2a5705f, v126                      // 0000000292C4: 5704FCFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000000292CC: BF870144
	v_mul_f32_e32 v132, v129, v122                             // 0000000292D0: 1108F581
	global_store_d16_hi_b16 v[47:48], v106, off offset:64      // 0000000292D4: DC960040 007C6A2F
	v_dual_fmac_f32 v123, v125, v112 :: v_dual_add_f32 v128, v128, v130// 0000000292DC: C808E17D 7B810580
	v_fma_f32 v118, -v111, v132, v129                          // 0000000292E4: D6130076 2607096F
	v_fma_f32 v120, -v121, v123, v120                          // 0000000292EC: D6130078 25E2F779
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000292F4: BF870113
	v_exp_f32_e32 v124, v128                                   // 0000000292F8: 7EF84B80
	v_fmac_f32_e32 v132, v118, v122                            // 0000000292FC: 5708F576
	v_cvt_i32_f32_e32 v118, v131                               // 000000029300: 7EEC1183
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000029304: BF870123
	v_div_fmas_f32 v112, v120, v112, v123                      // 000000029308: D6370070 05EEE178
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v126                 // 000000029310: 7C3CFCFF 42CE8ED0
	v_div_fixup_f32 v107, v112, v119, v107                     // 000000029318: D627006B 05AEEF70
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 000000029320: BF870205
	.long 0xd71c0075                                           // 000000029324: D71C0075
	v_cndmask_b32_e32 v1, v124, v118, vcc_lo                   // 000000029328: 0202ED7C
	s_waitcnt vmcnt(5)                                         // 00000002932C: BF8917F7
	v_lshlrev_b32_e32 v124, 16, v197                           // 000000029330: 30F98A90
	v_div_scale_f32 v118, null, v115, v115, v109               // 000000029334: D6FC7C76 05B6E773
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002933C: BF870193
	v_cndmask_b32_e32 v117, 0, v117, vcc_lo                    // 000000029340: 02EAEA80
	v_mul_f32_e32 v125, 0xbfb8aa3b, v124                       // 000000029344: 10FAF8FF BFB8AA3B
	v_fma_f32 v111, -v111, v132, v129                          // 00000002934C: D613006F 2607096F
	s_mov_b32 vcc_lo, s0                                       // 000000029354: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000029358: BF870112
	v_rndne_f32_e32 v128, v125                                 // 00000002935C: 7F00477D
	v_div_fmas_f32 v111, v111, v122, v132                      // 000000029360: D637006F 0612F56F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v126                 // 000000029368: 7C36FCFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000029370: BF870122
	v_div_fixup_f32 v105, v111, v116, v108                     // 000000029374: D6270069 05B2E96F
	v_cndmask_b32_e32 v117, 0x7f800000, v117, vcc_lo           // 00000002937C: 02EAEAFF 7F800000
	.long 0x7e0039e9                                           // 000000029384: 7E0039E9
	s_delay_alu instid0(VALU_DEP_2)                            // 000000029388: BF870002
	v_add_f32_e32 v111, 1.0, v117                              // 00000002938C: 06DEEAF2
	.long 0x7eea39eb                                           // 000000029390: 7EEA39EB
	.long 0x7fea3980                                           // 000000029394: 7FEA3980
	v_mul_f32_e32 v108, v113, v110                             // 000000029398: 10D8DD71
	v_rcp_f32_e32 v110, v118                                   // 00000002939C: 7EDC5576
	v_and_b32_e32 v123, 1, v0                                  // 0000000293A0: 36F60081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000293A4: BF870193
	v_and_b32_e32 v117, 1, v117                                // 0000000293A8: 36EAEA81
	v_div_scale_f32 v106, null, v111, v111, v108               // 0000000293AC: D6FC7C6A 05B2DF6F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000293B4: BF870193
	v_add3_u32 v105, v105, v123, 0x7fff                        // 0000000293B8: D6550069 03FEF769 00007FFF
	v_add3_u32 v107, v107, v117, 0x7fff                        // 0000000293C4: D655006B 03FEEB6B 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000000293D0: BF870313
	v_rcp_f32_e32 v120, v106                                   // 0000000293D4: 7EF0556A
	v_fma_f32 v119, -v118, v110, 1.0                           // 0000000293D8: D6130077 23CADD76
	s_clause 0x1                                               // 0000000293E0: BF850001
	global_store_d16_hi_b16 v[15:16], v107, off offset:64      // 0000000293E4: DC960040 007C6B0F
	global_store_d16_hi_b16 v[23:24], v105, off offset:64      // 0000000293EC: DC960040 007C6917
	v_fmac_f32_e32 v110, v119, v110                            // 0000000293F4: 56DCDD77
	v_div_scale_f32 v119, vcc_lo, v109, v115, v109             // 0000000293F8: D6FC6A77 05B6E76D
	v_lshlrev_b32_e32 v116, 16, v127                           // 000000029400: 30E8FE90
	v_fma_f32 v127, 0xbfb8aa3b, v124, -v125                    // 000000029404: D613007F 85F6F8FF BFB8AA3B
	v_sub_f32_e32 v125, v125, v128                             // 000000029410: 08FB017D
	v_fma_f32 v126, -v106, v120, 1.0                           // 000000029414: D613007E 23CAF16A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002941C: BF8701A3
	v_fmac_f32_e32 v127, 0xb2a5705f, v124                      // 000000029420: 56FEF8FF B2A5705F
	v_mul_f32_e32 v112, 0xbfb8aa3b, v116                       // 000000029428: 10E0E8FF BFB8AA3B
	v_fmac_f32_e32 v120, v126, v120                            // 000000029430: 56F0F17E
	v_div_scale_f32 v126, s0, v108, v111, v108                 // 000000029434: D6FC007E 05B2DF6C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002943C: BF870214
	v_add_f32_e32 v125, v125, v127                             // 000000029440: 06FAFF7D
	v_fma_f32 v121, 0xbfb8aa3b, v116, -v112                    // 000000029444: D6130079 85C2E8FF BFB8AA3B
	v_rndne_f32_e32 v122, v112                                 // 000000029450: 7EF44770
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000029454: BF870114
	v_mul_f32_e32 v129, v126, v120                             // 000000029458: 1102F17E
	v_dual_fmac_f32 v121, 0xb2a5705f, v116 :: v_dual_sub_f32 v112, v112, v122// 00000002945C: C80AE8FF 7970F570 B2A5705F
	v_cvt_i32_f32_e32 v122, v122                               // 000000029468: 7EF4117A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002946C: BF870193
	v_fma_f32 v117, -v106, v129, v126                          // 000000029470: D6130075 25FB036A
	v_dual_add_f32 v112, v112, v121 :: v_dual_mul_f32 v121, v119, v110// 000000029478: C906F370 7078DD77
	.long 0xd41e0001                                           // 000000029480: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v116, vcc_lo             // 000000029484: 0202E8FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002948C: BF870223
	v_fmac_f32_e32 v129, v117, v120                            // 000000029490: 5702F175
	v_cvt_i32_f32_e32 v117, v128                               // 000000029494: 7EEA1180
	v_fma_f32 v123, -v118, v121, v119                          // 000000029498: D613007B 25DEF376
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000294A0: BF870113
	v_fma_f32 v106, -v106, v129, v126                          // 0000000294A4: D613006A 25FB036A
	v_fmac_f32_e32 v121, v123, v110                            // 0000000294AC: 56F2DD7B
	v_exp_f32_e32 v112, v112                                   // 0000000294B0: 7EE04B70
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000294B4: BF870091
	v_fma_f32 v118, -v118, v121, v119                          // 0000000294B8: D6130076 25DEF376
	v_div_fmas_f32 v110, v118, v110, v121                      // 0000000294C0: D637006E 05E6DD76
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000294C8: BF8701B5
	.long 0xd71c0070                                           // 0000000294CC: D71C0070
	v_cndmask_b32_e32 v1, v112, v122, vcc_lo                   // 0000000294D0: 0202F570
	v_exp_f32_e32 v122, v125                                   // 0000000294D4: 7EF44B7D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v124                 // 0000000294D8: 7C3CF8FF 42CE8ED0
	v_div_fixup_f32 v109, v110, v115, v109                     // 0000000294E0: D627006D 05B6E76E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000000294E8: BF870233
	v_cndmask_b32_e64 v112, 0, v112, s1                        // 0000000294EC: D5010070 0006E080
	.long 0xd41b0001                                           // 0000000294F4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v116, vcc_lo             // 0000000294F8: 0202E8FF C2B17218
	.long 0x7fe63980                                           // 000000029500: 7FE63980
	.long 0x7ee639ed                                           // 000000029504: 7EE639ED
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000029508: BF870215
	.long 0xd71c0074                                           // 00000002950C: D71C0074
	v_cndmask_b32_e32 v1, v122, v117, vcc_lo                   // 000000029510: 0202EB7A
	v_cndmask_b32_e64 v112, 0x7f800000, v112, s1               // 000000029514: D5010070 0006E0FF 7F800000
	v_lshlrev_b32_e32 v122, 16, v179                           // 000000029520: 30F56690
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000029524: BF8701A3
	v_dual_cndmask_b32 v116, 0, v116 :: v_dual_and_b32 v115, 1, v115// 000000029528: CA64E880 7472E681
	s_mov_b32 vcc_lo, s0                                       // 000000029530: BEEA0000
	v_add_f32_e32 v112, 1.0, v112                              // 000000029534: 06E0E0F2
	v_div_fmas_f32 v106, v106, v120, v129                      // 000000029538: D637006A 0606F16A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v124                 // 000000029540: 7C36F8FF C2B17218
	v_mul_f32_e32 v123, 0xbfb8aa3b, v122                       // 000000029548: 10F6F4FF BFB8AA3B
	v_add3_u32 v109, v109, v115, 0x7fff                        // 000000029550: D655006D 03FEE76D 00007FFF
	v_div_scale_f32 v117, null, v112, v112, v97                // 00000002955C: D6FC7C75 0586E170
	v_div_fixup_f32 v106, v106, v111, v108                     // 000000029564: D627006A 05B2DF6A
	v_lshlrev_b32_e32 v111, 16, v180                           // 00000002956C: 30DF6890
	v_fma_f32 v125, 0xbfb8aa3b, v122, -v123                    // 000000029570: D613007D 85EEF4FF BFB8AA3B
	v_rndne_f32_e32 v126, v123                                 // 00000002957C: 7EFC477B
	v_rcp_f32_e32 v107, v117                                   // 000000029580: 7ED65575
	.long 0x7e0039ea                                           // 000000029584: 7E0039EA
	v_mul_f32_e32 v110, 0xbfb8aa3b, v111                       // 000000029588: 10DCDEFF BFB8AA3B
	global_store_d16_hi_b16 v[31:32], v109, off offset:64      // 000000029590: DC960040 007C6D1F
	v_sub_f32_e32 v123, v123, v126                             // 000000029598: 08F6FD7B
	v_fmac_f32_e32 v125, 0xb2a5705f, v122                      // 00000002959C: 56FAF4FF B2A5705F
	v_and_b32_e32 v121, 1, v0                                  // 0000000295A4: 36F20081
	v_fma_f32 v119, 0xbfb8aa3b, v111, -v110                    // 0000000295A8: D6130077 85BADEFF BFB8AA3B
	v_rndne_f32_e32 v120, v110                                 // 0000000295B4: 7EF0476E
	v_lshlrev_b32_e32 v109, 16, v193                           // 0000000295B8: 30DB8290
	v_add_f32_e32 v123, v123, v125                             // 0000000295BC: 06F6FB7B
	v_add3_u32 v106, v106, v121, 0x7fff                        // 0000000295C0: D655006A 03FEF36A 00007FFF
	v_fmac_f32_e32 v119, 0xb2a5705f, v111                      // 0000000295CC: 56EEDEFF B2A5705F
	v_cndmask_b32_e32 v116, 0x7f800000, v116, vcc_lo           // 0000000295D4: 02E8E8FF 7F800000
	global_store_d16_hi_b16 v[39:40], v106, off offset:64      // 0000000295DC: DC960040 007C6A27
	v_add_f32_e32 v108, 1.0, v116                              // 0000000295E4: 06D8E8F2
	v_fma_f32 v116, -v117, v107, 1.0                           // 0000000295E8: D6130074 23CAD775
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000295F0: BF870112
	v_div_scale_f32 v105, null, v108, v108, v98                // 0000000295F4: D6FC7C69 058AD96C
	v_fmac_f32_e32 v107, v116, v107                            // 0000000295FC: 56D6D774
	v_div_scale_f32 v116, vcc_lo, v97, v112, v97               // 000000029600: D6FC6A74 0586E161
	v_sub_f32_e32 v110, v110, v120                             // 000000029608: 08DCF16E
	v_cvt_i32_f32_e32 v120, v120                               // 00000002960C: 7EF01178
	v_rcp_f32_e32 v118, v105                                   // 000000029610: 7EEC5569
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000029614: BF8701B2
	v_add_f32_e32 v110, v110, v119                             // 000000029618: 06DCEF6E
	v_mul_f32_e32 v119, v116, v107                             // 00000002961C: 10EED774
	.long 0xd41e0001                                           // 000000029620: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v111, vcc_lo             // 000000029624: 0202DEFF 42CE8ED0
	v_exp_f32_e32 v110, v110                                   // 00000002962C: 7EDC4B6E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000029630: BF870312
	v_fma_f32 v121, -v117, v119, v116                          // 000000029634: D6130079 25D2EF75
	v_fma_f32 v124, -v105, v118, 1.0                           // 00000002963C: D613007C 23CAED69
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000029644: BF8702A1
	v_fmac_f32_e32 v118, v124, v118                            // 000000029648: 56ECED7C
	v_div_scale_f32 v124, s0, v98, v108, v98                   // 00000002964C: D6FC007C 058AD962
	.long 0xd71c006e                                           // 000000029654: D71C006E
	v_cndmask_b32_e32 v1, v110, v120, vcc_lo                   // 000000029658: 0202F16E
	v_exp_f32_e32 v120, v123                                   // 00000002965C: 7EF04B7B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000029660: BF870112
	v_mul_f32_e32 v127, v124, v118                             // 000000029664: 10FEED7C
	v_cndmask_b32_e64 v110, 0, v110, s1                        // 000000029668: D501006E 0006DC80
	.long 0xd41b0001                                           // 000000029670: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v111, vcc_lo             // 000000029674: 0202DEFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002967C: BF870113
	v_fma_f32 v115, -v105, v127, v124                          // 000000029680: D6130073 25F2FF69
	v_cndmask_b32_e64 v110, 0x7f800000, v110, s1               // 000000029688: D501006E 0006DCFF 7F800000
	v_fmac_f32_e32 v119, v121, v107                            // 000000029694: 56EED779
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000029698: BF870253
	v_fmac_f32_e32 v127, v115, v118                            // 00000002969C: 56FEED73
	v_cvt_i32_f32_e32 v115, v126                               // 0000000296A0: 7EE6117E
	.long 0xd41e0001                                           // 0000000296A4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v109, vcc_lo             // 0000000296A8: 0202DAFF 42CE8ED0
	v_add_f32_e32 v110, 1.0, v110                              // 0000000296B0: 06DCDCF2
	v_fma_f32 v116, -v117, v119, v116                          // 0000000296B4: D6130074 25D2EF75
	.long 0xd71c006f                                           // 0000000296BC: D71C006F
	v_cndmask_b32_e32 v1, v120, v115, vcc_lo                   // 0000000296C0: 0202E778
	v_lshlrev_b32_e32 v120, 16, v192                           // 0000000296C4: 30F18090
	v_fma_f32 v105, -v105, v127, v124                          // 0000000296C8: D6130069 25F2FF69
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000296D0: BF870224
	v_div_fmas_f32 v107, v116, v107, v119                      // 0000000296D4: D637006B 05DED774
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v122                 // 0000000296DC: 7C3CF4FF 42CE8ED0
	v_mul_f32_e32 v121, 0xbfb8aa3b, v120                       // 0000000296E4: 10F2F0FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000296EC: BF870003
	v_div_fixup_f32 v97, v107, v112, v97                       // 0000000296F0: D6270061 0586E16B
	v_cndmask_b32_e32 v111, 0, v111, vcc_lo                    // 0000000296F8: 02DEDE80
	s_mov_b32 vcc_lo, s0                                       // 0000000296FC: BEEA0000
	v_mul_f32_e32 v107, 0xbfb8aa3b, v109                       // 000000029700: 10D6DAFF BFB8AA3B
	v_div_fmas_f32 v105, v105, v118, v127                      // 000000029708: D6370069 05FEED69
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v122                 // 000000029710: 7C36F4FF C2B17218
	v_fma_f32 v123, 0xbfb8aa3b, v120, -v121                    // 000000029718: D613007B 85E6F0FF BFB8AA3B
	v_rndne_f32_e32 v124, v121                                 // 000000029724: 7EF84779
	v_fma_f32 v117, 0xbfb8aa3b, v109, -v107                    // 000000029728: D6130075 85AEDAFF BFB8AA3B
	v_div_fixup_f32 v98, v105, v108, v98                       // 000000029734: D6270062 058AD969
	v_cndmask_b32_e32 v111, 0x7f800000, v111, vcc_lo           // 00000002973C: 02DEDEFF 7F800000
	v_rndne_f32_e32 v118, v107                                 // 000000029744: 7EEC476B
	v_fmac_f32_e32 v123, 0xb2a5705f, v120                      // 000000029748: 56F6F0FF B2A5705F
	v_fmac_f32_e32 v117, 0xb2a5705f, v109                      // 000000029750: 56EADAFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000029758: BF870214
	v_dual_sub_f32 v121, v121, v124 :: v_dual_add_f32 v108, 1.0, v111// 00000002975C: C948F979 796CDEF2
	v_sub_f32_e32 v107, v107, v118                             // 000000029764: 08D6ED6B
	.long 0x7ede39e1                                           // 000000029768: 7EDE39E1
	.long 0x7fde3980                                           // 00000002976C: 7FDE3980
	v_cvt_i32_f32_e32 v118, v118                               // 000000029770: 7EEC1176
	v_div_scale_f32 v106, null, v108, v108, v100               // 000000029774: D6FC7C6A 0592D96C
	v_add_f32_e32 v107, v107, v117                             // 00000002977C: 06D6EB6B
	v_add_f32_e32 v121, v121, v123                             // 000000029780: 06F2F779
	v_and_b32_e32 v111, 1, v111                                // 000000029784: 36DEDE81
	.long 0x7e0039e2                                           // 000000029788: 7E0039E2
	v_rcp_f32_e32 v116, v106                                   // 00000002978C: 7EE8556A
	v_exp_f32_e32 v107, v107                                   // 000000029790: 7ED64B6B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000029794: BF870112
	v_add3_u32 v97, v97, v111, 0x7fff                          // 000000029798: D6550061 03FEDF61 00007FFF
	v_and_b32_e32 v119, 1, v0                                  // 0000000297A4: 36EE0081
	global_store_d16_hi_b16 v[7:8], v97, off offset:96         // 0000000297A8: DC960060 007C6107
	v_add3_u32 v98, v98, v119, 0x7fff                          // 0000000297B0: D6550062 03FEEF62 00007FFF
	v_fma_f32 v122, -v106, v116, 1.0                           // 0000000297BC: D613007A 23CAE96A
	v_mul_f32_e32 v99, v104, v99                               // 0000000297C4: 10C6C768
	.long 0xd71c006b                                           // 0000000297C8: D71C006B
	v_cndmask_b32_e32 v1, v107, v118, vcc_lo                   // 0000000297CC: 0202ED6B
	v_exp_f32_e32 v118, v121                                   // 0000000297D0: 7EEC4B79
	global_store_d16_hi_b16 v[47:48], v98, off offset:96       // 0000000297D4: DC960060 007C622F
	v_fmac_f32_e32 v116, v122, v116                            // 0000000297DC: 56E8E97A
	v_div_scale_f32 v115, null, v110, v110, v99                // 0000000297E0: D6FC7C73 058EDD6E
	v_div_scale_f32 v122, s0, v100, v108, v100                 // 0000000297E8: D6FC007A 0592D964
	v_cndmask_b32_e64 v107, 0, v107, s1                        // 0000000297F0: D501006B 0006D680
	.long 0xd41b0001                                           // 0000000297F8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v109, vcc_lo             // 0000000297FC: 0202DAFF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000029804: BF870194
	v_rcp_f32_e32 v105, v115                                   // 000000029808: 7ED25573
	v_mul_f32_e32 v125, v122, v116                             // 00000002980C: 10FAE97A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000029810: BF870112
	v_cndmask_b32_e64 v107, 0x7f800000, v107, s1               // 000000029814: D501006B 0006D6FF 7F800000
	v_fma_f32 v111, -v106, v125, v122                          // 000000029820: D613006F 25EAFB6A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000029828: BF870292
	v_add_f32_e32 v107, 1.0, v107                              // 00000002982C: 06D6D6F2
	v_fma_f32 v112, -v115, v105, 1.0                           // 000000029830: D6130070 23CAD373
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000029838: BF8701A3
	v_fmac_f32_e32 v125, v111, v116                            // 00000002983C: 56FAE96F
	v_cvt_i32_f32_e32 v111, v124                               // 000000029840: 7EDE117C
	v_fmac_f32_e32 v105, v112, v105                            // 000000029844: 56D2D370
	v_div_scale_f32 v112, vcc_lo, v99, v110, v99               // 000000029848: D6FC6A70 058EDD63
	s_delay_alu instid0(VALU_DEP_3)                            // 000000029850: BF870003
	.long 0xd71c006d                                           // 000000029854: D71C006D
	v_cndmask_b32_e32 v1, v118, v111, vcc_lo                   // 000000029858: 0202DF76
	s_waitcnt vmcnt(4)                                         // 00000002985C: BF8913F7
	v_lshlrev_b32_e32 v118, 16, v194                           // 000000029860: 30ED8490
	v_fma_f32 v106, -v106, v125, v122                          // 000000029864: D613006A 25EAFB6A
	v_div_scale_f32 v111, null, v107, v107, v101               // 00000002986C: D6FC7C6F 0596D76B
	v_mul_f32_e32 v117, v112, v105                             // 000000029874: 10EAD370
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000029878: BF870091
	v_fma_f32 v119, -v115, v117, v112                          // 00000002987C: D6130077 25C2EB73
	v_fmac_f32_e32 v117, v119, v105                            // 000000029884: 56EAD377
	v_mul_f32_e32 v119, 0xbfb8aa3b, v118                       // 000000029888: 10EEECFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000029890: BF870112
	v_fma_f32 v112, -v115, v117, v112                          // 000000029894: D6130070 25C2EB73
	v_fma_f32 v121, 0xbfb8aa3b, v118, -v119                    // 00000002989C: D6130079 85DEECFF BFB8AA3B
	v_rndne_f32_e32 v122, v119                                 // 0000000298A8: 7EF44777
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000298AC: BF870223
	v_div_fmas_f32 v105, v112, v105, v117                      // 0000000298B0: D6370069 05D6D370
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v120                 // 0000000298B8: 7C3CF0FF 42CE8ED0
	v_fmac_f32_e32 v121, 0xb2a5705f, v118                      // 0000000298C0: 56F2ECFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000298C8: BF870214
	v_sub_f32_e32 v119, v119, v122                             // 0000000298CC: 08EEF577
	v_div_fixup_f32 v99, v105, v110, v99                       // 0000000298D0: D6270063 058EDD69
	v_cndmask_b32_e32 v109, 0, v109, vcc_lo                    // 0000000298D8: 02DADA80
	s_mov_b32 vcc_lo, s0                                       // 0000000298DC: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000298E0: BF870133
	v_add_f32_e32 v119, v119, v121                             // 0000000298E4: 06EEF377
	v_div_fmas_f32 v106, v106, v116, v125                      // 0000000298E8: D637006A 05F6E96A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v120                 // 0000000298F0: 7C36F0FF C2B17218
	v_div_fixup_f32 v97, v106, v108, v100                      // 0000000298F8: D6270061 0592D96A
	v_dual_cndmask_b32 v109, 0x7f800000, v109 :: v_dual_mul_f32 v100, v113, v102// 000000029900: CA46DAFF 6D64CD71 7F800000
	v_lshlrev_b32_e32 v108, 16, v138                           // 00000002990C: 30D91490
	v_rcp_f32_e32 v102, v111                                   // 000000029910: 7ECC556F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000029914: BF870193
	.long 0x7e0039e1                                           // 000000029918: 7E0039E1
	v_add_f32_e32 v106, 1.0, v109                              // 00000002991C: 06D4DAF2
	.long 0x7eda39e3                                           // 000000029920: 7EDA39E3
	v_mul_f32_e32 v105, 0xbfb8aa3b, v108                       // 000000029924: 10D2D8FF BFB8AA3B
	.long 0x7fda3980                                           // 00000002992C: 7FDA3980
	v_and_b32_e32 v117, 1, v0                                  // 000000029930: 36EA0081
	v_div_scale_f32 v98, null, v106, v106, v100                // 000000029934: D6FC7C62 0592D56A
	.long 0xd41e0001                                           // 00000002993C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v108, vcc_lo             // 000000029940: 0202D8FF 42CE8ED0
	v_fma_f32 v115, 0xbfb8aa3b, v108, -v105                    // 000000029948: D6130073 85A6D8FF BFB8AA3B
	v_rndne_f32_e32 v116, v105                                 // 000000029954: 7EE84769
	v_fma_f32 v110, -v111, v102, 1.0                           // 000000029958: D613006E 23CACD6F
	v_rcp_f32_e32 v112, v98                                    // 000000029960: 7EE05562
	v_and_b32_e32 v109, 1, v109                                // 000000029964: 36DADA81
	v_fmac_f32_e32 v115, 0xb2a5705f, v108                      // 000000029968: 56E6D8FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000029970: BF870243
	v_dual_sub_f32 v105, v105, v116 :: v_dual_fmac_f32 v102, v110, v102// 000000029974: C940E969 6966CD6E
	v_div_scale_f32 v110, vcc_lo, v101, v107, v101             // 00000002997C: D6FC6A6E 0596D765
	v_add3_u32 v97, v97, v117, 0x7fff                          // 000000029984: D6550061 03FEEB61 00007FFF
	v_cvt_i32_f32_e32 v116, v116                               // 000000029990: 7EE81174
	v_add_f32_e32 v105, v105, v115                             // 000000029994: 06D2E769
	v_add3_u32 v99, v99, v109, 0x7fff                          // 000000029998: D6550063 03FEDB63 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000299A4: BF870225
	v_fma_f32 v120, -v98, v112, 1.0                            // 0000000299A8: D6130078 23CAE162
	v_mul_f32_e32 v115, v110, v102                             // 0000000299B0: 10E6CD6E
	v_exp_f32_e32 v105, v105                                   // 0000000299B4: 7ED24B69
	global_store_d16_hi_b16 v[15:16], v99, off offset:96       // 0000000299B8: DC960060 007C630F
	v_fmac_f32_e32 v112, v120, v112                            // 0000000299C0: 56E0E178
	v_div_scale_f32 v120, s0, v100, v106, v100                 // 0000000299C4: D6FC0078 0592D564
	v_fma_f32 v117, -v111, v115, v110                          // 0000000299CC: D6130075 25BAE76F
	global_store_d16_hi_b16 v[23:24], v97, off offset:96       // 0000000299D4: DC960060 007C6117
	v_mul_f32_e32 v123, v120, v112                             // 0000000299DC: 10F6E178
	v_fmac_f32_e32 v115, v117, v102                            // 0000000299E0: 56E6CD75
	.long 0xd71c0069                                           // 0000000299E4: D71C0069
	v_cndmask_b32_e32 v1, v105, v116, vcc_lo                   // 0000000299E8: 0202E969
	v_exp_f32_e32 v116, v119                                   // 0000000299EC: 7EE84B77
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000299F0: BF870193
	v_fma_f32 v109, -v98, v123, v120                           // 0000000299F4: D613006D 25E2F762
	v_fma_f32 v110, -v111, v115, v110                          // 0000000299FC: D613006E 25BAE76F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000029A04: BF870223
	v_cndmask_b32_e64 v105, 0, v105, s1                        // 000000029A08: D5010069 0006D280
	.long 0xd41b0001                                           // 000000029A10: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v108, vcc_lo             // 000000029A14: 0202D8FF C2B17218
	v_fmac_f32_e32 v123, v109, v112                            // 000000029A1C: 56F6E16D
	v_cvt_i32_f32_e32 v109, v122                               // 000000029A20: 7EDA117A
	v_div_fmas_f32 v102, v110, v102, v115                      // 000000029A24: D6370066 05CECD6E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v118                 // 000000029A2C: 7C3CECFF 42CE8ED0
	v_cndmask_b32_e64 v105, 0x7f800000, v105, s1               // 000000029A34: D5010069 0006D2FF 7F800000
	v_fma_f32 v98, -v98, v123, v120                            // 000000029A40: D6130062 25E2F762
	.long 0xd71c006c                                           // 000000029A48: D71C006C
	v_cndmask_b32_e32 v1, v116, v109, vcc_lo                   // 000000029A4C: 0202DB74
	v_div_fixup_f32 v101, v102, v107, v101                     // 000000029A50: D6270065 0596D766
	v_lshlrev_b32_e32 v116, 16, v177                           // 000000029A58: 30E96290
	v_add_f32_e32 v105, 1.0, v105                              // 000000029A5C: 06D2D2F2
	.long 0x7fd63980                                           // 000000029A60: 7FD63980
	v_cndmask_b32_e32 v108, 0, v108, vcc_lo                    // 000000029A64: 02D8D880
	s_mov_b32 vcc_lo, s0                                       // 000000029A68: BEEA0000
	v_mul_f32_e32 v117, 0xbfb8aa3b, v116                       // 000000029A6C: 10EAE8FF BFB8AA3B
	v_div_fmas_f32 v98, v98, v112, v123                        // 000000029A74: D6370062 05EEE162
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v118                 // 000000029A7C: 7C36ECFF C2B17218
	v_div_scale_f32 v109, null, v105, v105, v89                // 000000029A84: D6FC7C6D 0566D369
	.long 0x7ed639e5                                           // 000000029A8C: 7ED639E5
	v_fma_f32 v119, 0xbfb8aa3b, v116, -v117                    // 000000029A90: D6130077 85D6E8FF BFB8AA3B
	v_div_fixup_f32 v98, v98, v106, v100                       // 000000029A9C: D6270062 0592D562
	v_cndmask_b32_e32 v108, 0x7f800000, v108, vcc_lo           // 000000029AA4: 02D8D8FF 7F800000
	v_lshlrev_b32_e32 v106, 16, v178                           // 000000029AAC: 30D56490
	v_rcp_f32_e32 v99, v109                                    // 000000029AB0: 7EC6556D
	v_rndne_f32_e32 v120, v117                                 // 000000029AB4: 7EF04775
	.long 0x7e0039e2                                           // 000000029AB8: 7E0039E2
	v_add_f32_e32 v100, 1.0, v108                              // 000000029ABC: 06C8D8F2
	v_mul_f32_e32 v102, 0xbfb8aa3b, v106                       // 000000029AC0: 10CCD4FF BFB8AA3B
	v_fmac_f32_e32 v119, 0xb2a5705f, v116                      // 000000029AC8: 56EEE8FF B2A5705F
	v_sub_f32_e32 v117, v117, v120                             // 000000029AD0: 08EAF175
	v_and_b32_e32 v115, 1, v0                                  // 000000029AD4: 36E60081
	v_div_scale_f32 v97, null, v100, v100, v90                 // 000000029AD8: D6FC7C61 056AC964
	v_fma_f32 v111, 0xbfb8aa3b, v106, -v102                    // 000000029AE0: D613006F 859AD4FF BFB8AA3B
	v_rndne_f32_e32 v112, v102                                 // 000000029AEC: 7EE04766
	v_fma_f32 v108, -v109, v99, 1.0                            // 000000029AF0: D613006C 23CAC76D
	v_and_b32_e32 v107, 1, v107                                // 000000029AF8: 36D6D681
	v_rcp_f32_e32 v110, v97                                    // 000000029AFC: 7EDC5561
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000029B00: BF870193
	v_dual_fmac_f32 v111, 0xb2a5705f, v106 :: v_dual_sub_f32 v102, v102, v112// 000000029B04: C80AD4FF 6F66E166 B2A5705F
	v_fmac_f32_e32 v99, v108, v99                              // 000000029B10: 56C6C76C
	v_div_scale_f32 v108, vcc_lo, v89, v105, v89               // 000000029B14: D6FC6A6C 0566D359
	v_add3_u32 v98, v98, v115, 0x7fff                          // 000000029B1C: D6550062 03FEE762 00007FFF
	v_cvt_i32_f32_e32 v112, v112                               // 000000029B28: 7EE01170
	v_add_f32_e32 v102, v102, v111                             // 000000029B2C: 06CCDF66
	v_add_f32_e32 v117, v117, v119                             // 000000029B30: 06EAEF75
	v_mul_f32_e32 v111, v108, v99                              // 000000029B34: 10DEC76C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000029B38: BF870005
	v_fma_f32 v118, -v97, v110, 1.0                            // 000000029B3C: D6130076 23CADD61
	v_add3_u32 v101, v101, v107, 0x7fff                        // 000000029B44: D6550065 03FED765 00007FFF
	v_exp_f32_e32 v102, v102                                   // 000000029B50: 7ECC4B66
	.long 0xd41e0001                                           // 000000029B54: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v106, vcc_lo             // 000000029B58: 0202D4FF 42CE8ED0
	v_fma_f32 v115, -v109, v111, v108                          // 000000029B60: D6130073 25B2DF6D
	v_fmac_f32_e32 v110, v118, v110                            // 000000029B68: 56DCDD76
	v_div_scale_f32 v118, s0, v90, v100, v90                   // 000000029B6C: D6FC0076 056AC95A
	global_store_d16_hi_b16 v[31:32], v101, off offset:96      // 000000029B74: DC960060 007C651F
	v_lshlrev_b32_e32 v101, 16, v190                           // 000000029B7C: 30CB7C90
	v_fmac_f32_e32 v111, v115, v99                             // 000000029B80: 56DEC773
	global_store_d16_hi_b16 v[39:40], v98, off offset:96       // 000000029B84: DC960060 007C6227
	v_mul_f32_e32 v121, v118, v110                             // 000000029B8C: 10F2DD76
	.long 0xd71c0066                                           // 000000029B90: D71C0066
	v_cndmask_b32_e32 v1, v102, v112, vcc_lo                   // 000000029B94: 0202E166
	v_exp_f32_e32 v112, v117                                   // 000000029B98: 7EE04B75
	v_fma_f32 v108, -v109, v111, v108                          // 000000029B9C: D613006C 25B2DF6D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000029BA4: BF870193
	v_fma_f32 v107, -v97, v121, v118                           // 000000029BA8: D613006B 25DAF361
	v_cndmask_b32_e64 v102, 0, v102, s1                        // 000000029BB0: D5010066 0006CC80
	.long 0xd41b0001                                           // 000000029BB8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v106, vcc_lo             // 000000029BBC: 0202D4FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 000000029BC4: BF870004
	v_div_fmas_f32 v99, v108, v99, v111                        // 000000029BC8: D6370063 05BEC76C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v116                 // 000000029BD0: 7C3CE8FF 42CE8ED0
	v_fmac_f32_e32 v121, v107, v110                            // 000000029BD8: 56F2DD6B
	v_cvt_i32_f32_e32 v107, v120                               // 000000029BDC: 7ED61178
	v_cndmask_b32_e64 v102, 0x7f800000, v102, s1               // 000000029BE0: D5010066 0006CCFF 7F800000
	v_div_fixup_f32 v89, v99, v105, v89                        // 000000029BEC: D6270059 0566D363
	v_mul_f32_e32 v99, 0xbfb8aa3b, v101                        // 000000029BF4: 10C6CAFF BFB8AA3B
	v_fma_f32 v97, -v97, v121, v118                            // 000000029BFC: D6130061 25DAF361
	.long 0xd71c006a                                           // 000000029C04: D71C006A
	v_cndmask_b32_e32 v1, v112, v107, vcc_lo                   // 000000029C08: 0202D770
	v_add_f32_e32 v102, 1.0, v102                              // 000000029C0C: 06CCCCF2
	v_lshlrev_b32_e32 v112, 16, v189                           // 000000029C10: 30E17A90
	v_fma_f32 v109, 0xbfb8aa3b, v101, -v99                     // 000000029C14: D613006D 858ECAFF BFB8AA3B
	.long 0x7ed239d9                                           // 000000029C20: 7ED239D9
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000029C24: 02D4D480
	s_mov_b32 vcc_lo, s0                                       // 000000029C28: BEEA0000
	v_div_scale_f32 v107, null, v102, v102, v91                // 000000029C2C: D6FC7C6B 056ECD66
	v_div_fmas_f32 v97, v97, v110, v121                        // 000000029C34: D6370061 05E6DD61
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v116                 // 000000029C3C: 7C36E8FF C2B17218
	v_rndne_f32_e32 v110, v99                                  // 000000029C44: 7EDC4763
	v_fmac_f32_e32 v109, 0xb2a5705f, v101                      // 000000029C48: 56DACAFF B2A5705F
	v_mul_f32_e32 v115, 0xbfb8aa3b, v112                       // 000000029C50: 10E6E0FF BFB8AA3B
	v_div_fixup_f32 v90, v97, v100, v90                        // 000000029C58: D627005A 056AC961
	v_cndmask_b32_e32 v106, 0x7f800000, v106, vcc_lo           // 000000029C60: 02D4D4FF 7F800000
	v_rcp_f32_e32 v97, v107                                    // 000000029C68: 7EC2556B
	v_sub_f32_e32 v99, v99, v110                               // 000000029C6C: 08C6DD63
	v_fma_f32 v117, 0xbfb8aa3b, v112, -v115                    // 000000029C70: D6130075 85CEE0FF BFB8AA3B
	.long 0x7e0039da                                           // 000000029C7C: 7E0039DA
	v_add_f32_e32 v100, 1.0, v106                              // 000000029C80: 06C8D4F2
	v_rndne_f32_e32 v118, v115                                 // 000000029C84: 7EEC4773
	v_add_f32_e32 v99, v99, v109                               // 000000029C88: 06C6DB63
	.long 0x7fd23980                                           // 000000029C8C: 7FD23980
	v_and_b32_e32 v111, 1, v0                                  // 000000029C90: 36DE0081
	v_div_scale_f32 v98, null, v100, v100, v92                 // 000000029C94: D6FC7C62 0572C964
	v_fma_f32 v106, -v107, v97, 1.0                            // 000000029C9C: D613006A 23CAC36B
	v_exp_f32_e32 v99, v99                                     // 000000029CA4: 7EC64B63
	v_fmac_f32_e32 v117, 0xb2a5705f, v112                      // 000000029CA8: 56EAE0FF B2A5705F
	v_sub_f32_e32 v115, v115, v118                             // 000000029CB0: 08E6ED73
	v_rcp_f32_e32 v108, v98                                    // 000000029CB4: 7ED85562
	v_fmac_f32_e32 v97, v106, v97                              // 000000029CB8: 56C2C36A
	v_div_scale_f32 v106, vcc_lo, v91, v102, v91               // 000000029CBC: D6FC6A6A 056ECD5B
	v_and_b32_e32 v105, 1, v105                                // 000000029CC4: 36D2D281
	v_add3_u32 v90, v90, v111, 0x7fff                          // 000000029CC8: D655005A 03FEDF5A 00007FFF
	v_cvt_i32_f32_e32 v110, v110                               // 000000029CD4: 7EDC116E
	v_add_f32_e32 v115, v115, v117                             // 000000029CD8: 06E6EB73
	v_mul_f32_e32 v109, v106, v97                              // 000000029CDC: 10DAC36A
	v_add3_u32 v89, v89, v105, 0x7fff                          // 000000029CE0: D6550059 03FED359 00007FFF
	.long 0xd41e0001                                           // 000000029CEC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v101, vcc_lo             // 000000029CF0: 0202CAFF 42CE8ED0
	v_fma_f32 v116, -v98, v108, 1.0                            // 000000029CF8: D6130074 23CAD962
	.long 0xd71c0063                                           // 000000029D00: D71C0063
	v_cndmask_b32_e32 v1, v99, v110, vcc_lo                    // 000000029D04: 0202DD63
	v_fma_f32 v111, -v107, v109, v106                          // 000000029D08: D613006F 25AADB6B
	v_exp_f32_e32 v110, v115                                   // 000000029D10: 7EDC4B73
	global_store_d16_hi_b16 v[7:8], v89, off offset:128        // 000000029D14: DC960080 007C5907
	v_fmac_f32_e32 v108, v116, v108                            // 000000029D1C: 56D8D974
	v_div_scale_f32 v116, s0, v92, v100, v92                   // 000000029D20: D6FC0074 0572C95C
	v_fmac_f32_e32 v109, v111, v97                             // 000000029D28: 56DAC36F
	v_cndmask_b32_e64 v99, 0, v99, s1                          // 000000029D2C: D5010063 0006C680
	.long 0xd41b0001                                           // 000000029D34: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v101, vcc_lo             // 000000029D38: 0202CAFF C2B17218
	global_store_d16_hi_b16 v[47:48], v90, off offset:128      // 000000029D40: DC960080 007C5A2F
	v_mul_f32_e32 v119, v116, v108                             // 000000029D48: 10EED974
	v_fma_f32 v106, -v107, v109, v106                          // 000000029D4C: D613006A 25AADB6B
	v_lshlrev_b32_e32 v90, 16, v140                            // 000000029D54: 30B51890
	v_cndmask_b32_e64 v99, 0x7f800000, v99, s1                 // 000000029D58: D5010063 0006C6FF 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000029D64: BF870214
	v_fma_f32 v105, -v98, v119, v116                           // 000000029D68: D6130069 25D2EF62
	v_div_fmas_f32 v97, v106, v97, v109                        // 000000029D70: D6370061 05B6C36A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 000000029D78: 7C3CE0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000029D80: BF8701D4
	v_add_f32_e32 v99, 1.0, v99                                // 000000029D84: 06C6C6F2
	.long 0xd41e0001                                           // 000000029D88: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v90, vcc_lo              // 000000029D8C: 0202B4FF 42CE8ED0
	v_fmac_f32_e32 v119, v105, v108                            // 000000029D94: 56EED969
	v_cvt_i32_f32_e32 v105, v118                               // 000000029D98: 7ED21176
	v_div_fixup_f32 v91, v97, v102, v91                        // 000000029D9C: D627005B 056ECD61
	v_fma_f32 v98, -v98, v119, v116                            // 000000029DA4: D6130062 25D2EF62
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000029DAC: BF870123
	.long 0xd71c0065                                           // 000000029DB0: D71C0065
	v_cndmask_b32_e32 v1, v110, v105, vcc_lo                   // 000000029DB4: 0202D36E
	v_div_scale_f32 v105, null, v99, v99, v93                  // 000000029DB8: D6FC7C69 0576C763
	v_cndmask_b32_e32 v101, 0, v101, vcc_lo                    // 000000029DC0: 02CACA80
	s_mov_b32 vcc_lo, s0                                       // 000000029DC4: BEEA0000
	v_div_fmas_f32 v98, v98, v108, v119                        // 000000029DC8: D6370062 05DED962
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 000000029DD0: 7C36E0FF C2B17218
	s_waitcnt vmcnt(3)                                         // 000000029DD8: BF890FF7
	v_lshlrev_b32_e32 v108, 16, v191                           // 000000029DDC: 30D97E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000029DE0: BF8701B3
	v_div_fixup_f32 v89, v98, v100, v92                        // 000000029DE4: D6270059 0572C962
	v_dual_cndmask_b32 v101, 0x7f800000, v101 :: v_dual_mul_f32 v92, v113, v94// 000000029DEC: CA46CAFF 655CBD71 7F800000
	v_rcp_f32_e32 v94, v105                                    // 000000029DF8: 7EBC5569
	v_mul_f32_e32 v111, 0xbfb8aa3b, v108                       // 000000029DFC: 10DED8FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000029E04: BF870193
	.long 0x7e0039d9                                           // 000000029E08: 7E0039D9
	v_dual_add_f32 v98, 1.0, v101 :: v_dual_mul_f32 v101, 0xbfb8aa3b, v90// 000000029E0C: C906CAF2 6264B4FF BFB8AA3B
	.long 0x7ec839db                                           // 000000029E18: 7EC839DB
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000029E1C: BF870224
	v_fma_f32 v116, 0xbfb8aa3b, v108, -v111                    // 000000029E20: D6130074 85BED8FF BFB8AA3B
	v_rndne_f32_e32 v117, v111                                 // 000000029E2C: 7EEA476F
	v_div_scale_f32 v97, null, v98, v98, v92                   // 000000029E30: D6FC7C61 0572C562
	v_fma_f32 v109, 0xbfb8aa3b, v90, -v101                     // 000000029E38: D613006D 8596B4FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000029E44: BF870005
	v_fma_f32 v102, -v105, v94, 1.0                            // 000000029E48: D6130066 23CABD69
	v_rndne_f32_e32 v110, v101                                 // 000000029E50: 7EDC4765
	v_fmac_f32_e32 v116, 0xb2a5705f, v108                      // 000000029E54: 56E8D8FF B2A5705F
	v_rcp_f32_e32 v106, v97                                    // 000000029E5C: 7ED45561
	v_fmac_f32_e32 v109, 0xb2a5705f, v90                       // 000000029E60: 56DAB4FF B2A5705F
	v_fmac_f32_e32 v94, v102, v94                              // 000000029E68: 56BCBD66
	v_div_scale_f32 v102, vcc_lo, v93, v99, v93                // 000000029E6C: D6FC6A66 0576C75D
	v_sub_f32_e32 v101, v101, v110                             // 000000029E74: 08CADD65
	v_sub_f32_e32 v111, v111, v117                             // 000000029E78: 08DEEB6F
	v_and_b32_e32 v107, 1, v0                                  // 000000029E7C: 36D60081
	v_cvt_i32_f32_e32 v110, v110                               // 000000029E80: 7EDC116E
	v_mul_f32_e32 v115, v102, v94                              // 000000029E84: 10E6BD66
	v_add_f32_e32 v101, v101, v109                             // 000000029E88: 06CADB65
	v_fma_f32 v112, -v97, v106, 1.0                            // 000000029E8C: D6130070 23CAD561
	v_div_scale_f32 v109, s0, v92, v98, v92                    // 000000029E94: D6FC006D 0572C55C
	v_add_f32_e32 v111, v111, v116                             // 000000029E9C: 06DEE96F
	v_add3_u32 v89, v89, v107, 0x7fff                          // 000000029EA0: D6550059 03FED759 00007FFF
	v_exp_f32_e32 v101, v101                                   // 000000029EAC: 7ECA4B65
	v_fmac_f32_e32 v106, v112, v106                            // 000000029EB0: 56D4D570
	v_fma_f32 v112, -v105, v115, v102                          // 000000029EB4: D6130070 259AE769
	v_exp_f32_e32 v107, v111                                   // 000000029EBC: 7ED64B6F
	.long 0x7fc83980                                           // 000000029EC0: 7FC83980
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000029EC4: BF870113
	v_mul_f32_e32 v118, v109, v106                             // 000000029EC8: 10ECD56D
	v_dual_fmac_f32 v115, v112, v94 :: v_dual_and_b32 v100, 1, v100// 000000029ECC: C824BD70 7364C881
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000029ED4: BF870196
	.long 0xd71c0065                                           // 000000029ED8: D71C0065
	v_cndmask_b32_e32 v1, v101, v110, vcc_lo                   // 000000029EDC: 0202DD65
	v_fma_f32 v112, -v97, v118, v109                           // 000000029EE0: D6130070 25B6ED61
	s_delay_alu instid0(VALU_DEP_3)                            // 000000029EE8: BF870003
	v_fma_f32 v102, -v105, v115, v102                          // 000000029EEC: D6130066 259AE769
	v_cvt_i32_f32_e32 v105, v117                               // 000000029EF4: 7ED21175
	v_add3_u32 v91, v91, v100, 0x7fff                          // 000000029EF8: D655005B 03FEC95B 00007FFF
	v_cndmask_b32_e64 v101, 0, v101, s1                        // 000000029F04: D5010065 0006CA80
	v_fmac_f32_e32 v118, v112, v106                            // 000000029F0C: 56ECD570
	v_div_fmas_f32 v94, v102, v94, v115                        // 000000029F10: D637005E 05CEBD66
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v90                  // 000000029F18: 7C36B4FF C2B17218
	.long 0xd71c0066                                           // 000000029F20: D71C0066
	v_cndmask_b32_e32 v1, v107, v105, vcc_lo                   // 000000029F24: 0202D36B
	global_store_d16_hi_b16 v[15:16], v91, off offset:128      // 000000029F28: DC960080 007C5B0F
	v_fma_f32 v97, -v97, v118, v109                            // 000000029F30: D6130061 25B6ED61
	v_div_fixup_f32 v91, v94, v99, v93                         // 000000029F38: D627005B 0576C75E
	v_cndmask_b32_e32 v90, 0x7f800000, v101, vcc_lo            // 000000029F40: 02B4CAFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v108                 // 000000029F48: 7C3CD8FF 42CE8ED0
	v_lshlrev_b32_e32 v99, 16, v176                            // 000000029F50: 30C76090
	global_store_d16_hi_b16 v[23:24], v89, off offset:128      // 000000029F54: DC960080 007C5917
	.long 0x7ec839db                                           // 000000029F5C: 7EC839DB
	v_add_f32_e32 v90, 1.0, v90                                // 000000029F60: 06B4B4F2
	v_cndmask_b32_e32 v101, 0, v102, vcc_lo                    // 000000029F64: 02CACC80
	s_mov_b32 vcc_lo, s0                                       // 000000029F68: BEEA0000
	v_mul_f32_e32 v105, 0xbfb8aa3b, v99                        // 000000029F6C: 10D2C6FF BFB8AA3B
	v_div_fmas_f32 v97, v97, v106, v118                        // 000000029F74: D6370061 05DAD561
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v108                 // 000000029F7C: 7C36D8FF C2B17218
	.long 0x7fc83980                                           // 000000029F84: 7FC83980
	v_lshlrev_b32_e32 v108, 16, v175                           // 000000029F88: 30D95E90
	v_rndne_f32_e32 v106, v105                                 // 000000029F8C: 7ED44769
	v_div_fixup_f32 v92, v97, v98, v92                         // 000000029F90: D627005C 0572C561
	v_cndmask_b32_e32 v101, 0x7f800000, v101, vcc_lo           // 000000029F98: 02CACAFF 7F800000
	v_div_scale_f32 v97, null, v90, v90, v81                   // 000000029FA0: D6FC7C61 0546B55A
	v_and_b32_e32 v100, 1, v100                                // 000000029FA8: 36C8C881
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000029FAC: BF870214
	.long 0x7e0039dc                                           // 000000029FB0: 7E0039DC
	v_add_f32_e32 v98, 1.0, v101                               // 000000029FB4: 06C4CAF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000029FB8: BF870194
	v_rcp_f32_e32 v93, v97                                     // 000000029FBC: 7EBA5561
	v_add3_u32 v91, v91, v100, 0x7fff                          // 000000029FC0: D655005B 03FEC95B 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000029FCC: BF870193
	v_and_b32_e32 v101, 1, v0                                  // 000000029FD0: 36CA0081
	v_div_scale_f32 v94, null, v98, v98, v82                   // 000000029FD4: D6FC7C5E 054AC562
	global_store_d16_hi_b16 v[31:32], v91, off offset:128      // 000000029FDC: DC960080 007C5B1F
	v_add3_u32 v92, v92, v101, 0x7fff                          // 000000029FE4: D655005C 03FECB5C 00007FFF
	v_rcp_f32_e32 v102, v94                                    // 000000029FF0: 7ECC555E
	v_fma_f32 v89, -v97, v93, 1.0                              // 000000029FF4: D6130059 23CABB61
	v_fma_f32 v101, 0xbfb8aa3b, v99, -v105                     // 000000029FFC: D6130065 85A6C6FF BFB8AA3B
	v_sub_f32_e32 v105, v105, v106                             // 00000002A008: 08D2D569
	v_cvt_i32_f32_e32 v106, v106                               // 00000002A00C: 7ED4116A
	global_store_d16_hi_b16 v[39:40], v92, off offset:128      // 00000002A010: DC960080 007C5C27
	v_fmac_f32_e32 v93, v89, v93                               // 00000002A018: 56BABB59
	v_div_scale_f32 v89, vcc_lo, v81, v90, v81                 // 00000002A01C: D6FC6A59 0546B551
	v_fmac_f32_e32 v101, 0xb2a5705f, v99                       // 00000002A024: 56CAC6FF B2A5705F
	v_fma_f32 v107, -v94, v102, 1.0                            // 00000002A02C: D613006B 23CACD5E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002A034: BF870193
	v_mul_f32_e32 v109, v89, v93                               // 00000002A038: 10DABB59
	v_add_f32_e32 v101, v105, v101                             // 00000002A03C: 06CACB69
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002A040: BF870223
	v_dual_mul_f32 v105, 0xbfb8aa3b, v108 :: v_dual_fmac_f32 v102, v107, v102// 00000002A044: C8C0D8FF 6966CD6B BFB8AA3B
	v_div_scale_f32 v107, s0, v82, v98, v82                    // 00000002A050: D6FC006B 054AC552
	v_fma_f32 v100, -v97, v109, v89                            // 00000002A058: D6130064 2566DB61
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002A060: BF870194
	v_exp_f32_e32 v101, v101                                   // 00000002A064: 7ECA4B65
	v_fma_f32 v111, 0xbfb8aa3b, v108, -v105                    // 00000002A068: D613006F 85A6D8FF BFB8AA3B
	v_rndne_f32_e32 v112, v105                                 // 00000002A074: 7EE04769
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002A078: BF870193
	v_dual_mul_f32 v110, v107, v102 :: v_dual_fmac_f32 v109, v100, v93// 00000002A07C: C8C0CD6B 6E6CBB64
	v_fmac_f32_e32 v111, 0xb2a5705f, v108                      // 00000002A084: 56DED8FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002A08C: BF870193
	v_sub_f32_e32 v105, v105, v112                             // 00000002A090: 08D2E169
	v_fma_f32 v100, -v94, v110, v107                           // 00000002A094: D6130064 25AEDD5E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002A09C: BF870294
	v_fma_f32 v89, -v97, v109, v89                             // 00000002A0A0: D6130059 2566DB61
	.long 0xd71c005b                                           // 00000002A0A8: D71C005B
	v_cndmask_b32_e32 v1, v101, v106, vcc_lo                   // 00000002A0AC: 0202D565
	v_cvt_i32_f32_e32 v92, v112                                // 00000002A0B0: 7EB81170
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002A0B4: BF870214
	v_dual_add_f32 v97, v105, v111 :: v_dual_fmac_f32 v110, v100, v102// 00000002A0B8: C900DF69 616ECD64
	v_div_fmas_f32 v89, v89, v93, v109                         // 00000002A0C0: D6370059 05B6BB59
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v99                  // 00000002A0C8: 7C3CC6FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002A0D0: BF870213
	v_fma_f32 v93, -v94, v110, v107                            // 00000002A0D4: D613005D 25AEDD5E
	v_exp_f32_e32 v94, v97                                     // 00000002A0DC: 7EBC4B61
	v_cndmask_b32_e32 v91, 0, v91, vcc_lo                      // 00000002A0E0: 02B6B680
	s_mov_b32 vcc_lo, s0                                       // 00000002A0E4: BEEA0000
	v_div_fixup_f32 v81, v89, v90, v81                         // 00000002A0E8: D6270051 0546B559
	v_div_fmas_f32 v93, v93, v102, v110                        // 00000002A0F0: D637005D 05BACD5D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v99                  // 00000002A0F8: 7C36C6FF C2B17218
	v_lshlrev_b32_e32 v102, 16, v186                           // 00000002A100: 30CD7490
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000002A104: BF8702A3
	v_div_fixup_f32 v82, v93, v98, v82                         // 00000002A108: D6270052 054AC55D
	v_cndmask_b32_e32 v91, 0x7f800000, v91, vcc_lo             // 00000002A110: 02B6B6FF 7F800000
	.long 0xd71c0059                                           // 00000002A118: D71C0059
	v_cndmask_b32_e32 v1, v94, v92, vcc_lo                     // 00000002A11C: 0202B95E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v108                 // 00000002A120: 7C3CD8FF 42CE8ED0
	v_lshlrev_b32_e32 v93, 16, v187                            // 00000002A128: 30BB7690
	.long 0x7e0039d2                                           // 00000002A12C: 7E0039D2
	v_add_f32_e32 v90, 1.0, v91                                // 00000002A130: 06B4B6F2
	.long 0x7eb639d1                                           // 00000002A134: 7EB639D1
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000002A138: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v108                 // 00000002A13C: 7C36D8FF C2B17218
	v_mul_f32_e32 v97, 0xbfb8aa3b, v93                         // 00000002A144: 10C2BAFF BFB8AA3B
	v_div_scale_f32 v92, null, v90, v90, v83                   // 00000002A14C: D6FC7C5C 054EB55A
	.long 0x7fb63980                                           // 00000002A154: 7FB63980
	v_dual_cndmask_b32 v89, 0x7f800000, v89 :: v_dual_and_b32 v98, 1, v0// 00000002A158: CA64B2FF 59620081 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002A164: BF870214
	v_fma_f32 v99, 0xbfb8aa3b, v93, -v97                       // 00000002A168: D6130063 8586BAFF BFB8AA3B
	v_rcp_f32_e32 v94, v92                                     // 00000002A174: 7EBC555C
	v_rndne_f32_e32 v100, v97                                  // 00000002A178: 7EC84761
	v_and_b32_e32 v91, 1, v91                                  // 00000002A17C: 36B6B681
	v_add_f32_e32 v89, 1.0, v89                                // 00000002A180: 06B2B2F2
	v_fmac_f32_e32 v99, 0xb2a5705f, v93                        // 00000002A184: 56C6BAFF B2A5705F
	v_mul_f32_e32 v107, 0xbfb8aa3b, v102                       // 00000002A18C: 10D6CCFF BFB8AA3B
	v_sub_f32_e32 v97, v97, v100                               // 00000002A194: 08C2C961
	v_add3_u32 v82, v82, v98, 0x7fff                           // 00000002A198: D6550052 03FEC552 00007FFF
	v_div_scale_f32 v101, null, v89, v89, v84                  // 00000002A1A4: D6FC7C65 0552B359
	v_add3_u32 v81, v81, v91, 0x7fff                           // 00000002A1AC: D6550051 03FEB751 00007FFF
	v_fma_f32 v105, -v92, v94, 1.0                             // 00000002A1B8: D6130069 23CABD5C
	v_add_f32_e32 v91, v97, v99                                // 00000002A1C0: 06B6C761
	v_fma_f32 v97, 0xbfb8aa3b, v102, -v107                     // 00000002A1C4: D6130061 85AECCFF BFB8AA3B
	v_rndne_f32_e32 v98, v107                                  // 00000002A1D0: 7EC4476B
	v_rcp_f32_e32 v106, v101                                   // 00000002A1D4: 7ED45565
	v_fmac_f32_e32 v94, v105, v94                              // 00000002A1D8: 56BCBD69
	v_div_scale_f32 v99, vcc_lo, v83, v90, v83                 // 00000002A1DC: D6FC6A63 054EB553
	v_exp_f32_e32 v91, v91                                     // 00000002A1E4: 7EB64B5B
	v_fmac_f32_e32 v97, 0xb2a5705f, v102                       // 00000002A1E8: 56C2CCFF B2A5705F
	v_sub_f32_e32 v107, v107, v98                              // 00000002A1F0: 08D6C56B
	v_cvt_i32_f32_e32 v100, v100                               // 00000002A1F4: 7EC81164
	v_mul_f32_e32 v108, v99, v94                               // 00000002A1F8: 10D8BD63
	global_store_d16_hi_b16 v[7:8], v81, off offset:160        // 00000002A1FC: DC9600A0 007C5107
	.long 0xd41e0001                                           // 00000002A204: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v93, vcc_lo              // 00000002A208: 0202BAFF 42CE8ED0
	v_add_f32_e32 v97, v107, v97                               // 00000002A210: 06C2C36B
	v_fma_f32 v105, -v101, v106, 1.0                           // 00000002A214: D6130069 23CAD565
	global_store_d16_hi_b16 v[47:48], v82, off offset:160      // 00000002A21C: DC9600A0 007C522F
	.long 0xd71c0051                                           // 00000002A224: D71C0051
	v_cndmask_b32_e32 v1, v91, v100, vcc_lo                    // 00000002A228: 0202C95B
	v_fma_f32 v91, -v92, v108, v99                             // 00000002A22C: D613005B 258ED95C
	v_exp_f32_e32 v97, v97                                     // 00000002A234: 7EC24B61
	v_fmac_f32_e32 v106, v105, v106                            // 00000002A238: 56D4D569
	v_div_scale_f32 v105, s0, v84, v89, v84                    // 00000002A23C: D6FC0069 0552B354
	v_cndmask_b32_e64 v81, 0, v81, s1                          // 00000002A244: D5010051 0006A280
	v_fmac_f32_e32 v108, v91, v94                              // 00000002A24C: 56D8BD5B
	v_cvt_i32_f32_e32 v91, v98                                 // 00000002A250: 7EB61162
	.long 0xd41b0001                                           // 00000002A254: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v93, vcc_lo              // 00000002A258: 0202BAFF C2B17218
	v_mul_f32_e32 v100, v105, v106                             // 00000002A260: 10C8D569
	v_mul_f32_e32 v82, v113, v86                               // 00000002A264: 10A4AD71
	v_fma_f32 v92, -v92, v108, v99                             // 00000002A268: D613005C 258ED95C
	.long 0xd71c005b                                           // 00000002A270: D71C005B
	v_cndmask_b32_e32 v1, v97, v91, vcc_lo                     // 00000002A274: 0202B761
	v_cndmask_b32_e64 v81, 0x7f800000, v81, s1                 // 00000002A278: D5010051 0006A2FF 7F800000
	.long 0xd41e0001                                           // 00000002A284: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v102, vcc_lo             // 00000002A288: 0202CCFF 42CE8ED0
	v_fma_f32 v93, -v101, v100, v105                           // 00000002A290: D613005D 25A6C965
	v_div_fmas_f32 v92, v92, v94, v108                         // 00000002A298: D637005C 05B2BD5C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 00000002A2A0: 7C36CCFF C2B17218
	v_add_f32_e32 v81, 1.0, v81                                // 00000002A2A8: 06A2A2F2
	v_cndmask_b32_e64 v91, 0, v91, s1                          // 00000002A2AC: D501005B 0006B680
	v_fmac_f32_e32 v100, v93, v106                             // 00000002A2B4: 56C8D55D
	v_div_fixup_f32 v83, v92, v90, v83                         // 00000002A2B8: D6270053 054EB55C
	s_waitcnt vmcnt(2)                                         // 00000002A2C0: BF890BF7
	v_lshlrev_b32_e32 v102, 16, v188                           // 00000002A2C4: 30CD7890
	v_div_scale_f32 v97, null, v81, v81, v85                   // 00000002A2C8: D6FC7C61 0556A351
	v_cndmask_b32_e32 v91, 0x7f800000, v91, vcc_lo             // 00000002A2D0: 02B6B6FF 7F800000
	v_fma_f32 v94, -v101, v100, v105                           // 00000002A2D8: D613005E 25A6C965
	s_mov_b32 vcc_lo, s0                                       // 00000002A2E0: BEEA0000
	global_load_u16 v93, v[95:96], off offset:224              // 00000002A2E4: DC4A00E0 5D7C005F
	v_rcp_f32_e32 v98, v97                                     // 00000002A2EC: 7EC45561
	v_add_f32_e32 v86, 1.0, v91                                // 00000002A2F0: 06ACB6F2
	v_lshlrev_b32_e32 v91, 16, v147                            // 00000002A2F4: 30B72690
	v_div_fmas_f32 v94, v94, v106, v100                        // 00000002A2F8: D637005E 0592D55E
	v_div_scale_f32 v101, vcc_lo, v85, v81, v85                // 00000002A300: D6FC6A65 0556A355
	v_mul_f32_e32 v106, 0xbfb8aa3b, v102                       // 00000002A308: 10D4CCFF BFB8AA3B
	v_div_scale_f32 v90, null, v86, v86, v82                   // 00000002A310: D6FC7C5A 054AAD56
	v_mul_f32_e32 v92, 0xbfb8aa3b, v91                         // 00000002A318: 10B8B6FF BFB8AA3B
	v_div_fixup_f32 v84, v94, v89, v84                         // 00000002A320: D6270054 0552B35E
	.long 0x7ebc39d3                                           // 00000002A328: 7EBC39D3
	v_fma_f32 v89, -v97, v98, 1.0                              // 00000002A32C: D6130059 23CAC561
	v_fma_f32 v110, 0xbfb8aa3b, v102, -v106                    // 00000002A334: D613006E 85AACCFF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v91, -v92                       // 00000002A340: D6130063 8572B6FF BFB8AA3B
	v_rndne_f32_e32 v100, v92                                  // 00000002A34C: 7EC8475C
	v_rndne_f32_e32 v111, v106                                 // 00000002A350: 7EDE476A
	v_fmac_f32_e32 v98, v89, v98                               // 00000002A354: 56C4C559
	v_rcp_f32_e32 v89, v90                                     // 00000002A358: 7EB2555A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002A35C: BF8701A3
	v_dual_fmac_f32 v99, 0xb2a5705f, v91 :: v_dual_sub_f32 v92, v92, v100// 00000002A360: C80AB6FF 635CC95C B2A5705F
	.long 0x7fbc3980                                           // 00000002A36C: 7FBC3980
	v_mul_f32_e32 v105, v101, v98                              // 00000002A370: 10D2C565
	v_fmac_f32_e32 v110, 0xb2a5705f, v102                      // 00000002A374: 56DCCCFF B2A5705F
	v_sub_f32_e32 v106, v106, v111                             // 00000002A37C: 08D4DF6A
	v_add_f32_e32 v92, v92, v99                                // 00000002A380: 06B8C75C
	v_and_b32_e32 v94, 1, v94                                  // 00000002A384: 36BCBC81
	v_fma_f32 v99, -v97, v105, v101                            // 00000002A388: D6130063 2596D361
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000002A390: BF870005
	v_fma_f32 v109, -v90, v89, 1.0                             // 00000002A394: D613006D 23CAB35A
	v_cvt_i32_f32_e32 v100, v100                               // 00000002A39C: 7EC81164
	v_exp_f32_e32 v92, v92                                     // 00000002A3A0: 7EB84B5C
	v_add_f32_e32 v106, v106, v110                             // 00000002A3A4: 06D4DD6A
	v_fmac_f32_e32 v105, v99, v98                              // 00000002A3A8: 56D2C563
	v_fmac_f32_e32 v89, v109, v89                              // 00000002A3AC: 56B2B36D
	v_div_scale_f32 v109, s0, v82, v86, v82                    // 00000002A3B0: D6FC006D 054AAD52
	v_add3_u32 v83, v83, v94, 0x7fff                           // 00000002A3B8: D6550053 03FEBD53 00007FFF
	.long 0xd41e0001                                           // 00000002A3C4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v91, vcc_lo              // 00000002A3C8: 0202B6FF 42CE8ED0
	v_fma_f32 v94, -v97, v105, v101                            // 00000002A3D0: D613005E 2596D361
	v_cvt_i32_f32_e32 v101, v111                               // 00000002A3D8: 7ECA116F
	v_mul_f32_e32 v99, v109, v89                               // 00000002A3DC: 10C6B36D
	.long 0xd71c005c                                           // 00000002A3E0: D71C005C
	v_cndmask_b32_e32 v1, v92, v100, vcc_lo                    // 00000002A3E4: 0202C95C
	v_exp_f32_e32 v100, v106                                   // 00000002A3E8: 7EC84B6A
	v_div_fmas_f32 v94, v94, v98, v105                         // 00000002A3EC: D637005E 05A6C55E
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v91                  // 00000002A3F4: 7C36B6FF C2B17218
	v_fma_f32 v97, -v90, v99, v109                             // 00000002A3FC: D6130061 25B6C75A
	v_cndmask_b32_e64 v92, 0, v92, s1                          // 00000002A404: D501005C 0006B880
	global_load_u16 v98, v[79:80], off offset:224              // 00000002A40C: DC4A00E0 627C004F
	.long 0x7e0039d4                                           // 00000002A414: 7E0039D4
	v_div_fixup_f32 v81, v94, v81, v85                         // 00000002A418: D6270051 0556A35E
	v_fmac_f32_e32 v99, v97, v89                               // 00000002A420: 56C6B361
	global_load_u16 v97, v[87:88], off offset:224              // 00000002A424: DC4A00E0 617C0057
	v_cndmask_b32_e32 v91, 0x7f800000, v92, vcc_lo             // 00000002A42C: 02B6B8FF 7F800000
	.long 0xd71c005c                                           // 00000002A434: D71C005C
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                   // 00000002A438: 0202CB64
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 00000002A43C: 7C3CCCFF 42CE8ED0
	v_fma_f32 v90, -v90, v99, v109                             // 00000002A444: D613005A 25B6C75A
	v_lshlrev_b32_e32 v85, 16, v154                            // 00000002A44C: 30AB3490
	v_dual_add_f32 v91, 1.0, v91 :: v_dual_and_b32 v108, 1, v0 // 00000002A450: C924B6F2 5B6C0081
	v_cndmask_b32_e32 v92, 0, v92, vcc_lo                      // 00000002A458: 02B8B880
	s_mov_b32 vcc_lo, s0                                       // 00000002A45C: BEEA0000
	global_store_d16_hi_b16 v[15:16], v83, off offset:160      // 00000002A460: DC9600A0 007C530F
	v_div_fmas_f32 v89, v90, v89, v99                          // 00000002A468: D6370059 058EB35A
	v_div_scale_f32 v90, null, v91, v91, v73                   // 00000002A470: D6FC7C5A 0526B75B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 00000002A478: 7C36CCFF C2B17218
	v_mul_f32_e32 v100, 0xbfb8aa3b, v85                        // 00000002A480: 10C8AAFF BFB8AA3B
	v_add3_u32 v84, v84, v108, 0x7fff                          // 00000002A488: D6550054 03FED954 00007FFF
	v_div_fixup_f32 v82, v89, v86, v82                         // 00000002A494: D6270052 054AAD59
	v_rcp_f32_e32 v86, v90                                     // 00000002A49C: 7EAC555A
	v_cndmask_b32_e32 v92, 0x7f800000, v92, vcc_lo             // 00000002A4A0: 02B8B8FF 7F800000
	v_rndne_f32_e32 v101, v100                                 // 00000002A4A8: 7ECA4764
	global_store_d16_hi_b16 v[23:24], v84, off offset:160      // 00000002A4AC: DC9600A0 007C5417
	.long 0x7e0039d2                                           // 00000002A4B4: 7E0039D2
	v_div_scale_f32 v102, vcc_lo, v73, v91, v73                // 00000002A4B8: D6FC6A66 0526B749
	v_add_f32_e32 v89, 1.0, v92                                // 00000002A4C0: 06B2B8F2
	v_lshlrev_b32_e32 v105, 16, v153                           // 00000002A4C4: 30D33290
	.long 0x7eb839d1                                           // 00000002A4C8: 7EB839D1
	v_and_b32_e32 v84, 1, v0                                   // 00000002A4CC: 36A80081
	v_fma_f32 v94, -v90, v86, 1.0                              // 00000002A4D0: D613005E 23CAAD5A
	v_div_scale_f32 v83, null, v89, v89, v74                   // 00000002A4D8: D6FC7C53 052AB359
	.long 0x7fb83980                                           // 00000002A4E0: 7FB83980
	.long 0xd41e0001                                           // 00000002A4E4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v85, vcc_lo              // 00000002A4E8: 0202AAFF 42CE8ED0
	v_add3_u32 v82, v82, v84, 0x7fff                           // 00000002A4F0: D6550052 03FEA952 00007FFF
	v_fmac_f32_e32 v86, v94, v86                               // 00000002A4FC: 56ACAD5E
	v_rcp_f32_e32 v99, v83                                     // 00000002A500: 7EC65553
	v_fma_f32 v94, 0xbfb8aa3b, v85, -v100                      // 00000002A504: D613005E 8592AAFF BFB8AA3B
	v_sub_f32_e32 v100, v100, v101                             // 00000002A510: 08C8CB64
	v_mul_f32_e32 v84, 0xbfb8aa3b, v105                        // 00000002A514: 10A8D2FF BFB8AA3B
	v_mul_f32_e32 v108, v102, v86                              // 00000002A51C: 10D8AD66
	v_and_b32_e32 v92, 1, v92                                  // 00000002A520: 36B8B881
	v_fmac_f32_e32 v94, 0xb2a5705f, v85                        // 00000002A524: 56BCAAFF B2A5705F
	global_load_u16 v107, v[71:72], off offset:224             // 00000002A52C: DC4A00E0 6B7C0047
	v_rndne_f32_e32 v109, v84                                  // 00000002A534: 7EDA4754
	v_fma_f32 v110, -v90, v108, v102                           // 00000002A538: D613006E 259AD95A
	v_fma_f32 v106, -v83, v99, 1.0                             // 00000002A540: D613006A 23CAC753
	v_add_f32_e32 v94, v100, v94                               // 00000002A548: 06BCBD64
	v_div_scale_f32 v100, s0, v74, v89, v74                    // 00000002A54C: D6FC0064 052AB34A
	v_add3_u32 v81, v81, v92, 0x7fff                           // 00000002A554: D6550051 03FEB951 00007FFF
	v_cvt_i32_f32_e32 v92, v101                                // 00000002A560: 7EB81165
	v_fmac_f32_e32 v99, v106, v99                              // 00000002A564: 56C6C76A
	v_fma_f32 v106, 0xbfb8aa3b, v105, -v84                     // 00000002A568: D613006A 8552D2FF BFB8AA3B
	v_exp_f32_e32 v94, v94                                     // 00000002A574: 7EBC4B5E
	v_sub_f32_e32 v84, v84, v109                               // 00000002A578: 08A8DB54
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002A57C: BF870193
	v_dual_fmac_f32 v108, v110, v86 :: v_dual_mul_f32 v111, v100, v99// 00000002A580: C806AD6E 6C6EC764
	v_fmac_f32_e32 v106, 0xb2a5705f, v105                      // 00000002A588: 56D4D2FF B2A5705F
	s_clause 0x1                                               // 00000002A590: BF850001
	global_store_d16_hi_b16 v[31:32], v81, off offset:160      // 00000002A594: DC9600A0 007C511F
	global_store_d16_hi_b16 v[39:40], v82, off offset:160      // 00000002A59C: DC9600A0 007C5227
	v_fma_f32 v90, -v90, v108, v102                            // 00000002A5A4: D613005A 259AD95A
	v_fma_f32 v101, -v83, v111, v100                           // 00000002A5AC: D6130065 2592DF53
	v_add_f32_e32 v84, v84, v106                               // 00000002A5B4: 06A8D554
	.long 0xd71c0051                                           // 00000002A5B8: D71C0051
	v_cndmask_b32_e32 v1, v94, v92, vcc_lo                     // 00000002A5BC: 0202B95E
	v_cvt_i32_f32_e32 v92, v109                                // 00000002A5C0: 7EB8116D
	v_div_fmas_f32 v86, v90, v86, v108                         // 00000002A5C4: D6370056 05B2AD5A
	v_fmac_f32_e32 v111, v101, v99                             // 00000002A5CC: 56DEC765
	v_exp_f32_e32 v84, v84                                     // 00000002A5D0: 7EA84B54
	v_cndmask_b32_e64 v81, 0, v81, s1                          // 00000002A5D4: D5010051 0006A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v85                  // 00000002A5DC: 7C36AAFF C2B17218
	v_lshlrev_b32_e32 v85, 16, v183                            // 00000002A5E4: 30AB6E90
	v_fma_f32 v83, -v83, v111, v100                            // 00000002A5E8: D6130053 2592DF53
	v_div_fixup_f32 v73, v86, v91, v73                         // 00000002A5F0: D6270049 0526B756
	v_lshlrev_b32_e32 v91, 16, v184                            // 00000002A5F8: 30B77090
	v_cndmask_b32_e32 v81, 0x7f800000, v81, vcc_lo             // 00000002A5FC: 02A2A2FF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 00000002A604: BEEA0000
	v_mul_f32_e32 v90, 0xbfb8aa3b, v85                         // 00000002A608: 10B4AAFF BFB8AA3B
	.long 0xd71c0054                                           // 00000002A610: D71C0054
	v_cndmask_b32_e32 v1, v84, v92, vcc_lo                     // 00000002A614: 0202B954
	v_div_fmas_f32 v83, v83, v99, v111                         // 00000002A618: D6370053 05BEC753
	v_add_f32_e32 v81, 1.0, v81                                // 00000002A620: 06A2A2F2
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000002A624: 7C3CD2FF 42CE8ED0
	v_fma_f32 v102, 0xbfb8aa3b, v85, -v90                      // 00000002A62C: D6130066 856AAAFF BFB8AA3B
	.long 0x7eac39c9                                           // 00000002A638: 7EAC39C9
	v_div_fixup_f32 v74, v83, v89, v74                         // 00000002A63C: D627004A 052AB353
	v_div_scale_f32 v82, null, v81, v81, v75                   // 00000002A644: D6FC7C52 052EA351
	v_cndmask_b32_e32 v84, 0, v84, vcc_lo                      // 00000002A64C: 02A8A880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000002A650: 7C36D2FF C2B17218
	v_mul_f32_e32 v105, 0xbfb8aa3b, v91                        // 00000002A658: 10D2B6FF BFB8AA3B
	v_fmac_f32_e32 v102, 0xb2a5705f, v85                       // 00000002A660: 56CCAAFF B2A5705F
	.long 0x7fac3980                                           // 00000002A668: 7FAC3980
	.long 0x7e0039ca                                           // 00000002A66C: 7E0039CA
	v_cndmask_b32_e32 v83, 0x7f800000, v84, vcc_lo             // 00000002A670: 02A6A8FF 7F800000
	v_rcp_f32_e32 v84, v82                                     // 00000002A678: 7EA85552
	v_div_scale_f32 v106, vcc_lo, v75, v81, v75                // 00000002A67C: D6FC6A6A 052EA34B
	v_fma_f32 v108, 0xbfb8aa3b, v91, -v105                     // 00000002A684: D613006C 85A6B6FF BFB8AA3B
	v_rndne_f32_e32 v109, v105                                 // 00000002A690: 7EDA4769
	v_dual_add_f32 v83, 1.0, v83 :: v_dual_and_b32 v86, 1, v86 // 00000002A694: C924A6F2 5356AC81
	v_and_b32_e32 v100, 1, v0                                  // 00000002A69C: 36C80081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002A6A0: BF870193
	v_dual_fmac_f32 v108, 0xb2a5705f, v91 :: v_dual_sub_f32 v105, v105, v109// 00000002A6A4: C80AB6FF 6C68DB69 B2A5705F
	v_div_scale_f32 v89, null, v83, v83, v76                   // 00000002A6B0: D6FC7C59 0532A753
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000002A6B8: BF870005
	v_fma_f32 v99, -v82, v84, 1.0                              // 00000002A6BC: D6130063 23CAA952
	v_add3_u32 v73, v73, v86, 0x7fff                           // 00000002A6C4: D6550049 03FEAD49 00007FFF
	v_add3_u32 v74, v74, v100, 0x7fff                          // 00000002A6D0: D655004A 03FEC94A 00007FFF
	v_add_f32_e32 v105, v105, v108                             // 00000002A6DC: 06D2D969
	v_rcp_f32_e32 v101, v89                                    // 00000002A6E0: 7ECA5559
	v_fmac_f32_e32 v84, v99, v84                               // 00000002A6E4: 56A8A963
	v_rndne_f32_e32 v99, v90                                   // 00000002A6E8: 7EC6475A
	global_store_d16_hi_b16 v[7:8], v73, off offset:192        // 00000002A6EC: DC9600C0 007C4907
	v_exp_f32_e32 v105, v105                                   // 00000002A6F4: 7ED24B69
	global_store_d16_hi_b16 v[47:48], v74, off offset:192      // 00000002A6F8: DC9600C0 007C4A2F
	v_mul_f32_e32 v110, v106, v84                              // 00000002A700: 10DCA96A
	v_sub_f32_e32 v90, v90, v99                                // 00000002A704: 08B4C75A
	v_cvt_i32_f32_e32 v99, v99                                 // 00000002A708: 7EC61163
	global_load_u16 v100, v[95:96], off offset:256             // 00000002A70C: DC4A0100 647C005F
	v_fma_f32 v111, -v89, v101, 1.0                            // 00000002A714: D613006F 23CACB59
	s_clause 0x1                                               // 00000002A71C: BF850001
	global_load_u16 v94, v[63:64], off offset:256              // 00000002A720: DC4A0100 5E7C003F
	global_load_u16 v92, v[55:56], off offset:256              // 00000002A728: DC4A0100 5C7C0037
	v_add_f32_e32 v90, v90, v102                               // 00000002A730: 06B4CD5A
	v_fma_f32 v102, -v82, v110, v106                           // 00000002A734: D6130066 25AADD52
	v_fmac_f32_e32 v101, v111, v101                            // 00000002A73C: 56CACB6F
	v_div_scale_f32 v111, s0, v76, v83, v76                    // 00000002A740: D6FC006F 0532A74C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002A748: BF870194
	v_exp_f32_e32 v90, v90                                     // 00000002A74C: 7EB44B5A
	v_fmac_f32_e32 v110, v102, v84                             // 00000002A750: 56DCA966
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002A754: BF870112
	v_mul_f32_e32 v102, v111, v101                             // 00000002A758: 10CCCB6F
	v_fma_f32 v82, -v82, v110, v106                            // 00000002A75C: D6130052 25AADD52
	v_cvt_i32_f32_e32 v106, v109                               // 00000002A764: 7ED4116D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002A768: BF870293
	v_fma_f32 v86, -v89, v102, v111                            // 00000002A76C: D6130056 25BECD59
	.long 0xd71c005a                                           // 00000002A774: D71C005A
	v_cndmask_b32_e32 v1, v90, v99, vcc_lo                     // 00000002A778: 0202C75A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002A77C: BF870004
	v_div_fmas_f32 v82, v82, v84, v110                         // 00000002A780: D6370052 05BAA952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v85                  // 00000002A788: 7C3CAAFF 42CE8ED0
	.long 0xd71c0054                                           // 00000002A790: D71C0054
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 00000002A794: 0202D569
	v_fmac_f32_e32 v102, v86, v101                             // 00000002A798: 56CCCB56
	global_load_u16 v99, v[71:72], off offset:256              // 00000002A79C: DC4A0100 637C0047
	v_div_fixup_f32 v75, v82, v81, v75                         // 00000002A7A4: D627004B 052EA352
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000002A7AC: 02B4B480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v91                  // 00000002A7B0: 7C3CB6FF 42CE8ED0
	v_fma_f32 v86, -v89, v102, v111                            // 00000002A7B8: D6130056 25BECD59
	s_waitcnt vmcnt(9)                                         // 00000002A7C0: BF8927F7
	v_lshlrev_b32_e32 v106, 16, v185                           // 00000002A7C4: 30D57290
	.long 0x7ea439cb                                           // 00000002A7C8: 7EA439CB
	.long 0x7fa43980                                           // 00000002A7CC: 7FA43980
	v_cndmask_b32_e32 v84, 0, v84, vcc_lo                      // 00000002A7D0: 02A8A880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v85                  // 00000002A7D4: 7C36AAFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002A7DC: BF8701B3
	v_and_b32_e32 v82, 1, v82                                  // 00000002A7E0: 36A4A481
	v_cndmask_b32_e32 v85, 0x7f800000, v90, vcc_lo             // 00000002A7E4: 02AAB4FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v91                  // 00000002A7EC: 7C36B6FF C2B17218
	v_add3_u32 v75, v75, v82, 0x7fff                           // 00000002A7F4: D655004B 03FEA54B 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002A800: BF870003
	v_dual_add_f32 v85, 1.0, v85 :: v_dual_cndmask_b32 v84, 0x7f800000, v84// 00000002A804: C912AAF2 5554A8FF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 00000002A810: BEEA0000
	global_store_d16_hi_b16 v[15:16], v75, off offset:192      // 00000002A814: DC9600C0 007C4B0F
	v_div_fmas_f32 v86, v86, v101, v102                        // 00000002A81C: D6370056 059ACB56
	v_div_scale_f32 v89, null, v85, v85, v77                   // 00000002A824: D6FC7C59 0536AB55
	v_add_f32_e32 v84, 1.0, v84                                // 00000002A82C: 06A8A8F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002A830: BF870193
	v_div_fixup_f32 v73, v86, v83, v76                         // 00000002A834: D6270049 0532A756
	v_rcp_f32_e32 v76, v89                                     // 00000002A83C: 7E985559
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002A840: BF8701A2
	v_div_scale_f32 v83, null, v84, v84, v78                   // 00000002A844: D6FC7C53 053AA954
	v_lshlrev_b32_e32 v86, 16, v148                            // 00000002A84C: 30AD2890
	.long 0x7e0039c9                                           // 00000002A850: 7E0039C9
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002A854: BF870113
	v_rcp_f32_e32 v74, v83                                     // 00000002A858: 7E945553
	v_mul_f32_e32 v81, 0xbfb8aa3b, v86                         // 00000002A85C: 10A2ACFF BFB8AA3B
	.long 0xd41e0001                                           // 00000002A864: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v86, vcc_lo              // 00000002A868: 0202ACFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000002A870: BF870313
	v_and_b32_e32 v91, 1, v0                                   // 00000002A874: 36B60081
	v_fma_f32 v90, -v89, v76, 1.0                              // 00000002A878: D613005A 23CA9959
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002A880: BF870224
	v_fma_f32 v101, 0xbfb8aa3b, v86, -v81                      // 00000002A884: D6130065 8546ACFF BFB8AA3B
	v_rndne_f32_e32 v102, v81                                  // 00000002A890: 7ECC4751
	v_add3_u32 v73, v73, v91, 0x7fff                           // 00000002A894: D6550049 03FEB749 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002A8A0: BF870004
	v_fmac_f32_e32 v76, v90, v76                               // 00000002A8A4: 5698995A
	v_div_scale_f32 v90, vcc_lo, v77, v85, v77                 // 00000002A8A8: D6FC6A5A 0536AB4D
	v_fma_f32 v105, -v83, v74, 1.0                             // 00000002A8B0: D6130069 23CA9553
	v_fmac_f32_e32 v101, 0xb2a5705f, v86                       // 00000002A8B8: 56CAACFF B2A5705F
	v_sub_f32_e32 v81, v81, v102                               // 00000002A8C0: 08A2CD51
	global_store_d16_hi_b16 v[23:24], v73, off offset:192      // 00000002A8C4: DC9600C0 007C4917
	v_mul_f32_e32 v108, v90, v76                               // 00000002A8CC: 10D8995A
	v_fmac_f32_e32 v74, v105, v74                              // 00000002A8D0: 56949569
	v_mul_f32_e32 v105, 0xbfb8aa3b, v106                       // 00000002A8D4: 10D2D4FF BFB8AA3B
	v_add_f32_e32 v81, v81, v101                               // 00000002A8DC: 06A2CB51
	v_div_scale_f32 v101, s0, v78, v84, v78                    // 00000002A8E0: D6FC0065 053AA94E
	v_fma_f32 v91, -v89, v108, v90                             // 00000002A8E8: D613005B 256AD959
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002A8F0: BF8701A4
	v_fma_f32 v110, 0xbfb8aa3b, v106, -v105                    // 00000002A8F4: D613006E 85A6D4FF BFB8AA3B
	v_rndne_f32_e32 v111, v105                                 // 00000002A900: 7EDE4769
	v_dual_mul_f32 v109, v101, v74 :: v_dual_fmac_f32 v108, v91, v76// 00000002A904: C8C09565 6D6C995B
	v_cvt_i32_f32_e32 v91, v102                                // 00000002A90C: 7EB61166
	v_exp_f32_e32 v81, v81                                     // 00000002A910: 7EA24B51
	v_fmac_f32_e32 v110, 0xb2a5705f, v106                      // 00000002A914: 56DCD4FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002A91C: BF8701B3
	v_fma_f32 v102, -v83, v109, v101                           // 00000002A920: D6130066 2596DB53
	v_sub_f32_e32 v105, v105, v111                             // 00000002A928: 08D2DF69
	v_fma_f32 v82, -v89, v108, v90                             // 00000002A92C: D6130052 256AD959
	v_fmac_f32_e32 v109, v102, v74                             // 00000002A934: 56DA9566
	global_load_u16 v102, v[79:80], off offset:256             // 00000002A938: DC4A0100 667C004F
	v_div_fmas_f32 v76, v82, v76, v108                         // 00000002A940: D637004C 05B29952
	.long 0xd71c0051                                           // 00000002A948: D71C0051
	v_cndmask_b32_e32 v1, v81, v91, vcc_lo                     // 00000002A94C: 0202B751
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v86                  // 00000002A950: 7C36ACFF C2B17218
	v_fma_f32 v83, -v83, v109, v101                            // 00000002A958: D6130053 2596DB53
	global_load_u16 v101, v[87:88], off offset:256             // 00000002A960: DC4A0100 657C0057
	v_add_f32_e32 v89, v105, v110                              // 00000002A968: 06B2DD69
	v_cndmask_b32_e64 v81, 0, v81, s1                          // 00000002A96C: D5010051 0006A280
	v_cvt_i32_f32_e32 v86, v111                                // 00000002A974: 7EAC116F
	v_div_fixup_f32 v76, v76, v85, v77                         // 00000002A978: D627004C 0536AB4C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002A980: BF870194
	v_exp_f32_e32 v82, v89                                     // 00000002A984: 7EA44B59
	v_cndmask_b32_e32 v81, 0x7f800000, v81, vcc_lo             // 00000002A988: 02A2A2FF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 00000002A990: BEEA0000
	v_div_fmas_f32 v74, v83, v74, v109                         // 00000002A994: D637004A 05B69553
	v_mul_f32_e32 v83, v156, v65                               // 00000002A99C: 10A6839C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v106                 // 00000002A9A0: 7C3CD4FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002A9A8: BF870293
	v_div_fixup_f32 v74, v74, v84, v78                         // 00000002A9AC: D627004A 053AA94A
	.long 0xd71c0041                                           // 00000002A9B4: D71C0041
	v_cndmask_b32_e32 v1, v82, v86, vcc_lo                     // 00000002A9B8: 0202AD52
	v_add_f32_e32 v86, 1.0, v81                                // 00000002A9BC: 06ACA2F2
	.long 0x7e9c39cc                                           // 00000002A9C0: 7E9C39CC
	.long 0x7f9c3980                                           // 00000002A9C4: 7F9C3980
	.long 0x7e0039ca                                           // 00000002A9C8: 7E0039CA
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000002A9CC: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v106                 // 00000002A9D0: 7C36D4FF C2B17218
	v_div_scale_f32 v77, null, v86, v86, v83                   // 00000002A9D8: D6FC7C4D 054EAD56
	v_and_b32_e32 v75, 1, v78                                  // 00000002A9E0: 36969C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002A9E4: BF870194
	v_dual_mul_f32 v78, v155, v66 :: v_dual_cndmask_b32 v65, 0x7f800000, v65// 00000002A9E8: C8D2859B 4E4082FF 7F800000
	v_rcp_f32_e32 v84, v77                                     // 00000002A9F4: 7EA8554D
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002A9F8: BF870002
	v_add3_u32 v75, v76, v75, 0x7fff                           // 00000002A9FC: D655004B 03FE974C 00007FFF
	s_clause 0x5                                               // 00000002AA08: BF850005
	global_load_u16 v105, v[71:72], off offset:288             // 00000002AA0C: DC4A0120 697C0047
	global_load_u16 v90, v[71:72], off offset:320              // 00000002AA14: DC4A0140 5A7C0047
	global_load_u16 v82, v[71:72], off offset:352              // 00000002AA1C: DC4A0160 527C0047
	global_load_u16 v76, v[71:72], off offset:384              // 00000002AA24: DC4A0180 4C7C0047
	global_load_u16 v73, v[71:72], off offset:416              // 00000002AA2C: DC4A01A0 497C0047
	global_load_u16 v66, v[71:72], off offset:448              // 00000002AA34: DC4A01C0 427C0047
	v_add_f32_e32 v85, 1.0, v65                                // 00000002AA3C: 06AA82F2
	v_and_b32_e32 v65, 1, v0                                   // 00000002AA40: 36820081
	global_store_d16_hi_b16 v[31:32], v75, off offset:192      // 00000002AA44: DC9600C0 007C4B1F
	v_div_scale_f32 v91, null, v85, v85, v78                   // 00000002AA4C: D6FC7C5B 053AAB55
	v_fma_f32 v81, -v77, v84, 1.0                              // 00000002AA54: D6130051 23CAA94D
	v_add3_u32 v74, v74, v65, 0x7fff                           // 00000002AA5C: D655004A 03FE834A 00007FFF
	v_div_scale_f32 v116, s0, v78, v85, v78                    // 00000002AA68: D6FC0074 053AAB4E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002AA70: BF870194
	v_rcp_f32_e32 v106, v91                                    // 00000002AA74: 7ED4555B
	v_fmac_f32_e32 v84, v81, v84                               // 00000002AA78: 56A8A951
	s_clause 0x5                                               // 00000002AA7C: BF850005
	global_load_u16 v108, v[95:96], off offset:288             // 00000002AA80: DC4A0120 6C7C005F
	global_load_u16 v89, v[95:96], off offset:320              // 00000002AA88: DC4A0140 597C005F
	global_load_u16 v81, v[95:96], off offset:352              // 00000002AA90: DC4A0160 517C005F
	global_load_u16 v75, v[95:96], off offset:384              // 00000002AA98: DC4A0180 4B7C005F
	global_load_u16 v71, v[95:96], off offset:416              // 00000002AAA0: DC4A01A0 477C005F
	global_load_u16 v65, v[95:96], off offset:448              // 00000002AAA8: DC4A01C0 417C005F
	v_div_scale_f32 v95, vcc_lo, v83, v86, v83                 // 00000002AAB0: D6FC6A5F 054EAD53
	global_store_d16_hi_b16 v[39:40], v74, off offset:192      // 00000002AAB8: DC9600C0 007C4A27
	v_mul_f32_e32 v112, v95, v84                               // 00000002AAC0: 10E0A95F
	v_fma_f32 v110, -v91, v106, 1.0                            // 00000002AAC4: D613006E 23CAD55B
	s_waitcnt vmcnt(21)                                        // 00000002AACC: BF8957F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002AAD0: BF870091
	v_dual_fmac_f32 v106, v110, v106 :: v_dual_lshlrev_b32 v93, 16, v93// 00000002AAD4: C822D56E 6A5CBA90
	v_mul_f32_e32 v117, v116, v106                             // 00000002AADC: 10EAD574
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002AAE0: BF870092
	v_mul_f32_e32 v111, 0xbfb8aa3b, v93                        // 00000002AAE4: 10DEBAFF BFB8AA3B
	v_fma_f32 v110, 0xbfb8aa3b, v93, -v111                     // 00000002AAEC: D613006E 85BEBAFF BFB8AA3B
	v_rndne_f32_e32 v115, v111                                 // 00000002AAF8: 7EE6476F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002AAFC: BF870091
	v_dual_fmac_f32 v110, 0xb2a5705f, v93 :: v_dual_sub_f32 v111, v111, v115// 00000002AB00: C80ABAFF 6E6EE76F B2A5705F
	v_add_f32_e32 v74, v111, v110                              // 00000002AB0C: 0694DD6F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000002AB10: BF8700B1
	v_exp_f32_e32 v74, v74                                     // 00000002AB14: 7E944B4A
	s_waitcnt vmcnt(18)                                        // 00000002AB18: BF894BF7
	v_lshlrev_b32_e32 v72, 16, v107                            // 00000002AB1C: 3090D690
	v_mul_f32_e32 v107, 0xbfb8aa3b, v72                        // 00000002AB20: 10D690FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002AB28: BF8700A1
	v_fma_f32 v96, 0xbfb8aa3b, v72, -v107                      // 00000002AB2C: D6130060 85AE90FF BFB8AA3B
	v_rndne_f32_e32 v109, v107                                 // 00000002AB38: 7EDA476B
	v_dual_fmac_f32 v96, 0xb2a5705f, v72 :: v_dual_sub_f32 v107, v107, v109// 00000002AB3C: C80A90FF 606ADB6B B2A5705F
	v_cvt_i32_f32_e32 v109, v109                               // 00000002AB48: 7EDA116D
	s_waitcnt vmcnt(17)                                        // 00000002AB4C: BF8947F7
	v_lshlrev_b32_e32 v100, 16, v100                           // 00000002AB50: 30C8C890
	s_waitcnt vmcnt(14)                                        // 00000002AB54: BF893BF7
	v_lshlrev_b32_e32 v99, 16, v99                             // 00000002AB58: 30C6C690
	s_waitcnt vmcnt(13)                                        // 00000002AB5C: BF8937F7
	v_lshlrev_b32_e32 v102, 16, v102                           // 00000002AB60: 30CCCC90
	v_add_f32_e32 v96, v107, v96                               // 00000002AB64: 06C0C16B
	v_fma_f32 v107, -v77, v112, v95                            // 00000002AB68: D613006B 257EE14D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002AB70: BF870092
	v_exp_f32_e32 v96, v96                                     // 00000002AB74: 7EC04B60
	v_fmac_f32_e32 v112, v107, v84                             // 00000002AB78: 56E0A96B
	v_fma_f32 v107, -v91, v117, v116                           // 00000002AB7C: D613006B 25D2EB5B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002AB84: BF870112
	v_fma_f32 v77, -v77, v112, v95                             // 00000002AB88: D613004D 257EE14D
	v_fmac_f32_e32 v117, v107, v106                            // 00000002AB90: 56EAD56B
	v_cvt_i32_f32_e32 v107, v115                               // 00000002AB94: 7ED61173
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002AB98: BF870215
	.long 0xd71c0060                                           // 00000002AB9C: D71C0060
	v_cndmask_b32_e32 v1, v96, v109, vcc_lo                    // 00000002ABA0: 0202DB60
	v_div_fmas_f32 v77, v77, v84, v112                         // 00000002ABA4: D637004D 05C2A94D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000002ABAC: 7C3C90FF 42CE8ED0
	v_fma_f32 v84, -v91, v117, v116                            // 00000002ABB4: D6130054 25D2EB5B
	.long 0xd71c004a                                           // 00000002ABBC: D71C004A
	v_cndmask_b32_e32 v1, v74, v107, vcc_lo                    // 00000002ABC0: 0202D74A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002ABC4: BF870004
	v_div_fixup_f32 v86, v77, v86, v83                         // 00000002ABC8: D6270056 054EAD4D
	v_cndmask_b32_e32 v91, 0, v96, vcc_lo                      // 00000002ABD0: 02B6C080
	s_clause 0x1                                               // 00000002ABD4: BF850001
	global_load_u16 v96, v[63:64], off offset:288              // 00000002ABD8: DC4A0120 607C003F
	global_load_u16 v95, v[55:56], off offset:288              // 00000002ABE0: DC4A0120 5F7C0037
	s_mov_b32 vcc_lo, s0                                       // 00000002ABE8: BEEA0000
	v_div_fmas_f32 v84, v84, v106, v117                        // 00000002ABEC: D6370054 05D6D554
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000002ABF4: 7C3690FF C2B17218
	v_mul_f32_e32 v106, v104, v67                              // 00000002ABFC: 10D48768
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002AC00: BF8701B3
	v_div_fixup_f32 v85, v84, v85, v78                         // 00000002AC04: D6270055 053AAB54
	v_cndmask_b32_e32 v72, 0x7f800000, v91, vcc_lo             // 00000002AC0C: 0290B6FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v93                  // 00000002AC14: 7C3CBAFF 42CE8ED0
	.long 0x7e0039d5                                           // 00000002AC1C: 7E0039D5
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002AC20: BF870003
	v_dual_add_f32 v107, 1.0, v72 :: v_dual_cndmask_b32 v74, 0, v74// 00000002AC24: C91290F2 6B4A9480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v93                  // 00000002AC2C: 7C36BAFF C2B17218
	v_mul_f32_e32 v93, v103, v68                               // 00000002AC34: 10BA8967
	s_clause 0x5                                               // 00000002AC38: BF850005
	global_load_u16 v115, v[87:88], off offset:288             // 00000002AC3C: DC4A0120 737C0057
	global_load_u16 v91, v[87:88], off offset:320              // 00000002AC44: DC4A0140 5B7C0057
	global_load_u16 v84, v[87:88], off offset:352              // 00000002AC4C: DC4A0160 547C0057
	global_load_u16 v78, v[87:88], off offset:384              // 00000002AC54: DC4A0180 4E7C0057
	global_load_u16 v72, v[87:88], off offset:416              // 00000002AC5C: DC4A01A0 487C0057
	global_load_u16 v68, v[87:88], off offset:448              // 00000002AC64: DC4A01C0 447C0057
	v_div_scale_f32 v109, null, v107, v107, v106               // 00000002AC6C: D6FC7C6D 05AAD76B
	v_dual_cndmask_b32 v67, 0x7f800000, v74 :: v_dual_lshlrev_b32 v88, 16, v97// 00000002AC74: CA6294FF 4358C290 7F800000
	v_and_b32_e32 v74, 1, v0                                   // 00000002AC80: 36940081
	s_waitcnt vmcnt(12)                                        // 00000002AC84: BF8933F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000002AC88: 30B2B290
	v_rcp_f32_e32 v111, v109                                   // 00000002AC8C: 7EDE556D
	v_mul_f32_e32 v118, 0xbfb8aa3b, v88                        // 00000002AC90: 10ECB0FF BFB8AA3B
	v_add_f32_e32 v110, 1.0, v67                               // 00000002AC98: 06DC86F2
	.long 0x7e8639d6                                           // 00000002AC9C: 7E8639D6
	.long 0x7f863980                                           // 00000002ACA0: 7F863980
	v_add3_u32 v116, v85, v74, 0x7fff                          // 00000002ACA4: D6550074 03FE9555 00007FFF
	.long 0xd41e0001                                           // 00000002ACB0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v88, vcc_lo              // 00000002ACB4: 0202B0FF 42CE8ED0
	v_div_scale_f32 v112, null, v110, v110, v93                // 00000002ACBC: D6FC7C70 0576DD6E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002ACC4: BF870294
	v_and_b32_e32 v97, 1, v67                                  // 00000002ACC8: 36C28681
	v_fma_f32 v85, -v109, v111, 1.0                            // 00000002ACCC: D6130055 23CADF6D
	s_clause 0x5                                               // 00000002ACD4: BF850005
	global_load_u16 v119, v[79:80], off offset:288             // 00000002ACD8: DC4A0120 777C004F
	global_load_u16 v87, v[79:80], off offset:320              // 00000002ACE0: DC4A0140 577C004F
	global_load_u16 v83, v[79:80], off offset:352              // 00000002ACE8: DC4A0160 537C004F
	global_load_u16 v77, v[79:80], off offset:384              // 00000002ACF0: DC4A0180 4D7C004F
	global_load_u16 v74, v[79:80], off offset:416              // 00000002ACF8: DC4A01A0 4A7C004F
	global_load_u16 v67, v[79:80], off offset:448              // 00000002AD00: DC4A01C0 437C004F
	v_rcp_f32_e32 v117, v112                                   // 00000002AD08: 7EEA5570
	v_lshlrev_b32_e32 v79, 16, v98                             // 00000002AD0C: 309EC490
	v_fma_f32 v80, 0xbfb8aa3b, v88, -v118                      // 00000002AD10: D6130050 85DAB0FF BFB8AA3B
	v_rndne_f32_e32 v98, v118                                  // 00000002AD1C: 7EC44776
	v_fmac_f32_e32 v111, v85, v111                             // 00000002AD20: 56DEDF55
	v_div_scale_f32 v85, vcc_lo, v106, v107, v106              // 00000002AD24: D6FC6A55 05AAD76A
	v_mul_f32_e32 v120, 0xbfb8aa3b, v79                        // 00000002AD2C: 10F09EFF BFB8AA3B
	v_fmac_f32_e32 v80, 0xb2a5705f, v88                        // 00000002AD34: 56A0B0FF B2A5705F
	v_sub_f32_e32 v118, v118, v98                              // 00000002AD3C: 08ECC576
	v_add3_u32 v86, v86, v97, 0x7fff                           // 00000002AD40: D6550056 03FEC356 00007FFF
	v_fma_f32 v121, -v112, v117, 1.0                           // 00000002AD4C: D6130079 23CAEB70
	v_mul_f32_e32 v122, v85, v111                              // 00000002AD54: 10F4DF55
	v_fma_f32 v123, 0xbfb8aa3b, v79, -v120                     // 00000002AD58: D613007B 85E29EFF BFB8AA3B
	v_rndne_f32_e32 v124, v120                                 // 00000002AD64: 7EF84778
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002AD68: BF8701A4
	v_dual_add_f32 v80, v118, v80 :: v_dual_fmac_f32 v117, v121, v117// 00000002AD6C: C900A176 5074EB79
	v_div_scale_f32 v118, s0, v93, v110, v93                   // 00000002AD74: D6FC0076 0576DD5D
	v_dual_fmac_f32 v123, 0xb2a5705f, v79 :: v_dual_sub_f32 v120, v120, v124// 00000002AD7C: C80A9EFF 7B78F978 B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002AD88: BF8701A3
	v_exp_f32_e32 v80, v80                                     // 00000002AD8C: 7EA04B50
	v_fma_f32 v121, -v109, v122, v85                           // 00000002AD90: D6130079 2556F56D
	v_mul_f32_e32 v125, v118, v117                             // 00000002AD98: 10FAEB76
	v_cvt_i32_f32_e32 v98, v98                                 // 00000002AD9C: 7EC41162
	s_clause 0x1                                               // 00000002ADA0: BF850001
	global_store_d16_hi_b16 v[7:8], v86, off offset:224        // 00000002ADA4: DC9600E0 007C5607
	global_store_d16_hi_b16 v[47:48], v116, off offset:224     // 00000002ADAC: DC9600E0 007C742F
	v_fmac_f32_e32 v122, v121, v111                            // 00000002ADB4: 56F4DF79
	.long 0x7fe83980                                           // 00000002ADB8: 7FE83980
	.long 0xd71c0050                                           // 00000002ADBC: D71C0050
	v_cndmask_b32_e32 v1, v80, v98, vcc_lo                     // 00000002ADC0: 0202C550
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002ADC4: BF870113
	v_fma_f32 v85, -v109, v122, v85                            // 00000002ADC8: D6130055 2556F56D
	v_cndmask_b32_e64 v80, 0, v80, s1                          // 00000002ADD0: D5010050 0006A080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002ADD8: BF870122
	v_div_fmas_f32 v85, v85, v111, v122                        // 00000002ADDC: D6370055 05EADF55
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 00000002ADE4: 7C36B0FF C2B17218
	v_div_fixup_f32 v106, v85, v107, v106                      // 00000002ADEC: D627006A 05AAD755
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000002ADF4: BF870234
	v_cndmask_b32_e32 v80, 0x7f800000, v80, vcc_lo             // 00000002ADF8: 02A0A0FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v79                  // 00000002AE00: 7C3C9EFF 42CE8ED0
	v_mul_f32_e32 v107, v113, v70                              // 00000002AE08: 10D68D71
	.long 0x7ee839ea                                           // 00000002AE0C: 7EE839EA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002AE10: BF870114
	v_add_f32_e32 v98, 1.0, v80                                // 00000002AE14: 06C4A0F2
	v_and_b32_e32 v116, 1, v116                                // 00000002AE18: 36E8E881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000002AE1C: BF870151
	v_add3_u32 v106, v106, v116, 0x7fff                        // 00000002AE20: D655006A 03FEE96A 00007FFF
	global_store_d16_hi_b16 v[15:16], v106, off offset:224     // 00000002AE2C: DC9600E0 007C6A0F
	s_waitcnt vmcnt(13)                                        // 00000002AE34: BF8937F7
	v_dual_add_f32 v97, v120, v123 :: v_dual_lshlrev_b32 v96, 16, v96// 00000002AE38: C922F778 6160C090
	v_fma_f32 v120, -v112, v125, v118                          // 00000002AE40: D6130078 25DAFB70
	v_exp_f32_e32 v86, v97                                     // 00000002AE48: 7EAC4B61
	v_cvt_i32_f32_e32 v97, v124                                // 00000002AE4C: 7EC2117C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002AE50: BF870092
	v_fmac_f32_e32 v125, v120, v117                            // 00000002AE54: 56FAEB78
	v_fma_f32 v88, -v112, v125, v118                           // 00000002AE58: D6130058 25DAFB70
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 00000002AE60: BF870185
	.long 0xd71c0056                                           // 00000002AE64: D71C0056
	v_cndmask_b32_e32 v1, v86, v97, vcc_lo                     // 00000002AE68: 0202C356
	v_mul_f32_e32 v97, v114, v69                               // 00000002AE6C: 10C28B72
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002AE70: BF870122
	v_cndmask_b32_e32 v69, 0, v86, vcc_lo                      // 00000002AE74: 028AAC80
	s_mov_b32 vcc_lo, s0                                       // 00000002AE78: BEEA0000
	v_div_scale_f32 v109, null, v98, v98, v97                  // 00000002AE7C: D6FC7C6D 0586C562
	v_div_fmas_f32 v80, v88, v117, v125                        // 00000002AE84: D6370050 05F6EB58
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v79                  // 00000002AE8C: 7C369EFF C2B17218
	v_lshlrev_b32_e32 v117, 16, v92                            // 00000002AE94: 30EAB890
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002AE98: BF870194
	v_rcp_f32_e32 v111, v109                                   // 00000002AE9C: 7EDE556D
	v_div_fixup_f32 v93, v80, v110, v93                        // 00000002AEA0: D627005D 0576DD50
	v_cndmask_b32_e32 v69, 0x7f800000, v69, vcc_lo             // 00000002AEA8: 028A8AFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002AEB0: BF870223
	v_mul_f32_e32 v120, 0xbfb8aa3b, v117                       // 00000002AEB4: 10F0EAFF BFB8AA3B
	.long 0xd41e0001                                           // 00000002AEBC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v117, vcc_lo             // 00000002AEC0: 0202EAFF 42CE8ED0
	.long 0x7e0039dd                                           // 00000002AEC8: 7E0039DD
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002AECC: BF870004
	v_add_f32_e32 v110, 1.0, v69                               // 00000002AED0: 06DC8AF2
	s_clause 0x5                                               // 00000002AED4: BF850005
	global_load_u16 v112, v[55:56], off offset:320             // 00000002AED8: DC4A0140 707C0037
	global_load_u16 v88, v[55:56], off offset:352              // 00000002AEE0: DC4A0160 587C0037
	global_load_u16 v85, v[55:56], off offset:384              // 00000002AEE8: DC4A0180 557C0037
	global_load_u16 v79, v[55:56], off offset:416              // 00000002AEF0: DC4A01A0 4F7C0037
	global_load_u16 v69, v[55:56], off offset:448              // 00000002AEF8: DC4A01C0 457C0037
	global_load_u16 v55, v[55:56], off offset:480              // 00000002AF00: DC4A01E0 377C0037
	v_rndne_f32_e32 v125, v120                                 // 00000002AF08: 7EFA4778
	s_clause 0x5                                               // 00000002AF0C: BF850005
	global_load_u16 v126, v[63:64], off offset:320             // 00000002AF10: DC4A0140 7E7C003F
	global_load_u16 v92, v[63:64], off offset:352              // 00000002AF18: DC4A0160 5C7C003F
	global_load_u16 v86, v[63:64], off offset:384              // 00000002AF20: DC4A0180 567C003F
	global_load_u16 v80, v[63:64], off offset:416              // 00000002AF28: DC4A01A0 507C003F
	global_load_u16 v70, v[63:64], off offset:448              // 00000002AF30: DC4A01C0 467C003F
	global_load_u16 v56, v[63:64], off offset:480              // 00000002AF38: DC4A01E0 387C003F
	v_lshlrev_b32_e32 v63, 16, v94                             // 00000002AF40: 307EBC90
	v_div_scale_f32 v118, null, v110, v110, v107               // 00000002AF44: D6FC7C76 05AEDD6E
	v_fma_f32 v122, -v109, v111, 1.0                           // 00000002AF4C: D613007A 23CADF6D
	v_fma_f32 v124, 0xbfb8aa3b, v117, -v120                    // 00000002AF54: D613007C 85E2EAFF BFB8AA3B
	v_sub_f32_e32 v64, v120, v125                              // 00000002AF60: 0880FB78
	v_mul_f32_e32 v120, 0xbfb8aa3b, v63                        // 00000002AF64: 10F07EFF BFB8AA3B
	v_rcp_f32_e32 v123, v118                                   // 00000002AF6C: 7EF65576
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002AF70: BF8701A3
	v_dual_fmac_f32 v111, v122, v111 :: v_dual_fmac_f32 v124, 0xb2a5705f, v117// 00000002AF74: C800DF7A 6F7CEAFF B2A5705F
	v_div_scale_f32 v94, vcc_lo, v97, v98, v97                 // 00000002AF80: D6FC6A5E 0586C561
	v_fma_f32 v127, 0xbfb8aa3b, v63, -v120                     // 00000002AF88: D613007F 85E27EFF BFB8AA3B
	v_rndne_f32_e32 v128, v120                                 // 00000002AF94: 7F004778
	v_and_b32_e32 v121, 1, v0                                  // 00000002AF98: 36F20081
	v_add_f32_e32 v64, v64, v124                               // 00000002AF9C: 0680F940
	v_mul_f32_e32 v124, v94, v111                              // 00000002AFA0: 10F8DF5E
	v_fmac_f32_e32 v127, 0xb2a5705f, v63                       // 00000002AFA4: 56FE7EFF B2A5705F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000002AFAC: BF870005
	v_fma_f32 v122, -v118, v123, 1.0                           // 00000002AFB0: D613007A 23CAF776
	v_sub_f32_e32 v120, v120, v128                             // 00000002AFB8: 08F10178
	v_add3_u32 v93, v93, v121, 0x7fff                          // 00000002AFBC: D655005D 03FEF35D 00007FFF
	v_cvt_i32_f32_e32 v121, v125                               // 00000002AFC8: 7EF2117D
	v_fma_f32 v125, -v109, v124, v94                           // 00000002AFCC: D613007D 257AF96D
	v_fmac_f32_e32 v123, v122, v123                            // 00000002AFD4: 56F6F77A
	v_div_scale_f32 v122, s0, v107, v110, v107                 // 00000002AFD8: D6FC007A 05AEDD6B
	v_add_f32_e32 v120, v120, v127                             // 00000002AFE0: 06F0FF78
	v_exp_f32_e32 v64, v64                                     // 00000002AFE4: 7E804B40
	v_fmac_f32_e32 v124, v125, v111                            // 00000002AFE8: 56F8DF7D
	global_store_d16_hi_b16 v[23:24], v93, off offset:224      // 00000002AFEC: DC9600E0 007C5D17
	v_mul_f32_e32 v129, v122, v123                             // 00000002AFF4: 1102F77A
	v_exp_f32_e32 v120, v120                                   // 00000002AFF8: 7EF04B78
	v_mul_f32_e32 v41, v156, v41                               // 00000002AFFC: 1052539C
	v_fma_f32 v94, -v109, v124, v94                            // 00000002B000: D613005E 257AF96D
	v_cvt_i32_f32_e32 v109, v128                               // 00000002B008: 7EDA1180
	v_fma_f32 v116, -v118, v129, v122                          // 00000002B00C: D6130074 25EB0376
	.long 0xd71c0040                                           // 00000002B014: D71C0040
	v_cndmask_b32_e32 v1, v64, v121, vcc_lo                    // 00000002B018: 0202F340
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002B01C: BF870224
	v_div_fmas_f32 v94, v94, v111, v124                        // 00000002B020: D637005E 05F2DF5E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v63                  // 00000002B028: 7C3C7EFF 42CE8ED0
	v_fmac_f32_e32 v129, v116, v123                            // 00000002B030: 5702F774
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000002B034: BF870005
	.long 0xd71c006d                                           // 00000002B038: D71C006D
	v_cndmask_b32_e32 v1, v120, v109, vcc_lo                   // 00000002B03C: 0202DB78
	v_cndmask_b32_e64 v64, 0, v64, s1                          // 00000002B040: D5010040 00068080
	.long 0xd41b0001                                           // 00000002B048: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v117, vcc_lo             // 00000002B04C: 0202EAFF C2B17218
	v_div_fixup_f32 v94, v94, v98, v97                         // 00000002B054: D627005E 0586C55E
	v_fma_f32 v111, -v118, v129, v122                          // 00000002B05C: D613006F 25EB0376
	v_cndmask_b32_e32 v109, 0, v109, vcc_lo                    // 00000002B064: 02DADA80
	s_mov_b32 vcc_lo, s0                                       // 00000002B068: BEEA0000
	v_cndmask_b32_e64 v64, 0x7f800000, v64, s1                 // 00000002B06C: D5010040 000680FF 7F800000
	v_mul_f32_e32 v97, 0xbfb8aa3b, v99                         // 00000002B078: 10C2C6FF BFB8AA3B
	v_div_fmas_f32 v111, v111, v123, v129                      // 00000002B080: D637006F 0606F76F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v63                  // 00000002B088: 7C367EFF C2B17218
	v_mul_f32_e32 v120, 0xbfb8aa3b, v100                       // 00000002B090: 10F0C8FF BFB8AA3B
	v_add_f32_e32 v64, 1.0, v64                                // 00000002B098: 068080F2
	v_rndne_f32_e32 v117, v97                                  // 00000002B09C: 7EEA4761
	v_div_fixup_f32 v106, v111, v110, v107                     // 00000002B0A0: D627006A 05AEDD6F
	v_cndmask_b32_e32 v63, 0x7f800000, v109, vcc_lo            // 00000002B0A8: 027EDAFF 7F800000
	v_fma_f32 v111, 0xbfb8aa3b, v99, -v97                      // 00000002B0B0: D613006F 8586C6FF BFB8AA3B
	v_div_scale_f32 v116, null, v64, v64, v57                  // 00000002B0BC: D6FC7C74 04E68140
	v_sub_f32_e32 v97, v97, v117                               // 00000002B0C4: 08C2EB61
	.long 0x7e0039ea                                           // 00000002B0C8: 7E0039EA
	v_add_f32_e32 v63, 1.0, v63                                // 00000002B0CC: 067E7EF2
	v_fmac_f32_e32 v111, 0xb2a5705f, v99                       // 00000002B0D0: 56DEC6FF B2A5705F
	v_rcp_f32_e32 v107, v116                                   // 00000002B0D8: 7ED65574
	v_fma_f32 v122, 0xbfb8aa3b, v100, -v120                    // 00000002B0DC: D613007A 85E2C8FF BFB8AA3B
	v_rndne_f32_e32 v123, v120                                 // 00000002B0E8: 7EF64778
	v_div_scale_f32 v93, null, v63, v63, v58                   // 00000002B0EC: D6FC7C5D 04EA7F3F
	v_add_f32_e32 v97, v97, v111                               // 00000002B0F4: 06C2DF61
	.long 0x7ec439de                                           // 00000002B0F8: 7EC439DE
	.long 0x7fc43980                                           // 00000002B0FC: 7FC43980
	v_and_b32_e32 v118, 1, v0                                  // 00000002B100: 36EC0081
	v_rcp_f32_e32 v110, v93                                    // 00000002B104: 7EDC555D
	v_exp_f32_e32 v97, v97                                     // 00000002B108: 7EC24B61
	v_fma_f32 v109, -v116, v107, 1.0                           // 00000002B10C: D613006D 23CAD774
	v_fmac_f32_e32 v122, 0xb2a5705f, v100                      // 00000002B114: 56F4C8FF B2A5705F
	v_sub_f32_e32 v120, v120, v123                             // 00000002B11C: 08F0F778
	v_and_b32_e32 v98, 1, v98                                  // 00000002B120: 36C4C481
	v_add3_u32 v106, v106, v118, 0x7fff                        // 00000002B124: D655006A 03FEED6A 00007FFF
	v_fmac_f32_e32 v107, v109, v107                            // 00000002B130: 56D6D76D
	v_div_scale_f32 v109, vcc_lo, v57, v64, v57                // 00000002B134: D6FC6A6D 04E68139
	v_cvt_i32_f32_e32 v117, v117                               // 00000002B13C: 7EEA1175
	v_fma_f32 v121, -v93, v110, 1.0                            // 00000002B140: D6130079 23CADD5D
	v_add_f32_e32 v120, v120, v122                             // 00000002B148: 06F0F578
	v_add3_u32 v94, v94, v98, 0x7fff                           // 00000002B14C: D655005E 03FEC55E 00007FFF
	v_mul_f32_e32 v111, v109, v107                             // 00000002B158: 10DED76D
	.long 0xd71c0061                                           // 00000002B15C: D71C0061
	v_cndmask_b32_e32 v1, v97, v117, vcc_lo                    // 00000002B160: 0202EB61
	v_fmac_f32_e32 v110, v121, v110                            // 00000002B164: 56DCDD79
	v_div_scale_f32 v121, s0, v58, v63, v58                    // 00000002B168: D6FC0079 04EA7F3A
	v_exp_f32_e32 v117, v120                                   // 00000002B170: 7EEA4B78
	v_fma_f32 v118, -v116, v111, v109                          // 00000002B174: D6130076 25B6DF74
	.long 0xd41e0001                                           // 00000002B17C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v99, vcc_lo              // 00000002B180: 0202C6FF 42CE8ED0
	global_store_d16_hi_b16 v[31:32], v94, off offset:224      // 00000002B188: DC9600E0 007C5E1F
	v_mul_f32_e32 v124, v121, v110                             // 00000002B190: 10F8DD79
	v_dual_fmac_f32 v111, v118, v107 :: v_dual_lshlrev_b32 v94, 16, v101// 00000002B194: C822D776 6F5ECA90
	v_cndmask_b32_e64 v97, 0, v97, s1                          // 00000002B19C: D5010061 0006C280
	.long 0xd41b0001                                           // 00000002B1A4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v99, vcc_lo              // 00000002B1A8: 0202C6FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002B1B0: BF870004
	v_fma_f32 v98, -v93, v124, v121                            // 00000002B1B4: D6130062 25E6F95D
	global_store_d16_hi_b16 v[39:40], v106, off offset:224     // 00000002B1BC: DC9600E0 007C6A27
	v_fma_f32 v109, -v116, v111, v109                          // 00000002B1C4: D613006D 25B6DF74
	v_cndmask_b32_e64 v97, 0x7f800000, v97, s1                 // 00000002B1CC: D5010061 0006C2FF 7F800000
	v_fmac_f32_e32 v124, v98, v110                             // 00000002B1D8: 56F8DD62
	v_cvt_i32_f32_e32 v98, v123                                // 00000002B1DC: 7EC4117B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002B1E0: BF870004
	v_div_fmas_f32 v99, v109, v107, v111                       // 00000002B1E4: D6370063 05BED76D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 00000002B1EC: 7C3CC8FF 42CE8ED0
	v_add_f32_e32 v97, 1.0, v97                                // 00000002B1F4: 06C2C2F2
	v_fma_f32 v93, -v93, v124, v121                            // 00000002B1F8: D613005D 25E6F95D
	.long 0xd71c0062                                           // 00000002B200: D71C0062
	v_cndmask_b32_e32 v1, v117, v98, vcc_lo                    // 00000002B204: 0202C575
	v_div_fixup_f32 v57, v99, v64, v57                         // 00000002B208: D6270039 04E68163
	v_mul_f32_e32 v111, 0xbfb8aa3b, v102                       // 00000002B210: 10DECCFF BFB8AA3B
	v_div_scale_f32 v107, null, v97, v97, v59                  // 00000002B218: D6FC7C6B 04EEC361
	.long 0x7fc63980                                           // 00000002B220: 7FC63980
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000002B224: 02C4C480
	s_mov_b32 vcc_lo, s0                                       // 00000002B228: BEEA0000
	v_fma_f32 v117, 0xbfb8aa3b, v102, -v111                    // 00000002B22C: D6130075 85BECCFF BFB8AA3B
	v_div_fmas_f32 v93, v93, v110, v124                        // 00000002B238: D637005D 05F2DD5D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 00000002B240: 7C36C8FF C2B17218
	v_rndne_f32_e32 v118, v111                                 // 00000002B248: 7EEC476F
	.long 0x7ec639b9                                           // 00000002B24C: 7EC639B9
	v_fmac_f32_e32 v117, 0xb2a5705f, v102                      // 00000002B250: 56EACCFF B2A5705F
	v_div_fixup_f32 v58, v93, v63, v58                         // 00000002B258: D627003A 04EA7F5D
	v_cndmask_b32_e32 v98, 0x7f800000, v98, vcc_lo             // 00000002B260: 02C4C4FF 7F800000
	v_rcp_f32_e32 v63, v107                                    // 00000002B268: 7E7E556B
	v_sub_f32_e32 v111, v111, v118                             // 00000002B26C: 08DEED6F
	v_and_b32_e32 v99, 1, v99                                  // 00000002B270: 36C6C681
	.long 0x7e0039ba                                           // 00000002B274: 7E0039BA
	v_add_f32_e32 v93, 1.0, v98                                // 00000002B278: 06BAC4F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002B27C: BF870214
	v_dual_mul_f32 v98, 0xbfb8aa3b, v94 :: v_dual_add_f32 v111, v111, v117// 00000002B280: C8C8BCFF 626EEB6F BFB8AA3B
	v_add3_u32 v57, v57, v99, 0x7fff                           // 00000002B28C: D6550039 03FEC739 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002B298: BF870214
	v_and_b32_e32 v110, 1, v0                                  // 00000002B29C: 36DC0081
	v_div_scale_f32 v64, null, v93, v93, v60                   // 00000002B2A0: D6FC7C40 04F2BB5D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002B2A8: BF870004
	v_fma_f32 v106, 0xbfb8aa3b, v94, -v98                      // 00000002B2AC: D613006A 858ABCFF BFB8AA3B
	v_rndne_f32_e32 v109, v98                                  // 00000002B2B8: 7EDA4762
	v_fma_f32 v100, -v107, v63, 1.0                            // 00000002B2BC: D6130064 23CA7F6B
	v_add3_u32 v58, v58, v110, 0x7fff                          // 00000002B2C4: D655003A 03FEDD3A 00007FFF
	v_rcp_f32_e32 v101, v64                                    // 00000002B2D0: 7ECA5540
	v_fmac_f32_e32 v106, 0xb2a5705f, v94                       // 00000002B2D4: 56D4BCFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000002B2DC: BF870243
	v_dual_sub_f32 v98, v98, v109 :: v_dual_fmac_f32 v63, v100, v63// 00000002B2E0: C940DB62 623E7F64
	v_div_scale_f32 v100, vcc_lo, v59, v97, v59                // 00000002B2E8: D6FC6A64 04EEC33B
	v_cvt_i32_f32_e32 v109, v109                               // 00000002B2F0: 7EDA116D
	.long 0xd41e0001                                           // 00000002B2F4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v94, vcc_lo              // 00000002B2F8: 0202BCFF 42CE8ED0
	v_add_f32_e32 v98, v98, v106                               // 00000002B300: 06C4D562
	global_store_d16_hi_b16 v[7:8], v57, off offset:256        // 00000002B304: DC960100 007C3907
	v_mul_f32_e32 v106, v100, v63                              // 00000002B30C: 10D47F64
	v_fma_f32 v116, -v64, v101, 1.0                            // 00000002B310: D6130074 23CACB40
	global_store_d16_hi_b16 v[47:48], v58, off offset:256      // 00000002B318: DC960100 007C3A2F
	v_exp_f32_e32 v98, v98                                     // 00000002B320: 7EC44B62
	v_fma_f32 v110, -v107, v106, v100                          // 00000002B324: D613006E 2592D56B
	v_fmac_f32_e32 v101, v116, v101                            // 00000002B32C: 56CACB74
	v_div_scale_f32 v116, s0, v60, v93, v60                    // 00000002B330: D6FC0074 04F2BB3C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002B338: BF870113
	v_fmac_f32_e32 v106, v110, v63                             // 00000002B33C: 56D47F6E
	v_mul_f32_e32 v120, v116, v101                             // 00000002B340: 10F0CB74
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002B344: BF8701A5
	.long 0xd71c0062                                           // 00000002B348: D71C0062
	v_cndmask_b32_e32 v1, v98, v109, vcc_lo                    // 00000002B34C: 0202DB62
	v_exp_f32_e32 v109, v111                                   // 00000002B350: 7EDA4B6F
	v_fma_f32 v100, -v107, v106, v100                          // 00000002B354: D6130064 2592D56B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002B35C: BF870193
	v_fma_f32 v99, -v64, v120, v116                            // 00000002B360: D6130063 25D2F140
	v_cndmask_b32_e64 v98, 0, v98, s1                          // 00000002B368: D5010062 0006C480
	.long 0xd41b0001                                           // 00000002B370: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v94, vcc_lo              // 00000002B374: 0202BCFF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002B37C: BF870004
	v_div_fmas_f32 v63, v100, v63, v106                        // 00000002B380: D637003F 05AA7F64
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 00000002B388: 7C3CCCFF 42CE8ED0
	v_fmac_f32_e32 v120, v99, v101                             // 00000002B390: 56F0CB63
	v_cvt_i32_f32_e32 v99, v118                                // 00000002B394: 7EC61176
	v_cndmask_b32_e64 v94, 0x7f800000, v98, s1                 // 00000002B398: D501005E 0006C4FF 7F800000
	v_div_fixup_f32 v59, v63, v97, v59                         // 00000002B3A4: D627003B 04EEC33F
	v_mul_f32_e32 v106, 0xbfb8aa3b, v96                        // 00000002B3AC: 10D4C0FF BFB8AA3B
	v_fma_f32 v64, -v64, v120, v116                            // 00000002B3B4: D6130040 25D2F140
	.long 0xd71c0062                                           // 00000002B3BC: D71C0062
	v_cndmask_b32_e32 v1, v109, v99, vcc_lo                    // 00000002B3C0: 0202C76D
	v_add_f32_e32 v94, 1.0, v94                                // 00000002B3C4: 06BCBCF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002B3C8: BF870224
	v_fma_f32 v109, 0xbfb8aa3b, v96, -v106                     // 00000002B3CC: D613006D 85AAC0FF BFB8AA3B
	v_rndne_f32_e32 v110, v106                                 // 00000002B3D8: 7EDC476A
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000002B3DC: 02C4C480
	s_mov_b32 vcc_lo, s0                                       // 00000002B3E0: BEEA0000
	v_div_scale_f32 v99, null, v94, v94, v61                   // 00000002B3E4: D6FC7C63 04F6BD5E
	v_div_fmas_f32 v64, v64, v101, v120                        // 00000002B3EC: D6370040 05E2CB40
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 00000002B3F4: 7C36CCFF C2B17218
	v_dual_fmac_f32 v109, 0xb2a5705f, v96 :: v_dual_sub_f32 v106, v106, v110// 00000002B3FC: C80AC0FF 6D6ADD6A B2A5705F
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002B408: BF870003
	v_div_fixup_f32 v57, v64, v93, v60                         // 00000002B40C: D6270039 04F2BB40
	v_cndmask_b32_e32 v98, 0x7f800000, v98, vcc_lo             // 00000002B414: 02C4C4FF 7F800000
	s_waitcnt vmcnt(24)                                        // 00000002B41C: BF8963F7
	v_dual_mul_f32 v60, v113, v62 :: v_dual_lshlrev_b32 v93, 16, v95// 00000002B420: C8E27D71 3C5CBE90
	v_rcp_f32_e32 v62, v99                                     // 00000002B428: 7E7C5563
	.long 0x7e0039b9                                           // 00000002B42C: 7E0039B9
	v_add_f32_e32 v64, 1.0, v98                                // 00000002B430: 0680C4F2
	.long 0x7ebe39bb                                           // 00000002B434: 7EBE39BB
	v_mul_f32_e32 v63, 0xbfb8aa3b, v93                         // 00000002B438: 107EBAFF BFB8AA3B
	.long 0x7fbe3980                                           // 00000002B440: 7FBE3980
	v_and_b32_e32 v102, 1, v0                                  // 00000002B444: 36CC0081
	v_div_scale_f32 v58, null, v64, v64, v60                   // 00000002B448: D6FC7C3A 04F28140
	v_add_f32_e32 v106, v106, v109                             // 00000002B450: 06D4DB6A
	v_fma_f32 v100, 0xbfb8aa3b, v93, -v63                      // 00000002B454: D6130064 84FEBAFF BFB8AA3B
	v_rndne_f32_e32 v101, v63                                  // 00000002B460: 7ECA473F
	v_fma_f32 v97, -v99, v62, 1.0                              // 00000002B464: D6130061 23CA7D63
	v_rcp_f32_e32 v98, v58                                     // 00000002B46C: 7EC4553A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002B470: BF870113
	v_dual_fmac_f32 v100, 0xb2a5705f, v93 :: v_dual_and_b32 v95, 1, v95// 00000002B474: C824BAFF 645EBE81 B2A5705F
	v_dual_sub_f32 v63, v63, v101 :: v_dual_fmac_f32 v62, v97, v62// 00000002B480: C940CB3F 3F3E7D61
	v_div_scale_f32 v97, vcc_lo, v61, v94, v61                 // 00000002B488: D6FC6A61 04F6BD3D
	v_add3_u32 v57, v57, v102, 0x7fff                          // 00000002B490: D6550039 03FECD39 00007FFF
	v_cvt_i32_f32_e32 v101, v101                               // 00000002B49C: 7ECA1165
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000002B4A0: BF8702A4
	v_add_f32_e32 v63, v63, v100                               // 00000002B4A4: 067EC93F
	v_add3_u32 v59, v59, v95, 0x7fff                           // 00000002B4A8: D655003B 03FEBF3B 00007FFF
	v_fma_f32 v107, -v58, v98, 1.0                             // 00000002B4B4: D613006B 23CAC53A
	v_mul_f32_e32 v100, v97, v62                               // 00000002B4BC: 10C87D61
	.long 0xd41e0001                                           // 00000002B4C0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v93, vcc_lo              // 00000002B4C4: 0202BAFF 42CE8ED0
	v_exp_f32_e32 v63, v63                                     // 00000002B4CC: 7E7E4B3F
	global_store_d16_hi_b16 v[15:16], v59, off offset:256      // 00000002B4D0: DC960100 007C3B0F
	v_fmac_f32_e32 v98, v107, v98                              // 00000002B4D8: 56C4C56B
	v_div_scale_f32 v107, s0, v60, v64, v60                    // 00000002B4DC: D6FC006B 04F2813C
	v_fma_f32 v102, -v99, v100, v97                            // 00000002B4E4: D6130066 2586C963
	global_store_d16_hi_b16 v[23:24], v57, off offset:256      // 00000002B4EC: DC960100 007C3917
	v_mul_f32_e32 v111, v107, v98                              // 00000002B4F4: 10DEC56B
	v_fmac_f32_e32 v100, v102, v62                             // 00000002B4F8: 56C87D66
	.long 0xd71c003f                                           // 00000002B4FC: D71C003F
	v_cndmask_b32_e32 v1, v63, v101, vcc_lo                    // 00000002B500: 0202CB3F
	v_exp_f32_e32 v101, v106                                   // 00000002B504: 7ECA4B6A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002B508: BF870193
	v_fma_f32 v95, -v58, v111, v107                            // 00000002B50C: D613005F 25AEDF3A
	v_fma_f32 v97, -v99, v100, v97                             // 00000002B514: D6130061 2586C963
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002B51C: BF870223
	v_cndmask_b32_e64 v63, 0, v63, s1                          // 00000002B520: D501003F 00067E80
	.long 0xd41b0001                                           // 00000002B528: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v93, vcc_lo              // 00000002B52C: 0202BAFF C2B17218
	v_fmac_f32_e32 v111, v95, v98                              // 00000002B534: 56DEC55F
	v_cvt_i32_f32_e32 v95, v110                                // 00000002B538: 7EBE116E
	v_div_fmas_f32 v62, v97, v62, v100                         // 00000002B53C: D637003E 05927D61
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 00000002B544: 7C3CC0FF 42CE8ED0
	v_cndmask_b32_e64 v63, 0x7f800000, v63, s1                 // 00000002B54C: D501003F 00067EFF 7F800000
	v_fma_f32 v58, -v58, v111, v107                            // 00000002B558: D613003A 25AEDF3A
	.long 0xd71c005d                                           // 00000002B560: D71C005D
	v_cndmask_b32_e32 v1, v101, v95, vcc_lo                    // 00000002B564: 0202BF65
	v_div_fixup_f32 v61, v62, v94, v61                         // 00000002B568: D627003D 04F6BD3E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002B570: BF870194
	v_dual_add_f32 v63, 1.0, v63 :: v_dual_lshlrev_b32 v100, 16, v108// 00000002B574: C9227EF2 3F64D890
	v_cndmask_b32_e32 v93, 0, v93, vcc_lo                      // 00000002B57C: 02BABA80
	s_mov_b32 vcc_lo, s0                                       // 00000002B580: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000002B584: BF870242
	v_mul_f32_e32 v101, 0xbfb8aa3b, v100                       // 00000002B588: 10CAC8FF BFB8AA3B
	v_div_fmas_f32 v58, v58, v98, v111                         // 00000002B590: D637003A 05BEC53A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 00000002B598: 7C36C0FF C2B17218
	v_div_scale_f32 v95, null, v63, v63, v49                   // 00000002B5A0: D6FC7C5F 04C67F3F
	v_rndne_f32_e32 v106, v101                                 // 00000002B5A8: 7ED44765
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002B5AC: BF870004
	v_div_fixup_f32 v58, v58, v64, v60                         // 00000002B5B0: D627003A 04F2813A
	v_cndmask_b32_e32 v93, 0x7f800000, v93, vcc_lo             // 00000002B5B8: 02BABAFF 7F800000
	v_lshlrev_b32_e32 v64, 16, v105                            // 00000002B5C0: 3080D290
	v_rcp_f32_e32 v59, v95                                     // 00000002B5C4: 7E76555F
	v_fma_f32 v105, 0xbfb8aa3b, v100, -v101                    // 00000002B5C8: D6130069 8596C8FF BFB8AA3B
	.long 0x7e0039ba                                           // 00000002B5D4: 7E0039BA
	v_add_f32_e32 v60, 1.0, v93                                // 00000002B5D8: 0678BAF2
	v_mul_f32_e32 v62, 0xbfb8aa3b, v64                         // 00000002B5DC: 107C80FF BFB8AA3B
	.long 0x7eba39bd                                           // 00000002B5E4: 7EBA39BD
	.long 0x7fba3980                                           // 00000002B5E8: 7FBA3980
	v_and_b32_e32 v99, 1, v0                                   // 00000002B5EC: 36C60081
	v_div_scale_f32 v57, null, v60, v60, v50                   // 00000002B5F0: D6FC7C39 04CA793C
	v_fma_f32 v97, 0xbfb8aa3b, v64, -v62                       // 00000002B5F8: D6130061 84FA80FF BFB8AA3B
	v_rndne_f32_e32 v98, v62                                   // 00000002B604: 7EC4473E
	v_fma_f32 v94, -v95, v59, 1.0                              // 00000002B608: D613005E 23CA775F
	v_fmac_f32_e32 v105, 0xb2a5705f, v100                      // 00000002B610: 56D2C8FF B2A5705F
	v_rcp_f32_e32 v96, v57                                     // 00000002B618: 7EC05539
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002B61C: BF870193
	v_dual_fmac_f32 v97, 0xb2a5705f, v64 :: v_dual_sub_f32 v62, v62, v98// 00000002B620: C80A80FF 613EC53E B2A5705F
	v_fmac_f32_e32 v59, v94, v59                               // 00000002B62C: 5676775E
	v_div_scale_f32 v94, vcc_lo, v49, v63, v49                 // 00000002B630: D6FC6A5E 04C67F31
	v_sub_f32_e32 v101, v101, v106                             // 00000002B638: 08CAD565
	v_and_b32_e32 v93, 1, v93                                  // 00000002B63C: 36BABA81
	v_add_f32_e32 v62, v62, v97                                // 00000002B640: 067CC33E
	v_add3_u32 v58, v58, v99, 0x7fff                           // 00000002B644: D655003A 03FEC73A 00007FFF
	v_mul_f32_e32 v97, v94, v59                                // 00000002B650: 10C2775E
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000002B654: BF870005
	v_fma_f32 v102, -v57, v96, 1.0                             // 00000002B658: D6130066 23CAC139
	v_cvt_i32_f32_e32 v98, v98                                 // 00000002B660: 7EC41162
	v_exp_f32_e32 v62, v62                                     // 00000002B664: 7E7C4B3E
	v_add_f32_e32 v101, v101, v105                             // 00000002B668: 06CAD365
	v_fma_f32 v99, -v95, v97, v94                              // 00000002B66C: D6130063 257AC35F
	v_fmac_f32_e32 v96, v102, v96                              // 00000002B674: 56C0C166
	v_div_scale_f32 v102, s0, v50, v60, v50                    // 00000002B678: D6FC0066 04CA7932
	v_add3_u32 v61, v61, v93, 0x7fff                           // 00000002B680: D655003D 03FEBB3D 00007FFF
	.long 0xd41e0001                                           // 00000002B68C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v64, vcc_lo              // 00000002B690: 020280FF 42CE8ED0
	v_fmac_f32_e32 v97, v99, v59                               // 00000002B698: 56C27763
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002B69C: BF870294
	v_mul_f32_e32 v107, v102, v96                              // 00000002B6A0: 10D6C166
	.long 0xd71c003e                                           // 00000002B6A4: D71C003E
	v_cndmask_b32_e32 v1, v62, v98, vcc_lo                     // 00000002B6A8: 0202C53E
	v_exp_f32_e32 v98, v101                                    // 00000002B6AC: 7EC44B65
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002B6B0: BF870003
	v_fma_f32 v94, -v95, v97, v94                              // 00000002B6B4: D613005E 257AC35F
	global_store_d16_hi_b16 v[31:32], v61, off offset:256      // 00000002B6BC: DC960100 007C3D1F
	v_fma_f32 v93, -v57, v107, v102                            // 00000002B6C4: D613005D 259AD739
	v_cndmask_b32_e64 v62, 0, v62, s1                          // 00000002B6CC: D501003E 00067C80
	.long 0xd41b0001                                           // 00000002B6D4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v64, vcc_lo              // 00000002B6D8: 020280FF C2B17218
	v_div_fmas_f32 v59, v94, v59, v97                          // 00000002B6E0: D637003B 0586775E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 00000002B6E8: 7C3CC8FF 42CE8ED0
	v_fmac_f32_e32 v107, v93, v96                              // 00000002B6F0: 56D6C15D
	v_cvt_i32_f32_e32 v93, v106                                // 00000002B6F4: 7EBA116A
	v_cndmask_b32_e64 v62, 0x7f800000, v62, s1                 // 00000002B6F8: D501003E 00067CFF 7F800000
	s_waitcnt vmcnt(23)                                        // 00000002B704: BF895FF7
	v_lshlrev_b32_e32 v61, 16, v115                            // 00000002B708: 307AE690
	v_div_fixup_f32 v49, v59, v63, v49                         // 00000002B70C: D6270031 04C67F3B
	v_fma_f32 v57, -v57, v107, v102                            // 00000002B714: D6130039 259AD739
	.long 0xd71c0040                                           // 00000002B71C: D71C0040
	v_cndmask_b32_e32 v1, v98, v93, vcc_lo                     // 00000002B720: 0202BB62
	v_add_f32_e32 v62, 1.0, v62                                // 00000002B724: 067C7CF2
	global_store_d16_hi_b16 v[39:40], v58, off offset:256      // 00000002B728: DC960100 007C3A27
	s_waitcnt vmcnt(17)                                        // 00000002B730: BF8947F7
	v_dual_mul_f32 v59, 0xbfb8aa3b, v61 :: v_dual_lshlrev_b32 v98, 16, v119// 00000002B734: C8E27AFF 3B62EE90 BFB8AA3B
	v_cndmask_b32_e32 v64, 0, v64, vcc_lo                      // 00000002B740: 02808080
	s_mov_b32 vcc_lo, s0                                       // 00000002B744: BEEA0000
	v_div_scale_f32 v93, null, v62, v62, v51                   // 00000002B748: D6FC7C5D 04CE7D3E
	v_div_fmas_f32 v57, v57, v96, v107                         // 00000002B750: D6370039 05AEC139
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 00000002B758: 7C36C8FF C2B17218
	v_fma_f32 v95, 0xbfb8aa3b, v61, -v59                       // 00000002B760: D613005F 84EE7AFF BFB8AA3B
	v_rndne_f32_e32 v96, v59                                   // 00000002B76C: 7EC0473B
	v_mul_f32_e32 v99, 0xbfb8aa3b, v98                         // 00000002B770: 10C6C4FF BFB8AA3B
	v_div_fixup_f32 v50, v57, v60, v50                         // 00000002B778: D6270032 04CA7939
	v_cndmask_b32_e32 v64, 0x7f800000, v64, vcc_lo             // 00000002B780: 028080FF 7F800000
	v_rcp_f32_e32 v57, v93                                     // 00000002B788: 7E72555D
	v_fmac_f32_e32 v95, 0xb2a5705f, v61                        // 00000002B78C: 56BE7AFF B2A5705F
	v_sub_f32_e32 v59, v59, v96                                // 00000002B794: 0876C13B
	.long 0x7e0039b2                                           // 00000002B798: 7E0039B2
	v_add_f32_e32 v60, 1.0, v64                                // 00000002B79C: 067880F2
	v_fma_f32 v101, 0xbfb8aa3b, v98, -v99                      // 00000002B7A0: D6130065 858EC4FF BFB8AA3B
	v_rndne_f32_e32 v102, v99                                  // 00000002B7AC: 7ECC4763
	v_add_f32_e32 v59, v59, v95                                // 00000002B7B0: 0676BF3B
	.long 0x7e7e39b1                                           // 00000002B7B4: 7E7E39B1
	v_div_scale_f32 v58, null, v60, v60, v52                   // 00000002B7B8: D6FC7C3A 04D2793C
	v_fma_f32 v64, -v93, v57, 1.0                              // 00000002B7C0: D6130040 23CA735D
	.long 0x7f7e3980                                           // 00000002B7C8: 7F7E3980
	v_and_b32_e32 v97, 1, v0                                   // 00000002B7CC: 36C20081
	v_exp_f32_e32 v59, v59                                     // 00000002B7D0: 7E764B3B
	v_rcp_f32_e32 v94, v58                                     // 00000002B7D4: 7EBC553A
	v_fmac_f32_e32 v57, v64, v57                               // 00000002B7D8: 56727340
	v_div_scale_f32 v64, vcc_lo, v51, v62, v51                 // 00000002B7DC: D6FC6A40 04CE7D33
	v_fmac_f32_e32 v101, 0xb2a5705f, v98                       // 00000002B7E4: 56CAC4FF B2A5705F
	v_sub_f32_e32 v99, v99, v102                               // 00000002B7EC: 08C6CD63
	v_and_b32_e32 v63, 1, v63                                  // 00000002B7F0: 367E7E81
	v_add3_u32 v50, v50, v97, 0x7fff                           // 00000002B7F4: D6550032 03FEC332 00007FFF
	v_mul_f32_e32 v95, v64, v57                                // 00000002B800: 10BE7340
	v_cvt_i32_f32_e32 v96, v96                                 // 00000002B804: 7EC01160
	v_add_f32_e32 v99, v99, v101                               // 00000002B808: 06C6CB63
	v_fma_f32 v100, -v58, v94, 1.0                             // 00000002B80C: D6130064 23CABD3A
	v_add3_u32 v49, v49, v63, 0x7fff                           // 00000002B814: D6550031 03FE7F31 00007FFF
	v_fma_f32 v97, -v93, v95, v64                              // 00000002B820: D6130061 2502BF5D
	.long 0xd71c003b                                           // 00000002B828: D71C003B
	v_cndmask_b32_e32 v1, v59, v96, vcc_lo                     // 00000002B82C: 0202C13B
	v_exp_f32_e32 v96, v99                                     // 00000002B830: 7EC04B63
	v_fmac_f32_e32 v94, v100, v94                              // 00000002B834: 56BCBD64
	v_div_scale_f32 v100, s0, v52, v60, v52                    // 00000002B838: D6FC0064 04D27934
	v_fmac_f32_e32 v95, v97, v57                               // 00000002B840: 56BE7361
	.long 0xd41e0001                                           // 00000002B844: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v61, vcc_lo              // 00000002B848: 02027AFF 42CE8ED0
	s_clause 0x1                                               // 00000002B850: BF850001
	global_store_d16_hi_b16 v[7:8], v49, off offset:288        // 00000002B854: DC960120 007C3107
	global_store_d16_hi_b16 v[47:48], v50, off offset:288      // 00000002B85C: DC960120 007C322F
	v_mul_f32_e32 v105, v100, v94                              // 00000002B864: 10D2BD64
	v_fma_f32 v64, -v93, v95, v64                              // 00000002B868: D6130040 2502BF5D
	v_cndmask_b32_e64 v59, 0, v59, s1                          // 00000002B870: D501003B 00067680
	.long 0xd41b0001                                           // 00000002B878: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v61, vcc_lo              // 00000002B87C: 02027AFF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002B884: BF870214
	v_fma_f32 v63, -v58, v105, v100                            // 00000002B888: D613003F 2592D33A
	v_div_fmas_f32 v57, v64, v57, v95                          // 00000002B890: D6370039 057E7340
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v98                  // 00000002B898: 7C3CC4FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002B8A0: BF870214
	v_cndmask_b32_e64 v59, 0x7f800000, v59, s1                 // 00000002B8A4: D501003B 000676FF 7F800000
	v_fmac_f32_e32 v105, v63, v94                              // 00000002B8B0: 56D2BD3F
	v_cvt_i32_f32_e32 v63, v102                                // 00000002B8B4: 7E7E1166
	v_div_fixup_f32 v51, v57, v62, v51                         // 00000002B8B8: D6270033 04CE7D39
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002B8C0: BF870214
	v_add_f32_e32 v59, 1.0, v59                                // 00000002B8C4: 067676F2
	v_fma_f32 v58, -v58, v105, v100                            // 00000002B8C8: D613003A 2592D33A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000002B8D0: BF8701C4
	.long 0xd71c003d                                           // 00000002B8D4: D71C003D
	v_cndmask_b32_e32 v1, v96, v63, vcc_lo                     // 00000002B8D8: 02027F60
	s_waitcnt vmcnt(5)                                         // 00000002B8DC: BF8917F7
	v_lshlrev_b32_e32 v96, 16, v126                            // 00000002B8E0: 30C0FC90
	v_div_scale_f32 v63, null, v59, v59, v53                   // 00000002B8E4: D6FC7C3F 04D6773B
	v_cndmask_b32_e32 v61, 0, v61, vcc_lo                      // 00000002B8EC: 027A7A80
	s_mov_b32 vcc_lo, s0                                       // 00000002B8F0: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002B8F4: BF8701B3
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 00000002B8F8: 10C2C0FF BFB8AA3B
	v_div_fmas_f32 v58, v58, v94, v105                         // 00000002B900: D637003A 05A6BD3A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v98                  // 00000002B908: 7C36C4FF C2B17218
	v_fma_f32 v99, 0xbfb8aa3b, v96, -v97                       // 00000002B910: D6130063 8586C0FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000002B91C: BF8701C3
	v_div_fixup_f32 v49, v58, v60, v52                         // 00000002B920: D6270031 04D2793A
	v_dual_cndmask_b32 v61, 0x7f800000, v61 :: v_dual_mul_f32 v52, v113, v54// 00000002B928: CA467AFF 3D346D71 7F800000
	v_lshlrev_b32_e32 v60, 16, v112                            // 00000002B934: 3078E090
	v_rcp_f32_e32 v54, v63                                     // 00000002B938: 7E6C553F
	.long 0x7e0039b1                                           // 00000002B93C: 7E0039B1
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002B940: BF870003
	v_add_f32_e32 v58, 1.0, v61                                // 00000002B944: 06747AF2
	v_rndne_f32_e32 v100, v97                                  // 00000002B948: 7EC84761
	v_mul_f32_e32 v57, 0xbfb8aa3b, v60                         // 00000002B94C: 107278FF BFB8AA3B
	.long 0x7e7a39b3                                           // 00000002B954: 7E7A39B3
	.long 0x7f7a3980                                           // 00000002B958: 7F7A3980
	v_div_scale_f32 v50, null, v58, v58, v52                   // 00000002B95C: D6FC7C32 04D2753A
	v_and_b32_e32 v95, 1, v0                                   // 00000002B964: 36BE0081
	v_fma_f32 v93, 0xbfb8aa3b, v60, -v57                       // 00000002B968: D613005D 84E678FF BFB8AA3B
	v_rndne_f32_e32 v94, v57                                   // 00000002B974: 7EBC4739
	v_fma_f32 v62, -v63, v54, 1.0                              // 00000002B978: D613003E 23CA6D3F
	v_rcp_f32_e32 v64, v50                                     // 00000002B980: 7E805532
	v_fmac_f32_e32 v99, 0xb2a5705f, v96                        // 00000002B984: 56C6C0FF B2A5705F
	v_fmac_f32_e32 v93, 0xb2a5705f, v60                        // 00000002B98C: 56BA78FF B2A5705F
	v_sub_f32_e32 v57, v57, v94                                // 00000002B994: 0872BD39
	v_fmac_f32_e32 v54, v62, v54                               // 00000002B998: 566C6D3E
	v_div_scale_f32 v62, vcc_lo, v53, v59, v53                 // 00000002B99C: D6FC6A3E 04D67735
	v_sub_f32_e32 v97, v97, v100                               // 00000002B9A4: 08C2C961
	v_and_b32_e32 v61, 1, v61                                  // 00000002B9A8: 367A7A81
	v_add_f32_e32 v57, v57, v93                                // 00000002B9AC: 0672BB39
	v_add3_u32 v49, v49, v95, 0x7fff                           // 00000002B9B0: D6550031 03FEBF31 00007FFF
	v_fma_f32 v98, -v50, v64, 1.0                              // 00000002B9BC: D6130062 23CA8132
	v_mul_f32_e32 v93, v62, v54                                // 00000002B9C4: 10BA6D3E
	v_cvt_i32_f32_e32 v94, v94                                 // 00000002B9C8: 7EBC115E
	v_exp_f32_e32 v57, v57                                     // 00000002B9CC: 7E724B39
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000002B9D0: BF870253
	v_dual_add_f32 v97, v97, v99 :: v_dual_fmac_f32 v64, v98, v64// 00000002B9D4: C900C761 61408162
	v_div_scale_f32 v98, s0, v52, v58, v52                     // 00000002B9DC: D6FC0062 04D27534
	v_fma_f32 v95, -v63, v93, v62                              // 00000002B9E4: D613005F 24FABB3F
	v_add3_u32 v51, v51, v61, 0x7fff                           // 00000002B9EC: D6550033 03FE7B33 00007FFF
	.long 0xd41e0001                                           // 00000002B9F8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v60, vcc_lo              // 00000002B9FC: 020278FF 42CE8ED0
	v_mul_f32_e32 v101, v98, v64                               // 00000002BA04: 10CA8162
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002BA08: BF870294
	v_fmac_f32_e32 v93, v95, v54                               // 00000002BA0C: 56BA6D5F
	.long 0xd71c0039                                           // 00000002BA10: D71C0039
	v_cndmask_b32_e32 v1, v57, v94, vcc_lo                     // 00000002BA14: 0202BD39
	v_exp_f32_e32 v94, v97                                     // 00000002BA18: 7EBC4B61
	global_store_d16_hi_b16 v[15:16], v51, off offset:288      // 00000002BA1C: DC960120 007C330F
	v_fma_f32 v61, -v50, v101, v98                             // 00000002BA24: D613003D 258ACB32
	v_fma_f32 v62, -v63, v93, v62                              // 00000002BA2C: D613003E 24FABB3F
	v_cndmask_b32_e64 v57, 0, v57, s1                          // 00000002BA34: D5010039 00067280
	.long 0xd41b0001                                           // 00000002BA3C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v60, vcc_lo              // 00000002BA40: 020278FF C2B17218
	global_store_d16_hi_b16 v[23:24], v49, off offset:288      // 00000002BA48: DC960120 007C3117
	v_fmac_f32_e32 v101, v61, v64                              // 00000002BA50: 56CA813D
	v_cvt_i32_f32_e32 v61, v100                                // 00000002BA54: 7E7A1164
	v_div_fmas_f32 v54, v62, v54, v93                          // 00000002BA58: D6370036 05766D3E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 00000002BA60: 7C3CC0FF 42CE8ED0
	v_cndmask_b32_e64 v57, 0x7f800000, v57, s1                 // 00000002BA68: D5010039 000672FF 7F800000
	v_fma_f32 v50, -v50, v101, v98                             // 00000002BA74: D6130032 258ACB32
	.long 0xd71c003c                                           // 00000002BA7C: D71C003C
	v_cndmask_b32_e32 v1, v94, v61, vcc_lo                     // 00000002BA80: 02027B5E
	v_div_fixup_f32 v53, v54, v59, v53                         // 00000002BA84: D6270035 04D67736
	v_mul_f32_e32 v93, 0xbfb8aa3b, v89                         // 00000002BA8C: 10BAB2FF BFB8AA3B
	v_add_f32_e32 v57, 1.0, v57                                // 00000002BA94: 067272F2
	.long 0x7f763980                                           // 00000002BA98: 7F763980
	v_cndmask_b32_e32 v60, 0, v60, vcc_lo                      // 00000002BA9C: 02787880
	s_mov_b32 vcc_lo, s0                                       // 00000002BAA0: BEEA0000
	v_fma_f32 v95, 0xbfb8aa3b, v89, -v93                       // 00000002BAA4: D613005F 8576B2FF BFB8AA3B
	v_div_fmas_f32 v50, v50, v64, v101                         // 00000002BAB0: D6370032 05968132
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 00000002BAB8: 7C36C0FF C2B17218
	v_div_scale_f32 v61, null, v57, v57, v41                   // 00000002BAC0: D6FC7C3D 04A67339
	v_rndne_f32_e32 v96, v93                                   // 00000002BAC8: 7EC0475D
	.long 0x7e7639b5                                           // 00000002BACC: 7E7639B5
	v_div_fixup_f32 v50, v50, v58, v52                         // 00000002BAD0: D6270032 04D27532
	v_cndmask_b32_e32 v60, 0x7f800000, v60, vcc_lo             // 00000002BAD8: 027878FF 7F800000
	v_lshlrev_b32_e32 v58, 16, v90                             // 00000002BAE0: 3074B490
	v_rcp_f32_e32 v51, v61                                     // 00000002BAE4: 7E66553D
	v_fmac_f32_e32 v95, 0xb2a5705f, v89                        // 00000002BAE8: 56BEB2FF B2A5705F
	.long 0x7e0039b2                                           // 00000002BAF0: 7E0039B2
	v_add_f32_e32 v52, 1.0, v60                                // 00000002BAF4: 066878F2
	v_dual_mul_f32 v54, 0xbfb8aa3b, v58 :: v_dual_sub_f32 v93, v93, v96// 00000002BAF8: C8CA74FF 365CC15D BFB8AA3B
	v_and_b32_e32 v59, 1, v59                                  // 00000002BB04: 36767681
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002BB08: BF870214
	v_and_b32_e32 v90, 1, v0                                   // 00000002BB0C: 36B40081
	v_div_scale_f32 v49, null, v52, v52, v42                   // 00000002BB10: D6FC7C31 04AA6934
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000002BB18: BF8701D4
	v_fma_f32 v63, 0xbfb8aa3b, v58, -v54                       // 00000002BB1C: D613003F 84DA74FF BFB8AA3B
	v_rndne_f32_e32 v64, v54                                   // 00000002BB28: 7E804736
	v_fma_f32 v60, -v61, v51, 1.0                              // 00000002BB2C: D613003C 23CA673D
	v_add3_u32 v50, v50, v90, 0x7fff                           // 00000002BB34: D6550032 03FEB532 00007FFF
	v_rcp_f32_e32 v62, v49                                     // 00000002BB40: 7E7C5531
	v_dual_fmac_f32 v63, 0xb2a5705f, v58 :: v_dual_sub_f32 v54, v54, v64// 00000002BB44: C80A74FF 3F368136 B2A5705F
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002BB50: BF870003
	v_fmac_f32_e32 v51, v60, v51                               // 00000002BB54: 5666673C
	v_div_scale_f32 v60, vcc_lo, v41, v57, v41                 // 00000002BB58: D6FC6A3C 04A67329
	v_cvt_i32_f32_e32 v64, v64                                 // 00000002BB60: 7E801140
	v_add_f32_e32 v93, v93, v95                                // 00000002BB64: 06BABF5D
	v_add_f32_e32 v54, v54, v63                                // 00000002BB68: 066C7F36
	v_add3_u32 v53, v53, v59, 0x7fff                           // 00000002BB6C: D6550035 03FE7735 00007FFF
	v_mul_f32_e32 v63, v60, v51                                // 00000002BB78: 107E673C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000002BB7C: BF870005
	v_fma_f32 v94, -v49, v62, 1.0                              // 00000002BB80: D613005E 23CA7D31
	.long 0xd41e0001                                           // 00000002BB88: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v58, vcc_lo              // 00000002BB8C: 020274FF 42CE8ED0
	v_exp_f32_e32 v54, v54                                     // 00000002BB94: 7E6C4B36
	global_store_d16_hi_b16 v[31:32], v53, off offset:288      // 00000002BB98: DC960120 007C351F
	v_fma_f32 v90, -v61, v63, v60                              // 00000002BBA0: D613005A 24F27F3D
	v_fmac_f32_e32 v62, v94, v62                               // 00000002BBA8: 567C7D5E
	v_div_scale_f32 v94, s0, v42, v52, v42                     // 00000002BBAC: D6FC005E 04AA692A
	v_lshlrev_b32_e32 v53, 16, v91                             // 00000002BBB4: 306AB690
	global_store_d16_hi_b16 v[39:40], v50, off offset:288      // 00000002BBB8: DC960120 007C3227
	v_fmac_f32_e32 v63, v90, v51                               // 00000002BBC0: 567E675A
	v_mul_f32_e32 v97, v94, v62                                // 00000002BBC4: 10C27D5E
	.long 0xd71c0036                                           // 00000002BBC8: D71C0036
	v_cndmask_b32_e32 v1, v54, v64, vcc_lo                     // 00000002BBCC: 02028136
	v_exp_f32_e32 v64, v93                                     // 00000002BBD0: 7E804B5D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002BBD4: BF870193
	v_fma_f32 v60, -v61, v63, v60                              // 00000002BBD8: D613003C 24F27F3D
	v_fma_f32 v59, -v49, v97, v94                              // 00000002BBE0: D613003B 257AC331
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002BBE8: BF870223
	v_cndmask_b32_e64 v54, 0, v54, s1                          // 00000002BBEC: D5010036 00066C80
	.long 0xd41b0001                                           // 00000002BBF4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v58, vcc_lo              // 00000002BBF8: 020274FF C2B17218
	v_div_fmas_f32 v51, v60, v51, v63                          // 00000002BC00: D6370033 04FE673C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000002BC08: 7C3CB2FF 42CE8ED0
	v_fmac_f32_e32 v97, v59, v62                               // 00000002BC10: 56C27D3B
	v_cvt_i32_f32_e32 v59, v96                                 // 00000002BC14: 7E761160
	v_cndmask_b32_e64 v54, 0x7f800000, v54, s1                 // 00000002BC18: D5010036 00066CFF 7F800000
	v_div_fixup_f32 v41, v51, v57, v41                         // 00000002BC24: D6270029 04A67333
	v_mul_f32_e32 v51, 0xbfb8aa3b, v53                         // 00000002BC2C: 10666AFF BFB8AA3B
	v_fma_f32 v49, -v49, v97, v94                              // 00000002BC34: D6130031 257AC331
	.long 0xd71c003a                                           // 00000002BC3C: D71C003A
	v_cndmask_b32_e32 v1, v64, v59, vcc_lo                     // 00000002BC40: 02027740
	v_add_f32_e32 v54, 1.0, v54                                // 00000002BC44: 066C6CF2
	v_lshlrev_b32_e32 v64, 16, v87                             // 00000002BC48: 3080AE90
	v_fma_f32 v61, 0xbfb8aa3b, v53, -v51                       // 00000002BC4C: D613003D 84CE6AFF BFB8AA3B
	.long 0x7e7239a9                                           // 00000002BC58: 7E7239A9
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000002BC5C: 02747480
	s_mov_b32 vcc_lo, s0                                       // 00000002BC60: BEEA0000
	v_div_scale_f32 v59, null, v54, v54, v43                   // 00000002BC64: D6FC7C3B 04AE6D36
	v_div_fmas_f32 v49, v49, v62, v97                          // 00000002BC6C: D6370031 05867D31
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000002BC74: 7C36B2FF C2B17218
	v_rndne_f32_e32 v62, v51                                   // 00000002BC7C: 7E7C4733
	v_fmac_f32_e32 v61, 0xb2a5705f, v53                        // 00000002BC80: 567A6AFF B2A5705F
	v_mul_f32_e32 v87, 0xbfb8aa3b, v64                         // 00000002BC88: 10AE80FF BFB8AA3B
	v_div_fixup_f32 v42, v49, v52, v42                         // 00000002BC90: D627002A 04AA6931
	v_cndmask_b32_e32 v58, 0x7f800000, v58, vcc_lo             // 00000002BC98: 027474FF 7F800000
	v_rcp_f32_e32 v49, v59                                     // 00000002BCA0: 7E62553B
	v_sub_f32_e32 v51, v51, v62                                // 00000002BCA4: 08667D33
	v_fma_f32 v90, 0xbfb8aa3b, v64, -v87                       // 00000002BCA8: D613005A 855E80FF BFB8AA3B
	.long 0x7e0039aa                                           // 00000002BCB4: 7E0039AA
	v_add_f32_e32 v52, 1.0, v58                                // 00000002BCB8: 066874F2
	v_rndne_f32_e32 v91, v87                                   // 00000002BCBC: 7EB64757
	v_add_f32_e32 v51, v51, v61                                // 00000002BCC0: 06667B33
	.long 0x7f723980                                           // 00000002BCC4: 7F723980
	v_and_b32_e32 v63, 1, v0                                   // 00000002BCC8: 367E0081
	v_div_scale_f32 v50, null, v52, v52, v44                   // 00000002BCCC: D6FC7C32 04B26934
	v_fma_f32 v58, -v59, v49, 1.0                              // 00000002BCD4: D613003A 23CA633B
	v_exp_f32_e32 v51, v51                                     // 00000002BCDC: 7E664B33
	v_dual_fmac_f32 v90, 0xb2a5705f, v64 :: v_dual_sub_f32 v87, v87, v91// 00000002BCE0: C80A80FF 5A56B757 B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002BCEC: BF870113
	v_rcp_f32_e32 v60, v50                                     // 00000002BCF0: 7E785532
	v_fmac_f32_e32 v49, v58, v49                               // 00000002BCF4: 5662633A
	v_div_scale_f32 v58, vcc_lo, v43, v54, v43                 // 00000002BCF8: D6FC6A3A 04AE6D2B
	v_and_b32_e32 v57, 1, v57                                  // 00000002BD00: 36727281
	v_add3_u32 v42, v42, v63, 0x7fff                           // 00000002BD04: D655002A 03FE7F2A 00007FFF
	v_cvt_i32_f32_e32 v62, v62                                 // 00000002BD10: 7E7C113E
	v_add_f32_e32 v87, v87, v90                                // 00000002BD14: 06AEB557
	v_mul_f32_e32 v61, v58, v49                                // 00000002BD18: 107A633A
	v_add3_u32 v41, v41, v57, 0x7fff                           // 00000002BD1C: D6550029 03FE7329 00007FFF
	.long 0xd41e0001                                           // 00000002BD28: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v53, vcc_lo              // 00000002BD2C: 02026AFF 42CE8ED0
	v_fma_f32 v89, -v50, v60, 1.0                              // 00000002BD34: D6130059 23CA7932
	.long 0xd71c0033                                           // 00000002BD3C: D71C0033
	v_cndmask_b32_e32 v1, v51, v62, vcc_lo                     // 00000002BD40: 02027D33
	v_fma_f32 v63, -v59, v61, v58                              // 00000002BD44: D613003F 24EA7B3B
	v_exp_f32_e32 v62, v87                                     // 00000002BD4C: 7E7C4B57
	global_store_d16_hi_b16 v[7:8], v41, off offset:320        // 00000002BD50: DC960140 007C2907
	v_fmac_f32_e32 v60, v89, v60                               // 00000002BD58: 56787959
	v_div_scale_f32 v89, s0, v44, v52, v44                     // 00000002BD5C: D6FC0059 04B2692C
	v_fmac_f32_e32 v61, v63, v49                               // 00000002BD64: 567A633F
	v_cndmask_b32_e64 v51, 0, v51, s1                          // 00000002BD68: D5010033 00066680
	.long 0xd41b0001                                           // 00000002BD70: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v53, vcc_lo              // 00000002BD74: 02026AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v42, off offset:320      // 00000002BD7C: DC960140 007C2A2F
	v_mul_f32_e32 v93, v89, v60                                // 00000002BD84: 10BA7959
	v_fma_f32 v58, -v59, v61, v58                              // 00000002BD88: D613003A 24EA7B3B
	v_cndmask_b32_e64 v51, 0x7f800000, v51, s1                 // 00000002BD90: D5010033 000666FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002BD9C: BF870193
	v_fma_f32 v57, -v50, v93, v89                              // 00000002BDA0: D6130039 2566BB32
	v_div_fmas_f32 v49, v58, v49, v61                          // 00000002BDA8: D6370031 04F6633A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000002BDB0: 7C3C80FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002BDB8: BF870214
	v_add_f32_e32 v51, 1.0, v51                                // 00000002BDBC: 066666F2
	v_fmac_f32_e32 v93, v57, v60                               // 00000002BDC0: 56BA7939
	v_cvt_i32_f32_e32 v57, v91                                 // 00000002BDC4: 7E72115B
	v_div_fixup_f32 v43, v49, v54, v43                         // 00000002BDC8: D627002B 04AE6D31
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002BDD0: BF870193
	v_fma_f32 v50, -v50, v93, v89                              // 00000002BDD4: D6130032 2566BB32
	.long 0xd71c0035                                           // 00000002BDDC: D71C0035
	v_cndmask_b32_e32 v1, v62, v57, vcc_lo                     // 00000002BDE0: 0202733E
	v_div_scale_f32 v57, null, v51, v51, v45                   // 00000002BDE4: D6FC7C39 04B66733
	s_waitcnt vmcnt(4)                                         // 00000002BDEC: BF8913F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002BDF0: BF8700A2
	v_dual_cndmask_b32 v53, 0, v53 :: v_dual_lshlrev_b32 v62, 16, v92// 00000002BDF4: CA626A80 353EB890
	s_mov_b32 vcc_lo, s0                                       // 00000002BDFC: BEEA0000
	v_mul_f32_e32 v63, 0xbfb8aa3b, v62                         // 00000002BE00: 107E7CFF BFB8AA3B
	v_div_fmas_f32 v50, v50, v60, v93                          // 00000002BE08: D6370032 05767932
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000002BE10: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002BE18: BF870193
	v_fma_f32 v87, 0xbfb8aa3b, v62, -v63                       // 00000002BE1C: D6130057 84FE7CFF BFB8AA3B
	v_div_fixup_f32 v41, v50, v52, v44                         // 00000002BE28: D6270029 04B26932
	v_dual_cndmask_b32 v53, 0x7f800000, v53 :: v_dual_mul_f32 v44, v113, v46// 00000002BE30: CA466AFF 352C5D71 7F800000
	v_lshlrev_b32_e32 v52, 16, v88                             // 00000002BE3C: 3068B090
	v_rcp_f32_e32 v46, v57                                     // 00000002BE40: 7E5C5539
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002BE44: BF870193
	.long 0x7e0039a9                                           // 00000002BE48: 7E0039A9
	v_add_f32_e32 v50, 1.0, v53                                // 00000002BE4C: 06646AF2
	v_rndne_f32_e32 v88, v63                                   // 00000002BE50: 7EB0473F
	v_mul_f32_e32 v49, 0xbfb8aa3b, v52                         // 00000002BE54: 106268FF BFB8AA3B
	.long 0x7e6a39ab                                           // 00000002BE5C: 7E6A39AB
	.long 0x7f6a3980                                           // 00000002BE60: 7F6A3980
	v_div_scale_f32 v42, null, v50, v50, v44                   // 00000002BE64: D6FC7C2A 04B26532
	v_and_b32_e32 v61, 1, v0                                   // 00000002BE6C: 367A0081
	v_fma_f32 v59, 0xbfb8aa3b, v52, -v49                       // 00000002BE70: D613003B 84C668FF BFB8AA3B
	v_rndne_f32_e32 v60, v49                                   // 00000002BE7C: 7E784731
	v_fma_f32 v54, -v57, v46, 1.0                              // 00000002BE80: D6130036 23CA5D39
	v_rcp_f32_e32 v58, v42                                     // 00000002BE88: 7E74552A
	v_fmac_f32_e32 v87, 0xb2a5705f, v62                        // 00000002BE8C: 56AE7CFF B2A5705F
	v_fmac_f32_e32 v59, 0xb2a5705f, v52                        // 00000002BE94: 567668FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000002BE9C: BF870243
	v_dual_sub_f32 v49, v49, v60 :: v_dual_fmac_f32 v46, v54, v46// 00000002BEA0: C9407931 312E5D36
	v_div_scale_f32 v54, vcc_lo, v45, v51, v45                 // 00000002BEA8: D6FC6A36 04B6672D
	v_sub_f32_e32 v63, v63, v88                                // 00000002BEB0: 087EB13F
	v_and_b32_e32 v53, 1, v53                                  // 00000002BEB4: 366A6A81
	v_add_f32_e32 v49, v49, v59                                // 00000002BEB8: 06627731
	v_add3_u32 v41, v41, v61, 0x7fff                           // 00000002BEBC: D6550029 03FE7B29 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000002BEC8: BF8701C5
	v_fma_f32 v64, -v42, v58, 1.0                              // 00000002BECC: D6130040 23CA752A
	v_mul_f32_e32 v59, v54, v46                                // 00000002BED4: 10765D36
	v_cvt_i32_f32_e32 v60, v60                                 // 00000002BED8: 7E78113C
	v_exp_f32_e32 v49, v49                                     // 00000002BEDC: 7E624B31
	v_dual_add_f32 v63, v63, v87 :: v_dual_fmac_f32 v58, v64, v58// 00000002BEE0: C900AF3F 3F3A7540
	v_div_scale_f32 v64, s0, v44, v50, v44                     // 00000002BEE8: D6FC0040 04B2652C
	v_fma_f32 v61, -v57, v59, v54                              // 00000002BEF0: D613003D 24DA7739
	v_add3_u32 v43, v43, v53, 0x7fff                           // 00000002BEF8: D655002B 03FE6B2B 00007FFF
	.long 0xd41e0001                                           // 00000002BF04: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v52, vcc_lo              // 00000002BF08: 020268FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002BF10: BF870214
	v_mul_f32_e32 v89, v64, v58                                // 00000002BF14: 10B27540
	v_fmac_f32_e32 v59, v61, v46                               // 00000002BF18: 56765D3D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000002BF1C: BF870005
	.long 0xd71c0031                                           // 00000002BF20: D71C0031
	v_cndmask_b32_e32 v1, v49, v60, vcc_lo                     // 00000002BF24: 02027931
	v_exp_f32_e32 v60, v63                                     // 00000002BF28: 7E784B3F
	global_store_d16_hi_b16 v[15:16], v43, off offset:320      // 00000002BF2C: DC960140 007C2B0F
	v_fma_f32 v53, -v42, v89, v64                              // 00000002BF34: D6130035 2502B32A
	v_fma_f32 v54, -v57, v59, v54                              // 00000002BF3C: D6130036 24DA7739
	v_cndmask_b32_e64 v49, 0, v49, s1                          // 00000002BF44: D5010031 00066280
	.long 0xd41b0001                                           // 00000002BF4C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v52, vcc_lo              // 00000002BF50: 020268FF C2B17218
	global_store_d16_hi_b16 v[23:24], v41, off offset:320      // 00000002BF58: DC960140 007C2917
	v_fmac_f32_e32 v89, v53, v58                               // 00000002BF60: 56B27535
	v_cvt_i32_f32_e32 v53, v88                                 // 00000002BF64: 7E6A1158
	v_div_fmas_f32 v46, v54, v46, v59                          // 00000002BF68: D637002E 04EE5D36
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v62                  // 00000002BF70: 7C3C7CFF 42CE8ED0
	v_cndmask_b32_e64 v49, 0x7f800000, v49, s1                 // 00000002BF78: D5010031 000662FF 7F800000
	v_fma_f32 v42, -v42, v89, v64                              // 00000002BF84: D613002A 2502B32A
	.long 0xd71c0034                                           // 00000002BF8C: D71C0034
	v_cndmask_b32_e32 v1, v60, v53, vcc_lo                     // 00000002BF90: 02026B3C
	v_div_fixup_f32 v45, v46, v51, v45                         // 00000002BF94: D627002D 04B6672E
	v_lshlrev_b32_e32 v60, 16, v81                             // 00000002BF9C: 3078A290
	v_add_f32_e32 v49, 1.0, v49                                // 00000002BFA0: 066262F2
	.long 0x7f663980                                           // 00000002BFA4: 7F663980
	v_cndmask_b32_e32 v52, 0, v52, vcc_lo                      // 00000002BFA8: 02686880
	s_mov_b32 vcc_lo, s0                                       // 00000002BFAC: BEEA0000
	v_mul_f32_e32 v61, 0xbfb8aa3b, v60                         // 00000002BFB0: 107A78FF BFB8AA3B
	v_div_fmas_f32 v42, v42, v58, v89                          // 00000002BFB8: D637002A 0566752A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v62                  // 00000002BFC0: 7C367CFF C2B17218
	v_div_scale_f32 v53, null, v49, v49, v33                   // 00000002BFC8: D6FC7C35 04866331
	.long 0x7e6639ad                                           // 00000002BFD0: 7E6639AD
	v_fma_f32 v63, 0xbfb8aa3b, v60, -v61                       // 00000002BFD4: D613003F 84F678FF BFB8AA3B
	v_div_fixup_f32 v42, v42, v50, v44                         // 00000002BFE0: D627002A 04B2652A
	v_cndmask_b32_e32 v52, 0x7f800000, v52, vcc_lo             // 00000002BFE8: 026868FF 7F800000
	v_lshlrev_b32_e32 v50, 16, v82                             // 00000002BFF0: 3064A490
	v_rcp_f32_e32 v43, v53                                     // 00000002BFF4: 7E565535
	v_rndne_f32_e32 v64, v61                                   // 00000002BFF8: 7E80473D
	.long 0x7e0039aa                                           // 00000002BFFC: 7E0039AA
	v_add_f32_e32 v44, 1.0, v52                                // 00000002C000: 065868F2
	v_mul_f32_e32 v46, 0xbfb8aa3b, v50                         // 00000002C004: 105C64FF BFB8AA3B
	v_fmac_f32_e32 v63, 0xb2a5705f, v60                        // 00000002C00C: 567E78FF B2A5705F
	v_sub_f32_e32 v61, v61, v64                                // 00000002C014: 087A813D
	v_and_b32_e32 v59, 1, v0                                   // 00000002C018: 36760081
	v_div_scale_f32 v41, null, v44, v44, v34                   // 00000002C01C: D6FC7C29 048A592C
	v_fma_f32 v57, 0xbfb8aa3b, v50, -v46                       // 00000002C024: D6130039 84BA64FF BFB8AA3B
	v_rndne_f32_e32 v58, v46                                   // 00000002C030: 7E74472E
	v_fma_f32 v52, -v53, v43, 1.0                              // 00000002C034: D6130034 23CA5735
	v_and_b32_e32 v51, 1, v51                                  // 00000002C03C: 36666681
	v_rcp_f32_e32 v54, v41                                     // 00000002C040: 7E6C5529
	v_fmac_f32_e32 v57, 0xb2a5705f, v50                        // 00000002C044: 567264FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000002C04C: BF870243
	v_dual_sub_f32 v46, v46, v58 :: v_dual_fmac_f32 v43, v52, v43// 00000002C050: C940752E 2E2A5734
	v_div_scale_f32 v52, vcc_lo, v33, v49, v33                 // 00000002C058: D6FC6A34 04866321
	v_add3_u32 v42, v42, v59, 0x7fff                           // 00000002C060: D655002A 03FE772A 00007FFF
	v_cvt_i32_f32_e32 v58, v58                                 // 00000002C06C: 7E74113A
	v_dual_add_f32 v46, v46, v57 :: v_dual_add_f32 v61, v61, v63// 00000002C070: C908732E 2E3C7F3D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002C078: BF870294
	v_mul_f32_e32 v57, v52, v43                                // 00000002C07C: 10725734
	v_fma_f32 v62, -v41, v54, 1.0                              // 00000002C080: D613003E 23CA6D29
	v_add3_u32 v45, v45, v51, 0x7fff                           // 00000002C088: D655002D 03FE672D 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002C094: BF870004
	v_exp_f32_e32 v46, v46                                     // 00000002C098: 7E5C4B2E
	.long 0xd41e0001                                           // 00000002C09C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v50, vcc_lo              // 00000002C0A0: 020264FF 42CE8ED0
	v_fma_f32 v59, -v53, v57, v52                              // 00000002C0A8: D613003B 24D27335
	v_fmac_f32_e32 v54, v62, v54                               // 00000002C0B0: 566C6D3E
	v_div_scale_f32 v62, s0, v34, v44, v34                     // 00000002C0B4: D6FC003E 048A5922
	global_store_d16_hi_b16 v[31:32], v45, off offset:320      // 00000002C0BC: DC960140 007C2D1F
	v_lshlrev_b32_e32 v45, 16, v84                             // 00000002C0C4: 305AA890
	v_fmac_f32_e32 v57, v59, v43                               // 00000002C0C8: 5672573B
	global_store_d16_hi_b16 v[39:40], v42, off offset:320      // 00000002C0CC: DC960140 007C2A27
	v_mul_f32_e32 v81, v62, v54                                // 00000002C0D4: 10A26D3E
	.long 0xd71c002e                                           // 00000002C0D8: D71C002E
	v_cndmask_b32_e32 v1, v46, v58, vcc_lo                     // 00000002C0DC: 0202752E
	v_exp_f32_e32 v58, v61                                     // 00000002C0E0: 7E744B3D
	v_fma_f32 v52, -v53, v57, v52                              // 00000002C0E4: D6130034 24D27335
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002C0EC: BF870193
	v_fma_f32 v51, -v41, v81, v62                              // 00000002C0F0: D6130033 24FAA329
	v_cndmask_b32_e64 v46, 0, v46, s1                          // 00000002C0F8: D501002E 00065C80
	.long 0xd41b0001                                           // 00000002C100: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v50, vcc_lo              // 00000002C104: 020264FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002C10C: BF870004
	v_div_fmas_f32 v43, v52, v43, v57                          // 00000002C110: D637002B 04E65734
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v60                  // 00000002C118: 7C3C78FF 42CE8ED0
	v_fmac_f32_e32 v81, v51, v54                               // 00000002C120: 56A26D33
	v_cvt_i32_f32_e32 v51, v64                                 // 00000002C124: 7E661140
	v_cndmask_b32_e64 v46, 0x7f800000, v46, s1                 // 00000002C128: D501002E 00065CFF 7F800000
	v_div_fixup_f32 v33, v43, v49, v33                         // 00000002C134: D6270021 0486632B
	v_mul_f32_e32 v43, 0xbfb8aa3b, v45                         // 00000002C13C: 10565AFF BFB8AA3B
	v_fma_f32 v41, -v41, v81, v62                              // 00000002C144: D6130029 24FAA329
	.long 0xd71c0032                                           // 00000002C14C: D71C0032
	v_cndmask_b32_e32 v1, v58, v51, vcc_lo                     // 00000002C150: 0202673A
	v_add_f32_e32 v46, 1.0, v46                                // 00000002C154: 065C5CF2
	v_lshlrev_b32_e32 v58, 16, v83                             // 00000002C158: 3074A690
	v_fma_f32 v53, 0xbfb8aa3b, v45, -v43                       // 00000002C15C: D6130035 84AE5AFF BFB8AA3B
	.long 0x7e6239a1                                           // 00000002C168: 7E6239A1
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000002C16C: 02646480
	s_mov_b32 vcc_lo, s0                                       // 00000002C170: BEEA0000
	v_div_scale_f32 v51, null, v46, v46, v35                   // 00000002C174: D6FC7C33 048E5D2E
	v_div_fmas_f32 v41, v41, v54, v81                          // 00000002C17C: D6370029 05466D29
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v60                  // 00000002C184: 7C3678FF C2B17218
	v_rndne_f32_e32 v54, v43                                   // 00000002C18C: 7E6C472B
	v_fmac_f32_e32 v53, 0xb2a5705f, v45                        // 00000002C190: 566A5AFF B2A5705F
	v_mul_f32_e32 v59, 0xbfb8aa3b, v58                         // 00000002C198: 107674FF BFB8AA3B
	v_div_fixup_f32 v34, v41, v44, v34                         // 00000002C1A0: D6270022 048A5929
	v_cndmask_b32_e32 v50, 0x7f800000, v50, vcc_lo             // 00000002C1A8: 026464FF 7F800000
	v_rcp_f32_e32 v41, v51                                     // 00000002C1B0: 7E525533
	v_sub_f32_e32 v43, v43, v54                                // 00000002C1B4: 08566D2B
	v_fma_f32 v61, 0xbfb8aa3b, v58, -v59                       // 00000002C1B8: D613003D 84EE74FF BFB8AA3B
	.long 0x7e0039a2                                           // 00000002C1C4: 7E0039A2
	v_add_f32_e32 v44, 1.0, v50                                // 00000002C1C8: 065864F2
	v_rndne_f32_e32 v62, v59                                   // 00000002C1CC: 7E7C473B
	v_add_f32_e32 v43, v43, v53                                // 00000002C1D0: 06566B2B
	.long 0x7f623980                                           // 00000002C1D4: 7F623980
	v_and_b32_e32 v57, 1, v0                                   // 00000002C1D8: 36720081
	v_div_scale_f32 v42, null, v44, v44, v36                   // 00000002C1DC: D6FC7C2A 0492592C
	v_fma_f32 v50, -v51, v41, 1.0                              // 00000002C1E4: D6130032 23CA5333
	v_exp_f32_e32 v43, v43                                     // 00000002C1EC: 7E564B2B
	v_fmac_f32_e32 v61, 0xb2a5705f, v58                        // 00000002C1F0: 567A74FF B2A5705F
	v_sub_f32_e32 v59, v59, v62                                // 00000002C1F8: 08767D3B
	v_rcp_f32_e32 v52, v42                                     // 00000002C1FC: 7E68552A
	v_fmac_f32_e32 v41, v50, v41                               // 00000002C200: 56525332
	v_div_scale_f32 v50, vcc_lo, v35, v46, v35                 // 00000002C204: D6FC6A32 048E5D23
	v_and_b32_e32 v49, 1, v49                                  // 00000002C20C: 36626281
	v_add3_u32 v34, v34, v57, 0x7fff                           // 00000002C210: D6550022 03FE7322 00007FFF
	v_cvt_i32_f32_e32 v54, v54                                 // 00000002C21C: 7E6C1136
	v_add_f32_e32 v59, v59, v61                                // 00000002C220: 06767B3B
	v_mul_f32_e32 v53, v50, v41                                // 00000002C224: 106A5332
	v_add3_u32 v33, v33, v49, 0x7fff                           // 00000002C228: D6550021 03FE6321 00007FFF
	.long 0xd41e0001                                           // 00000002C234: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v45, vcc_lo              // 00000002C238: 02025AFF 42CE8ED0
	v_fma_f32 v60, -v42, v52, 1.0                              // 00000002C240: D613003C 23CA692A
	.long 0xd71c002b                                           // 00000002C248: D71C002B
	v_cndmask_b32_e32 v1, v43, v54, vcc_lo                     // 00000002C24C: 02026D2B
	v_fma_f32 v57, -v51, v53, v50                              // 00000002C250: D6130039 24CA6B33
	v_exp_f32_e32 v54, v59                                     // 00000002C258: 7E6C4B3B
	global_store_d16_hi_b16 v[7:8], v33, off offset:352        // 00000002C25C: DC960160 007C2107
	v_fmac_f32_e32 v52, v60, v52                               // 00000002C264: 5668693C
	v_div_scale_f32 v60, s0, v36, v44, v36                     // 00000002C268: D6FC003C 04925924
	v_fmac_f32_e32 v53, v57, v41                               // 00000002C270: 566A5339
	v_cndmask_b32_e64 v43, 0, v43, s1                          // 00000002C274: D501002B 00065680
	.long 0xd41b0001                                           // 00000002C27C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v45, vcc_lo              // 00000002C280: 02025AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v34, off offset:352      // 00000002C288: DC960160 007C222F
	v_mul_f32_e32 v63, v60, v52                                // 00000002C290: 107E693C
	v_fma_f32 v50, -v51, v53, v50                              // 00000002C294: D6130032 24CA6B33
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 00000002C29C: D501002B 000656FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002C2A8: BF870193
	v_fma_f32 v49, -v42, v63, v60                              // 00000002C2AC: D6130031 24F27F2A
	v_div_fmas_f32 v41, v50, v41, v53                          // 00000002C2B4: D6370029 04D65332
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v58                  // 00000002C2BC: 7C3C74FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002C2C4: BF870214
	v_add_f32_e32 v43, 1.0, v43                                // 00000002C2C8: 065656F2
	v_fmac_f32_e32 v63, v49, v52                               // 00000002C2CC: 567E6931
	v_cvt_i32_f32_e32 v49, v62                                 // 00000002C2D0: 7E62113E
	v_div_fixup_f32 v35, v41, v46, v35                         // 00000002C2D4: D6270023 048E5D29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002C2DC: BF870193
	v_fma_f32 v42, -v42, v63, v60                              // 00000002C2E0: D613002A 24F27F2A
	.long 0xd71c002d                                           // 00000002C2E8: D71C002D
	v_cndmask_b32_e32 v1, v54, v49, vcc_lo                     // 00000002C2EC: 02026336
	v_div_scale_f32 v49, null, v43, v43, v37                   // 00000002C2F0: D6FC7C31 0496572B
	s_waitcnt vmcnt(3)                                         // 00000002C2F8: BF890FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002C2FC: BF8700A2
	v_dual_cndmask_b32 v45, 0, v45 :: v_dual_lshlrev_b32 v54, 16, v86// 00000002C300: CA625A80 2D36AC90
	s_mov_b32 vcc_lo, s0                                       // 00000002C308: BEEA0000
	v_mul_f32_e32 v57, 0xbfb8aa3b, v54                         // 00000002C30C: 10726CFF BFB8AA3B
	v_div_fmas_f32 v42, v42, v52, v63                          // 00000002C314: D637002A 04FE692A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v58                  // 00000002C31C: 7C3674FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002C324: BF870193
	v_fma_f32 v59, 0xbfb8aa3b, v54, -v57                       // 00000002C328: D613003B 84E66CFF BFB8AA3B
	v_div_fixup_f32 v33, v42, v44, v36                         // 00000002C334: D6270021 0492592A
	v_dual_cndmask_b32 v45, 0x7f800000, v45 :: v_dual_mul_f32 v36, v113, v38// 00000002C33C: CA465AFF 2D244D71 7F800000
	v_lshlrev_b32_e32 v44, 16, v85                             // 00000002C348: 3058AA90
	v_rcp_f32_e32 v38, v49                                     // 00000002C34C: 7E4C5531
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002C350: BF870193
	.long 0x7e0039a1                                           // 00000002C354: 7E0039A1
	v_add_f32_e32 v42, 1.0, v45                                // 00000002C358: 06545AF2
	v_rndne_f32_e32 v60, v57                                   // 00000002C35C: 7E784739
	v_mul_f32_e32 v41, 0xbfb8aa3b, v44                         // 00000002C360: 105258FF BFB8AA3B
	.long 0x7e5a39a3                                           // 00000002C368: 7E5A39A3
	.long 0x7f5a3980                                           // 00000002C36C: 7F5A3980
	v_div_scale_f32 v34, null, v42, v42, v36                   // 00000002C370: D6FC7C22 0492552A
	v_and_b32_e32 v53, 1, v0                                   // 00000002C378: 366A0081
	v_fma_f32 v51, 0xbfb8aa3b, v44, -v41                       // 00000002C37C: D6130033 84A658FF BFB8AA3B
	v_rndne_f32_e32 v52, v41                                   // 00000002C388: 7E684729
	v_fma_f32 v46, -v49, v38, 1.0                              // 00000002C38C: D613002E 23CA4D31
	v_rcp_f32_e32 v50, v34                                     // 00000002C394: 7E645522
	v_fmac_f32_e32 v59, 0xb2a5705f, v54                        // 00000002C398: 56766CFF B2A5705F
	v_fmac_f32_e32 v51, 0xb2a5705f, v44                        // 00000002C3A0: 566658FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000002C3A8: BF870243
	v_dual_sub_f32 v41, v41, v52 :: v_dual_fmac_f32 v38, v46, v38// 00000002C3AC: C9406929 29264D2E
	v_div_scale_f32 v46, vcc_lo, v37, v43, v37                 // 00000002C3B4: D6FC6A2E 04965725
	v_sub_f32_e32 v57, v57, v60                                // 00000002C3BC: 08727939
	v_and_b32_e32 v45, 1, v45                                  // 00000002C3C0: 365A5A81
	v_add_f32_e32 v41, v41, v51                                // 00000002C3C4: 06526729
	v_add3_u32 v33, v33, v53, 0x7fff                           // 00000002C3C8: D6550021 03FE6B21 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000002C3D4: BF8701C5
	v_fma_f32 v58, -v34, v50, 1.0                              // 00000002C3D8: D613003A 23CA6522
	v_mul_f32_e32 v51, v46, v38                                // 00000002C3E0: 10664D2E
	v_cvt_i32_f32_e32 v52, v52                                 // 00000002C3E4: 7E681134
	v_exp_f32_e32 v41, v41                                     // 00000002C3E8: 7E524B29
	v_dual_add_f32 v57, v57, v59 :: v_dual_fmac_f32 v50, v58, v50// 00000002C3EC: C9007739 3932653A
	v_div_scale_f32 v58, s0, v36, v42, v36                     // 00000002C3F4: D6FC003A 04925524
	v_fma_f32 v53, -v49, v51, v46                              // 00000002C3FC: D6130035 24BA6731
	v_add3_u32 v35, v35, v45, 0x7fff                           // 00000002C404: D6550023 03FE5B23 00007FFF
	.long 0xd41e0001                                           // 00000002C410: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v44, vcc_lo              // 00000002C414: 020258FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002C41C: BF870214
	v_mul_f32_e32 v61, v58, v50                                // 00000002C420: 107A653A
	v_fmac_f32_e32 v51, v53, v38                               // 00000002C424: 56664D35
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000002C428: BF870005
	.long 0xd71c0029                                           // 00000002C42C: D71C0029
	v_cndmask_b32_e32 v1, v41, v52, vcc_lo                     // 00000002C430: 02026929
	v_exp_f32_e32 v52, v57                                     // 00000002C434: 7E684B39
	global_store_d16_hi_b16 v[15:16], v35, off offset:352      // 00000002C438: DC960160 007C230F
	v_fma_f32 v45, -v34, v61, v58                              // 00000002C440: D613002D 24EA7B22
	v_fma_f32 v46, -v49, v51, v46                              // 00000002C448: D613002E 24BA6731
	v_cndmask_b32_e64 v41, 0, v41, s1                          // 00000002C450: D5010029 00065280
	.long 0xd41b0001                                           // 00000002C458: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v44, vcc_lo              // 00000002C45C: 020258FF C2B17218
	global_store_d16_hi_b16 v[23:24], v33, off offset:352      // 00000002C464: DC960160 007C2117
	v_fmac_f32_e32 v61, v45, v50                               // 00000002C46C: 567A652D
	v_cvt_i32_f32_e32 v45, v60                                 // 00000002C470: 7E5A113C
	v_div_fmas_f32 v38, v46, v38, v51                          // 00000002C474: D6370026 04CE4D2E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v54                  // 00000002C47C: 7C3C6CFF 42CE8ED0
	v_cndmask_b32_e64 v41, 0x7f800000, v41, s1                 // 00000002C484: D5010029 000652FF 7F800000
	v_fma_f32 v34, -v34, v61, v58                              // 00000002C490: D6130022 24EA7B22
	.long 0xd71c002c                                           // 00000002C498: D71C002C
	v_cndmask_b32_e32 v1, v52, v45, vcc_lo                     // 00000002C49C: 02025B34
	v_div_fixup_f32 v37, v38, v43, v37                         // 00000002C4A0: D6270025 04965726
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002C4A8: BF870224
	v_dual_add_f32 v41, 1.0, v41 :: v_dual_lshlrev_b32 v52, 16, v75// 00000002C4AC: C92252F2 29349690
	.long 0x7f563980                                           // 00000002C4B4: 7F563980
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 00000002C4B8: 02585880
	s_mov_b32 vcc_lo, s0                                       // 00000002C4BC: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002C4C0: BF870003
	v_mul_f32_e32 v53, 0xbfb8aa3b, v52                         // 00000002C4C4: 106A68FF BFB8AA3B
	v_div_fmas_f32 v34, v34, v50, v61                          // 00000002C4CC: D6370022 04F66522
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v54                  // 00000002C4D4: 7C366CFF C2B17218
	v_div_scale_f32 v45, null, v41, v41, v25                   // 00000002C4DC: D6FC7C2D 04665329
	.long 0x7e5639a5                                           // 00000002C4E4: 7E5639A5
	v_fma_f32 v57, 0xbfb8aa3b, v52, -v53                       // 00000002C4E8: D6130039 84D668FF BFB8AA3B
	v_div_fixup_f32 v34, v34, v42, v36                         // 00000002C4F4: D6270022 04925522
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo             // 00000002C4FC: 025858FF 7F800000
	v_lshlrev_b32_e32 v42, 16, v76                             // 00000002C504: 30549890
	v_rcp_f32_e32 v35, v45                                     // 00000002C508: 7E46552D
	v_rndne_f32_e32 v58, v53                                   // 00000002C50C: 7E744735
	.long 0x7e0039a2                                           // 00000002C510: 7E0039A2
	v_add_f32_e32 v36, 1.0, v44                                // 00000002C514: 064858F2
	v_mul_f32_e32 v38, 0xbfb8aa3b, v42                         // 00000002C518: 104C54FF BFB8AA3B
	v_fmac_f32_e32 v57, 0xb2a5705f, v52                        // 00000002C520: 567268FF B2A5705F
	v_sub_f32_e32 v53, v53, v58                                // 00000002C528: 086A7535
	v_and_b32_e32 v51, 1, v0                                   // 00000002C52C: 36660081
	v_div_scale_f32 v33, null, v36, v36, v26                   // 00000002C530: D6FC7C21 046A4924
	v_fma_f32 v49, 0xbfb8aa3b, v42, -v38                       // 00000002C538: D6130031 849A54FF BFB8AA3B
	v_rndne_f32_e32 v50, v38                                   // 00000002C544: 7E644726
	v_fma_f32 v44, -v45, v35, 1.0                              // 00000002C548: D613002C 23CA472D
	v_and_b32_e32 v43, 1, v43                                  // 00000002C550: 36565681
	v_rcp_f32_e32 v46, v33                                     // 00000002C554: 7E5C5521
	v_fmac_f32_e32 v49, 0xb2a5705f, v42                        // 00000002C558: 566254FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000002C560: BF870243
	v_dual_sub_f32 v38, v38, v50 :: v_dual_fmac_f32 v35, v44, v35// 00000002C564: C9406526 2622472C
	v_div_scale_f32 v44, vcc_lo, v25, v41, v25                 // 00000002C56C: D6FC6A2C 04665319
	v_add3_u32 v34, v34, v51, 0x7fff                           // 00000002C574: D6550022 03FE6722 00007FFF
	v_cvt_i32_f32_e32 v50, v50                                 // 00000002C580: 7E641132
	v_add_f32_e32 v38, v38, v49                                // 00000002C584: 064C6326
	v_add_f32_e32 v53, v53, v57                                // 00000002C588: 066A7335
	v_mul_f32_e32 v49, v44, v35                                // 00000002C58C: 1062472C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000002C590: BF870005
	v_fma_f32 v54, -v33, v46, 1.0                              // 00000002C594: D6130036 23CA5D21
	v_add3_u32 v37, v37, v43, 0x7fff                           // 00000002C59C: D6550025 03FE5725 00007FFF
	v_exp_f32_e32 v38, v38                                     // 00000002C5A8: 7E4C4B26
	.long 0xd41e0001                                           // 00000002C5AC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v42, vcc_lo              // 00000002C5B0: 020254FF 42CE8ED0
	v_fma_f32 v51, -v45, v49, v44                              // 00000002C5B8: D6130033 24B2632D
	v_fmac_f32_e32 v46, v54, v46                               // 00000002C5C0: 565C5D36
	v_div_scale_f32 v54, s0, v26, v36, v26                     // 00000002C5C4: D6FC0036 046A491A
	global_store_d16_hi_b16 v[31:32], v37, off offset:352      // 00000002C5CC: DC960160 007C251F
	v_lshlrev_b32_e32 v37, 16, v78                             // 00000002C5D4: 304A9C90
	v_fmac_f32_e32 v49, v51, v35                               // 00000002C5D8: 56624733
	global_store_d16_hi_b16 v[39:40], v34, off offset:352      // 00000002C5DC: DC960160 007C2227
	v_mul_f32_e32 v59, v54, v46                                // 00000002C5E4: 10765D36
	.long 0xd71c0026                                           // 00000002C5E8: D71C0026
	v_cndmask_b32_e32 v1, v38, v50, vcc_lo                     // 00000002C5EC: 02026526
	v_exp_f32_e32 v50, v53                                     // 00000002C5F0: 7E644B35
	v_fma_f32 v44, -v45, v49, v44                              // 00000002C5F4: D613002C 24B2632D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002C5FC: BF870193
	v_fma_f32 v43, -v33, v59, v54                              // 00000002C600: D613002B 24DA7721
	v_cndmask_b32_e64 v38, 0, v38, s1                          // 00000002C608: D5010026 00064C80
	.long 0xd41b0001                                           // 00000002C610: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v42, vcc_lo              // 00000002C614: 020254FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002C61C: BF870004
	v_div_fmas_f32 v35, v44, v35, v49                          // 00000002C620: D6370023 04C6472C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v52                  // 00000002C628: 7C3C68FF 42CE8ED0
	v_fmac_f32_e32 v59, v43, v46                               // 00000002C630: 56765D2B
	v_cvt_i32_f32_e32 v43, v58                                 // 00000002C634: 7E56113A
	v_cndmask_b32_e64 v38, 0x7f800000, v38, s1                 // 00000002C638: D5010026 00064CFF 7F800000
	v_div_fixup_f32 v25, v35, v41, v25                         // 00000002C644: D6270019 04665323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v37                         // 00000002C64C: 10464AFF BFB8AA3B
	v_fma_f32 v33, -v33, v59, v54                              // 00000002C654: D6130021 24DA7721
	.long 0xd71c002a                                           // 00000002C65C: D71C002A
	v_cndmask_b32_e32 v1, v50, v43, vcc_lo                     // 00000002C660: 02025732
	v_add_f32_e32 v38, 1.0, v38                                // 00000002C664: 064C4CF2
	v_lshlrev_b32_e32 v50, 16, v77                             // 00000002C668: 30649A90
	v_fma_f32 v45, 0xbfb8aa3b, v37, -v35                       // 00000002C66C: D613002D 848E4AFF BFB8AA3B
	.long 0x7e523999                                           // 00000002C678: 7E523999
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000002C67C: 02545480
	s_mov_b32 vcc_lo, s0                                       // 00000002C680: BEEA0000
	v_div_scale_f32 v43, null, v38, v38, v27                   // 00000002C684: D6FC7C2B 046E4D26
	v_div_fmas_f32 v33, v33, v46, v59                          // 00000002C68C: D6370021 04EE5D21
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v52                  // 00000002C694: 7C3668FF C2B17218
	v_rndne_f32_e32 v46, v35                                   // 00000002C69C: 7E5C4723
	v_fmac_f32_e32 v45, 0xb2a5705f, v37                        // 00000002C6A0: 565A4AFF B2A5705F
	v_mul_f32_e32 v51, 0xbfb8aa3b, v50                         // 00000002C6A8: 106664FF BFB8AA3B
	v_div_fixup_f32 v26, v33, v36, v26                         // 00000002C6B0: D627001A 046A4921
	v_cndmask_b32_e32 v42, 0x7f800000, v42, vcc_lo             // 00000002C6B8: 025454FF 7F800000
	v_rcp_f32_e32 v33, v43                                     // 00000002C6C0: 7E42552B
	v_sub_f32_e32 v35, v35, v46                                // 00000002C6C4: 08465D23
	v_fma_f32 v53, 0xbfb8aa3b, v50, -v51                       // 00000002C6C8: D6130035 84CE64FF BFB8AA3B
	.long 0x7e00399a                                           // 00000002C6D4: 7E00399A
	v_add_f32_e32 v36, 1.0, v42                                // 00000002C6D8: 064854F2
	v_rndne_f32_e32 v54, v51                                   // 00000002C6DC: 7E6C4733
	v_add_f32_e32 v35, v35, v45                                // 00000002C6E0: 06465B23
	.long 0x7f523980                                           // 00000002C6E4: 7F523980
	v_and_b32_e32 v49, 1, v0                                   // 00000002C6E8: 36620081
	v_div_scale_f32 v34, null, v36, v36, v28                   // 00000002C6EC: D6FC7C22 04724924
	v_fma_f32 v42, -v43, v33, 1.0                              // 00000002C6F4: D613002A 23CA432B
	v_exp_f32_e32 v35, v35                                     // 00000002C6FC: 7E464B23
	v_fmac_f32_e32 v53, 0xb2a5705f, v50                        // 00000002C700: 566A64FF B2A5705F
	v_sub_f32_e32 v51, v51, v54                                // 00000002C708: 08666D33
	v_rcp_f32_e32 v44, v34                                     // 00000002C70C: 7E585522
	v_fmac_f32_e32 v33, v42, v33                               // 00000002C710: 5642432A
	v_div_scale_f32 v42, vcc_lo, v27, v38, v27                 // 00000002C714: D6FC6A2A 046E4D1B
	v_and_b32_e32 v41, 1, v41                                  // 00000002C71C: 36525281
	v_add3_u32 v26, v26, v49, 0x7fff                           // 00000002C720: D655001A 03FE631A 00007FFF
	v_cvt_i32_f32_e32 v46, v46                                 // 00000002C72C: 7E5C112E
	v_add_f32_e32 v51, v51, v53                                // 00000002C730: 06666B33
	v_mul_f32_e32 v45, v42, v33                                // 00000002C734: 105A432A
	v_add3_u32 v25, v25, v41, 0x7fff                           // 00000002C738: D6550019 03FE5319 00007FFF
	.long 0xd41e0001                                           // 00000002C744: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v37, vcc_lo              // 00000002C748: 02024AFF 42CE8ED0
	v_fma_f32 v52, -v34, v44, 1.0                              // 00000002C750: D6130034 23CA5922
	.long 0xd71c0023                                           // 00000002C758: D71C0023
	v_cndmask_b32_e32 v1, v35, v46, vcc_lo                     // 00000002C75C: 02025D23
	v_fma_f32 v49, -v43, v45, v42                              // 00000002C760: D6130031 24AA5B2B
	v_exp_f32_e32 v46, v51                                     // 00000002C768: 7E5C4B33
	global_store_d16_hi_b16 v[7:8], v25, off offset:384        // 00000002C76C: DC960180 007C1907
	v_fmac_f32_e32 v44, v52, v44                               // 00000002C774: 56585934
	v_div_scale_f32 v52, s0, v28, v36, v28                     // 00000002C778: D6FC0034 0472491C
	v_fmac_f32_e32 v45, v49, v33                               // 00000002C780: 565A4331
	v_cndmask_b32_e64 v35, 0, v35, s1                          // 00000002C784: D5010023 00064680
	.long 0xd41b0001                                           // 00000002C78C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v37, vcc_lo              // 00000002C790: 02024AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v26, off offset:384      // 00000002C798: DC960180 007C1A2F
	v_mul_f32_e32 v57, v52, v44                                // 00000002C7A0: 10725934
	v_fma_f32 v42, -v43, v45, v42                              // 00000002C7A4: D613002A 24AA5B2B
	v_cndmask_b32_e64 v35, 0x7f800000, v35, s1                 // 00000002C7AC: D5010023 000646FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002C7B8: BF870193
	v_fma_f32 v41, -v34, v57, v52                              // 00000002C7BC: D6130029 24D27322
	v_div_fmas_f32 v33, v42, v33, v45                          // 00000002C7C4: D6370021 04B6432A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v50                  // 00000002C7CC: 7C3C64FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002C7D4: BF870214
	v_add_f32_e32 v35, 1.0, v35                                // 00000002C7D8: 064646F2
	v_fmac_f32_e32 v57, v41, v44                               // 00000002C7DC: 56725929
	v_cvt_i32_f32_e32 v41, v54                                 // 00000002C7E0: 7E521136
	v_div_fixup_f32 v27, v33, v38, v27                         // 00000002C7E4: D627001B 046E4D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002C7EC: BF870193
	v_fma_f32 v34, -v34, v57, v52                              // 00000002C7F0: D6130022 24D27322
	.long 0xd71c0025                                           // 00000002C7F8: D71C0025
	v_cndmask_b32_e32 v1, v46, v41, vcc_lo                     // 00000002C7FC: 0202532E
	v_div_scale_f32 v41, null, v35, v35, v29                   // 00000002C800: D6FC7C29 04764723
	s_waitcnt vmcnt(2)                                         // 00000002C808: BF890BF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002C80C: BF8700A2
	v_dual_cndmask_b32 v37, 0, v37 :: v_dual_lshlrev_b32 v46, 16, v80// 00000002C810: CA624A80 252EA090
	s_mov_b32 vcc_lo, s0                                       // 00000002C818: BEEA0000
	v_mul_f32_e32 v49, 0xbfb8aa3b, v46                         // 00000002C81C: 10625CFF BFB8AA3B
	v_div_fmas_f32 v34, v34, v44, v57                          // 00000002C824: D6370022 04E65922
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v50                  // 00000002C82C: 7C3664FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002C834: BF870193
	v_fma_f32 v51, 0xbfb8aa3b, v46, -v49                       // 00000002C838: D6130033 84C65CFF BFB8AA3B
	v_div_fixup_f32 v25, v34, v36, v28                         // 00000002C844: D6270019 04724922
	v_dual_cndmask_b32 v37, 0x7f800000, v37 :: v_dual_mul_f32 v28, v113, v30// 00000002C84C: CA464AFF 251C3D71 7F800000
	v_lshlrev_b32_e32 v36, 16, v79                             // 00000002C858: 30489E90
	v_rcp_f32_e32 v30, v41                                     // 00000002C85C: 7E3C5529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002C860: BF870193
	.long 0x7e003999                                           // 00000002C864: 7E003999
	v_add_f32_e32 v34, 1.0, v37                                // 00000002C868: 06444AF2
	v_rndne_f32_e32 v52, v49                                   // 00000002C86C: 7E684731
	v_mul_f32_e32 v33, 0xbfb8aa3b, v36                         // 00000002C870: 104248FF BFB8AA3B
	.long 0x7e4a399b                                           // 00000002C878: 7E4A399B
	.long 0x7f4a3980                                           // 00000002C87C: 7F4A3980
	v_div_scale_f32 v26, null, v34, v34, v28                   // 00000002C880: D6FC7C1A 04724522
	v_and_b32_e32 v45, 1, v0                                   // 00000002C888: 365A0081
	v_fma_f32 v43, 0xbfb8aa3b, v36, -v33                       // 00000002C88C: D613002B 848648FF BFB8AA3B
	v_rndne_f32_e32 v44, v33                                   // 00000002C898: 7E584721
	v_fma_f32 v38, -v41, v30, 1.0                              // 00000002C89C: D6130026 23CA3D29
	v_rcp_f32_e32 v42, v26                                     // 00000002C8A4: 7E54551A
	v_fmac_f32_e32 v51, 0xb2a5705f, v46                        // 00000002C8A8: 56665CFF B2A5705F
	v_fmac_f32_e32 v43, 0xb2a5705f, v36                        // 00000002C8B0: 565648FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000002C8B8: BF870243
	v_dual_sub_f32 v33, v33, v44 :: v_dual_fmac_f32 v30, v38, v30// 00000002C8BC: C9405921 211E3D26
	v_div_scale_f32 v38, vcc_lo, v29, v35, v29                 // 00000002C8C4: D6FC6A26 0476471D
	v_sub_f32_e32 v49, v49, v52                                // 00000002C8CC: 08626931
	v_and_b32_e32 v37, 1, v37                                  // 00000002C8D0: 364A4A81
	v_add_f32_e32 v33, v33, v43                                // 00000002C8D4: 06425721
	v_add3_u32 v25, v25, v45, 0x7fff                           // 00000002C8D8: D6550019 03FE5B19 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000002C8E4: BF8701C5
	v_fma_f32 v50, -v26, v42, 1.0                              // 00000002C8E8: D6130032 23CA551A
	v_mul_f32_e32 v43, v38, v30                                // 00000002C8F0: 10563D26
	v_cvt_i32_f32_e32 v44, v44                                 // 00000002C8F4: 7E58112C
	v_exp_f32_e32 v33, v33                                     // 00000002C8F8: 7E424B21
	v_dual_add_f32 v49, v49, v51 :: v_dual_fmac_f32 v42, v50, v42// 00000002C8FC: C9006731 312A5532
	v_div_scale_f32 v50, s0, v28, v34, v28                     // 00000002C904: D6FC0032 0472451C
	v_fma_f32 v45, -v41, v43, v38                              // 00000002C90C: D613002D 249A5729
	v_add3_u32 v27, v27, v37, 0x7fff                           // 00000002C914: D655001B 03FE4B1B 00007FFF
	.long 0xd41e0001                                           // 00000002C920: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v36, vcc_lo              // 00000002C924: 020248FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002C92C: BF870214
	v_mul_f32_e32 v53, v50, v42                                // 00000002C930: 106A5532
	v_fmac_f32_e32 v43, v45, v30                               // 00000002C934: 56563D2D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000002C938: BF870005
	.long 0xd71c0021                                           // 00000002C93C: D71C0021
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 00000002C940: 02025921
	v_exp_f32_e32 v44, v49                                     // 00000002C944: 7E584B31
	global_store_d16_hi_b16 v[15:16], v27, off offset:384      // 00000002C948: DC960180 007C1B0F
	v_fma_f32 v37, -v26, v53, v50                              // 00000002C950: D6130025 24CA6B1A
	v_fma_f32 v38, -v41, v43, v38                              // 00000002C958: D6130026 249A5729
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 00000002C960: D5010021 00064280
	.long 0xd41b0001                                           // 00000002C968: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v36, vcc_lo              // 00000002C96C: 020248FF C2B17218
	global_store_d16_hi_b16 v[23:24], v25, off offset:384      // 00000002C974: DC960180 007C1917
	v_fmac_f32_e32 v53, v37, v42                               // 00000002C97C: 566A5525
	v_cvt_i32_f32_e32 v37, v52                                 // 00000002C980: 7E4A1134
	v_div_fmas_f32 v30, v38, v30, v43                          // 00000002C984: D637001E 04AE3D26
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 00000002C98C: 7C3C5CFF 42CE8ED0
	v_cndmask_b32_e64 v33, 0x7f800000, v33, s1                 // 00000002C994: D5010021 000642FF 7F800000
	v_fma_f32 v26, -v26, v53, v50                              // 00000002C9A0: D613001A 24CA6B1A
	.long 0xd71c0024                                           // 00000002C9A8: D71C0024
	v_cndmask_b32_e32 v1, v44, v37, vcc_lo                     // 00000002C9AC: 02024B2C
	v_div_fixup_f32 v29, v30, v35, v29                         // 00000002C9B0: D627001D 0476471E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002C9B8: BF870224
	v_dual_add_f32 v33, 1.0, v33 :: v_dual_lshlrev_b32 v44, 16, v71// 00000002C9BC: C92242F2 212C8E90
	.long 0x7f463980                                           // 00000002C9C4: 7F463980
	v_cndmask_b32_e32 v36, 0, v36, vcc_lo                      // 00000002C9C8: 02484880
	s_mov_b32 vcc_lo, s0                                       // 00000002C9CC: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002C9D0: BF870003
	v_mul_f32_e32 v45, 0xbfb8aa3b, v44                         // 00000002C9D4: 105A58FF BFB8AA3B
	v_div_fmas_f32 v26, v26, v42, v53                          // 00000002C9DC: D637001A 04D6551A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 00000002C9E4: 7C365CFF C2B17218
	v_div_scale_f32 v37, null, v33, v33, v17                   // 00000002C9EC: D6FC7C25 04464321
	.long 0x7e46399d                                           // 00000002C9F4: 7E46399D
	v_fma_f32 v49, 0xbfb8aa3b, v44, -v45                       // 00000002C9F8: D6130031 84B658FF BFB8AA3B
	v_div_fixup_f32 v26, v26, v34, v28                         // 00000002CA04: D627001A 0472451A
	v_cndmask_b32_e32 v36, 0x7f800000, v36, vcc_lo             // 00000002CA0C: 024848FF 7F800000
	v_lshlrev_b32_e32 v34, 16, v73                             // 00000002CA14: 30449290
	v_rcp_f32_e32 v27, v37                                     // 00000002CA18: 7E365525
	v_rndne_f32_e32 v50, v45                                   // 00000002CA1C: 7E64472D
	.long 0x7e00399a                                           // 00000002CA20: 7E00399A
	v_add_f32_e32 v28, 1.0, v36                                // 00000002CA24: 063848F2
	v_mul_f32_e32 v30, 0xbfb8aa3b, v34                         // 00000002CA28: 103C44FF BFB8AA3B
	v_fmac_f32_e32 v49, 0xb2a5705f, v44                        // 00000002CA30: 566258FF B2A5705F
	v_sub_f32_e32 v45, v45, v50                                // 00000002CA38: 085A652D
	v_and_b32_e32 v43, 1, v0                                   // 00000002CA3C: 36560081
	v_div_scale_f32 v25, null, v28, v28, v18                   // 00000002CA40: D6FC7C19 044A391C
	v_fma_f32 v41, 0xbfb8aa3b, v34, -v30                       // 00000002CA48: D6130029 847A44FF BFB8AA3B
	v_rndne_f32_e32 v42, v30                                   // 00000002CA54: 7E54471E
	v_fma_f32 v36, -v37, v27, 1.0                              // 00000002CA58: D6130024 23CA3725
	v_and_b32_e32 v35, 1, v35                                  // 00000002CA60: 36464681
	v_rcp_f32_e32 v38, v25                                     // 00000002CA64: 7E4C5519
	v_fmac_f32_e32 v41, 0xb2a5705f, v34                        // 00000002CA68: 565244FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000002CA70: BF870243
	v_dual_sub_f32 v30, v30, v42 :: v_dual_fmac_f32 v27, v36, v27// 00000002CA74: C940551E 1E1A3724
	v_div_scale_f32 v36, vcc_lo, v17, v33, v17                 // 00000002CA7C: D6FC6A24 04464311
	v_add3_u32 v26, v26, v43, 0x7fff                           // 00000002CA84: D655001A 03FE571A 00007FFF
	v_cvt_i32_f32_e32 v42, v42                                 // 00000002CA90: 7E54112A
	v_add_f32_e32 v30, v30, v41                                // 00000002CA94: 063C531E
	v_add_f32_e32 v45, v45, v49                                // 00000002CA98: 065A632D
	v_mul_f32_e32 v41, v36, v27                                // 00000002CA9C: 10523724
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000002CAA0: BF870005
	v_fma_f32 v46, -v25, v38, 1.0                              // 00000002CAA4: D613002E 23CA4D19
	v_add3_u32 v29, v29, v35, 0x7fff                           // 00000002CAAC: D655001D 03FE471D 00007FFF
	v_exp_f32_e32 v30, v30                                     // 00000002CAB8: 7E3C4B1E
	.long 0xd41e0001                                           // 00000002CABC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v34, vcc_lo              // 00000002CAC0: 020244FF 42CE8ED0
	v_fma_f32 v43, -v37, v41, v36                              // 00000002CAC8: D613002B 24925325
	v_fmac_f32_e32 v38, v46, v38                               // 00000002CAD0: 564C4D2E
	v_div_scale_f32 v46, s0, v18, v28, v18                     // 00000002CAD4: D6FC002E 044A3912
	s_clause 0x1                                               // 00000002CADC: BF850001
	global_store_d16_hi_b16 v[31:32], v29, off offset:384      // 00000002CAE0: DC960180 007C1D1F
	global_store_d16_hi_b16 v[39:40], v26, off offset:384      // 00000002CAE8: DC960180 007C1A27
	v_dual_fmac_f32 v41, v43, v27 :: v_dual_lshlrev_b32 v26, 16, v72// 00000002CAF0: C822372B 291A9090
	v_mul_f32_e32 v51, v46, v38                                // 00000002CAF8: 10664D2E
	.long 0xd71c001e                                           // 00000002CAFC: D71C001E
	v_cndmask_b32_e32 v1, v30, v42, vcc_lo                     // 00000002CB00: 0202551E
	v_exp_f32_e32 v42, v45                                     // 00000002CB04: 7E544B2D
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002CB08: BF870003
	v_fma_f32 v36, -v37, v41, v36                              // 00000002CB0C: D6130024 24925325
	.long 0x7f3a3980                                           // 00000002CB14: 7F3A3980
	v_fma_f32 v35, -v25, v51, v46                              // 00000002CB18: D6130023 24BA6719
	v_cndmask_b32_e64 v30, 0, v30, s1                          // 00000002CB20: D501001E 00063C80
	.long 0xd41b0001                                           // 00000002CB28: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v34, vcc_lo              // 00000002CB2C: 020244FF C2B17218
	v_div_fmas_f32 v27, v36, v27, v41                          // 00000002CB34: D637001B 04A63724
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v44                  // 00000002CB3C: 7C3C58FF 42CE8ED0
	v_fmac_f32_e32 v51, v35, v38                               // 00000002CB44: 56664D23
	v_cvt_i32_f32_e32 v35, v50                                 // 00000002CB48: 7E461132
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 00000002CB4C: D501001E 00063CFF 7F800000
	v_div_fixup_f32 v17, v27, v33, v17                         // 00000002CB58: D6270011 0446431B
	v_mul_f32_e32 v33, 0xbfb8aa3b, v26                         // 00000002CB60: 104234FF BFB8AA3B
	v_fma_f32 v25, -v25, v51, v46                              // 00000002CB68: D6130019 24BA6719
	.long 0xd71c0022                                           // 00000002CB70: D71C0022
	v_cndmask_b32_e32 v1, v42, v35, vcc_lo                     // 00000002CB74: 0202472A
	v_add_f32_e32 v30, 1.0, v30                                // 00000002CB78: 063C3CF2
	.long 0xd41e0001                                           // 00000002CB7C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v26, vcc_lo              // 00000002CB80: 020234FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v26, -v33                       // 00000002CB88: D6130029 848634FF BFB8AA3B
	v_rndne_f32_e32 v42, v33                                   // 00000002CB94: 7E544721
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000002CB98: 02444480
	s_mov_b32 vcc_lo, s0                                       // 00000002CB9C: BEEA0000
	v_div_scale_f32 v35, null, v30, v30, v19                   // 00000002CBA0: D6FC7C23 044E3D1E
	v_div_fmas_f32 v25, v25, v38, v51                          // 00000002CBA8: D6370019 04CE4D19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v44                  // 00000002CBB0: 7C3658FF C2B17218
	v_lshlrev_b32_e32 v38, 16, v74                             // 00000002CBB8: 304C9490
	v_fmac_f32_e32 v41, 0xb2a5705f, v26                        // 00000002CBBC: 565234FF B2A5705F
	v_sub_f32_e32 v33, v33, v42                                // 00000002CBC4: 08425521
	v_div_fixup_f32 v18, v25, v28, v18                         // 00000002CBC8: D6270012 044A3919
	v_cndmask_b32_e32 v34, 0x7f800000, v34, vcc_lo             // 00000002CBD0: 024444FF 7F800000
	v_rcp_f32_e32 v25, v35                                     // 00000002CBD8: 7E325523
	v_mul_f32_e32 v43, 0xbfb8aa3b, v38                         // 00000002CBDC: 10564CFF BFB8AA3B
	v_add_f32_e32 v33, v33, v41                                // 00000002CBE4: 06425321
	.long 0x7e003992                                           // 00000002CBE8: 7E003992
	v_add_f32_e32 v28, 1.0, v34                                // 00000002CBEC: 063844F2
	v_cvt_i32_f32_e32 v42, v42                                 // 00000002CBF0: 7E54112A
	v_fma_f32 v46, 0xbfb8aa3b, v38, -v43                       // 00000002CBF4: D613002E 84AE4CFF BFB8AA3B
	v_rndne_f32_e32 v49, v43                                   // 00000002CC00: 7E62472B
	v_exp_f32_e32 v33, v33                                     // 00000002CC04: 7E424B21
	v_div_scale_f32 v27, null, v28, v28, v20                   // 00000002CC08: D6FC7C1B 0452391C
	v_fma_f32 v34, -v35, v25, 1.0                              // 00000002CC10: D6130022 23CA3323
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002CC18: BF870223
	v_dual_fmac_f32 v46, 0xb2a5705f, v38 :: v_dual_sub_f32 v43, v43, v49// 00000002CC1C: C80A4CFF 2E2A632B B2A5705F
	v_div_scale_f32 v41, s0, v20, v28, v20                     // 00000002CC28: D6FC0029 04523914
	v_rcp_f32_e32 v36, v27                                     // 00000002CC30: 7E48551B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002CC34: BF870003
	v_fmac_f32_e32 v25, v34, v25                               // 00000002CC38: 56323322
	v_div_scale_f32 v34, vcc_lo, v19, v30, v19                 // 00000002CC3C: D6FC6A22 044E3D13
	v_and_b32_e32 v37, 1, v0                                   // 00000002CC44: 364A0081
	v_add_f32_e32 v43, v43, v46                                // 00000002CC48: 06565D2B
	.long 0xd71c0021                                           // 00000002CC4C: D71C0021
	v_cndmask_b32_e32 v1, v33, v42, vcc_lo                     // 00000002CC50: 02025521
	.long 0x7e3a3991                                           // 00000002CC54: 7E3A3991
	v_mul_f32_e32 v45, v34, v25                                // 00000002CC58: 105A3322
	v_add3_u32 v18, v18, v37, 0x7fff                           // 00000002CC5C: D6550012 03FE4B12 00007FFF
	v_exp_f32_e32 v37, v43                                     // 00000002CC68: 7E4A4B2B
	v_fma_f32 v44, -v27, v36, 1.0                              // 00000002CC6C: D613002C 23CA491B
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 00000002CC74: D5010021 00064280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002CC7C: BF870122
	v_dual_fmac_f32 v36, v44, v36 :: v_dual_and_b32 v29, 1, v29// 00000002CC80: C824492C 241C3A81
	v_fma_f32 v44, -v35, v45, v34                              // 00000002CC88: D613002C 248A5B23
	v_add3_u32 v17, v17, v29, 0x7fff                           // 00000002CC90: D6550011 03FE3B11 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002CC9C: BF870193
	v_dual_mul_f32 v50, v41, v36 :: v_dual_lshlrev_b32 v29, 16, v69// 00000002CCA0: C8E24929 321C8A90
	v_fmac_f32_e32 v45, v44, v25                               // 00000002CCA8: 565A332C
	s_clause 0x1                                               // 00000002CCAC: BF850001
	global_store_d16_hi_b16 v[7:8], v17, off offset:416        // 00000002CCB0: DC9601A0 007C1107
	global_store_d16_hi_b16 v[47:48], v18, off offset:416      // 00000002CCB8: DC9601A0 007C122F
	v_fma_f32 v44, -v27, v50, v41                              // 00000002CCC0: D613002C 24A6651B
	v_fma_f32 v34, -v35, v45, v34                              // 00000002CCC8: D6130022 248A5B23
	v_cvt_i32_f32_e32 v35, v49                                 // 00000002CCD0: 7E461131
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002CCD4: BF870193
	v_fmac_f32_e32 v50, v44, v36                               // 00000002CCD8: 5664492C
	v_div_fmas_f32 v25, v34, v25, v45                          // 00000002CCDC: D6370019 04B63322
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v26                  // 00000002CCE4: 7C3634FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002CCEC: BF870004
	.long 0xd71c0022                                           // 00000002CCF0: D71C0022
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 00000002CCF4: 02024725
	v_mul_f32_e32 v35, 0xbfb8aa3b, v29                         // 00000002CCF8: 10463AFF BFB8AA3B
	v_fma_f32 v27, -v27, v50, v41                              // 00000002CD00: D613001B 24A6651B
	v_div_fixup_f32 v17, v25, v30, v19                         // 00000002CD08: D6270011 044E3D19
	v_cndmask_b32_e32 v26, 0x7f800000, v33, vcc_lo             // 00000002CD10: 023442FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 00000002CD18: 7C3C4CFF 42CE8ED0
	.long 0x7f3c3980                                           // 00000002CD20: 7F3C3980
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002CD24: BF870214
	.long 0x7e3c3991                                           // 00000002CD28: 7E3C3991
	v_add_f32_e32 v26, 1.0, v26                                // 00000002CD2C: 063434F2
	v_cndmask_b32_e32 v33, 0, v34, vcc_lo                      // 00000002CD30: 02424480
	s_mov_b32 vcc_lo, s0                                       // 00000002CD34: BEEA0000
	v_div_fmas_f32 v27, v27, v36, v50                          // 00000002CD38: D637001B 04CA491B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 00000002CD40: 7C364CFF C2B17218
	v_rndne_f32_e32 v36, v35                                   // 00000002CD48: 7E484723
	s_waitcnt vmcnt(1)                                         // 00000002CD4C: BF8907F7
	v_lshlrev_b32_e32 v38, 16, v70                             // 00000002CD50: 304C8C90
	v_and_b32_e32 v30, 1, v30                                  // 00000002CD54: 363C3C81
	v_div_fixup_f32 v20, v27, v28, v20                         // 00000002CD58: D6270014 0452391B
	v_cndmask_b32_e32 v33, 0x7f800000, v33, vcc_lo             // 00000002CD60: 024242FF 7F800000
	v_div_scale_f32 v27, null, v26, v26, v21                   // 00000002CD68: D6FC7C1B 0456351A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002CD70: BF870214
	v_add3_u32 v17, v17, v30, 0x7fff                           // 00000002CD74: D6550011 03FE3D11 00007FFF
	.long 0x7e003994                                           // 00000002CD80: 7E003994
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002CD84: BF870214
	v_add_f32_e32 v28, 1.0, v33                                // 00000002CD88: 063842F2
	v_rcp_f32_e32 v19, v27                                     // 00000002CD8C: 7E26551B
	global_store_d16_hi_b16 v[15:16], v17, off offset:416      // 00000002CD90: DC9601A0 007C110F
	v_and_b32_e32 v33, 1, v0                                   // 00000002CD98: 36420081
	v_div_scale_f32 v25, null, v28, v28, v22                   // 00000002CD9C: D6FC7C19 045A391C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002CDA4: BF870112
	v_add3_u32 v20, v20, v33, 0x7fff                           // 00000002CDA8: D6550014 03FE4314 00007FFF
	v_rcp_f32_e32 v34, v25                                     // 00000002CDB4: 7E445519
	v_fma_f32 v18, -v27, v19, 1.0                              // 00000002CDB8: D6130012 23CA271B
	v_fma_f32 v33, 0xbfb8aa3b, v29, -v35                       // 00000002CDC0: D6130021 848E3AFF BFB8AA3B
	v_sub_f32_e32 v35, v35, v36                                // 00000002CDCC: 08464923
	v_cvt_i32_f32_e32 v36, v36                                 // 00000002CDD0: 7E481124
	global_store_d16_hi_b16 v[23:24], v20, off offset:416      // 00000002CDD4: DC9601A0 007C1417
	v_fmac_f32_e32 v19, v18, v19                               // 00000002CDDC: 56262712
	v_div_scale_f32 v18, vcc_lo, v21, v26, v21                 // 00000002CDE0: D6FC6A12 04563515
	v_fmac_f32_e32 v33, 0xb2a5705f, v29                        // 00000002CDE8: 56423AFF B2A5705F
	v_fma_f32 v37, -v25, v34, 1.0                              // 00000002CDF0: D6130025 23CA4519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002CDF8: BF870193
	v_mul_f32_e32 v41, v18, v19                                // 00000002CDFC: 10522712
	v_add_f32_e32 v33, v35, v33                                // 00000002CE00: 06424323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v38                         // 00000002CE04: 10464CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002CE0C: BF870004
	v_fmac_f32_e32 v34, v37, v34                               // 00000002CE10: 56444525
	v_div_scale_f32 v37, s0, v22, v28, v22                     // 00000002CE14: D6FC0025 045A3916
	v_fma_f32 v30, -v27, v41, v18                              // 00000002CE1C: D613001E 244A531B
	v_exp_f32_e32 v33, v33                                     // 00000002CE24: 7E424B21
	v_fma_f32 v43, 0xbfb8aa3b, v38, -v35                       // 00000002CE28: D613002B 848E4CFF BFB8AA3B
	v_rndne_f32_e32 v44, v35                                   // 00000002CE34: 7E584723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002CE38: BF870193
	v_dual_mul_f32 v42, v37, v34 :: v_dual_fmac_f32 v41, v30, v19// 00000002CE3C: C8C04525 2A28271E
	v_fmac_f32_e32 v43, 0xb2a5705f, v38                        // 00000002CE44: 56564CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002CE4C: BF870193
	v_sub_f32_e32 v35, v35, v44                                // 00000002CE50: 08465923
	v_fma_f32 v30, -v25, v42, v37                              // 00000002CE54: D613001E 24965519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002CE5C: BF870294
	v_fma_f32 v17, -v27, v41, v18                              // 00000002CE60: D6130011 244A531B
	.long 0xd71c0012                                           // 00000002CE68: D71C0012
	v_cndmask_b32_e32 v1, v33, v36, vcc_lo                     // 00000002CE6C: 02024921
	v_cvt_i32_f32_e32 v20, v44                                 // 00000002CE70: 7E28112C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002CE74: BF870214
	v_dual_add_f32 v27, v35, v43 :: v_dual_fmac_f32 v42, v30, v34// 00000002CE78: C9005723 1B2A451E
	v_div_fmas_f32 v17, v17, v19, v41                          // 00000002CE80: D6370011 04A62711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 00000002CE88: 7C3C3AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002CE90: BF870213
	v_fma_f32 v19, -v25, v42, v37                              // 00000002CE94: D6130013 24965519
	v_exp_f32_e32 v25, v27                                     // 00000002CE9C: 7E324B1B
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000002CEA0: 02242480
	s_mov_b32 vcc_lo, s0                                       // 00000002CEA4: BEEA0000
	v_div_fixup_f32 v17, v17, v26, v21                         // 00000002CEA8: D6270011 04563511
	v_div_fmas_f32 v19, v19, v34, v42                          // 00000002CEB0: D6370013 04AA4513
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 00000002CEB8: 7C363AFF C2B17218
	.long 0x7f2a3980                                           // 00000002CEC0: 7F2A3980
	v_lshlrev_b32_e32 v34, 16, v65                             // 00000002CEC4: 30448290
	.long 0x7e2a3991                                           // 00000002CEC8: 7E2A3991
	v_div_fixup_f32 v19, v19, v28, v22                         // 00000002CECC: D6270013 045A3913
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 00000002CED4: 022424FF 7F800000
	.long 0xd71c0014                                           // 00000002CEDC: D71C0014
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 00000002CEE0: 02022919
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 00000002CEE4: 7C3C4CFF 42CE8ED0
	v_lshlrev_b32_e32 v25, 16, v66                             // 00000002CEEC: 30328490
	.long 0x7e003993                                           // 00000002CEF0: 7E003993
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_and_b32 v21, 1, v21 // 00000002CEF4: C92424F2 12142A81
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 00000002CEFC: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 00000002CF00: 7C364CFF C2B17218
	v_mul_f32_e32 v27, 0xbfb8aa3b, v25                         // 00000002CF08: 103632FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000002CF10: BF870234
	v_div_scale_f32 v22, null, v18, v18, v9                    // 00000002CF14: D6FC7C16 04262512
	v_dual_mul_f32 v37, 0xbfb8aa3b, v34 :: v_dual_and_b32 v28, 1, v0// 00000002CF1C: C8E444FF 251C0081 BFB8AA3B
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 00000002CF28: 022828FF 7F800000
	v_fma_f32 v29, 0xbfb8aa3b, v25, -v27                       // 00000002CF30: D613001D 846E32FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002CF3C: BF8701B4
	v_rcp_f32_e32 v26, v22                                     // 00000002CF40: 7E345516
	v_rndne_f32_e32 v30, v27                                   // 00000002CF44: 7E3C471B
	v_add3_u32 v17, v17, v21, 0x7fff                           // 00000002CF48: D6550011 03FE2B11 00007FFF
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_fmac_f32 v29, 0xb2a5705f, v25// 00000002CF54: C90028F2 141C32FF B2A5705F
	v_add3_u32 v19, v19, v28, 0x7fff                           // 00000002CF60: D6550013 03FE3913 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002CF6C: BF870224
	v_sub_f32_e32 v27, v27, v30                                // 00000002CF70: 08363D1B
	v_rndne_f32_e32 v28, v37                                   // 00000002CF74: 7E384725
	v_div_scale_f32 v33, null, v20, v20, v10                   // 00000002CF78: D6FC7C21 042A2914
	v_cvt_i32_f32_e32 v30, v30                                 // 00000002CF80: 7E3C111E
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000002CF84: BF870005
	v_fma_f32 v35, -v22, v26, 1.0                              // 00000002CF88: D6130023 23CA3516
	v_add_f32_e32 v21, v27, v29                                // 00000002CF90: 062A3B1B
	v_fma_f32 v27, 0xbfb8aa3b, v34, -v37                       // 00000002CF94: D613001B 849644FF BFB8AA3B
	v_rcp_f32_e32 v36, v33                                     // 00000002CFA0: 7E485521
	v_div_scale_f32 v29, vcc_lo, v9, v18, v9                   // 00000002CFA4: D6FC6A1D 04262509
	v_fmac_f32_e32 v26, v35, v26                               // 00000002CFAC: 56343523
	v_exp_f32_e32 v21, v21                                     // 00000002CFB0: 7E2A4B15
	v_fmac_f32_e32 v27, 0xb2a5705f, v34                        // 00000002CFB4: 563644FF B2A5705F
	v_sub_f32_e32 v37, v37, v28                                // 00000002CFBC: 084A3925
	global_store_d16_hi_b16 v[31:32], v17, off offset:416      // 00000002CFC0: DC9601A0 007C111F
	v_mul_f32_e32 v38, v29, v26                                // 00000002CFC8: 104C351D
	.long 0xd41e0001                                           // 00000002CFCC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 00000002CFD0: 020232FF 42CE8ED0
	v_cvt_i32_f32_e32 v28, v28                                 // 00000002CFD8: 7E38111C
	v_fma_f32 v35, -v33, v36, 1.0                              // 00000002CFDC: D6130023 23CA4921
	v_add_f32_e32 v27, v37, v27                                // 00000002CFE4: 06363725
	global_store_d16_hi_b16 v[39:40], v19, off offset:416      // 00000002CFE8: DC9601A0 007C1327
	.long 0xd71c0011                                           // 00000002CFF0: D71C0011
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                     // 00000002CFF4: 02023D15
	v_fma_f32 v21, -v22, v38, v29                              // 00000002CFF8: D6130015 24764D16
	v_fmac_f32_e32 v36, v35, v36                               // 00000002D000: 56484923
	v_div_scale_f32 v35, s0, v10, v20, v10                     // 00000002D004: D6FC0023 042A290A
	v_exp_f32_e32 v27, v27                                     // 00000002D00C: 7E364B1B
	v_cndmask_b32_e64 v17, 0, v17, s1                          // 00000002D010: D5010011 00062280
	v_fmac_f32_e32 v38, v21, v26                               // 00000002D018: 564C3515
	.long 0xd41b0001                                           // 00000002D01C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v25, vcc_lo              // 00000002D020: 020232FF C2B17218
	v_mul_f32_e32 v30, v35, v36                                // 00000002D028: 103C4923
	v_lshlrev_b32_e32 v19, 16, v68                             // 00000002D02C: 30268890
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002D030: BF870214
	v_fma_f32 v22, -v22, v38, v29                              // 00000002D034: D6130016 24764D16
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 00000002D03C: D5010011 000622FF 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002D048: BF870214
	v_fma_f32 v21, -v33, v30, v35                              // 00000002D04C: D6130015 248E3D21
	.long 0xd41e0001                                           // 00000002D054: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v19, vcc_lo              // 00000002D058: 020226FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002D060: BF870224
	v_div_fmas_f32 v22, v22, v26, v38                          // 00000002D064: D6370016 049A3516
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 00000002D06C: 7C3C44FF 42CE8ED0
	v_fmac_f32_e32 v30, v21, v36                               // 00000002D074: 563C4915
	.long 0xd71c0015                                           // 00000002D078: D71C0015
	v_cndmask_b32_e32 v1, v27, v28, vcc_lo                     // 00000002D07C: 0202391B
	v_add_f32_e32 v17, 1.0, v17                                // 00000002D080: 062222F2
	v_div_fixup_f32 v9, v22, v18, v9                           // 00000002D084: D6270009 04262516
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002D08C: BF870214
	v_fma_f32 v25, -v33, v30, v35                              // 00000002D090: D6130019 248E3D21
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 00000002D098: 022A2A80
	s_mov_b32 vcc_lo, s0                                       // 00000002D09C: BEEA0000
	v_div_scale_f32 v26, null, v17, v17, v11                   // 00000002D0A0: D6FC7C1A 042E2311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000002D0A8: BF870233
	v_div_fmas_f32 v25, v25, v36, v30                          // 00000002D0AC: D6370019 047A4919
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 00000002D0B4: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v34, 16, v67                             // 00000002D0BC: 30448690
	v_rcp_f32_e32 v27, v26                                     // 00000002D0C0: 7E36551A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002D0C4: BF870003
	v_div_fixup_f32 v10, v25, v20, v10                         // 00000002D0C8: D627000A 042A2919
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 00000002D0D0: 022A2AFF 7F800000
	v_mul_f32_e32 v25, 0xbfb8aa3b, v19                         // 00000002D0D8: 103226FF BFB8AA3B
	v_div_scale_f32 v33, vcc_lo, v11, v17, v11                 // 00000002D0E0: D6FC6A21 042E230B
	v_mul_f32_e32 v36, 0xbfb8aa3b, v34                         // 00000002D0E8: 104844FF BFB8AA3B
	.long 0x7e00398a                                           // 00000002D0F0: 7E00398A
	v_add_f32_e32 v18, 1.0, v21                                // 00000002D0F4: 06242AF2
	v_fma_f32 v29, 0xbfb8aa3b, v19, -v25                       // 00000002D0F8: D613001D 846626FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000002D104: BF870005
	v_fma_f32 v21, -v26, v27, 1.0                              // 00000002D108: D6130015 23CA371A
	v_rndne_f32_e32 v30, v25                                   // 00000002D110: 7E3C4719
	v_and_b32_e32 v28, 1, v0                                   // 00000002D114: 36380081
	v_div_scale_f32 v22, null, v18, v18, v12                   // 00000002D118: D6FC7C16 04322512
	v_fmac_f32_e32 v29, 0xb2a5705f, v19                        // 00000002D120: 563A26FF B2A5705F
	v_fmac_f32_e32 v27, v21, v27                               // 00000002D128: 56363715
	v_sub_f32_e32 v25, v25, v30                                // 00000002D12C: 08323D19
	.long 0x7e283989                                           // 00000002D130: 7E283989
	v_rcp_f32_e32 v21, v22                                     // 00000002D134: 7E2A5516
	.long 0x7f283980                                           // 00000002D138: 7F283980
	v_mul_f32_e32 v35, v33, v27                                // 00000002D13C: 10463721
	v_add_f32_e32 v25, v25, v29                                // 00000002D140: 06323B19
	v_fma_f32 v37, 0xbfb8aa3b, v34, -v36                       // 00000002D144: D6130025 849244FF BFB8AA3B
	v_rndne_f32_e32 v38, v36                                   // 00000002D150: 7E4C4724
	v_add3_u32 v10, v10, v28, 0x7fff                           // 00000002D154: D655000A 03FE390A 00007FFF
	v_and_b32_e32 v20, 1, v20                                  // 00000002D160: 36282881
	v_fma_f32 v29, -v26, v35, v33                              // 00000002D164: D613001D 2486471A
	v_exp_f32_e32 v25, v25                                     // 00000002D16C: 7E324B19
	v_fma_f32 v28, -v22, v21, 1.0                              // 00000002D170: D613001C 23CA2B16
	v_fmac_f32_e32 v37, 0xb2a5705f, v34                        // 00000002D178: 564A44FF B2A5705F
	v_sub_f32_e32 v36, v36, v38                                // 00000002D180: 08484D24
	v_add3_u32 v9, v9, v20, 0x7fff                             // 00000002D184: D6550009 03FE2909 00007FFF
	v_cvt_i32_f32_e32 v20, v30                                 // 00000002D190: 7E28111E
	v_fmac_f32_e32 v21, v28, v21                               // 00000002D194: 562A2B1C
	v_div_scale_f32 v28, s0, v12, v18, v12                     // 00000002D198: D6FC001C 0432250C
	v_dual_fmac_f32 v35, v29, v27 :: v_dual_add_f32 v30, v36, v37// 00000002D1A0: C808371D 231E4B24
	global_store_d16_hi_b16 v[7:8], v9, off offset:448         // 00000002D1A8: DC9601C0 007C0907
	.long 0xd71c0009                                           // 00000002D1B0: D71C0009
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 00000002D1B4: 02022919
	v_mul_f32_e32 v29, v28, v21                                // 00000002D1B8: 103A2B1C
	v_fma_f32 v20, -v26, v35, v33                              // 00000002D1BC: D6130014 2486471A
	v_exp_f32_e32 v26, v30                                     // 00000002D1C4: 7E344B1E
	global_store_d16_hi_b16 v[47:48], v10, off offset:448      // 00000002D1C8: DC9601C0 007C0A2F
	v_cndmask_b32_e64 v9, 0, v9, s1                            // 00000002D1D0: D5010009 00061280
	v_fma_f32 v25, -v22, v29, v28                              // 00000002D1D8: D6130019 24723B16
	v_div_fmas_f32 v20, v20, v27, v35                          // 00000002D1E0: D6370014 048E3714
	v_cvt_i32_f32_e32 v27, v38                                 // 00000002D1E8: 7E361126
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v19                  // 00000002D1EC: 7C3626FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002D1F4: BF870214
	v_fmac_f32_e32 v29, v25, v21                               // 00000002D1F8: 563A2B19
	v_div_fixup_f32 v11, v20, v17, v11                         // 00000002D1FC: D627000B 042E2314
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002D204: BF870004
	.long 0xd71c0011                                           // 00000002D208: D71C0011
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000002D20C: 0202371A
	v_cndmask_b32_e32 v9, 0x7f800000, v9, vcc_lo               // 00000002D210: 021212FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 00000002D218: 7C3C44FF 42CE8ED0
	v_fma_f32 v19, -v22, v29, v28                              // 00000002D220: D6130013 24723B16
	s_waitcnt vmcnt(0)                                         // 00000002D228: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v56                             // 00000002D22C: 30327090
	.long 0x7e2c398b                                           // 00000002D230: 7E2C398B
	v_add_f32_e32 v9, 1.0, v9                                  // 00000002D234: 061212F2
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000002D238: 02222280
	s_mov_b32 vcc_lo, s0                                       // 00000002D23C: BEEA0000
	v_mul_f32_e32 v30, 0xbfb8aa3b, v25                         // 00000002D240: 103C32FF BFB8AA3B
	v_div_fmas_f32 v19, v19, v21, v29                          // 00000002D248: D6370013 04762B13
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 00000002D250: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v21, 16, v55                             // 00000002D258: 302A6E90
	v_div_scale_f32 v20, null, v9, v9, v13                     // 00000002D25C: D6FC7C14 04361309
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v30                       // 00000002D264: D6130022 847A32FF BFB8AA3B
	v_div_fixup_f32 v12, v19, v18, v12                         // 00000002D270: D627000C 04322513
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 00000002D278: 022222FF 7F800000
	v_mul_f32_e32 v19, 0xbfb8aa3b, v21                         // 00000002D280: 10262AFF BFB8AA3B
	v_rcp_f32_e32 v18, v20                                     // 00000002D288: 7E245514
	v_rndne_f32_e32 v35, v30                                   // 00000002D28C: 7E46471E
	v_fmac_f32_e32 v34, 0xb2a5705f, v25                        // 00000002D290: 564432FF B2A5705F
	v_add_f32_e32 v17, 1.0, v17                                // 00000002D298: 062222F2
	v_fma_f32 v27, 0xbfb8aa3b, v21, -v19                       // 00000002D29C: D613001B 844E2AFF BFB8AA3B
	v_rndne_f32_e32 v28, v19                                   // 00000002D2A8: 7E384713
	.long 0xd41e0001                                           // 00000002D2AC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v21, vcc_lo              // 00000002D2B0: 02022AFF 42CE8ED0
	.long 0x7e00398c                                           // 00000002D2B8: 7E00398C
	v_div_scale_f32 v26, null, v17, v17, v14                   // 00000002D2BC: D6FC7C1A 043A2311
	v_fmac_f32_e32 v27, 0xb2a5705f, v21                        // 00000002D2C4: 56362AFF B2A5705F
	v_sub_f32_e32 v19, v19, v28                                // 00000002D2CC: 08263913
	v_fma_f32 v29, -v20, v18, 1.0                              // 00000002D2D0: D613001D 23CA2514
	v_cvt_i32_f32_e32 v28, v28                                 // 00000002D2D8: 7E38111C
	v_rcp_f32_e32 v33, v26                                     // 00000002D2DC: 7E42551A
	.long 0x7f2c3980                                           // 00000002D2E0: 7F2C3980
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002D2E4: BF8701B3
	v_dual_add_f32 v19, v19, v27 :: v_dual_fmac_f32 v18, v29, v18// 00000002D2E8: C9003713 1312251D
	v_div_scale_f32 v27, vcc_lo, v13, v9, v13                  // 00000002D2F0: D6FC6A1B 0436130D
	v_dual_sub_f32 v29, v30, v35 :: v_dual_and_b32 v36, 1, v0  // 00000002D2F8: C964471E 1D240081
	v_exp_f32_e32 v19, v19                                     // 00000002D300: 7E264B13
	v_and_b32_e32 v22, 1, v22                                  // 00000002D304: 362C2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000002D308: BF870313
	v_mul_f32_e32 v37, v27, v18                                // 00000002D30C: 104A251B
	v_fma_f32 v30, -v26, v33, 1.0                              // 00000002D310: D613001E 23CA431A
	v_add_f32_e32 v29, v29, v34                                // 00000002D318: 063A451D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002D31C: BF870214
	v_add3_u32 v10, v11, v22, 0x7fff                           // 00000002D320: D655000A 03FE2D0B 00007FFF
	v_fma_f32 v34, -v20, v37, v27                              // 00000002D32C: D6130022 246E4B14
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002D334: BF870004
	v_fmac_f32_e32 v33, v30, v33                               // 00000002D338: 5642431E
	v_div_scale_f32 v30, s0, v14, v17, v14                     // 00000002D33C: D6FC001E 043A230E
	v_exp_f32_e32 v29, v29                                     // 00000002D344: 7E3A4B1D
	.long 0xd71c0013                                           // 00000002D348: D71C0013
	v_cndmask_b32_e32 v1, v19, v28, vcc_lo                     // 00000002D34C: 02023913
	v_fmac_f32_e32 v37, v34, v18                               // 00000002D350: 564A2522
	v_cvt_i32_f32_e32 v34, v35                                 // 00000002D354: 7E441123
	v_mul_f32_e32 v28, v30, v33                                // 00000002D358: 1038431E
	v_add3_u32 v11, v12, v36, 0x7fff                           // 00000002D35C: D655000B 03FE490C 00007FFF
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 00000002D368: D5010013 00062680
	.long 0xd41b0001                                           // 00000002D370: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v21, vcc_lo              // 00000002D374: 02022AFF C2B17218
	v_fma_f32 v20, -v20, v37, v27                              // 00000002D37C: D6130014 246E4B14
	v_fma_f32 v35, -v26, v28, v30                              // 00000002D384: D6130023 247A391A
	.long 0xd71c001b                                           // 00000002D38C: D71C001B
	v_cndmask_b32_e32 v1, v29, v34, vcc_lo                     // 00000002D390: 0202451D
	global_store_d16_hi_b16 v[15:16], v10, off offset:448      // 00000002D394: DC9601C0 007C0A0F
	v_cndmask_b32_e64 v19, 0x7f800000, v19, s1                 // 00000002D39C: D5010013 000626FF 7F800000
	.long 0xd41e0001                                           // 00000002D3A8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 00000002D3AC: 020232FF 42CE8ED0
	v_fmac_f32_e32 v28, v35, v33                               // 00000002D3B4: 56384323
	v_div_fmas_f32 v18, v20, v18, v37                          // 00000002D3B8: D6370012 04962514
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000002D3C0: 7C3632FF C2B17218
	v_add_f32_e32 v19, 1.0, v19                                // 00000002D3C8: 062626F2
	v_cndmask_b32_e64 v21, 0, v27, s1                          // 00000002D3CC: D5010015 00063680
	v_fma_f32 v20, -v26, v28, v30                              // 00000002D3D4: D6130014 247A391A
	v_div_fixup_f32 v9, v18, v9, v13                           // 00000002D3DC: D6270009 04361312
	global_store_d16_hi_b16 v[23:24], v11, off offset:448      // 00000002D3E4: DC9601C0 007C0B17
	v_div_scale_f32 v26, null, v19, v19, v1                    // 00000002D3EC: D6FC7C1A 04062713
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 00000002D3F4: 022A2AFF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 00000002D3FC: BEEA0000
	v_lshlrev_b32_e32 v18, 16, v172                            // 00000002D400: 30255890
	v_div_fmas_f32 v20, v20, v33, v28                          // 00000002D404: D6370014 04724314
	v_rcp_f32_e32 v25, v26                                     // 00000002D40C: 7E32551A
	v_add_f32_e32 v21, 1.0, v21                                // 00000002D410: 062A2AF2
	v_lshlrev_b32_e32 v29, 16, v171                            // 00000002D414: 303B5690
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002D418: BF870223
	v_div_fixup_f32 v12, v20, v17, v14                         // 00000002D41C: D627000C 043A2314
	.long 0x7e223989                                           // 00000002D424: 7E223989
	v_div_scale_f32 v14, null, v21, v21, v2                    // 00000002D428: D6FC7C0E 040A2B15
	.long 0x7f223980                                           // 00000002D430: 7F223980
	v_mul_f32_e32 v30, 0xbfb8aa3b, v29                         // 00000002D434: 103C3AFF BFB8AA3B
	.long 0x7e00398c                                           // 00000002D43C: 7E00398C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002D440: BF8701B5
	v_fma_f32 v10, -v26, v25, 1.0                              // 00000002D444: D613000A 23CA331A
	v_rcp_f32_e32 v13, v14                                     // 00000002D44C: 7E1A550E
	v_and_b32_e32 v17, 1, v17                                  // 00000002D450: 36222281
	v_and_b32_e32 v11, 1, v0                                   // 00000002D454: 36160081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002D458: BF870223
	v_fmac_f32_e32 v25, v10, v25                               // 00000002D45C: 5632330A
	v_div_scale_f32 v10, vcc_lo, v1, v19, v1                   // 00000002D460: D6FC6A0A 04062701
	v_add3_u32 v9, v9, v17, 0x7fff                             // 00000002D468: D6550009 03FE2309 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002D474: BF870224
	v_add3_u32 v11, v12, v11, 0x7fff                           // 00000002D478: D655000B 03FE170C 00007FFF
	v_mul_f32_e32 v12, 0xbfb8aa3b, v18                         // 00000002D484: 101824FF BFB8AA3B
	v_mul_f32_e32 v20, v10, v25                                // 00000002D48C: 1028330A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000002D490: BF870005
	v_fma_f32 v22, -v14, v13, 1.0                              // 00000002D494: D6130016 23CA1B0E
	s_clause 0x1                                               // 00000002D49C: BF850001
	global_store_d16_hi_b16 v[31:32], v9, off offset:448       // 00000002D4A0: DC9601C0 007C091F
	global_store_d16_hi_b16 v[39:40], v11, off offset:448      // 00000002D4A8: DC9601C0 007C0B27
	v_fma_f32 v27, 0xbfb8aa3b, v18, -v12                       // 00000002D4B0: D613001B 843224FF BFB8AA3B
	v_fma_f32 v17, -v26, v20, v10                              // 00000002D4BC: D6130011 242A291A
	v_fmac_f32_e32 v13, v22, v13                               // 00000002D4C4: 561A1B16
	v_div_scale_f32 v22, s0, v2, v21, v2                       // 00000002D4C8: D6FC0016 040A2B02
	v_rndne_f32_e32 v28, v12                                   // 00000002D4D0: 7E38470C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002D4D4: BF870114
	v_dual_fmac_f32 v27, 0xb2a5705f, v18 :: v_dual_fmac_f32 v20, v17, v25// 00000002D4D8: C80024FF 1B143311 B2A5705F
	v_dual_mul_f32 v17, v22, v13 :: v_dual_sub_f32 v12, v12, v28// 00000002D4E4: C8CA1B16 110C390C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002D4EC: BF8701A2
	v_fma_f32 v9, -v26, v20, v10                               // 00000002D4F0: D6130009 242A291A
	v_fma_f32 v26, 0xbfb8aa3b, v29, -v30                       // 00000002D4F8: D613001A 847A3AFF BFB8AA3B
	v_fma_f32 v10, -v14, v17, v22                              // 00000002D504: D613000A 245A230E
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002D50C: BF870004
	v_add_f32_e32 v12, v12, v27                                // 00000002D510: 0618370C
	v_rndne_f32_e32 v27, v30                                   // 00000002D514: 7E36471E
	v_div_fmas_f32 v9, v9, v25, v20                            // 00000002D518: D6370009 04523309
	v_fmac_f32_e32 v26, 0xb2a5705f, v29                        // 00000002D520: 56343AFF B2A5705F
	v_fmac_f32_e32 v17, v10, v13                               // 00000002D528: 56221B0A
	v_exp_f32_e32 v10, v12                                     // 00000002D52C: 7E144B0C
	v_sub_f32_e32 v12, v30, v27                                // 00000002D530: 0818371E
	v_lshlrev_b32_e32 v20, 16, v136                            // 00000002D534: 30291090
	v_cvt_i32_f32_e32 v25, v28                                 // 00000002D538: 7E32111C
	v_fma_f32 v14, -v14, v17, v22                              // 00000002D53C: D613000E 245A230E
	v_lshlrev_b32_e32 v22, 16, v174                            // 00000002D544: 302D5C90
	v_add_f32_e32 v12, v12, v26                                // 00000002D548: 0618350C
	v_mul_f32_e32 v26, 0xbfb8aa3b, v20                         // 00000002D54C: 103428FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v18                  // 00000002D554: 7C3C24FF 42CE8ED0
	v_cvt_i32_f32_e32 v27, v27                                 // 00000002D55C: 7E36111B
	v_mul_f32_e32 v28, 0xbfb8aa3b, v22                         // 00000002D560: 10382CFF BFB8AA3B
	.long 0xd71c000a                                           // 00000002D568: D71C000A
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 00000002D56C: 0202330A
	v_fma_f32 v25, 0xbfb8aa3b, v20, -v26                       // 00000002D570: D6130019 846A28FF BFB8AA3B
	v_rndne_f32_e32 v30, v26                                   // 00000002D57C: 7E3C471A
	v_exp_f32_e32 v12, v12                                     // 00000002D580: 7E184B0C
	v_fma_f32 v33, 0xbfb8aa3b, v22, -v28                       // 00000002D584: D6130021 84722CFF BFB8AA3B
	v_rndne_f32_e32 v34, v28                                   // 00000002D590: 7E44471C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002D594: BF870223
	v_dual_fmac_f32 v25, 0xb2a5705f, v20 :: v_dual_sub_f32 v26, v26, v30// 00000002D598: C80A28FF 191A3D1A B2A5705F
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000002D5A4: 02141480
	v_fmac_f32_e32 v33, 0xb2a5705f, v22                        // 00000002D5A8: 56422CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 00000002D5B0: BF8702B4
	v_sub_f32_e32 v28, v28, v34                                // 00000002D5B4: 0838451C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v18                  // 00000002D5B8: 7C3624FF C2B17218
	v_add_f32_e32 v25, v26, v25                                // 00000002D5C0: 0632331A
	.long 0xd71c000c                                           // 00000002D5C4: D71C000C
	v_cndmask_b32_e32 v1, v12, v27, vcc_lo                     // 00000002D5C8: 0202370C
	v_cvt_i32_f32_e32 v27, v34                                 // 00000002D5CC: 7E361122
	v_add_f32_e32 v26, v28, v33                                // 00000002D5D0: 0634431C
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo             // 00000002D5D4: 021414FF 7F800000
	v_exp_f32_e32 v18, v25                                     // 00000002D5DC: 7E244B19
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 00000002D5E0: 7C3C3AFF 42CE8ED0
	v_div_fixup_f32 v1, v9, v19, v1                            // 00000002D5E8: D6270001 04062709
	v_exp_f32_e32 v25, v26                                     // 00000002D5F0: 7E324B1A
	v_cvt_i32_f32_e32 v26, v30                                 // 00000002D5F4: 7E34111E
	v_add_f32_e32 v10, 1.0, v10                                // 00000002D5F8: 061414F2
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 00000002D5FC: 02181880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 00000002D600: 7C363AFF C2B17218
	.long 0x7e443981                                           // 00000002D608: 7E443981
	.long 0x7f443980                                           // 00000002D60C: 7F443980
	.long 0xd71c0012                                           // 00000002D610: D71C0012
	v_cndmask_b32_e32 v1, v18, v26, vcc_lo                     // 00000002D614: 02023512
	v_div_scale_f32 v26, null, v10, v10, v3                    // 00000002D618: D6FC7C1A 040E150A
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 00000002D620: 021818FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v20                  // 00000002D628: 7C3C28FF 42CE8ED0
	.long 0xd71c0019                                           // 00000002D630: D71C0019
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 00000002D634: 02023719
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002D638: BF870194
	v_rcp_f32_e32 v27, v26                                     // 00000002D63C: 7E36551A
	v_add_f32_e32 v12, 1.0, v12                                // 00000002D640: 061818F2
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000002D644: 02242480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v22                  // 00000002D648: 7C3C2CFF 42CE8ED0
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000002D650: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v20                  // 00000002D654: 7C3628FF C2B17218
	v_div_scale_f32 v20, null, v12, v12, v4                    // 00000002D65C: D6FC7C14 0412190C
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 00000002D664: 022424FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v22                  // 00000002D66C: 7C362CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002D674: BF870113
	v_rcp_f32_e32 v28, v20                                     // 00000002D678: 7E385514
	v_add_f32_e32 v18, 1.0, v18                                // 00000002D67C: 062424F2
	v_cndmask_b32_e32 v22, 0x7f800000, v25, vcc_lo             // 00000002D680: 022C32FF 7F800000
	v_fma_f32 v25, -v26, v27, 1.0                              // 00000002D688: D6130019 23CA371A
	s_mov_b32 vcc_lo, s0                                       // 00000002D690: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002D694: BF870193
	v_div_scale_f32 v29, null, v18, v18, v5                    // 00000002D698: D6FC7C1D 04162512
	v_add_f32_e32 v22, 1.0, v22                                // 00000002D6A0: 062C2CF2
	v_div_fmas_f32 v13, v14, v13, v17                          // 00000002D6A4: D637000D 04461B0E
	v_fmac_f32_e32 v27, v25, v27                               // 00000002D6AC: 56363719
	v_div_scale_f32 v17, vcc_lo, v3, v10, v3                   // 00000002D6B0: D6FC6A11 040E1503
	v_rcp_f32_e32 v14, v29                                     // 00000002D6B8: 7E1C551D
	v_div_scale_f32 v25, null, v22, v22, v6                    // 00000002D6BC: D6FC7C19 041A2D16
	v_fma_f32 v30, -v20, v28, 1.0                              // 00000002D6C4: D613001E 23CA3914
	v_div_fixup_f32 v2, v13, v21, v2                           // 00000002D6CC: D6270002 040A2B0D
	v_mul_f32_e32 v11, v17, v27                                // 00000002D6D4: 10163711
	v_div_scale_f32 v21, s0, v4, v12, v4                       // 00000002D6D8: D6FC0015 04121904
	v_rcp_f32_e32 v13, v25                                     // 00000002D6E0: 7E1A5519
	v_fmac_f32_e32 v28, v30, v28                               // 00000002D6E4: 5638391E
	.long 0x7e003982                                           // 00000002D6E8: 7E003982
	v_fma_f32 v9, -v26, v11, v17                               // 00000002D6EC: D6130009 2446171A
	v_fma_f32 v30, -v29, v14, 1.0                              // 00000002D6F4: D613001E 23CA1D1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002D6FC: BF870114
	v_mul_f32_e32 v19, v21, v28                                // 00000002D700: 10263915
	v_dual_fmac_f32 v11, v9, v27 :: v_dual_fmac_f32 v14, v30, v14// 00000002D704: C8003709 0B0E1D1E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002D70C: BF870225
	v_fma_f32 v33, -v25, v13, 1.0                              // 00000002D710: D6130021 23CA1B19
	v_div_scale_f32 v30, s1, v5, v18, v5                       // 00000002D718: D6FC011E 04162505
	v_fma_f32 v9, -v20, v19, v21                               // 00000002D720: D6130009 24562714
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002D728: BF870214
	v_fma_f32 v17, -v26, v11, v17                              // 00000002D72C: D6130011 2446171A
	v_fmac_f32_e32 v13, v33, v13                               // 00000002D734: 561A1B21
	v_div_scale_f32 v33, s2, v6, v22, v6                       // 00000002D738: D6FC0221 041A2D06
	v_mul_f32_e32 v35, v30, v14                                // 00000002D740: 10461D1E
	v_fmac_f32_e32 v19, v9, v28                                // 00000002D744: 56263909
	v_div_fmas_f32 v11, v17, v27, v11                          // 00000002D748: D637000B 042E3711
	s_mov_b32 vcc_lo, s0                                       // 00000002D750: BEEA0000
	v_mul_f32_e32 v26, v33, v13                                // 00000002D754: 10341B21
	v_fma_f32 v9, -v29, v35, v30                               // 00000002D758: D6130009 247A471D
	v_fma_f32 v17, -v20, v19, v21                              // 00000002D760: D6130011 24562714
	v_div_fixup_f32 v3, v11, v10, v3                           // 00000002D768: D6270003 040E150B
	v_and_b32_e32 v11, 1, v34                                  // 00000002D770: 36164481
	v_fma_f32 v20, -v25, v26, v33                              // 00000002D774: D6130014 24863519
	v_fmac_f32_e32 v35, v9, v14                                // 00000002D77C: 56461D09
	v_div_fmas_f32 v9, v17, v28, v19                           // 00000002D780: D6370009 044E3911
	s_mov_b32 vcc_lo, s1                                       // 00000002D788: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002D78C: BF870193
	v_dual_fmac_f32 v26, v20, v13 :: v_dual_and_b32 v17, 1, v0 // 00000002D790: C8241B14 1A100081
	v_fma_f32 v10, -v29, v35, v30                              // 00000002D798: D613000A 247A471D
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002D7A0: BF870003
	v_div_fixup_f32 v4, v9, v12, v4                            // 00000002D7A4: D6270004 04121909
	.long 0x7f183980                                           // 00000002D7AC: 7F183980
	v_add3_u32 v1, v1, v11, 0x7fff                             // 00000002D7B0: D6550001 03FE1701 00007FFF
	v_fma_f32 v9, -v25, v26, v33                               // 00000002D7BC: D6130009 24863519
	v_div_fmas_f32 v10, v10, v14, v35                          // 00000002D7C4: D637000A 048E1D0A
	s_mov_b32 vcc_lo, s2                                       // 00000002D7CC: BEEA0002
	.long 0x7e003984                                           // 00000002D7D0: 7E003984
	v_add3_u32 v2, v2, v17, 0x7fff                             // 00000002D7D4: D6550002 03FE2302 00007FFF
	v_div_fmas_f32 v9, v9, v13, v26                            // 00000002D7E0: D6370009 046A1B09
	v_div_fixup_f32 v5, v10, v18, v5                           // 00000002D7E8: D6270005 0416250A
	.long 0x7e143983                                           // 00000002D7F0: 7E143983
	.long 0x7f143980                                           // 00000002D7F4: 7F143980
	global_store_d16_hi_b16 v[7:8], v1, off offset:480         // 00000002D7F8: DC9601E0 007C0107
	v_div_fixup_f32 v6, v9, v22, v6                            // 00000002D800: D6270006 041A2D09
	.long 0x7e183985                                           // 00000002D808: 7E183985
	v_and_b32_e32 v9, 1, v0                                    // 00000002D80C: 36120081
	v_and_b32_e32 v10, 1, v10                                  // 00000002D810: 36141481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002D814: BF870214
	.long 0x7e003986                                           // 00000002D818: 7E003986
	v_and_b32_e32 v11, 1, v12                                  // 00000002D81C: 36161881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002D820: BF870223
	v_add3_u32 v1, v3, v10, 0x7fff                             // 00000002D824: D6550001 03FE1503 00007FFF
	v_add3_u32 v3, v4, v9, 0x7fff                              // 00000002D830: D6550003 03FE1304 00007FFF
	v_and_b32_e32 v0, 1, v0                                    // 00000002D83C: 36000081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002D840: BF870114
	v_add3_u32 v4, v5, v11, 0x7fff                             // 00000002D844: D6550004 03FE1705 00007FFF
	v_add3_u32 v0, v6, v0, 0x7fff                              // 00000002D850: D6550000 03FE0106 00007FFF
	s_clause 0x4                                               // 00000002D85C: BF850004
	global_store_d16_hi_b16 v[47:48], v2, off offset:480       // 00000002D860: DC9601E0 007C022F
	global_store_d16_hi_b16 v[15:16], v1, off offset:480       // 00000002D868: DC9601E0 007C010F
	global_store_d16_hi_b16 v[23:24], v3, off offset:480       // 00000002D870: DC9601E0 007C0317
	global_store_d16_hi_b16 v[31:32], v4, off offset:480       // 00000002D878: DC9601E0 007C041F
	global_store_d16_hi_b16 v[39:40], v0, off offset:480       // 00000002D880: DC9601E0 007C0027
	s_endpgm                                                   // 00000002D888: BFB00000
		...

