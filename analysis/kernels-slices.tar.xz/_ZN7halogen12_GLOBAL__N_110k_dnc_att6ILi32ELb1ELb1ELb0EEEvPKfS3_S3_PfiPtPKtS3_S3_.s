000000000005ac00 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_():
	s_load_b256 s[20:27], s[0:1], null                         // 00000005AC00: F40C0500 F8000000
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 00000005AC08: CA240100 040000FF 0000007F
	s_mov_b32 s4, s3                                           // 00000005AC14: BE840003
	v_mov_b32_e32 v5, v0                                       // 00000005AC18: 7E0A0300
	s_lshl_b32 s28, s4, 5                                      // 00000005AC1C: 841C8504
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000005AC20: BF8700B2
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000005AC24: 30020282
	s_mov_b32 s5, 0                                            // 00000005AC28: BE850080
	s_waitcnt lgkmcnt(0)                                       // 00000005AC2C: BF89FC07
	.long 0xd7000302                                           // 00000005AC30: D7000302
	v_cndmask_b32_e32 v1, s22, v1, vcc_lo                      // 00000005AC34: 02020216
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005AC38: BF870001
	v_add_co_ci_u32_e64 v3, null, s23, 0, s3                   // 00000005AC3C: D5207C03 000D0017
	s_ashr_i32 s3, s2, 31                                      // 00000005AC44: 86039F02
	s_nop 0                                                    // 00000005AC48: BF800000
	s_nop 0                                                    // 00000005AC4C: BF800000
	s_nop 0                                                    // 00000005AC50: BF800000
	s_nop 0                                                    // 00000005AC54: BF800000
	s_nop 0                                                    // 00000005AC58: BF800000
	s_nop 0                                                    // 00000005AC5C: BF800000
	s_nop 0                                                    // 00000005AC60: BF800000
	s_nop 0                                                    // 00000005AC64: BF800000
	s_nop 0                                                    // 00000005AC68: BF800000
	s_nop 0                                                    // 00000005AC6C: BF800000
	s_nop 0                                                    // 00000005AC70: BF800000
	s_nop 0                                                    // 00000005AC74: BF800000
	s_nop 0                                                    // 00000005AC78: BF800000
	s_nop 0                                                    // 00000005AC7C: BF800000
	v_lshrrev_b32_e32 v8, 7, v4                                // 00000005AC80: 32100887
	v_add_nc_u32_e32 v10, 0x100, v4                            // 00000005AC84: 4A1408FF 00000100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AC8C: BF870092
	v_or_b32_e32 v6, s28, v8                                   // 00000005AC90: 380C101C
	v_mad_i64_i32 v[6:7], null, v6, 48, s[2:3]                 // 00000005AC94: D6FF7C06 00096106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AC9C: BF870091
	.long 0xd73c0006                                           // 00000005ACA0: D73C0006
	v_cndmask_b32_e32 v1, 9, v6, vcc_lo                        // 00000005ACA4: 02020C89
	.long 0xd7006a06                                           // 00000005ACA8: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000005ACAC: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005ACB0: BF870001
	v_add_co_ci_u32_e64 v7, null, v3, v7, vcc_lo               // 00000005ACB4: D5207C07 01AA0F03
	v_cmp_lt_u32_e32 vcc_lo, 0xeff, v4                         // 00000005ACBC: 7C9208FF 00000EFF
	v_mov_b32_e32 v4, v10                                      // 00000005ACC4: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 00000005ACC8: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x204, v8, v[1:2]              // 00000005ACD0: D6FE7C06 040610FF 00000204
	s_or_b32 s5, vcc_lo, s5                                    // 00000005ACDC: 8C05056A
	s_waitcnt vmcnt(0)                                         // 00000005ACE0: BF8903F7
	ds_store_b32 v6, v9                                        // 00000005ACE4: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000005ACEC: 917E057E
	s_cbranch_execnz 65507                                     // 00000005ACF0: BFA6FFE3 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x80>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000005ACF4: 8C7E057E
	s_lshr_b32 s5, s4, 31                                      // 00000005ACF8: 85059F04
	s_mov_b32 s6, exec_lo                                      // 00000005ACFC: BE86007E
	s_add_i32 s4, s4, s5                                       // 00000005AD00: 81040504
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000005AD04: BF870499
	s_ashr_i32 s5, s4, 1                                       // 00000005AD08: 86058104
	s_lshl_b32 s4, s5, 6                                       // 00000005AD0C: 84048605
	v_cmpx_gt_u32_e32 64, v0                                   // 00000005AD10: 7D9800C0
	s_cbranch_execz 17                                         // 00000005AD14: BFA50011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x15c>
	v_or_b32_e32 v1, s4, v0                                    // 00000005AD18: 38020004
	s_lshl_b64 s[8:9], s[2:3], 2                               // 00000005AD1C: 84888202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AD20: BF870091
	v_mad_i64_i32 v[1:2], null, 0xc0, v1, s[24:25]             // 00000005AD24: D6FF7C01 006202FF 000000C0
	.long 0xd7006a01                                           // 00000005AD30: D7006A01
	v_cndmask_b32_e32 v0, v1, v8, vcc_lo                       // 00000005AD34: 02001101
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005AD38: BF870001
	v_add_co_ci_u32_e64 v2, null, s9, v2, vcc_lo               // 00000005AD3C: D5207C02 01AA0409
	global_load_b32 v1, v[1:2], off                            // 00000005AD44: DC520000 017C0001
	v_lshlrev_b32_e32 v2, 2, v0                                // 00000005AD4C: 30040082
	s_waitcnt vmcnt(0)                                         // 00000005AD50: BF8903F7
	ds_store_b32 v2, v1 offset:16512                           // 00000005AD54: D8344080 00000102
	s_or_b32 exec_lo, exec_lo, s6                              // 00000005AD5C: 8C7E067E
	s_mov_b64 s[22:23], 0                                      // 00000005AD60: BE960180
	s_cmp_eq_u64 s[26:27], 0                                   // 00000005AD64: BF10801A
	s_mul_hi_i32 s6, s5, 48                                    // 00000005AD68: 9706B005
	s_mul_i32 s5, s5, 48                                       // 00000005AD6C: 9605B005
	s_mov_b64 s[24:25], 0                                      // 00000005AD70: BE980180
	s_waitcnt lgkmcnt(0)                                       // 00000005AD74: BF89FC07
	s_barrier                                                  // 00000005AD78: BFBD0000
	buffer_gl0_inv                                             // 00000005AD7C: E0AC0000 00000000
	s_cbranch_scc1 6                                           // 00000005AD84: BFA20006 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x1a0>
	s_add_u32 s8, s5, s2                                       // 00000005AD88: 80080205
	s_addc_u32 s9, s6, s3                                      // 00000005AD8C: 82090306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000005AD90: BF870499
	s_lshl_b64 s[8:9], s[8:9], 14                              // 00000005AD94: 84888E08
	s_add_u32 s24, s26, s8                                     // 00000005AD98: 8018081A
	s_addc_u32 s25, s27, s9                                    // 00000005AD9C: 8219091B
	s_load_b64 s[0:1], s[0:1], 0x28                            // 00000005ADA0: F4040000 F8000028
	s_waitcnt lgkmcnt(0)                                       // 00000005ADA8: BF89FC07
	s_cmp_eq_u64 s[0:1], 0                                     // 00000005ADAC: BF108000
	s_cbranch_scc1 6                                           // 00000005ADB0: BFA20006 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x1cc>
	s_add_u32 s8, s5, s2                                       // 00000005ADB4: 80080205
	s_addc_u32 s9, s6, s3                                      // 00000005ADB8: 82090306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000005ADBC: BF870499
	s_lshl_b64 s[6:7], s[8:9], 13                              // 00000005ADC0: 84868D08
	s_add_u32 s22, s0, s6                                      // 00000005ADC4: 80160600
	s_addc_u32 s23, s1, s7                                     // 00000005ADC8: 82170701
	s_sub_i32 s27, s28, s4                                     // 00000005ADCC: 819B041C
	v_lshrrev_b32_e32 v6, 5, v0                                // 00000005ADD0: 320C0085
	s_lshl_b32 s26, s27, 5                                     // 00000005ADD4: 841A851B
	s_mov_b32 s30, exec_lo                                     // 00000005ADD8: BE9E007E
	s_sub_i32 s29, 0x800, s26                                  // 00000005ADDC: 819D1AFF 00000800
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005ADE4: BF870009
	.long 0xd4c4007e                                           // 00000005ADE8: D4C4007E
	v_cndmask_b32_e32 v1, s29, v0, vcc_lo                      // 00000005ADEC: 0202001D
	s_cbranch_execz 183                                        // 00000005ADF0: BFA500B7 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x4d0>
	v_mul_u32_u24_e32 v1, 0x204, v0                            // 00000005ADF4: 160200FF 00000204
	v_mul_u32_u24_e32 v2, 0x4080, v6                           // 00000005ADFC: 16040CFF 00004080
	s_cmp_lg_u64 s[24:25], 0                                   // 00000005AE04: BF118018
	s_mov_b32 s34, 0                                           // 00000005AE08: BEA20080
	s_cselect_b32 s31, -1, 0                                   // 00000005AE0C: 981F80C1
	s_cmp_lg_u64 s[22:23], 0                                   // 00000005AE10: BF118016
	v_sub_nc_u32_e32 v7, v1, v2                                // 00000005AE14: 4C0E0501
	s_cselect_b32 s33, -1, 0                                   // 00000005AE18: 982180C1
	s_mov_b32 s35, 0x41800000                                  // 00000005AE1C: BEA300FF 41800000
	s_branch 7                                                 // 00000005AE24: BFA00007 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x244>
	v_add_nc_u32_e32 v5, 0x100, v5                             // 00000005AE28: 4A0A0AFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005AE30: BF8704A1
	v_cmp_le_i32_e32 vcc_lo, s29, v5                           // 00000005AE34: 7C860A1D
	s_or_b32 s34, vcc_lo, s34                                  // 00000005AE38: 8C22226A
	s_and_not1_b32 exec_lo, exec_lo, s34                       // 00000005AE3C: 917E227E
	s_cbranch_execz 163                                        // 00000005AE40: BFA500A3 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x4d0>
	v_lshrrev_b32_e32 v2, 5, v5                                // 00000005AE44: 32040A85
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v1, s27, v5      // 00000005AE48: CA200080 08000A1B
	v_and_b32_e32 v4, 0x7fffffe0, v5                           // 00000005AE50: 36080AFF 7FFFFFE0
	s_mov_b32 s36, exec_lo                                     // 00000005AE58: BEA4007E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005AE5C: BF870113
	v_add_nc_u32_e32 v3, s27, v2                               // 00000005AE60: 4A06041B
	v_sub_nc_u32_e32 v1, v1, v4                                // 00000005AE64: 4C020901
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005AE68: BF870001
	.long 0xd4c3007e                                           // 00000005AE6C: D4C3007E
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000005AE70: 02020701
	s_cbranch_execz 107                                        // 00000005AE74: BFA5006B <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x424>
	v_add_nc_u32_e32 v2, s28, v2                               // 00000005AE78: 4A04041C
	v_mov_b32_e32 v4, v7                                       // 00000005AE7C: 7E080307
	s_delay_alu instid0(VALU_DEP_2)                            // 00000005AE80: BF870002
	v_readfirstlane_b32 s0, v2                                 // 00000005AE84: 7E000502
	v_mov_b32_e32 v2, 0                                        // 00000005AE88: 7E040280
	s_mul_i32 s1, s0, 48                                       // 00000005AE8C: 9601B000
	s_mul_hi_i32 s4, s0, 48                                    // 00000005AE90: 9704B000
	s_add_u32 s0, s1, s2                                       // 00000005AE94: 80000201
	s_addc_u32 s1, s4, s3                                      // 00000005AE98: 82010304
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000005AE9C: BF870499
	s_lshl_b64 s[0:1], s[0:1], 9                               // 00000005AEA0: 84808900
	s_add_u32 s37, s20, s0                                     // 00000005AEA4: 80250014
	s_addc_u32 s38, s21, s1                                    // 00000005AEA8: 82260115
	s_mov_b64 s[0:1], 0                                        // 00000005AEAC: BE800180
	s_set_inst_prefetch_distance 0x1                           // 00000005AEB0: BF840001
	s_nop 0                                                    // 00000005AEB4: BF800000
	s_nop 0                                                    // 00000005AEB8: BF800000
	s_nop 0                                                    // 00000005AEBC: BF800000
	s_add_u32 s4, s37, s0                                      // 00000005AEC0: 80040025
	s_addc_u32 s5, s38, s1                                     // 00000005AEC4: 82050126
	ds_load_2addr_b32 v[8:9], v4 offset1:1                     // 00000005AEC8: D8DC0100 08000004
	s_load_b512 s[4:19], s[4:5], null                          // 00000005AED0: F4100102 F8000000
	ds_load_2addr_b32 v[10:11], v4 offset0:2 offset1:3         // 00000005AED8: D8DC0302 0A000004
	ds_load_2addr_b32 v[12:13], v4 offset0:4 offset1:5         // 00000005AEE0: D8DC0504 0C000004
	ds_load_2addr_b32 v[14:15], v4 offset0:6 offset1:7         // 00000005AEE8: D8DC0706 0E000004
	s_add_u32 s0, s0, 64                                       // 00000005AEF0: 8000C000
	s_addc_u32 s1, s1, 0                                       // 00000005AEF4: 82018001
	s_cmpk_eq_i32 s0, 0x200                                    // 00000005AEF8: B1800200
	s_waitcnt lgkmcnt(0)                                       // 00000005AEFC: BF89FC07
	v_fmac_f32_e32 v2, s4, v8                                  // 00000005AF00: 56041004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000005AF04: BF8700B1
	v_fmac_f32_e32 v2, s5, v9                                  // 00000005AF08: 56041205
	ds_load_2addr_b32 v[8:9], v4 offset0:8 offset1:9           // 00000005AF0C: D8DC0908 08000004
	v_fmac_f32_e32 v2, s6, v10                                 // 00000005AF14: 56041406
	v_fmac_f32_e32 v2, s7, v11                                 // 00000005AF18: 56041607
	ds_load_2addr_b32 v[10:11], v4 offset0:10 offset1:11       // 00000005AF1C: D8DC0B0A 0A000004
	v_fmac_f32_e32 v2, s8, v12                                 // 00000005AF24: 56041808
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AF28: BF870091
	v_fmac_f32_e32 v2, s9, v13                                 // 00000005AF2C: 56041A09
	v_fmac_f32_e32 v2, s10, v14                                // 00000005AF30: 56041C0A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005AF34: BF870001
	v_fmac_f32_e32 v2, s11, v15                                // 00000005AF38: 56041E0B
	ds_load_2addr_b32 v[12:13], v4 offset0:12 offset1:13       // 00000005AF3C: D8DC0D0C 0C000004
	ds_load_2addr_b32 v[14:15], v4 offset0:14 offset1:15       // 00000005AF44: D8DC0F0E 0E000004
	v_add_nc_u32_e32 v4, 64, v4                                // 00000005AF4C: 4A0808C0
	s_waitcnt lgkmcnt(3)                                       // 00000005AF50: BF89FC37
	v_fmac_f32_e32 v2, s12, v8                                 // 00000005AF54: 5604100C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005AF58: BF8700A1
	v_fmac_f32_e32 v2, s13, v9                                 // 00000005AF5C: 5604120D
	s_waitcnt lgkmcnt(2)                                       // 00000005AF60: BF89FC27
	v_fmac_f32_e32 v2, s14, v10                                // 00000005AF64: 5604140E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005AF68: BF8700A1
	v_fmac_f32_e32 v2, s15, v11                                // 00000005AF6C: 5604160F
	s_waitcnt lgkmcnt(1)                                       // 00000005AF70: BF89FC17
	v_fmac_f32_e32 v2, s16, v12                                // 00000005AF74: 56041810
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005AF78: BF8700A1
	v_fmac_f32_e32 v2, s17, v13                                // 00000005AF7C: 56041A11
	s_waitcnt lgkmcnt(0)                                       // 00000005AF80: BF89FC07
	v_fmac_f32_e32 v2, s18, v14                                // 00000005AF84: 56041C12
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005AF88: BF870001
	v_fmac_f32_e32 v2, s19, v15                                // 00000005AF8C: 56041E13
	s_cbranch_scc0 65483                                       // 00000005AF90: BFA1FFCB <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x2c0>
	s_set_inst_prefetch_distance 0x2                           // 00000005AF94: BF840002
	v_lshlrev_b32_e32 v4, 2, v3                                // 00000005AF98: 30080682
	v_lshlrev_b32_e32 v8, 2, v1                                // 00000005AF9C: 30100282
	ds_load_b32 v4, v4 offset:16512                            // 00000005AFA0: D8D84080 04000004
	ds_load_b32 v8, v8 offset:16512                            // 00000005AFA8: D8D84080 08000008
	s_waitcnt lgkmcnt(0)                                       // 00000005AFB0: BF89FC07
	v_sub_f32_e32 v4, v4, v8                                   // 00000005AFB4: 08081104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005AFB8: BF870121
	v_mul_f32_e32 v8, 0x3fb8aa3b, v4                           // 00000005AFBC: 101008FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 00000005AFC4: 7C3608FF C2CE8ED0
	v_fma_f32 v9, 0x3fb8aa3b, v4, -v8                          // 00000005AFCC: D6130009 842208FF 3FB8AA3B
	v_rndne_f32_e32 v10, v8                                    // 00000005AFD8: 7E144708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AFDC: BF870091
	v_dual_fmac_f32 v9, 0x32a5705f, v4 :: v_dual_sub_f32 v8, v8, v10// 00000005AFE0: C80A08FF 09081508 32A5705F
	v_add_f32_e32 v8, v8, v9                                   // 00000005AFEC: 06101308
	v_cvt_i32_f32_e32 v9, v10                                  // 00000005AFF0: 7E12110A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005AFF4: BF870292
	v_exp_f32_e32 v8, v8                                       // 00000005AFF8: 7E104B08
	.long 0xd71c0008                                           // 00000005AFFC: D71C0008
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 00000005B000: 02021308
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005B004: BF870121
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo                        // 00000005B008: 02101080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 00000005B00C: 7C3C08FF 42B17218
	v_cndmask_b32_e32 v4, 0x7f800000, v8, vcc_lo               // 00000005B014: 020810FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005B01C: BF870001
	v_mul_f32_e32 v8, v2, v4                                   // 00000005B020: 10100902
	s_or_b32 exec_lo, exec_lo, s36                             // 00000005B024: 8C7E247E
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000005B028: 3408069F
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000005B02C: 3404029F
	s_and_not1_b32 vcc_lo, exec_lo, s31                        // 00000005B030: 916A1F7E
	s_cbranch_vccnz 17                                         // 00000005B034: BFA40011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x47c>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005B038: BF870112
	.long 0xd73c0009                                           // 00000005B03C: D73C0009
	v_cndmask_b32_e32 v1, 8, v3, vcc_lo                        // 00000005B040: 02020688
	.long 0xd73c000b                                           // 00000005B044: D73C000B
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000005B048: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B04C: BF870092
	.long 0xd7006a09                                           // 00000005B050: D7006A09
	v_cndmask_b32_e32 v1, s24, v9, vcc_lo                      // 00000005B054: 02021218
	v_add_co_ci_u32_e64 v10, null, s25, v10, vcc_lo            // 00000005B058: D5207C0A 01AA1419
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B060: BF870092
	.long 0xd7006a09                                           // 00000005B064: D7006A09
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 00000005B068: 02021709
	v_add_co_ci_u32_e64 v10, null, v10, v12, vcc_lo            // 00000005B06C: D5207C0A 01AA190A
	global_store_b32 v[9:10], v8, off                          // 00000005B074: DC6A0000 007C0809
	s_and_not1_b32 vcc_lo, exec_lo, s33                        // 00000005B07C: 916A217E
	s_cbranch_vccnz 65385                                      // 00000005B080: BFA4FF69 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x228>
	.long 0xd73c0003                                           // 00000005B084: D73C0003
	v_cndmask_b32_e32 v1, 7, v3, vcc_lo                        // 00000005B088: 02020687
	.long 0xd73c0009                                           // 00000005B08C: D73C0009
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000005B090: 02020281
	v_fma_mixlo_f16 v1, v8, s35, 0                             // 00000005B094: CC210001 02004708
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B09C: BF870093
	.long 0xd7006a02                                           // 00000005B0A0: D7006A02
	v_cndmask_b32_e32 v1, s22, v3, vcc_lo                      // 00000005B0A4: 02020616
	v_add_co_ci_u32_e64 v3, null, s23, v4, vcc_lo              // 00000005B0A8: D5207C03 01AA0817
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B0B0: BF870092
	.long 0xd7006a02                                           // 00000005B0B4: D7006A02
	v_cndmask_b32_e32 v1, v2, v9, vcc_lo                       // 00000005B0B8: 02021302
	v_add_co_ci_u32_e64 v3, null, v3, v10, vcc_lo              // 00000005B0BC: D5207C03 01AA1503
	global_store_b16 v[2:3], v1, off                           // 00000005B0C4: DC660000 007C0102
	s_branch 65366                                             // 00000005B0CC: BFA0FF56 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x228>
	s_or_b32 exec_lo, exec_lo, s30                             // 00000005B0D0: 8C7E1E7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005B0D4: BF870009
	s_mov_b32 s0, exec_lo                                      // 00000005B0D8: BE80007E
	.long 0xd4c4007e                                           // 00000005B0DC: D4C4007E
	v_cndmask_b32_e32 v1, s26, v0, vcc_lo                      // 00000005B0E0: 0202001A
	s_cbranch_execz 86                                         // 00000005B0E4: BFA50056 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x640>
	s_cmp_lg_u64 s[24:25], 0                                   // 00000005B0E8: BF118018
	v_and_b32_e32 v1, 0xe0, v0                                 // 00000005B0EC: 360200FF 000000E0
	s_cselect_b32 s1, -1, 0                                    // 00000005B0F4: 980180C1
	s_ashr_i32 s0, s27, 31                                     // 00000005B0F8: 86009F1B
	.long 0xd7000202                                           // 00000005B0FC: D7000202
	v_cndmask_b32_e32 v1, s27, v0, vcc_lo                      // 00000005B100: 0202001B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000005B104: BF8700B1
	v_add_co_ci_u32_e64 v3, null, s0, 0, s2                    // 00000005B108: D5207C03 00090000
	s_cmp_lg_u64 s[22:23], 0                                   // 00000005B110: BF118016
	.long 0xd7016a02                                           // 00000005B114: D7016A02
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 00000005B118: 02020302
	v_subrev_co_ci_u32_e64 v3, null, 0, v3, vcc_lo             // 00000005B11C: D5227C03 01AA0680
	v_mov_b32_e32 v1, 0                                        // 00000005B124: 7E020280
	v_lshlrev_b32_e32 v7, 8, v6                                // 00000005B128: 300E0C88
	v_lshlrev_b32_e32 v6, 7, v6                                // 00000005B12C: 300C0C87
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000005B130: BF870144
	.long 0xd73c0004                                           // 00000005B134: D73C0004
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000005B138: 02020482
	.long 0xd73c0002                                           // 00000005B13C: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000005B140: 02020481
	s_cselect_b32 s2, -1, 0                                    // 00000005B144: 980280C1
	s_mov_b32 s3, 0                                            // 00000005B148: BE830080
	.long 0xd7006a04                                           // 00000005B14C: D7006A04
	v_cndmask_b32_e32 v1, v7, v4, vcc_lo                       // 00000005B150: 02020907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000005B154: BF870191
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo                // 00000005B158: D5207C05 01AA0A80
	.long 0xd7006a06                                           // 00000005B160: D7006A06
	v_cndmask_b32_e32 v1, v6, v2, vcc_lo                       // 00000005B164: 02020506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005B168: BF870211
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 00000005B16C: D5207C07 01AA0680
	.long 0xd7006a02                                           // 00000005B174: D7006A02
	v_cndmask_b32_e32 v1, s24, v4, vcc_lo                      // 00000005B178: 02020818
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005B17C: BF870211
	v_add_co_ci_u32_e64 v3, null, s25, v5, vcc_lo              // 00000005B180: D5207C03 01AA0A19
	.long 0xd7006a04                                           // 00000005B188: D7006A04
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 00000005B18C: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005B190: BF870001
	v_add_co_ci_u32_e64 v5, null, s23, v7, vcc_lo              // 00000005B194: D5207C05 01AA0E17
	v_dual_mov_b32 v7, v1 :: v_dual_mov_b32 v6, v0             // 00000005B19C: CA100101 07060100
	s_set_inst_prefetch_distance 0x1                           // 00000005B1A4: BF840001
	s_branch 27                                                // 00000005B1A8: BFA0001B <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x618>
	s_nop 0                                                    // 00000005B1AC: BF800000
	s_nop 0                                                    // 00000005B1B0: BF800000
	s_nop 0                                                    // 00000005B1B4: BF800000
	s_nop 0                                                    // 00000005B1B8: BF800000
	s_nop 0                                                    // 00000005B1BC: BF800000
	.long 0xd7006a06                                           // 00000005B1C0: D7006A06
	v_cndmask_b32_e32 v1, 0x100, v6, vcc_lo                    // 00000005B1C4: 02020CFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B1CC: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 00000005B1D0: D5207C07 01AA0E80
	.long 0xd7006a02                                           // 00000005B1D8: D7006A02
	v_cndmask_b32_e32 v1, 0x800, v2, vcc_lo                    // 00000005B1DC: 020204FF 00000800
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000005B1E4: D5207C03 01AA0680
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B1EC: BF8700A4
	v_cmp_le_i32_e32 vcc_lo, s26, v6                           // 00000005B1F0: 7C860C1A
	.long 0xd7000004                                           // 00000005B1F4: D7000004
	v_cndmask_b32_e32 v1, 0x400, v4, vcc_lo                    // 00000005B1F8: 020208FF 00000400
	v_add_co_ci_u32_e64 v5, null, 0, v5, s0                    // 00000005B200: D5207C05 00020A80
	s_or_b32 s3, vcc_lo, s3                                    // 00000005B208: 8C03036A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005B20C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 00000005B210: 917E037E
	s_cbranch_execz 10                                         // 00000005B214: BFA5000A <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x640>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000005B218: 916A017E
	s_cbranch_vccnz 2                                          // 00000005B21C: BFA40002 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x628>
	global_store_b32 v[2:3], v1, off                           // 00000005B220: DC6A0000 007C0102
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 00000005B228: 916A027E
	s_cbranch_vccnz 65508                                      // 00000005B22C: BFA4FFE4 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x5c0>
	.long 0x7e003880                                           // 00000005B230: 7E003880
	global_store_b16 v[4:5], v0, off                           // 00000005B234: DC660000 007C0004
	s_branch 65504                                             // 00000005B23C: BFA0FFE0 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x5c0>
	s_set_inst_prefetch_distance 0x2                           // 00000005B240: BF840002
	s_endpgm                                                   // 00000005B244: BFB00000
		...

