0000000000056700 <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi():
	s_load_b256 s[4:11], s[0:1], null                          // 000000056700: F40C0100 F8000000
	v_lshrrev_b32_e32 v2, 7, v0                                // 000000056708: 32040087
	s_lshl_b32 s1, s2, 6                                       // 00000005670C: 84018602
	v_add_nc_u32_e32 v9, 0xffffff00, v0                        // 000000056710: 4A1200FF FFFFFF00
	s_mov_b32 s12, s3                                          // 000000056718: BE8C0003
	s_ashr_i32 s13, s3, 31                                     // 00000005671C: 860D9F03
	v_or_b32_e32 v10, s1, v2                                   // 000000056720: 38140401
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056724: BF870092
	v_dual_mov_b32 v6, v9 :: v_dual_and_b32 v1, 0x7f, v0       // 000000056728: CA240109 060000FF 0000007F
	v_lshlrev_b32_e32 v4, 2, v1                                // 000000056734: 30080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056738: BF870091
	v_mad_u32_u24 v8, 0x204, v2, v4                            // 00000005673C: D60B0008 041204FF 00000204
	v_dual_mov_b32 v2, v10 :: v_dual_mov_b32 v3, v8            // 000000056748: CA10010A 02020108
	s_waitcnt lgkmcnt(0)                                       // 000000056750: BF89FC07
	.long 0xd7000004                                           // 000000056754: D7000004
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000056758: 02020806
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005675C: BF870001
	v_add_co_ci_u32_e64 v5, null, s7, 0, s0                    // 000000056760: D5207C05 00010007
	s_mov_b32 s0, 0                                            // 000000056768: BE800080
	s_nop 0                                                    // 00000005676C: BF800000
	s_nop 0                                                    // 000000056770: BF800000
	s_nop 0                                                    // 000000056774: BF800000
	s_nop 0                                                    // 000000056778: BF800000
	s_nop 0                                                    // 00000005677C: BF800000
	v_mad_i64_i32 v[11:12], null, v2, 48, s[12:13]             // 000000056780: D6FF7C0B 00316102
	v_add_nc_u32_e32 v6, 0x100, v6                             // 000000056788: 4A0C0CFF 00000100
	v_add_nc_u32_e32 v2, 2, v2                                 // 000000056790: 4A040482
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056794: BF870093
	.long 0xd73c000b                                           // 000000056798: D73C000B
	v_cndmask_b32_e32 v1, 9, v11, vcc_lo                       // 00000005679C: 02021689
	.long 0xd7006a0b                                           // 0000000567A0: D7006A0B
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000000567A4: 02021704
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000567A8: BF870001
	v_add_co_ci_u32_e64 v12, null, v5, v12, vcc_lo             // 0000000567AC: D5207C0C 01AA1905
	v_cmp_lt_u32_e32 vcc_lo, 0x1eff, v6                        // 0000000567B4: 7C920CFF 00001EFF
	global_load_b32 v7, v[11:12], off                          // 0000000567BC: DC520000 077C000B
	s_or_b32 s0, vcc_lo, s0                                    // 0000000567C4: 8C00006A
	s_waitcnt vmcnt(0)                                         // 0000000567C8: BF8903F7
	ds_store_b32 v3, v7                                        // 0000000567CC: D8340000 00000703
	v_add_nc_u32_e32 v3, 0x408, v3                             // 0000000567D4: 4A0606FF 00000408
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 0000000567DC: 917E007E
	s_cbranch_execnz 65511                                     // 0000000567E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x80>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000567E4: 8C7E007E
	v_dual_mov_b32 v1, v10 :: v_dual_lshlrev_b32 v2, 2, v1     // 0000000567E8: CA22010A 01020282
	s_waitcnt lgkmcnt(0)                                       // 0000000567F0: BF89FC07
	s_barrier                                                  // 0000000567F4: BFBD0000
	buffer_gl0_inv                                             // 0000000567F8: E0AC0000 00000000
	.long 0xd700000b                                           // 000000056800: D700000B
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 000000056804: 02020404
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056808: BF870001
	v_add_co_ci_u32_e64 v12, null, s5, 0, s0                   // 00000005680C: D5207C0C 00010005
	v_dual_mov_b32 v2, v8 :: v_dual_mov_b32 v3, v9             // 000000056814: CA100108 02020109
	s_mov_b32 s0, 0                                            // 00000005681C: BE800080
	s_nop 0                                                    // 000000056820: BF800000
	s_nop 0                                                    // 000000056824: BF800000
	s_nop 0                                                    // 000000056828: BF800000
	s_nop 0                                                    // 00000005682C: BF800000
	s_nop 0                                                    // 000000056830: BF800000
	s_nop 0                                                    // 000000056834: BF800000
	s_nop 0                                                    // 000000056838: BF800000
	s_nop 0                                                    // 00000005683C: BF800000
	v_mad_i64_i32 v[4:5], null, v1, 48, s[12:13]               // 000000056840: D6FF7C04 00316101
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000056848: BF8701A2
	v_add_nc_u32_e32 v3, 0x100, v3                             // 00000005684C: 4A0606FF 00000100
	v_add_nc_u32_e32 v1, 2, v1                                 // 000000056854: 4A020282
	.long 0xd73c0004                                           // 000000056858: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 00000005685C: 02020889
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056860: BF870091
	.long 0xd7006a04                                           // 000000056864: D7006A04
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 000000056868: 0202090B
	v_add_co_ci_u32_e64 v5, null, v12, v5, vcc_lo              // 00000005686C: D5207C05 01AA0B0C
	v_cmp_lt_u32_e32 vcc_lo, 0x6ff, v3                         // 000000056874: 7C9206FF 000006FF
	global_load_b32 v4, v[4:5], off                            // 00000005687C: DC520000 047C0004
	s_or_b32 s0, vcc_lo, s0                                    // 000000056884: 8C00006A
	s_waitcnt vmcnt(0)                                         // 000000056888: BF8903F7
	ds_store_b32 v2, v4 offset:33024                           // 00000005688C: D8348100 00000402
	v_add_nc_u32_e32 v2, 0x408, v2                             // 000000056894: 4A0404FF 00000408
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 00000005689C: 917E007E
	s_cbranch_execnz 65511                                     // 0000000568A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x140>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000568A4: 8C7E007E
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v5, 63, v0          // 0000000568A8: CA240080 040400BF
	v_lshrrev_b32_e32 v3, 6, v0                                // 0000000568B0: 32060086
	s_mov_b32 s4, 0x8100                                       // 0000000568B4: BE8400FF 00008100
	s_mul_hi_u32 s0, s2, 48                                    // 0000000568BC: 9680B002
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000568C0: BF870002
	v_or_b32_e32 v1, s1, v5                                    // 0000000568C4: 38020A01
	s_mul_i32 s2, s2, 48                                       // 0000000568C8: 9602B002
	v_mad_u32_u24 v6, 0x204, v3, s4                            // 0000000568CC: D60B0006 001206FF 00000204
	s_add_u32 s2, s2, s12                                      // 0000000568D8: 80020C02
	s_addc_u32 s3, s0, s13                                     // 0000000568DC: 82030D00
	v_mad_u64_u32 v[1:2], null, v1, 48, s[12:13]               // 0000000568E0: D6FE7C01 00316101
	s_lshl_b64 s[2:3], s[2:3], 14                              // 0000000568E8: 84828E02
	v_mul_u32_u24_e32 v7, 0x204, v5                            // 0000000568EC: 160E0AFF 00000204
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v14, v0           // 0000000568F4: CA100106 0D0E0100
	s_add_u32 s2, s10, s2                                      // 0000000568FC: 8002020A
	s_addc_u32 s3, s11, s3                                     // 000000056900: 8203030B
	s_mov_b32 s4, 0                                            // 000000056904: BE840080
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000056908: 3404029F
	s_waitcnt lgkmcnt(0)                                       // 00000005690C: BF89FC07
	s_barrier                                                  // 000000056910: BFBD0000
	buffer_gl0_inv                                             // 000000056914: E0AC0000 00000000
	.long 0xd73c0001                                           // 00000005691C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000056920: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056924: BF870091
	.long 0xd7006a01                                           // 000000056928: D7006A01
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 00000005692C: 02020208
	v_add_co_ci_u32_e64 v2, null, s9, v2, vcc_lo               // 000000056930: D5207C02 01AA0409
	s_branch 24                                                // 000000056938: BFA00018 <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x29c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000005693C: 8C7E007E
	v_and_or_b32 v3, 0x7fffffc0, v14, v5                       // 000000056940: D6570003 04161CFF 7FFFFFC0
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v14                        // 00000005694C: 7C921CFF 000002FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000056954: BF870142
	.long 0xd73c0011                                           // 000000056958: D73C0011
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000005695C: 02020682
	v_add_nc_u32_e32 v3, 0x100, v14                            // 000000056960: 4A061CFF 00000100
	v_add_nc_u32_e32 v13, 0x810, v13                           // 000000056968: 4A1A1AFF 00000810
	s_or_b32 s4, vcc_lo, s4                                    // 000000056970: 8C04046A
	v_mov_b32_e32 v14, v3                                      // 000000056974: 7E1C0303
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056978: BF870094
	.long 0xd7000011                                           // 00000005697C: D7000011
	v_cndmask_b32_e32 v1, s2, v17, vcc_lo                      // 000000056980: 02022202
	v_add_co_ci_u32_e64 v18, null, s3, v18, s0                 // 000000056984: D5207C12 00022403
	global_store_b32 v[17:18], v16, off                        // 00000005698C: DC6A0000 007C1011
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000056994: 917E047E
	s_cbranch_execz 126                                        // 000000056998: BFA5007E <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x494>
	v_lshrrev_b32_e32 v15, 6, v14                              // 00000005699C: 321E1C86
	v_mov_b32_e32 v16, 0                                       // 0000000569A0: 7E200280
	s_mov_b32 s0, exec_lo                                      // 0000000569A4: BE80007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000569A8: BF870002
	.long 0xd4cb007e                                           // 0000000569AC: D4CB007E
	v_cndmask_b32_e32 v1, v5, v15, vcc_lo                      // 0000000569B0: 02021F05
	s_cbranch_execz 65505                                      // 0000000569B4: BFA5FFE1 <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x23c>
	v_mov_b32_e32 v3, 0                                        // 0000000569B8: 7E060280
	s_movk_i32 s5, 0xfe00                                      // 0000000569BC: B005FE00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000569C0: BF870009
	v_add_nc_u32_e32 v32, s5, v13                              // 0000000569C4: 4A401A05
	v_add_nc_u32_e32 v33, s5, v7                               // 0000000569C8: 4A420E05
	s_add_i32 s5, s5, 64                                       // 0000000569CC: 8105C005
	ds_load_2addr_b32 v[16:17], v32 offset0:128 offset1:129    // 0000000569D0: D8DC8180 10000020
	ds_load_2addr_b32 v[18:19], v33 offset0:128 offset1:129    // 0000000569D8: D8DC8180 12000021
	ds_load_2addr_b32 v[20:21], v33 offset0:130 offset1:131    // 0000000569E0: D8DC8382 14000021
	ds_load_2addr_b32 v[22:23], v32 offset0:130 offset1:131    // 0000000569E8: D8DC8382 16000020
	ds_load_2addr_b32 v[24:25], v32 offset0:132 offset1:133    // 0000000569F0: D8DC8584 18000020
	ds_load_2addr_b32 v[26:27], v32 offset0:134 offset1:135    // 0000000569F8: D8DC8786 1A000020
	ds_load_2addr_b32 v[28:29], v33 offset0:132 offset1:133    // 000000056A00: D8DC8584 1C000021
	ds_load_2addr_b32 v[30:31], v33 offset0:134 offset1:135    // 000000056A08: D8DC8786 1E000021
	s_cmp_eq_u32 s5, 0                                         // 000000056A10: BF068005
	s_waitcnt lgkmcnt(6)                                       // 000000056A14: BF89FC67
	v_fmac_f32_e32 v3, v16, v18                                // 000000056A18: 56062510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000056A1C: BF8700D1
	v_fmac_f32_e32 v3, v17, v19                                // 000000056A20: 56062711
	ds_load_2addr_b32 v[16:17], v32 offset0:136 offset1:137    // 000000056A24: D8DC8988 10000020
	ds_load_2addr_b32 v[18:19], v33 offset0:136 offset1:137    // 000000056A2C: D8DC8988 12000021
	s_waitcnt lgkmcnt(6)                                       // 000000056A34: BF89FC67
	v_fmac_f32_e32 v3, v22, v20                                // 000000056A38: 56062916
	v_fmac_f32_e32 v3, v23, v21                                // 000000056A3C: 56062B17
	ds_load_2addr_b32 v[20:21], v32 offset0:138 offset1:139    // 000000056A40: D8DC8B8A 14000020
	ds_load_2addr_b32 v[22:23], v33 offset0:138 offset1:139    // 000000056A48: D8DC8B8A 16000021
	s_waitcnt lgkmcnt(5)                                       // 000000056A50: BF89FC57
	v_fmac_f32_e32 v3, v24, v28                                // 000000056A54: 56063918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056A58: BF8700A1
	v_fmac_f32_e32 v3, v25, v29                                // 000000056A5C: 56063B19
	s_waitcnt lgkmcnt(4)                                       // 000000056A60: BF89FC47
	v_fmac_f32_e32 v3, v26, v30                                // 000000056A64: 56063D1A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056A68: BF870001
	v_fmac_f32_e32 v3, v27, v31                                // 000000056A6C: 56063F1B
	ds_load_2addr_b32 v[24:25], v32 offset0:140 offset1:141    // 000000056A70: D8DC8D8C 18000020
	ds_load_2addr_b32 v[26:27], v32 offset0:142 offset1:143    // 000000056A78: D8DC8F8E 1A000020
	ds_load_2addr_b32 v[28:29], v33 offset0:140 offset1:141    // 000000056A80: D8DC8D8C 1C000021
	ds_load_2addr_b32 v[30:31], v33 offset0:142 offset1:143    // 000000056A88: D8DC8F8E 1E000021
	s_waitcnt lgkmcnt(6)                                       // 000000056A90: BF89FC67
	v_fmac_f32_e32 v3, v16, v18                                // 000000056A94: 56062510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056A98: BF8700A1
	v_fmac_f32_e32 v3, v17, v19                                // 000000056A9C: 56062711
	s_waitcnt lgkmcnt(4)                                       // 000000056AA0: BF89FC47
	v_fmac_f32_e32 v3, v20, v22                                // 000000056AA4: 56062D14
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056AA8: BF8700A1
	v_fmac_f32_e32 v3, v21, v23                                // 000000056AAC: 56062F15
	s_waitcnt lgkmcnt(1)                                       // 000000056AB0: BF89FC17
	v_fmac_f32_e32 v3, v24, v28                                // 000000056AB4: 56063918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056AB8: BF8700A1
	v_fmac_f32_e32 v3, v25, v29                                // 000000056ABC: 56063B19
	s_waitcnt lgkmcnt(0)                                       // 000000056AC0: BF89FC07
	v_fmac_f32_e32 v3, v26, v30                                // 000000056AC4: 56063D1A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056AC8: BF870001
	v_fmac_f32_e32 v3, v27, v31                                // 000000056ACC: 56063F1B
	s_cbranch_scc0 65467                                       // 000000056AD0: BFA1FFBB <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x2c0>
	v_add_nc_u32_e32 v15, s1, v15                              // 000000056AD4: 4A1E1E01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056AD8: BF870091
	v_mad_u64_u32 v[15:16], null, v15, 48, s[12:13]            // 000000056ADC: D6FE7C0F 0031610F
	v_ashrrev_i32_e32 v16, 31, v15                             // 000000056AE4: 34201E9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056AE8: BF870091
	.long 0xd73c000f                                           // 000000056AEC: D73C000F
	v_cndmask_b32_e32 v1, 2, v15, vcc_lo                       // 000000056AF0: 02021E82
	.long 0xd7006a0f                                           // 000000056AF4: D7006A0F
	v_cndmask_b32_e32 v1, s8, v15, vcc_lo                      // 000000056AF8: 02021E08
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056AFC: BF870001
	v_add_co_ci_u32_e64 v16, null, s9, v16, vcc_lo             // 000000056B00: D5207C10 01AA2009
	s_clause 0x1                                               // 000000056B08: BF850001
	global_load_b32 v15, v[15:16], off                         // 000000056B0C: DC520000 0F7C000F
	global_load_b32 v16, v[1:2], off                           // 000000056B14: DC520000 107C0001
	s_waitcnt vmcnt(0)                                         // 000000056B1C: BF8903F7
	v_sub_f32_e32 v15, v15, v16                                // 000000056B20: 081E210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056B24: BF870091
	v_mul_f32_e32 v16, 0x3fb8aa3b, v15                         // 000000056B28: 10201EFF 3FB8AA3B
	v_fma_f32 v17, 0x3fb8aa3b, v15, -v16                       // 000000056B30: D6130011 84421EFF 3FB8AA3B
	v_rndne_f32_e32 v18, v16                                   // 000000056B3C: 7E244710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056B40: BF870091
	v_dual_fmac_f32 v17, 0x32a5705f, v15 :: v_dual_sub_f32 v16, v16, v18// 000000056B44: C80A1EFF 11102510 32A5705F
	v_add_f32_e32 v16, v16, v17                                // 000000056B50: 06202310
	v_cvt_i32_f32_e32 v17, v18                                 // 000000056B54: 7E221112
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v15                  // 000000056B58: 7C361EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000056B60: BF870293
	v_exp_f32_e32 v16, v16                                     // 000000056B64: 7E204B10
	.long 0xd71c0010                                           // 000000056B68: D71C0010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                     // 000000056B6C: 02022310
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000056B70: BF870121
	v_cndmask_b32_e32 v16, 0, v16, vcc_lo                      // 000000056B74: 02202080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v15                  // 000000056B78: 7C3C1EFF 42B17218
	v_cndmask_b32_e32 v15, 0x7f800000, v16, vcc_lo             // 000000056B80: 021E20FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056B88: BF870001
	v_mul_f32_e32 v16, v3, v15                                 // 000000056B8C: 10201F03
	s_branch 65386                                             // 000000056B90: BFA0FF6A <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x23c>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000056B94: 8C7E047E
	v_dual_mov_b32 v4, v8 :: v_dual_add_nc_u32 v3, 16, v10     // 000000056B98: CA200108 04021490
	v_mov_b32_e32 v13, v9                                      // 000000056BA0: 7E1A0309
	s_mov_b32 s0, 0                                            // 000000056BA4: BE800080
	s_waitcnt_vscnt null, 0x0                                  // 000000056BA8: BC7C0000
	s_barrier                                                  // 000000056BAC: BFBD0000
	buffer_gl0_inv                                             // 000000056BB0: E0AC0000 00000000
	s_nop 0                                                    // 000000056BB8: BF800000
	s_nop 0                                                    // 000000056BBC: BF800000
	v_mad_i64_i32 v[14:15], null, v3, 48, s[12:13]             // 000000056BC0: D6FF7C0E 00316103
	v_add_nc_u32_e32 v13, 0x100, v13                           // 000000056BC8: 4A1A1AFF 00000100
	v_add_nc_u32_e32 v3, 2, v3                                 // 000000056BD0: 4A060682
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056BD4: BF870093
	.long 0xd73c000e                                           // 000000056BD8: D73C000E
	v_cndmask_b32_e32 v1, 9, v14, vcc_lo                       // 000000056BDC: 02021C89
	.long 0xd7006a0e                                           // 000000056BE0: D7006A0E
	v_cndmask_b32_e32 v1, v11, v14, vcc_lo                     // 000000056BE4: 02021D0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056BE8: BF870001
	v_add_co_ci_u32_e64 v15, null, v12, v15, vcc_lo            // 000000056BEC: D5207C0F 01AA1F0C
	v_cmp_lt_u32_e32 vcc_lo, 0x6ff, v13                        // 000000056BF4: 7C921AFF 000006FF
	global_load_b32 v14, v[14:15], off                         // 000000056BFC: DC520000 0E7C000E
	s_or_b32 s0, vcc_lo, s0                                    // 000000056C04: 8C00006A
	s_waitcnt vmcnt(0)                                         // 000000056C08: BF8903F7
	ds_store_b32 v4, v14 offset:33024                          // 000000056C0C: D8348100 00000E04
	v_add_nc_u32_e32 v4, 0x408, v4                             // 000000056C14: 4A0808FF 00000408
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 000000056C1C: 917E007E
	s_cbranch_execnz 65511                                     // 000000056C20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x4c0>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000056C24: 8C7E007E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v13, v6             // 000000056C28: CA100080 040C0106
	v_mov_b32_e32 v14, v0                                      // 000000056C30: 7E1C0300
	s_mov_b32 s4, 0                                            // 000000056C34: BE840080
	s_waitcnt lgkmcnt(0)                                       // 000000056C38: BF89FC07
	s_barrier                                                  // 000000056C3C: BFBD0000
	buffer_gl0_inv                                             // 000000056C40: E0AC0000 00000000
	s_branch 23                                                // 000000056C48: BFA00017 <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x5a8>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000056C4C: 8C7E007E
	v_lshl_or_b32 v3, v3, 6, v5                                // 000000056C50: D6560003 04150D03
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v14                        // 000000056C58: 7C921CFF 000002FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000056C60: BF870142
	.long 0xd73c0010                                           // 000000056C64: D73C0010
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000056C68: 02020682
	v_add_nc_u32_e32 v3, 0x100, v14                            // 000000056C6C: 4A061CFF 00000100
	v_add_nc_u32_e32 v13, 0x810, v13                           // 000000056C74: 4A1A1AFF 00000810
	s_or_b32 s4, vcc_lo, s4                                    // 000000056C7C: 8C04046A
	v_mov_b32_e32 v14, v3                                      // 000000056C80: 7E1C0303
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056C84: BF870094
	.long 0xd7000010                                           // 000000056C88: D7000010
	v_cndmask_b32_e32 v1, s2, v16, vcc_lo                      // 000000056C8C: 02022002
	v_add_co_ci_u32_e64 v17, null, s3, v17, s0                 // 000000056C90: D5207C11 00022203
	global_store_b32 v[16:17], v15, off                        // 000000056C98: DC6A0000 007C0F10
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000056CA0: 917E047E
	s_cbranch_execz 127                                        // 000000056CA4: BFA5007F <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x7a4>
	v_lshrrev_b32_e32 v3, 6, v14                               // 000000056CA8: 32061C86
	v_mov_b32_e32 v15, 0                                       // 000000056CAC: 7E1E0280
	s_mov_b32 s0, exec_lo                                      // 000000056CB0: BE80007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056CB4: BF870092
	v_or_b32_e32 v3, 16, v3                                    // 000000056CB8: 38060690
	.long 0xd4cb007e                                           // 000000056CBC: D4CB007E
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 000000056CC0: 02020705
	s_cbranch_execz 65505                                      // 000000056CC4: BFA5FFE1 <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x54c>
	v_mov_b32_e32 v15, 0                                       // 000000056CC8: 7E1E0280
	s_movk_i32 s5, 0xfe00                                      // 000000056CCC: B005FE00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056CD0: BF870009
	v_add_nc_u32_e32 v32, s5, v13                              // 000000056CD4: 4A401A05
	v_add_nc_u32_e32 v33, s5, v7                               // 000000056CD8: 4A420E05
	s_add_i32 s5, s5, 64                                       // 000000056CDC: 8105C005
	ds_load_2addr_b32 v[16:17], v32 offset0:128 offset1:129    // 000000056CE0: D8DC8180 10000020
	ds_load_2addr_b32 v[18:19], v33 offset0:128 offset1:129    // 000000056CE8: D8DC8180 12000021
	ds_load_2addr_b32 v[20:21], v33 offset0:130 offset1:131    // 000000056CF0: D8DC8382 14000021
	ds_load_2addr_b32 v[22:23], v32 offset0:130 offset1:131    // 000000056CF8: D8DC8382 16000020
	ds_load_2addr_b32 v[24:25], v32 offset0:132 offset1:133    // 000000056D00: D8DC8584 18000020
	ds_load_2addr_b32 v[26:27], v32 offset0:134 offset1:135    // 000000056D08: D8DC8786 1A000020
	ds_load_2addr_b32 v[28:29], v33 offset0:132 offset1:133    // 000000056D10: D8DC8584 1C000021
	ds_load_2addr_b32 v[30:31], v33 offset0:134 offset1:135    // 000000056D18: D8DC8786 1E000021
	s_cmp_lg_u32 s5, 0                                         // 000000056D20: BF078005
	s_waitcnt lgkmcnt(6)                                       // 000000056D24: BF89FC67
	v_fmac_f32_e32 v15, v16, v18                               // 000000056D28: 561E2510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000056D2C: BF8700D1
	v_fmac_f32_e32 v15, v17, v19                               // 000000056D30: 561E2711
	ds_load_2addr_b32 v[16:17], v32 offset0:136 offset1:137    // 000000056D34: D8DC8988 10000020
	ds_load_2addr_b32 v[18:19], v33 offset0:136 offset1:137    // 000000056D3C: D8DC8988 12000021
	s_waitcnt lgkmcnt(6)                                       // 000000056D44: BF89FC67
	v_fmac_f32_e32 v15, v22, v20                               // 000000056D48: 561E2916
	v_fmac_f32_e32 v15, v23, v21                               // 000000056D4C: 561E2B17
	ds_load_2addr_b32 v[20:21], v32 offset0:138 offset1:139    // 000000056D50: D8DC8B8A 14000020
	ds_load_2addr_b32 v[22:23], v33 offset0:138 offset1:139    // 000000056D58: D8DC8B8A 16000021
	s_waitcnt lgkmcnt(5)                                       // 000000056D60: BF89FC57
	v_fmac_f32_e32 v15, v24, v28                               // 000000056D64: 561E3918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056D68: BF8700A1
	v_fmac_f32_e32 v15, v25, v29                               // 000000056D6C: 561E3B19
	s_waitcnt lgkmcnt(4)                                       // 000000056D70: BF89FC47
	v_fmac_f32_e32 v15, v26, v30                               // 000000056D74: 561E3D1A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056D78: BF870001
	v_fmac_f32_e32 v15, v27, v31                               // 000000056D7C: 561E3F1B
	ds_load_2addr_b32 v[24:25], v32 offset0:140 offset1:141    // 000000056D80: D8DC8D8C 18000020
	ds_load_2addr_b32 v[26:27], v32 offset0:142 offset1:143    // 000000056D88: D8DC8F8E 1A000020
	ds_load_2addr_b32 v[28:29], v33 offset0:140 offset1:141    // 000000056D90: D8DC8D8C 1C000021
	ds_load_2addr_b32 v[30:31], v33 offset0:142 offset1:143    // 000000056D98: D8DC8F8E 1E000021
	s_waitcnt lgkmcnt(6)                                       // 000000056DA0: BF89FC67
	v_fmac_f32_e32 v15, v16, v18                               // 000000056DA4: 561E2510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056DA8: BF8700A1
	v_fmac_f32_e32 v15, v17, v19                               // 000000056DAC: 561E2711
	s_waitcnt lgkmcnt(4)                                       // 000000056DB0: BF89FC47
	v_fmac_f32_e32 v15, v20, v22                               // 000000056DB4: 561E2D14
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056DB8: BF8700A1
	v_fmac_f32_e32 v15, v21, v23                               // 000000056DBC: 561E2F15
	s_waitcnt lgkmcnt(1)                                       // 000000056DC0: BF89FC17
	v_fmac_f32_e32 v15, v24, v28                               // 000000056DC4: 561E3918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056DC8: BF8700A1
	v_fmac_f32_e32 v15, v25, v29                               // 000000056DCC: 561E3B19
	s_waitcnt lgkmcnt(0)                                       // 000000056DD0: BF89FC07
	v_fmac_f32_e32 v15, v26, v30                               // 000000056DD4: 561E3D1A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056DD8: BF870001
	v_fmac_f32_e32 v15, v27, v31                               // 000000056DDC: 561E3F1B
	s_cbranch_scc1 65467                                       // 000000056DE0: BFA2FFBB <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x5d0>
	v_add_nc_u32_e32 v16, s1, v3                               // 000000056DE4: 4A200601
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056DE8: BF870091
	v_mad_u64_u32 v[16:17], null, v16, 48, s[12:13]            // 000000056DEC: D6FE7C10 00316110
	v_ashrrev_i32_e32 v17, 31, v16                             // 000000056DF4: 3422209F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056DF8: BF870091
	.long 0xd73c0010                                           // 000000056DFC: D73C0010
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 000000056E00: 02022082
	.long 0xd7006a10                                           // 000000056E04: D7006A10
	v_cndmask_b32_e32 v1, s8, v16, vcc_lo                      // 000000056E08: 02022008
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056E0C: BF870001
	v_add_co_ci_u32_e64 v17, null, s9, v17, vcc_lo             // 000000056E10: D5207C11 01AA2209
	s_clause 0x1                                               // 000000056E18: BF850001
	global_load_b32 v16, v[16:17], off                         // 000000056E1C: DC520000 107C0010
	global_load_b32 v17, v[1:2], off                           // 000000056E24: DC520000 117C0001
	s_waitcnt vmcnt(0)                                         // 000000056E2C: BF8903F7
	v_sub_f32_e32 v16, v16, v17                                // 000000056E30: 08202310
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056E34: BF870091
	v_mul_f32_e32 v17, 0x3fb8aa3b, v16                         // 000000056E38: 102220FF 3FB8AA3B
	v_fma_f32 v18, 0x3fb8aa3b, v16, -v17                       // 000000056E40: D6130012 844620FF 3FB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 000000056E4C: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000056E50: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 000000056E54: 08222711
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v16                  // 000000056E58: 7C3620FF C2CE8ED0
	v_fmac_f32_e32 v18, 0x32a5705f, v16                        // 000000056E60: 562420FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000056E68: BF870121
	v_add_f32_e32 v17, v17, v18                                // 000000056E6C: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 000000056E70: 7E241113
	v_exp_f32_e32 v17, v17                                     // 000000056E74: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056E78: BF870095
	.long 0xd71c0011                                           // 000000056E7C: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000056E80: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000056E84: 02222280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v16                  // 000000056E88: 7C3C20FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056E90: BF870092
	v_cndmask_b32_e32 v16, 0x7f800000, v17, vcc_lo             // 000000056E94: 022022FF 7F800000
	v_mul_f32_e32 v15, v15, v16                                // 000000056E9C: 101E210F
	s_branch 65386                                             // 000000056EA0: BFA0FF6A <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x54c>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000056EA4: 8C7E047E
	v_dual_mov_b32 v4, v8 :: v_dual_add_nc_u32 v3, 32, v10     // 000000056EA8: CA200108 040214A0
	v_mov_b32_e32 v13, v9                                      // 000000056EB0: 7E1A0309
	s_mov_b32 s0, 0                                            // 000000056EB4: BE800080
	s_waitcnt_vscnt null, 0x0                                  // 000000056EB8: BC7C0000
	s_barrier                                                  // 000000056EBC: BFBD0000
	buffer_gl0_inv                                             // 000000056EC0: E0AC0000 00000000
	s_nop 0                                                    // 000000056EC8: BF800000
	s_nop 0                                                    // 000000056ECC: BF800000
	s_nop 0                                                    // 000000056ED0: BF800000
	s_nop 0                                                    // 000000056ED4: BF800000
	s_nop 0                                                    // 000000056ED8: BF800000
	s_nop 0                                                    // 000000056EDC: BF800000
	s_nop 0                                                    // 000000056EE0: BF800000
	s_nop 0                                                    // 000000056EE4: BF800000
	s_nop 0                                                    // 000000056EE8: BF800000
	s_nop 0                                                    // 000000056EEC: BF800000
	s_nop 0                                                    // 000000056EF0: BF800000
	s_nop 0                                                    // 000000056EF4: BF800000
	s_nop 0                                                    // 000000056EF8: BF800000
	s_nop 0                                                    // 000000056EFC: BF800000
	v_mad_i64_i32 v[14:15], null, v3, 48, s[12:13]             // 000000056F00: D6FF7C0E 00316103
	v_add_nc_u32_e32 v13, 0x100, v13                           // 000000056F08: 4A1A1AFF 00000100
	v_add_nc_u32_e32 v3, 2, v3                                 // 000000056F10: 4A060682
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056F14: BF870093
	.long 0xd73c000e                                           // 000000056F18: D73C000E
	v_cndmask_b32_e32 v1, 9, v14, vcc_lo                       // 000000056F1C: 02021C89
	.long 0xd7006a0e                                           // 000000056F20: D7006A0E
	v_cndmask_b32_e32 v1, v11, v14, vcc_lo                     // 000000056F24: 02021D0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056F28: BF870001
	v_add_co_ci_u32_e64 v15, null, v12, v15, vcc_lo            // 000000056F2C: D5207C0F 01AA1F0C
	v_cmp_lt_u32_e32 vcc_lo, 0x6ff, v13                        // 000000056F34: 7C921AFF 000006FF
	global_load_b32 v14, v[14:15], off                         // 000000056F3C: DC520000 0E7C000E
	s_or_b32 s0, vcc_lo, s0                                    // 000000056F44: 8C00006A
	s_waitcnt vmcnt(0)                                         // 000000056F48: BF8903F7
	ds_store_b32 v4, v14 offset:33024                          // 000000056F4C: D8348100 00000E04
	v_add_nc_u32_e32 v4, 0x408, v4                             // 000000056F54: 4A0808FF 00000408
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 000000056F5C: 917E007E
	s_cbranch_execnz 65511                                     // 000000056F60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x800>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000056F64: 8C7E007E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v13, v6             // 000000056F68: CA100080 040C0106
	v_mov_b32_e32 v14, v0                                      // 000000056F70: 7E1C0300
	s_mov_b32 s4, 0                                            // 000000056F74: BE840080
	s_waitcnt lgkmcnt(0)                                       // 000000056F78: BF89FC07
	s_barrier                                                  // 000000056F7C: BFBD0000
	buffer_gl0_inv                                             // 000000056F80: E0AC0000 00000000
	s_branch 23                                                // 000000056F88: BFA00017 <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x8e8>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000056F8C: 8C7E007E
	v_lshl_or_b32 v3, v3, 6, v5                                // 000000056F90: D6560003 04150D03
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v14                        // 000000056F98: 7C921CFF 000002FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000056FA0: BF870142
	.long 0xd73c0010                                           // 000000056FA4: D73C0010
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000056FA8: 02020682
	v_add_nc_u32_e32 v3, 0x100, v14                            // 000000056FAC: 4A061CFF 00000100
	v_add_nc_u32_e32 v13, 0x810, v13                           // 000000056FB4: 4A1A1AFF 00000810
	s_or_b32 s4, vcc_lo, s4                                    // 000000056FBC: 8C04046A
	v_mov_b32_e32 v14, v3                                      // 000000056FC0: 7E1C0303
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056FC4: BF870094
	.long 0xd7000010                                           // 000000056FC8: D7000010
	v_cndmask_b32_e32 v1, s2, v16, vcc_lo                      // 000000056FCC: 02022002
	v_add_co_ci_u32_e64 v17, null, s3, v17, s0                 // 000000056FD0: D5207C11 00022203
	global_store_b32 v[16:17], v15, off                        // 000000056FD8: DC6A0000 007C0F10
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000056FE0: 917E047E
	s_cbranch_execz 127                                        // 000000056FE4: BFA5007F <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0xae4>
	v_lshrrev_b32_e32 v3, 6, v14                               // 000000056FE8: 32061C86
	v_mov_b32_e32 v15, 0                                       // 000000056FEC: 7E1E0280
	s_mov_b32 s0, exec_lo                                      // 000000056FF0: BE80007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056FF4: BF870092
	v_or_b32_e32 v3, 32, v3                                    // 000000056FF8: 380606A0
	.long 0xd4cb007e                                           // 000000056FFC: D4CB007E
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 000000057000: 02020705
	s_cbranch_execz 65505                                      // 000000057004: BFA5FFE1 <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x88c>
	v_mov_b32_e32 v15, 0                                       // 000000057008: 7E1E0280
	s_movk_i32 s5, 0xfe00                                      // 00000005700C: B005FE00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000057010: BF870009
	v_add_nc_u32_e32 v32, s5, v13                              // 000000057014: 4A401A05
	v_add_nc_u32_e32 v33, s5, v7                               // 000000057018: 4A420E05
	s_add_i32 s5, s5, 64                                       // 00000005701C: 8105C005
	ds_load_2addr_b32 v[16:17], v32 offset0:128 offset1:129    // 000000057020: D8DC8180 10000020
	ds_load_2addr_b32 v[18:19], v33 offset0:128 offset1:129    // 000000057028: D8DC8180 12000021
	ds_load_2addr_b32 v[20:21], v33 offset0:130 offset1:131    // 000000057030: D8DC8382 14000021
	ds_load_2addr_b32 v[22:23], v32 offset0:130 offset1:131    // 000000057038: D8DC8382 16000020
	ds_load_2addr_b32 v[24:25], v32 offset0:132 offset1:133    // 000000057040: D8DC8584 18000020
	ds_load_2addr_b32 v[26:27], v32 offset0:134 offset1:135    // 000000057048: D8DC8786 1A000020
	ds_load_2addr_b32 v[28:29], v33 offset0:132 offset1:133    // 000000057050: D8DC8584 1C000021
	ds_load_2addr_b32 v[30:31], v33 offset0:134 offset1:135    // 000000057058: D8DC8786 1E000021
	s_cmp_lg_u32 s5, 0                                         // 000000057060: BF078005
	s_waitcnt lgkmcnt(6)                                       // 000000057064: BF89FC67
	v_fmac_f32_e32 v15, v16, v18                               // 000000057068: 561E2510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000005706C: BF8700D1
	v_fmac_f32_e32 v15, v17, v19                               // 000000057070: 561E2711
	ds_load_2addr_b32 v[16:17], v32 offset0:136 offset1:137    // 000000057074: D8DC8988 10000020
	ds_load_2addr_b32 v[18:19], v33 offset0:136 offset1:137    // 00000005707C: D8DC8988 12000021
	s_waitcnt lgkmcnt(6)                                       // 000000057084: BF89FC67
	v_fmac_f32_e32 v15, v22, v20                               // 000000057088: 561E2916
	v_fmac_f32_e32 v15, v23, v21                               // 00000005708C: 561E2B17
	ds_load_2addr_b32 v[20:21], v32 offset0:138 offset1:139    // 000000057090: D8DC8B8A 14000020
	ds_load_2addr_b32 v[22:23], v33 offset0:138 offset1:139    // 000000057098: D8DC8B8A 16000021
	s_waitcnt lgkmcnt(5)                                       // 0000000570A0: BF89FC57
	v_fmac_f32_e32 v15, v24, v28                               // 0000000570A4: 561E3918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000570A8: BF8700A1
	v_fmac_f32_e32 v15, v25, v29                               // 0000000570AC: 561E3B19
	s_waitcnt lgkmcnt(4)                                       // 0000000570B0: BF89FC47
	v_fmac_f32_e32 v15, v26, v30                               // 0000000570B4: 561E3D1A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000570B8: BF870001
	v_fmac_f32_e32 v15, v27, v31                               // 0000000570BC: 561E3F1B
	ds_load_2addr_b32 v[24:25], v32 offset0:140 offset1:141    // 0000000570C0: D8DC8D8C 18000020
	ds_load_2addr_b32 v[26:27], v32 offset0:142 offset1:143    // 0000000570C8: D8DC8F8E 1A000020
	ds_load_2addr_b32 v[28:29], v33 offset0:140 offset1:141    // 0000000570D0: D8DC8D8C 1C000021
	ds_load_2addr_b32 v[30:31], v33 offset0:142 offset1:143    // 0000000570D8: D8DC8F8E 1E000021
	s_waitcnt lgkmcnt(6)                                       // 0000000570E0: BF89FC67
	v_fmac_f32_e32 v15, v16, v18                               // 0000000570E4: 561E2510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000570E8: BF8700A1
	v_fmac_f32_e32 v15, v17, v19                               // 0000000570EC: 561E2711
	s_waitcnt lgkmcnt(4)                                       // 0000000570F0: BF89FC47
	v_fmac_f32_e32 v15, v20, v22                               // 0000000570F4: 561E2D14
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000570F8: BF8700A1
	v_fmac_f32_e32 v15, v21, v23                               // 0000000570FC: 561E2F15
	s_waitcnt lgkmcnt(1)                                       // 000000057100: BF89FC17
	v_fmac_f32_e32 v15, v24, v28                               // 000000057104: 561E3918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000057108: BF8700A1
	v_fmac_f32_e32 v15, v25, v29                               // 00000005710C: 561E3B19
	s_waitcnt lgkmcnt(0)                                       // 000000057110: BF89FC07
	v_fmac_f32_e32 v15, v26, v30                               // 000000057114: 561E3D1A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057118: BF870001
	v_fmac_f32_e32 v15, v27, v31                               // 00000005711C: 561E3F1B
	s_cbranch_scc1 65467                                       // 000000057120: BFA2FFBB <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x910>
	v_add_nc_u32_e32 v16, s1, v3                               // 000000057124: 4A200601
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057128: BF870091
	v_mad_u64_u32 v[16:17], null, v16, 48, s[12:13]            // 00000005712C: D6FE7C10 00316110
	v_ashrrev_i32_e32 v17, 31, v16                             // 000000057134: 3422209F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057138: BF870091
	.long 0xd73c0010                                           // 00000005713C: D73C0010
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 000000057140: 02022082
	.long 0xd7006a10                                           // 000000057144: D7006A10
	v_cndmask_b32_e32 v1, s8, v16, vcc_lo                      // 000000057148: 02022008
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005714C: BF870001
	v_add_co_ci_u32_e64 v17, null, s9, v17, vcc_lo             // 000000057150: D5207C11 01AA2209
	s_clause 0x1                                               // 000000057158: BF850001
	global_load_b32 v16, v[16:17], off                         // 00000005715C: DC520000 107C0010
	global_load_b32 v17, v[1:2], off                           // 000000057164: DC520000 117C0001
	s_waitcnt vmcnt(0)                                         // 00000005716C: BF8903F7
	v_sub_f32_e32 v16, v16, v17                                // 000000057170: 08202310
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057174: BF870091
	v_mul_f32_e32 v17, 0x3fb8aa3b, v16                         // 000000057178: 102220FF 3FB8AA3B
	v_fma_f32 v18, 0x3fb8aa3b, v16, -v17                       // 000000057180: D6130012 844620FF 3FB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000005718C: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000057190: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 000000057194: 08222711
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v16                  // 000000057198: 7C3620FF C2CE8ED0
	v_fmac_f32_e32 v18, 0x32a5705f, v16                        // 0000000571A0: 562420FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000571A8: BF870121
	v_add_f32_e32 v17, v17, v18                                // 0000000571AC: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 0000000571B0: 7E241113
	v_exp_f32_e32 v17, v17                                     // 0000000571B4: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000571B8: BF870095
	.long 0xd71c0011                                           // 0000000571BC: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000000571C0: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000000571C4: 02222280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v16                  // 0000000571C8: 7C3C20FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000571D0: BF870092
	v_cndmask_b32_e32 v16, 0x7f800000, v17, vcc_lo             // 0000000571D4: 022022FF 7F800000
	v_mul_f32_e32 v15, v15, v16                                // 0000000571DC: 101E210F
	s_branch 65386                                             // 0000000571E0: BFA0FF6A <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0x88c>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000571E4: 8C7E047E
	v_add_nc_u32_e32 v3, 48, v10                               // 0000000571E8: 4A0614B0
	s_mov_b32 s0, 0                                            // 0000000571EC: BE800080
	s_waitcnt_vscnt null, 0x0                                  // 0000000571F0: BC7C0000
	s_barrier                                                  // 0000000571F4: BFBD0000
	buffer_gl0_inv                                             // 0000000571F8: E0AC0000 00000000
	v_mad_i64_i32 v[13:14], null, v3, 48, s[12:13]             // 000000057200: D6FF7C0D 00316103
	v_add_nc_u32_e32 v9, 0x100, v9                             // 000000057208: 4A1212FF 00000100
	v_add_nc_u32_e32 v3, 2, v3                                 // 000000057210: 4A060682
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057214: BF870093
	.long 0xd73c000d                                           // 000000057218: D73C000D
	v_cndmask_b32_e32 v1, 9, v13, vcc_lo                       // 00000005721C: 02021A89
	.long 0xd7006a0d                                           // 000000057220: D7006A0D
	v_cndmask_b32_e32 v1, v11, v13, vcc_lo                     // 000000057224: 02021B0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057228: BF870001
	v_add_co_ci_u32_e64 v14, null, v12, v14, vcc_lo            // 00000005722C: D5207C0E 01AA1D0C
	v_cmp_lt_u32_e32 vcc_lo, 0x6ff, v9                         // 000000057234: 7C9212FF 000006FF
	global_load_b32 v4, v[13:14], off                          // 00000005723C: DC520000 047C000D
	s_or_b32 s0, vcc_lo, s0                                    // 000000057244: 8C00006A
	s_waitcnt vmcnt(0)                                         // 000000057248: BF8903F7
	ds_store_b32 v8, v4 offset:33024                           // 00000005724C: D8348100 00000408
	v_add_nc_u32_e32 v8, 0x408, v8                             // 000000057254: 4A1010FF 00000408
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 00000005725C: 917E007E
	s_cbranch_execnz 65511                                     // 000000057260: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0xb00>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000057264: 8C7E007E
	v_mov_b32_e32 v4, 0                                        // 000000057268: 7E080280
	s_mov_b32 s4, 0                                            // 00000005726C: BE840080
	s_waitcnt lgkmcnt(0)                                       // 000000057270: BF89FC07
	s_barrier                                                  // 000000057274: BFBD0000
	buffer_gl0_inv                                             // 000000057278: E0AC0000 00000000
	s_branch 23                                                // 000000057280: BFA00017 <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0xbe0>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000057284: 8C7E007E
	v_lshl_or_b32 v3, v3, 6, v5                                // 000000057288: D6560003 04150D03
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v0                         // 000000057290: 7C9200FF 000002FF
	v_add_nc_u32_e32 v6, 0x810, v6                             // 000000057298: 4A0C0CFF 00000810
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000572A0: BF8700B3
	.long 0xd73c0009                                           // 0000000572A4: D73C0009
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 0000000572A8: 02020682
	v_add_nc_u32_e32 v3, 0x100, v0                             // 0000000572AC: 4A0600FF 00000100
	s_or_b32 s4, vcc_lo, s4                                    // 0000000572B4: 8C04046A
	v_mov_b32_e32 v0, v3                                       // 0000000572B8: 7E000303
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000572BC: BF870093
	.long 0xd7000009                                           // 0000000572C0: D7000009
	v_cndmask_b32_e32 v1, s2, v9, vcc_lo                       // 0000000572C4: 02021202
	v_add_co_ci_u32_e64 v10, null, s3, v10, s0                 // 0000000572C8: D5207C0A 00021403
	global_store_b32 v[9:10], v8, off                          // 0000000572D0: DC6A0000 007C0809
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000572D8: 917E047E
	s_cbranch_execz 127                                        // 0000000572DC: BFA5007F <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0xddc>
	v_lshrrev_b32_e32 v3, 6, v0                                // 0000000572E0: 32060086
	v_mov_b32_e32 v8, 0                                        // 0000000572E4: 7E100280
	s_mov_b32 s0, exec_lo                                      // 0000000572E8: BE80007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000572EC: BF870092
	v_or_b32_e32 v3, 48, v3                                    // 0000000572F0: 380606B0
	.long 0xd4cb007e                                           // 0000000572F4: D4CB007E
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 0000000572F8: 02020705
	s_cbranch_execz 65505                                      // 0000000572FC: BFA5FFE1 <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0xb84>
	v_mov_b32_e32 v8, 0                                        // 000000057300: 7E100280
	s_movk_i32 s5, 0xfe00                                      // 000000057304: B005FE00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000057308: BF870009
	v_add_nc_u32_e32 v25, s5, v6                               // 00000005730C: 4A320C05
	v_add_nc_u32_e32 v26, s5, v7                               // 000000057310: 4A340E05
	s_add_i32 s5, s5, 64                                       // 000000057314: 8105C005
	ds_load_2addr_b32 v[9:10], v25 offset0:128 offset1:129     // 000000057318: D8DC8180 09000019
	ds_load_2addr_b32 v[11:12], v26 offset0:128 offset1:129    // 000000057320: D8DC8180 0B00001A
	ds_load_2addr_b32 v[13:14], v26 offset0:130 offset1:131    // 000000057328: D8DC8382 0D00001A
	ds_load_2addr_b32 v[15:16], v25 offset0:130 offset1:131    // 000000057330: D8DC8382 0F000019
	ds_load_2addr_b32 v[17:18], v25 offset0:132 offset1:133    // 000000057338: D8DC8584 11000019
	ds_load_2addr_b32 v[19:20], v25 offset0:134 offset1:135    // 000000057340: D8DC8786 13000019
	ds_load_2addr_b32 v[21:22], v26 offset0:132 offset1:133    // 000000057348: D8DC8584 1500001A
	ds_load_2addr_b32 v[23:24], v26 offset0:134 offset1:135    // 000000057350: D8DC8786 1700001A
	s_cmp_lg_u32 s5, 0                                         // 000000057358: BF078005
	s_waitcnt lgkmcnt(6)                                       // 00000005735C: BF89FC67
	v_fmac_f32_e32 v8, v9, v11                                 // 000000057360: 56101709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000057364: BF8700D1
	v_fmac_f32_e32 v8, v10, v12                                // 000000057368: 5610190A
	ds_load_2addr_b32 v[9:10], v25 offset0:136 offset1:137     // 00000005736C: D8DC8988 09000019
	ds_load_2addr_b32 v[11:12], v26 offset0:136 offset1:137    // 000000057374: D8DC8988 0B00001A
	s_waitcnt lgkmcnt(6)                                       // 00000005737C: BF89FC67
	v_fmac_f32_e32 v8, v15, v13                                // 000000057380: 56101B0F
	v_fmac_f32_e32 v8, v16, v14                                // 000000057384: 56101D10
	ds_load_2addr_b32 v[13:14], v25 offset0:138 offset1:139    // 000000057388: D8DC8B8A 0D000019
	ds_load_2addr_b32 v[15:16], v26 offset0:138 offset1:139    // 000000057390: D8DC8B8A 0F00001A
	s_waitcnt lgkmcnt(5)                                       // 000000057398: BF89FC57
	v_fmac_f32_e32 v8, v17, v21                                // 00000005739C: 56102B11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000573A0: BF8700A1
	v_fmac_f32_e32 v8, v18, v22                                // 0000000573A4: 56102D12
	s_waitcnt lgkmcnt(4)                                       // 0000000573A8: BF89FC47
	v_fmac_f32_e32 v8, v19, v23                                // 0000000573AC: 56102F13
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000573B0: BF870001
	v_fmac_f32_e32 v8, v20, v24                                // 0000000573B4: 56103114
	ds_load_2addr_b32 v[17:18], v25 offset0:140 offset1:141    // 0000000573B8: D8DC8D8C 11000019
	ds_load_2addr_b32 v[19:20], v25 offset0:142 offset1:143    // 0000000573C0: D8DC8F8E 13000019
	ds_load_2addr_b32 v[21:22], v26 offset0:140 offset1:141    // 0000000573C8: D8DC8D8C 1500001A
	ds_load_2addr_b32 v[23:24], v26 offset0:142 offset1:143    // 0000000573D0: D8DC8F8E 1700001A
	s_waitcnt lgkmcnt(6)                                       // 0000000573D8: BF89FC67
	v_fmac_f32_e32 v8, v9, v11                                 // 0000000573DC: 56101709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000573E0: BF8700A1
	v_fmac_f32_e32 v8, v10, v12                                // 0000000573E4: 5610190A
	s_waitcnt lgkmcnt(4)                                       // 0000000573E8: BF89FC47
	v_fmac_f32_e32 v8, v13, v15                                // 0000000573EC: 56101F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000573F0: BF8700A1
	v_fmac_f32_e32 v8, v14, v16                                // 0000000573F4: 5610210E
	s_waitcnt lgkmcnt(1)                                       // 0000000573F8: BF89FC17
	v_fmac_f32_e32 v8, v17, v21                                // 0000000573FC: 56102B11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000057400: BF8700A1
	v_fmac_f32_e32 v8, v18, v22                                // 000000057404: 56102D12
	s_waitcnt lgkmcnt(0)                                       // 000000057408: BF89FC07
	v_fmac_f32_e32 v8, v19, v23                                // 00000005740C: 56102F13
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057410: BF870001
	v_fmac_f32_e32 v8, v20, v24                                // 000000057414: 56103114
	s_cbranch_scc1 65467                                       // 000000057418: BFA2FFBB <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0xc08>
	v_add_nc_u32_e32 v9, s1, v3                                // 00000005741C: 4A120601
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057420: BF870091
	v_mad_u64_u32 v[9:10], null, v9, 48, s[12:13]              // 000000057424: D6FE7C09 00316109
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000005742C: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057430: BF870091
	.long 0xd73c0009                                           // 000000057434: D73C0009
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000057438: 02021282
	.long 0xd7006a09                                           // 00000005743C: D7006A09
	v_cndmask_b32_e32 v1, s8, v9, vcc_lo                       // 000000057440: 02021208
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057444: BF870001
	v_add_co_ci_u32_e64 v10, null, s9, v10, vcc_lo             // 000000057448: D5207C0A 01AA1409
	s_clause 0x1                                               // 000000057450: BF850001
	global_load_b32 v9, v[9:10], off                           // 000000057454: DC520000 097C0009
	global_load_b32 v10, v[1:2], off                           // 00000005745C: DC520000 0A7C0001
	s_waitcnt vmcnt(0)                                         // 000000057464: BF8903F7
	v_sub_f32_e32 v9, v9, v10                                  // 000000057468: 08121509
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005746C: BF870091
	v_mul_f32_e32 v10, 0x3fb8aa3b, v9                          // 000000057470: 101412FF 3FB8AA3B
	v_fma_f32 v11, 0x3fb8aa3b, v9, -v10                        // 000000057478: D613000B 842A12FF 3FB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000057484: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057488: BF870091
	v_dual_fmac_f32 v11, 0x32a5705f, v9 :: v_dual_sub_f32 v10, v10, v12// 00000005748C: C80A12FF 0B0A190A 32A5705F
	v_add_f32_e32 v10, v10, v11                                // 000000057498: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000005749C: 7E16110C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v9                   // 0000000574A0: 7C3612FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000574A8: BF870293
	v_exp_f32_e32 v10, v10                                     // 0000000574AC: 7E144B0A
	.long 0xd71c000a                                           // 0000000574B0: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000574B4: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000574B8: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000574BC: 02141480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v9                   // 0000000574C0: 7C3C12FF 42B17218
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 0000000574C8: 021214FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000574D0: BF870001
	v_mul_f32_e32 v8, v8, v9                                   // 0000000574D4: 10101308
	s_branch 65386                                             // 0000000574D8: BFA0FF6A <_ZN7halogen12_GLOBAL__N_110k_dnc_att2EPKfS2_S2_Pfi+0xb84>
	s_endpgm                                                   // 0000000574DC: BFB00000
		...

