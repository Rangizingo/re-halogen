0000000000216900 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_():
	s_mov_b32 s16, s3                                          // 000000216900: BE900003
	.long 0xd44a0003                                           // 000000216904: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000216908: 02020080
	s_and_saveexec_b32 s4, s3                                  // 00000021690C: BE842003
	v_mov_b32_e32 v1, 0                                        // 000000216910: 7E020280
	ds_store_b32 v1, v1 offset:512                             // 000000216914: D8340200 00000101
	s_or_b32 exec_lo, exec_lo, s4                              // 00000021691C: 8C7E047E
	s_clause 0x3                                               // 000000216920: BF850003
	s_load_b64 s[22:23], s[0:1], 0x30                          // 000000216924: F4040580 F8000030
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000021692C: F4040300 F8000020
	s_load_b32 s18, s[0:1], 0x28                               // 000000216934: F4000480 F8000028
	s_load_b256 s[4:11], s[0:1], null                          // 00000021693C: F40C0100 F8000000
	.long 0xd71f0003                                           // 000000216944: D71F0003
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000216948: 020100C1
	s_mul_hi_i32 s14, s16, 0x55555556                          // 00000021694C: 970EFF10 55555556
	s_lshl_b32 s19, s2, 6                                      // 000000216954: 84138602
	s_lshr_b32 s15, s14, 31                                    // 000000216958: 850F9F0E
	s_ashr_i32 s17, s16, 31                                    // 00000021695C: 86119F10
	v_xor_b32_e32 v1, 31, v3                                   // 000000216960: 3A02069F
	s_add_i32 s14, s14, s15                                    // 000000216964: 810E0F0E
	s_mul_i32 s15, s2, 0x60000                                 // 000000216968: 960FFF02 00060000
	s_mul_hi_i32 s21, s19, 0x1800                              // 000000216970: 9715FF13 00001800
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v5, 2, v0      // 000000216978: CA220080 0C040082
	v_cmp_gt_u32_e32 vcc_lo, 8, v1                             // 000000216980: 7C980288
	v_and_b32_e32 v2, 16, v1                                   // 000000216984: 36040290
	.long 0xd44c0000                                           // 000000216988: D44C0000
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 00000021698C: 020200C0
	.long 0xd44c0001                                           // 000000216990: D44C0001
	v_cndmask_b32_e32 v1, 32, v0, vcc_lo                       // 000000216994: 020200A0
	v_rsq_f32_e32 v11, 0x43000000                              // 000000216998: 7E165CFF 43000000
	v_cndmask_b32_e64 v4, 8, 0, vcc_lo                         // 0000002169A0: D5010004 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v1                             // 0000002169A8: 7C980284
	s_waitcnt lgkmcnt(0)                                       // 0000002169AC: BF89FC07
	s_cmp_lg_u64 s[22:23], 0                                   // 0000002169B0: BF118016
	v_add_lshl_u32 v6, v2, v3, 2                               // 0000002169B4: D6470006 020A0702
	s_cselect_b32 s20, -1, 0                                   // 0000002169BC: 981480C1
	s_lshl_b32 s24, s14, 7                                     // 0000002169C0: 8418870E
	s_mul_i32 s14, s2, 0xc00                                   // 0000002169C4: 960EFF02 00000C00
	v_cndmask_b32_e64 v8, 4, 0, vcc_lo                         // 0000002169CC: D5010008 01A90084
	s_add_i32 s14, s16, s14                                    // 0000002169D4: 810E0E10
	s_lshl_b64 s[16:17], s[16:17], 7                           // 0000002169D8: 84908710
	v_cmp_gt_u32_e32 vcc_lo, 2, v1                             // 0000002169DC: 7C980282
	s_ashr_i32 s25, s24, 31                                    // 0000002169E0: 86199F18
	s_add_u32 s15, s15, s16                                    // 0000002169E4: 800F100F
	s_addc_u32 s16, s21, s17                                   // 0000002169E8: 82101115
	.long 0xd7000f01                                           // 0000002169EC: D7000F01
	v_cndmask_b32_e32 v1, s15, v0, vcc_lo                      // 0000002169F0: 0202000F
	v_cndmask_b32_e64 v9, 2, 0, vcc_lo                         // 0000002169F4: D5010009 01A90082
	v_add_co_ci_u32_e64 v2, null, s16, 0, s15                  // 0000002169FC: D5207C02 003D0010
	v_cmp_ne_u32_e32 vcc_lo, 31, v3                            // 000000216A04: 7C9A069F
	v_add_lshl_u32 v7, v4, v3, 2                               // 000000216A08: D6470007 020A0704
	v_add_lshl_u32 v8, v8, v3, 2                               // 000000216A10: D6470008 020A0708
	v_add_lshl_u32 v9, v9, v3, 2                               // 000000216A18: D6470009 020A0709
	s_mul_i32 s2, s2, 0x140000                                 // 000000216A20: 9602FF02 00140000
	v_add_co_ci_u32_e64 v10, null, 0, v3, vcc_lo               // 000000216A28: D5207C0A 01AA0680
	.long 0xd73c0003                                           // 000000216A30: D73C0003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000216A34: 02020282
	.long 0xd73c0001                                           // 000000216A38: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000216A3C: 02020281
	s_mul_hi_i32 s15, s19, 0x5000                              // 000000216A40: 970FFF13 00005000
	v_lshlrev_b32_e32 v0, 1, v0                                // 000000216A48: 30000081
	v_lshlrev_b32_e32 v10, 2, v10                              // 000000216A4C: 30141482
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000216A50: BF870094
	.long 0xd7006a0d                                           // 000000216A54: D7006A0D
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000216A58: 02020608
	v_add_co_ci_u32_e64 v14, null, s9, v4, vcc_lo              // 000000216A5C: D5207C0E 01AA0809
	s_lshl_b64 s[8:9], s[24:25], 1                             // 000000216A64: 84888118
	.long 0xd7006a01                                           // 000000216A68: D7006A01
	v_cndmask_b32_e32 v1, s22, v1, vcc_lo                      // 000000216A6C: 02020216
	s_add_u32 s2, s2, s8                                       // 000000216A70: 80020802
	s_addc_u32 s8, s15, s9                                     // 000000216A74: 8208090F
	s_add_u32 s2, s4, s2                                       // 000000216A78: 80020204
	s_addc_u32 s4, s5, s8                                      // 000000216A7C: 82040805
	.long 0xd7000210                                           // 000000216A80: D7000210
	v_cndmask_b32_e32 v1, s2, v0, vcc_lo                       // 000000216A84: 02020002
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000216A88: BF8700B1
	v_add_co_ci_u32_e64 v17, null, s4, 0, s2                   // 000000216A8C: D5207C11 00090004
	v_add_co_ci_u32_e64 v2, null, s23, v2, vcc_lo              // 000000216A94: D5207C02 01AA0417
	.long 0xd7006a00                                           // 000000216A9C: D7006A00
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 000000216AA0: 0202060A
	v_add_co_ci_u32_e64 v15, null, s11, v4, vcc_lo             // 000000216AA4: D5207C0F 01AA080B
	.long 0xd7006a03                                           // 000000216AAC: D7006A03
	v_cndmask_b32_e32 v1, 0x1000, v16, vcc_lo                  // 000000216AB0: 020220FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000216AB8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v17, vcc_lo               // 000000216ABC: D5207C04 01AA2280
	s_mov_b64 s[4:5], 0                                        // 000000216AC4: BE840180
	s_mov_b32 s2, 0x41800000                                   // 000000216AC8: BE8200FF 41800000
	s_barrier                                                  // 000000216AD0: BFBD0000
	buffer_gl0_inv                                             // 000000216AD4: E0AC0000 00000000
	s_branch 37                                                // 000000216ADC: BFA00025 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x274>
	ds_load_b32 v16, v12 offset:512                            // 000000216AE0: D8D80200 1000000C
	s_lshl_b64 s[10:11], s[14:15], 2                           // 000000216AE8: 848A820E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000216AEC: BF870009
	s_add_u32 s10, s12, s10                                    // 000000216AF0: 800A0A0C
	s_addc_u32 s11, s13, s11                                   // 000000216AF4: 820B0B0D
	s_waitcnt lgkmcnt(0)                                       // 000000216AF8: BF89FC07
	v_add_f32_e32 v16, s9, v16                                 // 000000216AFC: 06202009
	ds_store_b32 v12, v16 offset:512                           // 000000216B00: D8340200 0000100C
	global_store_b32 v12, v16, s[10:11]                        // 000000216B08: DC6A0000 000A100C
	s_or_b32 exec_lo, exec_lo, s8                              // 000000216B10: 8C7E087E
	.long 0xd7006a01                                           // 000000216B14: D7006A01
	v_cndmask_b32_e32 v1, 0x3000, v1, vcc_lo                   // 000000216B18: 020202FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000216B20: BF8700A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000216B24: D5207C02 01AA0480
	.long 0xd7006a03                                           // 000000216B2C: D7006A03
	v_cndmask_b32_e32 v1, 0x5000, v3, vcc_lo                   // 000000216B30: 020206FF 00005000
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000216B38: D5207C04 01AA0880
	s_add_u32 s4, s4, 0x6000                                   // 000000216B40: 8004FF04 00006000
	s_addc_u32 s5, s5, 0                                       // 000000216B48: 82058005
	s_add_i32 s14, s14, 48                                     // 000000216B4C: 810EB00E
	s_add_i32 s19, s19, 1                                      // 000000216B50: 81138113
	s_cmp_eq_u32 s4, 0x180000                                  // 000000216B54: BF06FF04 00180000
	s_waitcnt lgkmcnt(0)                                       // 000000216B5C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000216B60: BC7C0000
	s_barrier                                                  // 000000216B64: BFBD0000
	buffer_gl0_inv                                             // 000000216B68: E0AC0000 00000000
	s_cbranch_scc1 230                                         // 000000216B70: BFA200E6 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x60c>
	v_mov_b32_e32 v18, 0                                       // 000000216B74: 7E240280
	s_cmp_lt_i32 s19, s18                                      // 000000216B78: BF041213
	s_cselect_b32 s8, -1, 0                                    // 000000216B7C: 980880C1
	s_cmp_ge_i32 s19, s18                                      // 000000216B80: BF031213
	s_cbranch_scc1 4                                           // 000000216B84: BFA20004 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x298>
	global_load_u16 v16, v[3:4], off offset:-4096              // 000000216B88: DC4A1000 107C0003
	s_waitcnt vmcnt(0)                                         // 000000216B90: BF8903F7
	v_lshlrev_b32_e32 v18, 16, v16                             // 000000216B94: 30242090
	v_cndmask_b32_e64 v16, 0, 1, s8                            // 000000216B98: D5010010 00210280
	v_mov_b32_e32 v17, 0                                       // 000000216BA0: 7E220280
	s_and_not1_b32 vcc_lo, exec_lo, s8                         // 000000216BA4: 916A087E
	s_cbranch_vccnz 4                                          // 000000216BA8: BFA40004 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x2bc>
	global_load_u16 v17, v[3:4], off                           // 000000216BAC: DC4A0000 117C0003
	s_waitcnt vmcnt(0)                                         // 000000216BB4: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000216BB8: 30222290
	v_mul_f32_e32 v19, v18, v18                                // 000000216BBC: 10262512
	s_barrier                                                  // 000000216BC0: BFBD0000
	buffer_gl0_inv                                             // 000000216BC4: E0AC0000 00000000
	ds_store_b32 v5, v19                                       // 000000216BCC: D8340000 00001305
	s_waitcnt lgkmcnt(0)                                       // 000000216BD4: BF89FC07
	s_barrier                                                  // 000000216BD8: BFBD0000
	buffer_gl0_inv                                             // 000000216BDC: E0AC0000 00000000
	s_and_saveexec_b32 s8, s0                                  // 000000216BE4: BE882000
	s_cbranch_execz 6                                          // 000000216BE8: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x304>
	ds_load_2addr_stride64_b32 v[19:20], v5 offset1:1          // 000000216BEC: D8E00100 13000005
	s_waitcnt lgkmcnt(0)                                       // 000000216BF4: BF89FC07
	v_add_f32_e32 v19, v20, v19                                // 000000216BF8: 06262714
	ds_store_b32 v5, v19                                       // 000000216BFC: D8340000 00001305
	s_or_b32 exec_lo, exec_lo, s8                              // 000000216C04: 8C7E087E
	s_waitcnt lgkmcnt(0)                                       // 000000216C08: BF89FC07
	s_barrier                                                  // 000000216C0C: BFBD0000
	buffer_gl0_inv                                             // 000000216C10: E0AC0000 00000000
	s_and_saveexec_b32 s8, s1                                  // 000000216C18: BE882001
	s_cbranch_execz 6                                          // 000000216C1C: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x338>
	ds_load_2addr_b32 v[19:20], v5 offset1:32                  // 000000216C20: D8DC2000 13000005
	s_waitcnt lgkmcnt(0)                                       // 000000216C28: BF89FC07
	v_add_f32_e32 v19, v20, v19                                // 000000216C2C: 06262714
	ds_store_b32 v5, v19                                       // 000000216C30: D8340000 00001305
	s_or_b32 exec_lo, exec_lo, s8                              // 000000216C38: 8C7E087E
	v_mov_b32_e32 v19, 0                                       // 000000216C3C: 7E260280
	s_waitcnt lgkmcnt(0)                                       // 000000216C40: BF89FC07
	s_barrier                                                  // 000000216C44: BFBD0000
	buffer_gl0_inv                                             // 000000216C48: E0AC0000 00000000
	s_and_saveexec_b32 s8, s1                                  // 000000216C50: BE882001
	ds_load_b32 v19, v5                                        // 000000216C54: D8D80000 13000005
	s_or_b32 exec_lo, exec_lo, s8                              // 000000216C5C: 8C7E087E
	s_waitcnt lgkmcnt(0)                                       // 000000216C60: BF89FC07
	ds_bpermute_b32 v20, v6, v19                               // 000000216C64: DACC0000 14001306
	s_waitcnt lgkmcnt(0)                                       // 000000216C6C: BF89FC07
	v_add_f32_e32 v19, v19, v20                                // 000000216C70: 06262913
	ds_bpermute_b32 v20, v7, v19                               // 000000216C74: DACC0000 14001307
	s_waitcnt lgkmcnt(0)                                       // 000000216C7C: BF89FC07
	v_add_f32_e32 v19, v19, v20                                // 000000216C80: 06262913
	ds_bpermute_b32 v20, v8, v19                               // 000000216C84: DACC0000 14001308
	s_waitcnt lgkmcnt(0)                                       // 000000216C8C: BF89FC07
	v_add_f32_e32 v19, v19, v20                                // 000000216C90: 06262913
	ds_bpermute_b32 v20, v9, v19                               // 000000216C94: DACC0000 14001309
	s_waitcnt lgkmcnt(0)                                       // 000000216C9C: BF89FC07
	v_add_f32_e32 v19, v19, v20                                // 000000216CA0: 06262913
	ds_bpermute_b32 v20, v10, v19                              // 000000216CA4: DACC0000 1400130A
	s_and_saveexec_b32 s8, s3                                  // 000000216CAC: BE882003
	s_cbranch_execz 4                                          // 000000216CB0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x3c4>
	s_waitcnt lgkmcnt(0)                                       // 000000216CB4: BF89FC07
	v_add_f32_e32 v19, v19, v20                                // 000000216CB8: 06262913
	ds_store_b32 v12, v19                                      // 000000216CBC: D8340000 0000130C
	s_or_b32 exec_lo, exec_lo, s8                              // 000000216CC4: 8C7E087E
	s_waitcnt lgkmcnt(0)                                       // 000000216CC8: BF89FC07
	s_barrier                                                  // 000000216CCC: BFBD0000
	buffer_gl0_inv                                             // 000000216CD0: E0AC0000 00000000
	ds_load_b32 v19, v12                                       // 000000216CD8: D8D80000 1300000C
	s_waitcnt lgkmcnt(0)                                       // 000000216CE0: BF89FC07
	v_dual_mul_f32 v20, v17, v17 :: v_dual_add_f32 v19, 0x358637bd, v19// 000000216CE4: C8C82311 141226FF 358637BD
	s_delay_alu instid0(VALU_DEP_1)                            // 000000216CF0: BF870001
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v19                     // 000000216CF4: 7C2826FF 00800000
	s_barrier                                                  // 000000216CFC: BFBD0000
	buffer_gl0_inv                                             // 000000216D00: E0AC0000 00000000
	ds_store_b32 v5, v20                                       // 000000216D08: D8340000 00001405
	s_waitcnt lgkmcnt(0)                                       // 000000216D10: BF89FC07
	s_barrier                                                  // 000000216D14: BFBD0000
	buffer_gl0_inv                                             // 000000216D18: E0AC0000 00000000
	s_and_saveexec_b32 s8, s0                                  // 000000216D20: BE882000
	s_cbranch_execz 6                                          // 000000216D24: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x440>
	ds_load_2addr_stride64_b32 v[20:21], v5 offset1:1          // 000000216D28: D8E00100 14000005
	s_waitcnt lgkmcnt(0)                                       // 000000216D30: BF89FC07
	v_add_f32_e32 v20, v21, v20                                // 000000216D34: 06282915
	ds_store_b32 v5, v20                                       // 000000216D38: D8340000 00001405
	s_or_b32 exec_lo, exec_lo, s8                              // 000000216D40: 8C7E087E
	s_waitcnt lgkmcnt(0)                                       // 000000216D44: BF89FC07
	s_barrier                                                  // 000000216D48: BFBD0000
	buffer_gl0_inv                                             // 000000216D4C: E0AC0000 00000000
	s_and_saveexec_b32 s8, s1                                  // 000000216D54: BE882001
	s_cbranch_execz 6                                          // 000000216D58: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x474>
	ds_load_2addr_b32 v[20:21], v5 offset1:32                  // 000000216D5C: D8DC2000 14000005
	s_waitcnt lgkmcnt(0)                                       // 000000216D64: BF89FC07
	v_add_f32_e32 v20, v21, v20                                // 000000216D68: 06282915
	ds_store_b32 v5, v20                                       // 000000216D6C: D8340000 00001405
	s_or_b32 exec_lo, exec_lo, s8                              // 000000216D74: 8C7E087E
	v_mov_b32_e32 v20, 0                                       // 000000216D78: 7E280280
	s_waitcnt lgkmcnt(0)                                       // 000000216D7C: BF89FC07
	s_barrier                                                  // 000000216D80: BFBD0000
	buffer_gl0_inv                                             // 000000216D84: E0AC0000 00000000
	s_and_saveexec_b32 s8, s1                                  // 000000216D8C: BE882001
	ds_load_b32 v20, v5                                        // 000000216D90: D8D80000 14000005
	s_or_b32 exec_lo, exec_lo, s8                              // 000000216D98: 8C7E087E
	s_waitcnt lgkmcnt(0)                                       // 000000216D9C: BF89FC07
	ds_bpermute_b32 v21, v6, v20                               // 000000216DA0: DACC0000 15001406
	s_waitcnt lgkmcnt(0)                                       // 000000216DA8: BF89FC07
	v_add_f32_e32 v20, v20, v21                                // 000000216DAC: 06282B14
	ds_bpermute_b32 v21, v7, v20                               // 000000216DB0: DACC0000 15001407
	s_waitcnt lgkmcnt(0)                                       // 000000216DB8: BF89FC07
	v_add_f32_e32 v20, v20, v21                                // 000000216DBC: 06282B14
	ds_bpermute_b32 v21, v8, v20                               // 000000216DC0: DACC0000 15001408
	s_waitcnt lgkmcnt(0)                                       // 000000216DC8: BF89FC07
	v_add_f32_e32 v20, v20, v21                                // 000000216DCC: 06282B14
	ds_bpermute_b32 v21, v9, v20                               // 000000216DD0: DACC0000 15001409
	s_waitcnt lgkmcnt(0)                                       // 000000216DD8: BF89FC07
	v_add_f32_e32 v20, v20, v21                                // 000000216DDC: 06282B14
	ds_bpermute_b32 v21, v10, v20                              // 000000216DE0: DACC0000 1500140A
	s_and_saveexec_b32 s8, s3                                  // 000000216DE8: BE882003
	s_cbranch_execz 4                                          // 000000216DEC: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x500>
	s_waitcnt lgkmcnt(0)                                       // 000000216DF0: BF89FC07
	v_add_f32_e32 v20, v20, v21                                // 000000216DF4: 06282B14
	ds_store_b32 v12, v20                                      // 000000216DF8: D8340000 0000140C
	s_or_b32 exec_lo, exec_lo, s8                              // 000000216E00: 8C7E087E
	v_mul_f32_e32 v20, 0x4b800000, v19                         // 000000216E04: 102826FF 4B800000
	s_waitcnt lgkmcnt(0)                                       // 000000216E0C: BF89FC07
	s_barrier                                                  // 000000216E10: BFBD0000
	buffer_gl0_inv                                             // 000000216E14: E0AC0000 00000000
	v_cndmask_b32_e32 v19, v19, v20, vcc_lo                    // 000000216E1C: 02262913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000216E20: BF8700B1
	v_rsq_f32_e32 v20, v19                                     // 000000216E24: 7E285D13
	ds_load_b32 v19, v12                                       // 000000216E28: D8D80000 1300000C
	v_mul_f32_e32 v21, 0x45800000, v20                         // 000000216E30: 102A28FF 45800000
	v_cndmask_b32_e32 v20, v20, v21, vcc_lo                    // 000000216E38: 02282B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000216E3C: BF870091
	v_mul_f32_e32 v20, v11, v20                                // 000000216E40: 1028290B
	v_mul_f32_e32 v18, v18, v20                                // 000000216E44: 10242912
	.long 0xd7006a14                                           // 000000216E48: D7006A14
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 000000216E4C: 0200090D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000216E50: BF870001
	v_add_co_ci_u32_e64 v21, null, s5, v14, vcc_lo             // 000000216E54: D5207C15 01AA1C05
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 000000216E5C: 916A147E
	global_store_b32 v[20:21], v18, off                        // 000000216E60: DC6A0000 007C1214
	s_cbranch_vccnz 4                                          // 000000216E68: BFA40004 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x57c>
	v_fma_mixlo_f16 v18, v18, s2, 0                            // 000000216E6C: CC210012 02000512
	global_store_b16 v[1:2], v18, off                          // 000000216E74: DC660000 007C1201
	s_waitcnt lgkmcnt(0)                                       // 000000216E7C: BF89FC07
	v_add_f32_e32 v18, 0x358637bd, v19                         // 000000216E80: 062426FF 358637BD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000216E88: BF870121
	v_mul_f32_e32 v19, 0x4b800000, v18                         // 000000216E8C: 102624FF 4B800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v18                     // 000000216E94: 7C2824FF 00800000
	v_cndmask_b32_e32 v18, v18, v19, vcc_lo                    // 000000216E9C: 02242712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000216EA0: BF870291
	v_rsq_f32_e32 v18, v18                                     // 000000216EA4: 7E245D12
	v_mul_f32_e32 v19, 0x45800000, v18                         // 000000216EA8: 102624FF 45800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000216EB0: BF870091
	v_cndmask_b32_e32 v18, v18, v19, vcc_lo                    // 000000216EB4: 02242712
	v_mul_f32_e32 v19, v17, v18                                // 000000216EB8: 10262511
	.long 0xd7006a11                                           // 000000216EBC: D7006A11
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000216EC0: 02000900
	s_delay_alu instid0(VALU_DEP_1)                            // 000000216EC4: BF870001
	v_add_co_ci_u32_e64 v18, null, s5, v15, vcc_lo             // 000000216EC8: D5207C12 01AA1E05
	global_store_b32 v[17:18], v19, off                        // 000000216ED0: DC6A0000 007C1311
	s_and_saveexec_b32 s8, s3                                  // 000000216ED8: BE882003
	s_cbranch_execz 65292                                      // 000000216EDC: BFA5FF0C <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x210>
	v_cmp_ne_u32_e32 vcc_lo, 1, v16                            // 000000216EE0: 7C9A2081
	s_ashr_i32 s15, s14, 31                                    // 000000216EE4: 860F9F0E
	s_mov_b32 s9, 0                                            // 000000216EE8: BE890080
	s_cbranch_vccnz 65276                                      // 000000216EEC: BFA4FEFC <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x1e0>
	s_lshl_b64 s[10:11], s[14:15], 2                           // 000000216EF0: 848A820E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000216EF4: BF870009
	s_add_u32 s10, s6, s10                                     // 000000216EF8: 800A0A06
	s_addc_u32 s11, s7, s11                                    // 000000216EFC: 820B0B07
	s_load_b32 s9, s[10:11], null                              // 000000216F00: F4000245 F8000000
	s_branch 65269                                             // 000000216F08: BFA0FEF5 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb1ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x1e0>
	s_endpgm                                                   // 000000216F0C: BFB00000
		...

