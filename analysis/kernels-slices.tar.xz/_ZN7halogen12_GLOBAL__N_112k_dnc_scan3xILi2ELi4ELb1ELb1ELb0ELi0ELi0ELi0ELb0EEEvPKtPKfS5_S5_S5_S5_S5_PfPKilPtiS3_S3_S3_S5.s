00000000001f4700 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE():
	s_load_b256 s[16:23], s[0:1], 0x38                         // 0000001F4700: F40C0400 F8000038
	s_lshl_b32 s6, s3, 6                                       // 0000001F4708: 84068603
	s_ashr_i32 s3, s2, 31                                      // 0000001F470C: 86039F02
	s_ashr_i32 s7, s6, 31                                      // 0000001F4710: 86079F06
	v_and_b32_e32 v1, 63, v0                                   // 0000001F4714: 360200BF
	v_mov_b32_e32 v5, v0                                       // 0000001F4718: 7E0A0300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001F471C: BF8704D2
	v_lshlrev_b32_e32 v3, 2, v1                                // 0000001F4720: 30060282
	v_mul_u32_u24_e32 v2, 0x210, v1                            // 0000001F4724: 160402FF 00000210
	s_waitcnt lgkmcnt(0)                                       // 0000001F472C: BF89FC07
	s_load_b32 s4, s[18:19], null                              // 0000001F4730: F4000109 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000001F4738: 84928214
	s_add_u32 s5, s16, s18                                     // 0000001F473C: 80051210
	s_addc_u32 s8, s17, s19                                    // 0000001F4740: 82081311
	s_lshl_b64 s[34:35], s[2:3], 16                            // 0000001F4744: 84A29002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001F4748: BF870009
	s_add_u32 s5, s5, s34                                      // 0000001F474C: 80052205
	s_addc_u32 s8, s8, s35                                     // 0000001F4750: 82082308
	s_waitcnt lgkmcnt(0)                                       // 0000001F4754: BF89FC07
	s_mul_i32 s33, s4, 0x9000000                               // 0000001F4758: 9621FF04 09000000
	s_mul_hi_i32 s15, s4, 0x9000000                            // 0000001F4760: 970FFF04 09000000
	s_add_u32 s4, s5, s33                                      // 0000001F4768: 80042105
	s_addc_u32 s5, s8, s15                                     // 0000001F476C: 82050F08
	s_lshl_b64 s[48:49], s[6:7], 2                             // 0000001F4770: 84B08206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001F4774: BF8700B9
	s_add_u32 s4, s4, s48                                      // 0000001F4778: 80043004
	s_addc_u32 s5, s5, s49                                     // 0000001F477C: 82053105
	.long 0xd7000403                                           // 0000001F4780: D7000403
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000001F4784: 02020604
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 0000001F4788: D5207C04 00110005
	s_mov_b32 s4, 0                                            // 0000001F4790: BE840080
	s_nop 0                                                    // 0000001F4794: BF800000
	s_nop 0                                                    // 0000001F4798: BF800000
	s_nop 0                                                    // 0000001F479C: BF800000
	s_nop 0                                                    // 0000001F47A0: BF800000
	s_nop 0                                                    // 0000001F47A4: BF800000
	s_nop 0                                                    // 0000001F47A8: BF800000
	s_nop 0                                                    // 0000001F47AC: BF800000
	s_nop 0                                                    // 0000001F47B0: BF800000
	s_nop 0                                                    // 0000001F47B4: BF800000
	s_nop 0                                                    // 0000001F47B8: BF800000
	s_nop 0                                                    // 0000001F47BC: BF800000
	v_lshrrev_b32_e32 v8, 6, v5                                // 0000001F47C0: 32100A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001F47C4: BF870121
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000001F47C8: 300C1089
	v_lshl_add_u32 v8, v8, 2, v2                               // 0000001F47CC: D6460008 04090508
	.long 0xd7006a06                                           // 0000001F47D4: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000001F47D8: 02020D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001F47DC: BF8700D1
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000001F47E0: D5207C07 01AA0880
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v5                        // 0000001F47E8: 7C920AFF 00001F7F
	global_load_b32 v6, v[6:7], off                            // 0000001F47F0: DC520000 067C0006
	v_add_nc_u32_e32 v7, 0x80, v5                              // 0000001F47F8: 4A0E0AFF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 0000001F4800: 8C04046A
	v_mov_b32_e32 v5, v7                                       // 0000001F4804: 7E0A0307
	s_waitcnt vmcnt(0)                                         // 0000001F4808: BF8903F7
	ds_store_b32 v8, v6                                        // 0000001F480C: D8340000 00000608
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001F4814: 917E047E
	s_cbranch_execnz 65513                                     // 0000001F4818: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001F481C: 8C7E047E
	s_load_b32 s50, s[0:1], 0x58                               // 0000001F4820: F4000C80 F8000058
	v_mov_b32_e32 v115, 0                                      // 0000001F4828: 7EE60280
	v_or_b32_e32 v127, 0xffffff80, v0                          // 0000001F482C: 38FE00FF FFFFFF80
	v_lshlrev_b32_e32 v5, 3, v0                                // 0000001F4834: 300A0083
	v_lshlrev_b32_e32 v17, 2, v1                               // 0000001F4838: 30220282
	v_mul_u32_u24_e32 v3, 0x210, v1                            // 0000001F483C: 160602FF 00000210
	v_lshrrev_b32_e32 v4, 4, v0                                // 0000001F4844: 32080084
	s_mov_b32 s4, 0                                            // 0000001F4848: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000001F484C: BF89FC07
	s_barrier                                                  // 0000001F4850: BFBD0000
	buffer_gl0_inv                                             // 0000001F4854: E0AC0000 00000000
	s_cmp_gt_i32 s50, 0                                        // 0000001F485C: BF028032
	s_cbranch_scc1 12                                          // 0000001F4860: BFA2000C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x194>
	v_or_b32_e32 v6, 0xffffff80, v0                            // 0000001F4864: 380C00FF FFFFFF80
	v_dual_mov_b32 v7, v115 :: v_dual_and_b32 v114, 0x200, v5  // 0000001F486C: CA240173 07720AFF 00000200
	v_and_or_b32 v132, v4, 4, v3                               // 0000001F4878: D6570084 040D0904
	v_dual_mov_b32 v1, s48 :: v_dual_mov_b32 v2, s49           // 0000001F4880: CA100030 01020031
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 0000001F4888: 916A047E
	s_cbranch_vccz 1                                           // 0000001F488C: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x194>
	s_branch 8057                                              // 0000001F4890: BFA01F79 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7f78>
	s_clause 0x1                                               // 0000001F4894: BF850001
	s_load_b128 s[28:31], s[0:1], 0x10                         // 0000001F4898: F4080700 F8000010
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000001F48A0: F4040200 F8000020
	s_add_i32 s4, s50, 63                                      // 0000001F48A8: 8104BF32
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000001F48AC: 30020082
	s_ashr_i32 s5, s4, 31                                      // 0000001F48B0: 86059F04
	s_load_b256 s[36:43], s[0:1], 0x80                         // 0000001F48B4: F40C0900 F8000080
	s_lshr_b32 s5, s5, 26                                      // 0000001F48BC: 85059A05
	s_mov_b32 s14, 0xcc00                                      // 0000001F48C0: BE8E00FF 0000CC00
	s_add_i32 s10, s4, s5                                      // 0000001F48C8: 810A0504
	s_lshl_b64 s[4:5], s[2:3], 9                               // 0000001F48CC: 84848902
	s_ashr_i32 s51, s10, 6                                     // 0000001F48D0: 8633860A
	v_and_or_b32 v132, v4, 4, v3                               // 0000001F48D4: D6570084 040D0904
	s_mov_b32 s20, 0                                           // 0000001F48DC: BE940080
	s_waitcnt lgkmcnt(0)                                       // 0000001F48E0: BF89FC07
	s_mov_b32 s39, 0x41800000                                  // 0000001F48E4: BEA700FF 41800000
	s_mov_b32 s21, s20                                         // 0000001F48EC: BE950014
	s_mov_b32 s24, s20                                         // 0000001F48F0: BE980014
	s_mov_b32 s25, s20                                         // 0000001F48F4: BE990014
	s_mov_b32 s26, s20                                         // 0000001F48F8: BE9A0014
	s_mov_b32 s27, s20                                         // 0000001F48FC: BE9B0014
	v_mov_b32_e32 v115, 0                                      // 0000001F4900: 7EE60280
	s_add_u32 s4, s28, s4                                      // 0000001F4904: 8004041C
	s_addc_u32 s5, s29, s5                                     // 0000001F4908: 8205051D
	s_add_i32 s52, s50, -1                                     // 0000001F490C: 8134C132
	.long 0xd7000c02                                           // 0000001F4910: D7000C02
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000001F4914: 02020204
	s_mul_i32 s10, s52, 48                                     // 0000001F4918: 960AB034
	s_mul_hi_i32 s11, s52, 48                                  // 0000001F491C: 970BB034
	s_add_u32 s10, s10, s2                                     // 0000001F4920: 800A020A
	s_addc_u32 s11, s11, s3                                    // 0000001F4924: 820B030B
	v_add_co_ci_u32_e64 v6, null, s5, 0, s12                   // 0000001F4928: D5207C06 00310005
	s_lshl_b64 s[10:11], s[10:11], 9                           // 0000001F4930: 848A890A
	.long 0xd7006a07                                           // 0000001F4934: D7006A07
	v_cndmask_b32_e32 v1, 0x17a000, v2, vcc_lo                 // 0000001F4938: 020204FF 0017A000
	s_add_u32 s10, s28, s10                                    // 0000001F4940: 800A0A1C
	s_addc_u32 s11, s29, s11                                   // 0000001F4944: 820B0B1D
	.long 0xd7000a80                                           // 0000001F4948: D7000A80
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000001F494C: 0202020A
	v_add_co_ci_u32_e64 v8, null, 0, v6, vcc_lo                // 0000001F4950: D5207C08 01AA0C80
	v_add_co_ci_u32_e64 v129, null, s11, 0, s10                // 0000001F4958: D5207C81 0029000B
	.long 0xd7006a09                                           // 0000001F4960: D7006A09
	v_cndmask_b32_e32 v1, 0x174000, v2, vcc_lo                 // 0000001F4964: 020204FF 00174000
	s_cmp_gt_u32 s50, 63                                       // 0000001F496C: BF08BF32
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F4970: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4978: 986A80C1
	s_cmp_gt_u32 s50, 62                                       // 0000001F497C: BF08BE32
	v_dual_cndmask_b32 v8, v129, v8 :: v_dual_cndmask_b32 v7, v128, v7// 0000001F4980: CA521181 08060F80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4988: 986A80C1
	s_cmp_gt_u32 s50, 61                                       // 0000001F498C: BF08BD32
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F4990: CA521581 0A081380
	.long 0xd7006a0b                                           // 0000001F4998: D7006A0B
	v_cndmask_b32_e32 v1, 0x16e000, v2, vcc_lo                 // 0000001F499C: 020204FF 0016E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F49A4: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F49A8: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F49B0: 986A80C1
	global_load_b32 v177, v[7:8], off                          // 0000001F49B4: DC520000 B17C0007
	v_dual_cndmask_b32 v7, v128, v11 :: v_dual_cndmask_b32 v8, v129, v12// 0000001F49BC: CA521780 07081981
	global_load_b32 v159, v[9:10], off                         // 0000001F49C4: DC520000 9F7C0009
	.long 0xd7006a09                                           // 0000001F49CC: D7006A09
	v_cndmask_b32_e32 v1, 0x168000, v2, vcc_lo                 // 0000001F49D0: 020204FF 00168000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F49D8: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F49DC: D5207C0A 01AA0C80
	.long 0xd7006a0b                                           // 0000001F49E4: D7006A0B
	v_cndmask_b32_e32 v1, 0x162000, v2, vcc_lo                 // 0000001F49E8: 020204FF 00162000
	s_cmp_gt_u32 s50, 60                                       // 0000001F49F0: BF08BC32
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F49F4: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F49FC: 986A80C1
	s_cmp_gt_u32 s50, 59                                       // 0000001F4A00: BF08BB32
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F4A04: CA521581 0A081380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4A0C: 986A80C1
	s_cmp_gt_u32 s50, 58                                       // 0000001F4A10: BF08BA32
	v_dual_cndmask_b32 v12, v129, v12 :: v_dual_cndmask_b32 v11, v128, v11// 0000001F4A14: CA521981 0C0A1780
	.long 0xd7006a0d                                           // 0000001F4A1C: D7006A0D
	v_cndmask_b32_e32 v1, 0x15c000, v2, vcc_lo                 // 0000001F4A20: 020204FF 0015C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F4A28: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v6, vcc_lo               // 0000001F4A2C: D5207C0E 01AA0C80
	.long 0xd7006a0f                                           // 0000001F4A34: D7006A0F
	v_cndmask_b32_e32 v1, 0x156000, v2, vcc_lo                 // 0000001F4A38: 020204FF 00156000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001F4A40: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4A48: 986A80C1
	s_cmp_gt_u32 s50, 57                                       // 0000001F4A4C: BF08B932
	v_dual_cndmask_b32 v14, v129, v14 :: v_dual_cndmask_b32 v13, v128, v13// 0000001F4A50: CA521D81 0E0C1B80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4A58: 986A80C1
	s_cmp_gt_u32 s50, 56                                       // 0000001F4A5C: BF08B832
	v_dual_cndmask_b32 v16, v129, v16 :: v_dual_cndmask_b32 v15, v128, v15// 0000001F4A60: CA522181 100E1F80
	global_load_b32 v213, v[7:8], off                          // 0000001F4A68: DC520000 D57C0007
	global_load_b32 v212, v[9:10], off                         // 0000001F4A70: DC520000 D47C0009
	global_load_b32 v211, v[11:12], off                        // 0000001F4A78: DC520000 D37C000B
	global_load_b32 v158, v[13:14], off                        // 0000001F4A80: DC520000 9E7C000D
	global_load_b32 v176, v[15:16], off                        // 0000001F4A88: DC520000 B07C000F
	.long 0xd7006a07                                           // 0000001F4A90: D7006A07
	v_cndmask_b32_e32 v1, 0x150000, v2, vcc_lo                 // 0000001F4A94: 020204FF 00150000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F4A9C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v6, vcc_lo                // 0000001F4AA0: D5207C08 01AA0C80
	.long 0xd7006a09                                           // 0000001F4AA8: D7006A09
	v_cndmask_b32_e32 v1, 0x14a000, v2, vcc_lo                 // 0000001F4AAC: 020204FF 0014A000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F4AB4: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4ABC: 986A80C1
	s_cmp_gt_u32 s50, 55                                       // 0000001F4AC0: BF08B732
	v_dual_cndmask_b32 v8, v129, v8 :: v_dual_cndmask_b32 v7, v128, v7// 0000001F4AC4: CA521181 08060F80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4ACC: 986A80C1
	s_cmp_gt_u32 s50, 54                                       // 0000001F4AD0: BF08B632
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F4AD4: CA521581 0A081380
	.long 0xd7006a0b                                           // 0000001F4ADC: D7006A0B
	v_cndmask_b32_e32 v1, 0x144000, v2, vcc_lo                 // 0000001F4AE0: 020204FF 00144000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F4AE8: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F4AEC: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4AF4: 986A80C1
	global_load_b32 v175, v[7:8], off                          // 0000001F4AF8: DC520000 AF7C0007
	v_dual_cndmask_b32 v7, v128, v11 :: v_dual_cndmask_b32 v8, v129, v12// 0000001F4B00: CA521780 07081981
	global_load_b32 v157, v[9:10], off                         // 0000001F4B08: DC520000 9D7C0009
	.long 0xd7006a09                                           // 0000001F4B10: D7006A09
	v_cndmask_b32_e32 v1, 0x13e000, v2, vcc_lo                 // 0000001F4B14: 020204FF 0013E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F4B1C: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F4B20: D5207C0A 01AA0C80
	.long 0xd7006a0b                                           // 0000001F4B28: D7006A0B
	v_cndmask_b32_e32 v1, 0x138000, v2, vcc_lo                 // 0000001F4B2C: 020204FF 00138000
	s_cmp_gt_u32 s50, 53                                       // 0000001F4B34: BF08B532
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F4B38: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4B40: 986A80C1
	s_cmp_gt_u32 s50, 52                                       // 0000001F4B44: BF08B432
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F4B48: CA521581 0A081380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4B50: 986A80C1
	s_cmp_gt_u32 s50, 51                                       // 0000001F4B54: BF08B332
	v_dual_cndmask_b32 v12, v129, v12 :: v_dual_cndmask_b32 v11, v128, v11// 0000001F4B58: CA521981 0C0A1780
	.long 0xd7006a0d                                           // 0000001F4B60: D7006A0D
	v_cndmask_b32_e32 v1, 0x132000, v2, vcc_lo                 // 0000001F4B64: 020204FF 00132000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F4B6C: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v6, vcc_lo               // 0000001F4B70: D5207C0E 01AA0C80
	.long 0xd7006a0f                                           // 0000001F4B78: D7006A0F
	v_cndmask_b32_e32 v1, 0x12c000, v2, vcc_lo                 // 0000001F4B7C: 020204FF 0012C000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001F4B84: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4B8C: 986A80C1
	s_cmp_gt_u32 s50, 50                                       // 0000001F4B90: BF08B232
	v_dual_cndmask_b32 v14, v129, v14 :: v_dual_cndmask_b32 v13, v128, v13// 0000001F4B94: CA521D81 0E0C1B80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4B9C: 986A80C1
	s_cmp_gt_u32 s50, 49                                       // 0000001F4BA0: BF08B132
	v_dual_cndmask_b32 v16, v129, v16 :: v_dual_cndmask_b32 v15, v128, v15// 0000001F4BA4: CA522181 100E1F80
	global_load_b32 v210, v[7:8], off                          // 0000001F4BAC: DC520000 D27C0007
	global_load_b32 v209, v[9:10], off                         // 0000001F4BB4: DC520000 D17C0009
	global_load_b32 v208, v[11:12], off                        // 0000001F4BBC: DC520000 D07C000B
	global_load_b32 v156, v[13:14], off                        // 0000001F4BC4: DC520000 9C7C000D
	global_load_b32 v174, v[15:16], off                        // 0000001F4BCC: DC520000 AE7C000F
	.long 0xd7006a07                                           // 0000001F4BD4: D7006A07
	v_cndmask_b32_e32 v1, 0x126000, v2, vcc_lo                 // 0000001F4BD8: 020204FF 00126000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F4BE0: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v6, vcc_lo                // 0000001F4BE4: D5207C08 01AA0C80
	.long 0xd7006a09                                           // 0000001F4BEC: D7006A09
	v_cndmask_b32_e32 v1, 0x120000, v2, vcc_lo                 // 0000001F4BF0: 020204FF 00120000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F4BF8: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4C00: 986A80C1
	s_cmp_gt_u32 s50, 48                                       // 0000001F4C04: BF08B032
	v_dual_cndmask_b32 v8, v129, v8 :: v_dual_cndmask_b32 v7, v128, v7// 0000001F4C08: CA521181 08060F80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4C10: 986A80C1
	s_cmp_gt_u32 s50, 47                                       // 0000001F4C14: BF08AF32
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F4C18: CA521581 0A081380
	.long 0xd7006a0b                                           // 0000001F4C20: D7006A0B
	v_cndmask_b32_e32 v1, 0x11a000, v2, vcc_lo                 // 0000001F4C24: 020204FF 0011A000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F4C2C: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F4C30: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4C38: 986A80C1
	global_load_b32 v173, v[7:8], off                          // 0000001F4C3C: DC520000 AD7C0007
	v_dual_cndmask_b32 v7, v128, v11 :: v_dual_cndmask_b32 v8, v129, v12// 0000001F4C44: CA521780 07081981
	global_load_b32 v155, v[9:10], off                         // 0000001F4C4C: DC520000 9B7C0009
	.long 0xd7006a09                                           // 0000001F4C54: D7006A09
	v_cndmask_b32_e32 v1, 0x114000, v2, vcc_lo                 // 0000001F4C58: 020204FF 00114000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F4C60: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F4C64: D5207C0A 01AA0C80
	.long 0xd7006a0b                                           // 0000001F4C6C: D7006A0B
	v_cndmask_b32_e32 v1, 0x10e000, v2, vcc_lo                 // 0000001F4C70: 020204FF 0010E000
	s_cmp_gt_u32 s50, 46                                       // 0000001F4C78: BF08AE32
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F4C7C: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4C84: 986A80C1
	s_cmp_gt_u32 s50, 45                                       // 0000001F4C88: BF08AD32
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F4C8C: CA521581 0A081380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4C94: 986A80C1
	s_cmp_gt_u32 s50, 44                                       // 0000001F4C98: BF08AC32
	v_dual_cndmask_b32 v12, v129, v12 :: v_dual_cndmask_b32 v11, v128, v11// 0000001F4C9C: CA521981 0C0A1780
	.long 0xd7006a0d                                           // 0000001F4CA4: D7006A0D
	v_cndmask_b32_e32 v1, 0x108000, v2, vcc_lo                 // 0000001F4CA8: 020204FF 00108000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F4CB0: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v6, vcc_lo               // 0000001F4CB4: D5207C0E 01AA0C80
	.long 0xd7006a0f                                           // 0000001F4CBC: D7006A0F
	v_cndmask_b32_e32 v1, 0x102000, v2, vcc_lo                 // 0000001F4CC0: 020204FF 00102000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001F4CC8: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4CD0: 986A80C1
	s_cmp_gt_u32 s50, 43                                       // 0000001F4CD4: BF08AB32
	v_dual_cndmask_b32 v14, v129, v14 :: v_dual_cndmask_b32 v13, v128, v13// 0000001F4CD8: CA521D81 0E0C1B80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4CE0: 986A80C1
	s_cmp_gt_u32 s50, 42                                       // 0000001F4CE4: BF08AA32
	v_dual_cndmask_b32 v16, v129, v16 :: v_dual_cndmask_b32 v15, v128, v15// 0000001F4CE8: CA522181 100E1F80
	global_load_b32 v187, v[7:8], off                          // 0000001F4CF0: DC520000 BB7C0007
	global_load_b32 v188, v[9:10], off                         // 0000001F4CF8: DC520000 BC7C0009
	global_load_b32 v189, v[11:12], off                        // 0000001F4D00: DC520000 BD7C000B
	global_load_b32 v142, v[13:14], off                        // 0000001F4D08: DC520000 8E7C000D
	global_load_b32 v160, v[15:16], off                        // 0000001F4D10: DC520000 A07C000F
	.long 0xd7006a07                                           // 0000001F4D18: D7006A07
	v_cndmask_b32_e32 v1, 0xfc000, v2, vcc_lo                  // 0000001F4D1C: 020204FF 000FC000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F4D24: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v6, vcc_lo                // 0000001F4D28: D5207C08 01AA0C80
	.long 0xd7006a09                                           // 0000001F4D30: D7006A09
	v_cndmask_b32_e32 v1, 0xf6000, v2, vcc_lo                  // 0000001F4D34: 020204FF 000F6000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F4D3C: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4D44: 986A80C1
	s_cmp_gt_u32 s50, 41                                       // 0000001F4D48: BF08A932
	v_dual_cndmask_b32 v8, v129, v8 :: v_dual_cndmask_b32 v7, v128, v7// 0000001F4D4C: CA521181 08060F80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4D54: 986A80C1
	s_cmp_gt_u32 s50, 40                                       // 0000001F4D58: BF08A832
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F4D5C: CA521581 0A081380
	.long 0xd7006a0b                                           // 0000001F4D64: D7006A0B
	v_cndmask_b32_e32 v1, 0xf0000, v2, vcc_lo                  // 0000001F4D68: 020204FF 000F0000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F4D70: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F4D74: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4D7C: 986A80C1
	global_load_b32 v161, v[7:8], off                          // 0000001F4D80: DC520000 A17C0007
	v_dual_cndmask_b32 v7, v128, v11 :: v_dual_cndmask_b32 v8, v129, v12// 0000001F4D88: CA521780 07081981
	global_load_b32 v143, v[9:10], off                         // 0000001F4D90: DC520000 8F7C0009
	.long 0xd7006a09                                           // 0000001F4D98: D7006A09
	v_cndmask_b32_e32 v1, 0xea000, v2, vcc_lo                  // 0000001F4D9C: 020204FF 000EA000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F4DA4: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F4DA8: D5207C0A 01AA0C80
	.long 0xd7006a0b                                           // 0000001F4DB0: D7006A0B
	v_cndmask_b32_e32 v1, 0xe4000, v2, vcc_lo                  // 0000001F4DB4: 020204FF 000E4000
	s_cmp_gt_u32 s50, 39                                       // 0000001F4DBC: BF08A732
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F4DC0: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4DC8: 986A80C1
	s_cmp_gt_u32 s50, 38                                       // 0000001F4DCC: BF08A632
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F4DD0: CA521581 0A081380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4DD8: 986A80C1
	s_cmp_gt_u32 s50, 37                                       // 0000001F4DDC: BF08A532
	v_dual_cndmask_b32 v12, v129, v12 :: v_dual_cndmask_b32 v11, v128, v11// 0000001F4DE0: CA521981 0C0A1780
	.long 0xd7006a0d                                           // 0000001F4DE8: D7006A0D
	v_cndmask_b32_e32 v1, 0xde000, v2, vcc_lo                  // 0000001F4DEC: 020204FF 000DE000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F4DF4: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v6, vcc_lo               // 0000001F4DF8: D5207C0E 01AA0C80
	.long 0xd7006a0f                                           // 0000001F4E00: D7006A0F
	v_cndmask_b32_e32 v1, 0xd8000, v2, vcc_lo                  // 0000001F4E04: 020204FF 000D8000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001F4E0C: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4E14: 986A80C1
	s_cmp_gt_u32 s50, 36                                       // 0000001F4E18: BF08A432
	v_dual_cndmask_b32 v14, v129, v14 :: v_dual_cndmask_b32 v13, v128, v13// 0000001F4E1C: CA521D81 0E0C1B80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4E24: 986A80C1
	s_cmp_gt_u32 s50, 35                                       // 0000001F4E28: BF08A332
	v_dual_cndmask_b32 v16, v129, v16 :: v_dual_cndmask_b32 v15, v128, v15// 0000001F4E2C: CA522181 100E1F80
	global_load_b32 v190, v[7:8], off                          // 0000001F4E34: DC520000 BE7C0007
	global_load_b32 v191, v[9:10], off                         // 0000001F4E3C: DC520000 BF7C0009
	global_load_b32 v192, v[11:12], off                        // 0000001F4E44: DC520000 C07C000B
	global_load_b32 v144, v[13:14], off                        // 0000001F4E4C: DC520000 907C000D
	global_load_b32 v162, v[15:16], off                        // 0000001F4E54: DC520000 A27C000F
	.long 0xd7006a07                                           // 0000001F4E5C: D7006A07
	v_cndmask_b32_e32 v1, 0xd2000, v2, vcc_lo                  // 0000001F4E60: 020204FF 000D2000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F4E68: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v6, vcc_lo                // 0000001F4E6C: D5207C08 01AA0C80
	.long 0xd7006a09                                           // 0000001F4E74: D7006A09
	v_cndmask_b32_e32 v1, 0xcc000, v2, vcc_lo                  // 0000001F4E78: 020204FF 000CC000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F4E80: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4E88: 986A80C1
	s_cmp_gt_u32 s50, 34                                       // 0000001F4E8C: BF08A232
	v_dual_cndmask_b32 v8, v129, v8 :: v_dual_cndmask_b32 v7, v128, v7// 0000001F4E90: CA521181 08060F80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4E98: 986A80C1
	s_cmp_gt_u32 s50, 33                                       // 0000001F4E9C: BF08A132
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F4EA0: CA521581 0A081380
	.long 0xd7006a0b                                           // 0000001F4EA8: D7006A0B
	v_cndmask_b32_e32 v1, 0xc6000, v2, vcc_lo                  // 0000001F4EAC: 020204FF 000C6000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F4EB4: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F4EB8: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4EC0: 986A80C1
	global_load_b32 v163, v[7:8], off                          // 0000001F4EC4: DC520000 A37C0007
	v_dual_cndmask_b32 v7, v128, v11 :: v_dual_cndmask_b32 v8, v129, v12// 0000001F4ECC: CA521780 07081981
	global_load_b32 v145, v[9:10], off                         // 0000001F4ED4: DC520000 917C0009
	.long 0xd7006a09                                           // 0000001F4EDC: D7006A09
	v_cndmask_b32_e32 v1, 0xc0000, v2, vcc_lo                  // 0000001F4EE0: 020204FF 000C0000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F4EE8: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F4EEC: D5207C0A 01AA0C80
	.long 0xd7006a0b                                           // 0000001F4EF4: D7006A0B
	v_cndmask_b32_e32 v1, 0xba000, v2, vcc_lo                  // 0000001F4EF8: 020204FF 000BA000
	s_cmp_gt_u32 s50, 32                                       // 0000001F4F00: BF08A032
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F4F04: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4F0C: 986A80C1
	s_cmp_gt_u32 s50, 31                                       // 0000001F4F10: BF089F32
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F4F14: CA521581 0A081380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4F1C: 986A80C1
	s_cmp_gt_u32 s50, 30                                       // 0000001F4F20: BF089E32
	v_dual_cndmask_b32 v12, v129, v12 :: v_dual_cndmask_b32 v11, v128, v11// 0000001F4F24: CA521981 0C0A1780
	.long 0xd7006a0d                                           // 0000001F4F2C: D7006A0D
	v_cndmask_b32_e32 v1, 0xb4000, v2, vcc_lo                  // 0000001F4F30: 020204FF 000B4000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F4F38: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v6, vcc_lo               // 0000001F4F3C: D5207C0E 01AA0C80
	.long 0xd7006a0f                                           // 0000001F4F44: D7006A0F
	v_cndmask_b32_e32 v1, 0xae000, v2, vcc_lo                  // 0000001F4F48: 020204FF 000AE000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001F4F50: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4F58: 986A80C1
	s_cmp_gt_u32 s50, 29                                       // 0000001F4F5C: BF089D32
	v_dual_cndmask_b32 v14, v129, v14 :: v_dual_cndmask_b32 v13, v128, v13// 0000001F4F60: CA521D81 0E0C1B80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4F68: 986A80C1
	s_cmp_gt_u32 s50, 28                                       // 0000001F4F6C: BF089C32
	v_dual_cndmask_b32 v16, v129, v16 :: v_dual_cndmask_b32 v15, v128, v15// 0000001F4F70: CA522181 100E1F80
	global_load_b32 v193, v[7:8], off                          // 0000001F4F78: DC520000 C17C0007
	global_load_b32 v194, v[9:10], off                         // 0000001F4F80: DC520000 C27C0009
	global_load_b32 v195, v[11:12], off                        // 0000001F4F88: DC520000 C37C000B
	global_load_b32 v146, v[13:14], off                        // 0000001F4F90: DC520000 927C000D
	global_load_b32 v164, v[15:16], off                        // 0000001F4F98: DC520000 A47C000F
	.long 0xd7006a07                                           // 0000001F4FA0: D7006A07
	v_cndmask_b32_e32 v1, 0xa8000, v2, vcc_lo                  // 0000001F4FA4: 020204FF 000A8000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F4FAC: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v6, vcc_lo                // 0000001F4FB0: D5207C08 01AA0C80
	.long 0xd7006a09                                           // 0000001F4FB8: D7006A09
	v_cndmask_b32_e32 v1, 0xa2000, v2, vcc_lo                  // 0000001F4FBC: 020204FF 000A2000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F4FC4: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4FCC: 986A80C1
	s_cmp_gt_u32 s50, 27                                       // 0000001F4FD0: BF089B32
	v_dual_cndmask_b32 v8, v129, v8 :: v_dual_cndmask_b32 v7, v128, v7// 0000001F4FD4: CA521181 08060F80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F4FDC: 986A80C1
	s_cmp_gt_u32 s50, 26                                       // 0000001F4FE0: BF089A32
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F4FE4: CA521581 0A081380
	.long 0xd7006a0b                                           // 0000001F4FEC: D7006A0B
	v_cndmask_b32_e32 v1, 0x9c000, v2, vcc_lo                  // 0000001F4FF0: 020204FF 0009C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F4FF8: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F4FFC: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F5004: 986A80C1
	global_load_b32 v165, v[7:8], off                          // 0000001F5008: DC520000 A57C0007
	v_dual_cndmask_b32 v7, v128, v11 :: v_dual_cndmask_b32 v8, v129, v12// 0000001F5010: CA521780 07081981
	global_load_b32 v147, v[9:10], off                         // 0000001F5018: DC520000 937C0009
	.long 0xd7006a09                                           // 0000001F5020: D7006A09
	v_cndmask_b32_e32 v1, 0x96000, v2, vcc_lo                  // 0000001F5024: 020204FF 00096000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F502C: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F5030: D5207C0A 01AA0C80
	.long 0xd7006a0b                                           // 0000001F5038: D7006A0B
	v_cndmask_b32_e32 v1, 0x90000, v2, vcc_lo                  // 0000001F503C: 020204FF 00090000
	s_cmp_gt_u32 s50, 25                                       // 0000001F5044: BF089932
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F5048: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F5050: 986A80C1
	s_cmp_gt_u32 s50, 24                                       // 0000001F5054: BF089832
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F5058: CA521581 0A081380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F5060: 986A80C1
	s_cmp_gt_u32 s50, 23                                       // 0000001F5064: BF089732
	v_dual_cndmask_b32 v12, v129, v12 :: v_dual_cndmask_b32 v11, v128, v11// 0000001F5068: CA521981 0C0A1780
	.long 0xd7006a0d                                           // 0000001F5070: D7006A0D
	v_cndmask_b32_e32 v1, 0x8a000, v2, vcc_lo                  // 0000001F5074: 020204FF 0008A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F507C: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v6, vcc_lo               // 0000001F5080: D5207C0E 01AA0C80
	.long 0xd7006a0f                                           // 0000001F5088: D7006A0F
	v_cndmask_b32_e32 v1, 0x84000, v2, vcc_lo                  // 0000001F508C: 020204FF 00084000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001F5094: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F509C: 986A80C1
	s_cmp_gt_u32 s50, 22                                       // 0000001F50A0: BF089632
	v_dual_cndmask_b32 v14, v129, v14 :: v_dual_cndmask_b32 v13, v128, v13// 0000001F50A4: CA521D81 0E0C1B80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F50AC: 986A80C1
	s_cmp_gt_u32 s50, 21                                       // 0000001F50B0: BF089532
	v_dual_cndmask_b32 v16, v129, v16 :: v_dual_cndmask_b32 v15, v128, v15// 0000001F50B4: CA522181 100E1F80
	global_load_b32 v196, v[7:8], off                          // 0000001F50BC: DC520000 C47C0007
	global_load_b32 v197, v[9:10], off                         // 0000001F50C4: DC520000 C57C0009
	global_load_b32 v198, v[11:12], off                        // 0000001F50CC: DC520000 C67C000B
	global_load_b32 v148, v[13:14], off                        // 0000001F50D4: DC520000 947C000D
	global_load_b32 v166, v[15:16], off                        // 0000001F50DC: DC520000 A67C000F
	.long 0xd7006a07                                           // 0000001F50E4: D7006A07
	v_cndmask_b32_e32 v1, 0x7e000, v2, vcc_lo                  // 0000001F50E8: 020204FF 0007E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F50F0: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v6, vcc_lo                // 0000001F50F4: D5207C08 01AA0C80
	.long 0xd7006a09                                           // 0000001F50FC: D7006A09
	v_cndmask_b32_e32 v1, 0x78000, v2, vcc_lo                  // 0000001F5100: 020204FF 00078000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F5108: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F5110: 986A80C1
	s_cmp_gt_u32 s50, 20                                       // 0000001F5114: BF089432
	v_dual_cndmask_b32 v8, v129, v8 :: v_dual_cndmask_b32 v7, v128, v7// 0000001F5118: CA521181 08060F80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F5120: 986A80C1
	s_cmp_gt_u32 s50, 19                                       // 0000001F5124: BF089332
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F5128: CA521581 0A081380
	.long 0xd7006a0b                                           // 0000001F5130: D7006A0B
	v_cndmask_b32_e32 v1, 0x72000, v2, vcc_lo                  // 0000001F5134: 020204FF 00072000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F513C: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F5140: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F5148: 986A80C1
	global_load_b32 v167, v[7:8], off                          // 0000001F514C: DC520000 A77C0007
	v_dual_cndmask_b32 v7, v128, v11 :: v_dual_cndmask_b32 v8, v129, v12// 0000001F5154: CA521780 07081981
	global_load_b32 v149, v[9:10], off                         // 0000001F515C: DC520000 957C0009
	.long 0xd7006a09                                           // 0000001F5164: D7006A09
	v_cndmask_b32_e32 v1, 0x6c000, v2, vcc_lo                  // 0000001F5168: 020204FF 0006C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F5170: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F5174: D5207C0A 01AA0C80
	.long 0xd7006a0b                                           // 0000001F517C: D7006A0B
	v_cndmask_b32_e32 v1, 0x66000, v2, vcc_lo                  // 0000001F5180: 020204FF 00066000
	s_cmp_gt_u32 s50, 18                                       // 0000001F5188: BF089232
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F518C: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F5194: 986A80C1
	s_cmp_gt_u32 s50, 17                                       // 0000001F5198: BF089132
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F519C: CA521581 0A081380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F51A4: 986A80C1
	s_cmp_gt_u32 s50, 16                                       // 0000001F51A8: BF089032
	v_dual_cndmask_b32 v12, v129, v12 :: v_dual_cndmask_b32 v11, v128, v11// 0000001F51AC: CA521981 0C0A1780
	.long 0xd7006a0d                                           // 0000001F51B4: D7006A0D
	v_cndmask_b32_e32 v1, 0x60000, v2, vcc_lo                  // 0000001F51B8: 020204FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F51C0: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v6, vcc_lo               // 0000001F51C4: D5207C0E 01AA0C80
	.long 0xd7006a0f                                           // 0000001F51CC: D7006A0F
	v_cndmask_b32_e32 v1, 0x5a000, v2, vcc_lo                  // 0000001F51D0: 020204FF 0005A000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001F51D8: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F51E0: 986A80C1
	s_cmp_gt_u32 s50, 15                                       // 0000001F51E4: BF088F32
	v_dual_cndmask_b32 v14, v129, v14 :: v_dual_cndmask_b32 v13, v128, v13// 0000001F51E8: CA521D81 0E0C1B80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F51F0: 986A80C1
	s_cmp_gt_u32 s50, 14                                       // 0000001F51F4: BF088E32
	v_dual_cndmask_b32 v16, v129, v16 :: v_dual_cndmask_b32 v15, v128, v15// 0000001F51F8: CA522181 100E1F80
	global_load_b32 v199, v[7:8], off                          // 0000001F5200: DC520000 C77C0007
	global_load_b32 v200, v[9:10], off                         // 0000001F5208: DC520000 C87C0009
	global_load_b32 v201, v[11:12], off                        // 0000001F5210: DC520000 C97C000B
	global_load_b32 v150, v[13:14], off                        // 0000001F5218: DC520000 967C000D
	global_load_b32 v168, v[15:16], off                        // 0000001F5220: DC520000 A87C000F
	.long 0xd7006a07                                           // 0000001F5228: D7006A07
	v_cndmask_b32_e32 v1, 0x54000, v2, vcc_lo                  // 0000001F522C: 020204FF 00054000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F5234: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v6, vcc_lo                // 0000001F5238: D5207C08 01AA0C80
	.long 0xd7006a09                                           // 0000001F5240: D7006A09
	v_cndmask_b32_e32 v1, 0x4e000, v2, vcc_lo                  // 0000001F5244: 020204FF 0004E000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F524C: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F5254: 986A80C1
	s_cmp_gt_u32 s50, 13                                       // 0000001F5258: BF088D32
	v_dual_cndmask_b32 v8, v129, v8 :: v_dual_cndmask_b32 v7, v128, v7// 0000001F525C: CA521181 08060F80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F5264: 986A80C1
	s_cmp_gt_u32 s50, 12                                       // 0000001F5268: BF088C32
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F526C: CA521581 0A081380
	.long 0xd7006a0b                                           // 0000001F5274: D7006A0B
	v_cndmask_b32_e32 v1, 0x48000, v2, vcc_lo                  // 0000001F5278: 020204FF 00048000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F5280: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F5284: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F528C: 986A80C1
	global_load_b32 v169, v[7:8], off                          // 0000001F5290: DC520000 A97C0007
	v_dual_cndmask_b32 v7, v128, v11 :: v_dual_cndmask_b32 v8, v129, v12// 0000001F5298: CA521780 07081981
	global_load_b32 v151, v[9:10], off                         // 0000001F52A0: DC520000 977C0009
	.long 0xd7006a09                                           // 0000001F52A8: D7006A09
	v_cndmask_b32_e32 v1, 0x42000, v2, vcc_lo                  // 0000001F52AC: 020204FF 00042000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F52B4: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F52B8: D5207C0A 01AA0C80
	.long 0xd7006a0b                                           // 0000001F52C0: D7006A0B
	v_cndmask_b32_e32 v1, 0x3c000, v2, vcc_lo                  // 0000001F52C4: 020204FF 0003C000
	s_cmp_gt_u32 s50, 11                                       // 0000001F52CC: BF088B32
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F52D0: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F52D8: 986A80C1
	s_cmp_gt_u32 s50, 10                                       // 0000001F52DC: BF088A32
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F52E0: CA521581 0A081380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F52E8: 986A80C1
	s_cmp_gt_u32 s50, 9                                        // 0000001F52EC: BF088932
	v_dual_cndmask_b32 v12, v129, v12 :: v_dual_cndmask_b32 v11, v128, v11// 0000001F52F0: CA521981 0C0A1780
	.long 0xd7006a0d                                           // 0000001F52F8: D7006A0D
	v_cndmask_b32_e32 v1, 0x36000, v2, vcc_lo                  // 0000001F52FC: 020204FF 00036000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F5304: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v6, vcc_lo               // 0000001F5308: D5207C0E 01AA0C80
	.long 0xd7006a0f                                           // 0000001F5310: D7006A0F
	v_cndmask_b32_e32 v1, 0x30000, v2, vcc_lo                  // 0000001F5314: 020204FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001F531C: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F5324: 986A80C1
	s_cmp_gt_u32 s50, 8                                        // 0000001F5328: BF088832
	v_dual_cndmask_b32 v14, v129, v14 :: v_dual_cndmask_b32 v13, v128, v13// 0000001F532C: CA521D81 0E0C1B80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F5334: 986A80C1
	s_cmp_gt_u32 s50, 7                                        // 0000001F5338: BF088732
	v_dual_cndmask_b32 v16, v129, v16 :: v_dual_cndmask_b32 v15, v128, v15// 0000001F533C: CA522181 100E1F80
	global_load_b32 v202, v[7:8], off                          // 0000001F5344: DC520000 CA7C0007
	global_load_b32 v203, v[9:10], off                         // 0000001F534C: DC520000 CB7C0009
	global_load_b32 v204, v[11:12], off                        // 0000001F5354: DC520000 CC7C000B
	global_load_b32 v152, v[13:14], off                        // 0000001F535C: DC520000 987C000D
	global_load_b32 v170, v[15:16], off                        // 0000001F5364: DC520000 AA7C000F
	.long 0xd7006a07                                           // 0000001F536C: D7006A07
	v_cndmask_b32_e32 v1, 0x2a000, v2, vcc_lo                  // 0000001F5370: 020204FF 0002A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F5378: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v6, vcc_lo                // 0000001F537C: D5207C08 01AA0C80
	.long 0xd7006a09                                           // 0000001F5384: D7006A09
	v_cndmask_b32_e32 v1, 0x24000, v2, vcc_lo                  // 0000001F5388: 020204FF 00024000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F5390: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F5398: 986A80C1
	s_cmp_gt_u32 s50, 6                                        // 0000001F539C: BF088632
	v_dual_cndmask_b32 v8, v129, v8 :: v_dual_cndmask_b32 v7, v128, v7// 0000001F53A0: CA521181 08060F80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F53A8: 986A80C1
	s_cmp_gt_u32 s50, 5                                        // 0000001F53AC: BF088532
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F53B0: CA521581 0A081380
	.long 0xd7006a0b                                           // 0000001F53B8: D7006A0B
	v_cndmask_b32_e32 v1, 0x1e000, v2, vcc_lo                  // 0000001F53BC: 020204FF 0001E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F53C4: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F53C8: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F53D0: 986A80C1
	global_load_b32 v171, v[7:8], off                          // 0000001F53D4: DC520000 AB7C0007
	v_dual_cndmask_b32 v7, v128, v11 :: v_dual_cndmask_b32 v8, v129, v12// 0000001F53DC: CA521780 07081981
	global_load_b32 v153, v[9:10], off                         // 0000001F53E4: DC520000 997C0009
	.long 0xd7006a09                                           // 0000001F53EC: D7006A09
	v_cndmask_b32_e32 v1, 0x18000, v2, vcc_lo                  // 0000001F53F0: 020204FF 00018000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F53F8: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001F53FC: D5207C0A 01AA0C80
	.long 0xd7006a0b                                           // 0000001F5404: D7006A0B
	v_cndmask_b32_e32 v1, 0x12000, v2, vcc_lo                  // 0000001F5408: 020204FF 00012000
	s_cmp_gt_u32 s50, 4                                        // 0000001F5410: BF088432
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001F5414: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F541C: 986A80C1
	s_cmp_gt_u32 s50, 3                                        // 0000001F5420: BF088332
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001F5424: CA521581 0A081380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F542C: 986A80C1
	s_cmp_gt_u32 s50, 2                                        // 0000001F5430: BF088232
	v_dual_cndmask_b32 v12, v129, v12 :: v_dual_cndmask_b32 v11, v128, v11// 0000001F5434: CA521981 0C0A1780
	.long 0xd7006a0d                                           // 0000001F543C: D7006A0D
	v_cndmask_b32_e32 v1, 0xc000, v2, vcc_lo                   // 0000001F5440: 020204FF 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F5448: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v6, vcc_lo               // 0000001F544C: D5207C0E 01AA0C80
	.long 0xd7006a02                                           // 0000001F5454: D7006A02
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 0000001F5458: 020204FF 00006000
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo                // 0000001F5460: D5207C06 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F5468: 986A80C1
	s_cmp_eq_u32 s50, 1                                        // 0000001F546C: BF068132
	v_dual_cndmask_b32 v14, v129, v14 :: v_dual_cndmask_b32 v13, v128, v13// 0000001F5470: CA521D81 0E0C1B80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001F5478: 986A80C1
	v_dual_cndmask_b32 v15, v2, v128 :: v_dual_add_nc_u32 v126, 0xf100, v1// 0000001F547C: CA610102 0F7E02FF 0000F100
	v_cndmask_b32_e32 v16, v6, v129, vcc_lo                    // 0000001F5488: 02210306
	global_load_b32 v205, v[7:8], off                          // 0000001F548C: DC520000 CD7C0007
	global_load_b32 v206, v[9:10], off                         // 0000001F5494: DC520000 CE7C0009
	global_load_b32 v207, v[11:12], off                        // 0000001F549C: DC520000 CF7C000B
	global_load_b32 v154, v[13:14], off                        // 0000001F54A4: DC520000 9A7C000D
	global_load_b32 v172, v[15:16], off                        // 0000001F54AC: DC520000 AC7C000F
	global_load_b32 v138, v1, s[4:5]                           // 0000001F54B4: DC520000 8A040001
	.long 0xd7000402                                           // 0000001F54BC: D7000402
	v_cndmask_b32_e32 v1, s28, v1, vcc_lo                      // 0000001F54C0: 0202021C
	v_dual_mov_b32 v5, v115 :: v_dual_and_b32 v114, 0x200, v5  // 0000001F54C4: CA240173 05720AFF 00000200
	s_clause 0x1                                               // 0000001F54D0: BF850001
	s_load_b64 s[10:11], s[0:1], 0x70                          // 0000001F54D4: F4040280 F8000070
	s_load_b128 s[44:47], s[0:1], 0x60                         // 0000001F54DC: F4080B00 F8000060
	s_clause 0x1                                               // 0000001F54E4: BF850001
	scratch_store_b32 off, v2, off                             // 0000001F54E8: DC690000 007C0200
	scratch_store_b32 off, v17, off offset:8                   // 0000001F54F0: DC690008 007C1100
	v_add_co_ci_u32_e64 v2, null, s29, 0, s4                   // 0000001F54F8: D5207C02 0011001D
	v_and_b32_e32 v7, 15, v0                                   // 0000001F5500: 360E008F
	v_or_b32_e32 v140, 0xf000, v1                              // 0000001F5504: 391802FF 0000F000
	v_bfe_u32 v1, v0, 4, 1                                     // 0000001F550C: D6100001 02050900
	s_clause 0x1                                               // 0000001F5514: BF850001
	scratch_store_b32 off, v2, off offset:4                    // 0000001F5518: DC690004 007C0200
	scratch_store_b32 off, v5, off offset:12                   // 0000001F5520: DC69000C 007C0500
	v_lshrrev_b32_e32 v2, 5, v0                                // 0000001F5528: 32040085
	s_add_i32 s28, s2, 0xbd0                                   // 0000001F552C: 811CFF02 00000BD0
	s_add_u32 s12, s8, s48                                     // 0000001F5534: 800C3008
	s_addc_u32 s13, s9, s49                                    // 0000001F5538: 820D3109
	s_lshl_b32 s8, s2, 7                                       // 0000001F553C: 84088702
	v_lshlrev_b32_e32 v6, 4, v2                                // 0000001F5540: 300C0484
	v_mul_u32_u24_e32 v8, 0x2100, v2                           // 0000001F5544: 161004FF 00002100
	s_movk_i32 s5, 0x90                                        // 0000001F554C: B0050090
	s_ashr_i32 s9, s8, 31                                      // 0000001F5550: 86099F08
	v_mad_u32_u24 v136, v0, s5, 0x8400                         // 0000001F5554: D60B0088 03FC0B00 00008400
	v_or_b32_e32 v135, v6, v7                                  // 0000001F5560: 390E0F06
	v_or_b32_e32 v141, v1, v6                                  // 0000001F5564: 391A0D01
	v_mad_u32_u24 v6, 0x210, v7, v8                            // 0000001F5568: D60B0006 04220EFF 00000210
	v_lshlrev_b32_e32 v8, 2, v7                                // 0000001F5574: 30100E82
	s_lshl_b64 s[8:9], s[8:9], 1                               // 0000001F5578: 84888108
	v_mad_u32_u24 v179, v7, s5, 0x8400                         // 0000001F557C: D60B00B3 03FC0B07 00008400
	s_add_u32 s8, s22, s8                                      // 0000001F5588: 80080816
	v_lshl_or_b32 v180, v1, 2, v6                              // 0000001F558C: D65600B4 04190501
	v_lshlrev_b32_e32 v1, 7, v135                              // 0000001F5594: 30030E87
	.long 0xd70005b5                                           // 0000001F5598: D70005B5
	v_cndmask_b32_e32 v1, s12, v8, vcc_lo                      // 0000001F559C: 0202100C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001F55A0: BF8701A1
	v_add_co_ci_u32_e64 v182, null, s13, 0, s5                 // 0000001F55A4: D5207CB6 0015000D
	s_waitcnt lgkmcnt(0)                                       // 0000001F55AC: BF89FC07
	.long 0xd70005b8                                           // 0000001F55B0: D70005B8
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000001F55B4: 0202020A
	v_lshlrev_b32_e32 v1, 1, v7                                // 0000001F55B8: 30020E81
	s_addc_u32 s9, s23, s9                                     // 0000001F55BC: 82090917
	s_lshl_b64 s[6:7], s[6:7], 1                               // 0000001F55C0: 84868106
	v_mad_u32_u24 v139, 0x90, v7, s14                          // 0000001F55C4: D60B008B 003A0EFF 00000090
	s_add_u32 s8, s8, s6                                       // 0000001F55D0: 80080608
	s_addc_u32 s7, s9, s7                                      // 0000001F55D4: 82070709
	.long 0xd7000874                                           // 0000001F55D8: D7000874
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000001F55DC: 02020208
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F55E0: BF870001
	v_add_co_ci_u32_e64 v117, null, s7, 0, s8                  // 0000001F55E4: D5207C75 00210007
	s_load_b64 s[8:9], s[0:1], 0xa0                            // 0000001F55EC: F4040200 F80000A0
	s_max_i32 s29, s51, 1                                      // 0000001F55F4: 8A1D8133
	s_add_u32 s0, s48, s34                                     // 0000001F55F8: 80002230
	s_addc_u32 s1, s49, s35                                    // 0000001F55FC: 82012331
	.long 0xd7000001                                           // 0000001F5600: D7000001
	v_cndmask_b32_e32 v1, s0, v114, vcc_lo                     // 0000001F5604: 0202E400
	v_mad_u32_u24 v178, 0x900, v2, v139                        // 0000001F5608: D60B00B2 062E04FF 00000900
	v_add_co_ci_u32_e64 v185, null, s11, 0, s5                 // 0000001F5614: D5207CB9 0015000B
	.long 0xd44d0005                                           // 0000001F561C: D44D0005
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000001F5620: 02020480
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000001F5624: D5207C02 00010001
	.long 0xd7000001                                           // 0000001F562C: D7000001
	v_cndmask_b32_e32 v1, v1, v17, vcc_lo                      // 0000001F5630: 02022301
	.long 0xd4490004                                           // 0000001F5634: D4490004
	v_cndmask_b32_e32 v1, 63, v0, vcc_lo                       // 0000001F5638: 020200BF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001F563C: BF870193
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001F5640: D5207C02 00020480
	.long 0xd7000085                                           // 0000001F5648: D7000085
	v_cndmask_b32_e32 v1, s40, v1, vcc_lo                      // 0000001F564C: 02020228
	v_mul_u32_u24_e32 v137, 0x210, v7                          // 0000001F5650: 17120EFF 00000210
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F5658: BF8700A3
	v_add_co_ci_u32_e64 v134, null, s41, v2, s0                // 0000001F565C: D5207C86 00020429
	.long 0xd7000082                                           // 0000001F5664: D7000082
	v_cndmask_b32_e32 v1, s42, v1, vcc_lo                      // 0000001F5668: 0202022A
	v_add_co_ci_u32_e64 v131, null, s43, v2, s0                // 0000001F566C: D5207C83 0002042B
	s_waitcnt lgkmcnt(0)                                       // 0000001F5674: BF89FC07
	.long 0xd700007a                                           // 0000001F5678: D700007A
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000001F567C: 02020208
	v_lshl_add_u32 v183, v141, 1, v139                         // 0000001F5680: D64600B7 062D038D
	.long 0xd4490006                                           // 0000001F5688: D4490006
	v_cndmask_b32_e32 v1, 0x5f, v0, vcc_lo                     // 0000001F568C: 020200FF 0000005F
	v_lshl_or_b32 v186, v141, 2, 0xf100                        // 0000001F5694: D65600BA 03FD058D 0000F100
	v_add_co_ci_u32_e64 v123, null, s9, v2, s0                 // 0000001F56A0: D5207C7B 00020409
	s_mov_b32 s22, s20                                         // 0000001F56A8: BE960014
	s_mov_b32 s23, s20                                         // 0000001F56AC: BE970014
	s_mov_b32 s40, s20                                         // 0000001F56B0: BEA80014
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000001F56B4: 7C9800C0
	s_branch 3                                                 // 0000001F56B8: BFA00003 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xfc8>
	s_cmp_eq_u32 s7, s29                                       // 0000001F56BC: BF061D07
	s_mov_b32 s40, s7                                          // 0000001F56C0: BEA80007
	s_cbranch_scc1 7140                                        // 0000001F56C4: BFA21BE4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7f58>
	s_mul_i32 s0, s40, 0xc00                                   // 0000001F56C8: 9600FF28 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001F56D0: BF870499
	s_add_i32 s0, s28, s0                                      // 0000001F56D4: 8100001C
	s_ashr_i32 s1, s0, 31                                      // 0000001F56D8: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001F56DC: BF870009
	s_lshl_b64 s[8:9], s[0:1], 2                               // 0000001F56E0: 84888200
	s_lshl_b32 s1, s40, 6                                      // 0000001F56E4: 84018628
	s_add_u32 s8, s30, s8                                      // 0000001F56E8: 8008081E
	s_addc_u32 s9, s31, s9                                     // 0000001F56EC: 8209091F
	global_load_b32 v1, v115, s[8:9]                           // 0000001F56F0: DC520000 01080073
	s_waitcnt vmcnt(0)                                         // 0000001F56F8: BF8903F7
	v_readfirstlane_b32 s41, v1                                // 0000001F56FC: 7E520501
	s_and_saveexec_b32 s7, vcc_lo                              // 0000001F5700: BE87206A
	s_cbranch_execz 77                                         // 0000001F5704: BFA5004D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x113c>
	v_or_b32_e32 v1, s1, v0                                    // 0000001F5708: 38020001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F570C: BF870091
	v_mad_u64_u32 v[1:2], null, v1, 48, s[2:3]                 // 0000001F5710: D6FE7C01 00096101
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000001F5718: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F571C: BF870091
	.long 0xd73c0001                                           // 0000001F5720: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000001F5724: 02020282
	.long 0xd7000001                                           // 0000001F5728: D7000001
	v_cndmask_b32_e32 v1, s30, v1, vcc_lo                      // 0000001F572C: 0202021E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F5730: BF8700C1
	v_add_co_ci_u32_e64 v2, null, s31, v2, s0                  // 0000001F5734: D5207C02 0002041F
	global_load_b32 v1, v[1:2], off                            // 0000001F573C: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F5744: BF8903F7
	v_sub_f32_e32 v2, s41, v1                                  // 0000001F5748: 08040229
	v_dual_mul_f32 v4, 0x3fb8aa3b, v1 :: v_dual_mul_f32 v3, 0x3fb8aa3b, v2// 0000001F574C: C8C602FF 040204FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001F5758: BF8701A1
	v_fma_f32 v7, 0x3fb8aa3b, v1, -v4                          // 0000001F575C: D6130007 841202FF 3FB8AA3B
	v_rndne_f32_e32 v8, v4                                     // 0000001F5768: 7E104704
	v_fma_f32 v5, 0x3fb8aa3b, v2, -v3                          // 0000001F576C: D6130005 840E04FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 0000001F5778: 7E0C4703
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001F577C: BF870113
	v_dual_fmac_f32 v7, 0x32a5705f, v1 :: v_dual_sub_f32 v4, v4, v8// 0000001F5780: C80A02FF 07041104 32A5705F
	v_sub_f32_e32 v3, v3, v6                                   // 0000001F578C: 08060D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001F5790: BF870124
	v_fmac_f32_e32 v5, 0x32a5705f, v2                          // 0000001F5794: 560A04FF 32A5705F
	.long 0xd41b0000                                           // 0000001F579C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v2, vcc_lo               // 0000001F57A0: 020204FF C2CE8ED0
	v_dual_add_f32 v4, v4, v7 :: v_dual_add_f32 v3, v3, v5     // 0000001F57A8: C9080F04 04020B03
	v_cvt_i32_f32_e32 v5, v6                                   // 0000001F57B0: 7E0A1106
	v_cvt_i32_f32_e32 v6, v8                                   // 0000001F57B4: 7E0C1108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001F57B8: BF870193
	v_exp_f32_e32 v4, v4                                       // 0000001F57BC: 7E084B04
	v_exp_f32_e32 v3, v3                                       // 0000001F57C0: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001F57C4: BF870296
	.long 0xd71c0004                                           // 0000001F57C8: D71C0004
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000001F57CC: 02020D04
	.long 0xd71c0003                                           // 0000001F57D0: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000001F57D4: 02020B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F57D8: BF8700A1
	v_cndmask_b32_e64 v3, 0, v3, s0                            // 0000001F57DC: D5010003 00020680
	.long 0xd41b0000                                           // 0000001F57E4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v1, vcc_lo               // 0000001F57E8: 020202FF C2CE8ED0
	v_cndmask_b32_e64 v4, 0, v4, s0                            // 0000001F57F0: D5010004 00020880
	.long 0xd41e0000                                           // 0000001F57F8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v2, vcc_lo               // 0000001F57FC: 020204FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001F5804: BF8700A1
	v_cndmask_b32_e64 v2, 0x7f800000, v3, s0                   // 0000001F5808: D5010002 000206FF 7F800000
	.long 0xd41e0000                                           // 0000001F5814: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v1, vcc_lo               // 0000001F5818: 020202FF 42B17218
	v_cndmask_b32_e64 v1, 0x7f800000, v4, s0                   // 0000001F5820: D5010001 000208FF 7F800000
	ds_store_b32 v140, v2                                      // 0000001F582C: D8340000 0000028C
	ds_store_b32 v126, v1                                      // 0000001F5834: D8340000 0000017E
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001F583C: 8C7E077E
	v_add_nc_u32_e32 v17, s1, v135                             // 0000001F5840: 4A230E01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F5844: BF870091
	v_min_i32_e32 v1, s52, v17                                 // 0000001F5848: 22022234
	v_mad_i64_i32 v[1:2], null, v1, 48, s[2:3]                 // 0000001F584C: D6FF7C01 00096101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F5854: BF870091
	.long 0xd73c007c                                           // 0000001F5858: D73C007C
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000001F585C: 02020288
	.long 0xd7000005                                           // 0000001F5860: D7000005
	v_cndmask_b32_e32 v1, s46, v124, vcc_lo                    // 0000001F5864: 0202F82E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F5868: BF870001
	v_add_co_ci_u32_e64 v6, null, s47, v125, s0                // 0000001F586C: D5207C06 0002FA2F
	.long 0xd4430000                                           // 0000001F5874: D4430000
	v_cndmask_b32_e32 v1, s50, v17, vcc_lo                     // 0000001F5878: 02022232
	s_clause 0xf                                               // 0000001F587C: BF85000F
	global_load_b128 v[89:92], v[5:6], off                     // 0000001F5880: DC5E0000 597C0005
	global_load_b128 v[93:96], v[5:6], off offset:16           // 0000001F5888: DC5E0010 5D7C0005
	global_load_b128 v[81:84], v[5:6], off offset:32           // 0000001F5890: DC5E0020 517C0005
	global_load_b128 v[85:88], v[5:6], off offset:48           // 0000001F5898: DC5E0030 557C0005
	global_load_b128 v[73:76], v[5:6], off offset:64           // 0000001F58A0: DC5E0040 497C0005
	global_load_b128 v[77:80], v[5:6], off offset:80           // 0000001F58A8: DC5E0050 4D7C0005
	global_load_b128 v[65:68], v[5:6], off offset:96           // 0000001F58B0: DC5E0060 417C0005
	global_load_b128 v[69:72], v[5:6], off offset:112          // 0000001F58B8: DC5E0070 457C0005
	global_load_b128 v[49:52], v[5:6], off offset:128          // 0000001F58C0: DC5E0080 317C0005
	global_load_b128 v[53:56], v[5:6], off offset:144          // 0000001F58C8: DC5E0090 357C0005
	global_load_b128 v[25:28], v[5:6], off offset:160          // 0000001F58D0: DC5E00A0 197C0005
	global_load_b128 v[29:32], v[5:6], off offset:176          // 0000001F58D8: DC5E00B0 1D7C0005
	global_load_b128 v[9:12], v[5:6], off offset:192           // 0000001F58E0: DC5E00C0 097C0005
	global_load_b128 v[13:16], v[5:6], off offset:208          // 0000001F58E8: DC5E00D0 0D7C0005
	global_load_b128 v[1:4], v[5:6], off offset:224            // 0000001F58F0: DC5E00E0 017C0005
	global_load_b128 v[5:8], v[5:6], off offset:240            // 0000001F58F8: DC5E00F0 057C0005
	s_and_saveexec_b32 s7, s0                                  // 0000001F5900: BE872000
	s_cbranch_execz 81                                         // 0000001F5904: BFA50051 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x134c>
	s_waitcnt vmcnt(15)                                        // 0000001F5908: BF893FF7
	v_mov_b32_e32 v89, 0                                       // 0000001F590C: 7EB20280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F5910: BF870001
	v_mov_b32_e32 v90, v89                                     // 0000001F5914: 7EB40359
	v_mov_b32_e32 v91, v89                                     // 0000001F5918: 7EB60359
	v_mov_b32_e32 v92, v89                                     // 0000001F591C: 7EB80359
	s_waitcnt vmcnt(14)                                        // 0000001F5920: BF893BF7
	v_mov_b32_e32 v93, v89                                     // 0000001F5924: 7EBA0359
	v_mov_b32_e32 v94, v89                                     // 0000001F5928: 7EBC0359
	v_mov_b32_e32 v95, v89                                     // 0000001F592C: 7EBE0359
	v_mov_b32_e32 v96, v89                                     // 0000001F5930: 7EC00359
	s_waitcnt vmcnt(13)                                        // 0000001F5934: BF8937F7
	v_mov_b32_e32 v81, v89                                     // 0000001F5938: 7EA20359
	v_mov_b32_e32 v82, v89                                     // 0000001F593C: 7EA40359
	v_mov_b32_e32 v83, v89                                     // 0000001F5940: 7EA60359
	v_mov_b32_e32 v84, v89                                     // 0000001F5944: 7EA80359
	s_waitcnt vmcnt(12)                                        // 0000001F5948: BF8933F7
	v_mov_b32_e32 v85, v89                                     // 0000001F594C: 7EAA0359
	v_mov_b32_e32 v86, v89                                     // 0000001F5950: 7EAC0359
	v_mov_b32_e32 v87, v89                                     // 0000001F5954: 7EAE0359
	v_mov_b32_e32 v88, v89                                     // 0000001F5958: 7EB00359
	s_waitcnt vmcnt(11)                                        // 0000001F595C: BF892FF7
	v_mov_b32_e32 v73, v89                                     // 0000001F5960: 7E920359
	v_mov_b32_e32 v74, v89                                     // 0000001F5964: 7E940359
	v_mov_b32_e32 v75, v89                                     // 0000001F5968: 7E960359
	v_mov_b32_e32 v76, v89                                     // 0000001F596C: 7E980359
	s_waitcnt vmcnt(10)                                        // 0000001F5970: BF892BF7
	v_mov_b32_e32 v77, v89                                     // 0000001F5974: 7E9A0359
	v_mov_b32_e32 v78, v89                                     // 0000001F5978: 7E9C0359
	v_mov_b32_e32 v79, v89                                     // 0000001F597C: 7E9E0359
	v_mov_b32_e32 v80, v89                                     // 0000001F5980: 7EA00359
	s_waitcnt vmcnt(9)                                         // 0000001F5984: BF8927F7
	v_mov_b32_e32 v65, v89                                     // 0000001F5988: 7E820359
	v_mov_b32_e32 v66, v89                                     // 0000001F598C: 7E840359
	v_mov_b32_e32 v67, v89                                     // 0000001F5990: 7E860359
	v_mov_b32_e32 v68, v89                                     // 0000001F5994: 7E880359
	s_waitcnt vmcnt(8)                                         // 0000001F5998: BF8923F7
	v_mov_b32_e32 v69, v89                                     // 0000001F599C: 7E8A0359
	v_mov_b32_e32 v70, v89                                     // 0000001F59A0: 7E8C0359
	v_mov_b32_e32 v71, v89                                     // 0000001F59A4: 7E8E0359
	v_mov_b32_e32 v72, v89                                     // 0000001F59A8: 7E900359
	s_waitcnt vmcnt(7)                                         // 0000001F59AC: BF891FF7
	v_mov_b32_e32 v49, v89                                     // 0000001F59B0: 7E620359
	v_mov_b32_e32 v50, v89                                     // 0000001F59B4: 7E640359
	v_mov_b32_e32 v51, v89                                     // 0000001F59B8: 7E660359
	v_mov_b32_e32 v52, v89                                     // 0000001F59BC: 7E680359
	s_waitcnt vmcnt(6)                                         // 0000001F59C0: BF891BF7
	v_mov_b32_e32 v53, v89                                     // 0000001F59C4: 7E6A0359
	v_mov_b32_e32 v54, v89                                     // 0000001F59C8: 7E6C0359
	v_mov_b32_e32 v55, v89                                     // 0000001F59CC: 7E6E0359
	v_mov_b32_e32 v56, v89                                     // 0000001F59D0: 7E700359
	s_waitcnt vmcnt(5)                                         // 0000001F59D4: BF8917F7
	v_mov_b32_e32 v25, v89                                     // 0000001F59D8: 7E320359
	v_mov_b32_e32 v26, v89                                     // 0000001F59DC: 7E340359
	v_mov_b32_e32 v27, v89                                     // 0000001F59E0: 7E360359
	v_mov_b32_e32 v28, v89                                     // 0000001F59E4: 7E380359
	s_waitcnt vmcnt(4)                                         // 0000001F59E8: BF8913F7
	v_mov_b32_e32 v29, v89                                     // 0000001F59EC: 7E3A0359
	v_mov_b32_e32 v30, v89                                     // 0000001F59F0: 7E3C0359
	v_mov_b32_e32 v31, v89                                     // 0000001F59F4: 7E3E0359
	v_mov_b32_e32 v32, v89                                     // 0000001F59F8: 7E400359
	s_waitcnt vmcnt(3)                                         // 0000001F59FC: BF890FF7
	v_mov_b32_e32 v9, v89                                      // 0000001F5A00: 7E120359
	v_mov_b32_e32 v10, v89                                     // 0000001F5A04: 7E140359
	v_mov_b32_e32 v11, v89                                     // 0000001F5A08: 7E160359
	v_mov_b32_e32 v12, v89                                     // 0000001F5A0C: 7E180359
	s_waitcnt vmcnt(2)                                         // 0000001F5A10: BF890BF7
	v_mov_b32_e32 v13, v89                                     // 0000001F5A14: 7E1A0359
	v_mov_b32_e32 v14, v89                                     // 0000001F5A18: 7E1C0359
	v_mov_b32_e32 v15, v89                                     // 0000001F5A1C: 7E1E0359
	v_mov_b32_e32 v16, v89                                     // 0000001F5A20: 7E200359
	s_waitcnt vmcnt(1)                                         // 0000001F5A24: BF8907F7
	v_mov_b32_e32 v1, v89                                      // 0000001F5A28: 7E020359
	v_mov_b32_e32 v2, v89                                      // 0000001F5A2C: 7E040359
	v_mov_b32_e32 v3, v89                                      // 0000001F5A30: 7E060359
	v_mov_b32_e32 v4, v89                                      // 0000001F5A34: 7E080359
	s_waitcnt vmcnt(0)                                         // 0000001F5A38: BF8903F7
	v_mov_b32_e32 v5, v89                                      // 0000001F5A3C: 7E0A0359
	v_mov_b32_e32 v6, v89                                      // 0000001F5A40: 7E0C0359
	v_mov_b32_e32 v7, v89                                      // 0000001F5A44: 7E0E0359
	v_mov_b32_e32 v8, v89                                      // 0000001F5A48: 7E100359
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001F5A4C: 8C7E077E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001F5A50: BF890007
	s_waitcnt_vscnt null, 0x0                                  // 0000001F5A54: BC7C0000
	s_barrier                                                  // 0000001F5A58: BFBD0000
	buffer_gl0_inv                                             // 0000001F5A5C: E0AC0000 00000000
	ds_load_b128 v[17:20], v115 offset:61440                   // 0000001F5A64: DBFCF000 11000073
	ds_load_b128 v[21:24], v115 offset:61456                   // 0000001F5A6C: DBFCF010 15000073
	s_cmp_lt_i32 s1, s50                                       // 0000001F5A74: BF043201
	ds_load_b128 v[33:36], v115 offset:61472                   // 0000001F5A78: DBFCF020 21000073
	ds_load_b128 v[37:40], v115 offset:61488                   // 0000001F5A80: DBFCF030 25000073
	s_cselect_b32 s7, -1, 0                                    // 0000001F5A88: 980780C1
	s_or_b32 s8, s1, 1                                         // 0000001F5A8C: 8C088101
	ds_load_b128 v[57:60], v137 offset:8480                    // 0000001F5A90: DBFC2120 39000089
	ds_load_b128 v[61:64], v137 offset:8496                    // 0000001F5A98: DBFC2130 3D000089
	s_cmp_lt_i32 s8, s50                                       // 0000001F5AA0: BF043208
	ds_load_b128 v[222:225], v137 offset:16896                 // 0000001F5AA4: DBFC4200 DE000089
	ds_load_b128 v[226:229], v137 offset:16912                 // 0000001F5AAC: DBFC4210 E2000089
	s_cselect_b32 s8, -1, 0                                    // 0000001F5AB4: 980880C1
	s_or_b32 s9, s1, 2                                         // 0000001F5AB8: 8C098201
	ds_load_b128 v[230:233], v137 offset:16928                 // 0000001F5ABC: DBFC4220 E6000089
	ds_load_b128 v[234:237], v137 offset:16944                 // 0000001F5AC4: DBFC4230 EA000089
	s_cmp_lt_i32 s9, s50                                       // 0000001F5ACC: BF043209
	ds_load_b128 v[238:241], v137 offset:25376                 // 0000001F5AD0: DBFC6320 EE000089
	s_cselect_b32 s9, -1, 0                                    // 0000001F5AD8: 980980C1
	s_or_b32 s10, s1, 3                                        // 0000001F5ADC: 8C0A8301
	ds_load_b128 v[118:121], v137 offset:25440                 // 0000001F5AE0: DBFC6360 76000089
	s_waitcnt lgkmcnt(11)                                      // 0000001F5AE8: BF89FCB7
	v_dual_mul_f32 v17, v138, v17 :: v_dual_mul_f32 v18, v172, v18// 0000001F5AEC: C8C6238A 111225AC
	v_dual_mul_f32 v19, v154, v19 :: v_dual_mul_f32 v20, v207, v20// 0000001F5AF4: C8C6279A 131429CF
	s_cmp_lt_i32 s10, s50                                      // 0000001F5AFC: BF04320A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001F5B00: BF870192
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001F5B04: CC210011 02004F11
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001F5B0C: CC220011 02004F12
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001F5B14: BF870003
	v_fma_mixlo_f16 v18, v19, s39, 0                           // 0000001F5B18: CC210012 02004F13
	s_waitcnt lgkmcnt(10)                                      // 0000001F5B20: BF89FCA7
	v_mul_f32_e32 v19, v206, v21                               // 0000001F5B24: 10262BCE
	s_cselect_b32 s10, -1, 0                                   // 0000001F5B28: 980A80C1
	v_cndmask_b16 v17, 0, v17, s7                              // 0000001F5B2C: D65D0011 001E2280
	s_or_b32 s7, s1, 4                                         // 0000001F5B34: 8C078401
	v_fma_mixhi_f16 v18, v20, s39, 0                           // 0000001F5B38: CC220012 02004F14
	v_mul_f32_e32 v20, v205, v22                               // 0000001F5B40: 10282DCD
	v_fma_mixlo_f16 v19, v19, s39, 0                           // 0000001F5B44: CC210013 02004F13
	s_cmp_lt_i32 s7, s50                                       // 0000001F5B4C: BF043207
	v_cndmask_b16 v17, 0, v17, s8                              // 0000001F5B50: D65D5011 00222280
	s_cselect_b32 s7, -1, 0                                    // 0000001F5B58: 980780C1
	v_fma_mixhi_f16 v19, v20, s39, 0                           // 0000001F5B5C: CC220013 02004F14
	v_cndmask_b16 v19, 0, v19, s7                              // 0000001F5B64: D65D0013 001E2680
	s_or_b32 s7, s1, 5                                         // 0000001F5B6C: 8C078501
	v_dual_mul_f32 v20, v153, v23 :: v_dual_mul_f32 v21, v171, v24// 0000001F5B70: C8C62F99 141431AB
	s_cmp_lt_i32 s7, s50                                       // 0000001F5B78: BF043207
	v_cndmask_b16 v18, 0, v18, s9                              // 0000001F5B7C: D65D0012 00262480
	s_cselect_b32 s7, -1, 0                                    // 0000001F5B84: 980780C1
	s_or_b32 s8, s1, 6                                         // 0000001F5B88: 8C088601
	v_fma_mixlo_f16 v20, v20, s39, 0                           // 0000001F5B8C: CC210014 02004F14
	s_cmp_lt_i32 s8, s50                                       // 0000001F5B94: BF043208
	v_cndmask_b16 v19, 0, v19, s7                              // 0000001F5B98: D65D5013 001E2680
	s_cselect_b32 s7, -1, 0                                    // 0000001F5BA0: 980780C1
	s_or_b32 s8, s1, 7                                         // 0000001F5BA4: 8C088701
	v_cndmask_b16 v20, 0, v20, s7                              // 0000001F5BA8: D65D0014 001E2880
	s_cmp_lt_i32 s8, s50                                       // 0000001F5BB0: BF043208
	v_fma_mixhi_f16 v20, v21, s39, 0                           // 0000001F5BB4: CC220014 02004F15
	s_cselect_b32 s7, -1, 0                                    // 0000001F5BBC: 980780C1
	s_or_b32 s8, s1, 8                                         // 0000001F5BC0: 8C088801
	s_waitcnt lgkmcnt(9)                                       // 0000001F5BC4: BF89FC97
	v_dual_mul_f32 v21, v170, v33 :: v_dual_mul_f32 v22, v152, v34// 0000001F5BC8: C8C643AA 15164598
	s_cmp_lt_i32 s8, s50                                       // 0000001F5BD0: BF043208
	s_waitcnt lgkmcnt(8)                                       // 0000001F5BD4: BF89FC87
	v_dual_mul_f32 v23, v204, v35 :: v_dual_mul_f32 v24, v151, v38// 0000001F5BD8: C8C647CC 17184D97
	s_cselect_b32 s8, -1, 0                                    // 0000001F5BE0: 980880C1
	s_or_b32 s9, s1, 9                                         // 0000001F5BE4: 8C098901
	v_fma_mixlo_f16 v21, v21, s39, 0                           // 0000001F5BE8: CC210015 02004F15
	s_cmp_lt_i32 s9, s50                                       // 0000001F5BF0: BF043209
	v_cndmask_b16 v20, 0, v20, s7                              // 0000001F5BF4: D65D5014 001E2880
	s_cselect_b32 s7, -1, 0                                    // 0000001F5BFC: 980780C1
	s_or_b32 s9, s1, 10                                        // 0000001F5C00: 8C098A01
	v_fma_mixhi_f16 v21, v22, s39, 0                           // 0000001F5C04: CC220015 02004F16
	v_fma_mixlo_f16 v22, v23, s39, 0                           // 0000001F5C0C: CC210016 02004F17
	v_mul_f32_e32 v23, v203, v36                               // 0000001F5C14: 102E49CB
	s_cmp_lt_i32 s9, s50                                       // 0000001F5C18: BF043209
	v_cndmask_b16 v21, 0, v21, s8                              // 0000001F5C1C: D65D0015 00222A80
	s_cselect_b32 s8, -1, 0                                    // 0000001F5C24: 980880C1
	s_or_b32 s9, s1, 11                                        // 0000001F5C28: 8C098B01
	v_fma_mixhi_f16 v22, v23, s39, 0                           // 0000001F5C2C: CC220016 02004F17
	s_cmp_lt_i32 s9, s50                                       // 0000001F5C34: BF043209
	ds_load_b128 v[33:36], v115 offset:61504                   // 0000001F5C38: DBFCF040 21000073
	v_mul_f32_e32 v23, v202, v37                               // 0000001F5C40: 102E4BCA
	v_cndmask_b16 v21, 0, v21, s7                              // 0000001F5C44: D65D5015 001E2A80
	v_cndmask_b16 v22, 0, v22, s8                              // 0000001F5C4C: D65D0016 00222C80
	s_cselect_b32 s7, -1, 0                                    // 0000001F5C54: 980780C1
	s_or_b32 s8, s1, 12                                        // 0000001F5C58: 8C088C01
	v_fma_mixlo_f16 v23, v23, s39, 0                           // 0000001F5C5C: CC210017 02004F17
	s_cmp_lt_i32 s8, s50                                       // 0000001F5C64: BF043208
	v_fma_mixhi_f16 v23, v24, s39, 0                           // 0000001F5C68: CC220017 02004F18
	v_dual_mul_f32 v24, v169, v39 :: v_dual_mul_f32 v37, v168, v40// 0000001F5C70: C8C64FA9 182451A8
	v_cndmask_b16 v22, 0, v22, s7                              // 0000001F5C78: D65D5016 001E2C80
	s_cselect_b32 s7, -1, 0                                    // 0000001F5C80: 980780C1
	s_or_b32 s8, s1, 13                                        // 0000001F5C84: 8C088D01
	v_cndmask_b16 v23, 0, v23, s7                              // 0000001F5C88: D65D0017 001E2E80
	s_cmp_lt_i32 s8, s50                                       // 0000001F5C90: BF043208
	v_fma_mixlo_f16 v24, v24, s39, 0                           // 0000001F5C94: CC210018 02004F18
	s_cselect_b32 s8, -1, 0                                    // 0000001F5C9C: 980880C1
	s_or_b32 s7, s1, 14                                        // 0000001F5CA0: 8C078E01
	v_fma_mixhi_f16 v24, v37, s39, 0                           // 0000001F5CA4: CC220018 02004F25
	ds_load_b128 v[37:40], v115 offset:61520                   // 0000001F5CAC: DBFCF050 25000073
	s_cmp_lt_i32 s7, s50                                       // 0000001F5CB4: BF043207
	v_cndmask_b16 v23, 0, v23, s8                              // 0000001F5CB8: D65D5017 00222E80
	s_cselect_b32 s7, -1, 0                                    // 0000001F5CC0: 980780C1
	s_or_b32 s8, s1, 15                                        // 0000001F5CC4: 8C088F01
	v_cndmask_b16 v18, 0, v18, s10                             // 0000001F5CC8: D65D5012 002A2480
	s_cmp_lt_i32 s8, s50                                       // 0000001F5CD0: BF043208
	s_waitcnt lgkmcnt(1)                                       // 0000001F5CD4: BF89FC17
	v_mul_f32_e32 v33, v150, v33                               // 0000001F5CD8: 10424396
	s_cselect_b32 s8, -1, 0                                    // 0000001F5CDC: 980880C1
	s_or_b32 s9, s1, 16                                        // 0000001F5CE0: 8C099001
	v_mul_f32_e32 v34, v201, v34                               // 0000001F5CE4: 104445C9
	s_cmp_lt_i32 s9, s50                                       // 0000001F5CE8: BF043209
	v_cndmask_b16 v24, 0, v24, s7                              // 0000001F5CEC: D65D0018 001E3080
	v_cndmask_b16 v24, 0, v24, s8                              // 0000001F5CF4: D65D5018 00223080
	s_cselect_b32 s7, -1, 0                                    // 0000001F5CFC: 980780C1
	s_or_b32 s8, s1, 17                                        // 0000001F5D00: 8C089101
	ds_store_b128 v136, v[17:20]                               // 0000001F5D04: DB7C0000 00001188
	ds_store_b128 v136, v[21:24] offset:16                     // 0000001F5D0C: DB7C0010 00001588
	s_cmp_lt_i32 s8, s50                                       // 0000001F5D14: BF043208
	v_fma_mixhi_f16 v17, v34, s39, 0                           // 0000001F5D18: CC220011 02004F22
	v_mul_f32_e32 v18, v200, v35                               // 0000001F5D20: 102447C8
	v_fma_mixlo_f16 v17, v33, s39, 0                           // 0000001F5D24: CC210011 02004F21
	s_cselect_b32 s8, -1, 0                                    // 0000001F5D2C: 980880C1
	s_or_b32 s9, s1, 18                                        // 0000001F5D30: 8C099201
	v_cndmask_b16 v17, 0, v17, s8                              // 0000001F5D34: D65D5011 00222280
	s_cmp_lt_i32 s9, s50                                       // 0000001F5D3C: BF043209
	v_cndmask_b16 v17, 0, v17, s7                              // 0000001F5D40: D65D0011 001E2280
	s_cselect_b32 s7, -1, 0                                    // 0000001F5D48: 980780C1
	s_or_b32 s8, s1, 19                                        // 0000001F5D4C: 8C089301
	s_waitcnt lgkmcnt(2)                                       // 0000001F5D50: BF89FC27
	v_dual_mul_f32 v19, v199, v36 :: v_dual_mul_f32 v20, v149, v37// 0000001F5D54: C8C649C7 13144B95
	s_cmp_lt_i32 s8, s50                                       // 0000001F5D5C: BF043208
	v_fma_mixlo_f16 v18, v18, s39, 0                           // 0000001F5D60: CC210012 02004F12
	s_cselect_b32 s8, -1, 0                                    // 0000001F5D68: 980880C1
	s_or_b32 s9, s1, 20                                        // 0000001F5D6C: 8C099401
	ds_load_b128 v[21:24], v115 offset:61536                   // 0000001F5D70: DBFCF060 15000073
	v_fma_mixhi_f16 v18, v19, s39, 0                           // 0000001F5D78: CC220012 02004F13
	v_fma_mixlo_f16 v19, v20, s39, 0                           // 0000001F5D80: CC210013 02004F14
	s_cmp_lt_i32 s9, s50                                       // 0000001F5D88: BF043209
	v_mul_f32_e32 v20, v167, v38                               // 0000001F5D8C: 10284DA7
	v_cndmask_b16 v18, 0, v18, s7                              // 0000001F5D90: D65D0012 001E2480
	s_cselect_b32 s7, -1, 0                                    // 0000001F5D98: 980780C1
	v_mul_f32_e32 v33, v148, v40                               // 0000001F5D9C: 10425194
	v_cndmask_b16 v19, 0, v19, s7                              // 0000001F5DA0: D65D0013 001E2680
	s_or_b32 s7, s1, 21                                        // 0000001F5DA8: 8C079501
	v_fma_mixhi_f16 v19, v20, s39, 0                           // 0000001F5DAC: CC220013 02004F14
	v_mul_f32_e32 v20, v166, v39                               // 0000001F5DB4: 10284FA6
	s_cmp_lt_i32 s7, s50                                       // 0000001F5DB8: BF043207
	v_cndmask_b16 v18, 0, v18, s8                              // 0000001F5DBC: D65D5012 00222480
	s_cselect_b32 s7, -1, 0                                    // 0000001F5DC4: 980780C1
	s_or_b32 s8, s1, 22                                        // 0000001F5DC8: 8C089601
	v_fma_mixlo_f16 v20, v20, s39, 0                           // 0000001F5DCC: CC210014 02004F14
	s_cmp_lt_i32 s8, s50                                       // 0000001F5DD4: BF043208
	v_fma_mixhi_f16 v20, v33, s39, 0                           // 0000001F5DD8: CC220014 02004F21
	ds_load_b128 v[33:36], v115 offset:61552                   // 0000001F5DE0: DBFCF070 21000073
	v_cndmask_b16 v19, 0, v19, s7                              // 0000001F5DE8: D65D5013 001E2680
	s_cselect_b32 s7, -1, 0                                    // 0000001F5DF0: 980780C1
	s_or_b32 s8, s1, 23                                        // 0000001F5DF4: 8C089701
	v_cndmask_b16 v20, 0, v20, s7                              // 0000001F5DF8: D65D0014 001E2880
	s_cmp_lt_i32 s8, s50                                       // 0000001F5E00: BF043208
	s_waitcnt lgkmcnt(1)                                       // 0000001F5E04: BF89FC17
	v_dual_mul_f32 v21, v198, v21 :: v_dual_mul_f32 v22, v197, v22// 0000001F5E08: C8C62BC6 15162DC5
	s_cselect_b32 s7, -1, 0                                    // 0000001F5E10: 980780C1
	s_or_b32 s8, s1, 24                                        // 0000001F5E14: 8C089801
	ds_load_b128 v[37:40], v115 offset:61568                   // 0000001F5E18: DBFCF080 25000073
	s_cmp_lt_i32 s8, s50                                       // 0000001F5E20: BF043208
	v_mul_f32_e32 v23, v196, v23                               // 0000001F5E24: 102E2FC4
	s_cselect_b32 s8, -1, 0                                    // 0000001F5E28: 980880C1
	s_or_b32 s9, s1, 25                                        // 0000001F5E2C: 8C099901
	v_fma_mixlo_f16 v21, v21, s39, 0                           // 0000001F5E30: CC210015 02004F15
	s_cmp_lt_i32 s9, s50                                       // 0000001F5E38: BF043209
	v_cndmask_b16 v20, 0, v20, s7                              // 0000001F5E3C: D65D5014 001E2880
	s_cselect_b32 s7, -1, 0                                    // 0000001F5E44: 980780C1
	s_or_b32 s9, s1, 26                                        // 0000001F5E48: 8C099A01
	v_fma_mixhi_f16 v21, v22, s39, 0                           // 0000001F5E4C: CC220015 02004F16
	v_fma_mixlo_f16 v22, v23, s39, 0                           // 0000001F5E54: CC210016 02004F17
	s_waitcnt lgkmcnt(1)                                       // 0000001F5E5C: BF89FC17
	v_dual_mul_f32 v23, v147, v24 :: v_dual_mul_f32 v24, v164, v34// 0000001F5E60: C8C63193 171845A4
	s_cmp_lt_i32 s9, s50                                       // 0000001F5E68: BF043209
	v_cndmask_b16 v21, 0, v21, s8                              // 0000001F5E6C: D65D0015 00222A80
	s_cselect_b32 s8, -1, 0                                    // 0000001F5E74: 980880C1
	s_or_b32 s9, s1, 27                                        // 0000001F5E78: 8C099B01
	v_fma_mixhi_f16 v22, v23, s39, 0                           // 0000001F5E7C: CC220016 02004F17
	s_cmp_lt_i32 s9, s50                                       // 0000001F5E84: BF043209
	v_mul_f32_e32 v23, v165, v33                               // 0000001F5E88: 102E43A5
	v_cndmask_b16 v21, 0, v21, s7                              // 0000001F5E8C: D65D5015 001E2A80
	v_cndmask_b16 v22, 0, v22, s8                              // 0000001F5E94: D65D0016 00222C80
	s_cselect_b32 s7, -1, 0                                    // 0000001F5E9C: 980780C1
	s_or_b32 s8, s1, 28                                        // 0000001F5EA0: 8C089C01
	v_fma_mixlo_f16 v23, v23, s39, 0                           // 0000001F5EA4: CC210017 02004F17
	s_cmp_lt_i32 s8, s50                                       // 0000001F5EAC: BF043208
	v_fma_mixhi_f16 v23, v24, s39, 0                           // 0000001F5EB0: CC220017 02004F18
	v_dual_mul_f32 v24, v146, v35 :: v_dual_mul_f32 v33, v195, v36// 0000001F5EB8: C8C64792 182049C3
	v_cndmask_b16 v22, 0, v22, s7                              // 0000001F5EC0: D65D5016 001E2C80
	s_cselect_b32 s7, -1, 0                                    // 0000001F5EC8: 980780C1
	s_or_b32 s8, s1, 29                                        // 0000001F5ECC: 8C089D01
	v_cndmask_b16 v23, 0, v23, s7                              // 0000001F5ED0: D65D0017 001E2E80
	s_cmp_lt_i32 s8, s50                                       // 0000001F5ED8: BF043208
	v_fma_mixlo_f16 v24, v24, s39, 0                           // 0000001F5EDC: CC210018 02004F18
	s_cselect_b32 s8, -1, 0                                    // 0000001F5EE4: 980880C1
	s_or_b32 s7, s1, 30                                        // 0000001F5EE8: 8C079E01
	v_fma_mixhi_f16 v24, v33, s39, 0                           // 0000001F5EEC: CC220018 02004F21
	ds_load_b128 v[33:36], v115 offset:61584                   // 0000001F5EF4: DBFCF090 21000073
	s_cmp_lt_i32 s7, s50                                       // 0000001F5EFC: BF043207
	v_cndmask_b16 v23, 0, v23, s8                              // 0000001F5F00: D65D5017 00222E80
	s_cselect_b32 s7, -1, 0                                    // 0000001F5F08: 980780C1
	s_or_b32 s8, s1, 31                                        // 0000001F5F0C: 8C089F01
	s_waitcnt lgkmcnt(1)                                       // 0000001F5F10: BF89FC17
	v_mul_f32_e32 v37, v194, v37                               // 0000001F5F14: 104A4BC2
	s_cmp_lt_i32 s8, s50                                       // 0000001F5F18: BF043208
	v_mul_f32_e32 v38, v193, v38                               // 0000001F5F1C: 104C4DC1
	s_cselect_b32 s8, -1, 0                                    // 0000001F5F20: 980880C1
	s_or_b32 s9, s1, 32                                        // 0000001F5F24: 8C09A001
	v_cndmask_b16 v24, 0, v24, s7                              // 0000001F5F28: D65D0018 001E3080
	s_cmp_lt_i32 s9, s50                                       // 0000001F5F30: BF043209
	v_cndmask_b16 v24, 0, v24, s8                              // 0000001F5F34: D65D5018 00223080
	s_cselect_b32 s7, -1, 0                                    // 0000001F5F3C: 980780C1
	s_or_b32 s8, s1, 33                                        // 0000001F5F40: 8C08A101
	ds_store_b128 v136, v[17:20] offset:32                     // 0000001F5F44: DB7C0020 00001188
	ds_store_b128 v136, v[21:24] offset:48                     // 0000001F5F4C: DB7C0030 00001588
	s_cmp_lt_i32 s8, s50                                       // 0000001F5F54: BF043208
	v_fma_mixlo_f16 v17, v37, s39, 0                           // 0000001F5F58: CC210011 02004F25
	v_fma_mixhi_f16 v17, v38, s39, 0                           // 0000001F5F60: CC220011 02004F26
	v_mul_f32_e32 v18, v145, v39                               // 0000001F5F68: 10244F91
	s_cselect_b32 s8, -1, 0                                    // 0000001F5F6C: 980880C1
	s_or_b32 s9, s1, 34                                        // 0000001F5F70: 8C09A201
	v_cndmask_b16 v97, 0, v17, s7                              // 0000001F5F74: D65D0061 001E2280
	s_cmp_lt_i32 s9, s50                                       // 0000001F5F7C: BF043209
	v_cndmask_b16 v97, 0, v17, s8                              // 0000001F5F80: D65D5061 00222280
	s_cselect_b32 s7, -1, 0                                    // 0000001F5F88: 980780C1
	v_fma_mixlo_f16 v17, v18, s39, 0                           // 0000001F5F8C: CC210011 02004F12
	s_or_b32 s8, s1, 35                                        // 0000001F5F94: 8C08A301
	s_waitcnt lgkmcnt(2)                                       // 0000001F5F98: BF89FC27
	v_dual_mul_f32 v18, v163, v40 :: v_dual_mul_f32 v19, v162, v33// 0000001F5F9C: C8C651A3 121243A2
	v_mul_f32_e32 v22, v192, v35                               // 0000001F5FA4: 102C47C0
	s_cmp_lt_i32 s8, s50                                       // 0000001F5FA8: BF043208
	v_cndmask_b16 v98, 0, v17, s7                              // 0000001F5FAC: D65D0062 001E2280
	s_cselect_b32 s8, -1, 0                                    // 0000001F5FB4: 980880C1
	s_or_b32 s9, s1, 36                                        // 0000001F5FB8: 8C09A401
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001F5FBC: CC220011 02004F12
	v_fma_mixlo_f16 v18, v19, s39, 0                           // 0000001F5FC4: CC210012 02004F13
	s_cmp_lt_i32 s9, s50                                       // 0000001F5FCC: BF043209
	v_mul_f32_e32 v21, v144, v34                               // 0000001F5FD0: 102A4590
	s_cselect_b32 s7, -1, 0                                    // 0000001F5FD4: 980780C1
	v_cndmask_b16 v98, 0, v17, s8                              // 0000001F5FD8: D65D5062 00222280
	v_cndmask_b16 v99, 0, v18, s7                              // 0000001F5FE0: D65D0063 001E2480
	ds_load_b128 v[17:20], v115 offset:61600                   // 0000001F5FE8: DBFCF0A0 11000073
	s_or_b32 s7, s1, 37                                        // 0000001F5FF0: 8C07A501
	v_fma_mixlo_f16 v21, v21, s39, 0                           // 0000001F5FF4: CC210015 02004F15
	s_cmp_lt_i32 s7, s50                                       // 0000001F5FFC: BF043207
	.long 0x7ee23880                                           // 0000001F6000: 7EE23880
	s_cselect_b32 s7, -1, 0                                    // 0000001F6004: 980780C1
	s_or_b32 s8, s1, 38                                        // 0000001F6008: 8C08A601
	v_cndmask_b16 v99, 0, v21, s7                              // 0000001F600C: D65D4063 001E2A80
	v_fma_mixlo_f16 v21, v22, s39, 0                           // 0000001F6014: CC210015 02004F16
	v_mul_f32_e32 v22, v191, v36                               // 0000001F601C: 102C49BF
	s_cmp_lt_i32 s8, s50                                       // 0000001F6020: BF043208
	v_mov_b32_e32 v221, s27                                    // 0000001F6024: 7FBA021B
	s_cselect_b32 s7, -1, 0                                    // 0000001F6028: 980780C1
	s_or_b32 s8, s1, 39                                        // 0000001F602C: 8C08A701
	v_cndmask_b16 v100, 0, v21, s7                             // 0000001F6030: D65D0064 001E2A80
	v_fma_mixlo_f16 v33, v22, s39, 0                           // 0000001F6038: CC210021 02004F16
	ds_load_b128 v[21:24], v115 offset:61616                   // 0000001F6040: DBFCF0B0 15000073
	s_cmp_lt_i32 s8, s50                                       // 0000001F6048: BF043208
	v_mov_b32_e32 v219, s25                                    // 0000001F604C: 7FB60219
	s_cselect_b32 s7, -1, 0                                    // 0000001F6050: 980780C1
	s_or_b32 s8, s1, 40                                        // 0000001F6054: 8C08A801
	s_waitcnt lgkmcnt(1)                                       // 0000001F6058: BF89FC17
	v_dual_mul_f32 v17, v190, v17 :: v_dual_mul_f32 v18, v143, v18// 0000001F605C: C8C623BE 1112258F
	s_cmp_lt_i32 s8, s50                                       // 0000001F6064: BF043208
	v_mul_f32_e32 v19, v161, v19                               // 0000001F6068: 102627A1
	s_cselect_b32 s8, -1, 0                                    // 0000001F606C: 980880C1
	s_or_b32 s9, s1, 41                                        // 0000001F6070: 8C09A901
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001F6074: CC210011 02004F11
	s_cmp_lt_i32 s9, s50                                       // 0000001F607C: BF043209
	v_cndmask_b16 v100, 0, v33, s7                             // 0000001F6080: D65D4064 001E4280
	s_cselect_b32 s7, -1, 0                                    // 0000001F6088: 980780C1
	s_or_b32 s9, s1, 42                                        // 0000001F608C: 8C09AA01
	v_cndmask_b16 v101, 0, v17, s8                             // 0000001F6090: D65D0065 00222280
	s_cmp_lt_i32 s9, s50                                       // 0000001F6098: BF043209
	v_fma_mixlo_f16 v17, v18, s39, 0                           // 0000001F609C: CC210011 02004F12
	v_mul_f32_e32 v18, v160, v20                               // 0000001F60A4: 102429A0
	v_fma_mixhi_f16 v17, v19, s39, 0                           // 0000001F60A8: CC220011 02004F13
	s_cselect_b32 s8, -1, 0                                    // 0000001F60B0: 980880C1
	s_or_b32 s9, s1, 43                                        // 0000001F60B4: 8C09AB01
	v_cndmask_b16 v101, 0, v17, s7                             // 0000001F60B8: D65D4065 001E2280
	s_cmp_lt_i32 s9, s50                                       // 0000001F60C0: BF043209
	v_fma_mixlo_f16 v17, v18, s39, 0                           // 0000001F60C4: CC210011 02004F12
	v_cndmask_b16 v102, 0, v17, s8                             // 0000001F60CC: D65D1066 00222280
	s_cselect_b32 s7, -1, 0                                    // 0000001F60D4: 980780C1
	s_or_b32 s8, s1, 44                                        // 0000001F60D8: 8C08AC01
	s_waitcnt lgkmcnt(0)                                       // 0000001F60DC: BF89FC07
	v_dual_mul_f32 v18, v142, v21 :: v_dual_mul_f32 v19, v189, v22// 0000001F60E0: C8C62B8E 12122DBD
	s_cmp_lt_i32 s8, s50                                       // 0000001F60E8: BF043208
	v_cndmask_b16 v102, 0, v17, s7                             // 0000001F60EC: D65D4066 001E2280
	s_cselect_b32 s7, -1, 0                                    // 0000001F60F4: 980780C1
	s_or_b32 s8, s1, 45                                        // 0000001F60F8: 8C08AD01
	v_fma_mixlo_f16 v21, v18, s39, 0                           // 0000001F60FC: CC210015 02004F12
	v_fma_mixhi_f16 v21, v19, s39, 0                           // 0000001F6104: CC220015 02004F13
	s_cmp_lt_i32 s8, s50                                       // 0000001F610C: BF043208
	ds_load_b128 v[17:20], v115 offset:61632                   // 0000001F6110: DBFCF0C0 11000073
	s_cselect_b32 s8, -1, 0                                    // 0000001F6118: 980880C1
	v_cndmask_b16 v103, 0, v21, s7                             // 0000001F611C: D65D0067 001E2A80
	v_cndmask_b16 v103, 0, v21, s8                             // 0000001F6124: D65D5067 00222A80
	s_or_b32 s7, s1, 46                                        // 0000001F612C: 8C07AE01
	v_dual_mul_f32 v21, v188, v23 :: v_dual_mul_f32 v22, v187, v24// 0000001F6130: C8C62FBC 151631BB
	s_cmp_lt_i32 s7, s50                                       // 0000001F6138: BF043207
	ds_load_b128 v[33:36], v115 offset:61664                   // 0000001F613C: DBFCF0E0 21000073
	ds_load_b128 v[37:40], v115 offset:61680                   // 0000001F6144: DBFCF0F0 25000073
	s_cselect_b32 s7, -1, 0                                    // 0000001F614C: 980780C1
	s_or_b32 s8, s1, 47                                        // 0000001F6150: 8C08AF01
	v_fma_mixlo_f16 v21, v21, s39, 0                           // 0000001F6154: CC210015 02004F15
	v_fma_mixhi_f16 v21, v22, s39, 0                           // 0000001F615C: CC220015 02004F16
	s_cmp_lt_i32 s8, s50                                       // 0000001F6164: BF043208
	v_mov_b32_e32 v217, s23                                    // 0000001F6168: 7FB20217
	s_cselect_b32 s8, -1, 0                                    // 0000001F616C: 980880C1
	v_cndmask_b16 v104, 0, v21, s7                             // 0000001F6170: D65D0068 001E2A80
	v_cndmask_b16 v104, 0, v21, s8                             // 0000001F6178: D65D5068 00222A80
	ds_load_b128 v[21:24], v115 offset:61648                   // 0000001F6180: DBFCF0D0 15000073
	s_or_b32 s9, s1, 48                                        // 0000001F6188: 8C09B001
	s_waitcnt lgkmcnt(3)                                       // 0000001F618C: BF89FC37
	v_dual_mul_f32 v17, v155, v17 :: v_dual_mul_f32 v18, v173, v18// 0000001F6190: C8C6239B 111225AD
	s_cmp_lt_i32 s9, s50                                       // 0000001F6198: BF043209
	v_mov_b32_e32 v215, s21                                    // 0000001F619C: 7FAE0215
	s_cselect_b32 s7, -1, 0                                    // 0000001F61A0: 980780C1
	s_or_b32 s8, s1, 49                                        // 0000001F61A4: 8C08B101
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001F61A8: CC210011 02004F11
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001F61B0: CC220011 02004F12
	v_mul_f32_e32 v18, v174, v19                               // 0000001F61B8: 102427AE
	s_cmp_lt_i32 s8, s50                                       // 0000001F61BC: BF043208
	ds_load_b128 v[45:48], v137 offset:8464                    // 0000001F61C0: DBFC2110 2D000089
	s_cselect_b32 s8, -1, 0                                    // 0000001F61C8: 980880C1
	s_or_b32 s9, s1, 50                                        // 0000001F61CC: 8C09B201
	v_cndmask_b16 v105, 0, v17, s7                             // 0000001F61D0: D65D0069 001E2280
	s_cmp_lt_i32 s9, s50                                       // 0000001F61D8: BF043209
	v_cndmask_b16 v105, 0, v17, s8                             // 0000001F61DC: D65D5069 00222280
	s_cselect_b32 s7, -1, 0                                    // 0000001F61E4: 980780C1
	s_or_b32 s8, s1, 51                                        // 0000001F61E8: 8C08B301
	s_waitcnt lgkmcnt(1)                                       // 0000001F61EC: BF89FC17
	v_mul_f32_e32 v19, v208, v21                               // 0000001F61F0: 10262BD0
	v_fma_mixlo_f16 v17, v18, s39, 0                           // 0000001F61F4: CC210011 02004F12
	v_mul_f32_e32 v18, v156, v20                               // 0000001F61FC: 1024299C
	s_cmp_lt_i32 s8, s50                                       // 0000001F6200: BF043208
	v_mov_b32_e32 v220, s26                                    // 0000001F6204: 7FB8021A
	v_fma_mixhi_f16 v17, v19, s39, 0                           // 0000001F6208: CC220011 02004F13
	v_cndmask_b16 v106, 0, v17, s7                             // 0000001F6210: D65D006A 001E2280
	v_mul_f32_e32 v19, v158, v35                               // 0000001F6218: 1026479E
	v_fma_mixlo_f16 v17, v18, s39, 0                           // 0000001F621C: CC210011 02004F12
	s_cselect_b32 s7, -1, 0                                    // 0000001F6224: 980780C1
	s_or_b32 s8, s1, 52                                        // 0000001F6228: 8C08B401
	v_mul_f32_e32 v18, v209, v22                               // 0000001F622C: 10242DD1
	s_cmp_lt_i32 s8, s50                                       // 0000001F6230: BF043208
	v_cndmask_b16 v106, 0, v17, s7                             // 0000001F6234: D65D406A 001E2280
	s_cselect_b32 s8, -1, 0                                    // 0000001F623C: 980880C1
	s_or_b32 s7, s1, 53                                        // 0000001F6240: 8C07B501
	v_fma_mixlo_f16 v17, v18, s39, 0                           // 0000001F6244: CC210011 02004F12
	s_cmp_lt_i32 s7, s50                                       // 0000001F624C: BF043207
	v_mul_f32_e32 v18, v210, v23                               // 0000001F6250: 10242FD2
	v_cndmask_b16 v107, 0, v17, s8                             // 0000001F6254: D65D106B 00222280
	s_cselect_b32 s7, -1, 0                                    // 0000001F625C: 980780C1
	s_or_b32 s8, s1, 54                                        // 0000001F6260: 8C08B601
	v_cndmask_b16 v107, 0, v17, s7                             // 0000001F6264: D65D406B 001E2280
	s_cmp_lt_i32 s8, s50                                       // 0000001F626C: BF043208
	v_fma_mixlo_f16 v17, v18, s39, 0                           // 0000001F6270: CC210011 02004F12
	s_cselect_b32 s7, -1, 0                                    // 0000001F6278: 980780C1
	s_or_b32 s8, s1, 55                                        // 0000001F627C: 8C08B701
	v_mul_f32_e32 v18, v157, v24                               // 0000001F6280: 1024319D
	s_cmp_lt_i32 s8, s50                                       // 0000001F6284: BF043208
	v_cndmask_b16 v108, 0, v17, s7                             // 0000001F6288: D65D006C 001E2280
	s_cselect_b32 s7, -1, 0                                    // 0000001F6290: 980780C1
	s_or_b32 s8, s1, 56                                        // 0000001F6294: 8C08B801
	v_fma_mixlo_f16 v17, v18, s39, 0                           // 0000001F6298: CC210011 02004F12
	v_mul_f32_e32 v18, v175, v33                               // 0000001F62A0: 102443AF
	s_cmp_lt_i32 s8, s50                                       // 0000001F62A4: BF043208
	v_fma_mixhi_f16 v17, v19, s39, 0                           // 0000001F62A8: CC220011 02004F13
	s_cselect_b32 s8, -1, 0                                    // 0000001F62B0: 980880C1
	s_or_b32 s9, s1, 57                                        // 0000001F62B4: 8C09B901
	v_cndmask_b16 v108, 0, v17, s7                             // 0000001F62B8: D65D406C 001E2280
	s_cmp_lt_i32 s9, s50                                       // 0000001F62C0: BF043209
	v_fma_mixlo_f16 v17, v18, s39, 0                           // 0000001F62C4: CC210011 02004F12
	v_mul_f32_e32 v18, v176, v34                               // 0000001F62CC: 102445B0
	s_cselect_b32 s7, -1, 0                                    // 0000001F62D0: 980780C1
	s_or_b32 s9, s1, 58                                        // 0000001F62D4: 8C09BA01
	v_mov_b32_e32 v218, s24                                    // 0000001F62D8: 7FB40218
	s_cmp_lt_i32 s9, s50                                       // 0000001F62DC: BF043209
	v_cndmask_b16 v109, 0, v17, s8                             // 0000001F62E0: D65D006D 00222280
	v_fma_mixlo_f16 v17, v18, s39, 0                           // 0000001F62E8: CC210011 02004F12
	v_mul_f32_e32 v18, v211, v36                               // 0000001F62F0: 102449D3
	s_cselect_b32 s8, -1, 0                                    // 0000001F62F4: 980880C1
	s_or_b32 s9, s1, 59                                        // 0000001F62F8: 8C09BB01
	v_cndmask_b16 v110, 0, v17, s8                             // 0000001F62FC: D65D106E 00222280
	s_cmp_lt_i32 s9, s50                                       // 0000001F6304: BF043209
	v_cndmask_b16 v109, 0, v17, s7                             // 0000001F6308: D65D406D 001E2280
	s_cselect_b32 s7, -1, 0                                    // 0000001F6310: 980780C1
	v_fma_mixlo_f16 v21, v18, s39, 0                           // 0000001F6314: CC210015 02004F12
	s_or_b32 s8, s1, 60                                        // 0000001F631C: 8C08BC01
	v_mul_f32_e32 v18, v213, v38                               // 0000001F6320: 10244DD5
	s_cmp_lt_i32 s8, s50                                       // 0000001F6324: BF043208
	v_mul_f32_e32 v17, v212, v37                               // 0000001F6328: 10224BD4
	s_cselect_b32 s8, -1, 0                                    // 0000001F632C: 980880C1
	s_or_b32 s9, s1, 61                                        // 0000001F6330: 8C09BD01
	v_fma_mixlo_f16 v22, v18, s39, 0                           // 0000001F6334: CC210016 02004F12
	s_cmp_lt_i32 s9, s50                                       // 0000001F633C: BF043209
	v_cndmask_b16 v110, 0, v21, s7                             // 0000001F6340: D65D406E 001E2A80
	s_cselect_b32 s7, -1, 0                                    // 0000001F6348: 980780C1
	v_fma_mixhi_f16 v21, v17, s39, 0                           // 0000001F634C: CC220015 02004F11
	v_cndmask_b16 v111, 0, v22, s7                             // 0000001F6354: D65D406F 001E2C80
	s_or_b32 s7, s1, 62                                        // 0000001F635C: 8C07BE01
	v_dual_mul_f32 v37, v159, v39 :: v_dual_mul_f32 v38, v177, v40// 0000001F6360: C8C64F9F 252651B1
	s_cmp_lt_i32 s7, s50                                       // 0000001F6368: BF043207
	v_cndmask_b16 v111, 0, v21, s8                             // 0000001F636C: D65D106F 00222A80
	s_cselect_b32 s7, -1, 0                                    // 0000001F6374: 980780C1
	s_or_b32 s8, s1, 63                                        // 0000001F6378: 8C08BF01
	v_fma_mixlo_f16 v41, v37, s39, 0                           // 0000001F637C: CC210029 02004F25
	v_fma_mixhi_f16 v41, v38, s39, 0                           // 0000001F6384: CC220029 02004F26
	s_cmp_lt_i32 s8, s50                                       // 0000001F638C: BF043208
	ds_load_b128 v[17:20], v137                                // 0000001F6390: DBFC0000 11000089
	ds_load_b128 v[21:24], v137 offset:16                      // 0000001F6398: DBFC0010 15000089
	s_cselect_b32 s8, -1, 0                                    // 0000001F63A0: 980880C1
	ds_load_b128 v[33:36], v137 offset:32                      // 0000001F63A4: DBFC0020 21000089
	ds_load_b128 v[37:40], v137 offset:48                      // 0000001F63AC: DBFC0030 25000089
	v_cndmask_b16 v112, 0, v41, s7                             // 0000001F63B4: D65D0070 001E5280
	v_cndmask_b16 v112, 0, v41, s8                             // 0000001F63BC: D65D5070 00225280
	ds_load_b128 v[41:44], v137 offset:8448                    // 0000001F63C4: DBFC2100 29000089
	v_mov_b32_e32 v216, s22                                    // 0000001F63CC: 7FB00216
	v_mov_b32_e32 v214, s20                                    // 0000001F63D0: 7FAC0214
	ds_load_b128 v[242:245], v137 offset:80                    // 0000001F63D4: DBFC0050 F2000089
	ds_load_b128 v[246:249], v137 offset:112                   // 0000001F63DC: DBFC0070 F6000089
	ds_load_b128 v[250:253], v137 offset:25424                 // 0000001F63E4: DBFC6350 FA000089
	ds_store_b128 v136, v[97:100] offset:64                    // 0000001F63EC: DB7C0040 00006188
	ds_store_b128 v136, v[101:104] offset:80                   // 0000001F63F4: DB7C0050 00006588
	ds_store_b128 v136, v[105:108] offset:96                   // 0000001F63FC: DB7C0060 00006988
	ds_store_b128 v136, v[109:112] offset:112                  // 0000001F6404: DB7C0070 00006D88
	s_waitcnt lgkmcnt(11)                                      // 0000001F640C: BF89FCB7
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001F6410: CC210011 02004F11
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001F6418: CC220011 02004F12
	v_fma_mixlo_f16 v18, v19, s39, 0                           // 0000001F6420: CC210012 02004F13
	v_fma_mixhi_f16 v18, v20, s39, 0                           // 0000001F6428: CC220012 02004F14
	s_waitcnt lgkmcnt(10)                                      // 0000001F6430: BF89FCA7
	v_fma_mixlo_f16 v19, v21, s39, 0                           // 0000001F6434: CC210013 02004F15
	v_fma_mixhi_f16 v19, v22, s39, 0                           // 0000001F643C: CC220013 02004F16
	v_fma_mixlo_f16 v20, v23, s39, 0                           // 0000001F6444: CC210014 02004F17
	v_fma_mixhi_f16 v20, v24, s39, 0                           // 0000001F644C: CC220014 02004F18
	s_waitcnt lgkmcnt(9)                                       // 0000001F6454: BF89FC97
	v_fma_mixlo_f16 v21, v33, s39, 0                           // 0000001F6458: CC210015 02004F21
	v_fma_mixhi_f16 v21, v34, s39, 0                           // 0000001F6460: CC220015 02004F22
	v_fma_mixlo_f16 v22, v35, s39, 0                           // 0000001F6468: CC210016 02004F23
	v_fma_mixhi_f16 v22, v36, s39, 0                           // 0000001F6470: CC220016 02004F24
	s_waitcnt lgkmcnt(8)                                       // 0000001F6478: BF89FC87
	v_fma_mixlo_f16 v23, v37, s39, 0                           // 0000001F647C: CC210017 02004F25
	v_fma_mixhi_f16 v23, v38, s39, 0                           // 0000001F6484: CC220017 02004F26
	v_fma_mixlo_f16 v24, v39, s39, 0                           // 0000001F648C: CC210018 02004F27
	v_fma_mixhi_f16 v24, v40, s39, 0                           // 0000001F6494: CC220018 02004F28
	s_waitcnt lgkmcnt(7)                                       // 0000001F649C: BF89FC77
	v_fma_mixlo_f16 v33, v41, s39, 0                           // 0000001F64A0: CC210021 02004F29
	v_fma_mixhi_f16 v33, v42, s39, 0                           // 0000001F64A8: CC220021 02004F2A
	v_fma_mixlo_f16 v34, v43, s39, 0                           // 0000001F64B0: CC210022 02004F2B
	v_fma_mixhi_f16 v34, v44, s39, 0                           // 0000001F64B8: CC220022 02004F2C
	v_fma_mixlo_f16 v35, v45, s39, 0                           // 0000001F64C0: CC210023 02004F2D
	v_fma_mixhi_f16 v35, v46, s39, 0                           // 0000001F64C8: CC220023 02004F2E
	v_fma_mixlo_f16 v36, v47, s39, 0                           // 0000001F64D0: CC210024 02004F2F
	v_fma_mixhi_f16 v36, v48, s39, 0                           // 0000001F64D8: CC220024 02004F30
	v_fma_mixlo_f16 v37, v57, s39, 0                           // 0000001F64E0: CC210025 02004F39
	v_fma_mixhi_f16 v37, v58, s39, 0                           // 0000001F64E8: CC220025 02004F3A
	v_fma_mixlo_f16 v38, v59, s39, 0                           // 0000001F64F0: CC210026 02004F3B
	v_fma_mixhi_f16 v38, v60, s39, 0                           // 0000001F64F8: CC220026 02004F3C
	v_fma_mixlo_f16 v39, v61, s39, 0                           // 0000001F6500: CC210027 02004F3D
	v_fma_mixhi_f16 v39, v62, s39, 0                           // 0000001F6508: CC220027 02004F3E
	v_fma_mixlo_f16 v40, v63, s39, 0                           // 0000001F6510: CC210028 02004F3F
	v_fma_mixhi_f16 v40, v64, s39, 0                           // 0000001F6518: CC220028 02004F40
	v_wmma_f32_16x16x16_f16 v[57:64], v[89:96], v[17:24], v[214:221]// 0000001F6520: CC404039 1F5A2359
	v_fma_mixlo_f16 v20, v228, s39, 0                          // 0000001F6528: CC210014 02004FE4
	v_fma_mixhi_f16 v20, v229, s39, 0                          // 0000001F6530: CC220014 02004FE5
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001F6538: BF870004
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[33:40], v[214:221]// 0000001F653C: CC404029 1F5A4359
	ds_load_b128 v[33:36], v137 offset:25344                   // 0000001F6544: DBFC6300 21000089
	ds_load_b128 v[37:40], v137 offset:25360                   // 0000001F654C: DBFC6310 25000089
	v_fma_mixlo_f16 v21, v230, s39, 0                          // 0000001F6554: CC210015 02004FE6
	v_fma_mixhi_f16 v21, v231, s39, 0                          // 0000001F655C: CC220015 02004FE7
	ds_load_b128 v[228:231], v137 offset:25392                 // 0000001F6564: DBFC6330 E4000089
	v_fma_mixlo_f16 v19, v226, s39, 0                          // 0000001F656C: CC210013 02004FE2
	v_fma_mixlo_f16 v22, v232, s39, 0                          // 0000001F6574: CC210016 02004FE8
	v_fma_mixhi_f16 v22, v233, s39, 0                          // 0000001F657C: CC220016 02004FE9
	v_fma_mixlo_f16 v23, v234, s39, 0                          // 0000001F6584: CC210017 02004FEA
	v_fma_mixhi_f16 v23, v235, s39, 0                          // 0000001F658C: CC220017 02004FEB
	v_fma_mixlo_f16 v24, v236, s39, 0                          // 0000001F6594: CC210018 02004FEC
	v_fma_mixhi_f16 v24, v237, s39, 0                          // 0000001F659C: CC220018 02004FED
	ds_load_b128 v[232:235], v137 offset:64                    // 0000001F65A4: DBFC0040 E8000089
	v_fma_mixlo_f16 v226, v238, s39, 0                         // 0000001F65AC: CC2100E2 02004FEE
	v_fma_mixhi_f16 v226, v239, s39, 0                         // 0000001F65B4: CC2200E2 02004FEF
	ds_load_b128 v[236:239], v137 offset:96                    // 0000001F65BC: DBFC0060 EC000089
	v_fma_mixlo_f16 v17, v222, s39, 0                          // 0000001F65C4: CC210011 02004FDE
	v_fma_mixhi_f16 v17, v223, s39, 0                          // 0000001F65CC: CC220011 02004FDF
	v_fma_mixlo_f16 v18, v224, s39, 0                          // 0000001F65D4: CC210012 02004FE0
	v_fma_mixhi_f16 v18, v225, s39, 0                          // 0000001F65DC: CC220012 02004FE1
	v_fma_mixhi_f16 v19, v227, s39, 0                          // 0000001F65E4: CC220013 02004FE3
	s_waitcnt lgkmcnt(4)                                       // 0000001F65EC: BF89FC47
	v_fma_mixlo_f16 v222, v33, s39, 0                          // 0000001F65F0: CC2100DE 02004F21
	v_fma_mixhi_f16 v222, v34, s39, 0                          // 0000001F65F8: CC2200DE 02004F22
	v_fma_mixlo_f16 v223, v35, s39, 0                          // 0000001F6600: CC2100DF 02004F23
	v_fma_mixhi_f16 v223, v36, s39, 0                          // 0000001F6608: CC2200DF 02004F24
	s_waitcnt lgkmcnt(3)                                       // 0000001F6610: BF89FC37
	v_fma_mixlo_f16 v224, v37, s39, 0                          // 0000001F6614: CC2100E0 02004F25
	v_fma_mixhi_f16 v224, v38, s39, 0                          // 0000001F661C: CC2200E0 02004F26
	v_fma_mixlo_f16 v225, v39, s39, 0                          // 0000001F6624: CC2100E1 02004F27
	v_fma_mixhi_f16 v225, v40, s39, 0                          // 0000001F662C: CC2200E1 02004F28
	v_fma_mixlo_f16 v227, v240, s39, 0                         // 0000001F6634: CC2100E3 02004FF0
	v_fma_mixhi_f16 v227, v241, s39, 0                         // 0000001F663C: CC2200E3 02004FF1
	s_waitcnt lgkmcnt(2)                                       // 0000001F6644: BF89FC27
	v_fma_mixlo_f16 v228, v228, s39, 0                         // 0000001F6648: CC2100E4 02004FE4
	v_fma_mixhi_f16 v228, v229, s39, 0                         // 0000001F6650: CC2200E4 02004FE5
	v_fma_mixlo_f16 v229, v230, s39, 0                         // 0000001F6658: CC2100E5 02004FE6
	v_fma_mixhi_f16 v229, v231, s39, 0                         // 0000001F6660: CC2200E5 02004FE7
	v_wmma_f32_16x16x16_f16 v[33:40], v[89:96], v[17:24], v[214:221]// 0000001F6668: CC404021 1F5A2359
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001F6670: BF870002
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[222:229], v[214:221]// 0000001F6674: CC404011 1F5BBD59
	ds_load_b128 v[214:217], v137 offset:8512                  // 0000001F667C: DBFC2140 D6000089
	ds_load_b128 v[218:221], v137 offset:8528                  // 0000001F6684: DBFC2150 DA000089
	s_waitcnt lgkmcnt(3)                                       // 0000001F668C: BF89FC37
	v_fma_mixlo_f16 v89, v232, s39, 0                          // 0000001F6690: CC210059 02004FE8
	v_fma_mixhi_f16 v89, v233, s39, 0                          // 0000001F6698: CC220059 02004FE9
	v_fma_mixlo_f16 v90, v234, s39, 0                          // 0000001F66A0: CC21005A 02004FEA
	v_fma_mixhi_f16 v90, v235, s39, 0                          // 0000001F66A8: CC22005A 02004FEB
	ds_load_b128 v[222:225], v137 offset:8544                  // 0000001F66B0: DBFC2160 DE000089
	ds_load_b128 v[226:229], v137 offset:8560                  // 0000001F66B8: DBFC2170 E2000089
	s_waitcnt lgkmcnt(4)                                       // 0000001F66C0: BF89FC47
	v_fma_mixlo_f16 v93, v236, s39, 0                          // 0000001F66C4: CC21005D 02004FEC
	v_fma_mixhi_f16 v93, v237, s39, 0                          // 0000001F66CC: CC22005D 02004FED
	v_fma_mixlo_f16 v94, v238, s39, 0                          // 0000001F66D4: CC21005E 02004FEE
	v_fma_mixhi_f16 v94, v239, s39, 0                          // 0000001F66DC: CC22005E 02004FEF
	ds_load_b128 v[230:233], v137 offset:16960                 // 0000001F66E4: DBFC4240 E6000089
	ds_load_b128 v[234:237], v137 offset:16976                 // 0000001F66EC: DBFC4250 EA000089
	ds_load_b128 v[238:241], v137 offset:16992                 // 0000001F66F4: DBFC4260 EE000089
	v_fma_mixlo_f16 v91, v242, s39, 0                          // 0000001F66FC: CC21005B 02004FF2
	v_fma_mixhi_f16 v91, v243, s39, 0                          // 0000001F6704: CC22005B 02004FF3
	v_fma_mixlo_f16 v92, v244, s39, 0                          // 0000001F670C: CC21005C 02004FF4
	v_fma_mixhi_f16 v92, v245, s39, 0                          // 0000001F6714: CC22005C 02004FF5
	v_fma_mixlo_f16 v95, v246, s39, 0                          // 0000001F671C: CC21005F 02004FF6
	v_fma_mixhi_f16 v95, v247, s39, 0                          // 0000001F6724: CC22005F 02004FF7
	v_fma_mixlo_f16 v96, v248, s39, 0                          // 0000001F672C: CC210060 02004FF8
	v_fma_mixhi_f16 v96, v249, s39, 0                          // 0000001F6734: CC220060 02004FF9
	s_waitcnt lgkmcnt(6)                                       // 0000001F673C: BF89FC67
	v_fma_mixlo_f16 v214, v214, s39, 0                         // 0000001F6740: CC2100D6 02004FD6
	v_fma_mixhi_f16 v214, v215, s39, 0                         // 0000001F6748: CC2200D6 02004FD7
	v_fma_mixlo_f16 v215, v216, s39, 0                         // 0000001F6750: CC2100D7 02004FD8
	v_fma_mixhi_f16 v215, v217, s39, 0                         // 0000001F6758: CC2200D7 02004FD9
	s_waitcnt lgkmcnt(5)                                       // 0000001F6760: BF89FC57
	v_fma_mixhi_f16 v216, v219, s39, 0                         // 0000001F6764: CC2200D8 02004FDB
	v_fma_mixlo_f16 v217, v220, s39, 0                         // 0000001F676C: CC2100D9 02004FDC
	s_waitcnt lgkmcnt(4)                                       // 0000001F6774: BF89FC47
	v_fma_mixhi_f16 v219, v225, s39, 0                         // 0000001F6778: CC2200DB 02004FE1
	s_waitcnt lgkmcnt(3)                                       // 0000001F6780: BF89FC37
	v_fma_mixlo_f16 v220, v226, s39, 0                         // 0000001F6784: CC2100DC 02004FE2
	ds_load_b128 v[242:245], v137 offset:17008                 // 0000001F678C: DBFC4270 F2000089
	ds_load_b128 v[246:249], v137 offset:25408                 // 0000001F6794: DBFC6340 F6000089
	s_waitcnt lgkmcnt(3)                                       // 0000001F679C: BF89FC37
	v_fma_mixlo_f16 v225, v236, s39, 0                         // 0000001F67A0: CC2100E1 02004FEC
	v_fma_mixhi_f16 v225, v237, s39, 0                         // 0000001F67A8: CC2200E1 02004FED
	s_waitcnt lgkmcnt(2)                                       // 0000001F67B0: BF89FC27
	v_fma_mixlo_f16 v226, v238, s39, 0                         // 0000001F67B4: CC2100E2 02004FEE
	v_fma_mixhi_f16 v226, v239, s39, 0                         // 0000001F67BC: CC2200E2 02004FEF
	ds_load_b128 v[236:239], v137 offset:25456                 // 0000001F67C4: DBFC6370 EC000089
	v_fma_mixlo_f16 v219, v224, s39, 0                         // 0000001F67CC: CC2100DB 02004FE0
	v_fma_mixlo_f16 v224, v234, s39, 0                         // 0000001F67D4: CC2100E0 02004FEA
	v_fma_mixhi_f16 v224, v235, s39, 0                         // 0000001F67DC: CC2200E0 02004FEB
	v_fma_mixlo_f16 v234, v118, s39, 0                         // 0000001F67E4: CC2100EA 02004F76
	v_fma_mixhi_f16 v234, v119, s39, 0                         // 0000001F67EC: CC2200EA 02004F77
	v_fma_mixlo_f16 v235, v120, s39, 0                         // 0000001F67F4: CC2100EB 02004F78
	v_fma_mixhi_f16 v235, v121, s39, 0                         // 0000001F67FC: CC2200EB 02004F79
	ds_load_b128 v[118:121], v137 offset:160                   // 0000001F6804: DBFC00A0 76000089
	v_fma_mixlo_f16 v216, v218, s39, 0                         // 0000001F680C: CC2100D8 02004FDA
	v_fma_mixhi_f16 v217, v221, s39, 0                         // 0000001F6814: CC2200D9 02004FDD
	v_fma_mixlo_f16 v218, v222, s39, 0                         // 0000001F681C: CC2100DA 02004FDE
	v_fma_mixhi_f16 v218, v223, s39, 0                         // 0000001F6824: CC2200DA 02004FDF
	v_fma_mixhi_f16 v220, v227, s39, 0                         // 0000001F682C: CC2200DC 02004FE3
	v_fma_mixlo_f16 v221, v228, s39, 0                         // 0000001F6834: CC2100DD 02004FE4
	v_fma_mixhi_f16 v221, v229, s39, 0                         // 0000001F683C: CC2200DD 02004FE5
	v_fma_mixlo_f16 v222, v230, s39, 0                         // 0000001F6844: CC2100DE 02004FE6
	v_fma_mixhi_f16 v222, v231, s39, 0                         // 0000001F684C: CC2200DE 02004FE7
	v_fma_mixlo_f16 v223, v232, s39, 0                         // 0000001F6854: CC2100DF 02004FE8
	v_fma_mixhi_f16 v223, v233, s39, 0                         // 0000001F685C: CC2200DF 02004FE9
	v_fma_mixlo_f16 v227, v240, s39, 0                         // 0000001F6864: CC2100E3 02004FF0
	v_fma_mixhi_f16 v227, v241, s39, 0                         // 0000001F686C: CC2200E3 02004FF1
	s_waitcnt lgkmcnt(3)                                       // 0000001F6874: BF89FC37
	v_fma_mixlo_f16 v228, v242, s39, 0                         // 0000001F6878: CC2100E4 02004FF2
	v_fma_mixhi_f16 v228, v243, s39, 0                         // 0000001F6880: CC2200E4 02004FF3
	v_fma_mixlo_f16 v229, v244, s39, 0                         // 0000001F6888: CC2100E5 02004FF4
	v_fma_mixhi_f16 v229, v245, s39, 0                         // 0000001F6890: CC2200E5 02004FF5
	s_waitcnt lgkmcnt(2)                                       // 0000001F6898: BF89FC27
	v_fma_mixlo_f16 v230, v246, s39, 0                         // 0000001F689C: CC2100E6 02004FF6
	v_fma_mixhi_f16 v230, v247, s39, 0                         // 0000001F68A4: CC2200E6 02004FF7
	v_fma_mixlo_f16 v231, v248, s39, 0                         // 0000001F68AC: CC2100E7 02004FF8
	v_fma_mixhi_f16 v231, v249, s39, 0                         // 0000001F68B4: CC2200E7 02004FF9
	v_fma_mixlo_f16 v232, v250, s39, 0                         // 0000001F68BC: CC2100E8 02004FFA
	v_fma_mixhi_f16 v232, v251, s39, 0                         // 0000001F68C4: CC2200E8 02004FFB
	v_fma_mixlo_f16 v233, v252, s39, 0                         // 0000001F68CC: CC2100E9 02004FFC
	v_fma_mixhi_f16 v233, v253, s39, 0                         // 0000001F68D4: CC2200E9 02004FFD
	s_waitcnt lgkmcnt(1)                                       // 0000001F68DC: BF89FC17
	v_fma_mixlo_f16 v236, v236, s39, 0                         // 0000001F68E0: CC2100EC 02004FEC
	v_fma_mixhi_f16 v236, v237, s39, 0                         // 0000001F68E8: CC2200EC 02004FED
	v_fma_mixlo_f16 v237, v238, s39, 0                         // 0000001F68F0: CC2100ED 02004FEE
	v_fma_mixhi_f16 v237, v239, s39, 0                         // 0000001F68F8: CC2200ED 02004FEF
	v_wmma_f32_16x16x16_f16 v[57:64], v[81:88], v[89:96], v[57:64]// 0000001F6900: CC404039 1CE6B351
	ds_load_b128 v[89:92], v137 offset:176                     // 0000001F6908: DBFC00B0 59000089
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[214:221], v[41:48]// 0000001F6910: CC404029 1CA7AD51
	v_wmma_f32_16x16x16_f16 v[33:40], v[81:88], v[222:229], v[33:40]// 0000001F6918: CC404021 1C87BD51
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[230:237], v[17:24]// 0000001F6920: CC404011 1C47CD51
	ds_load_b128 v[93:96], v137 offset:8576                    // 0000001F6928: DBFC2180 5D000089
	ds_load_b128 v[214:217], v137 offset:8592                  // 0000001F6930: DBFC2190 D6000089
	ds_load_b128 v[218:221], v137 offset:8608                  // 0000001F6938: DBFC21A0 DA000089
	s_waitcnt lgkmcnt(4)                                       // 0000001F6940: BF89FC47
	v_fma_mixlo_f16 v85, v118, s39, 0                          // 0000001F6944: CC210055 02004F76
	v_fma_mixhi_f16 v85, v119, s39, 0                          // 0000001F694C: CC220055 02004F77
	v_fma_mixlo_f16 v86, v120, s39, 0                          // 0000001F6954: CC210056 02004F78
	v_fma_mixhi_f16 v86, v121, s39, 0                          // 0000001F695C: CC220056 02004F79
	ds_load_b128 v[118:121], v137 offset:8624                  // 0000001F6964: DBFC21B0 76000089
	ds_load_b128 v[240:243], v137 offset:128                   // 0000001F696C: DBFC0080 F0000089
	ds_load_b128 v[244:247], v137 offset:144                   // 0000001F6974: DBFC0090 F4000089
	ds_load_b128 v[222:225], v137 offset:17024                 // 0000001F697C: DBFC4280 DE000089
	ds_load_b128 v[226:229], v137 offset:17040                 // 0000001F6984: DBFC4290 E2000089
	ds_load_b128 v[230:233], v137 offset:17056                 // 0000001F698C: DBFC42A0 E6000089
	ds_load_b128 v[234:237], v137 offset:17072                 // 0000001F6994: DBFC42B0 EA000089
	s_waitcnt lgkmcnt(10)                                      // 0000001F699C: BF89FCA7
	v_fma_mixhi_f16 v87, v90, s39, 0                           // 0000001F69A0: CC220057 02004F5A
	v_fma_mixlo_f16 v87, v89, s39, 0                           // 0000001F69A8: CC210057 02004F59
	v_fma_mixhi_f16 v88, v92, s39, 0                           // 0000001F69B0: CC220058 02004F5C
	v_fma_mixlo_f16 v88, v91, s39, 0                           // 0000001F69B8: CC210058 02004F5B
	s_waitcnt lgkmcnt(9)                                       // 0000001F69C0: BF89FC97
	v_fma_mixlo_f16 v90, v95, s39, 0                           // 0000001F69C4: CC21005A 02004F5F
	v_fma_mixhi_f16 v90, v96, s39, 0                           // 0000001F69CC: CC22005A 02004F60
	v_fma_mixlo_f16 v89, v93, s39, 0                           // 0000001F69D4: CC210059 02004F5D
	s_waitcnt lgkmcnt(8)                                       // 0000001F69DC: BF89FC87
	v_fma_mixhi_f16 v92, v217, s39, 0                          // 0000001F69E0: CC22005C 02004FD9
	s_waitcnt lgkmcnt(7)                                       // 0000001F69E8: BF89FC77
	v_fma_mixlo_f16 v93, v218, s39, 0                          // 0000001F69EC: CC21005D 02004FDA
	v_fma_mixlo_f16 v91, v214, s39, 0                          // 0000001F69F4: CC21005B 02004FD6
	v_fma_mixhi_f16 v89, v94, s39, 0                           // 0000001F69FC: CC220059 02004F5E
	s_waitcnt lgkmcnt(6)                                       // 0000001F6A04: BF89FC67
	v_fma_mixlo_f16 v95, v118, s39, 0                          // 0000001F6A08: CC21005F 02004F76
	v_fma_mixhi_f16 v95, v119, s39, 0                          // 0000001F6A10: CC22005F 02004F77
	v_fma_mixlo_f16 v96, v120, s39, 0                          // 0000001F6A18: CC210060 02004F78
	v_fma_mixhi_f16 v96, v121, s39, 0                          // 0000001F6A20: CC220060 02004F79
	ds_load_b128 v[118:121], v137 offset:25472                 // 0000001F6A28: DBFC6380 76000089
	s_waitcnt lgkmcnt(6)                                       // 0000001F6A30: BF89FC67
	v_fma_mixlo_f16 v81, v240, s39, 0                          // 0000001F6A34: CC210051 02004FF0
	v_fma_mixhi_f16 v81, v241, s39, 0                          // 0000001F6A3C: CC220051 02004FF1
	v_fma_mixlo_f16 v82, v242, s39, 0                          // 0000001F6A44: CC210052 02004FF2
	v_fma_mixhi_f16 v82, v243, s39, 0                          // 0000001F6A4C: CC220052 02004FF3
	s_waitcnt lgkmcnt(5)                                       // 0000001F6A54: BF89FC57
	v_fma_mixlo_f16 v83, v244, s39, 0                          // 0000001F6A58: CC210053 02004FF4
	v_fma_mixhi_f16 v83, v245, s39, 0                          // 0000001F6A60: CC220053 02004FF5
	ds_load_b128 v[238:241], v137 offset:25488                 // 0000001F6A68: DBFC6390 EE000089
	s_waitcnt lgkmcnt(4)                                       // 0000001F6A70: BF89FC47
	v_fma_mixlo_f16 v217, v228, s39, 0                         // 0000001F6A74: CC2100D9 02004FE4
	ds_load_b128 v[242:245], v137 offset:25504                 // 0000001F6A7C: DBFC63A0 F2000089
	v_fma_mixhi_f16 v217, v229, s39, 0                         // 0000001F6A84: CC2200D9 02004FE5
	s_waitcnt lgkmcnt(4)                                       // 0000001F6A8C: BF89FC47
	v_fma_mixlo_f16 v218, v230, s39, 0                         // 0000001F6A90: CC2100DA 02004FE6
	v_fma_mixhi_f16 v218, v231, s39, 0                         // 0000001F6A98: CC2200DA 02004FE7
	ds_load_b128 v[228:231], v137 offset:25520                 // 0000001F6AA0: DBFC63B0 E4000089
	v_fma_mixlo_f16 v214, v222, s39, 0                         // 0000001F6AA8: CC2100D6 02004FDE
	v_fma_mixhi_f16 v214, v223, s39, 0                         // 0000001F6AB0: CC2200D6 02004FDF
	v_fma_mixlo_f16 v84, v246, s39, 0                          // 0000001F6AB8: CC210054 02004FF6
	v_fma_mixhi_f16 v84, v247, s39, 0                          // 0000001F6AC0: CC220054 02004FF7
	v_fma_mixhi_f16 v91, v215, s39, 0                          // 0000001F6AC8: CC22005B 02004FD7
	v_fma_mixlo_f16 v92, v216, s39, 0                          // 0000001F6AD0: CC21005C 02004FD8
	s_waitcnt lgkmcnt(3)                                       // 0000001F6AD8: BF89FC37
	v_fma_mixlo_f16 v222, v118, s39, 0                         // 0000001F6ADC: CC2100DE 02004F76
	v_fma_mixhi_f16 v222, v119, s39, 0                         // 0000001F6AE4: CC2200DE 02004F77
	v_fma_mixlo_f16 v223, v120, s39, 0                         // 0000001F6AEC: CC2100DF 02004F78
	v_fma_mixhi_f16 v223, v121, s39, 0                         // 0000001F6AF4: CC2200DF 02004F79
	ds_load_b128 v[118:121], v137 offset:192                   // 0000001F6AFC: DBFC00C0 76000089
	v_fma_mixhi_f16 v93, v219, s39, 0                          // 0000001F6B04: CC22005D 02004FDB
	v_fma_mixlo_f16 v94, v220, s39, 0                          // 0000001F6B0C: CC21005E 02004FDC
	v_fma_mixhi_f16 v94, v221, s39, 0                          // 0000001F6B14: CC22005E 02004FDD
	v_fma_mixlo_f16 v215, v224, s39, 0                         // 0000001F6B1C: CC2100D7 02004FE0
	v_fma_mixhi_f16 v215, v225, s39, 0                         // 0000001F6B24: CC2200D7 02004FE1
	v_fma_mixlo_f16 v216, v226, s39, 0                         // 0000001F6B2C: CC2100D8 02004FE2
	v_fma_mixhi_f16 v216, v227, s39, 0                         // 0000001F6B34: CC2200D8 02004FE3
	v_fma_mixlo_f16 v219, v232, s39, 0                         // 0000001F6B3C: CC2100DB 02004FE8
	v_fma_mixhi_f16 v219, v233, s39, 0                         // 0000001F6B44: CC2200DB 02004FE9
	v_fma_mixlo_f16 v220, v234, s39, 0                         // 0000001F6B4C: CC2100DC 02004FEA
	v_fma_mixhi_f16 v220, v235, s39, 0                         // 0000001F6B54: CC2200DC 02004FEB
	v_fma_mixlo_f16 v221, v236, s39, 0                         // 0000001F6B5C: CC2100DD 02004FEC
	v_fma_mixhi_f16 v221, v237, s39, 0                         // 0000001F6B64: CC2200DD 02004FED
	s_waitcnt lgkmcnt(3)                                       // 0000001F6B6C: BF89FC37
	v_fma_mixlo_f16 v224, v238, s39, 0                         // 0000001F6B70: CC2100E0 02004FEE
	v_fma_mixhi_f16 v224, v239, s39, 0                         // 0000001F6B78: CC2200E0 02004FEF
	v_fma_mixlo_f16 v225, v240, s39, 0                         // 0000001F6B80: CC2100E1 02004FF0
	v_fma_mixhi_f16 v225, v241, s39, 0                         // 0000001F6B88: CC2200E1 02004FF1
	s_waitcnt lgkmcnt(2)                                       // 0000001F6B90: BF89FC27
	v_fma_mixlo_f16 v226, v242, s39, 0                         // 0000001F6B94: CC2100E2 02004FF2
	v_fma_mixhi_f16 v226, v243, s39, 0                         // 0000001F6B9C: CC2200E2 02004FF3
	v_fma_mixlo_f16 v227, v244, s39, 0                         // 0000001F6BA4: CC2100E3 02004FF4
	v_fma_mixhi_f16 v227, v245, s39, 0                         // 0000001F6BAC: CC2200E3 02004FF5
	s_waitcnt lgkmcnt(1)                                       // 0000001F6BB4: BF89FC17
	v_fma_mixlo_f16 v228, v228, s39, 0                         // 0000001F6BB8: CC2100E4 02004FE4
	v_fma_mixhi_f16 v228, v229, s39, 0                         // 0000001F6BC0: CC2200E4 02004FE5
	v_fma_mixlo_f16 v229, v230, s39, 0                         // 0000001F6BC8: CC2100E5 02004FE6
	v_fma_mixhi_f16 v229, v231, s39, 0                         // 0000001F6BD0: CC2200E5 02004FE7
	ds_load_b128 v[232:235], v137 offset:208                   // 0000001F6BD8: DBFC00D0 E8000089
	ds_load_b128 v[236:239], v137 offset:224                   // 0000001F6BE0: DBFC00E0 EC000089
	v_wmma_f32_16x16x16_f16 v[57:64], v[73:80], v[81:88], v[57:64]// 0000001F6BE8: CC404039 1CE6A349
	ds_load_b128 v[81:84], v137 offset:240                     // 0000001F6BF0: DBFC00F0 51000089
	v_wmma_f32_16x16x16_f16 v[41:48], v[73:80], v[89:96], v[41:48]// 0000001F6BF8: CC404029 1CA6B349
	v_wmma_f32_16x16x16_f16 v[33:40], v[73:80], v[214:221], v[33:40]// 0000001F6C00: CC404021 1C87AD49
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[222:229], v[17:24]// 0000001F6C08: CC404011 1C47BD49
	ds_load_b128 v[85:88], v137 offset:8640                    // 0000001F6C10: DBFC21C0 55000089
	ds_load_b128 v[89:92], v137 offset:8656                    // 0000001F6C18: DBFC21D0 59000089
	s_waitcnt lgkmcnt(5)                                       // 0000001F6C20: BF89FC57
	v_fma_mixlo_f16 v73, v118, s39, 0                          // 0000001F6C24: CC210049 02004F76
	v_fma_mixhi_f16 v73, v119, s39, 0                          // 0000001F6C2C: CC220049 02004F77
	v_fma_mixlo_f16 v74, v120, s39, 0                          // 0000001F6C34: CC21004A 02004F78
	v_fma_mixhi_f16 v74, v121, s39, 0                          // 0000001F6C3C: CC22004A 02004F79
	ds_load_b128 v[93:96], v137 offset:8672                    // 0000001F6C44: DBFC21E0 5D000089
	ds_load_b128 v[118:121], v137 offset:8688                  // 0000001F6C4C: DBFC21F0 76000089
	ds_load_b128 v[214:217], v137 offset:17088                 // 0000001F6C54: DBFC42C0 D6000089
	ds_load_b128 v[218:221], v137 offset:17104                 // 0000001F6C5C: DBFC42D0 DA000089
	ds_load_b128 v[222:225], v137 offset:17120                 // 0000001F6C64: DBFC42E0 DE000089
	ds_load_b128 v[226:229], v137 offset:17136                 // 0000001F6C6C: DBFC42F0 E2000089
	s_waitcnt lgkmcnt(10)                                      // 0000001F6C74: BF89FCA7
	v_fma_mixlo_f16 v75, v232, s39, 0                          // 0000001F6C78: CC21004B 02004FE8
	v_fma_mixhi_f16 v75, v233, s39, 0                          // 0000001F6C80: CC22004B 02004FE9
	v_fma_mixlo_f16 v76, v234, s39, 0                          // 0000001F6C88: CC21004C 02004FEA
	s_waitcnt lgkmcnt(8)                                       // 0000001F6C90: BF89FC87
	v_fma_mixhi_f16 v79, v82, s39, 0                           // 0000001F6C94: CC22004F 02004F52
	v_fma_mixhi_f16 v76, v235, s39, 0                          // 0000001F6C9C: CC22004C 02004FEB
	v_fma_mixlo_f16 v77, v236, s39, 0                          // 0000001F6CA4: CC21004D 02004FEC
	v_fma_mixhi_f16 v77, v237, s39, 0                          // 0000001F6CAC: CC22004D 02004FED
	s_waitcnt lgkmcnt(7)                                       // 0000001F6CB4: BF89FC77
	v_fma_mixlo_f16 v82, v87, s39, 0                           // 0000001F6CB8: CC210052 02004F57
	v_fma_mixhi_f16 v82, v88, s39, 0                           // 0000001F6CC0: CC220052 02004F58
	v_fma_mixlo_f16 v79, v81, s39, 0                           // 0000001F6CC8: CC21004F 02004F51
	v_fma_mixhi_f16 v80, v84, s39, 0                           // 0000001F6CD0: CC220050 02004F54
	v_fma_mixlo_f16 v81, v85, s39, 0                           // 0000001F6CD8: CC210051 02004F55
	s_waitcnt lgkmcnt(6)                                       // 0000001F6CE0: BF89FC67
	v_fma_mixhi_f16 v84, v92, s39, 0                           // 0000001F6CE4: CC220054 02004F5C
	s_waitcnt lgkmcnt(5)                                       // 0000001F6CEC: BF89FC57
	v_fma_mixlo_f16 v85, v93, s39, 0                           // 0000001F6CF0: CC210055 02004F5D
	s_waitcnt lgkmcnt(4)                                       // 0000001F6CF8: BF89FC47
	v_fma_mixlo_f16 v87, v118, s39, 0                          // 0000001F6CFC: CC210057 02004F76
	v_fma_mixhi_f16 v87, v119, s39, 0                          // 0000001F6D04: CC220057 02004F77
	v_fma_mixlo_f16 v88, v120, s39, 0                          // 0000001F6D0C: CC210058 02004F78
	v_fma_mixhi_f16 v88, v121, s39, 0                          // 0000001F6D14: CC220058 02004F79
	ds_load_b128 v[118:121], v137 offset:25536                 // 0000001F6D1C: DBFC63C0 76000089
	ds_load_b128 v[230:233], v137 offset:25552                 // 0000001F6D24: DBFC63D0 E6000089
	s_waitcnt lgkmcnt(4)                                       // 0000001F6D2C: BF89FC47
	v_fma_mixlo_f16 v92, v220, s39, 0                          // 0000001F6D30: CC21005C 02004FDC
	ds_load_b128 v[234:237], v137 offset:25568                 // 0000001F6D38: DBFC63E0 EA000089
	v_fma_mixhi_f16 v92, v221, s39, 0                          // 0000001F6D40: CC22005C 02004FDD
	s_waitcnt lgkmcnt(4)                                       // 0000001F6D48: BF89FC47
	v_fma_mixlo_f16 v93, v222, s39, 0                          // 0000001F6D4C: CC21005D 02004FDE
	v_fma_mixhi_f16 v93, v223, s39, 0                          // 0000001F6D54: CC22005D 02004FDF
	ds_load_b128 v[220:223], v137 offset:25584                 // 0000001F6D5C: DBFC63F0 DC000089
	v_fma_mixlo_f16 v80, v83, s39, 0                           // 0000001F6D64: CC210050 02004F53
	v_fma_mixlo_f16 v83, v89, s39, 0                           // 0000001F6D6C: CC210053 02004F59
	v_fma_mixlo_f16 v89, v214, s39, 0                          // 0000001F6D74: CC210059 02004FD6
	v_fma_mixhi_f16 v89, v215, s39, 0                          // 0000001F6D7C: CC220059 02004FD7
	v_fma_mixlo_f16 v78, v238, s39, 0                          // 0000001F6D84: CC21004E 02004FEE
	v_fma_mixhi_f16 v78, v239, s39, 0                          // 0000001F6D8C: CC22004E 02004FEF
	v_fma_mixhi_f16 v81, v86, s39, 0                           // 0000001F6D94: CC220051 02004F56
	v_fma_mixhi_f16 v83, v90, s39, 0                           // 0000001F6D9C: CC220053 02004F5A
	v_fma_mixlo_f16 v84, v91, s39, 0                           // 0000001F6DA4: CC210054 02004F5B
	v_fma_mixhi_f16 v85, v94, s39, 0                           // 0000001F6DAC: CC220055 02004F5E
	v_fma_mixlo_f16 v86, v95, s39, 0                           // 0000001F6DB4: CC210056 02004F5F
	v_fma_mixhi_f16 v86, v96, s39, 0                           // 0000001F6DBC: CC220056 02004F60
	s_waitcnt lgkmcnt(3)                                       // 0000001F6DC4: BF89FC37
	v_fma_mixlo_f16 v214, v118, s39, 0                         // 0000001F6DC8: CC2100D6 02004F76
	v_fma_mixhi_f16 v214, v119, s39, 0                         // 0000001F6DD0: CC2200D6 02004F77
	v_fma_mixlo_f16 v215, v120, s39, 0                         // 0000001F6DD8: CC2100D7 02004F78
	v_fma_mixhi_f16 v215, v121, s39, 0                         // 0000001F6DE0: CC2200D7 02004F79
	ds_load_b128 v[118:121], v137 offset:256                   // 0000001F6DE8: DBFC0100 76000089
	v_fma_mixlo_f16 v90, v216, s39, 0                          // 0000001F6DF0: CC21005A 02004FD8
	v_fma_mixhi_f16 v90, v217, s39, 0                          // 0000001F6DF8: CC22005A 02004FD9
	v_fma_mixlo_f16 v91, v218, s39, 0                          // 0000001F6E00: CC21005B 02004FDA
	v_fma_mixhi_f16 v91, v219, s39, 0                          // 0000001F6E08: CC22005B 02004FDB
	v_fma_mixlo_f16 v94, v224, s39, 0                          // 0000001F6E10: CC21005E 02004FE0
	v_fma_mixhi_f16 v94, v225, s39, 0                          // 0000001F6E18: CC22005E 02004FE1
	v_fma_mixlo_f16 v95, v226, s39, 0                          // 0000001F6E20: CC21005F 02004FE2
	v_fma_mixhi_f16 v95, v227, s39, 0                          // 0000001F6E28: CC22005F 02004FE3
	v_fma_mixlo_f16 v96, v228, s39, 0                          // 0000001F6E30: CC210060 02004FE4
	v_fma_mixhi_f16 v96, v229, s39, 0                          // 0000001F6E38: CC220060 02004FE5
	s_waitcnt lgkmcnt(3)                                       // 0000001F6E40: BF89FC37
	v_fma_mixlo_f16 v216, v230, s39, 0                         // 0000001F6E44: CC2100D8 02004FE6
	v_fma_mixhi_f16 v216, v231, s39, 0                         // 0000001F6E4C: CC2200D8 02004FE7
	v_fma_mixlo_f16 v217, v232, s39, 0                         // 0000001F6E54: CC2100D9 02004FE8
	v_fma_mixhi_f16 v217, v233, s39, 0                         // 0000001F6E5C: CC2200D9 02004FE9
	s_waitcnt lgkmcnt(2)                                       // 0000001F6E64: BF89FC27
	v_fma_mixlo_f16 v218, v234, s39, 0                         // 0000001F6E68: CC2100DA 02004FEA
	v_fma_mixhi_f16 v218, v235, s39, 0                         // 0000001F6E70: CC2200DA 02004FEB
	v_fma_mixlo_f16 v219, v236, s39, 0                         // 0000001F6E78: CC2100DB 02004FEC
	v_fma_mixhi_f16 v219, v237, s39, 0                         // 0000001F6E80: CC2200DB 02004FED
	s_waitcnt lgkmcnt(1)                                       // 0000001F6E88: BF89FC17
	v_fma_mixlo_f16 v220, v220, s39, 0                         // 0000001F6E8C: CC2100DC 02004FDC
	v_fma_mixhi_f16 v220, v221, s39, 0                         // 0000001F6E94: CC2200DC 02004FDD
	v_fma_mixlo_f16 v221, v222, s39, 0                         // 0000001F6E9C: CC2100DD 02004FDE
	v_fma_mixhi_f16 v221, v223, s39, 0                         // 0000001F6EA4: CC2200DD 02004FDF
	ds_load_b128 v[224:227], v137 offset:272                   // 0000001F6EAC: DBFC0110 E0000089
	ds_load_b128 v[228:231], v137 offset:288                   // 0000001F6EB4: DBFC0120 E4000089
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[73:80], v[57:64]// 0000001F6EBC: CC404039 1CE69341
	ds_load_b128 v[73:76], v137 offset:304                     // 0000001F6EC4: DBFC0130 49000089
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[81:88], v[41:48]// 0000001F6ECC: CC404029 1CA6A341
	v_wmma_f32_16x16x16_f16 v[33:40], v[65:72], v[89:96], v[33:40]// 0000001F6ED4: CC404021 1C86B341
	v_wmma_f32_16x16x16_f16 v[17:24], v[65:72], v[214:221], v[17:24]// 0000001F6EDC: CC404011 1C47AD41
	ds_load_b128 v[77:80], v137 offset:8704                    // 0000001F6EE4: DBFC2200 4D000089
	ds_load_b128 v[81:84], v137 offset:8720                    // 0000001F6EEC: DBFC2210 51000089
	s_waitcnt lgkmcnt(5)                                       // 0000001F6EF4: BF89FC57
	v_fma_mixlo_f16 v65, v118, s39, 0                          // 0000001F6EF8: CC210041 02004F76
	v_fma_mixhi_f16 v65, v119, s39, 0                          // 0000001F6F00: CC220041 02004F77
	v_fma_mixlo_f16 v66, v120, s39, 0                          // 0000001F6F08: CC210042 02004F78
	v_fma_mixhi_f16 v66, v121, s39, 0                          // 0000001F6F10: CC220042 02004F79
	ds_load_b128 v[85:88], v137 offset:8736                    // 0000001F6F18: DBFC2220 55000089
	ds_load_b128 v[89:92], v137 offset:8752                    // 0000001F6F20: DBFC2230 59000089
	ds_load_b128 v[93:96], v137 offset:17152                   // 0000001F6F28: DBFC4300 5D000089
	ds_load_b128 v[118:121], v137 offset:17168                 // 0000001F6F30: DBFC4310 76000089
	ds_load_b128 v[214:217], v137 offset:17184                 // 0000001F6F38: DBFC4320 D6000089
	ds_load_b128 v[218:221], v137 offset:17200                 // 0000001F6F40: DBFC4330 DA000089
	s_waitcnt lgkmcnt(10)                                      // 0000001F6F48: BF89FCA7
	v_fma_mixlo_f16 v67, v224, s39, 0                          // 0000001F6F4C: CC210043 02004FE0
	v_fma_mixhi_f16 v67, v225, s39, 0                          // 0000001F6F54: CC220043 02004FE1
	ds_load_b128 v[222:225], v137 offset:25616                 // 0000001F6F5C: DBFC6410 DE000089
	s_waitcnt lgkmcnt(9)                                       // 0000001F6F64: BF89FC97
	v_fma_mixhi_f16 v71, v74, s39, 0                           // 0000001F6F68: CC220047 02004F4A
	v_fma_mixlo_f16 v72, v75, s39, 0                           // 0000001F6F70: CC210048 02004F4B
	v_fma_mixhi_f16 v72, v76, s39, 0                           // 0000001F6F78: CC220048 02004F4C
	v_fma_mixlo_f16 v68, v226, s39, 0                          // 0000001F6F80: CC210044 02004FE2
	s_waitcnt lgkmcnt(8)                                       // 0000001F6F88: BF89FC87
	v_fma_mixlo_f16 v74, v79, s39, 0                           // 0000001F6F8C: CC21004A 02004F4F
	v_fma_mixhi_f16 v74, v80, s39, 0                           // 0000001F6F94: CC22004A 02004F50
	s_waitcnt lgkmcnt(7)                                       // 0000001F6F9C: BF89FC77
	v_fma_mixlo_f16 v75, v81, s39, 0                           // 0000001F6FA0: CC21004B 02004F51
	v_fma_mixhi_f16 v75, v82, s39, 0                           // 0000001F6FA8: CC22004B 02004F52
	v_fma_mixlo_f16 v76, v83, s39, 0                           // 0000001F6FB0: CC21004C 02004F53
	v_fma_mixhi_f16 v76, v84, s39, 0                           // 0000001F6FB8: CC22004C 02004F54
	v_fma_mixhi_f16 v68, v227, s39, 0                          // 0000001F6FC0: CC220044 02004FE3
	s_waitcnt lgkmcnt(5)                                       // 0000001F6FC8: BF89FC57
	v_fma_mixlo_f16 v79, v89, s39, 0                           // 0000001F6FCC: CC21004F 02004F59
	v_fma_mixhi_f16 v79, v90, s39, 0                           // 0000001F6FD4: CC22004F 02004F5A
	v_fma_mixlo_f16 v80, v91, s39, 0                           // 0000001F6FDC: CC210050 02004F5B
	v_fma_mixhi_f16 v80, v92, s39, 0                           // 0000001F6FE4: CC220050 02004F5C
	ds_load_b128 v[89:92], v137 offset:25600                   // 0000001F6FEC: DBFC6400 59000089
	s_waitcnt lgkmcnt(5)                                       // 0000001F6FF4: BF89FC57
	v_fma_mixlo_f16 v81, v93, s39, 0                           // 0000001F6FF8: CC210051 02004F5D
	v_fma_mixhi_f16 v81, v94, s39, 0                           // 0000001F7000: CC220051 02004F5E
	v_fma_mixlo_f16 v82, v95, s39, 0                           // 0000001F7008: CC210052 02004F5F
	v_fma_mixhi_f16 v82, v96, s39, 0                           // 0000001F7010: CC220052 02004F60
	s_waitcnt lgkmcnt(4)                                       // 0000001F7018: BF89FC47
	v_fma_mixlo_f16 v83, v118, s39, 0                          // 0000001F701C: CC210053 02004F76
	v_fma_mixhi_f16 v83, v119, s39, 0                          // 0000001F7024: CC220053 02004F77
	v_fma_mixlo_f16 v84, v120, s39, 0                          // 0000001F702C: CC210054 02004F78
	ds_load_b128 v[93:96], v137 offset:25632                   // 0000001F7034: DBFC6420 5D000089
	v_fma_mixhi_f16 v84, v121, s39, 0                          // 0000001F703C: CC220054 02004F79
	ds_load_b128 v[118:121], v137 offset:25648                 // 0000001F7044: DBFC6430 76000089
	v_fma_mixlo_f16 v69, v228, s39, 0                          // 0000001F704C: CC210045 02004FE4
	v_fma_mixhi_f16 v69, v229, s39, 0                          // 0000001F7054: CC220045 02004FE5
	v_fma_mixlo_f16 v70, v230, s39, 0                          // 0000001F705C: CC210046 02004FE6
	v_fma_mixhi_f16 v70, v231, s39, 0                          // 0000001F7064: CC220046 02004FE7
	v_fma_mixlo_f16 v71, v73, s39, 0                           // 0000001F706C: CC210047 02004F49
	v_fma_mixlo_f16 v73, v77, s39, 0                           // 0000001F7074: CC210049 02004F4D
	v_fma_mixhi_f16 v73, v78, s39, 0                           // 0000001F707C: CC220049 02004F4E
	v_fma_mixlo_f16 v77, v85, s39, 0                           // 0000001F7084: CC21004D 02004F55
	v_fma_mixhi_f16 v77, v86, s39, 0                           // 0000001F708C: CC22004D 02004F56
	v_fma_mixlo_f16 v78, v87, s39, 0                           // 0000001F7094: CC21004E 02004F57
	v_fma_mixhi_f16 v78, v88, s39, 0                           // 0000001F709C: CC22004E 02004F58
	s_waitcnt lgkmcnt(5)                                       // 0000001F70A4: BF89FC57
	v_fma_mixlo_f16 v85, v214, s39, 0                          // 0000001F70A8: CC210055 02004FD6
	v_fma_mixhi_f16 v85, v215, s39, 0                          // 0000001F70B0: CC220055 02004FD7
	v_fma_mixlo_f16 v86, v216, s39, 0                          // 0000001F70B8: CC210056 02004FD8
	v_fma_mixhi_f16 v86, v217, s39, 0                          // 0000001F70C0: CC220056 02004FD9
	s_waitcnt lgkmcnt(4)                                       // 0000001F70C8: BF89FC47
	v_fma_mixlo_f16 v87, v218, s39, 0                          // 0000001F70CC: CC210057 02004FDA
	v_fma_mixhi_f16 v87, v219, s39, 0                          // 0000001F70D4: CC220057 02004FDB
	v_fma_mixlo_f16 v88, v220, s39, 0                          // 0000001F70DC: CC210058 02004FDC
	v_fma_mixhi_f16 v88, v221, s39, 0                          // 0000001F70E4: CC220058 02004FDD
	s_waitcnt lgkmcnt(2)                                       // 0000001F70EC: BF89FC27
	v_fma_mixlo_f16 v89, v89, s39, 0                           // 0000001F70F0: CC210059 02004F59
	v_fma_mixhi_f16 v89, v90, s39, 0                           // 0000001F70F8: CC220059 02004F5A
	v_fma_mixlo_f16 v90, v91, s39, 0                           // 0000001F7100: CC21005A 02004F5B
	v_fma_mixhi_f16 v90, v92, s39, 0                           // 0000001F7108: CC22005A 02004F5C
	v_fma_mixlo_f16 v91, v222, s39, 0                          // 0000001F7110: CC21005B 02004FDE
	v_fma_mixhi_f16 v91, v223, s39, 0                          // 0000001F7118: CC22005B 02004FDF
	v_fma_mixlo_f16 v92, v224, s39, 0                          // 0000001F7120: CC21005C 02004FE0
	v_fma_mixhi_f16 v92, v225, s39, 0                          // 0000001F7128: CC22005C 02004FE1
	s_waitcnt lgkmcnt(1)                                       // 0000001F7130: BF89FC17
	v_fma_mixlo_f16 v93, v93, s39, 0                           // 0000001F7134: CC21005D 02004F5D
	v_fma_mixhi_f16 v93, v94, s39, 0                           // 0000001F713C: CC22005D 02004F5E
	v_fma_mixlo_f16 v94, v95, s39, 0                           // 0000001F7144: CC21005E 02004F5F
	v_fma_mixhi_f16 v94, v96, s39, 0                           // 0000001F714C: CC22005E 02004F60
	s_waitcnt lgkmcnt(0)                                       // 0000001F7154: BF89FC07
	v_fma_mixlo_f16 v95, v118, s39, 0                          // 0000001F7158: CC21005F 02004F76
	v_fma_mixhi_f16 v95, v119, s39, 0                          // 0000001F7160: CC22005F 02004F77
	v_fma_mixlo_f16 v96, v120, s39, 0                          // 0000001F7168: CC210060 02004F78
	v_fma_mixhi_f16 v96, v121, s39, 0                          // 0000001F7170: CC220060 02004F79
	ds_load_b128 v[214:217], v137 offset:320                   // 0000001F7178: DBFC0140 D6000089
	ds_load_b128 v[218:221], v137 offset:336                   // 0000001F7180: DBFC0150 DA000089
	ds_load_b128 v[222:225], v137 offset:352                   // 0000001F7188: DBFC0160 DE000089
	v_wmma_f32_16x16x16_f16 v[57:64], v[49:56], v[65:72], v[57:64]// 0000001F7190: CC404039 1CE68331
	ds_load_b128 v[65:68], v137 offset:368                     // 0000001F7198: DBFC0170 41000089
	v_wmma_f32_16x16x16_f16 v[41:48], v[49:56], v[73:80], v[41:48]// 0000001F71A0: CC404029 1CA69331
	v_wmma_f32_16x16x16_f16 v[33:40], v[49:56], v[81:88], v[33:40]// 0000001F71A8: CC404021 1C86A331
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[89:96], v[17:24]// 0000001F71B0: CC404011 1C46B331
	ds_load_b128 v[69:72], v137 offset:8768                    // 0000001F71B8: DBFC2240 45000089
	ds_load_b128 v[73:76], v137 offset:8784                    // 0000001F71C0: DBFC2250 49000089
	ds_load_b128 v[77:80], v137 offset:8800                    // 0000001F71C8: DBFC2260 4D000089
	ds_load_b128 v[81:84], v137 offset:8816                    // 0000001F71D0: DBFC2270 51000089
	ds_load_b128 v[85:88], v137 offset:17216                   // 0000001F71D8: DBFC4340 55000089
	ds_load_b128 v[89:92], v137 offset:17232                   // 0000001F71E0: DBFC4350 59000089
	ds_load_b128 v[93:96], v137 offset:17248                   // 0000001F71E8: DBFC4360 5D000089
	ds_load_b128 v[118:121], v137 offset:17264                 // 0000001F71F0: DBFC4370 76000089
	s_waitcnt lgkmcnt(11)                                      // 0000001F71F8: BF89FCB7
	v_fma_mixlo_f16 v49, v214, s39, 0                          // 0000001F71FC: CC210031 02004FD6
	v_fma_mixhi_f16 v49, v215, s39, 0                          // 0000001F7204: CC220031 02004FD7
	v_fma_mixlo_f16 v50, v216, s39, 0                          // 0000001F720C: CC210032 02004FD8
	v_fma_mixhi_f16 v50, v217, s39, 0                          // 0000001F7214: CC220032 02004FD9
	s_waitcnt lgkmcnt(8)                                       // 0000001F721C: BF89FC87
	v_fma_mixhi_f16 v55, v66, s39, 0                           // 0000001F7220: CC220037 02004F42
	v_fma_mixlo_f16 v56, v67, s39, 0                           // 0000001F7228: CC210038 02004F43
	v_fma_mixhi_f16 v56, v68, s39, 0                           // 0000001F7230: CC220038 02004F44
	ds_load_b128 v[214:217], v137 offset:25680                 // 0000001F7238: DBFC6450 D6000089
	s_waitcnt lgkmcnt(8)                                       // 0000001F7240: BF89FC87
	v_fma_mixlo_f16 v66, v71, s39, 0                           // 0000001F7244: CC210042 02004F47
	v_fma_mixhi_f16 v66, v72, s39, 0                           // 0000001F724C: CC220042 02004F48
	s_waitcnt lgkmcnt(7)                                       // 0000001F7254: BF89FC77
	v_fma_mixlo_f16 v67, v73, s39, 0                           // 0000001F7258: CC210043 02004F49
	v_fma_mixhi_f16 v67, v74, s39, 0                           // 0000001F7260: CC220043 02004F4A
	v_fma_mixlo_f16 v68, v75, s39, 0                           // 0000001F7268: CC210044 02004F4B
	v_fma_mixhi_f16 v68, v76, s39, 0                           // 0000001F7270: CC220044 02004F4C
	s_waitcnt lgkmcnt(5)                                       // 0000001F7278: BF89FC57
	v_fma_mixlo_f16 v71, v81, s39, 0                           // 0000001F727C: CC210047 02004F51
	v_fma_mixhi_f16 v71, v82, s39, 0                           // 0000001F7284: CC220047 02004F52
	v_fma_mixlo_f16 v72, v83, s39, 0                           // 0000001F728C: CC210048 02004F53
	v_fma_mixhi_f16 v72, v84, s39, 0                           // 0000001F7294: CC220048 02004F54
	ds_load_b128 v[81:84], v137 offset:25664                   // 0000001F729C: DBFC6440 51000089
	s_waitcnt lgkmcnt(5)                                       // 0000001F72A4: BF89FC57
	v_fma_mixlo_f16 v73, v85, s39, 0                           // 0000001F72A8: CC210049 02004F55
	v_fma_mixhi_f16 v73, v86, s39, 0                           // 0000001F72B0: CC220049 02004F56
	v_fma_mixlo_f16 v74, v87, s39, 0                           // 0000001F72B8: CC21004A 02004F57
	v_fma_mixhi_f16 v74, v88, s39, 0                           // 0000001F72C0: CC22004A 02004F58
	s_waitcnt lgkmcnt(4)                                       // 0000001F72C8: BF89FC47
	v_fma_mixlo_f16 v75, v89, s39, 0                           // 0000001F72CC: CC21004B 02004F59
	v_fma_mixhi_f16 v75, v90, s39, 0                           // 0000001F72D4: CC22004B 02004F5A
	v_fma_mixlo_f16 v76, v91, s39, 0                           // 0000001F72DC: CC21004C 02004F5B
	ds_load_b128 v[85:88], v137 offset:25696                   // 0000001F72E4: DBFC6460 55000089
	v_fma_mixhi_f16 v76, v92, s39, 0                           // 0000001F72EC: CC22004C 02004F5C
	ds_load_b128 v[89:92], v137 offset:25712                   // 0000001F72F4: DBFC6470 59000089
	v_fma_mixlo_f16 v51, v218, s39, 0                          // 0000001F72FC: CC210033 02004FDA
	v_fma_mixhi_f16 v51, v219, s39, 0                          // 0000001F7304: CC220033 02004FDB
	v_fma_mixlo_f16 v52, v220, s39, 0                          // 0000001F730C: CC210034 02004FDC
	v_fma_mixhi_f16 v52, v221, s39, 0                          // 0000001F7314: CC220034 02004FDD
	v_fma_mixlo_f16 v53, v222, s39, 0                          // 0000001F731C: CC210035 02004FDE
	v_fma_mixhi_f16 v53, v223, s39, 0                          // 0000001F7324: CC220035 02004FDF
	v_fma_mixlo_f16 v54, v224, s39, 0                          // 0000001F732C: CC210036 02004FE0
	v_fma_mixhi_f16 v54, v225, s39, 0                          // 0000001F7334: CC220036 02004FE1
	v_fma_mixlo_f16 v55, v65, s39, 0                           // 0000001F733C: CC210037 02004F41
	v_fma_mixlo_f16 v65, v69, s39, 0                           // 0000001F7344: CC210041 02004F45
	v_fma_mixhi_f16 v65, v70, s39, 0                           // 0000001F734C: CC220041 02004F46
	v_fma_mixlo_f16 v69, v77, s39, 0                           // 0000001F7354: CC210045 02004F4D
	v_fma_mixhi_f16 v69, v78, s39, 0                           // 0000001F735C: CC220045 02004F4E
	v_fma_mixlo_f16 v70, v79, s39, 0                           // 0000001F7364: CC210046 02004F4F
	v_fma_mixhi_f16 v70, v80, s39, 0                           // 0000001F736C: CC220046 02004F50
	s_waitcnt lgkmcnt(5)                                       // 0000001F7374: BF89FC57
	v_fma_mixlo_f16 v77, v93, s39, 0                           // 0000001F7378: CC21004D 02004F5D
	v_fma_mixhi_f16 v77, v94, s39, 0                           // 0000001F7380: CC22004D 02004F5E
	v_fma_mixlo_f16 v78, v95, s39, 0                           // 0000001F7388: CC21004E 02004F5F
	v_fma_mixhi_f16 v78, v96, s39, 0                           // 0000001F7390: CC22004E 02004F60
	s_waitcnt lgkmcnt(4)                                       // 0000001F7398: BF89FC47
	v_fma_mixlo_f16 v79, v118, s39, 0                          // 0000001F739C: CC21004F 02004F76
	v_fma_mixhi_f16 v79, v119, s39, 0                          // 0000001F73A4: CC22004F 02004F77
	v_fma_mixlo_f16 v80, v120, s39, 0                          // 0000001F73AC: CC210050 02004F78
	v_fma_mixhi_f16 v80, v121, s39, 0                          // 0000001F73B4: CC220050 02004F79
	s_waitcnt lgkmcnt(2)                                       // 0000001F73BC: BF89FC27
	v_fma_mixlo_f16 v81, v81, s39, 0                           // 0000001F73C0: CC210051 02004F51
	v_fma_mixhi_f16 v81, v82, s39, 0                           // 0000001F73C8: CC220051 02004F52
	v_fma_mixlo_f16 v82, v83, s39, 0                           // 0000001F73D0: CC210052 02004F53
	v_fma_mixhi_f16 v82, v84, s39, 0                           // 0000001F73D8: CC220052 02004F54
	v_fma_mixlo_f16 v83, v214, s39, 0                          // 0000001F73E0: CC210053 02004FD6
	v_fma_mixhi_f16 v83, v215, s39, 0                          // 0000001F73E8: CC220053 02004FD7
	v_fma_mixlo_f16 v84, v216, s39, 0                          // 0000001F73F0: CC210054 02004FD8
	v_fma_mixhi_f16 v84, v217, s39, 0                          // 0000001F73F8: CC220054 02004FD9
	s_waitcnt lgkmcnt(1)                                       // 0000001F7400: BF89FC17
	v_fma_mixlo_f16 v85, v85, s39, 0                           // 0000001F7404: CC210055 02004F55
	v_fma_mixhi_f16 v85, v86, s39, 0                           // 0000001F740C: CC220055 02004F56
	v_fma_mixlo_f16 v86, v87, s39, 0                           // 0000001F7414: CC210056 02004F57
	v_fma_mixhi_f16 v86, v88, s39, 0                           // 0000001F741C: CC220056 02004F58
	s_waitcnt lgkmcnt(0)                                       // 0000001F7424: BF89FC07
	v_fma_mixlo_f16 v87, v89, s39, 0                           // 0000001F7428: CC210057 02004F59
	v_fma_mixhi_f16 v87, v90, s39, 0                           // 0000001F7430: CC220057 02004F5A
	v_fma_mixlo_f16 v88, v91, s39, 0                           // 0000001F7438: CC210058 02004F5B
	v_fma_mixhi_f16 v88, v92, s39, 0                           // 0000001F7440: CC220058 02004F5C
	ds_load_b128 v[93:96], v137 offset:384                     // 0000001F7448: DBFC0180 5D000089
	ds_load_b128 v[118:121], v137 offset:400                   // 0000001F7450: DBFC0190 76000089
	ds_load_b128 v[214:217], v137 offset:416                   // 0000001F7458: DBFC01A0 D6000089
	v_wmma_f32_16x16x16_f16 v[57:64], v[25:32], v[49:56], v[57:64]// 0000001F7460: CC404039 1CE66319
	ds_load_b128 v[49:52], v137 offset:432                     // 0000001F7468: DBFC01B0 31000089
	v_wmma_f32_16x16x16_f16 v[41:48], v[25:32], v[65:72], v[41:48]// 0000001F7470: CC404029 1CA68319
	v_wmma_f32_16x16x16_f16 v[33:40], v[25:32], v[73:80], v[33:40]// 0000001F7478: CC404021 1C869319
	v_wmma_f32_16x16x16_f16 v[17:24], v[25:32], v[81:88], v[17:24]// 0000001F7480: CC404011 1C46A319
	ds_load_b128 v[53:56], v137 offset:8832                    // 0000001F7488: DBFC2280 35000089
	ds_load_b128 v[65:68], v137 offset:8848                    // 0000001F7490: DBFC2290 41000089
	ds_load_b128 v[69:72], v137 offset:8864                    // 0000001F7498: DBFC22A0 45000089
	ds_load_b128 v[73:76], v137 offset:8880                    // 0000001F74A0: DBFC22B0 49000089
	ds_load_b128 v[77:80], v137 offset:17280                   // 0000001F74A8: DBFC4380 4D000089
	ds_load_b128 v[81:84], v137 offset:17296                   // 0000001F74B0: DBFC4390 51000089
	ds_load_b128 v[85:88], v137 offset:17312                   // 0000001F74B8: DBFC43A0 55000089
	ds_load_b128 v[89:92], v137 offset:17328                   // 0000001F74C0: DBFC43B0 59000089
	s_waitcnt lgkmcnt(11)                                      // 0000001F74C8: BF89FCB7
	v_fma_mixlo_f16 v25, v93, s39, 0                           // 0000001F74CC: CC210019 02004F5D
	v_fma_mixhi_f16 v25, v94, s39, 0                           // 0000001F74D4: CC220019 02004F5E
	v_fma_mixlo_f16 v26, v95, s39, 0                           // 0000001F74DC: CC21001A 02004F5F
	v_fma_mixhi_f16 v26, v96, s39, 0                           // 0000001F74E4: CC22001A 02004F60
	s_waitcnt lgkmcnt(8)                                       // 0000001F74EC: BF89FC87
	v_fma_mixhi_f16 v31, v50, s39, 0                           // 0000001F74F0: CC22001F 02004F32
	v_fma_mixlo_f16 v32, v51, s39, 0                           // 0000001F74F8: CC210020 02004F33
	v_fma_mixhi_f16 v32, v52, s39, 0                           // 0000001F7500: CC220020 02004F34
	ds_load_b128 v[93:96], v137 offset:25744                   // 0000001F7508: DBFC6490 5D000089
	s_waitcnt lgkmcnt(8)                                       // 0000001F7510: BF89FC87
	v_fma_mixlo_f16 v50, v55, s39, 0                           // 0000001F7514: CC210032 02004F37
	v_fma_mixhi_f16 v50, v56, s39, 0                           // 0000001F751C: CC220032 02004F38
	s_waitcnt lgkmcnt(7)                                       // 0000001F7524: BF89FC77
	v_fma_mixlo_f16 v51, v65, s39, 0                           // 0000001F7528: CC210033 02004F41
	v_fma_mixhi_f16 v51, v66, s39, 0                           // 0000001F7530: CC220033 02004F42
	v_fma_mixlo_f16 v52, v67, s39, 0                           // 0000001F7538: CC210034 02004F43
	v_fma_mixhi_f16 v52, v68, s39, 0                           // 0000001F7540: CC220034 02004F44
	s_waitcnt lgkmcnt(5)                                       // 0000001F7548: BF89FC57
	v_fma_mixlo_f16 v55, v73, s39, 0                           // 0000001F754C: CC210037 02004F49
	v_fma_mixhi_f16 v55, v74, s39, 0                           // 0000001F7554: CC220037 02004F4A
	v_fma_mixlo_f16 v56, v75, s39, 0                           // 0000001F755C: CC210038 02004F4B
	v_fma_mixhi_f16 v56, v76, s39, 0                           // 0000001F7564: CC220038 02004F4C
	ds_load_b128 v[73:76], v137 offset:25728                   // 0000001F756C: DBFC6480 49000089
	s_waitcnt lgkmcnt(5)                                       // 0000001F7574: BF89FC57
	v_fma_mixlo_f16 v65, v77, s39, 0                           // 0000001F7578: CC210041 02004F4D
	v_fma_mixhi_f16 v65, v78, s39, 0                           // 0000001F7580: CC220041 02004F4E
	v_fma_mixlo_f16 v66, v79, s39, 0                           // 0000001F7588: CC210042 02004F4F
	v_fma_mixhi_f16 v66, v80, s39, 0                           // 0000001F7590: CC220042 02004F50
	s_waitcnt lgkmcnt(4)                                       // 0000001F7598: BF89FC47
	v_fma_mixlo_f16 v67, v81, s39, 0                           // 0000001F759C: CC210043 02004F51
	v_fma_mixhi_f16 v67, v82, s39, 0                           // 0000001F75A4: CC220043 02004F52
	v_fma_mixlo_f16 v68, v83, s39, 0                           // 0000001F75AC: CC210044 02004F53
	ds_load_b128 v[77:80], v137 offset:25760                   // 0000001F75B4: DBFC64A0 4D000089
	v_fma_mixhi_f16 v68, v84, s39, 0                           // 0000001F75BC: CC220044 02004F54
	ds_load_b128 v[81:84], v137 offset:25776                   // 0000001F75C4: DBFC64B0 51000089
	v_fma_mixlo_f16 v27, v118, s39, 0                          // 0000001F75CC: CC21001B 02004F76
	v_fma_mixhi_f16 v27, v119, s39, 0                          // 0000001F75D4: CC22001B 02004F77
	v_fma_mixlo_f16 v28, v120, s39, 0                          // 0000001F75DC: CC21001C 02004F78
	v_fma_mixhi_f16 v28, v121, s39, 0                          // 0000001F75E4: CC22001C 02004F79
	v_fma_mixlo_f16 v29, v214, s39, 0                          // 0000001F75EC: CC21001D 02004FD6
	v_fma_mixhi_f16 v29, v215, s39, 0                          // 0000001F75F4: CC22001D 02004FD7
	v_fma_mixlo_f16 v30, v216, s39, 0                          // 0000001F75FC: CC21001E 02004FD8
	v_fma_mixhi_f16 v30, v217, s39, 0                          // 0000001F7604: CC22001E 02004FD9
	v_fma_mixlo_f16 v31, v49, s39, 0                           // 0000001F760C: CC21001F 02004F31
	v_fma_mixlo_f16 v49, v53, s39, 0                           // 0000001F7614: CC210031 02004F35
	v_fma_mixhi_f16 v49, v54, s39, 0                           // 0000001F761C: CC220031 02004F36
	v_fma_mixlo_f16 v53, v69, s39, 0                           // 0000001F7624: CC210035 02004F45
	v_fma_mixhi_f16 v53, v70, s39, 0                           // 0000001F762C: CC220035 02004F46
	v_fma_mixlo_f16 v54, v71, s39, 0                           // 0000001F7634: CC210036 02004F47
	v_fma_mixhi_f16 v54, v72, s39, 0                           // 0000001F763C: CC220036 02004F48
	s_waitcnt lgkmcnt(5)                                       // 0000001F7644: BF89FC57
	v_fma_mixlo_f16 v69, v85, s39, 0                           // 0000001F7648: CC210045 02004F55
	v_fma_mixhi_f16 v69, v86, s39, 0                           // 0000001F7650: CC220045 02004F56
	v_fma_mixlo_f16 v70, v87, s39, 0                           // 0000001F7658: CC210046 02004F57
	v_fma_mixhi_f16 v70, v88, s39, 0                           // 0000001F7660: CC220046 02004F58
	s_waitcnt lgkmcnt(4)                                       // 0000001F7668: BF89FC47
	v_fma_mixlo_f16 v71, v89, s39, 0                           // 0000001F766C: CC210047 02004F59
	v_fma_mixhi_f16 v71, v90, s39, 0                           // 0000001F7674: CC220047 02004F5A
	v_fma_mixlo_f16 v72, v91, s39, 0                           // 0000001F767C: CC210048 02004F5B
	v_fma_mixhi_f16 v72, v92, s39, 0                           // 0000001F7684: CC220048 02004F5C
	s_waitcnt lgkmcnt(2)                                       // 0000001F768C: BF89FC27
	v_fma_mixlo_f16 v73, v73, s39, 0                           // 0000001F7690: CC210049 02004F49
	v_fma_mixhi_f16 v73, v74, s39, 0                           // 0000001F7698: CC220049 02004F4A
	v_fma_mixlo_f16 v74, v75, s39, 0                           // 0000001F76A0: CC21004A 02004F4B
	v_fma_mixhi_f16 v74, v76, s39, 0                           // 0000001F76A8: CC22004A 02004F4C
	v_fma_mixlo_f16 v75, v93, s39, 0                           // 0000001F76B0: CC21004B 02004F5D
	v_fma_mixhi_f16 v75, v94, s39, 0                           // 0000001F76B8: CC22004B 02004F5E
	v_fma_mixlo_f16 v76, v95, s39, 0                           // 0000001F76C0: CC21004C 02004F5F
	v_fma_mixhi_f16 v76, v96, s39, 0                           // 0000001F76C8: CC22004C 02004F60
	s_waitcnt lgkmcnt(1)                                       // 0000001F76D0: BF89FC17
	v_fma_mixlo_f16 v77, v77, s39, 0                           // 0000001F76D4: CC21004D 02004F4D
	v_fma_mixhi_f16 v77, v78, s39, 0                           // 0000001F76DC: CC22004D 02004F4E
	v_fma_mixlo_f16 v78, v79, s39, 0                           // 0000001F76E4: CC21004E 02004F4F
	v_fma_mixhi_f16 v78, v80, s39, 0                           // 0000001F76EC: CC22004E 02004F50
	s_waitcnt lgkmcnt(0)                                       // 0000001F76F4: BF89FC07
	v_fma_mixlo_f16 v79, v81, s39, 0                           // 0000001F76F8: CC21004F 02004F51
	v_fma_mixhi_f16 v79, v82, s39, 0                           // 0000001F7700: CC22004F 02004F52
	v_fma_mixlo_f16 v80, v83, s39, 0                           // 0000001F7708: CC210050 02004F53
	v_fma_mixhi_f16 v80, v84, s39, 0                           // 0000001F7710: CC220050 02004F54
	ds_load_b128 v[85:88], v137 offset:448                     // 0000001F7718: DBFC01C0 55000089
	ds_load_b128 v[89:92], v137 offset:464                     // 0000001F7720: DBFC01D0 59000089
	ds_load_b128 v[93:96], v137 offset:480                     // 0000001F7728: DBFC01E0 5D000089
	v_wmma_f32_16x16x16_f16 v[57:64], v[9:16], v[25:32], v[57:64]// 0000001F7730: CC404039 1CE63309
	ds_load_b128 v[25:28], v137 offset:496                     // 0000001F7738: DBFC01F0 19000089
	v_wmma_f32_16x16x16_f16 v[41:48], v[9:16], v[49:56], v[41:48]// 0000001F7740: CC404029 1CA66309
	v_wmma_f32_16x16x16_f16 v[33:40], v[9:16], v[65:72], v[33:40]// 0000001F7748: CC404021 1C868309
	v_wmma_f32_16x16x16_f16 v[17:24], v[9:16], v[73:80], v[17:24]// 0000001F7750: CC404011 1C469309
	ds_load_b128 v[29:32], v137 offset:8896                    // 0000001F7758: DBFC22C0 1D000089
	ds_load_b128 v[49:52], v137 offset:8912                    // 0000001F7760: DBFC22D0 31000089
	ds_load_b128 v[53:56], v137 offset:8928                    // 0000001F7768: DBFC22E0 35000089
	ds_load_b128 v[65:68], v137 offset:8944                    // 0000001F7770: DBFC22F0 41000089
	ds_load_b128 v[69:72], v137 offset:17344                   // 0000001F7778: DBFC43C0 45000089
	ds_load_b128 v[73:76], v137 offset:17360                   // 0000001F7780: DBFC43D0 49000089
	ds_load_b128 v[77:80], v137 offset:17376                   // 0000001F7788: DBFC43E0 4D000089
	ds_load_b128 v[81:84], v137 offset:17392                   // 0000001F7790: DBFC43F0 51000089
	v_add_nc_u32_e32 v214, s1, v141                            // 0000001F7798: 4BAD1A01
	s_waitcnt lgkmcnt(11)                                      // 0000001F779C: BF89FCB7
	v_fma_mixlo_f16 v9, v85, s39, 0                            // 0000001F77A0: CC210009 02004F55
	v_fma_mixhi_f16 v9, v86, s39, 0                            // 0000001F77A8: CC220009 02004F56
	v_fma_mixlo_f16 v10, v87, s39, 0                           // 0000001F77B0: CC21000A 02004F57
	v_fma_mixhi_f16 v10, v88, s39, 0                           // 0000001F77B8: CC22000A 02004F58
	s_waitcnt lgkmcnt(8)                                       // 0000001F77C0: BF89FC87
	v_fma_mixhi_f16 v15, v26, s39, 0                           // 0000001F77C4: CC22000F 02004F1A
	v_fma_mixlo_f16 v16, v27, s39, 0                           // 0000001F77CC: CC210010 02004F1B
	v_fma_mixhi_f16 v16, v28, s39, 0                           // 0000001F77D4: CC220010 02004F1C
	ds_load_b128 v[85:88], v137 offset:25808                   // 0000001F77DC: DBFC64D0 55000089
	s_waitcnt lgkmcnt(8)                                       // 0000001F77E4: BF89FC87
	v_fma_mixlo_f16 v26, v31, s39, 0                           // 0000001F77E8: CC21001A 02004F1F
	v_fma_mixhi_f16 v26, v32, s39, 0                           // 0000001F77F0: CC22001A 02004F20
	s_waitcnt lgkmcnt(7)                                       // 0000001F77F8: BF89FC77
	v_fma_mixlo_f16 v27, v49, s39, 0                           // 0000001F77FC: CC21001B 02004F31
	v_fma_mixhi_f16 v27, v50, s39, 0                           // 0000001F7804: CC22001B 02004F32
	v_fma_mixlo_f16 v28, v51, s39, 0                           // 0000001F780C: CC21001C 02004F33
	v_fma_mixhi_f16 v28, v52, s39, 0                           // 0000001F7814: CC22001C 02004F34
	s_waitcnt lgkmcnt(5)                                       // 0000001F781C: BF89FC57
	v_fma_mixlo_f16 v31, v65, s39, 0                           // 0000001F7820: CC21001F 02004F41
	v_fma_mixhi_f16 v31, v66, s39, 0                           // 0000001F7828: CC22001F 02004F42
	v_fma_mixlo_f16 v32, v67, s39, 0                           // 0000001F7830: CC210020 02004F43
	v_fma_mixhi_f16 v32, v68, s39, 0                           // 0000001F7838: CC220020 02004F44
	ds_load_b128 v[65:68], v137 offset:25792                   // 0000001F7840: DBFC64C0 41000089
	s_waitcnt lgkmcnt(5)                                       // 0000001F7848: BF89FC57
	v_fma_mixlo_f16 v49, v69, s39, 0                           // 0000001F784C: CC210031 02004F45
	v_fma_mixhi_f16 v49, v70, s39, 0                           // 0000001F7854: CC220031 02004F46
	v_fma_mixlo_f16 v50, v71, s39, 0                           // 0000001F785C: CC210032 02004F47
	v_fma_mixhi_f16 v50, v72, s39, 0                           // 0000001F7864: CC220032 02004F48
	s_waitcnt lgkmcnt(4)                                       // 0000001F786C: BF89FC47
	v_fma_mixlo_f16 v51, v73, s39, 0                           // 0000001F7870: CC210033 02004F49
	v_fma_mixhi_f16 v51, v74, s39, 0                           // 0000001F7878: CC220033 02004F4A
	ds_load_b128 v[69:72], v137 offset:25824                   // 0000001F7880: DBFC64E0 45000089
	v_fma_mixlo_f16 v52, v75, s39, 0                           // 0000001F7888: CC210034 02004F4B
	v_fma_mixhi_f16 v52, v76, s39, 0                           // 0000001F7890: CC220034 02004F4C
	ds_load_b128 v[73:76], v137 offset:25840                   // 0000001F7898: DBFC64F0 49000089
	v_fma_mixlo_f16 v11, v89, s39, 0                           // 0000001F78A0: CC21000B 02004F59
	v_fma_mixhi_f16 v11, v90, s39, 0                           // 0000001F78A8: CC22000B 02004F5A
	v_fma_mixlo_f16 v12, v91, s39, 0                           // 0000001F78B0: CC21000C 02004F5B
	v_fma_mixhi_f16 v12, v92, s39, 0                           // 0000001F78B8: CC22000C 02004F5C
	v_fma_mixlo_f16 v13, v93, s39, 0                           // 0000001F78C0: CC21000D 02004F5D
	v_fma_mixhi_f16 v13, v94, s39, 0                           // 0000001F78C8: CC22000D 02004F5E
	v_fma_mixlo_f16 v14, v95, s39, 0                           // 0000001F78D0: CC21000E 02004F5F
	v_fma_mixhi_f16 v14, v96, s39, 0                           // 0000001F78D8: CC22000E 02004F60
	v_fma_mixlo_f16 v15, v25, s39, 0                           // 0000001F78E0: CC21000F 02004F19
	v_fma_mixlo_f16 v25, v29, s39, 0                           // 0000001F78E8: CC210019 02004F1D
	v_fma_mixhi_f16 v25, v30, s39, 0                           // 0000001F78F0: CC220019 02004F1E
	v_fma_mixlo_f16 v29, v53, s39, 0                           // 0000001F78F8: CC21001D 02004F35
	v_fma_mixhi_f16 v29, v54, s39, 0                           // 0000001F7900: CC22001D 02004F36
	v_fma_mixlo_f16 v30, v55, s39, 0                           // 0000001F7908: CC21001E 02004F37
	v_fma_mixhi_f16 v30, v56, s39, 0                           // 0000001F7910: CC22001E 02004F38
	s_waitcnt lgkmcnt(5)                                       // 0000001F7918: BF89FC57
	v_fma_mixlo_f16 v53, v77, s39, 0                           // 0000001F791C: CC210035 02004F4D
	v_fma_mixhi_f16 v53, v78, s39, 0                           // 0000001F7924: CC220035 02004F4E
	v_fma_mixlo_f16 v54, v79, s39, 0                           // 0000001F792C: CC210036 02004F4F
	v_fma_mixhi_f16 v54, v80, s39, 0                           // 0000001F7934: CC220036 02004F50
	s_waitcnt lgkmcnt(4)                                       // 0000001F793C: BF89FC47
	v_fma_mixlo_f16 v55, v81, s39, 0                           // 0000001F7940: CC210037 02004F51
	v_fma_mixhi_f16 v55, v82, s39, 0                           // 0000001F7948: CC220037 02004F52
	v_fma_mixlo_f16 v56, v83, s39, 0                           // 0000001F7950: CC210038 02004F53
	v_fma_mixhi_f16 v56, v84, s39, 0                           // 0000001F7958: CC220038 02004F54
	s_waitcnt lgkmcnt(2)                                       // 0000001F7960: BF89FC27
	v_fma_mixlo_f16 v65, v65, s39, 0                           // 0000001F7964: CC210041 02004F41
	v_fma_mixhi_f16 v65, v66, s39, 0                           // 0000001F796C: CC220041 02004F42
	v_fma_mixlo_f16 v66, v67, s39, 0                           // 0000001F7974: CC210042 02004F43
	v_fma_mixhi_f16 v66, v68, s39, 0                           // 0000001F797C: CC220042 02004F44
	v_fma_mixlo_f16 v67, v85, s39, 0                           // 0000001F7984: CC210043 02004F55
	v_fma_mixhi_f16 v67, v86, s39, 0                           // 0000001F798C: CC220043 02004F56
	v_fma_mixlo_f16 v68, v87, s39, 0                           // 0000001F7994: CC210044 02004F57
	v_fma_mixhi_f16 v68, v88, s39, 0                           // 0000001F799C: CC220044 02004F58
	s_waitcnt lgkmcnt(1)                                       // 0000001F79A4: BF89FC17
	v_fma_mixlo_f16 v69, v69, s39, 0                           // 0000001F79A8: CC210045 02004F45
	v_fma_mixhi_f16 v69, v70, s39, 0                           // 0000001F79B0: CC220045 02004F46
	v_fma_mixlo_f16 v70, v71, s39, 0                           // 0000001F79B8: CC210046 02004F47
	v_fma_mixhi_f16 v70, v72, s39, 0                           // 0000001F79C0: CC220046 02004F48
	s_waitcnt lgkmcnt(0)                                       // 0000001F79C8: BF89FC07
	v_fma_mixlo_f16 v71, v73, s39, 0                           // 0000001F79CC: CC210047 02004F49
	v_fma_mixhi_f16 v71, v74, s39, 0                           // 0000001F79D4: CC220047 02004F4A
	v_fma_mixlo_f16 v72, v75, s39, 0                           // 0000001F79DC: CC210048 02004F4B
	v_fma_mixhi_f16 v72, v76, s39, 0                           // 0000001F79E4: CC220048 02004F4C
	v_wmma_f32_16x16x16_f16 v[57:64], v[1:8], v[9:16], v[57:64]// 0000001F79EC: CC404039 1CE61301
	v_wmma_f32_16x16x16_f16 v[41:48], v[1:8], v[25:32], v[41:48]// 0000001F79F4: CC404029 1CA63301
	v_wmma_f32_16x16x16_f16 v[33:40], v[1:8], v[49:56], v[33:40]// 0000001F79FC: CC404021 1C866301
	.long 0xd4440001                                           // 0000001F7A04: D4440001
	v_cndmask_b32_e32 v1, s50, v214, vcc_lo                    // 0000001F7A08: 0203AC32
	v_wmma_f32_16x16x16_f16 v[17:24], v[1:8], v[65:72], v[17:24]// 0000001F7A0C: CC404011 1C468301
	.long 0x7e023971                                           // 0000001F7A14: 7E023971
	s_and_saveexec_b32 s8, s1                                  // 0000001F7A18: BE882001
	s_cbranch_execz 17                                         // 0000001F7A1C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3364>
	v_mad_u64_u32 v[1:2], null, v214, 48, s[2:3]               // 0000001F7A20: D6FE7C01 000961D6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7A28: BF870091
	.long 0xd73c0001                                           // 0000001F7A2C: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F7A30: 02020289
	.long 0xd7000701                                           // 0000001F7A34: D7000701
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F7A38: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7A3C: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s7                 // 0000001F7A40: D5207C02 001E05B6
	global_load_b32 v1, v[1:2], off                            // 0000001F7A48: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F7A50: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v57                         // 0000001F7A54: 560272FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001F7A5C: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001F7A64: 8C7E087E
	v_add_nc_u32_e32 v108, 2, v214                             // 0000001F7A68: 4AD9AC82
	ds_store_b16 v183, v1                                      // 0000001F7A6C: D87C0000 000001B7
	.long 0xd4440007                                           // 0000001F7A74: D4440007
	v_cndmask_b32_e32 v1, s50, v108, vcc_lo                    // 0000001F7A78: 0202D832
	s_and_saveexec_b32 s9, s7                                  // 0000001F7A7C: BE892007
	s_cbranch_execz 17                                         // 0000001F7A80: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x33c8>
	v_mad_u64_u32 v[1:2], null, v108, 48, s[2:3]               // 0000001F7A84: D6FE7C01 0009616C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7A8C: BF870091
	.long 0xd73c0001                                           // 0000001F7A90: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F7A94: 02020289
	.long 0xd7000801                                           // 0000001F7A98: D7000801
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F7A9C: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7AA0: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s8                 // 0000001F7AA4: D5207C02 002205B6
	global_load_b32 v1, v[1:2], off                            // 0000001F7AAC: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F7AB4: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v58                         // 0000001F7AB8: 560274FF BB800000
	v_fma_mixlo_f16 v113, v1, s39, 0                           // 0000001F7AC0: CC210071 02004F01
	s_or_b32 exec_lo, exec_lo, s9                              // 0000001F7AC8: 8C7E097E
	v_add_nc_u32_e32 v109, 4, v214                             // 0000001F7ACC: 4ADBAC84
	.long 0x7e023880                                           // 0000001F7AD0: 7E023880
	ds_store_b16 v183, v113 offset:4                           // 0000001F7AD4: D87C0004 000071B7
	.long 0xd4440008                                           // 0000001F7ADC: D4440008
	v_cndmask_b32_e32 v1, s50, v109, vcc_lo                    // 0000001F7AE0: 0202DA32
	.long 0x7f023901                                           // 0000001F7AE4: 7F023901
	s_and_saveexec_b32 s10, s8                                 // 0000001F7AE8: BE8A2008
	s_cbranch_execz 17                                         // 0000001F7AEC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3434>
	v_mad_u64_u32 v[2:3], null, v109, 48, s[2:3]               // 0000001F7AF0: D6FE7C02 0009616D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7AF8: BF870091
	.long 0xd73c0002                                           // 0000001F7AFC: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F7B00: 02020489
	.long 0xd7000902                                           // 0000001F7B04: D7000902
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F7B08: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7B0C: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s9                 // 0000001F7B10: D5207C03 002607B6
	global_load_b32 v2, v[2:3], off                            // 0000001F7B18: DC520000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F7B20: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v59                         // 0000001F7B24: 560476FF BB800000
	v_fma_mixhi_f16 v1, v2, s39, 0                             // 0000001F7B2C: CC220001 02004F02
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001F7B34: 8C7E0A7E
	v_add_nc_u32_e32 v110, 6, v214                             // 0000001F7B38: 4ADDAC86
	ds_store_b16_d16_hi v183, v1 offset:8                      // 0000001F7B3C: DA840008 000001B7
	.long 0xd4440009                                           // 0000001F7B44: D4440009
	v_cndmask_b32_e32 v1, s50, v110, vcc_lo                    // 0000001F7B48: 0202DC32
	s_and_saveexec_b32 s11, s9                                 // 0000001F7B4C: BE8B2009
	s_cbranch_execz 17                                         // 0000001F7B50: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3498>
	v_mad_u64_u32 v[1:2], null, v110, 48, s[2:3]               // 0000001F7B54: D6FE7C01 0009616E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7B5C: BF870091
	.long 0xd73c0001                                           // 0000001F7B60: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F7B64: 02020289
	.long 0xd7000a01                                           // 0000001F7B68: D7000A01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F7B6C: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7B70: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s10                // 0000001F7B74: D5207C02 002A05B6
	global_load_b32 v1, v[1:2], off                            // 0000001F7B7C: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F7B84: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v60                         // 0000001F7B88: 560278FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001F7B90: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001F7B98: 8C7E0B7E
	v_add_nc_u32_e32 v111, 8, v214                             // 0000001F7B9C: 4ADFAC88
	.long 0x7f023880                                           // 0000001F7BA0: 7F023880
	ds_store_b16 v183, v1 offset:12                            // 0000001F7BA4: D87C000C 000001B7
	.long 0xd444000a                                           // 0000001F7BAC: D444000A
	v_cndmask_b32_e32 v1, s50, v111, vcc_lo                    // 0000001F7BB0: 0202DE32
	.long 0x7e043981                                           // 0000001F7BB4: 7E043981
	s_and_saveexec_b32 s12, s10                                // 0000001F7BB8: BE8C200A
	s_cbranch_execz 17                                         // 0000001F7BBC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3504>
	v_mad_u64_u32 v[2:3], null, v111, 48, s[2:3]               // 0000001F7BC0: D6FE7C02 0009616F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7BC8: BF870091
	.long 0xd73c0002                                           // 0000001F7BCC: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F7BD0: 02020489
	.long 0xd7000b02                                           // 0000001F7BD4: D7000B02
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F7BD8: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7BDC: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s11                // 0000001F7BE0: D5207C03 002E07B6
	global_load_b32 v2, v[2:3], off                            // 0000001F7BE8: DC520000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F7BF0: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v61                         // 0000001F7BF4: 56047AFF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001F7BFC: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001F7C04: 8C7E0C7E
	v_add_nc_u32_e32 v112, 10, v214                            // 0000001F7C08: 4AE1AC8A
	ds_store_b16 v183, v2 offset:16                            // 0000001F7C0C: D87C0010 000002B7
	.long 0xd444000b                                           // 0000001F7C14: D444000B
	v_cndmask_b32_e32 v1, s50, v112, vcc_lo                    // 0000001F7C18: 0202E032
	s_and_saveexec_b32 s13, s11                                // 0000001F7C1C: BE8D200B
	s_cbranch_execz 17                                         // 0000001F7C20: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3568>
	v_mad_u64_u32 v[1:2], null, v112, 48, s[2:3]               // 0000001F7C24: D6FE7C01 00096170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7C2C: BF870091
	.long 0xd73c0001                                           // 0000001F7C30: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F7C34: 02020289
	.long 0xd7000c01                                           // 0000001F7C38: D7000C01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F7C3C: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7C40: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s12                // 0000001F7C44: D5207C02 003205B6
	global_load_b32 v1, v[1:2], off                            // 0000001F7C4C: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F7C54: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v62                         // 0000001F7C58: 56027CFF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000001F7C60: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s13                             // 0000001F7C68: 8C7E0D7E
	v_add_nc_u32_e32 v113, 12, v214                            // 0000001F7C6C: 4AE3AC8C
	.long 0x7e023880                                           // 0000001F7C70: 7E023880
	ds_store_b16_d16_hi v183, v1 offset:20                     // 0000001F7C74: DA840014 000001B7
	.long 0xd444000c                                           // 0000001F7C7C: D444000C
	v_cndmask_b32_e32 v1, s50, v113, vcc_lo                    // 0000001F7C80: 0202E232
	.long 0x7e043901                                           // 0000001F7C84: 7E043901
	s_and_saveexec_b32 s14, s12                                // 0000001F7C88: BE8E200C
	s_cbranch_execz 17                                         // 0000001F7C8C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x35d4>
	v_mad_u64_u32 v[2:3], null, v113, 48, s[2:3]               // 0000001F7C90: D6FE7C02 00096171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7C98: BF870091
	.long 0xd73c0002                                           // 0000001F7C9C: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F7CA0: 02020489
	.long 0xd7000d02                                           // 0000001F7CA4: D7000D02
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F7CA8: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7CAC: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s13                // 0000001F7CB0: D5207C03 003607B6
	global_load_b32 v2, v[2:3], off                            // 0000001F7CB8: DC520000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F7CC0: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v63                         // 0000001F7CC4: 56047EFF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001F7CCC: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001F7CD4: 8C7E0E7E
	v_add_nc_u32_e32 v215, 14, v214                            // 0000001F7CD8: 4BAFAC8E
	ds_store_b16 v183, v2 offset:24                            // 0000001F7CDC: D87C0018 000002B7
	.long 0xd444000d                                           // 0000001F7CE4: D444000D
	v_cndmask_b32_e32 v1, s50, v215, vcc_lo                    // 0000001F7CE8: 0203AE32
	s_and_saveexec_b32 s42, s13                                // 0000001F7CEC: BEAA200D
	s_cbranch_execz 17                                         // 0000001F7CF0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3638>
	v_mad_u64_u32 v[1:2], null, v215, 48, s[2:3]               // 0000001F7CF4: D6FE7C01 000961D7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7CFC: BF870091
	.long 0xd73c0001                                           // 0000001F7D00: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F7D04: 02020289
	.long 0xd7000e01                                           // 0000001F7D08: D7000E01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F7D0C: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7D10: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s14                // 0000001F7D14: D5207C02 003A05B6
	global_load_b32 v1, v[1:2], off                            // 0000001F7D1C: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F7D24: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v64                         // 0000001F7D28: 560280FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001F7D30: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F7D38: 8C7E2A7E
	.long 0x7f023880                                           // 0000001F7D3C: 7F023880
	ds_store_b16 v183, v1 offset:28                            // 0000001F7D40: D87C001C 000001B7
	.long 0x7e043981                                           // 0000001F7D48: 7E043981
	s_and_saveexec_b32 s42, s1                                 // 0000001F7D4C: BEAA2001
	s_cbranch_execz 17                                         // 0000001F7D50: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3698>
	v_mad_u64_u32 v[2:3], null, v214, 48, s[2:3]               // 0000001F7D54: D6FE7C02 000961D6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7D5C: BF870091
	.long 0xd73c0002                                           // 0000001F7D60: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F7D64: 02020489
	.long 0xd7000e02                                           // 0000001F7D68: D7000E02
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F7D6C: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7D70: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s14                // 0000001F7D74: D5207C03 003A07B6
	global_load_b32 v2, v[2:3], off offset:64                  // 0000001F7D7C: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F7D84: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v41                         // 0000001F7D88: 560452FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001F7D90: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F7D98: 8C7E2A7E
	ds_store_b16 v183, v2 offset:2304                          // 0000001F7D9C: D87C0900 000002B7
	s_and_saveexec_b32 s42, s7                                 // 0000001F7DA4: BEAA2007
	s_cbranch_execz 17                                         // 0000001F7DA8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x36f0>
	v_mad_u64_u32 v[1:2], null, v108, 48, s[2:3]               // 0000001F7DAC: D6FE7C01 0009616C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7DB4: BF870091
	.long 0xd73c0001                                           // 0000001F7DB8: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F7DBC: 02020289
	.long 0xd7000e01                                           // 0000001F7DC0: D7000E01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F7DC4: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7DC8: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s14                // 0000001F7DCC: D5207C02 003A05B6
	global_load_b32 v1, v[1:2], off offset:64                  // 0000001F7DD4: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F7DDC: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v42                         // 0000001F7DE0: 560254FF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000001F7DE8: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F7DF0: 8C7E2A7E
	.long 0x7e023880                                           // 0000001F7DF4: 7E023880
	ds_store_b16_d16_hi v183, v1 offset:2308                   // 0000001F7DF8: DA840904 000001B7
	.long 0x7e043901                                           // 0000001F7E00: 7E043901
	s_and_saveexec_b32 s42, s8                                 // 0000001F7E04: BEAA2008
	s_cbranch_execz 17                                         // 0000001F7E08: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3750>
	v_mad_u64_u32 v[2:3], null, v109, 48, s[2:3]               // 0000001F7E0C: D6FE7C02 0009616D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7E14: BF870091
	.long 0xd73c0002                                           // 0000001F7E18: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F7E1C: 02020489
	.long 0xd7000e02                                           // 0000001F7E20: D7000E02
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F7E24: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7E28: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s14                // 0000001F7E2C: D5207C03 003A07B6
	global_load_b32 v2, v[2:3], off offset:64                  // 0000001F7E34: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F7E3C: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v43                         // 0000001F7E40: 560456FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001F7E48: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F7E50: 8C7E2A7E
	ds_store_b16 v183, v2 offset:2312                          // 0000001F7E54: D87C0908 000002B7
	s_and_saveexec_b32 s42, s9                                 // 0000001F7E5C: BEAA2009
	s_cbranch_execz 17                                         // 0000001F7E60: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x37a8>
	v_mad_u64_u32 v[1:2], null, v110, 48, s[2:3]               // 0000001F7E64: D6FE7C01 0009616E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7E6C: BF870091
	.long 0xd73c0001                                           // 0000001F7E70: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F7E74: 02020289
	.long 0xd7000e01                                           // 0000001F7E78: D7000E01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F7E7C: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7E80: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s14                // 0000001F7E84: D5207C02 003A05B6
	global_load_b32 v1, v[1:2], off offset:64                  // 0000001F7E8C: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F7E94: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v44                         // 0000001F7E98: 560258FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001F7EA0: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F7EA8: 8C7E2A7E
	.long 0x7f023880                                           // 0000001F7EAC: 7F023880
	ds_store_b16 v183, v1 offset:2316                          // 0000001F7EB0: D87C090C 000001B7
	.long 0x7e043981                                           // 0000001F7EB8: 7E043981
	s_and_saveexec_b32 s42, s10                                // 0000001F7EBC: BEAA200A
	s_cbranch_execz 17                                         // 0000001F7EC0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3808>
	v_mad_u64_u32 v[2:3], null, v111, 48, s[2:3]               // 0000001F7EC4: D6FE7C02 0009616F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7ECC: BF870091
	.long 0xd73c0002                                           // 0000001F7ED0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F7ED4: 02020489
	.long 0xd7000e02                                           // 0000001F7ED8: D7000E02
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F7EDC: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7EE0: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s14                // 0000001F7EE4: D5207C03 003A07B6
	global_load_b32 v2, v[2:3], off offset:64                  // 0000001F7EEC: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F7EF4: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v45                         // 0000001F7EF8: 56045AFF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001F7F00: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F7F08: 8C7E2A7E
	ds_store_b16 v183, v2 offset:2320                          // 0000001F7F0C: D87C0910 000002B7
	s_and_saveexec_b32 s42, s11                                // 0000001F7F14: BEAA200B
	s_cbranch_execz 17                                         // 0000001F7F18: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3860>
	v_mad_u64_u32 v[1:2], null, v112, 48, s[2:3]               // 0000001F7F1C: D6FE7C01 00096170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7F24: BF870091
	.long 0xd73c0001                                           // 0000001F7F28: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F7F2C: 02020289
	.long 0xd7000e01                                           // 0000001F7F30: D7000E01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F7F34: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7F38: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s14                // 0000001F7F3C: D5207C02 003A05B6
	global_load_b32 v1, v[1:2], off offset:64                  // 0000001F7F44: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F7F4C: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v46                         // 0000001F7F50: 56025CFF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000001F7F58: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F7F60: 8C7E2A7E
	.long 0x7e023880                                           // 0000001F7F64: 7E023880
	ds_store_b16_d16_hi v183, v1 offset:2324                   // 0000001F7F68: DA840914 000001B7
	.long 0x7e043901                                           // 0000001F7F70: 7E043901
	s_and_saveexec_b32 s42, s12                                // 0000001F7F74: BEAA200C
	s_cbranch_execz 17                                         // 0000001F7F78: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x38c0>
	v_mad_u64_u32 v[2:3], null, v113, 48, s[2:3]               // 0000001F7F7C: D6FE7C02 00096171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7F84: BF870091
	.long 0xd73c0002                                           // 0000001F7F88: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F7F8C: 02020489
	.long 0xd7000e02                                           // 0000001F7F90: D7000E02
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F7F94: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7F98: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s14                // 0000001F7F9C: D5207C03 003A07B6
	global_load_b32 v2, v[2:3], off offset:64                  // 0000001F7FA4: DC520040 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F7FAC: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v47                         // 0000001F7FB0: 56045EFF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001F7FB8: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F7FC0: 8C7E2A7E
	ds_store_b16 v183, v2 offset:2328                          // 0000001F7FC4: D87C0918 000002B7
	s_and_saveexec_b32 s42, s13                                // 0000001F7FCC: BEAA200D
	s_cbranch_execz 17                                         // 0000001F7FD0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3918>
	v_mad_u64_u32 v[1:2], null, v215, 48, s[2:3]               // 0000001F7FD4: D6FE7C01 000961D7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F7FDC: BF870091
	.long 0xd73c0001                                           // 0000001F7FE0: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F7FE4: 02020289
	.long 0xd7000e01                                           // 0000001F7FE8: D7000E01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F7FEC: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F7FF0: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s14                // 0000001F7FF4: D5207C02 003A05B6
	global_load_b32 v1, v[1:2], off offset:64                  // 0000001F7FFC: DC520040 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F8004: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v48                         // 0000001F8008: 560260FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001F8010: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F8018: 8C7E2A7E
	.long 0x7f023880                                           // 0000001F801C: 7F023880
	ds_store_b16 v183, v1 offset:2332                          // 0000001F8020: D87C091C 000001B7
	.long 0x7e043981                                           // 0000001F8028: 7E043981
	s_and_saveexec_b32 s42, s1                                 // 0000001F802C: BEAA2001
	s_cbranch_execz 17                                         // 0000001F8030: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3978>
	v_mad_u64_u32 v[2:3], null, v214, 48, s[2:3]               // 0000001F8034: D6FE7C02 000961D6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F803C: BF870091
	.long 0xd73c0002                                           // 0000001F8040: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F8044: 02020489
	.long 0xd7000e02                                           // 0000001F8048: D7000E02
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F804C: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F8050: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s14                // 0000001F8054: D5207C03 003A07B6
	global_load_b32 v2, v[2:3], off offset:128                 // 0000001F805C: DC520080 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F8064: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v33                         // 0000001F8068: 560442FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001F8070: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F8078: 8C7E2A7E
	ds_store_b16 v183, v2 offset:4608                          // 0000001F807C: D87C1200 000002B7
	s_and_saveexec_b32 s42, s7                                 // 0000001F8084: BEAA2007
	s_cbranch_execz 17                                         // 0000001F8088: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x39d0>
	v_mad_u64_u32 v[1:2], null, v108, 48, s[2:3]               // 0000001F808C: D6FE7C01 0009616C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F8094: BF870091
	.long 0xd73c0001                                           // 0000001F8098: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F809C: 02020289
	.long 0xd7000e01                                           // 0000001F80A0: D7000E01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F80A4: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F80A8: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s14                // 0000001F80AC: D5207C02 003A05B6
	global_load_b32 v1, v[1:2], off offset:128                 // 0000001F80B4: DC520080 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F80BC: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v34                         // 0000001F80C0: 560244FF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000001F80C8: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F80D0: 8C7E2A7E
	.long 0x7e023880                                           // 0000001F80D4: 7E023880
	ds_store_b16_d16_hi v183, v1 offset:4612                   // 0000001F80D8: DA841204 000001B7
	.long 0x7e043901                                           // 0000001F80E0: 7E043901
	s_and_saveexec_b32 s42, s8                                 // 0000001F80E4: BEAA2008
	s_cbranch_execz 17                                         // 0000001F80E8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3a30>
	v_mad_u64_u32 v[2:3], null, v109, 48, s[2:3]               // 0000001F80EC: D6FE7C02 0009616D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F80F4: BF870091
	.long 0xd73c0002                                           // 0000001F80F8: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F80FC: 02020489
	.long 0xd7000e02                                           // 0000001F8100: D7000E02
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F8104: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F8108: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s14                // 0000001F810C: D5207C03 003A07B6
	global_load_b32 v2, v[2:3], off offset:128                 // 0000001F8114: DC520080 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F811C: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v35                         // 0000001F8120: 560446FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001F8128: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F8130: 8C7E2A7E
	ds_store_b16 v183, v2 offset:4616                          // 0000001F8134: D87C1208 000002B7
	s_and_saveexec_b32 s42, s9                                 // 0000001F813C: BEAA2009
	s_cbranch_execz 17                                         // 0000001F8140: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3a88>
	v_mad_u64_u32 v[1:2], null, v110, 48, s[2:3]               // 0000001F8144: D6FE7C01 0009616E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F814C: BF870091
	.long 0xd73c0001                                           // 0000001F8150: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F8154: 02020289
	.long 0xd7000e01                                           // 0000001F8158: D7000E01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F815C: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F8160: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s14                // 0000001F8164: D5207C02 003A05B6
	global_load_b32 v1, v[1:2], off offset:128                 // 0000001F816C: DC520080 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F8174: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v36                         // 0000001F8178: 560248FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001F8180: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F8188: 8C7E2A7E
	.long 0x7f023880                                           // 0000001F818C: 7F023880
	ds_store_b16 v183, v1 offset:4620                          // 0000001F8190: D87C120C 000001B7
	.long 0x7e043981                                           // 0000001F8198: 7E043981
	s_and_saveexec_b32 s42, s10                                // 0000001F819C: BEAA200A
	s_cbranch_execz 17                                         // 0000001F81A0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3ae8>
	v_mad_u64_u32 v[2:3], null, v111, 48, s[2:3]               // 0000001F81A4: D6FE7C02 0009616F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F81AC: BF870091
	.long 0xd73c0002                                           // 0000001F81B0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F81B4: 02020489
	.long 0xd7000e02                                           // 0000001F81B8: D7000E02
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F81BC: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F81C0: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s14                // 0000001F81C4: D5207C03 003A07B6
	global_load_b32 v2, v[2:3], off offset:128                 // 0000001F81CC: DC520080 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F81D4: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v37                         // 0000001F81D8: 56044AFF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001F81E0: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F81E8: 8C7E2A7E
	ds_store_b16 v183, v2 offset:4624                          // 0000001F81EC: D87C1210 000002B7
	s_and_saveexec_b32 s42, s11                                // 0000001F81F4: BEAA200B
	s_cbranch_execz 17                                         // 0000001F81F8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3b40>
	v_mad_u64_u32 v[1:2], null, v112, 48, s[2:3]               // 0000001F81FC: D6FE7C01 00096170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F8204: BF870091
	.long 0xd73c0001                                           // 0000001F8208: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F820C: 02020289
	.long 0xd7000e01                                           // 0000001F8210: D7000E01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F8214: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F8218: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s14                // 0000001F821C: D5207C02 003A05B6
	global_load_b32 v1, v[1:2], off offset:128                 // 0000001F8224: DC520080 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F822C: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v38                         // 0000001F8230: 56024CFF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000001F8238: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F8240: 8C7E2A7E
	.long 0x7e023880                                           // 0000001F8244: 7E023880
	ds_store_b16_d16_hi v183, v1 offset:4628                   // 0000001F8248: DA841214 000001B7
	.long 0x7e043901                                           // 0000001F8250: 7E043901
	s_and_saveexec_b32 s42, s12                                // 0000001F8254: BEAA200C
	s_cbranch_execz 17                                         // 0000001F8258: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3ba0>
	v_mad_u64_u32 v[2:3], null, v113, 48, s[2:3]               // 0000001F825C: D6FE7C02 00096171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F8264: BF870091
	.long 0xd73c0002                                           // 0000001F8268: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F826C: 02020489
	.long 0xd7000e02                                           // 0000001F8270: D7000E02
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F8274: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F8278: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s14                // 0000001F827C: D5207C03 003A07B6
	global_load_b32 v2, v[2:3], off offset:128                 // 0000001F8284: DC520080 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F828C: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v39                         // 0000001F8290: 56044EFF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001F8298: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F82A0: 8C7E2A7E
	ds_store_b16 v183, v2 offset:4632                          // 0000001F82A4: D87C1218 000002B7
	s_and_saveexec_b32 s42, s13                                // 0000001F82AC: BEAA200D
	s_cbranch_execz 17                                         // 0000001F82B0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3bf8>
	v_mad_u64_u32 v[1:2], null, v215, 48, s[2:3]               // 0000001F82B4: D6FE7C01 000961D7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F82BC: BF870091
	.long 0xd73c0001                                           // 0000001F82C0: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F82C4: 02020289
	.long 0xd7000e01                                           // 0000001F82C8: D7000E01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F82CC: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F82D0: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s14                // 0000001F82D4: D5207C02 003A05B6
	global_load_b32 v1, v[1:2], off offset:128                 // 0000001F82DC: DC520080 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F82E4: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v40                         // 0000001F82E8: 560250FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001F82F0: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F82F8: 8C7E2A7E
	.long 0x7f023880                                           // 0000001F82FC: 7F023880
	ds_store_b16 v183, v1 offset:4636                          // 0000001F8300: D87C121C 000001B7
	.long 0x7e043981                                           // 0000001F8308: 7E043981
	s_and_saveexec_b32 s42, s1                                 // 0000001F830C: BEAA2001
	s_cbranch_execz 17                                         // 0000001F8310: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3c58>
	v_mad_u64_u32 v[2:3], null, v214, 48, s[2:3]               // 0000001F8314: D6FE7C02 000961D6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F831C: BF870091
	.long 0xd73c0002                                           // 0000001F8320: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F8324: 02020489
	.long 0xd7000e02                                           // 0000001F8328: D7000E02
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F832C: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F8330: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s14                // 0000001F8334: D5207C03 003A07B6
	global_load_b32 v2, v[2:3], off offset:192                 // 0000001F833C: DC5200C0 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F8344: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v17                         // 0000001F8348: 560422FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001F8350: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F8358: 8C7E2A7E
	ds_store_b16 v183, v2 offset:6912                          // 0000001F835C: D87C1B00 000002B7
	s_and_saveexec_b32 s42, s7                                 // 0000001F8364: BEAA2007
	s_cbranch_execz 17                                         // 0000001F8368: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3cb0>
	v_mad_u64_u32 v[1:2], null, v108, 48, s[2:3]               // 0000001F836C: D6FE7C01 0009616C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F8374: BF870091
	.long 0xd73c0001                                           // 0000001F8378: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F837C: 02020289
	.long 0xd7000e01                                           // 0000001F8380: D7000E01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F8384: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F8388: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s14                // 0000001F838C: D5207C02 003A05B6
	global_load_b32 v1, v[1:2], off offset:192                 // 0000001F8394: DC5200C0 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F839C: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v18                         // 0000001F83A0: 560224FF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000001F83A8: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F83B0: 8C7E2A7E
	.long 0x7e023880                                           // 0000001F83B4: 7E023880
	ds_store_b16_d16_hi v183, v1 offset:6916                   // 0000001F83B8: DA841B04 000001B7
	.long 0x7e043901                                           // 0000001F83C0: 7E043901
	s_and_saveexec_b32 s42, s8                                 // 0000001F83C4: BEAA2008
	s_cbranch_execz 17                                         // 0000001F83C8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3d10>
	v_mad_u64_u32 v[2:3], null, v109, 48, s[2:3]               // 0000001F83CC: D6FE7C02 0009616D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F83D4: BF870091
	.long 0xd73c0002                                           // 0000001F83D8: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F83DC: 02020489
	.long 0xd7000e02                                           // 0000001F83E0: D7000E02
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F83E4: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F83E8: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s14                // 0000001F83EC: D5207C03 003A07B6
	global_load_b32 v2, v[2:3], off offset:192                 // 0000001F83F4: DC5200C0 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F83FC: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v19                         // 0000001F8400: 560426FF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001F8408: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F8410: 8C7E2A7E
	ds_store_b16 v183, v2 offset:6920                          // 0000001F8414: D87C1B08 000002B7
	s_and_saveexec_b32 s42, s9                                 // 0000001F841C: BEAA2009
	s_cbranch_execz 17                                         // 0000001F8420: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3d68>
	v_mad_u64_u32 v[1:2], null, v110, 48, s[2:3]               // 0000001F8424: D6FE7C01 0009616E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F842C: BF870091
	.long 0xd73c0001                                           // 0000001F8430: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F8434: 02020289
	.long 0xd7000e01                                           // 0000001F8438: D7000E01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F843C: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F8440: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s14                // 0000001F8444: D5207C02 003A05B6
	global_load_b32 v1, v[1:2], off offset:192                 // 0000001F844C: DC5200C0 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F8454: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v20                         // 0000001F8458: 560228FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001F8460: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F8468: 8C7E2A7E
	.long 0x7f023880                                           // 0000001F846C: 7F023880
	ds_store_b16 v183, v1 offset:6924                          // 0000001F8470: D87C1B0C 000001B7
	.long 0x7e043981                                           // 0000001F8478: 7E043981
	s_and_saveexec_b32 s42, s10                                // 0000001F847C: BEAA200A
	s_cbranch_execz 17                                         // 0000001F8480: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3dc8>
	v_mad_u64_u32 v[2:3], null, v111, 48, s[2:3]               // 0000001F8484: D6FE7C02 0009616F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F848C: BF870091
	.long 0xd73c0002                                           // 0000001F8490: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F8494: 02020489
	.long 0xd7000e02                                           // 0000001F8498: D7000E02
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F849C: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F84A0: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s14                // 0000001F84A4: D5207C03 003A07B6
	global_load_b32 v2, v[2:3], off offset:192                 // 0000001F84AC: DC5200C0 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F84B4: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v21                         // 0000001F84B8: 56042AFF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001F84C0: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F84C8: 8C7E2A7E
	ds_store_b16 v183, v2 offset:6928                          // 0000001F84CC: D87C1B10 000002B7
	s_and_saveexec_b32 s42, s11                                // 0000001F84D4: BEAA200B
	s_cbranch_execz 17                                         // 0000001F84D8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3e20>
	v_mad_u64_u32 v[1:2], null, v112, 48, s[2:3]               // 0000001F84DC: D6FE7C01 00096170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F84E4: BF870091
	.long 0xd73c0001                                           // 0000001F84E8: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F84EC: 02020289
	.long 0xd7000e01                                           // 0000001F84F0: D7000E01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F84F4: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F84F8: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s14                // 0000001F84FC: D5207C02 003A05B6
	global_load_b32 v1, v[1:2], off offset:192                 // 0000001F8504: DC5200C0 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F850C: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v22                         // 0000001F8510: 56022CFF BB800000
	v_fma_mixhi_f16 v1, v1, s39, 0                             // 0000001F8518: CC220001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F8520: 8C7E2A7E
	.long 0x7e023880                                           // 0000001F8524: 7E023880
	ds_store_b16_d16_hi v183, v1 offset:6932                   // 0000001F8528: DA841B14 000001B7
	.long 0x7e043901                                           // 0000001F8530: 7E043901
	s_and_saveexec_b32 s42, s12                                // 0000001F8534: BEAA200C
	s_cbranch_execz 17                                         // 0000001F8538: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3e80>
	v_mad_u64_u32 v[2:3], null, v113, 48, s[2:3]               // 0000001F853C: D6FE7C02 00096171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F8544: BF870091
	.long 0xd73c0002                                           // 0000001F8548: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000001F854C: 02020489
	.long 0xd7000e02                                           // 0000001F8550: D7000E02
	v_cndmask_b32_e32 v1, v181, v2, vcc_lo                     // 0000001F8554: 020205B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F8558: BF8700C1
	v_add_co_ci_u32_e64 v3, null, v182, v3, s14                // 0000001F855C: D5207C03 003A07B6
	global_load_b32 v2, v[2:3], off offset:192                 // 0000001F8564: DC5200C0 027C0002
	s_waitcnt vmcnt(0)                                         // 0000001F856C: BF8903F7
	v_fmac_f32_e32 v2, 0xbb800000, v23                         // 0000001F8570: 56042EFF BB800000
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001F8578: CC210002 02004F02
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F8580: 8C7E2A7E
	ds_store_b16 v183, v2 offset:6936                          // 0000001F8584: D87C1B18 000002B7
	s_and_saveexec_b32 s42, s13                                // 0000001F858C: BEAA200D
	s_cbranch_execz 17                                         // 0000001F8590: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3ed8>
	v_mad_u64_u32 v[1:2], null, v215, 48, s[2:3]               // 0000001F8594: D6FE7C01 000961D7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001F859C: BF870091
	.long 0xd73c0001                                           // 0000001F85A0: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001F85A4: 02020289
	.long 0xd7000e01                                           // 0000001F85A8: D7000E01
	v_cndmask_b32_e32 v1, v181, v1, vcc_lo                     // 0000001F85AC: 020203B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001F85B0: BF8700C1
	v_add_co_ci_u32_e64 v2, null, v182, v2, s14                // 0000001F85B4: D5207C02 003A05B6
	global_load_b32 v1, v[1:2], off offset:192                 // 0000001F85BC: DC5200C0 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001F85C4: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v24                         // 0000001F85C8: 560230FF BB800000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001F85D0: CC210001 02004F01
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001F85D8: 8C7E2A7E
	.long 0xd7000e02                                           // 0000001F85DC: D7000E02
	v_cndmask_b32_e32 v1, s44, v124, vcc_lo                    // 0000001F85E0: 0202F82C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F85E4: BF870001
	v_add_co_ci_u32_e64 v3, null, s45, v125, s14               // 0000001F85E8: D5207C03 003AFA2D
	ds_store_b16 v183, v1 offset:6940                          // 0000001F85F0: D87C1B1C 000001B7
	s_waitcnt lgkmcnt(0)                                       // 0000001F85F8: BF89FC07
	s_barrier                                                  // 0000001F85FC: BFBD0000
	buffer_gl0_inv                                             // 0000001F8600: E0AC0000 00000000
	s_clause 0xf                                               // 0000001F8608: BF85000F
	global_load_b128 v[97:100], v[2:3], off                    // 0000001F860C: DC5E0000 617C0002
	global_load_b128 v[101:104], v[2:3], off offset:16         // 0000001F8614: DC5E0010 657C0002
	global_load_b128 v[89:92], v[2:3], off offset:32           // 0000001F861C: DC5E0020 597C0002
	global_load_b128 v[93:96], v[2:3], off offset:48           // 0000001F8624: DC5E0030 5D7C0002
	global_load_b128 v[81:84], v[2:3], off offset:64           // 0000001F862C: DC5E0040 517C0002
	global_load_b128 v[85:88], v[2:3], off offset:80           // 0000001F8634: DC5E0050 557C0002
	global_load_b128 v[73:76], v[2:3], off offset:96           // 0000001F863C: DC5E0060 497C0002
	global_load_b128 v[77:80], v[2:3], off offset:112          // 0000001F8644: DC5E0070 4D7C0002
	global_load_b128 v[57:60], v[2:3], off offset:128          // 0000001F864C: DC5E0080 397C0002
	global_load_b128 v[61:64], v[2:3], off offset:144          // 0000001F8654: DC5E0090 3D7C0002
	global_load_b128 v[49:52], v[2:3], off offset:160          // 0000001F865C: DC5E00A0 317C0002
	global_load_b128 v[53:56], v[2:3], off offset:176          // 0000001F8664: DC5E00B0 357C0002
	global_load_b128 v[41:44], v[2:3], off offset:192          // 0000001F866C: DC5E00C0 297C0002
	global_load_b128 v[45:48], v[2:3], off offset:208          // 0000001F8674: DC5E00D0 2D7C0002
	global_load_b128 v[33:36], v[2:3], off offset:224          // 0000001F867C: DC5E00E0 217C0002
	global_load_b128 v[37:40], v[2:3], off offset:240          // 0000001F8684: DC5E00F0 257C0002
	s_and_saveexec_b32 s14, s0                                 // 0000001F868C: BE8E2000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001F8690: BF870009
	s_xor_b32 s0, exec_lo, s14                                 // 0000001F8694: 8D000E7E
	s_cbranch_execz 81                                         // 0000001F8698: BFA50051 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x40e0>
	s_waitcnt vmcnt(15)                                        // 0000001F869C: BF893FF7
	v_mov_b32_e32 v97, 0                                       // 0000001F86A0: 7EC20280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001F86A4: BF870001
	v_mov_b32_e32 v98, v97                                     // 0000001F86A8: 7EC40361
	v_mov_b32_e32 v99, v97                                     // 0000001F86AC: 7EC60361
	v_mov_b32_e32 v100, v97                                    // 0000001F86B0: 7EC80361
	s_waitcnt vmcnt(14)                                        // 0000001F86B4: BF893BF7
	v_mov_b32_e32 v101, v97                                    // 0000001F86B8: 7ECA0361
	v_mov_b32_e32 v102, v97                                    // 0000001F86BC: 7ECC0361
	v_mov_b32_e32 v103, v97                                    // 0000001F86C0: 7ECE0361
	v_mov_b32_e32 v104, v97                                    // 0000001F86C4: 7ED00361
	s_waitcnt vmcnt(13)                                        // 0000001F86C8: BF8937F7
	v_mov_b32_e32 v89, v97                                     // 0000001F86CC: 7EB20361
	v_mov_b32_e32 v90, v97                                     // 0000001F86D0: 7EB40361
	v_mov_b32_e32 v91, v97                                     // 0000001F86D4: 7EB60361
	v_mov_b32_e32 v92, v97                                     // 0000001F86D8: 7EB80361
	s_waitcnt vmcnt(12)                                        // 0000001F86DC: BF8933F7
	v_mov_b32_e32 v93, v97                                     // 0000001F86E0: 7EBA0361
	v_mov_b32_e32 v94, v97                                     // 0000001F86E4: 7EBC0361
	v_mov_b32_e32 v95, v97                                     // 0000001F86E8: 7EBE0361
	v_mov_b32_e32 v96, v97                                     // 0000001F86EC: 7EC00361
	s_waitcnt vmcnt(11)                                        // 0000001F86F0: BF892FF7
	v_mov_b32_e32 v81, v97                                     // 0000001F86F4: 7EA20361
	v_mov_b32_e32 v82, v97                                     // 0000001F86F8: 7EA40361
	v_mov_b32_e32 v83, v97                                     // 0000001F86FC: 7EA60361
	v_mov_b32_e32 v84, v97                                     // 0000001F8700: 7EA80361
	s_waitcnt vmcnt(10)                                        // 0000001F8704: BF892BF7
	v_mov_b32_e32 v85, v97                                     // 0000001F8708: 7EAA0361
	v_mov_b32_e32 v86, v97                                     // 0000001F870C: 7EAC0361
	v_mov_b32_e32 v87, v97                                     // 0000001F8710: 7EAE0361
	v_mov_b32_e32 v88, v97                                     // 0000001F8714: 7EB00361
	s_waitcnt vmcnt(9)                                         // 0000001F8718: BF8927F7
	v_mov_b32_e32 v73, v97                                     // 0000001F871C: 7E920361
	v_mov_b32_e32 v74, v97                                     // 0000001F8720: 7E940361
	v_mov_b32_e32 v75, v97                                     // 0000001F8724: 7E960361
	v_mov_b32_e32 v76, v97                                     // 0000001F8728: 7E980361
	s_waitcnt vmcnt(8)                                         // 0000001F872C: BF8923F7
	v_mov_b32_e32 v77, v97                                     // 0000001F8730: 7E9A0361
	v_mov_b32_e32 v78, v97                                     // 0000001F8734: 7E9C0361
	v_mov_b32_e32 v79, v97                                     // 0000001F8738: 7E9E0361
	v_mov_b32_e32 v80, v97                                     // 0000001F873C: 7EA00361
	s_waitcnt vmcnt(7)                                         // 0000001F8740: BF891FF7
	v_mov_b32_e32 v57, v97                                     // 0000001F8744: 7E720361
	v_mov_b32_e32 v58, v97                                     // 0000001F8748: 7E740361
	v_mov_b32_e32 v59, v97                                     // 0000001F874C: 7E760361
	v_mov_b32_e32 v60, v97                                     // 0000001F8750: 7E780361
	s_waitcnt vmcnt(6)                                         // 0000001F8754: BF891BF7
	v_mov_b32_e32 v61, v97                                     // 0000001F8758: 7E7A0361
	v_mov_b32_e32 v62, v97                                     // 0000001F875C: 7E7C0361
	v_mov_b32_e32 v63, v97                                     // 0000001F8760: 7E7E0361
	v_mov_b32_e32 v64, v97                                     // 0000001F8764: 7E800361
	s_waitcnt vmcnt(5)                                         // 0000001F8768: BF8917F7
	v_mov_b32_e32 v49, v97                                     // 0000001F876C: 7E620361
	v_mov_b32_e32 v50, v97                                     // 0000001F8770: 7E640361
	v_mov_b32_e32 v51, v97                                     // 0000001F8774: 7E660361
	v_mov_b32_e32 v52, v97                                     // 0000001F8778: 7E680361
	s_waitcnt vmcnt(4)                                         // 0000001F877C: BF8913F7
	v_mov_b32_e32 v53, v97                                     // 0000001F8780: 7E6A0361
	v_mov_b32_e32 v54, v97                                     // 0000001F8784: 7E6C0361
	v_mov_b32_e32 v55, v97                                     // 0000001F8788: 7E6E0361
	v_mov_b32_e32 v56, v97                                     // 0000001F878C: 7E700361
	s_waitcnt vmcnt(3)                                         // 0000001F8790: BF890FF7
	v_mov_b32_e32 v41, v97                                     // 0000001F8794: 7E520361
	v_mov_b32_e32 v42, v97                                     // 0000001F8798: 7E540361
	v_mov_b32_e32 v43, v97                                     // 0000001F879C: 7E560361
	v_mov_b32_e32 v44, v97                                     // 0000001F87A0: 7E580361
	s_waitcnt vmcnt(2)                                         // 0000001F87A4: BF890BF7
	v_mov_b32_e32 v45, v97                                     // 0000001F87A8: 7E5A0361
	v_mov_b32_e32 v46, v97                                     // 0000001F87AC: 7E5C0361
	v_mov_b32_e32 v47, v97                                     // 0000001F87B0: 7E5E0361
	v_mov_b32_e32 v48, v97                                     // 0000001F87B4: 7E600361
	s_waitcnt vmcnt(1)                                         // 0000001F87B8: BF8907F7
	v_mov_b32_e32 v33, v97                                     // 0000001F87BC: 7E420361
	v_mov_b32_e32 v34, v97                                     // 0000001F87C0: 7E440361
	v_mov_b32_e32 v35, v97                                     // 0000001F87C4: 7E460361
	v_mov_b32_e32 v36, v97                                     // 0000001F87C8: 7E480361
	s_waitcnt vmcnt(0)                                         // 0000001F87CC: BF8903F7
	v_mov_b32_e32 v37, v97                                     // 0000001F87D0: 7E4A0361
	v_mov_b32_e32 v38, v97                                     // 0000001F87D4: 7E4C0361
	v_mov_b32_e32 v39, v97                                     // 0000001F87D8: 7E4E0361
	v_mov_b32_e32 v40, v97                                     // 0000001F87DC: 7E500361
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F87E0: 8C7E007E
	ds_load_b128 v[1:4], v137                                  // 0000001F87E4: DBFC0000 01000089
	ds_load_b128 v[5:8], v137 offset:16                        // 0000001F87EC: DBFC0010 05000089
	ds_load_b128 v[9:12], v137 offset:32                       // 0000001F87F4: DBFC0020 09000089
	ds_load_b128 v[13:16], v137 offset:48                      // 0000001F87FC: DBFC0030 0D000089
	ds_load_b128 v[17:20], v137 offset:8448                    // 0000001F8804: DBFC2100 11000089
	ds_load_b128 v[21:24], v137 offset:8464                    // 0000001F880C: DBFC2110 15000089
	ds_load_b128 v[25:28], v137 offset:8480                    // 0000001F8814: DBFC2120 19000089
	ds_load_b128 v[29:32], v137 offset:8496                    // 0000001F881C: DBFC2130 1D000089
	ds_load_b128 v[118:121], v137 offset:16896                 // 0000001F8824: DBFC4200 76000089
	ds_load_b128 v[216:219], v137 offset:16912                 // 0000001F882C: DBFC4210 D8000089
	v_dual_mov_b32 v72, s27 :: v_dual_mov_b32 v71, s26         // 0000001F8834: CA10001B 4846001A
	v_dual_mov_b32 v70, s25 :: v_dual_mov_b32 v69, s24         // 0000001F883C: CA100019 46440018
	v_dual_mov_b32 v68, s23 :: v_dual_mov_b32 v67, s22         // 0000001F8844: CA100017 44420016
	v_dual_mov_b32 v66, s21 :: v_dual_mov_b32 v65, s20         // 0000001F884C: CA100015 42400014
	ds_load_b128 v[220:223], v137 offset:16928                 // 0000001F8854: DBFC4220 DC000089
	ds_load_b128 v[224:227], v137 offset:16944                 // 0000001F885C: DBFC4230 E0000089
	s_waitcnt lgkmcnt(11)                                      // 0000001F8864: BF89FCB7
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001F8868: CC210001 02004F01
	v_fma_mixhi_f16 v1, v2, s39, 0                             // 0000001F8870: CC220001 02004F02
	v_fma_mixlo_f16 v2, v3, s39, 0                             // 0000001F8878: CC210002 02004F03
	v_fma_mixhi_f16 v2, v4, s39, 0                             // 0000001F8880: CC220002 02004F04
	s_waitcnt lgkmcnt(10)                                      // 0000001F8888: BF89FCA7
	v_fma_mixlo_f16 v3, v5, s39, 0                             // 0000001F888C: CC210003 02004F05
	v_fma_mixhi_f16 v3, v6, s39, 0                             // 0000001F8894: CC220003 02004F06
	v_fma_mixlo_f16 v4, v7, s39, 0                             // 0000001F889C: CC210004 02004F07
	v_fma_mixhi_f16 v4, v8, s39, 0                             // 0000001F88A4: CC220004 02004F08
	s_waitcnt lgkmcnt(9)                                       // 0000001F88AC: BF89FC97
	v_fma_mixlo_f16 v5, v9, s39, 0                             // 0000001F88B0: CC210005 02004F09
	v_fma_mixhi_f16 v5, v10, s39, 0                            // 0000001F88B8: CC220005 02004F0A
	v_fma_mixlo_f16 v6, v11, s39, 0                            // 0000001F88C0: CC210006 02004F0B
	v_fma_mixhi_f16 v6, v12, s39, 0                            // 0000001F88C8: CC220006 02004F0C
	s_waitcnt lgkmcnt(8)                                       // 0000001F88D0: BF89FC87
	v_fma_mixlo_f16 v7, v13, s39, 0                            // 0000001F88D4: CC210007 02004F0D
	v_fma_mixhi_f16 v7, v14, s39, 0                            // 0000001F88DC: CC220007 02004F0E
	v_fma_mixlo_f16 v8, v15, s39, 0                            // 0000001F88E4: CC210008 02004F0F
	v_fma_mixhi_f16 v8, v16, s39, 0                            // 0000001F88EC: CC220008 02004F10
	s_waitcnt lgkmcnt(7)                                       // 0000001F88F4: BF89FC77
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001F88F8: CC210011 02004F11
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001F8900: CC220011 02004F12
	v_fma_mixlo_f16 v18, v19, s39, 0                           // 0000001F8908: CC210012 02004F13
	v_fma_mixhi_f16 v18, v20, s39, 0                           // 0000001F8910: CC220012 02004F14
	s_waitcnt lgkmcnt(6)                                       // 0000001F8918: BF89FC67
	v_fma_mixlo_f16 v19, v21, s39, 0                           // 0000001F891C: CC210013 02004F15
	v_fma_mixhi_f16 v19, v22, s39, 0                           // 0000001F8924: CC220013 02004F16
	v_fma_mixlo_f16 v20, v23, s39, 0                           // 0000001F892C: CC210014 02004F17
	v_fma_mixhi_f16 v20, v24, s39, 0                           // 0000001F8934: CC220014 02004F18
	s_waitcnt lgkmcnt(5)                                       // 0000001F893C: BF89FC57
	v_fma_mixlo_f16 v21, v25, s39, 0                           // 0000001F8940: CC210015 02004F19
	v_fma_mixhi_f16 v21, v26, s39, 0                           // 0000001F8948: CC220015 02004F1A
	v_fma_mixlo_f16 v22, v27, s39, 0                           // 0000001F8950: CC210016 02004F1B
	v_fma_mixhi_f16 v22, v28, s39, 0                           // 0000001F8958: CC220016 02004F1C
	s_waitcnt lgkmcnt(4)                                       // 0000001F8960: BF89FC47
	v_fma_mixlo_f16 v23, v29, s39, 0                           // 0000001F8964: CC210017 02004F1D
	v_fma_mixhi_f16 v23, v30, s39, 0                           // 0000001F896C: CC220017 02004F1E
	v_fma_mixlo_f16 v24, v31, s39, 0                           // 0000001F8974: CC210018 02004F1F
	v_fma_mixhi_f16 v24, v32, s39, 0                           // 0000001F897C: CC220018 02004F20
	s_waitcnt vmcnt(14)                                        // 0000001F8984: BF893BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[97:104], v[1:8], v[65:72]// 0000001F8988: CC404019 1D060361
	s_waitcnt lgkmcnt(3)                                       // 0000001F8990: BF89FC37
	v_fma_mixlo_f16 v1, v118, s39, 0                           // 0000001F8994: CC210001 02004F76
	v_fma_mixhi_f16 v1, v119, s39, 0                           // 0000001F899C: CC220001 02004F77
	v_fma_mixlo_f16 v2, v120, s39, 0                           // 0000001F89A4: CC210002 02004F78
	v_fma_mixhi_f16 v2, v121, s39, 0                           // 0000001F89AC: CC220002 02004F79
	ds_load_b128 v[118:121], v137 offset:25376                 // 0000001F89B4: DBFC6320 76000089
	ds_load_b128 v[228:231], v137 offset:25392                 // 0000001F89BC: DBFC6330 E4000089
	v_wmma_f32_16x16x16_f16 v[9:16], v[97:104], v[17:24], v[65:72]// 0000001F89C4: CC404009 1D062361
	ds_load_b128 v[17:20], v137 offset:25344                   // 0000001F89CC: DBFC6300 11000089
	ds_load_b128 v[21:24], v137 offset:25360                   // 0000001F89D4: DBFC6310 15000089
	s_waitcnt lgkmcnt(5)                                       // 0000001F89DC: BF89FC57
	v_fma_mixlo_f16 v5, v220, s39, 0                           // 0000001F89E0: CC210005 02004FDC
	v_fma_mixhi_f16 v5, v221, s39, 0                           // 0000001F89E8: CC220005 02004FDD
	s_waitcnt lgkmcnt(4)                                       // 0000001F89F0: BF89FC47
	v_fma_mixlo_f16 v7, v224, s39, 0                           // 0000001F89F4: CC210007 02004FE0
	v_fma_mixhi_f16 v7, v225, s39, 0                           // 0000001F89FC: CC220007 02004FE1
	v_fma_mixlo_f16 v8, v226, s39, 0                           // 0000001F8A04: CC210008 02004FE2
	v_fma_mixhi_f16 v8, v227, s39, 0                           // 0000001F8A0C: CC220008 02004FE3
	ds_load_b128 v[224:227], v137 offset:64                    // 0000001F8A14: DBFC0040 E0000089
	ds_load_b128 v[232:235], v137 offset:80                    // 0000001F8A1C: DBFC0050 E8000089
	v_fma_mixlo_f16 v3, v216, s39, 0                           // 0000001F8A24: CC210003 02004FD8
	v_fma_mixhi_f16 v3, v217, s39, 0                           // 0000001F8A2C: CC220003 02004FD9
	v_fma_mixlo_f16 v4, v218, s39, 0                           // 0000001F8A34: CC210004 02004FDA
	v_fma_mixhi_f16 v4, v219, s39, 0                           // 0000001F8A3C: CC220004 02004FDB
	v_fma_mixlo_f16 v6, v222, s39, 0                           // 0000001F8A44: CC210006 02004FDE
	v_fma_mixhi_f16 v6, v223, s39, 0                           // 0000001F8A4C: CC220006 02004FDF
	s_waitcnt lgkmcnt(5)                                       // 0000001F8A54: BF89FC57
	v_fma_mixlo_f16 v220, v118, s39, 0                         // 0000001F8A58: CC2100DC 02004F76
	v_fma_mixhi_f16 v220, v119, s39, 0                         // 0000001F8A60: CC2200DC 02004F77
	v_fma_mixlo_f16 v221, v120, s39, 0                         // 0000001F8A68: CC2100DD 02004F78
	v_fma_mixhi_f16 v221, v121, s39, 0                         // 0000001F8A70: CC2200DD 02004F79
	ds_load_b128 v[118:121], v137 offset:96                    // 0000001F8A78: DBFC0060 76000089
	s_waitcnt lgkmcnt(4)                                       // 0000001F8A80: BF89FC47
	v_fma_mixlo_f16 v216, v17, s39, 0                          // 0000001F8A84: CC2100D8 02004F11
	v_fma_mixhi_f16 v216, v18, s39, 0                          // 0000001F8A8C: CC2200D8 02004F12
	v_fma_mixlo_f16 v217, v19, s39, 0                          // 0000001F8A94: CC2100D9 02004F13
	v_fma_mixhi_f16 v217, v20, s39, 0                          // 0000001F8A9C: CC2200D9 02004F14
	s_waitcnt lgkmcnt(3)                                       // 0000001F8AA4: BF89FC37
	v_fma_mixlo_f16 v218, v21, s39, 0                          // 0000001F8AA8: CC2100DA 02004F15
	v_fma_mixhi_f16 v218, v22, s39, 0                          // 0000001F8AB0: CC2200DA 02004F16
	v_fma_mixlo_f16 v219, v23, s39, 0                          // 0000001F8AB8: CC2100DB 02004F17
	v_fma_mixhi_f16 v219, v24, s39, 0                          // 0000001F8AC0: CC2200DB 02004F18
	v_fma_mixlo_f16 v222, v228, s39, 0                         // 0000001F8AC8: CC2100DE 02004FE4
	v_fma_mixhi_f16 v222, v229, s39, 0                         // 0000001F8AD0: CC2200DE 02004FE5
	v_fma_mixlo_f16 v223, v230, s39, 0                         // 0000001F8AD8: CC2100DF 02004FE6
	v_fma_mixhi_f16 v223, v231, s39, 0                         // 0000001F8AE0: CC2200DF 02004FE7
	ds_load_b128 v[228:231], v137 offset:112                   // 0000001F8AE8: DBFC0070 E4000089
	v_wmma_f32_16x16x16_f16 v[17:24], v[97:104], v[1:8], v[65:72]// 0000001F8AF0: CC404011 1D060361
	ds_load_b128 v[236:239], v137 offset:16992                 // 0000001F8AF8: DBFC4260 EC000089
	ds_load_b128 v[240:243], v137 offset:17008                 // 0000001F8B00: DBFC4270 F0000089
	v_wmma_f32_16x16x16_f16 v[1:8], v[97:104], v[216:223], v[65:72]// 0000001F8B08: CC404001 1D07B161
	ds_load_b128 v[216:219], v137 offset:8512                  // 0000001F8B10: DBFC2140 D8000089
	ds_load_b128 v[220:223], v137 offset:8528                  // 0000001F8B18: DBFC2150 DC000089
	s_waitcnt lgkmcnt(7)                                       // 0000001F8B20: BF89FC77
	v_fma_mixlo_f16 v97, v224, s39, 0                          // 0000001F8B24: CC210061 02004FE0
	v_fma_mixhi_f16 v97, v225, s39, 0                          // 0000001F8B2C: CC220061 02004FE1
	v_fma_mixlo_f16 v98, v226, s39, 0                          // 0000001F8B34: CC210062 02004FE2
	v_fma_mixhi_f16 v98, v227, s39, 0                          // 0000001F8B3C: CC220062 02004FE3
	ds_load_b128 v[224:227], v137 offset:8544                  // 0000001F8B44: DBFC2160 E0000089
	s_waitcnt lgkmcnt(6)                                       // 0000001F8B4C: BF89FC67
	v_fma_mixlo_f16 v101, v118, s39, 0                         // 0000001F8B50: CC210065 02004F76
	v_fma_mixhi_f16 v101, v119, s39, 0                         // 0000001F8B58: CC220065 02004F77
	v_fma_mixlo_f16 v102, v120, s39, 0                         // 0000001F8B60: CC210066 02004F78
	v_fma_mixhi_f16 v102, v121, s39, 0                         // 0000001F8B68: CC220066 02004F79
	ds_load_b128 v[118:121], v137 offset:8560                  // 0000001F8B70: DBFC2170 76000089
	v_fma_mixlo_f16 v99, v232, s39, 0                          // 0000001F8B78: CC210063 02004FE8
	v_fma_mixhi_f16 v99, v233, s39, 0                          // 0000001F8B80: CC220063 02004FE9
	v_fma_mixlo_f16 v100, v234, s39, 0                         // 0000001F8B88: CC210064 02004FEA
	v_fma_mixhi_f16 v100, v235, s39, 0                         // 0000001F8B90: CC220064 02004FEB
	s_waitcnt lgkmcnt(6)                                       // 0000001F8B98: BF89FC67
	v_fma_mixlo_f16 v103, v228, s39, 0                         // 0000001F8B9C: CC210067 02004FE4
	v_fma_mixhi_f16 v103, v229, s39, 0                         // 0000001F8BA4: CC220067 02004FE5
	v_fma_mixlo_f16 v104, v230, s39, 0                         // 0000001F8BAC: CC210068 02004FE6
	v_fma_mixhi_f16 v104, v231, s39, 0                         // 0000001F8BB4: CC220068 02004FE7
	s_waitcnt lgkmcnt(3)                                       // 0000001F8BBC: BF89FC37
	v_fma_mixlo_f16 v216, v216, s39, 0                         // 0000001F8BC0: CC2100D8 02004FD8
	ds_load_b128 v[228:231], v137 offset:16960                 // 0000001F8BC8: DBFC4240 E4000089
	ds_load_b128 v[232:235], v137 offset:16976                 // 0000001F8BD0: DBFC4250 E8000089
	v_fma_mixhi_f16 v216, v217, s39, 0                         // 0000001F8BD8: CC2200D8 02004FD9
	v_fma_mixhi_f16 v217, v219, s39, 0                         // 0000001F8BE0: CC2200D9 02004FDB
	s_waitcnt lgkmcnt(4)                                       // 0000001F8BE8: BF89FC47
	v_fma_mixlo_f16 v219, v222, s39, 0                         // 0000001F8BEC: CC2100DB 02004FDE
	v_fma_mixhi_f16 v219, v223, s39, 0                         // 0000001F8BF4: CC2200DB 02004FDF
	ds_load_b128 v[244:247], v137 offset:25424                 // 0000001F8BFC: DBFC6350 F4000089
	ds_load_b128 v[248:251], v137 offset:25440                 // 0000001F8C04: DBFC6360 F8000089
	ds_load_b128 v[252:255], v137 offset:25456                 // 0000001F8C0C: DBFC6370 FC000089
	v_fma_mixlo_f16 v217, v218, s39, 0                         // 0000001F8C14: CC2100D9 02004FDA
	s_waitcnt lgkmcnt(5)                                       // 0000001F8C1C: BF89FC57
	v_fma_mixlo_f16 v222, v118, s39, 0                         // 0000001F8C20: CC2100DE 02004F76
	v_fma_mixhi_f16 v222, v119, s39, 0                         // 0000001F8C28: CC2200DE 02004F77
	v_fma_mixlo_f16 v223, v120, s39, 0                         // 0000001F8C30: CC2100DF 02004F78
	v_fma_mixhi_f16 v223, v121, s39, 0                         // 0000001F8C38: CC2200DF 02004F79
	ds_load_b128 v[118:121], v137 offset:25408                 // 0000001F8C40: DBFC6340 76000089
	v_fma_mixhi_f16 v218, v221, s39, 0                         // 0000001F8C48: CC2200DA 02004FDD
	v_fma_mixlo_f16 v221, v226, s39, 0                         // 0000001F8C50: CC2100DD 02004FE2
	v_fma_mixlo_f16 v218, v220, s39, 0                         // 0000001F8C58: CC2100DA 02004FDC
	v_fma_mixlo_f16 v220, v224, s39, 0                         // 0000001F8C60: CC2100DC 02004FE0
	v_fma_mixhi_f16 v220, v225, s39, 0                         // 0000001F8C68: CC2200DC 02004FE1
	v_fma_mixhi_f16 v221, v227, s39, 0                         // 0000001F8C70: CC2200DD 02004FE3
	s_waitcnt lgkmcnt(4)                                       // 0000001F8C78: BF89FC47
	v_fma_mixlo_f16 v226, v232, s39, 0                         // 0000001F8C7C: CC2100E2 02004FE8
	v_fma_mixhi_f16 v226, v233, s39, 0                         // 0000001F8C84: CC2200E2 02004FE9
	v_fma_mixlo_f16 v224, v228, s39, 0                         // 0000001F8C8C: CC2100E0 02004FE4
	v_fma_mixhi_f16 v224, v229, s39, 0                         // 0000001F8C94: CC2200E0 02004FE5
	v_fma_mixlo_f16 v225, v230, s39, 0                         // 0000001F8C9C: CC2100E1 02004FE6
	v_fma_mixhi_f16 v225, v231, s39, 0                         // 0000001F8CA4: CC2200E1 02004FE7
	v_fma_mixlo_f16 v227, v234, s39, 0                         // 0000001F8CAC: CC2100E3 02004FEA
	v_fma_mixhi_f16 v227, v235, s39, 0                         // 0000001F8CB4: CC2200E3 02004FEB
	v_fma_mixlo_f16 v228, v236, s39, 0                         // 0000001F8CBC: CC2100E4 02004FEC
	v_fma_mixhi_f16 v228, v237, s39, 0                         // 0000001F8CC4: CC2200E4 02004FED
	v_fma_mixlo_f16 v229, v238, s39, 0                         // 0000001F8CCC: CC2100E5 02004FEE
	v_fma_mixhi_f16 v229, v239, s39, 0                         // 0000001F8CD4: CC2200E5 02004FEF
	v_fma_mixlo_f16 v230, v240, s39, 0                         // 0000001F8CDC: CC2100E6 02004FF0
	s_waitcnt lgkmcnt(0)                                       // 0000001F8CE4: BF89FC07
	v_fma_mixlo_f16 v232, v118, s39, 0                         // 0000001F8CE8: CC2100E8 02004F76
	v_fma_mixhi_f16 v232, v119, s39, 0                         // 0000001F8CF0: CC2200E8 02004F77
	v_fma_mixlo_f16 v233, v120, s39, 0                         // 0000001F8CF8: CC2100E9 02004F78
	v_fma_mixhi_f16 v233, v121, s39, 0                         // 0000001F8D00: CC2200E9 02004F79
	ds_load_b128 v[118:121], v137 offset:128                   // 0000001F8D08: DBFC0080 76000089
	v_fma_mixhi_f16 v230, v241, s39, 0                         // 0000001F8D10: CC2200E6 02004FF1
	v_fma_mixlo_f16 v231, v242, s39, 0                         // 0000001F8D18: CC2100E7 02004FF2
	v_fma_mixhi_f16 v231, v243, s39, 0                         // 0000001F8D20: CC2200E7 02004FF3
	v_fma_mixlo_f16 v234, v244, s39, 0                         // 0000001F8D28: CC2100EA 02004FF4
	v_fma_mixhi_f16 v234, v245, s39, 0                         // 0000001F8D30: CC2200EA 02004FF5
	v_fma_mixlo_f16 v235, v246, s39, 0                         // 0000001F8D38: CC2100EB 02004FF6
	v_fma_mixhi_f16 v235, v247, s39, 0                         // 0000001F8D40: CC2200EB 02004FF7
	v_fma_mixlo_f16 v236, v248, s39, 0                         // 0000001F8D48: CC2100EC 02004FF8
	v_fma_mixhi_f16 v236, v249, s39, 0                         // 0000001F8D50: CC2200EC 02004FF9
	v_fma_mixlo_f16 v237, v250, s39, 0                         // 0000001F8D58: CC2100ED 02004FFA
	v_fma_mixhi_f16 v237, v251, s39, 0                         // 0000001F8D60: CC2200ED 02004FFB
	v_fma_mixlo_f16 v238, v252, s39, 0                         // 0000001F8D68: CC2100EE 02004FFC
	v_fma_mixhi_f16 v238, v253, s39, 0                         // 0000001F8D70: CC2200EE 02004FFD
	v_fma_mixlo_f16 v239, v254, s39, 0                         // 0000001F8D78: CC2100EF 02004FFE
	v_fma_mixhi_f16 v239, v255, s39, 0                         // 0000001F8D80: CC2200EF 02004FFF
	ds_load_b128 v[240:243], v137 offset:144                   // 0000001F8D88: DBFC0090 F0000089
	ds_load_b128 v[244:247], v137 offset:160                   // 0000001F8D90: DBFC00A0 F4000089
	s_waitcnt vmcnt(12)                                        // 0000001F8D98: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[97:104], v[25:32]// 0000001F8D9C: CC404019 1C66C359
	ds_load_b128 v[97:100], v137 offset:176                    // 0000001F8DA4: DBFC00B0 61000089
	v_wmma_f32_16x16x16_f16 v[9:16], v[89:96], v[216:223], v[9:16]// 0000001F8DAC: CC404009 1C27B159
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[224:231], v[17:24]// 0000001F8DB4: CC404011 1C47C159
	v_wmma_f32_16x16x16_f16 v[1:8], v[89:96], v[232:239], v[1:8]// 0000001F8DBC: CC404001 1C07D159
	ds_load_b128 v[101:104], v137 offset:8576                  // 0000001F8DC4: DBFC2180 65000089
	s_waitcnt lgkmcnt(4)                                       // 0000001F8DCC: BF89FC47
	v_fma_mixlo_f16 v89, v118, s39, 0                          // 0000001F8DD0: CC210059 02004F76
	v_fma_mixhi_f16 v89, v119, s39, 0                          // 0000001F8DD8: CC220059 02004F77
	v_fma_mixlo_f16 v90, v120, s39, 0                          // 0000001F8DE0: CC21005A 02004F78
	v_fma_mixhi_f16 v90, v121, s39, 0                          // 0000001F8DE8: CC22005A 02004F79
	ds_load_b128 v[118:121], v137 offset:8592                  // 0000001F8DF0: DBFC2190 76000089
	ds_load_b128 v[216:219], v137 offset:8608                  // 0000001F8DF8: DBFC21A0 D8000089
	ds_load_b128 v[220:223], v137 offset:8624                  // 0000001F8E00: DBFC21B0 DC000089
	ds_load_b128 v[224:227], v137 offset:17024                 // 0000001F8E08: DBFC4280 E0000089
	ds_load_b128 v[228:231], v137 offset:17040                 // 0000001F8E10: DBFC4290 E4000089
	ds_load_b128 v[232:235], v137 offset:17072                 // 0000001F8E18: DBFC42B0 E8000089
	ds_load_b128 v[236:239], v137 offset:25472                 // 0000001F8E20: DBFC6380 EC000089
	ds_load_b128 v[248:251], v137 offset:25520                 // 0000001F8E28: DBFC63B0 F8000089
	s_waitcnt lgkmcnt(11)                                      // 0000001F8E30: BF89FCB7
	v_fma_mixlo_f16 v91, v240, s39, 0                          // 0000001F8E34: CC21005B 02004FF0
	v_fma_mixhi_f16 v91, v241, s39, 0                          // 0000001F8E3C: CC22005B 02004FF1
	v_fma_mixlo_f16 v92, v242, s39, 0                          // 0000001F8E44: CC21005C 02004FF2
	s_waitcnt lgkmcnt(9)                                       // 0000001F8E4C: BF89FC97
	v_fma_mixlo_f16 v96, v99, s39, 0                           // 0000001F8E50: CC210060 02004F63
	v_fma_mixhi_f16 v96, v100, s39, 0                          // 0000001F8E58: CC220060 02004F64
	v_fma_mixhi_f16 v92, v243, s39, 0                          // 0000001F8E60: CC22005C 02004FF3
	v_fma_mixlo_f16 v93, v244, s39, 0                          // 0000001F8E68: CC21005D 02004FF4
	v_fma_mixhi_f16 v93, v245, s39, 0                          // 0000001F8E70: CC22005D 02004FF5
	v_fma_mixlo_f16 v94, v246, s39, 0                          // 0000001F8E78: CC21005E 02004FF6
	v_fma_mixhi_f16 v94, v247, s39, 0                          // 0000001F8E80: CC22005E 02004FF7
	ds_load_b128 v[240:243], v137 offset:25488                 // 0000001F8E88: DBFC6390 F0000089
	ds_load_b128 v[244:247], v137 offset:25504                 // 0000001F8E90: DBFC63A0 F4000089
	s_waitcnt lgkmcnt(9)                                       // 0000001F8E98: BF89FC97
	v_fma_mixlo_f16 v99, v118, s39, 0                          // 0000001F8E9C: CC210063 02004F76
	v_fma_mixhi_f16 v99, v119, s39, 0                          // 0000001F8EA4: CC220063 02004F77
	v_fma_mixlo_f16 v100, v120, s39, 0                         // 0000001F8EAC: CC210064 02004F78
	v_fma_mixhi_f16 v100, v121, s39, 0                         // 0000001F8EB4: CC220064 02004F79
	ds_load_b128 v[118:121], v137 offset:17056                 // 0000001F8EBC: DBFC42A0 76000089
	v_fma_mixhi_f16 v95, v98, s39, 0                           // 0000001F8EC4: CC22005F 02004F62
	v_fma_mixlo_f16 v98, v103, s39, 0                          // 0000001F8ECC: CC210062 02004F67
	s_waitcnt lgkmcnt(8)                                       // 0000001F8ED4: BF89FC87
	v_fma_mixlo_f16 v103, v220, s39, 0                         // 0000001F8ED8: CC210067 02004FDC
	v_fma_mixhi_f16 v103, v221, s39, 0                         // 0000001F8EE0: CC220067 02004FDD
	v_fma_mixlo_f16 v95, v97, s39, 0                           // 0000001F8EE8: CC21005F 02004F61
	v_fma_mixlo_f16 v97, v101, s39, 0                          // 0000001F8EF0: CC210061 02004F65
	v_fma_mixhi_f16 v97, v102, s39, 0                          // 0000001F8EF8: CC220061 02004F66
	v_fma_mixhi_f16 v98, v104, s39, 0                          // 0000001F8F00: CC220062 02004F68
	v_fma_mixlo_f16 v101, v216, s39, 0                         // 0000001F8F08: CC210065 02004FD8
	v_fma_mixhi_f16 v101, v217, s39, 0                         // 0000001F8F10: CC220065 02004FD9
	v_fma_mixlo_f16 v102, v218, s39, 0                         // 0000001F8F18: CC210066 02004FDA
	v_fma_mixhi_f16 v102, v219, s39, 0                         // 0000001F8F20: CC220066 02004FDB
	v_fma_mixlo_f16 v104, v222, s39, 0                         // 0000001F8F28: CC210068 02004FDE
	v_fma_mixhi_f16 v104, v223, s39, 0                         // 0000001F8F30: CC220068 02004FDF
	s_waitcnt lgkmcnt(7)                                       // 0000001F8F38: BF89FC77
	v_fma_mixlo_f16 v216, v224, s39, 0                         // 0000001F8F3C: CC2100D8 02004FE0
	v_fma_mixhi_f16 v216, v225, s39, 0                         // 0000001F8F44: CC2200D8 02004FE1
	v_fma_mixlo_f16 v217, v226, s39, 0                         // 0000001F8F4C: CC2100D9 02004FE2
	v_fma_mixhi_f16 v217, v227, s39, 0                         // 0000001F8F54: CC2200D9 02004FE3
	s_waitcnt lgkmcnt(6)                                       // 0000001F8F5C: BF89FC67
	v_fma_mixlo_f16 v218, v228, s39, 0                         // 0000001F8F60: CC2100DA 02004FE4
	s_waitcnt lgkmcnt(0)                                       // 0000001F8F68: BF89FC07
	v_fma_mixlo_f16 v220, v118, s39, 0                         // 0000001F8F6C: CC2100DC 02004F76
	v_fma_mixhi_f16 v220, v119, s39, 0                         // 0000001F8F74: CC2200DC 02004F77
	v_fma_mixlo_f16 v221, v120, s39, 0                         // 0000001F8F7C: CC2100DD 02004F78
	v_fma_mixhi_f16 v221, v121, s39, 0                         // 0000001F8F84: CC2200DD 02004F79
	ds_load_b128 v[118:121], v137 offset:192                   // 0000001F8F8C: DBFC00C0 76000089
	v_fma_mixhi_f16 v218, v229, s39, 0                         // 0000001F8F94: CC2200DA 02004FE5
	v_fma_mixlo_f16 v219, v230, s39, 0                         // 0000001F8F9C: CC2100DB 02004FE6
	v_fma_mixhi_f16 v219, v231, s39, 0                         // 0000001F8FA4: CC2200DB 02004FE7
	v_fma_mixlo_f16 v222, v232, s39, 0                         // 0000001F8FAC: CC2100DE 02004FE8
	v_fma_mixhi_f16 v222, v233, s39, 0                         // 0000001F8FB4: CC2200DE 02004FE9
	v_fma_mixlo_f16 v223, v234, s39, 0                         // 0000001F8FBC: CC2100DF 02004FEA
	v_fma_mixhi_f16 v223, v235, s39, 0                         // 0000001F8FC4: CC2200DF 02004FEB
	v_fma_mixlo_f16 v224, v236, s39, 0                         // 0000001F8FCC: CC2100E0 02004FEC
	v_fma_mixhi_f16 v224, v237, s39, 0                         // 0000001F8FD4: CC2200E0 02004FED
	v_fma_mixlo_f16 v225, v238, s39, 0                         // 0000001F8FDC: CC2100E1 02004FEE
	v_fma_mixhi_f16 v225, v239, s39, 0                         // 0000001F8FE4: CC2200E1 02004FEF
	v_fma_mixlo_f16 v226, v240, s39, 0                         // 0000001F8FEC: CC2100E2 02004FF0
	v_fma_mixhi_f16 v226, v241, s39, 0                         // 0000001F8FF4: CC2200E2 02004FF1
	v_fma_mixlo_f16 v227, v242, s39, 0                         // 0000001F8FFC: CC2100E3 02004FF2
	v_fma_mixhi_f16 v227, v243, s39, 0                         // 0000001F9004: CC2200E3 02004FF3
	v_fma_mixlo_f16 v228, v244, s39, 0                         // 0000001F900C: CC2100E4 02004FF4
	v_fma_mixhi_f16 v228, v245, s39, 0                         // 0000001F9014: CC2200E4 02004FF5
	v_fma_mixlo_f16 v229, v246, s39, 0                         // 0000001F901C: CC2100E5 02004FF6
	v_fma_mixhi_f16 v229, v247, s39, 0                         // 0000001F9024: CC2200E5 02004FF7
	v_fma_mixlo_f16 v230, v248, s39, 0                         // 0000001F902C: CC2100E6 02004FF8
	ds_load_b128 v[236:239], v137 offset:224                   // 0000001F9034: DBFC00E0 EC000089
	v_fma_mixhi_f16 v230, v249, s39, 0                         // 0000001F903C: CC2200E6 02004FF9
	v_fma_mixlo_f16 v231, v250, s39, 0                         // 0000001F9044: CC2100E7 02004FFA
	v_fma_mixhi_f16 v231, v251, s39, 0                         // 0000001F904C: CC2200E7 02004FFB
	s_waitcnt vmcnt(10)                                        // 0000001F9054: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 0000001F9058: CC404019 1C66B351
	ds_load_b128 v[89:92], v137 offset:240                     // 0000001F9060: DBFC00F0 59000089
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[97:104], v[9:16]// 0000001F9068: CC404009 1C26C351
	ds_load_b128 v[93:96], v137 offset:8640                    // 0000001F9070: DBFC21C0 5D000089
	ds_load_b128 v[97:100], v137 offset:8656                   // 0000001F9078: DBFC21D0 61000089
	ds_load_b128 v[101:104], v137 offset:8672                  // 0000001F9080: DBFC21E0 65000089
	ds_load_b128 v[232:235], v137 offset:208                   // 0000001F9088: DBFC00D0 E8000089
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[216:223], v[17:24]// 0000001F9090: CC404011 1C47B151
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[224:231], v[1:8]// 0000001F9098: CC404001 1C07C151
	s_waitcnt lgkmcnt(6)                                       // 0000001F90A0: BF89FC67
	v_fma_mixlo_f16 v81, v118, s39, 0                          // 0000001F90A4: CC210051 02004F76
	v_fma_mixhi_f16 v81, v119, s39, 0                          // 0000001F90AC: CC220051 02004F77
	v_fma_mixlo_f16 v82, v120, s39, 0                          // 0000001F90B4: CC210052 02004F78
	v_fma_mixhi_f16 v82, v121, s39, 0                          // 0000001F90BC: CC220052 02004F79
	ds_load_b128 v[118:121], v137 offset:8688                  // 0000001F90C4: DBFC21F0 76000089
	ds_load_b128 v[216:219], v137 offset:17088                 // 0000001F90CC: DBFC42C0 D8000089
	ds_load_b128 v[220:223], v137 offset:17104                 // 0000001F90D4: DBFC42D0 DC000089
	ds_load_b128 v[224:227], v137 offset:17120                 // 0000001F90DC: DBFC42E0 E0000089
	ds_load_b128 v[228:231], v137 offset:25552                 // 0000001F90E4: DBFC63D0 E4000089
	s_waitcnt lgkmcnt(10)                                      // 0000001F90EC: BF89FCA7
	v_fma_mixlo_f16 v85, v236, s39, 0                          // 0000001F90F0: CC210055 02004FEC
	v_fma_mixhi_f16 v85, v237, s39, 0                          // 0000001F90F8: CC220055 02004FED
	v_fma_mixlo_f16 v86, v238, s39, 0                          // 0000001F9100: CC210056 02004FEE
	s_waitcnt lgkmcnt(9)                                       // 0000001F9108: BF89FC97
	v_fma_mixlo_f16 v87, v89, s39, 0                           // 0000001F910C: CC210057 02004F59
	v_fma_mixhi_f16 v87, v90, s39, 0                           // 0000001F9114: CC220057 02004F5A
	s_waitcnt lgkmcnt(8)                                       // 0000001F911C: BF89FC87
	v_fma_mixhi_f16 v89, v94, s39, 0                           // 0000001F9120: CC220059 02004F5E
	v_fma_mixlo_f16 v90, v95, s39, 0                           // 0000001F9128: CC21005A 02004F5F
	s_waitcnt lgkmcnt(6)                                       // 0000001F9130: BF89FC67
	v_fma_mixlo_f16 v94, v103, s39, 0                          // 0000001F9134: CC21005E 02004F67
	v_fma_mixhi_f16 v94, v104, s39, 0                          // 0000001F913C: CC22005E 02004F68
	ds_load_b128 v[103:106], v137 offset:17136                 // 0000001F9144: DBFC42F0 67000089
	v_fma_mixhi_f16 v90, v96, s39, 0                           // 0000001F914C: CC22005A 02004F60
	v_fma_mixhi_f16 v88, v92, s39, 0                           // 0000001F9154: CC220058 02004F5C
	v_fma_mixlo_f16 v89, v93, s39, 0                           // 0000001F915C: CC210059 02004F5D
	v_fma_mixlo_f16 v92, v99, s39, 0                           // 0000001F9164: CC21005C 02004F63
	v_fma_mixhi_f16 v92, v100, s39, 0                          // 0000001F916C: CC22005C 02004F64
	s_waitcnt lgkmcnt(5)                                       // 0000001F9174: BF89FC57
	v_fma_mixlo_f16 v95, v118, s39, 0                          // 0000001F9178: CC21005F 02004F76
	v_fma_mixhi_f16 v95, v119, s39, 0                          // 0000001F9180: CC22005F 02004F77
	v_fma_mixlo_f16 v96, v120, s39, 0                          // 0000001F9188: CC210060 02004F78
	v_fma_mixhi_f16 v96, v121, s39, 0                          // 0000001F9190: CC220060 02004F79
	ds_load_b128 v[118:121], v137 offset:25536                 // 0000001F9198: DBFC63C0 76000089
	v_fma_mixlo_f16 v93, v101, s39, 0                          // 0000001F91A0: CC21005D 02004F65
	v_fma_mixhi_f16 v93, v102, s39, 0                          // 0000001F91A8: CC22005D 02004F66
	s_waitcnt lgkmcnt(4)                                       // 0000001F91B0: BF89FC47
	v_fma_mixlo_f16 v99, v220, s39, 0                          // 0000001F91B4: CC210063 02004FDC
	v_fma_mixhi_f16 v99, v221, s39, 0                          // 0000001F91BC: CC220063 02004FDD
	v_fma_mixlo_f16 v100, v222, s39, 0                         // 0000001F91C4: CC210064 02004FDE
	v_fma_mixhi_f16 v100, v223, s39, 0                         // 0000001F91CC: CC220064 02004FDF
	ds_load_b128 v[220:223], v137 offset:25568                 // 0000001F91D4: DBFC63E0 DC000089
	s_waitcnt lgkmcnt(4)                                       // 0000001F91DC: BF89FC47
	v_fma_mixlo_f16 v101, v224, s39, 0                         // 0000001F91E0: CC210065 02004FE0
	v_fma_mixhi_f16 v101, v225, s39, 0                         // 0000001F91E8: CC220065 02004FE1
	v_fma_mixlo_f16 v102, v226, s39, 0                         // 0000001F91F0: CC210066 02004FE2
	v_fma_mixhi_f16 v102, v227, s39, 0                         // 0000001F91F8: CC220066 02004FE3
	ds_load_b128 v[224:227], v137 offset:25584                 // 0000001F9200: DBFC63F0 E0000089
	v_fma_mixlo_f16 v83, v232, s39, 0                          // 0000001F9208: CC210053 02004FE8
	v_fma_mixhi_f16 v83, v233, s39, 0                          // 0000001F9210: CC220053 02004FE9
	v_fma_mixlo_f16 v84, v234, s39, 0                          // 0000001F9218: CC210054 02004FEA
	v_fma_mixhi_f16 v84, v235, s39, 0                          // 0000001F9220: CC220054 02004FEB
	v_fma_mixhi_f16 v86, v239, s39, 0                          // 0000001F9228: CC220056 02004FEF
	v_fma_mixlo_f16 v88, v91, s39, 0                           // 0000001F9230: CC210058 02004F5B
	v_fma_mixlo_f16 v91, v97, s39, 0                           // 0000001F9238: CC21005B 02004F61
	v_fma_mixhi_f16 v91, v98, s39, 0                           // 0000001F9240: CC22005B 02004F62
	v_fma_mixlo_f16 v97, v216, s39, 0                          // 0000001F9248: CC210061 02004FD8
	v_fma_mixhi_f16 v97, v217, s39, 0                          // 0000001F9250: CC220061 02004FD9
	v_fma_mixlo_f16 v98, v218, s39, 0                          // 0000001F9258: CC210062 02004FDA
	v_fma_mixhi_f16 v98, v219, s39, 0                          // 0000001F9260: CC220062 02004FDB
	s_waitcnt lgkmcnt(3)                                       // 0000001F9268: BF89FC37
	v_fma_mixlo_f16 v103, v103, s39, 0                         // 0000001F926C: CC210067 02004F67
	v_fma_mixhi_f16 v103, v104, s39, 0                         // 0000001F9274: CC220067 02004F68
	v_fma_mixlo_f16 v104, v105, s39, 0                         // 0000001F927C: CC210068 02004F69
	v_fma_mixhi_f16 v104, v106, s39, 0                         // 0000001F9284: CC220068 02004F6A
	s_waitcnt lgkmcnt(2)                                       // 0000001F928C: BF89FC27
	v_fma_mixlo_f16 v216, v118, s39, 0                         // 0000001F9290: CC2100D8 02004F76
	v_fma_mixhi_f16 v216, v119, s39, 0                         // 0000001F9298: CC2200D8 02004F77
	v_fma_mixlo_f16 v217, v120, s39, 0                         // 0000001F92A0: CC2100D9 02004F78
	v_fma_mixhi_f16 v217, v121, s39, 0                         // 0000001F92A8: CC2200D9 02004F79
	ds_load_b128 v[118:121], v137 offset:256                   // 0000001F92B0: DBFC0100 76000089
	s_waitcnt vmcnt(8)                                         // 0000001F92B8: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[81:88], v[25:32]// 0000001F92BC: CC404019 1C66A349
	ds_load_b128 v[81:84], v137 offset:8704                    // 0000001F92C4: DBFC2200 51000089
	ds_load_b128 v[85:88], v137 offset:8720                    // 0000001F92CC: DBFC2210 55000089
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[97:104], v[17:24]// 0000001F92D4: CC404011 1C46C349
	ds_load_b128 v[102:105], v137 offset:8736                  // 0000001F92DC: DBFC2220 66000089
	s_mul_i32 s0, s40, 48                                      // 0000001F92E4: 9600B028
	s_mul_hi_u32 s14, s40, 48                                  // 0000001F92E8: 968EB028
	s_add_u32 s42, s0, s2                                      // 0000001F92EC: 802A0200
	s_addc_u32 s43, s14, s3                                    // 0000001F92F0: 822B030E
	v_fma_mixlo_f16 v218, v228, s39, 0                         // 0000001F92F4: CC2100DA 02004FE4
	s_lshl_b64 s[42:43], s[42:43], 13                          // 0000001F92FC: 84AA8D2A
	v_fma_mixhi_f16 v218, v229, s39, 0                         // 0000001F9300: CC2200DA 02004FE5
	.long 0xd700006a                                           // 0000001F9308: D700006A
	v_cndmask_b32_e32 v0, v184, v42, vcc_lo                    // 0000001F930C: 020055B8
	v_fma_mixlo_f16 v219, v230, s39, 0                         // 0000001F9310: CC2100DB 02004FE6
	v_fma_mixhi_f16 v219, v231, s39, 0                         // 0000001F9318: CC2200DB 02004FE7
	s_waitcnt lgkmcnt(5)                                       // 0000001F9320: BF89FC57
	v_fma_mixlo_f16 v220, v220, s39, 0                         // 0000001F9324: CC2100DC 02004FDC
	v_fma_mixhi_f16 v220, v221, s39, 0                         // 0000001F932C: CC2200DC 02004FDD
	v_fma_mixlo_f16 v221, v222, s39, 0                         // 0000001F9334: CC2100DD 02004FDE
	v_fma_mixhi_f16 v221, v223, s39, 0                         // 0000001F933C: CC2200DD 02004FDF
	s_waitcnt lgkmcnt(4)                                       // 0000001F9344: BF89FC47
	v_fma_mixlo_f16 v222, v224, s39, 0                         // 0000001F9348: CC2100DE 02004FE0
	v_fma_mixhi_f16 v222, v225, s39, 0                         // 0000001F9350: CC2200DE 02004FE1
	v_fma_mixlo_f16 v223, v226, s39, 0                         // 0000001F9358: CC2100DF 02004FE2
	v_fma_mixhi_f16 v223, v227, s39, 0                         // 0000001F9360: CC2200DF 02004FE3
	v_add_co_ci_u32_e64 v107, null, s43, v185, s0              // 0000001F9368: D5207C6B 0003722B
	ds_load_b128 v[228:231], v137 offset:272                   // 0000001F9370: DBFC0110 E4000089
	v_wmma_f32_16x16x16_f16 v[9:16], v[73:80], v[89:96], v[9:16]// 0000001F9378: CC404009 1C26B349
	v_wmma_f32_16x16x16_f16 v[1:8], v[73:80], v[216:223], v[1:8]// 0000001F9380: CC404001 1C07B149
	s_clause 0x1                                               // 0000001F9388: BF850001
	global_load_b128 v[220:223], v[106:107], off offset:16     // 0000001F938C: DC5E0010 DC7C006A
	global_load_b128 v[216:219], v[106:107], off               // 0000001F9394: DC5E0000 D87C006A
	s_waitcnt lgkmcnt(4)                                       // 0000001F939C: BF89FC47
	v_fma_mixlo_f16 v73, v118, s39, 0                          // 0000001F93A0: CC210049 02004F76
	v_fma_mixhi_f16 v73, v119, s39, 0                          // 0000001F93A8: CC220049 02004F77
	v_fma_mixlo_f16 v74, v120, s39, 0                          // 0000001F93B0: CC21004A 02004F78
	v_fma_mixhi_f16 v74, v121, s39, 0                          // 0000001F93B8: CC22004A 02004F79
	s_waitcnt lgkmcnt(3)                                       // 0000001F93C0: BF89FC37
	v_fma_mixlo_f16 v81, v81, s39, 0                           // 0000001F93C4: CC210051 02004F51
	v_fma_mixhi_f16 v81, v82, s39, 0                           // 0000001F93CC: CC220051 02004F52
	v_fma_mixlo_f16 v82, v83, s39, 0                           // 0000001F93D4: CC210052 02004F53
	ds_load_b128 v[118:121], v137 offset:8752                  // 0000001F93DC: DBFC2230 76000089
	s_waitcnt lgkmcnt(3)                                       // 0000001F93E4: BF89FC37
	v_fma_mixlo_f16 v83, v85, s39, 0                           // 0000001F93E8: CC210053 02004F55
	v_fma_mixhi_f16 v83, v86, s39, 0                           // 0000001F93F0: CC220053 02004F56
	s_waitcnt lgkmcnt(2)                                       // 0000001F93F8: BF89FC27
	v_fma_mixlo_f16 v85, v102, s39, 0                          // 0000001F93FC: CC210055 02004F66
	v_fma_mixhi_f16 v85, v103, s39, 0                          // 0000001F9404: CC220055 02004F67
	v_fma_mixlo_f16 v86, v104, s39, 0                          // 0000001F940C: CC210056 02004F68
	s_clause 0x3                                               // 0000001F9414: BF850003
	global_load_b128 v[101:104], v[106:107], off offset:80     // 0000001F9418: DC5E0050 657C006A
	global_load_b128 v[97:100], v[106:107], off offset:64      // 0000001F9420: DC5E0040 617C006A
	global_load_b128 v[93:96], v[106:107], off offset:112      // 0000001F9428: DC5E0070 5D7C006A
	global_load_b128 v[89:92], v[106:107], off offset:96       // 0000001F9430: DC5E0060 597C006A
	ds_load_b128 v[232:235], v137 offset:288                   // 0000001F9438: DBFC0120 E8000089
	ds_load_b128 v[236:239], v137 offset:304                   // 0000001F9440: DBFC0130 EC000089
	s_waitcnt lgkmcnt(3)                                       // 0000001F9448: BF89FC37
	v_fma_mixlo_f16 v75, v228, s39, 0                          // 0000001F944C: CC21004B 02004FE4
	v_fma_mixhi_f16 v75, v229, s39, 0                          // 0000001F9454: CC22004B 02004FE5
	v_fma_mixlo_f16 v76, v230, s39, 0                          // 0000001F945C: CC21004C 02004FE6
	v_fma_mixhi_f16 v76, v231, s39, 0                          // 0000001F9464: CC22004C 02004FE7
	v_fma_mixhi_f16 v82, v84, s39, 0                           // 0000001F946C: CC220052 02004F54
	ds_load_b128 v[224:227], v137 offset:17152                 // 0000001F9474: DBFC4300 E0000089
	ds_load_b128 v[228:231], v137 offset:17168                 // 0000001F947C: DBFC4310 E4000089
	v_fma_mixlo_f16 v84, v87, s39, 0                           // 0000001F9484: CC210054 02004F57
	v_fma_mixhi_f16 v84, v88, s39, 0                           // 0000001F948C: CC220054 02004F58
	ds_load_b128 v[240:243], v137 offset:25616                 // 0000001F9494: DBFC6410 F0000089
	ds_load_b128 v[244:247], v137 offset:25632                 // 0000001F949C: DBFC6420 F4000089
	ds_load_b128 v[248:251], v137 offset:25648                 // 0000001F94A4: DBFC6430 F8000089
	s_waitcnt lgkmcnt(7)                                       // 0000001F94AC: BF89FC77
	v_fma_mixlo_f16 v87, v118, s39, 0                          // 0000001F94B0: CC210057 02004F76
	v_fma_mixhi_f16 v87, v119, s39, 0                          // 0000001F94B8: CC220057 02004F77
	v_fma_mixlo_f16 v88, v120, s39, 0                          // 0000001F94C0: CC210058 02004F78
	v_fma_mixhi_f16 v88, v121, s39, 0                          // 0000001F94C8: CC220058 02004F79
	ds_load_b128 v[118:121], v137 offset:25600                 // 0000001F94D0: DBFC6400 76000089
	v_fma_mixhi_f16 v86, v105, s39, 0                          // 0000001F94D8: CC220056 02004F69
	s_waitcnt lgkmcnt(7)                                       // 0000001F94E0: BF89FC77
	v_fma_mixlo_f16 v77, v232, s39, 0                          // 0000001F94E4: CC21004D 02004FE8
	v_fma_mixhi_f16 v77, v233, s39, 0                          // 0000001F94EC: CC22004D 02004FE9
	v_fma_mixlo_f16 v78, v234, s39, 0                          // 0000001F94F4: CC21004E 02004FEA
	v_fma_mixhi_f16 v78, v235, s39, 0                          // 0000001F94FC: CC22004E 02004FEB
	ds_load_b128 v[232:235], v137 offset:17184                 // 0000001F9504: DBFC4320 E8000089
	s_waitcnt lgkmcnt(7)                                       // 0000001F950C: BF89FC77
	v_fma_mixlo_f16 v79, v236, s39, 0                          // 0000001F9510: CC21004F 02004FEC
	v_fma_mixhi_f16 v79, v237, s39, 0                          // 0000001F9518: CC22004F 02004FED
	v_fma_mixlo_f16 v80, v238, s39, 0                          // 0000001F9520: CC210050 02004FEE
	v_fma_mixhi_f16 v80, v239, s39, 0                          // 0000001F9528: CC220050 02004FEF
	ds_load_b128 v[236:239], v137 offset:17200                 // 0000001F9530: DBFC4330 EC000089
	s_waitcnt lgkmcnt(7)                                       // 0000001F9538: BF89FC77
	v_fma_mixlo_f16 v224, v224, s39, 0                         // 0000001F953C: CC2100E0 02004FE0
	v_fma_mixhi_f16 v224, v225, s39, 0                         // 0000001F9544: CC2200E0 02004FE1
	v_fma_mixlo_f16 v225, v226, s39, 0                         // 0000001F954C: CC2100E1 02004FE2
	s_waitcnt lgkmcnt(6)                                       // 0000001F9554: BF89FC67
	v_fma_mixlo_f16 v226, v228, s39, 0                         // 0000001F9558: CC2100E2 02004FE4
	v_fma_mixhi_f16 v225, v227, s39, 0                         // 0000001F9560: CC2200E1 02004FE3
	v_fma_mixhi_f16 v226, v229, s39, 0                         // 0000001F9568: CC2200E2 02004FE5
	v_fma_mixlo_f16 v227, v230, s39, 0                         // 0000001F9570: CC2100E3 02004FE6
	v_fma_mixhi_f16 v227, v231, s39, 0                         // 0000001F9578: CC2200E3 02004FE7
	s_waitcnt vmcnt(12)                                        // 0000001F9580: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[73:80], v[25:32]// 0000001F9584: CC404019 1C669339
	ds_load_b128 v[73:76], v137 offset:368                     // 0000001F958C: DBFC0170 49000089
	v_wmma_f32_16x16x16_f16 v[9:16], v[57:64], v[81:88], v[9:16]// 0000001F9594: CC404009 1C26A339
	ds_load_b128 v[77:80], v137 offset:8768                    // 0000001F959C: DBFC2240 4D000089
	ds_load_b128 v[81:84], v137 offset:8784                    // 0000001F95A4: DBFC2250 51000089
	ds_load_b128 v[85:88], v137 offset:8800                    // 0000001F95AC: DBFC2260 55000089
	s_waitcnt lgkmcnt(5)                                       // 0000001F95B4: BF89FC57
	v_fma_mixlo_f16 v228, v232, s39, 0                         // 0000001F95B8: CC2100E4 02004FE8
	v_fma_mixhi_f16 v228, v233, s39, 0                         // 0000001F95C0: CC2200E4 02004FE9
	v_fma_mixlo_f16 v232, v118, s39, 0                         // 0000001F95C8: CC2100E8 02004F76
	v_fma_mixhi_f16 v232, v119, s39, 0                         // 0000001F95D0: CC2200E8 02004F77
	v_fma_mixlo_f16 v233, v120, s39, 0                         // 0000001F95D8: CC2100E9 02004F78
	v_fma_mixhi_f16 v233, v121, s39, 0                         // 0000001F95E0: CC2200E9 02004F79
	ds_load_b128 v[118:121], v137 offset:320                   // 0000001F95E8: DBFC0140 76000089
	v_fma_mixlo_f16 v229, v234, s39, 0                         // 0000001F95F0: CC2100E5 02004FEA
	v_fma_mixhi_f16 v229, v235, s39, 0                         // 0000001F95F8: CC2200E5 02004FEB
	s_waitcnt lgkmcnt(5)                                       // 0000001F9600: BF89FC57
	v_fma_mixlo_f16 v230, v236, s39, 0                         // 0000001F9604: CC2100E6 02004FEC
	v_fma_mixhi_f16 v230, v237, s39, 0                         // 0000001F960C: CC2200E6 02004FED
	v_fma_mixlo_f16 v231, v238, s39, 0                         // 0000001F9614: CC2100E7 02004FEE
	v_fma_mixhi_f16 v231, v239, s39, 0                         // 0000001F961C: CC2200E7 02004FEF
	v_fma_mixlo_f16 v234, v240, s39, 0                         // 0000001F9624: CC2100EA 02004FF0
	v_fma_mixhi_f16 v234, v241, s39, 0                         // 0000001F962C: CC2200EA 02004FF1
	v_fma_mixlo_f16 v235, v242, s39, 0                         // 0000001F9634: CC2100EB 02004FF2
	v_fma_mixhi_f16 v235, v243, s39, 0                         // 0000001F963C: CC2200EB 02004FF3
	v_fma_mixlo_f16 v236, v244, s39, 0                         // 0000001F9644: CC2100EC 02004FF4
	v_fma_mixhi_f16 v236, v245, s39, 0                         // 0000001F964C: CC2200EC 02004FF5
	v_fma_mixlo_f16 v237, v246, s39, 0                         // 0000001F9654: CC2100ED 02004FF6
	v_fma_mixhi_f16 v237, v247, s39, 0                         // 0000001F965C: CC2200ED 02004FF7
	v_fma_mixlo_f16 v238, v248, s39, 0                         // 0000001F9664: CC2100EE 02004FF8
	v_fma_mixhi_f16 v238, v249, s39, 0                         // 0000001F966C: CC2200EE 02004FF9
	v_fma_mixlo_f16 v239, v250, s39, 0                         // 0000001F9674: CC2100EF 02004FFA
	v_fma_mixhi_f16 v239, v251, s39, 0                         // 0000001F967C: CC2200EF 02004FFB
	ds_load_b128 v[240:243], v137 offset:336                   // 0000001F9684: DBFC0150 F0000089
	ds_load_b128 v[244:247], v137 offset:352                   // 0000001F968C: DBFC0160 F4000089
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[224:231], v[17:24]// 0000001F9694: CC404011 1C47C139
	ds_load_b128 v[224:227], v137 offset:17216                 // 0000001F969C: DBFC4340 E0000089
	ds_load_b128 v[228:231], v137 offset:17232                 // 0000001F96A4: DBFC4350 E4000089
	v_wmma_f32_16x16x16_f16 v[1:8], v[57:64], v[232:239], v[1:8]// 0000001F96AC: CC404001 1C07D139
	s_waitcnt lgkmcnt(4)                                       // 0000001F96B4: BF89FC47
	v_fma_mixlo_f16 v57, v118, s39, 0                          // 0000001F96B8: CC210039 02004F76
	v_fma_mixhi_f16 v57, v119, s39, 0                          // 0000001F96C0: CC220039 02004F77
	v_fma_mixlo_f16 v58, v120, s39, 0                          // 0000001F96C8: CC21003A 02004F78
	v_fma_mixhi_f16 v58, v121, s39, 0                          // 0000001F96D0: CC22003A 02004F79
	ds_load_b128 v[118:121], v137 offset:8816                  // 0000001F96D8: DBFC2270 76000089
	ds_load_b128 v[232:235], v137 offset:17248                 // 0000001F96E0: DBFC4360 E8000089
	ds_load_b128 v[236:239], v137 offset:17264                 // 0000001F96E8: DBFC4370 EC000089
	v_fma_mixhi_f16 v63, v74, s39, 0                           // 0000001F96F0: CC22003F 02004F4A
	v_fma_mixlo_f16 v74, v79, s39, 0                           // 0000001F96F8: CC21004A 02004F4F
	v_fma_mixhi_f16 v74, v80, s39, 0                           // 0000001F9700: CC22004A 02004F50
	v_fma_mixlo_f16 v63, v73, s39, 0                           // 0000001F9708: CC21003F 02004F49
	v_fma_mixhi_f16 v64, v76, s39, 0                           // 0000001F9710: CC220040 02004F4C
	v_fma_mixlo_f16 v73, v77, s39, 0                           // 0000001F9718: CC210049 02004F4D
	v_fma_mixhi_f16 v76, v84, s39, 0                           // 0000001F9720: CC22004C 02004F54
	s_waitcnt lgkmcnt(6)                                       // 0000001F9728: BF89FC67
	v_fma_mixlo_f16 v59, v240, s39, 0                          // 0000001F972C: CC21003B 02004FF0
	v_fma_mixhi_f16 v59, v241, s39, 0                          // 0000001F9734: CC22003B 02004FF1
	v_fma_mixlo_f16 v60, v242, s39, 0                          // 0000001F973C: CC21003C 02004FF2
	v_fma_mixhi_f16 v60, v243, s39, 0                          // 0000001F9744: CC22003C 02004FF3
	s_waitcnt lgkmcnt(5)                                       // 0000001F974C: BF89FC57
	v_fma_mixlo_f16 v61, v244, s39, 0                          // 0000001F9750: CC21003D 02004FF4
	v_fma_mixhi_f16 v61, v245, s39, 0                          // 0000001F9758: CC22003D 02004FF5
	v_fma_mixlo_f16 v62, v246, s39, 0                          // 0000001F9760: CC21003E 02004FF6
	v_fma_mixhi_f16 v62, v247, s39, 0                          // 0000001F9768: CC22003E 02004FF7
	v_fma_mixlo_f16 v77, v85, s39, 0                           // 0000001F9770: CC21004D 02004F55
	ds_load_b128 v[240:243], v137 offset:25680                 // 0000001F9778: DBFC6450 F0000089
	s_waitcnt lgkmcnt(3)                                       // 0000001F9780: BF89FC37
	v_fma_mixlo_f16 v79, v118, s39, 0                          // 0000001F9784: CC21004F 02004F76
	v_fma_mixhi_f16 v79, v119, s39, 0                          // 0000001F978C: CC22004F 02004F77
	v_fma_mixlo_f16 v80, v120, s39, 0                          // 0000001F9794: CC210050 02004F78
	v_fma_mixhi_f16 v80, v121, s39, 0                          // 0000001F979C: CC220050 02004F79
	ds_load_b128 v[118:121], v137 offset:25664                 // 0000001F97A4: DBFC6440 76000089
	v_fma_mixlo_f16 v84, v230, s39, 0                          // 0000001F97AC: CC210054 02004FE6
	ds_load_b128 v[244:247], v137 offset:25696                 // 0000001F97B4: DBFC6460 F4000089
	v_fma_mixhi_f16 v84, v231, s39, 0                          // 0000001F97BC: CC220054 02004FE7
	s_waitcnt lgkmcnt(4)                                       // 0000001F97C4: BF89FC47
	v_fma_mixlo_f16 v85, v232, s39, 0                          // 0000001F97C8: CC210055 02004FE8
	v_fma_mixhi_f16 v85, v233, s39, 0                          // 0000001F97D0: CC220055 02004FE9
	ds_load_b128 v[230:233], v137 offset:25712                 // 0000001F97D8: DBFC6470 E6000089
	v_fma_mixlo_f16 v64, v75, s39, 0                           // 0000001F97E0: CC210040 02004F4B
	v_fma_mixlo_f16 v75, v81, s39, 0                           // 0000001F97E8: CC21004B 02004F51
	v_fma_mixlo_f16 v81, v224, s39, 0                          // 0000001F97F0: CC210051 02004FE0
	v_fma_mixhi_f16 v81, v225, s39, 0                          // 0000001F97F8: CC220051 02004FE1
	v_fma_mixhi_f16 v73, v78, s39, 0                           // 0000001F9800: CC220049 02004F4E
	v_fma_mixhi_f16 v75, v82, s39, 0                           // 0000001F9808: CC22004B 02004F52
	v_fma_mixlo_f16 v76, v83, s39, 0                           // 0000001F9810: CC21004C 02004F53
	v_fma_mixhi_f16 v77, v86, s39, 0                           // 0000001F9818: CC22004D 02004F56
	v_fma_mixlo_f16 v78, v87, s39, 0                           // 0000001F9820: CC21004E 02004F57
	v_fma_mixhi_f16 v78, v88, s39, 0                           // 0000001F9828: CC22004E 02004F58
	v_fma_mixlo_f16 v82, v226, s39, 0                          // 0000001F9830: CC210052 02004FE2
	v_fma_mixhi_f16 v82, v227, s39, 0                          // 0000001F9838: CC220052 02004FE3
	v_fma_mixlo_f16 v83, v228, s39, 0                          // 0000001F9840: CC210053 02004FE4
	s_waitcnt lgkmcnt(2)                                       // 0000001F9848: BF89FC27
	v_fma_mixlo_f16 v224, v118, s39, 0                         // 0000001F984C: CC2100E0 02004F76
	v_fma_mixhi_f16 v224, v119, s39, 0                         // 0000001F9854: CC2200E0 02004F77
	v_fma_mixlo_f16 v225, v120, s39, 0                         // 0000001F985C: CC2100E1 02004F78
	v_fma_mixhi_f16 v225, v121, s39, 0                         // 0000001F9864: CC2200E1 02004F79
	ds_load_b128 v[118:121], v137 offset:384                   // 0000001F986C: DBFC0180 76000089
	v_fma_mixhi_f16 v83, v229, s39, 0                          // 0000001F9874: CC220053 02004FE5
	v_fma_mixlo_f16 v86, v234, s39, 0                          // 0000001F987C: CC210056 02004FEA
	v_fma_mixhi_f16 v86, v235, s39, 0                          // 0000001F9884: CC220056 02004FEB
	v_fma_mixlo_f16 v87, v236, s39, 0                          // 0000001F988C: CC210057 02004FEC
	v_fma_mixhi_f16 v87, v237, s39, 0                          // 0000001F9894: CC220057 02004FED
	v_fma_mixlo_f16 v88, v238, s39, 0                          // 0000001F989C: CC210058 02004FEE
	v_fma_mixhi_f16 v88, v239, s39, 0                          // 0000001F98A4: CC220058 02004FEF
	v_fma_mixlo_f16 v226, v240, s39, 0                         // 0000001F98AC: CC2100E2 02004FF0
	v_fma_mixhi_f16 v226, v241, s39, 0                         // 0000001F98B4: CC2200E2 02004FF1
	v_fma_mixlo_f16 v227, v242, s39, 0                         // 0000001F98BC: CC2100E3 02004FF2
	v_fma_mixhi_f16 v227, v243, s39, 0                         // 0000001F98C4: CC2200E3 02004FF3
	s_waitcnt lgkmcnt(2)                                       // 0000001F98CC: BF89FC27
	v_fma_mixlo_f16 v228, v244, s39, 0                         // 0000001F98D0: CC2100E4 02004FF4
	v_fma_mixhi_f16 v228, v245, s39, 0                         // 0000001F98D8: CC2200E4 02004FF5
	v_fma_mixlo_f16 v229, v246, s39, 0                         // 0000001F98E0: CC2100E5 02004FF6
	v_fma_mixhi_f16 v229, v247, s39, 0                         // 0000001F98E8: CC2200E5 02004FF7
	s_waitcnt lgkmcnt(1)                                       // 0000001F98F0: BF89FC17
	v_fma_mixlo_f16 v230, v230, s39, 0                         // 0000001F98F4: CC2100E6 02004FE6
	v_fma_mixhi_f16 v230, v231, s39, 0                         // 0000001F98FC: CC2200E6 02004FE7
	v_fma_mixlo_f16 v231, v232, s39, 0                         // 0000001F9904: CC2100E7 02004FE8
	v_fma_mixhi_f16 v231, v233, s39, 0                         // 0000001F990C: CC2200E7 02004FE9
	ds_load_b128 v[234:237], v137 offset:400                   // 0000001F9914: DBFC0190 EA000089
	ds_load_b128 v[238:241], v137 offset:416                   // 0000001F991C: DBFC01A0 EE000089
	s_waitcnt vmcnt(10)                                        // 0000001F9924: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[57:64], v[25:32]// 0000001F9928: CC404019 1C667331
	ds_load_b128 v[57:60], v137 offset:432                     // 0000001F9930: DBFC01B0 39000089
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[73:80], v[9:16]// 0000001F9938: CC404009 1C269331
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[81:88], v[17:24]// 0000001F9940: CC404011 1C46A331
	v_wmma_f32_16x16x16_f16 v[1:8], v[49:56], v[224:231], v[1:8]// 0000001F9948: CC404001 1C07C131
	ds_load_b128 v[61:64], v137 offset:8832                    // 0000001F9950: DBFC2280 3D000089
	ds_load_b128 v[73:76], v137 offset:8848                    // 0000001F9958: DBFC2290 49000089
	s_waitcnt lgkmcnt(5)                                       // 0000001F9960: BF89FC57
	v_fma_mixlo_f16 v49, v118, s39, 0                          // 0000001F9964: CC210031 02004F76
	v_fma_mixhi_f16 v49, v119, s39, 0                          // 0000001F996C: CC220031 02004F77
	v_fma_mixlo_f16 v50, v120, s39, 0                          // 0000001F9974: CC210032 02004F78
	v_fma_mixhi_f16 v50, v121, s39, 0                          // 0000001F997C: CC220032 02004F79
	ds_load_b128 v[77:80], v137 offset:8864                    // 0000001F9984: DBFC22A0 4D000089
	ds_load_b128 v[81:84], v137 offset:8880                    // 0000001F998C: DBFC22B0 51000089
	ds_load_b128 v[85:88], v137 offset:17280                   // 0000001F9994: DBFC4380 55000089
	ds_load_b128 v[118:121], v137 offset:17296                 // 0000001F999C: DBFC4390 76000089
	ds_load_b128 v[224:227], v137 offset:17312                 // 0000001F99A4: DBFC43A0 E0000089
	ds_load_b128 v[228:231], v137 offset:17328                 // 0000001F99AC: DBFC43B0 E4000089
	ds_load_b128 v[247:250], v137 offset:25824                 // 0000001F99B4: DBFC64E0 F7000089
	ds_load_b128 v[251:254], v137 offset:25840                 // 0000001F99BC: DBFC64F0 FB000089
	s_waitcnt lgkmcnt(12)                                      // 0000001F99C4: BF89FCC7
	v_fma_mixlo_f16 v51, v234, s39, 0                          // 0000001F99C8: CC210033 02004FEA
	v_fma_mixhi_f16 v51, v235, s39, 0                          // 0000001F99D0: CC220033 02004FEB
	s_waitcnt lgkmcnt(10)                                      // 0000001F99D8: BF89FCA7
	v_fma_mixhi_f16 v55, v58, s39, 0                           // 0000001F99DC: CC220037 02004F3A
	v_fma_mixlo_f16 v56, v59, s39, 0                           // 0000001F99E4: CC210038 02004F3B
	v_fma_mixhi_f16 v56, v60, s39, 0                           // 0000001F99EC: CC220038 02004F3C
	ds_load_b128 v[232:235], v137 offset:25744                 // 0000001F99F4: DBFC6490 E8000089
	s_waitcnt lgkmcnt(10)                                      // 0000001F99FC: BF89FCA7
	v_fma_mixlo_f16 v58, v63, s39, 0                           // 0000001F9A00: CC21003A 02004F3F
	v_fma_mixhi_f16 v58, v64, s39, 0                           // 0000001F9A08: CC22003A 02004F40
	s_waitcnt lgkmcnt(9)                                       // 0000001F9A10: BF89FC97
	v_fma_mixlo_f16 v59, v73, s39, 0                           // 0000001F9A14: CC21003B 02004F49
	v_fma_mixhi_f16 v59, v74, s39, 0                           // 0000001F9A1C: CC22003B 02004F4A
	v_fma_mixlo_f16 v60, v75, s39, 0                           // 0000001F9A24: CC21003C 02004F4B
	v_fma_mixhi_f16 v60, v76, s39, 0                           // 0000001F9A2C: CC22003C 02004F4C
	v_fma_mixlo_f16 v55, v57, s39, 0                           // 0000001F9A34: CC210037 02004F39
	s_waitcnt lgkmcnt(7)                                       // 0000001F9A3C: BF89FC77
	v_fma_mixlo_f16 v63, v81, s39, 0                           // 0000001F9A40: CC21003F 02004F51
	v_fma_mixhi_f16 v63, v82, s39, 0                           // 0000001F9A48: CC22003F 02004F52
	v_fma_mixlo_f16 v64, v83, s39, 0                           // 0000001F9A50: CC210040 02004F53
	v_fma_mixhi_f16 v64, v84, s39, 0                           // 0000001F9A58: CC220040 02004F54
	ds_load_b128 v[81:84], v137 offset:25728                   // 0000001F9A60: DBFC6480 51000089
	s_waitcnt lgkmcnt(7)                                       // 0000001F9A68: BF89FC77
	v_fma_mixlo_f16 v73, v85, s39, 0                           // 0000001F9A6C: CC210049 02004F55
	v_fma_mixhi_f16 v73, v86, s39, 0                           // 0000001F9A74: CC220049 02004F56
	v_fma_mixlo_f16 v74, v87, s39, 0                           // 0000001F9A7C: CC21004A 02004F57
	v_fma_mixhi_f16 v74, v88, s39, 0                           // 0000001F9A84: CC22004A 02004F58
	s_waitcnt lgkmcnt(6)                                       // 0000001F9A8C: BF89FC67
	v_fma_mixlo_f16 v75, v118, s39, 0                          // 0000001F9A90: CC21004B 02004F76
	v_fma_mixhi_f16 v75, v119, s39, 0                          // 0000001F9A98: CC22004B 02004F77
	v_fma_mixlo_f16 v76, v120, s39, 0                          // 0000001F9AA0: CC21004C 02004F78
	ds_load_b128 v[85:88], v137 offset:25760                   // 0000001F9AA8: DBFC64A0 55000089
	v_fma_mixhi_f16 v76, v121, s39, 0                          // 0000001F9AB0: CC22004C 02004F79
	ds_load_b128 v[118:121], v137 offset:25776                 // 0000001F9AB8: DBFC64B0 76000089
	v_fma_mixlo_f16 v57, v61, s39, 0                           // 0000001F9AC0: CC210039 02004F3D
	v_fma_mixlo_f16 v61, v77, s39, 0                           // 0000001F9AC8: CC21003D 02004F4D
	v_fma_mixhi_f16 v61, v78, s39, 0                           // 0000001F9AD0: CC22003D 02004F4E
	s_waitcnt lgkmcnt(7)                                       // 0000001F9AD8: BF89FC77
	v_fma_mixlo_f16 v77, v224, s39, 0                          // 0000001F9ADC: CC21004D 02004FE0
	v_fma_mixhi_f16 v77, v225, s39, 0                          // 0000001F9AE4: CC22004D 02004FE1
	v_fma_mixlo_f16 v78, v226, s39, 0                          // 0000001F9AEC: CC21004E 02004FE2
	v_fma_mixhi_f16 v78, v227, s39, 0                          // 0000001F9AF4: CC22004E 02004FE3
	ds_load_b128 v[224:227], v137 offset:448                   // 0000001F9AFC: DBFC01C0 E0000089
	v_fma_mixlo_f16 v52, v236, s39, 0                          // 0000001F9B04: CC210034 02004FEC
	s_waitcnt lgkmcnt(3)                                       // 0000001F9B0C: BF89FC37
	v_fma_mixlo_f16 v81, v81, s39, 0                           // 0000001F9B10: CC210051 02004F51
	v_fma_mixhi_f16 v81, v82, s39, 0                           // 0000001F9B18: CC220051 02004F52
	v_fma_mixlo_f16 v82, v83, s39, 0                           // 0000001F9B20: CC210052 02004F53
	v_fma_mixhi_f16 v82, v84, s39, 0                           // 0000001F9B28: CC220052 02004F54
	v_fma_mixlo_f16 v83, v232, s39, 0                          // 0000001F9B30: CC210053 02004FE8
	v_fma_mixhi_f16 v83, v233, s39, 0                          // 0000001F9B38: CC220053 02004FE9
	v_fma_mixlo_f16 v84, v234, s39, 0                          // 0000001F9B40: CC210054 02004FEA
	v_fma_mixhi_f16 v84, v235, s39, 0                          // 0000001F9B48: CC220054 02004FEB
	s_waitcnt lgkmcnt(2)                                       // 0000001F9B50: BF89FC27
	v_fma_mixlo_f16 v85, v85, s39, 0                           // 0000001F9B54: CC210055 02004F55
	v_fma_mixhi_f16 v85, v86, s39, 0                           // 0000001F9B5C: CC220055 02004F56
	v_fma_mixlo_f16 v86, v87, s39, 0                           // 0000001F9B64: CC210056 02004F57
	v_fma_mixhi_f16 v86, v88, s39, 0                           // 0000001F9B6C: CC220056 02004F58
	s_waitcnt lgkmcnt(1)                                       // 0000001F9B74: BF89FC17
	v_fma_mixlo_f16 v87, v118, s39, 0                          // 0000001F9B78: CC210057 02004F76
	ds_load_b128 v[232:235], v137 offset:480                   // 0000001F9B80: DBFC01E0 E8000089
	v_fma_mixhi_f16 v87, v119, s39, 0                          // 0000001F9B88: CC220057 02004F77
	v_fma_mixlo_f16 v88, v120, s39, 0                          // 0000001F9B90: CC210058 02004F78
	v_fma_mixhi_f16 v88, v121, s39, 0                          // 0000001F9B98: CC220058 02004F79
	ds_load_b128 v[118:121], v137 offset:496                   // 0000001F9BA0: DBFC01F0 76000089
	v_fma_mixhi_f16 v52, v237, s39, 0                          // 0000001F9BA8: CC220034 02004FED
	v_fma_mixlo_f16 v53, v238, s39, 0                          // 0000001F9BB0: CC210035 02004FEE
	v_fma_mixhi_f16 v53, v239, s39, 0                          // 0000001F9BB8: CC220035 02004FEF
	v_fma_mixlo_f16 v54, v240, s39, 0                          // 0000001F9BC0: CC210036 02004FF0
	v_fma_mixhi_f16 v54, v241, s39, 0                          // 0000001F9BC8: CC220036 02004FF1
	v_fma_mixhi_f16 v57, v62, s39, 0                           // 0000001F9BD0: CC220039 02004F3E
	v_fma_mixlo_f16 v62, v79, s39, 0                           // 0000001F9BD8: CC21003E 02004F4F
	v_fma_mixhi_f16 v62, v80, s39, 0                           // 0000001F9BE0: CC22003E 02004F50
	v_fma_mixlo_f16 v79, v228, s39, 0                          // 0000001F9BE8: CC21004F 02004FE4
	v_fma_mixhi_f16 v79, v229, s39, 0                          // 0000001F9BF0: CC22004F 02004FE5
	v_fma_mixlo_f16 v80, v230, s39, 0                          // 0000001F9BF8: CC210050 02004FE6
	v_fma_mixhi_f16 v80, v231, s39, 0                          // 0000001F9C00: CC220050 02004FE7
	ds_load_b128 v[228:231], v137 offset:464                   // 0000001F9C08: DBFC01D0 E4000089
	s_waitcnt vmcnt(8)                                         // 0000001F9C10: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[49:56], v[25:32]// 0000001F9C14: CC404019 1C666329
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[57:64], v[9:16]// 0000001F9C1C: CC404009 1C267329
	v_wmma_f32_16x16x16_f16 v[1:8], v[41:48], v[81:88], v[1:8] // 0000001F9C24: CC404001 1C06A329
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[73:80], v[17:24]// 0000001F9C2C: CC404011 1C469329
	ds_load_b128 v[49:52], v137 offset:8896                    // 0000001F9C34: DBFC22C0 31000089
	ds_load_b128 v[53:56], v137 offset:8912                    // 0000001F9C3C: DBFC22D0 35000089
	s_waitcnt lgkmcnt(5)                                       // 0000001F9C44: BF89FC57
	v_fma_mixlo_f16 v41, v224, s39, 0                          // 0000001F9C48: CC210029 02004FE0
	v_fma_mixhi_f16 v41, v225, s39, 0                          // 0000001F9C50: CC220029 02004FE1
	v_fma_mixlo_f16 v42, v226, s39, 0                          // 0000001F9C58: CC21002A 02004FE2
	v_fma_mixhi_f16 v42, v227, s39, 0                          // 0000001F9C60: CC22002A 02004FE3
	ds_load_b128 v[57:60], v137 offset:8928                    // 0000001F9C68: DBFC22E0 39000089
	ds_load_b128 v[61:64], v137 offset:8944                    // 0000001F9C70: DBFC22F0 3D000089
	s_waitcnt lgkmcnt(5)                                       // 0000001F9C78: BF89FC57
	v_fma_mixlo_f16 v47, v118, s39, 0                          // 0000001F9C7C: CC21002F 02004F76
	v_fma_mixhi_f16 v47, v119, s39, 0                          // 0000001F9C84: CC22002F 02004F77
	v_fma_mixlo_f16 v48, v120, s39, 0                          // 0000001F9C8C: CC210030 02004F78
	v_fma_mixhi_f16 v48, v121, s39, 0                          // 0000001F9C94: CC220030 02004F79
	ds_load_b128 v[73:76], v137 offset:17344                   // 0000001F9C9C: DBFC43C0 49000089
	ds_load_b128 v[77:80], v137 offset:17360                   // 0000001F9CA4: DBFC43D0 4D000089
	ds_load_b128 v[81:84], v137 offset:17376                   // 0000001F9CAC: DBFC43E0 51000089
	ds_load_b128 v[85:88], v137 offset:17392                   // 0000001F9CB4: DBFC43F0 55000089
	ds_load_b128 v[118:121], v137 offset:25792                 // 0000001F9CBC: DBFC64C0 76000089
	ds_load_b128 v[224:227], v137 offset:25808                 // 0000001F9CC4: DBFC64D0 E0000089
	s_waitcnt lgkmcnt(10)                                      // 0000001F9CCC: BF89FCA7
	v_fma_mixlo_f16 v43, v228, s39, 0                          // 0000001F9CD0: CC21002B 02004FE4
	v_fma_mixhi_f16 v43, v229, s39, 0                          // 0000001F9CD8: CC22002B 02004FE5
	v_fma_mixlo_f16 v44, v230, s39, 0                          // 0000001F9CE0: CC21002C 02004FE6
	v_fma_mixhi_f16 v44, v231, s39, 0                          // 0000001F9CE8: CC22002C 02004FE7
	v_fma_mixlo_f16 v45, v232, s39, 0                          // 0000001F9CF0: CC21002D 02004FE8
	v_fma_mixhi_f16 v45, v233, s39, 0                          // 0000001F9CF8: CC22002D 02004FE9
	v_fma_mixlo_f16 v46, v234, s39, 0                          // 0000001F9D00: CC21002E 02004FEA
	v_fma_mixhi_f16 v46, v235, s39, 0                          // 0000001F9D08: CC22002E 02004FEB
	s_waitcnt lgkmcnt(9)                                       // 0000001F9D10: BF89FC97
	v_fma_mixlo_f16 v49, v49, s39, 0                           // 0000001F9D14: CC210031 02004F31
	v_fma_mixhi_f16 v49, v50, s39, 0                           // 0000001F9D1C: CC220031 02004F32
	v_fma_mixlo_f16 v50, v51, s39, 0                           // 0000001F9D24: CC210032 02004F33
	v_fma_mixhi_f16 v50, v52, s39, 0                           // 0000001F9D2C: CC220032 02004F34
	s_waitcnt lgkmcnt(8)                                       // 0000001F9D34: BF89FC87
	v_fma_mixlo_f16 v51, v53, s39, 0                           // 0000001F9D38: CC210033 02004F35
	v_fma_mixhi_f16 v51, v54, s39, 0                           // 0000001F9D40: CC220033 02004F36
	v_fma_mixlo_f16 v52, v55, s39, 0                           // 0000001F9D48: CC210034 02004F37
	v_fma_mixhi_f16 v52, v56, s39, 0                           // 0000001F9D50: CC220034 02004F38
	s_waitcnt lgkmcnt(7)                                       // 0000001F9D58: BF89FC77
	v_fma_mixhi_f16 v53, v58, s39, 0                           // 0000001F9D5C: CC220035 02004F3A
	v_fma_mixlo_f16 v54, v59, s39, 0                           // 0000001F9D64: CC210036 02004F3B
	s_waitcnt lgkmcnt(6)                                       // 0000001F9D6C: BF89FC67
	v_fma_mixlo_f16 v55, v61, s39, 0                           // 0000001F9D70: CC210037 02004F3D
	v_fma_mixhi_f16 v55, v62, s39, 0                           // 0000001F9D78: CC220037 02004F3E
	v_fma_mixlo_f16 v56, v63, s39, 0                           // 0000001F9D80: CC210038 02004F3F
	v_fma_mixhi_f16 v56, v64, s39, 0                           // 0000001F9D88: CC220038 02004F40
	s_waitcnt lgkmcnt(5)                                       // 0000001F9D90: BF89FC57
	v_fma_mixlo_f16 v58, v75, s39, 0                           // 0000001F9D94: CC21003A 02004F4B
	v_fma_mixhi_f16 v58, v76, s39, 0                           // 0000001F9D9C: CC22003A 02004F4C
	s_waitcnt lgkmcnt(4)                                       // 0000001F9DA4: BF89FC47
	v_fma_mixlo_f16 v59, v77, s39, 0                           // 0000001F9DA8: CC21003B 02004F4D
	s_waitcnt lgkmcnt(3)                                       // 0000001F9DB0: BF89FC37
	v_fma_mixlo_f16 v61, v81, s39, 0                           // 0000001F9DB4: CC21003D 02004F51
	v_fma_mixhi_f16 v61, v82, s39, 0                           // 0000001F9DBC: CC22003D 02004F52
	v_fma_mixlo_f16 v62, v83, s39, 0                           // 0000001F9DC4: CC21003E 02004F53
	v_fma_mixhi_f16 v62, v84, s39, 0                           // 0000001F9DCC: CC22003E 02004F54
	s_waitcnt lgkmcnt(2)                                       // 0000001F9DD4: BF89FC27
	v_fma_mixlo_f16 v63, v85, s39, 0                           // 0000001F9DD8: CC21003F 02004F55
	v_fma_mixhi_f16 v63, v86, s39, 0                           // 0000001F9DE0: CC22003F 02004F56
	v_fma_mixlo_f16 v64, v87, s39, 0                           // 0000001F9DE8: CC210040 02004F57
	v_fma_mixhi_f16 v64, v88, s39, 0                           // 0000001F9DF0: CC220040 02004F58
	s_waitcnt lgkmcnt(0)                                       // 0000001F9DF8: BF89FC07
	v_fma_mixlo_f16 v75, v224, s39, 0                          // 0000001F9DFC: CC21004B 02004FE0
	v_fma_mixhi_f16 v75, v225, s39, 0                          // 0000001F9E04: CC22004B 02004FE1
	v_fma_mixlo_f16 v76, v226, s39, 0                          // 0000001F9E0C: CC21004C 02004FE2
	v_fma_mixhi_f16 v76, v227, s39, 0                          // 0000001F9E14: CC22004C 02004FE3
	v_fma_mixlo_f16 v77, v247, s39, 0                          // 0000001F9E1C: CC21004D 02004FF7
	ds_load_b128 v[81:84], v139                                // 0000001F9E24: DBFC0000 5100008B
	ds_load_b128 v[85:88], v139 offset:16                      // 0000001F9E2C: DBFC0010 5500008B
	ds_load_b128 v[228:231], v139 offset:2320                  // 0000001F9E34: DBFC0910 E400008B
	ds_load_b128 v[224:227], v139 offset:2304                  // 0000001F9E3C: DBFC0900 E000008B
	ds_load_b128 v[236:239], v139 offset:4624                  // 0000001F9E44: DBFC1210 EC00008B
	ds_load_b128 v[232:235], v139 offset:4608                  // 0000001F9E4C: DBFC1200 E800008B
	ds_load_b128 v[244:247], v139 offset:6928                  // 0000001F9E54: DBFC1B10 F400008B
	ds_load_b128 v[240:243], v139 offset:6912                  // 0000001F9E5C: DBFC1B00 F000008B
	v_fma_mixlo_f16 v53, v57, s39, 0                           // 0000001F9E64: CC210035 02004F39
	v_fma_mixhi_f16 v54, v60, s39, 0                           // 0000001F9E6C: CC220036 02004F3C
	v_fma_mixlo_f16 v57, v73, s39, 0                           // 0000001F9E74: CC210039 02004F49
	v_fma_mixhi_f16 v57, v74, s39, 0                           // 0000001F9E7C: CC220039 02004F4A
	v_fma_mixhi_f16 v59, v78, s39, 0                           // 0000001F9E84: CC22003B 02004F4E
	v_fma_mixlo_f16 v60, v79, s39, 0                           // 0000001F9E8C: CC21003C 02004F4F
	v_fma_mixhi_f16 v60, v80, s39, 0                           // 0000001F9E94: CC22003C 02004F50
	v_fma_mixlo_f16 v73, v118, s39, 0                          // 0000001F9E9C: CC210049 02004F76
	v_fma_mixhi_f16 v73, v119, s39, 0                          // 0000001F9EA4: CC220049 02004F77
	v_fma_mixlo_f16 v74, v120, s39, 0                          // 0000001F9EAC: CC21004A 02004F78
	v_fma_mixhi_f16 v74, v121, s39, 0                          // 0000001F9EB4: CC22004A 02004F79
	v_fma_mixhi_f16 v77, v248, s39, 0                          // 0000001F9EBC: CC22004D 02004FF8
	v_fma_mixlo_f16 v78, v249, s39, 0                          // 0000001F9EC4: CC21004E 02004FF9
	v_fma_mixhi_f16 v78, v250, s39, 0                          // 0000001F9ECC: CC22004E 02004FFA
	v_fma_mixlo_f16 v79, v251, s39, 0                          // 0000001F9ED4: CC21004F 02004FFB
	v_fma_mixhi_f16 v79, v252, s39, 0                          // 0000001F9EDC: CC22004F 02004FFC
	v_fma_mixlo_f16 v80, v253, s39, 0                          // 0000001F9EE4: CC210050 02004FFD
	v_fma_mixhi_f16 v80, v254, s39, 0                          // 0000001F9EEC: CC220050 02004FFE
	s_waitcnt vmcnt(6)                                         // 0000001F9EF4: BF891BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[41:48], v[25:32]// 0000001F9EF8: CC404019 1C665321
	v_wmma_f32_16x16x16_f16 v[9:16], v[33:40], v[49:56], v[9:16]// 0000001F9F00: CC404009 1C266321
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 0000001F9F08: CC404011 1C467321
	s_waitcnt vmcnt(4) lgkmcnt(6)                              // 0000001F9F10: BF891067
	v_wmma_f32_16x16x16_f16 v[57:64], v[216:223], v[81:88], v[65:72]// 0000001F9F14: CC404039 1D06A3D8
	v_wmma_f32_16x16x16_f16 v[1:8], v[33:40], v[73:80], v[1:8] // 0000001F9F1C: CC404001 1C069321
	s_waitcnt lgkmcnt(4)                                       // 0000001F9F24: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[216:223], v[224:231], v[65:72]// 0000001F9F28: CC404031 1D07C1D8
	s_waitcnt lgkmcnt(2)                                       // 0000001F9F30: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[216:223], v[232:239], v[65:72]// 0000001F9F34: CC404029 1D07D1D8
	s_waitcnt lgkmcnt(0)                                       // 0000001F9F3C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[216:223], v[240:247], v[65:72]// 0000001F9F40: CC404021 1D07E1D8
	s_and_saveexec_b32 s0, s5                                  // 0000001F9F48: BE802005
	s_cbranch_execnz 1604                                      // 0000001F9F4C: BFA60644 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7160>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9F50: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000001F9F54: BE802004
	s_cbranch_execnz 1637                                      // 0000001F9F58: BFA60665 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x71f0>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9F5C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000001F9F60: BE802006
	s_cbranch_execnz 1665                                      // 0000001F9F64: BFA60681 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x726c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9F68: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001F9F6C: BE802001
	s_cbranch_execnz 1695                                      // 0000001F9F70: BFA6069F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x72f0>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9F74: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001F9F78: BE802007
	s_cbranch_execnz 1714                                      // 0000001F9F7C: BFA606B2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7348>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9F80: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001F9F84: BE802008
	s_cbranch_execnz 1733                                      // 0000001F9F88: BFA606C5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x73a0>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9F8C: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001F9F90: BE802009
	s_cbranch_execnz 1752                                      // 0000001F9F94: BFA606D8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x73f8>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9F98: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001F9F9C: BE80200A
	s_cbranch_execnz 1771                                      // 0000001F9FA0: BFA606EB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7450>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9FA4: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001F9FA8: BE80200B
	s_cbranch_execnz 1790                                      // 0000001F9FAC: BFA606FE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x74a8>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9FB0: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001F9FB4: BE80200C
	s_cbranch_execnz 1809                                      // 0000001F9FB8: BFA60711 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7500>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9FBC: 8C7E007E
	s_and_saveexec_b32 s0, s13                                 // 0000001F9FC0: BE80200D
	s_cbranch_execnz 1828                                      // 0000001F9FC4: BFA60724 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7558>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9FC8: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001F9FCC: BE802001
	s_cbranch_execnz 1846                                      // 0000001F9FD0: BFA60736 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x75ac>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9FD4: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001F9FD8: BE802007
	s_cbranch_execnz 1865                                      // 0000001F9FDC: BFA60749 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7604>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9FE0: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001F9FE4: BE802008
	s_cbranch_execnz 1884                                      // 0000001F9FE8: BFA6075C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x765c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9FEC: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001F9FF0: BE802009
	s_cbranch_execnz 1903                                      // 0000001F9FF4: BFA6076F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x76b4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001F9FF8: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001F9FFC: BE80200A
	s_cbranch_execnz 1922                                      // 0000001FA000: BFA60782 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x770c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA004: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001FA008: BE80200B
	s_cbranch_execnz 1941                                      // 0000001FA00C: BFA60795 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7764>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA010: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001FA014: BE80200C
	s_cbranch_execnz 1960                                      // 0000001FA018: BFA607A8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x77bc>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA01C: 8C7E007E
	s_and_saveexec_b32 s0, s13                                 // 0000001FA020: BE80200D
	s_cbranch_execnz 1979                                      // 0000001FA024: BFA607BB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7814>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA028: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001FA02C: BE802001
	s_cbranch_execnz 1997                                      // 0000001FA030: BFA607CD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7868>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA034: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001FA038: BE802007
	s_cbranch_execnz 2016                                      // 0000001FA03C: BFA607E0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x78c0>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA040: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001FA044: BE802008
	s_cbranch_execnz 2035                                      // 0000001FA048: BFA607F3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7918>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA04C: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001FA050: BE802009
	s_cbranch_execnz 2054                                      // 0000001FA054: BFA60806 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7970>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA058: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001FA05C: BE80200A
	s_cbranch_execnz 2073                                      // 0000001FA060: BFA60819 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x79c8>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA064: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001FA068: BE80200B
	s_cbranch_execnz 2092                                      // 0000001FA06C: BFA6082C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7a20>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA070: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001FA074: BE80200C
	s_cbranch_execnz 2111                                      // 0000001FA078: BFA6083F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7a78>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA07C: 8C7E007E
	s_and_saveexec_b32 s0, s13                                 // 0000001FA080: BE80200D
	s_cbranch_execnz 2130                                      // 0000001FA084: BFA60852 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7ad0>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA088: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001FA08C: BE802001
	s_cbranch_execnz 2148                                      // 0000001FA090: BFA60864 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7b24>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA094: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001FA098: BE802007
	s_cbranch_execnz 2167                                      // 0000001FA09C: BFA60877 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7b7c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA0A0: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001FA0A4: BE802008
	s_cbranch_execnz 2186                                      // 0000001FA0A8: BFA6088A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7bd4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA0AC: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001FA0B0: BE802009
	s_cbranch_execnz 2205                                      // 0000001FA0B4: BFA6089D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7c2c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA0B8: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001FA0BC: BE80200A
	s_cbranch_execnz 2224                                      // 0000001FA0C0: BFA608B0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7c84>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA0C4: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001FA0C8: BE80200B
	s_cbranch_execnz 2243                                      // 0000001FA0CC: BFA608C3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7cdc>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA0D0: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001FA0D4: BE80200C
	s_cbranch_execnz 2262                                      // 0000001FA0D8: BFA608D6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7d34>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA0DC: 8C7E007E
	s_and_saveexec_b32 s0, s13                                 // 0000001FA0E0: BE80200D
	s_cbranch_execnz 2281                                      // 0000001FA0E4: BFA608E9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7d8c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FA0E8: 8C7E007E
	s_add_i32 s7, s40, 1                                       // 0000001FA0EC: 81078128
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001FA0F0: BF870009
	s_cmp_ge_i32 s7, s51                                       // 0000001FA0F4: BF033307
	s_cbranch_scc1 885                                         // 0000001FA0F8: BFA20375 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67d0>
	s_clause 0x1                                               // 0000001FA0FC: BF850001
	scratch_load_b32 v1, off, off                              // 0000001FA100: DC510000 017C0000
	scratch_load_b32 v2, off, off offset:4                     // 0000001FA108: DC510004 027C0000
	s_lshl_b32 s0, s7, 6                                       // 0000001FA110: 84008607
	s_mul_i32 s8, s7, 0xc00                                    // 0000001FA114: 9608FF07 00000C00
	s_sub_i32 s1, s50, s0                                      // 0000001FA11C: 81810032
	s_mul_hi_u32 s0, s7, 0xc00                                 // 0000001FA120: 9680FF07 00000C00
	s_add_u32 s8, s8, s2                                       // 0000001FA128: 80080208
	s_addc_u32 s9, s0, s3                                      // 0000001FA12C: 82090300
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001FA130: BF870009
	s_lshl_b64 s[8:9], s[8:9], 9                               // 0000001FA134: 84888908
	s_cmp_gt_i32 s1, 0                                         // 0000001FA138: BF028001
	s_waitcnt vmcnt(1)                                         // 0000001FA13C: BF8907F7
	.long 0xd7000001                                           // 0000001FA140: D7000001
	v_cndmask_b32_e32 v0, v1, v8, vcc_lo                       // 0000001FA144: 02001101
	s_waitcnt vmcnt(0)                                         // 0000001FA148: BF8903F7
	v_add_co_ci_u32_e64 v2, null, s9, v2, s0                   // 0000001FA14C: D5207C02 00020409
	s_cselect_b32 s0, -1, 0                                    // 0000001FA154: 980080C1
	s_cmp_gt_i32 s1, 1                                         // 0000001FA158: BF028101
	v_cndmask_b32_e64 v3, v128, v1, s0                         // 0000001FA15C: D5010003 00020380
	v_cndmask_b32_e64 v4, v129, v2, s0                         // 0000001FA164: D5010004 00020581
	global_load_b32 v138, v[3:4], off                          // 0000001FA16C: DC520000 8A7C0003
	.long 0xd7000003                                           // 0000001FA174: D7000003
	v_cndmask_b32_e32 v1, 0x6000, v1, vcc_lo                   // 0000001FA178: 020202FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FA180: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001FA184: D5207C04 00020480
	.long 0xd7000005                                           // 0000001FA18C: D7000005
	v_cndmask_b32_e32 v1, 0xc000, v1, vcc_lo                   // 0000001FA190: 020202FF 0000C000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FA198: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA1A0: 980080C1
	s_cmp_gt_i32 s1, 2                                         // 0000001FA1A4: BF028201
	v_cndmask_b32_e64 v4, v129, v4, s0                         // 0000001FA1A8: D5010004 00020981
	v_cndmask_b32_e64 v3, v128, v3, s0                         // 0000001FA1B0: D5010003 00020780
	s_cselect_b32 s0, -1, 0                                    // 0000001FA1B8: 980080C1
	s_cmp_gt_i32 s1, 3                                         // 0000001FA1BC: BF028301
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FA1C0: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FA1C8: D5010005 00020B80
	.long 0xd7000007                                           // 0000001FA1D0: D7000007
	v_cndmask_b32_e32 v1, 0x12000, v1, vcc_lo                  // 0000001FA1D4: 020202FF 00012000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FA1DC: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FA1E0: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA1E8: 980080C1
	global_load_b32 v172, v[3:4], off                          // 0000001FA1EC: DC520000 AC7C0003
	global_load_b32 v154, v[5:6], off                          // 0000001FA1F4: DC520000 9A7C0005
	v_cndmask_b32_e64 v4, v129, v8, s0                         // 0000001FA1FC: D5010004 00021181
	v_cndmask_b32_e64 v3, v128, v7, s0                         // 0000001FA204: D5010003 00020F80
	.long 0xd7000005                                           // 0000001FA20C: D7000005
	v_cndmask_b32_e32 v1, 0x18000, v1, vcc_lo                  // 0000001FA210: 020202FF 00018000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FA218: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FA21C: D5207C06 00020480
	.long 0xd7000007                                           // 0000001FA224: D7000007
	v_cndmask_b32_e32 v1, 0x1e000, v1, vcc_lo                  // 0000001FA228: 020202FF 0001E000
	s_cmp_gt_i32 s1, 4                                         // 0000001FA230: BF028401
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FA234: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA23C: 980080C1
	s_cmp_gt_i32 s1, 5                                         // 0000001FA240: BF028501
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FA244: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FA24C: D5010005 00020B80
	s_cselect_b32 s0, -1, 0                                    // 0000001FA254: 980080C1
	s_cmp_gt_i32 s1, 6                                         // 0000001FA258: BF028601
	v_cndmask_b32_e64 v8, v129, v8, s0                         // 0000001FA25C: D5010008 00021181
	v_cndmask_b32_e64 v7, v128, v7, s0                         // 0000001FA264: D5010007 00020F80
	.long 0xd7000009                                           // 0000001FA26C: D7000009
	v_cndmask_b32_e32 v1, 0x24000, v1, vcc_lo                  // 0000001FA270: 020202FF 00024000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FA278: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 0000001FA27C: D5207C0A 00020480
	.long 0xd700000b                                           // 0000001FA284: D700000B
	v_cndmask_b32_e32 v1, 0x2a000, v1, vcc_lo                  // 0000001FA288: 020202FF 0002A000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 0000001FA290: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA298: 980080C1
	s_cmp_gt_i32 s1, 7                                         // 0000001FA29C: BF028701
	v_cndmask_b32_e64 v10, v129, v10, s0                       // 0000001FA2A0: D501000A 00021581
	v_cndmask_b32_e64 v9, v128, v9, s0                         // 0000001FA2A8: D5010009 00021380
	s_cselect_b32 s0, -1, 0                                    // 0000001FA2B0: 980080C1
	s_cmp_gt_i32 s1, 8                                         // 0000001FA2B4: BF028801
	v_cndmask_b32_e64 v12, v129, v12, s0                       // 0000001FA2B8: D501000C 00021981
	v_cndmask_b32_e64 v11, v128, v11, s0                       // 0000001FA2C0: D501000B 00021780
	global_load_b32 v207, v[3:4], off                          // 0000001FA2C8: DC520000 CF7C0003
	global_load_b32 v206, v[5:6], off                          // 0000001FA2D0: DC520000 CE7C0005
	global_load_b32 v205, v[7:8], off                          // 0000001FA2D8: DC520000 CD7C0007
	global_load_b32 v153, v[9:10], off                         // 0000001FA2E0: DC520000 997C0009
	global_load_b32 v171, v[11:12], off                        // 0000001FA2E8: DC520000 AB7C000B
	.long 0xd7000003                                           // 0000001FA2F0: D7000003
	v_cndmask_b32_e32 v1, 0x30000, v1, vcc_lo                  // 0000001FA2F4: 020202FF 00030000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FA2FC: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001FA300: D5207C04 00020480
	.long 0xd7000005                                           // 0000001FA308: D7000005
	v_cndmask_b32_e32 v1, 0x36000, v1, vcc_lo                  // 0000001FA30C: 020202FF 00036000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FA314: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA31C: 980080C1
	s_cmp_gt_i32 s1, 9                                         // 0000001FA320: BF028901
	v_cndmask_b32_e64 v4, v129, v4, s0                         // 0000001FA324: D5010004 00020981
	v_cndmask_b32_e64 v3, v128, v3, s0                         // 0000001FA32C: D5010003 00020780
	s_cselect_b32 s0, -1, 0                                    // 0000001FA334: 980080C1
	s_cmp_gt_i32 s1, 10                                        // 0000001FA338: BF028A01
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FA33C: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FA344: D5010005 00020B80
	.long 0xd7000007                                           // 0000001FA34C: D7000007
	v_cndmask_b32_e32 v1, 0x3c000, v1, vcc_lo                  // 0000001FA350: 020202FF 0003C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FA358: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FA35C: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA364: 980080C1
	global_load_b32 v170, v[3:4], off                          // 0000001FA368: DC520000 AA7C0003
	global_load_b32 v152, v[5:6], off                          // 0000001FA370: DC520000 987C0005
	v_cndmask_b32_e64 v4, v129, v8, s0                         // 0000001FA378: D5010004 00021181
	v_cndmask_b32_e64 v3, v128, v7, s0                         // 0000001FA380: D5010003 00020F80
	.long 0xd7000005                                           // 0000001FA388: D7000005
	v_cndmask_b32_e32 v1, 0x42000, v1, vcc_lo                  // 0000001FA38C: 020202FF 00042000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FA394: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FA398: D5207C06 00020480
	.long 0xd7000007                                           // 0000001FA3A0: D7000007
	v_cndmask_b32_e32 v1, 0x48000, v1, vcc_lo                  // 0000001FA3A4: 020202FF 00048000
	s_cmp_gt_i32 s1, 11                                        // 0000001FA3AC: BF028B01
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FA3B0: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA3B8: 980080C1
	s_cmp_gt_i32 s1, 12                                        // 0000001FA3BC: BF028C01
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FA3C0: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FA3C8: D5010005 00020B80
	s_cselect_b32 s0, -1, 0                                    // 0000001FA3D0: 980080C1
	s_cmp_gt_i32 s1, 13                                        // 0000001FA3D4: BF028D01
	v_cndmask_b32_e64 v8, v129, v8, s0                         // 0000001FA3D8: D5010008 00021181
	v_cndmask_b32_e64 v7, v128, v7, s0                         // 0000001FA3E0: D5010007 00020F80
	.long 0xd7000009                                           // 0000001FA3E8: D7000009
	v_cndmask_b32_e32 v1, 0x4e000, v1, vcc_lo                  // 0000001FA3EC: 020202FF 0004E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FA3F4: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 0000001FA3F8: D5207C0A 00020480
	.long 0xd700000b                                           // 0000001FA400: D700000B
	v_cndmask_b32_e32 v1, 0x54000, v1, vcc_lo                  // 0000001FA404: 020202FF 00054000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 0000001FA40C: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA414: 980080C1
	s_cmp_gt_i32 s1, 14                                        // 0000001FA418: BF028E01
	v_cndmask_b32_e64 v10, v129, v10, s0                       // 0000001FA41C: D501000A 00021581
	v_cndmask_b32_e64 v9, v128, v9, s0                         // 0000001FA424: D5010009 00021380
	s_cselect_b32 s0, -1, 0                                    // 0000001FA42C: 980080C1
	s_cmp_gt_i32 s1, 15                                        // 0000001FA430: BF028F01
	v_cndmask_b32_e64 v12, v129, v12, s0                       // 0000001FA434: D501000C 00021981
	v_cndmask_b32_e64 v11, v128, v11, s0                       // 0000001FA43C: D501000B 00021780
	global_load_b32 v204, v[3:4], off                          // 0000001FA444: DC520000 CC7C0003
	global_load_b32 v203, v[5:6], off                          // 0000001FA44C: DC520000 CB7C0005
	global_load_b32 v202, v[7:8], off                          // 0000001FA454: DC520000 CA7C0007
	global_load_b32 v151, v[9:10], off                         // 0000001FA45C: DC520000 977C0009
	global_load_b32 v169, v[11:12], off                        // 0000001FA464: DC520000 A97C000B
	.long 0xd7000003                                           // 0000001FA46C: D7000003
	v_cndmask_b32_e32 v1, 0x5a000, v1, vcc_lo                  // 0000001FA470: 020202FF 0005A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FA478: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001FA47C: D5207C04 00020480
	.long 0xd7000005                                           // 0000001FA484: D7000005
	v_cndmask_b32_e32 v1, 0x60000, v1, vcc_lo                  // 0000001FA488: 020202FF 00060000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FA490: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA498: 980080C1
	s_cmp_gt_i32 s1, 16                                        // 0000001FA49C: BF029001
	v_cndmask_b32_e64 v4, v129, v4, s0                         // 0000001FA4A0: D5010004 00020981
	v_cndmask_b32_e64 v3, v128, v3, s0                         // 0000001FA4A8: D5010003 00020780
	s_cselect_b32 s0, -1, 0                                    // 0000001FA4B0: 980080C1
	s_cmp_gt_i32 s1, 17                                        // 0000001FA4B4: BF029101
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FA4B8: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FA4C0: D5010005 00020B80
	.long 0xd7000007                                           // 0000001FA4C8: D7000007
	v_cndmask_b32_e32 v1, 0x66000, v1, vcc_lo                  // 0000001FA4CC: 020202FF 00066000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FA4D4: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FA4D8: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA4E0: 980080C1
	global_load_b32 v168, v[3:4], off                          // 0000001FA4E4: DC520000 A87C0003
	global_load_b32 v150, v[5:6], off                          // 0000001FA4EC: DC520000 967C0005
	v_cndmask_b32_e64 v4, v129, v8, s0                         // 0000001FA4F4: D5010004 00021181
	v_cndmask_b32_e64 v3, v128, v7, s0                         // 0000001FA4FC: D5010003 00020F80
	.long 0xd7000005                                           // 0000001FA504: D7000005
	v_cndmask_b32_e32 v1, 0x6c000, v1, vcc_lo                  // 0000001FA508: 020202FF 0006C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FA510: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FA514: D5207C06 00020480
	.long 0xd7000007                                           // 0000001FA51C: D7000007
	v_cndmask_b32_e32 v1, 0x72000, v1, vcc_lo                  // 0000001FA520: 020202FF 00072000
	s_cmp_gt_i32 s1, 18                                        // 0000001FA528: BF029201
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FA52C: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA534: 980080C1
	s_cmp_gt_i32 s1, 19                                        // 0000001FA538: BF029301
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FA53C: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FA544: D5010005 00020B80
	s_cselect_b32 s0, -1, 0                                    // 0000001FA54C: 980080C1
	s_cmp_gt_i32 s1, 20                                        // 0000001FA550: BF029401
	v_cndmask_b32_e64 v8, v129, v8, s0                         // 0000001FA554: D5010008 00021181
	v_cndmask_b32_e64 v7, v128, v7, s0                         // 0000001FA55C: D5010007 00020F80
	.long 0xd7000009                                           // 0000001FA564: D7000009
	v_cndmask_b32_e32 v1, 0x78000, v1, vcc_lo                  // 0000001FA568: 020202FF 00078000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FA570: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 0000001FA574: D5207C0A 00020480
	.long 0xd700000b                                           // 0000001FA57C: D700000B
	v_cndmask_b32_e32 v1, 0x7e000, v1, vcc_lo                  // 0000001FA580: 020202FF 0007E000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 0000001FA588: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA590: 980080C1
	s_cmp_gt_i32 s1, 21                                        // 0000001FA594: BF029501
	v_cndmask_b32_e64 v10, v129, v10, s0                       // 0000001FA598: D501000A 00021581
	v_cndmask_b32_e64 v9, v128, v9, s0                         // 0000001FA5A0: D5010009 00021380
	s_cselect_b32 s0, -1, 0                                    // 0000001FA5A8: 980080C1
	s_cmp_gt_i32 s1, 22                                        // 0000001FA5AC: BF029601
	v_cndmask_b32_e64 v12, v129, v12, s0                       // 0000001FA5B0: D501000C 00021981
	v_cndmask_b32_e64 v11, v128, v11, s0                       // 0000001FA5B8: D501000B 00021780
	global_load_b32 v201, v[3:4], off                          // 0000001FA5C0: DC520000 C97C0003
	global_load_b32 v200, v[5:6], off                          // 0000001FA5C8: DC520000 C87C0005
	global_load_b32 v199, v[7:8], off                          // 0000001FA5D0: DC520000 C77C0007
	global_load_b32 v149, v[9:10], off                         // 0000001FA5D8: DC520000 957C0009
	global_load_b32 v167, v[11:12], off                        // 0000001FA5E0: DC520000 A77C000B
	.long 0xd7000003                                           // 0000001FA5E8: D7000003
	v_cndmask_b32_e32 v1, 0x84000, v1, vcc_lo                  // 0000001FA5EC: 020202FF 00084000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FA5F4: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001FA5F8: D5207C04 00020480
	.long 0xd7000005                                           // 0000001FA600: D7000005
	v_cndmask_b32_e32 v1, 0x8a000, v1, vcc_lo                  // 0000001FA604: 020202FF 0008A000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FA60C: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA614: 980080C1
	s_cmp_gt_i32 s1, 23                                        // 0000001FA618: BF029701
	v_cndmask_b32_e64 v4, v129, v4, s0                         // 0000001FA61C: D5010004 00020981
	v_cndmask_b32_e64 v3, v128, v3, s0                         // 0000001FA624: D5010003 00020780
	s_cselect_b32 s0, -1, 0                                    // 0000001FA62C: 980080C1
	s_cmp_gt_i32 s1, 24                                        // 0000001FA630: BF029801
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FA634: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FA63C: D5010005 00020B80
	.long 0xd7000007                                           // 0000001FA644: D7000007
	v_cndmask_b32_e32 v1, 0x90000, v1, vcc_lo                  // 0000001FA648: 020202FF 00090000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FA650: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FA654: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA65C: 980080C1
	global_load_b32 v166, v[3:4], off                          // 0000001FA660: DC520000 A67C0003
	global_load_b32 v148, v[5:6], off                          // 0000001FA668: DC520000 947C0005
	v_cndmask_b32_e64 v4, v129, v8, s0                         // 0000001FA670: D5010004 00021181
	v_cndmask_b32_e64 v3, v128, v7, s0                         // 0000001FA678: D5010003 00020F80
	.long 0xd7000005                                           // 0000001FA680: D7000005
	v_cndmask_b32_e32 v1, 0x96000, v1, vcc_lo                  // 0000001FA684: 020202FF 00096000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FA68C: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FA690: D5207C06 00020480
	.long 0xd7000007                                           // 0000001FA698: D7000007
	v_cndmask_b32_e32 v1, 0x9c000, v1, vcc_lo                  // 0000001FA69C: 020202FF 0009C000
	s_cmp_gt_i32 s1, 25                                        // 0000001FA6A4: BF029901
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FA6A8: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA6B0: 980080C1
	s_cmp_gt_i32 s1, 26                                        // 0000001FA6B4: BF029A01
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FA6B8: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FA6C0: D5010005 00020B80
	s_cselect_b32 s0, -1, 0                                    // 0000001FA6C8: 980080C1
	s_cmp_gt_i32 s1, 27                                        // 0000001FA6CC: BF029B01
	v_cndmask_b32_e64 v8, v129, v8, s0                         // 0000001FA6D0: D5010008 00021181
	v_cndmask_b32_e64 v7, v128, v7, s0                         // 0000001FA6D8: D5010007 00020F80
	.long 0xd7000009                                           // 0000001FA6E0: D7000009
	v_cndmask_b32_e32 v1, 0xa2000, v1, vcc_lo                  // 0000001FA6E4: 020202FF 000A2000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FA6EC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 0000001FA6F0: D5207C0A 00020480
	.long 0xd700000b                                           // 0000001FA6F8: D700000B
	v_cndmask_b32_e32 v1, 0xa8000, v1, vcc_lo                  // 0000001FA6FC: 020202FF 000A8000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 0000001FA704: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA70C: 980080C1
	s_cmp_gt_i32 s1, 28                                        // 0000001FA710: BF029C01
	v_cndmask_b32_e64 v10, v129, v10, s0                       // 0000001FA714: D501000A 00021581
	v_cndmask_b32_e64 v9, v128, v9, s0                         // 0000001FA71C: D5010009 00021380
	s_cselect_b32 s0, -1, 0                                    // 0000001FA724: 980080C1
	s_cmp_gt_i32 s1, 29                                        // 0000001FA728: BF029D01
	v_cndmask_b32_e64 v12, v129, v12, s0                       // 0000001FA72C: D501000C 00021981
	v_cndmask_b32_e64 v11, v128, v11, s0                       // 0000001FA734: D501000B 00021780
	global_load_b32 v198, v[3:4], off                          // 0000001FA73C: DC520000 C67C0003
	global_load_b32 v197, v[5:6], off                          // 0000001FA744: DC520000 C57C0005
	global_load_b32 v196, v[7:8], off                          // 0000001FA74C: DC520000 C47C0007
	global_load_b32 v147, v[9:10], off                         // 0000001FA754: DC520000 937C0009
	global_load_b32 v165, v[11:12], off                        // 0000001FA75C: DC520000 A57C000B
	.long 0xd7000003                                           // 0000001FA764: D7000003
	v_cndmask_b32_e32 v1, 0xae000, v1, vcc_lo                  // 0000001FA768: 020202FF 000AE000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FA770: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001FA774: D5207C04 00020480
	.long 0xd7000005                                           // 0000001FA77C: D7000005
	v_cndmask_b32_e32 v1, 0xb4000, v1, vcc_lo                  // 0000001FA780: 020202FF 000B4000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FA788: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA790: 980080C1
	s_cmp_gt_i32 s1, 30                                        // 0000001FA794: BF029E01
	v_cndmask_b32_e64 v4, v129, v4, s0                         // 0000001FA798: D5010004 00020981
	v_cndmask_b32_e64 v3, v128, v3, s0                         // 0000001FA7A0: D5010003 00020780
	s_cselect_b32 s0, -1, 0                                    // 0000001FA7A8: 980080C1
	s_cmp_gt_i32 s1, 31                                        // 0000001FA7AC: BF029F01
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FA7B0: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FA7B8: D5010005 00020B80
	.long 0xd7000007                                           // 0000001FA7C0: D7000007
	v_cndmask_b32_e32 v1, 0xba000, v1, vcc_lo                  // 0000001FA7C4: 020202FF 000BA000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FA7CC: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FA7D0: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA7D8: 980080C1
	global_load_b32 v164, v[3:4], off                          // 0000001FA7DC: DC520000 A47C0003
	global_load_b32 v146, v[5:6], off                          // 0000001FA7E4: DC520000 927C0005
	v_cndmask_b32_e64 v4, v129, v8, s0                         // 0000001FA7EC: D5010004 00021181
	v_cndmask_b32_e64 v3, v128, v7, s0                         // 0000001FA7F4: D5010003 00020F80
	.long 0xd7000005                                           // 0000001FA7FC: D7000005
	v_cndmask_b32_e32 v1, 0xc0000, v1, vcc_lo                  // 0000001FA800: 020202FF 000C0000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FA808: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FA80C: D5207C06 00020480
	.long 0xd7000007                                           // 0000001FA814: D7000007
	v_cndmask_b32_e32 v1, 0xc6000, v1, vcc_lo                  // 0000001FA818: 020202FF 000C6000
	s_cmp_gt_i32 s1, 32                                        // 0000001FA820: BF02A001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FA824: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA82C: 980080C1
	s_cmp_gt_i32 s1, 33                                        // 0000001FA830: BF02A101
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FA834: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FA83C: D5010005 00020B80
	s_cselect_b32 s0, -1, 0                                    // 0000001FA844: 980080C1
	s_cmp_gt_i32 s1, 34                                        // 0000001FA848: BF02A201
	v_cndmask_b32_e64 v8, v129, v8, s0                         // 0000001FA84C: D5010008 00021181
	v_cndmask_b32_e64 v7, v128, v7, s0                         // 0000001FA854: D5010007 00020F80
	.long 0xd7000009                                           // 0000001FA85C: D7000009
	v_cndmask_b32_e32 v1, 0xcc000, v1, vcc_lo                  // 0000001FA860: 020202FF 000CC000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FA868: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 0000001FA86C: D5207C0A 00020480
	.long 0xd700000b                                           // 0000001FA874: D700000B
	v_cndmask_b32_e32 v1, 0xd2000, v1, vcc_lo                  // 0000001FA878: 020202FF 000D2000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 0000001FA880: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA888: 980080C1
	s_cmp_gt_i32 s1, 35                                        // 0000001FA88C: BF02A301
	v_cndmask_b32_e64 v10, v129, v10, s0                       // 0000001FA890: D501000A 00021581
	v_cndmask_b32_e64 v9, v128, v9, s0                         // 0000001FA898: D5010009 00021380
	s_cselect_b32 s0, -1, 0                                    // 0000001FA8A0: 980080C1
	s_cmp_gt_i32 s1, 36                                        // 0000001FA8A4: BF02A401
	v_cndmask_b32_e64 v12, v129, v12, s0                       // 0000001FA8A8: D501000C 00021981
	v_cndmask_b32_e64 v11, v128, v11, s0                       // 0000001FA8B0: D501000B 00021780
	global_load_b32 v195, v[3:4], off                          // 0000001FA8B8: DC520000 C37C0003
	global_load_b32 v194, v[5:6], off                          // 0000001FA8C0: DC520000 C27C0005
	global_load_b32 v193, v[7:8], off                          // 0000001FA8C8: DC520000 C17C0007
	global_load_b32 v145, v[9:10], off                         // 0000001FA8D0: DC520000 917C0009
	global_load_b32 v163, v[11:12], off                        // 0000001FA8D8: DC520000 A37C000B
	.long 0xd7000003                                           // 0000001FA8E0: D7000003
	v_cndmask_b32_e32 v1, 0xd8000, v1, vcc_lo                  // 0000001FA8E4: 020202FF 000D8000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FA8EC: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001FA8F0: D5207C04 00020480
	.long 0xd7000005                                           // 0000001FA8F8: D7000005
	v_cndmask_b32_e32 v1, 0xde000, v1, vcc_lo                  // 0000001FA8FC: 020202FF 000DE000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FA904: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA90C: 980080C1
	s_cmp_gt_i32 s1, 37                                        // 0000001FA910: BF02A501
	v_cndmask_b32_e64 v4, v129, v4, s0                         // 0000001FA914: D5010004 00020981
	v_cndmask_b32_e64 v3, v128, v3, s0                         // 0000001FA91C: D5010003 00020780
	s_cselect_b32 s0, -1, 0                                    // 0000001FA924: 980080C1
	s_cmp_gt_i32 s1, 38                                        // 0000001FA928: BF02A601
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FA92C: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FA934: D5010005 00020B80
	.long 0xd7000007                                           // 0000001FA93C: D7000007
	v_cndmask_b32_e32 v1, 0xe4000, v1, vcc_lo                  // 0000001FA940: 020202FF 000E4000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FA948: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FA94C: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA954: 980080C1
	global_load_b32 v162, v[3:4], off                          // 0000001FA958: DC520000 A27C0003
	global_load_b32 v144, v[5:6], off                          // 0000001FA960: DC520000 907C0005
	v_cndmask_b32_e64 v4, v129, v8, s0                         // 0000001FA968: D5010004 00021181
	v_cndmask_b32_e64 v3, v128, v7, s0                         // 0000001FA970: D5010003 00020F80
	.long 0xd7000005                                           // 0000001FA978: D7000005
	v_cndmask_b32_e32 v1, 0xea000, v1, vcc_lo                  // 0000001FA97C: 020202FF 000EA000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FA984: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FA988: D5207C06 00020480
	.long 0xd7000007                                           // 0000001FA990: D7000007
	v_cndmask_b32_e32 v1, 0xf0000, v1, vcc_lo                  // 0000001FA994: 020202FF 000F0000
	s_cmp_gt_i32 s1, 39                                        // 0000001FA99C: BF02A701
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FA9A0: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FA9A8: 980080C1
	s_cmp_gt_i32 s1, 40                                        // 0000001FA9AC: BF02A801
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FA9B0: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FA9B8: D5010005 00020B80
	s_cselect_b32 s0, -1, 0                                    // 0000001FA9C0: 980080C1
	s_cmp_gt_i32 s1, 41                                        // 0000001FA9C4: BF02A901
	v_cndmask_b32_e64 v8, v129, v8, s0                         // 0000001FA9C8: D5010008 00021181
	v_cndmask_b32_e64 v7, v128, v7, s0                         // 0000001FA9D0: D5010007 00020F80
	.long 0xd7000009                                           // 0000001FA9D8: D7000009
	v_cndmask_b32_e32 v1, 0xf6000, v1, vcc_lo                  // 0000001FA9DC: 020202FF 000F6000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FA9E4: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 0000001FA9E8: D5207C0A 00020480
	.long 0xd700000b                                           // 0000001FA9F0: D700000B
	v_cndmask_b32_e32 v1, 0xfc000, v1, vcc_lo                  // 0000001FA9F4: 020202FF 000FC000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 0000001FA9FC: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FAA04: 980080C1
	s_cmp_gt_i32 s1, 42                                        // 0000001FAA08: BF02AA01
	v_cndmask_b32_e64 v10, v129, v10, s0                       // 0000001FAA0C: D501000A 00021581
	v_cndmask_b32_e64 v9, v128, v9, s0                         // 0000001FAA14: D5010009 00021380
	s_cselect_b32 s0, -1, 0                                    // 0000001FAA1C: 980080C1
	s_cmp_gt_i32 s1, 43                                        // 0000001FAA20: BF02AB01
	v_cndmask_b32_e64 v12, v129, v12, s0                       // 0000001FAA24: D501000C 00021981
	v_cndmask_b32_e64 v11, v128, v11, s0                       // 0000001FAA2C: D501000B 00021780
	global_load_b32 v192, v[3:4], off                          // 0000001FAA34: DC520000 C07C0003
	global_load_b32 v191, v[5:6], off                          // 0000001FAA3C: DC520000 BF7C0005
	global_load_b32 v190, v[7:8], off                          // 0000001FAA44: DC520000 BE7C0007
	global_load_b32 v143, v[9:10], off                         // 0000001FAA4C: DC520000 8F7C0009
	global_load_b32 v161, v[11:12], off                        // 0000001FAA54: DC520000 A17C000B
	.long 0xd7000003                                           // 0000001FAA5C: D7000003
	v_cndmask_b32_e32 v1, 0x102000, v1, vcc_lo                 // 0000001FAA60: 020202FF 00102000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FAA68: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001FAA6C: D5207C04 00020480
	.long 0xd7000005                                           // 0000001FAA74: D7000005
	v_cndmask_b32_e32 v1, 0x108000, v1, vcc_lo                 // 0000001FAA78: 020202FF 00108000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FAA80: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FAA88: 980080C1
	s_cmp_gt_i32 s1, 44                                        // 0000001FAA8C: BF02AC01
	v_cndmask_b32_e64 v4, v129, v4, s0                         // 0000001FAA90: D5010004 00020981
	v_cndmask_b32_e64 v3, v128, v3, s0                         // 0000001FAA98: D5010003 00020780
	s_cselect_b32 s0, -1, 0                                    // 0000001FAAA0: 980080C1
	s_cmp_gt_i32 s1, 45                                        // 0000001FAAA4: BF02AD01
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FAAA8: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FAAB0: D5010005 00020B80
	.long 0xd7000007                                           // 0000001FAAB8: D7000007
	v_cndmask_b32_e32 v1, 0x10e000, v1, vcc_lo                 // 0000001FAABC: 020202FF 0010E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FAAC4: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FAAC8: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FAAD0: 980080C1
	global_load_b32 v160, v[3:4], off                          // 0000001FAAD4: DC520000 A07C0003
	global_load_b32 v142, v[5:6], off                          // 0000001FAADC: DC520000 8E7C0005
	v_cndmask_b32_e64 v4, v129, v8, s0                         // 0000001FAAE4: D5010004 00021181
	v_cndmask_b32_e64 v3, v128, v7, s0                         // 0000001FAAEC: D5010003 00020F80
	.long 0xd7000005                                           // 0000001FAAF4: D7000005
	v_cndmask_b32_e32 v1, 0x114000, v1, vcc_lo                 // 0000001FAAF8: 020202FF 00114000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FAB00: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FAB04: D5207C06 00020480
	.long 0xd7000007                                           // 0000001FAB0C: D7000007
	v_cndmask_b32_e32 v1, 0x11a000, v1, vcc_lo                 // 0000001FAB10: 020202FF 0011A000
	s_cmp_gt_i32 s1, 46                                        // 0000001FAB18: BF02AE01
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FAB1C: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FAB24: 980080C1
	s_cmp_gt_i32 s1, 47                                        // 0000001FAB28: BF02AF01
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FAB2C: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FAB34: D5010005 00020B80
	s_cselect_b32 s0, -1, 0                                    // 0000001FAB3C: 980080C1
	s_cmp_gt_i32 s1, 48                                        // 0000001FAB40: BF02B001
	v_cndmask_b32_e64 v8, v129, v8, s0                         // 0000001FAB44: D5010008 00021181
	v_cndmask_b32_e64 v7, v128, v7, s0                         // 0000001FAB4C: D5010007 00020F80
	.long 0xd7000009                                           // 0000001FAB54: D7000009
	v_cndmask_b32_e32 v1, 0x120000, v1, vcc_lo                 // 0000001FAB58: 020202FF 00120000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FAB60: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 0000001FAB64: D5207C0A 00020480
	.long 0xd700000b                                           // 0000001FAB6C: D700000B
	v_cndmask_b32_e32 v1, 0x126000, v1, vcc_lo                 // 0000001FAB70: 020202FF 00126000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 0000001FAB78: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FAB80: 980080C1
	s_cmp_gt_i32 s1, 49                                        // 0000001FAB84: BF02B101
	v_cndmask_b32_e64 v10, v129, v10, s0                       // 0000001FAB88: D501000A 00021581
	v_cndmask_b32_e64 v9, v128, v9, s0                         // 0000001FAB90: D5010009 00021380
	s_cselect_b32 s0, -1, 0                                    // 0000001FAB98: 980080C1
	s_cmp_gt_i32 s1, 50                                        // 0000001FAB9C: BF02B201
	v_cndmask_b32_e64 v12, v129, v12, s0                       // 0000001FABA0: D501000C 00021981
	v_cndmask_b32_e64 v11, v128, v11, s0                       // 0000001FABA8: D501000B 00021780
	global_load_b32 v189, v[3:4], off                          // 0000001FABB0: DC520000 BD7C0003
	global_load_b32 v188, v[5:6], off                          // 0000001FABB8: DC520000 BC7C0005
	global_load_b32 v187, v[7:8], off                          // 0000001FABC0: DC520000 BB7C0007
	global_load_b32 v155, v[9:10], off                         // 0000001FABC8: DC520000 9B7C0009
	global_load_b32 v173, v[11:12], off                        // 0000001FABD0: DC520000 AD7C000B
	.long 0xd7000003                                           // 0000001FABD8: D7000003
	v_cndmask_b32_e32 v1, 0x12c000, v1, vcc_lo                 // 0000001FABDC: 020202FF 0012C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FABE4: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001FABE8: D5207C04 00020480
	.long 0xd7000005                                           // 0000001FABF0: D7000005
	v_cndmask_b32_e32 v1, 0x132000, v1, vcc_lo                 // 0000001FABF4: 020202FF 00132000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FABFC: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FAC04: 980080C1
	s_cmp_gt_i32 s1, 51                                        // 0000001FAC08: BF02B301
	v_cndmask_b32_e64 v4, v129, v4, s0                         // 0000001FAC0C: D5010004 00020981
	v_cndmask_b32_e64 v3, v128, v3, s0                         // 0000001FAC14: D5010003 00020780
	s_cselect_b32 s0, -1, 0                                    // 0000001FAC1C: 980080C1
	s_cmp_gt_i32 s1, 52                                        // 0000001FAC20: BF02B401
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FAC24: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FAC2C: D5010005 00020B80
	.long 0xd7000007                                           // 0000001FAC34: D7000007
	v_cndmask_b32_e32 v1, 0x138000, v1, vcc_lo                 // 0000001FAC38: 020202FF 00138000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FAC40: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FAC44: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FAC4C: 980080C1
	global_load_b32 v174, v[3:4], off                          // 0000001FAC50: DC520000 AE7C0003
	global_load_b32 v156, v[5:6], off                          // 0000001FAC58: DC520000 9C7C0005
	v_cndmask_b32_e64 v4, v129, v8, s0                         // 0000001FAC60: D5010004 00021181
	v_cndmask_b32_e64 v3, v128, v7, s0                         // 0000001FAC68: D5010003 00020F80
	.long 0xd7000005                                           // 0000001FAC70: D7000005
	v_cndmask_b32_e32 v1, 0x13e000, v1, vcc_lo                 // 0000001FAC74: 020202FF 0013E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FAC7C: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FAC80: D5207C06 00020480
	.long 0xd7000007                                           // 0000001FAC88: D7000007
	v_cndmask_b32_e32 v1, 0x144000, v1, vcc_lo                 // 0000001FAC8C: 020202FF 00144000
	s_cmp_gt_i32 s1, 53                                        // 0000001FAC94: BF02B501
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FAC98: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FACA0: 980080C1
	s_cmp_gt_i32 s1, 54                                        // 0000001FACA4: BF02B601
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FACA8: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FACB0: D5010005 00020B80
	s_cselect_b32 s0, -1, 0                                    // 0000001FACB8: 980080C1
	s_cmp_gt_i32 s1, 55                                        // 0000001FACBC: BF02B701
	v_cndmask_b32_e64 v8, v129, v8, s0                         // 0000001FACC0: D5010008 00021181
	v_cndmask_b32_e64 v7, v128, v7, s0                         // 0000001FACC8: D5010007 00020F80
	.long 0xd7000009                                           // 0000001FACD0: D7000009
	v_cndmask_b32_e32 v1, 0x14a000, v1, vcc_lo                 // 0000001FACD4: 020202FF 0014A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FACDC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 0000001FACE0: D5207C0A 00020480
	.long 0xd700000b                                           // 0000001FACE8: D700000B
	v_cndmask_b32_e32 v1, 0x150000, v1, vcc_lo                 // 0000001FACEC: 020202FF 00150000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 0000001FACF4: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FACFC: 980080C1
	s_cmp_gt_i32 s1, 56                                        // 0000001FAD00: BF02B801
	v_cndmask_b32_e64 v10, v129, v10, s0                       // 0000001FAD04: D501000A 00021581
	v_cndmask_b32_e64 v9, v128, v9, s0                         // 0000001FAD0C: D5010009 00021380
	s_cselect_b32 s0, -1, 0                                    // 0000001FAD14: 980080C1
	s_cmp_gt_i32 s1, 57                                        // 0000001FAD18: BF02B901
	v_cndmask_b32_e64 v12, v129, v12, s0                       // 0000001FAD1C: D501000C 00021981
	v_cndmask_b32_e64 v11, v128, v11, s0                       // 0000001FAD24: D501000B 00021780
	global_load_b32 v208, v[3:4], off                          // 0000001FAD2C: DC520000 D07C0003
	global_load_b32 v209, v[5:6], off                          // 0000001FAD34: DC520000 D17C0005
	global_load_b32 v210, v[7:8], off                          // 0000001FAD3C: DC520000 D27C0007
	global_load_b32 v157, v[9:10], off                         // 0000001FAD44: DC520000 9D7C0009
	global_load_b32 v175, v[11:12], off                        // 0000001FAD4C: DC520000 AF7C000B
	.long 0xd7000003                                           // 0000001FAD54: D7000003
	v_cndmask_b32_e32 v1, 0x156000, v1, vcc_lo                 // 0000001FAD58: 020202FF 00156000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FAD60: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, s0                    // 0000001FAD64: D5207C04 00020480
	.long 0xd7000005                                           // 0000001FAD6C: D7000005
	v_cndmask_b32_e32 v1, 0x15c000, v1, vcc_lo                 // 0000001FAD70: 020202FF 0015C000
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FAD78: D5207C06 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FAD80: 980080C1
	s_cmp_gt_i32 s1, 58                                        // 0000001FAD84: BF02BA01
	v_cndmask_b32_e64 v4, v129, v4, s0                         // 0000001FAD88: D5010004 00020981
	v_cndmask_b32_e64 v3, v128, v3, s0                         // 0000001FAD90: D5010003 00020780
	s_cselect_b32 s0, -1, 0                                    // 0000001FAD98: 980080C1
	s_cmp_gt_i32 s1, 59                                        // 0000001FAD9C: BF02BB01
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FADA0: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FADA8: D5010005 00020B80
	.long 0xd7000007                                           // 0000001FADB0: D7000007
	v_cndmask_b32_e32 v1, 0x162000, v1, vcc_lo                 // 0000001FADB4: 020202FF 00162000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FADBC: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FADC0: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FADC8: 980080C1
	global_load_b32 v176, v[3:4], off                          // 0000001FADCC: DC520000 B07C0003
	global_load_b32 v158, v[5:6], off                          // 0000001FADD4: DC520000 9E7C0005
	v_cndmask_b32_e64 v4, v129, v8, s0                         // 0000001FADDC: D5010004 00021181
	v_cndmask_b32_e64 v3, v128, v7, s0                         // 0000001FADE4: D5010003 00020F80
	.long 0xd7000005                                           // 0000001FADEC: D7000005
	v_cndmask_b32_e32 v1, 0x168000, v1, vcc_lo                 // 0000001FADF0: 020202FF 00168000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FADF8: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, s0                    // 0000001FADFC: D5207C06 00020480
	.long 0xd7000007                                           // 0000001FAE04: D7000007
	v_cndmask_b32_e32 v1, 0x16e000, v1, vcc_lo                 // 0000001FAE08: 020202FF 0016E000
	s_cmp_gt_i32 s1, 60                                        // 0000001FAE10: BF02BC01
	v_add_co_ci_u32_e64 v8, null, 0, v2, s0                    // 0000001FAE14: D5207C08 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FAE1C: 980080C1
	s_cmp_gt_i32 s1, 61                                        // 0000001FAE20: BF02BD01
	v_cndmask_b32_e64 v6, v129, v6, s0                         // 0000001FAE24: D5010006 00020D81
	v_cndmask_b32_e64 v5, v128, v5, s0                         // 0000001FAE2C: D5010005 00020B80
	s_cselect_b32 s0, -1, 0                                    // 0000001FAE34: 980080C1
	s_cmp_gt_i32 s1, 62                                        // 0000001FAE38: BF02BE01
	v_cndmask_b32_e64 v8, v129, v8, s0                         // 0000001FAE3C: D5010008 00021181
	v_cndmask_b32_e64 v7, v128, v7, s0                         // 0000001FAE44: D5010007 00020F80
	.long 0xd7000009                                           // 0000001FAE4C: D7000009
	v_cndmask_b32_e32 v1, 0x174000, v1, vcc_lo                 // 0000001FAE50: 020202FF 00174000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001FAE58: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, s0                   // 0000001FAE5C: D5207C0A 00020480
	.long 0xd700000b                                           // 0000001FAE64: D700000B
	v_cndmask_b32_e32 v1, 0x17a000, v1, vcc_lo                 // 0000001FAE68: 020202FF 0017A000
	v_add_co_ci_u32_e64 v12, null, 0, v2, s0                   // 0000001FAE70: D5207C0C 00020480
	s_cselect_b32 s0, -1, 0                                    // 0000001FAE78: 980080C1
	s_cmp_gt_i32 s1, 63                                        // 0000001FAE7C: BF02BF01
	v_cndmask_b32_e64 v2, v129, v10, s0                        // 0000001FAE80: D5010002 00021581
	v_cndmask_b32_e64 v1, v128, v9, s0                         // 0000001FAE88: D5010001 00021380
	s_cselect_b32 s0, -1, 0                                    // 0000001FAE90: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001FAE94: BF870009
	v_cndmask_b32_e64 v10, v129, v12, s0                       // 0000001FAE98: D501000A 00021981
	v_cndmask_b32_e64 v9, v128, v11, s0                        // 0000001FAEA0: D5010009 00021780
	global_load_b32 v211, v[3:4], off                          // 0000001FAEA8: DC520000 D37C0003
	global_load_b32 v212, v[5:6], off                          // 0000001FAEB0: DC520000 D47C0005
	global_load_b32 v213, v[7:8], off                          // 0000001FAEB8: DC520000 D57C0007
	global_load_b32 v159, v[1:2], off                          // 0000001FAEC0: DC520000 9F7C0001
	global_load_b32 v177, v[9:10], off                         // 0000001FAEC8: DC520000 B17C0009
	s_waitcnt vmcnt(0)                                         // 0000001FAED0: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 0000001FAED4: BC7C0000
	s_barrier                                                  // 0000001FAED8: BFBD0000
	buffer_gl0_inv                                             // 0000001FAEDC: E0AC0000 00000000
	ds_load_b128 v[1:4], v178                                  // 0000001FAEE4: DBFC0000 010000B2
	ds_load_b128 v[5:8], v178 offset:16                        // 0000001FAEEC: DBFC0010 050000B2
	ds_load_b128 v[25:28], v179                                // 0000001FAEF4: DBFC0000 190000B3
	ds_load_b128 v[29:32], v179 offset:16                      // 0000001FAEFC: DBFC0010 1D0000B3
	ds_load_b128 v[9:12], v178 offset:32                       // 0000001FAF04: DBFC0020 090000B2
	ds_load_b128 v[13:16], v178 offset:48                      // 0000001FAF0C: DBFC0030 0D0000B2
	ds_load_b128 v[33:36], v179 offset:2304                    // 0000001FAF14: DBFC0900 210000B3
	ds_load_b128 v[37:40], v179 offset:2320                    // 0000001FAF1C: DBFC0910 250000B3
	ds_load_b128 v[41:44], v179 offset:4608                    // 0000001FAF24: DBFC1200 290000B3
	ds_load_b128 v[45:48], v179 offset:4624                    // 0000001FAF2C: DBFC1210 2D0000B3
	ds_load_b128 v[49:52], v179 offset:6912                    // 0000001FAF34: DBFC1B00 310000B3
	ds_load_b128 v[53:56], v179 offset:6928                    // 0000001FAF3C: DBFC1B10 350000B3
	ds_load_b128 v[57:60], v179 offset:9216                    // 0000001FAF44: DBFC2400 390000B3
	ds_load_b128 v[61:64], v179 offset:9232                    // 0000001FAF4C: DBFC2410 3D0000B3
	ds_load_b128 v[65:68], v179 offset:11520                   // 0000001FAF54: DBFC2D00 410000B3
	ds_load_b128 v[69:72], v179 offset:11536                   // 0000001FAF5C: DBFC2D10 450000B3
	ds_load_b128 v[73:76], v179 offset:13824                   // 0000001FAF64: DBFC3600 490000B3
	ds_load_b128 v[77:80], v179 offset:13840                   // 0000001FAF6C: DBFC3610 4D0000B3
	ds_load_b128 v[81:84], v179 offset:16128                   // 0000001FAF74: DBFC3F00 510000B3
	ds_load_b128 v[85:88], v179 offset:16144                   // 0000001FAF7C: DBFC3F10 550000B3
	ds_load_b128 v[89:92], v179 offset:32                      // 0000001FAF84: DBFC0020 590000B3
	ds_load_b128 v[93:96], v179 offset:48                      // 0000001FAF8C: DBFC0030 5D0000B3
	v_dual_mov_b32 v17, s20 :: v_dual_mov_b32 v18, s21         // 0000001FAF94: CA100014 11120015
	v_dual_mov_b32 v19, s22 :: v_dual_mov_b32 v20, s23         // 0000001FAF9C: CA100016 13140017
	v_dual_mov_b32 v21, s24 :: v_dual_mov_b32 v22, s25         // 0000001FAFA4: CA100018 15160019
	v_dual_mov_b32 v23, s26 :: v_dual_mov_b32 v24, s27         // 0000001FAFAC: CA10001A 1718001B
	s_mul_f32 s0, s41, 0x3fb8aa3b                              // 0000001FAFB4: A200FF29 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000001FAFBC: BF87000B
	s_xor_b32 s1, s0, 0x80000000                               // 0000001FAFC0: 8D01FF00 80000000
	s_rndne_f32 s8, s0                                         // 0000001FAFC8: BE886300
	s_waitcnt lgkmcnt(14)                                      // 0000001FAFCC: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[105:112], v[33:40], v[1:8], v[17:24]// 0000001FAFD0: CC404069 1C460321
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[1:8], v[17:24]// 0000001FAFD8: CC404061 1C460319
	ds_load_b128 v[25:28], v179 offset:2336                    // 0000001FAFE0: DBFC0920 190000B3
	ds_load_b128 v[29:32], v179 offset:2352                    // 0000001FAFE8: DBFC0930 1D0000B3
	s_waitcnt lgkmcnt(14)                                      // 0000001FAFF0: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[1:8], v[17:24]// 0000001FAFF4: CC404021 1C460329
	s_waitcnt lgkmcnt(12)                                      // 0000001FAFFC: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[41:48], v[49:56], v[1:8], v[17:24]// 0000001FB000: CC404029 1C460331
	s_waitcnt lgkmcnt(10)                                      // 0000001FB008: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[49:56], v[57:64], v[1:8], v[17:24]// 0000001FB00C: CC404031 1C460339
	s_waitcnt lgkmcnt(8)                                       // 0000001FB014: BF89FC87
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[1:8], v[17:24]// 0000001FB018: CC404039 1C460341
	s_waitcnt lgkmcnt(6)                                       // 0000001FB020: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[73:80], v[1:8], v[17:24]// 0000001FB024: CC404041 1C460349
	s_waitcnt lgkmcnt(4)                                       // 0000001FB02C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[73:80], v[81:88], v[1:8], v[17:24]// 0000001FB030: CC404049 1C460351
	ds_load_b128 v[1:4], v179 offset:4640                      // 0000001FB038: DBFC1220 010000B3
	ds_load_b128 v[5:8], v179 offset:4656                      // 0000001FB040: DBFC1230 050000B3
	ds_load_b128 v[17:20], v179 offset:6944                    // 0000001FB048: DBFC1B20 110000B3
	ds_load_b128 v[21:24], v179 offset:6960                    // 0000001FB050: DBFC1B30 150000B3
	ds_load_b128 v[81:84], v179 offset:9248                    // 0000001FB058: DBFC2420 510000B3
	ds_load_b128 v[85:88], v179 offset:9264                    // 0000001FB060: DBFC2430 550000B3
	s_waitcnt lgkmcnt(8)                                       // 0000001FB068: BF89FC87
	v_wmma_f32_16x16x16_f16 v[97:104], v[89:96], v[9:16], v[97:104]// 0000001FB06C: CC404061 1D861359
	s_fmamk_f32 s1, s41, 0x3fb8aa3b, s1                        // 0000001FB074: A3010129 3FB8AA3B
	s_sub_f32 s0, s0, s8                                       // 0000001FB07C: A0800800
	s_cmp_nlt_f32 s41, 0xc2ce8ed0                              // 0000001FB080: BF4EFF29 C2CE8ED0
	s_waitcnt lgkmcnt(6)                                       // 0000001FB088: BF89FC67
	v_wmma_f32_16x16x16_f16 v[105:112], v[25:32], v[9:16], v[105:112]// 0000001FB08C: CC404069 1DA61319
	ds_load_b128 v[25:28], v179 offset:11552                   // 0000001FB094: DBFC2D20 190000B3
	ds_load_b128 v[29:32], v179 offset:11568                   // 0000001FB09C: DBFC2D30 1D0000B3
	s_fmamk_f32 s1, s41, 0x32a5705f, s1                        // 0000001FB0A4: A3010129 32A5705F
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000001FB0AC: BF87059B
	s_add_f32 s0, s0, s1                                       // 0000001FB0B0: A0000100
	v_exp_f32_e32 v91, s0                                      // 0000001FB0B4: 7EB64A00
	s_waitcnt lgkmcnt(6)                                       // 0000001FB0B8: BF89FC67
	v_wmma_f32_16x16x16_f16 v[33:40], v[1:8], v[9:16], v[33:40]// 0000001FB0BC: CC404021 1C861301
	ds_load_b128 v[1:4], v179 offset:13856                     // 0000001FB0C4: DBFC3620 010000B3
	ds_load_b128 v[5:8], v179 offset:13872                     // 0000001FB0CC: DBFC3630 050000B3
	s_waitcnt lgkmcnt(6)                                       // 0000001FB0D4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[9:16], v[41:48]// 0000001FB0D8: CC404029 1CA61311
	ds_load_b128 v[17:20], v179 offset:16160                   // 0000001FB0E0: DBFC3F20 110000B3
	ds_load_b128 v[21:24], v179 offset:16176                   // 0000001FB0E8: DBFC3F30 150000B3
	s_waitcnt lgkmcnt(6)                                       // 0000001FB0F0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[49:56], v[81:88], v[9:16], v[49:56]// 0000001FB0F4: CC404031 1CC61351
	ds_load_b128 v[85:88], v178 offset:80                      // 0000001FB0FC: DBFC0050 550000B2
	ds_load_b128 v[81:84], v178 offset:64                      // 0000001FB104: DBFC0040 510000B2
	s_cvt_i32_f32 s0, s8                                       // 0000001FB10C: BE806608
	s_waitcnt lgkmcnt(6)                                       // 0000001FB110: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[25:32], v[9:16], v[57:64]// 0000001FB114: CC404039 1CE61319
	ds_load_b128 v[29:32], v179 offset:80                      // 0000001FB11C: DBFC0050 1D0000B3
	ds_load_b128 v[25:28], v179 offset:64                      // 0000001FB124: DBFC0040 190000B3
	.long 0xd71c005b                                           // 0000001FB12C: D71C005B
	v_cndmask_b32_e32 v0, v91, v0, vcc_lo                      // 0000001FB130: 0200015B
	s_cselect_b32 s0, -1, 0                                    // 0000001FB134: 980080C1
	s_cmp_ngt_f32 s41, 0x42b17218                              // 0000001FB138: BF4BFF29 42B17218
	s_waitcnt lgkmcnt(6)                                       // 0000001FB140: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[1:8], v[9:16], v[65:72]// 0000001FB144: CC404041 1D061301
	ds_load_b128 v[5:8], v179 offset:2384                      // 0000001FB14C: DBFC0950 050000B3
	ds_load_b128 v[1:4], v179 offset:2368                      // 0000001FB154: DBFC0940 010000B3
	s_waitcnt lgkmcnt(6)                                       // 0000001FB15C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[9:16], v[73:80]// 0000001FB160: CC404049 1D261311
	ds_load_b128 v[13:16], v179 offset:4688                    // 0000001FB168: DBFC1250 0D0000B3
	ds_load_b128 v[9:12], v179 offset:4672                     // 0000001FB170: DBFC1240 090000B3
	ds_load_b128 v[21:24], v179 offset:6992                    // 0000001FB178: DBFC1B50 150000B3
	ds_load_b128 v[17:20], v179 offset:6976                    // 0000001FB180: DBFC1B40 110000B3
	s_waitcnt lgkmcnt(6)                                       // 0000001FB188: BF89FC67
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[81:88], v[97:104]// 0000001FB18C: CC404061 1D86A319
	ds_load_b128 v[29:32], v179 offset:9296                    // 0000001FB194: DBFC2450 1D0000B3
	ds_load_b128 v[25:28], v179 offset:9280                    // 0000001FB19C: DBFC2440 190000B3
	s_waitcnt lgkmcnt(6)                                       // 0000001FB1A4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[105:112], v[1:8], v[81:88], v[105:112]// 0000001FB1A8: CC404069 1DA6A301
	ds_load_b128 v[5:8], v179 offset:11600                     // 0000001FB1B0: DBFC2D50 050000B3
	ds_load_b128 v[1:4], v179 offset:11584                     // 0000001FB1B8: DBFC2D40 010000B3
	s_waitcnt lgkmcnt(6)                                       // 0000001FB1C0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[33:40], v[9:16], v[81:88], v[33:40]// 0000001FB1C4: CC404021 1C86A309
	ds_load_b128 v[13:16], v179 offset:13904                   // 0000001FB1CC: DBFC3650 0D0000B3
	ds_load_b128 v[9:12], v179 offset:13888                    // 0000001FB1D4: DBFC3640 090000B3
	s_waitcnt lgkmcnt(6)                                       // 0000001FB1DC: BF89FC67
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[81:88], v[41:48]// 0000001FB1E0: CC404029 1CA6A311
	ds_load_b128 v[21:24], v179 offset:16208                   // 0000001FB1E8: DBFC3F50 150000B3
	ds_load_b128 v[17:20], v179 offset:16192                   // 0000001FB1F0: DBFC3F40 110000B3
	s_waitcnt lgkmcnt(6)                                       // 0000001FB1F8: BF89FC67
	v_wmma_f32_16x16x16_f16 v[49:56], v[25:32], v[81:88], v[49:56]// 0000001FB1FC: CC404031 1CC6A319
	ds_load_b128 v[29:32], v178 offset:112                     // 0000001FB204: DBFC0070 1D0000B2
	ds_load_b128 v[25:28], v178 offset:96                      // 0000001FB20C: DBFC0060 190000B2
	s_waitcnt lgkmcnt(6)                                       // 0000001FB214: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[1:8], v[81:88], v[57:64]// 0000001FB218: CC404039 1CE6A301
	ds_load_b128 v[5:8], v179 offset:112                       // 0000001FB220: DBFC0070 050000B3
	ds_load_b128 v[1:4], v179 offset:96                        // 0000001FB228: DBFC0060 010000B3
	s_waitcnt lgkmcnt(6)                                       // 0000001FB230: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[9:16], v[81:88], v[65:72]// 0000001FB234: CC404041 1D06A309
	ds_load_b128 v[13:16], v179 offset:2416                    // 0000001FB23C: DBFC0970 0D0000B3
	ds_load_b128 v[9:12], v179 offset:2400                     // 0000001FB244: DBFC0960 090000B3
	s_waitcnt lgkmcnt(6)                                       // 0000001FB24C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[81:88], v[73:80]// 0000001FB250: CC404049 1D26A311
	ds_load_b128 v[21:24], v179 offset:4720                    // 0000001FB258: DBFC1270 150000B3
	ds_load_b128 v[17:20], v179 offset:4704                    // 0000001FB260: DBFC1260 110000B3
	ds_load_b128 v[85:88], v179 offset:7024                    // 0000001FB268: DBFC1B70 550000B3
	ds_load_b128 v[81:84], v179 offset:7008                    // 0000001FB270: DBFC1B60 510000B3
	s_waitcnt lgkmcnt(6)                                       // 0000001FB278: BF89FC67
	v_wmma_f32_16x16x16_f16 v[97:104], v[1:8], v[25:32], v[97:104]// 0000001FB27C: CC404061 1D863301
	ds_load_b128 v[5:8], v179 offset:9328                      // 0000001FB284: DBFC2470 050000B3
	ds_load_b128 v[1:4], v179 offset:9312                      // 0000001FB28C: DBFC2460 010000B3
	s_waitcnt lgkmcnt(6)                                       // 0000001FB294: BF89FC67
	v_wmma_f32_16x16x16_f16 v[105:112], v[9:16], v[25:32], v[105:112]// 0000001FB298: CC404069 1DA63309
	ds_load_b128 v[13:16], v179 offset:11632                   // 0000001FB2A0: DBFC2D70 0D0000B3
	ds_load_b128 v[9:12], v179 offset:11616                    // 0000001FB2A8: DBFC2D60 090000B3
	ds_load_2addr_b32 v[89:90], v180 offset1:2                 // 0000001FB2B0: D8DC0200 590000B4
	s_waitcnt lgkmcnt(7)                                       // 0000001FB2B8: BF89FC77
	v_wmma_f32_16x16x16_f16 v[33:40], v[17:24], v[25:32], v[33:40]// 0000001FB2BC: CC404021 1C863311
	ds_load_b128 v[21:24], v179 offset:13936                   // 0000001FB2C4: DBFC3670 150000B3
	ds_load_b128 v[17:20], v179 offset:13920                   // 0000001FB2CC: DBFC3660 110000B3
	s_waitcnt lgkmcnt(7)                                       // 0000001FB2D4: BF89FC77
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[25:32], v[41:48]// 0000001FB2D8: CC404029 1CA63351
	ds_load_b128 v[85:88], v179 offset:16240                   // 0000001FB2E0: DBFC3F70 550000B3
	ds_load_b128 v[81:84], v179 offset:16224                   // 0000001FB2E8: DBFC3F60 510000B3
	s_waitcnt lgkmcnt(7)                                       // 0000001FB2F0: BF89FC77
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[25:32], v[49:56]// 0000001FB2F4: CC404031 1CC63301
	ds_load_2addr_b32 v[1:2], v180 offset0:4 offset1:6         // 0000001FB2FC: D8DC0604 010000B4
	ds_load_2addr_b32 v[3:4], v180 offset0:8 offset1:10        // 0000001FB304: D8DC0A08 030000B4
	ds_load_2addr_b32 v[5:6], v180 offset0:12 offset1:14       // 0000001FB30C: D8DC0E0C 050000B4
	ds_load_2addr_b32 v[7:8], v180 offset0:16 offset1:18       // 0000001FB314: D8DC1210 070000B4
	s_waitcnt lgkmcnt(9)                                       // 0000001FB31C: BF89FC97
	v_wmma_f32_16x16x16_f16 v[57:64], v[9:16], v[25:32], v[57:64]// 0000001FB320: CC404039 1CE63309
	ds_load_2addr_b32 v[9:10], v180 offset0:20 offset1:22      // 0000001FB328: D8DC1614 090000B4
	ds_load_2addr_b32 v[11:12], v180 offset0:24 offset1:26     // 0000001FB330: D8DC1A18 0B0000B4
	ds_load_2addr_b32 v[13:14], v180 offset0:28 offset1:30     // 0000001FB338: D8DC1E1C 0D0000B4
	s_waitcnt lgkmcnt(9)                                       // 0000001FB340: BF89FC97
	v_wmma_f32_16x16x16_f16 v[65:72], v[17:24], v[25:32], v[65:72]// 0000001FB344: CC404041 1D063311
	ds_load_2addr_b32 v[15:16], v180 offset0:32 offset1:34     // 0000001FB34C: D8DC2220 0F0000B4
	ds_load_2addr_b32 v[17:18], v180 offset0:36 offset1:38     // 0000001FB354: D8DC2624 110000B4
	ds_load_2addr_b32 v[19:20], v180 offset0:40 offset1:42     // 0000001FB35C: D8DC2A28 130000B4
	ds_load_2addr_b32 v[21:22], v180 offset0:44 offset1:46     // 0000001FB364: D8DC2E2C 150000B4
	s_waitcnt lgkmcnt(11)                                      // 0000001FB36C: BF89FCB7
	v_wmma_f32_16x16x16_f16 v[73:80], v[81:88], v[25:32], v[73:80]// 0000001FB370: CC404049 1D263351
	v_cndmask_b32_e64 v31, 0, v91, s0                          // 0000001FB378: D501001F 0002B680
	s_cselect_b32 s0, -1, 0                                    // 0000001FB380: 980080C1
	ds_load_2addr_b32 v[23:24], v180 offset0:48 offset1:50     // 0000001FB384: D8DC3230 170000B4
	ds_load_2addr_b32 v[25:26], v180 offset0:52 offset1:54     // 0000001FB38C: D8DC3634 190000B4
	ds_load_2addr_b32 v[27:28], v180 offset0:56 offset1:58     // 0000001FB394: D8DC3A38 1B0000B4
	ds_load_2addr_b32 v[29:30], v180 offset0:60 offset1:62     // 0000001FB39C: D8DC3E3C 1D0000B4
	v_cndmask_b32_e64 v91, 0x7f800000, v31, s0                 // 0000001FB3A4: D501005B 00023EFF 7F800000
	ds_load_2addr_b32 v[31:32], v180 offset0:64 offset1:66     // 0000001FB3B0: D8DC4240 1F0000B4
	ds_load_2addr_b32 v[81:82], v180 offset0:68 offset1:70     // 0000001FB3B8: D8DC4644 510000B4
	ds_load_2addr_b32 v[83:84], v180 offset0:72 offset1:74     // 0000001FB3C0: D8DC4A48 530000B4
	ds_load_2addr_b32 v[85:86], v180 offset0:76 offset1:78     // 0000001FB3C8: D8DC4E4C 550000B4
	s_cmp_lg_u32 s40, s36                                      // 0000001FB3D0: BF072428
	v_mul_f32_e32 v90, v91, v90                                // 0000001FB3D4: 10B4B55B
	v_mul_f32_e32 v89, v91, v89                                // 0000001FB3D8: 10B2B35B
	s_waitcnt lgkmcnt(18)                                      // 0000001FB3DC: BF89FD27
	v_mul_f32_e32 v93, v91, v2                                 // 0000001FB3E0: 10BA055B
	v_mul_f32_e32 v92, v91, v1                                 // 0000001FB3E4: 10B8035B
	s_waitcnt lgkmcnt(17)                                      // 0000001FB3E8: BF89FD17
	v_mul_f32_e32 v95, v91, v4                                 // 0000001FB3EC: 10BE095B
	v_mul_f32_e32 v94, v91, v3                                 // 0000001FB3F0: 10BC075B
	s_waitcnt lgkmcnt(16)                                      // 0000001FB3F4: BF89FD07
	v_mul_f32_e32 v113, v91, v6                                // 0000001FB3F8: 10E20D5B
	v_mul_f32_e32 v96, v91, v5                                 // 0000001FB3FC: 10C00B5B
	v_dual_fmac_f32 v90, 0x3b800000, v98 :: v_dual_fmac_f32 v89, 0x3b800000, v97// 0000001FB400: C800C4FF 5A58C2FF 3B800000
	v_dual_fmac_f32 v93, 0x3b800000, v100 :: v_dual_fmac_f32 v92, 0x3b800000, v99// 0000001FB40C: C800C8FF 5D5CC6FF 3B800000
	v_dual_fmac_f32 v95, 0x3b800000, v102 :: v_dual_fmac_f32 v94, 0x3b800000, v101// 0000001FB418: C800CCFF 5F5ECAFF 3B800000
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001FB424: BF870004
	v_dual_fmac_f32 v113, 0x3b800000, v104 :: v_dual_fmac_f32 v96, 0x3b800000, v103// 0000001FB428: C800D0FF 7160CEFF 3B800000
	s_waitcnt lgkmcnt(15)                                      // 0000001FB434: BF89FCF7
	v_mul_f32_e32 v98, v91, v8                                 // 0000001FB438: 10C4115B
	v_mul_f32_e32 v97, v91, v7                                 // 0000001FB43C: 10C20F5B
	s_waitcnt lgkmcnt(14)                                      // 0000001FB440: BF89FCE7
	v_mul_f32_e32 v100, v91, v10                               // 0000001FB444: 10C8155B
	v_mul_f32_e32 v99, v91, v9                                 // 0000001FB448: 10C6135B
	s_waitcnt lgkmcnt(13)                                      // 0000001FB44C: BF89FCD7
	v_mul_f32_e32 v102, v91, v12                               // 0000001FB450: 10CC195B
	v_mul_f32_e32 v101, v91, v11                               // 0000001FB454: 10CA175B
	s_waitcnt lgkmcnt(12)                                      // 0000001FB458: BF89FCC7
	v_mul_f32_e32 v104, v91, v14                               // 0000001FB45C: 10D01D5B
	v_mul_f32_e32 v103, v91, v13                               // 0000001FB460: 10CE1B5B
	ds_load_2addr_b32 v[1:2], v180 offset0:80 offset1:82       // 0000001FB464: D8DC5250 010000B4
	ds_load_2addr_b32 v[3:4], v180 offset0:84 offset1:86       // 0000001FB46C: D8DC5654 030000B4
	ds_load_2addr_b32 v[5:6], v180 offset0:88 offset1:90       // 0000001FB474: D8DC5A58 050000B4
	ds_load_2addr_b32 v[87:88], v180 offset0:92 offset1:94     // 0000001FB47C: D8DC5E5C 570000B4
	v_dual_fmac_f32 v98, 0x3b800000, v106 :: v_dual_fmac_f32 v97, 0x3b800000, v105// 0000001FB484: C800D4FF 6260D2FF 3B800000
	v_dual_fmac_f32 v100, 0x3b800000, v108 :: v_dual_fmac_f32 v99, 0x3b800000, v107// 0000001FB490: C800D8FF 6462D6FF 3B800000
	v_dual_fmac_f32 v102, 0x3b800000, v110 :: v_dual_fmac_f32 v101, 0x3b800000, v109// 0000001FB49C: C800DCFF 6664DAFF 3B800000
	v_dual_fmac_f32 v104, 0x3b800000, v112 :: v_dual_fmac_f32 v103, 0x3b800000, v111// 0000001FB4A8: C800E0FF 6866DEFF 3B800000
	ds_load_2addr_b32 v[7:8], v180 offset0:96 offset1:98       // 0000001FB4B4: D8DC6260 070000B4
	ds_load_2addr_b32 v[9:10], v180 offset0:100 offset1:102    // 0000001FB4BC: D8DC6664 090000B4
	ds_load_2addr_b32 v[11:12], v180 offset0:104 offset1:106   // 0000001FB4C4: D8DC6A68 0B0000B4
	ds_load_2addr_b32 v[13:14], v180 offset0:108 offset1:110   // 0000001FB4CC: D8DC6E6C 0D0000B4
	s_waitcnt lgkmcnt(19)                                      // 0000001FB4D4: BF89FD37
	v_mul_f32_e32 v106, v91, v16                               // 0000001FB4D8: 10D4215B
	v_mul_f32_e32 v105, v91, v15                               // 0000001FB4DC: 10D21F5B
	s_waitcnt lgkmcnt(18)                                      // 0000001FB4E0: BF89FD27
	v_mul_f32_e32 v108, v91, v18                               // 0000001FB4E4: 10D8255B
	v_mul_f32_e32 v107, v91, v17                               // 0000001FB4E8: 10D6235B
	s_waitcnt lgkmcnt(17)                                      // 0000001FB4EC: BF89FD17
	v_mul_f32_e32 v110, v91, v20                               // 0000001FB4F0: 10DC295B
	v_mul_f32_e32 v109, v91, v19                               // 0000001FB4F4: 10DA275B
	s_waitcnt lgkmcnt(16)                                      // 0000001FB4F8: BF89FD07
	v_mul_f32_e32 v112, v91, v22                               // 0000001FB4FC: 10E02D5B
	v_mul_f32_e32 v111, v91, v21                               // 0000001FB500: 10DE2B5B
	ds_load_2addr_b32 v[15:16], v180 offset0:112 offset1:114   // 0000001FB504: D8DC7270 0F0000B4
	ds_load_2addr_b32 v[17:18], v180 offset0:116 offset1:118   // 0000001FB50C: D8DC7674 110000B4
	ds_load_2addr_b32 v[19:20], v180 offset0:120 offset1:122   // 0000001FB514: D8DC7A78 130000B4
	ds_load_2addr_b32 v[21:22], v180 offset0:124 offset1:126   // 0000001FB51C: D8DC7E7C 150000B4
	v_dual_fmac_f32 v106, 0x3b800000, v34 :: v_dual_fmac_f32 v105, 0x3b800000, v33// 0000001FB524: C80044FF 6A6842FF 3B800000
	v_dual_fmac_f32 v108, 0x3b800000, v36 :: v_dual_fmac_f32 v107, 0x3b800000, v35// 0000001FB530: C80048FF 6C6A46FF 3B800000
	v_dual_fmac_f32 v110, 0x3b800000, v38 :: v_dual_fmac_f32 v109, 0x3b800000, v37// 0000001FB53C: C8004CFF 6E6C4AFF 3B800000
	v_dual_fmac_f32 v112, 0x3b800000, v40 :: v_dual_fmac_f32 v111, 0x3b800000, v39// 0000001FB548: C80050FF 706E4EFF 3B800000
	s_waitcnt lgkmcnt(19)                                      // 0000001FB554: BF89FD37
	v_mul_f32_e32 v24, v91, v24                                // 0000001FB558: 1030315B
	v_mul_f32_e32 v23, v91, v23                                // 0000001FB55C: 102E2F5B
	s_waitcnt lgkmcnt(18)                                      // 0000001FB560: BF89FD27
	v_mul_f32_e32 v26, v91, v26                                // 0000001FB564: 1034355B
	v_mul_f32_e32 v25, v91, v25                                // 0000001FB568: 1032335B
	s_waitcnt lgkmcnt(17)                                      // 0000001FB56C: BF89FD17
	v_mul_f32_e32 v28, v91, v28                                // 0000001FB570: 1038395B
	v_mul_f32_e32 v27, v91, v27                                // 0000001FB574: 1036375B
	s_waitcnt lgkmcnt(16)                                      // 0000001FB578: BF89FD07
	v_mul_f32_e32 v30, v91, v30                                // 0000001FB57C: 103C3D5B
	v_mul_f32_e32 v29, v91, v29                                // 0000001FB580: 103A3B5B
	s_waitcnt lgkmcnt(15)                                      // 0000001FB584: BF89FCF7
	v_mul_f32_e32 v32, v91, v32                                // 0000001FB588: 1040415B
	v_mul_f32_e32 v31, v91, v31                                // 0000001FB58C: 103E3F5B
	s_waitcnt lgkmcnt(14)                                      // 0000001FB590: BF89FCE7
	v_mul_f32_e32 v34, v91, v82                                // 0000001FB594: 1044A55B
	v_mul_f32_e32 v33, v91, v81                                // 0000001FB598: 1042A35B
	s_waitcnt lgkmcnt(13)                                      // 0000001FB59C: BF89FCD7
	v_mul_f32_e32 v36, v91, v84                                // 0000001FB5A0: 1048A95B
	v_mul_f32_e32 v35, v91, v83                                // 0000001FB5A4: 1046A75B
	s_waitcnt lgkmcnt(12)                                      // 0000001FB5A8: BF89FCC7
	v_mul_f32_e32 v38, v91, v86                                // 0000001FB5AC: 104CAD5B
	v_mul_f32_e32 v37, v91, v85                                // 0000001FB5B0: 104AAB5B
	s_waitcnt lgkmcnt(11)                                      // 0000001FB5B4: BF89FCB7
	v_mul_f32_e32 v2, v91, v2                                  // 0000001FB5B8: 1004055B
	v_mul_f32_e32 v1, v91, v1                                  // 0000001FB5BC: 1002035B
	s_waitcnt lgkmcnt(10)                                      // 0000001FB5C0: BF89FCA7
	v_mul_f32_e32 v4, v91, v4                                  // 0000001FB5C4: 1008095B
	v_mul_f32_e32 v3, v91, v3                                  // 0000001FB5C8: 1006075B
	s_waitcnt lgkmcnt(9)                                       // 0000001FB5CC: BF89FC97
	v_mul_f32_e32 v6, v91, v6                                  // 0000001FB5D0: 100C0D5B
	v_mul_f32_e32 v5, v91, v5                                  // 0000001FB5D4: 100A0B5B
	s_waitcnt lgkmcnt(8)                                       // 0000001FB5D8: BF89FC87
	v_mul_f32_e32 v40, v91, v88                                // 0000001FB5DC: 1050B15B
	v_mul_f32_e32 v39, v91, v87                                // 0000001FB5E0: 104EAF5B
	s_waitcnt lgkmcnt(7)                                       // 0000001FB5E4: BF89FC77
	v_mul_f32_e32 v8, v91, v8                                  // 0000001FB5E8: 1010115B
	v_mul_f32_e32 v7, v91, v7                                  // 0000001FB5EC: 100E0F5B
	s_waitcnt lgkmcnt(6)                                       // 0000001FB5F0: BF89FC67
	v_mul_f32_e32 v10, v91, v10                                // 0000001FB5F4: 1014155B
	v_mul_f32_e32 v9, v91, v9                                  // 0000001FB5F8: 1012135B
	s_waitcnt lgkmcnt(5)                                       // 0000001FB5FC: BF89FC57
	v_mul_f32_e32 v12, v91, v12                                // 0000001FB600: 1018195B
	v_mul_f32_e32 v11, v91, v11                                // 0000001FB604: 1016175B
	s_waitcnt lgkmcnt(4)                                       // 0000001FB608: BF89FC47
	v_mul_f32_e32 v14, v91, v14                                // 0000001FB60C: 101C1D5B
	v_mul_f32_e32 v13, v91, v13                                // 0000001FB610: 101A1B5B
	s_waitcnt lgkmcnt(3)                                       // 0000001FB614: BF89FC37
	v_mul_f32_e32 v16, v91, v16                                // 0000001FB618: 1020215B
	v_mul_f32_e32 v15, v91, v15                                // 0000001FB61C: 101E1F5B
	s_waitcnt lgkmcnt(2)                                       // 0000001FB620: BF89FC27
	v_mul_f32_e32 v18, v91, v18                                // 0000001FB624: 1024255B
	v_mul_f32_e32 v17, v91, v17                                // 0000001FB628: 1022235B
	s_waitcnt lgkmcnt(1)                                       // 0000001FB62C: BF89FC17
	v_mul_f32_e32 v20, v91, v20                                // 0000001FB630: 1028295B
	v_mul_f32_e32 v19, v91, v19                                // 0000001FB634: 1026275B
	s_waitcnt lgkmcnt(0)                                       // 0000001FB638: BF89FC07
	v_mul_f32_e32 v22, v91, v22                                // 0000001FB63C: 102C2D5B
	v_dual_mul_f32 v21, v91, v21 :: v_dual_fmac_f32 v24, 0x3b800000, v42// 0000001FB640: C8C02B5B 151854FF 3B800000
	v_dual_fmac_f32 v23, 0x3b800000, v41 :: v_dual_fmac_f32 v26, 0x3b800000, v44// 0000001FB64C: C80052FF 171A58FF 3B800000
	v_dual_fmac_f32 v25, 0x3b800000, v43 :: v_dual_fmac_f32 v28, 0x3b800000, v46// 0000001FB658: C80056FF 191C5CFF 3B800000
	v_dual_fmac_f32 v27, 0x3b800000, v45 :: v_dual_fmac_f32 v30, 0x3b800000, v48// 0000001FB664: C8005AFF 1B1E60FF 3B800000
	v_dual_fmac_f32 v29, 0x3b800000, v47 :: v_dual_fmac_f32 v32, 0x3b800000, v50// 0000001FB670: C8005EFF 1D2064FF 3B800000
	v_dual_fmac_f32 v31, 0x3b800000, v49 :: v_dual_fmac_f32 v34, 0x3b800000, v52// 0000001FB67C: C80062FF 1F2268FF 3B800000
	v_dual_fmac_f32 v33, 0x3b800000, v51 :: v_dual_fmac_f32 v36, 0x3b800000, v54// 0000001FB688: C80066FF 21246CFF 3B800000
	v_dual_fmac_f32 v35, 0x3b800000, v53 :: v_dual_fmac_f32 v38, 0x3b800000, v56// 0000001FB694: C8006AFF 232670FF 3B800000
	v_dual_fmac_f32 v37, 0x3b800000, v55 :: v_dual_fmac_f32 v2, 0x3b800000, v58// 0000001FB6A0: C8006EFF 250274FF 3B800000
	v_dual_fmac_f32 v1, 0x3b800000, v57 :: v_dual_fmac_f32 v4, 0x3b800000, v60// 0000001FB6AC: C80072FF 010478FF 3B800000
	v_dual_fmac_f32 v3, 0x3b800000, v59 :: v_dual_fmac_f32 v6, 0x3b800000, v62// 0000001FB6B8: C80076FF 03067CFF 3B800000
	v_dual_fmac_f32 v5, 0x3b800000, v61 :: v_dual_fmac_f32 v40, 0x3b800000, v64// 0000001FB6C4: C8007AFF 052880FF 3B800000
	v_dual_fmac_f32 v39, 0x3b800000, v63 :: v_dual_fmac_f32 v8, 0x3b800000, v66// 0000001FB6D0: C8007EFF 270884FF 3B800000
	v_dual_fmac_f32 v7, 0x3b800000, v65 :: v_dual_fmac_f32 v10, 0x3b800000, v68// 0000001FB6DC: C80082FF 070A88FF 3B800000
	v_dual_fmac_f32 v9, 0x3b800000, v67 :: v_dual_fmac_f32 v12, 0x3b800000, v70// 0000001FB6E8: C80086FF 090C8CFF 3B800000
	v_dual_fmac_f32 v11, 0x3b800000, v69 :: v_dual_fmac_f32 v14, 0x3b800000, v72// 0000001FB6F4: C8008AFF 0B0E90FF 3B800000
	v_dual_fmac_f32 v13, 0x3b800000, v71 :: v_dual_fmac_f32 v16, 0x3b800000, v74// 0000001FB700: C8008EFF 0D1094FF 3B800000
	v_dual_fmac_f32 v15, 0x3b800000, v73 :: v_dual_fmac_f32 v18, 0x3b800000, v76// 0000001FB70C: C80092FF 0F1298FF 3B800000
	v_dual_fmac_f32 v17, 0x3b800000, v75 :: v_dual_fmac_f32 v20, 0x3b800000, v78// 0000001FB718: C80096FF 11149CFF 3B800000
	v_dual_fmac_f32 v19, 0x3b800000, v77 :: v_dual_fmac_f32 v22, 0x3b800000, v80// 0000001FB724: C8009AFF 1316A0FF 3B800000
	v_fmac_f32_e32 v21, 0x3b800000, v79                        // 0000001FB730: 562A9EFF 3B800000
	ds_store_2addr_b32 v180, v89, v90 offset1:2                // 0000001FB738: D8380200 005A59B4
	ds_store_2addr_b32 v180, v92, v93 offset0:4 offset1:6      // 0000001FB740: D8380604 005D5CB4
	ds_store_2addr_b32 v180, v94, v95 offset0:8 offset1:10     // 0000001FB748: D8380A08 005F5EB4
	ds_store_2addr_b32 v180, v96, v113 offset0:12 offset1:14   // 0000001FB750: D8380E0C 007160B4
	ds_store_2addr_b32 v180, v97, v98 offset0:16 offset1:18    // 0000001FB758: D8381210 006261B4
	ds_store_2addr_b32 v180, v99, v100 offset0:20 offset1:22   // 0000001FB760: D8381614 006463B4
	ds_store_2addr_b32 v180, v101, v102 offset0:24 offset1:26  // 0000001FB768: D8381A18 006665B4
	ds_store_2addr_b32 v180, v103, v104 offset0:28 offset1:30  // 0000001FB770: D8381E1C 006867B4
	ds_store_2addr_b32 v180, v105, v106 offset0:32 offset1:34  // 0000001FB778: D8382220 006A69B4
	ds_store_2addr_b32 v180, v107, v108 offset0:36 offset1:38  // 0000001FB780: D8382624 006C6BB4
	ds_store_2addr_b32 v180, v109, v110 offset0:40 offset1:42  // 0000001FB788: D8382A28 006E6DB4
	ds_store_2addr_b32 v180, v111, v112 offset0:44 offset1:46  // 0000001FB790: D8382E2C 00706FB4
	ds_store_2addr_b32 v180, v23, v24 offset0:48 offset1:50    // 0000001FB798: D8383230 001817B4
	ds_store_2addr_b32 v180, v25, v26 offset0:52 offset1:54    // 0000001FB7A0: D8383634 001A19B4
	ds_store_2addr_b32 v180, v27, v28 offset0:56 offset1:58    // 0000001FB7A8: D8383A38 001C1BB4
	ds_store_2addr_b32 v180, v29, v30 offset0:60 offset1:62    // 0000001FB7B0: D8383E3C 001E1DB4
	ds_store_2addr_b32 v180, v31, v32 offset0:64 offset1:66    // 0000001FB7B8: D8384240 00201FB4
	ds_store_2addr_b32 v180, v33, v34 offset0:68 offset1:70    // 0000001FB7C0: D8384644 002221B4
	ds_store_2addr_b32 v180, v35, v36 offset0:72 offset1:74    // 0000001FB7C8: D8384A48 002423B4
	ds_store_2addr_b32 v180, v37, v38 offset0:76 offset1:78    // 0000001FB7D0: D8384E4C 002625B4
	ds_store_2addr_b32 v180, v1, v2 offset0:80 offset1:82      // 0000001FB7D8: D8385250 000201B4
	ds_store_2addr_b32 v180, v3, v4 offset0:84 offset1:86      // 0000001FB7E0: D8385654 000403B4
	ds_store_2addr_b32 v180, v5, v6 offset0:88 offset1:90      // 0000001FB7E8: D8385A58 000605B4
	ds_store_2addr_b32 v180, v39, v40 offset0:92 offset1:94    // 0000001FB7F0: D8385E5C 002827B4
	ds_store_2addr_b32 v180, v7, v8 offset0:96 offset1:98      // 0000001FB7F8: D8386260 000807B4
	ds_store_2addr_b32 v180, v9, v10 offset0:100 offset1:102   // 0000001FB800: D8386664 000A09B4
	ds_store_2addr_b32 v180, v11, v12 offset0:104 offset1:106  // 0000001FB808: D8386A68 000C0BB4
	ds_store_2addr_b32 v180, v13, v14 offset0:108 offset1:110  // 0000001FB810: D8386E6C 000E0DB4
	ds_store_2addr_b32 v180, v15, v16 offset0:112 offset1:114  // 0000001FB818: D8387270 00100FB4
	ds_store_2addr_b32 v180, v17, v18 offset0:116 offset1:118  // 0000001FB820: D8387674 001211B4
	ds_store_2addr_b32 v180, v19, v20 offset0:120 offset1:122  // 0000001FB828: D8387A78 001413B4
	ds_store_2addr_b32 v180, v21, v22 offset0:124 offset1:126  // 0000001FB830: D8387E7C 001615B4
	s_waitcnt lgkmcnt(0)                                       // 0000001FB838: BF89FC07
	s_barrier                                                  // 0000001FB83C: BFBD0000
	buffer_gl0_inv                                             // 0000001FB840: E0AC0000 00000000
	s_cbranch_scc0 807                                         // 0000001FB848: BFA10327 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7de8>
	s_cmp_lg_u32 s40, s37                                      // 0000001FB84C: BF072528
	s_cbranch_scc0 834                                         // 0000001FB850: BFA10342 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7e5c>
	s_cmp_lg_u32 s40, s38                                      // 0000001FB854: BF072628
	s_cbranch_scc1 59288                                       // 0000001FB858: BFA2E798 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xfbc>
	s_branch 863                                               // 0000001FB85C: BFA0035F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7edc>
	s_clause 0x1                                               // 0000001FB860: BF850001
	global_load_b128 v[69:72], v[106:107], off offset:48       // 0000001FB864: DC5E0030 457C006A
	global_load_b128 v[65:68], v[106:107], off offset:32       // 0000001FB86C: DC5E0020 417C006A
	ds_load_b128 v[73:76], v139 offset:32                      // 0000001FB874: DBFC0020 4900008B
	ds_load_b128 v[77:80], v139 offset:48                      // 0000001FB87C: DBFC0030 4D00008B
	ds_load_b128 v[85:88], v139 offset:2352                    // 0000001FB884: DBFC0930 5500008B
	ds_load_b128 v[81:84], v139 offset:2336                    // 0000001FB88C: DBFC0920 5100008B
	ds_load_b128 v[220:223], v139 offset:4656                  // 0000001FB894: DBFC1230 DC00008B
	ds_load_b128 v[216:219], v139 offset:4640                  // 0000001FB89C: DBFC1220 D800008B
	ds_load_b128 v[228:231], v139 offset:6960                  // 0000001FB8A4: DBFC1B30 E400008B
	ds_load_b128 v[224:227], v139 offset:6944                  // 0000001FB8AC: DBFC1B20 E000008B
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001FB8B4: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[73:80], v[57:64]// 0000001FB8B8: CC404039 1CE69341
	s_waitcnt lgkmcnt(4)                                       // 0000001FB8C0: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[81:88], v[49:56]// 0000001FB8C4: CC404031 1CC6A341
	s_waitcnt lgkmcnt(2)                                       // 0000001FB8CC: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[216:223], v[41:48]// 0000001FB8D0: CC404029 1CA7B141
	s_waitcnt lgkmcnt(0)                                       // 0000001FB8D8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[65:72], v[224:231], v[33:40]// 0000001FB8DC: CC404021 1C87C141
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FB8E4: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000001FB8E8: BE802004
	s_cbranch_execz 63899                                      // 0000001FB8EC: BFA5F99B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x585c>
	ds_load_b128 v[65:68], v139 offset:64                      // 0000001FB8F0: DBFC0040 4100008B
	ds_load_b128 v[69:72], v139 offset:80                      // 0000001FB8F8: DBFC0050 4500008B
	ds_load_b128 v[77:80], v139 offset:2384                    // 0000001FB900: DBFC0950 4D00008B
	ds_load_b128 v[73:76], v139 offset:2368                    // 0000001FB908: DBFC0940 4900008B
	ds_load_b128 v[85:88], v139 offset:4688                    // 0000001FB910: DBFC1250 5500008B
	ds_load_b128 v[81:84], v139 offset:4672                    // 0000001FB918: DBFC1240 5100008B
	ds_load_b128 v[220:223], v139 offset:6992                  // 0000001FB920: DBFC1B50 DC00008B
	ds_load_b128 v[216:219], v139 offset:6976                  // 0000001FB928: DBFC1B40 D800008B
	s_waitcnt vmcnt(2) lgkmcnt(6)                              // 0000001FB930: BF890867
	v_wmma_f32_16x16x16_f16 v[57:64], v[97:104], v[65:72], v[57:64]// 0000001FB934: CC404039 1CE68361
	s_waitcnt lgkmcnt(4)                                       // 0000001FB93C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[97:104], v[73:80], v[49:56]// 0000001FB940: CC404031 1CC69361
	s_waitcnt lgkmcnt(2)                                       // 0000001FB948: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[97:104], v[81:88], v[41:48]// 0000001FB94C: CC404029 1CA6A361
	s_waitcnt lgkmcnt(0)                                       // 0000001FB954: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[97:104], v[216:223], v[33:40]// 0000001FB958: CC404021 1C87B161
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FB960: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000001FB964: BE802006
	s_cbranch_execz 63871                                      // 0000001FB968: BFA5F97F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5868>
	ds_load_b128 v[65:68], v139 offset:96                      // 0000001FB96C: DBFC0060 4100008B
	ds_load_b128 v[69:72], v139 offset:112                     // 0000001FB974: DBFC0070 4500008B
	ds_load_b128 v[77:80], v139 offset:2416                    // 0000001FB97C: DBFC0970 4D00008B
	ds_load_b128 v[73:76], v139 offset:2400                    // 0000001FB984: DBFC0960 4900008B
	ds_load_b128 v[85:88], v139 offset:4720                    // 0000001FB98C: DBFC1270 5500008B
	ds_load_b128 v[81:84], v139 offset:4704                    // 0000001FB994: DBFC1260 5100008B
	s_waitcnt vmcnt(3)                                         // 0000001FB99C: BF890FF7
	ds_load_b128 v[101:104], v139 offset:7024                  // 0000001FB9A0: DBFC1B70 6500008B
	s_waitcnt vmcnt(2)                                         // 0000001FB9A8: BF890BF7
	ds_load_b128 v[97:100], v139 offset:7008                   // 0000001FB9AC: DBFC1B60 6100008B
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001FB9B4: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[89:96], v[65:72], v[57:64]// 0000001FB9B8: CC404039 1CE68359
	s_waitcnt lgkmcnt(4)                                       // 0000001FB9C0: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[89:96], v[73:80], v[49:56]// 0000001FB9C4: CC404031 1CC69359
	s_waitcnt lgkmcnt(2)                                       // 0000001FB9CC: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[81:88], v[41:48]// 0000001FB9D0: CC404029 1CA6A359
	s_waitcnt lgkmcnt(0)                                       // 0000001FB9D8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[89:96], v[97:104], v[33:40]// 0000001FB9DC: CC404021 1C86C359
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FB9E4: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001FB9E8: BE802001
	s_cbranch_execz 63841                                      // 0000001FB9EC: BFA5F961 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5874>
	ds_load_b32 v65, v186                                      // 0000001FB9F0: D8D80000 410000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FB9F8: BF89FC07
	v_fma_f32 v25, v25, v65, v57                               // 0000001FB9FC: D6130019 04E68319
	v_mad_u64_u32 v[65:66], null, 0x3000, v214, v[116:117]     // 0000001FBA04: D6FE7C41 05D3ACFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001FBA10: BF870092
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 0000001FBA14: 103232FF 3B800000
	v_bfe_u32 v57, v25, 16, 1                                  // 0000001FBA1C: D6100039 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBA24: BF870001
	v_add3_u32 v25, v25, v57, 0x7fff                           // 0000001FBA28: D6550019 03FE7319 00007FFF
	global_store_d16_hi_b16 v[65:66], v25, off                 // 0000001FBA34: DC960000 007C1941
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBA3C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001FBA40: BE802007
	s_cbranch_execz 63822                                      // 0000001FBA44: BFA5F94E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5880>
	ds_load_b32 v25, v186 offset:8                             // 0000001FBA48: D8D80008 190000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBA50: BF89FC07
	v_fma_f32 v25, v26, v25, v58                               // 0000001FBA54: D6130019 04EA331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FBA5C: BF870121
	v_mul_f32_e32 v57, 0x3b800000, v25                         // 0000001FBA60: 107232FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v108, v[116:117]     // 0000001FBA68: D6FE7C19 05D2D8FF 00003000
	v_bfe_u32 v58, v57, 16, 1                                  // 0000001FBA74: D610003A 02052139
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBA7C: BF870001
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000001FBA80: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[25:26], v57, off                 // 0000001FBA8C: DC960000 007C3919
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBA94: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001FBA98: BE802008
	s_cbranch_execz 63803                                      // 0000001FBA9C: BFA5F93B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x588c>
	ds_load_b32 v25, v186 offset:16                            // 0000001FBAA0: D8D80010 190000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBAA8: BF89FC07
	v_fma_f32 v25, v27, v25, v59                               // 0000001FBAAC: D6130019 04EE331B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FBAB4: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001FBAB8: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v109, v[116:117]     // 0000001FBAC0: D6FE7C19 05D2DAFF 00003000
	v_bfe_u32 v57, v27, 16, 1                                  // 0000001FBACC: D6100039 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBAD4: BF870001
	v_add3_u32 v27, v27, v57, 0x7fff                           // 0000001FBAD8: D655001B 03FE731B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001FBAE4: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBAEC: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001FBAF0: BE802009
	s_cbranch_execz 63784                                      // 0000001FBAF4: BFA5F928 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5898>
	ds_load_b32 v25, v186 offset:24                            // 0000001FBAF8: D8D80018 190000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBB00: BF89FC07
	v_fma_f32 v25, v28, v25, v60                               // 0000001FBB04: D6130019 04F2331C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FBB0C: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001FBB10: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v110, v[116:117]     // 0000001FBB18: D6FE7C19 05D2DCFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001FBB24: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBB2C: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001FBB30: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001FBB3C: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBB44: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001FBB48: BE80200A
	s_cbranch_execz 63765                                      // 0000001FBB4C: BFA5F915 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x58a4>
	ds_load_b32 v25, v186 offset:32                            // 0000001FBB50: D8D80020 190000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBB58: BF89FC07
	v_fma_f32 v25, v29, v25, v61                               // 0000001FBB5C: D6130019 04F6331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FBB64: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001FBB68: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v111, v[116:117]     // 0000001FBB70: D6FE7C19 05D2DEFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001FBB7C: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBB84: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001FBB88: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001FBB94: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBB9C: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001FBBA0: BE80200B
	s_cbranch_execz 63746                                      // 0000001FBBA4: BFA5F902 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x58b0>
	ds_load_b32 v25, v186 offset:40                            // 0000001FBBA8: D8D80028 190000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBBB0: BF89FC07
	v_fma_f32 v25, v30, v25, v62                               // 0000001FBBB4: D6130019 04FA331E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FBBBC: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001FBBC0: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v112, v[116:117]     // 0000001FBBC8: D6FE7C19 05D2E0FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001FBBD4: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBBDC: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001FBBE0: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001FBBEC: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBBF4: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001FBBF8: BE80200C
	s_cbranch_execz 63727                                      // 0000001FBBFC: BFA5F8EF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x58bc>
	ds_load_b32 v25, v186 offset:48                            // 0000001FBC00: D8D80030 190000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBC08: BF89FC07
	v_fma_f32 v25, v31, v25, v63                               // 0000001FBC0C: D6130019 04FE331F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FBC14: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001FBC18: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v113, v[116:117]     // 0000001FBC20: D6FE7C19 05D2E2FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001FBC2C: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBC34: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001FBC38: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001FBC44: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBC4C: 8C7E007E
	s_and_saveexec_b32 s0, s13                                 // 0000001FBC50: BE80200D
	s_cbranch_execz 63708                                      // 0000001FBC54: BFA5F8DC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x58c8>
	ds_load_b32 v25, v186 offset:56                            // 0000001FBC58: D8D80038 190000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBC60: BF89FC07
	v_fmac_f32_e32 v64, v32, v25                               // 0000001FBC64: 56803320
	v_mad_u64_u32 v[25:26], null, 0x3000, v215, v[116:117]     // 0000001FBC68: D6FE7C19 05D3AEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001FBC74: BF870092
	v_mul_f32_e32 v27, 0x3b800000, v64                         // 0000001FBC78: 103680FF 3B800000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001FBC80: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBC88: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001FBC8C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001FBC98: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBCA0: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001FBCA4: BE802001
	s_cbranch_execz 63690                                      // 0000001FBCA8: BFA5F8CA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x58d4>
	ds_load_b32 v25, v186                                      // 0000001FBCAC: D8D80000 190000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBCB4: BF89FC07
	v_fma_f32 v9, v9, v25, v49                                 // 0000001FBCB8: D6130009 04C63309
	v_mad_u64_u32 v[25:26], null, 0x3000, v214, v[116:117]     // 0000001FBCC0: D6FE7C19 05D3ACFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001FBCCC: BF870092
	v_mul_f32_e32 v9, 0x3b800000, v9                           // 0000001FBCD0: 101212FF 3B800000
	v_bfe_u32 v27, v9, 16, 1                                   // 0000001FBCD8: D610001B 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBCE0: BF870001
	v_add3_u32 v9, v9, v27, 0x7fff                             // 0000001FBCE4: D6550009 03FE3709 00007FFF
	global_store_d16_hi_b16 v[25:26], v9, off offset:32        // 0000001FBCF0: DC960020 007C0919
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBCF8: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001FBCFC: BE802007
	s_cbranch_execz 63671                                      // 0000001FBD00: BFA5F8B7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x58e0>
	ds_load_b32 v9, v186 offset:8                              // 0000001FBD04: D8D80008 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBD0C: BF89FC07
	v_fma_f32 v9, v10, v9, v50                                 // 0000001FBD10: D6130009 04CA130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FBD18: BF870121
	v_mul_f32_e32 v25, 0x3b800000, v9                          // 0000001FBD1C: 103212FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v108, v[116:117]      // 0000001FBD24: D6FE7C09 05D2D8FF 00003000
	v_bfe_u32 v26, v25, 16, 1                                  // 0000001FBD30: D610001A 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBD38: BF870001
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000001FBD3C: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[9:10], v25, off offset:32        // 0000001FBD48: DC960020 007C1909
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBD50: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001FBD54: BE802008
	s_cbranch_execz 63652                                      // 0000001FBD58: BFA5F8A4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x58ec>
	ds_load_b32 v9, v186 offset:16                             // 0000001FBD5C: D8D80010 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBD64: BF89FC07
	v_fma_f32 v9, v11, v9, v51                                 // 0000001FBD68: D6130009 04CE130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FBD70: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001FBD74: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v109, v[116:117]      // 0000001FBD7C: D6FE7C09 05D2DAFF 00003000
	v_bfe_u32 v25, v11, 16, 1                                  // 0000001FBD88: D6100019 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBD90: BF870001
	v_add3_u32 v11, v11, v25, 0x7fff                           // 0000001FBD94: D655000B 03FE330B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001FBDA0: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBDA8: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001FBDAC: BE802009
	s_cbranch_execz 63633                                      // 0000001FBDB0: BFA5F891 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x58f8>
	ds_load_b32 v9, v186 offset:24                             // 0000001FBDB4: D8D80018 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBDBC: BF89FC07
	v_fma_f32 v9, v12, v9, v52                                 // 0000001FBDC0: D6130009 04D2130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FBDC8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001FBDCC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v110, v[116:117]      // 0000001FBDD4: D6FE7C09 05D2DCFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001FBDE0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBDE8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001FBDEC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001FBDF8: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBE00: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001FBE04: BE80200A
	s_cbranch_execz 63614                                      // 0000001FBE08: BFA5F87E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5904>
	ds_load_b32 v9, v186 offset:32                             // 0000001FBE0C: D8D80020 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBE14: BF89FC07
	v_fma_f32 v9, v13, v9, v53                                 // 0000001FBE18: D6130009 04D6130D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FBE20: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001FBE24: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v111, v[116:117]      // 0000001FBE2C: D6FE7C09 05D2DEFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001FBE38: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBE40: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001FBE44: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001FBE50: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBE58: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001FBE5C: BE80200B
	s_cbranch_execz 63595                                      // 0000001FBE60: BFA5F86B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5910>
	ds_load_b32 v9, v186 offset:40                             // 0000001FBE64: D8D80028 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBE6C: BF89FC07
	v_fma_f32 v9, v14, v9, v54                                 // 0000001FBE70: D6130009 04DA130E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FBE78: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001FBE7C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v112, v[116:117]      // 0000001FBE84: D6FE7C09 05D2E0FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001FBE90: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBE98: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001FBE9C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001FBEA8: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBEB0: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001FBEB4: BE80200C
	s_cbranch_execz 63576                                      // 0000001FBEB8: BFA5F858 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x591c>
	ds_load_b32 v9, v186 offset:48                             // 0000001FBEBC: D8D80030 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBEC4: BF89FC07
	v_fma_f32 v9, v15, v9, v55                                 // 0000001FBEC8: D6130009 04DE130F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FBED0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001FBED4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v113, v[116:117]      // 0000001FBEDC: D6FE7C09 05D2E2FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001FBEE8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBEF0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001FBEF4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001FBF00: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBF08: 8C7E007E
	s_and_saveexec_b32 s0, s13                                 // 0000001FBF0C: BE80200D
	s_cbranch_execz 63557                                      // 0000001FBF10: BFA5F845 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5928>
	ds_load_b32 v9, v186 offset:56                             // 0000001FBF14: D8D80038 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBF1C: BF89FC07
	v_fmac_f32_e32 v56, v16, v9                                // 0000001FBF20: 56701310
	v_mad_u64_u32 v[9:10], null, 0x3000, v215, v[116:117]      // 0000001FBF24: D6FE7C09 05D3AEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001FBF30: BF870092
	v_mul_f32_e32 v11, 0x3b800000, v56                         // 0000001FBF34: 101670FF 3B800000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001FBF3C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBF44: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001FBF48: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001FBF54: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBF5C: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001FBF60: BE802001
	s_cbranch_execz 63539                                      // 0000001FBF64: BFA5F833 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5934>
	ds_load_b32 v9, v186                                       // 0000001FBF68: D8D80000 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBF70: BF89FC07
	v_fma_f32 v9, v17, v9, v41                                 // 0000001FBF74: D6130009 04A61311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FBF7C: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001FBF80: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v214, v[116:117]      // 0000001FBF88: D6FE7C09 05D3ACFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001FBF94: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBF9C: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001FBFA0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001FBFAC: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FBFB4: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001FBFB8: BE802007
	s_cbranch_execz 63520                                      // 0000001FBFBC: BFA5F820 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5940>
	ds_load_b32 v9, v186 offset:8                              // 0000001FBFC0: D8D80008 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FBFC8: BF89FC07
	v_fma_f32 v9, v18, v9, v42                                 // 0000001FBFCC: D6130009 04AA1312
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FBFD4: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001FBFD8: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v108, v[116:117]      // 0000001FBFE0: D6FE7C09 05D2D8FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001FBFEC: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FBFF4: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001FBFF8: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001FC004: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC00C: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001FC010: BE802008
	s_cbranch_execz 63501                                      // 0000001FC014: BFA5F80D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x594c>
	ds_load_b32 v9, v186 offset:16                             // 0000001FC018: D8D80010 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FC020: BF89FC07
	v_fma_f32 v9, v19, v9, v43                                 // 0000001FC024: D6130009 04AE1313
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FC02C: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001FC030: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v109, v[116:117]      // 0000001FC038: D6FE7C09 05D2DAFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001FC044: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FC04C: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001FC050: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001FC05C: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC064: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001FC068: BE802009
	s_cbranch_execz 63482                                      // 0000001FC06C: BFA5F7FA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5958>
	ds_load_b32 v9, v186 offset:24                             // 0000001FC070: D8D80018 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FC078: BF89FC07
	v_fma_f32 v9, v20, v9, v44                                 // 0000001FC07C: D6130009 04B21314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FC084: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001FC088: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v110, v[116:117]      // 0000001FC090: D6FE7C09 05D2DCFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001FC09C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FC0A4: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001FC0A8: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001FC0B4: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC0BC: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001FC0C0: BE80200A
	s_cbranch_execz 63463                                      // 0000001FC0C4: BFA5F7E7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5964>
	ds_load_b32 v9, v186 offset:32                             // 0000001FC0C8: D8D80020 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FC0D0: BF89FC07
	v_fma_f32 v9, v21, v9, v45                                 // 0000001FC0D4: D6130009 04B61315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FC0DC: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001FC0E0: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v111, v[116:117]      // 0000001FC0E8: D6FE7C09 05D2DEFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001FC0F4: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FC0FC: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001FC100: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001FC10C: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC114: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001FC118: BE80200B
	s_cbranch_execz 63444                                      // 0000001FC11C: BFA5F7D4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5970>
	ds_load_b32 v9, v186 offset:40                             // 0000001FC120: D8D80028 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FC128: BF89FC07
	v_fma_f32 v9, v22, v9, v46                                 // 0000001FC12C: D6130009 04BA1316
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FC134: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001FC138: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v112, v[116:117]      // 0000001FC140: D6FE7C09 05D2E0FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001FC14C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FC154: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001FC158: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001FC164: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC16C: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001FC170: BE80200C
	s_cbranch_execz 63425                                      // 0000001FC174: BFA5F7C1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x597c>
	ds_load_b32 v9, v186 offset:48                             // 0000001FC178: D8D80030 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FC180: BF89FC07
	v_fma_f32 v9, v23, v9, v47                                 // 0000001FC184: D6130009 04BE1317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FC18C: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001FC190: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v113, v[116:117]      // 0000001FC198: D6FE7C09 05D2E2FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001FC1A4: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FC1AC: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001FC1B0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001FC1BC: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC1C4: 8C7E007E
	s_and_saveexec_b32 s0, s13                                 // 0000001FC1C8: BE80200D
	s_cbranch_execz 63406                                      // 0000001FC1CC: BFA5F7AE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5988>
	ds_load_b32 v9, v186 offset:56                             // 0000001FC1D0: D8D80038 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FC1D8: BF89FC07
	v_fmac_f32_e32 v48, v24, v9                                // 0000001FC1DC: 56601318
	v_mad_u64_u32 v[9:10], null, 0x3000, v215, v[116:117]      // 0000001FC1E0: D6FE7C09 05D3AEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001FC1EC: BF870092
	v_mul_f32_e32 v11, 0x3b800000, v48                         // 0000001FC1F0: 101660FF 3B800000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001FC1F8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FC200: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001FC204: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001FC210: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC218: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001FC21C: BE802001
	s_cbranch_execz 63388                                      // 0000001FC220: BFA5F79C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5994>
	ds_load_b32 v9, v186                                       // 0000001FC224: D8D80000 090000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FC22C: BF89FC07
	v_fma_f32 v1, v1, v9, v33                                  // 0000001FC230: D6130001 04861301
	v_mad_u64_u32 v[9:10], null, 0x3000, v214, v[116:117]      // 0000001FC238: D6FE7C09 05D3ACFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001FC244: BF870092
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 0000001FC248: 100202FF 3B800000
	v_bfe_u32 v11, v1, 16, 1                                   // 0000001FC250: D610000B 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FC258: BF870001
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001FC25C: D6550001 03FE1701 00007FFF
	global_store_d16_hi_b16 v[9:10], v1, off offset:96         // 0000001FC268: DC960060 007C0109
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC270: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001FC274: BE802007
	s_cbranch_execz 63369                                      // 0000001FC278: BFA5F789 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x59a0>
	ds_load_b32 v1, v186 offset:8                              // 0000001FC27C: D8D80008 010000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FC284: BF89FC07
	v_fma_f32 v1, v2, v1, v34                                  // 0000001FC288: D6130001 048A0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FC290: BF870121
	v_mul_f32_e32 v9, 0x3b800000, v1                           // 0000001FC294: 101202FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v108, v[116:117]       // 0000001FC29C: D6FE7C01 05D2D8FF 00003000
	v_bfe_u32 v10, v9, 16, 1                                   // 0000001FC2A8: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FC2B0: BF870001
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000001FC2B4: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[1:2], v9, off offset:96          // 0000001FC2C0: DC960060 007C0901
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC2C8: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001FC2CC: BE802008
	s_cbranch_execz 63350                                      // 0000001FC2D0: BFA5F776 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x59ac>
	ds_load_b32 v1, v186 offset:16                             // 0000001FC2D4: D8D80010 010000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FC2DC: BF89FC07
	v_fma_f32 v1, v3, v1, v35                                  // 0000001FC2E0: D6130001 048E0303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FC2E8: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001FC2EC: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v109, v[116:117]       // 0000001FC2F4: D6FE7C01 05D2DAFF 00003000
	v_bfe_u32 v9, v3, 16, 1                                    // 0000001FC300: D6100009 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FC308: BF870001
	v_add3_u32 v3, v3, v9, 0x7fff                              // 0000001FC30C: D6550003 03FE1303 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001FC318: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC320: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001FC324: BE802009
	s_cbranch_execz 63331                                      // 0000001FC328: BFA5F763 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x59b8>
	ds_load_b32 v1, v186 offset:24                             // 0000001FC32C: D8D80018 010000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FC334: BF89FC07
	v_fma_f32 v1, v4, v1, v36                                  // 0000001FC338: D6130001 04920304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FC340: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001FC344: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v110, v[116:117]       // 0000001FC34C: D6FE7C01 05D2DCFF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001FC358: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FC360: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001FC364: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001FC370: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC378: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001FC37C: BE80200A
	s_cbranch_execz 63312                                      // 0000001FC380: BFA5F750 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x59c4>
	ds_load_b32 v1, v186 offset:32                             // 0000001FC384: D8D80020 010000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FC38C: BF89FC07
	v_fma_f32 v1, v5, v1, v37                                  // 0000001FC390: D6130001 04960305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FC398: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001FC39C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v111, v[116:117]       // 0000001FC3A4: D6FE7C01 05D2DEFF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001FC3B0: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FC3B8: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001FC3BC: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001FC3C8: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC3D0: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001FC3D4: BE80200B
	s_cbranch_execz 63293                                      // 0000001FC3D8: BFA5F73D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x59d0>
	ds_load_b32 v1, v186 offset:40                             // 0000001FC3DC: D8D80028 010000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FC3E4: BF89FC07
	v_fma_f32 v1, v6, v1, v38                                  // 0000001FC3E8: D6130001 049A0306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FC3F0: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001FC3F4: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v112, v[116:117]       // 0000001FC3FC: D6FE7C01 05D2E0FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001FC408: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FC410: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001FC414: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001FC420: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC428: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001FC42C: BE80200C
	s_cbranch_execz 63274                                      // 0000001FC430: BFA5F72A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x59dc>
	ds_load_b32 v1, v186 offset:48                             // 0000001FC434: D8D80030 010000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FC43C: BF89FC07
	v_fma_f32 v1, v7, v1, v39                                  // 0000001FC440: D6130001 049E0307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FC448: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001FC44C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v113, v[116:117]       // 0000001FC454: D6FE7C01 05D2E2FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001FC460: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001FC468: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001FC46C: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001FC478: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC480: 8C7E007E
	s_and_saveexec_b32 s0, s13                                 // 0000001FC484: BE80200D
	s_cbranch_execz 63255                                      // 0000001FC488: BFA5F717 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x59e8>
	ds_load_b32 v1, v186 offset:56                             // 0000001FC48C: D8D80038 010000BA
	s_waitcnt lgkmcnt(0)                                       // 0000001FC494: BF89FC07
	v_fmac_f32_e32 v40, v8, v1                                 // 0000001FC498: 56500308
	v_mad_u64_u32 v[1:2], null, 0x3000, v215, v[116:117]       // 0000001FC49C: D6FE7C01 05D3AEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001FC4A8: BF870092
	v_mul_f32_e32 v3, 0x3b800000, v40                          // 0000001FC4AC: 100650FF 3B800000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001FC4B4: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000001FC4BC: BF8704C1
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001FC4C0: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001FC4CC: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001FC4D4: 8C7E007E
	s_add_i32 s7, s40, 1                                       // 0000001FC4D8: 81078128
	s_cmp_ge_i32 s7, s51                                       // 0000001FC4DC: BF033307
	s_cbranch_scc0 63238                                       // 0000001FC4E0: BFA1F706 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x59fc>
	s_branch 64122                                             // 0000001FC4E4: BFA0FA7A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67d0>
	v_dual_mov_b32 v1, v133 :: v_dual_mov_b32 v4, v127         // 0000001FC4E8: CA100185 0104017F
	v_dual_mov_b32 v3, v132 :: v_dual_mov_b32 v2, v134         // 0000001FC4F0: CA100184 03020186
	s_mov_b32 s8, 0                                            // 0000001FC4F8: BE880080
	s_nop 0                                                    // 0000001FC4FC: BF800000
	ds_load_b32 v5, v3                                         // 0000001FC500: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001FC508: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001FC510: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001FC514: BF8700D2
	.long 0xd4490000                                           // 0000001FC518: D4490000
	v_cndmask_b32_e32 v1, 0x1f7f, v4, vcc_lo                   // 0000001FC51C: 020208FF 00001F7F
	s_or_b32 s8, s0, s8                                        // 0000001FC524: 8C080800
	s_waitcnt lgkmcnt(0)                                       // 0000001FC528: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001FC52C: DC6A0000 007C0501
	.long 0xd7000101                                           // 0000001FC534: D7000101
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001FC538: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s1                    // 0000001FC540: D5207C02 00060480
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000001FC548: 917E087E
	s_cbranch_execnz 65516                                     // 0000001FC54C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7e00>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001FC550: 8C7E087E
	s_cmp_lg_u32 s40, s37                                      // 0000001FC554: BF072528
	s_cbranch_scc1 64702                                       // 0000001FC558: BFA2FCBE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7154>
	v_dual_mov_b32 v1, v130 :: v_dual_mov_b32 v4, v127         // 0000001FC55C: CA100182 0104017F
	v_dual_mov_b32 v3, v132 :: v_dual_mov_b32 v2, v131         // 0000001FC564: CA100184 03020183
	s_mov_b32 s8, 0                                            // 0000001FC56C: BE880080
	s_nop 0                                                    // 0000001FC570: BF800000
	s_nop 0                                                    // 0000001FC574: BF800000
	s_nop 0                                                    // 0000001FC578: BF800000
	s_nop 0                                                    // 0000001FC57C: BF800000
	ds_load_b32 v5, v3                                         // 0000001FC580: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001FC588: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001FC590: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001FC594: BF8700D2
	.long 0xd4490000                                           // 0000001FC598: D4490000
	v_cndmask_b32_e32 v1, 0x1f7f, v4, vcc_lo                   // 0000001FC59C: 020208FF 00001F7F
	s_or_b32 s8, s0, s8                                        // 0000001FC5A4: 8C080800
	s_waitcnt lgkmcnt(0)                                       // 0000001FC5A8: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001FC5AC: DC6A0000 007C0501
	.long 0xd7000101                                           // 0000001FC5B4: D7000101
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001FC5B8: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s1                    // 0000001FC5C0: D5207C02 00060480
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000001FC5C8: 917E087E
	s_cbranch_execnz 65516                                     // 0000001FC5CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7e80>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001FC5D0: 8C7E087E
	s_cmp_lg_u32 s40, s38                                      // 0000001FC5D4: BF072628
	s_cbranch_scc1 58424                                       // 0000001FC5D8: BFA2E438 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xfbc>
	v_dual_mov_b32 v1, v122 :: v_dual_mov_b32 v4, v127         // 0000001FC5DC: CA10017A 0104017F
	v_dual_mov_b32 v3, v132 :: v_dual_mov_b32 v2, v123         // 0000001FC5E4: CA100184 0302017B
	s_mov_b32 s8, 0                                            // 0000001FC5EC: BE880080
	s_nop 0                                                    // 0000001FC5F0: BF800000
	s_nop 0                                                    // 0000001FC5F4: BF800000
	s_nop 0                                                    // 0000001FC5F8: BF800000
	s_nop 0                                                    // 0000001FC5FC: BF800000
	ds_load_b32 v5, v3                                         // 0000001FC600: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001FC608: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001FC610: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001FC614: BF8700D2
	.long 0xd4490000                                           // 0000001FC618: D4490000
	v_cndmask_b32_e32 v1, 0x1f7f, v4, vcc_lo                   // 0000001FC61C: 020208FF 00001F7F
	s_or_b32 s8, s0, s8                                        // 0000001FC624: 8C080800
	s_waitcnt lgkmcnt(0)                                       // 0000001FC628: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001FC62C: DC6A0000 007C0501
	.long 0xd7000101                                           // 0000001FC634: D7000101
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001FC638: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s1                    // 0000001FC640: D5207C02 00060480
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000001FC648: 917E087E
	s_cbranch_execnz 65516                                     // 0000001FC64C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7f00>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001FC650: 8C7E087E
	s_branch 58393                                             // 0000001FC654: BFA0E419 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xfbc>
	s_clause 0x1                                               // 0000001FC658: BF850001
	scratch_load_b32 v17, off, off offset:8                    // 0000001FC65C: DC510008 117C0000
	scratch_load_b32 v7, off, off offset:12                    // 0000001FC664: DC51000C 077C0000
	v_dual_mov_b32 v1, s48 :: v_dual_mov_b32 v2, s49           // 0000001FC66C: CA100030 01020031
	v_mov_b32_e32 v6, v127                                     // 0000001FC674: 7E0C037F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001FC678: BF870091
	.long 0xd7006a00                                           // 0000001FC67C: D7006A00
	v_cndmask_b32_e32 v0, v1, v18, vcc_lo                      // 0000001FC680: 02002501
	v_add_co_ci_u32_e64 v1, null, s19, v2, vcc_lo              // 0000001FC684: D5207C01 01AA0413
	s_add_u32 s0, s33, s34                                     // 0000001FC68C: 80002221
	s_addc_u32 s1, s15, s35                                    // 0000001FC690: 8201230F
	.long 0xd7006a00                                           // 0000001FC694: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000001FC698: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001FC69C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000001FC6A0: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000001FC6A8: BE810080
	.long 0xd7006a00                                           // 0000001FC6AC: D7006A00
	v_cndmask_b32_e32 v1, v0, v114, vcc_lo                     // 0000001FC6B0: 0202E500
	v_add_co_ci_u32_e64 v1, null, v1, v115, vcc_lo             // 0000001FC6B4: D5207C01 01AAE701
	s_waitcnt vmcnt(1)                                         // 0000001FC6BC: BF8907F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001FC6C0: BF870122
	.long 0xd7006a00                                           // 0000001FC6C4: D7006A00
	v_cndmask_b32_e32 v1, v0, v17, vcc_lo                      // 0000001FC6C8: 02022300
	s_waitcnt vmcnt(0)                                         // 0000001FC6CC: BF8903F7
	v_add_co_ci_u32_e64 v1, null, v1, v7, vcc_lo               // 0000001FC6D0: D5207C01 01AA0F01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001FC6D8: BF870092
	.long 0xd7006a00                                           // 0000001FC6DC: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000001FC6E0: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000001FC6E4: D5207C01 01AA0211
	s_nop 0                                                    // 0000001FC6EC: BF800000
	s_nop 0                                                    // 0000001FC6F0: BF800000
	s_nop 0                                                    // 0000001FC6F4: BF800000
	s_nop 0                                                    // 0000001FC6F8: BF800000
	s_nop 0                                                    // 0000001FC6FC: BF800000
	ds_load_b32 v2, v132                                       // 0000001FC700: D8D80000 02000084
	v_add_nc_u32_e32 v6, 0x80, v6                              // 0000001FC708: 4A0C0CFF 00000080
	v_add_nc_u32_e32 v132, 8, v132                             // 0000001FC710: 4B090888
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001FC714: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v6                        // 0000001FC718: 7C920CFF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001FC720: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001FC724: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000001FC728: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000001FC730: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 0000001FC734: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000001FC73C: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001FC744: 917E017E
	s_cbranch_execnz 65517                                     // 0000001FC748: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi0ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8000>
	s_nop 0                                                    // 0000001FC74C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001FC750: BFB60003
	s_endpgm                                                   // 0000001FC754: BFB00000
		...

