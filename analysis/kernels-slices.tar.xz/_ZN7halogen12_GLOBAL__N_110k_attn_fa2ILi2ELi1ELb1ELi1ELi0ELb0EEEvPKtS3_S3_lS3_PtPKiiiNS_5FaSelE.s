00000000000e8f00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 0000000E8F00: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 0000000E8F04: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 0000000E8F0C: F4080500 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 0000000E8F14: 3706009F
	v_lshrrev_b32_e32 v155, 5, v0                              // 0000000E8F18: 33360085
	s_mov_b32 s24, s3                                          // 0000000E8F1C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E8F20: BF870112
	.long 0xd44c0003                                           // 0000000E8F24: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 0000000E8F28: 02030690
	v_lshlrev_b32_e32 v132, 6, v155                            // 0000000E8F2C: 31093686
	s_waitcnt lgkmcnt(0)                                       // 0000000E8F30: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 0000000E8F34: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 0000000E8F3C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E8F40: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 0000000E8F44: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 0000000E8F4C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:231 offset1:243// 0000000E8F58: D83CF3E7 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000E8F60: 8C7E047E
	v_mul_u32_u24_e32 v1, 0x2ab, v0                            // 0000000E8F64: 160200FF 000002AB
	s_lshl_b32 s25, s2, 5                                      // 0000000E8F6C: 84198502
	v_dual_mov_b32 v141, 0 :: v_dual_and_b32 v154, 15, v0      // 0000000E8F70: CA240080 8D9A008F
	s_cmp_eq_u64 s[14:15], 0                                   // 0000000E8F78: BF10800E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000E8F7C: BF8704C2
	.long 0xd7381001                                           // 0000000E8F80: D7381001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000000E8F84: 02020282
	.long 0x7f023880                                           // 0000000E8F88: 7F023880
	v_mov_b32_e32 v142, 0                                      // 0000000E8F8C: 7F1C0280
	s_cselect_b32 s27, -1, 0                                   // 0000000E8F90: 981B80C1
	s_and_b32 vcc_lo, exec_lo, s27                             // 0000000E8F94: 8B6A1B7E
	.long 0xd7620001                                           // 0000000E8F98: D7620001
	v_cndmask_b32_e32 v0, v1, v176, vcc_lo                     // 0000000E8F9C: 02016101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8FA0: BF870091
	v_add_nc_u32_e32 v156, s25, v1                             // 0000000E8FA4: 4B380219
	v_or_b32_e32 v129, v156, v154                              // 0000000E8FA8: 3903359C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E8FAC: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000E8FB0: 3505029F
	s_cbranch_vccnz 10                                         // 0000000E8FB4: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xe0>
	v_mad_i64_i32 v[1:2], null, s23, v129, 0                   // 0000000E8FB8: D6FF7C01 02030217
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E8FC0: BF870091
	.long 0xd73c0001                                           // 0000000E8FC4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000000E8FC8: 02020282
	.long 0xd7006a8d                                           // 0000000E8FCC: D7006A8D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000000E8FD0: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E8FD4: BF870001
	v_add_co_ci_u32_e64 v142, null, s15, v2, vcc_lo            // 0000000E8FD8: D5207C8E 01AA040F
	s_clause 0x2                                               // 0000000E8FE0: BF850002
	s_load_b64 s[14:15], s[0:1], 0x38                          // 0000000E8FE4: F4040380 F8000038
	s_load_b128 s[16:19], s[0:1], 0x20                         // 0000000E8FEC: F4080400 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000000E8FF4: F40C0100 F8000000
	v_mov_b32_e32 v158, 0                                      // 0000000E8FFC: 7F3C0280
	s_xor_b32 s0, s27, -1                                      // 0000000E9000: 8D00C11B
	s_waitcnt lgkmcnt(0)                                       // 0000000E9004: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v129                         // 0000000E9008: 7C89020E
	s_and_b32 s23, s0, vcc_lo                                  // 0000000E900C: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000E9010: BF870009
	s_and_saveexec_b32 s0, s23                                 // 0000000E9014: BE802017
	s_cbranch_execz 9                                          // 0000000E9018: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x140>
	.long 0xd73c0001                                           // 0000000E901C: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 0000000E9020: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E9024: BF870091
	.long 0xd7006a01                                           // 0000000E9028: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 0000000E902C: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 0000000E9030: D5207C02 01AA0415
	global_load_b32 v158, v[1:2], off                          // 0000000E9038: DC520000 9E7C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000E9040: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 0000000E9044: BF10800C
	s_mov_b64 s[20:21], 0                                      // 0000000E9048: BE940180
	s_cbranch_scc1 10                                          // 0000000E904C: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x178>
	s_ashr_i32 s0, s22, 31                                     // 0000000E9050: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 0000000E9054: 96810216
	s_mul_i32 s0, s0, s2                                       // 0000000E9058: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000E905C: BF8704A9
	s_add_i32 s1, s1, s0                                       // 0000000E9060: 81010001
	s_mul_i32 s0, s22, s2                                      // 0000000E9064: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000000E9068: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000E906C: BF870009
	s_add_u32 s20, s12, s0                                     // 0000000E9070: 8014000C
	s_addc_u32 s21, s13, s1                                    // 0000000E9074: 8215010D
	.long 0xd7050001                                           // 0000000E9078: D7050001
	v_cndmask_b32_e32 v0, v155, v150, vcc_lo                   // 0000000E907C: 02012D9B
	s_or_b32 s25, s25, 31                                      // 0000000E9080: 8C199F19
	s_add_i32 s0, s14, -1                                      // 0000000E9084: 8100C10E
	v_lshrrev_b32_e32 v157, 4, v131                            // 0000000E9088: 333B0684
	s_min_i32 s0, s25, s0                                      // 0000000E908C: 89000019
	.long 0xd7390001                                           // 0000000E9090: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000000E9094: 02020288
	s_add_i32 s0, s26, s0                                      // 0000000E9098: 8100001A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E909C: BF870099
	s_cmp_lt_i32 s0, -15                                       // 0000000E90A0: BF04CF00
	.long 0xd7050001                                           // 0000000E90A4: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 0000000E90A8: 02011901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E90AC: BF870091
	.long 0xd7040001                                           // 0000000E90B0: D7040001
	v_cndmask_b32_e32 v1, v155, v1, vcc_lo                     // 0000000E90B4: 0202039B
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 0000000E90B8: CA240080 480002FF 000000FF
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E90C4: BF870001
	v_mov_b32_e32 v71, v72                                     // 0000000E90C8: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 0000000E90CC: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 0000000E90D0: 7E880348
	v_mov_b32_e32 v67, v72                                     // 0000000E90D4: 7E860348
	v_mad_u64_u32 v[138:139], null, s24, 12, v[1:2]            // 0000000E90D8: D6FE7C8A 04051818
	v_mov_b32_e32 v70, v72                                     // 0000000E90E0: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 0000000E90E4: 7E840348
	v_mov_b32_e32 v65, v72                                     // 0000000E90E8: 7E820348
	v_mov_b32_e32 v80, v72                                     // 0000000E90EC: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 0000000E90F0: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 0000000E90F4: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 0000000E90F8: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 0000000E90FC: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 0000000E9104: 7E960348
	v_mov_b32_e32 v74, v72                                     // 0000000E9108: 7E940348
	v_mov_b32_e32 v73, v72                                     // 0000000E910C: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000E9110: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000000E9114: 3404029F
	v_mov_b32_e32 v88, v72                                     // 0000000E9118: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 0000000E911C: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 0000000E9120: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 0000000E9124: 7EAA0348
	.long 0xd73c008b                                           // 0000000E9128: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000000E912C: 02020281
	v_mov_b32_e32 v84, v72                                     // 0000000E9130: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 0000000E9134: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 0000000E9138: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 0000000E913C: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 0000000E9140: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 0000000E9144: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 0000000E9148: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 0000000E914C: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 0000000E9150: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 0000000E9154: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 0000000E9158: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 0000000E915C: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 0000000E9160: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 0000000E9164: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 0000000E9168: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 0000000E916C: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 0000000E9170: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 0000000E9174: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 0000000E9178: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 0000000E917C: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 0000000E9180: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 0000000E9184: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 0000000E9188: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 0000000E918C: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 0000000E9190: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 0000000E9194: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 0000000E9198: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 0000000E919C: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 0000000E91A0: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 0000000E91A4: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 0000000E91A8: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 0000000E91AC: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 0000000E91B0: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 0000000E91B4: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 0000000E91B8: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 0000000E91BC: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 0000000E91C0: 7F000348
	v_mov_b32_e32 v127, v72                                    // 0000000E91C4: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 0000000E91C8: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 0000000E91CC: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 0000000E91D0: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 0000000E91D4: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 0000000E91D8: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 0000000E91DC: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 0000000E91E0: 7E800348
	v_mov_b32_e32 v63, v72                                     // 0000000E91E4: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 0000000E91E8: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 0000000E91EC: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 0000000E91F0: 7E780348
	v_mov_b32_e32 v59, v72                                     // 0000000E91F4: 7E760348
	v_mov_b32_e32 v58, v72                                     // 0000000E91F8: 7E740348
	v_mov_b32_e32 v57, v72                                     // 0000000E91FC: 7E720348
	v_mov_b32_e32 v56, v72                                     // 0000000E9200: 7E700348
	v_mov_b32_e32 v55, v72                                     // 0000000E9204: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 0000000E9208: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 0000000E920C: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 0000000E9210: 7E680348
	v_mov_b32_e32 v51, v72                                     // 0000000E9214: 7E660348
	v_mov_b32_e32 v50, v72                                     // 0000000E9218: 7E640348
	v_mov_b32_e32 v49, v72                                     // 0000000E921C: 7E620348
	v_mov_b32_e32 v48, v72                                     // 0000000E9220: 7E600348
	v_mov_b32_e32 v47, v72                                     // 0000000E9224: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 0000000E9228: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 0000000E922C: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 0000000E9230: 7E580348
	v_mov_b32_e32 v43, v72                                     // 0000000E9234: 7E560348
	v_mov_b32_e32 v42, v72                                     // 0000000E9238: 7E540348
	v_mov_b32_e32 v41, v72                                     // 0000000E923C: 7E520348
	v_mov_b32_e32 v40, v72                                     // 0000000E9240: 7E500348
	v_mov_b32_e32 v39, v72                                     // 0000000E9244: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 0000000E9248: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 0000000E924C: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 0000000E9250: 7E480348
	v_mov_b32_e32 v35, v72                                     // 0000000E9254: 7E460348
	v_mov_b32_e32 v34, v72                                     // 0000000E9258: 7E440348
	v_mov_b32_e32 v33, v72                                     // 0000000E925C: 7E420348
	v_mov_b32_e32 v32, v72                                     // 0000000E9260: 7E400348
	v_mov_b32_e32 v31, v72                                     // 0000000E9264: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 0000000E9268: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 0000000E926C: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 0000000E9270: 7E380348
	v_mov_b32_e32 v27, v72                                     // 0000000E9274: 7E360348
	v_mov_b32_e32 v26, v72                                     // 0000000E9278: 7E340348
	v_mov_b32_e32 v25, v72                                     // 0000000E927C: 7E320348
	v_mov_b32_e32 v24, v72                                     // 0000000E9280: 7E300348
	v_mov_b32_e32 v23, v72                                     // 0000000E9284: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 0000000E9288: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 0000000E928C: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 0000000E9290: 7E280348
	v_mov_b32_e32 v19, v72                                     // 0000000E9294: 7E260348
	v_mov_b32_e32 v18, v72                                     // 0000000E9298: 7E240348
	v_mov_b32_e32 v17, v72                                     // 0000000E929C: 7E220348
	v_mov_b32_e32 v16, v72                                     // 0000000E92A0: 7E200348
	v_mov_b32_e32 v15, v72                                     // 0000000E92A4: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 0000000E92A8: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 0000000E92AC: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 0000000E92B0: 7E180348
	v_mov_b32_e32 v11, v72                                     // 0000000E92B4: 7E160348
	v_mov_b32_e32 v10, v72                                     // 0000000E92B8: 7E140348
	v_mov_b32_e32 v9, v72                                      // 0000000E92BC: 7E120348
	v_mov_b32_e32 v8, v72                                      // 0000000E92C0: 7E100348
	v_mov_b32_e32 v7, v72                                      // 0000000E92C4: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 0000000E92C8: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 0000000E92CC: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 0000000E92D0: 7E080348
	v_mov_b32_e32 v3, v72                                      // 0000000E92D4: 7E060348
	v_mov_b32_e32 v2, v72                                      // 0000000E92D8: 7E040348
	v_mov_b32_e32 v1, v72                                      // 0000000E92DC: 7E020348
	s_cbranch_scc1 2885                                        // 0000000E92E0: BFA20B45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x30f8>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[4:5]           // 0000000E92E4: D6FF7C01 001302FF 00003000
	v_lshlrev_b32_e32 v4, 2, v131                              // 0000000E92F0: 30090682
	s_movk_i32 s2, 0x440                                       // 0000000E92F4: B0020440
	s_ashr_i32 s1, s0, 31                                      // 0000000E92F8: 86019F00
	v_mad_u32_u24 v3, v155, s2, 0x3000                         // 0000000E92FC: D60B0003 03FC059B 00003000
	s_lshr_b32 s1, s1, 28                                      // 0000000E9308: 85019C01
	v_mad_u32_u24 v172, v154, 48, 0x9600                       // 0000000E930C: D60B00AC 03FD619A 00009600
	s_add_i32 s0, s0, s1                                       // 0000000E9318: 81000100
	.long 0xd7006a8f                                           // 0000000E931C: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 0000000E9320: 02031701
	v_add3_u32 v1, v129, s26, 1                                // 0000000E9324: D6550001 02043581
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 0000000E932C: D5207C90 01AB1902
	v_mov_b32_e32 v129, 0                                      // 0000000E9334: 7F020280
	s_ashr_i32 s5, s0, 4                                       // 0000000E9338: 86058400
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000E933C: BF870003
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000000E9340: 3404029F
	.long 0xd44c0000                                           // 0000000E9344: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000000E9348: 020200FF 00000200
	v_mad_u32_u24 v5, 0x44, v157, v3                           // 0000000E9350: D60B0005 040F3AFF 00000044
	v_mad_u32_u24 v164, 0x44, v131, v3                         // 0000000E935C: D60B00A4 040F06FF 00000044
	v_dual_mov_b32 v10, v129 :: v_dual_lshlrev_b32 v3, 4, v0   // 0000000E9368: CA220181 0A020084
	v_lshrrev_b32_e32 v2, 30, v2                               // 0000000E9370: 3204049E
	s_cmp_eq_u64 s[20:21], 0                                   // 0000000E9374: BF108014
	v_add_nc_u32_e32 v159, s26, v156                           // 0000000E9378: 4B3F381A
	s_cselect_b32 s12, -1, 0                                   // 0000000E937C: 980C80C1
	s_cmp_lg_u64 s[20:21], 0                                   // 0000000E9380: BF118014
	v_add_nc_u32_e32 v1, v1, v2                                // 0000000E9384: 4A020501
	v_add_nc_u32_e32 v2, v132, v4                              // 0000000E9388: 4A040984
	v_lshl_add_u32 v160, v154, 2, v5                           // 0000000E938C: D64600A0 0415059A
	v_lshlrev_b32_e32 v5, 9, v155                              // 0000000E9394: 300B3689
	v_add_nc_u32_e32 v6, 0xed00, v132                          // 0000000E9398: 4A0D08FF 0000ED00
	v_ashrrev_i32_e32 v161, 2, v1                              // 0000000E93A0: 35420282
	v_lshrrev_b32_e32 v1, 1, v0                                // 0000000E93A4: 32020081
	v_add_nc_u32_e32 v163, 0xe700, v2                          // 0000000E93A8: 4B4604FF 0000E700
	v_dual_mov_b32 v7, v129 :: v_dual_add_nc_u32 v0, 0xf300, v2// 0000000E93B0: CA200181 070004FF 0000F300
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000000E93BC: BF870143
	v_dual_mov_b32 v8, v129 :: v_dual_and_b32 v1, 0xf8, v1     // 0000000E93C0: CA240181 080002FF 000000F8
	s_cselect_b32 s13, -1, 0                                   // 0000000E93CC: 980D80C1
	s_ashr_i32 s25, s24, 31                                    // 0000000E93D0: 86199F18
	v_dual_mov_b32 v11, v129 :: v_dual_and_b32 v130, 0x1f0, v3 // 0000000E93D4: CA240181 0B8206FF 000001F0
	v_mul_u32_u24_e32 v2, 48, v1                               // 0000000E93E0: 160402B0
	s_lshl_b64 s[24:25], s[24:25], 9                           // 0000000E93E4: 84988918
	s_add_i32 s15, s15, -1                                     // 0000000E93E8: 810FC10F
	v_dual_mov_b32 v9, 0 :: v_dual_add_nc_u32 v166, v6, v4     // 0000000E93EC: CA200080 09A60906
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000E93F4: BF870002
	v_lshl_or_b32 v2, v154, 1, v2                              // 0000000E93F8: D6560002 0409039A
	v_mov_b32_e32 v4, v129                                     // 0000000E9400: 7E080381
	v_lshl_add_u32 v165, v131, 5, v5                           // 0000000E9404: D64600A5 04150B83
	s_add_u32 s1, s6, s24                                      // 0000000E940C: 80011806
	s_addc_u32 s4, s7, s25                                     // 0000000E9410: 82041907
	v_dual_mov_b32 v13, v129 :: v_dual_add_nc_u32 v170, 0x9600, v2// 0000000E9414: CA200181 0DAA04FF 00009600
	v_mov_b32_e32 v2, v129                                     // 0000000E9420: 7E040381
	v_add_nc_u32_e32 v162, v159, v131                          // 0000000E9424: 4B45079F
	v_dual_mov_b32 v12, v129 :: v_dual_lshlrev_b32 v131, 1, v1 // 0000000E9428: CA220181 0C820281
	v_mul_u32_u24_e32 v3, 0x210, v155                          // 0000000E9430: 160736FF 00000210
	s_add_u32 s2, s8, s24                                      // 0000000E9438: 80021808
	.long 0xd70001ad                                           // 0000000E943C: D70001AD
	v_cndmask_b32_e32 v1, s1, v130, vcc_lo                     // 0000000E9440: 02030401
	s_addc_u32 s6, s9, s25                                     // 0000000E9444: 82061909
	s_movk_i32 s7, 0x210                                       // 0000000E9448: B0070210
	v_add_co_ci_u32_e64 v174, null, s4, 0, s1                  // 0000000E944C: D5207CAE 00050004
	.long 0xd70001af                                           // 0000000E9454: D70001AF
	v_cndmask_b32_e32 v1, s2, v131, vcc_lo                     // 0000000E9458: 02030602
	v_lshl_or_b32 v168, v154, 5, v5                            // 0000000E945C: D65600A8 04150B9A
	v_add3_u32 v169, v3, v130, 0xc600                          // 0000000E9464: D65500A9 03FF0503 0000C600
	v_mov_b32_e32 v1, 0                                        // 0000000E9470: 7E020280
	v_mov_b32_e32 v3, v129                                     // 0000000E9474: 7E060381
	v_mov_b32_e32 v5, v129                                     // 0000000E9478: 7E0A0381
	v_lshl_or_b32 v167, v157, 2, v6                            // 0000000E947C: D65600A7 0419059D
	v_mov_b32_e32 v6, v129                                     // 0000000E9484: 7E0C0381
	v_dual_mov_b32 v14, v129 :: v_dual_mov_b32 v17, 0          // 0000000E9488: CA100181 0E100080
	v_mov_b32_e32 v15, v129                                    // 0000000E9490: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v25, 0          // 0000000E9494: CA100181 10180080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v33, 0          // 0000000E949C: CA100181 12200080
	v_mov_b32_e32 v19, v129                                    // 0000000E94A4: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v41, 0          // 0000000E94A8: CA100181 14280080
	v_mov_b32_e32 v21, v129                                    // 0000000E94B0: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v49, 0          // 0000000E94B4: CA100181 16300080
	v_mov_b32_e32 v23, v129                                    // 0000000E94BC: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v57, 0          // 0000000E94C0: CA100181 18380080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v121, 0         // 0000000E94C8: CA100181 1A780080
	v_mov_b32_e32 v27, v129                                    // 0000000E94D0: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v113, 0         // 0000000E94D4: CA100181 1C700080
	v_mov_b32_e32 v29, v129                                    // 0000000E94DC: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v105, 0         // 0000000E94E0: CA100181 1E680080
	v_mov_b32_e32 v31, v129                                    // 0000000E94E8: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v97, 0          // 0000000E94EC: CA100181 20600080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v89, 0          // 0000000E94F4: CA100181 22580080
	v_mov_b32_e32 v35, v129                                    // 0000000E94FC: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v81, 0          // 0000000E9500: CA100181 24500080
	v_mov_b32_e32 v37, v129                                    // 0000000E9508: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v73, 0          // 0000000E950C: CA100181 26480080
	v_mov_b32_e32 v39, v129                                    // 0000000E9514: 7E4E0381
	v_dual_mov_b32 v40, v129 :: v_dual_mov_b32 v65, 0          // 0000000E9518: CA100181 28400080
	v_dual_mov_b32 v42, v129 :: v_dual_mov_b32 v145, 0         // 0000000E9520: CA100181 2A900080
	v_mov_b32_e32 v43, v129                                    // 0000000E9528: 7E560381
	v_mov_b32_e32 v44, v129                                    // 0000000E952C: 7E580381
	v_mov_b32_e32 v45, v129                                    // 0000000E9530: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 0000000E9534: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 0000000E9538: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 0000000E953C: 7E600381
	v_mov_b32_e32 v50, v129                                    // 0000000E9540: 7E640381
	v_mov_b32_e32 v51, v129                                    // 0000000E9544: 7E660381
	v_mov_b32_e32 v52, v129                                    // 0000000E9548: 7E680381
	v_mov_b32_e32 v53, v129                                    // 0000000E954C: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 0000000E9550: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 0000000E9554: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 0000000E9558: 7E700381
	v_mov_b32_e32 v58, v129                                    // 0000000E955C: 7E740381
	v_mov_b32_e32 v59, v129                                    // 0000000E9560: 7E760381
	v_mov_b32_e32 v60, v129                                    // 0000000E9564: 7E780381
	v_mov_b32_e32 v61, v129                                    // 0000000E9568: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 0000000E956C: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 0000000E9570: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 0000000E9574: 7E800381
	v_mov_b32_e32 v122, v129                                   // 0000000E9578: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 0000000E957C: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 0000000E9580: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 0000000E9584: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 0000000E9588: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 0000000E958C: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 0000000E9590: 7F000381
	v_mov_b32_e32 v114, v129                                   // 0000000E9594: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 0000000E9598: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 0000000E959C: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 0000000E95A0: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 0000000E95A4: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 0000000E95A8: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 0000000E95AC: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 0000000E95B0: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 0000000E95B4: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 0000000E95B8: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 0000000E95BC: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 0000000E95C0: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 0000000E95C4: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 0000000E95C8: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 0000000E95CC: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 0000000E95D0: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 0000000E95D4: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 0000000E95D8: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 0000000E95DC: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 0000000E95E0: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 0000000E95E4: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 0000000E95E8: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 0000000E95EC: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 0000000E95F0: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 0000000E95F4: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 0000000E95F8: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 0000000E95FC: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 0000000E9600: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 0000000E9604: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 0000000E9608: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 0000000E960C: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 0000000E9610: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 0000000E9614: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 0000000E9618: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 0000000E961C: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 0000000E9620: 7E940381
	v_mov_b32_e32 v75, v129                                    // 0000000E9624: 7E960381
	v_mov_b32_e32 v76, v129                                    // 0000000E9628: 7E980381
	v_mov_b32_e32 v77, v129                                    // 0000000E962C: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 0000000E9630: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 0000000E9634: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 0000000E9638: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 0000000E963C: 7E840381
	v_mov_b32_e32 v67, v129                                    // 0000000E9640: 7E860381
	v_mov_b32_e32 v68, v129                                    // 0000000E9644: 7E880381
	v_mov_b32_e32 v69, v129                                    // 0000000E9648: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 0000000E964C: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 0000000E9650: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 0000000E9654: 7E900381
	v_mad_u32_u24 v171, v154, s7, 0xc600                       // 0000000E9658: D60B00AB 03FC0F9A 0000C600
	v_add_co_ci_u32_e64 v176, null, s6, 0, s1                  // 0000000E9664: D5207CB0 00050006
	s_mov_b32 s6, 0                                            // 0000000E966C: BE860080
	s_branch 116                                               // 0000000E9670: BFA00074 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x944>
	ds_load_b128 v[146:149], v172                              // 0000000E9674: DBFC0000 920000AC
	ds_load_b128 v[150:153], v172 offset:16                    // 0000000E967C: DBFC0010 960000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E9684: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[146:153], v[121:128]// 0000000E9688: CC414079 1DE72582
	ds_load_b128 v[150:153], v172 offset:784                   // 0000000E9690: DBFC0310 960000AC
	ds_load_b128 v[146:149], v172 offset:768                   // 0000000E9698: DBFC0300 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E96A0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[146:153], v[113:120]// 0000000E96A4: CC414071 1DC72582
	ds_load_b128 v[150:153], v172 offset:1552                  // 0000000E96AC: DBFC0610 960000AC
	ds_load_b128 v[146:149], v172 offset:1536                  // 0000000E96B4: DBFC0600 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E96BC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[146:153], v[105:112]// 0000000E96C0: CC414069 1DA72582
	ds_load_b128 v[150:153], v172 offset:2320                  // 0000000E96C8: DBFC0910 960000AC
	ds_load_b128 v[146:149], v172 offset:2304                  // 0000000E96D0: DBFC0900 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E96D8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[146:153], v[97:104]// 0000000E96DC: CC414061 1D872582
	ds_load_b128 v[150:153], v172 offset:3088                  // 0000000E96E4: DBFC0C10 960000AC
	ds_load_b128 v[146:149], v172 offset:3072                  // 0000000E96EC: DBFC0C00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E96F4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[146:153], v[89:96]// 0000000E96F8: CC414059 1D672582
	ds_load_b128 v[150:153], v172 offset:3856                  // 0000000E9700: DBFC0F10 960000AC
	ds_load_b128 v[146:149], v172 offset:3840                  // 0000000E9708: DBFC0F00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E9710: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[146:153], v[81:88]// 0000000E9714: CC414051 1D472582
	ds_load_b128 v[150:153], v172 offset:4624                  // 0000000E971C: DBFC1210 960000AC
	ds_load_b128 v[146:149], v172 offset:4608                  // 0000000E9724: DBFC1200 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E972C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[146:153], v[73:80]// 0000000E9730: CC414049 1D272582
	ds_load_b128 v[150:153], v172 offset:5392                  // 0000000E9738: DBFC1510 960000AC
	ds_load_b128 v[146:149], v172 offset:5376                  // 0000000E9740: DBFC1500 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E9748: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[146:153], v[65:72]// 0000000E974C: CC414041 1D072582
	ds_load_b128 v[150:153], v172 offset:6160                  // 0000000E9754: DBFC1810 960000AC
	ds_load_b128 v[146:149], v172 offset:6144                  // 0000000E975C: DBFC1800 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E9764: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[146:153], v[57:64]// 0000000E9768: CC414039 1CE72582
	ds_load_b128 v[150:153], v172 offset:6928                  // 0000000E9770: DBFC1B10 960000AC
	ds_load_b128 v[146:149], v172 offset:6912                  // 0000000E9778: DBFC1B00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E9780: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[146:153], v[49:56]// 0000000E9784: CC414031 1CC72582
	ds_load_b128 v[150:153], v172 offset:7696                  // 0000000E978C: DBFC1E10 960000AC
	ds_load_b128 v[146:149], v172 offset:7680                  // 0000000E9794: DBFC1E00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E979C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[146:153], v[41:48]// 0000000E97A0: CC414029 1CA72582
	ds_load_b128 v[150:153], v172 offset:8464                  // 0000000E97A8: DBFC2110 960000AC
	ds_load_b128 v[146:149], v172 offset:8448                  // 0000000E97B0: DBFC2100 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E97B8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[146:153], v[33:40]// 0000000E97BC: CC414021 1C872582
	ds_load_b128 v[150:153], v172 offset:9232                  // 0000000E97C4: DBFC2410 960000AC
	ds_load_b128 v[146:149], v172 offset:9216                  // 0000000E97CC: DBFC2400 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E97D4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[146:153], v[25:32]// 0000000E97D8: CC414019 1C672582
	ds_load_b128 v[150:153], v172 offset:10000                 // 0000000E97E0: DBFC2710 960000AC
	ds_load_b128 v[146:149], v172 offset:9984                  // 0000000E97E8: DBFC2700 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E97F0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[146:153], v[17:24]// 0000000E97F4: CC414011 1C472582
	ds_load_b128 v[150:153], v172 offset:10768                 // 0000000E97FC: DBFC2A10 960000AC
	ds_load_b128 v[146:149], v172 offset:10752                 // 0000000E9804: DBFC2A00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E980C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[146:153], v[9:16]// 0000000E9810: CC414009 1C272582
	ds_load_b128 v[150:153], v172 offset:11536                 // 0000000E9818: DBFC2D10 960000AC
	ds_load_b128 v[146:149], v172 offset:11520                 // 0000000E9820: DBFC2D00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 0000000E9828: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[146:153], v[1:8]// 0000000E982C: CC414001 1C072582
	s_add_i32 s1, s6, 1                                        // 0000000E9834: 81018106
	s_cmp_eq_u32 s6, s5                                        // 0000000E9838: BF060506
	s_mov_b32 s6, s1                                           // 0000000E983C: BE860001
	s_cbranch_scc1 2541                                        // 0000000E9840: BFA209ED <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x30f8>
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 0000000E9844: 916A0D7E
	s_mov_b32 s1, s12                                          // 0000000E9848: BE81000C
	s_cbranch_vccz 3                                           // 0000000E984C: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x95c>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000000E9850: 916A017E
	s_cbranch_vccnz 65527                                      // 0000000E9854: BFA4FFF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x934>
	s_branch 15                                                // 0000000E9858: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x998>
	s_lshr_b32 s1, s6, 3                                       // 0000000E985C: 85018306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000E9860: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 0000000E9864: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 0000000E986C: 7F040201
	global_load_b32 v130, v130, s[20:21]                       // 0000000E9870: DC520000 82140082
	s_waitcnt vmcnt(0)                                         // 0000000E9878: BF8903F7
	v_lshrrev_b32_e32 v130, s6, v130                           // 0000000E987C: 33050406
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E9880: BF870091
	v_and_b32_e32 v130, 1, v130                                // 0000000E9884: 37050481
	.long 0xd44a0001                                           // 0000000E9888: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000E988C: 02030481
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000000E9890: 916A017E
	s_cbranch_vccnz 65511                                      // 0000000E9894: BFA4FFE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x934>
	s_lshl_b32 s2, s6, 4                                       // 0000000E9898: 84028406
	s_waitcnt vmcnt(0)                                         // 0000000E989C: BF8903F7
	s_barrier                                                  // 0000000E98A0: BFBD0000
	buffer_gl0_inv                                             // 0000000E98A4: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000000E98AC: BE812000
	s_cbranch_execz 64                                         // 0000000E98B0: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xab4>
	v_or_b32_e32 v130, s2, v155                                // 0000000E98B4: 39053602
	v_or_b32_e32 v131, s2, v154                                // 0000000E98B8: 39073402
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E98BC: BF870112
	v_min_i32_e32 v130, s15, v130                              // 0000000E98C0: 2305040F
	v_min_i32_e32 v132, s15, v131                              // 0000000E98C4: 2309060F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E98C8: BF870112
	v_ashrrev_i32_e32 v133, 31, v130                           // 0000000E98CC: 350B049F
	v_ashrrev_i32_e32 v135, 31, v132                           // 0000000E98D0: 350F089F
	.long 0xd72c0086                                           // 0000000E98D4: D72C0086
	v_cndmask_b32_e32 v1, s11, v130, vcc_lo                    // 0000000E98D8: 0203040B
	v_mad_u64_u32 v[130:131], null, s10, v130, 0               // 0000000E98DC: D6FE7C82 0203040A
	.long 0xd72c0089                                           // 0000000E98E4: D72C0089
	v_cndmask_b32_e32 v1, s11, v132, vcc_lo                    // 0000000E98E8: 0203080B
	.long 0xd72c0088                                           // 0000000E98EC: D72C0088
	v_cndmask_b32_e32 v1, s10, v133, vcc_lo                    // 0000000E98F0: 02030A0A
	v_mad_u64_u32 v[132:133], null, s10, v132, 0               // 0000000E98F4: D6FE7C84 0203080A
	.long 0xd72c0087                                           // 0000000E98FC: D72C0087
	v_cndmask_b32_e32 v1, s10, v135, vcc_lo                    // 0000000E9900: 02030E0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E9904: BF870113
	v_add3_u32 v131, v131, v136, v134                          // 0000000E9908: D6550083 061B1183
	v_add3_u32 v133, v133, v135, v137                          // 0000000E9910: D6550085 06270F85
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E9918: BF870112
	.long 0xd73c0082                                           // 0000000E991C: D73C0082
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000E9920: 02030481
	.long 0xd73c0084                                           // 0000000E9924: D73C0084
	v_cndmask_b32_e32 v1, 1, v132, vcc_lo                      // 0000000E9928: 02030881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E992C: BF870092
	.long 0xd7006a82                                           // 0000000E9930: D7006A82
	v_cndmask_b32_e32 v1, v173, v130, vcc_lo                   // 0000000E9934: 020305AD
	v_add_co_ci_u32_e64 v131, null, v174, v131, vcc_lo         // 0000000E9938: D5207C83 01AB07AE
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E9940: BF870093
	.long 0xd7006a86                                           // 0000000E9944: D7006A86
	v_cndmask_b32_e32 v1, v175, v132, vcc_lo                   // 0000000E9948: 020309AF
	v_add_co_ci_u32_e64 v135, null, v176, v133, vcc_lo         // 0000000E994C: D5207C87 01AB0BB0
	global_load_b128 v[130:133], v[130:131], off               // 0000000E9954: DC5E0000 827C0082
	global_load_b128 v[134:137], v[134:135], off               // 0000000E995C: DC5E0000 867C0086
	s_waitcnt vmcnt(1)                                         // 0000000E9964: BF8907F7
	ds_store_b128 v169, v[130:133]                             // 0000000E9968: DB7C0000 000082A9
	s_waitcnt vmcnt(0)                                         // 0000000E9970: BF8903F7
	ds_store_b16 v170, v134                                    // 0000000E9974: D87C0000 000086AA
	ds_store_b16_d16_hi v170, v134 offset:48                   // 0000000E997C: DA840030 000086AA
	ds_store_b16 v170, v135 offset:96                          // 0000000E9984: D87C0060 000087AA
	ds_store_b16_d16_hi v170, v135 offset:144                  // 0000000E998C: DA840090 000087AA
	ds_store_b16 v170, v136 offset:192                         // 0000000E9994: D87C00C0 000088AA
	ds_store_b16_d16_hi v170, v136 offset:240                  // 0000000E999C: DA8400F0 000088AA
	ds_store_b16 v170, v137 offset:288                         // 0000000E99A4: D87C0120 000089AA
	ds_store_b16_d16_hi v170, v137 offset:336                  // 0000000E99AC: DA840150 000089AA
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000E99B4: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 0000000E99B8: BF89FC07
	s_barrier                                                  // 0000000E99BC: BFBD0000
	buffer_gl0_inv                                             // 0000000E99C0: E0AC0000 00000000
	s_clause 0x1                                               // 0000000E99C8: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:16     // 0000000E99CC: DC5E0010 967C008F
	global_load_b128 v[146:149], v[143:144], off               // 0000000E99D4: DC5E0000 927C008F
	ds_load_b128 v[177:180], v171                              // 0000000E99DC: DBFC0000 B10000AB
	ds_load_b128 v[181:184], v171 offset:16                    // 0000000E99E4: DBFC0010 B50000AB
	v_mov_b32_e32 v136, v129                                   // 0000000E99EC: 7F100381
	v_mov_b32_e32 v130, v129                                   // 0000000E99F0: 7F040381
	v_mov_b32_e32 v131, v129                                   // 0000000E99F4: 7F060381
	v_mov_b32_e32 v132, v129                                   // 0000000E99F8: 7F080381
	v_mov_b32_e32 v133, v129                                   // 0000000E99FC: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 0000000E9A00: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 0000000E9A04: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 0000000E9A08: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000E9A0C: BF870212
	v_mov_b32_e32 v136, v135                                   // 0000000E9A10: 7F100387
	v_mov_b32_e32 v135, v134                                   // 0000000E9A14: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 0000000E9A18: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 0000000E9A1C: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 0000000E9A20: 7F080383
	v_mov_b32_e32 v131, v130                                   // 0000000E9A24: 7F060382
	v_mov_b32_e32 v130, v129                                   // 0000000E9A28: 7F040381
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9A2C: BF890007
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E9A30: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9A34: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9A3C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:48     // 0000000E9A40: DC5E0030 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:32     // 0000000E9A48: DC5E0020 927C008F
	ds_load_b128 v[177:180], v171 offset:32                    // 0000000E9A50: DBFC0020 B10000AB
	ds_load_b128 v[181:184], v171 offset:48                    // 0000000E9A58: DBFC0030 B50000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9A60: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9A64: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9A6C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:80     // 0000000E9A70: DC5E0050 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:64     // 0000000E9A78: DC5E0040 927C008F
	ds_load_b128 v[181:184], v171 offset:80                    // 0000000E9A80: DBFC0050 B50000AB
	ds_load_b128 v[177:180], v171 offset:64                    // 0000000E9A88: DBFC0040 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9A90: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9A94: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9A9C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:112    // 0000000E9AA0: DC5E0070 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:96     // 0000000E9AA8: DC5E0060 927C008F
	ds_load_b128 v[181:184], v171 offset:112                   // 0000000E9AB0: DBFC0070 B50000AB
	ds_load_b128 v[177:180], v171 offset:96                    // 0000000E9AB8: DBFC0060 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9AC0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9AC4: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9ACC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:144    // 0000000E9AD0: DC5E0090 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:128    // 0000000E9AD8: DC5E0080 927C008F
	ds_load_b128 v[181:184], v171 offset:144                   // 0000000E9AE0: DBFC0090 B50000AB
	ds_load_b128 v[177:180], v171 offset:128                   // 0000000E9AE8: DBFC0080 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9AF0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9AF4: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9AFC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:176    // 0000000E9B00: DC5E00B0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:160    // 0000000E9B08: DC5E00A0 927C008F
	ds_load_b128 v[181:184], v171 offset:176                   // 0000000E9B10: DBFC00B0 B50000AB
	ds_load_b128 v[177:180], v171 offset:160                   // 0000000E9B18: DBFC00A0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9B20: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9B24: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9B2C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:208    // 0000000E9B30: DC5E00D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:192    // 0000000E9B38: DC5E00C0 927C008F
	ds_load_b128 v[181:184], v171 offset:208                   // 0000000E9B40: DBFC00D0 B50000AB
	ds_load_b128 v[177:180], v171 offset:192                   // 0000000E9B48: DBFC00C0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9B50: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9B54: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9B5C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:240    // 0000000E9B60: DC5E00F0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:224    // 0000000E9B68: DC5E00E0 927C008F
	ds_load_b128 v[181:184], v171 offset:240                   // 0000000E9B70: DBFC00F0 B50000AB
	ds_load_b128 v[177:180], v171 offset:224                   // 0000000E9B78: DBFC00E0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9B80: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9B84: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9B8C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:272    // 0000000E9B90: DC5E0110 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:256    // 0000000E9B98: DC5E0100 927C008F
	ds_load_b128 v[181:184], v171 offset:272                   // 0000000E9BA0: DBFC0110 B50000AB
	ds_load_b128 v[177:180], v171 offset:256                   // 0000000E9BA8: DBFC0100 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9BB0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9BB4: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9BBC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:304    // 0000000E9BC0: DC5E0130 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:288    // 0000000E9BC8: DC5E0120 927C008F
	ds_load_b128 v[181:184], v171 offset:304                   // 0000000E9BD0: DBFC0130 B50000AB
	ds_load_b128 v[177:180], v171 offset:288                   // 0000000E9BD8: DBFC0120 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9BE0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9BE4: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9BEC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:336    // 0000000E9BF0: DC5E0150 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:320    // 0000000E9BF8: DC5E0140 927C008F
	ds_load_b128 v[181:184], v171 offset:336                   // 0000000E9C00: DBFC0150 B50000AB
	ds_load_b128 v[177:180], v171 offset:320                   // 0000000E9C08: DBFC0140 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9C10: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9C14: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9C1C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:368    // 0000000E9C20: DC5E0170 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:352    // 0000000E9C28: DC5E0160 927C008F
	ds_load_b128 v[181:184], v171 offset:368                   // 0000000E9C30: DBFC0170 B50000AB
	ds_load_b128 v[177:180], v171 offset:352                   // 0000000E9C38: DBFC0160 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9C40: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9C44: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9C4C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:400    // 0000000E9C50: DC5E0190 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:384    // 0000000E9C58: DC5E0180 927C008F
	ds_load_b128 v[181:184], v171 offset:400                   // 0000000E9C60: DBFC0190 B50000AB
	ds_load_b128 v[177:180], v171 offset:384                   // 0000000E9C68: DBFC0180 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9C70: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9C74: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9C7C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:432    // 0000000E9C80: DC5E01B0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:416    // 0000000E9C88: DC5E01A0 927C008F
	ds_load_b128 v[181:184], v171 offset:432                   // 0000000E9C90: DBFC01B0 B50000AB
	ds_load_b128 v[177:180], v171 offset:416                   // 0000000E9C98: DBFC01A0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9CA0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9CA4: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9CAC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:464    // 0000000E9CB0: DC5E01D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:448    // 0000000E9CB8: DC5E01C0 927C008F
	ds_load_b128 v[181:184], v171 offset:464                   // 0000000E9CC0: DBFC01D0 B50000AB
	ds_load_b128 v[177:180], v171 offset:448                   // 0000000E9CC8: DBFC01C0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9CD0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9CD4: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000E9CDC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:496    // 0000000E9CE0: DC5E01F0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:480    // 0000000E9CE8: DC5E01E0 927C008F
	ds_load_b128 v[181:184], v171 offset:496                   // 0000000E9CF0: DBFC01F0 B50000AB
	ds_load_b128 v[177:180], v171 offset:480                   // 0000000E9CF8: DBFC01E0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E9D00: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000E9D04: CC414082 1E0B6392
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000E9D0C: BF870111
	v_dual_mul_f32 v130, 0x3d800000, v130 :: v_dual_mul_f32 v131, 0x3d800000, v131// 0000000E9D10: C8C704FF 828306FF 3D800000
	v_mul_f32_e32 v146, 0x3d800000, v134                       // 0000000E9D1C: 11250CFF 3D800000
	v_mov_b32_e32 v134, 0xffff                                 // 0000000E9D24: 7F0C02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000E9D2C: BF870004
	v_dual_mul_f32 v132, 0x3d800000, v132 :: v_dual_mul_f32 v133, 0x3d800000, v133// 0000000E9D30: C8C708FF 84850AFF 3D800000
	v_dual_mul_f32 v135, 0x3d800000, v135 :: v_dual_mul_f32 v136, 0x3d800000, v136// 0000000E9D3C: C8C70EFF 878910FF 3D800000
	v_mul_f32_e32 v137, 0x3d800000, v137                       // 0000000E9D48: 111312FF 3D800000
	ds_store_2addr_b32 v160, v130, v131 offset1:34             // 0000000E9D50: D8382200 008382A0
	ds_store_2addr_b32 v160, v132, v133 offset0:68 offset1:102 // 0000000E9D58: D8386644 008584A0
	ds_store_2addr_b32 v160, v146, v135 offset0:136 offset1:170// 0000000E9D60: D838AA88 008792A0
	ds_store_2addr_b32 v160, v136, v137 offset0:204 offset1:238// 0000000E9D68: D838EECC 008988A0
	s_waitcnt lgkmcnt(0)                                       // 0000000E9D70: BF89FC07
	s_barrier                                                  // 0000000E9D74: BFBD0000
	buffer_gl0_inv                                             // 0000000E9D78: E0AC0000 00000000
	s_and_saveexec_b32 s4, s23                                 // 0000000E9D80: BE842017
	s_cbranch_execz 370                                        // 0000000E9D84: BFA50172 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1450>
	s_lshl_b32 s7, s6, 2                                       // 0000000E9D88: 84078206
	s_mov_b32 s8, exec_lo                                      // 0000000E9D8C: BE88007E
	.long 0xd4c1007e                                           // 0000000E9D90: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 0000000E9D94: 02033D91
	s_cbranch_execz 55                                         // 0000000E9D98: BFA50037 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf78>
	v_ashrrev_i32_e32 v146, 31, v145                           // 0000000E9D9C: 3525229F
	s_mov_b32 s9, 0                                            // 0000000E9DA0: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E9DA4: BF870091
	.long 0xd73c0082                                           // 0000000E9DA8: D73C0082
	v_cndmask_b32_e32 v1, 2, v145, vcc_lo                      // 0000000E9DAC: 02032282
	.long 0xd7006a82                                           // 0000000E9DB0: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 0000000E9DB4: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E9DB8: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 0000000E9DBC: D5207C83 01AB078E
	s_branch 22                                                // 0000000E9DC4: BFA00016 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf20>
	s_nop 0                                                    // 0000000E9DC8: BF800000
	s_nop 0                                                    // 0000000E9DCC: BF800000
	s_nop 0                                                    // 0000000E9DD0: BF800000
	s_nop 0                                                    // 0000000E9DD4: BF800000
	s_nop 0                                                    // 0000000E9DD8: BF800000
	s_nop 0                                                    // 0000000E9DDC: BF800000
	s_nop 0                                                    // 0000000E9DE0: BF800000
	s_nop 0                                                    // 0000000E9DE4: BF800000
	s_nop 0                                                    // 0000000E9DE8: BF800000
	s_nop 0                                                    // 0000000E9DEC: BF800000
	s_nop 0                                                    // 0000000E9DF0: BF800000
	s_nop 0                                                    // 0000000E9DF4: BF800000
	s_nop 0                                                    // 0000000E9DF8: BF800000
	s_nop 0                                                    // 0000000E9DFC: BF800000
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000E9E00: 8C7E187E
	v_mov_b32_e32 v133, v145                                   // 0000000E9E04: 7F0A0391
	v_mov_b32_e32 v145, v132                                   // 0000000E9E08: 7F220384
	s_and_b32 s1, exec_lo, s22                                 // 0000000E9E0C: 8B01167E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000E9E10: BF870499
	s_or_b32 s9, s1, s9                                        // 0000000E9E14: 8C090901
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000E9E18: 917E097E
	s_cbranch_execz 20                                         // 0000000E9E1C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf70>
	global_load_b32 v132, v[130:131], off                      // 0000000E9E20: DC520000 847C0082
	s_or_b32 s22, s22, exec_lo                                 // 0000000E9E28: 8C167E16
	s_waitcnt vmcnt(0)                                         // 0000000E9E2C: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s7, v132                          // 0000000E9E30: 7C890807
	s_and_saveexec_b32 s24, vcc_lo                             // 0000000E9E34: BE98206A
	s_cbranch_execz 65521                                      // 0000000E9E38: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf00>
	v_dual_mov_b32 v145, v158 :: v_dual_add_nc_u32 v132, 1, v145// 0000000E9E3C: CA20019E 91852281
	.long 0xd7000182                                           // 0000000E9E44: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 0000000E9E48: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000E9E4C: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 0000000E9E50: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v158, v132                        // 0000000E9E58: 7C95099E
	s_and_not1_b32 s1, s22, exec_lo                            // 0000000E9E5C: 91017E16
	s_and_b32 s22, vcc_lo, exec_lo                             // 0000000E9E60: 8B167E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000E9E64: BF870009
	s_or_b32 s22, s1, s22                                      // 0000000E9E68: 8C161601
	s_branch 65508                                             // 0000000E9E6C: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf00>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000E9E70: 8C7E097E
	v_mov_b32_e32 v145, v133                                   // 0000000E9E74: 7F220385
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E9E78: 8C7E087E
	v_mov_b32_e32 v134, 15                                     // 0000000E9E7C: 7F0C028F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000E9E80: BF870002
	v_mov_b32_e32 v130, v145                                   // 0000000E9E84: 7F040391
	s_mov_b32 s1, exec_lo                                      // 0000000E9E88: BE81007E
	.long 0xd4c1007e                                           // 0000000E9E8C: D4C1007E
	v_cndmask_b32_e32 v1, s7, v161, vcc_lo                     // 0000000E9E90: 02034207
	s_cbranch_execz 62                                         // 0000000E9E94: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1090>
	v_mov_b32_e32 v134, 0                                      // 0000000E9E98: 7F0C0280
	v_mov_b32_e32 v130, v145                                   // 0000000E9E9C: 7F040391
	s_mov_b32 s8, exec_lo                                      // 0000000E9EA0: BE88007E
	.long 0xd4c1007e                                           // 0000000E9EA4: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 0000000E9EA8: 02033D91
	s_cbranch_execz 54                                         // 0000000E9EAC: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1088>
	v_mov_b32_e32 v130, v145                                   // 0000000E9EB0: 7F040391
	s_mov_b32 s22, 0                                           // 0000000E9EB4: BE960080
	s_set_inst_prefetch_distance 0x1                           // 0000000E9EB8: BF840001
	s_branch 10                                                // 0000000E9EBC: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfe8>
	s_or_b32 exec_lo, exec_lo, s26                             // 0000000E9EC0: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000E9EC4: BF870499
	s_and_b32 s26, exec_lo, s25                                // 0000000E9EC8: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 0000000E9ECC: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 0000000E9ED0: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 0000000E9ED4: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000E9ED8: BF870009
	s_or_b32 s9, s9, s26                                       // 0000000E9EDC: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000000E9EE0: 917E167E
	s_cbranch_execz 28                                         // 0000000E9EE4: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1058>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000E9EE8: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 0000000E9EEC: 7F060382
	s_or_b32 s24, s24, exec_lo                                 // 0000000E9EF0: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 0000000E9EF4: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 0000000E9EF8: BE9A007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000E9EFC: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E9F00: BF870091
	.long 0xd73c0084                                           // 0000000E9F04: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000E9F08: 02030682
	.long 0xd7006a84                                           // 0000000E9F0C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 0000000E9F10: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E9F14: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 0000000E9F18: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 0000000E9F20: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 0000000E9F28: BF8903F7
	.long 0xd4c4007e                                           // 0000000E9F2C: D4C4007E
	v_cndmask_b32_e32 v1, s7, v132, vcc_lo                     // 0000000E9F30: 02030807
	s_cbranch_execz 65506                                      // 0000000E9F34: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfc0>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000E9F38: 4B050681
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000E9F3C: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 0000000E9F40: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000E9F44: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000E9F48: 7C95059E
	s_and_b32 s27, vcc_lo, exec_lo                             // 0000000E9F4C: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 0000000E9F50: 8C191B19
	s_branch 65498                                             // 0000000E9F54: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfc0>
	s_set_inst_prefetch_distance 0x2                           // 0000000E9F58: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000E9F5C: 8C7E167E
	v_mov_b32_e32 v134, 0                                      // 0000000E9F60: 7F0C0280
	v_mov_b32_e32 v130, v158                                   // 0000000E9F64: 7F04039E
	s_and_saveexec_b32 s22, s9                                 // 0000000E9F68: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000E9F6C: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 0000000E9F70: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v132                          // 0000000E9F74: 7C950807
	v_mov_b32_e32 v130, v131                                   // 0000000E9F78: 7F040383
	v_cndmask_b32_e64 v134, 0, 15, vcc_lo                      // 0000000E9F7C: D5010086 01A91E80
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000E9F84: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000E9F88: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000E9F8C: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000E9F90: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000E9F94: 8C7E017E
	s_or_b32 s8, s7, 1                                         // 0000000E9F98: 8C088107
	s_mov_b32 s1, exec_lo                                      // 0000000E9F9C: BE81007E
	.long 0xd4c6007e                                           // 0000000E9FA0: D4C6007E
	v_cndmask_b32_e32 v1, s8, v161, vcc_lo                     // 0000000E9FA4: 02034208
	s_xor_b32 s1, exec_lo, s1                                  // 0000000E9FA8: 8D01017E
	v_or_b32_e32 v134, 0xf0, v134                              // 0000000E9FAC: 390D0CFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 0000000E9FB4: BE813001
	s_cbranch_execz 70                                         // 0000000E9FB8: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11d4>
	s_mov_b32 s9, exec_lo                                      // 0000000E9FBC: BE89007E
	.long 0xd4c1007e                                           // 0000000E9FC0: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 0000000E9FC4: 02033D82
	s_cbranch_execz 64                                         // 0000000E9FC8: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11cc>
	s_mov_b32 s24, 0                                           // 0000000E9FCC: BE980080
	s_set_inst_prefetch_distance 0x1                           // 0000000E9FD0: BF840001
	s_branch 20                                                // 0000000E9FD4: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1128>
	s_nop 0                                                    // 0000000E9FD8: BF800000
	s_nop 0                                                    // 0000000E9FDC: BF800000
	s_nop 0                                                    // 0000000E9FE0: BF800000
	s_nop 0                                                    // 0000000E9FE4: BF800000
	s_nop 0                                                    // 0000000E9FE8: BF800000
	s_nop 0                                                    // 0000000E9FEC: BF800000
	s_nop 0                                                    // 0000000E9FF0: BF800000
	s_nop 0                                                    // 0000000E9FF4: BF800000
	s_nop 0                                                    // 0000000E9FF8: BF800000
	s_nop 0                                                    // 0000000E9FFC: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 0000000EA000: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000EA004: BF870499
	s_and_b32 s27, exec_lo, s26                                // 0000000EA008: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 0000000EA00C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 0000000EA010: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 0000000EA014: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA018: BF870009
	s_or_b32 s22, s22, s27                                     // 0000000EA01C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 0000000EA020: 917E187E
	s_cbranch_execz 27                                         // 0000000EA024: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1194>
	v_mov_b32_e32 v131, v130                                   // 0000000EA028: 7F060382
	s_or_b32 s25, s25, exec_lo                                 // 0000000EA02C: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 0000000EA030: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 0000000EA034: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA038: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000EA03C: 3509069F
	.long 0xd73c0084                                           // 0000000EA040: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000EA044: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA048: BF870091
	.long 0xd7006a84                                           // 0000000EA04C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 0000000EA050: 0203098D
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 0000000EA054: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 0000000EA05C: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 0000000EA064: BF8903F7
	.long 0xd4c6007e                                           // 0000000EA068: D4C6007E
	v_cndmask_b32_e32 v1, s7, v132, vcc_lo                     // 0000000EA06C: 02030807
	s_cbranch_execz 65507                                      // 0000000EA070: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1100>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000EA074: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000EA078: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000EA07C: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000EA080: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000EA084: 7C95059E
	s_and_b32 s28, vcc_lo, exec_lo                             // 0000000EA088: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 0000000EA08C: 8C1A1C1A
	s_branch 65499                                             // 0000000EA090: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1100>
	s_set_inst_prefetch_distance 0x2                           // 0000000EA094: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000EA098: 8C7E187E
	v_mov_b32_e32 v130, v158                                   // 0000000EA09C: 7F04039E
	s_and_saveexec_b32 s24, s22                                // 0000000EA0A0: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA0A4: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 0000000EA0A8: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v132                          // 0000000EA0AC: 7C950808
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 0000000EA0B0: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA0BC: BF870001
	v_or_b32_e32 v134, v130, v134                              // 0000000EA0C0: 390D0D82
	v_mov_b32_e32 v130, v131                                   // 0000000EA0C4: 7F040383
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000EA0C8: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA0CC: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000EA0D0: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA0D4: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA0D8: 8C7E017E
	s_or_b32 s8, s7, 2                                         // 0000000EA0DC: 8C088207
	s_mov_b32 s1, exec_lo                                      // 0000000EA0E0: BE81007E
	.long 0xd4c6007e                                           // 0000000EA0E4: D4C6007E
	v_cndmask_b32_e32 v1, s8, v161, vcc_lo                     // 0000000EA0E8: 02034208
	s_xor_b32 s1, exec_lo, s1                                  // 0000000EA0EC: 8D01017E
	v_or_b32_e32 v134, 0xf00, v134                             // 0000000EA0F0: 390D0CFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 0000000EA0F8: BE813001
	s_cbranch_execz 69                                         // 0000000EA0FC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1314>
	s_mov_b32 s9, exec_lo                                      // 0000000EA100: BE89007E
	.long 0xd4c1007e                                           // 0000000EA104: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 0000000EA108: 02033D82
	s_cbranch_execz 63                                         // 0000000EA10C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x130c>
	s_mov_b32 s24, 0                                           // 0000000EA110: BE980080
	s_set_inst_prefetch_distance 0x1                           // 0000000EA114: BF840001
	s_branch 19                                                // 0000000EA118: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1268>
	s_nop 0                                                    // 0000000EA11C: BF800000
	s_nop 0                                                    // 0000000EA120: BF800000
	s_nop 0                                                    // 0000000EA124: BF800000
	s_nop 0                                                    // 0000000EA128: BF800000
	s_nop 0                                                    // 0000000EA12C: BF800000
	s_nop 0                                                    // 0000000EA130: BF800000
	s_nop 0                                                    // 0000000EA134: BF800000
	s_nop 0                                                    // 0000000EA138: BF800000
	s_nop 0                                                    // 0000000EA13C: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 0000000EA140: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000EA144: BF870499
	s_and_b32 s27, exec_lo, s26                                // 0000000EA148: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 0000000EA14C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 0000000EA150: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 0000000EA154: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA158: BF870009
	s_or_b32 s22, s22, s27                                     // 0000000EA15C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 0000000EA160: 917E187E
	s_cbranch_execz 27                                         // 0000000EA164: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12d4>
	v_mov_b32_e32 v131, v130                                   // 0000000EA168: 7F060382
	s_or_b32 s25, s25, exec_lo                                 // 0000000EA16C: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 0000000EA170: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 0000000EA174: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA178: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000EA17C: 3509069F
	.long 0xd73c0084                                           // 0000000EA180: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000EA184: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA188: BF870091
	.long 0xd7006a84                                           // 0000000EA18C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 0000000EA190: 0203098D
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 0000000EA194: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 0000000EA19C: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 0000000EA1A4: BF8903F7
	.long 0xd4c4007e                                           // 0000000EA1A8: D4C4007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 0000000EA1AC: 02030808
	s_cbranch_execz 65507                                      // 0000000EA1B0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000EA1B4: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000EA1B8: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000EA1BC: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000EA1C0: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000EA1C4: 7C95059E
	s_and_b32 s28, vcc_lo, exec_lo                             // 0000000EA1C8: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 0000000EA1CC: 8C1A1C1A
	s_branch 65499                                             // 0000000EA1D0: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	s_set_inst_prefetch_distance 0x2                           // 0000000EA1D4: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000EA1D8: 8C7E187E
	v_mov_b32_e32 v130, v158                                   // 0000000EA1DC: 7F04039E
	s_and_saveexec_b32 s24, s22                                // 0000000EA1E0: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA1E4: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 0000000EA1E8: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v132                          // 0000000EA1EC: 7C950808
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 0000000EA1F0: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA1FC: BF870001
	v_or_b32_e32 v134, v130, v134                              // 0000000EA200: 390D0D82
	v_mov_b32_e32 v130, v131                                   // 0000000EA204: 7F040383
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000EA208: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA20C: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000EA210: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA214: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA218: 8C7E017E
	s_or_b32 s7, s7, 3                                         // 0000000EA21C: 8C078307
	s_mov_b32 s1, exec_lo                                      // 0000000EA220: BE81007E
	.long 0xd4c6007e                                           // 0000000EA224: D4C6007E
	v_cndmask_b32_e32 v1, s7, v161, vcc_lo                     // 0000000EA228: 02034207
	s_xor_b32 s1, exec_lo, s1                                  // 0000000EA22C: 8D01017E
	v_or_b32_e32 v134, 0xf000, v134                            // 0000000EA230: 390D0CFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 0000000EA238: BE813001
	s_cbranch_execz 66                                         // 0000000EA23C: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1448>
	s_mov_b32 s8, exec_lo                                      // 0000000EA240: BE88007E
	.long 0xd4c1007e                                           // 0000000EA244: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 0000000EA248: 02033D82
	s_cbranch_execz 60                                         // 0000000EA24C: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1440>
	s_mov_b32 s22, 0                                           // 0000000EA250: BE960080
	s_set_inst_prefetch_distance 0x1                           // 0000000EA254: BF840001
	s_branch 19                                                // 0000000EA258: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13a8>
	s_nop 0                                                    // 0000000EA25C: BF800000
	s_nop 0                                                    // 0000000EA260: BF800000
	s_nop 0                                                    // 0000000EA264: BF800000
	s_nop 0                                                    // 0000000EA268: BF800000
	s_nop 0                                                    // 0000000EA26C: BF800000
	s_nop 0                                                    // 0000000EA270: BF800000
	s_nop 0                                                    // 0000000EA274: BF800000
	s_nop 0                                                    // 0000000EA278: BF800000
	s_nop 0                                                    // 0000000EA27C: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 0000000EA280: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000EA284: BF870499
	s_and_b32 s26, exec_lo, s25                                // 0000000EA288: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 0000000EA28C: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 0000000EA290: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 0000000EA294: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA298: BF870009
	s_or_b32 s9, s9, s26                                       // 0000000EA29C: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000000EA2A0: 917E167E
	s_cbranch_execz 26                                         // 0000000EA2A4: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1410>
	v_ashrrev_i32_e32 v131, 31, v130                           // 0000000EA2A8: 3507049F
	s_or_b32 s24, s24, exec_lo                                 // 0000000EA2AC: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 0000000EA2B0: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 0000000EA2B4: BE9A007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA2B8: BF870091
	.long 0xd73c0083                                           // 0000000EA2BC: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 0000000EA2C0: 02030482
	.long 0xd7006a83                                           // 0000000EA2C4: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 0000000EA2C8: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA2CC: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 0000000EA2D0: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 0000000EA2D8: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 0000000EA2E0: BF8903F7
	.long 0xd4c4007e                                           // 0000000EA2E4: D4C4007E
	v_cndmask_b32_e32 v1, s7, v131, vcc_lo                     // 0000000EA2E8: 02030607
	s_cbranch_execz 65508                                      // 0000000EA2EC: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1380>
	v_add_nc_u32_e32 v130, 1, v130                             // 0000000EA2F0: 4B050481
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000EA2F4: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 0000000EA2F8: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000EA2FC: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000EA300: 7C95059E
	s_and_b32 s27, vcc_lo, exec_lo                             // 0000000EA304: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 0000000EA308: 8C191B19
	s_branch 65500                                             // 0000000EA30C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1380>
	s_set_inst_prefetch_distance 0x2                           // 0000000EA310: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000EA314: 8C7E167E
	s_and_saveexec_b32 s22, s9                                 // 0000000EA318: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA31C: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 0000000EA320: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v131                          // 0000000EA324: 7C950607
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 0000000EA328: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA334: BF870001
	v_or_b32_e32 v134, v130, v134                              // 0000000EA338: 390D0D82
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000EA33C: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA340: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EA344: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA348: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA34C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000EA350: BF8704C9
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EA354: 8C7E047E
	v_cmp_eq_u32_e32 vcc_lo, 0xffff, v134                      // 0000000EA358: 7C950CFF 0000FFFF
	s_cmp_eq_u32 vcc_lo, -1                                    // 0000000EA360: BF06C16A
	s_cselect_b32 s1, -1, 0                                    // 0000000EA364: 980180C1
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 0000000EA368: D5010082 00050280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA370: BF870001
	v_readfirstlane_b32 s1, v130                               // 0000000EA374: 7E020582
	s_bitcmp0_b32 s1, 0                                        // 0000000EA378: BF0C8001
	s_mov_b32 s1, 0                                            // 0000000EA37C: BE810080
	s_cbranch_scc1 8                                           // 0000000EA380: BFA20008 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14a4>
	s_or_b32 s1, s2, 15                                        // 0000000EA384: 8C018F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EA388: BF8700A9
	v_cmp_le_i32_e32 vcc_lo, s1, v159                          // 0000000EA38C: 7C873E01
	v_cndmask_b32_e64 v130, 0, 1, vcc_lo                       // 0000000EA390: D5010082 01A90280
	v_readfirstlane_b32 s1, v130                               // 0000000EA398: 7E020582
	s_bitcmp1_b32 s1, 0                                        // 0000000EA39C: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 0000000EA3A0: 980180C1
	s_and_saveexec_b32 s4, s3                                  // 0000000EA3A4: BE842003
	s_cbranch_execz 1625                                       // 0000000EA3A8: BFA50659 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2e10>
	ds_load_b32 v132, v163                                     // 0000000EA3AC: D8D80000 840000A3
	s_xor_b32 s1, s1, -1                                       // 0000000EA3B4: 8D01C101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA3B8: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000000EA3BC: 916A017E
	s_mov_b32 s1, -1                                           // 0000000EA3C0: BE8100C1
	s_cbranch_vccnz 985                                        // 0000000EA3C4: BFA403D9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x242c>
	s_waitcnt lgkmcnt(0)                                       // 0000000EA3C8: BF89FC07
	v_dual_mov_b32 v133, v132 :: v_dual_and_b32 v130, 1, v134  // 0000000EA3CC: CA240184 85830C81
	v_cmp_le_i32_e32 vcc_lo, s2, v162                          // 0000000EA3D4: 7C874402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000EA3D8: BF8704A2
	.long 0xd44a0001                                           // 0000000EA3DC: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000EA3E0: 02030481
	s_and_b32 s35, vcc_lo, s1                                  // 0000000EA3E4: 8B23016A
	s_and_saveexec_b32 s1, s35                                 // 0000000EA3E8: BE812023
	s_cbranch_execz 7                                          // 0000000EA3EC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x150c>
	ds_load_b32 v130, v164                                     // 0000000EA3F0: D8D80000 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA3F8: BF89FC07
	v_dual_max_f32 v131, v132, v132 :: v_dual_max_f32 v130, v130, v130// 0000000EA3FC: CA950984 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA404: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA408: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA40C: 8C7E017E
	v_and_b32_e32 v130, 2, v134                                // 0000000EA410: 37050C82
	v_cmp_lt_i32_e32 vcc_lo, s2, v162                          // 0000000EA414: 7C834402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000EA418: BF8704A2
	.long 0xd44d0001                                           // 0000000EA41C: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA420: 02030480
	s_and_b32 s34, vcc_lo, s1                                  // 0000000EA424: 8B22016A
	s_and_saveexec_b32 s1, s34                                 // 0000000EA428: BE812022
	s_cbranch_execz 7                                          // 0000000EA42C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x154c>
	ds_load_b32 v130, v164 offset:4                            // 0000000EA430: D8D80004 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA438: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA43C: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA444: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA448: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA44C: 8C7E017E
	v_and_b32_e32 v130, 4, v134                                // 0000000EA450: 37050C84
	s_or_b32 s1, s2, 2                                         // 0000000EA454: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA458: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000EA45C: 7C874401
	.long 0xd44d0001                                           // 0000000EA460: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA464: 02030480
	s_and_b32 s33, vcc_lo, s1                                  // 0000000EA468: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA46C: BF870009
	s_and_saveexec_b32 s1, s33                                 // 0000000EA470: BE812021
	s_cbranch_execz 7                                          // 0000000EA474: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1594>
	ds_load_b32 v130, v164 offset:8                            // 0000000EA478: D8D80008 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA480: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA484: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA48C: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA490: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA494: 8C7E017E
	v_and_b32_e32 v130, 8, v134                                // 0000000EA498: 37050C88
	s_or_b32 s1, s2, 3                                         // 0000000EA49C: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA4A0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000EA4A4: 7C874401
	.long 0xd44d0001                                           // 0000000EA4A8: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA4AC: 02030480
	s_and_b32 s31, vcc_lo, s1                                  // 0000000EA4B0: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA4B4: BF870009
	s_and_saveexec_b32 s1, s31                                 // 0000000EA4B8: BE81201F
	s_cbranch_execz 7                                          // 0000000EA4BC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15dc>
	ds_load_b32 v130, v164 offset:12                           // 0000000EA4C0: D8D8000C 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA4C8: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA4CC: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA4D4: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA4D8: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA4DC: 8C7E017E
	v_and_b32_e32 v130, 16, v134                               // 0000000EA4E0: 37050C90
	s_or_b32 s1, s2, 4                                         // 0000000EA4E4: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA4E8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000EA4EC: 7C874401
	.long 0xd44d0001                                           // 0000000EA4F0: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA4F4: 02030480
	s_and_b32 s30, vcc_lo, s1                                  // 0000000EA4F8: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA4FC: BF870009
	s_and_saveexec_b32 s1, s30                                 // 0000000EA500: BE81201E
	s_cbranch_execz 7                                          // 0000000EA504: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1624>
	ds_load_b32 v130, v164 offset:16                           // 0000000EA508: D8D80010 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA510: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA514: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA51C: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA520: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA524: 8C7E017E
	v_and_b32_e32 v130, 32, v134                               // 0000000EA528: 37050CA0
	s_or_b32 s1, s2, 5                                         // 0000000EA52C: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA530: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000EA534: 7C874401
	.long 0xd44d0001                                           // 0000000EA538: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA53C: 02030480
	s_and_b32 s29, vcc_lo, s1                                  // 0000000EA540: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA544: BF870009
	s_and_saveexec_b32 s1, s29                                 // 0000000EA548: BE81201D
	s_cbranch_execz 7                                          // 0000000EA54C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x166c>
	ds_load_b32 v130, v164 offset:20                           // 0000000EA550: D8D80014 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA558: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA55C: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA564: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA568: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA56C: 8C7E017E
	v_and_b32_e32 v130, 64, v134                               // 0000000EA570: 37050CC0
	s_or_b32 s1, s2, 6                                         // 0000000EA574: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA578: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000EA57C: 7C874401
	.long 0xd44d0001                                           // 0000000EA580: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA584: 02030480
	s_and_b32 s28, vcc_lo, s1                                  // 0000000EA588: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA58C: BF870009
	s_and_saveexec_b32 s1, s28                                 // 0000000EA590: BE81201C
	s_cbranch_execz 7                                          // 0000000EA594: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16b4>
	ds_load_b32 v130, v164 offset:24                           // 0000000EA598: D8D80018 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA5A0: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA5A4: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA5AC: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA5B0: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA5B4: 8C7E017E
	v_and_b32_e32 v130, 0x80, v134                             // 0000000EA5B8: 37050CFF 00000080
	s_or_b32 s1, s2, 7                                         // 0000000EA5C0: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA5C4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000EA5C8: 7C874401
	.long 0xd44d0001                                           // 0000000EA5CC: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA5D0: 02030480
	s_and_b32 s27, vcc_lo, s1                                  // 0000000EA5D4: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA5D8: BF870009
	s_and_saveexec_b32 s1, s27                                 // 0000000EA5DC: BE81201B
	s_cbranch_execz 7                                          // 0000000EA5E0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1700>
	ds_load_b32 v130, v164 offset:28                           // 0000000EA5E4: D8D8001C 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA5EC: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA5F0: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA5F8: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA5FC: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA600: 8C7E017E
	v_and_b32_e32 v130, 0x100, v134                            // 0000000EA604: 37050CFF 00000100
	s_or_b32 s1, s2, 8                                         // 0000000EA60C: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA610: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000EA614: 7C874401
	.long 0xd44d0001                                           // 0000000EA618: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA61C: 02030480
	s_and_b32 s26, vcc_lo, s1                                  // 0000000EA620: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA624: BF870009
	s_and_saveexec_b32 s1, s26                                 // 0000000EA628: BE81201A
	s_cbranch_execz 7                                          // 0000000EA62C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x174c>
	ds_load_b32 v130, v164 offset:32                           // 0000000EA630: D8D80020 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA638: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA63C: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA644: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA648: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA64C: 8C7E017E
	v_and_b32_e32 v130, 0x200, v134                            // 0000000EA650: 37050CFF 00000200
	s_or_b32 s1, s2, 9                                         // 0000000EA658: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA65C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000EA660: 7C874401
	.long 0xd44d0001                                           // 0000000EA664: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA668: 02030480
	s_and_b32 s25, vcc_lo, s1                                  // 0000000EA66C: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA670: BF870009
	s_and_saveexec_b32 s1, s25                                 // 0000000EA674: BE812019
	s_cbranch_execz 7                                          // 0000000EA678: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1798>
	ds_load_b32 v130, v164 offset:36                           // 0000000EA67C: D8D80024 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA684: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA688: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA690: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA694: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA698: 8C7E017E
	v_and_b32_e32 v130, 0x400, v134                            // 0000000EA69C: 37050CFF 00000400
	s_or_b32 s1, s2, 10                                        // 0000000EA6A4: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA6A8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000EA6AC: 7C874401
	.long 0xd44d0001                                           // 0000000EA6B0: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA6B4: 02030480
	s_and_b32 s24, vcc_lo, s1                                  // 0000000EA6B8: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA6BC: BF870009
	s_and_saveexec_b32 s1, s24                                 // 0000000EA6C0: BE812018
	s_cbranch_execz 7                                          // 0000000EA6C4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17e4>
	ds_load_b32 v130, v164 offset:40                           // 0000000EA6C8: D8D80028 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA6D0: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA6D4: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA6DC: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA6E0: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA6E4: 8C7E017E
	v_and_b32_e32 v130, 0x800, v134                            // 0000000EA6E8: 37050CFF 00000800
	s_or_b32 s1, s2, 11                                        // 0000000EA6F0: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA6F4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000EA6F8: 7C874401
	.long 0xd44d0001                                           // 0000000EA6FC: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA700: 02030480
	s_and_b32 s22, vcc_lo, s1                                  // 0000000EA704: 8B16016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA708: BF870009
	s_and_saveexec_b32 s1, s22                                 // 0000000EA70C: BE812016
	s_cbranch_execz 7                                          // 0000000EA710: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1830>
	ds_load_b32 v130, v164 offset:44                           // 0000000EA714: D8D8002C 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA71C: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA720: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA728: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA72C: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA730: 8C7E017E
	v_and_b32_e32 v130, 0x1000, v134                           // 0000000EA734: 37050CFF 00001000
	s_or_b32 s1, s2, 12                                        // 0000000EA73C: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA740: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000EA744: 7C874401
	.long 0xd44d0001                                           // 0000000EA748: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA74C: 02030480
	s_and_b32 s9, vcc_lo, s1                                   // 0000000EA750: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA754: BF870009
	s_and_saveexec_b32 s1, s9                                  // 0000000EA758: BE812009
	s_cbranch_execz 7                                          // 0000000EA75C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x187c>
	ds_load_b32 v130, v164 offset:48                           // 0000000EA760: D8D80030 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA768: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA76C: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA774: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA778: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA77C: 8C7E017E
	v_and_b32_e32 v130, 0x2000, v134                           // 0000000EA780: 37050CFF 00002000
	s_or_b32 s1, s2, 13                                        // 0000000EA788: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA78C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000EA790: 7C874401
	.long 0xd44d0001                                           // 0000000EA794: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA798: 02030480
	s_and_b32 s8, vcc_lo, s1                                   // 0000000EA79C: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA7A0: BF870009
	s_and_saveexec_b32 s1, s8                                  // 0000000EA7A4: BE812008
	s_cbranch_execz 7                                          // 0000000EA7A8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18c8>
	ds_load_b32 v130, v164 offset:52                           // 0000000EA7AC: D8D80034 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA7B4: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA7B8: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA7C0: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA7C4: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA7C8: 8C7E017E
	v_and_b32_e32 v130, 0x4000, v134                           // 0000000EA7CC: 37050CFF 00004000
	s_or_b32 s1, s2, 14                                        // 0000000EA7D4: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA7D8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000EA7DC: 7C874401
	.long 0xd44d0001                                           // 0000000EA7E0: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA7E4: 02030480
	s_and_b32 s7, vcc_lo, s1                                   // 0000000EA7E8: 8B07016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA7EC: BF870009
	s_and_saveexec_b32 s1, s7                                  // 0000000EA7F0: BE812007
	s_cbranch_execz 7                                          // 0000000EA7F4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1914>
	ds_load_b32 v130, v164 offset:56                           // 0000000EA7F8: D8D80038 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA800: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA804: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA80C: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA810: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EA814: 8C7E017E
	v_and_b32_e32 v130, 0x8000, v134                           // 0000000EA818: 37050CFF 00008000
	s_or_b32 s2, s2, 15                                        // 0000000EA820: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EA824: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v162                          // 0000000EA828: 7C874402
	.long 0xd44d0001                                           // 0000000EA82C: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 0000000EA830: 02030480
	s_and_b32 s1, vcc_lo, s1                                   // 0000000EA834: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EA838: BF870009
	s_and_saveexec_b32 s2, s1                                  // 0000000EA83C: BE822001
	s_cbranch_execz 7                                          // 0000000EA840: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1960>
	ds_load_b32 v130, v164 offset:60                           // 0000000EA844: D8D8003C 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA84C: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 0000000EA850: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EA858: BF870001
	v_max_f32_e32 v133, v131, v130                             // 0000000EA85C: 210B0583
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EA860: 8C7E027E
	v_dual_mov_b32 v130, 0 :: v_dual_mov_b32 v131, 0           // 0000000EA864: CA100080 82820080
	s_and_saveexec_b32 s2, s35                                 // 0000000EA86C: BE822023
	s_cbranch_execz 30                                         // 0000000EA870: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19ec>
	ds_load_b32 v131, v164                                     // 0000000EA874: D8D80000 830000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA87C: BF89FC07
	v_sub_f32_e32 v131, v131, v133                             // 0000000EA880: 09070B83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA884: BF870091
	v_mul_f32_e32 v134, 0x3fb8aa3b, v131                       // 0000000EA888: 110D06FF 3FB8AA3B
	v_fma_f32 v135, 0x3fb8aa3b, v131, -v134                    // 0000000EA890: D6130087 861B06FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 0000000EA89C: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EA8A0: BF870221
	v_sub_f32_e32 v134, v134, v136                             // 0000000EA8A4: 090D1186
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 0000000EA8A8: 7C3706FF C2CE8ED0
	v_fmac_f32_e32 v135, 0x32a5705f, v131                      // 0000000EA8B0: 570F06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EA8B8: BF870121
	v_add_f32_e32 v134, v134, v135                             // 0000000EA8BC: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 0000000EA8C0: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 0000000EA8C4: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA8C8: BF870095
	.long 0xd71c0086                                           // 0000000EA8CC: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 0000000EA8D0: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000000EA8D4: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 0000000EA8D8: 7C3D06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EA8E0: BF870002
	v_cndmask_b32_e32 v131, 0x7f800000, v134, vcc_lo           // 0000000EA8E4: 03070CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EA8EC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA8F0: BF870091
	v_bfe_u32 v134, v131, 16, 1                                // 0000000EA8F4: D6100086 02052183
	v_add3_u32 v134, v131, v134, 0x7fff                        // 0000000EA8FC: D6550086 03FF0D83 00007FFF
	ds_store_b16_d16_hi v165, v134                             // 0000000EA908: DA840000 000086A5
	s_and_saveexec_b32 s2, s34                                 // 0000000EA910: BE822022
	s_cbranch_execz 29                                         // 0000000EA914: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a8c>
	ds_load_b32 v130, v164 offset:4                            // 0000000EA918: D8D80004 820000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA920: BF89FC07
	v_sub_f32_e32 v130, v130, v133                             // 0000000EA924: 09050B82
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EA928: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v130                       // 0000000EA92C: 110D04FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 0000000EA934: 7C3704FF C2CE8ED0
	v_fma_f32 v135, 0x3fb8aa3b, v130, -v134                    // 0000000EA93C: D6130087 861B04FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 0000000EA948: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA94C: BF870091
	v_dual_fmac_f32 v135, 0x32a5705f, v130 :: v_dual_sub_f32 v134, v134, v136// 0000000EA950: C80B04FF 87871186 32A5705F
	v_add_f32_e32 v134, v134, v135                             // 0000000EA95C: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 0000000EA960: 7F0E1188
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EA964: BF870292
	v_exp_f32_e32 v134, v134                                   // 0000000EA968: 7F0C4B86
	.long 0xd71c0086                                           // 0000000EA96C: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 0000000EA970: 02030F86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EA974: BF870121
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000000EA978: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 0000000EA97C: 7C3D04FF 42B17218
	v_cndmask_b32_e32 v130, 0x7f800000, v134, vcc_lo           // 0000000EA984: 03050CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EA98C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EA990: BF870121
	v_bfe_u32 v134, v130, 16, 1                                // 0000000EA994: D6100086 02052182
	v_mov_b32_e32 v135, 0                                      // 0000000EA99C: 7F0E0280
	v_add3_u32 v136, v130, v134, 0x7fff                        // 0000000EA9A0: D6550088 03FF0D82 00007FFF
	v_mov_b32_e32 v134, 0                                      // 0000000EA9AC: 7F0C0280
	ds_store_b16_d16_hi v165, v136 offset:2                    // 0000000EA9B0: DA840002 000088A5
	s_and_saveexec_b32 s2, s33                                 // 0000000EA9B8: BE822021
	s_cbranch_execz 30                                         // 0000000EA9BC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b38>
	ds_load_b32 v135, v164 offset:8                            // 0000000EA9C0: D8D80008 870000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EA9C8: BF89FC07
	v_sub_f32_e32 v135, v135, v133                             // 0000000EA9CC: 090F0B87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EA9D0: BF870091
	v_mul_f32_e32 v136, 0x3fb8aa3b, v135                       // 0000000EA9D4: 11110EFF 3FB8AA3B
	v_fma_f32 v137, 0x3fb8aa3b, v135, -v136                    // 0000000EA9DC: D6130089 86230EFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 0000000EA9E8: 7F244788
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EA9EC: BF870221
	v_sub_f32_e32 v136, v136, v146                             // 0000000EA9F0: 09112588
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 0000000EA9F4: 7C370EFF C2CE8ED0
	v_fmac_f32_e32 v137, 0x32a5705f, v135                      // 0000000EA9FC: 57130EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAA04: BF870121
	v_add_f32_e32 v136, v136, v137                             // 0000000EAA08: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 0000000EAA0C: 7F121192
	v_exp_f32_e32 v136, v136                                   // 0000000EAA10: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAA14: BF870095
	.long 0xd71c0088                                           // 0000000EAA18: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 0000000EAA1C: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000000EAA20: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 0000000EAA24: 7C3D0EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EAA2C: BF870002
	v_cndmask_b32_e32 v135, 0x7f800000, v136, vcc_lo           // 0000000EAA30: 030F10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EAA38: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAA3C: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 0000000EAA40: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 0000000EAA48: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v165, v136 offset:4                    // 0000000EAA54: DA840004 000088A5
	s_and_saveexec_b32 s2, s31                                 // 0000000EAA5C: BE82201F
	s_cbranch_execz 30                                         // 0000000EAA60: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1bdc>
	ds_load_b32 v134, v164 offset:12                           // 0000000EAA64: D8D8000C 860000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EAA6C: BF89FC07
	v_sub_f32_e32 v134, v134, v133                             // 0000000EAA70: 090D0B86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAA74: BF870121
	v_mul_f32_e32 v136, 0x3fb8aa3b, v134                       // 0000000EAA78: 11110CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 0000000EAA80: 7C370CFF C2CE8ED0
	v_fma_f32 v137, 0x3fb8aa3b, v134, -v136                    // 0000000EAA88: D6130089 86230CFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 0000000EAA94: 7F244788
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EAA98: BF870112
	v_fmac_f32_e32 v137, 0x32a5705f, v134                      // 0000000EAA9C: 57130CFF 32A5705F
	v_sub_f32_e32 v136, v136, v146                             // 0000000EAAA4: 09112588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAAA8: BF870121
	v_add_f32_e32 v136, v136, v137                             // 0000000EAAAC: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 0000000EAAB0: 7F121192
	v_exp_f32_e32 v136, v136                                   // 0000000EAAB4: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAAB8: BF870095
	.long 0xd71c0088                                           // 0000000EAABC: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 0000000EAAC0: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000000EAAC4: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 0000000EAAC8: 7C3D0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EAAD0: BF870002
	v_cndmask_b32_e32 v134, 0x7f800000, v136, vcc_lo           // 0000000EAAD4: 030D10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EAADC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAAE0: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 0000000EAAE4: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 0000000EAAEC: 7F120280
	v_add3_u32 v146, v134, v136, 0x7fff                        // 0000000EAAF0: D6550092 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 0000000EAAFC: 7F100280
	ds_store_b16_d16_hi v165, v146 offset:6                    // 0000000EAB00: DA840006 000092A5
	s_and_saveexec_b32 s2, s30                                 // 0000000EAB08: BE82201E
	s_cbranch_execz 30                                         // 0000000EAB0C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c88>
	ds_load_b32 v137, v164 offset:16                           // 0000000EAB10: D8D80010 890000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EAB18: BF89FC07
	v_sub_f32_e32 v137, v137, v133                             // 0000000EAB1C: 09130B89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAB20: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 0000000EAB24: 112512FF 3FB8AA3B
	v_fma_f32 v147, 0x3fb8aa3b, v137, -v146                    // 0000000EAB2C: D6130093 864B12FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 0000000EAB38: 7F284792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EAB3C: BF870221
	v_sub_f32_e32 v146, v146, v148                             // 0000000EAB40: 09252992
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v137                 // 0000000EAB44: 7C3712FF C2CE8ED0
	v_fmac_f32_e32 v147, 0x32a5705f, v137                      // 0000000EAB4C: 572712FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAB54: BF870121
	v_add_f32_e32 v146, v146, v147                             // 0000000EAB58: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 0000000EAB5C: 7F261194
	v_exp_f32_e32 v146, v146                                   // 0000000EAB60: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAB64: BF870095
	.long 0xd71c0092                                           // 0000000EAB68: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 0000000EAB6C: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 0000000EAB70: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v137                 // 0000000EAB74: 7C3D12FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EAB7C: BF870002
	v_cndmask_b32_e32 v137, 0x7f800000, v146, vcc_lo           // 0000000EAB80: 031324FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EAB88: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAB8C: BF870091
	v_bfe_u32 v146, v137, 16, 1                                // 0000000EAB90: D6100092 02052189
	v_add3_u32 v146, v137, v146, 0x7fff                        // 0000000EAB98: D6550092 03FF2589 00007FFF
	ds_store_b16_d16_hi v165, v146 offset:8                    // 0000000EABA4: DA840008 000092A5
	s_and_saveexec_b32 s2, s29                                 // 0000000EABAC: BE82201D
	s_cbranch_execz 30                                         // 0000000EABB0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d2c>
	ds_load_b32 v136, v164 offset:20                           // 0000000EABB4: D8D80014 880000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EABBC: BF89FC07
	v_sub_f32_e32 v136, v136, v133                             // 0000000EABC0: 09110B88
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EABC4: BF870121
	v_mul_f32_e32 v146, 0x3fb8aa3b, v136                       // 0000000EABC8: 112510FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 0000000EABD0: 7C3710FF C2CE8ED0
	v_fma_f32 v147, 0x3fb8aa3b, v136, -v146                    // 0000000EABD8: D6130093 864B10FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 0000000EABE4: 7F284792
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EABE8: BF870112
	v_fmac_f32_e32 v147, 0x32a5705f, v136                      // 0000000EABEC: 572710FF 32A5705F
	v_sub_f32_e32 v146, v146, v148                             // 0000000EABF4: 09252992
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EABF8: BF870121
	v_add_f32_e32 v146, v146, v147                             // 0000000EABFC: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 0000000EAC00: 7F261194
	v_exp_f32_e32 v146, v146                                   // 0000000EAC04: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAC08: BF870095
	.long 0xd71c0092                                           // 0000000EAC0C: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 0000000EAC10: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 0000000EAC14: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 0000000EAC18: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EAC20: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v146, vcc_lo           // 0000000EAC24: 031124FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EAC2C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAC30: BF870121
	v_bfe_u32 v146, v136, 16, 1                                // 0000000EAC34: D6100092 02052188
	v_mov_b32_e32 v147, 0                                      // 0000000EAC3C: 7F260280
	v_add3_u32 v148, v136, v146, 0x7fff                        // 0000000EAC40: D6550094 03FF2588 00007FFF
	v_mov_b32_e32 v146, 0                                      // 0000000EAC4C: 7F240280
	ds_store_b16_d16_hi v165, v148 offset:10                   // 0000000EAC50: DA84000A 000094A5
	s_and_saveexec_b32 s2, s28                                 // 0000000EAC58: BE82201C
	s_cbranch_execz 30                                         // 0000000EAC5C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1dd8>
	ds_load_b32 v147, v164 offset:24                           // 0000000EAC60: D8D80018 930000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EAC68: BF89FC07
	v_sub_f32_e32 v147, v147, v133                             // 0000000EAC6C: 09270B93
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAC70: BF870091
	v_mul_f32_e32 v148, 0x3fb8aa3b, v147                       // 0000000EAC74: 112926FF 3FB8AA3B
	v_fma_f32 v149, 0x3fb8aa3b, v147, -v148                    // 0000000EAC7C: D6130095 865326FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 0000000EAC88: 7F2C4794
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EAC8C: BF870221
	v_sub_f32_e32 v148, v148, v150                             // 0000000EAC90: 09292D94
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 0000000EAC94: 7C3726FF C2CE8ED0
	v_fmac_f32_e32 v149, 0x32a5705f, v147                      // 0000000EAC9C: 572B26FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EACA4: BF870121
	v_add_f32_e32 v148, v148, v149                             // 0000000EACA8: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 0000000EACAC: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 0000000EACB0: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EACB4: BF870095
	.long 0xd71c0094                                           // 0000000EACB8: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 0000000EACBC: 02032B94
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 0000000EACC0: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 0000000EACC4: 7C3D26FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EACCC: BF870002
	v_cndmask_b32_e32 v147, 0x7f800000, v148, vcc_lo           // 0000000EACD0: 032728FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EACD8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EACDC: BF870091
	v_bfe_u32 v148, v147, 16, 1                                // 0000000EACE0: D6100094 02052193
	v_add3_u32 v148, v147, v148, 0x7fff                        // 0000000EACE8: D6550094 03FF2993 00007FFF
	ds_store_b16_d16_hi v165, v148 offset:12                   // 0000000EACF4: DA84000C 000094A5
	s_and_saveexec_b32 s2, s27                                 // 0000000EACFC: BE82201B
	s_cbranch_execz 30                                         // 0000000EAD00: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e7c>
	ds_load_b32 v146, v164 offset:28                           // 0000000EAD04: D8D8001C 920000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EAD0C: BF89FC07
	v_sub_f32_e32 v146, v146, v133                             // 0000000EAD10: 09250B92
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAD14: BF870121
	v_mul_f32_e32 v148, 0x3fb8aa3b, v146                       // 0000000EAD18: 112924FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 0000000EAD20: 7C3724FF C2CE8ED0
	v_fma_f32 v149, 0x3fb8aa3b, v146, -v148                    // 0000000EAD28: D6130095 865324FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 0000000EAD34: 7F2C4794
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EAD38: BF870112
	v_fmac_f32_e32 v149, 0x32a5705f, v146                      // 0000000EAD3C: 572B24FF 32A5705F
	v_sub_f32_e32 v148, v148, v150                             // 0000000EAD44: 09292D94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAD48: BF870121
	v_add_f32_e32 v148, v148, v149                             // 0000000EAD4C: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 0000000EAD50: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 0000000EAD54: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAD58: BF870095
	.long 0xd71c0094                                           // 0000000EAD5C: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 0000000EAD60: 02032B94
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 0000000EAD64: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 0000000EAD68: 7C3D24FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EAD70: BF870002
	v_cndmask_b32_e32 v146, 0x7f800000, v148, vcc_lo           // 0000000EAD74: 032528FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EAD7C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAD80: BF870121
	v_bfe_u32 v148, v146, 16, 1                                // 0000000EAD84: D6100094 02052192
	v_mov_b32_e32 v149, 0                                      // 0000000EAD8C: 7F2A0280
	v_add3_u32 v150, v146, v148, 0x7fff                        // 0000000EAD90: D6550096 03FF2992 00007FFF
	v_mov_b32_e32 v148, 0                                      // 0000000EAD9C: 7F280280
	ds_store_b16_d16_hi v165, v150 offset:14                   // 0000000EADA0: DA84000E 000096A5
	s_and_saveexec_b32 s2, s26                                 // 0000000EADA8: BE82201A
	s_cbranch_execz 30                                         // 0000000EADAC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f28>
	ds_load_b32 v149, v164 offset:32                           // 0000000EADB0: D8D80020 950000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EADB8: BF89FC07
	v_sub_f32_e32 v149, v149, v133                             // 0000000EADBC: 092B0B95
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EADC0: BF870091
	v_mul_f32_e32 v150, 0x3fb8aa3b, v149                       // 0000000EADC4: 112D2AFF 3FB8AA3B
	v_fma_f32 v151, 0x3fb8aa3b, v149, -v150                    // 0000000EADCC: D6130097 865B2AFF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 0000000EADD8: 7F304796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EADDC: BF870221
	v_sub_f32_e32 v150, v150, v152                             // 0000000EADE0: 092D3196
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 0000000EADE4: 7C372AFF C2CE8ED0
	v_fmac_f32_e32 v151, 0x32a5705f, v149                      // 0000000EADEC: 572F2AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EADF4: BF870121
	v_add_f32_e32 v150, v150, v151                             // 0000000EADF8: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 0000000EADFC: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 0000000EAE00: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAE04: BF870095
	.long 0xd71c0096                                           // 0000000EAE08: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 0000000EAE0C: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 0000000EAE10: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 0000000EAE14: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EAE1C: BF870002
	v_cndmask_b32_e32 v149, 0x7f800000, v150, vcc_lo           // 0000000EAE20: 032B2CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EAE28: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAE2C: BF870091
	v_bfe_u32 v150, v149, 16, 1                                // 0000000EAE30: D6100096 02052195
	v_add3_u32 v150, v149, v150, 0x7fff                        // 0000000EAE38: D6550096 03FF2D95 00007FFF
	ds_store_b16_d16_hi v165, v150 offset:16                   // 0000000EAE44: DA840010 000096A5
	s_and_saveexec_b32 s2, s25                                 // 0000000EAE4C: BE822019
	s_cbranch_execz 30                                         // 0000000EAE50: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1fcc>
	ds_load_b32 v148, v164 offset:36                           // 0000000EAE54: D8D80024 940000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EAE5C: BF89FC07
	v_sub_f32_e32 v148, v148, v133                             // 0000000EAE60: 09290B94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAE64: BF870121
	v_mul_f32_e32 v150, 0x3fb8aa3b, v148                       // 0000000EAE68: 112D28FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 0000000EAE70: 7C3728FF C2CE8ED0
	v_fma_f32 v151, 0x3fb8aa3b, v148, -v150                    // 0000000EAE78: D6130097 865B28FF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 0000000EAE84: 7F304796
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EAE88: BF870112
	v_fmac_f32_e32 v151, 0x32a5705f, v148                      // 0000000EAE8C: 572F28FF 32A5705F
	v_sub_f32_e32 v150, v150, v152                             // 0000000EAE94: 092D3196
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAE98: BF870121
	v_add_f32_e32 v150, v150, v151                             // 0000000EAE9C: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 0000000EAEA0: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 0000000EAEA4: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAEA8: BF870095
	.long 0xd71c0096                                           // 0000000EAEAC: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 0000000EAEB0: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 0000000EAEB4: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 0000000EAEB8: 7C3D28FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EAEC0: BF870002
	v_cndmask_b32_e32 v148, 0x7f800000, v150, vcc_lo           // 0000000EAEC4: 03292CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EAECC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAED0: BF870121
	v_bfe_u32 v150, v148, 16, 1                                // 0000000EAED4: D6100096 02052194
	v_mov_b32_e32 v151, 0                                      // 0000000EAEDC: 7F2E0280
	v_add3_u32 v152, v148, v150, 0x7fff                        // 0000000EAEE0: D6550098 03FF2D94 00007FFF
	v_mov_b32_e32 v150, 0                                      // 0000000EAEEC: 7F2C0280
	ds_store_b16_d16_hi v165, v152 offset:18                   // 0000000EAEF0: DA840012 000098A5
	s_and_saveexec_b32 s2, s24                                 // 0000000EAEF8: BE822018
	s_cbranch_execz 29                                         // 0000000EAEFC: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2074>
	ds_load_b32 v151, v164 offset:40                           // 0000000EAF00: D8D80028 970000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EAF08: BF89FC07
	v_sub_f32_e32 v151, v151, v133                             // 0000000EAF0C: 092F0B97
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAF10: BF870121
	v_mul_f32_e32 v152, 0x3fb8aa3b, v151                       // 0000000EAF14: 11312EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 0000000EAF1C: 7C372EFF C2CE8ED0
	v_fma_f32 v153, 0x3fb8aa3b, v151, -v152                    // 0000000EAF24: D6130099 86632EFF 3FB8AA3B
	v_rndne_f32_e32 v177, v152                                 // 0000000EAF30: 7F624798
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAF34: BF870091
	v_dual_fmac_f32 v153, 0x32a5705f, v151 :: v_dual_sub_f32 v152, v152, v177// 0000000EAF38: C80B2EFF 99996398 32A5705F
	v_add_f32_e32 v152, v152, v153                             // 0000000EAF44: 07313398
	v_cvt_i32_f32_e32 v153, v177                               // 0000000EAF48: 7F3211B1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EAF4C: BF870292
	v_exp_f32_e32 v152, v152                                   // 0000000EAF50: 7F304B98
	.long 0xd71c0098                                           // 0000000EAF54: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 0000000EAF58: 02033398
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAF5C: BF870121
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 0000000EAF60: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 0000000EAF64: 7C3D2EFF 42B17218
	v_cndmask_b32_e32 v151, 0x7f800000, v152, vcc_lo           // 0000000EAF6C: 032F30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EAF74: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAF78: BF870091
	v_bfe_u32 v152, v151, 16, 1                                // 0000000EAF7C: D6100098 02052197
	v_add3_u32 v152, v151, v152, 0x7fff                        // 0000000EAF84: D6550098 03FF3197 00007FFF
	ds_store_b16_d16_hi v165, v152 offset:20                   // 0000000EAF90: DA840014 000098A5
	s_and_saveexec_b32 s2, s22                                 // 0000000EAF98: BE822016
	s_cbranch_execz 29                                         // 0000000EAF9C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2114>
	ds_load_b32 v150, v164 offset:44                           // 0000000EAFA0: D8D8002C 960000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EAFA8: BF89FC07
	v_sub_f32_e32 v150, v150, v133                             // 0000000EAFAC: 092D0B96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAFB0: BF870121
	v_mul_f32_e32 v152, 0x3fb8aa3b, v150                       // 0000000EAFB4: 11312CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 0000000EAFBC: 7C372CFF C2CE8ED0
	v_fma_f32 v153, 0x3fb8aa3b, v150, -v152                    // 0000000EAFC4: D6130099 86632CFF 3FB8AA3B
	v_rndne_f32_e32 v177, v152                                 // 0000000EAFD0: 7F624798
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EAFD4: BF870091
	v_dual_fmac_f32 v153, 0x32a5705f, v150 :: v_dual_sub_f32 v152, v152, v177// 0000000EAFD8: C80B2CFF 99996398 32A5705F
	v_add_f32_e32 v152, v152, v153                             // 0000000EAFE4: 07313398
	v_cvt_i32_f32_e32 v153, v177                               // 0000000EAFE8: 7F3211B1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EAFEC: BF870292
	v_exp_f32_e32 v152, v152                                   // 0000000EAFF0: 7F304B98
	.long 0xd71c0098                                           // 0000000EAFF4: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 0000000EAFF8: 02033398
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EAFFC: BF870121
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 0000000EB000: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 0000000EB004: 7C3D2CFF 42B17218
	v_cndmask_b32_e32 v150, 0x7f800000, v152, vcc_lo           // 0000000EB00C: 032D30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EB014: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EB018: BF870121
	v_bfe_u32 v152, v150, 16, 1                                // 0000000EB01C: D6100098 02052196
	v_mov_b32_e32 v153, 0                                      // 0000000EB024: 7F320280
	v_add3_u32 v177, v150, v152, 0x7fff                        // 0000000EB028: D65500B1 03FF3196 00007FFF
	v_mov_b32_e32 v152, 0                                      // 0000000EB034: 7F300280
	ds_store_b16_d16_hi v165, v177 offset:22                   // 0000000EB038: DA840016 0000B1A5
	s_and_saveexec_b32 s2, s9                                  // 0000000EB040: BE822009
	s_cbranch_execz 29                                         // 0000000EB044: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21bc>
	ds_load_b32 v153, v164 offset:48                           // 0000000EB048: D8D80030 990000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EB050: BF89FC07
	v_sub_f32_e32 v153, v153, v133                             // 0000000EB054: 09330B99
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EB058: BF870121
	v_mul_f32_e32 v177, 0x3fb8aa3b, v153                       // 0000000EB05C: 116332FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 0000000EB064: 7C3732FF C2CE8ED0
	v_fma_f32 v178, 0x3fb8aa3b, v153, -v177                    // 0000000EB06C: D61300B2 86C732FF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 0000000EB078: 7F6647B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB07C: BF870091
	v_dual_fmac_f32 v178, 0x32a5705f, v153 :: v_dual_sub_f32 v177, v177, v179// 0000000EB080: C80B32FF B2B167B1 32A5705F
	v_add_f32_e32 v177, v177, v178                             // 0000000EB08C: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 0000000EB090: 7F6411B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EB094: BF870292
	v_exp_f32_e32 v177, v177                                   // 0000000EB098: 7F624BB1
	.long 0xd71c00b1                                           // 0000000EB09C: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 0000000EB0A0: 020365B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EB0A4: BF870121
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 0000000EB0A8: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 0000000EB0AC: 7C3D32FF 42B17218
	v_cndmask_b32_e32 v153, 0x7f800000, v177, vcc_lo           // 0000000EB0B4: 033362FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EB0BC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB0C0: BF870091
	v_bfe_u32 v177, v153, 16, 1                                // 0000000EB0C4: D61000B1 02052199
	v_add3_u32 v177, v153, v177, 0x7fff                        // 0000000EB0CC: D65500B1 03FF6399 00007FFF
	ds_store_b16_d16_hi v165, v177 offset:24                   // 0000000EB0D8: DA840018 0000B1A5
	s_and_saveexec_b32 s2, s8                                  // 0000000EB0E0: BE822008
	s_cbranch_execz 30                                         // 0000000EB0E4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2260>
	ds_load_b32 v152, v164 offset:52                           // 0000000EB0E8: D8D80034 980000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EB0F0: BF89FC07
	v_sub_f32_e32 v152, v152, v133                             // 0000000EB0F4: 09310B98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB0F8: BF870091
	v_mul_f32_e32 v177, 0x3fb8aa3b, v152                       // 0000000EB0FC: 116330FF 3FB8AA3B
	v_fma_f32 v178, 0x3fb8aa3b, v152, -v177                    // 0000000EB104: D61300B2 86C730FF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 0000000EB110: 7F6647B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EB114: BF870221
	v_sub_f32_e32 v177, v177, v179                             // 0000000EB118: 096367B1
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 0000000EB11C: 7C3730FF C2CE8ED0
	v_fmac_f32_e32 v178, 0x32a5705f, v152                      // 0000000EB124: 576530FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EB12C: BF870121
	v_add_f32_e32 v177, v177, v178                             // 0000000EB130: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 0000000EB134: 7F6411B3
	v_exp_f32_e32 v177, v177                                   // 0000000EB138: 7F624BB1
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB13C: BF870095
	.long 0xd71c00b1                                           // 0000000EB140: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 0000000EB144: 020365B1
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 0000000EB148: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 0000000EB14C: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EB154: BF870002
	v_cndmask_b32_e32 v152, 0x7f800000, v177, vcc_lo           // 0000000EB158: 033162FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EB160: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EB164: BF870121
	v_bfe_u32 v177, v152, 16, 1                                // 0000000EB168: D61000B1 02052198
	v_mov_b32_e32 v178, 0                                      // 0000000EB170: 7F640280
	v_add3_u32 v179, v152, v177, 0x7fff                        // 0000000EB174: D65500B3 03FF6398 00007FFF
	v_mov_b32_e32 v177, 0                                      // 0000000EB180: 7F620280
	ds_store_b16_d16_hi v165, v179 offset:26                   // 0000000EB184: DA84001A 0000B3A5
	s_and_saveexec_b32 s2, s7                                  // 0000000EB18C: BE822007
	s_cbranch_execz 29                                         // 0000000EB190: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2308>
	ds_load_b32 v178, v164 offset:56                           // 0000000EB194: D8D80038 B20000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EB19C: BF89FC07
	v_sub_f32_e32 v178, v178, v133                             // 0000000EB1A0: 09650BB2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB1A4: BF870091
	v_mul_f32_e32 v179, 0x3fb8aa3b, v178                       // 0000000EB1A8: 116764FF 3FB8AA3B
	v_fma_f32 v180, 0x3fb8aa3b, v178, -v179                    // 0000000EB1B0: D61300B4 86CF64FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000EB1BC: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB1C0: BF870091
	v_dual_fmac_f32 v180, 0x32a5705f, v178 :: v_dual_sub_f32 v179, v179, v181// 0000000EB1C4: C80B64FF B4B36BB3 32A5705F
	v_add_f32_e32 v179, v179, v180                             // 0000000EB1D0: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000EB1D4: 7F6811B5
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 0000000EB1D8: 7C3764FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EB1E0: BF870293
	v_exp_f32_e32 v179, v179                                   // 0000000EB1E4: 7F664BB3
	.long 0xd71c00b3                                           // 0000000EB1E8: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000EB1EC: 020369B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EB1F0: BF870121
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000EB1F4: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 0000000EB1F8: 7C3D64FF 42B17218
	v_cndmask_b32_e32 v178, 0x7f800000, v179, vcc_lo           // 0000000EB200: 036566FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EB208: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB20C: BF870091
	v_bfe_u32 v179, v178, 16, 1                                // 0000000EB210: D61000B3 020521B2
	v_add3_u32 v179, v178, v179, 0x7fff                        // 0000000EB218: D65500B3 03FF67B2 00007FFF
	ds_store_b16_d16_hi v165, v179 offset:28                   // 0000000EB224: DA84001C 0000B3A5
	s_and_saveexec_b32 s2, s1                                  // 0000000EB22C: BE822001
	s_cbranch_execz 30                                         // 0000000EB230: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x23ac>
	ds_load_b32 v177, v164 offset:60                           // 0000000EB234: D8D8003C B10000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000EB23C: BF89FC07
	v_sub_f32_e32 v177, v177, v133                             // 0000000EB240: 09630BB1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EB244: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v177                       // 0000000EB248: 116762FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v177                 // 0000000EB250: 7C3762FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v177, -v179                    // 0000000EB258: D61300B4 86CF62FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000EB264: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EB268: BF870112
	v_fmac_f32_e32 v180, 0x32a5705f, v177                      // 0000000EB26C: 576962FF 32A5705F
	v_sub_f32_e32 v179, v179, v181                             // 0000000EB274: 09676BB3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EB278: BF870121
	v_add_f32_e32 v179, v179, v180                             // 0000000EB27C: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000EB280: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 0000000EB284: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB288: BF870095
	.long 0xd71c00b3                                           // 0000000EB28C: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000EB290: 020369B3
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000EB294: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v177                 // 0000000EB298: 7C3D62FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EB2A0: BF870002
	v_cndmask_b32_e32 v177, 0x7f800000, v179, vcc_lo           // 0000000EB2A4: 036366FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EB2AC: 8C7E027E
	v_add_f32_e32 v130, v131, v130                             // 0000000EB2B0: 07050583
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EB2B4: BF870122
	v_bfe_u32 v131, v177, 16, 1                                // 0000000EB2B8: D6100083 020521B1
	s_mov_b32 s1, 0                                            // 0000000EB2C0: BE810080
	v_add_f32_e32 v130, v130, v135                             // 0000000EB2C4: 07050F82
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EB2C8: BF870112
	v_add3_u32 v131, v177, v131, 0x7fff                        // 0000000EB2CC: D6550083 03FF07B1 00007FFF
	v_add_f32_e32 v130, v130, v134                             // 0000000EB2D8: 07050D82
	ds_store_b16_d16_hi v165, v131 offset:30                   // 0000000EB2DC: DA84001E 000083A5
	v_add_f32_e32 v130, v130, v137                             // 0000000EB2E4: 07051382
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB2E8: BF870091
	v_add_f32_e32 v130, v130, v136                             // 0000000EB2EC: 07051182
	v_add_f32_e32 v130, v130, v147                             // 0000000EB2F0: 07052782
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB2F4: BF870091
	v_add_f32_e32 v130, v130, v146                             // 0000000EB2F8: 07052582
	v_add_f32_e32 v130, v130, v149                             // 0000000EB2FC: 07052B82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB300: BF870091
	v_add_f32_e32 v130, v130, v148                             // 0000000EB304: 07052982
	v_add_f32_e32 v130, v130, v151                             // 0000000EB308: 07052F82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB30C: BF870091
	v_add_f32_e32 v130, v130, v150                             // 0000000EB310: 07052D82
	v_add_f32_e32 v130, v130, v153                             // 0000000EB314: 07053382
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB318: BF870091
	v_add_f32_e32 v130, v130, v152                             // 0000000EB31C: 07053182
	v_add_f32_e32 v130, v130, v178                             // 0000000EB320: 07056582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EB324: BF870001
	v_add_f32_e32 v130, v130, v177                             // 0000000EB328: 07056382
	s_and_b32 vcc_lo, exec_lo, s1                              // 0000000EB32C: 8B6A017E
	s_cbranch_vccz 587                                         // 0000000EB330: BFA3024B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2d60>
	ds_load_2addr_b32 v[135:136], v164 offset1:1               // 0000000EB334: D8DC0100 870000A4
	ds_load_2addr_b32 v[146:147], v164 offset0:2 offset1:3     // 0000000EB33C: D8DC0302 920000A4
	ds_load_2addr_b32 v[148:149], v164 offset0:4 offset1:5     // 0000000EB344: D8DC0504 940000A4
	ds_load_2addr_b32 v[150:151], v164 offset0:6 offset1:7     // 0000000EB34C: D8DC0706 960000A4
	ds_load_2addr_b32 v[152:153], v164 offset0:8 offset1:9     // 0000000EB354: D8DC0908 980000A4
	ds_load_2addr_b32 v[177:178], v164 offset0:10 offset1:11   // 0000000EB35C: D8DC0B0A B10000A4
	.long 0xd59c4086                                           // 0000000EB364: D59C4086
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 0000000EB368: 02010080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000EB36C: BF8700D1
	.long 0xd59c4889                                           // 0000000EB370: D59C4889
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 0000000EB374: 02010186
	.long 0xd59c48b5                                           // 0000000EB378: D59C48B5
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 0000000EB37C: 02010186
	s_waitcnt lgkmcnt(5)                                       // 0000000EB380: BF89FC57
	v_max3_f32 v130, v132, v135, v136                          // 0000000EB384: D61C0082 06230F84
	s_waitcnt lgkmcnt(4)                                       // 0000000EB38C: BF89FC47
	v_max3_f32 v130, v130, v146, v147                          // 0000000EB390: D61C0082 064F2582
	s_waitcnt lgkmcnt(3)                                       // 0000000EB398: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EB39C: BF870001
	v_max3_f32 v133, v130, v148, v149                          // 0000000EB3A0: D61C0085 06572982
	ds_load_2addr_b32 v[179:180], v164 offset0:12 offset1:13   // 0000000EB3A8: D8DC0D0C B30000A4
	ds_load_2addr_b32 v[130:131], v164 offset0:14 offset1:15   // 0000000EB3B0: D8DC0F0E 820000A4
	s_waitcnt lgkmcnt(4)                                       // 0000000EB3B8: BF89FC47
	v_max3_f32 v133, v133, v150, v151                          // 0000000EB3BC: D61C0085 065F2D85
	s_waitcnt lgkmcnt(3)                                       // 0000000EB3C4: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EB3C8: BF8700A1
	v_max3_f32 v133, v133, v152, v153                          // 0000000EB3CC: D61C0085 06673185
	s_waitcnt lgkmcnt(2)                                       // 0000000EB3D4: BF89FC27
	v_max3_f32 v133, v133, v177, v178                          // 0000000EB3D8: D61C0085 06CB6385
	s_waitcnt lgkmcnt(1)                                       // 0000000EB3E0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EB3E4: BF8700A1
	v_max3_f32 v133, v133, v179, v180                          // 0000000EB3E8: D61C0085 06D36785
	s_waitcnt lgkmcnt(0)                                       // 0000000EB3F0: BF89FC07
	v_max3_f32 v133, v133, v130, v131                          // 0000000EB3F4: D61C0085 060F0585
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EB3FC: BF870001
	v_sub_f32_e32 v147, v147, v133                             // 0000000EB400: 09270B93
	v_sub_f32_e32 v135, v135, v133                             // 0000000EB404: 090F0B87
	v_sub_f32_e32 v146, v146, v133                             // 0000000EB408: 09250B92
	v_sub_f32_e32 v136, v136, v133                             // 0000000EB40C: 09110B88
	v_sub_f32_e32 v150, v150, v133                             // 0000000EB410: 092D0B96
	v_mul_f32_e32 v184, 0x3fb8aa3b, v147                       // 0000000EB414: 117126FF 3FB8AA3B
	v_mul_f32_e32 v182, 0x3fb8aa3b, v135                       // 0000000EB41C: 116D0EFF 3FB8AA3B
	v_dual_sub_f32 v148, v148, v133 :: v_dual_mul_f32 v185, 0x3fb8aa3b, v146// 0000000EB424: C9470B94 94B924FF 3FB8AA3B
	v_mul_f32_e32 v183, 0x3fb8aa3b, v136                       // 0000000EB430: 116F10FF 3FB8AA3B
	v_mul_f32_e32 v189, 0x3fb8aa3b, v150                       // 0000000EB438: 117B2CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EB440: BF870004
	v_fma_f32 v190, 0x3fb8aa3b, v135, -v182                    // 0000000EB444: D61300BE 86DB0EFF 3FB8AA3B
	v_rndne_f32_e32 v191, v182                                 // 0000000EB450: 7F7E47B6
	v_sub_f32_e32 v151, v151, v133                             // 0000000EB454: 092F0B97
	v_mul_f32_e32 v187, 0x3fb8aa3b, v148                       // 0000000EB458: 117728FF 3FB8AA3B
	v_fma_f32 v192, 0x3fb8aa3b, v136, -v183                    // 0000000EB460: D61300C0 86DF10FF 3FB8AA3B
	v_rndne_f32_e32 v193, v183                                 // 0000000EB46C: 7F8247B7
	v_fmac_f32_e32 v190, 0x32a5705f, v135                      // 0000000EB470: 577D0EFF 32A5705F
	v_dual_sub_f32 v182, v182, v191 :: v_dual_sub_f32 v149, v149, v133// 0000000EB478: C94B7FB6 B6950B95
	v_mul_f32_e32 v188, 0x3fb8aa3b, v151                       // 0000000EB480: 11792EFF 3FB8AA3B
	v_fma_f32 v194, 0x3fb8aa3b, v147, -v184                    // 0000000EB488: D61300C2 86E326FF 3FB8AA3B
	v_rndne_f32_e32 v197, v185                                 // 0000000EB494: 7F8A47B9
	v_fma_f32 v200, 0x3fb8aa3b, v148, -v187                    // 0000000EB498: D61300C8 86EF28FF 3FB8AA3B
	v_rndne_f32_e32 v201, v187                                 // 0000000EB4A4: 7F9247BB
	v_dual_fmac_f32 v192, 0x32a5705f, v136 :: v_dual_sub_f32 v183, v183, v193// 0000000EB4A8: C80B10FF C0B783B7 32A5705F
	v_add_f32_e32 v182, v182, v190                             // 0000000EB4B4: 076D7DB6
	v_rndne_f32_e32 v195, v184                                 // 0000000EB4B8: 7F8647B8
	v_fma_f32 v196, 0x3fb8aa3b, v146, -v185                    // 0000000EB4BC: D61300C4 86E724FF 3FB8AA3B
	v_dual_fmac_f32 v194, 0x32a5705f, v147 :: v_dual_sub_f32 v187, v187, v201// 0000000EB4C8: C80B26FF C2BB93BB 32A5705F
	v_sub_f32_e32 v185, v185, v197                             // 0000000EB4D4: 09738BB9
	v_dual_mul_f32 v186, 0x3fb8aa3b, v149 :: v_dual_add_f32 v183, v183, v192// 0000000EB4D8: C8C92AFF BAB781B7 3FB8AA3B
	v_fmac_f32_e32 v200, 0x32a5705f, v148                      // 0000000EB4E4: 579128FF 32A5705F
	v_exp_f32_e32 v182, v182                                   // 0000000EB4EC: 7F6C4BB6
	v_cvt_i32_f32_e32 v191, v191                               // 0000000EB4F0: 7F7E11BF
	v_fmac_f32_e32 v196, 0x32a5705f, v146                      // 0000000EB4F4: 578924FF 32A5705F
	v_exp_f32_e32 v183, v183                                   // 0000000EB4FC: 7F6E4BB7
	v_dual_add_f32 v187, v187, v200 :: v_dual_sub_f32 v184, v184, v195// 0000000EB500: C90B91BB BBB987B8
	v_fma_f32 v198, 0x3fb8aa3b, v149, -v186                    // 0000000EB508: D61300C6 86EB2AFF 3FB8AA3B
	v_rndne_f32_e32 v199, v186                                 // 0000000EB514: 7F8E47BA
	v_cvt_i32_f32_e32 v193, v193                               // 0000000EB518: 7F8211C1
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000000EB51C: BF870314
	v_dual_add_f32 v185, v185, v196 :: v_dual_add_f32 v184, v184, v194// 0000000EB520: C90989B9 B9B985B8
	.long 0xd71c00b6                                           // 0000000EB528: D71C00B6
	v_cndmask_b32_e32 v1, v182, v191, vcc_lo                   // 0000000EB52C: 02037FB6
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 0000000EB530: 7C370EFF C2CE8ED0
	v_rndne_f32_e32 v205, v189                                 // 0000000EB538: 7F9A47BD
	v_sub_f32_e32 v186, v186, v199                             // 0000000EB53C: 09758FBA
	v_exp_f32_e32 v184, v184                                   // 0000000EB540: 7F704BB8
	.long 0xd71c00b7                                           // 0000000EB544: D71C00B7
	v_cndmask_b32_e32 v1, v183, v193, vcc_lo                   // 0000000EB548: 020383B7
	v_cndmask_b32_e32 v182, 0, v182, vcc_lo                    // 0000000EB54C: 036D6C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 0000000EB550: 7C3710FF C2CE8ED0
	v_fmac_f32_e32 v198, 0x32a5705f, v149                      // 0000000EB558: 578D2AFF 32A5705F
	v_fma_f32 v204, 0x3fb8aa3b, v150, -v189                    // 0000000EB560: D61300CC 86F72CFF 3FB8AA3B
	v_cvt_i32_f32_e32 v195, v195                               // 0000000EB56C: 7F8611C3
	v_exp_f32_e32 v185, v185                                   // 0000000EB570: 7F724BB9
	v_sub_f32_e32 v189, v189, v205                             // 0000000EB574: 097B9BBD
	v_dual_cndmask_b32 v183, 0, v183 :: v_dual_add_f32 v186, v186, v198// 0000000EB578: CA496E80 B7BB8DBA
	v_cvt_i32_f32_e32 v197, v197                               // 0000000EB580: 7F8A11C5
	.long 0xd71c00b8                                           // 0000000EB584: D71C00B8
	v_cndmask_b32_e32 v1, v184, v195, vcc_lo                   // 0000000EB588: 020387B8
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 0000000EB58C: 7C3726FF C2CE8ED0
	v_cvt_i32_f32_e32 v199, v199                               // 0000000EB594: 7F8E11C7
	v_exp_f32_e32 v186, v186                                   // 0000000EB598: 7F744BBA
	v_rndne_f32_e32 v203, v188                                 // 0000000EB59C: 7F9647BC
	s_delay_alu instid0(TRANS32_DEP_2)                         // 0000000EB5A0: BF870006
	.long 0xd71c00b9                                           // 0000000EB5A4: D71C00B9
	v_cndmask_b32_e32 v1, v185, v197, vcc_lo                   // 0000000EB5A8: 02038BB9
	v_cndmask_b32_e32 v184, 0, v184, vcc_lo                    // 0000000EB5AC: 03717080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 0000000EB5B0: 7C3724FF C2CE8ED0
	v_fma_f32 v202, 0x3fb8aa3b, v151, -v188                    // 0000000EB5B8: D61300CA 86F32EFF 3FB8AA3B
	v_exp_f32_e32 v187, v187                                   // 0000000EB5C4: 7F764BBB
	v_cvt_i32_f32_e32 v201, v201                               // 0000000EB5C8: 7F9211C9
	v_sub_f32_e32 v179, v179, v133                             // 0000000EB5CC: 09670BB3
	v_cndmask_b32_e32 v185, 0, v185, vcc_lo                    // 0000000EB5D0: 03737280
	.long 0xd71c00ba                                           // 0000000EB5D4: D71C00BA
	v_cndmask_b32_e32 v1, v186, v199, vcc_lo                   // 0000000EB5D8: 02038FBA
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 0000000EB5DC: 7C372AFF C2CE8ED0
	v_sub_f32_e32 v130, v130, v133                             // 0000000EB5E4: 09050B82
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000000EB5E8: BF8702A3
	v_dual_sub_f32 v153, v153, v133 :: v_dual_cndmask_b32 v186, 0, v186// 0000000EB5EC: C9530B99 99BB7480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 0000000EB5F4: 7C3D10FF 42B17218
	.long 0xd71c00bb                                           // 0000000EB5FC: D71C00BB
	v_cndmask_b32_e32 v1, v187, v201, vcc_lo                   // 0000000EB600: 020393BB
	v_cndmask_b32_e32 v136, 0x7f800000, v183, vcc_lo           // 0000000EB604: 03116EFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 0000000EB60C: 7C3D0EFF 42B17218
	v_dual_sub_f32 v188, v188, v203 :: v_dual_cndmask_b32 v135, 0x7f800000, v182// 0000000EB614: C95397BC BC876CFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 0000000EB620: 7C3D24FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000EB628: BF8701C2
	v_add_f32_e32 v146, v135, v136                             // 0000000EB62C: 07251187
	v_cndmask_b32_e32 v182, 0x7f800000, v185, vcc_lo           // 0000000EB630: 036D72FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 0000000EB638: 7C3D26FF 42B17218
	.long 0xd59c0889                                           // 0000000EB640: D59C0889
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 0000000EB644: 02010187
	.long 0xd59c08b5                                           // 0000000EB648: D59C08B5
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                   // 0000000EB64C: 020101B6
	v_cndmask_b32_e32 v183, 0x7f800000, v184, vcc_lo           // 0000000EB650: 036F70FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 0000000EB658: 7C3728FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EB660: BF870214
	v_and_b32_e32 v137, 1, v137                                // 0000000EB664: 37131281
	v_dual_cndmask_b32 v184, 0, v187 :: v_dual_and_b32 v181, 1, v181// 0000000EB668: CA657680 B8B56A81
	v_add_f32_e32 v187, v146, v182                             // 0000000EB670: 07776D92
	.long 0xd59c0886                                           // 0000000EB674: D59C0886
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 0000000EB678: 02010188
	v_fmac_f32_e32 v202, 0x32a5705f, v151                      // 0000000EB67C: 57952EFF 32A5705F
	v_fmac_f32_e32 v204, 0x32a5705f, v150                      // 0000000EB684: 57992CFF 32A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 0000000EB68C: 7C3D28FF 42B17218
	v_add3_u32 v135, v135, v137, 0x7fff                        // 0000000EB694: D6550087 03FF1387 00007FFF
	v_and_b32_e32 v147, 1, v134                                // 0000000EB6A0: 37270C81
	.long 0xd59c0886                                           // 0000000EB6A4: D59C0886
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                   // 0000000EB6A8: 020101B7
	v_dual_add_f32 v148, v188, v202 :: v_dual_cndmask_b32 v137, 0x7f800000, v184// 0000000EB6AC: C91395BC 948970FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 0000000EB6B8: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EB6C0: BF870214
	v_add3_u32 v146, v136, v147, 0x7fff                        // 0000000EB6C4: D6550092 03FF2788 00007FFF
	v_and_b32_e32 v185, 1, v134                                // 0000000EB6D0: 37730C81
	v_add3_u32 v136, v182, v181, 0x7fff                        // 0000000EB6D4: D6550088 03FF6BB6 00007FFF
	v_exp_f32_e32 v148, v148                                   // 0000000EB6E0: 7F284B94
	.long 0xd59c08b6                                           // 0000000EB6E4: D59C08B6
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 0000000EB6E8: 02010189
	.long 0xd59c48b6                                           // 0000000EB6EC: D59C48B6
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 0000000EB6F0: 02010186
	v_add3_u32 v147, v183, v185, 0x7fff                        // 0000000EB6F4: D6550093 03FF73B7 00007FFF
	v_add_f32_e32 v183, v187, v183                             // 0000000EB700: 076F6FBB
	v_add_f32_e32 v181, v189, v204                             // 0000000EB704: 076B99BD
	v_cndmask_b32_e32 v149, 0x7f800000, v186, vcc_lo           // 0000000EB708: 032B74FF 7F800000
	v_cvt_i32_f32_e32 v184, v203                               // 0000000EB710: 7F7011CB
	v_cvt_i32_f32_e32 v186, v205                               // 0000000EB714: 7F7411CD
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 0000000EB718: 7C372EFF C2CE8ED0
	v_exp_f32_e32 v181, v181                                   // 0000000EB720: 7F6A4BB5
	.long 0xd59c0886                                           // 0000000EB724: D59C0886
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                   // 0000000EB728: 02010195
	.long 0xd71c00b8                                           // 0000000EB72C: D71C00B8
	v_cndmask_b32_e32 v1, v148, v184, vcc_lo                   // 0000000EB730: 02037194
	v_add_f32_e32 v183, v183, v137                             // 0000000EB734: 076F13B7
	.long 0xd59c0893                                           // 0000000EB738: D59C0893
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 0000000EB73C: 02010188
	.long 0xd59c0892                                           // 0000000EB740: D59C0892
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 0000000EB744: 02010187
	v_and_b32_e32 v185, 1, v134                                // 0000000EB748: 37730C81
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000EB74C: BF8701A5
	.long 0xd71c00b5                                           // 0000000EB750: D71C00B5
	v_cndmask_b32_e32 v1, v181, v186, vcc_lo                   // 0000000EB754: 020375B5
	v_and_b32_e32 v182, 1, v182                                // 0000000EB758: 376D6C81
	v_add3_u32 v148, v149, v185, 0x7fff                        // 0000000EB75C: D6550094 03FF7395 00007FFF
	v_add_f32_e32 v149, v183, v149                             // 0000000EB768: 072B2BB7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000EB76C: BF870243
	v_add3_u32 v137, v137, v182, 0x7fff                        // 0000000EB770: D6550089 03FF6D89 00007FFF
	v_cndmask_b32_e32 v182, 0, v184, vcc_lo                    // 0000000EB77C: 036D7080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 0000000EB780: 7C372CFF C2CE8ED0
	.long 0xd59c48b8                                           // 0000000EB788: D59C48B8
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 0000000EB78C: 02010186
	.long 0xd59c0894                                           // 0000000EB790: D59C0894
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 0000000EB794: 02010189
	v_cndmask_b32_e32 v181, 0, v181, vcc_lo                    // 0000000EB798: 036B6A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 0000000EB79C: 7C3D2EFF 42B17218
	v_cndmask_b32_e32 v151, 0x7f800000, v182, vcc_lo           // 0000000EB7A4: 032F6CFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 0000000EB7AC: 7C3D2CFF 42B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EB7B4: BF870194
	v_cndmask_b32_e32 v150, 0x7f800000, v181, vcc_lo           // 0000000EB7B8: 032D6AFF 7F800000
	.long 0xd59c0886                                           // 0000000EB7C0: D59C0886
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 0000000EB7C4: 02010197
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 0000000EB7C8: 7C3732FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EB7D0: BF870123
	.long 0xd59c08b8                                           // 0000000EB7D4: D59C08B8
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                   // 0000000EB7D8: 02010196
	v_sub_f32_e32 v152, v152, v133                             // 0000000EB7DC: 09310B98
	v_dual_add_f32 v186, v149, v150 :: v_dual_and_b32 v149, 1, v184// 0000000EB7E0: C9252D95 BA957081
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000EB7E8: BF8701A2
	v_dual_mul_f32 v182, 0x3fb8aa3b, v153 :: v_dual_mul_f32 v185, 0x3fb8aa3b, v152// 0000000EB7EC: C8C732FF B6B930FF 3FB8AA3B
	v_and_b32_e32 v184, 1, v134                                // 0000000EB7F8: 37710C81
	v_add3_u32 v150, v150, v149, 0x7fff                        // 0000000EB7FC: D6550096 03FF2B96 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000000EB808: BF870253
	v_fma_f32 v181, 0x3fb8aa3b, v153, -v182                    // 0000000EB80C: D61300B5 86DB32FF 3FB8AA3B
	v_rndne_f32_e32 v183, v182                                 // 0000000EB818: 7F6E47B6
	v_rndne_f32_e32 v187, v185                                 // 0000000EB81C: 7F7647B9
	v_add3_u32 v149, v151, v184, 0x7fff                        // 0000000EB820: D6550095 03FF7197 00007FFF
	.long 0xd59c0895                                           // 0000000EB82C: D59C0895
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                   // 0000000EB830: 02010196
	v_dual_fmac_f32 v181, 0x32a5705f, v153 :: v_dual_sub_f32 v182, v182, v183// 0000000EB834: C80B32FF B5B76FB6 32A5705F
	v_cvt_i32_f32_e32 v136, v183                               // 0000000EB840: 7F1011B7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000EB844: BF8701B2
	v_add_f32_e32 v181, v182, v181                             // 0000000EB848: 076B6BB6
	v_fma_f32 v182, 0x3fb8aa3b, v152, -v185                    // 0000000EB84C: D61300B6 86E730FF 3FB8AA3B
	v_add_f32_e32 v151, v186, v151                             // 0000000EB858: 072F2FBA
	v_exp_f32_e32 v181, v181                                   // 0000000EB85C: 7F6A4BB5
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EB860: BF870195
	.long 0xd71c0087                                           // 0000000EB864: D71C0087
	v_cndmask_b32_e32 v1, v181, v136, vcc_lo                   // 0000000EB868: 020311B5
	v_fmac_f32_e32 v182, 0x32a5705f, v152                      // 0000000EB86C: 576D30FF 32A5705F
	v_cvt_i32_f32_e32 v181, v187                               // 0000000EB874: 7F6A11BB
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000EB878: BF870133
	v_dual_cndmask_b32 v135, 0, v135 :: v_dual_sub_f32 v150, v177, v133// 0000000EB87C: CA4B0E80 87970BB1
	v_dual_sub_f32 v184, v185, v187 :: v_dual_sub_f32 v177, v178, v133// 0000000EB884: C94B77B9 B8B10BB2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 0000000EB88C: 7C3730FF C2CE8ED0
	v_dual_add_f32 v137, v184, v182 :: v_dual_mul_f32 v178, 0x3fb8aa3b, v177// 0000000EB894: C9076DB8 89B362FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EB8A0: BF870091
	v_exp_f32_e32 v136, v137                                   // 0000000EB8A4: 7F104B89
	v_fma_f32 v184, 0x3fb8aa3b, v177, -v178                    // 0000000EB8A8: D61300B8 86CB62FF 3FB8AA3B
	v_rndne_f32_e32 v185, v178                                 // 0000000EB8B4: 7F7247B2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EB8B8: BF870115
	.long 0xd71c0088                                           // 0000000EB8BC: D71C0088
	v_cndmask_b32_e32 v1, v136, v181, vcc_lo                   // 0000000EB8C0: 02036B88
	v_cvt_i32_f32_e32 v181, v185                               // 0000000EB8C4: 7F6A11B9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000000EB8C8: BF8701D2
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000000EB8CC: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 0000000EB8D0: 7C3D32FF 42B17218
	v_cndmask_b32_e32 v135, 0x7f800000, v135, vcc_lo           // 0000000EB8D8: 030F0EFF 7F800000
	v_mul_f32_e32 v137, 0x3fb8aa3b, v150                       // 0000000EB8E0: 11132CFF 3FB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 0000000EB8E8: 7C3D30FF 42B17218
	.long 0xd59c0886                                           // 0000000EB8F0: D59C0886
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 0000000EB8F4: 02010187
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000000EB8F8: BF870253
	v_fma_f32 v182, 0x3fb8aa3b, v150, -v137                    // 0000000EB8FC: D61300B6 86272CFF 3FB8AA3B
	v_rndne_f32_e32 v183, v137                                 // 0000000EB908: 7F6E4789
	v_cndmask_b32_e32 v136, 0x7f800000, v136, vcc_lo           // 0000000EB90C: 031110FF 7F800000
	v_sub_f32_e32 v178, v178, v185                             // 0000000EB914: 096573B2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 0000000EB918: 7C372CFF C2CE8ED0
	v_dual_fmac_f32 v182, 0x32a5705f, v150 :: v_dual_sub_f32 v137, v137, v183// 0000000EB920: C80B2CFF B6896F89 32A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EB92C: BF870114
	v_dual_fmac_f32 v184, 0x32a5705f, v177 :: v_dual_add_f32 v151, v151, v136// 0000000EB930: C80962FF B8971197 32A5705F
	v_add_f32_e32 v137, v137, v182                             // 0000000EB93C: 07136D89
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000000EB940: BF870232
	v_dual_add_f32 v153, v178, v184 :: v_dual_and_b32 v182, 1, v134// 0000000EB944: C92571B2 99B70C81
	v_cvt_i32_f32_e32 v178, v183                               // 0000000EB94C: 7F6411B7
	v_mul_f32_e32 v184, 0x3fb8aa3b, v130                       // 0000000EB950: 117104FF 3FB8AA3B
	v_exp_f32_e32 v137, v137                                   // 0000000EB958: 7F124B89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000000EB95C: BF870153
	v_exp_f32_e32 v152, v153                                   // 0000000EB960: 7F304B99
	.long 0xd59c0899                                           // 0000000EB964: D59C0899
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 0000000EB968: 02010188
	.long 0xd59c4899                                           // 0000000EB96C: D59C4899
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 0000000EB970: 02010186
	v_fma_f32 v186, 0x3fb8aa3b, v130, -v184                    // 0000000EB974: D61300BA 86E304FF 3FB8AA3B
	v_rndne_f32_e32 v187, v184                                 // 0000000EB980: 7F7647B8
	v_dual_fmac_f32 v186, 0x32a5705f, v130 :: v_dual_and_b32 v153, 1, v153// 0000000EB984: C82504FF BA993281 32A5705F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EB990: BF870296
	.long 0xd71c0089                                           // 0000000EB994: D71C0089
	v_cndmask_b32_e32 v1, v137, v178, vcc_lo                   // 0000000EB998: 02036589
	.long 0xd71c0098                                           // 0000000EB99C: D71C0098
	v_cndmask_b32_e32 v1, v152, v181, vcc_lo                   // 0000000EB9A0: 02036B98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EB9A4: BF870193
	v_add3_u32 v136, v136, v153, 0x7fff                        // 0000000EB9A8: D6550088 03FF3388 00007FFF
	v_cndmask_b32_e32 v137, 0, v137, vcc_lo                    // 0000000EB9B4: 03131280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v177                 // 0000000EB9B8: 7C3762FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EB9C0: BF870004
	v_dual_add_f32 v151, v151, v135 :: v_dual_cndmask_b32 v152, 0, v152// 0000000EB9C4: C9130F97 97993080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 0000000EB9CC: 7C3D2CFF 42B17218
	v_add3_u32 v150, v135, v182, 0x7fff                        // 0000000EB9D4: D6550096 03FF6D87 00007FFF
	v_mul_f32_e32 v182, 0x3fb8aa3b, v179                       // 0000000EB9E0: 116D66FF 3FB8AA3B
	.long 0xd59c0896                                           // 0000000EB9E8: D59C0896
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 0000000EB9EC: 02010188
	v_cndmask_b32_e32 v137, 0x7f800000, v137, vcc_lo           // 0000000EB9F0: 031312FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v177                 // 0000000EB9F8: 7C3D62FF 42B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EBA00: BF8700A4
	v_rndne_f32_e32 v183, v182                                 // 0000000EBA04: 7F6E47B6
	v_cndmask_b32_e32 v152, 0x7f800000, v152, vcc_lo           // 0000000EBA08: 033130FF 7F800000
	.long 0xd59c0886                                           // 0000000EBA10: D59C0886
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 0000000EBA14: 02010198
	v_sub_f32_e32 v178, v180, v133                             // 0000000EBA18: 09650BB4
	.long 0xd59c08b4                                           // 0000000EBA1C: D59C08B4
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 0000000EBA20: 02010189
	.long 0xd59c48b4                                           // 0000000EBA24: D59C48B4
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 0000000EBA28: 02010186
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EBA2C: BF870214
	v_and_b32_e32 v181, 1, v134                                // 0000000EBA30: 376B0C81
	v_mul_f32_e32 v177, 0x3fb8aa3b, v178                       // 0000000EBA34: 116364FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 0000000EBA3C: 7C3764FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EBA44: BF870194
	v_dual_add_f32 v135, v151, v137 :: v_dual_and_b32 v180, 1, v180// 0000000EBA48: C9251397 87B56881
	v_fma_f32 v151, 0x3fb8aa3b, v178, -v177                    // 0000000EBA50: D6130097 86C764FF 3FB8AA3B
	v_rndne_f32_e32 v153, v177                                 // 0000000EBA5C: 7F3247B1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EBA60: BF870193
	v_add3_u32 v137, v137, v180, 0x7fff                        // 0000000EBA64: D6550089 03FF6989 00007FFF
	v_fmac_f32_e32 v151, 0x32a5705f, v178                      // 0000000EBA70: 572F64FF 32A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EBA78: BF870123
	v_sub_f32_e32 v177, v177, v153                             // 0000000EBA7C: 096333B1
	v_cvt_i32_f32_e32 v153, v153                               // 0000000EBA80: 7F321199
	v_add_f32_e32 v151, v177, v151                             // 0000000EBA84: 072F2FB1
	v_fma_f32 v177, 0x3fb8aa3b, v179, -v182                    // 0000000EBA88: D61300B1 86DB66FF 3FB8AA3B
	v_sub_f32_e32 v182, v182, v183                             // 0000000EBA94: 096D6FB6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EBA98: BF870113
	v_exp_f32_e32 v151, v151                                   // 0000000EBA9C: 7F2E4B97
	v_fmac_f32_e32 v177, 0x32a5705f, v179                      // 0000000EBAA0: 576366FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000000EBAA8: BF8702A1
	v_dual_add_f32 v177, v182, v177 :: v_dual_sub_f32 v182, v184, v187// 0000000EBAAC: C90B63B6 B1B777B8
	v_sub_f32_e32 v131, v131, v133                             // 0000000EBAB4: 09070B83
	.long 0xd71c0097                                           // 0000000EBAB8: D71C0097
	v_cndmask_b32_e32 v1, v151, v153, vcc_lo                   // 0000000EBABC: 02033397
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EBAC0: BF870112
	v_dual_add_f32 v180, v182, v186 :: v_dual_mul_f32 v185, 0x3fb8aa3b, v131// 0000000EBAC4: C90775B6 B4B906FF 3FB8AA3B
	v_cndmask_b32_e32 v151, 0, v151, vcc_lo                    // 0000000EBAD0: 032F2E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 0000000EBAD4: 7C3D64FF 42B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EBADC: BF870193
	v_exp_f32_e32 v153, v180                                   // 0000000EBAE0: 7F324BB4
	v_fma_f32 v188, 0x3fb8aa3b, v131, -v185                    // 0000000EBAE4: D61300BC 86E706FF 3FB8AA3B
	v_rndne_f32_e32 v189, v185                                 // 0000000EBAF0: 7F7A47B9
	v_cvt_i32_f32_e32 v180, v183                               // 0000000EBAF4: 7F6811B7
	v_dual_add_f32 v135, v135, v152 :: v_dual_cndmask_b32 v178, 0x7f800000, v151// 0000000EBAF8: C9133187 87B32EFF 7F800000
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EBB04: BF870004
	v_fmac_f32_e32 v188, 0x32a5705f, v131                      // 0000000EBB08: 577906FF 32A5705F
	v_exp_f32_e32 v177, v177                                   // 0000000EBB10: 7F624BB1
	v_sub_f32_e32 v184, v185, v189                             // 0000000EBB14: 09717BB9
	v_cvt_i32_f32_e32 v183, v187                               // 0000000EBB18: 7F6E11BB
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v179                 // 0000000EBB1C: 7C3766FF C2CE8ED0
	.long 0xd59c0886                                           // 0000000EBB24: D59C0886
	v_cndmask_b32_e32 v0, v178, v128, vcc_lo                   // 0000000EBB28: 020101B2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EBB2C: BF870214
	v_add_f32_e32 v182, v184, v188                             // 0000000EBB30: 076D79B8
	.long 0xd71c0097                                           // 0000000EBB34: D71C0097
	v_cndmask_b32_e32 v1, v153, v183, vcc_lo                   // 0000000EBB38: 02036F99
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EBB3C: BF870195
	.long 0xd71c00b1                                           // 0000000EBB40: D71C00B1
	v_cndmask_b32_e32 v1, v177, v180, vcc_lo                   // 0000000EBB44: 020369B1
	v_exp_f32_e32 v182, v182                                   // 0000000EBB48: 7F6C4BB6
	v_cvt_i32_f32_e32 v180, v189                               // 0000000EBB4C: 7F6811BD
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 0000000EBB50: BF8702C2
	v_cndmask_b32_e32 v153, 0, v177, vcc_lo                    // 0000000EBB54: 03336280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 0000000EBB58: 7C3704FF C2CE8ED0
	v_cndmask_b32_e32 v151, 0, v151, vcc_lo                    // 0000000EBB60: 032F2E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v179                 // 0000000EBB64: 7C3D66FF 42B17218
	.long 0xd71c00b1                                           // 0000000EBB6C: D71C00B1
	v_cndmask_b32_e32 v1, v182, v180, vcc_lo                   // 0000000EBB70: 020369B6
	v_and_b32_e32 v179, 1, v134                                // 0000000EBB74: 37670C81
	v_cndmask_b32_e32 v153, 0x7f800000, v153, vcc_lo           // 0000000EBB78: 033332FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 0000000EBB80: 7C3706FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EBB88: BF870004
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 0000000EBB8C: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 0000000EBB90: 7C3D04FF 42B17218
	v_cndmask_b32_e32 v130, 0x7f800000, v151, vcc_lo           // 0000000EBB98: 03052EFF 7F800000
	.long 0xd59c0897                                           // 0000000EBBA0: D59C0897
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                   // 0000000EBBA4: 02010199
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 0000000EBBA8: 7C3D06FF 42B17218
	.long 0xd59c4897                                           // 0000000EBBB0: D59C4897
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 0000000EBBB4: 02010186
	v_cndmask_b32_e32 v131, 0x7f800000, v177, vcc_lo           // 0000000EBBB8: 030762FF 7F800000
	.long 0xd59c08b1                                           // 0000000EBBC0: D59C08B1
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                   // 0000000EBBC4: 02010182
	.long 0xd59c48b1                                           // 0000000EBBC8: D59C48B1
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 0000000EBBCC: 02010186
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EBBD0: BF870214
	v_dual_add_f32 v135, v135, v153 :: v_dual_and_b32 v180, 1, v151// 0000000EBBD4: C9253387 87B52E81
	.long 0xd59c0886                                           // 0000000EBBDC: D59C0886
	v_cndmask_b32_e32 v0, v131, v128, vcc_lo                   // 0000000EBBE0: 02010183
	v_add3_u32 v151, v152, v181, 0x7fff                        // 0000000EBBE4: D6550097 03FF6B98 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EBBF0: BF870214
	v_and_b32_e32 v177, 1, v177                                // 0000000EBBF4: 37636281
	v_add3_u32 v180, v153, v180, 0x7fff                        // 0000000EBBF8: D65500B4 03FF6999 00007FFF
	v_add_f32_e32 v135, v135, v178                             // 0000000EBC04: 070F6587
	v_and_b32_e32 v134, 1, v134                                // 0000000EBC08: 370D0C81
	v_add3_u32 v152, v178, v179, 0x7fff                        // 0000000EBC0C: D6550098 03FF67B2 00007FFF
	v_add3_u32 v177, v130, v177, 0x7fff                        // 0000000EBC18: D65500B1 03FF6382 00007FFF
	.long 0xd59c0898                                           // 0000000EBC24: D59C0898
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                   // 0000000EBC28: 020101B4
	v_add_f32_e32 v130, v135, v130                             // 0000000EBC2C: 07050587
	v_add3_u32 v153, v131, v134, 0x7fff                        // 0000000EBC30: D6550099 03FF0D83 00007FFF
	.long 0xd59c0897                                           // 0000000EBC3C: D59C0897
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 0000000EBC40: 02010189
	.long 0xd59c0899                                           // 0000000EBC44: D59C0899
	v_cndmask_b32_e32 v0, v177, v128, vcc_lo                   // 0000000EBC48: 020101B1
	ds_store_b128 v165, v[146:149]                             // 0000000EBC4C: DB7C0000 000092A5
	ds_store_b128 v165, v[150:153] offset:16                   // 0000000EBC54: DB7C0010 000096A5
	v_add_f32_e32 v130, v130, v131                             // 0000000EBC5C: 07050782
	v_mov_b32_e32 v131, 0                                      // 0000000EBC60: 7F060280
	s_mov_b32 s1, exec_lo                                      // 0000000EBC64: BE81007E
	s_waitcnt lgkmcnt(0)                                       // 0000000EBC68: BF89FC07
	v_cmpx_lt_f32_e32 0xefa18f08, v132                         // 0000000EBC6C: 7D2308FF EFA18F08
	s_cbranch_execz 27                                         // 0000000EBC74: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2de4>
	v_sub_f32_e32 v131, v132, v133                             // 0000000EBC78: 09070B84
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EBC7C: BF870121
	v_mul_f32_e32 v132, 0x3fb8aa3b, v131                       // 0000000EBC80: 110906FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 0000000EBC88: 7C3706FF C2CE8ED0
	v_fma_f32 v134, 0x3fb8aa3b, v131, -v132                    // 0000000EBC90: D6130086 861306FF 3FB8AA3B
	v_rndne_f32_e32 v135, v132                                 // 0000000EBC9C: 7F0E4784
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EBCA0: BF870112
	v_fmac_f32_e32 v134, 0x32a5705f, v131                      // 0000000EBCA4: 570D06FF 32A5705F
	v_sub_f32_e32 v132, v132, v135                             // 0000000EBCAC: 09090F84
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EBCB0: BF870121
	v_add_f32_e32 v132, v132, v134                             // 0000000EBCB4: 07090D84
	v_cvt_i32_f32_e32 v134, v135                               // 0000000EBCB8: 7F0C1187
	v_exp_f32_e32 v132, v132                                   // 0000000EBCBC: 7F084B84
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EBCC0: BF870095
	.long 0xd71c0084                                           // 0000000EBCC4: D71C0084
	v_cndmask_b32_e32 v1, v132, v134, vcc_lo                   // 0000000EBCC8: 02030D84
	v_cndmask_b32_e32 v132, 0, v132, vcc_lo                    // 0000000EBCCC: 03090880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 0000000EBCD0: 7C3D06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EBCD8: BF870002
	v_cndmask_b32_e32 v131, 0x7f800000, v132, vcc_lo           // 0000000EBCDC: 030708FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EBCE4: 8C7E017E
	ds_load_b32 v132, v0                                       // 0000000EBCE8: D8D80000 84000000
	s_waitcnt lgkmcnt(0)                                       // 0000000EBCF0: BF89FC07
	v_fmac_f32_e32 v130, v131, v132                            // 0000000EBCF4: 57050983
	ds_store_b32 v163, v133                                    // 0000000EBCF8: D8340000 000085A3
	ds_store_b32 v0, v130                                      // 0000000EBD00: D8340000 00008200
	ds_store_b32 v166, v131                                    // 0000000EBD08: D8340000 000083A6
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EBD10: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000EBD14: BF89FC07
	s_barrier                                                  // 0000000EBD18: BFBD0000
	buffer_gl0_inv                                             // 0000000EBD1C: E0AC0000 00000000
	ds_load_2addr_b32 v[152:153], v167 offset1:2               // 0000000EBD24: D8DC0200 980000A7
	ds_load_2addr_b32 v[150:151], v167 offset0:4 offset1:6     // 0000000EBD2C: D8DC0604 960000A7
	ds_load_2addr_b32 v[148:149], v167 offset0:8 offset1:10    // 0000000EBD34: D8DC0A08 940000A7
	ds_load_2addr_b32 v[146:147], v167 offset0:12 offset1:14   // 0000000EBD3C: D8DC0E0C 920000A7
	s_waitcnt lgkmcnt(3)                                       // 0000000EBD44: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v152                         // 0000000EBD48: 7C2530F2
	.long 0xd4120001                                           // 0000000EBD4C: D4120001
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 0000000EBD50: 020332F2
	s_waitcnt lgkmcnt(2)                                       // 0000000EBD54: BF89FC27
	.long 0xd4120002                                           // 0000000EBD58: D4120002
	v_cndmask_b32_e32 v1, 1.0, v150, vcc_lo                    // 0000000EBD5C: 02032CF2
	.long 0xd4120004                                           // 0000000EBD60: D4120004
	v_cndmask_b32_e32 v1, 1.0, v151, vcc_lo                    // 0000000EBD64: 02032EF2
	s_and_b32 s1, vcc_lo, s1                                   // 0000000EBD68: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 0000000EBD6C: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v148                         // 0000000EBD70: 7C2528F2
	s_and_b32 s2, s1, s2                                       // 0000000EBD74: 8B020201
	.long 0xd4120001                                           // 0000000EBD78: D4120001
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 0000000EBD7C: 02032AF2
	s_and_b32 s4, s2, s4                                       // 0000000EBD80: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 0000000EBD84: BF89FC07
	.long 0xd4120002                                           // 0000000EBD88: D4120002
	v_cndmask_b32_e32 v1, 1.0, v146, vcc_lo                    // 0000000EBD8C: 020324F2
	s_and_b32 s4, s4, vcc_lo                                   // 0000000EBD90: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v147                         // 0000000EBD94: 7C2526F2
	s_and_b32 s1, s4, s1                                       // 0000000EBD98: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000EBD9C: BF870499
	s_and_b32 s1, s1, s2                                       // 0000000EBDA0: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 0000000EBDA4: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EBDA8: BF870099
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 0000000EBDAC: D5010082 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v130                           // 0000000EBDB4: 7C9B0480
	ds_load_b128 v[130:133], v168                              // 0000000EBDB8: DBFC0000 820000A8
	ds_load_b128 v[134:137], v168 offset:16                    // 0000000EBDC0: DBFC0010 860000A8
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 0000000EBDC8: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 0000000EBDCC: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EBDD0: BF870099
	v_cndmask_b32_e64 v177, 0, 1, s1                           // 0000000EBDD4: D50100B1 00050280
	v_readfirstlane_b32 s1, v177                               // 0000000EBDDC: 7E0205B1
	s_bitcmp1_b32 s1, 0                                        // 0000000EBDE0: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 0000000EBDE4: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EBDE8: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 0000000EBDEC: 8B6A017E
	s_cbranch_vccnz 63008                                      // 0000000EBDF0: BFA4F620 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x774>
	v_dual_mul_f32 v121, v152, v121 :: v_dual_mul_f32 v122, v153, v122// 0000000EBDF4: C8C6F398 797AF599
	v_dual_mul_f32 v123, v150, v123 :: v_dual_mul_f32 v124, v151, v124// 0000000EBDFC: C8C6F796 7B7CF997
	v_dual_mul_f32 v125, v148, v125 :: v_dual_mul_f32 v126, v149, v126// 0000000EBE04: C8C6FB94 7D7EFD95
	v_dual_mul_f32 v127, v146, v127 :: v_dual_mul_f32 v128, v147, v128// 0000000EBE0C: C8C6FF92 7F810193
	v_dual_mul_f32 v113, v152, v113 :: v_dual_mul_f32 v114, v153, v114// 0000000EBE14: C8C6E398 7172E599
	v_dual_mul_f32 v115, v150, v115 :: v_dual_mul_f32 v116, v151, v116// 0000000EBE1C: C8C6E796 7374E997
	v_dual_mul_f32 v117, v148, v117 :: v_dual_mul_f32 v118, v149, v118// 0000000EBE24: C8C6EB94 7576ED95
	v_dual_mul_f32 v119, v146, v119 :: v_dual_mul_f32 v120, v147, v120// 0000000EBE2C: C8C6EF92 7778F193
	v_dual_mul_f32 v105, v152, v105 :: v_dual_mul_f32 v106, v153, v106// 0000000EBE34: C8C6D398 696AD599
	v_dual_mul_f32 v107, v150, v107 :: v_dual_mul_f32 v108, v151, v108// 0000000EBE3C: C8C6D796 6B6CD997
	v_dual_mul_f32 v109, v148, v109 :: v_dual_mul_f32 v110, v149, v110// 0000000EBE44: C8C6DB94 6D6EDD95
	v_dual_mul_f32 v111, v146, v111 :: v_dual_mul_f32 v112, v147, v112// 0000000EBE4C: C8C6DF92 6F70E193
	v_dual_mul_f32 v97, v152, v97 :: v_dual_mul_f32 v98, v153, v98// 0000000EBE54: C8C6C398 6162C599
	v_dual_mul_f32 v99, v150, v99 :: v_dual_mul_f32 v100, v151, v100// 0000000EBE5C: C8C6C796 6364C997
	v_dual_mul_f32 v101, v148, v101 :: v_dual_mul_f32 v102, v149, v102// 0000000EBE64: C8C6CB94 6566CD95
	v_dual_mul_f32 v103, v146, v103 :: v_dual_mul_f32 v104, v147, v104// 0000000EBE6C: C8C6CF92 6768D193
	v_dual_mul_f32 v89, v152, v89 :: v_dual_mul_f32 v90, v153, v90// 0000000EBE74: C8C6B398 595AB599
	v_dual_mul_f32 v91, v150, v91 :: v_dual_mul_f32 v92, v151, v92// 0000000EBE7C: C8C6B796 5B5CB997
	v_dual_mul_f32 v93, v148, v93 :: v_dual_mul_f32 v94, v149, v94// 0000000EBE84: C8C6BB94 5D5EBD95
	v_dual_mul_f32 v95, v146, v95 :: v_dual_mul_f32 v96, v147, v96// 0000000EBE8C: C8C6BF92 5F60C193
	v_dual_mul_f32 v81, v152, v81 :: v_dual_mul_f32 v82, v153, v82// 0000000EBE94: C8C6A398 5152A599
	v_dual_mul_f32 v83, v150, v83 :: v_dual_mul_f32 v84, v151, v84// 0000000EBE9C: C8C6A796 5354A997
	v_dual_mul_f32 v85, v148, v85 :: v_dual_mul_f32 v86, v149, v86// 0000000EBEA4: C8C6AB94 5556AD95
	v_dual_mul_f32 v87, v146, v87 :: v_dual_mul_f32 v88, v147, v88// 0000000EBEAC: C8C6AF92 5758B193
	v_dual_mul_f32 v73, v152, v73 :: v_dual_mul_f32 v74, v153, v74// 0000000EBEB4: C8C69398 494A9599
	v_dual_mul_f32 v75, v150, v75 :: v_dual_mul_f32 v76, v151, v76// 0000000EBEBC: C8C69796 4B4C9997
	v_dual_mul_f32 v77, v148, v77 :: v_dual_mul_f32 v78, v149, v78// 0000000EBEC4: C8C69B94 4D4E9D95
	v_dual_mul_f32 v79, v146, v79 :: v_dual_mul_f32 v80, v147, v80// 0000000EBECC: C8C69F92 4F50A193
	v_dual_mul_f32 v65, v152, v65 :: v_dual_mul_f32 v66, v153, v66// 0000000EBED4: C8C68398 41428599
	v_dual_mul_f32 v67, v150, v67 :: v_dual_mul_f32 v68, v151, v68// 0000000EBEDC: C8C68796 43448997
	v_dual_mul_f32 v69, v148, v69 :: v_dual_mul_f32 v70, v149, v70// 0000000EBEE4: C8C68B94 45468D95
	v_dual_mul_f32 v71, v146, v71 :: v_dual_mul_f32 v72, v147, v72// 0000000EBEEC: C8C68F92 47489193
	v_dual_mul_f32 v57, v152, v57 :: v_dual_mul_f32 v58, v153, v58// 0000000EBEF4: C8C67398 393A7599
	v_dual_mul_f32 v59, v150, v59 :: v_dual_mul_f32 v60, v151, v60// 0000000EBEFC: C8C67796 3B3C7997
	v_dual_mul_f32 v61, v148, v61 :: v_dual_mul_f32 v62, v149, v62// 0000000EBF04: C8C67B94 3D3E7D95
	v_dual_mul_f32 v63, v146, v63 :: v_dual_mul_f32 v64, v147, v64// 0000000EBF0C: C8C67F92 3F408193
	v_dual_mul_f32 v49, v152, v49 :: v_dual_mul_f32 v50, v153, v50// 0000000EBF14: C8C66398 31326599
	v_dual_mul_f32 v51, v150, v51 :: v_dual_mul_f32 v52, v151, v52// 0000000EBF1C: C8C66796 33346997
	v_dual_mul_f32 v53, v148, v53 :: v_dual_mul_f32 v54, v149, v54// 0000000EBF24: C8C66B94 35366D95
	v_dual_mul_f32 v55, v146, v55 :: v_dual_mul_f32 v56, v147, v56// 0000000EBF2C: C8C66F92 37387193
	v_dual_mul_f32 v41, v152, v41 :: v_dual_mul_f32 v42, v153, v42// 0000000EBF34: C8C65398 292A5599
	v_dual_mul_f32 v43, v150, v43 :: v_dual_mul_f32 v44, v151, v44// 0000000EBF3C: C8C65796 2B2C5997
	v_dual_mul_f32 v45, v148, v45 :: v_dual_mul_f32 v46, v149, v46// 0000000EBF44: C8C65B94 2D2E5D95
	v_dual_mul_f32 v47, v146, v47 :: v_dual_mul_f32 v48, v147, v48// 0000000EBF4C: C8C65F92 2F306193
	v_dual_mul_f32 v33, v152, v33 :: v_dual_mul_f32 v34, v153, v34// 0000000EBF54: C8C64398 21224599
	v_dual_mul_f32 v35, v150, v35 :: v_dual_mul_f32 v36, v151, v36// 0000000EBF5C: C8C64796 23244997
	v_dual_mul_f32 v37, v148, v37 :: v_dual_mul_f32 v38, v149, v38// 0000000EBF64: C8C64B94 25264D95
	v_dual_mul_f32 v39, v146, v39 :: v_dual_mul_f32 v40, v147, v40// 0000000EBF6C: C8C64F92 27285193
	v_dual_mul_f32 v25, v152, v25 :: v_dual_mul_f32 v26, v153, v26// 0000000EBF74: C8C63398 191A3599
	v_dual_mul_f32 v27, v150, v27 :: v_dual_mul_f32 v28, v151, v28// 0000000EBF7C: C8C63796 1B1C3997
	v_dual_mul_f32 v29, v148, v29 :: v_dual_mul_f32 v30, v149, v30// 0000000EBF84: C8C63B94 1D1E3D95
	v_dual_mul_f32 v31, v146, v31 :: v_dual_mul_f32 v32, v147, v32// 0000000EBF8C: C8C63F92 1F204193
	v_dual_mul_f32 v17, v152, v17 :: v_dual_mul_f32 v18, v153, v18// 0000000EBF94: C8C62398 11122599
	v_dual_mul_f32 v19, v150, v19 :: v_dual_mul_f32 v20, v151, v20// 0000000EBF9C: C8C62796 13142997
	v_dual_mul_f32 v21, v148, v21 :: v_dual_mul_f32 v22, v149, v22// 0000000EBFA4: C8C62B94 15162D95
	v_dual_mul_f32 v23, v146, v23 :: v_dual_mul_f32 v24, v147, v24// 0000000EBFAC: C8C62F92 17183193
	v_dual_mul_f32 v9, v152, v9 :: v_dual_mul_f32 v10, v153, v10// 0000000EBFB4: C8C61398 090A1599
	v_dual_mul_f32 v11, v150, v11 :: v_dual_mul_f32 v12, v151, v12// 0000000EBFBC: C8C61796 0B0C1997
	v_dual_mul_f32 v13, v148, v13 :: v_dual_mul_f32 v14, v149, v14// 0000000EBFC4: C8C61B94 0D0E1D95
	v_dual_mul_f32 v15, v146, v15 :: v_dual_mul_f32 v16, v147, v16// 0000000EBFCC: C8C61F92 0F102193
	v_dual_mul_f32 v1, v152, v1 :: v_dual_mul_f32 v2, v153, v2 // 0000000EBFD4: C8C60398 01020599
	v_dual_mul_f32 v3, v150, v3 :: v_dual_mul_f32 v4, v151, v4 // 0000000EBFDC: C8C60796 03040997
	v_dual_mul_f32 v5, v148, v5 :: v_dual_mul_f32 v6, v149, v6 // 0000000EBFE4: C8C60B94 05060D95
	v_dual_mul_f32 v7, v146, v7 :: v_dual_mul_f32 v8, v147, v8 // 0000000EBFEC: C8C60F92 07081193
	s_branch 62879                                             // 0000000EBFF4: BFA0F59F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x774>
	v_lshlrev_b32_e32 v0, 2, v157                              // 0000000EBFF8: 30013A82
	.long 0xd700008b                                           // 0000000EBFFC: D700008B
	v_cndmask_b32_e32 v1, s18, v139, vcc_lo                    // 0000000EC000: 02031612
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EC004: BF870191
	v_add_co_ci_u32_e64 v140, null, s19, v140, s0              // 0000000EC008: D5207C8C 00031813
	v_lshl_or_b32 v0, v155, 6, v0                              // 0000000EC010: D6560000 04010D9B
	v_lshlrev_b32_e32 v147, 1, v154                            // 0000000EC018: 31273481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000000EC01C: BF870152
	v_add_nc_u32_e32 v133, 0xf000, v0                          // 0000000EC020: 4B0A00FF 0000F000
	ds_load_2addr_b32 v[141:142], v133 offset0:192 offset1:194 // 0000000EC028: D8DCC2C0 8D000085
	s_waitcnt lgkmcnt(0)                                       // 0000000EC030: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 0000000EC034: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 0000000EC03C: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 0000000EC044: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000000EC048: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 0000000EC04C: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 0000000EC054: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:196 offset1:198 // 0000000EC058: D8DCC6C4 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:200 offset1:202 // 0000000EC060: D8DCCAC8 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:204 offset1:206 // 0000000EC068: D8DCCECC 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 0000000EC070: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000EC074: 3505029F
	v_or_b32_e32 v0, v156, v157                                // 0000000EC078: 38013B9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EC07C: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 0000000EC080: 11252191
	.long 0xd73c0083                                           // 0000000EC084: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000000EC088: 02030281
	.long 0xd7000081                                           // 0000000EC08C: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 0000000EC090: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EC094: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 0000000EC098: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 0000000EC0A0: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC0A8: BF870094
	.long 0xd7000083                                           // 0000000EC0AC: D7000083
	v_cndmask_b32_e32 v1, s16, v131, vcc_lo                    // 0000000EC0B0: 02030610
	v_add_co_ci_u32_e64 v132, null, s17, v132, s0              // 0000000EC0B4: D5207C84 00030811
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EC0BC: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 0000000EC0C0: 57252194
	.long 0xd4440000                                           // 0000000EC0C4: D4440000
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 0000000EC0C8: 0202000E
	v_fma_f32 v139, -v143, v146, v145                          // 0000000EC0CC: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EC0D4: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 0000000EC0D8: D637008B 064B218B
	.long 0xd7006a83                                           // 0000000EC0E0: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 0000000EC0E4: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 0000000EC0E8: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000EC0F0: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 0000000EC0F4: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 0000000EC0FC: BE812000
	s_cbranch_execz 70                                         // 0000000EC100: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x331c>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EC104: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 0000000EC108: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 0000000EC114: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 0000000EC118: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 0000000EC120: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 0000000EC124: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC128: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 0000000EC12C: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 0000000EC134: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 0000000EC140: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EC144: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 0000000EC148: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 0000000EC150: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000EC154: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 0000000EC158: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 0000000EC15C: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 0000000EC160: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 0000000EC168: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC16C: BF870095
	.long 0xd71c008d                                           // 0000000EC170: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 0000000EC174: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000EC178: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 0000000EC17C: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC184: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 0000000EC188: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 0000000EC190: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC194: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 0000000EC198: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 0000000EC1A0: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC1A4: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 0000000EC1A8: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 0000000EC1B0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 0000000EC1B4: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC1BC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000EC1C0: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 0000000EC1C4: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC1CC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000EC1D0: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 0000000EC1D4: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC1DC: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 0000000EC1E0: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 0000000EC1E8: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 0000000EC1F0: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC1FC: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 0000000EC200: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 0000000EC208: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 0000000EC214: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000EC21C: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 0000000EC220: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 0000000EC228: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EC230: BF870292
	v_rcp_f32_e32 v140, v121                                   // 0000000EC234: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 0000000EC238: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC240: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 0000000EC244: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 0000000EC248: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC24C: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 0000000EC250: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 0000000EC258: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC25C: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 0000000EC260: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 0000000EC268: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 0000000EC270: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EC274: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 0000000EC278: D627008C 03CB1D8C
	.long 0xd4440001                                           // 0000000EC280: D4440001
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 0000000EC284: 0202F20E
	s_and_saveexec_b32 s2, s1                                  // 0000000EC288: BE822001
	s_cbranch_execz 69                                         // 0000000EC28C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34a4>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000000EC290: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 0000000EC29C: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 0000000EC2A0: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000EC2A8: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000EC2AC: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC2B0: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000EC2B4: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000EC2BC: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000EC2C8: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EC2CC: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000EC2D0: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000EC2D4: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000EC2DC: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EC2E4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000EC2E8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000EC2EC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000EC2F0: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC2F4: BF870095
	.long 0xd71c008e                                           // 0000000EC2F8: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000EC2FC: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000EC300: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000EC304: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC30C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000EC310: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000EC318: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC31C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 0000000EC320: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000EC328: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC32C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000EC330: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000EC338: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 0000000EC33C: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC344: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000EC348: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000EC34C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC354: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000EC358: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000EC35C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC364: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000EC368: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 0000000EC370: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 0000000EC378: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC384: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 0000000EC388: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 0000000EC390: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 0000000EC39C: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000EC3A4: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 0000000EC3A8: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 0000000EC3AC: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 0000000EC3B4: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EC3BC: BF870292
	v_rcp_f32_e32 v141, v122                                   // 0000000EC3C0: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 0000000EC3C4: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC3CC: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000EC3D0: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000EC3D4: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC3D8: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 0000000EC3DC: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 0000000EC3E4: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC3E8: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 0000000EC3EC: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 0000000EC3F4: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 0000000EC3FC: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EC400: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 0000000EC404: D6270089 03CB138D
	.long 0xd4440002                                           // 0000000EC40C: D4440002
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 0000000EC410: 0202F40E
	s_and_saveexec_b32 s3, s2                                  // 0000000EC414: BE832002
	s_cbranch_execz 69                                         // 0000000EC418: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3630>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 0000000EC41C: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 0000000EC428: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 0000000EC42C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000EC434: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000EC438: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC43C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000EC440: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000EC448: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000EC454: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EC458: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000EC45C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000EC460: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000EC468: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EC470: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000EC474: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000EC478: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000EC47C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC480: BF870095
	.long 0xd71c008e                                           // 0000000EC484: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000EC488: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000EC48C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000EC490: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC498: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000EC49C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000EC4A4: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC4A8: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 0000000EC4AC: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000EC4B4: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC4B8: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000EC4BC: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000EC4C4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 0000000EC4C8: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC4D0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000EC4D4: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000EC4D8: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC4E0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000EC4E4: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000EC4E8: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC4F0: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000EC4F4: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 0000000EC4FC: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 0000000EC504: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC510: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 0000000EC514: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 0000000EC51C: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 0000000EC528: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000EC530: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 0000000EC534: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 0000000EC53C: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EC544: BF870292
	v_rcp_f32_e32 v141, v123                                   // 0000000EC548: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 0000000EC54C: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC554: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000EC558: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000EC55C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC560: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 0000000EC564: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 0000000EC56C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC570: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 0000000EC574: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 0000000EC57C: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 0000000EC584: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EC588: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 0000000EC58C: D627008A 03CB158D
	.long 0xd4440003                                           // 0000000EC594: D4440003
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 0000000EC598: 0202F60E
	s_and_saveexec_b32 s4, s3                                  // 0000000EC59C: BE842003
	s_cbranch_execz 69                                         // 0000000EC5A0: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37b8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 0000000EC5A4: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 0000000EC5B0: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 0000000EC5B4: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000EC5BC: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000EC5C0: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC5C4: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000EC5C8: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000EC5D0: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000EC5DC: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EC5E0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000EC5E4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000EC5E8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000EC5F0: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EC5F8: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000EC5FC: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000EC600: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000EC604: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC608: BF870095
	.long 0xd71c008e                                           // 0000000EC60C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000EC610: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000EC614: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000EC618: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC620: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000EC624: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000EC62C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC630: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 0000000EC634: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000EC63C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC640: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000EC644: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000EC64C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 0000000EC650: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC658: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000EC65C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000EC660: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC668: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000EC66C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000EC670: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC678: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000EC67C: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 0000000EC684: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 0000000EC68C: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC698: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 0000000EC69C: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 0000000EC6A4: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 0000000EC6B0: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EC6B8: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 0000000EC6BC: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 0000000EC6C0: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 0000000EC6C8: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EC6D0: BF870292
	v_rcp_f32_e32 v141, v124                                   // 0000000EC6D4: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 0000000EC6D8: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC6E0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000EC6E4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000EC6E8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC6EC: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 0000000EC6F0: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 0000000EC6F8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC6FC: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 0000000EC700: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 0000000EC708: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 0000000EC710: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EC714: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 0000000EC718: D6270087 03CB0F8D
	.long 0xd4440004                                           // 0000000EC720: D4440004
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 0000000EC724: 0202F80E
	s_and_saveexec_b32 s5, s4                                  // 0000000EC728: BE852004
	s_cbranch_execz 69                                         // 0000000EC72C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3944>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 0000000EC730: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 0000000EC73C: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 0000000EC740: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000EC748: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000EC74C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC750: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000EC754: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000EC75C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000EC768: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EC76C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000EC770: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000EC774: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000EC77C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EC784: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000EC788: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000EC78C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000EC790: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC794: BF870095
	.long 0xd71c008e                                           // 0000000EC798: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000EC79C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000EC7A0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000EC7A4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC7AC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000EC7B0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000EC7B8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC7BC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 0000000EC7C0: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000EC7C8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC7CC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000EC7D0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000EC7D8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 0000000EC7DC: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC7E4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000EC7E8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000EC7EC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC7F4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000EC7F8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000EC7FC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC804: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000EC808: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 0000000EC810: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 0000000EC818: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC824: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 0000000EC828: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 0000000EC830: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 0000000EC83C: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000EC844: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 0000000EC848: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 0000000EC850: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EC858: BF870292
	v_rcp_f32_e32 v141, v125                                   // 0000000EC85C: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 0000000EC860: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC868: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000EC86C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000EC870: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC874: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 0000000EC878: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 0000000EC880: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC884: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 0000000EC888: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 0000000EC890: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 0000000EC898: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EC89C: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 0000000EC8A0: D6270088 03CB118D
	.long 0xd4440005                                           // 0000000EC8A8: D4440005
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 0000000EC8AC: 0202FA0E
	s_and_saveexec_b32 s6, s5                                  // 0000000EC8B0: BE862005
	s_cbranch_execz 69                                         // 0000000EC8B4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3acc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 0000000EC8B8: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 0000000EC8C4: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 0000000EC8C8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000EC8D0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000EC8D4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC8D8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000EC8DC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000EC8E4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000EC8F0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EC8F4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000EC8F8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000EC8FC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000EC904: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EC90C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000EC910: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000EC914: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000EC918: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC91C: BF870095
	.long 0xd71c008e                                           // 0000000EC920: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000EC924: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000EC928: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000EC92C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC934: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000EC938: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000EC940: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC944: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 0000000EC948: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000EC950: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC954: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000EC958: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000EC960: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 0000000EC964: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC96C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000EC970: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000EC974: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC97C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000EC980: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000EC984: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC98C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000EC990: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 0000000EC998: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 0000000EC9A0: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC9AC: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 0000000EC9B0: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 0000000EC9B8: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 0000000EC9C4: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000EC9CC: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000EC9D0: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 0000000EC9D4: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 0000000EC9DC: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EC9E4: BF870292
	v_rcp_f32_e32 v141, v126                                   // 0000000EC9E8: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 0000000EC9EC: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC9F4: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000EC9F8: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000EC9FC: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECA00: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 0000000ECA04: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 0000000ECA0C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECA10: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 0000000ECA14: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 0000000ECA1C: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 0000000ECA24: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ECA28: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 0000000ECA2C: D6270085 03CB0B8D
	.long 0xd4440006                                           // 0000000ECA34: D4440006
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 0000000ECA38: 0202FC0E
	s_and_saveexec_b32 s7, s6                                  // 0000000ECA3C: BE872006
	s_cbranch_execz 69                                         // 0000000ECA40: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c58>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 0000000ECA44: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 0000000ECA50: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 0000000ECA54: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000ECA5C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000ECA60: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECA64: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000ECA68: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000ECA70: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000ECA7C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ECA80: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000ECA84: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000ECA88: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000ECA90: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ECA98: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000ECA9C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000ECAA0: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000ECAA4: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECAA8: BF870095
	.long 0xd71c008e                                           // 0000000ECAAC: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000ECAB0: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000ECAB4: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000ECAB8: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECAC0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000ECAC4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000ECACC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECAD0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 0000000ECAD4: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000ECADC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECAE0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000ECAE4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000ECAEC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 0000000ECAF0: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECAF8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000ECAFC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000ECB00: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECB08: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000ECB0C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000ECB10: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECB18: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000ECB1C: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 0000000ECB24: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 0000000ECB2C: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECB38: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 0000000ECB3C: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 0000000ECB44: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 0000000ECB50: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000ECB58: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 0000000ECB5C: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 0000000ECB64: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000ECB6C: BF870292
	v_rcp_f32_e32 v141, v127                                   // 0000000ECB70: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 0000000ECB74: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECB7C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000ECB80: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000ECB84: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECB88: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 0000000ECB8C: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 0000000ECB94: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECB98: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 0000000ECB9C: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 0000000ECBA4: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 0000000ECBAC: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ECBB0: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 0000000ECBB4: D6270086 03CB0D8D
	.long 0xd4440007                                           // 0000000ECBBC: D4440007
	v_cndmask_b32_e32 v1, s14, v127, vcc_lo                    // 0000000ECBC0: 0202FE0E
	s_and_saveexec_b32 s8, s7                                  // 0000000ECBC4: BE882007
	s_cbranch_execnz 363                                       // 0000000ECBC8: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4278>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECBCC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ECBD0: BE882000
	s_cbranch_execnz 432                                       // 0000000ECBD4: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4398>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECBD8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ECBDC: BE882001
	s_cbranch_execnz 501                                       // 0000000ECBE0: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x44b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECBE4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ECBE8: BE882002
	s_cbranch_execnz 570                                       // 0000000ECBEC: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x45d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECBF0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ECBF4: BE882003
	s_cbranch_execnz 639                                       // 0000000ECBF8: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x46f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECBFC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ECC00: BE882004
	s_cbranch_execnz 708                                       // 0000000ECC04: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4818>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECC08: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ECC0C: BE882005
	s_cbranch_execnz 777                                       // 0000000ECC10: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4938>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECC14: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ECC18: BE882006
	s_cbranch_execnz 846                                       // 0000000ECC1C: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4a58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECC20: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000ECC24: BE882007
	s_cbranch_execnz 915                                       // 0000000ECC28: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4b78>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECC2C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ECC30: BE882000
	s_cbranch_execnz 984                                       // 0000000ECC34: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4c98>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECC38: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ECC3C: BE882001
	s_cbranch_execnz 1053                                      // 0000000ECC40: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4db8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECC44: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ECC48: BE882002
	s_cbranch_execnz 1122                                      // 0000000ECC4C: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4ed8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECC50: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ECC54: BE882003
	s_cbranch_execnz 1191                                      // 0000000ECC58: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4ff8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECC5C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ECC60: BE882004
	s_cbranch_execnz 1260                                      // 0000000ECC64: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5118>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECC68: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ECC6C: BE882005
	s_cbranch_execnz 1329                                      // 0000000ECC70: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5238>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECC74: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ECC78: BE882006
	s_cbranch_execnz 1398                                      // 0000000ECC7C: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5358>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECC80: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000ECC84: BE882007
	s_cbranch_execnz 1467                                      // 0000000ECC88: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5478>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECC8C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ECC90: BE882000
	s_cbranch_execnz 1536                                      // 0000000ECC94: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5598>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECC98: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ECC9C: BE882001
	s_cbranch_execnz 1605                                      // 0000000ECCA0: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x56b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECCA4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ECCA8: BE882002
	s_cbranch_execnz 1674                                      // 0000000ECCAC: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x57d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECCB0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ECCB4: BE882003
	s_cbranch_execnz 1743                                      // 0000000ECCB8: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x58f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECCBC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ECCC0: BE882004
	s_cbranch_execnz 1812                                      // 0000000ECCC4: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5a18>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECCC8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ECCCC: BE882005
	s_cbranch_execnz 1881                                      // 0000000ECCD0: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5b38>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECCD4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ECCD8: BE882006
	s_cbranch_execnz 1950                                      // 0000000ECCDC: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5c58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECCE0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000ECCE4: BE882007
	s_cbranch_execnz 2019                                      // 0000000ECCE8: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5d78>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECCEC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ECCF0: BE882000
	s_cbranch_execnz 2088                                      // 0000000ECCF4: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5e98>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECCF8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ECCFC: BE882001
	s_cbranch_execnz 2157                                      // 0000000ECD00: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5fb8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECD04: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ECD08: BE882002
	s_cbranch_execnz 2226                                      // 0000000ECD0C: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x60d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECD10: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ECD14: BE882003
	s_cbranch_execnz 2295                                      // 0000000ECD18: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x61f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECD1C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ECD20: BE882004
	s_cbranch_execnz 2364                                      // 0000000ECD24: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6318>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECD28: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ECD2C: BE882005
	s_cbranch_execnz 2433                                      // 0000000ECD30: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6438>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECD34: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ECD38: BE882006
	s_cbranch_execnz 2502                                      // 0000000ECD3C: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6558>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECD40: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000ECD44: BE882007
	s_cbranch_execnz 2571                                      // 0000000ECD48: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6678>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECD4C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ECD50: BE882000
	s_cbranch_execnz 2640                                      // 0000000ECD54: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6798>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECD58: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ECD5C: BE882001
	s_cbranch_execnz 2709                                      // 0000000ECD60: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x68b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECD64: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ECD68: BE882002
	s_cbranch_execnz 2778                                      // 0000000ECD6C: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x69d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECD70: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ECD74: BE882003
	s_cbranch_execnz 2847                                      // 0000000ECD78: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6af8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECD7C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ECD80: BE882004
	s_cbranch_execnz 2916                                      // 0000000ECD84: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6c18>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECD88: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ECD8C: BE882005
	s_cbranch_execnz 2985                                      // 0000000ECD90: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6d38>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECD94: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ECD98: BE882006
	s_cbranch_execnz 3054                                      // 0000000ECD9C: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6e58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECDA0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000ECDA4: BE882007
	s_cbranch_execnz 3123                                      // 0000000ECDA8: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6f78>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECDAC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ECDB0: BE882000
	s_cbranch_execnz 3192                                      // 0000000ECDB4: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7098>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECDB8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ECDBC: BE882001
	s_cbranch_execnz 3261                                      // 0000000ECDC0: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x71b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECDC4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ECDC8: BE882002
	s_cbranch_execnz 3330                                      // 0000000ECDCC: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x72d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECDD0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ECDD4: BE882003
	s_cbranch_execnz 3399                                      // 0000000ECDD8: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x73f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECDDC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ECDE0: BE882004
	s_cbranch_execnz 3468                                      // 0000000ECDE4: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7518>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECDE8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ECDEC: BE882005
	s_cbranch_execnz 3537                                      // 0000000ECDF0: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7638>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECDF4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ECDF8: BE882006
	s_cbranch_execnz 3606                                      // 0000000ECDFC: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7758>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECE00: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000ECE04: BE882007
	s_cbranch_execnz 3675                                      // 0000000ECE08: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7878>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECE0C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ECE10: BE882000
	s_cbranch_execnz 3744                                      // 0000000ECE14: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7998>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECE18: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ECE1C: BE882001
	s_cbranch_execnz 3813                                      // 0000000ECE20: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7ab8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECE24: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ECE28: BE882002
	s_cbranch_execnz 3882                                      // 0000000ECE2C: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7bd8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECE30: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ECE34: BE882003
	s_cbranch_execnz 3951                                      // 0000000ECE38: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7cf8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECE3C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ECE40: BE882004
	s_cbranch_execnz 4020                                      // 0000000ECE44: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7e18>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECE48: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ECE4C: BE882005
	s_cbranch_execnz 4089                                      // 0000000ECE50: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7f38>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECE54: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ECE58: BE882006
	s_cbranch_execnz 4158                                      // 0000000ECE5C: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8058>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECE60: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000ECE64: BE882007
	s_cbranch_execnz 4227                                      // 0000000ECE68: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8178>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECE6C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ECE70: BE882000
	s_cbranch_execnz 4296                                      // 0000000ECE74: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8298>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECE78: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ECE7C: BE882001
	s_cbranch_execnz 4365                                      // 0000000ECE80: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x83b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECE84: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ECE88: BE882002
	s_cbranch_execnz 4434                                      // 0000000ECE8C: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x84d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECE90: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ECE94: BE882003
	s_cbranch_execnz 4503                                      // 0000000ECE98: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x85f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECE9C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ECEA0: BE882004
	s_cbranch_execnz 4572                                      // 0000000ECEA4: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8718>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECEA8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ECEAC: BE882005
	s_cbranch_execnz 4641                                      // 0000000ECEB0: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8838>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECEB4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ECEB8: BE882006
	s_cbranch_execnz 4710                                      // 0000000ECEBC: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8958>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECEC0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000ECEC4: BE882007
	s_cbranch_execnz 4779                                      // 0000000ECEC8: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8a78>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECECC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ECED0: BE882000
	s_cbranch_execnz 4848                                      // 0000000ECED4: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b98>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECED8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ECEDC: BE882001
	s_cbranch_execnz 4917                                      // 0000000ECEE0: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8cb8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECEE4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ECEE8: BE882002
	s_cbranch_execnz 4986                                      // 0000000ECEEC: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8dd8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECEF0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ECEF4: BE882003
	s_cbranch_execnz 5055                                      // 0000000ECEF8: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8ef8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECEFC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ECF00: BE882004
	s_cbranch_execnz 5124                                      // 0000000ECF04: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9018>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECF08: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ECF0C: BE882005
	s_cbranch_execnz 5193                                      // 0000000ECF10: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9138>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECF14: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ECF18: BE882006
	s_cbranch_execnz 5262                                      // 0000000ECF1C: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9258>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECF20: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000ECF24: BE882007
	s_cbranch_execnz 5331                                      // 0000000ECF28: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9378>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECF2C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ECF30: BE882000
	s_cbranch_execnz 5400                                      // 0000000ECF34: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9498>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECF38: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ECF3C: BE882001
	s_cbranch_execnz 5469                                      // 0000000ECF40: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x95b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECF44: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ECF48: BE882002
	s_cbranch_execnz 5538                                      // 0000000ECF4C: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x96d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECF50: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ECF54: BE882003
	s_cbranch_execnz 5607                                      // 0000000ECF58: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x97f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECF5C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ECF60: BE882004
	s_cbranch_execnz 5676                                      // 0000000ECF64: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9918>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECF68: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ECF6C: BE882005
	s_cbranch_execnz 5745                                      // 0000000ECF70: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9a38>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECF74: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ECF78: BE882006
	s_cbranch_execnz 5814                                      // 0000000ECF7C: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9b58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECF80: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000ECF84: BE882007
	s_cbranch_execnz 5883                                      // 0000000ECF88: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c78>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECF8C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ECF90: BE882000
	s_cbranch_execnz 5952                                      // 0000000ECF94: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9d98>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECF98: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ECF9C: BE882001
	s_cbranch_execnz 6021                                      // 0000000ECFA0: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9eb8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECFA4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ECFA8: BE882002
	s_cbranch_execnz 6090                                      // 0000000ECFAC: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9fd8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECFB0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ECFB4: BE882003
	s_cbranch_execnz 6159                                      // 0000000ECFB8: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa0f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECFBC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ECFC0: BE882004
	s_cbranch_execnz 6228                                      // 0000000ECFC4: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa218>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECFC8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ECFCC: BE882005
	s_cbranch_execnz 6297                                      // 0000000ECFD0: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa338>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECFD4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ECFD8: BE882006
	s_cbranch_execnz 6366                                      // 0000000ECFDC: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa458>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECFE0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000ECFE4: BE882007
	s_cbranch_execnz 6435                                      // 0000000ECFE8: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa578>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECFEC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ECFF0: BE882000
	s_cbranch_execnz 6504                                      // 0000000ECFF4: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa698>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ECFF8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ECFFC: BE882001
	s_cbranch_execnz 6573                                      // 0000000ED000: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa7b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED004: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ED008: BE882002
	s_cbranch_execnz 6642                                      // 0000000ED00C: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa8d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED010: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ED014: BE882003
	s_cbranch_execnz 6711                                      // 0000000ED018: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa9f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED01C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ED020: BE882004
	s_cbranch_execnz 6780                                      // 0000000ED024: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xab18>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED028: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ED02C: BE882005
	s_cbranch_execnz 6849                                      // 0000000ED030: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac38>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED034: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ED038: BE882006
	s_cbranch_execnz 6918                                      // 0000000ED03C: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xad58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED040: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000ED044: BE882007
	s_cbranch_execnz 6987                                      // 0000000ED048: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xae78>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED04C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ED050: BE882000
	s_cbranch_execnz 7056                                      // 0000000ED054: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaf98>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED058: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ED05C: BE882001
	s_cbranch_execnz 7125                                      // 0000000ED060: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb0b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED064: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ED068: BE882002
	s_cbranch_execnz 7194                                      // 0000000ED06C: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb1d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED070: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ED074: BE882003
	s_cbranch_execnz 7263                                      // 0000000ED078: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb2f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED07C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ED080: BE882004
	s_cbranch_execnz 7332                                      // 0000000ED084: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb418>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED088: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ED08C: BE882005
	s_cbranch_execnz 7401                                      // 0000000ED090: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb538>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED094: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ED098: BE882006
	s_cbranch_execnz 7470                                      // 0000000ED09C: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb658>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED0A0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000ED0A4: BE882007
	s_cbranch_execnz 7539                                      // 0000000ED0A8: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb778>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED0AC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ED0B0: BE882000
	s_cbranch_execnz 7608                                      // 0000000ED0B4: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb898>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED0B8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ED0BC: BE882001
	s_cbranch_execnz 7677                                      // 0000000ED0C0: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb9b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED0C4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ED0C8: BE882002
	s_cbranch_execnz 7746                                      // 0000000ED0CC: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbad8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED0D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ED0D4: BE882003
	s_cbranch_execnz 7815                                      // 0000000ED0D8: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbbf8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED0DC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ED0E0: BE882004
	s_cbranch_execnz 7884                                      // 0000000ED0E4: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbd18>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED0E8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ED0EC: BE882005
	s_cbranch_execnz 7953                                      // 0000000ED0F0: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbe38>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED0F4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ED0F8: BE882006
	s_cbranch_execnz 8022                                      // 0000000ED0FC: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbf58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED100: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000ED104: BE882007
	s_cbranch_execnz 8091                                      // 0000000ED108: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc078>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED10C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ED110: BE882000
	s_cbranch_execnz 8160                                      // 0000000ED114: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc198>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED118: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 0000000ED11C: BE802001
	s_cbranch_execnz 8229                                      // 0000000ED120: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc2b8>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000ED124: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000ED128: BE802002
	s_cbranch_execnz 8298                                      // 0000000ED12C: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc3d8>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000ED130: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000ED134: BE802003
	s_cbranch_execnz 8367                                      // 0000000ED138: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc4f8>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000ED13C: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000ED140: BE802004
	s_cbranch_execnz 8436                                      // 0000000ED144: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc618>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000ED148: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000ED14C: BE802005
	s_cbranch_execnz 8505                                      // 0000000ED150: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc738>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000ED154: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000ED158: BE802006
	s_cbranch_execnz 8574                                      // 0000000ED15C: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc858>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000ED160: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000ED164: BE802007
	s_cbranch_execnz 8643                                      // 0000000ED168: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc978>
	s_nop 0                                                    // 0000000ED16C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000000ED170: BFB60003
	s_endpgm                                                   // 0000000ED174: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 0000000ED178: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 0000000ED184: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 0000000ED188: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000ED190: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000ED194: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED198: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000ED19C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000ED1A4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000ED1B0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ED1B4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000ED1B8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000ED1BC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000ED1C4: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ED1CC: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000ED1D0: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000ED1D4: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000ED1D8: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED1DC: BF870095
	.long 0xd71c008e                                           // 0000000ED1E0: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000ED1E4: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000ED1E8: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000ED1EC: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED1F4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000ED1F8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000ED200: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED204: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 0000000ED208: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000ED210: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED214: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000ED218: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000ED220: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 0000000ED224: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED22C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000ED230: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000ED234: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED23C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000ED240: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000ED244: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED24C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000ED250: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 0000000ED258: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 0000000ED260: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED26C: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 0000000ED270: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 0000000ED278: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 0000000ED284: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED28C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000ED290: BE882000
	s_cbranch_execz 65104                                      // 0000000ED294: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cd8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 0000000ED298: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 0000000ED2A4: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 0000000ED2A8: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 0000000ED2B0: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 0000000ED2B4: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED2B8: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 0000000ED2BC: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 0000000ED2C4: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 0000000ED2D0: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ED2D4: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 0000000ED2D8: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 0000000ED2DC: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 0000000ED2E4: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ED2EC: BF870121
	v_add_f32_e32 v141, v141, v142                             // 0000000ED2F0: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 0000000ED2F4: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 0000000ED2F8: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED2FC: BF870095
	.long 0xd71c008d                                           // 0000000ED300: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 0000000ED304: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000ED308: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 0000000ED30C: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED314: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 0000000ED318: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 0000000ED320: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED324: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 0000000ED328: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 0000000ED330: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED334: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 0000000ED338: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 0000000ED340: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 0000000ED344: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED34C: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 0000000ED350: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 0000000ED354: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED35C: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 0000000ED360: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 0000000ED364: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED36C: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 0000000ED370: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 0000000ED378: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 0000000ED380: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED38C: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 0000000ED390: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 0000000ED398: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 0000000ED3A4: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED3AC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000ED3B0: BE882001
	s_cbranch_execz 65035                                      // 0000000ED3B4: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ce4>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000000ED3B8: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 0000000ED3C4: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 0000000ED3C8: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 0000000ED3D0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000ED3D4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED3D8: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 0000000ED3DC: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 0000000ED3E4: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 0000000ED3F0: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ED3F4: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 0000000ED3F8: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000ED3FC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 0000000ED404: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ED40C: BF870121
	v_add_f32_e32 v128, v128, v141                             // 0000000ED410: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 0000000ED414: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 0000000ED418: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED41C: BF870095
	.long 0xd71c0080                                           // 0000000ED420: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 0000000ED424: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 0000000ED428: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000ED42C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED434: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 0000000ED438: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000ED440: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED444: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 0000000ED448: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 0000000ED450: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED454: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 0000000ED458: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 0000000ED460: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 0000000ED464: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED46C: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 0000000ED470: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 0000000ED474: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED47C: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 0000000ED480: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 0000000ED484: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED48C: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 0000000ED490: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 0000000ED498: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 0000000ED4A0: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED4AC: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 0000000ED4B0: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 0000000ED4B8: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 0000000ED4C4: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED4CC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000ED4D0: BE882002
	s_cbranch_execz 64966                                      // 0000000ED4D4: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cf0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 0000000ED4D8: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000ED4E4: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000ED4EC: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000ED4F0: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED4F4: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000ED4F8: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 0000000ED500: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 0000000ED50C: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ED510: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 0000000ED514: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 0000000ED51C: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000ED520: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 0000000ED524: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 0000000ED528: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000ED52C: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 0000000ED534: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED538: BF870095
	.long 0xd71c0072                                           // 0000000ED53C: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 0000000ED540: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000ED544: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000ED548: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED550: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 0000000ED554: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000ED560: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED564: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000ED568: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 0000000ED570: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED574: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 0000000ED578: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 0000000ED580: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 0000000ED584: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED58C: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 0000000ED590: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 0000000ED594: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED59C: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 0000000ED5A0: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 0000000ED5A4: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED5AC: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 0000000ED5B0: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000ED5B8: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 0000000ED5C0: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED5CC: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 0000000ED5D0: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 0000000ED5D8: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000ED5E4: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED5EC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000ED5F0: BE882003
	s_cbranch_execz 64897                                      // 0000000ED5F4: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cfc>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 0000000ED5F8: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000ED604: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000ED60C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000ED610: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED614: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000ED618: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000ED620: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 0000000ED62C: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ED630: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 0000000ED634: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000ED638: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000ED640: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ED648: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000ED64C: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 0000000ED650: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 0000000ED654: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED658: BF870095
	.long 0xd71c0072                                           // 0000000ED65C: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000ED660: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000ED664: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000ED668: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED670: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 0000000ED674: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000ED680: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED684: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000ED688: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000ED690: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED694: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 0000000ED698: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 0000000ED6A0: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 0000000ED6A4: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED6AC: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 0000000ED6B0: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 0000000ED6B4: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED6BC: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 0000000ED6C0: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 0000000ED6C4: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED6CC: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 0000000ED6D0: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000ED6D8: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 0000000ED6E0: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED6EC: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000ED6F0: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000ED6F8: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000ED704: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED70C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000ED710: BE882004
	s_cbranch_execz 64828                                      // 0000000ED714: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d08>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 0000000ED718: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000ED724: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000ED72C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000ED730: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED734: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000ED738: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000ED740: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000ED74C: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ED750: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000ED754: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000ED758: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000ED760: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ED768: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000ED76C: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000ED770: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000ED774: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED778: BF870095
	.long 0xd71c0072                                           // 0000000ED77C: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000ED780: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000ED784: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000ED788: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED790: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 0000000ED794: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000ED7A0: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED7A4: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000ED7A8: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000ED7B0: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED7B4: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000ED7B8: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000ED7C0: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000ED7C4: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED7CC: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 0000000ED7D0: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 0000000ED7D4: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED7DC: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 0000000ED7E0: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 0000000ED7E4: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED7EC: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 0000000ED7F0: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000ED7F8: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 0000000ED800: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED80C: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000ED810: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000ED818: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000ED824: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED82C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000ED830: BE882005
	s_cbranch_execz 64759                                      // 0000000ED834: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d14>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 0000000ED838: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000ED844: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000ED84C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000ED850: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED854: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000ED858: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000ED860: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000ED86C: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ED870: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000ED874: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000ED878: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000ED880: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ED888: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000ED88C: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000ED890: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000ED894: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED898: BF870095
	.long 0xd71c0072                                           // 0000000ED89C: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000ED8A0: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000ED8A4: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000ED8A8: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED8B0: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000ED8B4: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 0000000ED8BC: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED8C4: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000ED8C8: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000ED8D0: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED8D4: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000ED8D8: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000ED8E0: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000ED8E4: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED8EC: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000ED8F0: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 0000000ED8F4: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED8FC: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 0000000ED900: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 0000000ED904: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED90C: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000ED910: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000ED918: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 0000000ED920: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED92C: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000ED930: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000ED938: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000ED944: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ED94C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000ED950: BE882006
	s_cbranch_execz 64690                                      // 0000000ED954: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d20>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 0000000ED958: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000ED964: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000ED96C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000ED970: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED974: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000ED978: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000ED980: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000ED98C: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ED990: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000ED994: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000ED998: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000ED9A0: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ED9A8: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000ED9AC: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000ED9B0: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000ED9B4: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED9B8: BF870095
	.long 0xd71c0072                                           // 0000000ED9BC: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000ED9C0: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000ED9C4: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000ED9C8: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED9D0: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 0000000ED9D4: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000ED9E0: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED9E4: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000ED9E8: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000ED9F0: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED9F4: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000ED9F8: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000EDA00: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000EDA04: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDA0C: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000EDA10: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000EDA14: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDA1C: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000EDA20: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000EDA24: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDA2C: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000EDA30: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000EDA38: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 0000000EDA40: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDA4C: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000EDA50: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000EDA58: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000EDA64: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EDA6C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000EDA70: BE882007
	s_cbranch_execz 64621                                      // 0000000EDA74: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d2c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 0000000EDA78: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000EDA84: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000EDA8C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000EDA90: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDA94: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000EDA98: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000EDAA0: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000EDAAC: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EDAB0: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000EDAB4: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000EDAB8: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000EDAC0: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EDAC8: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000EDACC: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000EDAD0: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000EDAD4: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDAD8: BF870095
	.long 0xd71c0072                                           // 0000000EDADC: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000EDAE0: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000EDAE4: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000EDAE8: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDAF0: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 0000000EDAF4: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000EDB00: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDB04: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000EDB08: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000EDB10: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDB14: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000EDB18: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000EDB20: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000EDB24: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDB2C: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000EDB30: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000EDB34: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDB3C: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000EDB40: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000EDB44: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDB4C: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000EDB50: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000EDB58: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 0000000EDB60: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDB6C: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000EDB70: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000EDB78: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000EDB84: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EDB8C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000EDB90: BE882000
	s_cbranch_execz 64552                                      // 0000000EDB94: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d38>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 0000000EDB98: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 0000000EDBA4: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 0000000EDBA8: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000EDBB0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000EDBB4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDBB8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000EDBBC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000EDBC4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000EDBD0: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EDBD4: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000EDBD8: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000EDBDC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000EDBE4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EDBEC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000EDBF0: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000EDBF4: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000EDBF8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDBFC: BF870095
	.long 0xd71c0072                                           // 0000000EDC00: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000EDC04: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000EDC08: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000EDC0C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDC14: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000EDC18: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000EDC20: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDC24: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 0000000EDC28: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 0000000EDC30: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDC34: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 0000000EDC38: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 0000000EDC40: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 0000000EDC44: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDC4C: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 0000000EDC50: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 0000000EDC54: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDC5C: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 0000000EDC60: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 0000000EDC64: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDC6C: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 0000000EDC70: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 0000000EDC78: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 0000000EDC80: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDC8C: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 0000000EDC90: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 0000000EDC98: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 0000000EDCA4: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EDCAC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000EDCB0: BE882001
	s_cbranch_execz 64483                                      // 0000000EDCB4: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d44>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 0000000EDCB8: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 0000000EDCC4: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 0000000EDCC8: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 0000000EDCD0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000EDCD4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EDCD8: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 0000000EDCDC: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000EDCE4: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 0000000EDCEC: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000000EDCF8: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EDCFC: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 0000000EDD00: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 0000000EDD08: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EDD0C: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000000EDD10: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000000EDD14: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000000EDD18: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDD1C: BF870095
	.long 0xd71c0071                                           // 0000000EDD20: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000000EDD24: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000EDD28: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000EDD2C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDD34: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 0000000EDD38: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000EDD40: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDD44: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 0000000EDD48: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 0000000EDD50: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDD54: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 0000000EDD58: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 0000000EDD60: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 0000000EDD64: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDD6C: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 0000000EDD70: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 0000000EDD74: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDD7C: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 0000000EDD80: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 0000000EDD84: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDD8C: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 0000000EDD90: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 0000000EDD98: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 0000000EDDA0: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDDAC: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 0000000EDDB0: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 0000000EDDB8: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 0000000EDDC4: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EDDCC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000EDDD0: BE882002
	s_cbranch_execz 64414                                      // 0000000EDDD4: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d50>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 0000000EDDD8: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000EDDE4: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000EDDEC: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000EDDF0: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDDF4: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000EDDF8: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 0000000EDE00: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 0000000EDE0C: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EDE10: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 0000000EDE14: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000EDE18: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 0000000EDE20: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EDE28: BF870121
	v_add_f32_e32 v106, v106, v113                             // 0000000EDE2C: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 0000000EDE30: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 0000000EDE34: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDE38: BF870095
	.long 0xd71c006a                                           // 0000000EDE3C: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 0000000EDE40: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000EDE44: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000EDE48: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDE50: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 0000000EDE54: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000EDE60: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDE64: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000EDE68: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 0000000EDE70: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDE74: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 0000000EDE78: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 0000000EDE80: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 0000000EDE84: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDE8C: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 0000000EDE90: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 0000000EDE94: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDE9C: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 0000000EDEA0: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 0000000EDEA4: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDEAC: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 0000000EDEB0: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000EDEB8: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 0000000EDEC0: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDECC: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 0000000EDED0: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 0000000EDED8: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000EDEE4: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EDEEC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000EDEF0: BE882003
	s_cbranch_execz 64345                                      // 0000000EDEF4: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d5c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 0000000EDEF8: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000EDF04: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000EDF0C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000EDF10: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDF14: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000EDF18: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000EDF20: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 0000000EDF2C: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDF30: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 0000000EDF34: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 0000000EDF40: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 0000000EDF44: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000EDF48: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EDF50: BF870293
	v_exp_f32_e32 v106, v106                                   // 0000000EDF54: 7ED44B6A
	.long 0xd71c006a                                           // 0000000EDF58: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000EDF5C: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EDF60: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000EDF64: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000EDF68: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 0000000EDF70: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDF7C: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 0000000EDF80: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000EDF84: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EDF8C: BF870291
	v_rcp_f32_e32 v108, v107                                   // 0000000EDF90: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 0000000EDF94: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EDF9C: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 0000000EDFA0: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 0000000EDFA4: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 0000000EDFAC: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDFB0: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 0000000EDFB4: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 0000000EDFBC: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDFC0: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 0000000EDFC4: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 0000000EDFCC: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EDFD4: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000EDFD8: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 0000000EDFE0: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 0000000EDFEC: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EDFF4: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000EDFF8: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000EE004: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EE00C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000EE010: BE882004
	s_cbranch_execz 64276                                      // 0000000EE014: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d68>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 0000000EE018: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000EE024: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000EE02C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000EE030: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE034: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000EE038: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000EE040: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000EE04C: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EE050: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000EE054: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000EE058: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000EE060: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EE068: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000EE06C: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000EE070: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000EE074: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE078: BF870095
	.long 0xd71c006a                                           // 0000000EE07C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000EE080: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000EE084: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000EE088: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE090: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 0000000EE094: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000EE0A0: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE0A4: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000EE0A8: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000EE0B0: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE0B4: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000EE0B8: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000EE0C0: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000EE0C4: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE0CC: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 0000000EE0D0: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 0000000EE0D4: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE0DC: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 0000000EE0E0: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 0000000EE0E4: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE0EC: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 0000000EE0F0: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000EE0F8: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 0000000EE100: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE10C: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000EE110: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000EE118: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000EE124: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EE12C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000EE130: BE882005
	s_cbranch_execz 64207                                      // 0000000EE134: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d74>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 0000000EE138: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000EE144: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000EE14C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000EE150: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE154: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000EE158: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000EE160: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000EE16C: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EE170: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000EE174: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000EE178: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000EE180: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EE188: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000EE18C: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000EE190: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000EE194: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE198: BF870095
	.long 0xd71c006a                                           // 0000000EE19C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000EE1A0: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000EE1A4: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000EE1A8: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE1B0: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000000EE1B4: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 0000000EE1BC: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE1C4: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000EE1C8: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000EE1D0: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE1D4: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000EE1D8: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000EE1E0: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000EE1E4: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE1EC: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000EE1F0: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 0000000EE1F4: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE1FC: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 0000000EE200: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 0000000EE204: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE20C: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000EE210: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000EE218: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 0000000EE220: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE22C: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000EE230: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000EE238: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000EE244: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EE24C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000EE250: BE882006
	s_cbranch_execz 64138                                      // 0000000EE254: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d80>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 0000000EE258: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000EE264: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000EE26C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000EE270: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE274: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000EE278: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000EE280: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000EE28C: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EE290: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000EE294: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000EE298: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000EE2A0: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EE2A8: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000EE2AC: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000EE2B0: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000EE2B4: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE2B8: BF870095
	.long 0xd71c006a                                           // 0000000EE2BC: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000EE2C0: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000EE2C4: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000EE2C8: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE2D0: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 0000000EE2D4: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000EE2E0: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE2E4: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000EE2E8: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000EE2F0: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE2F4: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000EE2F8: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000EE300: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000EE304: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE30C: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000EE310: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 0000000EE314: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE31C: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 0000000EE320: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 0000000EE324: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE32C: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000EE330: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000EE338: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 0000000EE340: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE34C: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000EE350: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000EE358: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000EE364: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EE36C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000EE370: BE882007
	s_cbranch_execz 64069                                      // 0000000EE374: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d8c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 0000000EE378: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000EE384: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000EE38C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000EE390: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE394: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000EE398: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000EE3A0: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000EE3AC: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EE3B0: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000EE3B4: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000EE3B8: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000EE3C0: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EE3C8: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000EE3CC: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000EE3D0: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000EE3D4: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE3D8: BF870095
	.long 0xd71c006a                                           // 0000000EE3DC: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000EE3E0: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000EE3E4: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000EE3E8: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE3F0: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 0000000EE3F4: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000EE400: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE404: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000EE408: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000EE410: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE414: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000EE418: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000EE420: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000EE424: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE42C: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000EE430: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 0000000EE434: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE43C: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 0000000EE440: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 0000000EE444: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE44C: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000EE450: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000EE458: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 0000000EE460: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE46C: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000EE470: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000EE478: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000EE484: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EE48C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000EE490: BE882000
	s_cbranch_execz 64000                                      // 0000000EE494: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d98>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 0000000EE498: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 0000000EE4A4: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 0000000EE4A8: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000EE4B0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000EE4B4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE4B8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000EE4BC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000EE4C4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000EE4D0: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EE4D4: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000EE4D8: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000EE4DC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000EE4E4: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EE4EC: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000EE4F0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000EE4F4: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000EE4F8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE4FC: BF870095
	.long 0xd71c006a                                           // 0000000EE500: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000EE504: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000EE508: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000EE50C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE514: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000000EE518: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000EE520: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE524: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 0000000EE528: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 0000000EE530: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE534: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 0000000EE538: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 0000000EE540: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 0000000EE544: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE54C: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 0000000EE550: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 0000000EE554: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE55C: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 0000000EE560: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 0000000EE564: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE56C: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 0000000EE570: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 0000000EE578: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 0000000EE580: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE58C: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 0000000EE590: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 0000000EE598: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 0000000EE5A4: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EE5AC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000EE5B0: BE882001
	s_cbranch_execz 63931                                      // 0000000EE5B4: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3da4>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 0000000EE5B8: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 0000000EE5C4: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 0000000EE5C8: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 0000000EE5D0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000EE5D4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EE5D8: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 0000000EE5DC: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000EE5E4: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 0000000EE5EC: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000000EE5F8: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EE5FC: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 0000000EE600: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 0000000EE608: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EE60C: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000000EE610: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000000EE614: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000000EE618: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE61C: BF870095
	.long 0xd71c0069                                           // 0000000EE620: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000000EE624: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000000EE628: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000EE62C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE634: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 0000000EE638: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000EE640: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE644: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 0000000EE648: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 0000000EE650: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE654: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 0000000EE658: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 0000000EE660: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 0000000EE664: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE66C: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 0000000EE670: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 0000000EE674: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE67C: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 0000000EE680: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 0000000EE684: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE68C: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 0000000EE690: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 0000000EE698: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 0000000EE6A0: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE6AC: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 0000000EE6B0: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 0000000EE6B8: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 0000000EE6C4: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EE6CC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000EE6D0: BE882002
	s_cbranch_execz 63862                                      // 0000000EE6D4: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3db0>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 0000000EE6D8: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000EE6E4: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000EE6EC: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000EE6F0: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE6F4: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000EE6F8: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 0000000EE700: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 0000000EE70C: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EE710: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 0000000EE714: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000EE718: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 0000000EE720: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EE728: BF870121
	v_add_f32_e32 v98, v98, v105                               // 0000000EE72C: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 0000000EE730: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 0000000EE734: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE738: BF870095
	.long 0xd71c0062                                           // 0000000EE73C: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 0000000EE740: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000EE744: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000EE748: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE750: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 0000000EE754: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000EE760: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE764: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000EE768: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 0000000EE770: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE774: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 0000000EE778: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 0000000EE780: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 0000000EE784: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE78C: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 0000000EE790: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 0000000EE794: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE79C: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 0000000EE7A0: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 0000000EE7A4: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE7AC: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 0000000EE7B0: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000EE7B8: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 0000000EE7C0: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE7CC: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 0000000EE7D0: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 0000000EE7D8: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000EE7E4: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EE7EC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000EE7F0: BE882003
	s_cbranch_execz 63793                                      // 0000000EE7F4: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dbc>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 0000000EE7F8: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000EE804: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000EE80C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000EE810: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE814: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000EE818: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000EE820: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 0000000EE82C: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE830: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 0000000EE834: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 0000000EE840: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 0000000EE844: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000EE848: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EE850: BF870293
	v_exp_f32_e32 v98, v98                                     // 0000000EE854: 7EC44B62
	.long 0xd71c0062                                           // 0000000EE858: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000EE85C: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EE860: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000EE864: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000EE868: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 0000000EE870: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE87C: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 0000000EE880: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000EE884: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EE88C: BF870291
	v_rcp_f32_e32 v100, v99                                    // 0000000EE890: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 0000000EE894: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EE89C: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 0000000EE8A0: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 0000000EE8A4: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 0000000EE8AC: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE8B0: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 0000000EE8B4: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 0000000EE8BC: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE8C0: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 0000000EE8C4: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 0000000EE8CC: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EE8D4: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000EE8D8: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 0000000EE8E0: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000EE8EC: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EE8F4: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000EE8F8: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000EE904: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EE90C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000EE910: BE882004
	s_cbranch_execz 63724                                      // 0000000EE914: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dc8>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 0000000EE918: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000EE924: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000EE92C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000EE930: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE934: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000EE938: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000EE940: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000EE94C: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EE950: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000EE954: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000EE958: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000EE960: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EE968: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000EE96C: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000EE970: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000EE974: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE978: BF870095
	.long 0xd71c0062                                           // 0000000EE97C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000EE980: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000EE984: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000EE988: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE990: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 0000000EE994: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000EE9A0: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE9A4: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000EE9A8: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000EE9B0: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE9B4: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000EE9B8: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000EE9C0: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000EE9C4: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE9CC: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 0000000EE9D0: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 0000000EE9D4: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE9DC: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 0000000EE9E0: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 0000000EE9E4: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE9EC: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 0000000EE9F0: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000EE9F8: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 0000000EEA00: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEA0C: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000EEA10: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000EEA18: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000EEA24: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EEA2C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000EEA30: BE882005
	s_cbranch_execz 63655                                      // 0000000EEA34: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dd4>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 0000000EEA38: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000EEA44: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000EEA4C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000EEA50: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEA54: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000EEA58: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000EEA60: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000EEA6C: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EEA70: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000EEA74: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000EEA78: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000EEA80: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EEA88: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000EEA8C: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000EEA90: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000EEA94: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEA98: BF870095
	.long 0xd71c0062                                           // 0000000EEA9C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000EEAA0: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000EEAA4: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000EEAA8: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEAB0: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000EEAB4: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 0000000EEABC: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEAC4: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000EEAC8: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000EEAD0: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEAD4: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000EEAD8: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000EEAE0: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000EEAE4: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEAEC: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000EEAF0: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 0000000EEAF4: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEAFC: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 0000000EEB00: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 0000000EEB04: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEB0C: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000EEB10: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000EEB18: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 0000000EEB20: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEB2C: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000EEB30: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000EEB38: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000EEB44: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EEB4C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000EEB50: BE882006
	s_cbranch_execz 63586                                      // 0000000EEB54: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3de0>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 0000000EEB58: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000EEB64: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000EEB6C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000EEB70: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEB74: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000EEB78: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000EEB80: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000EEB8C: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EEB90: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000EEB94: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000EEB98: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000EEBA0: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EEBA8: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000EEBAC: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000EEBB0: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000EEBB4: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEBB8: BF870095
	.long 0xd71c0062                                           // 0000000EEBBC: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000EEBC0: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000EEBC4: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000EEBC8: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEBD0: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 0000000EEBD4: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000EEBE0: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEBE4: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000EEBE8: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000EEBF0: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEBF4: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000EEBF8: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000EEC00: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000EEC04: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEC0C: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000EEC10: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000EEC14: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEC1C: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000EEC20: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000EEC24: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEC2C: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000EEC30: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000EEC38: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 0000000EEC40: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEC4C: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000EEC50: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000EEC58: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000EEC64: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EEC6C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000EEC70: BE882007
	s_cbranch_execz 63517                                      // 0000000EEC74: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dec>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 0000000EEC78: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000EEC84: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000EEC8C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000EEC90: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEC94: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000EEC98: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000EECA0: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000EECAC: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EECB0: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000EECB4: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000EECB8: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000EECC0: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EECC8: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000EECCC: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000EECD0: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000EECD4: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EECD8: BF870095
	.long 0xd71c0062                                           // 0000000EECDC: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000EECE0: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000EECE4: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000EECE8: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EECF0: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 0000000EECF4: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000EED00: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EED04: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000EED08: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000EED10: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EED14: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000EED18: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000EED20: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000EED24: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EED2C: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000EED30: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000EED34: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EED3C: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000EED40: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000EED44: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EED4C: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000EED50: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000EED58: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 0000000EED60: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EED6C: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000EED70: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000EED78: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000EED84: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EED8C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000EED90: BE882000
	s_cbranch_execz 63448                                      // 0000000EED94: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3df8>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 0000000EED98: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 0000000EEDA4: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 0000000EEDA8: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000EEDB0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000EEDB4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEDB8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000EEDBC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000EEDC4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000EEDD0: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EEDD4: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000EEDD8: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000EEDDC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000EEDE4: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EEDEC: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000EEDF0: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000EEDF4: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000EEDF8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEDFC: BF870095
	.long 0xd71c0062                                           // 0000000EEE00: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000EEE04: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000EEE08: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000EEE0C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEE14: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000EEE18: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000EEE20: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEE24: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 0000000EEE28: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 0000000EEE30: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEE34: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000000EEE38: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 0000000EEE40: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 0000000EEE44: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEE4C: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 0000000EEE50: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 0000000EEE54: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEE5C: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 0000000EEE60: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 0000000EEE64: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEE6C: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 0000000EEE70: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 0000000EEE78: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 0000000EEE80: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEE8C: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 0000000EEE90: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 0000000EEE98: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 0000000EEEA4: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EEEAC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000EEEB0: BE882001
	s_cbranch_execz 63379                                      // 0000000EEEB4: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e04>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 0000000EEEB8: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 0000000EEEC4: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 0000000EEEC8: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 0000000EEED0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000EEED4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EEED8: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 0000000EEEDC: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000EEEE4: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 0000000EEEEC: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000000EEEF8: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EEEFC: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 0000000EEF00: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 0000000EEF08: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EEF0C: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000000EEF10: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000000EEF14: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000000EEF18: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEF1C: BF870095
	.long 0xd71c0061                                           // 0000000EEF20: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000000EEF24: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000EEF28: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000EEF2C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEF34: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 0000000EEF38: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000EEF40: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEF44: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 0000000EEF48: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 0000000EEF50: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEF54: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 0000000EEF58: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 0000000EEF60: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 0000000EEF64: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEF6C: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 0000000EEF70: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 0000000EEF74: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEF7C: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 0000000EEF80: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 0000000EEF84: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEF8C: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 0000000EEF90: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 0000000EEF98: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 0000000EEFA0: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEFAC: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 0000000EEFB0: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 0000000EEFB8: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 0000000EEFC4: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EEFCC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000EEFD0: BE882002
	s_cbranch_execz 63310                                      // 0000000EEFD4: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e10>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 0000000EEFD8: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000EEFE4: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000EEFEC: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000EEFF0: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEFF4: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000EEFF8: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 0000000EF000: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 0000000EF00C: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EF010: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 0000000EF014: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000EF018: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 0000000EF020: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EF028: BF870121
	v_add_f32_e32 v90, v90, v97                                // 0000000EF02C: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 0000000EF030: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 0000000EF034: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF038: BF870095
	.long 0xd71c005a                                           // 0000000EF03C: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 0000000EF040: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000EF044: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000EF048: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF050: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 0000000EF054: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000EF060: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF064: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000EF068: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 0000000EF070: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF074: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 0000000EF078: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 0000000EF080: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 0000000EF084: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF08C: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 0000000EF090: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 0000000EF094: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF09C: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 0000000EF0A0: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 0000000EF0A4: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF0AC: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 0000000EF0B0: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000EF0B8: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 0000000EF0C0: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF0CC: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 0000000EF0D0: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 0000000EF0D8: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000EF0E4: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EF0EC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000EF0F0: BE882003
	s_cbranch_execz 63241                                      // 0000000EF0F4: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e1c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 0000000EF0F8: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000EF104: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000EF10C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000EF110: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF114: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000EF118: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000EF120: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 0000000EF12C: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF130: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 0000000EF134: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 0000000EF140: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 0000000EF144: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000EF148: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EF150: BF870293
	v_exp_f32_e32 v90, v90                                     // 0000000EF154: 7EB44B5A
	.long 0xd71c005a                                           // 0000000EF158: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000EF15C: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EF160: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000EF164: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000EF168: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 0000000EF170: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF17C: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 0000000EF180: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000EF184: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EF18C: BF870291
	v_rcp_f32_e32 v92, v91                                     // 0000000EF190: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 0000000EF194: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EF19C: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 0000000EF1A0: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 0000000EF1A4: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 0000000EF1AC: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF1B0: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 0000000EF1B4: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 0000000EF1BC: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF1C0: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 0000000EF1C4: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 0000000EF1CC: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EF1D4: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000EF1D8: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 0000000EF1E0: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000EF1EC: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EF1F4: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000EF1F8: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000EF204: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EF20C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000EF210: BE882004
	s_cbranch_execz 63172                                      // 0000000EF214: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e28>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 0000000EF218: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000EF224: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000EF22C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000EF230: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF234: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000EF238: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000EF240: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000EF24C: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EF250: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000EF254: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000EF258: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000EF260: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EF268: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000EF26C: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000EF270: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000EF274: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF278: BF870095
	.long 0xd71c005a                                           // 0000000EF27C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000EF280: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000EF284: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000EF288: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF290: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 0000000EF294: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000EF2A0: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF2A4: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000EF2A8: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000EF2B0: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF2B4: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000EF2B8: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000EF2C0: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000EF2C4: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF2CC: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 0000000EF2D0: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 0000000EF2D4: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF2DC: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 0000000EF2E0: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 0000000EF2E4: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF2EC: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 0000000EF2F0: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000EF2F8: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 0000000EF300: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF30C: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000EF310: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000EF318: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000EF324: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EF32C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000EF330: BE882005
	s_cbranch_execz 63103                                      // 0000000EF334: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e34>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 0000000EF338: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000EF344: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000EF34C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000EF350: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF354: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000EF358: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000EF360: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000EF36C: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EF370: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000EF374: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000EF378: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000EF380: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EF388: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000EF38C: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000EF390: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000EF394: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF398: BF870095
	.long 0xd71c005a                                           // 0000000EF39C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000EF3A0: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000EF3A4: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000EF3A8: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF3B0: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000000EF3B4: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 0000000EF3BC: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF3C4: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000EF3C8: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000EF3D0: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF3D4: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000EF3D8: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000EF3E0: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000EF3E4: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF3EC: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000EF3F0: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 0000000EF3F4: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF3FC: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 0000000EF400: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 0000000EF404: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF40C: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000EF410: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000EF418: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 0000000EF420: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF42C: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000EF430: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000EF438: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000EF444: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EF44C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000EF450: BE882006
	s_cbranch_execz 63034                                      // 0000000EF454: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e40>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 0000000EF458: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000EF464: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000EF46C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000EF470: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF474: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000EF478: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000EF480: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000EF48C: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EF490: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000EF494: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000EF498: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000EF4A0: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EF4A8: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000EF4AC: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000EF4B0: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000EF4B4: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF4B8: BF870095
	.long 0xd71c005a                                           // 0000000EF4BC: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000EF4C0: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000EF4C4: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000EF4C8: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF4D0: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 0000000EF4D4: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000EF4E0: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF4E4: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000EF4E8: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000EF4F0: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF4F4: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000EF4F8: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000EF500: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000EF504: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF50C: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000EF510: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000000EF514: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF51C: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000000EF520: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000000EF524: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF52C: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000EF530: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000EF538: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 0000000EF540: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF54C: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000EF550: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000EF558: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000EF564: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EF56C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000EF570: BE882007
	s_cbranch_execz 62965                                      // 0000000EF574: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e4c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 0000000EF578: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000EF584: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000EF58C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000EF590: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF594: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000EF598: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000EF5A0: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000EF5AC: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EF5B0: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000EF5B4: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000EF5B8: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000EF5C0: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EF5C8: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000EF5CC: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000EF5D0: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000EF5D4: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF5D8: BF870095
	.long 0xd71c005a                                           // 0000000EF5DC: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000EF5E0: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000EF5E4: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000EF5E8: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF5F0: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 0000000EF5F4: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000EF600: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF604: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000EF608: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000EF610: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF614: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000EF618: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000EF620: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000EF624: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF62C: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000EF630: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000000EF634: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF63C: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000000EF640: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000000EF644: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF64C: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000EF650: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000EF658: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 0000000EF660: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF66C: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000EF670: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000EF678: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000EF684: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EF68C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000EF690: BE882000
	s_cbranch_execz 62896                                      // 0000000EF694: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e58>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 0000000EF698: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 0000000EF6A4: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 0000000EF6A8: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000EF6B0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000EF6B4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF6B8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000EF6BC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000EF6C4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000EF6D0: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EF6D4: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000EF6D8: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000EF6DC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000EF6E4: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EF6EC: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000EF6F0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000EF6F4: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000EF6F8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF6FC: BF870095
	.long 0xd71c005a                                           // 0000000EF700: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000EF704: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000EF708: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000EF70C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF714: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000000EF718: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000EF720: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF724: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 0000000EF728: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 0000000EF730: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF734: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 0000000EF738: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 0000000EF740: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 0000000EF744: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF74C: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 0000000EF750: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 0000000EF754: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF75C: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 0000000EF760: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 0000000EF764: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF76C: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 0000000EF770: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 0000000EF778: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 0000000EF780: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF78C: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 0000000EF790: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 0000000EF798: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 0000000EF7A4: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EF7AC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000EF7B0: BE882001
	s_cbranch_execz 62827                                      // 0000000EF7B4: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e64>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 0000000EF7B8: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 0000000EF7C4: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 0000000EF7C8: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 0000000EF7D0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000EF7D4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EF7D8: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 0000000EF7DC: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000EF7E4: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 0000000EF7EC: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000000EF7F8: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000EF7FC: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 0000000EF800: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 0000000EF808: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EF80C: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000000EF810: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000000EF814: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000000EF818: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF81C: BF870095
	.long 0xd71c0059                                           // 0000000EF820: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000000EF824: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000EF828: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000EF82C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF834: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 0000000EF838: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000EF840: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF844: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 0000000EF848: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 0000000EF850: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF854: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 0000000EF858: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 0000000EF860: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 0000000EF864: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF86C: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 0000000EF870: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 0000000EF874: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF87C: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 0000000EF880: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 0000000EF884: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF88C: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 0000000EF890: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 0000000EF898: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 0000000EF8A0: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF8AC: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 0000000EF8B0: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 0000000EF8B8: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 0000000EF8C4: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EF8CC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000EF8D0: BE882002
	s_cbranch_execz 62758                                      // 0000000EF8D4: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e70>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 0000000EF8D8: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000EF8E4: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000EF8EC: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000EF8F0: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF8F4: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000EF8F8: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 0000000EF900: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 0000000EF90C: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EF910: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 0000000EF914: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000EF918: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 0000000EF920: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EF928: BF870121
	v_add_f32_e32 v82, v82, v89                                // 0000000EF92C: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 0000000EF930: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 0000000EF934: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF938: BF870095
	.long 0xd71c0052                                           // 0000000EF93C: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 0000000EF940: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000EF944: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000EF948: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF950: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 0000000EF954: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000EF960: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF964: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000EF968: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 0000000EF970: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF974: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 0000000EF978: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 0000000EF980: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 0000000EF984: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF98C: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 0000000EF990: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 0000000EF994: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF99C: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 0000000EF9A0: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 0000000EF9A4: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF9AC: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 0000000EF9B0: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000EF9B8: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 0000000EF9C0: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EF9CC: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 0000000EF9D0: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 0000000EF9D8: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000EF9E4: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EF9EC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000EF9F0: BE882003
	s_cbranch_execz 62689                                      // 0000000EF9F4: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e7c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 0000000EF9F8: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000EFA04: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000EFA0C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000EFA10: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFA14: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000EFA18: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000EFA20: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 0000000EFA2C: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFA30: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 0000000EFA34: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 0000000EFA40: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 0000000EFA44: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000EFA48: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EFA50: BF870293
	v_exp_f32_e32 v82, v82                                     // 0000000EFA54: 7EA44B52
	.long 0xd71c0052                                           // 0000000EFA58: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000EFA5C: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EFA60: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000EFA64: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000EFA68: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 0000000EFA70: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFA7C: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 0000000EFA80: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000EFA84: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000EFA8C: BF870291
	v_rcp_f32_e32 v84, v83                                     // 0000000EFA90: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 0000000EFA94: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EFA9C: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 0000000EFAA0: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 0000000EFAA4: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 0000000EFAAC: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFAB0: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 0000000EFAB4: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 0000000EFABC: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFAC0: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 0000000EFAC4: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 0000000EFACC: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EFAD4: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000EFAD8: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 0000000EFAE0: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000EFAEC: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EFAF4: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000EFAF8: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000EFB04: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EFB0C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000EFB10: BE882004
	s_cbranch_execz 62620                                      // 0000000EFB14: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e88>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 0000000EFB18: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000EFB24: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000EFB2C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000EFB30: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFB34: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000EFB38: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000EFB40: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000EFB4C: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EFB50: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000EFB54: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000EFB58: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000EFB60: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EFB68: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000EFB6C: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000EFB70: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000EFB74: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFB78: BF870095
	.long 0xd71c0052                                           // 0000000EFB7C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000EFB80: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000EFB84: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000EFB88: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFB90: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 0000000EFB94: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000EFBA0: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFBA4: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000EFBA8: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000EFBB0: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFBB4: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000EFBB8: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000EFBC0: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000EFBC4: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFBCC: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 0000000EFBD0: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 0000000EFBD4: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFBDC: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 0000000EFBE0: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 0000000EFBE4: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFBEC: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 0000000EFBF0: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000EFBF8: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 0000000EFC00: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFC0C: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000EFC10: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000EFC18: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000EFC24: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EFC2C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000EFC30: BE882005
	s_cbranch_execz 62551                                      // 0000000EFC34: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e94>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 0000000EFC38: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000EFC44: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000EFC4C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000EFC50: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFC54: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000EFC58: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000EFC60: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000EFC6C: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EFC70: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000EFC74: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000EFC78: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000EFC80: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EFC88: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000EFC8C: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000EFC90: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000EFC94: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFC98: BF870095
	.long 0xd71c0052                                           // 0000000EFC9C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000EFCA0: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000EFCA4: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000EFCA8: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFCB0: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 0000000EFCB4: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 0000000EFCBC: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFCC4: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000EFCC8: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000EFCD0: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFCD4: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000EFCD8: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000EFCE0: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000EFCE4: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFCEC: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000EFCF0: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 0000000EFCF4: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFCFC: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 0000000EFD00: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 0000000EFD04: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFD0C: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000EFD10: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000EFD18: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 0000000EFD20: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFD2C: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000EFD30: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000EFD38: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000EFD44: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EFD4C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000EFD50: BE882006
	s_cbranch_execz 62482                                      // 0000000EFD54: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ea0>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 0000000EFD58: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000EFD64: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000EFD6C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000EFD70: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFD74: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000EFD78: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000EFD80: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000EFD8C: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EFD90: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000EFD94: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000EFD98: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000EFDA0: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EFDA8: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000EFDAC: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000EFDB0: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000EFDB4: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFDB8: BF870095
	.long 0xd71c0052                                           // 0000000EFDBC: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000EFDC0: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000EFDC4: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000EFDC8: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFDD0: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 0000000EFDD4: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000EFDE0: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFDE4: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000EFDE8: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000EFDF0: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFDF4: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000EFDF8: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000EFE00: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000EFE04: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFE0C: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000EFE10: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000EFE14: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFE1C: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000EFE20: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000EFE24: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFE2C: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000EFE30: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000EFE38: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 0000000EFE40: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFE4C: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000EFE50: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000EFE58: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000EFE64: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EFE6C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000EFE70: BE882007
	s_cbranch_execz 62413                                      // 0000000EFE74: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eac>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 0000000EFE78: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000EFE84: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000EFE8C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000EFE90: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFE94: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000EFE98: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000EFEA0: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000EFEAC: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EFEB0: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000EFEB4: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000EFEB8: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000EFEC0: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EFEC8: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000EFECC: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000EFED0: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000EFED4: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFED8: BF870095
	.long 0xd71c0052                                           // 0000000EFEDC: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000EFEE0: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000EFEE4: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000EFEE8: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFEF0: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 0000000EFEF4: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000EFF00: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFF04: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000EFF08: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000EFF10: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFF14: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000EFF18: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000EFF20: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000EFF24: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFF2C: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000EFF30: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000EFF34: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFF3C: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000EFF40: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000EFF44: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFF4C: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000EFF50: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000EFF58: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 0000000EFF60: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFF6C: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000EFF70: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000EFF78: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000EFF84: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000EFF8C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000EFF90: BE882000
	s_cbranch_execz 62344                                      // 0000000EFF94: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eb8>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 0000000EFF98: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 0000000EFFA4: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 0000000EFFA8: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000EFFB0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000EFFB4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFFB8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000EFFBC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000EFFC4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000EFFD0: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000EFFD4: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000EFFD8: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000EFFDC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000EFFE4: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EFFEC: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000EFFF0: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000EFFF4: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000EFFF8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EFFFC: BF870095
	.long 0xd71c0052                                           // 0000000F0000: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000F0004: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000F0008: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000F000C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0014: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 0000000F0018: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000F0020: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0024: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 0000000F0028: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 0000000F0030: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0034: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 0000000F0038: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 0000000F0040: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 0000000F0044: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F004C: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 0000000F0050: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 0000000F0054: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F005C: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 0000000F0060: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 0000000F0064: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F006C: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 0000000F0070: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 0000000F0078: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 0000000F0080: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F008C: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 0000000F0090: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 0000000F0098: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 0000000F00A4: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F00AC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F00B0: BE882001
	s_cbranch_execz 62275                                      // 0000000F00B4: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ec4>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 0000000F00B8: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 0000000F00C4: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 0000000F00C8: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 0000000F00D0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000F00D4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F00D8: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 0000000F00DC: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000F00E4: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 0000000F00EC: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 0000000F00F8: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F00FC: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 0000000F0100: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 0000000F0108: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F010C: BF870121
	v_add_f32_e32 v81, v81, v82                                // 0000000F0110: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 0000000F0114: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 0000000F0118: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F011C: BF870095
	.long 0xd71c0051                                           // 0000000F0120: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000000F0124: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000F0128: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000F012C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0134: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 0000000F0138: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000F0140: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0144: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 0000000F0148: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 0000000F0150: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0154: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 0000000F0158: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 0000000F0160: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 0000000F0164: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F016C: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 0000000F0170: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 0000000F0174: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F017C: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 0000000F0180: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 0000000F0184: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F018C: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 0000000F0190: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 0000000F0198: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 0000000F01A0: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F01AC: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 0000000F01B0: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 0000000F01B8: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 0000000F01C4: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F01CC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F01D0: BE882002
	s_cbranch_execz 62206                                      // 0000000F01D4: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ed0>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 0000000F01D8: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000F01E4: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000F01EC: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000F01F0: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F01F4: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000F01F8: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 0000000F0200: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 0000000F020C: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F0210: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 0000000F0214: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000F0218: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 0000000F0220: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F0228: BF870121
	v_add_f32_e32 v74, v74, v81                                // 0000000F022C: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 0000000F0230: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 0000000F0234: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0238: BF870095
	.long 0xd71c004a                                           // 0000000F023C: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 0000000F0240: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000F0244: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000F0248: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0250: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 0000000F0254: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000F0260: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0264: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000F0268: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 0000000F0270: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0274: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 0000000F0278: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 0000000F0280: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 0000000F0284: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F028C: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 0000000F0290: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 0000000F0294: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F029C: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 0000000F02A0: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 0000000F02A4: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F02AC: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 0000000F02B0: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000F02B8: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 0000000F02C0: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F02CC: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 0000000F02D0: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 0000000F02D8: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000F02E4: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F02EC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F02F0: BE882003
	s_cbranch_execz 62137                                      // 0000000F02F4: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3edc>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 0000000F02F8: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000F0304: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000F030C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000F0310: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0314: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000F0318: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000F0320: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 0000000F032C: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0330: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 0000000F0334: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 0000000F0340: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 0000000F0344: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000F0348: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F0350: BF870293
	v_exp_f32_e32 v74, v74                                     // 0000000F0354: 7E944B4A
	.long 0xd71c004a                                           // 0000000F0358: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000F035C: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F0360: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000F0364: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000F0368: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 0000000F0370: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F037C: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 0000000F0380: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000F0384: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F038C: BF870291
	v_rcp_f32_e32 v76, v75                                     // 0000000F0390: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 0000000F0394: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F039C: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 0000000F03A0: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 0000000F03A4: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 0000000F03AC: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F03B0: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 0000000F03B4: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 0000000F03BC: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F03C0: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 0000000F03C4: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 0000000F03CC: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F03D4: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000F03D8: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 0000000F03E0: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000F03EC: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F03F4: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000F03F8: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000F0404: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F040C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F0410: BE882004
	s_cbranch_execz 62068                                      // 0000000F0414: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ee8>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 0000000F0418: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000F0424: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000F042C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000F0430: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0434: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000F0438: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000F0440: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000F044C: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F0450: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000F0454: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000F0458: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000F0460: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F0468: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000F046C: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000F0470: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000F0474: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0478: BF870095
	.long 0xd71c004a                                           // 0000000F047C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000F0480: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000F0484: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000F0488: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0490: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 0000000F0494: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000F04A0: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F04A4: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000F04A8: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000F04B0: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F04B4: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000F04B8: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000F04C0: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000F04C4: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F04CC: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 0000000F04D0: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 0000000F04D4: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F04DC: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 0000000F04E0: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 0000000F04E4: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F04EC: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 0000000F04F0: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000F04F8: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 0000000F0500: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F050C: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000F0510: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000F0518: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000F0524: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F052C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F0530: BE882005
	s_cbranch_execz 61999                                      // 0000000F0534: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ef4>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 0000000F0538: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000F0544: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000F054C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000F0550: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0554: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000F0558: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000F0560: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000F056C: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F0570: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000F0574: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000F0578: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000F0580: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F0588: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000F058C: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000F0590: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000F0594: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0598: BF870095
	.long 0xd71c004a                                           // 0000000F059C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000F05A0: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000F05A4: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000F05A8: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F05B0: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000000F05B4: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 0000000F05BC: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F05C4: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000F05C8: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000F05D0: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F05D4: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000F05D8: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000F05E0: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000F05E4: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F05EC: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000F05F0: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 0000000F05F4: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F05FC: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 0000000F0600: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 0000000F0604: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F060C: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000F0610: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000F0618: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 0000000F0620: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F062C: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000F0630: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000F0638: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000F0644: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F064C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F0650: BE882006
	s_cbranch_execz 61930                                      // 0000000F0654: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f00>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 0000000F0658: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000F0664: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000F066C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000F0670: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0674: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000F0678: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000F0680: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000F068C: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F0690: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000F0694: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000F0698: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000F06A0: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F06A8: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000F06AC: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000F06B0: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000F06B4: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F06B8: BF870095
	.long 0xd71c004a                                           // 0000000F06BC: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000F06C0: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000F06C4: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000F06C8: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F06D0: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 0000000F06D4: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000F06E0: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F06E4: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000F06E8: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000F06F0: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F06F4: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000F06F8: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000F0700: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000F0704: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F070C: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000F0710: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000F0714: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F071C: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000F0720: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000F0724: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F072C: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000F0730: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000F0738: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 0000000F0740: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F074C: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000F0750: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000F0758: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000F0764: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F076C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F0770: BE882007
	s_cbranch_execz 61861                                      // 0000000F0774: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f0c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 0000000F0778: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000F0784: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000F078C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000F0790: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0794: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000F0798: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000F07A0: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000F07AC: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F07B0: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000F07B4: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000F07B8: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000F07C0: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F07C8: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000F07CC: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000F07D0: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000F07D4: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F07D8: BF870095
	.long 0xd71c004a                                           // 0000000F07DC: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000F07E0: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000F07E4: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000F07E8: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F07F0: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 0000000F07F4: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000F0800: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0804: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000F0808: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000F0810: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0814: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000F0818: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000F0820: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000F0824: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F082C: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000F0830: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000F0834: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F083C: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000F0840: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000F0844: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F084C: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000F0850: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000F0858: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 0000000F0860: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F086C: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000F0870: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000F0878: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000F0884: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F088C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F0890: BE882000
	s_cbranch_execz 61792                                      // 0000000F0894: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f18>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 0000000F0898: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 0000000F08A4: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 0000000F08A8: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000F08B0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000F08B4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F08B8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000F08BC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000F08C4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000F08D0: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F08D4: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000F08D8: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000F08DC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000F08E4: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F08EC: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000F08F0: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000F08F4: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000F08F8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F08FC: BF870095
	.long 0xd71c004a                                           // 0000000F0900: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000F0904: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000F0908: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000F090C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0914: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000000F0918: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000F0920: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0924: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 0000000F0928: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 0000000F0930: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0934: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000000F0938: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000000F0940: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 0000000F0944: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F094C: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 0000000F0950: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 0000000F0954: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F095C: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 0000000F0960: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 0000000F0964: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F096C: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 0000000F0970: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 0000000F0978: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 0000000F0980: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F098C: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 0000000F0990: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 0000000F0998: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 0000000F09A4: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F09AC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F09B0: BE882001
	s_cbranch_execz 61723                                      // 0000000F09B4: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f24>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 0000000F09B8: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 0000000F09C4: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 0000000F09C8: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 0000000F09D0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000F09D4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F09D8: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 0000000F09DC: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000F09E4: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 0000000F09EC: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000000F09F8: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F09FC: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 0000000F0A00: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 0000000F0A08: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F0A0C: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000000F0A10: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000000F0A14: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000000F0A18: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0A1C: BF870095
	.long 0xd71c0049                                           // 0000000F0A20: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000F0A24: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000F0A28: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000F0A2C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0A34: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 0000000F0A38: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000F0A40: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0A44: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 0000000F0A48: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 0000000F0A50: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0A54: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 0000000F0A58: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 0000000F0A60: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 0000000F0A64: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0A6C: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 0000000F0A70: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 0000000F0A74: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0A7C: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 0000000F0A80: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 0000000F0A84: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0A8C: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 0000000F0A90: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 0000000F0A98: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 0000000F0AA0: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0AAC: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 0000000F0AB0: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 0000000F0AB8: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 0000000F0AC4: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F0ACC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F0AD0: BE882002
	s_cbranch_execz 61654                                      // 0000000F0AD4: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f30>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 0000000F0AD8: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000F0AE4: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000F0AEC: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000F0AF0: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0AF4: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000F0AF8: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 0000000F0B00: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 0000000F0B0C: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F0B10: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 0000000F0B14: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000F0B18: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 0000000F0B20: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F0B28: BF870121
	v_add_f32_e32 v66, v66, v73                                // 0000000F0B2C: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 0000000F0B30: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 0000000F0B34: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0B38: BF870095
	.long 0xd71c0042                                           // 0000000F0B3C: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 0000000F0B40: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000F0B44: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000F0B48: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0B50: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 0000000F0B54: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000F0B60: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0B64: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000F0B68: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 0000000F0B70: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0B74: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 0000000F0B78: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 0000000F0B80: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 0000000F0B84: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0B8C: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 0000000F0B90: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 0000000F0B94: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0B9C: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 0000000F0BA0: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 0000000F0BA4: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0BAC: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 0000000F0BB0: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000F0BB8: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 0000000F0BC0: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0BCC: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 0000000F0BD0: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 0000000F0BD8: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000F0BE4: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F0BEC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F0BF0: BE882003
	s_cbranch_execz 61585                                      // 0000000F0BF4: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f3c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 0000000F0BF8: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000F0C04: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000F0C0C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000F0C10: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0C14: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000F0C18: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000F0C20: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 0000000F0C2C: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0C30: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 0000000F0C34: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 0000000F0C40: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 0000000F0C44: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000F0C48: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F0C50: BF870293
	v_exp_f32_e32 v66, v66                                     // 0000000F0C54: 7E844B42
	.long 0xd71c0042                                           // 0000000F0C58: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000F0C5C: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F0C60: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000F0C64: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000F0C68: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 0000000F0C70: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0C7C: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 0000000F0C80: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000F0C84: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F0C8C: BF870291
	v_rcp_f32_e32 v68, v67                                     // 0000000F0C90: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 0000000F0C94: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F0C9C: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 0000000F0CA0: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 0000000F0CA4: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 0000000F0CAC: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0CB0: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 0000000F0CB4: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 0000000F0CBC: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0CC0: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 0000000F0CC4: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 0000000F0CCC: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F0CD4: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000F0CD8: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 0000000F0CE0: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000F0CEC: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F0CF4: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000F0CF8: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000F0D04: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F0D0C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F0D10: BE882004
	s_cbranch_execz 61516                                      // 0000000F0D14: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f48>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 0000000F0D18: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000F0D24: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000F0D2C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000F0D30: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0D34: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000F0D38: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000F0D40: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000F0D4C: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F0D50: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000F0D54: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000F0D58: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000F0D60: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F0D68: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000F0D6C: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000F0D70: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000F0D74: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0D78: BF870095
	.long 0xd71c0042                                           // 0000000F0D7C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000F0D80: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000F0D84: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000F0D88: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0D90: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 0000000F0D94: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000F0DA0: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0DA4: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000F0DA8: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000F0DB0: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0DB4: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000F0DB8: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000F0DC0: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000F0DC4: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0DCC: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 0000000F0DD0: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 0000000F0DD4: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0DDC: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 0000000F0DE0: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 0000000F0DE4: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0DEC: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 0000000F0DF0: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000F0DF8: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 0000000F0E00: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0E0C: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000F0E10: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000F0E18: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000F0E24: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F0E2C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F0E30: BE882005
	s_cbranch_execz 61447                                      // 0000000F0E34: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f54>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 0000000F0E38: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000F0E44: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000F0E4C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000F0E50: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0E54: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000F0E58: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000F0E60: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000F0E6C: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F0E70: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000F0E74: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000F0E78: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000F0E80: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F0E88: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000F0E8C: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000F0E90: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000F0E94: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0E98: BF870095
	.long 0xd71c0042                                           // 0000000F0E9C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000F0EA0: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000F0EA4: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000F0EA8: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0EB0: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 0000000F0EB4: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 0000000F0EBC: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0EC4: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000F0EC8: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000F0ED0: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0ED4: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000F0ED8: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000F0EE0: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000F0EE4: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0EEC: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000F0EF0: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 0000000F0EF4: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0EFC: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 0000000F0F00: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 0000000F0F04: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0F0C: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000F0F10: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000F0F18: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 0000000F0F20: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0F2C: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000F0F30: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000F0F38: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000F0F44: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F0F4C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F0F50: BE882006
	s_cbranch_execz 61378                                      // 0000000F0F54: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f60>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 0000000F0F58: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000F0F64: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000F0F6C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000F0F70: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0F74: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000F0F78: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000F0F80: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000F0F8C: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F0F90: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000F0F94: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000F0F98: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000F0FA0: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F0FA8: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000F0FAC: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000F0FB0: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000F0FB4: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0FB8: BF870095
	.long 0xd71c0042                                           // 0000000F0FBC: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000F0FC0: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000F0FC4: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000F0FC8: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0FD0: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 0000000F0FD4: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000F0FE0: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0FE4: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000F0FE8: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000F0FF0: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F0FF4: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000F0FF8: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000F1000: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000F1004: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F100C: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000F1010: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000F1014: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F101C: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000F1020: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000F1024: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F102C: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000F1030: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000F1038: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 0000000F1040: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F104C: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000F1050: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000F1058: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000F1064: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F106C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F1070: BE882007
	s_cbranch_execz 61309                                      // 0000000F1074: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f6c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 0000000F1078: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000F1084: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000F108C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000F1090: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1094: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000F1098: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000F10A0: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000F10AC: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F10B0: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000F10B4: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000F10B8: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000F10C0: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F10C8: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000F10CC: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000F10D0: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000F10D4: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F10D8: BF870095
	.long 0xd71c0042                                           // 0000000F10DC: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000F10E0: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000F10E4: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000F10E8: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F10F0: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 0000000F10F4: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000F1100: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1104: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000F1108: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000F1110: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1114: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000F1118: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000F1120: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000F1124: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F112C: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000F1130: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000F1134: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F113C: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000F1140: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000F1144: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F114C: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000F1150: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000F1158: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 0000000F1160: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F116C: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000F1170: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000F1178: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000F1184: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F118C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F1190: BE882000
	s_cbranch_execz 61240                                      // 0000000F1194: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f78>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 0000000F1198: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 0000000F11A4: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 0000000F11A8: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000F11B0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000F11B4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F11B8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000F11BC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000F11C4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000F11D0: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F11D4: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000F11D8: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000F11DC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000F11E4: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F11EC: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000F11F0: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000F11F4: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000F11F8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F11FC: BF870095
	.long 0xd71c0042                                           // 0000000F1200: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000F1204: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000F1208: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000F120C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1214: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 0000000F1218: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000F1220: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1224: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 0000000F1228: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 0000000F1230: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1234: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 0000000F1238: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 0000000F1240: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 0000000F1244: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F124C: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 0000000F1250: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 0000000F1254: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F125C: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 0000000F1260: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 0000000F1264: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F126C: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 0000000F1270: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 0000000F1278: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 0000000F1280: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F128C: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 0000000F1290: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 0000000F1298: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 0000000F12A4: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F12AC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F12B0: BE882001
	s_cbranch_execz 61171                                      // 0000000F12B4: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f84>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 0000000F12B8: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 0000000F12C4: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 0000000F12C8: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 0000000F12D0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000F12D4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F12D8: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 0000000F12DC: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000F12E4: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 0000000F12EC: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 0000000F12F8: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F12FC: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 0000000F1300: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 0000000F1308: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F130C: BF870121
	v_add_f32_e32 v65, v65, v66                                // 0000000F1310: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 0000000F1314: 7E841143
	v_exp_f32_e32 v65, v65                                     // 0000000F1318: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F131C: BF870095
	.long 0xd71c0041                                           // 0000000F1320: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 0000000F1324: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 0000000F1328: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000F132C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1334: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 0000000F1338: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000F1340: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1344: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 0000000F1348: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 0000000F1350: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1354: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 0000000F1358: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 0000000F1360: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 0000000F1364: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F136C: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 0000000F1370: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 0000000F1374: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F137C: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 0000000F1380: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 0000000F1384: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F138C: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 0000000F1390: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 0000000F1398: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 0000000F13A0: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F13AC: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 0000000F13B0: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 0000000F13B8: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 0000000F13C4: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F13CC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F13D0: BE882002
	s_cbranch_execz 61102                                      // 0000000F13D4: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f90>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 0000000F13D8: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000F13E4: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000F13EC: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000F13F0: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F13F4: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000F13F8: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 0000000F1400: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 0000000F140C: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F1410: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 0000000F1414: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000F1418: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 0000000F1420: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F1428: BF870121
	v_add_f32_e32 v58, v58, v65                                // 0000000F142C: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 0000000F1430: 7E821142
	v_exp_f32_e32 v58, v58                                     // 0000000F1434: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1438: BF870095
	.long 0xd71c003a                                           // 0000000F143C: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 0000000F1440: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000F1444: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000F1448: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1450: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 0000000F1454: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000F1460: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1464: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000F1468: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 0000000F1470: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1474: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 0000000F1478: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 0000000F1480: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 0000000F1484: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F148C: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 0000000F1490: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 0000000F1494: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F149C: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 0000000F14A0: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 0000000F14A4: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F14AC: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 0000000F14B0: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000F14B8: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 0000000F14C0: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F14CC: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 0000000F14D0: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 0000000F14D8: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000F14E4: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F14EC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F14F0: BE882003
	s_cbranch_execz 61033                                      // 0000000F14F4: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f9c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 0000000F14F8: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000F1504: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000F150C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000F1510: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1514: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000F1518: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000F1520: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 0000000F152C: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1530: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 0000000F1534: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 0000000F1540: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 0000000F1544: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000F1548: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F1550: BF870293
	v_exp_f32_e32 v58, v58                                     // 0000000F1554: 7E744B3A
	.long 0xd71c003a                                           // 0000000F1558: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000F155C: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F1560: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000F1564: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000F1568: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 0000000F1570: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F157C: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 0000000F1580: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000F1584: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F158C: BF870291
	v_rcp_f32_e32 v60, v59                                     // 0000000F1590: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 0000000F1594: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F159C: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 0000000F15A0: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 0000000F15A4: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 0000000F15AC: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F15B0: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 0000000F15B4: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 0000000F15BC: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F15C0: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 0000000F15C4: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 0000000F15CC: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F15D4: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000F15D8: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 0000000F15E0: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000F15EC: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F15F4: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000F15F8: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000F1604: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F160C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F1610: BE882004
	s_cbranch_execz 60964                                      // 0000000F1614: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fa8>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 0000000F1618: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000F1624: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000F162C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000F1630: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1634: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000F1638: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000F1640: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000F164C: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F1650: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000F1654: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000F1658: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000F1660: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F1668: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000F166C: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000F1670: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000F1674: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1678: BF870095
	.long 0xd71c003a                                           // 0000000F167C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000F1680: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000F1684: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000F1688: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1690: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 0000000F1694: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000F16A0: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F16A4: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000F16A8: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000F16B0: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F16B4: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000F16B8: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000F16C0: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000F16C4: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F16CC: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 0000000F16D0: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 0000000F16D4: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F16DC: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 0000000F16E0: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 0000000F16E4: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F16EC: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 0000000F16F0: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000F16F8: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 0000000F1700: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F170C: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000F1710: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000F1718: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000F1724: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F172C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F1730: BE882005
	s_cbranch_execz 60895                                      // 0000000F1734: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fb4>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 0000000F1738: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000F1744: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000F174C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000F1750: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1754: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000F1758: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000F1760: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000F176C: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F1770: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000F1774: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000F1778: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000F1780: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F1788: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000F178C: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000F1790: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000F1794: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1798: BF870095
	.long 0xd71c003a                                           // 0000000F179C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000F17A0: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000F17A4: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000F17A8: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F17B0: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000F17B4: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 0000000F17BC: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F17C4: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000F17C8: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000F17D0: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F17D4: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000F17D8: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000F17E0: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000F17E4: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F17EC: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000F17F0: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 0000000F17F4: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F17FC: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 0000000F1800: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 0000000F1804: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F180C: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000F1810: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000F1818: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 0000000F1820: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F182C: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000F1830: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000F1838: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000F1844: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F184C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F1850: BE882006
	s_cbranch_execz 60826                                      // 0000000F1854: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fc0>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 0000000F1858: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000F1864: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000F186C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000F1870: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1874: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000F1878: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000F1880: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000F188C: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F1890: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000F1894: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000F1898: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000F18A0: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F18A8: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000F18AC: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000F18B0: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000F18B4: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F18B8: BF870095
	.long 0xd71c003a                                           // 0000000F18BC: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000F18C0: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000F18C4: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000F18C8: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F18D0: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 0000000F18D4: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000F18E0: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F18E4: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000F18E8: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000F18F0: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F18F4: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000F18F8: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000F1900: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000F1904: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F190C: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000F1910: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000F1914: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F191C: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000F1920: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000F1924: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F192C: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000F1930: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000F1938: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 0000000F1940: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F194C: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000F1950: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000F1958: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000F1964: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F196C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F1970: BE882007
	s_cbranch_execz 60757                                      // 0000000F1974: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fcc>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 0000000F1978: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000F1984: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000F198C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000F1990: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1994: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000F1998: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000F19A0: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000F19AC: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F19B0: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000F19B4: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000F19B8: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000F19C0: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F19C8: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000F19CC: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000F19D0: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000F19D4: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F19D8: BF870095
	.long 0xd71c003a                                           // 0000000F19DC: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000F19E0: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000F19E4: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000F19E8: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F19F0: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 0000000F19F4: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000F1A00: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1A04: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000F1A08: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000F1A10: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1A14: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000F1A18: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000F1A20: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000F1A24: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1A2C: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000F1A30: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000F1A34: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1A3C: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000F1A40: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000F1A44: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1A4C: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000F1A50: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000F1A58: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 0000000F1A60: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1A6C: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000F1A70: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000F1A78: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000F1A84: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F1A8C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F1A90: BE882000
	s_cbranch_execz 60688                                      // 0000000F1A94: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fd8>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 0000000F1A98: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 0000000F1AA4: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 0000000F1AA8: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000F1AB0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000F1AB4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1AB8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000F1ABC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000F1AC4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000F1AD0: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F1AD4: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000F1AD8: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000F1ADC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000F1AE4: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F1AEC: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000F1AF0: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000F1AF4: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000F1AF8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1AFC: BF870095
	.long 0xd71c003a                                           // 0000000F1B00: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000F1B04: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000F1B08: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000F1B0C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1B14: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000F1B18: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000F1B20: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1B24: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 0000000F1B28: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 0000000F1B30: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1B34: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 0000000F1B38: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 0000000F1B40: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 0000000F1B44: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1B4C: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 0000000F1B50: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 0000000F1B54: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1B5C: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 0000000F1B60: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 0000000F1B64: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1B6C: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 0000000F1B70: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 0000000F1B78: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 0000000F1B80: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1B8C: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 0000000F1B90: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 0000000F1B98: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 0000000F1BA4: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F1BAC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F1BB0: BE882001
	s_cbranch_execz 60619                                      // 0000000F1BB4: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fe4>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 0000000F1BB8: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 0000000F1BC4: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 0000000F1BC8: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 0000000F1BD0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000F1BD4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F1BD8: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 0000000F1BDC: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000F1BE4: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 0000000F1BEC: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 0000000F1BF8: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F1BFC: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 0000000F1C00: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 0000000F1C08: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F1C0C: BF870121
	v_add_f32_e32 v57, v57, v58                                // 0000000F1C10: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 0000000F1C14: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 0000000F1C18: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1C1C: BF870095
	.long 0xd71c0039                                           // 0000000F1C20: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000000F1C24: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000F1C28: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000F1C2C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1C34: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 0000000F1C38: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000F1C40: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1C44: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 0000000F1C48: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 0000000F1C50: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1C54: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 0000000F1C58: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 0000000F1C60: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 0000000F1C64: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1C6C: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 0000000F1C70: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 0000000F1C74: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1C7C: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 0000000F1C80: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 0000000F1C84: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1C8C: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 0000000F1C90: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 0000000F1C98: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 0000000F1CA0: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1CAC: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 0000000F1CB0: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000000F1CB8: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 0000000F1CC4: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F1CCC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F1CD0: BE882002
	s_cbranch_execz 60550                                      // 0000000F1CD4: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ff0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 0000000F1CD8: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000F1CE4: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000F1CEC: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000F1CF0: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1CF4: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000F1CF8: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 0000000F1D00: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 0000000F1D0C: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F1D10: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 0000000F1D14: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000F1D18: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 0000000F1D20: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F1D28: BF870121
	v_add_f32_e32 v50, v50, v57                                // 0000000F1D2C: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 0000000F1D30: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 0000000F1D34: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1D38: BF870095
	.long 0xd71c0032                                           // 0000000F1D3C: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 0000000F1D40: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000F1D44: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000F1D48: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1D50: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 0000000F1D54: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000F1D60: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1D64: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000F1D68: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 0000000F1D70: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1D74: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 0000000F1D78: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 0000000F1D80: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 0000000F1D84: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1D8C: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 0000000F1D90: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 0000000F1D94: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1D9C: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 0000000F1DA0: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 0000000F1DA4: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1DAC: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 0000000F1DB0: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000F1DB8: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 0000000F1DC0: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1DCC: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 0000000F1DD0: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 0000000F1DD8: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000F1DE4: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F1DEC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F1DF0: BE882003
	s_cbranch_execz 60481                                      // 0000000F1DF4: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ffc>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 0000000F1DF8: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000F1E04: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000F1E0C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000F1E10: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1E14: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000F1E18: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000F1E20: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 0000000F1E2C: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1E30: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 0000000F1E34: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 0000000F1E40: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 0000000F1E44: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000F1E48: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F1E50: BF870293
	v_exp_f32_e32 v50, v50                                     // 0000000F1E54: 7E644B32
	.long 0xd71c0032                                           // 0000000F1E58: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000F1E5C: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F1E60: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000F1E64: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000F1E68: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 0000000F1E70: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1E7C: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 0000000F1E80: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000F1E84: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F1E8C: BF870291
	v_rcp_f32_e32 v52, v51                                     // 0000000F1E90: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 0000000F1E94: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F1E9C: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 0000000F1EA0: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 0000000F1EA4: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 0000000F1EAC: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1EB0: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 0000000F1EB4: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 0000000F1EBC: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1EC0: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 0000000F1EC4: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 0000000F1ECC: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F1ED4: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000F1ED8: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 0000000F1EE0: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000F1EEC: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F1EF4: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000F1EF8: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000F1F04: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F1F0C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F1F10: BE882004
	s_cbranch_execz 60412                                      // 0000000F1F14: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4008>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 0000000F1F18: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000F1F24: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000F1F2C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000F1F30: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1F34: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000F1F38: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000F1F40: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000F1F4C: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F1F50: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000F1F54: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000F1F58: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000F1F60: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F1F68: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000F1F6C: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000F1F70: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000F1F74: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1F78: BF870095
	.long 0xd71c0032                                           // 0000000F1F7C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000F1F80: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000F1F84: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000F1F88: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1F90: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 0000000F1F94: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000F1FA0: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1FA4: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000F1FA8: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000F1FB0: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1FB4: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000F1FB8: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000F1FC0: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000F1FC4: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1FCC: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 0000000F1FD0: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 0000000F1FD4: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1FDC: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 0000000F1FE0: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 0000000F1FE4: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1FEC: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 0000000F1FF0: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000F1FF8: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 0000000F2000: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F200C: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000F2010: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000F2018: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000F2024: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F202C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F2030: BE882005
	s_cbranch_execz 60343                                      // 0000000F2034: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4014>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 0000000F2038: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000F2044: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000F204C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000F2050: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2054: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000F2058: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000F2060: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000F206C: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F2070: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000F2074: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000F2078: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000F2080: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F2088: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000F208C: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000F2090: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000F2094: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2098: BF870095
	.long 0xd71c0032                                           // 0000000F209C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000F20A0: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000F20A4: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000F20A8: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F20B0: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 0000000F20B4: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 0000000F20BC: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F20C4: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000F20C8: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000F20D0: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F20D4: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000F20D8: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000F20E0: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000F20E4: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F20EC: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000F20F0: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 0000000F20F4: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F20FC: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 0000000F2100: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 0000000F2104: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F210C: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000F2110: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000F2118: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 0000000F2120: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F212C: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000F2130: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000F2138: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000F2144: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F214C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F2150: BE882006
	s_cbranch_execz 60274                                      // 0000000F2154: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4020>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 0000000F2158: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000F2164: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000F216C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000F2170: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2174: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000F2178: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000F2180: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000F218C: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F2190: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000F2194: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000F2198: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000F21A0: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F21A8: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000F21AC: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000F21B0: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000F21B4: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F21B8: BF870095
	.long 0xd71c0032                                           // 0000000F21BC: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000F21C0: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000F21C4: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000F21C8: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F21D0: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 0000000F21D4: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000F21E0: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F21E4: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000F21E8: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000F21F0: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F21F4: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000F21F8: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000F2200: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000F2204: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F220C: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000F2210: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 0000000F2214: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F221C: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 0000000F2220: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000F2224: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F222C: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000F2230: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000F2238: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 0000000F2240: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F224C: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000F2250: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000F2258: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000F2264: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F226C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F2270: BE882007
	s_cbranch_execz 60205                                      // 0000000F2274: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x402c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 0000000F2278: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000F2284: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000F228C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000F2290: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2294: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000F2298: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000F22A0: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000F22AC: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F22B0: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000F22B4: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000F22B8: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000F22C0: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F22C8: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000F22CC: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000F22D0: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000F22D4: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F22D8: BF870095
	.long 0xd71c0032                                           // 0000000F22DC: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000F22E0: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000F22E4: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000F22E8: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F22F0: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 0000000F22F4: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000F2300: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2304: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000F2308: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000F2310: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2314: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000F2318: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000F2320: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000F2324: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F232C: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000F2330: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 0000000F2334: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F233C: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 0000000F2340: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000F2344: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F234C: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000F2350: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000F2358: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 0000000F2360: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F236C: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000F2370: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000F2378: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000F2384: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F238C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F2390: BE882000
	s_cbranch_execz 60136                                      // 0000000F2394: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4038>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 0000000F2398: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 0000000F23A4: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 0000000F23A8: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000F23B0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000F23B4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F23B8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000F23BC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000F23C4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000F23D0: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F23D4: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000F23D8: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000F23DC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000F23E4: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F23EC: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000F23F0: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000F23F4: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000F23F8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F23FC: BF870095
	.long 0xd71c0032                                           // 0000000F2400: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000F2404: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000F2408: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000F240C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2414: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 0000000F2418: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000F2420: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2424: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 0000000F2428: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 0000000F2430: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2434: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 0000000F2438: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 0000000F2440: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 0000000F2444: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F244C: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 0000000F2450: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 0000000F2454: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F245C: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 0000000F2460: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 0000000F2464: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F246C: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 0000000F2470: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 0000000F2478: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 0000000F2480: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F248C: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 0000000F2490: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 0000000F2498: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 0000000F24A4: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F24AC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F24B0: BE882001
	s_cbranch_execz 60067                                      // 0000000F24B4: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4044>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 0000000F24B8: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 0000000F24C4: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 0000000F24C8: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 0000000F24D0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000F24D4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F24D8: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 0000000F24DC: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000F24E4: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 0000000F24EC: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 0000000F24F8: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F24FC: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 0000000F2500: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 0000000F2508: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F250C: BF870121
	v_add_f32_e32 v49, v49, v50                                // 0000000F2510: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 0000000F2514: 7E641133
	v_exp_f32_e32 v49, v49                                     // 0000000F2518: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F251C: BF870095
	.long 0xd71c0031                                           // 0000000F2520: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 0000000F2524: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000000F2528: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000F252C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2534: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 0000000F2538: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000F2540: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2544: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 0000000F2548: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 0000000F2550: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2554: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 0000000F2558: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 0000000F2560: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 0000000F2564: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F256C: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 0000000F2570: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 0000000F2574: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F257C: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 0000000F2580: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 0000000F2584: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F258C: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 0000000F2590: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 0000000F2598: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 0000000F25A0: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F25AC: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 0000000F25B0: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 0000000F25B8: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 0000000F25C4: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F25CC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F25D0: BE882002
	s_cbranch_execz 59998                                      // 0000000F25D4: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4050>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 0000000F25D8: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000F25E4: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000F25EC: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000F25F0: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F25F4: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000F25F8: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 0000000F2600: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 0000000F260C: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F2610: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 0000000F2614: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000F2618: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 0000000F2620: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F2628: BF870121
	v_add_f32_e32 v42, v42, v49                                // 0000000F262C: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 0000000F2630: 7E621132
	v_exp_f32_e32 v42, v42                                     // 0000000F2634: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2638: BF870095
	.long 0xd71c002a                                           // 0000000F263C: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 0000000F2640: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000F2644: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000F2648: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2650: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 0000000F2654: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000F2660: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2664: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000F2668: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 0000000F2670: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2674: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 0000000F2678: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 0000000F2680: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 0000000F2684: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F268C: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 0000000F2690: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 0000000F2694: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F269C: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 0000000F26A0: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 0000000F26A4: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F26AC: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 0000000F26B0: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000F26B8: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 0000000F26C0: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F26CC: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 0000000F26D0: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 0000000F26D8: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000F26E4: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F26EC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F26F0: BE882003
	s_cbranch_execz 59929                                      // 0000000F26F4: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x405c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 0000000F26F8: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000F2704: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000F270C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000F2710: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2714: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000F2718: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000F2720: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 0000000F272C: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2730: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 0000000F2734: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 0000000F2740: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 0000000F2744: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000F2748: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F2750: BF870293
	v_exp_f32_e32 v42, v42                                     // 0000000F2754: 7E544B2A
	.long 0xd71c002a                                           // 0000000F2758: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000F275C: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F2760: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000F2764: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000F2768: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 0000000F2770: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F277C: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 0000000F2780: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000F2784: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F278C: BF870291
	v_rcp_f32_e32 v44, v43                                     // 0000000F2790: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 0000000F2794: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F279C: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 0000000F27A0: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 0000000F27A4: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 0000000F27AC: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F27B0: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 0000000F27B4: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 0000000F27BC: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F27C0: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 0000000F27C4: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 0000000F27CC: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F27D4: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000F27D8: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 0000000F27E0: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000F27EC: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F27F4: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000F27F8: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000F2804: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F280C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F2810: BE882004
	s_cbranch_execz 59860                                      // 0000000F2814: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4068>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 0000000F2818: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000F2824: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000F282C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000F2830: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2834: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000F2838: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000F2840: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000F284C: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F2850: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000F2854: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000F2858: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000F2860: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F2868: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000F286C: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000F2870: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000F2874: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2878: BF870095
	.long 0xd71c002a                                           // 0000000F287C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000F2880: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000F2884: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000F2888: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2890: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 0000000F2894: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000F28A0: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F28A4: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000F28A8: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000F28B0: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F28B4: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000F28B8: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000F28C0: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000F28C4: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F28CC: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 0000000F28D0: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 0000000F28D4: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F28DC: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 0000000F28E0: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 0000000F28E4: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F28EC: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 0000000F28F0: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000F28F8: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 0000000F2900: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F290C: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000F2910: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000F2918: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000F2924: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F292C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F2930: BE882005
	s_cbranch_execz 59791                                      // 0000000F2934: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4074>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 0000000F2938: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000F2944: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000F294C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000F2950: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2954: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000F2958: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000F2960: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000F296C: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F2970: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000F2974: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000F2978: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000F2980: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F2988: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000F298C: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000F2990: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000F2994: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2998: BF870095
	.long 0xd71c002a                                           // 0000000F299C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000F29A0: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000F29A4: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000F29A8: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F29B0: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000F29B4: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 0000000F29BC: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F29C4: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000F29C8: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000F29D0: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F29D4: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000F29D8: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000F29E0: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000F29E4: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F29EC: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000F29F0: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 0000000F29F4: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F29FC: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 0000000F2A00: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 0000000F2A04: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2A0C: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000F2A10: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000F2A18: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 0000000F2A20: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2A2C: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000F2A30: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000F2A38: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000F2A44: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F2A4C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F2A50: BE882006
	s_cbranch_execz 59722                                      // 0000000F2A54: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4080>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 0000000F2A58: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000F2A64: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000F2A6C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000F2A70: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2A74: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000F2A78: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000F2A80: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000F2A8C: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F2A90: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000F2A94: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000F2A98: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000F2AA0: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F2AA8: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000F2AAC: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000F2AB0: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000F2AB4: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2AB8: BF870095
	.long 0xd71c002a                                           // 0000000F2ABC: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000F2AC0: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000F2AC4: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000F2AC8: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2AD0: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 0000000F2AD4: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000F2AE0: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2AE4: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000F2AE8: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000F2AF0: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2AF4: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000F2AF8: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000F2B00: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000F2B04: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2B0C: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000F2B10: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000F2B14: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2B1C: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000F2B20: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000F2B24: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2B2C: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000F2B30: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000F2B38: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 0000000F2B40: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2B4C: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000F2B50: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000F2B58: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000F2B64: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F2B6C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F2B70: BE882007
	s_cbranch_execz 59653                                      // 0000000F2B74: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x408c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 0000000F2B78: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000F2B84: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000F2B8C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000F2B90: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2B94: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000F2B98: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000F2BA0: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000F2BAC: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F2BB0: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000F2BB4: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000F2BB8: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000F2BC0: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F2BC8: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000F2BCC: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000F2BD0: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000F2BD4: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2BD8: BF870095
	.long 0xd71c002a                                           // 0000000F2BDC: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000F2BE0: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000F2BE4: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000F2BE8: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2BF0: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 0000000F2BF4: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000F2C00: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2C04: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000F2C08: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000F2C10: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2C14: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000F2C18: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000F2C20: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000F2C24: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2C2C: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000F2C30: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000F2C34: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2C3C: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000F2C40: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000F2C44: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2C4C: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000F2C50: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000F2C58: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 0000000F2C60: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2C6C: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000F2C70: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000F2C78: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000F2C84: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F2C8C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F2C90: BE882000
	s_cbranch_execz 59584                                      // 0000000F2C94: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4098>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 0000000F2C98: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 0000000F2CA4: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 0000000F2CA8: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000F2CB0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000F2CB4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2CB8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000F2CBC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000F2CC4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000F2CD0: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F2CD4: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000F2CD8: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000F2CDC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000F2CE4: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F2CEC: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000F2CF0: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000F2CF4: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000F2CF8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2CFC: BF870095
	.long 0xd71c002a                                           // 0000000F2D00: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000F2D04: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000F2D08: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000F2D0C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2D14: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000F2D18: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000F2D20: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2D24: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 0000000F2D28: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 0000000F2D30: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2D34: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000000F2D38: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000000F2D40: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 0000000F2D44: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2D4C: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 0000000F2D50: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 0000000F2D54: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2D5C: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 0000000F2D60: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 0000000F2D64: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2D6C: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 0000000F2D70: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 0000000F2D78: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 0000000F2D80: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2D8C: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 0000000F2D90: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 0000000F2D98: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 0000000F2DA4: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F2DAC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F2DB0: BE882001
	s_cbranch_execz 59515                                      // 0000000F2DB4: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40a4>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 0000000F2DB8: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 0000000F2DC4: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 0000000F2DC8: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 0000000F2DD0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000F2DD4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F2DD8: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 0000000F2DDC: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000F2DE4: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 0000000F2DEC: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000000F2DF8: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F2DFC: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 0000000F2E00: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 0000000F2E08: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F2E0C: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000000F2E10: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000000F2E14: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 0000000F2E18: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2E1C: BF870095
	.long 0xd71c0029                                           // 0000000F2E20: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000000F2E24: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000F2E28: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000F2E2C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2E34: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 0000000F2E38: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000F2E40: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2E44: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 0000000F2E48: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 0000000F2E50: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2E54: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 0000000F2E58: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 0000000F2E60: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 0000000F2E64: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2E6C: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 0000000F2E70: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 0000000F2E74: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2E7C: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 0000000F2E80: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 0000000F2E84: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2E8C: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 0000000F2E90: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 0000000F2E98: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 0000000F2EA0: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2EAC: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 0000000F2EB0: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 0000000F2EB8: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 0000000F2EC4: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F2ECC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F2ED0: BE882002
	s_cbranch_execz 59446                                      // 0000000F2ED4: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40b0>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 0000000F2ED8: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000F2EE4: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000F2EEC: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000F2EF0: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2EF4: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000F2EF8: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 0000000F2F00: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 0000000F2F0C: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F2F10: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 0000000F2F14: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000F2F18: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 0000000F2F20: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F2F28: BF870121
	v_add_f32_e32 v34, v34, v41                                // 0000000F2F2C: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 0000000F2F30: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 0000000F2F34: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2F38: BF870095
	.long 0xd71c0022                                           // 0000000F2F3C: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 0000000F2F40: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000F2F44: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000F2F48: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2F50: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 0000000F2F54: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000F2F60: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2F64: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000F2F68: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 0000000F2F70: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2F74: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 0000000F2F78: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 0000000F2F80: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 0000000F2F84: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2F8C: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 0000000F2F90: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 0000000F2F94: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2F9C: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 0000000F2FA0: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 0000000F2FA4: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2FAC: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 0000000F2FB0: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000F2FB8: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 0000000F2FC0: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2FCC: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 0000000F2FD0: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 0000000F2FD8: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000F2FE4: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F2FEC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F2FF0: BE882003
	s_cbranch_execz 59377                                      // 0000000F2FF4: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40bc>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 0000000F2FF8: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000F3004: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000F300C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000F3010: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3014: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000F3018: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000F3020: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 0000000F302C: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3030: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 0000000F3034: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 0000000F3040: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 0000000F3044: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000F3048: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F3050: BF870293
	v_exp_f32_e32 v34, v34                                     // 0000000F3054: 7E444B22
	.long 0xd71c0022                                           // 0000000F3058: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000F305C: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F3060: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000F3064: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000F3068: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 0000000F3070: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F307C: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 0000000F3080: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000F3084: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F308C: BF870291
	v_rcp_f32_e32 v36, v35                                     // 0000000F3090: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 0000000F3094: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F309C: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 0000000F30A0: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 0000000F30A4: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 0000000F30AC: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F30B0: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 0000000F30B4: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 0000000F30BC: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F30C0: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 0000000F30C4: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 0000000F30CC: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F30D4: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000F30D8: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 0000000F30E0: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000F30EC: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F30F4: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000F30F8: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000F3104: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F310C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F3110: BE882004
	s_cbranch_execz 59308                                      // 0000000F3114: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40c8>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 0000000F3118: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000F3124: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000F312C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000F3130: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3134: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000F3138: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000F3140: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000F314C: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F3150: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000F3154: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000F3158: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000F3160: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F3168: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000F316C: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000F3170: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000F3174: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3178: BF870095
	.long 0xd71c0022                                           // 0000000F317C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000F3180: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000F3184: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000F3188: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3190: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 0000000F3194: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000F31A0: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F31A4: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000F31A8: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000F31B0: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F31B4: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000F31B8: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000F31C0: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000F31C4: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F31CC: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 0000000F31D0: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 0000000F31D4: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F31DC: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 0000000F31E0: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 0000000F31E4: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F31EC: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 0000000F31F0: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000F31F8: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 0000000F3200: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F320C: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000F3210: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000F3218: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000F3224: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F322C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F3230: BE882005
	s_cbranch_execz 59239                                      // 0000000F3234: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40d4>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 0000000F3238: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000F3244: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000F324C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000F3250: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3254: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000F3258: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000F3260: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000F326C: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F3270: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000F3274: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000F3278: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000F3280: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F3288: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000F328C: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000F3290: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000F3294: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3298: BF870095
	.long 0xd71c0022                                           // 0000000F329C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000F32A0: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000F32A4: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000F32A8: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F32B0: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000000F32B4: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 0000000F32BC: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F32C4: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000F32C8: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000F32D0: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F32D4: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000F32D8: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000F32E0: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000F32E4: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F32EC: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000F32F0: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 0000000F32F4: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F32FC: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 0000000F3300: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 0000000F3304: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F330C: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000F3310: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000F3318: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 0000000F3320: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F332C: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000F3330: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000F3338: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000F3344: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F334C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F3350: BE882006
	s_cbranch_execz 59170                                      // 0000000F3354: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40e0>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 0000000F3358: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000F3364: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000F336C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000F3370: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3374: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000F3378: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000F3380: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000F338C: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F3390: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000F3394: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000F3398: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000F33A0: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F33A8: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000F33AC: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000F33B0: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000F33B4: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F33B8: BF870095
	.long 0xd71c0022                                           // 0000000F33BC: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000F33C0: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000F33C4: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000F33C8: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F33D0: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 0000000F33D4: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000F33E0: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F33E4: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000F33E8: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000F33F0: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F33F4: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000F33F8: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000F3400: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000F3404: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F340C: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000F3410: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 0000000F3414: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F341C: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 0000000F3420: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000000F3424: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F342C: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000F3430: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000F3438: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 0000000F3440: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F344C: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000F3450: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000F3458: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000F3464: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F346C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F3470: BE882007
	s_cbranch_execz 59101                                      // 0000000F3474: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40ec>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 0000000F3478: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000F3484: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000F348C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000F3490: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3494: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000F3498: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000F34A0: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000F34AC: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F34B0: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000F34B4: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000F34B8: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000F34C0: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F34C8: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000F34CC: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000F34D0: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000F34D4: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F34D8: BF870095
	.long 0xd71c0022                                           // 0000000F34DC: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000F34E0: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000F34E4: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000F34E8: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F34F0: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 0000000F34F4: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000F3500: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3504: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000F3508: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000F3510: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3514: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000F3518: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000F3520: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000F3524: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F352C: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000F3530: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 0000000F3534: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F353C: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 0000000F3540: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000000F3544: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F354C: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000F3550: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000F3558: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 0000000F3560: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F356C: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000F3570: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000F3578: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000F3584: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F358C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F3590: BE882000
	s_cbranch_execz 59032                                      // 0000000F3594: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40f8>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 0000000F3598: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 0000000F35A4: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 0000000F35A8: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000F35B0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000F35B4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F35B8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000F35BC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000F35C4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000F35D0: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F35D4: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000F35D8: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000F35DC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000F35E4: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F35EC: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000F35F0: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000F35F4: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000F35F8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F35FC: BF870095
	.long 0xd71c0022                                           // 0000000F3600: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000F3604: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000F3608: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000F360C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3614: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000000F3618: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000F3620: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3624: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 0000000F3628: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 0000000F3630: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3634: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000000F3638: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000000F3640: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 0000000F3644: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F364C: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 0000000F3650: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 0000000F3654: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F365C: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 0000000F3660: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 0000000F3664: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F366C: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 0000000F3670: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 0000000F3678: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 0000000F3680: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F368C: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 0000000F3690: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 0000000F3698: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 0000000F36A4: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F36AC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F36B0: BE882001
	s_cbranch_execz 58963                                      // 0000000F36B4: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4104>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 0000000F36B8: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 0000000F36C4: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 0000000F36C8: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 0000000F36D0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000F36D4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F36D8: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 0000000F36DC: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000F36E4: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 0000000F36EC: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000000F36F8: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F36FC: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 0000000F3700: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 0000000F3708: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F370C: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000000F3710: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 0000000F3714: 7E441123
	v_exp_f32_e32 v33, v33                                     // 0000000F3718: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F371C: BF870095
	.long 0xd71c0021                                           // 0000000F3720: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000F3724: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000F3728: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000F372C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3734: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 0000000F3738: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000F3740: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3744: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 0000000F3748: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 0000000F3750: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3754: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 0000000F3758: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 0000000F3760: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 0000000F3764: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F376C: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 0000000F3770: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 0000000F3774: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F377C: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 0000000F3780: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 0000000F3784: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F378C: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 0000000F3790: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 0000000F3798: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 0000000F37A0: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F37AC: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 0000000F37B0: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 0000000F37B8: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 0000000F37C4: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F37CC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F37D0: BE882002
	s_cbranch_execz 58894                                      // 0000000F37D4: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4110>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 0000000F37D8: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000F37E4: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000F37EC: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000F37F0: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F37F4: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000F37F8: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 0000000F3800: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 0000000F380C: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F3810: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 0000000F3814: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000F3818: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 0000000F3820: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F3828: BF870121
	v_add_f32_e32 v26, v26, v33                                // 0000000F382C: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000F3830: 7E421122
	v_exp_f32_e32 v26, v26                                     // 0000000F3834: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3838: BF870095
	.long 0xd71c001a                                           // 0000000F383C: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 0000000F3840: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000F3844: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000F3848: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3850: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 0000000F3854: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000F3860: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3864: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000F3868: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 0000000F3870: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3874: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 0000000F3878: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 0000000F3880: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 0000000F3884: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F388C: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 0000000F3890: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 0000000F3894: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F389C: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 0000000F38A0: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 0000000F38A4: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F38AC: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 0000000F38B0: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000F38B8: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 0000000F38C0: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F38CC: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 0000000F38D0: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 0000000F38D8: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000F38E4: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F38EC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F38F0: BE882003
	s_cbranch_execz 58825                                      // 0000000F38F4: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x411c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 0000000F38F8: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000F3904: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000F390C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000F3910: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3914: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000F3918: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000F3920: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 0000000F392C: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3930: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 0000000F3934: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 0000000F3940: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 0000000F3944: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000F3948: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F3950: BF870293
	v_exp_f32_e32 v26, v26                                     // 0000000F3954: 7E344B1A
	.long 0xd71c001a                                           // 0000000F3958: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000F395C: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F3960: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000F3964: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000F3968: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 0000000F3970: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F397C: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 0000000F3980: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000F3984: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F398C: BF870291
	v_rcp_f32_e32 v28, v27                                     // 0000000F3990: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 0000000F3994: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F399C: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 0000000F39A0: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 0000000F39A4: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 0000000F39AC: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F39B0: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 0000000F39B4: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 0000000F39BC: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F39C0: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 0000000F39C4: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 0000000F39CC: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F39D4: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000F39D8: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 0000000F39E0: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000F39EC: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F39F4: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000F39F8: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000F3A04: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F3A0C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F3A10: BE882004
	s_cbranch_execz 58756                                      // 0000000F3A14: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4128>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 0000000F3A18: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000F3A24: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000F3A2C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000F3A30: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3A34: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000F3A38: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000F3A40: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000F3A4C: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F3A50: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000F3A54: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000F3A58: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000F3A60: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F3A68: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000F3A6C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000F3A70: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000F3A74: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3A78: BF870095
	.long 0xd71c001a                                           // 0000000F3A7C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000F3A80: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000F3A84: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000F3A88: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3A90: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 0000000F3A94: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000F3AA0: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3AA4: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000F3AA8: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000F3AB0: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3AB4: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000F3AB8: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000F3AC0: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000F3AC4: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3ACC: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 0000000F3AD0: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 0000000F3AD4: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3ADC: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 0000000F3AE0: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 0000000F3AE4: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3AEC: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 0000000F3AF0: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000F3AF8: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 0000000F3B00: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3B0C: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000F3B10: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000F3B18: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000F3B24: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F3B2C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F3B30: BE882005
	s_cbranch_execz 58687                                      // 0000000F3B34: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4134>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 0000000F3B38: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000F3B44: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000F3B4C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000F3B50: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3B54: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000F3B58: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000F3B60: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000F3B6C: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F3B70: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000F3B74: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000F3B78: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000F3B80: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F3B88: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000F3B8C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000F3B90: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000F3B94: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3B98: BF870095
	.long 0xd71c001a                                           // 0000000F3B9C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000F3BA0: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000F3BA4: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000F3BA8: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3BB0: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 0000000F3BB4: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 0000000F3BBC: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3BC4: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000F3BC8: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000F3BD0: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3BD4: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000F3BD8: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000F3BE0: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000F3BE4: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3BEC: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000F3BF0: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 0000000F3BF4: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3BFC: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 0000000F3C00: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 0000000F3C04: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3C0C: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000F3C10: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000F3C18: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 0000000F3C20: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3C2C: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000F3C30: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000F3C38: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000F3C44: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F3C4C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F3C50: BE882006
	s_cbranch_execz 58618                                      // 0000000F3C54: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4140>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 0000000F3C58: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000F3C64: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000F3C6C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000F3C70: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3C74: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000F3C78: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000F3C80: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000F3C8C: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F3C90: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000F3C94: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000F3C98: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000F3CA0: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F3CA8: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000F3CAC: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000F3CB0: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000F3CB4: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3CB8: BF870095
	.long 0xd71c001a                                           // 0000000F3CBC: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000F3CC0: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000F3CC4: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000F3CC8: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3CD0: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 0000000F3CD4: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000F3CE0: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3CE4: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000F3CE8: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000F3CF0: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3CF4: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000F3CF8: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000F3D00: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000F3D04: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3D0C: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000F3D10: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000F3D14: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3D1C: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000F3D20: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000F3D24: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3D2C: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000F3D30: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000F3D38: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 0000000F3D40: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3D4C: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000F3D50: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000F3D58: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000F3D64: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F3D6C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F3D70: BE882007
	s_cbranch_execz 58549                                      // 0000000F3D74: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x414c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 0000000F3D78: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000F3D84: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000F3D8C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000F3D90: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3D94: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000F3D98: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000F3DA0: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000F3DAC: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F3DB0: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000F3DB4: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000F3DB8: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000F3DC0: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F3DC8: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000F3DCC: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000F3DD0: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000F3DD4: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3DD8: BF870095
	.long 0xd71c001a                                           // 0000000F3DDC: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000F3DE0: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000F3DE4: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000F3DE8: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3DF0: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 0000000F3DF4: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000F3E00: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3E04: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000F3E08: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000F3E10: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3E14: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000F3E18: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000F3E20: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000F3E24: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3E2C: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000F3E30: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000F3E34: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3E3C: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000F3E40: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000F3E44: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3E4C: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000F3E50: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000F3E58: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 0000000F3E60: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3E6C: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000F3E70: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000F3E78: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000F3E84: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F3E8C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F3E90: BE882000
	s_cbranch_execz 58480                                      // 0000000F3E94: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4158>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 0000000F3E98: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 0000000F3EA4: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 0000000F3EA8: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000F3EB0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000F3EB4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3EB8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000F3EBC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000F3EC4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000F3ED0: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F3ED4: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000F3ED8: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000F3EDC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000F3EE4: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F3EEC: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000F3EF0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000F3EF4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000F3EF8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3EFC: BF870095
	.long 0xd71c001a                                           // 0000000F3F00: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000F3F04: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000F3F08: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000F3F0C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3F14: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 0000000F3F18: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000F3F20: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3F24: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 0000000F3F28: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 0000000F3F30: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3F34: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 0000000F3F38: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 0000000F3F40: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 0000000F3F44: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3F4C: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 0000000F3F50: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 0000000F3F54: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3F5C: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 0000000F3F60: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 0000000F3F64: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3F6C: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 0000000F3F70: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 0000000F3F78: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 0000000F3F80: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3F8C: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 0000000F3F90: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 0000000F3F98: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 0000000F3FA4: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F3FAC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F3FB0: BE882001
	s_cbranch_execz 58411                                      // 0000000F3FB4: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4164>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 0000000F3FB8: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 0000000F3FC4: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 0000000F3FC8: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 0000000F3FD0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000F3FD4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F3FD8: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 0000000F3FDC: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000F3FE4: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 0000000F3FEC: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 0000000F3FF8: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F3FFC: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 0000000F4000: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 0000000F4008: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F400C: BF870121
	v_add_f32_e32 v25, v25, v26                                // 0000000F4010: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 0000000F4014: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 0000000F4018: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F401C: BF870095
	.long 0xd71c0019                                           // 0000000F4020: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000000F4024: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000000F4028: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000F402C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4034: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 0000000F4038: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000F4040: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4044: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 0000000F4048: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 0000000F4050: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4054: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 0000000F4058: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 0000000F4060: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 0000000F4064: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F406C: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 0000000F4070: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 0000000F4074: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F407C: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 0000000F4080: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 0000000F4084: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F408C: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 0000000F4090: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 0000000F4098: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 0000000F40A0: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F40AC: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 0000000F40B0: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000000F40B8: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 0000000F40C4: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F40CC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F40D0: BE882002
	s_cbranch_execz 58342                                      // 0000000F40D4: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4170>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 0000000F40D8: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000F40E4: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000F40EC: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000F40F0: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F40F4: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000F40F8: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 0000000F4100: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 0000000F410C: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F4110: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 0000000F4114: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000F4118: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 0000000F4120: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F4128: BF870121
	v_add_f32_e32 v18, v18, v25                                // 0000000F412C: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 0000000F4130: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 0000000F4134: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4138: BF870095
	.long 0xd71c0012                                           // 0000000F413C: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 0000000F4140: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000F4144: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000F4148: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4150: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 0000000F4154: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000F4160: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4164: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000F4168: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 0000000F4170: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4174: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 0000000F4178: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 0000000F4180: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 0000000F4184: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F418C: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 0000000F4190: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 0000000F4194: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F419C: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 0000000F41A0: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 0000000F41A4: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F41AC: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 0000000F41B0: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000F41B8: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 0000000F41C0: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F41CC: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 0000000F41D0: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 0000000F41D8: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000F41E4: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F41EC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F41F0: BE882003
	s_cbranch_execz 58273                                      // 0000000F41F4: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x417c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 0000000F41F8: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000F4204: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000F420C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000F4210: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4214: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000F4218: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000F4220: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 0000000F422C: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4230: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 0000000F4234: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 0000000F4240: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 0000000F4244: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000F4248: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F4250: BF870293
	v_exp_f32_e32 v18, v18                                     // 0000000F4254: 7E244B12
	.long 0xd71c0012                                           // 0000000F4258: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000F425C: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F4260: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000F4264: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000F4268: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 0000000F4270: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F427C: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 0000000F4280: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000F4284: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F428C: BF870291
	v_rcp_f32_e32 v20, v19                                     // 0000000F4290: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 0000000F4294: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F429C: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 0000000F42A0: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 0000000F42A4: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 0000000F42AC: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F42B0: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 0000000F42B4: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 0000000F42BC: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F42C0: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 0000000F42C4: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 0000000F42CC: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F42D4: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000F42D8: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 0000000F42E0: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000F42EC: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F42F4: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000F42F8: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000F4304: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F430C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F4310: BE882004
	s_cbranch_execz 58204                                      // 0000000F4314: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4188>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 0000000F4318: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000F4324: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000F432C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000F4330: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4334: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000F4338: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000F4340: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000F434C: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F4350: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000F4354: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000F4358: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000F4360: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F4368: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000F436C: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000F4370: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000F4374: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4378: BF870095
	.long 0xd71c0012                                           // 0000000F437C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000F4380: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000F4384: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000F4388: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4390: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 0000000F4394: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000F43A0: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F43A4: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000F43A8: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000F43B0: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F43B4: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000F43B8: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000F43C0: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000F43C4: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F43CC: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 0000000F43D0: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 0000000F43D4: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F43DC: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 0000000F43E0: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 0000000F43E4: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F43EC: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 0000000F43F0: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000F43F8: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 0000000F4400: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F440C: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000F4410: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000F4418: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000F4424: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F442C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F4430: BE882005
	s_cbranch_execz 58135                                      // 0000000F4434: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4194>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 0000000F4438: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000F4444: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000F444C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000F4450: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4454: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000F4458: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000F4460: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000F446C: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F4470: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000F4474: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000F4478: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000F4480: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F4488: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000F448C: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000F4490: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000F4494: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4498: BF870095
	.long 0xd71c0012                                           // 0000000F449C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000F44A0: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000F44A4: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000F44A8: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F44B0: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000F44B4: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 0000000F44BC: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F44C4: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000F44C8: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000F44D0: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F44D4: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000F44D8: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000F44E0: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000F44E4: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F44EC: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000F44F0: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 0000000F44F4: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F44FC: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 0000000F4500: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 0000000F4504: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F450C: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000F4510: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000F4518: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 0000000F4520: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F452C: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000F4530: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000F4538: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000F4544: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F454C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F4550: BE882006
	s_cbranch_execz 58066                                      // 0000000F4554: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41a0>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 0000000F4558: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000F4564: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000F456C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000F4570: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4574: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000F4578: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000F4580: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000F458C: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F4590: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000F4594: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000F4598: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000F45A0: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F45A8: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000F45AC: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000F45B0: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000F45B4: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F45B8: BF870095
	.long 0xd71c0012                                           // 0000000F45BC: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000F45C0: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000F45C4: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000F45C8: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F45D0: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 0000000F45D4: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000F45E0: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F45E4: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000F45E8: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000F45F0: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F45F4: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000F45F8: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000F4600: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000F4604: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F460C: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000F4610: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000F4614: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F461C: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000F4620: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000F4624: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F462C: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000F4630: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000F4638: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 0000000F4640: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F464C: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000F4650: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000F4658: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000F4664: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F466C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F4670: BE882007
	s_cbranch_execz 57997                                      // 0000000F4674: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41ac>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 0000000F4678: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000F4684: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000F468C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000F4690: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4694: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000F4698: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000F46A0: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000F46AC: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F46B0: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000F46B4: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000F46B8: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000F46C0: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F46C8: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000F46CC: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000F46D0: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000F46D4: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F46D8: BF870095
	.long 0xd71c0012                                           // 0000000F46DC: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000F46E0: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000F46E4: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000F46E8: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F46F0: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 0000000F46F4: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000F4700: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4704: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000F4708: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000F4710: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4714: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000F4718: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000F4720: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000F4724: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F472C: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000F4730: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000F4734: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F473C: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000F4740: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000F4744: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F474C: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000F4750: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000F4758: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 0000000F4760: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F476C: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000F4770: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000F4778: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000F4784: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F478C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F4790: BE882000
	s_cbranch_execz 57928                                      // 0000000F4794: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41b8>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 0000000F4798: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 0000000F47A4: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 0000000F47A8: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000F47B0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000F47B4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F47B8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000F47BC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000F47C4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000F47D0: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F47D4: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000F47D8: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000F47DC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000F47E4: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F47EC: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000F47F0: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000F47F4: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000F47F8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F47FC: BF870095
	.long 0xd71c0012                                           // 0000000F4800: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000F4804: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000F4808: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000F480C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4814: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000F4818: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000F4820: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4824: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 0000000F4828: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 0000000F4830: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4834: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000000F4838: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 0000000F4840: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 0000000F4844: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F484C: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 0000000F4850: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 0000000F4854: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F485C: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 0000000F4860: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 0000000F4864: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F486C: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 0000000F4870: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 0000000F4878: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 0000000F4880: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F488C: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 0000000F4890: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 0000000F4898: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 0000000F48A4: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F48AC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F48B0: BE882001
	s_cbranch_execz 57859                                      // 0000000F48B4: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41c4>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 0000000F48B8: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 0000000F48C4: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 0000000F48C8: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 0000000F48D0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000F48D4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F48D8: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 0000000F48DC: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000F48E4: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 0000000F48EC: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 0000000F48F8: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F48FC: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 0000000F4900: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 0000000F4908: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F490C: BF870121
	v_add_f32_e32 v17, v17, v18                                // 0000000F4910: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 0000000F4914: 7E241113
	v_exp_f32_e32 v17, v17                                     // 0000000F4918: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F491C: BF870095
	.long 0xd71c0011                                           // 0000000F4920: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000000F4924: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000000F4928: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000F492C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4934: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 0000000F4938: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000F4940: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4944: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 0000000F4948: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 0000000F4950: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4954: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 0000000F4958: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 0000000F4960: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 0000000F4964: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F496C: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 0000000F4970: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 0000000F4974: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F497C: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 0000000F4980: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 0000000F4984: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F498C: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 0000000F4990: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 0000000F4998: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 0000000F49A0: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F49AC: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 0000000F49B0: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000000F49B8: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 0000000F49C4: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F49CC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F49D0: BE882002
	s_cbranch_execz 57790                                      // 0000000F49D4: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41d0>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 0000000F49D8: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000F49E4: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000F49EC: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000F49F0: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F49F4: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000F49F8: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 0000000F4A00: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 0000000F4A0C: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F4A10: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 0000000F4A14: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000F4A18: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 0000000F4A20: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F4A28: BF870121
	v_add_f32_e32 v10, v10, v17                                // 0000000F4A2C: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 0000000F4A30: 7E221112
	v_exp_f32_e32 v10, v10                                     // 0000000F4A34: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4A38: BF870095
	.long 0xd71c000a                                           // 0000000F4A3C: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 0000000F4A40: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000F4A44: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000F4A48: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4A50: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 0000000F4A54: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000F4A60: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4A64: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000F4A68: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 0000000F4A70: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4A74: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 0000000F4A78: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 0000000F4A80: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 0000000F4A84: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4A8C: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 0000000F4A90: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 0000000F4A94: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4A9C: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 0000000F4AA0: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 0000000F4AA4: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4AAC: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 0000000F4AB0: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000F4AB8: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 0000000F4AC0: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4ACC: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 0000000F4AD0: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 0000000F4AD8: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000F4AE4: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F4AEC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F4AF0: BE882003
	s_cbranch_execz 57721                                      // 0000000F4AF4: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41dc>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 0000000F4AF8: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000F4B04: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000F4B0C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000F4B10: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4B14: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000F4B18: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000F4B20: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 0000000F4B2C: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4B30: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 0000000F4B34: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 0000000F4B40: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 0000000F4B44: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000F4B48: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F4B50: BF870293
	v_exp_f32_e32 v10, v10                                     // 0000000F4B54: 7E144B0A
	.long 0xd71c000a                                           // 0000000F4B58: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000F4B5C: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F4B60: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000F4B64: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000F4B68: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 0000000F4B70: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4B7C: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000F4B80: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000F4B84: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F4B8C: BF870291
	v_rcp_f32_e32 v12, v11                                     // 0000000F4B90: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 0000000F4B94: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F4B9C: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 0000000F4BA0: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 0000000F4BA4: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 0000000F4BAC: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4BB0: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 0000000F4BB4: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 0000000F4BBC: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4BC0: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 0000000F4BC4: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 0000000F4BCC: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F4BD4: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000F4BD8: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 0000000F4BE0: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000F4BEC: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F4BF4: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000F4BF8: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000F4C04: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F4C0C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F4C10: BE882004
	s_cbranch_execz 57652                                      // 0000000F4C14: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41e8>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 0000000F4C18: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000F4C24: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000F4C2C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000F4C30: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4C34: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000F4C38: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000F4C40: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000F4C4C: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F4C50: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000F4C54: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000F4C58: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000F4C60: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F4C68: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000F4C6C: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000F4C70: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000F4C74: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4C78: BF870095
	.long 0xd71c000a                                           // 0000000F4C7C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000F4C80: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000F4C84: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000F4C88: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4C90: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 0000000F4C94: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000F4CA0: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4CA4: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000F4CA8: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000F4CB0: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4CB4: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000F4CB8: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000F4CC0: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000F4CC4: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4CCC: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 0000000F4CD0: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 0000000F4CD4: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4CDC: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 0000000F4CE0: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 0000000F4CE4: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4CEC: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 0000000F4CF0: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000F4CF8: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 0000000F4D00: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4D0C: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000F4D10: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000F4D18: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000F4D24: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F4D2C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F4D30: BE882005
	s_cbranch_execz 57583                                      // 0000000F4D34: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41f4>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 0000000F4D38: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000F4D44: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000F4D4C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000F4D50: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4D54: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000F4D58: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000F4D60: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000F4D6C: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F4D70: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000F4D74: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000F4D78: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000F4D80: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F4D88: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000F4D8C: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000F4D90: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000F4D94: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4D98: BF870095
	.long 0xd71c000a                                           // 0000000F4D9C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000F4DA0: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000F4DA4: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000F4DA8: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4DB0: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 0000000F4DB4: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 0000000F4DBC: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4DC4: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000F4DC8: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000F4DD0: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4DD4: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000F4DD8: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000F4DE0: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000F4DE4: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4DEC: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000F4DF0: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 0000000F4DF4: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4DFC: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 0000000F4E00: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 0000000F4E04: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4E0C: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000F4E10: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000F4E18: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 0000000F4E20: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4E2C: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000F4E30: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000F4E38: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000F4E44: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F4E4C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F4E50: BE882006
	s_cbranch_execz 57514                                      // 0000000F4E54: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4200>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 0000000F4E58: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000F4E64: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000F4E6C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000F4E70: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4E74: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000F4E78: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000F4E80: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000F4E8C: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F4E90: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000F4E94: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000F4E98: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000F4EA0: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F4EA8: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000F4EAC: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000F4EB0: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000F4EB4: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4EB8: BF870095
	.long 0xd71c000a                                           // 0000000F4EBC: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000F4EC0: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000F4EC4: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000F4EC8: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4ED0: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 0000000F4ED4: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000F4EE0: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4EE4: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000F4EE8: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000F4EF0: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4EF4: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000F4EF8: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000F4F00: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000F4F04: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4F0C: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000F4F10: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000000F4F14: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4F1C: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000F4F20: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000F4F24: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4F2C: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000F4F30: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000F4F38: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 0000000F4F40: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4F4C: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000F4F50: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000F4F58: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000F4F64: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F4F6C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F4F70: BE882007
	s_cbranch_execz 57445                                      // 0000000F4F74: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x420c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 0000000F4F78: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000F4F84: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000F4F8C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000F4F90: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4F94: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000F4F98: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000F4FA0: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000F4FAC: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F4FB0: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000F4FB4: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000F4FB8: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000F4FC0: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F4FC8: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000F4FCC: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000F4FD0: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000F4FD4: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4FD8: BF870095
	.long 0xd71c000a                                           // 0000000F4FDC: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000F4FE0: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000F4FE4: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000F4FE8: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F4FF0: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 0000000F4FF4: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000F5000: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5004: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000F5008: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000F5010: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5014: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000F5018: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000F5020: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000F5024: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F502C: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000F5030: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000000F5034: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F503C: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000F5040: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000F5044: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F504C: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000F5050: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000F5058: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 0000000F5060: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F506C: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000F5070: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000F5078: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000F5084: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F508C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F5090: BE882000
	s_cbranch_execz 57376                                      // 0000000F5094: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4218>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 0000000F5098: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 0000000F50A4: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 0000000F50A8: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000F50B0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000F50B4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F50B8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000F50BC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000F50C4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000F50D0: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F50D4: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000F50D8: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000F50DC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000F50E4: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F50EC: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000F50F0: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000F50F4: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000F50F8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F50FC: BF870095
	.long 0xd71c000a                                           // 0000000F5100: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000F5104: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000F5108: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000F510C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5114: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 0000000F5118: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000F5120: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5124: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 0000000F5128: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 0000000F5130: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5134: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 0000000F5138: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 0000000F5140: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 0000000F5144: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F514C: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 0000000F5150: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 0000000F5154: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F515C: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 0000000F5160: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 0000000F5164: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F516C: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 0000000F5170: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 0000000F5178: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 0000000F5180: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F518C: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 0000000F5190: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000000F5198: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 0000000F51A4: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F51AC: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 0000000F51B0: BE802001
	s_cbranch_execz 57307                                      // 0000000F51B4: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4224>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 0000000F51B8: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000F51C4: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000F51CC: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000F51D0: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F51D4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000F51D8: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 0000000F51E0: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 0000000F51EC: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F51F0: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 0000000F51F4: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 0000000F51F8: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000F5200: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F5208: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 0000000F520C: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 0000000F5210: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 0000000F5214: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5218: BF870095
	.long 0xd71c0001                                           // 0000000F521C: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 0000000F5220: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000F5224: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000F5228: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5230: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 0000000F5234: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000F5240: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5244: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000F5248: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 0000000F5250: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5254: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 0000000F5258: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 0000000F5260: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 0000000F5264: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F526C: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 0000000F5270: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 0000000F5274: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F527C: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 0000000F5280: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 0000000F5284: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F528C: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 0000000F5290: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000F5298: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 0000000F52A0: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F52AC: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 0000000F52B0: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 0000000F52B8: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000F52C4: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000F52CC: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000F52D0: BE802002
	s_cbranch_execz 57238                                      // 0000000F52D4: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4230>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 0000000F52D8: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000F52E4: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000F52EC: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000F52F0: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F52F4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000F52F8: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000F5300: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 0000000F530C: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F5310: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 0000000F5314: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000F5318: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000F5320: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F5328: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000F532C: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 0000000F5330: 7E041109
	v_exp_f32_e32 v1, v1                                       // 0000000F5334: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5338: BF870095
	.long 0xd71c0001                                           // 0000000F533C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000F5340: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000F5344: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000F5348: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5350: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 0000000F5354: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000F5360: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5364: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000F5368: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000F5370: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5374: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 0000000F5378: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 0000000F5380: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 0000000F5384: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F538C: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 0000000F5390: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 0000000F5394: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F539C: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 0000000F53A0: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 0000000F53A4: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F53AC: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 0000000F53B0: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000F53B8: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 0000000F53C0: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F53CC: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000F53D0: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000F53D8: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000F53E4: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000F53EC: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000F53F0: BE802003
	s_cbranch_execz 57169                                      // 0000000F53F4: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x423c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 0000000F53F8: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000F5404: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000F540C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000F5410: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5414: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000F5418: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000F5420: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000F542C: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F5430: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000F5434: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000F5438: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000F5440: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F5448: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000F544C: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000F5450: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000F5454: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5458: BF870095
	.long 0xd71c0001                                           // 0000000F545C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000F5460: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000F5464: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000F5468: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5470: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 0000000F5474: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000F5480: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5484: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000F5488: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000F5490: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5494: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000F5498: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000F54A0: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000F54A4: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F54AC: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 0000000F54B0: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 0000000F54B4: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F54BC: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 0000000F54C0: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 0000000F54C4: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F54CC: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 0000000F54D0: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000F54D8: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 0000000F54E0: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F54EC: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000F54F0: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000F54F8: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000F5504: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000F550C: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000F5510: BE802004
	s_cbranch_execz 57100                                      // 0000000F5514: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4248>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 0000000F5518: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000F5524: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000F552C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000F5530: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5534: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000F5538: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000F5540: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000F554C: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F5550: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000F5554: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000F5558: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000F5560: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F5568: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000F556C: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000F5570: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000F5574: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5578: BF870095
	.long 0xd71c0001                                           // 0000000F557C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000F5580: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000F5584: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000F5588: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5590: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 0000000F5594: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 0000000F559C: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F55A4: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000F55A8: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000F55B0: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F55B4: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000F55B8: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000F55C0: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000F55C4: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F55CC: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000F55D0: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 0000000F55D4: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F55DC: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 0000000F55E0: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000F55E4: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F55EC: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000F55F0: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000F55F8: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 0000000F5600: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F560C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000F5610: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000F5618: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000F5624: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000F562C: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000F5630: BE802005
	s_cbranch_execz 57031                                      // 0000000F5634: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4254>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 0000000F5638: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000F5644: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000F564C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000F5650: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5654: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000F5658: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000F5660: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000F566C: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F5670: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000F5674: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000F5678: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000F5680: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F5688: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000F568C: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000F5690: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000F5694: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5698: BF870095
	.long 0xd71c0001                                           // 0000000F569C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000F56A0: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000F56A4: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000F56A8: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F56B0: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 0000000F56B4: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000F56C0: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F56C4: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000F56C8: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000F56D0: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F56D4: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000F56D8: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000F56E0: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000F56E4: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F56EC: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000F56F0: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000F56F4: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F56FC: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000F5700: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000F5704: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F570C: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000F5710: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000F5718: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 0000000F5720: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F572C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000F5730: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000F5738: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000F5744: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000F574C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000F5750: BE802006
	s_cbranch_execz 56962                                      // 0000000F5754: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4260>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 0000000F5758: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000F5764: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000F576C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000F5770: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5774: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000F5778: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000F5780: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000F578C: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F5790: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000F5794: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000F5798: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000F57A0: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F57A8: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000F57AC: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000F57B0: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000F57B4: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F57B8: BF870095
	.long 0xd71c0001                                           // 0000000F57BC: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000F57C0: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000F57C4: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000F57C8: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F57D0: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 0000000F57D4: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000F57E0: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F57E4: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000F57E8: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000F57F0: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F57F4: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000F57F8: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000F5800: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000F5804: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F580C: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000F5810: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000F5814: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F581C: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000F5820: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000F5824: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F582C: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000F5830: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000F5838: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 0000000F5840: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F584C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000F5850: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000F5858: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000F5864: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000F586C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000F5870: BE802007
	s_cbranch_execz 56893                                      // 0000000F5874: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x426c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 0000000F5878: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000F5884: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000F588C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000F5890: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5894: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000F5898: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000F58A0: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000F58AC: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F58B0: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000F58B4: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000F58B8: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000F58C0: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F58C8: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000F58CC: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000F58D0: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000F58D4: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F58D8: BF870095
	.long 0xd71c0001                                           // 0000000F58DC: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000F58E0: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000F58E4: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000F58E8: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F58F0: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 0000000F58F4: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000F5900: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5904: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000F5908: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000F5910: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5914: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000F5918: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000F5920: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000F5924: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F592C: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000F5930: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000F5934: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F593C: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000F5940: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000F5944: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F594C: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000F5950: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000F5958: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 0000000F5960: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F596C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000F5970: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000F5978: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000F5984: DC9601E0 007C0200
	s_nop 0                                                    // 0000000F598C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000000F5990: BFB60003
	s_endpgm                                                   // 0000000F5994: BFB00000
		...

