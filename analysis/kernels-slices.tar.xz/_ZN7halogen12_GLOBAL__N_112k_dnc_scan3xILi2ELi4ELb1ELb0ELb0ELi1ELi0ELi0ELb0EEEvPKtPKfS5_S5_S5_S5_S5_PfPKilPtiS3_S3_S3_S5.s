00000000001cc200 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE():
	s_load_b256 s[16:23], s[0:1], 0x38                         // 0000001CC200: F40C0400 F8000038
	s_lshl_b32 s6, s3, 6                                       // 0000001CC208: 84068603
	s_ashr_i32 s3, s2, 31                                      // 0000001CC20C: 86039F02
	s_ashr_i32 s7, s6, 31                                      // 0000001CC210: 86079F06
	v_and_b32_e32 v1, 63, v0                                   // 0000001CC214: 360200BF
	v_mov_b32_e32 v5, v0                                       // 0000001CC218: 7E0A0300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001CC21C: BF8704D2
	v_lshlrev_b32_e32 v3, 2, v1                                // 0000001CC220: 30060282
	v_mul_u32_u24_e32 v2, 0x210, v1                            // 0000001CC224: 160402FF 00000210
	s_waitcnt lgkmcnt(0)                                       // 0000001CC22C: BF89FC07
	s_load_b32 s4, s[18:19], null                              // 0000001CC230: F4000109 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000001CC238: 84928214
	s_add_u32 s5, s16, s18                                     // 0000001CC23C: 80051210
	s_addc_u32 s8, s17, s19                                    // 0000001CC240: 82081311
	s_lshl_b64 s[34:35], s[2:3], 16                            // 0000001CC244: 84A29002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001CC248: BF870009
	s_add_u32 s5, s5, s34                                      // 0000001CC24C: 80052205
	s_addc_u32 s8, s8, s35                                     // 0000001CC250: 82082308
	s_waitcnt lgkmcnt(0)                                       // 0000001CC254: BF89FC07
	s_mul_i32 s33, s4, 0x9000000                               // 0000001CC258: 9621FF04 09000000
	s_mul_hi_i32 s15, s4, 0x9000000                            // 0000001CC260: 970FFF04 09000000
	s_add_u32 s4, s5, s33                                      // 0000001CC268: 80042105
	s_addc_u32 s5, s8, s15                                     // 0000001CC26C: 82050F08
	s_lshl_b64 s[48:49], s[6:7], 2                             // 0000001CC270: 84B08206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001CC274: BF8700B9
	s_add_u32 s4, s4, s48                                      // 0000001CC278: 80043004
	s_addc_u32 s5, s5, s49                                     // 0000001CC27C: 82053105
	.long 0xd7000403                                           // 0000001CC280: D7000403
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000001CC284: 02020604
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 0000001CC288: D5207C04 00110005
	s_mov_b32 s4, 0                                            // 0000001CC290: BE840080
	s_nop 0                                                    // 0000001CC294: BF800000
	s_nop 0                                                    // 0000001CC298: BF800000
	s_nop 0                                                    // 0000001CC29C: BF800000
	s_nop 0                                                    // 0000001CC2A0: BF800000
	s_nop 0                                                    // 0000001CC2A4: BF800000
	s_nop 0                                                    // 0000001CC2A8: BF800000
	s_nop 0                                                    // 0000001CC2AC: BF800000
	s_nop 0                                                    // 0000001CC2B0: BF800000
	s_nop 0                                                    // 0000001CC2B4: BF800000
	s_nop 0                                                    // 0000001CC2B8: BF800000
	s_nop 0                                                    // 0000001CC2BC: BF800000
	v_lshrrev_b32_e32 v8, 6, v5                                // 0000001CC2C0: 32100A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CC2C4: BF870121
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000001CC2C8: 300C1089
	v_lshl_add_u32 v8, v8, 2, v2                               // 0000001CC2CC: D6460008 04090508
	.long 0xd7006a06                                           // 0000001CC2D4: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000001CC2D8: 02020D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001CC2DC: BF8700D1
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000001CC2E0: D5207C07 01AA0880
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v5                        // 0000001CC2E8: 7C920AFF 00001F7F
	global_load_b32 v6, v[6:7], off                            // 0000001CC2F0: DC520000 067C0006
	v_add_nc_u32_e32 v7, 0x80, v5                              // 0000001CC2F8: 4A0E0AFF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 0000001CC300: 8C04046A
	v_mov_b32_e32 v5, v7                                       // 0000001CC304: 7E0A0307
	s_waitcnt vmcnt(0)                                         // 0000001CC308: BF8903F7
	ds_store_b32 v8, v6                                        // 0000001CC30C: D8340000 00000608
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001CC314: 917E047E
	s_cbranch_execnz 65513                                     // 0000001CC318: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001CC31C: 8C7E047E
	s_load_b32 s50, s[0:1], 0x58                               // 0000001CC320: F4000C80 F8000058
	v_or_b32_e32 v119, 0xffffff80, v0                          // 0000001CC328: 38EE00FF FFFFFF80
	v_lshlrev_b32_e32 v5, 3, v0                                // 0000001CC330: 300A0083
	v_lshlrev_b32_e32 v118, 2, v1                              // 0000001CC334: 30EC0282
	v_mul_u32_u24_e32 v3, 0x210, v1                            // 0000001CC338: 160602FF 00000210
	v_lshrrev_b32_e32 v4, 4, v0                                // 0000001CC340: 32080084
	s_mov_b32 s4, 0                                            // 0000001CC344: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000001CC348: BF89FC07
	s_barrier                                                  // 0000001CC34C: BFBD0000
	buffer_gl0_inv                                             // 0000001CC350: E0AC0000 00000000
	s_cmp_gt_i32 s50, 0                                        // 0000001CC358: BF028032
	s_cbranch_scc1 14                                          // 0000001CC35C: BFA2000E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	v_dual_mov_b32 v107, 0 :: v_dual_and_b32 v106, 0x200, v5   // 0000001CC360: CA240080 6B6A0AFF 00000200
	v_mov_b32_e32 v1, s48                                      // 0000001CC36C: 7E020230
	v_or_b32_e32 v6, 0xffffff80, v0                            // 0000001CC370: 380C00FF FFFFFF80
	v_and_or_b32 v124, v4, 4, v3                               // 0000001CC378: D657007C 040D0904
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CC380: BF870004
	v_dual_mov_b32 v131, v107 :: v_dual_mov_b32 v2, s49        // 0000001CC384: CA10016B 83020031
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 0000001CC38C: 916A047E
	s_cbranch_vccz 1                                           // 0000001CC390: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	s_branch 7293                                              // 0000001CC394: BFA01C7D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x738c>
	s_clause 0x3                                               // 0000001CC398: BF850003
	s_load_b128 s[28:31], s[0:1], 0x10                         // 0000001CC39C: F4080700 F8000010
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000001CC3A4: F4040200 F8000020
	s_load_b64 s[10:11], s[0:1], 0x70                          // 0000001CC3AC: F4040280 F8000070
	s_load_b128 s[44:47], s[0:1], 0x60                         // 0000001CC3B4: F4080B00 F8000060
	v_dual_mov_b32 v107, 0 :: v_dual_lshlrev_b32 v2, 2, v0     // 0000001CC3BC: CA220080 6B020082
	s_add_i32 s12, s50, 63                                     // 0000001CC3C4: 810CBF32
	s_add_i32 s52, s50, -1                                     // 0000001CC3C8: 8134C132
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000001CC3CC: 32020085
	s_lshr_b32 s53, s12, 6                                     // 0000001CC3D0: 8535860C
	s_mul_i32 s12, s52, 48                                     // 0000001CC3D4: 960CB034
	s_add_i32 s51, s2, 0xbd0                                   // 0000001CC3D8: 8133FF02 00000BD0
	s_mul_hi_u32 s13, s52, 48                                  // 0000001CC3E0: 968DB034
	s_add_u32 s12, s12, s2                                     // 0000001CC3E4: 800C020C
	s_addc_u32 s13, s13, s3                                    // 0000001CC3E8: 820D030D
	v_or_b32_e32 v120, 0xf000, v2                              // 0000001CC3EC: 38F004FF 0000F000
	v_add_nc_u32_e32 v121, 0xf100, v2                          // 0000001CC3F4: 4AF204FF 0000F100
	s_lshl_b64 s[12:13], s[12:13], 9                           // 0000001CC3FC: 848C890C
	v_and_b32_e32 v6, 15, v0                                   // 0000001CC400: 360C008F
	v_bfe_u32 v7, v0, 4, 1                                     // 0000001CC404: D6100007 02050900
	s_waitcnt lgkmcnt(0)                                       // 0000001CC40C: BF89FC07
	.long 0xd7000e7a                                           // 0000001CC410: D7000E7A
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 0000001CC414: 0202041C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CC418: BF870231
	v_add_co_ci_u32_e64 v123, null, s29, 0, s14                // 0000001CC41C: D5207C7B 0039001D
	v_dual_mov_b32 v131, v107 :: v_dual_lshlrev_b32 v2, 4, v1  // 0000001CC424: CA22016B 83020284
	v_mul_u32_u24_e32 v8, 0x2100, v1                           // 0000001CC42C: 161002FF 00002100
	.long 0xd7006a7d                                           // 0000001CC434: D7006A7D
	v_cndmask_b32_e32 v0, v122, v12, vcc_lo                    // 0000001CC438: 0200197A
	s_add_u32 s12, s8, s48                                     // 0000001CC43C: 800C3008
	v_add_co_ci_u32_e64 v126, null, s13, v123, vcc_lo          // 0000001CC440: D5207C7E 01AAF60D
	s_addc_u32 s13, s9, s49                                    // 0000001CC448: 820D3109
	s_lshl_b32 s8, s2, 7                                       // 0000001CC44C: 84088702
	v_or_b32_e32 v128, v2, v6                                  // 0000001CC450: 39000D02
	v_or_b32_e32 v132, v2, v7                                  // 0000001CC454: 39080F02
	v_mad_u32_u24 v2, 0x210, v6, v8                            // 0000001CC458: D60B0002 04220CFF 00000210
	s_ashr_i32 s9, s8, 31                                      // 0000001CC464: 86099F08
	v_lshlrev_b32_e32 v8, 2, v6                                // 0000001CC468: 30100C82
	s_lshl_b64 s[8:9], s[8:9], 1                               // 0000001CC46C: 84888108
	s_load_b256 s[36:43], s[0:1], 0x80                         // 0000001CC470: F40C0900 F8000080
	s_add_u32 s8, s22, s8                                      // 0000001CC478: 80080816
	v_lshl_or_b32 v135, v7, 2, v2                              // 0000001CC47C: D6560087 04090507
	v_lshlrev_b32_e32 v2, 7, v128                              // 0000001CC484: 30050087
	s_addc_u32 s9, s23, s9                                     // 0000001CC488: 82090917
	s_lshl_b64 s[6:7], s[6:7], 1                               // 0000001CC48C: 84868106
	s_mov_b32 s20, 0xcc00                                      // 0000001CC490: BE9400FF 0000CC00
	s_add_u32 s8, s8, s6                                       // 0000001CC498: 80080608
	.long 0xd7000688                                           // 0000001CC49C: D7000688
	v_cndmask_b32_e32 v1, s12, v8, vcc_lo                      // 0000001CC4A0: 0202100C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CC4A4: BF870001
	v_add_co_ci_u32_e64 v137, null, s13, 0, s6                 // 0000001CC4A8: D5207C89 0019000D
	.long 0xd700068b                                           // 0000001CC4B0: D700068B
	v_cndmask_b32_e32 v1, s10, v2, vcc_lo                      // 0000001CC4B4: 0202040A
	v_lshlrev_b32_e32 v2, 1, v6                                // 0000001CC4B8: 30040C81
	s_load_b64 s[0:1], s[0:1], 0xa0                            // 0000001CC4BC: F4040000 F80000A0
	v_mad_u32_u24 v130, 0x90, v6, s20                          // 0000001CC4C4: D60B0082 00520CFF 00000090
	v_and_b32_e32 v106, 0x200, v5                              // 0000001CC4D0: 36D40AFF 00000200
	s_addc_u32 s9, s9, s7                                      // 0000001CC4D8: 82090709
	.long 0xd700086c                                           // 0000001CC4DC: D700086C
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000001CC4E0: 02020408
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CC4E4: BF870001
	v_add_co_ci_u32_e64 v109, null, s9, 0, s8                  // 0000001CC4E8: D5207C6D 00210009
	s_add_u32 s8, s48, s34                                     // 0000001CC4F0: 80082230
	v_mad_u32_u24 v133, 0x900, v1, v130                        // 0000001CC4F4: D60B0085 060A02FF 00000900
	v_add_co_ci_u32_e64 v140, null, s11, 0, s6                 // 0000001CC500: D5207C8C 0019000B
	.long 0xd44d0006                                           // 0000001CC508: D44D0006
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000001CC50C: 02020280
	s_addc_u32 s9, s49, s35                                    // 0000001CC510: 82092331
	.long 0xd7000801                                           // 0000001CC514: D7000801
	v_cndmask_b32_e32 v1, s8, v106, vcc_lo                     // 0000001CC518: 0202D408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001CC51C: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s9, 0, s8                    // 0000001CC520: D5207C02 00210009
	s_movk_i32 s14, 0x90                                       // 0000001CC528: B00E0090
	.long 0xd7006a01                                           // 0000001CC52C: D7006A01
	v_cndmask_b32_e32 v1, v1, v118, vcc_lo                     // 0000001CC530: 0202ED01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000001CC534: D5207C02 01AA0480
	.long 0xd44c0004                                           // 0000001CC53C: D44C0004
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 0000001CC540: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 0000001CC544: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CC548: BF870093
	.long 0xd7006a6e                                           // 0000001CC54C: D7006A6E
	v_cndmask_b32_e32 v1, s40, v1, vcc_lo                      // 0000001CC550: 02020228
	v_add_co_ci_u32_e64 v111, null, s41, v2, vcc_lo            // 0000001CC554: D5207C6F 01AA0429
	.long 0xd7006a70                                           // 0000001CC55C: D7006A70
	v_cndmask_b32_e32 v1, s42, v1, vcc_lo                      // 0000001CC560: 0202022A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CC564: BF870001
	v_add_co_ci_u32_e64 v113, null, s43, v2, vcc_lo            // 0000001CC568: D5207C71 01AA042B
	.long 0xd7006a72                                           // 0000001CC570: D7006A72
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 0000001CC574: 02020200
	.long 0xd4490005                                           // 0000001CC578: D4490005
	v_cndmask_b32_e32 v1, 63, v0, vcc_lo                       // 0000001CC57C: 020200BF
	v_mad_u32_u24 v127, v0, s14, 0x8400                        // 0000001CC580: D60B007F 03FC1D00 00008400
	v_mul_u32_u24_e32 v129, 0x210, v6                          // 0000001CC58C: 17020CFF 00000210
	v_mad_u32_u24 v134, v6, s14, 0x8400                        // 0000001CC594: D60B0086 03FC1D06 00008400
	v_lshl_add_u32 v138, v132, 1, v130                         // 0000001CC5A0: D646008A 06090384
	.long 0xd4490007                                           // 0000001CC5A8: D4490007
	v_cndmask_b32_e32 v1, 0x5f, v0, vcc_lo                     // 0000001CC5AC: 020200FF 0000005F
	v_lshl_or_b32 v141, v132, 2, 0xf100                        // 0000001CC5B4: D656008D 03FD0584 0000F100
	v_and_or_b32 v124, v4, 4, v3                               // 0000001CC5C0: D657007C 040D0904
	v_add_co_ci_u32_e64 v115, null, s1, v2, vcc_lo             // 0000001CC5C8: D5207C73 01AA0401
	s_mov_b32 s20, 0                                           // 0000001CC5D0: BE940080
	s_mov_b32 s39, 0x41800000                                  // 0000001CC5D4: BEA700FF 41800000
	s_mov_b32 s21, s20                                         // 0000001CC5DC: BE950014
	s_mov_b32 s22, s20                                         // 0000001CC5E0: BE960014
	s_mov_b32 s23, s20                                         // 0000001CC5E4: BE970014
	s_mov_b32 s24, s20                                         // 0000001CC5E8: BE980014
	s_mov_b32 s25, s20                                         // 0000001CC5EC: BE990014
	s_mov_b32 s26, s20                                         // 0000001CC5F0: BE9A0014
	s_mov_b32 s27, s20                                         // 0000001CC5F4: BE9B0014
	s_mov_b32 s40, s20                                         // 0000001CC5F8: BEA80014
	s_branch 4                                                 // 0000001CC5FC: BFA00004 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x410>
	s_add_i32 s40, s40, 1                                      // 0000001CC600: 81288128
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001CC604: BF870009
	s_cmp_eq_u32 s40, s53                                      // 0000001CC608: BF063528
	s_cbranch_scc1 7132                                        // 0000001CC60C: BFA21BDC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7380>
	s_mul_i32 s1, s40, 0xc00                                   // 0000001CC610: 9601FF28 00000C00
	s_lshl_b32 s42, s40, 6                                     // 0000001CC618: 842A8628
	s_add_i32 s8, s51, s1                                      // 0000001CC61C: 81080133
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001CC620: BF870499
	s_ashr_i32 s9, s8, 31                                      // 0000001CC624: 86099F08
	s_lshl_b64 s[8:9], s[8:9], 2                               // 0000001CC628: 84888208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001CC62C: BF870009
	s_add_u32 s8, s30, s8                                      // 0000001CC630: 8008081E
	s_addc_u32 s9, s31, s9                                     // 0000001CC634: 8209091F
	global_load_b32 v1, v107, s[8:9]                           // 0000001CC638: DC520000 0108006B
	s_waitcnt vmcnt(0)                                         // 0000001CC640: BF8903F7
	v_readfirstlane_b32 s41, v1                                // 0000001CC644: 7E520501
	s_and_saveexec_b32 s0, s4                                  // 0000001CC648: BE802004
	s_cbranch_execz 69                                         // 0000001CC64C: BFA50045 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x564>
	v_or_b32_e32 v1, s42, v0                                   // 0000001CC650: 3802002A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CC654: BF870091
	v_mad_u64_u32 v[1:2], null, v1, 48, s[2:3]                 // 0000001CC658: D6FE7C01 00096101
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000001CC660: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CC664: BF870091
	.long 0xd73c0001                                           // 0000001CC668: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000001CC66C: 02020282
	.long 0xd7006a01                                           // 0000001CC670: D7006A01
	v_cndmask_b32_e32 v1, s30, v1, vcc_lo                      // 0000001CC674: 0202021E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001CC678: BF8700C1
	v_add_co_ci_u32_e64 v2, null, s31, v2, vcc_lo              // 0000001CC67C: D5207C02 01AA041F
	global_load_b32 v1, v[1:2], off                            // 0000001CC684: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001CC68C: BF8903F7
	v_sub_f32_e32 v2, s41, v1                                  // 0000001CC690: 08040229
	v_dual_mul_f32 v4, 0x3fb8aa3b, v1 :: v_dual_mul_f32 v3, 0x3fb8aa3b, v2// 0000001CC694: C8C602FF 040204FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001CC6A0: BF8701A1
	v_rndne_f32_e32 v8, v4                                     // 0000001CC6A4: 7E104704
	v_fma_f32 v7, 0x3fb8aa3b, v1, -v4                          // 0000001CC6A8: D6130007 841202FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v2, -v3                          // 0000001CC6B4: D6130005 840E04FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 0000001CC6C0: 7E0C4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CC6C4: BF870191
	v_dual_sub_f32 v4, v4, v8 :: v_dual_sub_f32 v3, v3, v6     // 0000001CC6C8: C94A1104 04020D03
	v_fmac_f32_e32 v5, 0x32a5705f, v2                          // 0000001CC6D0: 560A04FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2                   // 0000001CC6D8: 7C3604FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001CC6E0: BF8701B2
	v_add_f32_e32 v3, v3, v5                                   // 0000001CC6E4: 06060B03
	v_cvt_i32_f32_e32 v5, v6                                   // 0000001CC6E8: 7E0A1106
	v_cvt_i32_f32_e32 v6, v8                                   // 0000001CC6EC: 7E0C1108
	v_exp_f32_e32 v3, v3                                       // 0000001CC6F0: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CC6F4: BF870095
	.long 0xd71c0003                                           // 0000001CC6F8: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000001CC6FC: 02020B03
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 0000001CC700: 02060680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 0000001CC704: 7C3602FF C2CE8ED0
	v_fmac_f32_e32 v7, 0x32a5705f, v1                          // 0000001CC70C: 560E02FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CC714: BF870091
	v_add_f32_e32 v4, v4, v7                                   // 0000001CC718: 06080F04
	v_exp_f32_e32 v4, v4                                       // 0000001CC71C: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CC720: BF870095
	.long 0xd71c0004                                           // 0000001CC724: D71C0004
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000001CC728: 02020D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 0000001CC72C: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2                   // 0000001CC730: 7C3C04FF 42B17218
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo               // 0000001CC738: 020406FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 0000001CC740: 7C3C02FF 42B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CC748: BF870004
	v_cndmask_b32_e32 v1, 0x7f800000, v4, vcc_lo               // 0000001CC74C: 020208FF 7F800000
	ds_store_b32 v120, v2                                      // 0000001CC754: D8340000 00000278
	ds_store_b32 v121, v1                                      // 0000001CC75C: D8340000 00000179
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CC764: 8C7E007E
	s_sub_i32 s0, s50, s42                                     // 0000001CC768: 81802A32
	s_mul_hi_u32 s8, s40, 0xc00                                // 0000001CC76C: 9688FF28 00000C00
	s_add_u32 s28, s1, s2                                      // 0000001CC774: 801C0201
	s_addc_u32 s29, s8, s3                                     // 0000001CC778: 821D0308
	.long 0x7ec23880                                           // 0000001CC77C: 7EC23880
	s_lshl_b64 s[8:9], s[28:29], 9                             // 0000001CC780: 8488891C
	s_cmp_gt_i32 s0, 0                                         // 0000001CC784: BF028000
	.long 0xd7006a01                                           // 0000001CC788: D7006A01
	v_cndmask_b32_e32 v0, v122, v8, vcc_lo                     // 0000001CC78C: 0200117A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CC790: BF870001
	v_add_co_ci_u32_e64 v2, null, s9, v123, vcc_lo             // 0000001CC794: D5207C02 01AAF609
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CC79C: 986A80C1
	s_cmp_gt_i32 s0, 1                                         // 0000001CC7A0: BF028100
	v_dual_cndmask_b32 v3, v125, v1 :: v_dual_cndmask_b32 v4, v126, v2// 0000001CC7A4: CA52037D 0304057E
	global_load_b32 v17, v[3:4], off                           // 0000001CC7AC: DC520000 117C0003
	.long 0xd7006a03                                           // 0000001CC7B4: D7006A03
	v_cndmask_b32_e32 v1, 0x6000, v1, vcc_lo                   // 0000001CC7B8: 020202FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CC7C0: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001CC7C4: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001CC7CC: D7006A05
	v_cndmask_b32_e32 v1, 0xc000, v1, vcc_lo                   // 0000001CC7D0: 020202FF 0000C000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CC7D8: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CC7E0: 986A80C1
	s_cmp_gt_i32 s0, 2                                         // 0000001CC7E4: BF028200
	v_dual_cndmask_b32 v4, v126, v4 :: v_dual_cndmask_b32 v3, v125, v3// 0000001CC7E8: CA52097E 0402077D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CC7F0: 986A80C1
	s_cmp_gt_i32 s0, 3                                         // 0000001CC7F4: BF028300
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CC7F8: CA520D7E 06040B7D
	.long 0xd7006a07                                           // 0000001CC800: D7006A07
	v_cndmask_b32_e32 v1, 0x12000, v1, vcc_lo                  // 0000001CC804: 020202FF 00012000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CC80C: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CC810: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CC818: 986A80C1
	global_load_b32 v18, v[3:4], off                           // 0000001CC81C: DC520000 127C0003
	global_load_b32 v19, v[5:6], off                           // 0000001CC824: DC520000 137C0005
	v_dual_cndmask_b32 v4, v126, v8 :: v_dual_cndmask_b32 v3, v125, v7// 0000001CC82C: CA52117E 04020F7D
	.long 0xd7006a05                                           // 0000001CC834: D7006A05
	v_cndmask_b32_e32 v1, 0x18000, v1, vcc_lo                  // 0000001CC838: 020202FF 00018000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CC840: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CC844: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001CC84C: D7006A07
	v_cndmask_b32_e32 v1, 0x1e000, v1, vcc_lo                  // 0000001CC850: 020202FF 0001E000
	s_cmp_gt_i32 s0, 4                                         // 0000001CC858: BF028400
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CC85C: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CC864: 986A80C1
	s_cmp_gt_i32 s0, 5                                         // 0000001CC868: BF028500
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CC86C: CA520D7E 06040B7D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CC874: 986A80C1
	s_cmp_gt_i32 s0, 6                                         // 0000001CC878: BF028600
	v_dual_cndmask_b32 v8, v126, v8 :: v_dual_cndmask_b32 v7, v125, v7// 0000001CC87C: CA52117E 08060F7D
	.long 0xd7006a09                                           // 0000001CC884: D7006A09
	v_cndmask_b32_e32 v1, 0x24000, v1, vcc_lo                  // 0000001CC888: 020202FF 00024000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CC890: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001CC894: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001CC89C: D7006A0B
	v_cndmask_b32_e32 v1, 0x2a000, v1, vcc_lo                  // 0000001CC8A0: 020202FF 0002A000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001CC8A8: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CC8B0: 986A80C1
	s_cmp_gt_i32 s0, 7                                         // 0000001CC8B4: BF028700
	v_dual_cndmask_b32 v10, v126, v10 :: v_dual_cndmask_b32 v9, v125, v9// 0000001CC8B8: CA52157E 0A08137D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CC8C0: 986A80C1
	s_cmp_gt_i32 s0, 8                                         // 0000001CC8C4: BF028800
	v_dual_cndmask_b32 v12, v126, v12 :: v_dual_cndmask_b32 v11, v125, v11// 0000001CC8C8: CA52197E 0C0A177D
	global_load_b32 v20, v[3:4], off                           // 0000001CC8D0: DC520000 147C0003
	global_load_b32 v21, v[5:6], off                           // 0000001CC8D8: DC520000 157C0005
	global_load_b32 v22, v[7:8], off                           // 0000001CC8E0: DC520000 167C0007
	global_load_b32 v23, v[9:10], off                          // 0000001CC8E8: DC520000 177C0009
	global_load_b32 v24, v[11:12], off                         // 0000001CC8F0: DC520000 187C000B
	.long 0xd7006a03                                           // 0000001CC8F8: D7006A03
	v_cndmask_b32_e32 v1, 0x30000, v1, vcc_lo                  // 0000001CC8FC: 020202FF 00030000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CC904: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001CC908: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001CC910: D7006A05
	v_cndmask_b32_e32 v1, 0x36000, v1, vcc_lo                  // 0000001CC914: 020202FF 00036000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CC91C: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CC924: 986A80C1
	s_cmp_gt_i32 s0, 9                                         // 0000001CC928: BF028900
	v_dual_cndmask_b32 v4, v126, v4 :: v_dual_cndmask_b32 v3, v125, v3// 0000001CC92C: CA52097E 0402077D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CC934: 986A80C1
	s_cmp_gt_i32 s0, 10                                        // 0000001CC938: BF028A00
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CC93C: CA520D7E 06040B7D
	.long 0xd7006a07                                           // 0000001CC944: D7006A07
	v_cndmask_b32_e32 v1, 0x3c000, v1, vcc_lo                  // 0000001CC948: 020202FF 0003C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CC950: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CC954: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CC95C: 986A80C1
	global_load_b32 v25, v[3:4], off                           // 0000001CC960: DC520000 197C0003
	global_load_b32 v26, v[5:6], off                           // 0000001CC968: DC520000 1A7C0005
	v_dual_cndmask_b32 v4, v126, v8 :: v_dual_cndmask_b32 v3, v125, v7// 0000001CC970: CA52117E 04020F7D
	.long 0xd7006a05                                           // 0000001CC978: D7006A05
	v_cndmask_b32_e32 v1, 0x42000, v1, vcc_lo                  // 0000001CC97C: 020202FF 00042000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CC984: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CC988: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001CC990: D7006A07
	v_cndmask_b32_e32 v1, 0x48000, v1, vcc_lo                  // 0000001CC994: 020202FF 00048000
	s_cmp_gt_i32 s0, 11                                        // 0000001CC99C: BF028B00
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CC9A0: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CC9A8: 986A80C1
	s_cmp_gt_i32 s0, 12                                        // 0000001CC9AC: BF028C00
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CC9B0: CA520D7E 06040B7D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CC9B8: 986A80C1
	s_cmp_gt_i32 s0, 13                                        // 0000001CC9BC: BF028D00
	v_dual_cndmask_b32 v8, v126, v8 :: v_dual_cndmask_b32 v7, v125, v7// 0000001CC9C0: CA52117E 08060F7D
	.long 0xd7006a09                                           // 0000001CC9C8: D7006A09
	v_cndmask_b32_e32 v1, 0x4e000, v1, vcc_lo                  // 0000001CC9CC: 020202FF 0004E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CC9D4: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001CC9D8: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001CC9E0: D7006A0B
	v_cndmask_b32_e32 v1, 0x54000, v1, vcc_lo                  // 0000001CC9E4: 020202FF 00054000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001CC9EC: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CC9F4: 986A80C1
	s_cmp_gt_i32 s0, 14                                        // 0000001CC9F8: BF028E00
	v_dual_cndmask_b32 v10, v126, v10 :: v_dual_cndmask_b32 v9, v125, v9// 0000001CC9FC: CA52157E 0A08137D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCA04: 986A80C1
	s_cmp_gt_i32 s0, 15                                        // 0000001CCA08: BF028F00
	v_dual_cndmask_b32 v12, v126, v12 :: v_dual_cndmask_b32 v11, v125, v11// 0000001CCA0C: CA52197E 0C0A177D
	global_load_b32 v27, v[3:4], off                           // 0000001CCA14: DC520000 1B7C0003
	global_load_b32 v28, v[5:6], off                           // 0000001CCA1C: DC520000 1C7C0005
	global_load_b32 v29, v[7:8], off                           // 0000001CCA24: DC520000 1D7C0007
	global_load_b32 v30, v[9:10], off                          // 0000001CCA2C: DC520000 1E7C0009
	global_load_b32 v31, v[11:12], off                         // 0000001CCA34: DC520000 1F7C000B
	.long 0xd7006a03                                           // 0000001CCA3C: D7006A03
	v_cndmask_b32_e32 v1, 0x5a000, v1, vcc_lo                  // 0000001CCA40: 020202FF 0005A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CCA48: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001CCA4C: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001CCA54: D7006A05
	v_cndmask_b32_e32 v1, 0x60000, v1, vcc_lo                  // 0000001CCA58: 020202FF 00060000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CCA60: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCA68: 986A80C1
	s_cmp_gt_i32 s0, 16                                        // 0000001CCA6C: BF029000
	v_dual_cndmask_b32 v4, v126, v4 :: v_dual_cndmask_b32 v3, v125, v3// 0000001CCA70: CA52097E 0402077D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCA78: 986A80C1
	s_cmp_gt_i32 s0, 17                                        // 0000001CCA7C: BF029100
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CCA80: CA520D7E 06040B7D
	.long 0xd7006a07                                           // 0000001CCA88: D7006A07
	v_cndmask_b32_e32 v1, 0x66000, v1, vcc_lo                  // 0000001CCA8C: 020202FF 00066000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CCA94: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CCA98: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCAA0: 986A80C1
	global_load_b32 v32, v[3:4], off                           // 0000001CCAA4: DC520000 207C0003
	global_load_b32 v41, v[5:6], off                           // 0000001CCAAC: DC520000 297C0005
	v_dual_cndmask_b32 v4, v126, v8 :: v_dual_cndmask_b32 v3, v125, v7// 0000001CCAB4: CA52117E 04020F7D
	.long 0xd7006a05                                           // 0000001CCABC: D7006A05
	v_cndmask_b32_e32 v1, 0x6c000, v1, vcc_lo                  // 0000001CCAC0: 020202FF 0006C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CCAC8: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CCACC: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001CCAD4: D7006A07
	v_cndmask_b32_e32 v1, 0x72000, v1, vcc_lo                  // 0000001CCAD8: 020202FF 00072000
	s_cmp_gt_i32 s0, 18                                        // 0000001CCAE0: BF029200
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CCAE4: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCAEC: 986A80C1
	s_cmp_gt_i32 s0, 19                                        // 0000001CCAF0: BF029300
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CCAF4: CA520D7E 06040B7D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCAFC: 986A80C1
	s_cmp_gt_i32 s0, 20                                        // 0000001CCB00: BF029400
	v_dual_cndmask_b32 v8, v126, v8 :: v_dual_cndmask_b32 v7, v125, v7// 0000001CCB04: CA52117E 08060F7D
	.long 0xd7006a09                                           // 0000001CCB0C: D7006A09
	v_cndmask_b32_e32 v1, 0x78000, v1, vcc_lo                  // 0000001CCB10: 020202FF 00078000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CCB18: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001CCB1C: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001CCB24: D7006A0B
	v_cndmask_b32_e32 v1, 0x7e000, v1, vcc_lo                  // 0000001CCB28: 020202FF 0007E000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001CCB30: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCB38: 986A80C1
	s_cmp_gt_i32 s0, 21                                        // 0000001CCB3C: BF029500
	v_dual_cndmask_b32 v10, v126, v10 :: v_dual_cndmask_b32 v9, v125, v9// 0000001CCB40: CA52157E 0A08137D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCB48: 986A80C1
	s_cmp_gt_i32 s0, 22                                        // 0000001CCB4C: BF029600
	v_dual_cndmask_b32 v12, v126, v12 :: v_dual_cndmask_b32 v11, v125, v11// 0000001CCB50: CA52197E 0C0A177D
	global_load_b32 v48, v[3:4], off                           // 0000001CCB58: DC520000 307C0003
	global_load_b32 v49, v[5:6], off                           // 0000001CCB60: DC520000 317C0005
	global_load_b32 v50, v[7:8], off                           // 0000001CCB68: DC520000 327C0007
	global_load_b32 v42, v[9:10], off                          // 0000001CCB70: DC520000 2A7C0009
	global_load_b32 v43, v[11:12], off                         // 0000001CCB78: DC520000 2B7C000B
	.long 0xd7006a03                                           // 0000001CCB80: D7006A03
	v_cndmask_b32_e32 v1, 0x84000, v1, vcc_lo                  // 0000001CCB84: 020202FF 00084000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CCB8C: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001CCB90: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001CCB98: D7006A05
	v_cndmask_b32_e32 v1, 0x8a000, v1, vcc_lo                  // 0000001CCB9C: 020202FF 0008A000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CCBA4: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCBAC: 986A80C1
	s_cmp_gt_i32 s0, 23                                        // 0000001CCBB0: BF029700
	v_dual_cndmask_b32 v4, v126, v4 :: v_dual_cndmask_b32 v3, v125, v3// 0000001CCBB4: CA52097E 0402077D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCBBC: 986A80C1
	s_cmp_gt_i32 s0, 24                                        // 0000001CCBC0: BF029800
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CCBC4: CA520D7E 06040B7D
	.long 0xd7006a07                                           // 0000001CCBCC: D7006A07
	v_cndmask_b32_e32 v1, 0x90000, v1, vcc_lo                  // 0000001CCBD0: 020202FF 00090000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CCBD8: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CCBDC: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCBE4: 986A80C1
	global_load_b32 v45, v[3:4], off                           // 0000001CCBE8: DC520000 2D7C0003
	global_load_b32 v44, v[5:6], off                           // 0000001CCBF0: DC520000 2C7C0005
	v_dual_cndmask_b32 v4, v126, v8 :: v_dual_cndmask_b32 v3, v125, v7// 0000001CCBF8: CA52117E 04020F7D
	.long 0xd7006a05                                           // 0000001CCC00: D7006A05
	v_cndmask_b32_e32 v1, 0x96000, v1, vcc_lo                  // 0000001CCC04: 020202FF 00096000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CCC0C: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CCC10: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001CCC18: D7006A07
	v_cndmask_b32_e32 v1, 0x9c000, v1, vcc_lo                  // 0000001CCC1C: 020202FF 0009C000
	s_cmp_gt_i32 s0, 25                                        // 0000001CCC24: BF029900
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CCC28: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCC30: 986A80C1
	s_cmp_gt_i32 s0, 26                                        // 0000001CCC34: BF029A00
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CCC38: CA520D7E 06040B7D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCC40: 986A80C1
	s_cmp_gt_i32 s0, 27                                        // 0000001CCC44: BF029B00
	v_dual_cndmask_b32 v8, v126, v8 :: v_dual_cndmask_b32 v7, v125, v7// 0000001CCC48: CA52117E 08060F7D
	.long 0xd7006a09                                           // 0000001CCC50: D7006A09
	v_cndmask_b32_e32 v1, 0xa2000, v1, vcc_lo                  // 0000001CCC54: 020202FF 000A2000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CCC5C: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001CCC60: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001CCC68: D7006A0B
	v_cndmask_b32_e32 v1, 0xa8000, v1, vcc_lo                  // 0000001CCC6C: 020202FF 000A8000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001CCC74: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCC7C: 986A80C1
	s_cmp_gt_i32 s0, 28                                        // 0000001CCC80: BF029C00
	v_dual_cndmask_b32 v10, v126, v10 :: v_dual_cndmask_b32 v9, v125, v9// 0000001CCC84: CA52157E 0A08137D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCC8C: 986A80C1
	s_cmp_gt_i32 s0, 29                                        // 0000001CCC90: BF029D00
	v_dual_cndmask_b32 v12, v126, v12 :: v_dual_cndmask_b32 v11, v125, v11// 0000001CCC94: CA52197E 0C0A177D
	global_load_b32 v55, v[3:4], off                           // 0000001CCC9C: DC520000 377C0003
	global_load_b32 v52, v[5:6], off                           // 0000001CCCA4: DC520000 347C0005
	global_load_b32 v51, v[7:8], off                           // 0000001CCCAC: DC520000 337C0007
	global_load_b32 v46, v[9:10], off                          // 0000001CCCB4: DC520000 2E7C0009
	global_load_b32 v47, v[11:12], off                         // 0000001CCCBC: DC520000 2F7C000B
	.long 0xd7006a03                                           // 0000001CCCC4: D7006A03
	v_cndmask_b32_e32 v1, 0xae000, v1, vcc_lo                  // 0000001CCCC8: 020202FF 000AE000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CCCD0: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001CCCD4: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001CCCDC: D7006A05
	v_cndmask_b32_e32 v1, 0xb4000, v1, vcc_lo                  // 0000001CCCE0: 020202FF 000B4000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CCCE8: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCCF0: 986A80C1
	s_cmp_gt_i32 s0, 30                                        // 0000001CCCF4: BF029E00
	v_dual_cndmask_b32 v4, v126, v4 :: v_dual_cndmask_b32 v3, v125, v3// 0000001CCCF8: CA52097E 0402077D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCD00: 986A80C1
	s_cmp_gt_i32 s0, 31                                        // 0000001CCD04: BF029F00
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CCD08: CA520D7E 06040B7D
	.long 0xd7006a07                                           // 0000001CCD10: D7006A07
	v_cndmask_b32_e32 v1, 0xba000, v1, vcc_lo                  // 0000001CCD14: 020202FF 000BA000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CCD1C: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CCD20: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCD28: 986A80C1
	global_load_b32 v53, v[3:4], off                           // 0000001CCD2C: DC520000 357C0003
	global_load_b32 v54, v[5:6], off                           // 0000001CCD34: DC520000 367C0005
	v_dual_cndmask_b32 v4, v126, v8 :: v_dual_cndmask_b32 v3, v125, v7// 0000001CCD3C: CA52117E 04020F7D
	.long 0xd7006a05                                           // 0000001CCD44: D7006A05
	v_cndmask_b32_e32 v1, 0xc0000, v1, vcc_lo                  // 0000001CCD48: 020202FF 000C0000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CCD50: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CCD54: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001CCD5C: D7006A07
	v_cndmask_b32_e32 v1, 0xc6000, v1, vcc_lo                  // 0000001CCD60: 020202FF 000C6000
	s_cmp_gt_i32 s0, 32                                        // 0000001CCD68: BF02A000
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CCD6C: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCD74: 986A80C1
	s_cmp_gt_i32 s0, 33                                        // 0000001CCD78: BF02A100
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CCD7C: CA520D7E 06040B7D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCD84: 986A80C1
	s_cmp_gt_i32 s0, 34                                        // 0000001CCD88: BF02A200
	v_dual_cndmask_b32 v8, v126, v8 :: v_dual_cndmask_b32 v7, v125, v7// 0000001CCD8C: CA52117E 08060F7D
	.long 0xd7006a09                                           // 0000001CCD94: D7006A09
	v_cndmask_b32_e32 v1, 0xcc000, v1, vcc_lo                  // 0000001CCD98: 020202FF 000CC000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CCDA0: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001CCDA4: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001CCDAC: D7006A0B
	v_cndmask_b32_e32 v1, 0xd2000, v1, vcc_lo                  // 0000001CCDB0: 020202FF 000D2000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001CCDB8: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCDC0: 986A80C1
	s_cmp_gt_i32 s0, 35                                        // 0000001CCDC4: BF02A300
	v_dual_cndmask_b32 v10, v126, v10 :: v_dual_cndmask_b32 v9, v125, v9// 0000001CCDC8: CA52157E 0A08137D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCDD0: 986A80C1
	s_cmp_gt_i32 s0, 36                                        // 0000001CCDD4: BF02A400
	v_dual_cndmask_b32 v12, v126, v12 :: v_dual_cndmask_b32 v11, v125, v11// 0000001CCDD8: CA52197E 0C0A177D
	global_load_b32 v105, v[3:4], off                          // 0000001CCDE0: DC520000 697C0003
	global_load_b32 v102, v[5:6], off                          // 0000001CCDE8: DC520000 667C0005
	global_load_b32 v101, v[7:8], off                          // 0000001CCDF0: DC520000 657C0007
	global_load_b32 v56, v[9:10], off                          // 0000001CCDF8: DC520000 387C0009
	global_load_b32 v100, v[11:12], off                        // 0000001CCE00: DC520000 647C000B
	.long 0xd7006a03                                           // 0000001CCE08: D7006A03
	v_cndmask_b32_e32 v1, 0xd8000, v1, vcc_lo                  // 0000001CCE0C: 020202FF 000D8000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CCE14: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001CCE18: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001CCE20: D7006A05
	v_cndmask_b32_e32 v1, 0xde000, v1, vcc_lo                  // 0000001CCE24: 020202FF 000DE000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CCE2C: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCE34: 986A80C1
	s_cmp_gt_i32 s0, 37                                        // 0000001CCE38: BF02A500
	v_dual_cndmask_b32 v4, v126, v4 :: v_dual_cndmask_b32 v3, v125, v3// 0000001CCE3C: CA52097E 0402077D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCE44: 986A80C1
	s_cmp_gt_i32 s0, 38                                        // 0000001CCE48: BF02A600
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CCE4C: CA520D7E 06040B7D
	.long 0xd7006a07                                           // 0000001CCE54: D7006A07
	v_cndmask_b32_e32 v1, 0xe4000, v1, vcc_lo                  // 0000001CCE58: 020202FF 000E4000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CCE60: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CCE64: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCE6C: 986A80C1
	global_load_b32 v104, v[3:4], off                          // 0000001CCE70: DC520000 687C0003
	global_load_b32 v103, v[5:6], off                          // 0000001CCE78: DC520000 677C0005
	v_dual_cndmask_b32 v4, v126, v8 :: v_dual_cndmask_b32 v3, v125, v7// 0000001CCE80: CA52117E 04020F7D
	.long 0xd7006a05                                           // 0000001CCE88: D7006A05
	v_cndmask_b32_e32 v1, 0xea000, v1, vcc_lo                  // 0000001CCE8C: 020202FF 000EA000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CCE94: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CCE98: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001CCEA0: D7006A07
	v_cndmask_b32_e32 v1, 0xf0000, v1, vcc_lo                  // 0000001CCEA4: 020202FF 000F0000
	s_cmp_gt_i32 s0, 39                                        // 0000001CCEAC: BF02A700
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CCEB0: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCEB8: 986A80C1
	s_cmp_gt_i32 s0, 40                                        // 0000001CCEBC: BF02A800
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CCEC0: CA520D7E 06040B7D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCEC8: 986A80C1
	s_cmp_gt_i32 s0, 41                                        // 0000001CCECC: BF02A900
	v_dual_cndmask_b32 v8, v126, v8 :: v_dual_cndmask_b32 v7, v125, v7// 0000001CCED0: CA52117E 08060F7D
	.long 0xd7006a09                                           // 0000001CCED8: D7006A09
	v_cndmask_b32_e32 v1, 0xf6000, v1, vcc_lo                  // 0000001CCEDC: 020202FF 000F6000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CCEE4: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001CCEE8: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001CCEF0: D7006A0B
	v_cndmask_b32_e32 v1, 0xfc000, v1, vcc_lo                  // 0000001CCEF4: 020202FF 000FC000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001CCEFC: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCF04: 986A80C1
	s_cmp_gt_i32 s0, 42                                        // 0000001CCF08: BF02AA00
	v_dual_cndmask_b32 v10, v126, v10 :: v_dual_cndmask_b32 v9, v125, v9// 0000001CCF0C: CA52157E 0A08137D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCF14: 986A80C1
	s_cmp_gt_i32 s0, 43                                        // 0000001CCF18: BF02AB00
	v_dual_cndmask_b32 v12, v126, v12 :: v_dual_cndmask_b32 v11, v125, v11// 0000001CCF1C: CA52197E 0C0A177D
	global_load_b32 v145, v[3:4], off                          // 0000001CCF24: DC520000 917C0003
	global_load_b32 v144, v[5:6], off                          // 0000001CCF2C: DC520000 907C0005
	global_load_b32 v142, v[7:8], off                          // 0000001CCF34: DC520000 8E7C0007
	global_load_b32 v117, v[9:10], off                         // 0000001CCF3C: DC520000 757C0009
	global_load_b32 v116, v[11:12], off                        // 0000001CCF44: DC520000 747C000B
	.long 0xd7006a03                                           // 0000001CCF4C: D7006A03
	v_cndmask_b32_e32 v1, 0x102000, v1, vcc_lo                 // 0000001CCF50: 020202FF 00102000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CCF58: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001CCF5C: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001CCF64: D7006A05
	v_cndmask_b32_e32 v1, 0x108000, v1, vcc_lo                 // 0000001CCF68: 020202FF 00108000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CCF70: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCF78: 986A80C1
	s_cmp_gt_i32 s0, 44                                        // 0000001CCF7C: BF02AC00
	v_dual_cndmask_b32 v4, v126, v4 :: v_dual_cndmask_b32 v3, v125, v3// 0000001CCF80: CA52097E 0402077D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCF88: 986A80C1
	s_cmp_gt_i32 s0, 45                                        // 0000001CCF8C: BF02AD00
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CCF90: CA520D7E 06040B7D
	.long 0xd7006a07                                           // 0000001CCF98: D7006A07
	v_cndmask_b32_e32 v1, 0x10e000, v1, vcc_lo                 // 0000001CCF9C: 020202FF 0010E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CCFA4: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CCFA8: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCFB0: 986A80C1
	global_load_b32 v146, v[3:4], off                          // 0000001CCFB4: DC520000 927C0003
	global_load_b32 v143, v[5:6], off                          // 0000001CCFBC: DC520000 8F7C0005
	v_dual_cndmask_b32 v4, v126, v8 :: v_dual_cndmask_b32 v3, v125, v7// 0000001CCFC4: CA52117E 04020F7D
	.long 0xd7006a05                                           // 0000001CCFCC: D7006A05
	v_cndmask_b32_e32 v1, 0x114000, v1, vcc_lo                 // 0000001CCFD0: 020202FF 00114000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CCFD8: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CCFDC: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001CCFE4: D7006A07
	v_cndmask_b32_e32 v1, 0x11a000, v1, vcc_lo                 // 0000001CCFE8: 020202FF 0011A000
	s_cmp_gt_i32 s0, 46                                        // 0000001CCFF0: BF02AE00
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CCFF4: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CCFFC: 986A80C1
	s_cmp_gt_i32 s0, 47                                        // 0000001CD000: BF02AF00
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CD004: CA520D7E 06040B7D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD00C: 986A80C1
	s_cmp_gt_i32 s0, 48                                        // 0000001CD010: BF02B000
	v_dual_cndmask_b32 v8, v126, v8 :: v_dual_cndmask_b32 v7, v125, v7// 0000001CD014: CA52117E 08060F7D
	.long 0xd7006a09                                           // 0000001CD01C: D7006A09
	v_cndmask_b32_e32 v1, 0x120000, v1, vcc_lo                 // 0000001CD020: 020202FF 00120000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CD028: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001CD02C: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001CD034: D7006A0B
	v_cndmask_b32_e32 v1, 0x126000, v1, vcc_lo                 // 0000001CD038: 020202FF 00126000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001CD040: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD048: 986A80C1
	s_cmp_gt_i32 s0, 49                                        // 0000001CD04C: BF02B100
	v_dual_cndmask_b32 v10, v126, v10 :: v_dual_cndmask_b32 v9, v125, v9// 0000001CD050: CA52157E 0A08137D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD058: 986A80C1
	s_cmp_gt_i32 s0, 50                                        // 0000001CD05C: BF02B200
	v_dual_cndmask_b32 v12, v126, v12 :: v_dual_cndmask_b32 v11, v125, v11// 0000001CD060: CA52197E 0C0A177D
	global_load_b32 v152, v[3:4], off                          // 0000001CD068: DC520000 987C0003
	global_load_b32 v150, v[5:6], off                          // 0000001CD070: DC520000 967C0005
	global_load_b32 v149, v[7:8], off                          // 0000001CD078: DC520000 957C0007
	global_load_b32 v148, v[9:10], off                         // 0000001CD080: DC520000 947C0009
	global_load_b32 v147, v[11:12], off                        // 0000001CD088: DC520000 937C000B
	.long 0xd7006a03                                           // 0000001CD090: D7006A03
	v_cndmask_b32_e32 v1, 0x12c000, v1, vcc_lo                 // 0000001CD094: 020202FF 0012C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CD09C: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001CD0A0: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001CD0A8: D7006A05
	v_cndmask_b32_e32 v1, 0x132000, v1, vcc_lo                 // 0000001CD0AC: 020202FF 00132000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CD0B4: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD0BC: 986A80C1
	s_cmp_gt_i32 s0, 51                                        // 0000001CD0C0: BF02B300
	v_dual_cndmask_b32 v4, v126, v4 :: v_dual_cndmask_b32 v3, v125, v3// 0000001CD0C4: CA52097E 0402077D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD0CC: 986A80C1
	s_cmp_gt_i32 s0, 52                                        // 0000001CD0D0: BF02B400
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CD0D4: CA520D7E 06040B7D
	.long 0xd7006a07                                           // 0000001CD0DC: D7006A07
	v_cndmask_b32_e32 v1, 0x138000, v1, vcc_lo                 // 0000001CD0E0: 020202FF 00138000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CD0E8: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CD0EC: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD0F4: 986A80C1
	global_load_b32 v153, v[3:4], off                          // 0000001CD0F8: DC520000 997C0003
	global_load_b32 v151, v[5:6], off                          // 0000001CD100: DC520000 977C0005
	v_dual_cndmask_b32 v4, v126, v8 :: v_dual_cndmask_b32 v3, v125, v7// 0000001CD108: CA52117E 04020F7D
	.long 0xd7006a05                                           // 0000001CD110: D7006A05
	v_cndmask_b32_e32 v1, 0x13e000, v1, vcc_lo                 // 0000001CD114: 020202FF 0013E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CD11C: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CD120: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001CD128: D7006A07
	v_cndmask_b32_e32 v1, 0x144000, v1, vcc_lo                 // 0000001CD12C: 020202FF 00144000
	s_cmp_gt_i32 s0, 53                                        // 0000001CD134: BF02B500
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CD138: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD140: 986A80C1
	s_cmp_gt_i32 s0, 54                                        // 0000001CD144: BF02B600
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CD148: CA520D7E 06040B7D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD150: 986A80C1
	s_cmp_gt_i32 s0, 55                                        // 0000001CD154: BF02B700
	v_dual_cndmask_b32 v8, v126, v8 :: v_dual_cndmask_b32 v7, v125, v7// 0000001CD158: CA52117E 08060F7D
	.long 0xd7006a09                                           // 0000001CD160: D7006A09
	v_cndmask_b32_e32 v1, 0x14a000, v1, vcc_lo                 // 0000001CD164: 020202FF 0014A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CD16C: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001CD170: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001CD178: D7006A0B
	v_cndmask_b32_e32 v1, 0x150000, v1, vcc_lo                 // 0000001CD17C: 020202FF 00150000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001CD184: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD18C: 986A80C1
	s_cmp_gt_i32 s0, 56                                        // 0000001CD190: BF02B800
	v_dual_cndmask_b32 v10, v126, v10 :: v_dual_cndmask_b32 v9, v125, v9// 0000001CD194: CA52157E 0A08137D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD19C: 986A80C1
	s_cmp_gt_i32 s0, 57                                        // 0000001CD1A0: BF02B900
	v_dual_cndmask_b32 v12, v126, v12 :: v_dual_cndmask_b32 v11, v125, v11// 0000001CD1A4: CA52197E 0C0A177D
	global_load_b32 v158, v[3:4], off                          // 0000001CD1AC: DC520000 9E7C0003
	global_load_b32 v157, v[5:6], off                          // 0000001CD1B4: DC520000 9D7C0005
	global_load_b32 v156, v[7:8], off                          // 0000001CD1BC: DC520000 9C7C0007
	global_load_b32 v155, v[9:10], off                         // 0000001CD1C4: DC520000 9B7C0009
	global_load_b32 v154, v[11:12], off                        // 0000001CD1CC: DC520000 9A7C000B
	.long 0xd7006a03                                           // 0000001CD1D4: D7006A03
	v_cndmask_b32_e32 v1, 0x156000, v1, vcc_lo                 // 0000001CD1D8: 020202FF 00156000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CD1E0: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001CD1E4: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001CD1EC: D7006A05
	v_cndmask_b32_e32 v1, 0x15c000, v1, vcc_lo                 // 0000001CD1F0: 020202FF 0015C000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CD1F8: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD200: 986A80C1
	s_cmp_gt_i32 s0, 58                                        // 0000001CD204: BF02BA00
	v_dual_cndmask_b32 v4, v126, v4 :: v_dual_cndmask_b32 v3, v125, v3// 0000001CD208: CA52097E 0402077D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD210: 986A80C1
	s_cmp_gt_i32 s0, 59                                        // 0000001CD214: BF02BB00
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CD218: CA520D7E 06040B7D
	.long 0xd7006a07                                           // 0000001CD220: D7006A07
	v_cndmask_b32_e32 v1, 0x162000, v1, vcc_lo                 // 0000001CD224: 020202FF 00162000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CD22C: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CD230: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD238: 986A80C1
	global_load_b32 v159, v[3:4], off                          // 0000001CD23C: DC520000 9F7C0003
	global_load_b32 v160, v[5:6], off                          // 0000001CD244: DC520000 A07C0005
	v_dual_cndmask_b32 v4, v126, v8 :: v_dual_cndmask_b32 v3, v125, v7// 0000001CD24C: CA52117E 04020F7D
	.long 0xd7006a05                                           // 0000001CD254: D7006A05
	v_cndmask_b32_e32 v1, 0x168000, v1, vcc_lo                 // 0000001CD258: 020202FF 00168000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CD260: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001CD264: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001CD26C: D7006A07
	v_cndmask_b32_e32 v1, 0x16e000, v1, vcc_lo                 // 0000001CD270: 020202FF 0016E000
	s_cmp_gt_i32 s0, 60                                        // 0000001CD278: BF02BC00
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001CD27C: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD284: 986A80C1
	s_cmp_gt_i32 s0, 61                                        // 0000001CD288: BF02BD00
	v_dual_cndmask_b32 v6, v126, v6 :: v_dual_cndmask_b32 v5, v125, v5// 0000001CD28C: CA520D7E 06040B7D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD294: 986A80C1
	s_cmp_gt_i32 s0, 62                                        // 0000001CD298: BF02BE00
	v_dual_cndmask_b32 v8, v126, v8 :: v_dual_cndmask_b32 v7, v125, v7// 0000001CD29C: CA52117E 08060F7D
	.long 0xd7006a09                                           // 0000001CD2A4: D7006A09
	v_cndmask_b32_e32 v1, 0x174000, v1, vcc_lo                 // 0000001CD2A8: 020202FF 00174000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CD2B0: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001CD2B4: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001CD2BC: D7006A0B
	v_cndmask_b32_e32 v1, 0x17a000, v1, vcc_lo                 // 0000001CD2C0: 020202FF 0017A000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001CD2C8: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD2D0: 986A80C1
	s_cmp_gt_i32 s0, 63                                        // 0000001CD2D4: BF02BF00
	v_dual_cndmask_b32 v2, v126, v10 :: v_dual_cndmask_b32 v1, v125, v9// 0000001CD2D8: CA52157E 0200137D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CD2E0: 986A80C1
	s_cmp_gt_i32 s50, s42                                      // 0000001CD2E4: BF022A32
	v_dual_cndmask_b32 v10, v126, v12 :: v_dual_cndmask_b32 v9, v125, v11// 0000001CD2E8: CA52197E 0A08177D
	global_load_b32 v165, v[3:4], off                          // 0000001CD2F0: DC520000 A57C0003
	global_load_b32 v164, v[5:6], off                          // 0000001CD2F8: DC520000 A47C0005
	global_load_b32 v162, v[7:8], off                          // 0000001CD300: DC520000 A27C0007
	global_load_b32 v161, v[1:2], off                          // 0000001CD308: DC520000 A17C0001
	global_load_b32 v163, v[9:10], off                         // 0000001CD310: DC520000 A37C0009
	s_cselect_b32 s0, -1, 0                                    // 0000001CD318: 980080C1
	s_or_b32 s1, s42, 1                                        // 0000001CD31C: 8C01812A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001CD320: BF8704B9
	s_cmp_lt_i32 s1, s50                                       // 0000001CD324: BF043201
	s_cselect_b32 s1, -1, 0                                    // 0000001CD328: 980180C1
	s_or_b32 s8, s42, 2                                        // 0000001CD32C: 8C08822A
	s_cmp_lt_i32 s8, s50                                       // 0000001CD330: BF043208
	s_cselect_b32 s8, -1, 0                                    // 0000001CD334: 980880C1
	s_or_b32 s9, s42, 3                                        // 0000001CD338: 8C09832A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001CD33C: BF8704B9
	s_cmp_lt_i32 s9, s50                                       // 0000001CD340: BF043209
	s_cselect_b32 s9, -1, 0                                    // 0000001CD344: 980980C1
	s_or_b32 s10, s42, 4                                       // 0000001CD348: 8C0A842A
	s_cmp_lt_i32 s10, s50                                      // 0000001CD34C: BF04320A
	s_cselect_b32 s10, -1, 0                                   // 0000001CD350: 980A80C1
	s_or_b32 s11, s42, 5                                       // 0000001CD354: 8C0B852A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001CD358: BF8704B9
	s_cmp_lt_i32 s11, s50                                      // 0000001CD35C: BF04320B
	s_cselect_b32 s11, -1, 0                                   // 0000001CD360: 980B80C1
	s_or_b32 s12, s42, 6                                       // 0000001CD364: 8C0C862A
	s_cmp_lt_i32 s12, s50                                      // 0000001CD368: BF04320C
	s_cselect_b32 s12, -1, 0                                   // 0000001CD36C: 980C80C1
	s_or_b32 s13, s42, 7                                       // 0000001CD370: 8C0D872A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001CD374: BF8704B9
	s_cmp_lt_i32 s13, s50                                      // 0000001CD378: BF04320D
	s_cselect_b32 s13, -1, 0                                   // 0000001CD37C: 980D80C1
	s_or_b32 s14, s42, 8                                       // 0000001CD380: 8C0E882A
	s_cmp_lt_i32 s14, s50                                      // 0000001CD384: BF04320E
	s_cselect_b32 s14, -1, 0                                   // 0000001CD388: 980E80C1
	s_or_b32 s43, s42, 9                                       // 0000001CD38C: 8C2B892A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001CD390: BF8704B9
	s_cmp_lt_i32 s43, s50                                      // 0000001CD394: BF04322B
	s_cselect_b32 s43, -1, 0                                   // 0000001CD398: 982B80C1
	s_or_b32 s54, s42, 10                                      // 0000001CD39C: 8C368A2A
	s_cmp_lt_i32 s54, s50                                      // 0000001CD3A0: BF043236
	s_cselect_b32 s54, -1, 0                                   // 0000001CD3A4: 983680C1
	s_or_b32 s55, s42, 11                                      // 0000001CD3A8: 8C378B2A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001CD3AC: BF8704B9
	s_cmp_lt_i32 s55, s50                                      // 0000001CD3B0: BF043237
	s_cselect_b32 s55, -1, 0                                   // 0000001CD3B4: 983780C1
	s_or_b32 s56, s42, 12                                      // 0000001CD3B8: 8C388C2A
	s_cmp_lt_i32 s56, s50                                      // 0000001CD3BC: BF043238
	s_cselect_b32 s56, -1, 0                                   // 0000001CD3C0: 983880C1
	s_or_b32 s57, s42, 13                                      // 0000001CD3C4: 8C398D2A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001CD3C8: BF8704B9
	s_cmp_lt_i32 s57, s50                                      // 0000001CD3CC: BF043239
	s_cselect_b32 s57, -1, 0                                   // 0000001CD3D0: 983980C1
	s_or_b32 s58, s42, 14                                      // 0000001CD3D4: 8C3A8E2A
	s_cmp_lt_i32 s58, s50                                      // 0000001CD3D8: BF04323A
	s_cselect_b32 s58, -1, 0                                   // 0000001CD3DC: 983A80C1
	s_or_b32 s59, s42, 15                                      // 0000001CD3E0: 8C3B8F2A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001CD3E4: BF8704B9
	s_cmp_lt_i32 s59, s50                                      // 0000001CD3E8: BF04323B
	s_cselect_b32 s59, -1, 0                                   // 0000001CD3EC: 983B80C1
	s_or_b32 s60, s42, 16                                      // 0000001CD3F0: 8C3C902A
	s_cmp_lt_i32 s60, s50                                      // 0000001CD3F4: BF04323C
	s_cselect_b32 s60, -1, 0                                   // 0000001CD3F8: 983C80C1
	s_or_b32 s61, s42, 17                                      // 0000001CD3FC: 8C3D912A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001CD400: BF8704B9
	s_cmp_lt_i32 s61, s50                                      // 0000001CD404: BF04323D
	s_cselect_b32 s61, -1, 0                                   // 0000001CD408: 983D80C1
	s_or_b32 s62, s42, 18                                      // 0000001CD40C: 8C3E922A
	s_cmp_lt_i32 s62, s50                                      // 0000001CD410: BF04323E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001CD414: BF890007
	s_barrier                                                  // 0000001CD418: BFBD0000
	buffer_gl0_inv                                             // 0000001CD41C: E0AC0000 00000000
	ds_load_b128 v[166:169], v107 offset:61440                 // 0000001CD424: DBFCF000 A600006B
	ds_load_b128 v[170:173], v107 offset:61456                 // 0000001CD42C: DBFCF010 AA00006B
	ds_load_b128 v[174:177], v107 offset:61472                 // 0000001CD434: DBFCF020 AE00006B
	ds_load_b128 v[178:181], v107 offset:61488                 // 0000001CD43C: DBFCF030 B200006B
	ds_load_b128 v[182:185], v107 offset:61504                 // 0000001CD444: DBFCF040 B600006B
	ds_load_b128 v[186:189], v107 offset:61520                 // 0000001CD44C: DBFCF050 BA00006B
	s_waitcnt lgkmcnt(5)                                       // 0000001CD454: BF89FC57
	v_dual_mul_f32 v17, v17, v166 :: v_dual_add_nc_u32 v190, s42, v128// 0000001CD458: C8E14D11 11BF002A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001CD460: BF8701C1
	v_min_i32_e32 v1, s52, v190                                // 0000001CD464: 22037C34
	v_dual_mul_f32 v18, v18, v167 :: v_dual_mul_f32 v19, v19, v168// 0000001CD468: C8C74F12 12135113
	s_waitcnt lgkmcnt(4)                                       // 0000001CD470: BF89FC47
	v_dual_mul_f32 v20, v20, v169 :: v_dual_mul_f32 v21, v21, v170// 0000001CD474: C8C75314 14155515
	v_mad_i64_i32 v[1:2], null, v1, 48, s[2:3]                 // 0000001CD47C: D6FF7C01 00096101
	v_dual_mul_f32 v22, v22, v171 :: v_dual_mul_f32 v23, v23, v172// 0000001CD484: C8C75716 16175917
	s_waitcnt lgkmcnt(3)                                       // 0000001CD48C: BF89FC37
	v_dual_mul_f32 v24, v24, v173 :: v_dual_mul_f32 v25, v25, v174// 0000001CD490: C8C75B18 18195D19
	v_dual_mul_f32 v26, v26, v175 :: v_dual_mul_f32 v27, v27, v176// 0000001CD498: C8C75F1A 1A1B611B
	s_waitcnt lgkmcnt(2)                                       // 0000001CD4A0: BF89FC27
	v_dual_mul_f32 v28, v28, v177 :: v_dual_mul_f32 v29, v29, v178// 0000001CD4A4: C8C7631C 1C1D651D
	.long 0xd73c0062                                           // 0000001CD4AC: D73C0062
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000001CD4B0: 02020288
	v_dual_mul_f32 v30, v30, v179 :: v_dual_mul_f32 v31, v31, v180// 0000001CD4B4: C8C7671E 1E1F691F
	s_waitcnt lgkmcnt(1)                                       // 0000001CD4BC: BF89FC17
	v_dual_mul_f32 v32, v32, v181 :: v_dual_mul_f32 v41, v41, v182// 0000001CD4C0: C8C76B20 20296D29
	v_mul_f32_e32 v50, v50, v185                               // 0000001CD4C8: 10657332
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CD4CC: BF870094
	.long 0xd7006a05                                           // 0000001CD4D0: D7006A05
	v_cndmask_b32_e32 v1, s46, v98, vcc_lo                     // 0000001CD4D4: 0202C42E
	v_add_co_ci_u32_e64 v6, null, s47, v99, vcc_lo             // 0000001CD4D8: D5207C06 01AAC62F
	s_clause 0xf                                               // 0000001CD4E0: BF85000F
	global_load_b128 v[89:92], v[5:6], off                     // 0000001CD4E4: DC5E0000 597C0005
	global_load_b128 v[93:96], v[5:6], off offset:16           // 0000001CD4EC: DC5E0010 5D7C0005
	global_load_b128 v[81:84], v[5:6], off offset:32           // 0000001CD4F4: DC5E0020 517C0005
	global_load_b128 v[85:88], v[5:6], off offset:48           // 0000001CD4FC: DC5E0030 557C0005
	global_load_b128 v[73:76], v[5:6], off offset:64           // 0000001CD504: DC5E0040 497C0005
	global_load_b128 v[77:80], v[5:6], off offset:80           // 0000001CD50C: DC5E0050 4D7C0005
	global_load_b128 v[65:68], v[5:6], off offset:96           // 0000001CD514: DC5E0060 417C0005
	global_load_b128 v[69:72], v[5:6], off offset:112          // 0000001CD51C: DC5E0070 457C0005
	global_load_b128 v[57:60], v[5:6], off offset:128          // 0000001CD524: DC5E0080 397C0005
	global_load_b128 v[61:64], v[5:6], off offset:144          // 0000001CD52C: DC5E0090 3D7C0005
	global_load_b128 v[33:36], v[5:6], off offset:160          // 0000001CD534: DC5E00A0 217C0005
	global_load_b128 v[37:40], v[5:6], off offset:176          // 0000001CD53C: DC5E00B0 257C0005
	global_load_b128 v[9:12], v[5:6], off offset:192           // 0000001CD544: DC5E00C0 097C0005
	global_load_b128 v[13:16], v[5:6], off offset:208          // 0000001CD54C: DC5E00D0 0D7C0005
	global_load_b128 v[1:4], v[5:6], off offset:224            // 0000001CD554: DC5E00E0 017C0005
	global_load_b128 v[5:8], v[5:6], off offset:240            // 0000001CD55C: DC5E00F0 057C0005
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001CD564: CC210011 02004F11
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001CD56C: CC220011 02004F12
	v_fma_mixlo_f16 v18, v19, s39, 0                           // 0000001CD574: CC210012 02004F13
	v_fma_mixhi_f16 v18, v20, s39, 0                           // 0000001CD57C: CC220012 02004F14
	v_fma_mixlo_f16 v19, v21, s39, 0                           // 0000001CD584: CC210013 02004F15
	v_fma_mixhi_f16 v19, v22, s39, 0                           // 0000001CD58C: CC220013 02004F16
	v_fma_mixlo_f16 v20, v23, s39, 0                           // 0000001CD594: CC210014 02004F17
	v_fma_mixhi_f16 v20, v24, s39, 0                           // 0000001CD59C: CC220014 02004F18
	v_fma_mixlo_f16 v21, v25, s39, 0                           // 0000001CD5A4: CC210015 02004F19
	v_fma_mixlo_f16 v22, v27, s39, 0                           // 0000001CD5AC: CC210016 02004F1B
	v_fma_mixhi_f16 v22, v28, s39, 0                           // 0000001CD5B4: CC220016 02004F1C
	v_fma_mixlo_f16 v23, v29, s39, 0                           // 0000001CD5BC: CC210017 02004F1D
	v_fma_mixhi_f16 v23, v30, s39, 0                           // 0000001CD5C4: CC220017 02004F1E
	v_fma_mixlo_f16 v24, v31, s39, 0                           // 0000001CD5CC: CC210018 02004F1F
	v_fma_mixhi_f16 v24, v32, s39, 0                           // 0000001CD5D4: CC220018 02004F20
	v_fma_mixlo_f16 v25, v41, s39, 0                           // 0000001CD5DC: CC210019 02004F29
	ds_load_b128 v[29:32], v107 offset:61536                   // 0000001CD5E4: DBFCF060 1D00006B
	s_waitcnt lgkmcnt(1)                                       // 0000001CD5EC: BF89FC17
	v_dual_mul_f32 v27, v42, v186 :: v_dual_mul_f32 v28, v43, v187// 0000001CD5F0: C8C7752A 1B1D772B
	v_dual_mul_f32 v41, v45, v188 :: v_dual_mul_f32 v48, v48, v183// 0000001CD5F8: C8C7792D 29316F30
	v_mul_f32_e32 v49, v49, v184                               // 0000001CD600: 10637131
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CD604: BF870213
	v_fma_mixlo_f16 v27, v27, s39, 0                           // 0000001CD608: CC21001B 02004F1B
	v_fma_mixhi_f16 v27, v28, s39, 0                           // 0000001CD610: CC22001B 02004F1C
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CD618: BF870004
	v_fma_mixlo_f16 v28, v41, s39, 0                           // 0000001CD61C: CC21001C 02004F29
	v_mul_f32_e32 v45, v44, v189                               // 0000001CD624: 105B7B2C
	ds_load_b128 v[41:44], v107 offset:61552                   // 0000001CD628: DBFCF070 2900006B
	v_fma_mixhi_f16 v21, v26, s39, 0                           // 0000001CD630: CC220015 02004F1A
	v_fma_mixlo_f16 v26, v49, s39, 0                           // 0000001CD638: CC21001A 02004F31
	v_cndmask_b16 v17, 0, v17, s0                              // 0000001CD640: D65D0011 00022280
	v_cndmask_b16 v17, 0, v17, s1                              // 0000001CD648: D65D5011 00062280
	s_cselect_b32 s0, -1, 0                                    // 0000001CD650: 980080C1
	s_or_b32 s1, s42, 19                                       // 0000001CD654: 8C01932A
	v_fma_mixhi_f16 v26, v50, s39, 0                           // 0000001CD658: CC22001A 02004F32
	s_cmp_lt_i32 s1, s50                                       // 0000001CD660: BF043201
	v_cndmask_b16 v26, 0, v26, s0                              // 0000001CD664: D65D001A 00023480
	s_cselect_b32 s0, -1, 0                                    // 0000001CD66C: 980080C1
	s_or_b32 s1, s42, 20                                       // 0000001CD670: 8C01942A
	v_cndmask_b16 v26, 0, v26, s0                              // 0000001CD674: D65D501A 00023480
	s_cmp_lt_i32 s1, s50                                       // 0000001CD67C: BF043201
	s_waitcnt lgkmcnt(1)                                       // 0000001CD680: BF89FC17
	v_dual_mul_f32 v29, v55, v29 :: v_dual_mul_f32 v30, v52, v30// 0000001CD684: C8C63B37 1D1E3D34
	s_cselect_b32 s0, -1, 0                                    // 0000001CD68C: 980080C1
	s_or_b32 s1, s42, 21                                       // 0000001CD690: 8C01952A
	v_mul_f32_e32 v31, v51, v31                                // 0000001CD694: 103E3F33
	s_cmp_lt_i32 s1, s50                                       // 0000001CD698: BF043201
	v_cndmask_b16 v18, 0, v18, s8                              // 0000001CD69C: D65D0012 00222480
	s_cselect_b32 s1, -1, 0                                    // 0000001CD6A4: 980180C1
	s_or_b32 s8, s42, 22                                       // 0000001CD6A8: 8C08962A
	v_cndmask_b16 v27, 0, v27, s0                              // 0000001CD6AC: D65D001B 00023680
	s_cmp_lt_i32 s8, s50                                       // 0000001CD6B4: BF043208
	v_fma_mixlo_f16 v29, v29, s39, 0                           // 0000001CD6B8: CC21001D 02004F1D
	s_cselect_b32 s0, -1, 0                                    // 0000001CD6C0: 980080C1
	v_fma_mixhi_f16 v29, v30, s39, 0                           // 0000001CD6C4: CC22001D 02004F1E
	v_fma_mixlo_f16 v30, v31, s39, 0                           // 0000001CD6CC: CC21001E 02004F1F
	s_waitcnt lgkmcnt(0)                                       // 0000001CD6D4: BF89FC07
	v_dual_mul_f32 v31, v46, v32 :: v_dual_mul_f32 v32, v47, v41// 0000001CD6D8: C8C6412E 1F20532F
	v_cndmask_b16 v28, 0, v28, s0                              // 0000001CD6E0: D65D001C 00023880
	s_or_b32 s0, s42, 23                                       // 0000001CD6E8: 8C00972A
	v_cndmask_b16 v27, 0, v27, s1                              // 0000001CD6EC: D65D501B 00063680
	s_cmp_lt_i32 s0, s50                                       // 0000001CD6F4: BF043200
	v_fma_mixhi_f16 v30, v31, s39, 0                           // 0000001CD6F8: CC22001E 02004F1F
	v_fma_mixlo_f16 v31, v32, s39, 0                           // 0000001CD700: CC21001F 02004F20
	v_mul_f32_e32 v32, v53, v42                                // 0000001CD708: 10405535
	v_fma_mixhi_f16 v28, v45, s39, 0                           // 0000001CD70C: CC22001C 02004F2D
	s_cselect_b32 s0, -1, 0                                    // 0000001CD714: 980080C1
	s_or_b32 s1, s42, 24                                       // 0000001CD718: 8C01982A
	v_fma_mixhi_f16 v25, v48, s39, 0                           // 0000001CD71C: CC220019 02004F30
	s_cmp_lt_i32 s1, s50                                       // 0000001CD724: BF043201
	v_cndmask_b16 v28, 0, v28, s0                              // 0000001CD728: D65D501C 00023880
	s_cselect_b32 s0, -1, 0                                    // 0000001CD730: 980080C1
	ds_load_b128 v[45:48], v107 offset:61568                   // 0000001CD734: DBFCF080 2D00006B
	v_cndmask_b16 v29, 0, v29, s0                              // 0000001CD73C: D65D001D 00023A80
	s_or_b32 s0, s42, 25                                       // 0000001CD744: 8C00992A
	v_cndmask_b16 v18, 0, v18, s9                              // 0000001CD748: D65D5012 00262480
	s_cmp_lt_i32 s0, s50                                       // 0000001CD750: BF043200
	v_cndmask_b16 v19, 0, v19, s10                             // 0000001CD754: D65D0013 002A2680
	s_cselect_b32 s0, -1, 0                                    // 0000001CD75C: 980080C1
	s_or_b32 s1, s42, 26                                       // 0000001CD760: 8C019A2A
	v_cndmask_b16 v29, 0, v29, s0                              // 0000001CD764: D65D501D 00023A80
	s_cmp_lt_i32 s1, s50                                       // 0000001CD76C: BF043201
	v_cndmask_b16 v19, 0, v19, s11                             // 0000001CD770: D65D5013 002E2680
	s_cselect_b32 s0, -1, 0                                    // 0000001CD778: 980080C1
	v_cndmask_b16 v20, 0, v20, s12                             // 0000001CD77C: D65D0014 00322880
	v_cndmask_b16 v30, 0, v30, s0                              // 0000001CD784: D65D001E 00023C80
	s_or_b32 s0, s42, 27                                       // 0000001CD78C: 8C009B2A
	v_cndmask_b16 v20, 0, v20, s13                             // 0000001CD790: D65D5014 00362880
	s_cmp_lt_i32 s0, s50                                       // 0000001CD798: BF043200
	v_cndmask_b16 v21, 0, v21, s14                             // 0000001CD79C: D65D0015 003A2A80
	s_cselect_b32 s0, -1, 0                                    // 0000001CD7A4: 980080C1
	s_or_b32 s1, s42, 28                                       // 0000001CD7A8: 8C019C2A
	v_cndmask_b16 v30, 0, v30, s0                              // 0000001CD7AC: D65D501E 00023C80
	s_cmp_lt_i32 s1, s50                                       // 0000001CD7B4: BF043201
	v_cndmask_b16 v21, 0, v21, s43                             // 0000001CD7B8: D65D5015 00AE2A80
	s_cselect_b32 s0, -1, 0                                    // 0000001CD7C0: 980080C1
	s_or_b32 s1, s42, 29                                       // 0000001CD7C4: 8C019D2A
	v_cndmask_b16 v22, 0, v22, s54                             // 0000001CD7C8: D65D0016 00DA2C80
	v_cndmask_b16 v22, 0, v22, s55                             // 0000001CD7D0: D65D5016 00DE2C80
	v_cndmask_b16 v23, 0, v23, s56                             // 0000001CD7D8: D65D0017 00E22E80
	v_cndmask_b16 v23, 0, v23, s57                             // 0000001CD7E0: D65D5017 00E62E80
	v_cndmask_b16 v24, 0, v24, s58                             // 0000001CD7E8: D65D0018 00EA3080
	v_cndmask_b16 v24, 0, v24, s59                             // 0000001CD7F0: D65D5018 00EE3080
	s_cmp_lt_i32 s1, s50                                       // 0000001CD7F8: BF043201
	v_cndmask_b16 v31, 0, v31, s0                              // 0000001CD7FC: D65D001F 00023E80
	s_cselect_b32 s0, -1, 0                                    // 0000001CD804: 980080C1
	s_or_b32 s1, s42, 30                                       // 0000001CD808: 8C019E2A
	v_mul_f32_e32 v42, v105, v44                               // 0000001CD80C: 10545969
	s_cmp_lt_i32 s1, s50                                       // 0000001CD810: BF043201
	ds_store_b128 v127, v[17:20]                               // 0000001CD814: DB7C0000 0000117F
	ds_store_b128 v127, v[21:24] offset:16                     // 0000001CD81C: DB7C0010 0000157F
	ds_load_b128 v[17:20], v107 offset:61584                   // 0000001CD824: DBFCF090 1100006B
	v_fma_mixhi_f16 v31, v32, s39, 0                           // 0000001CD82C: CC22001F 02004F20
	s_waitcnt lgkmcnt(3)                                       // 0000001CD834: BF89FC37
	v_dual_mul_f32 v41, v54, v43 :: v_dual_mul_f32 v22, v101, v46// 0000001CD838: C8C65736 29165D65
	s_cselect_b32 s1, -1, 0                                    // 0000001CD840: 980180C1
	s_or_b32 s8, s42, 31                                       // 0000001CD844: 8C089F2A
	v_fma_mixhi_f16 v32, v42, s39, 0                           // 0000001CD848: CC220020 02004F2A
	s_cmp_lt_i32 s8, s50                                       // 0000001CD850: BF043208
	v_cndmask_b16 v31, 0, v31, s0                              // 0000001CD854: D65D501F 00023E80
	s_cselect_b32 s0, -1, 0                                    // 0000001CD85C: 980080C1
	v_mul_f32_e32 v21, v102, v45                               // 0000001CD860: 102A5B66
	v_fma_mixlo_f16 v32, v41, s39, 0                           // 0000001CD864: CC210020 02004F29
	v_cndmask_b16 v32, 0, v32, s0                              // 0000001CD86C: D65D5020 00024080
	s_or_b32 s0, s42, 32                                       // 0000001CD874: 8C00A02A
	v_cndmask_b16 v25, 0, v25, s60                             // 0000001CD878: D65D0019 00F23280
	s_cmp_lt_i32 s0, s50                                       // 0000001CD880: BF043200
	v_fma_mixlo_f16 v21, v21, s39, 0                           // 0000001CD884: CC210015 02004F15
	v_cndmask_b16 v32, 0, v32, s1                              // 0000001CD88C: D65D0020 00064080
	s_cselect_b32 s0, -1, 0                                    // 0000001CD894: 980080C1
	s_or_b32 s1, s42, 33                                       // 0000001CD898: 8C01A12A
	v_fma_mixhi_f16 v21, v22, s39, 0                           // 0000001CD89C: CC220015 02004F16
	s_cmp_lt_i32 s1, s50                                       // 0000001CD8A4: BF043201
	v_cndmask_b16 v25, 0, v25, s61                             // 0000001CD8A8: D65D5019 00F63280
	v_cndmask_b16 v21, 0, v21, s0                              // 0000001CD8B0: D65D0015 00022A80
	s_cselect_b32 s0, -1, 0                                    // 0000001CD8B8: 980080C1
	s_or_b32 s1, s42, 34                                       // 0000001CD8BC: 8C01A22A
	v_mul_f32_e32 v22, v56, v47                                // 0000001CD8C0: 102C5F38
	s_cmp_lt_i32 s1, s50                                       // 0000001CD8C4: BF043201
	v_mul_f32_e32 v23, v100, v48                               // 0000001CD8C8: 102E6164
	v_cndmask_b16 v21, 0, v21, s0                              // 0000001CD8CC: D65D5015 00022A80
	s_cselect_b32 s0, -1, 0                                    // 0000001CD8D4: 980080C1
	s_or_b32 s1, s42, 35                                       // 0000001CD8D8: 8C01A32A
	s_waitcnt lgkmcnt(0)                                       // 0000001CD8DC: BF89FC07
	v_mul_f32_e32 v24, v104, v17                               // 0000001CD8E0: 10302368
	ds_store_b128 v127, v[25:28] offset:32                     // 0000001CD8E4: DB7C0020 0000197F
	ds_store_b128 v127, v[29:32] offset:48                     // 0000001CD8EC: DB7C0030 00001D7F
	ds_load_b128 v[25:28], v107 offset:61600                   // 0000001CD8F4: DBFCF0A0 1900006B
	s_cmp_lt_i32 s1, s50                                       // 0000001CD8FC: BF043201
	v_fma_mixlo_f16 v22, v22, s39, 0                           // 0000001CD900: CC210016 02004F16
	s_cselect_b32 s1, -1, 0                                    // 0000001CD908: 980180C1
	v_fma_mixlo_f16 v17, v23, s39, 0                           // 0000001CD90C: CC210011 02004F17
	s_or_b32 s8, s42, 36                                       // 0000001CD914: 8C08A42A
	v_fma_mixhi_f16 v17, v24, s39, 0                           // 0000001CD918: CC220011 02004F18
	s_cmp_lt_i32 s8, s50                                       // 0000001CD920: BF043208
	v_cndmask_b16 v22, 0, v22, s0                              // 0000001CD924: D65D0016 00022C80
	s_cselect_b32 s0, -1, 0                                    // 0000001CD92C: 980080C1
	v_cndmask_b16 v22, 0, v17, s1                              // 0000001CD930: D65D4016 00062280
	s_or_b32 s1, s42, 37                                       // 0000001CD938: 8C01A52A
	v_cndmask_b16 v23, 0, v17, s0                              // 0000001CD93C: D65D1017 00022280
	v_dual_mul_f32 v17, v103, v18 :: v_dual_mul_f32 v18, v145, v19// 0000001CD944: C8C62567 11122791
	s_cmp_lt_i32 s1, s50                                       // 0000001CD94C: BF043201
	v_mul_f32_e32 v19, v144, v20                               // 0000001CD950: 10262990
	s_cselect_b32 s0, -1, 0                                    // 0000001CD954: 980080C1
	s_or_b32 s1, s42, 38                                       // 0000001CD958: 8C01A62A
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001CD95C: CC210011 02004F11
	s_cmp_lt_i32 s1, s50                                       // 0000001CD964: BF043201
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001CD968: CC220011 02004F12
	s_cselect_b32 s1, -1, 0                                    // 0000001CD970: 980180C1
	s_or_b32 s8, s42, 39                                       // 0000001CD974: 8C08A72A
	v_fma_mixhi_f16 v24, v19, s39, 0                           // 0000001CD978: CC220018 02004F13
	s_cmp_lt_i32 s8, s50                                       // 0000001CD980: BF043208
	v_cndmask_b16 v23, 0, v17, s0                              // 0000001CD984: D65D4017 00022280
	v_cndmask_b16 v24, 0, v17, s1                              // 0000001CD98C: D65D1018 00062280
	ds_load_b128 v[17:20], v107 offset:61616                   // 0000001CD994: DBFCF0B0 1100006B
	s_cselect_b32 s0, -1, 0                                    // 0000001CD99C: 980080C1
	s_waitcnt lgkmcnt(1)                                       // 0000001CD9A0: BF89FC17
	v_mul_f32_e32 v25, v142, v25                               // 0000001CD9A4: 1032338E
	v_cndmask_b16 v24, 0, v24, s0                              // 0000001CD9A8: D65D5018 00023080
	s_or_b32 s0, s42, 40                                       // 0000001CD9B0: 8C00A82A
	v_mul_f32_e32 v26, v117, v26                               // 0000001CD9B4: 10343575
	s_cmp_lt_i32 s0, s50                                       // 0000001CD9B8: BF043200
	v_fma_mixlo_f16 v25, v25, s39, 0                           // 0000001CD9BC: CC210019 02004F19
	s_cselect_b32 s0, -1, 0                                    // 0000001CD9C4: 980080C1
	s_or_b32 s1, s42, 41                                       // 0000001CD9C8: 8C01A92A
	v_fma_mixhi_f16 v25, v26, s39, 0                           // 0000001CD9CC: CC220019 02004F1A
	s_cmp_lt_i32 s1, s50                                       // 0000001CD9D4: BF043201
	v_cndmask_b16 v25, 0, v25, s0                              // 0000001CD9D8: D65D0019 00023280
	s_cselect_b32 s0, -1, 0                                    // 0000001CD9E0: 980080C1
	v_mul_f32_e32 v26, v116, v27                               // 0000001CD9E4: 10343774
	v_cndmask_b16 v25, 0, v25, s0                              // 0000001CD9E8: D65D5019 00023280
	s_or_b32 s0, s42, 42                                       // 0000001CD9F0: 8C00AA2A
	v_mul_f32_e32 v27, v146, v28                               // 0000001CD9F4: 10363992
	s_cmp_lt_i32 s0, s50                                       // 0000001CD9F8: BF043200
	v_fma_mixlo_f16 v26, v26, s39, 0                           // 0000001CD9FC: CC21001A 02004F1A
	s_cselect_b32 s0, -1, 0                                    // 0000001CDA04: 980080C1
	s_or_b32 s1, s42, 43                                       // 0000001CDA08: 8C01AB2A
	s_waitcnt lgkmcnt(0)                                       // 0000001CDA0C: BF89FC07
	v_mul_f32_e32 v18, v152, v18                               // 0000001CDA10: 10242598
	s_cmp_lt_i32 s1, s50                                       // 0000001CDA14: BF043201
	v_fma_mixhi_f16 v26, v27, s39, 0                           // 0000001CDA18: CC22001A 02004F1B
	v_cndmask_b16 v26, 0, v26, s0                              // 0000001CDA20: D65D001A 00023480
	s_cselect_b32 s0, -1, 0                                    // 0000001CDA28: 980080C1
	s_or_b32 s1, s42, 44                                       // 0000001CDA2C: 8C01AC2A
	v_mul_f32_e32 v17, v143, v17                               // 0000001CDA30: 1022238F
	ds_load_b128 v[28:31], v107 offset:61632                   // 0000001CDA34: DBFCF0C0 1C00006B
	s_cmp_lt_i32 s1, s50                                       // 0000001CDA3C: BF043201
	v_cndmask_b16 v26, 0, v26, s0                              // 0000001CDA40: D65D501A 00023480
	s_cselect_b32 s0, -1, 0                                    // 0000001CDA48: 980080C1
	s_or_b32 s1, s42, 45                                       // 0000001CDA4C: 8C01AD2A
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001CDA50: CC210011 02004F11
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001CDA58: CC220011 02004F12
	v_mul_f32_e32 v18, v150, v19                               // 0000001CDA60: 10242796
	s_cmp_lt_i32 s1, s50                                       // 0000001CDA64: BF043201
	v_mul_f32_e32 v41, v149, v20                               // 0000001CDA68: 10522995
	s_cselect_b32 s1, -1, 0                                    // 0000001CDA6C: 980180C1
	v_cndmask_b16 v27, 0, v17, s0                              // 0000001CDA70: D65D001B 00022280
	v_cndmask_b16 v27, 0, v17, s1                              // 0000001CDA78: D65D501B 00062280
	v_fma_mixlo_f16 v32, v18, s39, 0                           // 0000001CDA80: CC210020 02004F12
	ds_load_b128 v[17:20], v107 offset:61648                   // 0000001CDA88: DBFCF0D0 1100006B
	s_or_b32 s8, s42, 46                                       // 0000001CDA90: 8C08AE2A
	v_cmp_le_i32_e32 vcc_lo, s50, v190                         // 0000001CDA94: 7C877C32
	s_cmp_lt_i32 s8, s50                                       // 0000001CDA98: BF043208
	s_cselect_b32 s0, -1, 0                                    // 0000001CDA9C: 980080C1
	s_or_b32 s8, s42, 47                                       // 0000001CDAA0: 8C08AF2A
	s_waitcnt lgkmcnt(1)                                       // 0000001CDAA4: BF89FC17
	v_dual_mul_f32 v42, v148, v28 :: v_dual_mul_f32 v29, v147, v29// 0000001CDAA8: C8C63994 2A1C3B93
	s_cmp_lt_i32 s8, s50                                       // 0000001CDAB0: BF043208
	v_mul_f32_e32 v30, v153, v30                               // 0000001CDAB4: 103C3D99
	s_cselect_b32 s1, -1, 0                                    // 0000001CDAB8: 980180C1
	s_or_b32 s8, s42, 48                                       // 0000001CDABC: 8C08B02A
	v_cndmask_b16 v28, 0, v32, s0                              // 0000001CDAC0: D65D001C 00024080
	v_fma_mixlo_f16 v32, v42, s39, 0                           // 0000001CDAC8: CC210020 02004F2A
	s_cmp_lt_i32 s8, s50                                       // 0000001CDAD0: BF043208
	v_fma_mixlo_f16 v29, v29, s39, 0                           // 0000001CDAD4: CC21001D 02004F1D
	s_cselect_b32 s0, -1, 0                                    // 0000001CDADC: 980080C1
	v_fma_mixhi_f16 v29, v30, s39, 0                           // 0000001CDAE0: CC22001D 02004F1E
	v_cndmask_b16 v49, 0, v32, s0                              // 0000001CDAE8: D65D0031 00024080
	s_waitcnt lgkmcnt(0)                                       // 0000001CDAF0: BF89FC07
	v_mul_f32_e32 v30, v158, v17                               // 0000001CDAF4: 103C239E
	v_fma_mixhi_f16 v28, v41, s39, 0                           // 0000001CDAF8: CC22001C 02004F29
	s_or_b32 s0, s42, 49                                       // 0000001CDB00: 8C00B12A
	v_mul_f32_e32 v18, v157, v18                               // 0000001CDB04: 1024259D
	s_cmp_lt_i32 s0, s50                                       // 0000001CDB08: BF043200
	v_fma_mixhi_f16 v17, v30, s39, 0                           // 0000001CDB0C: CC220011 02004F1E
	v_cndmask_b16 v28, 0, v28, s1                              // 0000001CDB14: D65D501C 00063880
	s_cselect_b32 s0, -1, 0                                    // 0000001CDB1C: 980080C1
	s_or_b32 s1, s42, 50                                       // 0000001CDB20: 8C01B22A
	v_cndmask_b16 v49, 0, v29, s0                              // 0000001CDB24: D65D4031 00023A80
	s_cmp_lt_i32 s1, s50                                       // 0000001CDB2C: BF043201
	ds_load_b128 v[41:44], v107 offset:61664                   // 0000001CDB30: DBFCF0E0 2900006B
	ds_load_b128 v[45:48], v107 offset:61680                   // 0000001CDB38: DBFCF0F0 2D00006B
	s_cselect_b32 s1, -1, 0                                    // 0000001CDB40: 980180C1
	s_or_b32 s8, s42, 51                                       // 0000001CDB44: 8C08B32A
	v_cndmask_b16 v50, 0, v29, s1                              // 0000001CDB48: D65D1032 00063A80
	v_mul_f32_e32 v29, v151, v31                               // 0000001CDB50: 103A3F97
	s_cmp_lt_i32 s8, s50                                       // 0000001CDB54: BF043208
	s_cselect_b32 s0, -1, 0                                    // 0000001CDB58: 980080C1
	s_or_b32 s1, s42, 52                                       // 0000001CDB5C: 8C01B42A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001CDB60: BF8700C1
	v_fma_mixlo_f16 v17, v29, s39, 0                           // 0000001CDB64: CC210011 02004F1D
	s_cmp_lt_i32 s1, s50                                       // 0000001CDB6C: BF043201
	s_cselect_b32 s1, -1, 0                                    // 0000001CDB70: 980180C1
	s_or_b32 s8, s42, 53                                       // 0000001CDB74: 8C08B52A
	v_cndmask_b16 v50, 0, v17, s0                              // 0000001CDB78: D65D4032 00022280
	v_cndmask_b16 v51, 0, v17, s1                              // 0000001CDB80: D65D1033 00062280
	v_mul_f32_e32 v17, v156, v19                               // 0000001CDB88: 1022279C
	v_fma_mixlo_f16 v18, v18, s39, 0                           // 0000001CDB8C: CC210012 02004F12
	s_cmp_lt_i32 s8, s50                                       // 0000001CDB94: BF043208
	s_waitcnt lgkmcnt(1)                                       // 0000001CDB98: BF89FC17
	v_mul_f32_e32 v19, v160, v43                               // 0000001CDB9C: 102657A0
	s_cselect_b32 s0, -1, 0                                    // 0000001CDBA0: 980080C1
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001CDBA4: CC210011 02004F11
	v_cndmask_b16 v51, 0, v18, s0                              // 0000001CDBAC: D65D4033 00022480
	s_or_b32 s0, s42, 54                                       // 0000001CDBB4: 8C00B62A
	v_mul_f32_e32 v18, v155, v20                               // 0000001CDBB8: 1024299B
	s_cmp_lt_i32 s0, s50                                       // 0000001CDBBC: BF043200
	s_waitcnt lgkmcnt(0)                                       // 0000001CDBC0: BF89FC07
	v_mul_f32_e32 v20, v164, v45                               // 0000001CDBC4: 10285BA4
	s_cselect_b32 s0, -1, 0                                    // 0000001CDBC8: 980080C1
	s_or_b32 s1, s42, 55                                       // 0000001CDBCC: 8C01B72A
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001CDBD0: CC220011 02004F12
	s_cmp_lt_i32 s1, s50                                       // 0000001CDBD8: BF043201
	v_cndmask_b16 v52, 0, v17, s0                              // 0000001CDBDC: D65D0034 00022280
	s_cselect_b32 s1, -1, 0                                    // 0000001CDBE4: 980180C1
	s_or_b32 s8, s42, 56                                       // 0000001CDBE8: 8C08B82A
	v_cndmask_b16 v52, 0, v17, s1                              // 0000001CDBEC: D65D5034 00062280
	s_cmp_lt_i32 s8, s50                                       // 0000001CDBF4: BF043208
	v_mul_f32_e32 v17, v154, v41                               // 0000001CDBF8: 1022539A
	s_cselect_b32 s0, -1, 0                                    // 0000001CDBFC: 980080C1
	s_or_b32 s1, s42, 57                                       // 0000001CDC00: 8C01B92A
	v_mul_f32_e32 v18, v159, v42                               // 0000001CDC04: 1024559F
	s_cmp_lt_i32 s1, s50                                       // 0000001CDC08: BF043201
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001CDC0C: CC210011 02004F11
	s_cselect_b32 s1, -1, 0                                    // 0000001CDC14: 980180C1
	s_or_b32 s8, s42, 58                                       // 0000001CDC18: 8C08BA2A
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001CDC1C: CC220011 02004F12
	v_fma_mixlo_f16 v18, v19, s39, 0                           // 0000001CDC24: CC210012 02004F13
	s_cmp_lt_i32 s8, s50                                       // 0000001CDC2C: BF043208
	v_cndmask_b16 v17, 0, v17, s0                              // 0000001CDC30: D65D0011 00022280
	s_cselect_b32 s0, -1, 0                                    // 0000001CDC38: 980080C1
	v_mul_f32_e32 v19, v165, v44                               // 0000001CDC3C: 102659A5
	v_cndmask_b16 v18, 0, v18, s0                              // 0000001CDC40: D65D0012 00022480
	s_or_b32 s0, s42, 59                                       // 0000001CDC48: 8C00BB2A
	v_cndmask_b16 v17, 0, v17, s1                              // 0000001CDC4C: D65D5011 00062280
	s_cmp_lt_i32 s0, s50                                       // 0000001CDC54: BF043200
	v_fma_mixhi_f16 v18, v19, s39, 0                           // 0000001CDC58: CC220012 02004F13
	s_cselect_b32 s0, -1, 0                                    // 0000001CDC60: 980080C1
	s_or_b32 s1, s42, 60                                       // 0000001CDC64: 8C01BC2A
	v_fma_mixlo_f16 v19, v20, s39, 0                           // 0000001CDC68: CC210013 02004F14
	s_cmp_lt_i32 s1, s50                                       // 0000001CDC70: BF043201
	v_dual_mul_f32 v20, v162, v46 :: v_dual_mul_f32 v29, v161, v47// 0000001CDC74: C8C65DA2 141C5FA1
	s_cselect_b32 s1, -1, 0                                    // 0000001CDC7C: 980180C1
	s_or_b32 s8, s42, 61                                       // 0000001CDC80: 8C08BD2A
	v_cndmask_b16 v18, 0, v18, s0                              // 0000001CDC84: D65D5012 00022480
	s_cmp_lt_i32 s8, s50                                       // 0000001CDC8C: BF043208
	v_cndmask_b16 v19, 0, v19, s1                              // 0000001CDC90: D65D0013 00062680
	s_cselect_b32 s0, -1, 0                                    // 0000001CDC98: 980080C1
	s_or_b32 s1, s42, 62                                       // 0000001CDC9C: 8C01BE2A
	v_mul_f32_e32 v30, v163, v48                               // 0000001CDCA0: 103C61A3
	s_cmp_lt_i32 s1, s50                                       // 0000001CDCA4: BF043201
	v_fma_mixhi_f16 v19, v20, s39, 0                           // 0000001CDCA8: CC220013 02004F14
	s_cselect_b32 s1, -1, 0                                    // 0000001CDCB0: 980180C1
	s_or_b32 s8, s42, 63                                       // 0000001CDCB4: 8C08BF2A
	v_fma_mixlo_f16 v20, v29, s39, 0                           // 0000001CDCB8: CC210014 02004F1D
	v_fma_mixhi_f16 v20, v30, s39, 0                           // 0000001CDCC0: CC220014 02004F1E
	s_cmp_lt_i32 s8, s50                                       // 0000001CDCC8: BF043208
	v_cndmask_b16 v19, 0, v19, s0                              // 0000001CDCCC: D65D5013 00022680
	s_cselect_b32 s0, -1, 0                                    // 0000001CDCD4: 980080C1
	v_cndmask_b16 v20, 0, v20, s1                              // 0000001CDCD8: D65D0014 00062880
	v_cndmask_b16 v20, 0, v20, s0                              // 0000001CDCE0: D65D5014 00022880
	ds_store_b128 v127, v[21:24] offset:64                     // 0000001CDCE8: DB7C0040 0000157F
	ds_store_b128 v127, v[25:28] offset:80                     // 0000001CDCF0: DB7C0050 0000197F
	ds_store_b128 v127, v[49:52] offset:96                     // 0000001CDCF8: DB7C0060 0000317F
	ds_store_b128 v127, v[17:20] offset:112                    // 0000001CDD00: DB7C0070 0000117F
	s_and_saveexec_b32 s0, vcc_lo                              // 0000001CDD08: BE80206A
	s_cbranch_execz 67                                         // 0000001CDD0C: BFA50043 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x1c1c>
	s_waitcnt vmcnt(1)                                         // 0000001CDD10: BF8907F7
	v_mov_b32_e32 v1, 0                                        // 0000001CDD14: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CDD18: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000001CDD1C: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000001CDD20: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000001CDD24: 7E080301
	s_waitcnt vmcnt(0)                                         // 0000001CDD28: BF8903F7
	v_mov_b32_e32 v5, v1                                       // 0000001CDD2C: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000001CDD30: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000001CDD34: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000001CDD38: 7E100301
	v_mov_b32_e32 v9, v1                                       // 0000001CDD3C: 7E120301
	v_mov_b32_e32 v10, v1                                      // 0000001CDD40: 7E140301
	v_mov_b32_e32 v11, v1                                      // 0000001CDD44: 7E160301
	v_mov_b32_e32 v12, v1                                      // 0000001CDD48: 7E180301
	v_mov_b32_e32 v13, v1                                      // 0000001CDD4C: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 0000001CDD50: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 0000001CDD54: 7E1E0301
	v_mov_b32_e32 v16, v1                                      // 0000001CDD58: 7E200301
	v_mov_b32_e32 v33, v1                                      // 0000001CDD5C: 7E420301
	v_mov_b32_e32 v34, v1                                      // 0000001CDD60: 7E440301
	v_mov_b32_e32 v35, v1                                      // 0000001CDD64: 7E460301
	v_mov_b32_e32 v36, v1                                      // 0000001CDD68: 7E480301
	v_mov_b32_e32 v37, v1                                      // 0000001CDD6C: 7E4A0301
	v_mov_b32_e32 v38, v1                                      // 0000001CDD70: 7E4C0301
	v_mov_b32_e32 v39, v1                                      // 0000001CDD74: 7E4E0301
	v_mov_b32_e32 v40, v1                                      // 0000001CDD78: 7E500301
	v_mov_b32_e32 v57, v1                                      // 0000001CDD7C: 7E720301
	v_mov_b32_e32 v58, v1                                      // 0000001CDD80: 7E740301
	v_mov_b32_e32 v59, v1                                      // 0000001CDD84: 7E760301
	v_mov_b32_e32 v60, v1                                      // 0000001CDD88: 7E780301
	v_mov_b32_e32 v61, v1                                      // 0000001CDD8C: 7E7A0301
	v_mov_b32_e32 v62, v1                                      // 0000001CDD90: 7E7C0301
	v_mov_b32_e32 v63, v1                                      // 0000001CDD94: 7E7E0301
	v_mov_b32_e32 v64, v1                                      // 0000001CDD98: 7E800301
	v_mov_b32_e32 v65, v1                                      // 0000001CDD9C: 7E820301
	v_mov_b32_e32 v66, v1                                      // 0000001CDDA0: 7E840301
	v_mov_b32_e32 v67, v1                                      // 0000001CDDA4: 7E860301
	v_mov_b32_e32 v68, v1                                      // 0000001CDDA8: 7E880301
	v_mov_b32_e32 v69, v1                                      // 0000001CDDAC: 7E8A0301
	v_mov_b32_e32 v70, v1                                      // 0000001CDDB0: 7E8C0301
	v_mov_b32_e32 v71, v1                                      // 0000001CDDB4: 7E8E0301
	v_mov_b32_e32 v72, v1                                      // 0000001CDDB8: 7E900301
	v_mov_b32_e32 v73, v1                                      // 0000001CDDBC: 7E920301
	v_mov_b32_e32 v74, v1                                      // 0000001CDDC0: 7E940301
	v_mov_b32_e32 v75, v1                                      // 0000001CDDC4: 7E960301
	v_mov_b32_e32 v76, v1                                      // 0000001CDDC8: 7E980301
	v_mov_b32_e32 v77, v1                                      // 0000001CDDCC: 7E9A0301
	v_mov_b32_e32 v78, v1                                      // 0000001CDDD0: 7E9C0301
	v_mov_b32_e32 v79, v1                                      // 0000001CDDD4: 7E9E0301
	v_mov_b32_e32 v80, v1                                      // 0000001CDDD8: 7EA00301
	v_mov_b32_e32 v81, v1                                      // 0000001CDDDC: 7EA20301
	v_mov_b32_e32 v82, v1                                      // 0000001CDDE0: 7EA40301
	v_mov_b32_e32 v83, v1                                      // 0000001CDDE4: 7EA60301
	v_mov_b32_e32 v84, v1                                      // 0000001CDDE8: 7EA80301
	v_mov_b32_e32 v85, v1                                      // 0000001CDDEC: 7EAA0301
	v_mov_b32_e32 v86, v1                                      // 0000001CDDF0: 7EAC0301
	v_mov_b32_e32 v87, v1                                      // 0000001CDDF4: 7EAE0301
	v_mov_b32_e32 v88, v1                                      // 0000001CDDF8: 7EB00301
	v_mov_b32_e32 v89, v1                                      // 0000001CDDFC: 7EB20301
	v_mov_b32_e32 v90, v1                                      // 0000001CDE00: 7EB40301
	v_mov_b32_e32 v91, v1                                      // 0000001CDE04: 7EB60301
	v_mov_b32_e32 v92, v1                                      // 0000001CDE08: 7EB80301
	v_mov_b32_e32 v93, v1                                      // 0000001CDE0C: 7EBA0301
	v_mov_b32_e32 v94, v1                                      // 0000001CDE10: 7EBC0301
	v_mov_b32_e32 v95, v1                                      // 0000001CDE14: 7EBE0301
	v_mov_b32_e32 v96, v1                                      // 0000001CDE18: 7EC00301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CDE1C: 8C7E007E
	ds_load_b128 v[17:20], v129                                // 0000001CDE20: DBFC0000 11000081
	ds_load_b128 v[21:24], v129 offset:16                      // 0000001CDE28: DBFC0010 15000081
	ds_load_b128 v[25:28], v129 offset:32                      // 0000001CDE30: DBFC0020 19000081
	ds_load_b128 v[29:32], v129 offset:48                      // 0000001CDE38: DBFC0030 1D000081
	ds_load_b128 v[41:44], v129 offset:8448                    // 0000001CDE40: DBFC2100 29000081
	ds_load_b128 v[45:48], v129 offset:8464                    // 0000001CDE48: DBFC2110 2D000081
	ds_load_b128 v[49:52], v129 offset:8480                    // 0000001CDE50: DBFC2120 31000081
	ds_load_b128 v[53:56], v129 offset:8496                    // 0000001CDE58: DBFC2130 35000081
	ds_load_b128 v[100:103], v129 offset:16896                 // 0000001CDE60: DBFC4200 64000081
	ds_load_b128 v[150:153], v129 offset:16912                 // 0000001CDE68: DBFC4210 96000081
	v_dual_mov_b32 v149, s27 :: v_dual_mov_b32 v148, s26       // 0000001CDE70: CA10001B 9594001A
	v_dual_mov_b32 v147, s25 :: v_dual_mov_b32 v146, s24       // 0000001CDE78: CA100019 93920018
	v_dual_mov_b32 v145, s23 :: v_dual_mov_b32 v144, s22       // 0000001CDE80: CA100017 91900016
	v_dual_mov_b32 v143, s21 :: v_dual_mov_b32 v142, s20       // 0000001CDE88: CA100015 8F8E0014
	ds_load_b128 v[154:157], v129 offset:25344                 // 0000001CDE90: DBFC6300 9A000081
	ds_load_b128 v[158:161], v129 offset:25360                 // 0000001CDE98: DBFC6310 9E000081
	s_waitcnt lgkmcnt(11)                                      // 0000001CDEA0: BF89FCB7
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001CDEA4: CC210011 02004F11
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001CDEAC: CC220011 02004F12
	v_fma_mixlo_f16 v18, v19, s39, 0                           // 0000001CDEB4: CC210012 02004F13
	v_fma_mixhi_f16 v18, v20, s39, 0                           // 0000001CDEBC: CC220012 02004F14
	s_waitcnt lgkmcnt(10)                                      // 0000001CDEC4: BF89FCA7
	v_fma_mixlo_f16 v19, v21, s39, 0                           // 0000001CDEC8: CC210013 02004F15
	v_fma_mixhi_f16 v19, v22, s39, 0                           // 0000001CDED0: CC220013 02004F16
	v_fma_mixlo_f16 v20, v23, s39, 0                           // 0000001CDED8: CC210014 02004F17
	v_fma_mixhi_f16 v20, v24, s39, 0                           // 0000001CDEE0: CC220014 02004F18
	s_waitcnt lgkmcnt(9)                                       // 0000001CDEE8: BF89FC97
	v_fma_mixlo_f16 v21, v25, s39, 0                           // 0000001CDEEC: CC210015 02004F19
	v_fma_mixhi_f16 v21, v26, s39, 0                           // 0000001CDEF4: CC220015 02004F1A
	v_fma_mixlo_f16 v22, v27, s39, 0                           // 0000001CDEFC: CC210016 02004F1B
	v_fma_mixhi_f16 v22, v28, s39, 0                           // 0000001CDF04: CC220016 02004F1C
	s_waitcnt lgkmcnt(8)                                       // 0000001CDF0C: BF89FC87
	v_fma_mixlo_f16 v23, v29, s39, 0                           // 0000001CDF10: CC210017 02004F1D
	v_fma_mixhi_f16 v23, v30, s39, 0                           // 0000001CDF18: CC220017 02004F1E
	v_fma_mixlo_f16 v24, v31, s39, 0                           // 0000001CDF20: CC210018 02004F1F
	v_fma_mixhi_f16 v24, v32, s39, 0                           // 0000001CDF28: CC220018 02004F20
	s_waitcnt lgkmcnt(7)                                       // 0000001CDF30: BF89FC77
	v_fma_mixlo_f16 v25, v41, s39, 0                           // 0000001CDF34: CC210019 02004F29
	v_fma_mixhi_f16 v25, v42, s39, 0                           // 0000001CDF3C: CC220019 02004F2A
	v_fma_mixlo_f16 v26, v43, s39, 0                           // 0000001CDF44: CC21001A 02004F2B
	v_fma_mixhi_f16 v26, v44, s39, 0                           // 0000001CDF4C: CC22001A 02004F2C
	s_waitcnt lgkmcnt(6)                                       // 0000001CDF54: BF89FC67
	v_fma_mixlo_f16 v27, v45, s39, 0                           // 0000001CDF58: CC21001B 02004F2D
	v_fma_mixhi_f16 v27, v46, s39, 0                           // 0000001CDF60: CC22001B 02004F2E
	v_fma_mixlo_f16 v28, v47, s39, 0                           // 0000001CDF68: CC21001C 02004F2F
	v_fma_mixhi_f16 v28, v48, s39, 0                           // 0000001CDF70: CC22001C 02004F30
	s_waitcnt lgkmcnt(5)                                       // 0000001CDF78: BF89FC57
	v_fma_mixlo_f16 v29, v49, s39, 0                           // 0000001CDF7C: CC21001D 02004F31
	v_fma_mixhi_f16 v29, v50, s39, 0                           // 0000001CDF84: CC22001D 02004F32
	v_fma_mixlo_f16 v30, v51, s39, 0                           // 0000001CDF8C: CC21001E 02004F33
	v_fma_mixhi_f16 v30, v52, s39, 0                           // 0000001CDF94: CC22001E 02004F34
	s_waitcnt lgkmcnt(4)                                       // 0000001CDF9C: BF89FC47
	v_fma_mixlo_f16 v31, v53, s39, 0                           // 0000001CDFA0: CC21001F 02004F35
	v_fma_mixhi_f16 v31, v54, s39, 0                           // 0000001CDFA8: CC22001F 02004F36
	v_fma_mixlo_f16 v32, v55, s39, 0                           // 0000001CDFB0: CC210020 02004F37
	v_fma_mixhi_f16 v32, v56, s39, 0                           // 0000001CDFB8: CC220020 02004F38
	s_waitcnt vmcnt(14)                                        // 0000001CDFC0: BF893BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[17:24], v[142:149]// 0000001CDFC4: CC404029 1E3A2359
	ds_load_b128 v[49:52], v129 offset:16928                   // 0000001CDFCC: DBFC4220 31000081
	ds_load_b128 v[53:56], v129 offset:16944                   // 0000001CDFD4: DBFC4230 35000081
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[25:32], v[142:149]// 0000001CDFDC: CC404011 1E3A3359
	s_waitcnt lgkmcnt(5)                                       // 0000001CDFE4: BF89FC57
	v_fma_mixlo_f16 v25, v100, s39, 0                          // 0000001CDFE8: CC210019 02004F64
	v_fma_mixhi_f16 v25, v101, s39, 0                          // 0000001CDFF0: CC220019 02004F65
	v_fma_mixlo_f16 v26, v102, s39, 0                          // 0000001CDFF8: CC21001A 02004F66
	v_fma_mixhi_f16 v26, v103, s39, 0                          // 0000001CE000: CC22001A 02004F67
	ds_load_b128 v[100:103], v129 offset:25376                 // 0000001CE008: DBFC6320 64000081
	ds_load_b128 v[162:165], v129 offset:25392                 // 0000001CE010: DBFC6330 A2000081
	s_waitcnt lgkmcnt(6)                                       // 0000001CE018: BF89FC67
	v_fma_mixlo_f16 v27, v150, s39, 0                          // 0000001CE01C: CC21001B 02004F96
	s_waitcnt lgkmcnt(5)                                       // 0000001CE024: BF89FC57
	v_fma_mixlo_f16 v150, v154, s39, 0                         // 0000001CE028: CC210096 02004F9A
	v_fma_mixhi_f16 v150, v155, s39, 0                         // 0000001CE030: CC220096 02004F9B
	v_fma_mixhi_f16 v27, v151, s39, 0                          // 0000001CE038: CC22001B 02004F97
	v_fma_mixlo_f16 v28, v152, s39, 0                          // 0000001CE040: CC21001C 02004F98
	v_fma_mixhi_f16 v28, v153, s39, 0                          // 0000001CE048: CC22001C 02004F99
	v_fma_mixlo_f16 v151, v156, s39, 0                         // 0000001CE050: CC210097 02004F9C
	v_fma_mixhi_f16 v151, v157, s39, 0                         // 0000001CE058: CC220097 02004F9D
	s_waitcnt lgkmcnt(4)                                       // 0000001CE060: BF89FC47
	v_fma_mixlo_f16 v152, v158, s39, 0                         // 0000001CE064: CC210098 02004F9E
	v_fma_mixhi_f16 v152, v159, s39, 0                         // 0000001CE06C: CC220098 02004F9F
	s_waitcnt lgkmcnt(3)                                       // 0000001CE074: BF89FC37
	v_fma_mixlo_f16 v29, v49, s39, 0                           // 0000001CE078: CC21001D 02004F31
	v_fma_mixhi_f16 v29, v50, s39, 0                           // 0000001CE080: CC22001D 02004F32
	v_fma_mixlo_f16 v30, v51, s39, 0                           // 0000001CE088: CC21001E 02004F33
	v_fma_mixhi_f16 v30, v52, s39, 0                           // 0000001CE090: CC22001E 02004F34
	s_waitcnt lgkmcnt(2)                                       // 0000001CE098: BF89FC27
	v_fma_mixlo_f16 v31, v53, s39, 0                           // 0000001CE09C: CC21001F 02004F35
	v_fma_mixhi_f16 v31, v54, s39, 0                           // 0000001CE0A4: CC22001F 02004F36
	v_fma_mixlo_f16 v32, v55, s39, 0                           // 0000001CE0AC: CC210020 02004F37
	v_fma_mixhi_f16 v32, v56, s39, 0                           // 0000001CE0B4: CC220020 02004F38
	s_waitcnt lgkmcnt(1)                                       // 0000001CE0BC: BF89FC17
	v_fma_mixlo_f16 v154, v100, s39, 0                         // 0000001CE0C0: CC21009A 02004F64
	v_fma_mixhi_f16 v154, v101, s39, 0                         // 0000001CE0C8: CC22009A 02004F65
	v_fma_mixlo_f16 v155, v102, s39, 0                         // 0000001CE0D0: CC21009B 02004F66
	v_fma_mixhi_f16 v155, v103, s39, 0                         // 0000001CE0D8: CC22009B 02004F67
	ds_load_b128 v[100:103], v129 offset:96                    // 0000001CE0E0: DBFC0060 64000081
	v_fma_mixlo_f16 v153, v160, s39, 0                         // 0000001CE0E8: CC210099 02004FA0
	v_fma_mixhi_f16 v153, v161, s39, 0                         // 0000001CE0F0: CC220099 02004FA1
	s_waitcnt lgkmcnt(1)                                       // 0000001CE0F8: BF89FC17
	v_fma_mixlo_f16 v156, v162, s39, 0                         // 0000001CE0FC: CC21009C 02004FA2
	v_fma_mixhi_f16 v156, v163, s39, 0                         // 0000001CE104: CC22009C 02004FA3
	v_fma_mixlo_f16 v157, v164, s39, 0                         // 0000001CE10C: CC21009D 02004FA4
	v_fma_mixhi_f16 v157, v165, s39, 0                         // 0000001CE114: CC22009D 02004FA5
	ds_load_b128 v[166:169], v129 offset:64                    // 0000001CE11C: DBFC0040 A6000081
	ds_load_b128 v[158:161], v129 offset:80                    // 0000001CE124: DBFC0050 9E000081
	ds_load_b128 v[162:165], v129 offset:112                   // 0000001CE12C: DBFC0070 A2000081
	v_wmma_f32_16x16x16_f16 v[49:56], v[89:96], v[25:32], v[142:149]// 0000001CE134: CC404031 1E3A3359
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[150:157], v[142:149]// 0000001CE13C: CC404019 1E3B2D59
	ds_load_b128 v[142:145], v129 offset:8512                  // 0000001CE144: DBFC2140 8E000081
	ds_load_b128 v[146:149], v129 offset:8528                  // 0000001CE14C: DBFC2150 92000081
	ds_load_b128 v[150:153], v129 offset:8544                  // 0000001CE154: DBFC2160 96000081
	ds_load_b128 v[154:157], v129 offset:16960                 // 0000001CE15C: DBFC4240 9A000081
	ds_load_b128 v[170:173], v129 offset:25424                 // 0000001CE164: DBFC6350 AA000081
	ds_load_b128 v[174:177], v129 offset:25440                 // 0000001CE16C: DBFC6360 AE000081
	ds_load_b128 v[178:181], v129 offset:25456                 // 0000001CE174: DBFC6370 B2000081
	s_waitcnt lgkmcnt(10)                                      // 0000001CE17C: BF89FCA7
	v_fma_mixlo_f16 v93, v100, s39, 0                          // 0000001CE180: CC21005D 02004F64
	v_fma_mixhi_f16 v93, v101, s39, 0                          // 0000001CE188: CC22005D 02004F65
	v_fma_mixlo_f16 v94, v102, s39, 0                          // 0000001CE190: CC21005E 02004F66
	v_fma_mixhi_f16 v94, v103, s39, 0                          // 0000001CE198: CC22005E 02004F67
	ds_load_b128 v[100:103], v129 offset:8560                  // 0000001CE1A0: DBFC2170 64000081
	s_waitcnt lgkmcnt(10)                                      // 0000001CE1A8: BF89FCA7
	v_fma_mixlo_f16 v89, v166, s39, 0                          // 0000001CE1AC: CC210059 02004FA6
	s_waitcnt lgkmcnt(9)                                       // 0000001CE1B4: BF89FC97
	v_fma_mixlo_f16 v91, v158, s39, 0                          // 0000001CE1B8: CC21005B 02004F9E
	v_fma_mixhi_f16 v91, v159, s39, 0                          // 0000001CE1C0: CC22005B 02004F9F
	v_fma_mixlo_f16 v92, v160, s39, 0                          // 0000001CE1C8: CC21005C 02004FA0
	v_fma_mixhi_f16 v92, v161, s39, 0                          // 0000001CE1D0: CC22005C 02004FA1
	ds_load_b128 v[158:161], v129 offset:16976                 // 0000001CE1D8: DBFC4250 9E000081
	v_fma_mixhi_f16 v89, v167, s39, 0                          // 0000001CE1E0: CC220059 02004FA7
	s_waitcnt lgkmcnt(8)                                       // 0000001CE1E8: BF89FC87
	v_fma_mixlo_f16 v142, v142, s39, 0                         // 0000001CE1EC: CC21008E 02004F8E
	v_fma_mixhi_f16 v142, v143, s39, 0                         // 0000001CE1F4: CC22008E 02004F8F
	v_fma_mixhi_f16 v143, v145, s39, 0                         // 0000001CE1FC: CC22008F 02004F91
	s_waitcnt lgkmcnt(7)                                       // 0000001CE204: BF89FC77
	v_fma_mixlo_f16 v145, v148, s39, 0                         // 0000001CE208: CC210091 02004F94
	v_fma_mixhi_f16 v145, v149, s39, 0                         // 0000001CE210: CC220091 02004F95
	v_fma_mixlo_f16 v90, v168, s39, 0                          // 0000001CE218: CC21005A 02004FA8
	v_fma_mixhi_f16 v90, v169, s39, 0                          // 0000001CE220: CC22005A 02004FA9
	v_fma_mixlo_f16 v95, v162, s39, 0                          // 0000001CE228: CC21005F 02004FA2
	v_fma_mixhi_f16 v95, v163, s39, 0                          // 0000001CE230: CC22005F 02004FA3
	v_fma_mixlo_f16 v96, v164, s39, 0                          // 0000001CE238: CC210060 02004FA4
	v_fma_mixhi_f16 v96, v165, s39, 0                          // 0000001CE240: CC220060 02004FA5
	s_waitcnt lgkmcnt(1)                                       // 0000001CE248: BF89FC17
	v_fma_mixlo_f16 v148, v100, s39, 0                         // 0000001CE24C: CC210094 02004F64
	v_fma_mixhi_f16 v148, v101, s39, 0                         // 0000001CE254: CC220094 02004F65
	v_fma_mixlo_f16 v149, v102, s39, 0                         // 0000001CE25C: CC210095 02004F66
	v_fma_mixhi_f16 v149, v103, s39, 0                         // 0000001CE264: CC220095 02004F67
	ds_load_b128 v[100:103], v129 offset:25408                 // 0000001CE26C: DBFC6340 64000081
	ds_load_b128 v[162:165], v129 offset:16992                 // 0000001CE274: DBFC4260 A2000081
	ds_load_b128 v[166:169], v129 offset:17008                 // 0000001CE27C: DBFC4270 A6000081
	v_fma_mixlo_f16 v143, v144, s39, 0                         // 0000001CE284: CC21008F 02004F90
	v_fma_mixhi_f16 v144, v147, s39, 0                         // 0000001CE28C: CC220090 02004F93
	v_fma_mixlo_f16 v147, v152, s39, 0                         // 0000001CE294: CC210093 02004F98
	s_waitcnt lgkmcnt(3)                                       // 0000001CE29C: BF89FC37
	v_fma_mixlo_f16 v152, v158, s39, 0                         // 0000001CE2A0: CC210098 02004F9E
	v_fma_mixhi_f16 v152, v159, s39, 0                         // 0000001CE2A8: CC220098 02004F9F
	v_fma_mixlo_f16 v144, v146, s39, 0                         // 0000001CE2B0: CC210090 02004F92
	v_fma_mixlo_f16 v146, v150, s39, 0                         // 0000001CE2B8: CC210092 02004F96
	v_fma_mixhi_f16 v146, v151, s39, 0                         // 0000001CE2C0: CC220092 02004F97
	v_fma_mixhi_f16 v147, v153, s39, 0                         // 0000001CE2C8: CC220093 02004F99
	v_fma_mixlo_f16 v150, v154, s39, 0                         // 0000001CE2D0: CC210096 02004F9A
	v_fma_mixhi_f16 v150, v155, s39, 0                         // 0000001CE2D8: CC220096 02004F9B
	v_fma_mixlo_f16 v151, v156, s39, 0                         // 0000001CE2E0: CC210097 02004F9C
	v_fma_mixhi_f16 v151, v157, s39, 0                         // 0000001CE2E8: CC220097 02004F9D
	v_fma_mixlo_f16 v153, v160, s39, 0                         // 0000001CE2F0: CC210099 02004FA0
	v_fma_mixhi_f16 v153, v161, s39, 0                         // 0000001CE2F8: CC220099 02004FA1
	v_fma_mixlo_f16 v160, v170, s39, 0                         // 0000001CE300: CC2100A0 02004FAA
	v_fma_mixhi_f16 v160, v171, s39, 0                         // 0000001CE308: CC2200A0 02004FAB
	s_waitcnt lgkmcnt(2)                                       // 0000001CE310: BF89FC27
	v_fma_mixlo_f16 v158, v100, s39, 0                         // 0000001CE314: CC21009E 02004F64
	v_fma_mixhi_f16 v158, v101, s39, 0                         // 0000001CE31C: CC22009E 02004F65
	v_fma_mixlo_f16 v159, v102, s39, 0                         // 0000001CE324: CC21009F 02004F66
	v_fma_mixhi_f16 v159, v103, s39, 0                         // 0000001CE32C: CC22009F 02004F67
	ds_load_b128 v[100:103], v129 offset:128                   // 0000001CE334: DBFC0080 64000081
	s_waitcnt lgkmcnt(2)                                       // 0000001CE33C: BF89FC27
	v_fma_mixlo_f16 v154, v162, s39, 0                         // 0000001CE340: CC21009A 02004FA2
	v_fma_mixhi_f16 v154, v163, s39, 0                         // 0000001CE348: CC22009A 02004FA3
	v_fma_mixlo_f16 v155, v164, s39, 0                         // 0000001CE350: CC21009B 02004FA4
	v_fma_mixhi_f16 v155, v165, s39, 0                         // 0000001CE358: CC22009B 02004FA5
	s_waitcnt lgkmcnt(1)                                       // 0000001CE360: BF89FC17
	v_fma_mixlo_f16 v156, v166, s39, 0                         // 0000001CE364: CC21009C 02004FA6
	v_fma_mixhi_f16 v156, v167, s39, 0                         // 0000001CE36C: CC22009C 02004FA7
	v_fma_mixlo_f16 v157, v168, s39, 0                         // 0000001CE374: CC21009D 02004FA8
	v_fma_mixhi_f16 v157, v169, s39, 0                         // 0000001CE37C: CC22009D 02004FA9
	v_fma_mixlo_f16 v161, v172, s39, 0                         // 0000001CE384: CC2100A1 02004FAC
	v_fma_mixhi_f16 v161, v173, s39, 0                         // 0000001CE38C: CC2200A1 02004FAD
	v_fma_mixlo_f16 v162, v174, s39, 0                         // 0000001CE394: CC2100A2 02004FAE
	v_fma_mixhi_f16 v162, v175, s39, 0                         // 0000001CE39C: CC2200A2 02004FAF
	v_fma_mixlo_f16 v163, v176, s39, 0                         // 0000001CE3A4: CC2100A3 02004FB0
	v_fma_mixhi_f16 v163, v177, s39, 0                         // 0000001CE3AC: CC2200A3 02004FB1
	v_fma_mixlo_f16 v164, v178, s39, 0                         // 0000001CE3B4: CC2100A4 02004FB2
	v_fma_mixhi_f16 v164, v179, s39, 0                         // 0000001CE3BC: CC2200A4 02004FB3
	v_fma_mixlo_f16 v165, v180, s39, 0                         // 0000001CE3C4: CC2100A5 02004FB4
	v_fma_mixhi_f16 v165, v181, s39, 0                         // 0000001CE3CC: CC2200A5 02004FB5
	ds_load_b128 v[166:169], v129 offset:144                   // 0000001CE3D4: DBFC0090 A6000081
	ds_load_b128 v[170:173], v129 offset:160                   // 0000001CE3DC: DBFC00A0 AA000081
	s_waitcnt vmcnt(12)                                        // 0000001CE3E4: BF8933F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[89:96], v[41:48]// 0000001CE3E8: CC404029 1CA6B351
	ds_load_b128 v[89:92], v129 offset:176                     // 0000001CE3F0: DBFC00B0 59000081
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[142:149], v[17:24]// 0000001CE3F8: CC404011 1C471D51
	v_wmma_f32_16x16x16_f16 v[49:56], v[81:88], v[150:157], v[49:56]// 0000001CE400: CC404031 1CC72D51
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[158:165], v[25:32]// 0000001CE408: CC404019 1C673D51
	ds_load_b128 v[93:96], v129 offset:8576                    // 0000001CE410: DBFC2180 5D000081
	s_waitcnt lgkmcnt(4)                                       // 0000001CE418: BF89FC47
	v_fma_mixlo_f16 v81, v100, s39, 0                          // 0000001CE41C: CC210051 02004F64
	v_fma_mixhi_f16 v81, v101, s39, 0                          // 0000001CE424: CC220051 02004F65
	v_fma_mixlo_f16 v82, v102, s39, 0                          // 0000001CE42C: CC210052 02004F66
	v_fma_mixhi_f16 v82, v103, s39, 0                          // 0000001CE434: CC220052 02004F67
	ds_load_b128 v[100:103], v129 offset:8592                  // 0000001CE43C: DBFC2190 64000081
	ds_load_b128 v[142:145], v129 offset:8608                  // 0000001CE444: DBFC21A0 8E000081
	ds_load_b128 v[146:149], v129 offset:8624                  // 0000001CE44C: DBFC21B0 92000081
	ds_load_b128 v[150:153], v129 offset:17024                 // 0000001CE454: DBFC4280 96000081
	ds_load_b128 v[154:157], v129 offset:17040                 // 0000001CE45C: DBFC4290 9A000081
	ds_load_b128 v[158:161], v129 offset:17072                 // 0000001CE464: DBFC42B0 9E000081
	ds_load_b128 v[162:165], v129 offset:25472                 // 0000001CE46C: DBFC6380 A2000081
	ds_load_b128 v[174:177], v129 offset:25520                 // 0000001CE474: DBFC63B0 AE000081
	s_waitcnt lgkmcnt(11)                                      // 0000001CE47C: BF89FCB7
	v_fma_mixlo_f16 v83, v166, s39, 0                          // 0000001CE480: CC210053 02004FA6
	v_fma_mixhi_f16 v83, v167, s39, 0                          // 0000001CE488: CC220053 02004FA7
	v_fma_mixlo_f16 v84, v168, s39, 0                          // 0000001CE490: CC210054 02004FA8
	s_waitcnt lgkmcnt(9)                                       // 0000001CE498: BF89FC97
	v_fma_mixlo_f16 v88, v91, s39, 0                           // 0000001CE49C: CC210058 02004F5B
	v_fma_mixhi_f16 v88, v92, s39, 0                           // 0000001CE4A4: CC220058 02004F5C
	v_fma_mixhi_f16 v84, v169, s39, 0                          // 0000001CE4AC: CC220054 02004FA9
	v_fma_mixlo_f16 v85, v170, s39, 0                          // 0000001CE4B4: CC210055 02004FAA
	v_fma_mixhi_f16 v85, v171, s39, 0                          // 0000001CE4BC: CC220055 02004FAB
	v_fma_mixlo_f16 v86, v172, s39, 0                          // 0000001CE4C4: CC210056 02004FAC
	v_fma_mixhi_f16 v86, v173, s39, 0                          // 0000001CE4CC: CC220056 02004FAD
	ds_load_b128 v[166:169], v129 offset:25488                 // 0000001CE4D4: DBFC6390 A6000081
	ds_load_b128 v[170:173], v129 offset:25504                 // 0000001CE4DC: DBFC63A0 AA000081
	s_waitcnt lgkmcnt(9)                                       // 0000001CE4E4: BF89FC97
	v_fma_mixlo_f16 v91, v100, s39, 0                          // 0000001CE4E8: CC21005B 02004F64
	v_fma_mixhi_f16 v91, v101, s39, 0                          // 0000001CE4F0: CC22005B 02004F65
	v_fma_mixlo_f16 v92, v102, s39, 0                          // 0000001CE4F8: CC21005C 02004F66
	v_fma_mixhi_f16 v92, v103, s39, 0                          // 0000001CE500: CC22005C 02004F67
	ds_load_b128 v[100:103], v129 offset:17056                 // 0000001CE508: DBFC42A0 64000081
	v_fma_mixhi_f16 v87, v90, s39, 0                           // 0000001CE510: CC220057 02004F5A
	v_fma_mixlo_f16 v90, v95, s39, 0                           // 0000001CE518: CC21005A 02004F5F
	s_waitcnt lgkmcnt(8)                                       // 0000001CE520: BF89FC87
	v_fma_mixlo_f16 v95, v146, s39, 0                          // 0000001CE524: CC21005F 02004F92
	v_fma_mixhi_f16 v95, v147, s39, 0                          // 0000001CE52C: CC22005F 02004F93
	v_fma_mixlo_f16 v87, v89, s39, 0                           // 0000001CE534: CC210057 02004F59
	v_fma_mixlo_f16 v89, v93, s39, 0                           // 0000001CE53C: CC210059 02004F5D
	v_fma_mixhi_f16 v89, v94, s39, 0                           // 0000001CE544: CC220059 02004F5E
	v_fma_mixhi_f16 v90, v96, s39, 0                           // 0000001CE54C: CC22005A 02004F60
	v_fma_mixlo_f16 v93, v142, s39, 0                          // 0000001CE554: CC21005D 02004F8E
	v_fma_mixhi_f16 v93, v143, s39, 0                          // 0000001CE55C: CC22005D 02004F8F
	v_fma_mixlo_f16 v94, v144, s39, 0                          // 0000001CE564: CC21005E 02004F90
	v_fma_mixhi_f16 v94, v145, s39, 0                          // 0000001CE56C: CC22005E 02004F91
	v_fma_mixlo_f16 v96, v148, s39, 0                          // 0000001CE574: CC210060 02004F94
	v_fma_mixhi_f16 v96, v149, s39, 0                          // 0000001CE57C: CC220060 02004F95
	s_waitcnt lgkmcnt(7)                                       // 0000001CE584: BF89FC77
	v_fma_mixlo_f16 v142, v150, s39, 0                         // 0000001CE588: CC21008E 02004F96
	v_fma_mixhi_f16 v142, v151, s39, 0                         // 0000001CE590: CC22008E 02004F97
	v_fma_mixlo_f16 v143, v152, s39, 0                         // 0000001CE598: CC21008F 02004F98
	v_fma_mixhi_f16 v143, v153, s39, 0                         // 0000001CE5A0: CC22008F 02004F99
	s_waitcnt lgkmcnt(6)                                       // 0000001CE5A8: BF89FC67
	v_fma_mixlo_f16 v144, v154, s39, 0                         // 0000001CE5AC: CC210090 02004F9A
	s_waitcnt lgkmcnt(0)                                       // 0000001CE5B4: BF89FC07
	v_fma_mixlo_f16 v146, v100, s39, 0                         // 0000001CE5B8: CC210092 02004F64
	v_fma_mixhi_f16 v146, v101, s39, 0                         // 0000001CE5C0: CC220092 02004F65
	v_fma_mixlo_f16 v147, v102, s39, 0                         // 0000001CE5C8: CC210093 02004F66
	v_fma_mixhi_f16 v147, v103, s39, 0                         // 0000001CE5D0: CC220093 02004F67
	ds_load_b128 v[100:103], v129 offset:192                   // 0000001CE5D8: DBFC00C0 64000081
	v_fma_mixhi_f16 v144, v155, s39, 0                         // 0000001CE5E0: CC220090 02004F9B
	v_fma_mixlo_f16 v145, v156, s39, 0                         // 0000001CE5E8: CC210091 02004F9C
	v_fma_mixhi_f16 v145, v157, s39, 0                         // 0000001CE5F0: CC220091 02004F9D
	v_fma_mixlo_f16 v148, v158, s39, 0                         // 0000001CE5F8: CC210094 02004F9E
	v_fma_mixhi_f16 v148, v159, s39, 0                         // 0000001CE600: CC220094 02004F9F
	v_fma_mixlo_f16 v149, v160, s39, 0                         // 0000001CE608: CC210095 02004FA0
	v_fma_mixhi_f16 v149, v161, s39, 0                         // 0000001CE610: CC220095 02004FA1
	v_fma_mixlo_f16 v150, v162, s39, 0                         // 0000001CE618: CC210096 02004FA2
	v_fma_mixhi_f16 v150, v163, s39, 0                         // 0000001CE620: CC220096 02004FA3
	v_fma_mixlo_f16 v151, v164, s39, 0                         // 0000001CE628: CC210097 02004FA4
	v_fma_mixhi_f16 v151, v165, s39, 0                         // 0000001CE630: CC220097 02004FA5
	v_fma_mixlo_f16 v152, v166, s39, 0                         // 0000001CE638: CC210098 02004FA6
	v_fma_mixhi_f16 v152, v167, s39, 0                         // 0000001CE640: CC220098 02004FA7
	v_fma_mixlo_f16 v153, v168, s39, 0                         // 0000001CE648: CC210099 02004FA8
	v_fma_mixhi_f16 v153, v169, s39, 0                         // 0000001CE650: CC220099 02004FA9
	v_fma_mixlo_f16 v154, v170, s39, 0                         // 0000001CE658: CC21009A 02004FAA
	v_fma_mixhi_f16 v154, v171, s39, 0                         // 0000001CE660: CC22009A 02004FAB
	v_fma_mixlo_f16 v155, v172, s39, 0                         // 0000001CE668: CC21009B 02004FAC
	v_fma_mixhi_f16 v155, v173, s39, 0                         // 0000001CE670: CC22009B 02004FAD
	v_fma_mixlo_f16 v156, v174, s39, 0                         // 0000001CE678: CC21009C 02004FAE
	v_fma_mixhi_f16 v156, v175, s39, 0                         // 0000001CE680: CC22009C 02004FAF
	v_fma_mixlo_f16 v157, v176, s39, 0                         // 0000001CE688: CC21009D 02004FB0
	v_fma_mixhi_f16 v157, v177, s39, 0                         // 0000001CE690: CC22009D 02004FB1
	ds_load_b128 v[158:161], v129 offset:208                   // 0000001CE698: DBFC00D0 9E000081
	ds_load_b128 v[162:165], v129 offset:224                   // 0000001CE6A0: DBFC00E0 A2000081
	s_waitcnt vmcnt(10)                                        // 0000001CE6A8: BF892BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[73:80], v[81:88], v[41:48]// 0000001CE6AC: CC404029 1CA6A349
	ds_load_b128 v[81:84], v129 offset:240                     // 0000001CE6B4: DBFC00F0 51000081
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[89:96], v[17:24]// 0000001CE6BC: CC404011 1C46B349
	v_wmma_f32_16x16x16_f16 v[49:56], v[73:80], v[142:149], v[49:56]// 0000001CE6C4: CC404031 1CC71D49
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[150:157], v[25:32]// 0000001CE6CC: CC404019 1C672D49
	ds_load_b128 v[85:88], v129 offset:8640                    // 0000001CE6D4: DBFC21C0 55000081
	ds_load_b128 v[89:92], v129 offset:8656                    // 0000001CE6DC: DBFC21D0 59000081
	s_waitcnt lgkmcnt(5)                                       // 0000001CE6E4: BF89FC57
	v_fma_mixlo_f16 v73, v100, s39, 0                          // 0000001CE6E8: CC210049 02004F64
	v_fma_mixhi_f16 v73, v101, s39, 0                          // 0000001CE6F0: CC220049 02004F65
	v_fma_mixlo_f16 v74, v102, s39, 0                          // 0000001CE6F8: CC21004A 02004F66
	v_fma_mixhi_f16 v74, v103, s39, 0                          // 0000001CE700: CC22004A 02004F67
	ds_load_b128 v[93:96], v129 offset:8672                    // 0000001CE708: DBFC21E0 5D000081
	ds_load_b128 v[100:103], v129 offset:8688                  // 0000001CE710: DBFC21F0 64000081
	ds_load_b128 v[142:145], v129 offset:17088                 // 0000001CE718: DBFC42C0 8E000081
	ds_load_b128 v[146:149], v129 offset:17104                 // 0000001CE720: DBFC42D0 92000081
	ds_load_b128 v[150:153], v129 offset:17120                 // 0000001CE728: DBFC42E0 96000081
	ds_load_b128 v[154:157], v129 offset:17136                 // 0000001CE730: DBFC42F0 9A000081
	s_waitcnt lgkmcnt(10)                                      // 0000001CE738: BF89FCA7
	v_fma_mixlo_f16 v75, v158, s39, 0                          // 0000001CE73C: CC21004B 02004F9E
	v_fma_mixhi_f16 v75, v159, s39, 0                          // 0000001CE744: CC22004B 02004F9F
	v_fma_mixlo_f16 v76, v160, s39, 0                          // 0000001CE74C: CC21004C 02004FA0
	s_waitcnt lgkmcnt(8)                                       // 0000001CE754: BF89FC87
	v_fma_mixhi_f16 v79, v82, s39, 0                           // 0000001CE758: CC22004F 02004F52
	v_fma_mixhi_f16 v76, v161, s39, 0                          // 0000001CE760: CC22004C 02004FA1
	v_fma_mixlo_f16 v77, v162, s39, 0                          // 0000001CE768: CC21004D 02004FA2
	v_fma_mixhi_f16 v77, v163, s39, 0                          // 0000001CE770: CC22004D 02004FA3
	s_waitcnt lgkmcnt(7)                                       // 0000001CE778: BF89FC77
	v_fma_mixlo_f16 v82, v87, s39, 0                           // 0000001CE77C: CC210052 02004F57
	v_fma_mixhi_f16 v82, v88, s39, 0                           // 0000001CE784: CC220052 02004F58
	v_fma_mixlo_f16 v78, v164, s39, 0                          // 0000001CE78C: CC21004E 02004FA4
	v_fma_mixhi_f16 v78, v165, s39, 0                          // 0000001CE794: CC22004E 02004FA5
	v_fma_mixlo_f16 v79, v81, s39, 0                           // 0000001CE79C: CC21004F 02004F51
	v_fma_mixhi_f16 v80, v84, s39, 0                           // 0000001CE7A4: CC220050 02004F54
	v_fma_mixlo_f16 v81, v85, s39, 0                           // 0000001CE7AC: CC210051 02004F55
	s_waitcnt lgkmcnt(4)                                       // 0000001CE7B4: BF89FC47
	v_fma_mixlo_f16 v87, v100, s39, 0                          // 0000001CE7B8: CC210057 02004F64
	v_fma_mixhi_f16 v87, v101, s39, 0                          // 0000001CE7C0: CC220057 02004F65
	v_fma_mixlo_f16 v88, v102, s39, 0                          // 0000001CE7C8: CC210058 02004F66
	v_fma_mixhi_f16 v88, v103, s39, 0                          // 0000001CE7D0: CC220058 02004F67
	ds_load_b128 v[100:103], v129 offset:25536                 // 0000001CE7D8: DBFC63C0 64000081
	ds_load_b128 v[158:161], v129 offset:25552                 // 0000001CE7E0: DBFC63D0 9E000081
	v_fma_mixhi_f16 v84, v92, s39, 0                           // 0000001CE7E8: CC220054 02004F5C
	v_fma_mixlo_f16 v85, v93, s39, 0                           // 0000001CE7F0: CC210055 02004F5D
	s_waitcnt lgkmcnt(4)                                       // 0000001CE7F8: BF89FC47
	v_fma_mixlo_f16 v92, v148, s39, 0                          // 0000001CE7FC: CC21005C 02004F94
	ds_load_b128 v[162:165], v129 offset:25568                 // 0000001CE804: DBFC63E0 A2000081
	v_fma_mixhi_f16 v92, v149, s39, 0                          // 0000001CE80C: CC22005C 02004F95
	s_waitcnt lgkmcnt(4)                                       // 0000001CE814: BF89FC47
	v_fma_mixlo_f16 v93, v150, s39, 0                          // 0000001CE818: CC21005D 02004F96
	v_fma_mixhi_f16 v93, v151, s39, 0                          // 0000001CE820: CC22005D 02004F97
	ds_load_b128 v[148:151], v129 offset:25584                 // 0000001CE828: DBFC63F0 94000081
	v_fma_mixlo_f16 v80, v83, s39, 0                           // 0000001CE830: CC210050 02004F53
	v_fma_mixlo_f16 v83, v89, s39, 0                           // 0000001CE838: CC210053 02004F59
	v_fma_mixlo_f16 v89, v142, s39, 0                          // 0000001CE840: CC210059 02004F8E
	v_fma_mixhi_f16 v89, v143, s39, 0                          // 0000001CE848: CC220059 02004F8F
	v_fma_mixhi_f16 v81, v86, s39, 0                           // 0000001CE850: CC220051 02004F56
	v_fma_mixhi_f16 v83, v90, s39, 0                           // 0000001CE858: CC220053 02004F5A
	v_fma_mixlo_f16 v84, v91, s39, 0                           // 0000001CE860: CC210054 02004F5B
	v_fma_mixhi_f16 v85, v94, s39, 0                           // 0000001CE868: CC220055 02004F5E
	v_fma_mixlo_f16 v86, v95, s39, 0                           // 0000001CE870: CC210056 02004F5F
	v_fma_mixhi_f16 v86, v96, s39, 0                           // 0000001CE878: CC220056 02004F60
	s_waitcnt lgkmcnt(3)                                       // 0000001CE880: BF89FC37
	v_fma_mixlo_f16 v142, v100, s39, 0                         // 0000001CE884: CC21008E 02004F64
	v_fma_mixhi_f16 v142, v101, s39, 0                         // 0000001CE88C: CC22008E 02004F65
	v_fma_mixlo_f16 v143, v102, s39, 0                         // 0000001CE894: CC21008F 02004F66
	v_fma_mixhi_f16 v143, v103, s39, 0                         // 0000001CE89C: CC22008F 02004F67
	ds_load_b128 v[100:103], v129 offset:256                   // 0000001CE8A4: DBFC0100 64000081
	v_fma_mixlo_f16 v90, v144, s39, 0                          // 0000001CE8AC: CC21005A 02004F90
	v_fma_mixhi_f16 v90, v145, s39, 0                          // 0000001CE8B4: CC22005A 02004F91
	v_fma_mixlo_f16 v91, v146, s39, 0                          // 0000001CE8BC: CC21005B 02004F92
	v_fma_mixhi_f16 v91, v147, s39, 0                          // 0000001CE8C4: CC22005B 02004F93
	v_fma_mixlo_f16 v94, v152, s39, 0                          // 0000001CE8CC: CC21005E 02004F98
	v_fma_mixhi_f16 v94, v153, s39, 0                          // 0000001CE8D4: CC22005E 02004F99
	v_fma_mixlo_f16 v95, v154, s39, 0                          // 0000001CE8DC: CC21005F 02004F9A
	v_fma_mixhi_f16 v95, v155, s39, 0                          // 0000001CE8E4: CC22005F 02004F9B
	v_fma_mixlo_f16 v96, v156, s39, 0                          // 0000001CE8EC: CC210060 02004F9C
	v_fma_mixhi_f16 v96, v157, s39, 0                          // 0000001CE8F4: CC220060 02004F9D
	s_waitcnt lgkmcnt(3)                                       // 0000001CE8FC: BF89FC37
	v_fma_mixlo_f16 v144, v158, s39, 0                         // 0000001CE900: CC210090 02004F9E
	v_fma_mixhi_f16 v144, v159, s39, 0                         // 0000001CE908: CC220090 02004F9F
	v_fma_mixlo_f16 v145, v160, s39, 0                         // 0000001CE910: CC210091 02004FA0
	v_fma_mixhi_f16 v145, v161, s39, 0                         // 0000001CE918: CC220091 02004FA1
	s_waitcnt lgkmcnt(2)                                       // 0000001CE920: BF89FC27
	v_fma_mixlo_f16 v146, v162, s39, 0                         // 0000001CE924: CC210092 02004FA2
	v_fma_mixhi_f16 v146, v163, s39, 0                         // 0000001CE92C: CC220092 02004FA3
	v_fma_mixlo_f16 v147, v164, s39, 0                         // 0000001CE934: CC210093 02004FA4
	v_fma_mixhi_f16 v147, v165, s39, 0                         // 0000001CE93C: CC220093 02004FA5
	s_waitcnt lgkmcnt(1)                                       // 0000001CE944: BF89FC17
	v_fma_mixlo_f16 v148, v148, s39, 0                         // 0000001CE948: CC210094 02004F94
	v_fma_mixhi_f16 v148, v149, s39, 0                         // 0000001CE950: CC220094 02004F95
	v_fma_mixlo_f16 v149, v150, s39, 0                         // 0000001CE958: CC210095 02004F96
	v_fma_mixhi_f16 v149, v151, s39, 0                         // 0000001CE960: CC220095 02004F97
	ds_load_b128 v[152:155], v129 offset:272                   // 0000001CE968: DBFC0110 98000081
	ds_load_b128 v[156:159], v129 offset:288                   // 0000001CE970: DBFC0120 9C000081
	s_waitcnt vmcnt(8)                                         // 0000001CE978: BF8923F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[73:80], v[41:48]// 0000001CE97C: CC404029 1CA69341
	ds_load_b128 v[73:76], v129 offset:304                     // 0000001CE984: DBFC0130 49000081
	v_wmma_f32_16x16x16_f16 v[17:24], v[65:72], v[81:88], v[17:24]// 0000001CE98C: CC404011 1C46A341
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[89:96], v[49:56]// 0000001CE994: CC404031 1CC6B341
	v_wmma_f32_16x16x16_f16 v[25:32], v[65:72], v[142:149], v[25:32]// 0000001CE99C: CC404019 1C671D41
	ds_load_b128 v[77:80], v129 offset:8704                    // 0000001CE9A4: DBFC2200 4D000081
	ds_load_b128 v[81:84], v129 offset:8720                    // 0000001CE9AC: DBFC2210 51000081
	s_waitcnt lgkmcnt(5)                                       // 0000001CE9B4: BF89FC57
	v_fma_mixlo_f16 v65, v100, s39, 0                          // 0000001CE9B8: CC210041 02004F64
	v_fma_mixhi_f16 v65, v101, s39, 0                          // 0000001CE9C0: CC220041 02004F65
	v_fma_mixlo_f16 v66, v102, s39, 0                          // 0000001CE9C8: CC210042 02004F66
	v_fma_mixhi_f16 v66, v103, s39, 0                          // 0000001CE9D0: CC220042 02004F67
	ds_load_b128 v[85:88], v129 offset:8736                    // 0000001CE9D8: DBFC2220 55000081
	ds_load_b128 v[89:92], v129 offset:8752                    // 0000001CE9E0: DBFC2230 59000081
	ds_load_b128 v[93:96], v129 offset:17152                   // 0000001CE9E8: DBFC4300 5D000081
	ds_load_b128 v[100:103], v129 offset:17168                 // 0000001CE9F0: DBFC4310 64000081
	ds_load_b128 v[142:145], v129 offset:17184                 // 0000001CE9F8: DBFC4320 8E000081
	ds_load_b128 v[146:149], v129 offset:17200                 // 0000001CEA00: DBFC4330 92000081
	s_waitcnt lgkmcnt(10)                                      // 0000001CEA08: BF89FCA7
	v_fma_mixlo_f16 v67, v152, s39, 0                          // 0000001CEA0C: CC210043 02004F98
	v_fma_mixhi_f16 v67, v153, s39, 0                          // 0000001CEA14: CC220043 02004F99
	ds_load_b128 v[150:153], v129 offset:25616                 // 0000001CEA1C: DBFC6410 96000081
	s_waitcnt lgkmcnt(9)                                       // 0000001CEA24: BF89FC97
	v_fma_mixhi_f16 v71, v74, s39, 0                           // 0000001CEA28: CC220047 02004F4A
	v_fma_mixlo_f16 v72, v75, s39, 0                           // 0000001CEA30: CC210048 02004F4B
	v_fma_mixhi_f16 v72, v76, s39, 0                           // 0000001CEA38: CC220048 02004F4C
	v_fma_mixlo_f16 v68, v154, s39, 0                          // 0000001CEA40: CC210044 02004F9A
	s_waitcnt lgkmcnt(8)                                       // 0000001CEA48: BF89FC87
	v_fma_mixlo_f16 v74, v79, s39, 0                           // 0000001CEA4C: CC21004A 02004F4F
	v_fma_mixhi_f16 v74, v80, s39, 0                           // 0000001CEA54: CC22004A 02004F50
	s_waitcnt lgkmcnt(7)                                       // 0000001CEA5C: BF89FC77
	v_fma_mixlo_f16 v75, v81, s39, 0                           // 0000001CEA60: CC21004B 02004F51
	v_fma_mixhi_f16 v75, v82, s39, 0                           // 0000001CEA68: CC22004B 02004F52
	v_fma_mixlo_f16 v76, v83, s39, 0                           // 0000001CEA70: CC21004C 02004F53
	v_fma_mixhi_f16 v76, v84, s39, 0                           // 0000001CEA78: CC22004C 02004F54
	v_fma_mixhi_f16 v68, v155, s39, 0                          // 0000001CEA80: CC220044 02004F9B
	s_waitcnt lgkmcnt(5)                                       // 0000001CEA88: BF89FC57
	v_fma_mixlo_f16 v79, v89, s39, 0                           // 0000001CEA8C: CC21004F 02004F59
	v_fma_mixhi_f16 v79, v90, s39, 0                           // 0000001CEA94: CC22004F 02004F5A
	v_fma_mixlo_f16 v80, v91, s39, 0                           // 0000001CEA9C: CC210050 02004F5B
	v_fma_mixhi_f16 v80, v92, s39, 0                           // 0000001CEAA4: CC220050 02004F5C
	ds_load_b128 v[89:92], v129 offset:25600                   // 0000001CEAAC: DBFC6400 59000081
	s_waitcnt lgkmcnt(5)                                       // 0000001CEAB4: BF89FC57
	v_fma_mixlo_f16 v81, v93, s39, 0                           // 0000001CEAB8: CC210051 02004F5D
	v_fma_mixhi_f16 v81, v94, s39, 0                           // 0000001CEAC0: CC220051 02004F5E
	v_fma_mixlo_f16 v82, v95, s39, 0                           // 0000001CEAC8: CC210052 02004F5F
	v_fma_mixhi_f16 v82, v96, s39, 0                           // 0000001CEAD0: CC220052 02004F60
	s_waitcnt lgkmcnt(4)                                       // 0000001CEAD8: BF89FC47
	v_fma_mixlo_f16 v83, v100, s39, 0                          // 0000001CEADC: CC210053 02004F64
	v_fma_mixhi_f16 v83, v101, s39, 0                          // 0000001CEAE4: CC220053 02004F65
	v_fma_mixlo_f16 v84, v102, s39, 0                          // 0000001CEAEC: CC210054 02004F66
	ds_load_b128 v[93:96], v129 offset:25632                   // 0000001CEAF4: DBFC6420 5D000081
	v_fma_mixhi_f16 v84, v103, s39, 0                          // 0000001CEAFC: CC220054 02004F67
	ds_load_b128 v[100:103], v129 offset:25648                 // 0000001CEB04: DBFC6430 64000081
	v_fma_mixlo_f16 v69, v156, s39, 0                          // 0000001CEB0C: CC210045 02004F9C
	v_fma_mixhi_f16 v69, v157, s39, 0                          // 0000001CEB14: CC220045 02004F9D
	v_fma_mixlo_f16 v70, v158, s39, 0                          // 0000001CEB1C: CC210046 02004F9E
	v_fma_mixhi_f16 v70, v159, s39, 0                          // 0000001CEB24: CC220046 02004F9F
	v_fma_mixlo_f16 v71, v73, s39, 0                           // 0000001CEB2C: CC210047 02004F49
	v_fma_mixlo_f16 v73, v77, s39, 0                           // 0000001CEB34: CC210049 02004F4D
	v_fma_mixhi_f16 v73, v78, s39, 0                           // 0000001CEB3C: CC220049 02004F4E
	v_fma_mixlo_f16 v77, v85, s39, 0                           // 0000001CEB44: CC21004D 02004F55
	v_fma_mixhi_f16 v77, v86, s39, 0                           // 0000001CEB4C: CC22004D 02004F56
	v_fma_mixlo_f16 v78, v87, s39, 0                           // 0000001CEB54: CC21004E 02004F57
	v_fma_mixhi_f16 v78, v88, s39, 0                           // 0000001CEB5C: CC22004E 02004F58
	s_waitcnt lgkmcnt(5)                                       // 0000001CEB64: BF89FC57
	v_fma_mixlo_f16 v85, v142, s39, 0                          // 0000001CEB68: CC210055 02004F8E
	v_fma_mixhi_f16 v85, v143, s39, 0                          // 0000001CEB70: CC220055 02004F8F
	v_fma_mixlo_f16 v86, v144, s39, 0                          // 0000001CEB78: CC210056 02004F90
	v_fma_mixhi_f16 v86, v145, s39, 0                          // 0000001CEB80: CC220056 02004F91
	s_waitcnt lgkmcnt(4)                                       // 0000001CEB88: BF89FC47
	v_fma_mixlo_f16 v87, v146, s39, 0                          // 0000001CEB8C: CC210057 02004F92
	v_fma_mixhi_f16 v87, v147, s39, 0                          // 0000001CEB94: CC220057 02004F93
	v_fma_mixlo_f16 v88, v148, s39, 0                          // 0000001CEB9C: CC210058 02004F94
	v_fma_mixhi_f16 v88, v149, s39, 0                          // 0000001CEBA4: CC220058 02004F95
	s_waitcnt lgkmcnt(2)                                       // 0000001CEBAC: BF89FC27
	v_fma_mixlo_f16 v89, v89, s39, 0                           // 0000001CEBB0: CC210059 02004F59
	v_fma_mixhi_f16 v89, v90, s39, 0                           // 0000001CEBB8: CC220059 02004F5A
	v_fma_mixlo_f16 v90, v91, s39, 0                           // 0000001CEBC0: CC21005A 02004F5B
	v_fma_mixhi_f16 v90, v92, s39, 0                           // 0000001CEBC8: CC22005A 02004F5C
	v_fma_mixlo_f16 v91, v150, s39, 0                          // 0000001CEBD0: CC21005B 02004F96
	v_fma_mixhi_f16 v91, v151, s39, 0                          // 0000001CEBD8: CC22005B 02004F97
	v_fma_mixlo_f16 v92, v152, s39, 0                          // 0000001CEBE0: CC21005C 02004F98
	v_fma_mixhi_f16 v92, v153, s39, 0                          // 0000001CEBE8: CC22005C 02004F99
	s_waitcnt lgkmcnt(1)                                       // 0000001CEBF0: BF89FC17
	v_fma_mixlo_f16 v93, v93, s39, 0                           // 0000001CEBF4: CC21005D 02004F5D
	v_fma_mixhi_f16 v93, v94, s39, 0                           // 0000001CEBFC: CC22005D 02004F5E
	v_fma_mixlo_f16 v94, v95, s39, 0                           // 0000001CEC04: CC21005E 02004F5F
	v_fma_mixhi_f16 v94, v96, s39, 0                           // 0000001CEC0C: CC22005E 02004F60
	s_waitcnt lgkmcnt(0)                                       // 0000001CEC14: BF89FC07
	v_fma_mixlo_f16 v95, v100, s39, 0                          // 0000001CEC18: CC21005F 02004F64
	v_fma_mixhi_f16 v95, v101, s39, 0                          // 0000001CEC20: CC22005F 02004F65
	v_fma_mixlo_f16 v96, v102, s39, 0                          // 0000001CEC28: CC210060 02004F66
	v_fma_mixhi_f16 v96, v103, s39, 0                          // 0000001CEC30: CC220060 02004F67
	ds_load_b128 v[142:145], v129 offset:320                   // 0000001CEC38: DBFC0140 8E000081
	ds_load_b128 v[146:149], v129 offset:336                   // 0000001CEC40: DBFC0150 92000081
	ds_load_b128 v[150:153], v129 offset:352                   // 0000001CEC48: DBFC0160 96000081
	s_waitcnt vmcnt(6)                                         // 0000001CEC50: BF891BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[57:64], v[65:72], v[41:48]// 0000001CEC54: CC404029 1CA68339
	ds_load_b128 v[65:68], v129 offset:368                     // 0000001CEC5C: DBFC0170 41000081
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[73:80], v[17:24]// 0000001CEC64: CC404011 1C469339
	v_wmma_f32_16x16x16_f16 v[49:56], v[57:64], v[81:88], v[49:56]// 0000001CEC6C: CC404031 1CC6A339
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[89:96], v[25:32]// 0000001CEC74: CC404019 1C66B339
	ds_load_b128 v[69:72], v129 offset:8768                    // 0000001CEC7C: DBFC2240 45000081
	ds_load_b128 v[73:76], v129 offset:8784                    // 0000001CEC84: DBFC2250 49000081
	ds_load_b128 v[77:80], v129 offset:8800                    // 0000001CEC8C: DBFC2260 4D000081
	ds_load_b128 v[81:84], v129 offset:8816                    // 0000001CEC94: DBFC2270 51000081
	ds_load_b128 v[85:88], v129 offset:17216                   // 0000001CEC9C: DBFC4340 55000081
	ds_load_b128 v[89:92], v129 offset:17232                   // 0000001CECA4: DBFC4350 59000081
	ds_load_b128 v[93:96], v129 offset:17248                   // 0000001CECAC: DBFC4360 5D000081
	ds_load_b128 v[100:103], v129 offset:17264                 // 0000001CECB4: DBFC4370 64000081
	s_waitcnt lgkmcnt(11)                                      // 0000001CECBC: BF89FCB7
	v_fma_mixlo_f16 v57, v142, s39, 0                          // 0000001CECC0: CC210039 02004F8E
	v_fma_mixhi_f16 v57, v143, s39, 0                          // 0000001CECC8: CC220039 02004F8F
	v_fma_mixlo_f16 v58, v144, s39, 0                          // 0000001CECD0: CC21003A 02004F90
	v_fma_mixhi_f16 v58, v145, s39, 0                          // 0000001CECD8: CC22003A 02004F91
	s_waitcnt lgkmcnt(8)                                       // 0000001CECE0: BF89FC87
	v_fma_mixhi_f16 v63, v66, s39, 0                           // 0000001CECE4: CC22003F 02004F42
	v_fma_mixlo_f16 v64, v67, s39, 0                           // 0000001CECEC: CC210040 02004F43
	v_fma_mixhi_f16 v64, v68, s39, 0                           // 0000001CECF4: CC220040 02004F44
	ds_load_b128 v[142:145], v129 offset:25680                 // 0000001CECFC: DBFC6450 8E000081
	s_waitcnt lgkmcnt(8)                                       // 0000001CED04: BF89FC87
	v_fma_mixlo_f16 v66, v71, s39, 0                           // 0000001CED08: CC210042 02004F47
	v_fma_mixhi_f16 v66, v72, s39, 0                           // 0000001CED10: CC220042 02004F48
	s_waitcnt lgkmcnt(7)                                       // 0000001CED18: BF89FC77
	v_fma_mixlo_f16 v67, v73, s39, 0                           // 0000001CED1C: CC210043 02004F49
	v_fma_mixhi_f16 v67, v74, s39, 0                           // 0000001CED24: CC220043 02004F4A
	v_fma_mixlo_f16 v68, v75, s39, 0                           // 0000001CED2C: CC210044 02004F4B
	v_fma_mixhi_f16 v68, v76, s39, 0                           // 0000001CED34: CC220044 02004F4C
	s_waitcnt lgkmcnt(5)                                       // 0000001CED3C: BF89FC57
	v_fma_mixlo_f16 v71, v81, s39, 0                           // 0000001CED40: CC210047 02004F51
	v_fma_mixhi_f16 v71, v82, s39, 0                           // 0000001CED48: CC220047 02004F52
	v_fma_mixlo_f16 v72, v83, s39, 0                           // 0000001CED50: CC210048 02004F53
	v_fma_mixhi_f16 v72, v84, s39, 0                           // 0000001CED58: CC220048 02004F54
	ds_load_b128 v[81:84], v129 offset:25664                   // 0000001CED60: DBFC6440 51000081
	s_waitcnt lgkmcnt(5)                                       // 0000001CED68: BF89FC57
	v_fma_mixlo_f16 v73, v85, s39, 0                           // 0000001CED6C: CC210049 02004F55
	v_fma_mixhi_f16 v73, v86, s39, 0                           // 0000001CED74: CC220049 02004F56
	v_fma_mixlo_f16 v74, v87, s39, 0                           // 0000001CED7C: CC21004A 02004F57
	v_fma_mixhi_f16 v74, v88, s39, 0                           // 0000001CED84: CC22004A 02004F58
	s_waitcnt lgkmcnt(4)                                       // 0000001CED8C: BF89FC47
	v_fma_mixlo_f16 v75, v89, s39, 0                           // 0000001CED90: CC21004B 02004F59
	v_fma_mixhi_f16 v75, v90, s39, 0                           // 0000001CED98: CC22004B 02004F5A
	v_fma_mixlo_f16 v76, v91, s39, 0                           // 0000001CEDA0: CC21004C 02004F5B
	ds_load_b128 v[85:88], v129 offset:25696                   // 0000001CEDA8: DBFC6460 55000081
	v_fma_mixhi_f16 v76, v92, s39, 0                           // 0000001CEDB0: CC22004C 02004F5C
	ds_load_b128 v[89:92], v129 offset:25712                   // 0000001CEDB8: DBFC6470 59000081
	v_fma_mixlo_f16 v59, v146, s39, 0                          // 0000001CEDC0: CC21003B 02004F92
	v_fma_mixhi_f16 v59, v147, s39, 0                          // 0000001CEDC8: CC22003B 02004F93
	v_fma_mixlo_f16 v60, v148, s39, 0                          // 0000001CEDD0: CC21003C 02004F94
	v_fma_mixhi_f16 v60, v149, s39, 0                          // 0000001CEDD8: CC22003C 02004F95
	v_fma_mixlo_f16 v61, v150, s39, 0                          // 0000001CEDE0: CC21003D 02004F96
	v_fma_mixhi_f16 v61, v151, s39, 0                          // 0000001CEDE8: CC22003D 02004F97
	v_fma_mixlo_f16 v62, v152, s39, 0                          // 0000001CEDF0: CC21003E 02004F98
	v_fma_mixhi_f16 v62, v153, s39, 0                          // 0000001CEDF8: CC22003E 02004F99
	v_fma_mixlo_f16 v63, v65, s39, 0                           // 0000001CEE00: CC21003F 02004F41
	v_fma_mixlo_f16 v65, v69, s39, 0                           // 0000001CEE08: CC210041 02004F45
	v_fma_mixhi_f16 v65, v70, s39, 0                           // 0000001CEE10: CC220041 02004F46
	v_fma_mixlo_f16 v69, v77, s39, 0                           // 0000001CEE18: CC210045 02004F4D
	v_fma_mixhi_f16 v69, v78, s39, 0                           // 0000001CEE20: CC220045 02004F4E
	v_fma_mixlo_f16 v70, v79, s39, 0                           // 0000001CEE28: CC210046 02004F4F
	v_fma_mixhi_f16 v70, v80, s39, 0                           // 0000001CEE30: CC220046 02004F50
	s_waitcnt lgkmcnt(5)                                       // 0000001CEE38: BF89FC57
	v_fma_mixlo_f16 v77, v93, s39, 0                           // 0000001CEE3C: CC21004D 02004F5D
	v_fma_mixhi_f16 v77, v94, s39, 0                           // 0000001CEE44: CC22004D 02004F5E
	v_fma_mixlo_f16 v78, v95, s39, 0                           // 0000001CEE4C: CC21004E 02004F5F
	v_fma_mixhi_f16 v78, v96, s39, 0                           // 0000001CEE54: CC22004E 02004F60
	s_waitcnt lgkmcnt(4)                                       // 0000001CEE5C: BF89FC47
	v_fma_mixlo_f16 v79, v100, s39, 0                          // 0000001CEE60: CC21004F 02004F64
	v_fma_mixhi_f16 v79, v101, s39, 0                          // 0000001CEE68: CC22004F 02004F65
	v_fma_mixlo_f16 v80, v102, s39, 0                          // 0000001CEE70: CC210050 02004F66
	v_fma_mixhi_f16 v80, v103, s39, 0                          // 0000001CEE78: CC220050 02004F67
	s_waitcnt lgkmcnt(2)                                       // 0000001CEE80: BF89FC27
	v_fma_mixlo_f16 v81, v81, s39, 0                           // 0000001CEE84: CC210051 02004F51
	v_fma_mixhi_f16 v81, v82, s39, 0                           // 0000001CEE8C: CC220051 02004F52
	v_fma_mixlo_f16 v82, v83, s39, 0                           // 0000001CEE94: CC210052 02004F53
	v_fma_mixhi_f16 v82, v84, s39, 0                           // 0000001CEE9C: CC220052 02004F54
	v_fma_mixlo_f16 v83, v142, s39, 0                          // 0000001CEEA4: CC210053 02004F8E
	v_fma_mixhi_f16 v83, v143, s39, 0                          // 0000001CEEAC: CC220053 02004F8F
	v_fma_mixlo_f16 v84, v144, s39, 0                          // 0000001CEEB4: CC210054 02004F90
	v_fma_mixhi_f16 v84, v145, s39, 0                          // 0000001CEEBC: CC220054 02004F91
	s_waitcnt lgkmcnt(1)                                       // 0000001CEEC4: BF89FC17
	v_fma_mixlo_f16 v85, v85, s39, 0                           // 0000001CEEC8: CC210055 02004F55
	v_fma_mixhi_f16 v85, v86, s39, 0                           // 0000001CEED0: CC220055 02004F56
	v_fma_mixlo_f16 v86, v87, s39, 0                           // 0000001CEED8: CC210056 02004F57
	v_fma_mixhi_f16 v86, v88, s39, 0                           // 0000001CEEE0: CC220056 02004F58
	s_waitcnt lgkmcnt(0)                                       // 0000001CEEE8: BF89FC07
	v_fma_mixlo_f16 v87, v89, s39, 0                           // 0000001CEEEC: CC210057 02004F59
	v_fma_mixhi_f16 v87, v90, s39, 0                           // 0000001CEEF4: CC220057 02004F5A
	v_fma_mixlo_f16 v88, v91, s39, 0                           // 0000001CEEFC: CC210058 02004F5B
	v_fma_mixhi_f16 v88, v92, s39, 0                           // 0000001CEF04: CC220058 02004F5C
	ds_load_b128 v[93:96], v129 offset:384                     // 0000001CEF0C: DBFC0180 5D000081
	ds_load_b128 v[100:103], v129 offset:400                   // 0000001CEF14: DBFC0190 64000081
	ds_load_b128 v[142:145], v129 offset:416                   // 0000001CEF1C: DBFC01A0 8E000081
	s_waitcnt vmcnt(4)                                         // 0000001CEF24: BF8913F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[33:40], v[57:64], v[41:48]// 0000001CEF28: CC404029 1CA67321
	ds_load_b128 v[57:60], v129 offset:432                     // 0000001CEF30: DBFC01B0 39000081
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[65:72], v[17:24]// 0000001CEF38: CC404011 1C468321
	v_wmma_f32_16x16x16_f16 v[49:56], v[33:40], v[73:80], v[49:56]// 0000001CEF40: CC404031 1CC69321
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[81:88], v[25:32]// 0000001CEF48: CC404019 1C66A321
	ds_load_b128 v[61:64], v129 offset:8832                    // 0000001CEF50: DBFC2280 3D000081
	ds_load_b128 v[65:68], v129 offset:8848                    // 0000001CEF58: DBFC2290 41000081
	ds_load_b128 v[69:72], v129 offset:8864                    // 0000001CEF60: DBFC22A0 45000081
	ds_load_b128 v[73:76], v129 offset:8880                    // 0000001CEF68: DBFC22B0 49000081
	ds_load_b128 v[77:80], v129 offset:17280                   // 0000001CEF70: DBFC4380 4D000081
	ds_load_b128 v[81:84], v129 offset:17296                   // 0000001CEF78: DBFC4390 51000081
	ds_load_b128 v[85:88], v129 offset:17312                   // 0000001CEF80: DBFC43A0 55000081
	ds_load_b128 v[89:92], v129 offset:17328                   // 0000001CEF88: DBFC43B0 59000081
	s_waitcnt lgkmcnt(11)                                      // 0000001CEF90: BF89FCB7
	v_fma_mixlo_f16 v33, v93, s39, 0                           // 0000001CEF94: CC210021 02004F5D
	v_fma_mixhi_f16 v33, v94, s39, 0                           // 0000001CEF9C: CC220021 02004F5E
	v_fma_mixlo_f16 v34, v95, s39, 0                           // 0000001CEFA4: CC210022 02004F5F
	v_fma_mixhi_f16 v34, v96, s39, 0                           // 0000001CEFAC: CC220022 02004F60
	s_waitcnt lgkmcnt(8)                                       // 0000001CEFB4: BF89FC87
	v_fma_mixhi_f16 v39, v58, s39, 0                           // 0000001CEFB8: CC220027 02004F3A
	v_fma_mixlo_f16 v40, v59, s39, 0                           // 0000001CEFC0: CC210028 02004F3B
	v_fma_mixhi_f16 v40, v60, s39, 0                           // 0000001CEFC8: CC220028 02004F3C
	ds_load_b128 v[93:96], v129 offset:25744                   // 0000001CEFD0: DBFC6490 5D000081
	s_waitcnt lgkmcnt(8)                                       // 0000001CEFD8: BF89FC87
	v_fma_mixlo_f16 v58, v63, s39, 0                           // 0000001CEFDC: CC21003A 02004F3F
	v_fma_mixhi_f16 v58, v64, s39, 0                           // 0000001CEFE4: CC22003A 02004F40
	s_waitcnt lgkmcnt(7)                                       // 0000001CEFEC: BF89FC77
	v_fma_mixlo_f16 v59, v65, s39, 0                           // 0000001CEFF0: CC21003B 02004F41
	v_fma_mixhi_f16 v59, v66, s39, 0                           // 0000001CEFF8: CC22003B 02004F42
	v_fma_mixlo_f16 v60, v67, s39, 0                           // 0000001CF000: CC21003C 02004F43
	v_fma_mixhi_f16 v60, v68, s39, 0                           // 0000001CF008: CC22003C 02004F44
	s_waitcnt lgkmcnt(5)                                       // 0000001CF010: BF89FC57
	v_fma_mixlo_f16 v63, v73, s39, 0                           // 0000001CF014: CC21003F 02004F49
	v_fma_mixhi_f16 v63, v74, s39, 0                           // 0000001CF01C: CC22003F 02004F4A
	v_fma_mixlo_f16 v64, v75, s39, 0                           // 0000001CF024: CC210040 02004F4B
	v_fma_mixhi_f16 v64, v76, s39, 0                           // 0000001CF02C: CC220040 02004F4C
	ds_load_b128 v[73:76], v129 offset:25728                   // 0000001CF034: DBFC6480 49000081
	s_waitcnt lgkmcnt(5)                                       // 0000001CF03C: BF89FC57
	v_fma_mixlo_f16 v65, v77, s39, 0                           // 0000001CF040: CC210041 02004F4D
	v_fma_mixhi_f16 v65, v78, s39, 0                           // 0000001CF048: CC220041 02004F4E
	v_fma_mixlo_f16 v66, v79, s39, 0                           // 0000001CF050: CC210042 02004F4F
	v_fma_mixhi_f16 v66, v80, s39, 0                           // 0000001CF058: CC220042 02004F50
	s_waitcnt lgkmcnt(4)                                       // 0000001CF060: BF89FC47
	v_fma_mixlo_f16 v67, v81, s39, 0                           // 0000001CF064: CC210043 02004F51
	v_fma_mixhi_f16 v67, v82, s39, 0                           // 0000001CF06C: CC220043 02004F52
	v_fma_mixlo_f16 v68, v83, s39, 0                           // 0000001CF074: CC210044 02004F53
	ds_load_b128 v[77:80], v129 offset:25760                   // 0000001CF07C: DBFC64A0 4D000081
	v_fma_mixhi_f16 v68, v84, s39, 0                           // 0000001CF084: CC220044 02004F54
	ds_load_b128 v[81:84], v129 offset:25776                   // 0000001CF08C: DBFC64B0 51000081
	v_fma_mixlo_f16 v35, v100, s39, 0                          // 0000001CF094: CC210023 02004F64
	v_fma_mixhi_f16 v35, v101, s39, 0                          // 0000001CF09C: CC220023 02004F65
	v_fma_mixlo_f16 v36, v102, s39, 0                          // 0000001CF0A4: CC210024 02004F66
	v_fma_mixhi_f16 v36, v103, s39, 0                          // 0000001CF0AC: CC220024 02004F67
	v_fma_mixlo_f16 v37, v142, s39, 0                          // 0000001CF0B4: CC210025 02004F8E
	v_fma_mixhi_f16 v37, v143, s39, 0                          // 0000001CF0BC: CC220025 02004F8F
	v_fma_mixlo_f16 v38, v144, s39, 0                          // 0000001CF0C4: CC210026 02004F90
	v_fma_mixhi_f16 v38, v145, s39, 0                          // 0000001CF0CC: CC220026 02004F91
	v_fma_mixlo_f16 v39, v57, s39, 0                           // 0000001CF0D4: CC210027 02004F39
	v_fma_mixlo_f16 v57, v61, s39, 0                           // 0000001CF0DC: CC210039 02004F3D
	v_fma_mixhi_f16 v57, v62, s39, 0                           // 0000001CF0E4: CC220039 02004F3E
	v_fma_mixlo_f16 v61, v69, s39, 0                           // 0000001CF0EC: CC21003D 02004F45
	v_fma_mixhi_f16 v61, v70, s39, 0                           // 0000001CF0F4: CC22003D 02004F46
	v_fma_mixlo_f16 v62, v71, s39, 0                           // 0000001CF0FC: CC21003E 02004F47
	v_fma_mixhi_f16 v62, v72, s39, 0                           // 0000001CF104: CC22003E 02004F48
	s_waitcnt lgkmcnt(5)                                       // 0000001CF10C: BF89FC57
	v_fma_mixlo_f16 v69, v85, s39, 0                           // 0000001CF110: CC210045 02004F55
	v_fma_mixhi_f16 v69, v86, s39, 0                           // 0000001CF118: CC220045 02004F56
	v_fma_mixlo_f16 v70, v87, s39, 0                           // 0000001CF120: CC210046 02004F57
	v_fma_mixhi_f16 v70, v88, s39, 0                           // 0000001CF128: CC220046 02004F58
	s_waitcnt lgkmcnt(4)                                       // 0000001CF130: BF89FC47
	v_fma_mixlo_f16 v71, v89, s39, 0                           // 0000001CF134: CC210047 02004F59
	v_fma_mixhi_f16 v71, v90, s39, 0                           // 0000001CF13C: CC220047 02004F5A
	v_fma_mixlo_f16 v72, v91, s39, 0                           // 0000001CF144: CC210048 02004F5B
	v_fma_mixhi_f16 v72, v92, s39, 0                           // 0000001CF14C: CC220048 02004F5C
	s_waitcnt lgkmcnt(2)                                       // 0000001CF154: BF89FC27
	v_fma_mixlo_f16 v73, v73, s39, 0                           // 0000001CF158: CC210049 02004F49
	v_fma_mixhi_f16 v73, v74, s39, 0                           // 0000001CF160: CC220049 02004F4A
	v_fma_mixlo_f16 v74, v75, s39, 0                           // 0000001CF168: CC21004A 02004F4B
	v_fma_mixhi_f16 v74, v76, s39, 0                           // 0000001CF170: CC22004A 02004F4C
	v_fma_mixlo_f16 v75, v93, s39, 0                           // 0000001CF178: CC21004B 02004F5D
	v_fma_mixhi_f16 v75, v94, s39, 0                           // 0000001CF180: CC22004B 02004F5E
	v_fma_mixlo_f16 v76, v95, s39, 0                           // 0000001CF188: CC21004C 02004F5F
	v_fma_mixhi_f16 v76, v96, s39, 0                           // 0000001CF190: CC22004C 02004F60
	s_waitcnt lgkmcnt(1)                                       // 0000001CF198: BF89FC17
	v_fma_mixlo_f16 v77, v77, s39, 0                           // 0000001CF19C: CC21004D 02004F4D
	v_fma_mixhi_f16 v77, v78, s39, 0                           // 0000001CF1A4: CC22004D 02004F4E
	v_fma_mixlo_f16 v78, v79, s39, 0                           // 0000001CF1AC: CC21004E 02004F4F
	v_fma_mixhi_f16 v78, v80, s39, 0                           // 0000001CF1B4: CC22004E 02004F50
	s_waitcnt lgkmcnt(0)                                       // 0000001CF1BC: BF89FC07
	v_fma_mixlo_f16 v79, v81, s39, 0                           // 0000001CF1C0: CC21004F 02004F51
	v_fma_mixhi_f16 v79, v82, s39, 0                           // 0000001CF1C8: CC22004F 02004F52
	v_fma_mixlo_f16 v80, v83, s39, 0                           // 0000001CF1D0: CC210050 02004F53
	v_fma_mixhi_f16 v80, v84, s39, 0                           // 0000001CF1D8: CC220050 02004F54
	ds_load_b128 v[85:88], v129 offset:448                     // 0000001CF1E0: DBFC01C0 55000081
	ds_load_b128 v[89:92], v129 offset:464                     // 0000001CF1E8: DBFC01D0 59000081
	ds_load_b128 v[93:96], v129 offset:480                     // 0000001CF1F0: DBFC01E0 5D000081
	s_waitcnt vmcnt(2)                                         // 0000001CF1F8: BF890BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[9:16], v[33:40], v[41:48]// 0000001CF1FC: CC404029 1CA64309
	ds_load_b128 v[33:36], v129 offset:496                     // 0000001CF204: DBFC01F0 21000081
	v_wmma_f32_16x16x16_f16 v[17:24], v[9:16], v[57:64], v[17:24]// 0000001CF20C: CC404011 1C467309
	v_wmma_f32_16x16x16_f16 v[49:56], v[9:16], v[65:72], v[49:56]// 0000001CF214: CC404031 1CC68309
	v_wmma_f32_16x16x16_f16 v[25:32], v[9:16], v[73:80], v[25:32]// 0000001CF21C: CC404019 1C669309
	ds_load_b128 v[37:40], v129 offset:8896                    // 0000001CF224: DBFC22C0 25000081
	ds_load_b128 v[57:60], v129 offset:8912                    // 0000001CF22C: DBFC22D0 39000081
	ds_load_b128 v[61:64], v129 offset:8928                    // 0000001CF234: DBFC22E0 3D000081
	ds_load_b128 v[65:68], v129 offset:8944                    // 0000001CF23C: DBFC22F0 41000081
	ds_load_b128 v[69:72], v129 offset:17344                   // 0000001CF244: DBFC43C0 45000081
	ds_load_b128 v[73:76], v129 offset:17360                   // 0000001CF24C: DBFC43D0 49000081
	ds_load_b128 v[77:80], v129 offset:17376                   // 0000001CF254: DBFC43E0 4D000081
	ds_load_b128 v[81:84], v129 offset:17392                   // 0000001CF25C: DBFC43F0 51000081
	s_waitcnt lgkmcnt(11)                                      // 0000001CF264: BF89FCB7
	v_fma_mixlo_f16 v9, v85, s39, 0                            // 0000001CF268: CC210009 02004F55
	v_fma_mixhi_f16 v9, v86, s39, 0                            // 0000001CF270: CC220009 02004F56
	v_fma_mixlo_f16 v10, v87, s39, 0                           // 0000001CF278: CC21000A 02004F57
	v_fma_mixhi_f16 v10, v88, s39, 0                           // 0000001CF280: CC22000A 02004F58
	s_waitcnt lgkmcnt(8)                                       // 0000001CF288: BF89FC87
	v_fma_mixhi_f16 v15, v34, s39, 0                           // 0000001CF28C: CC22000F 02004F22
	v_fma_mixlo_f16 v16, v35, s39, 0                           // 0000001CF294: CC210010 02004F23
	v_fma_mixhi_f16 v16, v36, s39, 0                           // 0000001CF29C: CC220010 02004F24
	ds_load_b128 v[85:88], v129 offset:25808                   // 0000001CF2A4: DBFC64D0 55000081
	s_waitcnt lgkmcnt(8)                                       // 0000001CF2AC: BF89FC87
	v_fma_mixlo_f16 v34, v39, s39, 0                           // 0000001CF2B0: CC210022 02004F27
	v_fma_mixhi_f16 v34, v40, s39, 0                           // 0000001CF2B8: CC220022 02004F28
	s_waitcnt lgkmcnt(7)                                       // 0000001CF2C0: BF89FC77
	v_fma_mixlo_f16 v35, v57, s39, 0                           // 0000001CF2C4: CC210023 02004F39
	v_fma_mixhi_f16 v35, v58, s39, 0                           // 0000001CF2CC: CC220023 02004F3A
	v_fma_mixlo_f16 v36, v59, s39, 0                           // 0000001CF2D4: CC210024 02004F3B
	v_fma_mixhi_f16 v36, v60, s39, 0                           // 0000001CF2DC: CC220024 02004F3C
	s_waitcnt lgkmcnt(5)                                       // 0000001CF2E4: BF89FC57
	v_fma_mixlo_f16 v39, v65, s39, 0                           // 0000001CF2E8: CC210027 02004F41
	v_fma_mixhi_f16 v39, v66, s39, 0                           // 0000001CF2F0: CC220027 02004F42
	v_fma_mixlo_f16 v40, v67, s39, 0                           // 0000001CF2F8: CC210028 02004F43
	v_fma_mixhi_f16 v40, v68, s39, 0                           // 0000001CF300: CC220028 02004F44
	ds_load_b128 v[65:68], v129 offset:25792                   // 0000001CF308: DBFC64C0 41000081
	s_waitcnt lgkmcnt(5)                                       // 0000001CF310: BF89FC57
	v_fma_mixlo_f16 v57, v69, s39, 0                           // 0000001CF314: CC210039 02004F45
	v_fma_mixhi_f16 v57, v70, s39, 0                           // 0000001CF31C: CC220039 02004F46
	v_fma_mixlo_f16 v58, v71, s39, 0                           // 0000001CF324: CC21003A 02004F47
	v_fma_mixhi_f16 v58, v72, s39, 0                           // 0000001CF32C: CC22003A 02004F48
	s_waitcnt lgkmcnt(4)                                       // 0000001CF334: BF89FC47
	v_fma_mixlo_f16 v59, v73, s39, 0                           // 0000001CF338: CC21003B 02004F49
	v_fma_mixhi_f16 v59, v74, s39, 0                           // 0000001CF340: CC22003B 02004F4A
	ds_load_b128 v[69:72], v129 offset:25824                   // 0000001CF348: DBFC64E0 45000081
	v_fma_mixlo_f16 v60, v75, s39, 0                           // 0000001CF350: CC21003C 02004F4B
	v_fma_mixhi_f16 v60, v76, s39, 0                           // 0000001CF358: CC22003C 02004F4C
	ds_load_b128 v[73:76], v129 offset:25840                   // 0000001CF360: DBFC64F0 49000081
	v_fma_mixlo_f16 v11, v89, s39, 0                           // 0000001CF368: CC21000B 02004F59
	v_fma_mixhi_f16 v11, v90, s39, 0                           // 0000001CF370: CC22000B 02004F5A
	v_fma_mixlo_f16 v12, v91, s39, 0                           // 0000001CF378: CC21000C 02004F5B
	v_fma_mixhi_f16 v12, v92, s39, 0                           // 0000001CF380: CC22000C 02004F5C
	v_fma_mixlo_f16 v13, v93, s39, 0                           // 0000001CF388: CC21000D 02004F5D
	v_fma_mixhi_f16 v13, v94, s39, 0                           // 0000001CF390: CC22000D 02004F5E
	v_fma_mixlo_f16 v14, v95, s39, 0                           // 0000001CF398: CC21000E 02004F5F
	v_fma_mixhi_f16 v14, v96, s39, 0                           // 0000001CF3A0: CC22000E 02004F60
	v_fma_mixlo_f16 v15, v33, s39, 0                           // 0000001CF3A8: CC21000F 02004F21
	v_fma_mixlo_f16 v33, v37, s39, 0                           // 0000001CF3B0: CC210021 02004F25
	v_fma_mixhi_f16 v33, v38, s39, 0                           // 0000001CF3B8: CC220021 02004F26
	v_fma_mixlo_f16 v37, v61, s39, 0                           // 0000001CF3C0: CC210025 02004F3D
	v_fma_mixhi_f16 v37, v62, s39, 0                           // 0000001CF3C8: CC220025 02004F3E
	v_fma_mixlo_f16 v38, v63, s39, 0                           // 0000001CF3D0: CC210026 02004F3F
	v_fma_mixhi_f16 v38, v64, s39, 0                           // 0000001CF3D8: CC220026 02004F40
	s_waitcnt lgkmcnt(5)                                       // 0000001CF3E0: BF89FC57
	v_fma_mixlo_f16 v61, v77, s39, 0                           // 0000001CF3E4: CC21003D 02004F4D
	v_fma_mixhi_f16 v61, v78, s39, 0                           // 0000001CF3EC: CC22003D 02004F4E
	v_fma_mixlo_f16 v62, v79, s39, 0                           // 0000001CF3F4: CC21003E 02004F4F
	v_fma_mixhi_f16 v62, v80, s39, 0                           // 0000001CF3FC: CC22003E 02004F50
	s_waitcnt lgkmcnt(4)                                       // 0000001CF404: BF89FC47
	v_fma_mixlo_f16 v63, v81, s39, 0                           // 0000001CF408: CC21003F 02004F51
	v_fma_mixhi_f16 v63, v82, s39, 0                           // 0000001CF410: CC22003F 02004F52
	v_fma_mixlo_f16 v64, v83, s39, 0                           // 0000001CF418: CC210040 02004F53
	v_fma_mixhi_f16 v64, v84, s39, 0                           // 0000001CF420: CC220040 02004F54
	s_waitcnt lgkmcnt(2)                                       // 0000001CF428: BF89FC27
	v_fma_mixlo_f16 v65, v65, s39, 0                           // 0000001CF42C: CC210041 02004F41
	v_fma_mixhi_f16 v65, v66, s39, 0                           // 0000001CF434: CC220041 02004F42
	v_fma_mixlo_f16 v66, v67, s39, 0                           // 0000001CF43C: CC210042 02004F43
	v_fma_mixhi_f16 v66, v68, s39, 0                           // 0000001CF444: CC220042 02004F44
	v_fma_mixlo_f16 v67, v85, s39, 0                           // 0000001CF44C: CC210043 02004F55
	v_fma_mixhi_f16 v67, v86, s39, 0                           // 0000001CF454: CC220043 02004F56
	v_fma_mixlo_f16 v68, v87, s39, 0                           // 0000001CF45C: CC210044 02004F57
	v_fma_mixhi_f16 v68, v88, s39, 0                           // 0000001CF464: CC220044 02004F58
	s_waitcnt lgkmcnt(1)                                       // 0000001CF46C: BF89FC17
	v_fma_mixlo_f16 v69, v69, s39, 0                           // 0000001CF470: CC210045 02004F45
	v_fma_mixhi_f16 v69, v70, s39, 0                           // 0000001CF478: CC220045 02004F46
	v_fma_mixlo_f16 v70, v71, s39, 0                           // 0000001CF480: CC210046 02004F47
	v_fma_mixhi_f16 v70, v72, s39, 0                           // 0000001CF488: CC220046 02004F48
	s_waitcnt lgkmcnt(0)                                       // 0000001CF490: BF89FC07
	v_fma_mixlo_f16 v71, v73, s39, 0                           // 0000001CF494: CC210047 02004F49
	v_fma_mixhi_f16 v71, v74, s39, 0                           // 0000001CF49C: CC220047 02004F4A
	v_fma_mixlo_f16 v72, v75, s39, 0                           // 0000001CF4A4: CC210048 02004F4B
	v_fma_mixhi_f16 v72, v76, s39, 0                           // 0000001CF4AC: CC220048 02004F4C
	s_waitcnt vmcnt(0)                                         // 0000001CF4B4: BF8903F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[1:8], v[9:16], v[41:48]// 0000001CF4B8: CC404029 1CA61301
	v_wmma_f32_16x16x16_f16 v[17:24], v[1:8], v[33:40], v[17:24]// 0000001CF4C0: CC404011 1C464301
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[57:64], v[49:56]// 0000001CF4C8: CC404031 1CC67301
	v_wmma_f32_16x16x16_f16 v[25:32], v[1:8], v[65:72], v[25:32]// 0000001CF4D0: CC404019 1C668301
	v_add_nc_u32_e32 v142, s42, v132                           // 0000001CF4D8: 4B1D082A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CF4DC: BF870001
	v_or_b32_e32 v1, 2, v142                                   // 0000001CF4E0: 38031C82
	v_or_b32_e32 v2, 4, v142                                   // 0000001CF4E4: 38051C84
	v_or_b32_e32 v5, 6, v142                                   // 0000001CF4E8: 380B1C86
	v_or_b32_e32 v7, 8, v142                                   // 0000001CF4EC: 380F1C88
	v_or_b32_e32 v8, 10, v142                                  // 0000001CF4F0: 38111C8A
	v_min_i32_e32 v1, s52, v1                                  // 0000001CF4F4: 22020234
	v_min_i32_e32 v6, s52, v2                                  // 0000001CF4F8: 220C0434
	v_min_i32_e32 v10, s52, v5                                 // 0000001CF4FC: 22140A34
	v_or_b32_e32 v9, 12, v142                                  // 0000001CF500: 38131C8C
	v_min_i32_e32 v11, s52, v7                                 // 0000001CF504: 22160E34
	v_mad_i64_i32 v[1:2], null, v1, 48, s[2:3]                 // 0000001CF508: D6FF7C01 00096101
	v_mad_i64_i32 v[5:6], null, v6, 48, s[2:3]                 // 0000001CF510: D6FF7C05 00096106
	v_min_i32_e32 v13, s52, v8                                 // 0000001CF518: 221A1034
	v_mad_i64_i32 v[7:8], null, v10, 48, s[2:3]                // 0000001CF51C: D6FF7C07 0009610A
	v_min_i32_e32 v14, s52, v9                                 // 0000001CF524: 221C1234
	v_mad_i64_i32 v[9:10], null, v11, 48, s[2:3]               // 0000001CF528: D6FF7C09 0009610B
	v_or_b32_e32 v33, 14, v142                                 // 0000001CF530: 38431C8E
	v_min_i32_e32 v3, s52, v142                                // 0000001CF534: 22071C34
	.long 0xd73c0001                                           // 0000001CF538: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001CF53C: 02020289
	.long 0xd73c0005                                           // 0000001CF540: D73C0005
	v_cndmask_b32_e32 v1, 9, v5, vcc_lo                        // 0000001CF544: 02020A89
	.long 0xd444000b                                           // 0000001CF548: D444000B
	v_cndmask_b32_e32 v1, s50, v142, vcc_lo                    // 0000001CF54C: 02031C32
	v_min_i32_e32 v33, s52, v33                                // 0000001CF550: 22424234
	v_mad_i64_i32 v[3:4], null, v3, 48, s[2:3]                 // 0000001CF554: D6FF7C03 00096103
	.long 0xd73c0009                                           // 0000001CF55C: D73C0009
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 0000001CF560: 02021289
	.long 0xd700000b                                           // 0000001CF564: D700000B
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001CF568: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001CF56C: BF8700D1
	v_add_co_ci_u32_e64 v12, null, v137, v2, s0                // 0000001CF570: D5207C0C 00020589
	.long 0xd73c0001                                           // 0000001CF578: D73C0001
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 0000001CF57C: 02020E89
	v_mad_i64_i32 v[7:8], null, v13, 48, s[2:3]                // 0000001CF580: D6FF7C07 0009610D
	v_mad_i64_i32 v[13:14], null, v14, 48, s[2:3]              // 0000001CF588: D6FF7C0D 0009610E
	.long 0xd7000005                                           // 0000001CF590: D7000005
	v_cndmask_b32_e32 v1, v136, v5, vcc_lo                     // 0000001CF594: 02020B88
	v_add_co_ci_u32_e64 v6, null, v137, v6, s0                 // 0000001CF598: D5207C06 00020D89
	.long 0xd700000f                                           // 0000001CF5A0: D700000F
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001CF5A4: 02020388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001CF5A8: BF8700B1
	v_add_co_ci_u32_e64 v16, null, v137, v2, s0                // 0000001CF5AC: D5207C10 00020589
	.long 0xd73c0001                                           // 0000001CF5B4: D73C0001
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 0000001CF5B8: 02020E89
	.long 0xd7000025                                           // 0000001CF5BC: D7000025
	v_cndmask_b32_e32 v1, v136, v9, vcc_lo                     // 0000001CF5C0: 02021388
	v_add_co_ci_u32_e64 v38, null, v137, v10, s0               // 0000001CF5C4: D5207C26 00021589
	.long 0xd73c0007                                           // 0000001CF5CC: D73C0007
	v_cndmask_b32_e32 v1, 9, v13, vcc_lo                       // 0000001CF5D0: 02021A89
	v_mad_i64_i32 v[9:10], null, v33, 48, s[2:3]               // 0000001CF5D4: D6FF7C09 00096121
	.long 0xd7000042                                           // 0000001CF5DC: D7000042
	v_cndmask_b32_e32 v1, v136, v1, vcc_lo                     // 0000001CF5E0: 02020388
	.long 0xd73c0003                                           // 0000001CF5E4: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001CF5E8: 02020689
	v_add_co_ci_u32_e64 v67, null, v137, v2, s0                // 0000001CF5EC: D5207C43 00020589
	.long 0xd7000044                                           // 0000001CF5F4: D7000044
	v_cndmask_b32_e32 v1, v136, v7, vcc_lo                     // 0000001CF5F8: 02020F88
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001CF5FC: BF8700B1
	v_add_co_ci_u32_e64 v69, null, v137, v8, s0                // 0000001CF600: D5207C45 00021189
	.long 0xd73c0007                                           // 0000001CF608: D73C0007
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 0000001CF60C: 02021289
	.long 0xd7000001                                           // 0000001CF610: D7000001
	v_cndmask_b32_e32 v1, v136, v3, vcc_lo                     // 0000001CF614: 02020788
	v_add_co_ci_u32_e64 v2, null, v137, v4, s0                 // 0000001CF618: D5207C02 00020989
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CF620: BF870093
	.long 0xd7000046                                           // 0000001CF624: D7000046
	v_cndmask_b32_e32 v1, v136, v7, vcc_lo                     // 0000001CF628: 02020F88
	v_add_co_ci_u32_e64 v71, null, v137, v8, s0                // 0000001CF62C: D5207C47 00021189
	s_clause 0x1e                                              // 0000001CF634: BF85001E
	global_load_b32 v62, v[11:12], off                         // 0000001CF638: DC520000 3E7C000B
	global_load_b32 v59, v[5:6], off                           // 0000001CF640: DC520000 3B7C0005
	global_load_b32 v39, v[1:2], off offset:64                 // 0000001CF648: DC520040 277C0001
	global_load_b32 v40, v[11:12], off offset:64               // 0000001CF650: DC520040 287C000B
	global_load_b32 v34, v[1:2], off offset:128                // 0000001CF658: DC520080 227C0001
	global_load_b32 v14, v[11:12], off offset:128              // 0000001CF660: DC520080 0E7C000B
	global_load_b32 v8, v[11:12], off offset:192               // 0000001CF668: DC5200C0 087C000B
	global_load_b32 v9, v[1:2], off offset:192                 // 0000001CF670: DC5200C0 097C0001
	global_load_b32 v65, v[15:16], off                         // 0000001CF678: DC520000 417C000F
	global_load_b32 v64, v[37:38], off                         // 0000001CF680: DC520000 407C0025
	global_load_b32 v58, v[5:6], off offset:64                 // 0000001CF688: DC520040 3A7C0005
	global_load_b32 v57, v[15:16], off offset:64               // 0000001CF690: DC520040 397C000F
	global_load_b32 v33, v[5:6], off offset:128                // 0000001CF698: DC520080 217C0005
	global_load_b32 v11, v[15:16], off offset:128              // 0000001CF6A0: DC520080 0B7C000F
	global_load_b32 v3, v[15:16], off offset:192               // 0000001CF6A8: DC5200C0 037C000F
	global_load_b32 v10, v[5:6], off offset:192                // 0000001CF6B0: DC5200C0 0A7C0005
	global_load_b32 v63, v[66:67], off                         // 0000001CF6B8: DC520000 3F7C0042
	global_load_b32 v60, v[68:69], off                         // 0000001CF6C0: DC520000 3C7C0044
	global_load_b32 v35, v[37:38], off offset:64               // 0000001CF6C8: DC520040 237C0025
	global_load_b32 v36, v[66:67], off offset:64               // 0000001CF6D0: DC520040 247C0042
	global_load_b32 v15, v[37:38], off offset:128              // 0000001CF6D8: DC520080 0F7C0025
	global_load_b32 v16, v[66:67], off offset:128              // 0000001CF6E0: DC520080 107C0042
	global_load_b32 v4, v[66:67], off offset:192               // 0000001CF6E8: DC5200C0 047C0042
	global_load_b32 v5, v[37:38], off offset:192               // 0000001CF6F0: DC5200C0 057C0025
	global_load_b32 v61, v[70:71], off                         // 0000001CF6F8: DC520000 3D7C0046
	global_load_b32 v37, v[68:69], off offset:64               // 0000001CF700: DC520040 257C0044
	global_load_b32 v38, v[70:71], off offset:64               // 0000001CF708: DC520040 267C0046
	global_load_b32 v12, v[68:69], off offset:128              // 0000001CF710: DC520080 0C7C0044
	global_load_b32 v13, v[70:71], off offset:128              // 0000001CF718: DC520080 0D7C0046
	global_load_b32 v6, v[70:71], off offset:192               // 0000001CF720: DC5200C0 067C0046
	global_load_b32 v7, v[68:69], off offset:192               // 0000001CF728: DC5200C0 077C0044
	s_and_saveexec_b32 s0, s11                                 // 0000001CF730: BE80200B
	s_cbranch_execz 8                                          // 0000001CF734: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3558>
	global_load_b32 v1, v[1:2], off                            // 0000001CF738: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001CF740: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v41                         // 0000001CF744: 560252FF BB800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CF74C: BF870001
	v_fma_mixlo_f16 v97, v1, s39, 0                            // 0000001CF750: CC210061 02004F01
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CF758: 8C7E007E
	s_waitcnt vmcnt(21)                                        // 0000001CF75C: BF8957F7
	v_dual_fmac_f32 v64, 0xbb800000, v45 :: v_dual_add_nc_u32 v149, 2, v142// 0000001CF760: C8205AFF 40951C82 BB800000
	v_dual_fmac_f32 v62, 0xbb800000, v42 :: v_dual_fmac_f32 v59, 0xbb800000, v43// 0000001CF76C: C80054FF 3E3A56FF BB800000
	v_dual_fmac_f32 v65, 0xbb800000, v44 :: v_dual_add_nc_u32 v148, 4, v142// 0000001CF778: C82058FF 41951C84 BB800000
	s_waitcnt vmcnt(13)                                        // 0000001CF784: BF8937F7
	v_dual_fmac_f32 v60, 0xbb800000, v47 :: v_dual_add_nc_u32 v147, 6, v142// 0000001CF788: C8205EFF 3C931C86 BB800000
	s_waitcnt vmcnt(6)                                         // 0000001CF794: BF891BF7
	v_dual_fmac_f32 v61, 0xbb800000, v48 :: v_dual_add_nc_u32 v146, 8, v142// 0000001CF798: C82060FF 3D931C88 BB800000
	v_dual_fmac_f32 v58, 0xbb800000, v19 :: v_dual_add_nc_u32 v145, 10, v142// 0000001CF7A4: C82026FF 3A911C8A BB800000
	s_waitcnt vmcnt(4)                                         // 0000001CF7B0: BF8913F7
	v_dual_fmac_f32 v63, 0xbb800000, v46 :: v_dual_fmac_f32 v38, 0xbb800000, v24// 0000001CF7B4: C8005CFF 3F2630FF BB800000
	v_dual_fmac_f32 v39, 0xbb800000, v17 :: v_dual_add_nc_u32 v144, 12, v142// 0000001CF7C0: C82022FF 27911C8C BB800000
	v_dual_fmac_f32 v34, 0xbb800000, v49 :: v_dual_add_nc_u32 v143, 14, v142// 0000001CF7CC: C82062FF 228F1C8E BB800000
	.long 0xd444000d                                           // 0000001CF7D8: D444000D
	v_cndmask_b32_e32 v1, s50, v149, vcc_lo                    // 0000001CF7DC: 02032A32
	v_fma_mixlo_f16 v1, v62, s39, 0                            // 0000001CF7E0: CC210001 02004F3E
	.long 0xd444000c                                           // 0000001CF7E8: D444000C
	v_cndmask_b32_e32 v1, s50, v148, vcc_lo                    // 0000001CF7EC: 02032832
	v_fma_mixhi_f16 v1, v59, s39, 0                            // 0000001CF7F0: CC220001 02004F3B
	v_dual_fmac_f32 v40, 0xbb800000, v18 :: v_dual_fmac_f32 v57, 0xbb800000, v20// 0000001CF7F8: C80024FF 283828FF BB800000
	.long 0xd444000a                                           // 0000001CF804: D444000A
	v_cndmask_b32_e32 v1, s50, v147, vcc_lo                    // 0000001CF808: 02032632
	v_fma_mixlo_f16 v2, v65, s39, 0                            // 0000001CF80C: CC210002 02004F41
	.long 0xd4440009                                           // 0000001CF814: D4440009
	v_cndmask_b32_e32 v1, s50, v146, vcc_lo                    // 0000001CF818: 02032432
	v_fma_mixhi_f16 v2, v64, s39, 0                            // 0000001CF81C: CC220002 02004F40
	.long 0xd4440001                                           // 0000001CF824: D4440001
	v_cndmask_b32_e32 v1, s50, v145, vcc_lo                    // 0000001CF828: 02032232
	v_fma_mixlo_f16 v41, v63, s39, 0                           // 0000001CF82C: CC210029 02004F3F
	.long 0xd4440008                                           // 0000001CF834: D4440008
	v_cndmask_b32_e32 v1, s50, v144, vcc_lo                    // 0000001CF838: 02032032
	v_fma_mixhi_f16 v41, v60, s39, 0                           // 0000001CF83C: CC220029 02004F3C
	.long 0xd4440000                                           // 0000001CF844: D4440000
	v_cndmask_b32_e32 v1, s50, v143, vcc_lo                    // 0000001CF848: 02031E32
	v_fma_mixlo_f16 v42, v61, s39, 0                           // 0000001CF84C: CC21002A 02004F3D
	v_cndmask_b16 v1, 0, v1, s13                               // 0000001CF854: D65D0001 00360280
	v_dual_fmac_f32 v35, 0xbb800000, v21 :: v_dual_fmac_f32 v36, 0xbb800000, v22// 0000001CF85C: C8002AFF 23242CFF BB800000
	v_cndmask_b16 v1, 0, v1, s12                               // 0000001CF868: D65D5001 00320280
	v_fma_mixlo_f16 v18, v39, s39, 0                           // 0000001CF870: CC210012 02004F27
	v_fma_mixhi_f16 v18, v40, s39, 0                           // 0000001CF878: CC220012 02004F28
	v_dual_fmac_f32 v37, 0xbb800000, v23 :: v_dual_fmac_f32 v14, 0xbb800000, v50// 0000001CF880: C8002EFF 250E64FF BB800000
	v_cndmask_b16 v2, 0, v2, s10                               // 0000001CF88C: D65D0002 002A0480
	v_cndmask_b16 v2, 0, v2, s9                                // 0000001CF894: D65D5002 00260480
	v_fma_mixlo_f16 v19, v58, s39, 0                           // 0000001CF89C: CC210013 02004F3A
	v_cndmask_b16 v41, 0, v41, s1                              // 0000001CF8A4: D65D0029 00065280
	v_cndmask_b16 v17, 0, v41, s8                              // 0000001CF8AC: D65D1011 00225280
	v_cndmask_b16 v17, 0, v42, s0                              // 0000001CF8B4: D65D4011 00025480
	ds_store_b16 v138, v97                                     // 0000001CF8BC: D87C0000 0000618A
	ds_store_b16 v138, v1 offset:4                             // 0000001CF8C4: D87C0004 0000018A
	ds_store_b16_d16_hi v138, v1 offset:8                      // 0000001CF8CC: DA840008 0000018A
	ds_store_b16 v138, v2 offset:12                            // 0000001CF8D4: D87C000C 0000028A
	ds_store_b16_d16_hi v138, v2 offset:16                     // 0000001CF8DC: DA840010 0000028A
	ds_store_b16 v138, v41 offset:20                           // 0000001CF8E4: D87C0014 0000298A
	ds_store_b16 v138, v17 offset:24                           // 0000001CF8EC: D87C0018 0000118A
	ds_store_b16_d16_hi v138, v17 offset:28                    // 0000001CF8F4: DA84001C 0000118A
	v_fma_mixhi_f16 v2, v57, s39, 0                            // 0000001CF8FC: CC220002 02004F39
	v_fma_mixlo_f16 v17, v35, s39, 0                           // 0000001CF904: CC210011 02004F23
	v_cndmask_b16 v1, 0, v18, s11                              // 0000001CF90C: D65D0001 002E2480
	v_cndmask_b16 v1, 0, v18, s13                              // 0000001CF914: D65D5001 00362480
	v_fma_mixhi_f16 v17, v36, s39, 0                           // 0000001CF91C: CC220011 02004F24
	v_fma_mixlo_f16 v18, v37, s39, 0                           // 0000001CF924: CC210012 02004F25
	v_fma_mixhi_f16 v18, v38, s39, 0                           // 0000001CF92C: CC220012 02004F26
	v_dual_fmac_f32 v33, 0xbb800000, v51 :: v_dual_fmac_f32 v16, 0xbb800000, v54// 0000001CF934: C80066FF 21106CFF BB800000
	v_cndmask_b16 v2, 0, v19, s12                              // 0000001CF940: D65D0002 00322680
	s_waitcnt vmcnt(3)                                         // 0000001CF948: BF890FF7
	v_dual_fmac_f32 v11, 0xbb800000, v52 :: v_dual_fmac_f32 v12, 0xbb800000, v55// 0000001CF94C: C80068FF 0B0C6EFF BB800000
	v_cndmask_b16 v2, 0, v2, s10                               // 0000001CF958: D65D5002 002A0480
	v_dual_fmac_f32 v15, 0xbb800000, v53 :: v_dual_fmac_f32 v8, 0xbb800000, v26// 0000001CF960: C8006AFF 0F0834FF BB800000
	v_cndmask_b16 v17, 0, v17, s9                              // 0000001CF96C: D65D0011 00262280
	v_fma_mixlo_f16 v19, v34, s39, 0                           // 0000001CF974: CC210013 02004F22
	s_waitcnt vmcnt(2)                                         // 0000001CF97C: BF890BF7
	v_dual_fmac_f32 v13, 0xbb800000, v56 :: v_dual_fmac_f32 v10, 0xbb800000, v27// 0000001CF980: C80070FF 0D0A36FF BB800000
	v_cndmask_b16 v17, 0, v17, s1                              // 0000001CF98C: D65D5011 00062280
	v_cndmask_b16 v18, 0, v18, s8                              // 0000001CF994: D65D0012 00222480
	v_cndmask_b16 v18, 0, v18, s0                              // 0000001CF99C: D65D5012 00022480
	ds_store_b16 v138, v1 offset:2304                          // 0000001CF9A4: D87C0900 0000018A
	ds_store_b16_d16_hi v138, v1 offset:2308                   // 0000001CF9AC: DA840904 0000018A
	ds_store_b16 v138, v2 offset:2312                          // 0000001CF9B4: D87C0908 0000028A
	ds_store_b16_d16_hi v138, v2 offset:2316                   // 0000001CF9BC: DA84090C 0000028A
	ds_store_b16 v138, v17 offset:2320                         // 0000001CF9C4: D87C0910 0000118A
	ds_store_b16_d16_hi v138, v17 offset:2324                  // 0000001CF9CC: DA840914 0000118A
	ds_store_b16 v138, v18 offset:2328                         // 0000001CF9D4: D87C0918 0000128A
	ds_store_b16_d16_hi v138, v18 offset:2332                  // 0000001CF9DC: DA84091C 0000128A
	v_fma_mixhi_f16 v1, v14, s39, 0                            // 0000001CF9E4: CC220001 02004F0E
	v_fma_mixlo_f16 v2, v33, s39, 0                            // 0000001CF9EC: CC210002 02004F21
	v_dual_fmac_f32 v9, 0xbb800000, v25 :: v_dual_fmac_f32 v4, 0xbb800000, v30// 0000001CF9F4: C80032FF 09043CFF BB800000
	v_fma_mixhi_f16 v2, v11, s39, 0                            // 0000001CFA00: CC220002 02004F0B
	v_fma_mixlo_f16 v11, v15, s39, 0                           // 0000001CFA08: CC21000B 02004F0F
	v_cndmask_b16 v1, 0, v19, s11                              // 0000001CFA10: D65D0001 002E2680
	v_fma_mixhi_f16 v11, v16, s39, 0                           // 0000001CFA18: CC22000B 02004F10
	v_fma_mixlo_f16 v12, v12, s39, 0                           // 0000001CFA20: CC21000C 02004F0C
	v_fma_mixhi_f16 v12, v13, s39, 0                           // 0000001CFA28: CC22000C 02004F0D
	v_fmac_f32_e32 v3, 0xbb800000, v28                         // 0000001CFA30: 560638FF BB800000
	v_cndmask_b16 v1, 0, v1, s13                               // 0000001CFA38: D65D5001 00360280
	s_waitcnt vmcnt(1)                                         // 0000001CFA40: BF8907F7
	v_dual_fmac_f32 v5, 0xbb800000, v29 :: v_dual_fmac_f32 v6, 0xbb800000, v32// 0000001CFA44: C8003AFF 050640FF BB800000
	v_cndmask_b16 v2, 0, v2, s12                               // 0000001CFA50: D65D0002 00320480
	v_fma_mixlo_f16 v9, v9, s39, 0                             // 0000001CFA58: CC210009 02004F09
	s_waitcnt vmcnt(0)                                         // 0000001CFA60: BF8903F7
	v_fmac_f32_e32 v7, 0xbb800000, v31                         // 0000001CFA64: 560E3EFF BB800000
	v_cndmask_b16 v2, 0, v2, s10                               // 0000001CFA6C: D65D5002 002A0480
	v_fma_mixlo_f16 v8, v8, s39, 0                             // 0000001CFA74: CC210008 02004F08
	v_cndmask_b16 v11, 0, v11, s9                              // 0000001CFA7C: D65D000B 00261680
	v_fma_mixhi_f16 v8, v10, s39, 0                            // 0000001CFA84: CC220008 02004F0A
	v_cndmask_b16 v11, 0, v11, s1                              // 0000001CFA8C: D65D500B 00061680
	v_cndmask_b16 v12, 0, v12, s8                              // 0000001CFA94: D65D000C 00221880
	v_cndmask_b16 v12, 0, v12, s0                              // 0000001CFA9C: D65D500C 00021880
	ds_store_b16 v138, v1 offset:4608                          // 0000001CFAA4: D87C1200 0000018A
	ds_store_b16_d16_hi v138, v1 offset:4612                   // 0000001CFAAC: DA841204 0000018A
	ds_store_b16 v138, v2 offset:4616                          // 0000001CFAB4: D87C1208 0000028A
	ds_store_b16_d16_hi v138, v2 offset:4620                   // 0000001CFABC: DA84120C 0000028A
	ds_store_b16 v138, v11 offset:4624                         // 0000001CFAC4: D87C1210 00000B8A
	ds_store_b16_d16_hi v138, v11 offset:4628                  // 0000001CFACC: DA841214 00000B8A
	ds_store_b16 v138, v12 offset:4632                         // 0000001CFAD4: D87C1218 00000C8A
	ds_store_b16_d16_hi v138, v12 offset:4636                  // 0000001CFADC: DA84121C 00000C8A
	v_fma_mixhi_f16 v2, v3, s39, 0                             // 0000001CFAE4: CC220002 02004F03
	v_fma_mixlo_f16 v3, v5, s39, 0                             // 0000001CFAEC: CC210003 02004F05
	v_cndmask_b16 v1, 0, v9, s11                               // 0000001CFAF4: D65D0001 002E1280
	v_fma_mixhi_f16 v3, v4, s39, 0                             // 0000001CFAFC: CC220003 02004F04
	v_fma_mixlo_f16 v4, v7, s39, 0                             // 0000001CFB04: CC210004 02004F07
	v_fma_mixhi_f16 v4, v6, s39, 0                             // 0000001CFB0C: CC220004 02004F06
	v_cndmask_b16 v1, 0, v8, s13                               // 0000001CFB14: D65D4001 00361080
	v_cndmask_b16 v2, 0, v8, s12                               // 0000001CFB1C: D65D1002 00321080
	v_cndmask_b16 v2, 0, v2, s10                               // 0000001CFB24: D65D5002 002A0480
	v_cndmask_b16 v3, 0, v3, s9                                // 0000001CFB2C: D65D0003 00260680
	v_cndmask_b16 v3, 0, v3, s1                                // 0000001CFB34: D65D5003 00060680
	v_cndmask_b16 v4, 0, v4, s8                                // 0000001CFB3C: D65D0004 00220880
	v_cndmask_b16 v4, 0, v4, s0                                // 0000001CFB44: D65D5004 00020880
	ds_store_b16 v138, v1 offset:6912                          // 0000001CFB4C: D87C1B00 0000018A
	ds_store_b16_d16_hi v138, v1 offset:6916                   // 0000001CFB54: DA841B04 0000018A
	ds_store_b16 v138, v2 offset:6920                          // 0000001CFB5C: D87C1B08 0000028A
	ds_store_b16_d16_hi v138, v2 offset:6924                   // 0000001CFB64: DA841B0C 0000028A
	ds_store_b16 v138, v3 offset:6928                          // 0000001CFB6C: D87C1B10 0000038A
	ds_store_b16_d16_hi v138, v3 offset:6932                   // 0000001CFB74: DA841B14 0000038A
	ds_store_b16 v138, v4 offset:6936                          // 0000001CFB7C: D87C1B18 0000048A
	ds_store_b16_d16_hi v138, v4 offset:6940                   // 0000001CFB84: DA841B1C 0000048A
	.long 0xd7000e01                                           // 0000001CFB8C: D7000E01
	v_cndmask_b32_e32 v1, s44, v98, vcc_lo                     // 0000001CFB90: 0202C42C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CFB94: BF870001
	v_add_co_ci_u32_e64 v2, null, s45, v99, s14                // 0000001CFB98: D5207C02 003AC62D
	s_waitcnt lgkmcnt(0)                                       // 0000001CFBA0: BF89FC07
	s_barrier                                                  // 0000001CFBA4: BFBD0000
	buffer_gl0_inv                                             // 0000001CFBA8: E0AC0000 00000000
	s_clause 0xf                                               // 0000001CFBB0: BF85000F
	global_load_b128 v[97:100], v[1:2], off                    // 0000001CFBB4: DC5E0000 617C0001
	global_load_b128 v[101:104], v[1:2], off offset:16         // 0000001CFBBC: DC5E0010 657C0001
	global_load_b128 v[89:92], v[1:2], off offset:32           // 0000001CFBC4: DC5E0020 597C0001
	global_load_b128 v[93:96], v[1:2], off offset:48           // 0000001CFBCC: DC5E0030 5D7C0001
	global_load_b128 v[81:84], v[1:2], off offset:64           // 0000001CFBD4: DC5E0040 517C0001
	global_load_b128 v[85:88], v[1:2], off offset:80           // 0000001CFBDC: DC5E0050 557C0001
	global_load_b128 v[73:76], v[1:2], off offset:96           // 0000001CFBE4: DC5E0060 497C0001
	global_load_b128 v[77:80], v[1:2], off offset:112          // 0000001CFBEC: DC5E0070 4D7C0001
	global_load_b128 v[57:60], v[1:2], off offset:128          // 0000001CFBF4: DC5E0080 397C0001
	global_load_b128 v[61:64], v[1:2], off offset:144          // 0000001CFBFC: DC5E0090 3D7C0001
	global_load_b128 v[49:52], v[1:2], off offset:160          // 0000001CFC04: DC5E00A0 317C0001
	global_load_b128 v[53:56], v[1:2], off offset:176          // 0000001CFC0C: DC5E00B0 357C0001
	global_load_b128 v[41:44], v[1:2], off offset:192          // 0000001CFC14: DC5E00C0 297C0001
	global_load_b128 v[45:48], v[1:2], off offset:208          // 0000001CFC1C: DC5E00D0 2D7C0001
	global_load_b128 v[33:36], v[1:2], off offset:224          // 0000001CFC24: DC5E00E0 217C0001
	global_load_b128 v[37:40], v[1:2], off offset:240          // 0000001CFC2C: DC5E00F0 257C0001
	s_and_saveexec_b32 s14, vcc_lo                             // 0000001CFC34: BE8E206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001CFC38: BF870009
	s_xor_b32 s14, exec_lo, s14                                // 0000001CFC3C: 8D0E0E7E
	s_cbranch_execz 81                                         // 0000001CFC40: BFA50051 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3b88>
	s_waitcnt vmcnt(15)                                        // 0000001CFC44: BF893FF7
	v_mov_b32_e32 v97, 0                                       // 0000001CFC48: 7EC20280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CFC4C: BF870001
	v_mov_b32_e32 v98, v97                                     // 0000001CFC50: 7EC40361
	v_mov_b32_e32 v99, v97                                     // 0000001CFC54: 7EC60361
	v_mov_b32_e32 v100, v97                                    // 0000001CFC58: 7EC80361
	s_waitcnt vmcnt(14)                                        // 0000001CFC5C: BF893BF7
	v_mov_b32_e32 v101, v97                                    // 0000001CFC60: 7ECA0361
	v_mov_b32_e32 v102, v97                                    // 0000001CFC64: 7ECC0361
	v_mov_b32_e32 v103, v97                                    // 0000001CFC68: 7ECE0361
	v_mov_b32_e32 v104, v97                                    // 0000001CFC6C: 7ED00361
	s_waitcnt vmcnt(13)                                        // 0000001CFC70: BF8937F7
	v_mov_b32_e32 v89, v97                                     // 0000001CFC74: 7EB20361
	v_mov_b32_e32 v90, v97                                     // 0000001CFC78: 7EB40361
	v_mov_b32_e32 v91, v97                                     // 0000001CFC7C: 7EB60361
	v_mov_b32_e32 v92, v97                                     // 0000001CFC80: 7EB80361
	s_waitcnt vmcnt(12)                                        // 0000001CFC84: BF8933F7
	v_mov_b32_e32 v93, v97                                     // 0000001CFC88: 7EBA0361
	v_mov_b32_e32 v94, v97                                     // 0000001CFC8C: 7EBC0361
	v_mov_b32_e32 v95, v97                                     // 0000001CFC90: 7EBE0361
	v_mov_b32_e32 v96, v97                                     // 0000001CFC94: 7EC00361
	s_waitcnt vmcnt(11)                                        // 0000001CFC98: BF892FF7
	v_mov_b32_e32 v81, v97                                     // 0000001CFC9C: 7EA20361
	v_mov_b32_e32 v82, v97                                     // 0000001CFCA0: 7EA40361
	v_mov_b32_e32 v83, v97                                     // 0000001CFCA4: 7EA60361
	v_mov_b32_e32 v84, v97                                     // 0000001CFCA8: 7EA80361
	s_waitcnt vmcnt(10)                                        // 0000001CFCAC: BF892BF7
	v_mov_b32_e32 v85, v97                                     // 0000001CFCB0: 7EAA0361
	v_mov_b32_e32 v86, v97                                     // 0000001CFCB4: 7EAC0361
	v_mov_b32_e32 v87, v97                                     // 0000001CFCB8: 7EAE0361
	v_mov_b32_e32 v88, v97                                     // 0000001CFCBC: 7EB00361
	s_waitcnt vmcnt(9)                                         // 0000001CFCC0: BF8927F7
	v_mov_b32_e32 v73, v97                                     // 0000001CFCC4: 7E920361
	v_mov_b32_e32 v74, v97                                     // 0000001CFCC8: 7E940361
	v_mov_b32_e32 v75, v97                                     // 0000001CFCCC: 7E960361
	v_mov_b32_e32 v76, v97                                     // 0000001CFCD0: 7E980361
	s_waitcnt vmcnt(8)                                         // 0000001CFCD4: BF8923F7
	v_mov_b32_e32 v77, v97                                     // 0000001CFCD8: 7E9A0361
	v_mov_b32_e32 v78, v97                                     // 0000001CFCDC: 7E9C0361
	v_mov_b32_e32 v79, v97                                     // 0000001CFCE0: 7E9E0361
	v_mov_b32_e32 v80, v97                                     // 0000001CFCE4: 7EA00361
	s_waitcnt vmcnt(7)                                         // 0000001CFCE8: BF891FF7
	v_mov_b32_e32 v57, v97                                     // 0000001CFCEC: 7E720361
	v_mov_b32_e32 v58, v97                                     // 0000001CFCF0: 7E740361
	v_mov_b32_e32 v59, v97                                     // 0000001CFCF4: 7E760361
	v_mov_b32_e32 v60, v97                                     // 0000001CFCF8: 7E780361
	s_waitcnt vmcnt(6)                                         // 0000001CFCFC: BF891BF7
	v_mov_b32_e32 v61, v97                                     // 0000001CFD00: 7E7A0361
	v_mov_b32_e32 v62, v97                                     // 0000001CFD04: 7E7C0361
	v_mov_b32_e32 v63, v97                                     // 0000001CFD08: 7E7E0361
	v_mov_b32_e32 v64, v97                                     // 0000001CFD0C: 7E800361
	s_waitcnt vmcnt(5)                                         // 0000001CFD10: BF8917F7
	v_mov_b32_e32 v49, v97                                     // 0000001CFD14: 7E620361
	v_mov_b32_e32 v50, v97                                     // 0000001CFD18: 7E640361
	v_mov_b32_e32 v51, v97                                     // 0000001CFD1C: 7E660361
	v_mov_b32_e32 v52, v97                                     // 0000001CFD20: 7E680361
	s_waitcnt vmcnt(4)                                         // 0000001CFD24: BF8913F7
	v_mov_b32_e32 v53, v97                                     // 0000001CFD28: 7E6A0361
	v_mov_b32_e32 v54, v97                                     // 0000001CFD2C: 7E6C0361
	v_mov_b32_e32 v55, v97                                     // 0000001CFD30: 7E6E0361
	v_mov_b32_e32 v56, v97                                     // 0000001CFD34: 7E700361
	s_waitcnt vmcnt(3)                                         // 0000001CFD38: BF890FF7
	v_mov_b32_e32 v41, v97                                     // 0000001CFD3C: 7E520361
	v_mov_b32_e32 v42, v97                                     // 0000001CFD40: 7E540361
	v_mov_b32_e32 v43, v97                                     // 0000001CFD44: 7E560361
	v_mov_b32_e32 v44, v97                                     // 0000001CFD48: 7E580361
	s_waitcnt vmcnt(2)                                         // 0000001CFD4C: BF890BF7
	v_mov_b32_e32 v45, v97                                     // 0000001CFD50: 7E5A0361
	v_mov_b32_e32 v46, v97                                     // 0000001CFD54: 7E5C0361
	v_mov_b32_e32 v47, v97                                     // 0000001CFD58: 7E5E0361
	v_mov_b32_e32 v48, v97                                     // 0000001CFD5C: 7E600361
	s_waitcnt vmcnt(1)                                         // 0000001CFD60: BF8907F7
	v_mov_b32_e32 v33, v97                                     // 0000001CFD64: 7E420361
	v_mov_b32_e32 v34, v97                                     // 0000001CFD68: 7E440361
	v_mov_b32_e32 v35, v97                                     // 0000001CFD6C: 7E460361
	v_mov_b32_e32 v36, v97                                     // 0000001CFD70: 7E480361
	s_waitcnt vmcnt(0)                                         // 0000001CFD74: BF8903F7
	v_mov_b32_e32 v37, v97                                     // 0000001CFD78: 7E4A0361
	v_mov_b32_e32 v38, v97                                     // 0000001CFD7C: 7E4C0361
	v_mov_b32_e32 v39, v97                                     // 0000001CFD80: 7E4E0361
	v_mov_b32_e32 v40, v97                                     // 0000001CFD84: 7E500361
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001CFD88: 8C7E0E7E
	ds_load_b128 v[1:4], v129                                  // 0000001CFD8C: DBFC0000 01000081
	ds_load_b128 v[5:8], v129 offset:16                        // 0000001CFD94: DBFC0010 05000081
	ds_load_b128 v[9:12], v129 offset:32                       // 0000001CFD9C: DBFC0020 09000081
	ds_load_b128 v[13:16], v129 offset:48                      // 0000001CFDA4: DBFC0030 0D000081
	ds_load_b128 v[17:20], v129 offset:8448                    // 0000001CFDAC: DBFC2100 11000081
	ds_load_b128 v[21:24], v129 offset:8464                    // 0000001CFDB4: DBFC2110 15000081
	ds_load_b128 v[25:28], v129 offset:8480                    // 0000001CFDBC: DBFC2120 19000081
	ds_load_b128 v[29:32], v129 offset:8496                    // 0000001CFDC4: DBFC2130 1D000081
	ds_load_b128 v[150:153], v129 offset:16896                 // 0000001CFDCC: DBFC4200 96000081
	ds_load_b128 v[154:157], v129 offset:16912                 // 0000001CFDD4: DBFC4210 9A000081
	ds_load_b128 v[158:161], v129 offset:16928                 // 0000001CFDDC: DBFC4220 9E000081
	ds_load_b128 v[162:165], v129 offset:16944                 // 0000001CFDE4: DBFC4230 A2000081
	ds_load_b128 v[166:169], v129 offset:25376                 // 0000001CFDEC: DBFC6320 A6000081
	v_dual_mov_b32 v72, s27 :: v_dual_mov_b32 v71, s26         // 0000001CFDF4: CA10001B 4846001A
	v_dual_mov_b32 v70, s25 :: v_dual_mov_b32 v69, s24         // 0000001CFDFC: CA100019 46440018
	v_dual_mov_b32 v68, s23 :: v_dual_mov_b32 v67, s22         // 0000001CFE04: CA100017 44420016
	v_dual_mov_b32 v66, s21 :: v_dual_mov_b32 v65, s20         // 0000001CFE0C: CA100015 42400014
	s_waitcnt lgkmcnt(12)                                      // 0000001CFE14: BF89FCC7
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001CFE18: CC210001 02004F01
	v_fma_mixhi_f16 v1, v2, s39, 0                             // 0000001CFE20: CC220001 02004F02
	v_fma_mixlo_f16 v2, v3, s39, 0                             // 0000001CFE28: CC210002 02004F03
	v_fma_mixhi_f16 v2, v4, s39, 0                             // 0000001CFE30: CC220002 02004F04
	s_waitcnt lgkmcnt(11)                                      // 0000001CFE38: BF89FCB7
	v_fma_mixlo_f16 v3, v5, s39, 0                             // 0000001CFE3C: CC210003 02004F05
	v_fma_mixhi_f16 v3, v6, s39, 0                             // 0000001CFE44: CC220003 02004F06
	v_fma_mixlo_f16 v4, v7, s39, 0                             // 0000001CFE4C: CC210004 02004F07
	v_fma_mixhi_f16 v4, v8, s39, 0                             // 0000001CFE54: CC220004 02004F08
	s_waitcnt lgkmcnt(10)                                      // 0000001CFE5C: BF89FCA7
	v_fma_mixlo_f16 v5, v9, s39, 0                             // 0000001CFE60: CC210005 02004F09
	v_fma_mixhi_f16 v5, v10, s39, 0                            // 0000001CFE68: CC220005 02004F0A
	v_fma_mixlo_f16 v6, v11, s39, 0                            // 0000001CFE70: CC210006 02004F0B
	v_fma_mixhi_f16 v6, v12, s39, 0                            // 0000001CFE78: CC220006 02004F0C
	s_waitcnt lgkmcnt(9)                                       // 0000001CFE80: BF89FC97
	v_fma_mixlo_f16 v7, v13, s39, 0                            // 0000001CFE84: CC210007 02004F0D
	v_fma_mixhi_f16 v7, v14, s39, 0                            // 0000001CFE8C: CC220007 02004F0E
	v_fma_mixlo_f16 v8, v15, s39, 0                            // 0000001CFE94: CC210008 02004F0F
	v_fma_mixhi_f16 v8, v16, s39, 0                            // 0000001CFE9C: CC220008 02004F10
	s_waitcnt lgkmcnt(8)                                       // 0000001CFEA4: BF89FC87
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001CFEA8: CC210011 02004F11
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001CFEB0: CC220011 02004F12
	v_fma_mixlo_f16 v18, v19, s39, 0                           // 0000001CFEB8: CC210012 02004F13
	v_fma_mixhi_f16 v18, v20, s39, 0                           // 0000001CFEC0: CC220012 02004F14
	s_waitcnt lgkmcnt(7)                                       // 0000001CFEC8: BF89FC77
	v_fma_mixlo_f16 v19, v21, s39, 0                           // 0000001CFECC: CC210013 02004F15
	v_fma_mixhi_f16 v19, v22, s39, 0                           // 0000001CFED4: CC220013 02004F16
	v_fma_mixlo_f16 v20, v23, s39, 0                           // 0000001CFEDC: CC210014 02004F17
	v_fma_mixhi_f16 v20, v24, s39, 0                           // 0000001CFEE4: CC220014 02004F18
	s_waitcnt lgkmcnt(6)                                       // 0000001CFEEC: BF89FC67
	v_fma_mixlo_f16 v21, v25, s39, 0                           // 0000001CFEF0: CC210015 02004F19
	v_fma_mixhi_f16 v21, v26, s39, 0                           // 0000001CFEF8: CC220015 02004F1A
	v_fma_mixlo_f16 v22, v27, s39, 0                           // 0000001CFF00: CC210016 02004F1B
	v_fma_mixhi_f16 v22, v28, s39, 0                           // 0000001CFF08: CC220016 02004F1C
	s_waitcnt lgkmcnt(5)                                       // 0000001CFF10: BF89FC57
	v_fma_mixlo_f16 v23, v29, s39, 0                           // 0000001CFF14: CC210017 02004F1D
	v_fma_mixhi_f16 v23, v30, s39, 0                           // 0000001CFF1C: CC220017 02004F1E
	v_fma_mixlo_f16 v24, v31, s39, 0                           // 0000001CFF24: CC210018 02004F1F
	v_fma_mixhi_f16 v24, v32, s39, 0                           // 0000001CFF2C: CC220018 02004F20
	s_waitcnt vmcnt(14)                                        // 0000001CFF34: BF893BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[97:104], v[1:8], v[65:72]// 0000001CFF38: CC404019 1D060361
	s_waitcnt lgkmcnt(3)                                       // 0000001CFF40: BF89FC37
	v_fma_mixlo_f16 v4, v156, s39, 0                           // 0000001CFF44: CC210004 02004F9C
	v_fma_mixhi_f16 v4, v157, s39, 0                           // 0000001CFF4C: CC220004 02004F9D
	v_wmma_f32_16x16x16_f16 v[9:16], v[97:104], v[17:24], v[65:72]// 0000001CFF54: CC404009 1D062361
	ds_load_b128 v[17:20], v129 offset:25344                   // 0000001CFF5C: DBFC6300 11000081
	ds_load_b128 v[21:24], v129 offset:25360                   // 0000001CFF64: DBFC6310 15000081
	s_waitcnt lgkmcnt(4)                                       // 0000001CFF6C: BF89FC47
	v_fma_mixlo_f16 v5, v158, s39, 0                           // 0000001CFF70: CC210005 02004F9E
	v_fma_mixhi_f16 v5, v159, s39, 0                           // 0000001CFF78: CC220005 02004F9F
	ds_load_b128 v[156:159], v129 offset:25392                 // 0000001CFF80: DBFC6330 9C000081
	v_fma_mixlo_f16 v3, v154, s39, 0                           // 0000001CFF88: CC210003 02004F9A
	v_fma_mixlo_f16 v6, v160, s39, 0                           // 0000001CFF90: CC210006 02004FA0
	v_fma_mixhi_f16 v6, v161, s39, 0                           // 0000001CFF98: CC220006 02004FA1
	s_waitcnt lgkmcnt(4)                                       // 0000001CFFA0: BF89FC47
	v_fma_mixlo_f16 v7, v162, s39, 0                           // 0000001CFFA4: CC210007 02004FA2
	v_fma_mixhi_f16 v7, v163, s39, 0                           // 0000001CFFAC: CC220007 02004FA3
	v_fma_mixlo_f16 v8, v164, s39, 0                           // 0000001CFFB4: CC210008 02004FA4
	v_fma_mixhi_f16 v8, v165, s39, 0                           // 0000001CFFBC: CC220008 02004FA5
	ds_load_b128 v[160:163], v129 offset:64                    // 0000001CFFC4: DBFC0040 A0000081
	ds_load_b128 v[170:173], v129 offset:80                    // 0000001CFFCC: DBFC0050 AA000081
	s_waitcnt lgkmcnt(5)                                       // 0000001CFFD4: BF89FC57
	v_fma_mixlo_f16 v154, v166, s39, 0                         // 0000001CFFD8: CC21009A 02004FA6
	v_fma_mixhi_f16 v154, v167, s39, 0                         // 0000001CFFE0: CC22009A 02004FA7
	ds_load_b128 v[164:167], v129 offset:96                    // 0000001CFFE8: DBFC0060 A4000081
	ds_load_b128 v[174:177], v129 offset:112                   // 0000001CFFF0: DBFC0070 AE000081
	v_fma_mixlo_f16 v1, v150, s39, 0                           // 0000001CFFF8: CC210001 02004F96
	v_fma_mixhi_f16 v1, v151, s39, 0                           // 0000001D0000: CC220001 02004F97
	v_fma_mixlo_f16 v2, v152, s39, 0                           // 0000001D0008: CC210002 02004F98
	v_fma_mixhi_f16 v2, v153, s39, 0                           // 0000001D0010: CC220002 02004F99
	v_fma_mixhi_f16 v3, v155, s39, 0                           // 0000001D0018: CC220003 02004F9B
	s_waitcnt lgkmcnt(6)                                       // 0000001D0020: BF89FC67
	v_fma_mixlo_f16 v150, v17, s39, 0                          // 0000001D0024: CC210096 02004F11
	v_fma_mixhi_f16 v150, v18, s39, 0                          // 0000001D002C: CC220096 02004F12
	v_fma_mixlo_f16 v151, v19, s39, 0                          // 0000001D0034: CC210097 02004F13
	v_fma_mixhi_f16 v151, v20, s39, 0                          // 0000001D003C: CC220097 02004F14
	s_waitcnt lgkmcnt(5)                                       // 0000001D0044: BF89FC57
	v_fma_mixlo_f16 v152, v21, s39, 0                          // 0000001D0048: CC210098 02004F15
	v_fma_mixhi_f16 v152, v22, s39, 0                          // 0000001D0050: CC220098 02004F16
	v_fma_mixlo_f16 v153, v23, s39, 0                          // 0000001D0058: CC210099 02004F17
	v_fma_mixhi_f16 v153, v24, s39, 0                          // 0000001D0060: CC220099 02004F18
	v_fma_mixlo_f16 v155, v168, s39, 0                         // 0000001D0068: CC21009B 02004FA8
	v_fma_mixhi_f16 v155, v169, s39, 0                         // 0000001D0070: CC22009B 02004FA9
	s_waitcnt lgkmcnt(4)                                       // 0000001D0078: BF89FC47
	v_fma_mixlo_f16 v156, v156, s39, 0                         // 0000001D007C: CC21009C 02004F9C
	v_fma_mixhi_f16 v156, v157, s39, 0                         // 0000001D0084: CC22009C 02004F9D
	v_fma_mixlo_f16 v157, v158, s39, 0                         // 0000001D008C: CC21009D 02004F9E
	v_fma_mixhi_f16 v157, v159, s39, 0                         // 0000001D0094: CC22009D 02004F9F
	v_wmma_f32_16x16x16_f16 v[17:24], v[97:104], v[1:8], v[65:72]// 0000001D009C: CC404011 1D060361
	ds_load_b128 v[178:181], v129 offset:17008                 // 0000001D00A4: DBFC4270 B2000081
	ds_load_b128 v[182:185], v129 offset:25408                 // 0000001D00AC: DBFC6340 B6000081
	ds_load_b128 v[186:189], v129 offset:25424                 // 0000001D00B4: DBFC6350 BA000081
	v_wmma_f32_16x16x16_f16 v[1:8], v[97:104], v[150:157], v[65:72]// 0000001D00BC: CC404001 1D072D61
	ds_load_b128 v[150:153], v129 offset:8512                  // 0000001D00C4: DBFC2140 96000081
	ds_load_b128 v[154:157], v129 offset:8528                  // 0000001D00CC: DBFC2150 9A000081
	s_waitcnt lgkmcnt(8)                                       // 0000001D00D4: BF89FC87
	v_fma_mixlo_f16 v97, v160, s39, 0                          // 0000001D00D8: CC210061 02004FA0
	v_fma_mixhi_f16 v97, v161, s39, 0                          // 0000001D00E0: CC220061 02004FA1
	v_fma_mixlo_f16 v98, v162, s39, 0                          // 0000001D00E8: CC210062 02004FA2
	v_fma_mixhi_f16 v98, v163, s39, 0                          // 0000001D00F0: CC220062 02004FA3
	s_waitcnt lgkmcnt(7)                                       // 0000001D00F8: BF89FC77
	v_fma_mixlo_f16 v99, v170, s39, 0                          // 0000001D00FC: CC210063 02004FAA
	v_fma_mixhi_f16 v99, v171, s39, 0                          // 0000001D0104: CC220063 02004FAB
	v_fma_mixlo_f16 v100, v172, s39, 0                         // 0000001D010C: CC210064 02004FAC
	v_fma_mixhi_f16 v100, v173, s39, 0                         // 0000001D0114: CC220064 02004FAD
	ds_load_b128 v[158:161], v129 offset:8544                  // 0000001D011C: DBFC2160 9E000081
	s_waitcnt lgkmcnt(7)                                       // 0000001D0124: BF89FC77
	v_fma_mixlo_f16 v101, v164, s39, 0                         // 0000001D0128: CC210065 02004FA4
	v_fma_mixhi_f16 v101, v165, s39, 0                         // 0000001D0130: CC220065 02004FA5
	v_fma_mixlo_f16 v102, v166, s39, 0                         // 0000001D0138: CC210066 02004FA6
	v_fma_mixhi_f16 v102, v167, s39, 0                         // 0000001D0140: CC220066 02004FA7
	ds_load_b128 v[162:165], v129 offset:8560                  // 0000001D0148: DBFC2170 A2000081
	s_waitcnt lgkmcnt(7)                                       // 0000001D0150: BF89FC77
	v_fma_mixlo_f16 v103, v174, s39, 0                         // 0000001D0154: CC210067 02004FAE
	v_fma_mixhi_f16 v103, v175, s39, 0                         // 0000001D015C: CC220067 02004FAF
	v_fma_mixlo_f16 v104, v176, s39, 0                         // 0000001D0164: CC210068 02004FB0
	v_fma_mixhi_f16 v104, v177, s39, 0                         // 0000001D016C: CC220068 02004FB1
	ds_load_b128 v[166:169], v129 offset:16960                 // 0000001D0174: DBFC4240 A6000081
	ds_load_b128 v[170:173], v129 offset:16976                 // 0000001D017C: DBFC4250 AA000081
	ds_load_b128 v[174:177], v129 offset:16992                 // 0000001D0184: DBFC4260 AE000081
	s_waitcnt lgkmcnt(6)                                       // 0000001D018C: BF89FC67
	v_fma_mixlo_f16 v150, v150, s39, 0                         // 0000001D0190: CC210096 02004F96
	v_fma_mixhi_f16 v150, v151, s39, 0                         // 0000001D0198: CC220096 02004F97
	v_fma_mixlo_f16 v151, v152, s39, 0                         // 0000001D01A0: CC210097 02004F98
	v_fma_mixhi_f16 v151, v153, s39, 0                         // 0000001D01A8: CC220097 02004F99
	s_waitcnt lgkmcnt(5)                                       // 0000001D01B0: BF89FC57
	v_fma_mixhi_f16 v152, v155, s39, 0                         // 0000001D01B4: CC220098 02004F9B
	v_fma_mixlo_f16 v153, v156, s39, 0                         // 0000001D01BC: CC210099 02004F9C
	ds_load_b128 v[190:193], v129 offset:25440                 // 0000001D01C4: DBFC6360 BE000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D01CC: BF89FC57
	v_fma_mixhi_f16 v155, v161, s39, 0                         // 0000001D01D0: CC22009B 02004FA1
	v_fma_mixlo_f16 v152, v154, s39, 0                         // 0000001D01D8: CC210098 02004F9A
	v_fma_mixhi_f16 v153, v157, s39, 0                         // 0000001D01E0: CC220099 02004F9D
	v_fma_mixlo_f16 v154, v158, s39, 0                         // 0000001D01E8: CC21009A 02004F9E
	v_fma_mixhi_f16 v154, v159, s39, 0                         // 0000001D01F0: CC22009A 02004F9F
	s_waitcnt lgkmcnt(4)                                       // 0000001D01F8: BF89FC47
	v_fma_mixlo_f16 v156, v162, s39, 0                         // 0000001D01FC: CC21009C 02004FA2
	v_fma_mixlo_f16 v155, v160, s39, 0                         // 0000001D0204: CC21009B 02004FA0
	v_fma_mixhi_f16 v156, v163, s39, 0                         // 0000001D020C: CC22009C 02004FA3
	v_fma_mixlo_f16 v157, v164, s39, 0                         // 0000001D0214: CC21009D 02004FA4
	v_fma_mixhi_f16 v157, v165, s39, 0                         // 0000001D021C: CC22009D 02004FA5
	s_waitcnt lgkmcnt(3)                                       // 0000001D0224: BF89FC37
	v_fma_mixlo_f16 v158, v166, s39, 0                         // 0000001D0228: CC21009E 02004FA6
	s_waitcnt lgkmcnt(2)                                       // 0000001D0230: BF89FC27
	v_fma_mixlo_f16 v161, v172, s39, 0                         // 0000001D0234: CC2100A1 02004FAC
	v_fma_mixhi_f16 v161, v173, s39, 0                         // 0000001D023C: CC2200A1 02004FAD
	s_waitcnt lgkmcnt(1)                                       // 0000001D0244: BF89FC17
	v_fma_mixlo_f16 v162, v174, s39, 0                         // 0000001D0248: CC2100A2 02004FAE
	v_fma_mixhi_f16 v162, v175, s39, 0                         // 0000001D0250: CC2200A2 02004FAF
	ds_load_b128 v[172:175], v129 offset:25456                 // 0000001D0258: DBFC6370 AC000081
	v_fma_mixhi_f16 v158, v167, s39, 0                         // 0000001D0260: CC22009E 02004FA7
	v_fma_mixlo_f16 v159, v168, s39, 0                         // 0000001D0268: CC21009F 02004FA8
	v_fma_mixhi_f16 v159, v169, s39, 0                         // 0000001D0270: CC22009F 02004FA9
	v_fma_mixlo_f16 v160, v170, s39, 0                         // 0000001D0278: CC2100A0 02004FAA
	v_fma_mixhi_f16 v160, v171, s39, 0                         // 0000001D0280: CC2200A0 02004FAB
	v_fma_mixlo_f16 v163, v176, s39, 0                         // 0000001D0288: CC2100A3 02004FB0
	v_fma_mixhi_f16 v163, v177, s39, 0                         // 0000001D0290: CC2200A3 02004FB1
	v_fma_mixlo_f16 v164, v178, s39, 0                         // 0000001D0298: CC2100A4 02004FB2
	v_fma_mixhi_f16 v164, v179, s39, 0                         // 0000001D02A0: CC2200A4 02004FB3
	v_fma_mixlo_f16 v165, v180, s39, 0                         // 0000001D02A8: CC2100A5 02004FB4
	v_fma_mixhi_f16 v165, v181, s39, 0                         // 0000001D02B0: CC2200A5 02004FB5
	v_fma_mixlo_f16 v166, v182, s39, 0                         // 0000001D02B8: CC2100A6 02004FB6
	v_fma_mixhi_f16 v166, v183, s39, 0                         // 0000001D02C0: CC2200A6 02004FB7
	v_fma_mixlo_f16 v167, v184, s39, 0                         // 0000001D02C8: CC2100A7 02004FB8
	v_fma_mixhi_f16 v167, v185, s39, 0                         // 0000001D02D0: CC2200A7 02004FB9
	v_fma_mixlo_f16 v168, v186, s39, 0                         // 0000001D02D8: CC2100A8 02004FBA
	v_fma_mixhi_f16 v168, v187, s39, 0                         // 0000001D02E0: CC2200A8 02004FBB
	v_fma_mixlo_f16 v169, v188, s39, 0                         // 0000001D02E8: CC2100A9 02004FBC
	v_fma_mixhi_f16 v169, v189, s39, 0                         // 0000001D02F0: CC2200A9 02004FBD
	s_waitcnt lgkmcnt(1)                                       // 0000001D02F8: BF89FC17
	v_fma_mixlo_f16 v170, v190, s39, 0                         // 0000001D02FC: CC2100AA 02004FBE
	v_fma_mixhi_f16 v170, v191, s39, 0                         // 0000001D0304: CC2200AA 02004FBF
	v_fma_mixlo_f16 v171, v192, s39, 0                         // 0000001D030C: CC2100AB 02004FC0
	v_fma_mixhi_f16 v171, v193, s39, 0                         // 0000001D0314: CC2200AB 02004FC1
	s_waitcnt lgkmcnt(0)                                       // 0000001D031C: BF89FC07
	v_fma_mixlo_f16 v172, v172, s39, 0                         // 0000001D0320: CC2100AC 02004FAC
	v_fma_mixhi_f16 v172, v173, s39, 0                         // 0000001D0328: CC2200AC 02004FAD
	v_fma_mixlo_f16 v173, v174, s39, 0                         // 0000001D0330: CC2100AD 02004FAE
	v_fma_mixhi_f16 v173, v175, s39, 0                         // 0000001D0338: CC2200AD 02004FAF
	ds_load_b128 v[176:179], v129 offset:128                   // 0000001D0340: DBFC0080 B0000081
	ds_load_b128 v[180:183], v129 offset:144                   // 0000001D0348: DBFC0090 B4000081
	ds_load_b128 v[184:187], v129 offset:160                   // 0000001D0350: DBFC00A0 B8000081
	s_waitcnt vmcnt(12)                                        // 0000001D0358: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[97:104], v[25:32]// 0000001D035C: CC404019 1C66C359
	ds_load_b128 v[97:100], v129 offset:176                    // 0000001D0364: DBFC00B0 61000081
	v_wmma_f32_16x16x16_f16 v[9:16], v[89:96], v[150:157], v[9:16]// 0000001D036C: CC404009 1C272D59
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[158:165], v[17:24]// 0000001D0374: CC404011 1C473D59
	v_wmma_f32_16x16x16_f16 v[1:8], v[89:96], v[166:173], v[1:8]// 0000001D037C: CC404001 1C074D59
	ds_load_b128 v[101:104], v129 offset:8576                  // 0000001D0384: DBFC2180 65000081
	ds_load_b128 v[150:153], v129 offset:8592                  // 0000001D038C: DBFC2190 96000081
	ds_load_b128 v[154:157], v129 offset:8608                  // 0000001D0394: DBFC21A0 9A000081
	ds_load_b128 v[158:161], v129 offset:8624                  // 0000001D039C: DBFC21B0 9E000081
	ds_load_b128 v[162:165], v129 offset:17024                 // 0000001D03A4: DBFC4280 A2000081
	ds_load_b128 v[166:169], v129 offset:17040                 // 0000001D03AC: DBFC4290 A6000081
	ds_load_b128 v[170:173], v129 offset:17056                 // 0000001D03B4: DBFC42A0 AA000081
	s_mul_hi_u32 s14, s40, 0xfffff430                          // 0000001D03BC: 968EFF28 FFFFF430
	s_mul_i32 s43, s40, 0xfffff430                             // 0000001D03C4: 962BFF28 FFFFF430
	s_sub_i32 s14, s14, s40                                    // 0000001D03CC: 818E280E
	s_add_u32 s28, s28, s43                                    // 0000001D03D0: 801C2B1C
	s_addc_u32 s29, s29, s14                                   // 0000001D03D4: 821D0E1D
	s_waitcnt lgkmcnt(10)                                      // 0000001D03D8: BF89FCA7
	v_fma_mixlo_f16 v89, v176, s39, 0                          // 0000001D03DC: CC210059 02004FB0
	v_fma_mixhi_f16 v89, v177, s39, 0                          // 0000001D03E4: CC220059 02004FB1
	v_fma_mixlo_f16 v90, v178, s39, 0                          // 0000001D03EC: CC21005A 02004FB2
	v_fma_mixhi_f16 v90, v179, s39, 0                          // 0000001D03F4: CC22005A 02004FB3
	s_waitcnt lgkmcnt(9)                                       // 0000001D03FC: BF89FC97
	v_fma_mixlo_f16 v91, v180, s39, 0                          // 0000001D0400: CC21005B 02004FB4
	v_fma_mixhi_f16 v91, v181, s39, 0                          // 0000001D0408: CC22005B 02004FB5
	s_waitcnt lgkmcnt(7)                                       // 0000001D0410: BF89FC77
	v_fma_mixhi_f16 v95, v98, s39, 0                           // 0000001D0414: CC22005F 02004F62
	v_fma_mixlo_f16 v96, v99, s39, 0                           // 0000001D041C: CC210060 02004F63
	v_fma_mixhi_f16 v96, v100, s39, 0                          // 0000001D0424: CC220060 02004F64
	s_waitcnt lgkmcnt(6)                                       // 0000001D042C: BF89FC67
	v_fma_mixlo_f16 v98, v103, s39, 0                          // 0000001D0430: CC210062 02004F67
	v_fma_mixhi_f16 v98, v104, s39, 0                          // 0000001D0438: CC220062 02004F68
	s_waitcnt lgkmcnt(5)                                       // 0000001D0440: BF89FC57
	v_fma_mixlo_f16 v99, v150, s39, 0                          // 0000001D0444: CC210063 02004F96
	v_fma_mixhi_f16 v99, v151, s39, 0                          // 0000001D044C: CC220063 02004F97
	v_fma_mixlo_f16 v100, v152, s39, 0                         // 0000001D0454: CC210064 02004F98
	v_fma_mixhi_f16 v100, v153, s39, 0                         // 0000001D045C: CC220064 02004F99
	s_waitcnt lgkmcnt(3)                                       // 0000001D0464: BF89FC37
	v_fma_mixlo_f16 v103, v158, s39, 0                         // 0000001D0468: CC210067 02004F9E
	ds_load_b128 v[174:177], v129 offset:17072                 // 0000001D0470: DBFC42B0 AE000081
	v_fma_mixhi_f16 v103, v159, s39, 0                         // 0000001D0478: CC220067 02004F9F
	v_fma_mixlo_f16 v104, v160, s39, 0                         // 0000001D0480: CC210068 02004FA0
	v_fma_mixhi_f16 v104, v161, s39, 0                         // 0000001D0488: CC220068 02004FA1
	ds_load_b128 v[158:161], v129 offset:25472                 // 0000001D0490: DBFC6380 9E000081
	ds_load_b128 v[178:181], v129 offset:25488                 // 0000001D0498: DBFC6390 B2000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D04A0: BF89FC57
	v_fma_mixlo_f16 v150, v162, s39, 0                         // 0000001D04A4: CC210096 02004FA2
	v_fma_mixhi_f16 v150, v163, s39, 0                         // 0000001D04AC: CC220096 02004FA3
	v_fma_mixlo_f16 v151, v164, s39, 0                         // 0000001D04B4: CC210097 02004FA4
	v_fma_mixhi_f16 v151, v165, s39, 0                         // 0000001D04BC: CC220097 02004FA5
	s_waitcnt lgkmcnt(4)                                       // 0000001D04C4: BF89FC47
	v_fma_mixlo_f16 v152, v166, s39, 0                         // 0000001D04C8: CC210098 02004FA6
	v_fma_mixhi_f16 v152, v167, s39, 0                         // 0000001D04D0: CC220098 02004FA7
	v_fma_mixlo_f16 v153, v168, s39, 0                         // 0000001D04D8: CC210099 02004FA8
	ds_load_b128 v[162:165], v129 offset:25504                 // 0000001D04E0: DBFC63A0 A2000081
	v_fma_mixhi_f16 v153, v169, s39, 0                         // 0000001D04E8: CC220099 02004FA9
	ds_load_b128 v[166:169], v129 offset:25520                 // 0000001D04F0: DBFC63B0 A6000081
	v_fma_mixlo_f16 v92, v182, s39, 0                          // 0000001D04F8: CC21005C 02004FB6
	v_fma_mixhi_f16 v92, v183, s39, 0                          // 0000001D0500: CC22005C 02004FB7
	v_fma_mixlo_f16 v93, v184, s39, 0                          // 0000001D0508: CC21005D 02004FB8
	v_fma_mixhi_f16 v93, v185, s39, 0                          // 0000001D0510: CC22005D 02004FB9
	v_fma_mixlo_f16 v94, v186, s39, 0                          // 0000001D0518: CC21005E 02004FBA
	v_fma_mixhi_f16 v94, v187, s39, 0                          // 0000001D0520: CC22005E 02004FBB
	v_fma_mixlo_f16 v95, v97, s39, 0                           // 0000001D0528: CC21005F 02004F61
	v_fma_mixlo_f16 v97, v101, s39, 0                          // 0000001D0530: CC210061 02004F65
	v_fma_mixhi_f16 v97, v102, s39, 0                          // 0000001D0538: CC220061 02004F66
	v_fma_mixlo_f16 v101, v154, s39, 0                         // 0000001D0540: CC210065 02004F9A
	v_fma_mixhi_f16 v101, v155, s39, 0                         // 0000001D0548: CC220065 02004F9B
	v_fma_mixlo_f16 v102, v156, s39, 0                         // 0000001D0550: CC210066 02004F9C
	v_fma_mixhi_f16 v102, v157, s39, 0                         // 0000001D0558: CC220066 02004F9D
	s_waitcnt lgkmcnt(5)                                       // 0000001D0560: BF89FC57
	v_fma_mixlo_f16 v154, v170, s39, 0                         // 0000001D0564: CC21009A 02004FAA
	v_fma_mixhi_f16 v154, v171, s39, 0                         // 0000001D056C: CC22009A 02004FAB
	v_fma_mixlo_f16 v155, v172, s39, 0                         // 0000001D0574: CC21009B 02004FAC
	v_fma_mixhi_f16 v155, v173, s39, 0                         // 0000001D057C: CC22009B 02004FAD
	s_waitcnt lgkmcnt(4)                                       // 0000001D0584: BF89FC47
	v_fma_mixlo_f16 v156, v174, s39, 0                         // 0000001D0588: CC21009C 02004FAE
	v_fma_mixhi_f16 v156, v175, s39, 0                         // 0000001D0590: CC22009C 02004FAF
	v_fma_mixlo_f16 v157, v176, s39, 0                         // 0000001D0598: CC21009D 02004FB0
	v_fma_mixhi_f16 v157, v177, s39, 0                         // 0000001D05A0: CC22009D 02004FB1
	s_waitcnt lgkmcnt(3)                                       // 0000001D05A8: BF89FC37
	v_fma_mixlo_f16 v158, v158, s39, 0                         // 0000001D05AC: CC21009E 02004F9E
	v_fma_mixhi_f16 v158, v159, s39, 0                         // 0000001D05B4: CC22009E 02004F9F
	v_fma_mixlo_f16 v159, v160, s39, 0                         // 0000001D05BC: CC21009F 02004FA0
	v_fma_mixhi_f16 v159, v161, s39, 0                         // 0000001D05C4: CC22009F 02004FA1
	s_waitcnt lgkmcnt(2)                                       // 0000001D05CC: BF89FC27
	v_fma_mixlo_f16 v160, v178, s39, 0                         // 0000001D05D0: CC2100A0 02004FB2
	v_fma_mixhi_f16 v160, v179, s39, 0                         // 0000001D05D8: CC2200A0 02004FB3
	v_fma_mixlo_f16 v161, v180, s39, 0                         // 0000001D05E0: CC2100A1 02004FB4
	v_fma_mixhi_f16 v161, v181, s39, 0                         // 0000001D05E8: CC2200A1 02004FB5
	s_waitcnt lgkmcnt(1)                                       // 0000001D05F0: BF89FC17
	v_fma_mixlo_f16 v162, v162, s39, 0                         // 0000001D05F4: CC2100A2 02004FA2
	v_fma_mixhi_f16 v162, v163, s39, 0                         // 0000001D05FC: CC2200A2 02004FA3
	v_fma_mixlo_f16 v163, v164, s39, 0                         // 0000001D0604: CC2100A3 02004FA4
	v_fma_mixhi_f16 v163, v165, s39, 0                         // 0000001D060C: CC2200A3 02004FA5
	s_waitcnt lgkmcnt(0)                                       // 0000001D0614: BF89FC07
	v_fma_mixlo_f16 v164, v166, s39, 0                         // 0000001D0618: CC2100A4 02004FA6
	v_fma_mixhi_f16 v164, v167, s39, 0                         // 0000001D0620: CC2200A4 02004FA7
	v_fma_mixlo_f16 v165, v168, s39, 0                         // 0000001D0628: CC2100A5 02004FA8
	v_fma_mixhi_f16 v165, v169, s39, 0                         // 0000001D0630: CC2200A5 02004FA9
	ds_load_b128 v[170:173], v129 offset:192                   // 0000001D0638: DBFC00C0 AA000081
	ds_load_b128 v[174:177], v129 offset:208                   // 0000001D0640: DBFC00D0 AE000081
	ds_load_b128 v[178:181], v129 offset:224                   // 0000001D0648: DBFC00E0 B2000081
	s_waitcnt vmcnt(10)                                        // 0000001D0650: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 0000001D0654: CC404019 1C66B351
	ds_load_b128 v[89:92], v129 offset:240                     // 0000001D065C: DBFC00F0 59000081
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[97:104], v[9:16]// 0000001D0664: CC404009 1C26C351
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[150:157], v[17:24]// 0000001D066C: CC404011 1C472D51
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[158:165], v[1:8]// 0000001D0674: CC404001 1C073D51
	ds_load_b128 v[93:96], v129 offset:8640                    // 0000001D067C: DBFC21C0 5D000081
	ds_load_b128 v[97:100], v129 offset:8656                   // 0000001D0684: DBFC21D0 61000081
	ds_load_b128 v[101:104], v129 offset:8672                  // 0000001D068C: DBFC21E0 65000081
	ds_load_b128 v[150:153], v129 offset:8688                  // 0000001D0694: DBFC21F0 96000081
	ds_load_b128 v[154:157], v129 offset:17088                 // 0000001D069C: DBFC42C0 9A000081
	ds_load_b128 v[158:161], v129 offset:17104                 // 0000001D06A4: DBFC42D0 9E000081
	ds_load_b128 v[162:165], v129 offset:17120                 // 0000001D06AC: DBFC42E0 A2000081
	ds_load_b128 v[166:169], v129 offset:17136                 // 0000001D06B4: DBFC42F0 A6000081
	s_lshl_b64 s[28:29], s[28:29], 13                          // 0000001D06BC: 849C8D1C
	ds_load_b128 v[182:185], v129 offset:25616                 // 0000001D06C0: DBFC6410 B6000081
	.long 0xd7006a74                                           // 0000001D06C8: D7006A74
	v_cndmask_b32_e32 v0, v139, v28, vcc_lo                    // 0000001D06CC: 0200398B
	s_waitcnt lgkmcnt(12)                                      // 0000001D06D0: BF89FCC7
	v_fma_mixlo_f16 v81, v170, s39, 0                          // 0000001D06D4: CC210051 02004FAA
	v_fma_mixhi_f16 v81, v171, s39, 0                          // 0000001D06DC: CC220051 02004FAB
	v_fma_mixlo_f16 v82, v172, s39, 0                          // 0000001D06E4: CC210052 02004FAC
	v_fma_mixhi_f16 v82, v173, s39, 0                          // 0000001D06EC: CC220052 02004FAD
	s_waitcnt lgkmcnt(9)                                       // 0000001D06F4: BF89FC97
	v_fma_mixhi_f16 v87, v90, s39, 0                           // 0000001D06F8: CC220057 02004F5A
	v_fma_mixlo_f16 v88, v91, s39, 0                           // 0000001D0700: CC210058 02004F5B
	v_fma_mixhi_f16 v88, v92, s39, 0                           // 0000001D0708: CC220058 02004F5C
	ds_load_b128 v[170:173], v129 offset:25552                 // 0000001D0710: DBFC63D0 AA000081
	s_waitcnt lgkmcnt(9)                                       // 0000001D0718: BF89FC97
	v_fma_mixlo_f16 v90, v95, s39, 0                           // 0000001D071C: CC21005A 02004F5F
	v_fma_mixhi_f16 v90, v96, s39, 0                           // 0000001D0724: CC22005A 02004F60
	s_waitcnt lgkmcnt(8)                                       // 0000001D072C: BF89FC87
	v_fma_mixlo_f16 v91, v97, s39, 0                           // 0000001D0730: CC21005B 02004F61
	v_fma_mixhi_f16 v91, v98, s39, 0                           // 0000001D0738: CC22005B 02004F62
	v_fma_mixlo_f16 v92, v99, s39, 0                           // 0000001D0740: CC21005C 02004F63
	v_fma_mixhi_f16 v92, v100, s39, 0                          // 0000001D0748: CC22005C 02004F64
	s_waitcnt lgkmcnt(6)                                       // 0000001D0750: BF89FC67
	v_fma_mixlo_f16 v95, v150, s39, 0                          // 0000001D0754: CC21005F 02004F96
	v_fma_mixhi_f16 v95, v151, s39, 0                          // 0000001D075C: CC22005F 02004F97
	v_fma_mixlo_f16 v96, v152, s39, 0                          // 0000001D0764: CC210060 02004F98
	v_fma_mixhi_f16 v96, v153, s39, 0                          // 0000001D076C: CC220060 02004F99
	ds_load_b128 v[150:153], v129 offset:25536                 // 0000001D0774: DBFC63C0 96000081
	s_waitcnt lgkmcnt(6)                                       // 0000001D077C: BF89FC67
	v_fma_mixlo_f16 v97, v154, s39, 0                          // 0000001D0780: CC210061 02004F9A
	v_fma_mixhi_f16 v97, v155, s39, 0                          // 0000001D0788: CC220061 02004F9B
	v_fma_mixlo_f16 v98, v156, s39, 0                          // 0000001D0790: CC210062 02004F9C
	v_fma_mixhi_f16 v98, v157, s39, 0                          // 0000001D0798: CC220062 02004F9D
	s_waitcnt lgkmcnt(5)                                       // 0000001D07A0: BF89FC57
	v_fma_mixlo_f16 v99, v158, s39, 0                          // 0000001D07A4: CC210063 02004F9E
	v_fma_mixhi_f16 v99, v159, s39, 0                          // 0000001D07AC: CC220063 02004F9F
	v_fma_mixlo_f16 v100, v160, s39, 0                         // 0000001D07B4: CC210064 02004FA0
	v_fma_mixhi_f16 v100, v161, s39, 0                         // 0000001D07BC: CC220064 02004FA1
	ds_load_b128 v[154:157], v129 offset:25568                 // 0000001D07C4: DBFC63E0 9A000081
	ds_load_b128 v[158:161], v129 offset:25584                 // 0000001D07CC: DBFC63F0 9E000081
	v_fma_mixlo_f16 v83, v174, s39, 0                          // 0000001D07D4: CC210053 02004FAE
	v_fma_mixhi_f16 v83, v175, s39, 0                          // 0000001D07DC: CC220053 02004FAF
	v_fma_mixlo_f16 v84, v176, s39, 0                          // 0000001D07E4: CC210054 02004FB0
	v_fma_mixhi_f16 v84, v177, s39, 0                          // 0000001D07EC: CC220054 02004FB1
	v_fma_mixlo_f16 v85, v178, s39, 0                          // 0000001D07F4: CC210055 02004FB2
	v_fma_mixhi_f16 v85, v179, s39, 0                          // 0000001D07FC: CC220055 02004FB3
	v_fma_mixlo_f16 v86, v180, s39, 0                          // 0000001D0804: CC210056 02004FB4
	v_fma_mixhi_f16 v86, v181, s39, 0                          // 0000001D080C: CC220056 02004FB5
	v_fma_mixlo_f16 v87, v89, s39, 0                           // 0000001D0814: CC210057 02004F59
	v_fma_mixlo_f16 v89, v93, s39, 0                           // 0000001D081C: CC210059 02004F5D
	v_fma_mixhi_f16 v89, v94, s39, 0                           // 0000001D0824: CC220059 02004F5E
	v_fma_mixlo_f16 v93, v101, s39, 0                          // 0000001D082C: CC21005D 02004F65
	v_fma_mixhi_f16 v93, v102, s39, 0                          // 0000001D0834: CC22005D 02004F66
	v_fma_mixlo_f16 v94, v103, s39, 0                          // 0000001D083C: CC21005E 02004F67
	v_fma_mixhi_f16 v94, v104, s39, 0                          // 0000001D0844: CC22005E 02004F68
	s_waitcnt lgkmcnt(6)                                       // 0000001D084C: BF89FC67
	v_fma_mixlo_f16 v101, v162, s39, 0                         // 0000001D0850: CC210065 02004FA2
	v_fma_mixhi_f16 v101, v163, s39, 0                         // 0000001D0858: CC220065 02004FA3
	v_fma_mixlo_f16 v102, v164, s39, 0                         // 0000001D0860: CC210066 02004FA4
	v_fma_mixhi_f16 v102, v165, s39, 0                         // 0000001D0868: CC220066 02004FA5
	s_waitcnt lgkmcnt(5)                                       // 0000001D0870: BF89FC57
	v_fma_mixlo_f16 v103, v166, s39, 0                         // 0000001D0874: CC210067 02004FA6
	v_fma_mixhi_f16 v103, v167, s39, 0                         // 0000001D087C: CC220067 02004FA7
	v_fma_mixlo_f16 v104, v168, s39, 0                         // 0000001D0884: CC210068 02004FA8
	v_fma_mixhi_f16 v104, v169, s39, 0                         // 0000001D088C: CC220068 02004FA9
	s_waitcnt vmcnt(8)                                         // 0000001D0894: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[81:88], v[25:32]// 0000001D0898: CC404019 1C66A349
	ds_load_b128 v[81:84], v129 offset:8704                    // 0000001D08A0: DBFC2200 51000081
	ds_load_b128 v[85:88], v129 offset:8720                    // 0000001D08A8: DBFC2210 55000081
	s_waitcnt lgkmcnt(4)                                       // 0000001D08B0: BF89FC47
	v_fma_mixlo_f16 v150, v150, s39, 0                         // 0000001D08B4: CC210096 02004F96
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[97:104], v[17:24]// 0000001D08BC: CC404011 1C46C349
	ds_load_b128 v[102:105], v129 offset:8736                  // 0000001D08C4: DBFC2220 66000081
	v_fma_mixhi_f16 v150, v151, s39, 0                         // 0000001D08CC: CC220096 02004F97
	v_fma_mixlo_f16 v151, v152, s39, 0                         // 0000001D08D4: CC210097 02004F98
	v_fma_mixhi_f16 v151, v153, s39, 0                         // 0000001D08DC: CC220097 02004F99
	v_fma_mixlo_f16 v152, v170, s39, 0                         // 0000001D08E4: CC210098 02004FAA
	v_fma_mixhi_f16 v152, v171, s39, 0                         // 0000001D08EC: CC220098 02004FAB
	v_fma_mixlo_f16 v153, v172, s39, 0                         // 0000001D08F4: CC210099 02004FAC
	v_fma_mixhi_f16 v153, v173, s39, 0                         // 0000001D08FC: CC220099 02004FAD
	s_waitcnt lgkmcnt(4)                                       // 0000001D0904: BF89FC47
	v_fma_mixlo_f16 v154, v154, s39, 0                         // 0000001D0908: CC21009A 02004F9A
	v_fma_mixhi_f16 v154, v155, s39, 0                         // 0000001D0910: CC22009A 02004F9B
	v_fma_mixlo_f16 v155, v156, s39, 0                         // 0000001D0918: CC21009B 02004F9C
	v_fma_mixhi_f16 v155, v157, s39, 0                         // 0000001D0920: CC22009B 02004F9D
	s_waitcnt lgkmcnt(3)                                       // 0000001D0928: BF89FC37
	v_fma_mixlo_f16 v156, v158, s39, 0                         // 0000001D092C: CC21009C 02004F9E
	v_fma_mixhi_f16 v156, v159, s39, 0                         // 0000001D0934: CC22009C 02004F9F
	v_fma_mixlo_f16 v157, v160, s39, 0                         // 0000001D093C: CC21009D 02004FA0
	v_fma_mixhi_f16 v157, v161, s39, 0                         // 0000001D0944: CC22009D 02004FA1
	v_add_co_ci_u32_e64 v117, null, s29, v140, vcc_lo          // 0000001D094C: D5207C75 01AB181D
	v_wmma_f32_16x16x16_f16 v[9:16], v[73:80], v[89:96], v[9:16]// 0000001D0954: CC404009 1C26B349
	s_waitcnt lgkmcnt(2)                                       // 0000001D095C: BF89FC27
	v_fma_mixlo_f16 v81, v81, s39, 0                           // 0000001D0960: CC210051 02004F51
	v_wmma_f32_16x16x16_f16 v[1:8], v[73:80], v[150:157], v[1:8]// 0000001D0968: CC404001 1C072D49
	s_clause 0x1                                               // 0000001D0970: BF850001
	global_load_b128 v[154:157], v[116:117], off offset:16     // 0000001D0974: DC5E0010 9A7C0074
	global_load_b128 v[150:153], v[116:117], off               // 0000001D097C: DC5E0000 967C0074
	v_fma_mixhi_f16 v81, v82, s39, 0                           // 0000001D0984: CC220051 02004F52
	v_fma_mixlo_f16 v82, v83, s39, 0                           // 0000001D098C: CC210052 02004F53
	ds_load_b128 v[158:161], v129 offset:8752                  // 0000001D0994: DBFC2230 9E000081
	s_waitcnt lgkmcnt(2)                                       // 0000001D099C: BF89FC27
	v_fma_mixlo_f16 v83, v85, s39, 0                           // 0000001D09A0: CC210053 02004F55
	v_fma_mixhi_f16 v83, v86, s39, 0                           // 0000001D09A8: CC220053 02004F56
	s_waitcnt lgkmcnt(1)                                       // 0000001D09B0: BF89FC17
	v_fma_mixlo_f16 v85, v102, s39, 0                          // 0000001D09B4: CC210055 02004F66
	v_fma_mixhi_f16 v85, v103, s39, 0                          // 0000001D09BC: CC220055 02004F67
	v_fma_mixlo_f16 v86, v104, s39, 0                          // 0000001D09C4: CC210056 02004F68
	s_clause 0x3                                               // 0000001D09CC: BF850003
	global_load_b128 v[101:104], v[116:117], off offset:80     // 0000001D09D0: DC5E0050 657C0074
	global_load_b128 v[97:100], v[116:117], off offset:64      // 0000001D09D8: DC5E0040 617C0074
	global_load_b128 v[93:96], v[116:117], off offset:112      // 0000001D09E0: DC5E0070 5D7C0074
	global_load_b128 v[89:92], v[116:117], off offset:96       // 0000001D09E8: DC5E0060 597C0074
	ds_load_b128 v[162:165], v129 offset:256                   // 0000001D09F0: DBFC0100 A2000081
	ds_load_b128 v[166:169], v129 offset:272                   // 0000001D09F8: DBFC0110 A6000081
	ds_load_b128 v[170:173], v129 offset:288                   // 0000001D0A00: DBFC0120 AA000081
	ds_load_b128 v[174:177], v129 offset:304                   // 0000001D0A08: DBFC0130 AE000081
	ds_load_b128 v[178:181], v129 offset:25600                 // 0000001D0A10: DBFC6400 B2000081
	ds_load_b128 v[186:189], v129 offset:25632                 // 0000001D0A18: DBFC6420 BA000081
	ds_load_b128 v[190:193], v129 offset:25648                 // 0000001D0A20: DBFC6430 BE000081
	v_fma_mixhi_f16 v82, v84, s39, 0                           // 0000001D0A28: CC220052 02004F54
	v_fma_mixlo_f16 v84, v87, s39, 0                           // 0000001D0A30: CC210054 02004F57
	v_fma_mixhi_f16 v84, v88, s39, 0                           // 0000001D0A38: CC220054 02004F58
	v_fma_mixhi_f16 v86, v105, s39, 0                          // 0000001D0A40: CC220056 02004F69
	s_waitcnt lgkmcnt(7)                                       // 0000001D0A48: BF89FC77
	v_fma_mixlo_f16 v87, v158, s39, 0                          // 0000001D0A4C: CC210057 02004F9E
	v_fma_mixhi_f16 v87, v159, s39, 0                          // 0000001D0A54: CC220057 02004F9F
	v_fma_mixlo_f16 v88, v160, s39, 0                          // 0000001D0A5C: CC210058 02004FA0
	v_fma_mixhi_f16 v88, v161, s39, 0                          // 0000001D0A64: CC220058 02004FA1
	s_waitcnt lgkmcnt(6)                                       // 0000001D0A6C: BF89FC67
	v_fma_mixlo_f16 v73, v162, s39, 0                          // 0000001D0A70: CC210049 02004FA2
	v_fma_mixhi_f16 v73, v163, s39, 0                          // 0000001D0A78: CC220049 02004FA3
	v_fma_mixlo_f16 v74, v164, s39, 0                          // 0000001D0A80: CC21004A 02004FA4
	v_fma_mixhi_f16 v74, v165, s39, 0                          // 0000001D0A88: CC22004A 02004FA5
	s_waitcnt lgkmcnt(5)                                       // 0000001D0A90: BF89FC57
	v_fma_mixlo_f16 v75, v166, s39, 0                          // 0000001D0A94: CC21004B 02004FA6
	v_fma_mixhi_f16 v75, v167, s39, 0                          // 0000001D0A9C: CC22004B 02004FA7
	v_fma_mixlo_f16 v76, v168, s39, 0                          // 0000001D0AA4: CC21004C 02004FA8
	v_fma_mixhi_f16 v76, v169, s39, 0                          // 0000001D0AAC: CC22004C 02004FA9
	s_waitcnt lgkmcnt(4)                                       // 0000001D0AB4: BF89FC47
	v_fma_mixlo_f16 v77, v170, s39, 0                          // 0000001D0AB8: CC21004D 02004FAA
	v_fma_mixhi_f16 v77, v171, s39, 0                          // 0000001D0AC0: CC22004D 02004FAB
	v_fma_mixlo_f16 v78, v172, s39, 0                          // 0000001D0AC8: CC21004E 02004FAC
	v_fma_mixhi_f16 v78, v173, s39, 0                          // 0000001D0AD0: CC22004E 02004FAD
	s_waitcnt lgkmcnt(3)                                       // 0000001D0AD8: BF89FC37
	v_fma_mixlo_f16 v79, v174, s39, 0                          // 0000001D0ADC: CC21004F 02004FAE
	v_fma_mixhi_f16 v79, v175, s39, 0                          // 0000001D0AE4: CC22004F 02004FAF
	v_fma_mixlo_f16 v80, v176, s39, 0                          // 0000001D0AEC: CC210050 02004FB0
	v_fma_mixhi_f16 v80, v177, s39, 0                          // 0000001D0AF4: CC220050 02004FB1
	ds_load_b128 v[162:165], v129 offset:17152                 // 0000001D0AFC: DBFC4300 A2000081
	ds_load_b128 v[166:169], v129 offset:17168                 // 0000001D0B04: DBFC4310 A6000081
	ds_load_b128 v[170:173], v129 offset:17184                 // 0000001D0B0C: DBFC4320 AA000081
	ds_load_b128 v[174:177], v129 offset:17200                 // 0000001D0B14: DBFC4330 AE000081
	s_waitcnt vmcnt(12)                                        // 0000001D0B1C: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[73:80], v[25:32]// 0000001D0B20: CC404019 1C669339
	ds_load_b128 v[73:76], v129 offset:368                     // 0000001D0B28: DBFC0170 49000081
	v_wmma_f32_16x16x16_f16 v[9:16], v[57:64], v[81:88], v[9:16]// 0000001D0B30: CC404009 1C26A339
	ds_load_b128 v[77:80], v129 offset:8768                    // 0000001D0B38: DBFC2240 4D000081
	ds_load_b128 v[81:84], v129 offset:8784                    // 0000001D0B40: DBFC2250 51000081
	ds_load_b128 v[85:88], v129 offset:8800                    // 0000001D0B48: DBFC2260 55000081
	s_waitcnt lgkmcnt(7)                                       // 0000001D0B50: BF89FC77
	v_fma_mixlo_f16 v158, v162, s39, 0                         // 0000001D0B54: CC21009E 02004FA2
	v_fma_mixhi_f16 v158, v163, s39, 0                         // 0000001D0B5C: CC22009E 02004FA3
	v_fma_mixlo_f16 v159, v164, s39, 0                         // 0000001D0B64: CC21009F 02004FA4
	v_fma_mixhi_f16 v159, v165, s39, 0                         // 0000001D0B6C: CC22009F 02004FA5
	s_waitcnt lgkmcnt(6)                                       // 0000001D0B74: BF89FC67
	v_fma_mixlo_f16 v160, v166, s39, 0                         // 0000001D0B78: CC2100A0 02004FA6
	v_fma_mixhi_f16 v160, v167, s39, 0                         // 0000001D0B80: CC2200A0 02004FA7
	v_fma_mixlo_f16 v161, v168, s39, 0                         // 0000001D0B88: CC2100A1 02004FA8
	v_fma_mixhi_f16 v161, v169, s39, 0                         // 0000001D0B90: CC2200A1 02004FA9
	s_waitcnt lgkmcnt(5)                                       // 0000001D0B98: BF89FC57
	v_fma_mixlo_f16 v162, v170, s39, 0                         // 0000001D0B9C: CC2100A2 02004FAA
	v_fma_mixhi_f16 v162, v171, s39, 0                         // 0000001D0BA4: CC2200A2 02004FAB
	v_fma_mixlo_f16 v163, v172, s39, 0                         // 0000001D0BAC: CC2100A3 02004FAC
	v_fma_mixhi_f16 v163, v173, s39, 0                         // 0000001D0BB4: CC2200A3 02004FAD
	s_waitcnt lgkmcnt(4)                                       // 0000001D0BBC: BF89FC47
	v_fma_mixlo_f16 v164, v174, s39, 0                         // 0000001D0BC0: CC2100A4 02004FAE
	v_fma_mixhi_f16 v164, v175, s39, 0                         // 0000001D0BC8: CC2200A4 02004FAF
	v_fma_mixlo_f16 v165, v176, s39, 0                         // 0000001D0BD0: CC2100A5 02004FB0
	v_fma_mixhi_f16 v165, v177, s39, 0                         // 0000001D0BD8: CC2200A5 02004FB1
	v_fma_mixlo_f16 v166, v178, s39, 0                         // 0000001D0BE0: CC2100A6 02004FB2
	v_fma_mixhi_f16 v166, v179, s39, 0                         // 0000001D0BE8: CC2200A6 02004FB3
	v_fma_mixlo_f16 v167, v180, s39, 0                         // 0000001D0BF0: CC2100A7 02004FB4
	v_fma_mixhi_f16 v167, v181, s39, 0                         // 0000001D0BF8: CC2200A7 02004FB5
	v_fma_mixlo_f16 v168, v182, s39, 0                         // 0000001D0C00: CC2100A8 02004FB6
	v_fma_mixhi_f16 v168, v183, s39, 0                         // 0000001D0C08: CC2200A8 02004FB7
	v_fma_mixlo_f16 v169, v184, s39, 0                         // 0000001D0C10: CC2100A9 02004FB8
	v_fma_mixhi_f16 v169, v185, s39, 0                         // 0000001D0C18: CC2200A9 02004FB9
	v_fma_mixlo_f16 v170, v186, s39, 0                         // 0000001D0C20: CC2100AA 02004FBA
	v_fma_mixhi_f16 v170, v187, s39, 0                         // 0000001D0C28: CC2200AA 02004FBB
	v_fma_mixlo_f16 v171, v188, s39, 0                         // 0000001D0C30: CC2100AB 02004FBC
	v_fma_mixhi_f16 v171, v189, s39, 0                         // 0000001D0C38: CC2200AB 02004FBD
	v_fma_mixlo_f16 v172, v190, s39, 0                         // 0000001D0C40: CC2100AC 02004FBE
	v_fma_mixhi_f16 v172, v191, s39, 0                         // 0000001D0C48: CC2200AC 02004FBF
	v_fma_mixlo_f16 v173, v192, s39, 0                         // 0000001D0C50: CC2100AD 02004FC0
	v_fma_mixhi_f16 v173, v193, s39, 0                         // 0000001D0C58: CC2200AD 02004FC1
	ds_load_b128 v[174:177], v129 offset:320                   // 0000001D0C60: DBFC0140 AE000081
	ds_load_b128 v[178:181], v129 offset:336                   // 0000001D0C68: DBFC0150 B2000081
	ds_load_b128 v[182:185], v129 offset:352                   // 0000001D0C70: DBFC0160 B6000081
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[158:165], v[17:24]// 0000001D0C78: CC404011 1C473D39
	v_wmma_f32_16x16x16_f16 v[1:8], v[57:64], v[166:173], v[1:8]// 0000001D0C80: CC404001 1C074D39
	ds_load_b128 v[158:161], v129 offset:8816                  // 0000001D0C88: DBFC2270 9E000081
	ds_load_b128 v[162:165], v129 offset:17216                 // 0000001D0C90: DBFC4340 A2000081
	ds_load_b128 v[166:169], v129 offset:17232                 // 0000001D0C98: DBFC4350 A6000081
	s_waitcnt lgkmcnt(9)                                       // 0000001D0CA0: BF89FC97
	v_fma_mixhi_f16 v63, v74, s39, 0                           // 0000001D0CA4: CC22003F 02004F4A
	v_fma_mixlo_f16 v64, v75, s39, 0                           // 0000001D0CAC: CC210040 02004F4B
	v_fma_mixhi_f16 v64, v76, s39, 0                           // 0000001D0CB4: CC220040 02004F4C
	s_waitcnt lgkmcnt(8)                                       // 0000001D0CBC: BF89FC87
	v_fma_mixlo_f16 v74, v79, s39, 0                           // 0000001D0CC0: CC21004A 02004F4F
	v_fma_mixhi_f16 v74, v80, s39, 0                           // 0000001D0CC8: CC22004A 02004F50
	s_waitcnt lgkmcnt(7)                                       // 0000001D0CD0: BF89FC77
	v_fma_mixlo_f16 v75, v81, s39, 0                           // 0000001D0CD4: CC21004B 02004F51
	v_fma_mixhi_f16 v75, v82, s39, 0                           // 0000001D0CDC: CC22004B 02004F52
	v_fma_mixlo_f16 v76, v83, s39, 0                           // 0000001D0CE4: CC21004C 02004F53
	v_fma_mixhi_f16 v76, v84, s39, 0                           // 0000001D0CEC: CC22004C 02004F54
	ds_load_b128 v[170:173], v129 offset:17248                 // 0000001D0CF4: DBFC4360 AA000081
	v_fma_mixlo_f16 v63, v73, s39, 0                           // 0000001D0CFC: CC21003F 02004F49
	v_fma_mixlo_f16 v73, v77, s39, 0                           // 0000001D0D04: CC210049 02004F4D
	s_waitcnt lgkmcnt(6)                                       // 0000001D0D0C: BF89FC67
	v_fma_mixlo_f16 v57, v174, s39, 0                          // 0000001D0D10: CC210039 02004FAE
	v_fma_mixhi_f16 v57, v175, s39, 0                          // 0000001D0D18: CC220039 02004FAF
	v_fma_mixlo_f16 v58, v176, s39, 0                          // 0000001D0D20: CC21003A 02004FB0
	v_fma_mixhi_f16 v58, v177, s39, 0                          // 0000001D0D28: CC22003A 02004FB1
	s_waitcnt lgkmcnt(5)                                       // 0000001D0D30: BF89FC57
	v_fma_mixlo_f16 v59, v178, s39, 0                          // 0000001D0D34: CC21003B 02004FB2
	v_fma_mixhi_f16 v59, v179, s39, 0                          // 0000001D0D3C: CC22003B 02004FB3
	v_fma_mixlo_f16 v60, v180, s39, 0                          // 0000001D0D44: CC21003C 02004FB4
	v_fma_mixhi_f16 v60, v181, s39, 0                          // 0000001D0D4C: CC22003C 02004FB5
	s_waitcnt lgkmcnt(3)                                       // 0000001D0D54: BF89FC37
	v_fma_mixlo_f16 v79, v158, s39, 0                          // 0000001D0D58: CC21004F 02004F9E
	ds_load_b128 v[174:177], v129 offset:17264                 // 0000001D0D60: DBFC4370 AE000081
	v_fma_mixhi_f16 v79, v159, s39, 0                          // 0000001D0D68: CC22004F 02004F9F
	v_fma_mixlo_f16 v80, v160, s39, 0                          // 0000001D0D70: CC210050 02004FA0
	v_fma_mixhi_f16 v80, v161, s39, 0                          // 0000001D0D78: CC220050 02004FA1
	ds_load_b128 v[158:161], v129 offset:25664                 // 0000001D0D80: DBFC6440 9E000081
	ds_load_b128 v[178:181], v129 offset:25680                 // 0000001D0D88: DBFC6450 B2000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D0D90: BF89FC57
	v_fma_mixlo_f16 v81, v162, s39, 0                          // 0000001D0D94: CC210051 02004FA2
	v_fma_mixhi_f16 v81, v163, s39, 0                          // 0000001D0D9C: CC220051 02004FA3
	v_fma_mixlo_f16 v82, v164, s39, 0                          // 0000001D0DA4: CC210052 02004FA4
	v_fma_mixhi_f16 v82, v165, s39, 0                          // 0000001D0DAC: CC220052 02004FA5
	s_waitcnt lgkmcnt(4)                                       // 0000001D0DB4: BF89FC47
	v_fma_mixlo_f16 v83, v166, s39, 0                          // 0000001D0DB8: CC210053 02004FA6
	v_fma_mixhi_f16 v83, v167, s39, 0                          // 0000001D0DC0: CC220053 02004FA7
	v_fma_mixlo_f16 v84, v168, s39, 0                          // 0000001D0DC8: CC210054 02004FA8
	ds_load_b128 v[162:165], v129 offset:25696                 // 0000001D0DD0: DBFC6460 A2000081
	v_fma_mixhi_f16 v84, v169, s39, 0                          // 0000001D0DD8: CC220054 02004FA9
	ds_load_b128 v[166:169], v129 offset:25712                 // 0000001D0DE0: DBFC6470 A6000081
	v_fma_mixlo_f16 v61, v182, s39, 0                          // 0000001D0DE8: CC21003D 02004FB6
	v_fma_mixhi_f16 v61, v183, s39, 0                          // 0000001D0DF0: CC22003D 02004FB7
	v_fma_mixlo_f16 v62, v184, s39, 0                          // 0000001D0DF8: CC21003E 02004FB8
	v_fma_mixhi_f16 v62, v185, s39, 0                          // 0000001D0E00: CC22003E 02004FB9
	v_fma_mixhi_f16 v73, v78, s39, 0                           // 0000001D0E08: CC220049 02004F4E
	v_fma_mixlo_f16 v77, v85, s39, 0                           // 0000001D0E10: CC21004D 02004F55
	v_fma_mixhi_f16 v77, v86, s39, 0                           // 0000001D0E18: CC22004D 02004F56
	v_fma_mixlo_f16 v78, v87, s39, 0                           // 0000001D0E20: CC21004E 02004F57
	v_fma_mixhi_f16 v78, v88, s39, 0                           // 0000001D0E28: CC22004E 02004F58
	s_waitcnt lgkmcnt(5)                                       // 0000001D0E30: BF89FC57
	v_fma_mixlo_f16 v85, v170, s39, 0                          // 0000001D0E34: CC210055 02004FAA
	v_fma_mixhi_f16 v85, v171, s39, 0                          // 0000001D0E3C: CC220055 02004FAB
	v_fma_mixlo_f16 v86, v172, s39, 0                          // 0000001D0E44: CC210056 02004FAC
	v_fma_mixhi_f16 v86, v173, s39, 0                          // 0000001D0E4C: CC220056 02004FAD
	s_waitcnt lgkmcnt(4)                                       // 0000001D0E54: BF89FC47
	v_fma_mixlo_f16 v87, v174, s39, 0                          // 0000001D0E58: CC210057 02004FAE
	v_fma_mixhi_f16 v87, v175, s39, 0                          // 0000001D0E60: CC220057 02004FAF
	v_fma_mixlo_f16 v88, v176, s39, 0                          // 0000001D0E68: CC210058 02004FB0
	v_fma_mixhi_f16 v88, v177, s39, 0                          // 0000001D0E70: CC220058 02004FB1
	s_waitcnt lgkmcnt(3)                                       // 0000001D0E78: BF89FC37
	v_fma_mixlo_f16 v158, v158, s39, 0                         // 0000001D0E7C: CC21009E 02004F9E
	v_fma_mixhi_f16 v158, v159, s39, 0                         // 0000001D0E84: CC22009E 02004F9F
	v_fma_mixlo_f16 v159, v160, s39, 0                         // 0000001D0E8C: CC21009F 02004FA0
	v_fma_mixhi_f16 v159, v161, s39, 0                         // 0000001D0E94: CC22009F 02004FA1
	s_waitcnt lgkmcnt(2)                                       // 0000001D0E9C: BF89FC27
	v_fma_mixlo_f16 v160, v178, s39, 0                         // 0000001D0EA0: CC2100A0 02004FB2
	v_fma_mixhi_f16 v160, v179, s39, 0                         // 0000001D0EA8: CC2200A0 02004FB3
	v_fma_mixlo_f16 v161, v180, s39, 0                         // 0000001D0EB0: CC2100A1 02004FB4
	v_fma_mixhi_f16 v161, v181, s39, 0                         // 0000001D0EB8: CC2200A1 02004FB5
	s_waitcnt lgkmcnt(1)                                       // 0000001D0EC0: BF89FC17
	v_fma_mixlo_f16 v162, v162, s39, 0                         // 0000001D0EC4: CC2100A2 02004FA2
	v_fma_mixhi_f16 v162, v163, s39, 0                         // 0000001D0ECC: CC2200A2 02004FA3
	v_fma_mixlo_f16 v163, v164, s39, 0                         // 0000001D0ED4: CC2100A3 02004FA4
	v_fma_mixhi_f16 v163, v165, s39, 0                         // 0000001D0EDC: CC2200A3 02004FA5
	s_waitcnt lgkmcnt(0)                                       // 0000001D0EE4: BF89FC07
	v_fma_mixlo_f16 v164, v166, s39, 0                         // 0000001D0EE8: CC2100A4 02004FA6
	v_fma_mixhi_f16 v164, v167, s39, 0                         // 0000001D0EF0: CC2200A4 02004FA7
	v_fma_mixlo_f16 v165, v168, s39, 0                         // 0000001D0EF8: CC2100A5 02004FA8
	v_fma_mixhi_f16 v165, v169, s39, 0                         // 0000001D0F00: CC2200A5 02004FA9
	ds_load_b128 v[170:173], v129 offset:384                   // 0000001D0F08: DBFC0180 AA000081
	ds_load_b128 v[174:177], v129 offset:400                   // 0000001D0F10: DBFC0190 AE000081
	ds_load_b128 v[178:181], v129 offset:416                   // 0000001D0F18: DBFC01A0 B2000081
	s_waitcnt vmcnt(10)                                        // 0000001D0F20: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[57:64], v[25:32]// 0000001D0F24: CC404019 1C667331
	ds_load_b128 v[57:60], v129 offset:432                     // 0000001D0F2C: DBFC01B0 39000081
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[73:80], v[9:16]// 0000001D0F34: CC404009 1C269331
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[81:88], v[17:24]// 0000001D0F3C: CC404011 1C46A331
	v_wmma_f32_16x16x16_f16 v[1:8], v[49:56], v[158:165], v[1:8]// 0000001D0F44: CC404001 1C073D31
	ds_load_b128 v[61:64], v129 offset:8832                    // 0000001D0F4C: DBFC2280 3D000081
	ds_load_b128 v[73:76], v129 offset:8848                    // 0000001D0F54: DBFC2290 49000081
	ds_load_b128 v[77:80], v129 offset:8864                    // 0000001D0F5C: DBFC22A0 4D000081
	ds_load_b128 v[81:84], v129 offset:8880                    // 0000001D0F64: DBFC22B0 51000081
	ds_load_b128 v[85:88], v129 offset:17280                   // 0000001D0F6C: DBFC4380 55000081
	ds_load_b128 v[158:161], v129 offset:17296                 // 0000001D0F74: DBFC4390 9E000081
	ds_load_b128 v[162:165], v129 offset:17312                 // 0000001D0F7C: DBFC43A0 A2000081
	ds_load_b128 v[166:169], v129 offset:17328                 // 0000001D0F84: DBFC43B0 A6000081
	ds_load_b128 v[185:188], v129 offset:25840                 // 0000001D0F8C: DBFC64F0 B9000081
	s_waitcnt lgkmcnt(12)                                      // 0000001D0F94: BF89FCC7
	v_fma_mixlo_f16 v49, v170, s39, 0                          // 0000001D0F98: CC210031 02004FAA
	v_fma_mixhi_f16 v49, v171, s39, 0                          // 0000001D0FA0: CC220031 02004FAB
	v_fma_mixlo_f16 v50, v172, s39, 0                          // 0000001D0FA8: CC210032 02004FAC
	v_fma_mixhi_f16 v50, v173, s39, 0                          // 0000001D0FB0: CC220032 02004FAD
	s_waitcnt lgkmcnt(9)                                       // 0000001D0FB8: BF89FC97
	v_fma_mixhi_f16 v55, v58, s39, 0                           // 0000001D0FBC: CC220037 02004F3A
	v_fma_mixlo_f16 v56, v59, s39, 0                           // 0000001D0FC4: CC210038 02004F3B
	v_fma_mixhi_f16 v56, v60, s39, 0                           // 0000001D0FCC: CC220038 02004F3C
	ds_load_b128 v[170:173], v129 offset:25744                 // 0000001D0FD4: DBFC6490 AA000081
	s_waitcnt lgkmcnt(9)                                       // 0000001D0FDC: BF89FC97
	v_fma_mixlo_f16 v58, v63, s39, 0                           // 0000001D0FE0: CC21003A 02004F3F
	v_fma_mixhi_f16 v58, v64, s39, 0                           // 0000001D0FE8: CC22003A 02004F40
	s_waitcnt lgkmcnt(8)                                       // 0000001D0FF0: BF89FC87
	v_fma_mixlo_f16 v59, v73, s39, 0                           // 0000001D0FF4: CC21003B 02004F49
	v_fma_mixhi_f16 v59, v74, s39, 0                           // 0000001D0FFC: CC22003B 02004F4A
	v_fma_mixlo_f16 v60, v75, s39, 0                           // 0000001D1004: CC21003C 02004F4B
	v_fma_mixhi_f16 v60, v76, s39, 0                           // 0000001D100C: CC22003C 02004F4C
	s_waitcnt lgkmcnt(6)                                       // 0000001D1014: BF89FC67
	v_fma_mixlo_f16 v63, v81, s39, 0                           // 0000001D1018: CC21003F 02004F51
	v_fma_mixhi_f16 v63, v82, s39, 0                           // 0000001D1020: CC22003F 02004F52
	v_fma_mixlo_f16 v64, v83, s39, 0                           // 0000001D1028: CC210040 02004F53
	v_fma_mixhi_f16 v64, v84, s39, 0                           // 0000001D1030: CC220040 02004F54
	ds_load_b128 v[81:84], v129 offset:25728                   // 0000001D1038: DBFC6480 51000081
	s_waitcnt lgkmcnt(6)                                       // 0000001D1040: BF89FC67
	v_fma_mixlo_f16 v73, v85, s39, 0                           // 0000001D1044: CC210049 02004F55
	v_fma_mixhi_f16 v73, v86, s39, 0                           // 0000001D104C: CC220049 02004F56
	v_fma_mixlo_f16 v74, v87, s39, 0                           // 0000001D1054: CC21004A 02004F57
	v_fma_mixhi_f16 v74, v88, s39, 0                           // 0000001D105C: CC22004A 02004F58
	s_waitcnt lgkmcnt(5)                                       // 0000001D1064: BF89FC57
	v_fma_mixlo_f16 v75, v158, s39, 0                          // 0000001D1068: CC21004B 02004F9E
	v_fma_mixhi_f16 v75, v159, s39, 0                          // 0000001D1070: CC22004B 02004F9F
	v_fma_mixlo_f16 v76, v160, s39, 0                          // 0000001D1078: CC21004C 02004FA0
	ds_load_b128 v[85:88], v129 offset:25760                   // 0000001D1080: DBFC64A0 55000081
	v_fma_mixhi_f16 v76, v161, s39, 0                          // 0000001D1088: CC22004C 02004FA1
	ds_load_b128 v[158:161], v129 offset:25776                 // 0000001D1090: DBFC64B0 9E000081
	v_fma_mixlo_f16 v55, v57, s39, 0                           // 0000001D1098: CC210037 02004F39
	v_fma_mixlo_f16 v57, v61, s39, 0                           // 0000001D10A0: CC210039 02004F3D
	v_fma_mixlo_f16 v61, v77, s39, 0                           // 0000001D10A8: CC21003D 02004F4D
	v_fma_mixhi_f16 v61, v78, s39, 0                           // 0000001D10B0: CC22003D 02004F4E
	s_waitcnt lgkmcnt(6)                                       // 0000001D10B8: BF89FC67
	v_fma_mixlo_f16 v77, v162, s39, 0                          // 0000001D10BC: CC21004D 02004FA2
	v_fma_mixhi_f16 v77, v163, s39, 0                          // 0000001D10C4: CC22004D 02004FA3
	v_fma_mixlo_f16 v78, v164, s39, 0                          // 0000001D10CC: CC21004E 02004FA4
	v_fma_mixhi_f16 v78, v165, s39, 0                          // 0000001D10D4: CC22004E 02004FA5
	ds_load_b128 v[162:165], v129 offset:448                   // 0000001D10DC: DBFC01C0 A2000081
	s_waitcnt lgkmcnt(3)                                       // 0000001D10E4: BF89FC37
	v_fma_mixlo_f16 v81, v81, s39, 0                           // 0000001D10E8: CC210051 02004F51
	v_fma_mixhi_f16 v81, v82, s39, 0                           // 0000001D10F0: CC220051 02004F52
	v_fma_mixlo_f16 v82, v83, s39, 0                           // 0000001D10F8: CC210052 02004F53
	v_fma_mixhi_f16 v82, v84, s39, 0                           // 0000001D1100: CC220052 02004F54
	v_fma_mixlo_f16 v83, v170, s39, 0                          // 0000001D1108: CC210053 02004FAA
	v_fma_mixhi_f16 v83, v171, s39, 0                          // 0000001D1110: CC220053 02004FAB
	v_fma_mixlo_f16 v84, v172, s39, 0                          // 0000001D1118: CC210054 02004FAC
	v_fma_mixhi_f16 v84, v173, s39, 0                          // 0000001D1120: CC220054 02004FAD
	s_waitcnt lgkmcnt(2)                                       // 0000001D1128: BF89FC27
	v_fma_mixlo_f16 v85, v85, s39, 0                           // 0000001D112C: CC210055 02004F55
	v_fma_mixhi_f16 v85, v86, s39, 0                           // 0000001D1134: CC220055 02004F56
	v_fma_mixlo_f16 v86, v87, s39, 0                           // 0000001D113C: CC210056 02004F57
	v_fma_mixhi_f16 v86, v88, s39, 0                           // 0000001D1144: CC220056 02004F58
	s_waitcnt lgkmcnt(1)                                       // 0000001D114C: BF89FC17
	v_fma_mixlo_f16 v87, v158, s39, 0                          // 0000001D1150: CC210057 02004F9E
	ds_load_b128 v[170:173], v129 offset:480                   // 0000001D1158: DBFC01E0 AA000081
	v_fma_mixhi_f16 v87, v159, s39, 0                          // 0000001D1160: CC220057 02004F9F
	v_fma_mixlo_f16 v88, v160, s39, 0                          // 0000001D1168: CC210058 02004FA0
	v_fma_mixhi_f16 v88, v161, s39, 0                          // 0000001D1170: CC220058 02004FA1
	ds_load_b128 v[158:161], v129 offset:496                   // 0000001D1178: DBFC01F0 9E000081
	v_fma_mixlo_f16 v51, v174, s39, 0                          // 0000001D1180: CC210033 02004FAE
	v_fma_mixhi_f16 v51, v175, s39, 0                          // 0000001D1188: CC220033 02004FAF
	v_fma_mixlo_f16 v52, v176, s39, 0                          // 0000001D1190: CC210034 02004FB0
	v_fma_mixhi_f16 v52, v177, s39, 0                          // 0000001D1198: CC220034 02004FB1
	v_fma_mixlo_f16 v53, v178, s39, 0                          // 0000001D11A0: CC210035 02004FB2
	v_fma_mixhi_f16 v53, v179, s39, 0                          // 0000001D11A8: CC220035 02004FB3
	v_fma_mixlo_f16 v54, v180, s39, 0                          // 0000001D11B0: CC210036 02004FB4
	v_fma_mixhi_f16 v54, v181, s39, 0                          // 0000001D11B8: CC220036 02004FB5
	v_fma_mixhi_f16 v57, v62, s39, 0                           // 0000001D11C0: CC220039 02004F3E
	v_fma_mixlo_f16 v62, v79, s39, 0                           // 0000001D11C8: CC21003E 02004F4F
	v_fma_mixhi_f16 v62, v80, s39, 0                           // 0000001D11D0: CC22003E 02004F50
	v_fma_mixlo_f16 v79, v166, s39, 0                          // 0000001D11D8: CC21004F 02004FA6
	v_fma_mixhi_f16 v79, v167, s39, 0                          // 0000001D11E0: CC22004F 02004FA7
	v_fma_mixlo_f16 v80, v168, s39, 0                          // 0000001D11E8: CC210050 02004FA8
	v_fma_mixhi_f16 v80, v169, s39, 0                          // 0000001D11F0: CC220050 02004FA9
	ds_load_b128 v[166:169], v129 offset:464                   // 0000001D11F8: DBFC01D0 A6000081
	s_waitcnt vmcnt(8)                                         // 0000001D1200: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[49:56], v[25:32]// 0000001D1204: CC404019 1C666329
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[57:64], v[9:16]// 0000001D120C: CC404009 1C267329
	v_wmma_f32_16x16x16_f16 v[1:8], v[41:48], v[81:88], v[1:8] // 0000001D1214: CC404001 1C06A329
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[73:80], v[17:24]// 0000001D121C: CC404011 1C469329
	ds_load_b128 v[49:52], v129 offset:8896                    // 0000001D1224: DBFC22C0 31000081
	ds_load_b128 v[53:56], v129 offset:8912                    // 0000001D122C: DBFC22D0 35000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D1234: BF89FC57
	v_fma_mixlo_f16 v41, v162, s39, 0                          // 0000001D1238: CC210029 02004FA2
	v_fma_mixhi_f16 v41, v163, s39, 0                          // 0000001D1240: CC220029 02004FA3
	v_fma_mixlo_f16 v42, v164, s39, 0                          // 0000001D1248: CC21002A 02004FA4
	v_fma_mixhi_f16 v42, v165, s39, 0                          // 0000001D1250: CC22002A 02004FA5
	ds_load_b128 v[57:60], v129 offset:8928                    // 0000001D1258: DBFC22E0 39000081
	ds_load_b128 v[61:64], v129 offset:8944                    // 0000001D1260: DBFC22F0 3D000081
	s_waitcnt lgkmcnt(5)                                       // 0000001D1268: BF89FC57
	v_fma_mixlo_f16 v47, v158, s39, 0                          // 0000001D126C: CC21002F 02004F9E
	v_fma_mixhi_f16 v47, v159, s39, 0                          // 0000001D1274: CC22002F 02004F9F
	v_fma_mixlo_f16 v48, v160, s39, 0                          // 0000001D127C: CC210030 02004FA0
	v_fma_mixhi_f16 v48, v161, s39, 0                          // 0000001D1284: CC220030 02004FA1
	ds_load_b128 v[73:76], v129 offset:17344                   // 0000001D128C: DBFC43C0 49000081
	ds_load_b128 v[77:80], v129 offset:17360                   // 0000001D1294: DBFC43D0 4D000081
	ds_load_b128 v[81:84], v129 offset:17376                   // 0000001D129C: DBFC43E0 51000081
	ds_load_b128 v[85:88], v129 offset:17392                   // 0000001D12A4: DBFC43F0 55000081
	ds_load_b128 v[158:161], v129 offset:25792                 // 0000001D12AC: DBFC64C0 9E000081
	ds_load_b128 v[162:165], v129 offset:25808                 // 0000001D12B4: DBFC64D0 A2000081
	ds_load_b128 v[181:184], v129 offset:25824                 // 0000001D12BC: DBFC64E0 B5000081
	s_waitcnt lgkmcnt(11)                                      // 0000001D12C4: BF89FCB7
	v_fma_mixlo_f16 v43, v166, s39, 0                          // 0000001D12C8: CC21002B 02004FA6
	v_fma_mixhi_f16 v43, v167, s39, 0                          // 0000001D12D0: CC22002B 02004FA7
	v_fma_mixlo_f16 v44, v168, s39, 0                          // 0000001D12D8: CC21002C 02004FA8
	v_fma_mixhi_f16 v44, v169, s39, 0                          // 0000001D12E0: CC22002C 02004FA9
	v_fma_mixlo_f16 v45, v170, s39, 0                          // 0000001D12E8: CC21002D 02004FAA
	v_fma_mixhi_f16 v45, v171, s39, 0                          // 0000001D12F0: CC22002D 02004FAB
	v_fma_mixlo_f16 v46, v172, s39, 0                          // 0000001D12F8: CC21002E 02004FAC
	v_fma_mixhi_f16 v46, v173, s39, 0                          // 0000001D1300: CC22002E 02004FAD
	s_waitcnt lgkmcnt(10)                                      // 0000001D1308: BF89FCA7
	v_fma_mixlo_f16 v49, v49, s39, 0                           // 0000001D130C: CC210031 02004F31
	v_fma_mixhi_f16 v49, v50, s39, 0                           // 0000001D1314: CC220031 02004F32
	v_fma_mixlo_f16 v50, v51, s39, 0                           // 0000001D131C: CC210032 02004F33
	v_fma_mixhi_f16 v50, v52, s39, 0                           // 0000001D1324: CC220032 02004F34
	s_waitcnt lgkmcnt(9)                                       // 0000001D132C: BF89FC97
	v_fma_mixlo_f16 v51, v53, s39, 0                           // 0000001D1330: CC210033 02004F35
	v_fma_mixhi_f16 v51, v54, s39, 0                           // 0000001D1338: CC220033 02004F36
	v_fma_mixlo_f16 v52, v55, s39, 0                           // 0000001D1340: CC210034 02004F37
	v_fma_mixhi_f16 v52, v56, s39, 0                           // 0000001D1348: CC220034 02004F38
	s_waitcnt lgkmcnt(8)                                       // 0000001D1350: BF89FC87
	v_fma_mixlo_f16 v53, v57, s39, 0                           // 0000001D1354: CC210035 02004F39
	v_fma_mixhi_f16 v53, v58, s39, 0                           // 0000001D135C: CC220035 02004F3A
	v_fma_mixlo_f16 v54, v59, s39, 0                           // 0000001D1364: CC210036 02004F3B
	s_waitcnt lgkmcnt(7)                                       // 0000001D136C: BF89FC77
	v_fma_mixlo_f16 v55, v61, s39, 0                           // 0000001D1370: CC210037 02004F3D
	v_fma_mixhi_f16 v55, v62, s39, 0                           // 0000001D1378: CC220037 02004F3E
	v_fma_mixlo_f16 v56, v63, s39, 0                           // 0000001D1380: CC210038 02004F3F
	v_fma_mixhi_f16 v56, v64, s39, 0                           // 0000001D1388: CC220038 02004F40
	s_waitcnt lgkmcnt(6)                                       // 0000001D1390: BF89FC67
	v_fma_mixlo_f16 v57, v73, s39, 0                           // 0000001D1394: CC210039 02004F49
	v_fma_mixhi_f16 v57, v74, s39, 0                           // 0000001D139C: CC220039 02004F4A
	v_fma_mixlo_f16 v58, v75, s39, 0                           // 0000001D13A4: CC21003A 02004F4B
	v_fma_mixhi_f16 v58, v76, s39, 0                           // 0000001D13AC: CC22003A 02004F4C
	s_waitcnt lgkmcnt(5)                                       // 0000001D13B4: BF89FC57
	v_fma_mixlo_f16 v59, v77, s39, 0                           // 0000001D13B8: CC21003B 02004F4D
	s_waitcnt lgkmcnt(4)                                       // 0000001D13C0: BF89FC47
	v_fma_mixlo_f16 v61, v81, s39, 0                           // 0000001D13C4: CC21003D 02004F51
	v_fma_mixhi_f16 v61, v82, s39, 0                           // 0000001D13CC: CC22003D 02004F52
	v_fma_mixlo_f16 v62, v83, s39, 0                           // 0000001D13D4: CC21003E 02004F53
	v_fma_mixhi_f16 v62, v84, s39, 0                           // 0000001D13DC: CC22003E 02004F54
	s_waitcnt lgkmcnt(3)                                       // 0000001D13E4: BF89FC37
	v_fma_mixlo_f16 v63, v85, s39, 0                           // 0000001D13E8: CC21003F 02004F55
	v_fma_mixhi_f16 v63, v86, s39, 0                           // 0000001D13F0: CC22003F 02004F56
	v_fma_mixlo_f16 v64, v87, s39, 0                           // 0000001D13F8: CC210040 02004F57
	v_fma_mixhi_f16 v64, v88, s39, 0                           // 0000001D1400: CC220040 02004F58
	s_waitcnt lgkmcnt(2)                                       // 0000001D1408: BF89FC27
	v_fma_mixlo_f16 v73, v158, s39, 0                          // 0000001D140C: CC210049 02004F9E
	v_fma_mixhi_f16 v73, v159, s39, 0                          // 0000001D1414: CC220049 02004F9F
	v_fma_mixlo_f16 v74, v160, s39, 0                          // 0000001D141C: CC21004A 02004FA0
	v_fma_mixhi_f16 v74, v161, s39, 0                          // 0000001D1424: CC22004A 02004FA1
	s_waitcnt lgkmcnt(1)                                       // 0000001D142C: BF89FC17
	v_fma_mixlo_f16 v75, v162, s39, 0                          // 0000001D1430: CC21004B 02004FA2
	v_fma_mixhi_f16 v75, v163, s39, 0                          // 0000001D1438: CC22004B 02004FA3
	v_fma_mixlo_f16 v76, v164, s39, 0                          // 0000001D1440: CC21004C 02004FA4
	v_fma_mixhi_f16 v76, v165, s39, 0                          // 0000001D1448: CC22004C 02004FA5
	s_waitcnt lgkmcnt(0)                                       // 0000001D1450: BF89FC07
	v_fma_mixlo_f16 v77, v181, s39, 0                          // 0000001D1454: CC21004D 02004FB5
	ds_load_b128 v[81:84], v130                                // 0000001D145C: DBFC0000 51000082
	ds_load_b128 v[85:88], v130 offset:16                      // 0000001D1464: DBFC0010 55000082
	ds_load_b128 v[162:165], v130 offset:2320                  // 0000001D146C: DBFC0910 A2000082
	ds_load_b128 v[158:161], v130 offset:2304                  // 0000001D1474: DBFC0900 9E000082
	ds_load_b128 v[170:173], v130 offset:4624                  // 0000001D147C: DBFC1210 AA000082
	ds_load_b128 v[166:169], v130 offset:4608                  // 0000001D1484: DBFC1200 A6000082
	ds_load_b128 v[178:181], v130 offset:6928                  // 0000001D148C: DBFC1B10 B2000082
	ds_load_b128 v[174:177], v130 offset:6912                  // 0000001D1494: DBFC1B00 AE000082
	v_fma_mixhi_f16 v54, v60, s39, 0                           // 0000001D149C: CC220036 02004F3C
	v_fma_mixhi_f16 v59, v78, s39, 0                           // 0000001D14A4: CC22003B 02004F4E
	v_fma_mixlo_f16 v60, v79, s39, 0                           // 0000001D14AC: CC21003C 02004F4F
	v_fma_mixhi_f16 v60, v80, s39, 0                           // 0000001D14B4: CC22003C 02004F50
	v_fma_mixhi_f16 v77, v182, s39, 0                          // 0000001D14BC: CC22004D 02004FB6
	v_fma_mixlo_f16 v78, v183, s39, 0                          // 0000001D14C4: CC21004E 02004FB7
	v_fma_mixhi_f16 v78, v184, s39, 0                          // 0000001D14CC: CC22004E 02004FB8
	v_fma_mixlo_f16 v79, v185, s39, 0                          // 0000001D14D4: CC21004F 02004FB9
	v_fma_mixhi_f16 v79, v186, s39, 0                          // 0000001D14DC: CC22004F 02004FBA
	v_fma_mixlo_f16 v80, v187, s39, 0                          // 0000001D14E4: CC210050 02004FBB
	v_fma_mixhi_f16 v80, v188, s39, 0                          // 0000001D14EC: CC220050 02004FBC
	s_waitcnt vmcnt(6)                                         // 0000001D14F4: BF891BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[41:48], v[25:32]// 0000001D14F8: CC404019 1C665321
	v_wmma_f32_16x16x16_f16 v[9:16], v[33:40], v[49:56], v[9:16]// 0000001D1500: CC404009 1C266321
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 0000001D1508: CC404011 1C467321
	s_waitcnt vmcnt(4) lgkmcnt(6)                              // 0000001D1510: BF891067
	v_wmma_f32_16x16x16_f16 v[57:64], v[150:157], v[81:88], v[65:72]// 0000001D1514: CC404039 1D06A396
	v_wmma_f32_16x16x16_f16 v[1:8], v[33:40], v[73:80], v[1:8] // 0000001D151C: CC404001 1C069321
	s_waitcnt lgkmcnt(4)                                       // 0000001D1524: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[150:157], v[158:165], v[65:72]// 0000001D1528: CC404031 1D073D96
	s_waitcnt lgkmcnt(2)                                       // 0000001D1530: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[150:157], v[166:173], v[65:72]// 0000001D1534: CC404029 1D074D96
	s_waitcnt lgkmcnt(0)                                       // 0000001D153C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[150:157], v[174:181], v[65:72]// 0000001D1540: CC404021 1D075D96
	s_and_saveexec_b32 s14, s6                                 // 0000001D1548: BE8E2006
	s_cbranch_execnz 1208                                      // 0000001D154C: BFA604B8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6630>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1550: 8C7E0E7E
	s_and_saveexec_b32 s14, s5                                 // 0000001D1554: BE8E2005
	s_cbranch_execnz 1241                                      // 0000001D1558: BFA604D9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66c0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D155C: 8C7E0E7E
	s_and_saveexec_b32 s14, s7                                 // 0000001D1560: BE8E2007
	s_cbranch_execz 30                                         // 0000001D1564: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x53e0>
	ds_load_b128 v[65:68], v130 offset:96                      // 0000001D1568: DBFC0060 41000082
	ds_load_b128 v[69:72], v130 offset:112                     // 0000001D1570: DBFC0070 45000082
	ds_load_b128 v[77:80], v130 offset:2416                    // 0000001D1578: DBFC0970 4D000082
	ds_load_b128 v[73:76], v130 offset:2400                    // 0000001D1580: DBFC0960 49000082
	ds_load_b128 v[85:88], v130 offset:4720                    // 0000001D1588: DBFC1270 55000082
	ds_load_b128 v[81:84], v130 offset:4704                    // 0000001D1590: DBFC1260 51000082
	s_waitcnt vmcnt(3)                                         // 0000001D1598: BF890FF7
	ds_load_b128 v[101:104], v130 offset:7024                  // 0000001D159C: DBFC1B70 65000082
	s_waitcnt vmcnt(2)                                         // 0000001D15A4: BF890BF7
	ds_load_b128 v[97:100], v130 offset:7008                   // 0000001D15A8: DBFC1B60 61000082
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001D15B0: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[89:96], v[65:72], v[57:64]// 0000001D15B4: CC404039 1CE68359
	s_waitcnt lgkmcnt(4)                                       // 0000001D15BC: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[89:96], v[73:80], v[49:56]// 0000001D15C0: CC404031 1CC69359
	s_waitcnt lgkmcnt(2)                                       // 0000001D15C8: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[81:88], v[41:48]// 0000001D15CC: CC404029 1CA6A359
	s_waitcnt lgkmcnt(0)                                       // 0000001D15D4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[89:96], v[97:104], v[33:40]// 0000001D15D8: CC404021 1C86C359
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D15E0: 8C7E0E7E
	s_add_i32 s42, s42, 64                                     // 0000001D15E4: 812AC02A
	s_mov_b32 s14, -1                                          // 0000001D15E8: BE8E00C1
	s_cmp_le_i32 s42, s50                                      // 0000001D15EC: BF05322A
	s_cbranch_scc0 392                                         // 0000001D15F0: BFA10188 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a14>
	ds_load_2addr_b32 v[65:66], v141 offset1:2                 // 0000001D15F4: D8DC0200 4100008D
	ds_load_2addr_b32 v[67:68], v141 offset0:4 offset1:6       // 0000001D15FC: D8DC0604 4300008D
	ds_load_2addr_b32 v[69:70], v141 offset0:8 offset1:10      // 0000001D1604: D8DC0A08 4500008D
	ds_load_2addr_b32 v[71:72], v141 offset0:12 offset1:14     // 0000001D160C: D8DC0E0C 4700008D
	v_mad_u64_u32 v[73:74], null, 0x3000, v142, v[108:109]     // 0000001D1614: D6FE7C49 05B31CFF 00003000
	v_mad_u64_u32 v[75:76], null, 0x3000, v149, v[108:109]     // 0000001D1620: D6FE7C4B 05B32AFF 00003000
	v_mad_u64_u32 v[77:78], null, 0x3000, v148, v[108:109]     // 0000001D162C: D6FE7C4D 05B328FF 00003000
	v_mad_u64_u32 v[79:80], null, 0x3000, v147, v[108:109]     // 0000001D1638: D6FE7C4F 05B326FF 00003000
	s_mov_b32 s14, 0                                           // 0000001D1644: BE8E0080
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000001D1648: BF890437
	v_fma_f32 v96, v9, v65, v49                                // 0000001D164C: D6130060 04C68309
	v_fma_f32 v97, v10, v66, v50                               // 0000001D1654: D6130061 04CA850A
	s_waitcnt lgkmcnt(2)                                       // 0000001D165C: BF89FC27
	v_fma_f32 v98, v11, v67, v51                               // 0000001D1660: D6130062 04CE870B
	v_fma_f32 v100, v12, v68, v52                              // 0000001D1668: D6130064 04D2890C
	s_waitcnt lgkmcnt(1)                                       // 0000001D1670: BF89FC17
	v_fma_f32 v104, v13, v69, v53                              // 0000001D1674: D6130068 04D68B0D
	v_dual_mul_f32 v96, 0x3b800000, v96 :: v_dual_mul_f32 v97, 0x3b800000, v97// 0000001D167C: C8C6C0FF 6060C2FF 3B800000
	v_mul_f32_e32 v98, 0x3b800000, v98                         // 0000001D1688: 10C4C4FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 0000001D1690: BF89FC07
	v_fma_f32 v105, v16, v72, v56                              // 0000001D1694: D6130069 04E29110
	v_mul_f32_e32 v100, 0x3b800000, v100                       // 0000001D169C: 10C8C8FF 3B800000
	v_bfe_u32 v101, v96, 16, 1                                 // 0000001D16A4: D6100065 02052160
	v_bfe_u32 v102, v97, 16, 1                                 // 0000001D16AC: D6100066 02052161
	v_bfe_u32 v103, v98, 16, 1                                 // 0000001D16B4: D6100067 02052162
	v_mul_f32_e32 v105, 0x3b800000, v105                       // 0000001D16BC: 10D2D2FF 3B800000
	v_fma_f32 v151, v18, v66, v42                              // 0000001D16C4: D6130097 04AA8512
	v_add3_u32 v96, v96, v101, 0x7fff                          // 0000001D16CC: D6550060 03FECB60 00007FFF
	v_add3_u32 v97, v97, v102, 0x7fff                          // 0000001D16D8: D6550061 03FECD61 00007FFF
	v_add3_u32 v98, v98, v103, 0x7fff                          // 0000001D16E4: D6550062 03FECF62 00007FFF
	v_bfe_u32 v101, v100, 16, 1                                // 0000001D16F0: D6100065 02052164
	v_mul_f32_e32 v102, 0x3b800000, v104                       // 0000001D16F8: 10CCD0FF 3B800000
	v_fma_f32 v103, v14, v70, v54                              // 0000001D1700: D6130067 04DA8D0E
	v_fma_f32 v104, v15, v71, v55                              // 0000001D1708: D6130068 04DE8F0F
	v_fma_f32 v116, v17, v65, v41                              // 0000001D1710: D6130074 04A68311
	v_add3_u32 v100, v100, v101, 0x7fff                        // 0000001D1718: D6550064 03FECB64 00007FFF
	v_bfe_u32 v101, v102, 16, 1                                // 0000001D1724: D6100065 02052166
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D172C: BF870234
	v_dual_mul_f32 v103, 0x3b800000, v103 :: v_dual_mul_f32 v104, 0x3b800000, v104// 0000001D1730: C8C6CEFF 6768D0FF 3B800000
	v_bfe_u32 v150, v105, 16, 1                                // 0000001D173C: D6100096 02052169
	v_fma_f32 v153, v22, v70, v46                              // 0000001D1744: D6130099 04BA8D16
	v_add3_u32 v101, v102, v101, 0x7fff                        // 0000001D174C: D6550065 03FECB66 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D1758: BF870224
	v_bfe_u32 v102, v103, 16, 1                                // 0000001D175C: D6100066 02052167
	v_bfe_u32 v117, v104, 16, 1                                // 0000001D1764: D6100075 02052168
	v_dual_mul_f32 v116, 0x3b800000, v116 :: v_dual_mul_f32 v153, 0x3b800000, v153// 0000001D176C: C8C6E8FF 749932FF 3B800000
	v_fma_f32 v152, v21, v69, v45                              // 0000001D1778: D6130098 04B68B15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D1780: BF870214
	v_add3_u32 v102, v103, v102, 0x7fff                        // 0000001D1784: D6550066 03FECD67 00007FFF
	v_add3_u32 v103, v104, v117, 0x7fff                        // 0000001D1790: D6550067 03FEEB68 00007FFF
	v_add3_u32 v104, v105, v150, 0x7fff                        // 0000001D179C: D6550068 03FF2D69 00007FFF
	v_bfe_u32 v105, v116, 16, 1                                // 0000001D17A8: D6100069 02052174
	v_mul_f32_e32 v117, 0x3b800000, v151                       // 0000001D17B0: 10EB2EFF 3B800000
	v_fma_f32 v150, v19, v67, v43                              // 0000001D17B8: D6130096 04AE8713
	v_fma_f32 v151, v20, v68, v44                              // 0000001D17C0: D6130097 04B28914
	v_fma_f32 v81, v25, v65, v57                               // 0000001D17C8: D6130051 04E68319
	v_add3_u32 v105, v116, v105, 0x7fff                        // 0000001D17D0: D6550069 03FED374 00007FFF
	v_bfe_u32 v116, v117, 16, 1                                // 0000001D17DC: D6100074 02052175
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D17E4: BF870234
	v_dual_mul_f32 v150, 0x3b800000, v150 :: v_dual_mul_f32 v151, 0x3b800000, v151// 0000001D17E8: C8C72CFF 96972EFF 3B800000
	v_fma_f32 v65, v1, v65, v33                                // 0000001D17F4: D6130041 04868301
	v_mul_f32_e32 v152, 0x3b800000, v152                       // 0000001D17FC: 113130FF 3B800000
	v_add3_u32 v116, v117, v116, 0x7fff                        // 0000001D1804: D6550074 03FEE975 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D1810: BF870004
	v_bfe_u32 v117, v150, 16, 1                                // 0000001D1814: D6100075 02052196
	v_bfe_u32 v154, v151, 16, 1                                // 0000001D181C: D610009A 02052197
	v_fma_f32 v156, v23, v71, v47                              // 0000001D1824: D613009C 04BE8F17
	v_mul_f32_e32 v65, 0x3b800000, v65                         // 0000001D182C: 108282FF 3B800000
	v_bfe_u32 v155, v152, 16, 1                                // 0000001D1834: D610009B 02052198
	v_fma_f32 v83, v27, v67, v59                               // 0000001D183C: D6130053 04EE871B
	v_add3_u32 v117, v150, v117, 0x7fff                        // 0000001D1844: D6550075 03FEEB96 00007FFF
	v_add3_u32 v150, v151, v154, 0x7fff                        // 0000001D1850: D6550096 03FF3597 00007FFF
	v_fma_f32 v67, v3, v67, v35                                // 0000001D185C: D6130043 048E8703
	v_add3_u32 v151, v152, v155, 0x7fff                        // 0000001D1864: D6550097 03FF3798 00007FFF
	v_bfe_u32 v152, v153, 16, 1                                // 0000001D1870: D6100098 02052199
	v_mul_f32_e32 v154, 0x3b800000, v156                       // 0000001D1878: 113538FF 3B800000
	v_fma_f32 v155, v24, v72, v48                              // 0000001D1880: D613009B 04C29118
	v_fma_f32 v82, v26, v66, v58                               // 0000001D1888: D6130052 04EA851A
	v_fma_f32 v66, v2, v66, v34                                // 0000001D1890: D6130042 048A8502
	v_mul_f32_e32 v81, 0x3b800000, v81                         // 0000001D1898: 10A2A2FF 3B800000
	v_add3_u32 v152, v153, v152, 0x7fff                        // 0000001D18A0: D6550098 03FF3199 00007FFF
	v_mul_f32_e32 v155, 0x3b800000, v155                       // 0000001D18AC: 113736FF 3B800000
	v_mul_f32_e32 v67, 0x3b800000, v67                         // 0000001D18B4: 108686FF 3B800000
	v_bfe_u32 v153, v154, 16, 1                                // 0000001D18BC: D6100099 0205219A
	v_mul_f32_e32 v82, 0x3b800000, v82                         // 0000001D18C4: 10A4A4FF 3B800000
	v_fma_f32 v85, v29, v69, v61                               // 0000001D18CC: D6130055 04F68B1D
	v_fma_f32 v69, v5, v69, v37                                // 0000001D18D4: D6130045 04968B05
	v_mul_f32_e32 v66, 0x3b800000, v66                         // 0000001D18DC: 108484FF 3B800000
	v_fma_f32 v84, v28, v68, v60                               // 0000001D18E4: D6130054 04F2891C
	v_fma_f32 v87, v31, v71, v63                               // 0000001D18EC: D6130057 04FE8F1F
	s_waitcnt vmcnt(0)                                         // 0000001D18F4: BF8903F7
	v_bfe_u32 v89, v81, 16, 1                                  // 0000001D18F8: D6100059 02052151
	v_add3_u32 v153, v154, v153, 0x7fff                        // 0000001D1900: D6550099 03FF339A 00007FFF
	v_bfe_u32 v154, v155, 16, 1                                // 0000001D190C: D610009A 0205219B
	v_fma_f32 v68, v4, v68, v36                                // 0000001D1914: D6130044 04928904
	v_fma_f32 v86, v30, v70, v62                               // 0000001D191C: D6130056 04FA8D1E
	v_bfe_u32 v90, v82, 16, 1                                  // 0000001D1924: D610005A 02052152
	v_bfe_u32 v156, v65, 16, 1                                 // 0000001D192C: D610009C 02052141
	v_bfe_u32 v157, v66, 16, 1                                 // 0000001D1934: D610009D 02052142
	v_fma_f32 v88, v32, v72, v64                               // 0000001D193C: D6130058 05029120
	v_dual_mul_f32 v83, 0x3b800000, v83 :: v_dual_mul_f32 v84, 0x3b800000, v84// 0000001D1944: C8C6A6FF 5354A8FF 3B800000
	v_mul_f32_e32 v87, 0x3b800000, v87                         // 0000001D1950: 10AEAEFF 3B800000
	v_add3_u32 v89, v81, v89, 0x7fff                           // 0000001D1958: D6550059 03FEB351 00007FFF
	v_add3_u32 v154, v155, v154, 0x7fff                        // 0000001D1964: D655009A 03FF359B 00007FFF
	v_bfe_u32 v155, v67, 16, 1                                 // 0000001D1970: D610009B 02052143
	v_fma_f32 v70, v6, v70, v38                                // 0000001D1978: D6130046 049A8D06
	v_dual_mul_f32 v68, 0x3b800000, v68 :: v_dual_mul_f32 v85, 0x3b800000, v85// 0000001D1980: C8C688FF 4454AAFF 3B800000
	v_mul_f32_e32 v86, 0x3b800000, v86                         // 0000001D198C: 10ACACFF 3B800000
	v_add3_u32 v90, v82, v90, 0x7fff                           // 0000001D1994: D655005A 03FEB552 00007FFF
	v_add3_u32 v65, v65, v156, 0x7fff                          // 0000001D19A0: D6550041 03FF3941 00007FFF
	v_add3_u32 v66, v66, v157, 0x7fff                          // 0000001D19AC: D6550042 03FF3B42 00007FFF
	v_mul_f32_e32 v88, 0x3b800000, v88                         // 0000001D19B8: 10B0B0FF 3B800000
	v_bfe_u32 v91, v83, 16, 1                                  // 0000001D19C0: D610005B 02052153
	v_bfe_u32 v95, v87, 16, 1                                  // 0000001D19C8: D610005F 02052157
	s_clause 0x7                                               // 0000001D19D0: BF850007
	global_store_d16_hi_b16 v[73:74], v89, off                 // 0000001D19D4: DC960000 007C5949
	global_store_d16_hi_b16 v[73:74], v96, off offset:32       // 0000001D19DC: DC960020 007C6049
	global_store_d16_hi_b16 v[73:74], v105, off offset:64      // 0000001D19E4: DC960040 007C6949
	global_store_d16_hi_b16 v[75:76], v90, off                 // 0000001D19EC: DC960000 007C5A4B
	global_store_d16_hi_b16 v[75:76], v97, off offset:32       // 0000001D19F4: DC960020 007C614B
	global_store_d16_hi_b16 v[75:76], v116, off offset:64      // 0000001D19FC: DC960040 007C744B
	global_store_d16_hi_b16 v[73:74], v65, off offset:96       // 0000001D1A04: DC960060 007C4149
	global_store_d16_hi_b16 v[75:76], v66, off offset:96       // 0000001D1A0C: DC960060 007C424B
	v_add3_u32 v65, v67, v155, 0x7fff                          // 0000001D1A14: D6550041 03FF3743 00007FFF
	v_mul_f32_e32 v67, 0x3b800000, v69                         // 0000001D1A20: 10868AFF 3B800000
	v_mul_f32_e32 v69, 0x3b800000, v70                         // 0000001D1A28: 108A8CFF 3B800000
	v_bfe_u32 v66, v68, 16, 1                                  // 0000001D1A30: D6100042 02052144
	v_fma_f32 v70, v7, v71, v39                                // 0000001D1A38: D6130046 049E8F07
	v_fma_f32 v71, v8, v72, v40                                // 0000001D1A40: D6130047 04A29108
	v_bfe_u32 v93, v85, 16, 1                                  // 0000001D1A48: D610005D 02052155
	v_bfe_u32 v94, v86, 16, 1                                  // 0000001D1A50: D610005E 02052156
	v_bfe_u32 v92, v84, 16, 1                                  // 0000001D1A58: D610005C 02052154
	v_add3_u32 v91, v83, v91, 0x7fff                           // 0000001D1A60: D655005B 03FEB753 00007FFF
	v_add3_u32 v95, v87, v95, 0x7fff                           // 0000001D1A6C: D655005F 03FEBF57 00007FFF
	v_bfe_u32 v87, v88, 16, 1                                  // 0000001D1A78: D6100057 02052158
	v_add3_u32 v66, v68, v66, 0x7fff                           // 0000001D1A80: D6550042 03FE8544 00007FFF
	v_bfe_u32 v68, v67, 16, 1                                  // 0000001D1A8C: D6100044 02052143
	v_dual_mul_f32 v70, 0x3b800000, v70 :: v_dual_mul_f32 v71, 0x3b800000, v71// 0000001D1A94: C8C68CFF 46468EFF 3B800000
	v_add3_u32 v93, v85, v93, 0x7fff                           // 0000001D1AA0: D655005D 03FEBB55 00007FFF
	v_mad_u64_u32 v[81:82], null, 0x3000, v146, v[108:109]     // 0000001D1AAC: D6FE7C51 05B324FF 00003000
	v_add3_u32 v94, v86, v94, 0x7fff                           // 0000001D1AB8: D655005E 03FEBD56 00007FFF
	v_mad_u64_u32 v[85:86], null, 0x3000, v144, v[108:109]     // 0000001D1AC4: D6FE7C55 05B320FF 00003000
	v_add3_u32 v92, v84, v92, 0x7fff                           // 0000001D1AD0: D655005C 03FEB954 00007FFF
	v_bfe_u32 v72, v69, 16, 1                                  // 0000001D1ADC: D6100048 02052145
	v_mad_u64_u32 v[83:84], null, 0x3000, v145, v[108:109]     // 0000001D1AE4: D6FE7C53 05B322FF 00003000
	v_add3_u32 v99, v88, v87, 0x7fff                           // 0000001D1AF0: D6550063 03FEAF58 00007FFF
	v_mad_u64_u32 v[87:88], null, 0x3000, v143, v[108:109]     // 0000001D1AFC: D6FE7C57 05B31EFF 00003000
	s_clause 0x7                                               // 0000001D1B08: BF850007
	global_store_d16_hi_b16 v[77:78], v91, off                 // 0000001D1B0C: DC960000 007C5B4D
	global_store_d16_hi_b16 v[77:78], v98, off offset:32       // 0000001D1B14: DC960020 007C624D
	global_store_d16_hi_b16 v[77:78], v117, off offset:64      // 0000001D1B1C: DC960040 007C754D
	global_store_d16_hi_b16 v[79:80], v92, off                 // 0000001D1B24: DC960000 007C5C4F
	global_store_d16_hi_b16 v[79:80], v100, off offset:32      // 0000001D1B2C: DC960020 007C644F
	global_store_d16_hi_b16 v[79:80], v150, off offset:64      // 0000001D1B34: DC960040 007C964F
	global_store_d16_hi_b16 v[77:78], v65, off offset:96       // 0000001D1B3C: DC960060 007C414D
	global_store_d16_hi_b16 v[79:80], v66, off offset:96       // 0000001D1B44: DC960060 007C424F
	v_add3_u32 v65, v67, v68, 0x7fff                           // 0000001D1B4C: D6550041 03FE8943 00007FFF
	v_bfe_u32 v67, v70, 16, 1                                  // 0000001D1B58: D6100043 02052146
	v_bfe_u32 v68, v71, 16, 1                                  // 0000001D1B60: D6100044 02052147
	v_add3_u32 v66, v69, v72, 0x7fff                           // 0000001D1B68: D6550042 03FE9145 00007FFF
	s_clause 0x7                                               // 0000001D1B74: BF850007
	global_store_d16_hi_b16 v[81:82], v93, off                 // 0000001D1B78: DC960000 007C5D51
	global_store_d16_hi_b16 v[81:82], v101, off offset:32      // 0000001D1B80: DC960020 007C6551
	global_store_d16_hi_b16 v[81:82], v151, off offset:64      // 0000001D1B88: DC960040 007C9751
	global_store_d16_hi_b16 v[83:84], v94, off                 // 0000001D1B90: DC960000 007C5E53
	global_store_d16_hi_b16 v[83:84], v102, off offset:32      // 0000001D1B98: DC960020 007C6653
	global_store_d16_hi_b16 v[83:84], v152, off offset:64      // 0000001D1BA0: DC960040 007C9853
	global_store_d16_hi_b16 v[81:82], v65, off offset:96       // 0000001D1BA8: DC960060 007C4151
	global_store_d16_hi_b16 v[83:84], v66, off offset:96       // 0000001D1BB0: DC960060 007C4253
	v_add3_u32 v65, v70, v67, 0x7fff                           // 0000001D1BB8: D6550041 03FE8746 00007FFF
	v_add3_u32 v66, v71, v68, 0x7fff                           // 0000001D1BC4: D6550042 03FE8947 00007FFF
	s_clause 0x7                                               // 0000001D1BD0: BF850007
	global_store_d16_hi_b16 v[85:86], v95, off                 // 0000001D1BD4: DC960000 007C5F55
	global_store_d16_hi_b16 v[85:86], v103, off offset:32      // 0000001D1BDC: DC960020 007C6755
	global_store_d16_hi_b16 v[85:86], v153, off offset:64      // 0000001D1BE4: DC960040 007C9955
	global_store_d16_hi_b16 v[87:88], v99, off                 // 0000001D1BEC: DC960000 007C6357
	global_store_d16_hi_b16 v[87:88], v104, off offset:32      // 0000001D1BF4: DC960020 007C6857
	global_store_d16_hi_b16 v[87:88], v154, off offset:64      // 0000001D1BFC: DC960040 007C9A57
	global_store_d16_hi_b16 v[85:86], v65, off offset:96       // 0000001D1C04: DC960060 007C4155
	global_store_d16_hi_b16 v[87:88], v66, off offset:96       // 0000001D1C0C: DC960060 007C4257
	s_and_not1_b32 vcc_lo, exec_lo, s14                        // 0000001D1C14: 916A0E7E
	s_cbranch_vccnz 114                                        // 0000001D1C18: BFA40072 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5be4>
	s_and_saveexec_b32 s14, s11                                // 0000001D1C1C: BE8E200B
	s_cbranch_execnz 940                                       // 0000001D1C20: BFA603AC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68d4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1C24: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001D1C28: BE8E200D
	s_cbranch_execnz 959                                       // 0000001D1C2C: BFA603BF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x692c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1C30: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001D1C34: BE8E200C
	s_cbranch_execnz 978                                       // 0000001D1C38: BFA603D2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6984>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1C3C: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001D1C40: BE8E200A
	s_cbranch_execnz 997                                       // 0000001D1C44: BFA603E5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x69dc>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1C48: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001D1C4C: BE8E2009
	s_cbranch_execnz 1016                                      // 0000001D1C50: BFA603F8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6a34>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1C54: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001D1C58: BE8E2001
	s_cbranch_execnz 1035                                      // 0000001D1C5C: BFA6040B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6a8c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1C60: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001D1C64: BE8E2008
	s_cbranch_execnz 1054                                      // 0000001D1C68: BFA6041E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6ae4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1C6C: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001D1C70: BE8E2000
	s_cbranch_execnz 1073                                      // 0000001D1C74: BFA60431 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6b3c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1C78: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001D1C7C: BE8E200B
	s_cbranch_execnz 1092                                      // 0000001D1C80: BFA60444 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6b94>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1C84: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001D1C88: BE8E200D
	s_cbranch_execnz 1111                                      // 0000001D1C8C: BFA60457 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6bec>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1C90: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001D1C94: BE8E200C
	s_cbranch_execnz 1130                                      // 0000001D1C98: BFA6046A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6c44>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1C9C: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001D1CA0: BE8E200A
	s_cbranch_execnz 1149                                      // 0000001D1CA4: BFA6047D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6c9c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1CA8: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001D1CAC: BE8E2009
	s_cbranch_execnz 1168                                      // 0000001D1CB0: BFA60490 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6cf4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1CB4: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001D1CB8: BE8E2001
	s_cbranch_execnz 1187                                      // 0000001D1CBC: BFA604A3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6d4c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1CC0: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001D1CC4: BE8E2008
	s_cbranch_execnz 1206                                      // 0000001D1CC8: BFA604B6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6da4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1CCC: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001D1CD0: BE8E2000
	s_cbranch_execnz 1225                                      // 0000001D1CD4: BFA604C9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6dfc>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1CD8: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001D1CDC: BE8E200B
	s_cbranch_execnz 1244                                      // 0000001D1CE0: BFA604DC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6e54>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1CE4: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001D1CE8: BE8E200D
	s_cbranch_execnz 1263                                      // 0000001D1CEC: BFA604EF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6eac>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1CF0: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001D1CF4: BE8E200C
	s_cbranch_execnz 1282                                      // 0000001D1CF8: BFA60502 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6f04>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1CFC: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001D1D00: BE8E200A
	s_cbranch_execnz 1301                                      // 0000001D1D04: BFA60515 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6f5c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1D08: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001D1D0C: BE8E2009
	s_cbranch_execnz 1320                                      // 0000001D1D10: BFA60528 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6fb4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1D14: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001D1D18: BE8E2001
	s_cbranch_execnz 1339                                      // 0000001D1D1C: BFA6053B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x700c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1D20: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001D1D24: BE8E2008
	s_cbranch_execnz 1358                                      // 0000001D1D28: BFA6054E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7064>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1D2C: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001D1D30: BE8E2000
	s_cbranch_execnz 1377                                      // 0000001D1D34: BFA60561 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x70bc>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1D38: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001D1D3C: BE8E200B
	s_cbranch_execnz 1396                                      // 0000001D1D40: BFA60574 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7114>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D1D44: 8C7E0E7E
	s_and_saveexec_b32 s11, s13                                // 0000001D1D48: BE8B200D
	s_cbranch_execnz 1415                                      // 0000001D1D4C: BFA60587 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x716c>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001D1D50: 8C7E0B7E
	s_and_saveexec_b32 s11, s12                                // 0000001D1D54: BE8B200C
	s_cbranch_execnz 1434                                      // 0000001D1D58: BFA6059A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x71c4>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001D1D5C: 8C7E0B7E
	s_and_saveexec_b32 s11, s10                                // 0000001D1D60: BE8B200A
	s_cbranch_execnz 1453                                      // 0000001D1D64: BFA605AD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x721c>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001D1D68: 8C7E0B7E
	s_and_saveexec_b32 s10, s9                                 // 0000001D1D6C: BE8A2009
	s_cbranch_execnz 1472                                      // 0000001D1D70: BFA605C0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7274>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001D1D74: 8C7E0A7E
	s_and_saveexec_b32 s9, s1                                  // 0000001D1D78: BE892001
	s_cbranch_execnz 1491                                      // 0000001D1D7C: BFA605D3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x72cc>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000001D1D80: 8C7E097E
	s_and_saveexec_b32 s1, s8                                  // 0000001D1D84: BE812008
	s_cbranch_execnz 1510                                      // 0000001D1D88: BFA605E6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7324>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001D1D8C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000001D1D90: BE812000
	s_cbranch_execz 18                                         // 0000001D1D94: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5be0>
	ds_load_b32 v1, v141 offset:56                             // 0000001D1D98: D8D80038 0100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D1DA0: BF89FC07
	v_fmac_f32_e32 v40, v8, v1                                 // 0000001D1DA4: 56500308
	v_mad_u64_u32 v[1:2], null, 0x3000, v143, v[108:109]       // 0000001D1DA8: D6FE7C01 05B31EFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D1DB4: BF870092
	v_mul_f32_e32 v3, 0x3b800000, v40                          // 0000001D1DB8: 100650FF 3B800000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001D1DC0: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D1DC8: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001D1DCC: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001D1DD8: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001D1DE0: 8C7E017E
	s_waitcnt vmcnt(0)                                         // 0000001D1DE4: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 0000001D1DE8: BC7C0000
	s_barrier                                                  // 0000001D1DEC: BFBD0000
	buffer_gl0_inv                                             // 0000001D1DF0: E0AC0000 00000000
	ds_load_b128 v[1:4], v133                                  // 0000001D1DF8: DBFC0000 01000085
	ds_load_b128 v[5:8], v133 offset:16                        // 0000001D1E00: DBFC0010 05000085
	ds_load_b128 v[25:28], v134                                // 0000001D1E08: DBFC0000 19000086
	ds_load_b128 v[29:32], v134 offset:16                      // 0000001D1E10: DBFC0010 1D000086
	ds_load_b128 v[9:12], v133 offset:32                       // 0000001D1E18: DBFC0020 09000085
	ds_load_b128 v[13:16], v133 offset:48                      // 0000001D1E20: DBFC0030 0D000085
	ds_load_b128 v[33:36], v134 offset:2304                    // 0000001D1E28: DBFC0900 21000086
	ds_load_b128 v[37:40], v134 offset:2320                    // 0000001D1E30: DBFC0910 25000086
	ds_load_b128 v[41:44], v134 offset:4608                    // 0000001D1E38: DBFC1200 29000086
	ds_load_b128 v[45:48], v134 offset:4624                    // 0000001D1E40: DBFC1210 2D000086
	ds_load_b128 v[49:52], v134 offset:6912                    // 0000001D1E48: DBFC1B00 31000086
	ds_load_b128 v[53:56], v134 offset:6928                    // 0000001D1E50: DBFC1B10 35000086
	ds_load_b128 v[57:60], v134 offset:9216                    // 0000001D1E58: DBFC2400 39000086
	ds_load_b128 v[61:64], v134 offset:9232                    // 0000001D1E60: DBFC2410 3D000086
	ds_load_b128 v[65:68], v134 offset:11520                   // 0000001D1E68: DBFC2D00 41000086
	ds_load_b128 v[69:72], v134 offset:11536                   // 0000001D1E70: DBFC2D10 45000086
	ds_load_b128 v[73:76], v134 offset:13824                   // 0000001D1E78: DBFC3600 49000086
	ds_load_b128 v[77:80], v134 offset:13840                   // 0000001D1E80: DBFC3610 4D000086
	ds_load_b128 v[81:84], v134 offset:16128                   // 0000001D1E88: DBFC3F00 51000086
	ds_load_b128 v[85:88], v134 offset:16144                   // 0000001D1E90: DBFC3F10 55000086
	ds_load_b128 v[89:92], v134 offset:32                      // 0000001D1E98: DBFC0020 59000086
	ds_load_b128 v[93:96], v134 offset:48                      // 0000001D1EA0: DBFC0030 5D000086
	v_dual_mov_b32 v17, s20 :: v_dual_mov_b32 v18, s21         // 0000001D1EA8: CA100014 11120015
	v_dual_mov_b32 v19, s22 :: v_dual_mov_b32 v20, s23         // 0000001D1EB0: CA100016 13140017
	v_dual_mov_b32 v21, s24 :: v_dual_mov_b32 v22, s25         // 0000001D1EB8: CA100018 15160019
	v_dual_mov_b32 v23, s26 :: v_dual_mov_b32 v24, s27         // 0000001D1EC0: CA10001A 1718001B
	s_mul_f32 s0, s41, 0x3fb8aa3b                              // 0000001D1EC8: A200FF29 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000001D1ED0: BF87000B
	s_xor_b32 s1, s0, 0x80000000                               // 0000001D1ED4: 8D01FF00 80000000
	s_rndne_f32 s8, s0                                         // 0000001D1EDC: BE886300
	s_waitcnt lgkmcnt(14)                                      // 0000001D1EE0: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[142:149], v[33:40], v[1:8], v[17:24]// 0000001D1EE4: CC40408E 1C460321
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[1:8], v[17:24]// 0000001D1EEC: CC404061 1C460319
	ds_load_b128 v[25:28], v134 offset:2336                    // 0000001D1EF4: DBFC0920 19000086
	ds_load_b128 v[29:32], v134 offset:2352                    // 0000001D1EFC: DBFC0930 1D000086
	s_waitcnt lgkmcnt(14)                                      // 0000001D1F04: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[1:8], v[17:24]// 0000001D1F08: CC404021 1C460329
	s_waitcnt lgkmcnt(12)                                      // 0000001D1F10: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[41:48], v[49:56], v[1:8], v[17:24]// 0000001D1F14: CC404029 1C460331
	s_waitcnt lgkmcnt(10)                                      // 0000001D1F1C: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[49:56], v[57:64], v[1:8], v[17:24]// 0000001D1F20: CC404031 1C460339
	s_waitcnt lgkmcnt(8)                                       // 0000001D1F28: BF89FC87
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[1:8], v[17:24]// 0000001D1F2C: CC404039 1C460341
	s_waitcnt lgkmcnt(6)                                       // 0000001D1F34: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[73:80], v[1:8], v[17:24]// 0000001D1F38: CC404041 1C460349
	s_waitcnt lgkmcnt(4)                                       // 0000001D1F40: BF89FC47
	v_wmma_f32_16x16x16_f16 v[73:80], v[81:88], v[1:8], v[17:24]// 0000001D1F44: CC404049 1C460351
	ds_load_b128 v[1:4], v134 offset:4640                      // 0000001D1F4C: DBFC1220 01000086
	ds_load_b128 v[5:8], v134 offset:4656                      // 0000001D1F54: DBFC1230 05000086
	ds_load_b128 v[17:20], v134 offset:6944                    // 0000001D1F5C: DBFC1B20 11000086
	ds_load_b128 v[21:24], v134 offset:6960                    // 0000001D1F64: DBFC1B30 15000086
	ds_load_b128 v[81:84], v134 offset:9248                    // 0000001D1F6C: DBFC2420 51000086
	ds_load_b128 v[85:88], v134 offset:9264                    // 0000001D1F74: DBFC2430 55000086
	s_waitcnt lgkmcnt(8)                                       // 0000001D1F7C: BF89FC87
	v_wmma_f32_16x16x16_f16 v[97:104], v[89:96], v[9:16], v[97:104]// 0000001D1F80: CC404061 1D861359
	s_fmamk_f32 s1, s41, 0x3fb8aa3b, s1                        // 0000001D1F88: A3010129 3FB8AA3B
	s_sub_f32 s0, s0, s8                                       // 0000001D1F90: A0800800
	s_cmp_nlt_f32 s41, 0xc2ce8ed0                              // 0000001D1F94: BF4EFF29 C2CE8ED0
	s_waitcnt lgkmcnt(6)                                       // 0000001D1F9C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[142:149], v[25:32], v[9:16], v[142:149]// 0000001D1FA0: CC40408E 1E3A1319
	ds_load_b128 v[25:28], v134 offset:11552                   // 0000001D1FA8: DBFC2D20 19000086
	ds_load_b128 v[29:32], v134 offset:11568                   // 0000001D1FB0: DBFC2D30 1D000086
	s_fmamk_f32 s1, s41, 0x32a5705f, s1                        // 0000001D1FB8: A3010129 32A5705F
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001D1FC0: 986A80C1
	s_cmp_ngt_f32 s41, 0x42b17218                              // 0000001D1FC4: BF4BFF29 42B17218
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000001D1FCC: BF870599
	s_add_f32 s0, s0, s1                                       // 0000001D1FD0: A0000100
	v_exp_f32_e32 v91, s0                                      // 0000001D1FD4: 7EB64A00
	s_waitcnt lgkmcnt(6)                                       // 0000001D1FD8: BF89FC67
	v_wmma_f32_16x16x16_f16 v[33:40], v[1:8], v[9:16], v[33:40]// 0000001D1FDC: CC404021 1C861301
	ds_load_b128 v[1:4], v134 offset:13856                     // 0000001D1FE4: DBFC3620 01000086
	ds_load_b128 v[5:8], v134 offset:13872                     // 0000001D1FEC: DBFC3630 05000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D1FF4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[9:16], v[41:48]// 0000001D1FF8: CC404029 1CA61311
	ds_load_b128 v[17:20], v134 offset:16160                   // 0000001D2000: DBFC3F20 11000086
	ds_load_b128 v[21:24], v134 offset:16176                   // 0000001D2008: DBFC3F30 15000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D2010: BF89FC67
	v_wmma_f32_16x16x16_f16 v[49:56], v[81:88], v[9:16], v[49:56]// 0000001D2014: CC404031 1CC61351
	ds_load_b128 v[85:88], v133 offset:80                      // 0000001D201C: DBFC0050 55000085
	ds_load_b128 v[81:84], v133 offset:64                      // 0000001D2024: DBFC0040 51000085
	s_cvt_i32_f32 s0, s8                                       // 0000001D202C: BE806608
	s_waitcnt lgkmcnt(6)                                       // 0000001D2030: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[25:32], v[9:16], v[57:64]// 0000001D2034: CC404039 1CE61319
	ds_load_b128 v[29:32], v134 offset:80                      // 0000001D203C: DBFC0050 1D000086
	ds_load_b128 v[25:28], v134 offset:64                      // 0000001D2044: DBFC0040 19000086
	.long 0xd71c005b                                           // 0000001D204C: D71C005B
	v_cndmask_b32_e32 v0, v91, v0, vcc_lo                      // 0000001D2050: 0200015B
	s_waitcnt lgkmcnt(6)                                       // 0000001D2054: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[1:8], v[9:16], v[65:72]// 0000001D2058: CC404041 1D061301
	ds_load_b128 v[5:8], v134 offset:2384                      // 0000001D2060: DBFC0950 05000086
	ds_load_b128 v[1:4], v134 offset:2368                      // 0000001D2068: DBFC0940 01000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D2070: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[9:16], v[73:80]// 0000001D2074: CC404049 1D261311
	ds_load_b128 v[13:16], v134 offset:4688                    // 0000001D207C: DBFC1250 0D000086
	ds_load_b128 v[9:12], v134 offset:4672                     // 0000001D2084: DBFC1240 09000086
	ds_load_b128 v[21:24], v134 offset:6992                    // 0000001D208C: DBFC1B50 15000086
	ds_load_b128 v[17:20], v134 offset:6976                    // 0000001D2094: DBFC1B40 11000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D209C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[81:88], v[97:104]// 0000001D20A0: CC404061 1D86A319
	ds_load_b128 v[29:32], v134 offset:9296                    // 0000001D20A8: DBFC2450 1D000086
	ds_load_b128 v[25:28], v134 offset:9280                    // 0000001D20B0: DBFC2440 19000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D20B8: BF89FC67
	v_wmma_f32_16x16x16_f16 v[142:149], v[1:8], v[81:88], v[142:149]// 0000001D20BC: CC40408E 1E3AA301
	ds_load_b128 v[5:8], v134 offset:11600                     // 0000001D20C4: DBFC2D50 05000086
	ds_load_b128 v[1:4], v134 offset:11584                     // 0000001D20CC: DBFC2D40 01000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D20D4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[33:40], v[9:16], v[81:88], v[33:40]// 0000001D20D8: CC404021 1C86A309
	ds_load_b128 v[13:16], v134 offset:13904                   // 0000001D20E0: DBFC3650 0D000086
	ds_load_b128 v[9:12], v134 offset:13888                    // 0000001D20E8: DBFC3640 09000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D20F0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[81:88], v[41:48]// 0000001D20F4: CC404029 1CA6A311
	ds_load_b128 v[21:24], v134 offset:16208                   // 0000001D20FC: DBFC3F50 15000086
	ds_load_b128 v[17:20], v134 offset:16192                   // 0000001D2104: DBFC3F40 11000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D210C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[49:56], v[25:32], v[81:88], v[49:56]// 0000001D2110: CC404031 1CC6A319
	ds_load_b128 v[29:32], v133 offset:112                     // 0000001D2118: DBFC0070 1D000085
	ds_load_b128 v[25:28], v133 offset:96                      // 0000001D2120: DBFC0060 19000085
	s_waitcnt lgkmcnt(6)                                       // 0000001D2128: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[1:8], v[81:88], v[57:64]// 0000001D212C: CC404039 1CE6A301
	ds_load_b128 v[5:8], v134 offset:112                       // 0000001D2134: DBFC0070 05000086
	ds_load_b128 v[1:4], v134 offset:96                        // 0000001D213C: DBFC0060 01000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D2144: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[9:16], v[81:88], v[65:72]// 0000001D2148: CC404041 1D06A309
	ds_load_b128 v[13:16], v134 offset:2416                    // 0000001D2150: DBFC0970 0D000086
	ds_load_b128 v[9:12], v134 offset:2400                     // 0000001D2158: DBFC0960 09000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D2160: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[81:88], v[73:80]// 0000001D2164: CC404049 1D26A311
	ds_load_b128 v[21:24], v134 offset:4720                    // 0000001D216C: DBFC1270 15000086
	ds_load_b128 v[17:20], v134 offset:4704                    // 0000001D2174: DBFC1260 11000086
	ds_load_b128 v[85:88], v134 offset:7024                    // 0000001D217C: DBFC1B70 55000086
	ds_load_b128 v[81:84], v134 offset:7008                    // 0000001D2184: DBFC1B60 51000086
	s_waitcnt lgkmcnt(6)                                       // 0000001D218C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[97:104], v[1:8], v[25:32], v[97:104]// 0000001D2190: CC404061 1D863301
	ds_load_b128 v[5:8], v134 offset:9328                      // 0000001D2198: DBFC2470 05000086
	ds_load_b128 v[1:4], v134 offset:9312                      // 0000001D21A0: DBFC2460 01000086
	s_waitcnt lgkmcnt(4)                                       // 0000001D21A8: BF89FC47
	v_wmma_f32_16x16x16_f16 v[33:40], v[17:24], v[25:32], v[33:40]// 0000001D21AC: CC404021 1C863311
	ds_load_b128 v[21:24], v134 offset:13936                   // 0000001D21B4: DBFC3670 15000086
	ds_load_b128 v[17:20], v134 offset:13920                   // 0000001D21BC: DBFC3660 11000086
	s_waitcnt lgkmcnt(4)                                       // 0000001D21C4: BF89FC47
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[25:32], v[41:48]// 0000001D21C8: CC404029 1CA63351
	ds_load_b128 v[85:88], v134 offset:16240                   // 0000001D21D0: DBFC3F70 55000086
	ds_load_b128 v[81:84], v134 offset:16224                   // 0000001D21D8: DBFC3F60 51000086
	v_wmma_f32_16x16x16_f16 v[142:149], v[9:16], v[25:32], v[142:149]// 0000001D21E0: CC40408E 1E3A3309
	ds_load_b128 v[13:16], v134 offset:11632                   // 0000001D21E8: DBFC2D70 0D000086
	ds_load_b128 v[9:12], v134 offset:11616                    // 0000001D21F0: DBFC2D60 09000086
	ds_load_2addr_b32 v[89:90], v135 offset1:2                 // 0000001D21F8: D8DC0200 59000087
	s_waitcnt lgkmcnt(7)                                       // 0000001D2200: BF89FC77
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[25:32], v[49:56]// 0000001D2204: CC404031 1CC63301
	ds_load_2addr_b32 v[1:2], v135 offset0:4 offset1:6         // 0000001D220C: D8DC0604 01000087
	ds_load_2addr_b32 v[3:4], v135 offset0:8 offset1:10        // 0000001D2214: D8DC0A08 03000087
	ds_load_2addr_b32 v[5:6], v135 offset0:12 offset1:14       // 0000001D221C: D8DC0E0C 05000087
	s_waitcnt lgkmcnt(8)                                       // 0000001D2224: BF89FC87
	v_wmma_f32_16x16x16_f16 v[65:72], v[17:24], v[25:32], v[65:72]// 0000001D2228: CC404041 1D063311
	ds_load_2addr_b32 v[7:8], v135 offset0:16 offset1:18       // 0000001D2230: D8DC1210 07000087
	s_waitcnt lgkmcnt(7)                                       // 0000001D2238: BF89FC77
	v_wmma_f32_16x16x16_f16 v[73:80], v[81:88], v[25:32], v[73:80]// 0000001D223C: CC404049 1D263351
	s_waitcnt lgkmcnt(5)                                       // 0000001D2244: BF89FC57
	v_wmma_f32_16x16x16_f16 v[57:64], v[9:16], v[25:32], v[57:64]// 0000001D2248: CC404039 1CE63309
	v_cndmask_b32_e32 v31, 0, v91, vcc_lo                      // 0000001D2250: 023EB680
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001D2254: 986A80C1
	ds_load_2addr_b32 v[9:10], v135 offset0:20 offset1:22      // 0000001D2258: D8DC1614 09000087
	ds_load_2addr_b32 v[11:12], v135 offset0:24 offset1:26     // 0000001D2260: D8DC1A18 0B000087
	ds_load_2addr_b32 v[13:14], v135 offset0:28 offset1:30     // 0000001D2268: D8DC1E1C 0D000087
	ds_load_2addr_b32 v[15:16], v135 offset0:32 offset1:34     // 0000001D2270: D8DC2220 0F000087
	ds_load_2addr_b32 v[17:18], v135 offset0:36 offset1:38     // 0000001D2278: D8DC2624 11000087
	v_cndmask_b32_e32 v91, 0x7f800000, v31, vcc_lo             // 0000001D2280: 02B63EFF 7F800000
	ds_load_2addr_b32 v[19:20], v135 offset0:40 offset1:42     // 0000001D2288: D8DC2A28 13000087
	ds_load_2addr_b32 v[21:22], v135 offset0:44 offset1:46     // 0000001D2290: D8DC2E2C 15000087
	ds_load_2addr_b32 v[23:24], v135 offset0:48 offset1:50     // 0000001D2298: D8DC3230 17000087
	ds_load_2addr_b32 v[25:26], v135 offset0:52 offset1:54     // 0000001D22A0: D8DC3634 19000087
	ds_load_2addr_b32 v[27:28], v135 offset0:56 offset1:58     // 0000001D22A8: D8DC3A38 1B000087
	ds_load_2addr_b32 v[29:30], v135 offset0:60 offset1:62     // 0000001D22B0: D8DC3E3C 1D000087
	s_waitcnt lgkmcnt(15)                                      // 0000001D22B8: BF89FCF7
	v_mul_f32_e32 v90, v91, v90                                // 0000001D22BC: 10B4B55B
	v_mul_f32_e32 v89, v91, v89                                // 0000001D22C0: 10B2B35B
	ds_load_2addr_b32 v[31:32], v135 offset0:64 offset1:66     // 0000001D22C4: D8DC4240 1F000087
	ds_load_2addr_b32 v[81:82], v135 offset0:68 offset1:70     // 0000001D22CC: D8DC4644 51000087
	ds_load_2addr_b32 v[83:84], v135 offset0:72 offset1:74     // 0000001D22D4: D8DC4A48 53000087
	ds_load_2addr_b32 v[85:86], v135 offset0:76 offset1:78     // 0000001D22DC: D8DC4E4C 55000087
	s_waitcnt lgkmcnt(18)                                      // 0000001D22E4: BF89FD27
	v_mul_f32_e32 v93, v91, v2                                 // 0000001D22E8: 10BA055B
	v_mul_f32_e32 v92, v91, v1                                 // 0000001D22EC: 10B8035B
	v_fmac_f32_e32 v90, 0x3b800000, v98                        // 0000001D22F0: 56B4C4FF 3B800000
	s_waitcnt lgkmcnt(17)                                      // 0000001D22F8: BF89FD17
	v_dual_mul_f32 v94, v91, v3 :: v_dual_fmac_f32 v89, 0x3b800000, v97// 0000001D22FC: C8C0075B 5E58C2FF 3B800000
	v_mul_f32_e32 v95, v91, v4                                 // 0000001D2308: 10BE095B
	v_dual_fmac_f32 v93, 0x3b800000, v100 :: v_dual_fmac_f32 v92, 0x3b800000, v99// 0000001D230C: C800C8FF 5D5CC6FF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D2318: BF8701A3
	v_fmac_f32_e32 v94, 0x3b800000, v101                       // 0000001D231C: 56BCCAFF 3B800000
	s_waitcnt lgkmcnt(16)                                      // 0000001D2324: BF89FD07
	v_dual_mul_f32 v96, v91, v5 :: v_dual_fmac_f32 v95, 0x3b800000, v102// 0000001D2328: C8C00B5B 605ECCFF 3B800000
	v_mul_f32_e32 v105, v91, v6                                // 0000001D2334: 10D20D5B
	s_waitcnt lgkmcnt(14)                                      // 0000001D2338: BF89FCE7
	v_mul_f32_e32 v100, v91, v10                               // 0000001D233C: 10C8155B
	v_mul_f32_e32 v97, v91, v7                                 // 0000001D2340: 10C20F5B
	v_fmac_f32_e32 v96, 0x3b800000, v103                       // 0000001D2344: 56C0CEFF 3B800000
	s_waitcnt lgkmcnt(11)                                      // 0000001D234C: BF89FCB7
	v_dual_mul_f32 v116, v91, v15 :: v_dual_fmac_f32 v105, 0x3b800000, v104// 0000001D2350: C8C01F5B 7468D0FF 3B800000
	v_fmac_f32_e32 v100, 0x3b800000, v145                      // 0000001D235C: 56C922FF 3B800000
	v_dual_mul_f32 v98, v91, v8 :: v_dual_fmac_f32 v97, 0x3b800000, v142// 0000001D2364: C8C0115B 62611CFF 3B800000
	v_mul_f32_e32 v99, v91, v9                                 // 0000001D2370: 10C6135B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D2374: BF870194
	v_dual_mul_f32 v117, v91, v16 :: v_dual_fmac_f32 v116, 0x3b800000, v33// 0000001D2378: C8C0215B 757442FF 3B800000
	v_fmac_f32_e32 v98, 0x3b800000, v143                       // 0000001D2384: 56C51EFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001D238C: BF8701C3
	v_dual_mul_f32 v104, v91, v14 :: v_dual_fmac_f32 v99, 0x3b800000, v144// 0000001D2390: C8C01D5B 686320FF 3B800000
	v_mul_f32_e32 v101, v91, v11                               // 0000001D239C: 10CA175B
	s_waitcnt lgkmcnt(10)                                      // 0000001D23A0: BF89FCA7
	v_dual_mul_f32 v142, v91, v17 :: v_dual_fmac_f32 v117, 0x3b800000, v34// 0000001D23A4: C8C0235B 8E7444FF 3B800000
	v_fmac_f32_e32 v104, 0x3b800000, v149                      // 0000001D23B0: 56D12AFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D23B8: BF870223
	v_dual_mul_f32 v102, v91, v12 :: v_dual_fmac_f32 v101, 0x3b800000, v146// 0000001D23BC: C8C0195B 666524FF 3B800000
	v_mul_f32_e32 v103, v91, v13                               // 0000001D23C8: 10CE1B5B
	v_dual_mul_f32 v143, v91, v18 :: v_dual_fmac_f32 v142, 0x3b800000, v35// 0000001D23CC: C8C0255B 8F8E46FF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D23D8: BF8701A3
	v_fmac_f32_e32 v102, 0x3b800000, v147                      // 0000001D23DC: 56CD26FF 3B800000
	s_waitcnt lgkmcnt(9)                                       // 0000001D23E4: BF89FC97
	v_dual_mul_f32 v144, v91, v19 :: v_dual_fmac_f32 v103, 0x3b800000, v148// 0000001D23E8: C8C0275B 906728FF 3B800000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D23F4: BF870003
	v_fmac_f32_e32 v143, 0x3b800000, v36                       // 0000001D23F8: 571E48FF 3B800000
	v_mul_f32_e32 v145, v91, v20                               // 0000001D2400: 1122295B
	ds_load_2addr_b32 v[1:2], v135 offset0:80 offset1:82       // 0000001D2404: D8DC5250 01000087
	ds_load_2addr_b32 v[3:4], v135 offset0:84 offset1:86       // 0000001D240C: D8DC5654 03000087
	ds_load_2addr_b32 v[5:6], v135 offset0:88 offset1:90       // 0000001D2414: D8DC5A58 05000087
	ds_load_2addr_b32 v[87:88], v135 offset0:92 offset1:94     // 0000001D241C: D8DC5E5C 57000087
	ds_load_2addr_b32 v[7:8], v135 offset0:96 offset1:98       // 0000001D2424: D8DC6260 07000087
	ds_load_2addr_b32 v[9:10], v135 offset0:100 offset1:102    // 0000001D242C: D8DC6664 09000087
	ds_load_2addr_b32 v[11:12], v135 offset0:104 offset1:106   // 0000001D2434: D8DC6A68 0B000087
	ds_load_2addr_b32 v[13:14], v135 offset0:108 offset1:110   // 0000001D243C: D8DC6E6C 0D000087
	v_fmac_f32_e32 v144, 0x3b800000, v37                       // 0000001D2444: 57204AFF 3B800000
	s_waitcnt lgkmcnt(16)                                      // 0000001D244C: BF89FD07
	v_dual_mul_f32 v146, v91, v21 :: v_dual_fmac_f32 v145, 0x3b800000, v38// 0000001D2450: C8C02B5B 92904CFF 3B800000
	v_mul_f32_e32 v147, v91, v22                               // 0000001D245C: 11262D5B
	ds_load_2addr_b32 v[15:16], v135 offset0:112 offset1:114   // 0000001D2460: D8DC7270 0F000087
	ds_load_2addr_b32 v[17:18], v135 offset0:116 offset1:118   // 0000001D2468: D8DC7674 11000087
	ds_load_2addr_b32 v[19:20], v135 offset0:120 offset1:122   // 0000001D2470: D8DC7A78 13000087
	ds_load_2addr_b32 v[21:22], v135 offset0:124 offset1:126   // 0000001D2478: D8DC7E7C 15000087
	s_waitcnt lgkmcnt(18)                                      // 0000001D2480: BF89FD27
	v_mul_f32_e32 v26, v91, v26                                // 0000001D2484: 1034355B
	v_dual_fmac_f32 v146, 0x3b800000, v39 :: v_dual_mul_f32 v25, v91, v25// 0000001D2488: C8064EFF 9218335B 3B800000
	v_fmac_f32_e32 v147, 0x3b800000, v40                       // 0000001D2494: 572650FF 3B800000
	v_mul_f32_e32 v24, v91, v24                                // 0000001D249C: 1030315B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000001D24A0: BF8701D4
	v_fmac_f32_e32 v26, 0x3b800000, v44                        // 0000001D24A4: 563458FF 3B800000
	s_waitcnt lgkmcnt(17)                                      // 0000001D24AC: BF89FD17
	v_dual_mul_f32 v28, v91, v28 :: v_dual_fmac_f32 v25, 0x3b800000, v43// 0000001D24B0: C8C0395B 1C1856FF 3B800000
	v_mul_f32_e32 v27, v91, v27                                // 0000001D24BC: 1036375B
	v_dual_mul_f32 v23, v91, v23 :: v_dual_fmac_f32 v24, 0x3b800000, v42// 0000001D24C0: C8C02F5B 171854FF 3B800000
	v_fmac_f32_e32 v28, 0x3b800000, v46                        // 0000001D24CC: 56385CFF 3B800000
	s_waitcnt lgkmcnt(16)                                      // 0000001D24D4: BF89FD07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001D24D8: BF870133
	v_dual_mul_f32 v30, v91, v30 :: v_dual_fmac_f32 v27, 0x3b800000, v45// 0000001D24DC: C8C03D5B 1E1A5AFF 3B800000
	v_mul_f32_e32 v29, v91, v29                                // 0000001D24E8: 103A3B5B
	s_cmp_lg_u32 s40, s36                                      // 0000001D24EC: BF072428
	v_dual_fmac_f32 v23, 0x3b800000, v41 :: v_dual_fmac_f32 v30, 0x3b800000, v48// 0000001D24F0: C80052FF 171E60FF 3B800000
	s_waitcnt lgkmcnt(15)                                      // 0000001D24FC: BF89FCF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D2500: BF870092
	v_dual_mul_f32 v32, v91, v32 :: v_dual_fmac_f32 v29, 0x3b800000, v47// 0000001D2504: C8C0415B 201C5EFF 3B800000
	v_dual_mul_f32 v31, v91, v31 :: v_dual_fmac_f32 v32, 0x3b800000, v50// 0000001D2510: C8C03F5B 1F2064FF 3B800000
	s_waitcnt lgkmcnt(14)                                      // 0000001D251C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D2520: BF870091
	v_dual_mul_f32 v34, v91, v82 :: v_dual_fmac_f32 v31, 0x3b800000, v49// 0000001D2524: C8C0A55B 221E62FF 3B800000
	v_dual_mul_f32 v33, v91, v81 :: v_dual_fmac_f32 v34, 0x3b800000, v52// 0000001D2530: C8C0A35B 212268FF 3B800000
	s_waitcnt lgkmcnt(13)                                      // 0000001D253C: BF89FCD7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D2540: BF870091
	v_dual_mul_f32 v36, v91, v84 :: v_dual_fmac_f32 v33, 0x3b800000, v51// 0000001D2544: C8C0A95B 242066FF 3B800000
	v_dual_mul_f32 v35, v91, v83 :: v_dual_fmac_f32 v36, 0x3b800000, v54// 0000001D2550: C8C0A75B 23246CFF 3B800000
	s_waitcnt lgkmcnt(12)                                      // 0000001D255C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D2560: BF870091
	v_dual_mul_f32 v38, v91, v86 :: v_dual_fmac_f32 v35, 0x3b800000, v53// 0000001D2564: C8C0AD5B 26226AFF 3B800000
	v_dual_mul_f32 v37, v91, v85 :: v_dual_fmac_f32 v38, 0x3b800000, v56// 0000001D2570: C8C0AB5B 252670FF 3B800000
	s_waitcnt lgkmcnt(11)                                      // 0000001D257C: BF89FCB7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D2580: BF870091
	v_dual_mul_f32 v2, v91, v2 :: v_dual_fmac_f32 v37, 0x3b800000, v55// 0000001D2584: C8C0055B 02246EFF 3B800000
	v_dual_mul_f32 v1, v91, v1 :: v_dual_fmac_f32 v2, 0x3b800000, v58// 0000001D2590: C8C0035B 010274FF 3B800000
	s_waitcnt lgkmcnt(10)                                      // 0000001D259C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D25A0: BF870091
	v_dual_mul_f32 v4, v91, v4 :: v_dual_fmac_f32 v1, 0x3b800000, v57// 0000001D25A4: C8C0095B 040072FF 3B800000
	v_dual_mul_f32 v3, v91, v3 :: v_dual_fmac_f32 v4, 0x3b800000, v60// 0000001D25B0: C8C0075B 030478FF 3B800000
	s_waitcnt lgkmcnt(9)                                       // 0000001D25BC: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D25C0: BF870091
	v_dual_mul_f32 v6, v91, v6 :: v_dual_fmac_f32 v3, 0x3b800000, v59// 0000001D25C4: C8C00D5B 060276FF 3B800000
	v_dual_mul_f32 v5, v91, v5 :: v_dual_fmac_f32 v6, 0x3b800000, v62// 0000001D25D0: C8C00B5B 05067CFF 3B800000
	s_waitcnt lgkmcnt(8)                                       // 0000001D25DC: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D25E0: BF870091
	v_dual_mul_f32 v40, v91, v88 :: v_dual_fmac_f32 v5, 0x3b800000, v61// 0000001D25E4: C8C0B15B 28047AFF 3B800000
	v_dual_mul_f32 v39, v91, v87 :: v_dual_fmac_f32 v40, 0x3b800000, v64// 0000001D25F0: C8C0AF5B 272880FF 3B800000
	s_waitcnt lgkmcnt(7)                                       // 0000001D25FC: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D2600: BF870091
	v_dual_mul_f32 v8, v91, v8 :: v_dual_fmac_f32 v39, 0x3b800000, v63// 0000001D2604: C8C0115B 08267EFF 3B800000
	v_dual_mul_f32 v7, v91, v7 :: v_dual_fmac_f32 v8, 0x3b800000, v66// 0000001D2610: C8C00F5B 070884FF 3B800000
	s_waitcnt lgkmcnt(6)                                       // 0000001D261C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D2620: BF870091
	v_dual_mul_f32 v10, v91, v10 :: v_dual_fmac_f32 v7, 0x3b800000, v65// 0000001D2624: C8C0155B 0A0682FF 3B800000
	v_dual_mul_f32 v9, v91, v9 :: v_dual_fmac_f32 v10, 0x3b800000, v68// 0000001D2630: C8C0135B 090A88FF 3B800000
	s_waitcnt lgkmcnt(5)                                       // 0000001D263C: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D2640: BF870091
	v_dual_mul_f32 v12, v91, v12 :: v_dual_fmac_f32 v9, 0x3b800000, v67// 0000001D2644: C8C0195B 0C0886FF 3B800000
	v_dual_mul_f32 v11, v91, v11 :: v_dual_fmac_f32 v12, 0x3b800000, v70// 0000001D2650: C8C0175B 0B0C8CFF 3B800000
	s_waitcnt lgkmcnt(4)                                       // 0000001D265C: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D2660: BF870091
	v_dual_mul_f32 v14, v91, v14 :: v_dual_fmac_f32 v11, 0x3b800000, v69// 0000001D2664: C8C01D5B 0E0A8AFF 3B800000
	v_dual_mul_f32 v13, v91, v13 :: v_dual_fmac_f32 v14, 0x3b800000, v72// 0000001D2670: C8C01B5B 0D0E90FF 3B800000
	s_waitcnt lgkmcnt(3)                                       // 0000001D267C: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D2680: BF870091
	v_dual_mul_f32 v16, v91, v16 :: v_dual_fmac_f32 v13, 0x3b800000, v71// 0000001D2684: C8C0215B 100C8EFF 3B800000
	v_dual_mul_f32 v15, v91, v15 :: v_dual_fmac_f32 v16, 0x3b800000, v74// 0000001D2690: C8C01F5B 0F1094FF 3B800000
	s_waitcnt lgkmcnt(2)                                       // 0000001D269C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D26A0: BF870091
	v_dual_mul_f32 v18, v91, v18 :: v_dual_fmac_f32 v15, 0x3b800000, v73// 0000001D26A4: C8C0255B 120E92FF 3B800000
	v_dual_mul_f32 v17, v91, v17 :: v_dual_fmac_f32 v18, 0x3b800000, v76// 0000001D26B0: C8C0235B 111298FF 3B800000
	s_waitcnt lgkmcnt(1)                                       // 0000001D26BC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D26C0: BF870091
	v_dual_mul_f32 v20, v91, v20 :: v_dual_fmac_f32 v17, 0x3b800000, v75// 0000001D26C4: C8C0295B 141096FF 3B800000
	v_dual_mul_f32 v19, v91, v19 :: v_dual_fmac_f32 v20, 0x3b800000, v78// 0000001D26D0: C8C0275B 13149CFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 0000001D26DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D26E0: BF870091
	v_dual_mul_f32 v22, v91, v22 :: v_dual_fmac_f32 v19, 0x3b800000, v77// 0000001D26E4: C8C02D5B 16129AFF 3B800000
	v_dual_mul_f32 v21, v91, v21 :: v_dual_fmac_f32 v22, 0x3b800000, v80// 0000001D26F0: C8C02B5B 1516A0FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D26FC: BF870001
	v_fmac_f32_e32 v21, 0x3b800000, v79                        // 0000001D2700: 562A9EFF 3B800000
	ds_store_2addr_b32 v135, v89, v90 offset1:2                // 0000001D2708: D8380200 005A5987
	ds_store_2addr_b32 v135, v92, v93 offset0:4 offset1:6      // 0000001D2710: D8380604 005D5C87
	ds_store_2addr_b32 v135, v94, v95 offset0:8 offset1:10     // 0000001D2718: D8380A08 005F5E87
	ds_store_2addr_b32 v135, v96, v105 offset0:12 offset1:14   // 0000001D2720: D8380E0C 00696087
	ds_store_2addr_b32 v135, v97, v98 offset0:16 offset1:18    // 0000001D2728: D8381210 00626187
	ds_store_2addr_b32 v135, v99, v100 offset0:20 offset1:22   // 0000001D2730: D8381614 00646387
	ds_store_2addr_b32 v135, v101, v102 offset0:24 offset1:26  // 0000001D2738: D8381A18 00666587
	ds_store_2addr_b32 v135, v103, v104 offset0:28 offset1:30  // 0000001D2740: D8381E1C 00686787
	ds_store_2addr_b32 v135, v116, v117 offset0:32 offset1:34  // 0000001D2748: D8382220 00757487
	ds_store_2addr_b32 v135, v142, v143 offset0:36 offset1:38  // 0000001D2750: D8382624 008F8E87
	ds_store_2addr_b32 v135, v144, v145 offset0:40 offset1:42  // 0000001D2758: D8382A28 00919087
	ds_store_2addr_b32 v135, v146, v147 offset0:44 offset1:46  // 0000001D2760: D8382E2C 00939287
	ds_store_2addr_b32 v135, v23, v24 offset0:48 offset1:50    // 0000001D2768: D8383230 00181787
	ds_store_2addr_b32 v135, v25, v26 offset0:52 offset1:54    // 0000001D2770: D8383634 001A1987
	ds_store_2addr_b32 v135, v27, v28 offset0:56 offset1:58    // 0000001D2778: D8383A38 001C1B87
	ds_store_2addr_b32 v135, v29, v30 offset0:60 offset1:62    // 0000001D2780: D8383E3C 001E1D87
	ds_store_2addr_b32 v135, v31, v32 offset0:64 offset1:66    // 0000001D2788: D8384240 00201F87
	ds_store_2addr_b32 v135, v33, v34 offset0:68 offset1:70    // 0000001D2790: D8384644 00222187
	ds_store_2addr_b32 v135, v35, v36 offset0:72 offset1:74    // 0000001D2798: D8384A48 00242387
	ds_store_2addr_b32 v135, v37, v38 offset0:76 offset1:78    // 0000001D27A0: D8384E4C 00262587
	ds_store_2addr_b32 v135, v1, v2 offset0:80 offset1:82      // 0000001D27A8: D8385250 00020187
	ds_store_2addr_b32 v135, v3, v4 offset0:84 offset1:86      // 0000001D27B0: D8385654 00040387
	ds_store_2addr_b32 v135, v5, v6 offset0:88 offset1:90      // 0000001D27B8: D8385A58 00060587
	ds_store_2addr_b32 v135, v39, v40 offset0:92 offset1:94    // 0000001D27C0: D8385E5C 00282787
	ds_store_2addr_b32 v135, v7, v8 offset0:96 offset1:98      // 0000001D27C8: D8386260 00080787
	ds_store_2addr_b32 v135, v9, v10 offset0:100 offset1:102   // 0000001D27D0: D8386664 000A0987
	ds_store_2addr_b32 v135, v11, v12 offset0:104 offset1:106  // 0000001D27D8: D8386A68 000C0B87
	ds_store_2addr_b32 v135, v13, v14 offset0:108 offset1:110  // 0000001D27E0: D8386E6C 000E0D87
	ds_store_2addr_b32 v135, v15, v16 offset0:112 offset1:114  // 0000001D27E8: D8387270 00100F87
	ds_store_2addr_b32 v135, v17, v18 offset0:116 offset1:118  // 0000001D27F0: D8387674 00121187
	ds_store_2addr_b32 v135, v19, v20 offset0:120 offset1:122  // 0000001D27F8: D8387A78 00141387
	ds_store_2addr_b32 v135, v21, v22 offset0:124 offset1:126  // 0000001D2800: D8387E7C 00161587
	s_waitcnt lgkmcnt(0)                                       // 0000001D2808: BF89FC07
	s_barrier                                                  // 0000001D280C: BFBD0000
	buffer_gl0_inv                                             // 0000001D2810: E0AC0000 00000000
	s_cbranch_scc0 73                                          // 0000001D2818: BFA10049 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6740>
	s_cmp_lg_u32 s40, s37                                      // 0000001D281C: BF072528
	s_cbranch_scc0 109                                         // 0000001D2820: BFA1006D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67d8>
	s_cmp_lg_u32 s40, s38                                      // 0000001D2824: BF072628
	s_cbranch_scc1 59253                                       // 0000001D2828: BFA2E775 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x400>
	s_branch 138                                               // 0000001D282C: BFA0008A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6858>
	s_clause 0x1                                               // 0000001D2830: BF850001
	global_load_b128 v[69:72], v[116:117], off offset:48       // 0000001D2834: DC5E0030 457C0074
	global_load_b128 v[65:68], v[116:117], off offset:32       // 0000001D283C: DC5E0020 417C0074
	ds_load_b128 v[73:76], v130 offset:32                      // 0000001D2844: DBFC0020 49000082
	ds_load_b128 v[77:80], v130 offset:48                      // 0000001D284C: DBFC0030 4D000082
	ds_load_b128 v[85:88], v130 offset:2352                    // 0000001D2854: DBFC0930 55000082
	ds_load_b128 v[81:84], v130 offset:2336                    // 0000001D285C: DBFC0920 51000082
	ds_load_b128 v[154:157], v130 offset:4656                  // 0000001D2864: DBFC1230 9A000082
	ds_load_b128 v[150:153], v130 offset:4640                  // 0000001D286C: DBFC1220 96000082
	ds_load_b128 v[162:165], v130 offset:6960                  // 0000001D2874: DBFC1B30 A2000082
	ds_load_b128 v[158:161], v130 offset:6944                  // 0000001D287C: DBFC1B20 9E000082
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001D2884: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[73:80], v[57:64]// 0000001D2888: CC404039 1CE69341
	s_waitcnt lgkmcnt(4)                                       // 0000001D2890: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[81:88], v[49:56]// 0000001D2894: CC404031 1CC6A341
	s_waitcnt lgkmcnt(2)                                       // 0000001D289C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[150:157], v[41:48]// 0000001D28A0: CC404029 1CA72D41
	s_waitcnt lgkmcnt(0)                                       // 0000001D28A8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[65:72], v[158:165], v[33:40]// 0000001D28AC: CC404021 1C873D41
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D28B4: 8C7E0E7E
	s_and_saveexec_b32 s14, s5                                 // 0000001D28B8: BE8E2005
	s_cbranch_execz 64295                                      // 0000001D28BC: BFA5FB27 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x535c>
	ds_load_b128 v[65:68], v130 offset:64                      // 0000001D28C0: DBFC0040 41000082
	ds_load_b128 v[69:72], v130 offset:80                      // 0000001D28C8: DBFC0050 45000082
	ds_load_b128 v[77:80], v130 offset:2384                    // 0000001D28D0: DBFC0950 4D000082
	ds_load_b128 v[73:76], v130 offset:2368                    // 0000001D28D8: DBFC0940 49000082
	ds_load_b128 v[85:88], v130 offset:4688                    // 0000001D28E0: DBFC1250 55000082
	ds_load_b128 v[81:84], v130 offset:4672                    // 0000001D28E8: DBFC1240 51000082
	ds_load_b128 v[154:157], v130 offset:6992                  // 0000001D28F0: DBFC1B50 9A000082
	ds_load_b128 v[150:153], v130 offset:6976                  // 0000001D28F8: DBFC1B40 96000082
	s_waitcnt vmcnt(2) lgkmcnt(6)                              // 0000001D2900: BF890867
	v_wmma_f32_16x16x16_f16 v[57:64], v[97:104], v[65:72], v[57:64]// 0000001D2904: CC404039 1CE68361
	s_waitcnt lgkmcnt(4)                                       // 0000001D290C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[97:104], v[73:80], v[49:56]// 0000001D2910: CC404031 1CC69361
	s_waitcnt lgkmcnt(2)                                       // 0000001D2918: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[97:104], v[81:88], v[41:48]// 0000001D291C: CC404029 1CA6A361
	s_waitcnt lgkmcnt(0)                                       // 0000001D2924: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[97:104], v[150:157], v[33:40]// 0000001D2928: CC404021 1C872D61
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2930: 8C7E0E7E
	s_and_saveexec_b32 s14, s7                                 // 0000001D2934: BE8E2007
	s_cbranch_execnz 64267                                     // 0000001D2938: BFA6FB0B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5368>
	s_branch 64296                                             // 0000001D293C: BFA0FB28 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x53e0>
	v_dual_mov_b32 v1, v110 :: v_dual_mov_b32 v4, v119         // 0000001D2940: CA10016E 01040177
	v_dual_mov_b32 v3, v124 :: v_dual_mov_b32 v2, v111         // 0000001D2948: CA10017C 0302016F
	s_mov_b32 s1, 0                                            // 0000001D2950: BE810080
	s_nop 0                                                    // 0000001D2954: BF800000
	s_nop 0                                                    // 0000001D2958: BF800000
	s_nop 0                                                    // 0000001D295C: BF800000
	s_nop 0                                                    // 0000001D2960: BF800000
	s_nop 0                                                    // 0000001D2964: BF800000
	s_nop 0                                                    // 0000001D2968: BF800000
	s_nop 0                                                    // 0000001D296C: BF800000
	s_nop 0                                                    // 0000001D2970: BF800000
	s_nop 0                                                    // 0000001D2974: BF800000
	s_nop 0                                                    // 0000001D2978: BF800000
	s_nop 0                                                    // 0000001D297C: BF800000
	ds_load_b32 v5, v3                                         // 0000001D2980: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001D2988: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001D2990: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001D2994: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001D2998: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001D29A0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001D29A4: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001D29A8: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001D29B0: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001D29B4: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001D29BC: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001D29C4: 917E017E
	s_cbranch_execnz 65517                                     // 0000001D29C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6780>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001D29CC: 8C7E017E
	s_cmp_lg_u32 s40, s37                                      // 0000001D29D0: BF072528
	s_cbranch_scc1 65427                                       // 0000001D29D4: BFA2FF93 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6624>
	v_dual_mov_b32 v1, v112 :: v_dual_mov_b32 v4, v119         // 0000001D29D8: CA100170 01040177
	v_dual_mov_b32 v3, v124 :: v_dual_mov_b32 v2, v113         // 0000001D29E0: CA10017C 03020171
	s_mov_b32 s1, 0                                            // 0000001D29E8: BE810080
	s_nop 0                                                    // 0000001D29EC: BF800000
	s_nop 0                                                    // 0000001D29F0: BF800000
	s_nop 0                                                    // 0000001D29F4: BF800000
	s_nop 0                                                    // 0000001D29F8: BF800000
	s_nop 0                                                    // 0000001D29FC: BF800000
	ds_load_b32 v5, v3                                         // 0000001D2A00: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001D2A08: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001D2A10: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001D2A14: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001D2A18: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001D2A20: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001D2A24: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001D2A28: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001D2A30: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001D2A34: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001D2A3C: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001D2A44: 917E017E
	s_cbranch_execnz 65517                                     // 0000001D2A48: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6800>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001D2A4C: 8C7E017E
	s_cmp_lg_u32 s40, s38                                      // 0000001D2A50: BF072628
	s_cbranch_scc1 59114                                       // 0000001D2A54: BFA2E6EA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x400>
	v_dual_mov_b32 v1, v114 :: v_dual_mov_b32 v4, v119         // 0000001D2A58: CA100172 01040177
	v_dual_mov_b32 v3, v124 :: v_dual_mov_b32 v2, v115         // 0000001D2A60: CA10017C 03020173
	s_mov_b32 s1, 0                                            // 0000001D2A68: BE810080
	s_nop 0                                                    // 0000001D2A6C: BF800000
	s_nop 0                                                    // 0000001D2A70: BF800000
	s_nop 0                                                    // 0000001D2A74: BF800000
	s_nop 0                                                    // 0000001D2A78: BF800000
	s_nop 0                                                    // 0000001D2A7C: BF800000
	ds_load_b32 v5, v3                                         // 0000001D2A80: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001D2A88: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001D2A90: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001D2A94: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001D2A98: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001D2AA0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001D2AA4: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001D2AA8: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001D2AB0: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001D2AB4: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001D2ABC: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001D2AC4: 917E017E
	s_cbranch_execnz 65517                                     // 0000001D2AC8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6880>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001D2ACC: 8C7E017E
	s_branch 59083                                             // 0000001D2AD0: BFA0E6CB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x400>
	ds_load_b32 v65, v141                                      // 0000001D2AD4: D8D80000 4100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2ADC: BF89FC07
	v_fma_f32 v25, v25, v65, v57                               // 0000001D2AE0: D6130019 04E68319
	v_mad_u64_u32 v[65:66], null, 0x3000, v142, v[108:109]     // 0000001D2AE8: D6FE7C41 05B31CFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D2AF4: BF870092
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 0000001D2AF8: 103232FF 3B800000
	v_bfe_u32 v57, v25, 16, 1                                  // 0000001D2B00: D6100039 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2B08: BF870001
	v_add3_u32 v25, v25, v57, 0x7fff                           // 0000001D2B0C: D6550019 03FE7319 00007FFF
	global_store_d16_hi_b16 v[65:66], v25, off                 // 0000001D2B18: DC960000 007C1941
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2B20: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001D2B24: BE8E200D
	s_cbranch_execz 64577                                      // 0000001D2B28: BFA5FC41 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a30>
	ds_load_b32 v25, v141 offset:8                             // 0000001D2B2C: D8D80008 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2B34: BF89FC07
	v_fma_f32 v25, v26, v25, v58                               // 0000001D2B38: D6130019 04EA331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D2B40: BF870121
	v_mul_f32_e32 v57, 0x3b800000, v25                         // 0000001D2B44: 107232FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v149, v[108:109]     // 0000001D2B4C: D6FE7C19 05B32AFF 00003000
	v_bfe_u32 v58, v57, 16, 1                                  // 0000001D2B58: D610003A 02052139
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2B60: BF870001
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000001D2B64: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[25:26], v57, off                 // 0000001D2B70: DC960000 007C3919
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2B78: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001D2B7C: BE8E200C
	s_cbranch_execz 64558                                      // 0000001D2B80: BFA5FC2E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a3c>
	ds_load_b32 v25, v141 offset:16                            // 0000001D2B84: D8D80010 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2B8C: BF89FC07
	v_fma_f32 v25, v27, v25, v59                               // 0000001D2B90: D6130019 04EE331B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D2B98: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001D2B9C: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v148, v[108:109]     // 0000001D2BA4: D6FE7C19 05B328FF 00003000
	v_bfe_u32 v57, v27, 16, 1                                  // 0000001D2BB0: D6100039 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2BB8: BF870001
	v_add3_u32 v27, v27, v57, 0x7fff                           // 0000001D2BBC: D655001B 03FE731B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001D2BC8: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2BD0: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001D2BD4: BE8E200A
	s_cbranch_execz 64539                                      // 0000001D2BD8: BFA5FC1B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a48>
	ds_load_b32 v25, v141 offset:24                            // 0000001D2BDC: D8D80018 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2BE4: BF89FC07
	v_fma_f32 v25, v28, v25, v60                               // 0000001D2BE8: D6130019 04F2331C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D2BF0: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001D2BF4: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v147, v[108:109]     // 0000001D2BFC: D6FE7C19 05B326FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001D2C08: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2C10: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001D2C14: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001D2C20: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2C28: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001D2C2C: BE8E2009
	s_cbranch_execz 64520                                      // 0000001D2C30: BFA5FC08 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a54>
	ds_load_b32 v25, v141 offset:32                            // 0000001D2C34: D8D80020 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2C3C: BF89FC07
	v_fma_f32 v25, v29, v25, v61                               // 0000001D2C40: D6130019 04F6331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D2C48: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001D2C4C: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v146, v[108:109]     // 0000001D2C54: D6FE7C19 05B324FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001D2C60: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2C68: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001D2C6C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001D2C78: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2C80: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001D2C84: BE8E2001
	s_cbranch_execz 64501                                      // 0000001D2C88: BFA5FBF5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a60>
	ds_load_b32 v25, v141 offset:40                            // 0000001D2C8C: D8D80028 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2C94: BF89FC07
	v_fma_f32 v25, v30, v25, v62                               // 0000001D2C98: D6130019 04FA331E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D2CA0: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001D2CA4: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v145, v[108:109]     // 0000001D2CAC: D6FE7C19 05B322FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001D2CB8: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2CC0: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001D2CC4: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001D2CD0: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2CD8: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001D2CDC: BE8E2008
	s_cbranch_execz 64482                                      // 0000001D2CE0: BFA5FBE2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a6c>
	ds_load_b32 v25, v141 offset:48                            // 0000001D2CE4: D8D80030 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2CEC: BF89FC07
	v_fma_f32 v25, v31, v25, v63                               // 0000001D2CF0: D6130019 04FE331F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D2CF8: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001D2CFC: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v144, v[108:109]     // 0000001D2D04: D6FE7C19 05B320FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001D2D10: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2D18: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001D2D1C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001D2D28: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2D30: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001D2D34: BE8E2000
	s_cbranch_execz 64463                                      // 0000001D2D38: BFA5FBCF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a78>
	ds_load_b32 v25, v141 offset:56                            // 0000001D2D3C: D8D80038 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2D44: BF89FC07
	v_fma_f32 v25, v32, v25, v64                               // 0000001D2D48: D6130019 05023320
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D2D50: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001D2D54: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v143, v[108:109]     // 0000001D2D5C: D6FE7C19 05B31EFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001D2D68: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2D70: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001D2D74: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001D2D80: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2D88: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001D2D8C: BE8E200B
	s_cbranch_execz 64444                                      // 0000001D2D90: BFA5FBBC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a84>
	ds_load_b32 v25, v141                                      // 0000001D2D94: D8D80000 1900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2D9C: BF89FC07
	v_fma_f32 v9, v9, v25, v49                                 // 0000001D2DA0: D6130009 04C63309
	v_mad_u64_u32 v[25:26], null, 0x3000, v142, v[108:109]     // 0000001D2DA8: D6FE7C19 05B31CFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D2DB4: BF870092
	v_mul_f32_e32 v9, 0x3b800000, v9                           // 0000001D2DB8: 101212FF 3B800000
	v_bfe_u32 v27, v9, 16, 1                                   // 0000001D2DC0: D610001B 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2DC8: BF870001
	v_add3_u32 v9, v9, v27, 0x7fff                             // 0000001D2DCC: D6550009 03FE3709 00007FFF
	global_store_d16_hi_b16 v[25:26], v9, off offset:32        // 0000001D2DD8: DC960020 007C0919
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2DE0: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001D2DE4: BE8E200D
	s_cbranch_execz 64425                                      // 0000001D2DE8: BFA5FBA9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a90>
	ds_load_b32 v9, v141 offset:8                              // 0000001D2DEC: D8D80008 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2DF4: BF89FC07
	v_fma_f32 v9, v10, v9, v50                                 // 0000001D2DF8: D6130009 04CA130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D2E00: BF870121
	v_mul_f32_e32 v25, 0x3b800000, v9                          // 0000001D2E04: 103212FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v149, v[108:109]      // 0000001D2E0C: D6FE7C09 05B32AFF 00003000
	v_bfe_u32 v26, v25, 16, 1                                  // 0000001D2E18: D610001A 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2E20: BF870001
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000001D2E24: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[9:10], v25, off offset:32        // 0000001D2E30: DC960020 007C1909
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2E38: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001D2E3C: BE8E200C
	s_cbranch_execz 64406                                      // 0000001D2E40: BFA5FB96 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a9c>
	ds_load_b32 v9, v141 offset:16                             // 0000001D2E44: D8D80010 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2E4C: BF89FC07
	v_fma_f32 v9, v11, v9, v51                                 // 0000001D2E50: D6130009 04CE130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D2E58: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001D2E5C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v148, v[108:109]      // 0000001D2E64: D6FE7C09 05B328FF 00003000
	v_bfe_u32 v25, v11, 16, 1                                  // 0000001D2E70: D6100019 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2E78: BF870001
	v_add3_u32 v11, v11, v25, 0x7fff                           // 0000001D2E7C: D655000B 03FE330B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001D2E88: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2E90: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001D2E94: BE8E200A
	s_cbranch_execz 64387                                      // 0000001D2E98: BFA5FB83 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5aa8>
	ds_load_b32 v9, v141 offset:24                             // 0000001D2E9C: D8D80018 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2EA4: BF89FC07
	v_fma_f32 v9, v12, v9, v52                                 // 0000001D2EA8: D6130009 04D2130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D2EB0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001D2EB4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v147, v[108:109]      // 0000001D2EBC: D6FE7C09 05B326FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001D2EC8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2ED0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001D2ED4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001D2EE0: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2EE8: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001D2EEC: BE8E2009
	s_cbranch_execz 64368                                      // 0000001D2EF0: BFA5FB70 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5ab4>
	ds_load_b32 v9, v141 offset:32                             // 0000001D2EF4: D8D80020 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2EFC: BF89FC07
	v_fma_f32 v9, v13, v9, v53                                 // 0000001D2F00: D6130009 04D6130D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D2F08: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001D2F0C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v146, v[108:109]      // 0000001D2F14: D6FE7C09 05B324FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001D2F20: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2F28: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001D2F2C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001D2F38: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2F40: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001D2F44: BE8E2001
	s_cbranch_execz 64349                                      // 0000001D2F48: BFA5FB5D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5ac0>
	ds_load_b32 v9, v141 offset:40                             // 0000001D2F4C: D8D80028 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2F54: BF89FC07
	v_fma_f32 v9, v14, v9, v54                                 // 0000001D2F58: D6130009 04DA130E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D2F60: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001D2F64: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v145, v[108:109]      // 0000001D2F6C: D6FE7C09 05B322FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001D2F78: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2F80: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001D2F84: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001D2F90: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2F98: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001D2F9C: BE8E2008
	s_cbranch_execz 64330                                      // 0000001D2FA0: BFA5FB4A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5acc>
	ds_load_b32 v9, v141 offset:48                             // 0000001D2FA4: D8D80030 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D2FAC: BF89FC07
	v_fma_f32 v9, v15, v9, v55                                 // 0000001D2FB0: D6130009 04DE130F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D2FB8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001D2FBC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v144, v[108:109]      // 0000001D2FC4: D6FE7C09 05B320FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001D2FD0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D2FD8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001D2FDC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001D2FE8: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D2FF0: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001D2FF4: BE8E2000
	s_cbranch_execz 64311                                      // 0000001D2FF8: BFA5FB37 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5ad8>
	ds_load_b32 v9, v141 offset:56                             // 0000001D2FFC: D8D80038 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D3004: BF89FC07
	v_fma_f32 v9, v16, v9, v56                                 // 0000001D3008: D6130009 04E21310
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D3010: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001D3014: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v143, v[108:109]      // 0000001D301C: D6FE7C09 05B31EFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001D3028: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3030: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001D3034: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001D3040: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D3048: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001D304C: BE8E200B
	s_cbranch_execz 64292                                      // 0000001D3050: BFA5FB24 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5ae4>
	ds_load_b32 v9, v141                                       // 0000001D3054: D8D80000 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D305C: BF89FC07
	v_fma_f32 v9, v17, v9, v41                                 // 0000001D3060: D6130009 04A61311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D3068: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001D306C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v142, v[108:109]      // 0000001D3074: D6FE7C09 05B31CFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001D3080: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3088: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001D308C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001D3098: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D30A0: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001D30A4: BE8E200D
	s_cbranch_execz 64273                                      // 0000001D30A8: BFA5FB11 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5af0>
	ds_load_b32 v9, v141 offset:8                              // 0000001D30AC: D8D80008 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D30B4: BF89FC07
	v_fma_f32 v9, v18, v9, v42                                 // 0000001D30B8: D6130009 04AA1312
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D30C0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001D30C4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v149, v[108:109]      // 0000001D30CC: D6FE7C09 05B32AFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001D30D8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D30E0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001D30E4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001D30F0: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D30F8: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001D30FC: BE8E200C
	s_cbranch_execz 64254                                      // 0000001D3100: BFA5FAFE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5afc>
	ds_load_b32 v9, v141 offset:16                             // 0000001D3104: D8D80010 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D310C: BF89FC07
	v_fma_f32 v9, v19, v9, v43                                 // 0000001D3110: D6130009 04AE1313
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D3118: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001D311C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v148, v[108:109]      // 0000001D3124: D6FE7C09 05B328FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001D3130: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3138: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001D313C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001D3148: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D3150: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001D3154: BE8E200A
	s_cbranch_execz 64235                                      // 0000001D3158: BFA5FAEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b08>
	ds_load_b32 v9, v141 offset:24                             // 0000001D315C: D8D80018 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D3164: BF89FC07
	v_fma_f32 v9, v20, v9, v44                                 // 0000001D3168: D6130009 04B21314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D3170: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001D3174: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v147, v[108:109]      // 0000001D317C: D6FE7C09 05B326FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001D3188: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3190: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001D3194: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001D31A0: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D31A8: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001D31AC: BE8E2009
	s_cbranch_execz 64216                                      // 0000001D31B0: BFA5FAD8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b14>
	ds_load_b32 v9, v141 offset:32                             // 0000001D31B4: D8D80020 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D31BC: BF89FC07
	v_fma_f32 v9, v21, v9, v45                                 // 0000001D31C0: D6130009 04B61315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D31C8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001D31CC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v146, v[108:109]      // 0000001D31D4: D6FE7C09 05B324FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001D31E0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D31E8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001D31EC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001D31F8: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D3200: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001D3204: BE8E2001
	s_cbranch_execz 64197                                      // 0000001D3208: BFA5FAC5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b20>
	ds_load_b32 v9, v141 offset:40                             // 0000001D320C: D8D80028 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D3214: BF89FC07
	v_fma_f32 v9, v22, v9, v46                                 // 0000001D3218: D6130009 04BA1316
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D3220: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001D3224: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v145, v[108:109]      // 0000001D322C: D6FE7C09 05B322FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001D3238: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3240: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001D3244: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001D3250: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D3258: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001D325C: BE8E2008
	s_cbranch_execz 64178                                      // 0000001D3260: BFA5FAB2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b2c>
	ds_load_b32 v9, v141 offset:48                             // 0000001D3264: D8D80030 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D326C: BF89FC07
	v_fma_f32 v9, v23, v9, v47                                 // 0000001D3270: D6130009 04BE1317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D3278: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001D327C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v144, v[108:109]      // 0000001D3284: D6FE7C09 05B320FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001D3290: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3298: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001D329C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001D32A8: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D32B0: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001D32B4: BE8E2000
	s_cbranch_execz 64159                                      // 0000001D32B8: BFA5FA9F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b38>
	ds_load_b32 v9, v141 offset:56                             // 0000001D32BC: D8D80038 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D32C4: BF89FC07
	v_fma_f32 v9, v24, v9, v48                                 // 0000001D32C8: D6130009 04C21318
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D32D0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001D32D4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v143, v[108:109]      // 0000001D32DC: D6FE7C09 05B31EFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001D32E8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D32F0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001D32F4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001D3300: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D3308: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001D330C: BE8E200B
	s_cbranch_execz 64140                                      // 0000001D3310: BFA5FA8C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b44>
	ds_load_b32 v9, v141                                       // 0000001D3314: D8D80000 0900008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D331C: BF89FC07
	v_fma_f32 v1, v1, v9, v33                                  // 0000001D3320: D6130001 04861301
	v_mad_u64_u32 v[9:10], null, 0x3000, v142, v[108:109]      // 0000001D3328: D6FE7C09 05B31CFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D3334: BF870092
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 0000001D3338: 100202FF 3B800000
	v_bfe_u32 v11, v1, 16, 1                                   // 0000001D3340: D610000B 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3348: BF870001
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001D334C: D6550001 03FE1701 00007FFF
	global_store_d16_hi_b16 v[9:10], v1, off offset:96         // 0000001D3358: DC960060 007C0109
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001D3360: 8C7E0E7E
	s_and_saveexec_b32 s11, s13                                // 0000001D3364: BE8B200D
	s_cbranch_execz 64121                                      // 0000001D3368: BFA5FA79 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b50>
	ds_load_b32 v1, v141 offset:8                              // 0000001D336C: D8D80008 0100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D3374: BF89FC07
	v_fma_f32 v1, v2, v1, v34                                  // 0000001D3378: D6130001 048A0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D3380: BF870121
	v_mul_f32_e32 v9, 0x3b800000, v1                           // 0000001D3384: 101202FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v149, v[108:109]       // 0000001D338C: D6FE7C01 05B32AFF 00003000
	v_bfe_u32 v10, v9, 16, 1                                   // 0000001D3398: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D33A0: BF870001
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000001D33A4: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[1:2], v9, off offset:96          // 0000001D33B0: DC960060 007C0901
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001D33B8: 8C7E0B7E
	s_and_saveexec_b32 s11, s12                                // 0000001D33BC: BE8B200C
	s_cbranch_execz 64102                                      // 0000001D33C0: BFA5FA66 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b5c>
	ds_load_b32 v1, v141 offset:16                             // 0000001D33C4: D8D80010 0100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D33CC: BF89FC07
	v_fma_f32 v1, v3, v1, v35                                  // 0000001D33D0: D6130001 048E0303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D33D8: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001D33DC: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v148, v[108:109]       // 0000001D33E4: D6FE7C01 05B328FF 00003000
	v_bfe_u32 v9, v3, 16, 1                                    // 0000001D33F0: D6100009 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D33F8: BF870001
	v_add3_u32 v3, v3, v9, 0x7fff                              // 0000001D33FC: D6550003 03FE1303 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001D3408: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001D3410: 8C7E0B7E
	s_and_saveexec_b32 s11, s10                                // 0000001D3414: BE8B200A
	s_cbranch_execz 64083                                      // 0000001D3418: BFA5FA53 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b68>
	ds_load_b32 v1, v141 offset:24                             // 0000001D341C: D8D80018 0100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D3424: BF89FC07
	v_fma_f32 v1, v4, v1, v36                                  // 0000001D3428: D6130001 04920304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D3430: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001D3434: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v147, v[108:109]       // 0000001D343C: D6FE7C01 05B326FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001D3448: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3450: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001D3454: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001D3460: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001D3468: 8C7E0B7E
	s_and_saveexec_b32 s10, s9                                 // 0000001D346C: BE8A2009
	s_cbranch_execz 64064                                      // 0000001D3470: BFA5FA40 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b74>
	ds_load_b32 v1, v141 offset:32                             // 0000001D3474: D8D80020 0100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D347C: BF89FC07
	v_fma_f32 v1, v5, v1, v37                                  // 0000001D3480: D6130001 04960305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D3488: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001D348C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v146, v[108:109]       // 0000001D3494: D6FE7C01 05B324FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001D34A0: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D34A8: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001D34AC: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001D34B8: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001D34C0: 8C7E0A7E
	s_and_saveexec_b32 s9, s1                                  // 0000001D34C4: BE892001
	s_cbranch_execz 64045                                      // 0000001D34C8: BFA5FA2D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b80>
	ds_load_b32 v1, v141 offset:40                             // 0000001D34CC: D8D80028 0100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D34D4: BF89FC07
	v_fma_f32 v1, v6, v1, v38                                  // 0000001D34D8: D6130001 049A0306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D34E0: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001D34E4: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v145, v[108:109]       // 0000001D34EC: D6FE7C01 05B322FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001D34F8: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3500: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001D3504: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001D3510: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s9                              // 0000001D3518: 8C7E097E
	s_and_saveexec_b32 s1, s8                                  // 0000001D351C: BE812008
	s_cbranch_execz 64026                                      // 0000001D3520: BFA5FA1A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b8c>
	ds_load_b32 v1, v141 offset:48                             // 0000001D3524: D8D80030 0100008D
	s_waitcnt lgkmcnt(0)                                       // 0000001D352C: BF89FC07
	v_fma_f32 v1, v7, v1, v39                                  // 0000001D3530: D6130001 049E0307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D3538: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001D353C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v144, v[108:109]       // 0000001D3544: D6FE7C01 05B320FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001D3550: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D3558: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001D355C: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001D3568: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001D3570: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000001D3574: BE812000
	s_cbranch_execnz 64007                                     // 0000001D3578: BFA6FA07 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b98>
	s_branch 64024                                             // 0000001D357C: BFA0FA18 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5be0>
	v_dual_mov_b32 v1, s48 :: v_dual_mov_b32 v2, s49           // 0000001D3580: CA100030 01020031
	v_mov_b32_e32 v6, v119                                     // 0000001D3588: 7E0C0377
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D358C: BF870092
	.long 0xd7006a00                                           // 0000001D3590: D7006A00
	v_cndmask_b32_e32 v0, v1, v18, vcc_lo                      // 0000001D3594: 02002501
	v_add_co_ci_u32_e64 v1, null, s19, v2, vcc_lo              // 0000001D3598: D5207C01 01AA0413
	s_add_u32 s0, s33, s34                                     // 0000001D35A0: 80002221
	s_addc_u32 s1, s15, s35                                    // 0000001D35A4: 8201230F
	.long 0xd7006a00                                           // 0000001D35A8: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000001D35AC: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001D35B0: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000001D35B4: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000001D35BC: BE810080
	.long 0xd7006a00                                           // 0000001D35C0: D7006A00
	v_cndmask_b32_e32 v1, v0, v106, vcc_lo                     // 0000001D35C4: 0202D500
	v_add_co_ci_u32_e64 v1, null, v1, v107, vcc_lo             // 0000001D35C8: D5207C01 01AAD701
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D35D0: BF870092
	.long 0xd7006a00                                           // 0000001D35D4: D7006A00
	v_cndmask_b32_e32 v1, v0, v118, vcc_lo                     // 0000001D35D8: 0202ED00
	v_add_co_ci_u32_e64 v1, null, v1, v131, vcc_lo             // 0000001D35DC: D5207C01 01AB0701
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D35E4: BF870092
	.long 0xd7006a00                                           // 0000001D35E8: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000001D35EC: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000001D35F0: D5207C01 01AA0211
	s_nop 0                                                    // 0000001D35F8: BF800000
	s_nop 0                                                    // 0000001D35FC: BF800000
	ds_load_b32 v2, v124                                       // 0000001D3600: D8D80000 0200007C
	v_add_nc_u32_e32 v6, 0x80, v6                              // 0000001D3608: 4A0C0CFF 00000080
	v_add_nc_u32_e32 v124, 8, v124                             // 0000001D3610: 4AF8F888
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001D3614: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v6                        // 0000001D3618: 7C920CFF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001D3620: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001D3624: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000001D3628: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000001D3630: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 0000001D3634: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000001D363C: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001D3644: 917E017E
	s_cbranch_execnz 65517                                     // 0000001D3648: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7400>
	s_nop 0                                                    // 0000001D364C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001D3650: BFB60003
	s_endpgm                                                   // 0000001D3654: BFB00000
		...

