0000000000219900 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii>:
; _ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii():
	s_load_b256 s[4:11], s[0:1], null                          // 000000219900: F40C0100 F8000000
	s_mov_b32 s20, s3                                          // 000000219908: BE940003
	s_ashr_i32 s21, s3, 31                                     // 00000021990C: 86159F03
	s_load_b128 s[12:15], s[0:1], 0x30                         // 000000219910: F4080300 F8000030
	s_lshl_b64 s[2:3], s[20:21], 5                             // 000000219918: 84828514
	v_dual_mov_b32 v2, 0xff800000 :: v_dual_lshlrev_b32 v1, 2, v0// 00000021991C: CA2200FF 02000082 FF800000
	s_waitcnt lgkmcnt(0)                                       // 000000219928: BF89FC07
	s_add_u32 s2, s8, s2                                       // 00000021992C: 80020208
	s_addc_u32 s3, s9, s3                                      // 000000219930: 82030309
	s_mov_b32 s8, exec_lo                                      // 000000219934: BE88007E
	s_clause 0x1                                               // 000000219938: BF850001
	s_load_b32 s22, s[2:3], null                               // 00000021993C: F4000581 F8000000
	s_load_b32 s15, s[2:3], 0xc                                // 000000219944: F40003C1 F800000C
	s_mul_i32 s2, s20, 0x4048                                  // 00000021994C: 9602FF14 00004048
	s_mul_hi_i32 s3, s20, 0x4048                               // 000000219954: 9703FF14 00004048
	s_add_u32 s2, s10, s2                                      // 00000021995C: 8002020A
	s_addc_u32 s3, s11, s3                                     // 000000219960: 8203030B
	.long 0xd4c4007e                                           // 000000219964: D4C4007E
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 000000219968: 0202000E
	s_cbranch_execz 2                                          // 00000021996C: BFA50002 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x78>
	global_load_b32 v2, v1, s[2:3]                             // 000000219970: DC520000 02020001
	s_or_b32 exec_lo, exec_lo, s8                              // 000000219978: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000021997C: BF870009
	s_mov_b32 s8, exec_lo                                      // 000000219980: BE88007E
	s_waitcnt vmcnt(0)                                         // 000000219984: BF8903F7
	ds_store_b32 v1, v2                                        // 000000219988: D8340000 00000201
	s_waitcnt lgkmcnt(0)                                       // 000000219990: BF89FC07
	s_barrier                                                  // 000000219994: BFBD0000
	buffer_gl0_inv                                             // 000000219998: E0AC0000 00000000
	v_cmpx_gt_u32_e32 0x80, v0                                 // 0000002199A0: 7D9800FF 00000080
	s_cbranch_execz 9                                          // 0000002199A8: BFA50009 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0xd0>
	ds_load_2addr_stride64_b32 v[2:3], v1 offset1:2            // 0000002199AC: D8E00200 02000001
	s_waitcnt lgkmcnt(0)                                       // 0000002199B4: BF89FC07
	v_dual_max_f32 v3, v3, v3 :: v_dual_max_f32 v2, v2, v2     // 0000002199B8: CA940703 03020502
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002199C0: BF870001
	v_max_f32_e32 v2, v2, v3                                   // 0000002199C4: 20040702
	ds_store_b32 v1, v2                                        // 0000002199C8: D8340000 00000201
	s_or_b32 exec_lo, exec_lo, s8                              // 0000002199D0: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002199D4: BF870009
	s_mov_b32 s8, exec_lo                                      // 0000002199D8: BE88007E
	s_waitcnt lgkmcnt(0)                                       // 0000002199DC: BF89FC07
	s_barrier                                                  // 0000002199E0: BFBD0000
	buffer_gl0_inv                                             // 0000002199E4: E0AC0000 00000000
	v_cmpx_gt_u32_e32 64, v0                                   // 0000002199EC: 7D9800C0
	s_cbranch_execz 9                                          // 0000002199F0: BFA50009 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x118>
	ds_load_2addr_stride64_b32 v[2:3], v1 offset1:1            // 0000002199F4: D8E00100 02000001
	s_waitcnt lgkmcnt(0)                                       // 0000002199FC: BF89FC07
	v_dual_max_f32 v3, v3, v3 :: v_dual_max_f32 v2, v2, v2     // 000000219A00: CA940703 03020502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219A08: BF870001
	v_max_f32_e32 v2, v2, v3                                   // 000000219A0C: 20040702
	ds_store_b32 v1, v2                                        // 000000219A10: D8340000 00000201
	s_or_b32 exec_lo, exec_lo, s8                              // 000000219A18: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000219A1C: BF870009
	s_mov_b32 s8, exec_lo                                      // 000000219A20: BE88007E
	s_waitcnt lgkmcnt(0)                                       // 000000219A24: BF89FC07
	s_barrier                                                  // 000000219A28: BFBD0000
	buffer_gl0_inv                                             // 000000219A2C: E0AC0000 00000000
	v_cmpx_gt_u32_e32 32, v0                                   // 000000219A34: 7D9800A0
	s_cbranch_execz 9                                          // 000000219A38: BFA50009 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x160>
	ds_load_2addr_b32 v[2:3], v1 offset1:32                    // 000000219A3C: D8DC2000 02000001
	s_waitcnt lgkmcnt(0)                                       // 000000219A44: BF89FC07
	v_dual_max_f32 v3, v3, v3 :: v_dual_max_f32 v2, v2, v2     // 000000219A48: CA940703 03020502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219A50: BF870001
	v_max_f32_e32 v2, v2, v3                                   // 000000219A54: 20040702
	ds_store_b32 v1, v2                                        // 000000219A58: D8340000 00000201
	s_or_b32 exec_lo, exec_lo, s8                              // 000000219A60: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000219A64: BF870009
	s_mov_b32 s8, exec_lo                                      // 000000219A68: BE88007E
	s_waitcnt lgkmcnt(0)                                       // 000000219A6C: BF89FC07
	s_barrier                                                  // 000000219A70: BFBD0000
	buffer_gl0_inv                                             // 000000219A74: E0AC0000 00000000
	v_cmpx_gt_u32_e32 16, v0                                   // 000000219A7C: 7D980090
	s_cbranch_execz 9                                          // 000000219A80: BFA50009 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x1a8>
	ds_load_2addr_b32 v[2:3], v1 offset1:16                    // 000000219A84: D8DC1000 02000001
	s_waitcnt lgkmcnt(0)                                       // 000000219A8C: BF89FC07
	v_dual_max_f32 v3, v3, v3 :: v_dual_max_f32 v2, v2, v2     // 000000219A90: CA940703 03020502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219A98: BF870001
	v_max_f32_e32 v2, v2, v3                                   // 000000219A9C: 20040702
	ds_store_b32 v1, v2                                        // 000000219AA0: D8340000 00000201
	s_or_b32 exec_lo, exec_lo, s8                              // 000000219AA8: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000219AAC: BF870009
	s_mov_b32 s8, exec_lo                                      // 000000219AB0: BE88007E
	s_waitcnt lgkmcnt(0)                                       // 000000219AB4: BF89FC07
	s_barrier                                                  // 000000219AB8: BFBD0000
	buffer_gl0_inv                                             // 000000219ABC: E0AC0000 00000000
	v_cmpx_gt_u32_e32 8, v0                                    // 000000219AC4: 7D980088
	s_cbranch_execz 9                                          // 000000219AC8: BFA50009 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x1f0>
	ds_load_2addr_b32 v[2:3], v1 offset1:8                     // 000000219ACC: D8DC0800 02000001
	s_waitcnt lgkmcnt(0)                                       // 000000219AD4: BF89FC07
	v_dual_max_f32 v3, v3, v3 :: v_dual_max_f32 v2, v2, v2     // 000000219AD8: CA940703 03020502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219AE0: BF870001
	v_max_f32_e32 v2, v2, v3                                   // 000000219AE4: 20040702
	ds_store_b32 v1, v2                                        // 000000219AE8: D8340000 00000201
	s_or_b32 exec_lo, exec_lo, s8                              // 000000219AF0: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000219AF4: BF870009
	s_mov_b32 s8, exec_lo                                      // 000000219AF8: BE88007E
	s_waitcnt lgkmcnt(0)                                       // 000000219AFC: BF89FC07
	s_barrier                                                  // 000000219B00: BFBD0000
	buffer_gl0_inv                                             // 000000219B04: E0AC0000 00000000
	v_cmpx_gt_u32_e32 4, v0                                    // 000000219B0C: 7D980084
	s_cbranch_execz 9                                          // 000000219B10: BFA50009 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x238>
	ds_load_2addr_b32 v[2:3], v1 offset1:4                     // 000000219B14: D8DC0400 02000001
	s_waitcnt lgkmcnt(0)                                       // 000000219B1C: BF89FC07
	v_dual_max_f32 v3, v3, v3 :: v_dual_max_f32 v2, v2, v2     // 000000219B20: CA940703 03020502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219B28: BF870001
	v_max_f32_e32 v2, v2, v3                                   // 000000219B2C: 20040702
	ds_store_b32 v1, v2                                        // 000000219B30: D8340000 00000201
	s_or_b32 exec_lo, exec_lo, s8                              // 000000219B38: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000219B3C: BF870009
	s_mov_b32 s8, exec_lo                                      // 000000219B40: BE88007E
	s_waitcnt lgkmcnt(0)                                       // 000000219B44: BF89FC07
	s_barrier                                                  // 000000219B48: BFBD0000
	buffer_gl0_inv                                             // 000000219B4C: E0AC0000 00000000
	v_cmpx_gt_u32_e32 2, v0                                    // 000000219B54: 7D980082
	s_cbranch_execz 9                                          // 000000219B58: BFA50009 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x280>
	ds_load_2addr_b32 v[2:3], v1 offset1:2                     // 000000219B5C: D8DC0200 02000001
	s_waitcnt lgkmcnt(0)                                       // 000000219B64: BF89FC07
	v_dual_max_f32 v3, v3, v3 :: v_dual_max_f32 v2, v2, v2     // 000000219B68: CA940703 03020502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219B70: BF870001
	v_max_f32_e32 v2, v2, v3                                   // 000000219B74: 20040702
	ds_store_b32 v1, v2                                        // 000000219B78: D8340000 00000201
	s_or_b32 exec_lo, exec_lo, s8                              // 000000219B80: 8C7E087E
	s_load_b128 s[16:19], s[0:1], 0x20                         // 000000219B84: F4080400 F8000020
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000219B8C: 7C940080
	s_waitcnt lgkmcnt(0)                                       // 000000219B90: BF89FC07
	s_barrier                                                  // 000000219B94: BFBD0000
	buffer_gl0_inv                                             // 000000219B98: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 000000219BA0: BE80206A
	s_cbranch_execz 13                                         // 000000219BA4: BFA5000D <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x2dc>
	v_mov_b32_e32 v0, 0                                        // 000000219BA8: 7E000280
	ds_load_b32 v0, v0 offset:4                                // 000000219BAC: D8D80004 00000000
	ds_load_b32 v2, v1                                         // 000000219BB4: D8D80000 02000001
	s_waitcnt lgkmcnt(1)                                       // 000000219BBC: BF89FC17
	v_max_f32_e32 v0, v0, v0                                   // 000000219BC0: 20000100
	s_waitcnt lgkmcnt(0)                                       // 000000219BC4: BF89FC07
	v_max_f32_e32 v2, v2, v2                                   // 000000219BC8: 20040502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219BCC: BF870001
	v_max_f32_e32 v0, v2, v0                                   // 000000219BD0: 20000102
	ds_store_b32 v1, v0                                        // 000000219BD4: D8340000 00000001
	s_or_b32 exec_lo, exec_lo, s0                              // 000000219BDC: 8C7E007E
	v_mov_b32_e32 v0, 0                                        // 000000219BE0: 7E000280
	s_waitcnt lgkmcnt(0)                                       // 000000219BE4: BF89FC07
	s_barrier                                                  // 000000219BE8: BFBD0000
	buffer_gl0_inv                                             // 000000219BEC: E0AC0000 00000000
	ds_load_b32 v0, v0                                         // 000000219BF4: D8D80000 00000000
	s_waitcnt lgkmcnt(0)                                       // 000000219BFC: BF89FC07
	s_barrier                                                  // 000000219C00: BFBD0000
	buffer_gl0_inv                                             // 000000219C04: E0AC0000 00000000
	s_and_saveexec_b32 s8, vcc_lo                              // 000000219C0C: BE88206A
	s_cbranch_execz 29                                         // 000000219C10: BFA5001D <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x388>
	s_cmp_lt_i32 s14, 1                                        // 000000219C14: BF04810E
	s_cbranch_scc1 21                                          // 000000219C18: BFA20015 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x370>
	s_mul_i32 s0, s20, 0x4048                                  // 000000219C1C: 9600FF14 00004048
	s_mul_hi_i32 s1, s20, 0x4048                               // 000000219C24: 9701FF14 00004048
	s_add_u32 s0, s10, s0                                      // 000000219C2C: 8000000A
	s_addc_u32 s1, s11, s1                                     // 000000219C30: 8201010B
	s_add_u32 s0, s0, 0x400                                    // 000000219C34: 8000FF00 00000400
	s_addc_u32 s1, s1, 0                                       // 000000219C3C: 82018001
	s_mov_b32 s9, 0                                            // 000000219C40: BE890080
	s_mov_b32 s23, s14                                         // 000000219C44: BE97000E
	s_load_b32 s24, s[0:1], null                               // 000000219C48: F4000600 F8000000
	s_add_i32 s23, s23, -1                                     // 000000219C50: 8117C117
	s_add_u32 s0, s0, 4                                        // 000000219C54: 80008400
	s_addc_u32 s1, s1, 0                                       // 000000219C58: 82018001
	s_cmp_eq_u32 s23, 0                                        // 000000219C5C: BF068017
	s_waitcnt lgkmcnt(0)                                       // 000000219C60: BF89FC07
	s_add_f32 s9, s9, s24                                      // 000000219C64: A0091809
	s_cbranch_scc0 65527                                       // 000000219C68: BFA1FFF7 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x348>
	s_branch 1                                                 // 000000219C6C: BFA00001 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x374>
	s_mov_b32 s9, 0                                            // 000000219C70: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000219C74: BF870009
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, s9              // 000000219C78: CA100080 01020009
	ds_store_b32 v1, v2 offset:1024                            // 000000219C80: D8340400 00000201
	s_or_b32 exec_lo, exec_lo, s8                              // 000000219C88: 8C7E087E
	v_mov_b32_e32 v1, 0                                        // 000000219C8C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000219C90: BF89FC07
	s_barrier                                                  // 000000219C94: BFBD0000
	buffer_gl0_inv                                             // 000000219C98: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:1024                             // 000000219CA0: D8D80400 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000219CA8: BF89FC07
	s_barrier                                                  // 000000219CAC: BFBD0000
	buffer_gl0_inv                                             // 000000219CB0: E0AC0000 00000000
	s_and_saveexec_b32 s8, vcc_lo                              // 000000219CB8: BE88206A
	s_cbranch_execz 28                                         // 000000219CBC: BFA5001C <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x430>
	s_cmp_lt_i32 s14, 1                                        // 000000219CC0: BF04810E
	s_cbranch_scc1 20                                          // 000000219CC4: BFA20014 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x418>
	s_mul_i32 s0, s20, 0x4048                                  // 000000219CC8: 9600FF14 00004048
	s_mul_hi_i32 s1, s20, 0x4048                               // 000000219CD0: 9701FF14 00004048
	s_add_u32 s0, s10, s0                                      // 000000219CD8: 8000000A
	s_addc_u32 s1, s11, s1                                     // 000000219CDC: 8201010B
	s_add_u32 s0, s0, 0x800                                    // 000000219CE0: 8000FF00 00000800
	s_addc_u32 s1, s1, 0                                       // 000000219CE8: 82018001
	s_mov_b32 s9, 0                                            // 000000219CEC: BE890080
	s_load_b32 s10, s[0:1], null                               // 000000219CF0: F4000280 F8000000
	s_add_i32 s14, s14, -1                                     // 000000219CF8: 810EC10E
	s_add_u32 s0, s0, 4                                        // 000000219CFC: 80008400
	s_addc_u32 s1, s1, 0                                       // 000000219D00: 82018001
	s_cmp_eq_u32 s14, 0                                        // 000000219D04: BF06800E
	s_waitcnt lgkmcnt(0)                                       // 000000219D08: BF89FC07
	s_add_f32 s9, s9, s10                                      // 000000219D0C: A0090A09
	s_cbranch_scc0 65527                                       // 000000219D10: BFA1FFF7 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x3f0>
	s_branch 1                                                 // 000000219D14: BFA00001 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x41c>
	s_mov_b32 s9, 0                                            // 000000219D18: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000219D1C: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s9              // 000000219D20: CA100080 02020009
	ds_store_b32 v2, v3 offset:1028                            // 000000219D28: D8340404 00000302
	s_or_b32 exec_lo, exec_lo, s8                              // 000000219D30: 8C7E087E
	v_mov_b32_e32 v3, 0                                        // 000000219D34: 7E060280
	s_waitcnt lgkmcnt(0)                                       // 000000219D38: BF89FC07
	s_barrier                                                  // 000000219D3C: BFBD0000
	buffer_gl0_inv                                             // 000000219D40: E0AC0000 00000000
	ds_load_b32 v2, v3 offset:1028                             // 000000219D48: D8D80404 02000003
	s_waitcnt lgkmcnt(0)                                       // 000000219D50: BF89FC07
	s_barrier                                                  // 000000219D54: BFBD0000
	buffer_gl0_inv                                             // 000000219D58: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 000000219D60: BE80206A
	s_cbranch_execz 148                                        // 000000219D64: BFA50094 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x6b8>
	s_lshl_b64 s[8:9], s[20:21], 2                             // 000000219D68: 84888214
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000219D6C: BF870009
	s_add_u32 s0, s6, s8                                       // 000000219D70: 80000806
	s_addc_u32 s1, s7, s9                                      // 000000219D74: 82010907
	s_load_b32 s0, s[0:1], null                                // 000000219D78: F4000000 F8000000
	s_waitcnt lgkmcnt(0)                                       // 000000219D80: BF89FC07
	s_cmp_lt_i32 s0, 0                                         // 000000219D84: BF048000
	s_cbranch_scc1 123                                         // 000000219D88: BFA2007B <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x678>
	v_cmp_nlt_f32_e32 vcc_lo, 0, v2                            // 000000219D8C: 7C3C0480
	s_cmp_ge_i32 s0, s12                                       // 000000219D90: BF030C00
	s_cselect_b32 s1, -1, 0                                    // 000000219D94: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000219D98: BF870499
	s_or_b32 s1, vcc_lo, s1                                    // 000000219D9C: 8C01016A
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000219DA0: 8B6A017E
	s_cbranch_vccnz 115                                        // 000000219DA4: BFA40073 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x674>
	v_div_scale_f32 v3, null, s22, s22, 1.0                    // 000000219DA8: D6FC7C03 03C82C16
	v_div_scale_f32 v6, vcc_lo, 1.0, s22, 1.0                  // 000000219DB0: D6FC6A06 03C82CF2
	s_mul_hi_i32 s7, s12, s20                                  // 000000219DB8: 9707140C
	s_mul_i32 s6, s12, s20                                     // 000000219DBC: 9606140C
	s_mov_b32 s1, 0                                            // 000000219DC0: BE810080
	v_rcp_f32_e32 v4, v3                                       // 000000219DC4: 7E085503
	v_xor_b32_e32 v3, 0x80000000, v3                           // 000000219DC8: 3A0606FF 80000000
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000219DD0: 84868206
	s_load_b32 s2, s[2:3], 0x4040                              // 000000219DD4: F4000081 F8004040
	s_add_u32 s4, s4, s6                                       // 000000219DDC: 80040604
	s_addc_u32 s5, s5, s7                                      // 000000219DE0: 82050705
	s_lshl_b64 s[0:1], s[0:1], 2                               // 000000219DE4: 84808200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000219DE8: BF8702A9
	s_add_u32 s0, s4, s0                                       // 000000219DEC: 80000004
	s_addc_u32 s1, s5, s1                                      // 000000219DF0: 82010105
	v_fma_f32 v5, v3, v4, 1.0                                  // 000000219DF4: D6130005 03CA0903
	s_load_b32 s1, s[0:1], null                                // 000000219DFC: F4000040 F8000000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000219E04: BF870091
	v_fmac_f32_e32 v4, v5, v4                                  // 000000219E08: 56080905
	v_mul_f32_e32 v5, v6, v4                                   // 000000219E0C: 100A0906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000219E10: BF870091
	v_fma_f32 v7, v3, v5, v6                                   // 000000219E14: D6130007 041A0B03
	v_fmac_f32_e32 v5, v7, v4                                  // 000000219E1C: 560A0907
	s_waitcnt lgkmcnt(0)                                       // 000000219E20: BF89FC07
	s_not_b32 s3, s1                                           // 000000219E24: BE831E01
	s_or_b32 s4, s1, 0x80000000                                // 000000219E28: 8C04FF01 80000000
	s_cmp_lt_i32 s1, 0                                         // 000000219E30: BF048001
	v_fmac_f32_e32 v6, v3, v5                                  // 000000219E34: 560C0B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000219E38: BF870121
	v_div_fmas_f32 v3, v6, v4, v5                              // 000000219E3C: D6370003 04160906
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v1                      // 000000219E44: 7C2802FF 00800000
	v_div_fixup_f32 v5, v3, s22, 1.0                           // 000000219E4C: D6270005 03C82D03
	v_cndmask_b32_e64 v3, 1.0, 0x4f800000, vcc_lo              // 000000219E54: D5010003 01A9FEF2 4F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000219E60: BF870091
	v_mul_f32_e32 v1, v1, v3                                   // 000000219E64: 10020701
	v_log_f32_e32 v1, v1                                       // 000000219E68: 7E024F01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000219E6C: BF870125
	v_mul_f32_e32 v7, 0x3f317217, v1                           // 000000219E70: 100E02FF 3F317217
	v_and_b32_e32 v12, 0x7fffffff, v1                          // 000000219E78: 361802FF 7FFFFFFF
	v_xor_b32_e32 v9, 0x80000000, v7                           // 000000219E80: 3A120EFF 80000000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000219E88: BF870091
	v_dual_sub_f32 v4, s1, v0 :: v_dual_fmac_f32 v9, 0x3f317217, v1// 000000219E8C: C9400001 040802FF 3F317217
	v_fmamk_f32 v9, v1, 0x3377d1cf, v9                         // 000000219E98: 58121301 3377D1CF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000219EA0: BF8701B1
	v_dual_mul_f32 v0, v5, v4 :: v_dual_add_f32 v7, v7, v9     // 000000219EA4: C8C80905 00061307
	v_cndmask_b32_e64 v9, 0, 0x41b17218, vcc_lo                // 000000219EAC: D5010009 01A9FE80 41B17218
	v_cmp_gt_f32_e32 vcc_lo, 0x7f800000, v12                   // 000000219EB8: 7C2818FF 7F800000
	v_dual_mul_f32 v0, 0x3fb8aa3b, v0 :: v_dual_cndmask_b32 v1, v1, v7// 000000219EC0: C8D200FF 00000F01 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000219ECC: BF870091
	v_exp_f32_e32 v0, v0                                       // 000000219ED0: 7E004B00
	v_sub_f32_e32 v1, v1, v9                                   // 000000219ED4: 08021301
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000219ED8: BF870005
	v_div_scale_f32 v3, null, v2, v2, v0                       // 000000219EDC: D6FC7C03 04020502
	v_div_scale_f32 v10, s0, v0, v2, v0                        // 000000219EE4: D6FC000A 04020500
	s_mov_b32 vcc_lo, s0                                       // 000000219EEC: BEEA0000
	s_cselect_b32 s0, s3, s4                                   // 000000219EF0: 98000403
	v_rcp_f32_e32 v6, v3                                       // 000000219EF4: 7E0C5503
	v_xor_b32_e32 v3, 0x80000000, v3                           // 000000219EF8: 3A0606FF 80000000
	s_cmp_lt_u32 s0, s2                                        // 000000219F00: BF0A0200
	s_cselect_b32 s0, -1, 0                                    // 000000219F04: 980080C1
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 000000219F08: BF870085
	v_fma_f32 v8, v3, v6, 1.0                                  // 000000219F0C: D6130008 03CA0D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000219F14: BF870091
	v_fmac_f32_e32 v6, v8, v6                                  // 000000219F18: 560C0D08
	v_mul_f32_e32 v8, v10, v6                                  // 000000219F1C: 10100D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000219F20: BF870091
	v_fma_f32 v11, v3, v8, v10                                 // 000000219F24: D613000B 042A1103
	v_fmac_f32_e32 v8, v11, v6                                 // 000000219F2C: 56100D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000219F30: BF870091
	v_fmac_f32_e32 v10, v3, v8                                 // 000000219F34: 56141103
	v_div_fmas_f32 v3, v10, v6, v8                             // 000000219F38: D6370003 04220D0A
	v_cmp_nle_f32_e32 vcc_lo, s15, v0                          // 000000219F40: 7C38000F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000219F44: BF870002
	v_div_fixup_f32 v2, v3, v2, v0                             // 000000219F48: D6270002 04020503
	v_xor_b32_e32 v0, 0x80000000, v1                           // 000000219F50: 3A0002FF 80000000
	s_or_b32 s0, s0, vcc_lo                                    // 000000219F58: 8C006A00
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 000000219F5C: BF870482
	v_cndmask_b32_e64 v3, v2, 0, s0                            // 000000219F60: D5010003 00010102
	s_delay_alu instid0(VALU_DEP_2)                            // 000000219F68: BF870002
	v_fmac_f32_e32 v0, v5, v4                                  // 000000219F6C: 56000905
	s_branch 3                                                 // 000000219F70: BFA00003 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x680>
	v_mov_b32_e32 v3, 0                                        // 000000219F74: 7E060280
	v_mov_b32_e32 v0, 0xff800000                               // 000000219F78: 7E0002FF FF800000
	s_cmp_lg_u32 s13, 3                                        // 000000219F80: BF07830D
	v_mov_b32_e32 v1, 0                                        // 000000219F84: 7E020280
	s_cselect_b32 vcc_lo, -1, 0                                // 000000219F88: 986A80C1
	s_add_u32 s0, s16, s8                                      // 000000219F8C: 80000810
	v_cndmask_b32_e32 v2, 1.0, v3, vcc_lo                      // 000000219F90: 020406F2
	s_addc_u32 s1, s17, s9                                     // 000000219F94: 82010911
	s_cmp_eq_u64 s[18:19], 0                                   // 000000219F98: BF108012
	global_store_b32 v1, v2, s[0:1]                            // 000000219F9C: DC6A0000 00000201
	s_cbranch_scc1 4                                           // 000000219FA4: BFA20004 <_ZN7halogen19k_smpg_accept_finalEPKfPKiPKNS_9SampleRowEPKNS_10SmpScratchEPfSA_iii+0x6b8>
	s_add_u32 s0, s18, s8                                      // 000000219FA8: 80000812
	s_addc_u32 s1, s19, s9                                     // 000000219FAC: 82010913
	global_store_b32 v1, v0, s[0:1]                            // 000000219FB0: DC6A0000 00000001
	s_endpgm                                                   // 000000219FB8: BFB00000
	s_nop 0                                                    // 000000219FBC: BF800000
	s_nop 0                                                    // 000000219FC0: BF800000
	s_nop 0                                                    // 000000219FC4: BF800000
	s_nop 0                                                    // 000000219FC8: BF800000
	s_nop 0                                                    // 000000219FCC: BF800000
	s_nop 0                                                    // 000000219FD0: BF800000
	s_nop 0                                                    // 000000219FD4: BF800000
	s_nop 0                                                    // 000000219FD8: BF800000
	s_nop 0                                                    // 000000219FDC: BF800000
	s_nop 0                                                    // 000000219FE0: BF800000
	s_nop 0                                                    // 000000219FE4: BF800000
	s_nop 0                                                    // 000000219FE8: BF800000
	s_nop 0                                                    // 000000219FEC: BF800000
	s_nop 0                                                    // 000000219FF0: BF800000
	s_nop 0                                                    // 000000219FF4: BF800000
	s_nop 0                                                    // 000000219FF8: BF800000
	s_nop 0                                                    // 000000219FFC: BF800000

