000000000014c900 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_load_b256 s[12:19], s[0:1], 0x38                         // 00000014C900: F40C0300 F8000038
	s_lshl_b32 s4, s3, 6                                       // 00000014C908: 84048603
	s_ashr_i32 s3, s2, 31                                      // 00000014C90C: 86039F02
	s_ashr_i32 s5, s4, 31                                      // 00000014C910: 86059F04
	v_and_b32_e32 v74, 63, v0                                  // 00000014C914: 369400BF
	s_movk_i32 s7, 0x210                                       // 00000014C918: B0070210
	v_mov_b32_e32 v4, v0                                       // 00000014C91C: 7E080300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000014C920: BF8704D2
	v_lshlrev_b32_e32 v2, 2, v74                               // 00000014C924: 30049482
	v_mad_u32_u24 v1, v74, s7, 0x3200                          // 00000014C928: D60B0001 03FC0F4A 00003200
	s_waitcnt lgkmcnt(0)                                       // 00000014C934: BF89FC07
	s_load_b32 s6, s[14:15], null                              // 00000014C938: F4000187 F8000000
	s_lshl_b64 s[14:15], s[16:17], 2                           // 00000014C940: 848E8210
	s_add_u32 s8, s12, s14                                     // 00000014C944: 80080E0C
	s_addc_u32 s9, s13, s15                                    // 00000014C948: 82090F0D
	s_lshl_b64 s[16:17], s[2:3], 16                            // 00000014C94C: 84909002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014C950: BF870009
	s_add_u32 s8, s8, s16                                      // 00000014C954: 80081008
	s_addc_u32 s9, s9, s17                                     // 00000014C958: 82091109
	s_waitcnt lgkmcnt(0)                                       // 00000014C95C: BF89FC07
	s_mul_i32 s33, s6, 0x9000000                               // 00000014C960: 9621FF06 09000000
	s_mul_hi_i32 s34, s6, 0x9000000                            // 00000014C968: 9722FF06 09000000
	s_add_u32 s6, s8, s33                                      // 00000014C970: 80062108
	s_addc_u32 s8, s9, s34                                     // 00000014C974: 82082209
	s_lshl_b64 s[28:29], s[4:5], 2                             // 00000014C978: 849C8204
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000014C97C: BF8700B9
	s_add_u32 s6, s6, s28                                      // 00000014C980: 80061C06
	s_addc_u32 s7, s8, s29                                     // 00000014C984: 82071D08
	.long 0xd7000602                                           // 00000014C988: D7000602
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 00000014C98C: 02020406
	v_add_co_ci_u32_e64 v3, null, s7, 0, s6                    // 00000014C990: D5207C03 00190007
	s_mov_b32 s6, 0                                            // 00000014C998: BE860080
	s_nop 0                                                    // 00000014C99C: BF800000
	s_nop 0                                                    // 00000014C9A0: BF800000
	s_nop 0                                                    // 00000014C9A4: BF800000
	s_nop 0                                                    // 00000014C9A8: BF800000
	s_nop 0                                                    // 00000014C9AC: BF800000
	s_nop 0                                                    // 00000014C9B0: BF800000
	s_nop 0                                                    // 00000014C9B4: BF800000
	s_nop 0                                                    // 00000014C9B8: BF800000
	s_nop 0                                                    // 00000014C9BC: BF800000
	v_lshrrev_b32_e32 v7, 6, v4                                // 00000014C9C0: 320E0886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C9C4: BF870121
	v_lshlrev_b32_e32 v5, 9, v7                                // 00000014C9C8: 300A0E89
	v_lshl_add_u32 v7, v7, 2, v1                               // 00000014C9CC: D6460007 04050507
	.long 0xd7006a05                                           // 00000014C9D4: D7006A05
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 00000014C9D8: 02020B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000014C9DC: BF8700D1
	v_add_co_ci_u32_e64 v6, null, 0, v3, vcc_lo                // 00000014C9E0: D5207C06 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 00000014C9E8: 7C9208FF 00001F7F
	global_load_b32 v5, v[5:6], off                            // 00000014C9F0: DC520000 057C0005
	v_add_nc_u32_e32 v6, 0x80, v4                              // 00000014C9F8: 4A0C08FF 00000080
	s_or_b32 s6, vcc_lo, s6                                    // 00000014CA00: 8C06066A
	v_mov_b32_e32 v4, v6                                       // 00000014CA04: 7E080306
	s_waitcnt vmcnt(0)                                         // 00000014CA08: BF8903F7
	ds_store_b32 v7, v5                                        // 00000014CA0C: D8340000 00000507
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000014CA14: 917E067E
	s_cbranch_execnz 65513                                     // 00000014CA18: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000014CA1C: 8C7E067E
	s_load_b32 s35, s[0:1], 0x58                               // 00000014CA20: F40008C0 F8000058
	v_or_b32_e32 v75, 0xffffff80, v0                           // 00000014CA28: 389600FF FFFFFF80
	v_lshrrev_b32_e32 v1, 6, v0                                // 00000014CA30: 32020086
	s_mov_b32 s6, 0                                            // 00000014CA34: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000014CA38: BF89FC07
	s_barrier                                                  // 00000014CA3C: BFBD0000
	buffer_gl0_inv                                             // 00000014CA40: E0AC0000 00000000
	s_cmp_gt_i32 s35, 0                                        // 00000014CA48: BF028023
	s_cbranch_scc1 9                                           // 00000014CA4C: BFA20009 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x174>
	v_lshrrev_b32_e32 v68, 6, v0                               // 00000014CA50: 32880086
	v_or_b32_e32 v2, 0xffffff80, v0                            // 00000014CA54: 380400FF FFFFFF80
	v_mov_b32_e32 v69, 0                                       // 00000014CA5C: 7E8A0280
	s_delay_alu instid0(VALU_DEP_3)                            // 00000014CA60: BF870003
	v_mov_b32_e32 v3, v68                                      // 00000014CA64: 7E060344
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 00000014CA68: 916A067E
	s_cbranch_vccz 1                                           // 00000014CA6C: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x174>
	s_branch 6255                                              // 00000014CA70: BFA0186F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6330>
	v_and_b32_e32 v4, 15, v0                                   // 00000014CA74: 3608008F
	s_clause 0x1                                               // 00000014CA78: BF850001
	s_load_b256 s[20:27], s[0:1], 0x8                          // 00000014CA7C: F40C0500 F8000008
	s_load_b64 s[30:31], s[0:1], 0x28                          // 00000014CA84: F4040780 F8000028
	s_movk_i32 s1, 0x210                                       // 00000014CA8C: B0010210
	v_lshrrev_b32_e32 v2, 5, v0                                // 00000014CA90: 32040085
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000014CA94: 30060082
	v_mad_u32_u24 v78, v4, s1, 0x3200                          // 00000014CA98: D60B004E 03FC0304 00003200
	s_mov_b32 s36, 0                                           // 00000014CAA4: BEA40080
	v_bfe_u32 v5, v0, 4, 1                                     // 00000014CAA8: D6100005 02050900
	v_mul_u32_u24_e32 v7, 0xa00, v2                            // 00000014CAB0: 160E04FF 00000A00
	v_or_b32_e32 v76, 0xb600, v3                               // 00000014CAB8: 389806FF 0000B600
	v_add_nc_u32_e32 v77, 0xb700, v3                           // 00000014CAC0: 4A9A06FF 0000B700
	s_mov_b32 s37, s36                                         // 00000014CAC8: BEA50024
	s_mov_b32 s38, s36                                         // 00000014CACC: BEA60024
	s_mov_b32 s39, s36                                         // 00000014CAD0: BEA70024
	s_mov_b32 s40, s36                                         // 00000014CAD4: BEA80024
	s_mov_b32 s41, s36                                         // 00000014CAD8: BEA90024
	s_mov_b32 s42, s36                                         // 00000014CADC: BEAA0024
	s_mov_b32 s43, s36                                         // 00000014CAE0: BEAB0024
	v_dual_mov_b32 v10, s36 :: v_dual_lshlrev_b32 v3, 4, v2    // 00000014CAE4: CA220024 0A020484
	v_mad_u32_u24 v2, 0x2100, v2, v78                          // 00000014CAEC: D60B0002 053A04FF 00002100
	s_add_i32 s0, s35, 63                                      // 00000014CAF8: 8100BF23
	s_movk_i32 s6, 0xa0                                        // 00000014CAFC: B00600A0
	s_add_i32 s44, s2, 0xbd0                                   // 00000014CB00: 812CFF02 00000BD0
	s_lshr_b32 s45, s0, 6                                      // 00000014CB08: 852D8600
	v_lshl_or_b32 v83, v5, 2, v2                               // 00000014CB0C: D6560053 04090505
	v_mov_b32_e32 v2, 0                                        // 00000014CB14: 7E040280
	v_or_b32_e32 v81, v3, v5                                   // 00000014CB18: 38A20B03
	v_mov_b32_e32 v12, s38                                     // 00000014CB1C: 7E180226
	v_mov_b32_e32 v14, s40                                     // 00000014CB20: 7E1C0228
	v_lshl_or_b32 v88, v74, 2, 0xb600                          // 00000014CB24: D6560058 03FD054A 0000B600
	v_mov_b32_e32 v69, v2                                      // 00000014CB30: 7E8A0302
	v_mad_u32_u24 v79, v4, s6, 0x2800                          // 00000014CB34: D60B004F 03FC0D04 00002800
	s_waitcnt lgkmcnt(0)                                       // 00000014CB40: BF89FC07
	s_add_u32 s6, s26, s28                                     // 00000014CB44: 80061C1A
	s_addc_u32 s7, s27, s29                                    // 00000014CB48: 82071D1B
	s_lshl_b32 s0, s2, 7                                       // 00000014CB4C: 84008702
	v_or_b32_e32 v80, v3, v4                                   // 00000014CB50: 38A00903
	s_ashr_i32 s1, s0, 31                                      // 00000014CB54: 86019F00
	v_lshlrev_b32_e32 v3, 2, v4                                // 00000014CB58: 30060882
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000014CB5C: 84808100
	v_mul_u32_u24_e32 v6, 0xa0, v4                             // 00000014CB60: 160C08FF 000000A0
	s_add_u32 s8, s18, s0                                      // 00000014CB68: 80080012
	s_addc_u32 s9, s19, s1                                     // 00000014CB6C: 82090113
	s_lshl_b64 s[0:1], s[4:5], 1                               // 00000014CB70: 84808104
	v_mad_u32_u24 v82, 0xa0, v4, v7                            // 00000014CB74: D60B0052 041E08FF 000000A0
	s_add_u32 s4, s8, s0                                       // 00000014CB80: 80040008
	.long 0xd7000054                                           // 00000014CB84: D7000054
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 00000014CB88: 02020606
	s_addc_u32 s5, s9, s1                                      // 00000014CB8C: 82050109
	v_add_co_ci_u32_e64 v85, null, s7, 0, s0                   // 00000014CB90: D5207C55 00010007
	s_lshl_b64 s[0:1], s[2:3], 9                               // 00000014CB98: 84808902
	v_lshlrev_b32_e32 v5, 1, v4                                // 00000014CB9C: 300A0881
	v_mad_u64_u32 v[3:4], null, 0x6000, v74, s[0:1]            // 00000014CBA0: D6FE7C03 000294FF 00006000
	v_lshl_add_u32 v86, v81, 1, v6                             // 00000014CBAC: D6460056 04190351
	v_mul_u32_u24_e32 v6, 0xa0, v1                             // 00000014CBB4: 160C02FF 000000A0
	v_lshl_or_b32 v87, v81, 2, 0xb700                          // 00000014CBBC: D6560057 03FD0551 0000B700
	.long 0xd7000046                                           // 00000014CBC8: D7000046
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 00000014CBCC: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000014CBD0: BF870251
	v_add_co_ci_u32_e64 v71, null, s5, 0, s0                   // 00000014CBD4: D5207C47 00010005
	v_lshl_or_b32 v3, v1, 2, v3                                // 00000014CBDC: D6560003 040D0501
	v_lshl_add_u32 v89, v74, 1, v6                             // 00000014CBE4: D6460059 0419034A
	v_dual_mov_b32 v68, v1 :: v_dual_mov_b32 v11, s37          // 00000014CBEC: CA100101 440A0025
	v_mov_b32_e32 v16, s42                                     // 00000014CBF4: 7E20022A
	.long 0xd7000048                                           // 00000014CBF8: D7000048
	v_cndmask_b32_e32 v1, s22, v3, vcc_lo                      // 00000014CBFC: 02020616
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014CC00: BF870001
	v_add_co_ci_u32_e64 v73, null, s23, v4, s0                 // 00000014CC04: D5207C49 00020817
	v_mov_b32_e32 v13, s39                                     // 00000014CC0C: 7E1A0227
	v_mov_b32_e32 v15, s41                                     // 00000014CC10: 7E1E0229
	v_mov_b32_e32 v17, s43                                     // 00000014CC14: 7E22022B
	s_mov_b32 s18, 0x41800000                                  // 00000014CC18: BE9200FF 41800000
	s_mov_b32 s19, s36                                         // 00000014CC20: BE930024
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000014CC24: 7C9800C0
	s_branch 13                                                // 00000014CC28: BFA0000D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x360>
	.long 0xd7000048                                           // 00000014CC2C: D7000048
	v_cndmask_b32_e32 v1, 0x180000, v72, vcc_lo                // 00000014CC30: 020290FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014CC38: BF870001
	v_add_co_ci_u32_e64 v73, null, 0, v73, s0                  // 00000014CC3C: D5207C49 00029280
	s_add_i32 s19, s19, 1                                      // 00000014CC44: 81138113
	s_waitcnt lgkmcnt(0)                                       // 00000014CC48: BF89FC07
	s_cmp_eq_u32 s19, s45                                      // 00000014CC4C: BF062D13
	s_barrier                                                  // 00000014CC50: BFBD0000
	buffer_gl0_inv                                             // 00000014CC54: E0AC0000 00000000
	s_cbranch_scc1 6130                                        // 00000014CC5C: BFA217F2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6328>
	s_mul_i32 s0, s19, 0xc00                                   // 00000014CC60: 9600FF13 00000C00
	s_lshl_b32 s22, s19, 6                                     // 00000014CC68: 84168613
	s_add_i32 s0, s44, s0                                      // 00000014CC6C: 8100002C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000014CC70: BF870499
	s_ashr_i32 s1, s0, 31                                      // 00000014CC74: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000014CC78: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014CC7C: BF870009
	s_add_u32 s0, s24, s0                                      // 00000014CC80: 80000018
	s_addc_u32 s1, s25, s1                                     // 00000014CC84: 82010119
	global_load_b32 v3, v2, s[0:1]                             // 00000014CC88: DC520000 03000002
	s_waitcnt vmcnt(0)                                         // 00000014CC90: BF8903F7
	v_readfirstlane_b32 s23, v3                                // 00000014CC94: 7E2E0503
	s_and_saveexec_b32 s1, vcc_lo                              // 00000014CC98: BE81206A
	s_cbranch_execz 77                                         // 00000014CC9C: BFA5004D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4d4>
	v_or_b32_e32 v3, s22, v0                                   // 00000014CCA0: 38060016
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014CCA4: BF870091
	v_mad_u64_u32 v[3:4], null, v3, 48, s[2:3]                 // 00000014CCA8: D6FE7C03 00096103
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000014CCB0: 3408069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014CCB4: BF870091
	.long 0xd73c0003                                           // 00000014CCB8: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000014CCBC: 02020682
	.long 0xd7000003                                           // 00000014CCC0: D7000003
	v_cndmask_b32_e32 v1, s24, v3, vcc_lo                      // 00000014CCC4: 02020618
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014CCC8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, s25, v4, s0                  // 00000014CCCC: D5207C04 00020819
	global_load_b32 v3, v[3:4], off                            // 00000014CCD4: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014CCDC: BF8903F7
	v_sub_f32_e32 v4, s23, v3                                  // 00000014CCE0: 08080617
	v_dual_mul_f32 v6, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, 0x3fb8aa3b, v4// 00000014CCE4: C8C606FF 060408FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000014CCF0: BF8701A1
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v6                          // 00000014CCF4: D6130009 841A06FF 3FB8AA3B
	v_rndne_f32_e32 v18, v6                                    // 00000014CD00: 7E244706
	v_fma_f32 v7, 0x3fb8aa3b, v4, -v5                          // 00000014CD04: D6130007 841608FF 3FB8AA3B
	v_rndne_f32_e32 v8, v5                                     // 00000014CD10: 7E104705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014CD14: BF870113
	v_dual_fmac_f32 v9, 0x32a5705f, v3 :: v_dual_sub_f32 v6, v6, v18// 00000014CD18: C80A06FF 09062506 32A5705F
	v_sub_f32_e32 v5, v5, v8                                   // 00000014CD24: 080A1105
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014CD28: BF870124
	v_fmac_f32_e32 v7, 0x32a5705f, v4                          // 00000014CD2C: 560E08FF 32A5705F
	.long 0xd41b0000                                           // 00000014CD34: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v4, vcc_lo               // 00000014CD38: 020208FF C2CE8ED0
	v_dual_add_f32 v6, v6, v9 :: v_dual_add_f32 v5, v5, v7     // 00000014CD40: C9081306 06040F05
	v_cvt_i32_f32_e32 v7, v8                                   // 00000014CD48: 7E0E1108
	v_cvt_i32_f32_e32 v8, v18                                  // 00000014CD4C: 7E101112
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000014CD50: BF870193
	v_exp_f32_e32 v6, v6                                       // 00000014CD54: 7E0C4B06
	v_exp_f32_e32 v5, v5                                       // 00000014CD58: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014CD5C: BF870296
	.long 0xd71c0006                                           // 00000014CD60: D71C0006
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 00000014CD64: 02021106
	.long 0xd71c0005                                           // 00000014CD68: D71C0005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000014CD6C: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000014CD70: BF8700A1
	v_cndmask_b32_e64 v5, 0, v5, s0                            // 00000014CD74: D5010005 00020A80
	.long 0xd41b0000                                           // 00000014CD7C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v3, vcc_lo               // 00000014CD80: 020206FF C2CE8ED0
	v_cndmask_b32_e64 v6, 0, v6, s0                            // 00000014CD88: D5010006 00020C80
	.long 0xd41e0000                                           // 00000014CD90: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v4, vcc_lo               // 00000014CD94: 020208FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000014CD9C: BF8700A1
	v_cndmask_b32_e64 v4, 0x7f800000, v5, s0                   // 00000014CDA0: D5010004 00020AFF 7F800000
	.long 0xd41e0000                                           // 00000014CDAC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v3, vcc_lo               // 00000014CDB0: 020206FF 42B17218
	v_cndmask_b32_e64 v3, 0x7f800000, v6, s0                   // 00000014CDB8: D5010003 00020CFF 7F800000
	ds_store_b32 v76, v4                                       // 00000014CDC4: D8340000 0000044C
	ds_store_b32 v77, v3                                       // 00000014CDCC: D8340000 0000034D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014CDD4: 8C7E017E
	v_add_nc_u32_e32 v7, s22, v80                              // 00000014CDD8: 4A0EA016
	.long 0x7f7a3880                                           // 00000014CDDC: 7F7A3880
	s_waitcnt lgkmcnt(0)                                       // 00000014CDE0: BF89FC07
	s_barrier                                                  // 00000014CDE4: BFBD0000
	buffer_gl0_inv                                             // 00000014CDE8: E0AC0000 00000000
	v_mad_u64_u32 v[3:4], null, v7, 48, s[2:3]                 // 00000014CDF0: D6FE7C03 00096107
	.long 0xd4440000                                           // 00000014CDF8: D4440000
	v_cndmask_b32_e32 v1, s35, v7, vcc_lo                      // 00000014CDFC: 02020E23
	.long 0x7f7639bd                                           // 00000014CE00: 7F7639BD
	.long 0x7e7639bd                                           // 00000014CE04: 7E7639BD
	.long 0x7f7439bd                                           // 00000014CE08: 7F7439BD
	.long 0x7e7439bd                                           // 00000014CE0C: 7E7439BD
	.long 0xd73c0005                                           // 00000014CE10: D73C0005
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014CE14: 02020689
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014CE18: BF870091
	.long 0xd7000103                                           // 00000014CE1C: D7000103
	v_cndmask_b32_e32 v1, s30, v5, vcc_lo                      // 00000014CE20: 02020A1E
	v_add_co_ci_u32_e64 v4, null, s31, v6, s1                  // 00000014CE24: D5207C04 00060C1F
	s_and_saveexec_b32 s1, s0                                  // 00000014CE2C: BE812000
	s_cbranch_execz 11                                         // 00000014CE30: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x560>
	global_load_b128 v[18:21], v[3:4], off                     // 00000014CE34: DC5E0000 127C0003
	s_waitcnt vmcnt(0)                                         // 00000014CE3C: BF8903F7
	v_fma_mixlo_f16 v58, v18, s18, 0                           // 00000014CE40: CC21003A 02002512
	v_fma_mixhi_f16 v58, v19, s18, 0                           // 00000014CE48: CC22003A 02002513
	v_fma_mixlo_f16 v59, v20, s18, 0                           // 00000014CE50: CC21003B 02002514
	v_fma_mixhi_f16 v59, v21, s18, 0                           // 00000014CE58: CC22003B 02002515
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014CE60: 8C7E017E
	.long 0x7e7a39bd                                           // 00000014CE64: 7E7A39BD
	.long 0x7f7839bd                                           // 00000014CE68: 7F7839BD
	.long 0x7e7839bd                                           // 00000014CE6C: 7E7839BD
	s_and_saveexec_b32 s1, s0                                  // 00000014CE70: BE812000
	s_cbranch_execz 11                                         // 00000014CE74: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a4>
	global_load_b128 v[18:21], v[3:4], off offset:16           // 00000014CE78: DC5E0010 127C0003
	s_waitcnt vmcnt(0)                                         // 00000014CE80: BF8903F7
	v_fma_mixlo_f16 v60, v18, s18, 0                           // 00000014CE84: CC21003C 02002512
	v_fma_mixhi_f16 v60, v19, s18, 0                           // 00000014CE8C: CC22003C 02002513
	v_fma_mixlo_f16 v61, v20, s18, 0                           // 00000014CE94: CC21003D 02002514
	v_fma_mixhi_f16 v61, v21, s18, 0                           // 00000014CE9C: CC22003D 02002515
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014CEA4: 8C7E017E
	.long 0x7f823880                                           // 00000014CEA8: 7F823880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014CEAC: BF870001
	.long 0x7f7e39c1                                           // 00000014CEB0: 7F7E39C1
	.long 0x7e7e39c1                                           // 00000014CEB4: 7E7E39C1
	.long 0x7f7c39c1                                           // 00000014CEB8: 7F7C39C1
	.long 0x7e7c39c1                                           // 00000014CEBC: 7E7C39C1
	s_and_saveexec_b32 s1, s0                                  // 00000014CEC0: BE812000
	s_cbranch_execz 11                                         // 00000014CEC4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f4>
	global_load_b128 v[18:21], v[3:4], off offset:32           // 00000014CEC8: DC5E0020 127C0003
	s_waitcnt vmcnt(0)                                         // 00000014CED0: BF8903F7
	v_fma_mixlo_f16 v62, v18, s18, 0                           // 00000014CED4: CC21003E 02002512
	v_fma_mixhi_f16 v62, v19, s18, 0                           // 00000014CEDC: CC22003E 02002513
	v_fma_mixlo_f16 v63, v20, s18, 0                           // 00000014CEE4: CC21003F 02002514
	v_fma_mixhi_f16 v63, v21, s18, 0                           // 00000014CEEC: CC22003F 02002515
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014CEF4: 8C7E017E
	.long 0x7e8239c1                                           // 00000014CEF8: 7E8239C1
	.long 0x7f8039c1                                           // 00000014CEFC: 7F8039C1
	.long 0x7e8039c1                                           // 00000014CF00: 7E8039C1
	s_and_saveexec_b32 s1, s0                                  // 00000014CF04: BE812000
	s_cbranch_execz 11                                         // 00000014CF08: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x638>
	global_load_b128 v[18:21], v[3:4], off offset:48           // 00000014CF0C: DC5E0030 127C0003
	s_waitcnt vmcnt(0)                                         // 00000014CF14: BF8903F7
	v_fma_mixlo_f16 v64, v18, s18, 0                           // 00000014CF18: CC210040 02002512
	v_fma_mixhi_f16 v64, v19, s18, 0                           // 00000014CF20: CC220040 02002513
	v_fma_mixlo_f16 v65, v20, s18, 0                           // 00000014CF28: CC210041 02002514
	v_fma_mixhi_f16 v65, v21, s18, 0                           // 00000014CF30: CC220041 02002515
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014CF38: 8C7E017E
	ds_load_b128 v[18:21], v78                                 // 00000014CF3C: DBFC0000 1200004E
	ds_load_b128 v[22:25], v78 offset:16                       // 00000014CF44: DBFC0010 1600004E
	ds_load_b128 v[26:29], v78 offset:32                       // 00000014CF4C: DBFC0020 1A00004E
	ds_load_b128 v[30:33], v78 offset:48                       // 00000014CF54: DBFC0030 1E00004E
	ds_load_b128 v[34:37], v78 offset:8448                     // 00000014CF5C: DBFC2100 2200004E
	ds_load_b128 v[38:41], v78 offset:8464                     // 00000014CF64: DBFC2110 2600004E
	ds_load_b128 v[42:45], v78 offset:8480                     // 00000014CF6C: DBFC2120 2A00004E
	ds_load_b128 v[46:49], v78 offset:8496                     // 00000014CF74: DBFC2130 2E00004E
	ds_load_b128 v[50:53], v78 offset:16896                    // 00000014CF7C: DBFC4200 3200004E
	ds_load_b128 v[54:57], v78 offset:16912                    // 00000014CF84: DBFC4210 3600004E
	ds_load_b128 v[90:93], v78 offset:16928                    // 00000014CF8C: DBFC4220 5A00004E
	ds_load_b128 v[94:97], v78 offset:16944                    // 00000014CF94: DBFC4230 5E00004E
	s_waitcnt lgkmcnt(11)                                      // 00000014CF9C: BF89FCB7
	v_fma_mixlo_f16 v18, v18, s18, 0                           // 00000014CFA0: CC210012 02002512
	v_fma_mixhi_f16 v18, v19, s18, 0                           // 00000014CFA8: CC220012 02002513
	v_fma_mixlo_f16 v19, v20, s18, 0                           // 00000014CFB0: CC210013 02002514
	v_fma_mixhi_f16 v19, v21, s18, 0                           // 00000014CFB8: CC220013 02002515
	s_waitcnt lgkmcnt(10)                                      // 00000014CFC0: BF89FCA7
	v_fma_mixlo_f16 v20, v22, s18, 0                           // 00000014CFC4: CC210014 02002516
	v_fma_mixhi_f16 v20, v23, s18, 0                           // 00000014CFCC: CC220014 02002517
	v_fma_mixlo_f16 v21, v24, s18, 0                           // 00000014CFD4: CC210015 02002518
	v_fma_mixhi_f16 v21, v25, s18, 0                           // 00000014CFDC: CC220015 02002519
	s_waitcnt lgkmcnt(9)                                       // 00000014CFE4: BF89FC97
	v_fma_mixlo_f16 v22, v26, s18, 0                           // 00000014CFE8: CC210016 0200251A
	v_fma_mixhi_f16 v22, v27, s18, 0                           // 00000014CFF0: CC220016 0200251B
	v_fma_mixlo_f16 v23, v28, s18, 0                           // 00000014CFF8: CC210017 0200251C
	v_fma_mixhi_f16 v23, v29, s18, 0                           // 00000014D000: CC220017 0200251D
	s_waitcnt lgkmcnt(8)                                       // 00000014D008: BF89FC87
	v_fma_mixlo_f16 v24, v30, s18, 0                           // 00000014D00C: CC210018 0200251E
	v_fma_mixhi_f16 v24, v31, s18, 0                           // 00000014D014: CC220018 0200251F
	v_fma_mixlo_f16 v25, v32, s18, 0                           // 00000014D01C: CC210019 02002520
	v_fma_mixhi_f16 v25, v33, s18, 0                           // 00000014D024: CC220019 02002521
	s_waitcnt lgkmcnt(7)                                       // 00000014D02C: BF89FC77
	v_fma_mixlo_f16 v26, v34, s18, 0                           // 00000014D030: CC21001A 02002522
	v_fma_mixhi_f16 v26, v35, s18, 0                           // 00000014D038: CC22001A 02002523
	v_fma_mixlo_f16 v27, v36, s18, 0                           // 00000014D040: CC21001B 02002524
	v_fma_mixhi_f16 v27, v37, s18, 0                           // 00000014D048: CC22001B 02002525
	s_waitcnt lgkmcnt(6)                                       // 00000014D050: BF89FC67
	v_fma_mixlo_f16 v28, v38, s18, 0                           // 00000014D054: CC21001C 02002526
	v_fma_mixhi_f16 v28, v39, s18, 0                           // 00000014D05C: CC22001C 02002527
	v_fma_mixlo_f16 v29, v40, s18, 0                           // 00000014D064: CC21001D 02002528
	v_fma_mixhi_f16 v29, v41, s18, 0                           // 00000014D06C: CC22001D 02002529
	s_waitcnt lgkmcnt(5)                                       // 00000014D074: BF89FC57
	v_fma_mixlo_f16 v30, v42, s18, 0                           // 00000014D078: CC21001E 0200252A
	v_fma_mixhi_f16 v30, v43, s18, 0                           // 00000014D080: CC22001E 0200252B
	v_fma_mixlo_f16 v31, v44, s18, 0                           // 00000014D088: CC21001F 0200252C
	v_fma_mixhi_f16 v31, v45, s18, 0                           // 00000014D090: CC22001F 0200252D
	s_waitcnt lgkmcnt(4)                                       // 00000014D098: BF89FC47
	v_fma_mixlo_f16 v32, v46, s18, 0                           // 00000014D09C: CC210020 0200252E
	v_fma_mixhi_f16 v32, v47, s18, 0                           // 00000014D0A4: CC220020 0200252F
	v_fma_mixlo_f16 v33, v48, s18, 0                           // 00000014D0AC: CC210021 02002530
	v_fma_mixhi_f16 v33, v49, s18, 0                           // 00000014D0B4: CC220021 02002531
	v_wmma_f32_16x16x16_f16 v[42:49], v[58:65], v[18:25], v[10:17]// 00000014D0BC: CC40402A 1C2A253A
	s_waitcnt lgkmcnt(3)                                       // 00000014D0C4: BF89FC37
	v_fma_mixlo_f16 v18, v50, s18, 0                           // 00000014D0C8: CC210012 02002532
	v_fma_mixhi_f16 v18, v51, s18, 0                           // 00000014D0D0: CC220012 02002533
	v_wmma_f32_16x16x16_f16 v[34:41], v[58:65], v[26:33], v[10:17]// 00000014D0D8: CC404022 1C2A353A
	ds_load_b128 v[26:29], v78 offset:25344                    // 00000014D0E0: DBFC6300 1A00004E
	ds_load_b128 v[30:33], v78 offset:25360                    // 00000014D0E8: DBFC6310 1E00004E
	v_fma_mixlo_f16 v19, v52, s18, 0                           // 00000014D0F0: CC210013 02002534
	v_fma_mixhi_f16 v19, v53, s18, 0                           // 00000014D0F8: CC220013 02002535
	s_waitcnt lgkmcnt(4)                                       // 00000014D100: BF89FC47
	v_fma_mixlo_f16 v20, v54, s18, 0                           // 00000014D104: CC210014 02002536
	v_fma_mixhi_f16 v20, v55, s18, 0                           // 00000014D10C: CC220014 02002537
	ds_load_b128 v[50:53], v78 offset:25376                    // 00000014D114: DBFC6320 3200004E
	v_fma_mixlo_f16 v21, v56, s18, 0                           // 00000014D11C: CC210015 02002538
	v_fma_mixhi_f16 v21, v57, s18, 0                           // 00000014D124: CC220015 02002539
	ds_load_b128 v[54:57], v78 offset:25392                    // 00000014D12C: DBFC6330 3600004E
	s_waitcnt lgkmcnt(5)                                       // 00000014D134: BF89FC57
	v_fma_mixlo_f16 v22, v90, s18, 0                           // 00000014D138: CC210016 0200255A
	v_fma_mixhi_f16 v22, v91, s18, 0                           // 00000014D140: CC220016 0200255B
	v_fma_mixlo_f16 v23, v92, s18, 0                           // 00000014D148: CC210017 0200255C
	v_fma_mixhi_f16 v23, v93, s18, 0                           // 00000014D150: CC220017 0200255D
	s_waitcnt lgkmcnt(4)                                       // 00000014D158: BF89FC47
	v_fma_mixlo_f16 v24, v94, s18, 0                           // 00000014D15C: CC210018 0200255E
	v_fma_mixhi_f16 v24, v95, s18, 0                           // 00000014D164: CC220018 0200255F
	v_fma_mixlo_f16 v25, v96, s18, 0                           // 00000014D16C: CC210019 02002560
	v_fma_mixhi_f16 v25, v97, s18, 0                           // 00000014D174: CC220019 02002561
	s_waitcnt lgkmcnt(3)                                       // 00000014D17C: BF89FC37
	v_fma_mixlo_f16 v90, v26, s18, 0                           // 00000014D180: CC21005A 0200251A
	v_fma_mixhi_f16 v90, v27, s18, 0                           // 00000014D188: CC22005A 0200251B
	v_fma_mixlo_f16 v91, v28, s18, 0                           // 00000014D190: CC21005B 0200251C
	v_fma_mixhi_f16 v91, v29, s18, 0                           // 00000014D198: CC22005B 0200251D
	s_waitcnt lgkmcnt(2)                                       // 00000014D1A0: BF89FC27
	v_fma_mixlo_f16 v92, v30, s18, 0                           // 00000014D1A4: CC21005C 0200251E
	v_fma_mixhi_f16 v92, v31, s18, 0                           // 00000014D1AC: CC22005C 0200251F
	v_fma_mixlo_f16 v93, v32, s18, 0                           // 00000014D1B4: CC21005D 02002520
	v_fma_mixhi_f16 v93, v33, s18, 0                           // 00000014D1BC: CC22005D 02002521
	s_waitcnt lgkmcnt(1)                                       // 00000014D1C4: BF89FC17
	v_fma_mixlo_f16 v94, v50, s18, 0                           // 00000014D1C8: CC21005E 02002532
	v_fma_mixhi_f16 v94, v51, s18, 0                           // 00000014D1D0: CC22005E 02002533
	v_fma_mixlo_f16 v95, v52, s18, 0                           // 00000014D1D8: CC21005F 02002534
	v_fma_mixhi_f16 v95, v53, s18, 0                           // 00000014D1E0: CC22005F 02002535
	s_waitcnt lgkmcnt(0)                                       // 00000014D1E8: BF89FC07
	v_fma_mixlo_f16 v96, v54, s18, 0                           // 00000014D1EC: CC210060 02002536
	v_fma_mixhi_f16 v96, v55, s18, 0                           // 00000014D1F4: CC220060 02002537
	v_fma_mixlo_f16 v97, v56, s18, 0                           // 00000014D1FC: CC210061 02002538
	v_fma_mixhi_f16 v97, v57, s18, 0                           // 00000014D204: CC220061 02002539
	.long 0x7f723880                                           // 00000014D20C: 7F723880
	v_wmma_f32_16x16x16_f16 v[26:33], v[58:65], v[18:25], v[10:17]// 00000014D210: CC40401A 1C2A253A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000014D218: BF870193
	v_wmma_f32_16x16x16_f16 v[18:25], v[58:65], v[90:97], v[10:17]// 00000014D21C: CC404012 1C2AB53A
	.long 0x7f6e39b9                                           // 00000014D224: 7F6E39B9
	.long 0x7e6e39b9                                           // 00000014D228: 7E6E39B9
	.long 0x7f6c39b9                                           // 00000014D22C: 7F6C39B9
	.long 0x7e6c39b9                                           // 00000014D230: 7E6C39B9
	s_and_saveexec_b32 s1, s0                                  // 00000014D234: BE812000
	s_cbranch_execz 11                                         // 00000014D238: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x968>
	global_load_b128 v[50:53], v[3:4], off offset:64           // 00000014D23C: DC5E0040 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014D244: BF8903F7
	v_fma_mixlo_f16 v54, v50, s18, 0                           // 00000014D248: CC210036 02002532
	v_fma_mixhi_f16 v54, v51, s18, 0                           // 00000014D250: CC220036 02002533
	v_fma_mixlo_f16 v55, v52, s18, 0                           // 00000014D258: CC210037 02002534
	v_fma_mixhi_f16 v55, v53, s18, 0                           // 00000014D260: CC220037 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014D268: 8C7E017E
	.long 0x7e7239b9                                           // 00000014D26C: 7E7239B9
	.long 0x7f7039b9                                           // 00000014D270: 7F7039B9
	.long 0x7e7039b9                                           // 00000014D274: 7E7039B9
	s_and_saveexec_b32 s1, s0                                  // 00000014D278: BE812000
	s_cbranch_execz 11                                         // 00000014D27C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x9ac>
	global_load_b128 v[50:53], v[3:4], off offset:80           // 00000014D280: DC5E0050 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014D288: BF8903F7
	v_fma_mixlo_f16 v56, v50, s18, 0                           // 00000014D28C: CC210038 02002532
	v_fma_mixhi_f16 v56, v51, s18, 0                           // 00000014D294: CC220038 02002533
	v_fma_mixlo_f16 v57, v52, s18, 0                           // 00000014D29C: CC210039 02002534
	v_fma_mixhi_f16 v57, v53, s18, 0                           // 00000014D2A4: CC220039 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014D2AC: 8C7E017E
	.long 0x7f7a3880                                           // 00000014D2B0: 7F7A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014D2B4: BF870001
	.long 0x7f7639bd                                           // 00000014D2B8: 7F7639BD
	.long 0x7e7639bd                                           // 00000014D2BC: 7E7639BD
	.long 0x7f7439bd                                           // 00000014D2C0: 7F7439BD
	.long 0x7e7439bd                                           // 00000014D2C4: 7E7439BD
	s_and_saveexec_b32 s1, s0                                  // 00000014D2C8: BE812000
	s_cbranch_execz 11                                         // 00000014D2CC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x9fc>
	global_load_b128 v[50:53], v[3:4], off offset:96           // 00000014D2D0: DC5E0060 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014D2D8: BF8903F7
	v_fma_mixlo_f16 v58, v50, s18, 0                           // 00000014D2DC: CC21003A 02002532
	v_fma_mixhi_f16 v58, v51, s18, 0                           // 00000014D2E4: CC22003A 02002533
	v_fma_mixlo_f16 v59, v52, s18, 0                           // 00000014D2EC: CC21003B 02002534
	v_fma_mixhi_f16 v59, v53, s18, 0                           // 00000014D2F4: CC22003B 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014D2FC: 8C7E017E
	.long 0x7e7a39bd                                           // 00000014D300: 7E7A39BD
	.long 0x7f7839bd                                           // 00000014D304: 7F7839BD
	.long 0x7e7839bd                                           // 00000014D308: 7E7839BD
	s_and_saveexec_b32 s1, s0                                  // 00000014D30C: BE812000
	s_cbranch_execz 11                                         // 00000014D310: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa40>
	global_load_b128 v[50:53], v[3:4], off offset:112          // 00000014D314: DC5E0070 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014D31C: BF8903F7
	v_fma_mixlo_f16 v60, v50, s18, 0                           // 00000014D320: CC21003C 02002532
	v_fma_mixhi_f16 v60, v51, s18, 0                           // 00000014D328: CC22003C 02002533
	v_fma_mixlo_f16 v61, v52, s18, 0                           // 00000014D330: CC21003D 02002534
	v_fma_mixhi_f16 v61, v53, s18, 0                           // 00000014D338: CC22003D 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014D340: 8C7E017E
	ds_load_b128 v[50:53], v78 offset:64                       // 00000014D344: DBFC0040 3200004E
	ds_load_b128 v[62:65], v78 offset:80                       // 00000014D34C: DBFC0050 3E00004E
	ds_load_b128 v[94:97], v78 offset:96                       // 00000014D354: DBFC0060 5E00004E
	ds_load_b128 v[98:101], v78 offset:112                     // 00000014D35C: DBFC0070 6200004E
	ds_load_b128 v[102:105], v78 offset:8512                   // 00000014D364: DBFC2140 6600004E
	ds_load_b128 v[106:109], v78 offset:8528                   // 00000014D36C: DBFC2150 6A00004E
	ds_load_b128 v[110:113], v78 offset:8544                   // 00000014D374: DBFC2160 6E00004E
	ds_load_b128 v[114:117], v78 offset:8560                   // 00000014D37C: DBFC2170 7200004E
	ds_load_b128 v[118:121], v78 offset:16992                  // 00000014D384: DBFC4260 7600004E
	ds_load_b128 v[122:125], v78 offset:17008                  // 00000014D38C: DBFC4270 7A00004E
	ds_load_b128 v[126:129], v78 offset:25424                  // 00000014D394: DBFC6350 7E00004E
	s_waitcnt lgkmcnt(10)                                      // 00000014D39C: BF89FCA7
	v_fma_mixlo_f16 v90, v50, s18, 0                           // 00000014D3A0: CC21005A 02002532
	v_fma_mixhi_f16 v90, v51, s18, 0                           // 00000014D3A8: CC22005A 02002533
	v_fma_mixlo_f16 v91, v52, s18, 0                           // 00000014D3B0: CC21005B 02002534
	v_fma_mixhi_f16 v91, v53, s18, 0                           // 00000014D3B8: CC22005B 02002535
	s_waitcnt lgkmcnt(9)                                       // 00000014D3C0: BF89FC97
	v_fma_mixlo_f16 v92, v62, s18, 0                           // 00000014D3C4: CC21005C 0200253E
	v_fma_mixhi_f16 v92, v63, s18, 0                           // 00000014D3CC: CC22005C 0200253F
	v_fma_mixlo_f16 v93, v64, s18, 0                           // 00000014D3D4: CC21005D 02002540
	v_fma_mixhi_f16 v93, v65, s18, 0                           // 00000014D3DC: CC22005D 02002541
	ds_load_b128 v[50:53], v78 offset:16960                    // 00000014D3E4: DBFC4240 3200004E
	ds_load_b128 v[62:65], v78 offset:16976                    // 00000014D3EC: DBFC4250 3E00004E
	s_waitcnt lgkmcnt(10)                                      // 00000014D3F4: BF89FCA7
	v_fma_mixlo_f16 v94, v94, s18, 0                           // 00000014D3F8: CC21005E 0200255E
	v_fma_mixhi_f16 v94, v95, s18, 0                           // 00000014D400: CC22005E 0200255F
	v_fma_mixlo_f16 v95, v96, s18, 0                           // 00000014D408: CC21005F 02002560
	v_fma_mixhi_f16 v95, v97, s18, 0                           // 00000014D410: CC22005F 02002561
	s_waitcnt lgkmcnt(9)                                       // 00000014D418: BF89FC97
	v_fma_mixhi_f16 v96, v99, s18, 0                           // 00000014D41C: CC220060 02002563
	v_fma_mixlo_f16 v97, v100, s18, 0                          // 00000014D424: CC210061 02002564
	v_fma_mixhi_f16 v97, v101, s18, 0                          // 00000014D42C: CC220061 02002565
	s_waitcnt lgkmcnt(8)                                       // 00000014D434: BF89FC87
	v_fma_mixlo_f16 v99, v104, s18, 0                          // 00000014D438: CC210063 02002568
	v_fma_mixhi_f16 v99, v105, s18, 0                          // 00000014D440: CC220063 02002569
	s_waitcnt lgkmcnt(7)                                       // 00000014D448: BF89FC77
	v_fma_mixlo_f16 v100, v106, s18, 0                         // 00000014D44C: CC210064 0200256A
	v_fma_mixhi_f16 v100, v107, s18, 0                         // 00000014D454: CC220064 0200256B
	v_fma_mixlo_f16 v101, v108, s18, 0                         // 00000014D45C: CC210065 0200256C
	v_fma_mixhi_f16 v101, v109, s18, 0                         // 00000014D464: CC220065 0200256D
	s_waitcnt lgkmcnt(5)                                       // 00000014D46C: BF89FC57
	v_fma_mixlo_f16 v104, v114, s18, 0                         // 00000014D470: CC210068 02002572
	v_fma_mixhi_f16 v104, v115, s18, 0                         // 00000014D478: CC220068 02002573
	v_fma_mixlo_f16 v105, v116, s18, 0                         // 00000014D480: CC210069 02002574
	v_fma_mixhi_f16 v105, v117, s18, 0                         // 00000014D488: CC220069 02002575
	ds_load_b128 v[114:117], v78 offset:25408                  // 00000014D490: DBFC6340 7200004E
	s_waitcnt lgkmcnt(2)                                       // 00000014D498: BF89FC27
	v_fma_mixlo_f16 v106, v50, s18, 0                          // 00000014D49C: CC21006A 02002532
	v_fma_mixhi_f16 v106, v51, s18, 0                          // 00000014D4A4: CC22006A 02002533
	v_fma_mixlo_f16 v107, v52, s18, 0                          // 00000014D4AC: CC21006B 02002534
	v_fma_mixhi_f16 v107, v53, s18, 0                          // 00000014D4B4: CC22006B 02002535
	s_waitcnt lgkmcnt(1)                                       // 00000014D4BC: BF89FC17
	v_fma_mixlo_f16 v108, v62, s18, 0                          // 00000014D4C0: CC21006C 0200253E
	v_fma_mixhi_f16 v108, v63, s18, 0                          // 00000014D4C8: CC22006C 0200253F
	ds_load_b128 v[50:53], v78 offset:25440                    // 00000014D4D0: DBFC6360 3200004E
	v_fma_mixlo_f16 v109, v64, s18, 0                          // 00000014D4D8: CC21006D 02002540
	v_fma_mixhi_f16 v109, v65, s18, 0                          // 00000014D4E0: CC22006D 02002541
	ds_load_b128 v[62:65], v78 offset:25456                    // 00000014D4E8: DBFC6370 3E00004E
	v_fma_mixlo_f16 v96, v98, s18, 0                           // 00000014D4F0: CC210060 02002562
	v_fma_mixlo_f16 v98, v102, s18, 0                          // 00000014D4F8: CC210062 02002566
	v_fma_mixhi_f16 v98, v103, s18, 0                          // 00000014D500: CC220062 02002567
	v_fma_mixlo_f16 v102, v110, s18, 0                         // 00000014D508: CC210066 0200256E
	v_fma_mixhi_f16 v102, v111, s18, 0                         // 00000014D510: CC220066 0200256F
	v_fma_mixlo_f16 v103, v112, s18, 0                         // 00000014D518: CC210067 02002570
	v_fma_mixhi_f16 v103, v113, s18, 0                         // 00000014D520: CC220067 02002571
	v_fma_mixlo_f16 v110, v118, s18, 0                         // 00000014D528: CC21006E 02002576
	v_fma_mixhi_f16 v110, v119, s18, 0                         // 00000014D530: CC22006E 02002577
	v_fma_mixlo_f16 v111, v120, s18, 0                         // 00000014D538: CC21006F 02002578
	v_fma_mixhi_f16 v111, v121, s18, 0                         // 00000014D540: CC22006F 02002579
	v_fma_mixlo_f16 v112, v122, s18, 0                         // 00000014D548: CC210070 0200257A
	v_fma_mixhi_f16 v112, v123, s18, 0                         // 00000014D550: CC220070 0200257B
	v_fma_mixlo_f16 v113, v124, s18, 0                         // 00000014D558: CC210071 0200257C
	v_fma_mixhi_f16 v113, v125, s18, 0                         // 00000014D560: CC220071 0200257D
	s_waitcnt lgkmcnt(2)                                       // 00000014D568: BF89FC27
	v_fma_mixlo_f16 v114, v114, s18, 0                         // 00000014D56C: CC210072 02002572
	v_fma_mixhi_f16 v114, v115, s18, 0                         // 00000014D574: CC220072 02002573
	v_fma_mixlo_f16 v115, v116, s18, 0                         // 00000014D57C: CC210073 02002574
	v_fma_mixhi_f16 v115, v117, s18, 0                         // 00000014D584: CC220073 02002575
	v_fma_mixlo_f16 v116, v126, s18, 0                         // 00000014D58C: CC210074 0200257E
	v_fma_mixhi_f16 v116, v127, s18, 0                         // 00000014D594: CC220074 0200257F
	v_fma_mixlo_f16 v117, v128, s18, 0                         // 00000014D59C: CC210075 02002580
	v_fma_mixhi_f16 v117, v129, s18, 0                         // 00000014D5A4: CC220075 02002581
	s_waitcnt lgkmcnt(1)                                       // 00000014D5AC: BF89FC17
	v_fma_mixlo_f16 v118, v50, s18, 0                          // 00000014D5B0: CC210076 02002532
	v_fma_mixhi_f16 v118, v51, s18, 0                          // 00000014D5B8: CC220076 02002533
	v_fma_mixlo_f16 v119, v52, s18, 0                          // 00000014D5C0: CC210077 02002534
	v_fma_mixhi_f16 v119, v53, s18, 0                          // 00000014D5C8: CC220077 02002535
	s_waitcnt lgkmcnt(0)                                       // 00000014D5D0: BF89FC07
	v_fma_mixlo_f16 v120, v62, s18, 0                          // 00000014D5D4: CC210078 0200253E
	v_fma_mixhi_f16 v120, v63, s18, 0                          // 00000014D5DC: CC220078 0200253F
	v_fma_mixlo_f16 v121, v64, s18, 0                          // 00000014D5E4: CC210079 02002540
	v_fma_mixhi_f16 v121, v65, s18, 0                          // 00000014D5EC: CC220079 02002541
	.long 0x7f6a3880                                           // 00000014D5F4: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[54:61], v[90:97], v[42:49]// 00000014D5F8: CC40402A 1CAAB536
	v_wmma_f32_16x16x16_f16 v[34:41], v[54:61], v[98:105], v[34:41]// 00000014D600: CC404022 1C8AC536
	v_wmma_f32_16x16x16_f16 v[26:33], v[54:61], v[106:113], v[26:33]// 00000014D608: CC40401A 1C6AD536
	v_wmma_f32_16x16x16_f16 v[18:25], v[54:61], v[114:121], v[18:25]// 00000014D610: CC404012 1C4AE536
	.long 0x7f6639b5                                           // 00000014D618: 7F6639B5
	.long 0x7e6639b5                                           // 00000014D61C: 7E6639B5
	.long 0x7f6439b5                                           // 00000014D620: 7F6439B5
	.long 0x7e6439b5                                           // 00000014D624: 7E6439B5
	s_and_saveexec_b32 s1, s0                                  // 00000014D628: BE812000
	s_cbranch_execz 11                                         // 00000014D62C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd5c>
	global_load_b128 v[54:57], v[3:4], off offset:128          // 00000014D630: DC5E0080 367C0003
	s_waitcnt vmcnt(0)                                         // 00000014D638: BF8903F7
	v_fma_mixlo_f16 v50, v54, s18, 0                           // 00000014D63C: CC210032 02002536
	v_fma_mixhi_f16 v50, v55, s18, 0                           // 00000014D644: CC220032 02002537
	v_fma_mixlo_f16 v51, v56, s18, 0                           // 00000014D64C: CC210033 02002538
	v_fma_mixhi_f16 v51, v57, s18, 0                           // 00000014D654: CC220033 02002539
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014D65C: 8C7E017E
	.long 0x7e6a39b5                                           // 00000014D660: 7E6A39B5
	.long 0x7f6839b5                                           // 00000014D664: 7F6839B5
	.long 0x7e6839b5                                           // 00000014D668: 7E6839B5
	s_and_saveexec_b32 s1, s0                                  // 00000014D66C: BE812000
	s_cbranch_execz 11                                         // 00000014D670: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xda0>
	global_load_b128 v[52:55], v[3:4], off offset:144          // 00000014D674: DC5E0090 347C0003
	s_waitcnt vmcnt(0)                                         // 00000014D67C: BF8903F7
	v_fma_mixlo_f16 v52, v52, s18, 0                           // 00000014D680: CC210034 02002534
	v_fma_mixhi_f16 v52, v53, s18, 0                           // 00000014D688: CC220034 02002535
	v_fma_mixlo_f16 v53, v54, s18, 0                           // 00000014D690: CC210035 02002536
	v_fma_mixhi_f16 v53, v55, s18, 0                           // 00000014D698: CC220035 02002537
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014D6A0: 8C7E017E
	.long 0x7f723880                                           // 00000014D6A4: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014D6A8: BF870001
	.long 0x7f6e39b9                                           // 00000014D6AC: 7F6E39B9
	.long 0x7e6e39b9                                           // 00000014D6B0: 7E6E39B9
	.long 0x7f6c39b9                                           // 00000014D6B4: 7F6C39B9
	.long 0x7e6c39b9                                           // 00000014D6B8: 7E6C39B9
	s_and_saveexec_b32 s1, s0                                  // 00000014D6BC: BE812000
	s_cbranch_execz 11                                         // 00000014D6C0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xdf0>
	global_load_b128 v[58:61], v[3:4], off offset:160          // 00000014D6C4: DC5E00A0 3A7C0003
	s_waitcnt vmcnt(0)                                         // 00000014D6CC: BF8903F7
	v_fma_mixlo_f16 v54, v58, s18, 0                           // 00000014D6D0: CC210036 0200253A
	v_fma_mixhi_f16 v54, v59, s18, 0                           // 00000014D6D8: CC220036 0200253B
	v_fma_mixlo_f16 v55, v60, s18, 0                           // 00000014D6E0: CC210037 0200253C
	v_fma_mixhi_f16 v55, v61, s18, 0                           // 00000014D6E8: CC220037 0200253D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014D6F0: 8C7E017E
	.long 0x7e7239b9                                           // 00000014D6F4: 7E7239B9
	.long 0x7f7039b9                                           // 00000014D6F8: 7F7039B9
	.long 0x7e7039b9                                           // 00000014D6FC: 7E7039B9
	s_and_saveexec_b32 s1, s0                                  // 00000014D700: BE812000
	s_cbranch_execz 11                                         // 00000014D704: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe34>
	global_load_b128 v[56:59], v[3:4], off offset:176          // 00000014D708: DC5E00B0 387C0003
	s_waitcnt vmcnt(0)                                         // 00000014D710: BF8903F7
	v_fma_mixlo_f16 v56, v56, s18, 0                           // 00000014D714: CC210038 02002538
	v_fma_mixhi_f16 v56, v57, s18, 0                           // 00000014D71C: CC220038 02002539
	v_fma_mixlo_f16 v57, v58, s18, 0                           // 00000014D724: CC210039 0200253A
	v_fma_mixhi_f16 v57, v59, s18, 0                           // 00000014D72C: CC220039 0200253B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014D734: 8C7E017E
	ds_load_b128 v[59:62], v78 offset:128                      // 00000014D738: DBFC0080 3B00004E
	ds_load_b128 v[63:66], v78 offset:144                      // 00000014D740: DBFC0090 3F00004E
	ds_load_b128 v[90:93], v78 offset:160                      // 00000014D748: DBFC00A0 5A00004E
	ds_load_b128 v[94:97], v78 offset:176                      // 00000014D750: DBFC00B0 5E00004E
	ds_load_b128 v[98:101], v78 offset:8576                    // 00000014D758: DBFC2180 6200004E
	ds_load_b128 v[102:105], v78 offset:8592                   // 00000014D760: DBFC2190 6600004E
	ds_load_b128 v[106:109], v78 offset:8608                   // 00000014D768: DBFC21A0 6A00004E
	ds_load_b128 v[110:113], v78 offset:8624                   // 00000014D770: DBFC21B0 6E00004E
	ds_load_b128 v[114:117], v78 offset:17024                  // 00000014D778: DBFC4280 7200004E
	ds_load_b128 v[118:121], v78 offset:17040                  // 00000014D780: DBFC4290 7600004E
	.long 0x7f743880                                           // 00000014D788: 7F743880
	ds_load_b128 v[122:125], v78 offset:25488                  // 00000014D78C: DBFC6390 7A00004E
	s_waitcnt lgkmcnt(10)                                      // 00000014D794: BF89FCA7
	v_fma_mixlo_f16 v59, v59, s18, 0                           // 00000014D798: CC21003B 0200253B
	v_fma_mixhi_f16 v59, v60, s18, 0                           // 00000014D7A0: CC22003B 0200253C
	v_fma_mixlo_f16 v60, v61, s18, 0                           // 00000014D7A8: CC21003C 0200253D
	v_fma_mixhi_f16 v60, v62, s18, 0                           // 00000014D7B0: CC22003C 0200253E
	s_waitcnt lgkmcnt(9)                                       // 00000014D7B8: BF89FC97
	v_fma_mixlo_f16 v61, v63, s18, 0                           // 00000014D7BC: CC21003D 0200253F
	v_fma_mixhi_f16 v61, v64, s18, 0                           // 00000014D7C4: CC22003D 02002540
	v_fma_mixlo_f16 v62, v65, s18, 0                           // 00000014D7CC: CC21003E 02002541
	v_fma_mixhi_f16 v62, v66, s18, 0                           // 00000014D7D4: CC22003E 02002542
	s_waitcnt lgkmcnt(8)                                       // 00000014D7DC: BF89FC87
	v_fma_mixlo_f16 v63, v90, s18, 0                           // 00000014D7E0: CC21003F 0200255A
	v_fma_mixhi_f16 v63, v91, s18, 0                           // 00000014D7E8: CC22003F 0200255B
	v_fma_mixlo_f16 v64, v92, s18, 0                           // 00000014D7F0: CC210040 0200255C
	v_fma_mixhi_f16 v64, v93, s18, 0                           // 00000014D7F8: CC220040 0200255D
	s_waitcnt lgkmcnt(7)                                       // 00000014D800: BF89FC77
	v_fma_mixlo_f16 v65, v94, s18, 0                           // 00000014D804: CC210041 0200255E
	v_fma_mixhi_f16 v65, v95, s18, 0                           // 00000014D80C: CC220041 0200255F
	v_fma_mixlo_f16 v66, v96, s18, 0                           // 00000014D814: CC210042 02002560
	v_fma_mixhi_f16 v66, v97, s18, 0                           // 00000014D81C: CC220042 02002561
	s_waitcnt lgkmcnt(6)                                       // 00000014D824: BF89FC67
	v_fma_mixlo_f16 v90, v98, s18, 0                           // 00000014D828: CC21005A 02002562
	v_fma_mixhi_f16 v90, v99, s18, 0                           // 00000014D830: CC22005A 02002563
	v_fma_mixlo_f16 v91, v100, s18, 0                          // 00000014D838: CC21005B 02002564
	v_fma_mixhi_f16 v91, v101, s18, 0                          // 00000014D840: CC22005B 02002565
	s_waitcnt lgkmcnt(5)                                       // 00000014D848: BF89FC57
	v_fma_mixlo_f16 v92, v102, s18, 0                          // 00000014D84C: CC21005C 02002566
	v_fma_mixhi_f16 v92, v103, s18, 0                          // 00000014D854: CC22005C 02002567
	v_fma_mixlo_f16 v93, v104, s18, 0                          // 00000014D85C: CC21005D 02002568
	v_fma_mixhi_f16 v93, v105, s18, 0                          // 00000014D864: CC22005D 02002569
	s_waitcnt lgkmcnt(4)                                       // 00000014D86C: BF89FC47
	v_fma_mixlo_f16 v94, v106, s18, 0                          // 00000014D870: CC21005E 0200256A
	ds_load_b128 v[102:105], v78 offset:17056                  // 00000014D878: DBFC42A0 6600004E
	v_fma_mixhi_f16 v94, v107, s18, 0                          // 00000014D880: CC22005E 0200256B
	v_fma_mixlo_f16 v95, v108, s18, 0                          // 00000014D888: CC21005F 0200256C
	v_fma_mixhi_f16 v95, v109, s18, 0                          // 00000014D890: CC22005F 0200256D
	s_waitcnt lgkmcnt(4)                                       // 00000014D898: BF89FC47
	v_fma_mixlo_f16 v96, v110, s18, 0                          // 00000014D89C: CC210060 0200256E
	ds_load_b128 v[106:109], v78 offset:17072                  // 00000014D8A4: DBFC42B0 6A00004E
	v_fma_mixhi_f16 v96, v111, s18, 0                          // 00000014D8AC: CC220060 0200256F
	v_fma_mixlo_f16 v97, v112, s18, 0                          // 00000014D8B4: CC210061 02002570
	v_fma_mixhi_f16 v97, v113, s18, 0                          // 00000014D8BC: CC220061 02002571
	ds_load_b128 v[110:113], v78 offset:25472                  // 00000014D8C4: DBFC6380 6E00004E
	s_waitcnt lgkmcnt(5)                                       // 00000014D8CC: BF89FC57
	v_fma_mixlo_f16 v98, v114, s18, 0                          // 00000014D8D0: CC210062 02002572
	v_fma_mixhi_f16 v98, v115, s18, 0                          // 00000014D8D8: CC220062 02002573
	v_fma_mixlo_f16 v99, v116, s18, 0                          // 00000014D8E0: CC210063 02002574
	v_fma_mixhi_f16 v99, v117, s18, 0                          // 00000014D8E8: CC220063 02002575
	s_waitcnt lgkmcnt(4)                                       // 00000014D8F0: BF89FC47
	v_fma_mixlo_f16 v100, v118, s18, 0                         // 00000014D8F4: CC210064 02002576
	v_fma_mixhi_f16 v100, v119, s18, 0                         // 00000014D8FC: CC220064 02002577
	ds_load_b128 v[114:117], v78 offset:25504                  // 00000014D904: DBFC63A0 7200004E
	v_fma_mixlo_f16 v101, v120, s18, 0                         // 00000014D90C: CC210065 02002578
	v_fma_mixhi_f16 v101, v121, s18, 0                         // 00000014D914: CC220065 02002579
	ds_load_b128 v[118:121], v78 offset:25520                  // 00000014D91C: DBFC63B0 7600004E
	s_waitcnt lgkmcnt(4)                                       // 00000014D924: BF89FC47
	v_fma_mixlo_f16 v102, v102, s18, 0                         // 00000014D928: CC210066 02002566
	v_fma_mixhi_f16 v102, v103, s18, 0                         // 00000014D930: CC220066 02002567
	v_fma_mixlo_f16 v103, v104, s18, 0                         // 00000014D938: CC210067 02002568
	v_fma_mixhi_f16 v103, v105, s18, 0                         // 00000014D940: CC220067 02002569
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[59:66], v[42:49]// 00000014D948: CC40402A 1CAA7732
	s_waitcnt lgkmcnt(3)                                       // 00000014D950: BF89FC37
	v_fma_mixlo_f16 v104, v106, s18, 0                         // 00000014D954: CC210068 0200256A
	v_fma_mixhi_f16 v104, v107, s18, 0                         // 00000014D95C: CC220068 0200256B
	v_fma_mixlo_f16 v105, v108, s18, 0                         // 00000014D964: CC210069 0200256C
	v_fma_mixhi_f16 v105, v109, s18, 0                         // 00000014D96C: CC220069 0200256D
	s_waitcnt lgkmcnt(2)                                       // 00000014D974: BF89FC27
	v_fma_mixlo_f16 v106, v110, s18, 0                         // 00000014D978: CC21006A 0200256E
	v_fma_mixhi_f16 v106, v111, s18, 0                         // 00000014D980: CC22006A 0200256F
	v_fma_mixlo_f16 v107, v112, s18, 0                         // 00000014D988: CC21006B 02002570
	v_fma_mixhi_f16 v107, v113, s18, 0                         // 00000014D990: CC22006B 02002571
	v_fma_mixlo_f16 v108, v122, s18, 0                         // 00000014D998: CC21006C 0200257A
	v_fma_mixhi_f16 v108, v123, s18, 0                         // 00000014D9A0: CC22006C 0200257B
	v_fma_mixlo_f16 v109, v124, s18, 0                         // 00000014D9A8: CC21006D 0200257C
	v_fma_mixhi_f16 v109, v125, s18, 0                         // 00000014D9B0: CC22006D 0200257D
	s_waitcnt lgkmcnt(1)                                       // 00000014D9B8: BF89FC17
	v_fma_mixlo_f16 v110, v114, s18, 0                         // 00000014D9BC: CC21006E 02002572
	v_fma_mixhi_f16 v110, v115, s18, 0                         // 00000014D9C4: CC22006E 02002573
	v_fma_mixlo_f16 v111, v116, s18, 0                         // 00000014D9CC: CC21006F 02002574
	v_fma_mixhi_f16 v111, v117, s18, 0                         // 00000014D9D4: CC22006F 02002575
	s_waitcnt lgkmcnt(0)                                       // 00000014D9DC: BF89FC07
	v_fma_mixlo_f16 v112, v118, s18, 0                         // 00000014D9E0: CC210070 02002576
	v_fma_mixhi_f16 v112, v119, s18, 0                         // 00000014D9E8: CC220070 02002577
	v_fma_mixlo_f16 v113, v120, s18, 0                         // 00000014D9F0: CC210071 02002578
	v_fma_mixhi_f16 v113, v121, s18, 0                         // 00000014D9F8: CC220071 02002579
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[90:97], v[34:41]// 00000014DA00: CC404022 1C8AB532
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[98:105], v[26:33]// 00000014DA08: CC40401A 1C6AC532
	s_delay_alu instid0(VALU_DEP_3)                            // 00000014DA10: BF870003
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[106:113], v[18:25]// 00000014DA14: CC404012 1C4AD532
	.long 0x7f7039ba                                           // 00000014DA1C: 7F7039BA
	.long 0x7e7039ba                                           // 00000014DA20: 7E7039BA
	.long 0x7f6e39ba                                           // 00000014DA24: 7F6E39BA
	.long 0x7e6e39ba                                           // 00000014DA28: 7E6E39BA
	s_and_saveexec_b32 s1, s0                                  // 00000014DA2C: BE812000
	s_cbranch_execz 11                                         // 00000014DA30: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1160>
	global_load_b128 v[50:53], v[3:4], off offset:192          // 00000014DA34: DC5E00C0 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014DA3C: BF8903F7
	v_fma_mixlo_f16 v55, v50, s18, 0                           // 00000014DA40: CC210037 02002532
	v_fma_mixhi_f16 v55, v51, s18, 0                           // 00000014DA48: CC220037 02002533
	v_fma_mixlo_f16 v56, v52, s18, 0                           // 00000014DA50: CC210038 02002534
	v_fma_mixhi_f16 v56, v53, s18, 0                           // 00000014DA58: CC220038 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DA60: 8C7E017E
	.long 0x7e7439ba                                           // 00000014DA64: 7E7439BA
	.long 0x7f7239ba                                           // 00000014DA68: 7F7239BA
	.long 0x7e7239ba                                           // 00000014DA6C: 7E7239BA
	s_and_saveexec_b32 s1, s0                                  // 00000014DA70: BE812000
	s_cbranch_execz 11                                         // 00000014DA74: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11a4>
	global_load_b128 v[50:53], v[3:4], off offset:208          // 00000014DA78: DC5E00D0 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014DA80: BF8903F7
	v_fma_mixlo_f16 v57, v50, s18, 0                           // 00000014DA84: CC210039 02002532
	v_fma_mixhi_f16 v57, v51, s18, 0                           // 00000014DA8C: CC220039 02002533
	v_fma_mixlo_f16 v58, v52, s18, 0                           // 00000014DA94: CC21003A 02002534
	v_fma_mixhi_f16 v58, v53, s18, 0                           // 00000014DA9C: CC22003A 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DAA4: 8C7E017E
	.long 0x7f7c3880                                           // 00000014DAA8: 7F7C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DAAC: BF870001
	.long 0x7f7839be                                           // 00000014DAB0: 7F7839BE
	.long 0x7e7839be                                           // 00000014DAB4: 7E7839BE
	.long 0x7f7639be                                           // 00000014DAB8: 7F7639BE
	.long 0x7e7639be                                           // 00000014DABC: 7E7639BE
	s_and_saveexec_b32 s1, s0                                  // 00000014DAC0: BE812000
	s_cbranch_execz 11                                         // 00000014DAC4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11f4>
	global_load_b128 v[50:53], v[3:4], off offset:224          // 00000014DAC8: DC5E00E0 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014DAD0: BF8903F7
	v_fma_mixlo_f16 v59, v50, s18, 0                           // 00000014DAD4: CC21003B 02002532
	v_fma_mixhi_f16 v59, v51, s18, 0                           // 00000014DADC: CC22003B 02002533
	v_fma_mixlo_f16 v60, v52, s18, 0                           // 00000014DAE4: CC21003C 02002534
	v_fma_mixhi_f16 v60, v53, s18, 0                           // 00000014DAEC: CC22003C 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DAF4: 8C7E017E
	.long 0x7e7c39be                                           // 00000014DAF8: 7E7C39BE
	.long 0x7f7a39be                                           // 00000014DAFC: 7F7A39BE
	.long 0x7e7a39be                                           // 00000014DB00: 7E7A39BE
	s_and_saveexec_b32 s1, s0                                  // 00000014DB04: BE812000
	s_cbranch_execz 11                                         // 00000014DB08: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1238>
	global_load_b128 v[50:53], v[3:4], off offset:240          // 00000014DB0C: DC5E00F0 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014DB14: BF8903F7
	v_fma_mixlo_f16 v61, v50, s18, 0                           // 00000014DB18: CC21003D 02002532
	v_fma_mixhi_f16 v61, v51, s18, 0                           // 00000014DB20: CC22003D 02002533
	v_fma_mixlo_f16 v62, v52, s18, 0                           // 00000014DB28: CC21003E 02002534
	v_fma_mixhi_f16 v62, v53, s18, 0                           // 00000014DB30: CC22003E 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DB38: 8C7E017E
	ds_load_b128 v[50:53], v78 offset:192                      // 00000014DB3C: DBFC00C0 3200004E
	ds_load_b128 v[63:66], v78 offset:208                      // 00000014DB44: DBFC00D0 3F00004E
	ds_load_b128 v[94:97], v78 offset:224                      // 00000014DB4C: DBFC00E0 5E00004E
	ds_load_b128 v[98:101], v78 offset:240                     // 00000014DB54: DBFC00F0 6200004E
	ds_load_b128 v[102:105], v78 offset:8640                   // 00000014DB5C: DBFC21C0 6600004E
	ds_load_b128 v[106:109], v78 offset:8656                   // 00000014DB64: DBFC21D0 6A00004E
	ds_load_b128 v[110:113], v78 offset:8672                   // 00000014DB6C: DBFC21E0 6E00004E
	ds_load_b128 v[114:117], v78 offset:8688                   // 00000014DB74: DBFC21F0 7200004E
	ds_load_b128 v[118:121], v78 offset:17120                  // 00000014DB7C: DBFC42E0 7600004E
	ds_load_b128 v[122:125], v78 offset:17136                  // 00000014DB84: DBFC42F0 7A00004E
	ds_load_b128 v[126:129], v78 offset:25552                  // 00000014DB8C: DBFC63D0 7E00004E
	s_waitcnt lgkmcnt(10)                                      // 00000014DB94: BF89FCA7
	v_fma_mixlo_f16 v90, v50, s18, 0                           // 00000014DB98: CC21005A 02002532
	v_fma_mixhi_f16 v90, v51, s18, 0                           // 00000014DBA0: CC22005A 02002533
	v_fma_mixlo_f16 v91, v52, s18, 0                           // 00000014DBA8: CC21005B 02002534
	v_fma_mixhi_f16 v91, v53, s18, 0                           // 00000014DBB0: CC22005B 02002535
	s_waitcnt lgkmcnt(9)                                       // 00000014DBB8: BF89FC97
	v_fma_mixlo_f16 v92, v63, s18, 0                           // 00000014DBBC: CC21005C 0200253F
	v_fma_mixhi_f16 v92, v64, s18, 0                           // 00000014DBC4: CC22005C 02002540
	v_fma_mixlo_f16 v93, v65, s18, 0                           // 00000014DBCC: CC21005D 02002541
	v_fma_mixhi_f16 v93, v66, s18, 0                           // 00000014DBD4: CC22005D 02002542
	ds_load_b128 v[50:53], v78 offset:17088                    // 00000014DBDC: DBFC42C0 3200004E
	ds_load_b128 v[63:66], v78 offset:17104                    // 00000014DBE4: DBFC42D0 3F00004E
	s_waitcnt lgkmcnt(10)                                      // 00000014DBEC: BF89FCA7
	v_fma_mixlo_f16 v94, v94, s18, 0                           // 00000014DBF0: CC21005E 0200255E
	v_fma_mixhi_f16 v94, v95, s18, 0                           // 00000014DBF8: CC22005E 0200255F
	v_fma_mixlo_f16 v95, v96, s18, 0                           // 00000014DC00: CC21005F 02002560
	v_fma_mixhi_f16 v95, v97, s18, 0                           // 00000014DC08: CC22005F 02002561
	s_waitcnt lgkmcnt(9)                                       // 00000014DC10: BF89FC97
	v_fma_mixhi_f16 v96, v99, s18, 0                           // 00000014DC14: CC220060 02002563
	v_fma_mixlo_f16 v97, v100, s18, 0                          // 00000014DC1C: CC210061 02002564
	v_fma_mixhi_f16 v97, v101, s18, 0                          // 00000014DC24: CC220061 02002565
	s_waitcnt lgkmcnt(8)                                       // 00000014DC2C: BF89FC87
	v_fma_mixlo_f16 v99, v104, s18, 0                          // 00000014DC30: CC210063 02002568
	v_fma_mixhi_f16 v99, v105, s18, 0                          // 00000014DC38: CC220063 02002569
	s_waitcnt lgkmcnt(7)                                       // 00000014DC40: BF89FC77
	v_fma_mixlo_f16 v100, v106, s18, 0                         // 00000014DC44: CC210064 0200256A
	v_fma_mixhi_f16 v100, v107, s18, 0                         // 00000014DC4C: CC220064 0200256B
	v_fma_mixlo_f16 v101, v108, s18, 0                         // 00000014DC54: CC210065 0200256C
	v_fma_mixhi_f16 v101, v109, s18, 0                         // 00000014DC5C: CC220065 0200256D
	s_waitcnt lgkmcnt(5)                                       // 00000014DC64: BF89FC57
	v_fma_mixlo_f16 v104, v114, s18, 0                         // 00000014DC68: CC210068 02002572
	v_fma_mixhi_f16 v104, v115, s18, 0                         // 00000014DC70: CC220068 02002573
	v_fma_mixlo_f16 v105, v116, s18, 0                         // 00000014DC78: CC210069 02002574
	v_fma_mixhi_f16 v105, v117, s18, 0                         // 00000014DC80: CC220069 02002575
	ds_load_b128 v[114:117], v78 offset:25536                  // 00000014DC88: DBFC63C0 7200004E
	s_waitcnt lgkmcnt(2)                                       // 00000014DC90: BF89FC27
	v_fma_mixlo_f16 v106, v50, s18, 0                          // 00000014DC94: CC21006A 02002532
	v_fma_mixhi_f16 v106, v51, s18, 0                          // 00000014DC9C: CC22006A 02002533
	v_fma_mixlo_f16 v107, v52, s18, 0                          // 00000014DCA4: CC21006B 02002534
	v_fma_mixhi_f16 v107, v53, s18, 0                          // 00000014DCAC: CC22006B 02002535
	s_waitcnt lgkmcnt(1)                                       // 00000014DCB4: BF89FC17
	v_fma_mixlo_f16 v108, v63, s18, 0                          // 00000014DCB8: CC21006C 0200253F
	v_fma_mixhi_f16 v108, v64, s18, 0                          // 00000014DCC0: CC22006C 02002540
	ds_load_b128 v[50:53], v78 offset:25568                    // 00000014DCC8: DBFC63E0 3200004E
	v_fma_mixlo_f16 v109, v65, s18, 0                          // 00000014DCD0: CC21006D 02002541
	v_fma_mixhi_f16 v109, v66, s18, 0                          // 00000014DCD8: CC22006D 02002542
	ds_load_b128 v[63:66], v78 offset:25584                    // 00000014DCE0: DBFC63F0 3F00004E
	v_fma_mixlo_f16 v96, v98, s18, 0                           // 00000014DCE8: CC210060 02002562
	v_fma_mixlo_f16 v98, v102, s18, 0                          // 00000014DCF0: CC210062 02002566
	v_fma_mixhi_f16 v98, v103, s18, 0                          // 00000014DCF8: CC220062 02002567
	v_fma_mixlo_f16 v102, v110, s18, 0                         // 00000014DD00: CC210066 0200256E
	v_fma_mixhi_f16 v102, v111, s18, 0                         // 00000014DD08: CC220066 0200256F
	v_fma_mixlo_f16 v103, v112, s18, 0                         // 00000014DD10: CC210067 02002570
	v_fma_mixhi_f16 v103, v113, s18, 0                         // 00000014DD18: CC220067 02002571
	v_fma_mixlo_f16 v110, v118, s18, 0                         // 00000014DD20: CC21006E 02002576
	v_fma_mixhi_f16 v110, v119, s18, 0                         // 00000014DD28: CC22006E 02002577
	v_fma_mixlo_f16 v111, v120, s18, 0                         // 00000014DD30: CC21006F 02002578
	v_fma_mixhi_f16 v111, v121, s18, 0                         // 00000014DD38: CC22006F 02002579
	v_fma_mixlo_f16 v112, v122, s18, 0                         // 00000014DD40: CC210070 0200257A
	v_fma_mixhi_f16 v112, v123, s18, 0                         // 00000014DD48: CC220070 0200257B
	v_fma_mixlo_f16 v113, v124, s18, 0                         // 00000014DD50: CC210071 0200257C
	v_fma_mixhi_f16 v113, v125, s18, 0                         // 00000014DD58: CC220071 0200257D
	s_waitcnt lgkmcnt(2)                                       // 00000014DD60: BF89FC27
	v_fma_mixlo_f16 v114, v114, s18, 0                         // 00000014DD64: CC210072 02002572
	v_fma_mixhi_f16 v114, v115, s18, 0                         // 00000014DD6C: CC220072 02002573
	v_fma_mixlo_f16 v115, v116, s18, 0                         // 00000014DD74: CC210073 02002574
	v_fma_mixhi_f16 v115, v117, s18, 0                         // 00000014DD7C: CC220073 02002575
	v_fma_mixlo_f16 v116, v126, s18, 0                         // 00000014DD84: CC210074 0200257E
	v_fma_mixhi_f16 v116, v127, s18, 0                         // 00000014DD8C: CC220074 0200257F
	v_fma_mixlo_f16 v117, v128, s18, 0                         // 00000014DD94: CC210075 02002580
	v_fma_mixhi_f16 v117, v129, s18, 0                         // 00000014DD9C: CC220075 02002581
	s_waitcnt lgkmcnt(1)                                       // 00000014DDA4: BF89FC17
	v_fma_mixlo_f16 v118, v50, s18, 0                          // 00000014DDA8: CC210076 02002532
	v_fma_mixhi_f16 v118, v51, s18, 0                          // 00000014DDB0: CC220076 02002533
	v_fma_mixlo_f16 v119, v52, s18, 0                          // 00000014DDB8: CC210077 02002534
	v_fma_mixhi_f16 v119, v53, s18, 0                          // 00000014DDC0: CC220077 02002535
	s_waitcnt lgkmcnt(0)                                       // 00000014DDC8: BF89FC07
	v_fma_mixlo_f16 v120, v63, s18, 0                          // 00000014DDCC: CC210078 0200253F
	v_fma_mixhi_f16 v120, v64, s18, 0                          // 00000014DDD4: CC220078 02002540
	v_fma_mixlo_f16 v121, v65, s18, 0                          // 00000014DDDC: CC210079 02002541
	v_fma_mixhi_f16 v121, v66, s18, 0                          // 00000014DDE4: CC220079 02002542
	.long 0x7f6a3880                                           // 00000014DDEC: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[55:62], v[90:97], v[42:49]// 00000014DDF0: CC40402A 1CAAB537
	v_wmma_f32_16x16x16_f16 v[34:41], v[55:62], v[98:105], v[34:41]// 00000014DDF8: CC404022 1C8AC537
	v_wmma_f32_16x16x16_f16 v[26:33], v[55:62], v[106:113], v[26:33]// 00000014DE00: CC40401A 1C6AD537
	v_wmma_f32_16x16x16_f16 v[18:25], v[55:62], v[114:121], v[18:25]// 00000014DE08: CC404012 1C4AE537
	.long 0x7f6639b5                                           // 00000014DE10: 7F6639B5
	.long 0x7e6639b5                                           // 00000014DE14: 7E6639B5
	.long 0x7f6439b5                                           // 00000014DE18: 7F6439B5
	.long 0x7e6439b5                                           // 00000014DE1C: 7E6439B5
	s_and_saveexec_b32 s1, s0                                  // 00000014DE20: BE812000
	s_cbranch_execz 11                                         // 00000014DE24: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1554>
	global_load_b128 v[54:57], v[3:4], off offset:256          // 00000014DE28: DC5E0100 367C0003
	s_waitcnt vmcnt(0)                                         // 00000014DE30: BF8903F7
	v_fma_mixlo_f16 v50, v54, s18, 0                           // 00000014DE34: CC210032 02002536
	v_fma_mixhi_f16 v50, v55, s18, 0                           // 00000014DE3C: CC220032 02002537
	v_fma_mixlo_f16 v51, v56, s18, 0                           // 00000014DE44: CC210033 02002538
	v_fma_mixhi_f16 v51, v57, s18, 0                           // 00000014DE4C: CC220033 02002539
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DE54: 8C7E017E
	.long 0x7e6a39b5                                           // 00000014DE58: 7E6A39B5
	.long 0x7f6839b5                                           // 00000014DE5C: 7F6839B5
	.long 0x7e6839b5                                           // 00000014DE60: 7E6839B5
	s_and_saveexec_b32 s1, s0                                  // 00000014DE64: BE812000
	s_cbranch_execz 11                                         // 00000014DE68: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1598>
	global_load_b128 v[52:55], v[3:4], off offset:272          // 00000014DE6C: DC5E0110 347C0003
	s_waitcnt vmcnt(0)                                         // 00000014DE74: BF8903F7
	v_fma_mixlo_f16 v52, v52, s18, 0                           // 00000014DE78: CC210034 02002534
	v_fma_mixhi_f16 v52, v53, s18, 0                           // 00000014DE80: CC220034 02002535
	v_fma_mixlo_f16 v53, v54, s18, 0                           // 00000014DE88: CC210035 02002536
	v_fma_mixhi_f16 v53, v55, s18, 0                           // 00000014DE90: CC220035 02002537
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DE98: 8C7E017E
	.long 0x7f723880                                           // 00000014DE9C: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DEA0: BF870001
	.long 0x7f6e39b9                                           // 00000014DEA4: 7F6E39B9
	.long 0x7e6e39b9                                           // 00000014DEA8: 7E6E39B9
	.long 0x7f6c39b9                                           // 00000014DEAC: 7F6C39B9
	.long 0x7e6c39b9                                           // 00000014DEB0: 7E6C39B9
	s_and_saveexec_b32 s1, s0                                  // 00000014DEB4: BE812000
	s_cbranch_execz 11                                         // 00000014DEB8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15e8>
	global_load_b128 v[58:61], v[3:4], off offset:288          // 00000014DEBC: DC5E0120 3A7C0003
	s_waitcnt vmcnt(0)                                         // 00000014DEC4: BF8903F7
	v_fma_mixlo_f16 v54, v58, s18, 0                           // 00000014DEC8: CC210036 0200253A
	v_fma_mixhi_f16 v54, v59, s18, 0                           // 00000014DED0: CC220036 0200253B
	v_fma_mixlo_f16 v55, v60, s18, 0                           // 00000014DED8: CC210037 0200253C
	v_fma_mixhi_f16 v55, v61, s18, 0                           // 00000014DEE0: CC220037 0200253D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DEE8: 8C7E017E
	.long 0x7e7239b9                                           // 00000014DEEC: 7E7239B9
	.long 0x7f7039b9                                           // 00000014DEF0: 7F7039B9
	.long 0x7e7039b9                                           // 00000014DEF4: 7E7039B9
	s_and_saveexec_b32 s1, s0                                  // 00000014DEF8: BE812000
	s_cbranch_execz 11                                         // 00000014DEFC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x162c>
	global_load_b128 v[56:59], v[3:4], off offset:304          // 00000014DF00: DC5E0130 387C0003
	s_waitcnt vmcnt(0)                                         // 00000014DF08: BF8903F7
	v_fma_mixlo_f16 v56, v56, s18, 0                           // 00000014DF0C: CC210038 02002538
	v_fma_mixhi_f16 v56, v57, s18, 0                           // 00000014DF14: CC220038 02002539
	v_fma_mixlo_f16 v57, v58, s18, 0                           // 00000014DF1C: CC210039 0200253A
	v_fma_mixhi_f16 v57, v59, s18, 0                           // 00000014DF24: CC220039 0200253B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DF2C: 8C7E017E
	ds_load_b128 v[59:62], v78 offset:256                      // 00000014DF30: DBFC0100 3B00004E
	ds_load_b128 v[63:66], v78 offset:272                      // 00000014DF38: DBFC0110 3F00004E
	ds_load_b128 v[90:93], v78 offset:288                      // 00000014DF40: DBFC0120 5A00004E
	ds_load_b128 v[94:97], v78 offset:304                      // 00000014DF48: DBFC0130 5E00004E
	ds_load_b128 v[98:101], v78 offset:8704                    // 00000014DF50: DBFC2200 6200004E
	ds_load_b128 v[102:105], v78 offset:8720                   // 00000014DF58: DBFC2210 6600004E
	ds_load_b128 v[106:109], v78 offset:8736                   // 00000014DF60: DBFC2220 6A00004E
	ds_load_b128 v[110:113], v78 offset:8752                   // 00000014DF68: DBFC2230 6E00004E
	ds_load_b128 v[114:117], v78 offset:17152                  // 00000014DF70: DBFC4300 7200004E
	ds_load_b128 v[118:121], v78 offset:17168                  // 00000014DF78: DBFC4310 7600004E
	.long 0x7f743880                                           // 00000014DF80: 7F743880
	ds_load_b128 v[122:125], v78 offset:25616                  // 00000014DF84: DBFC6410 7A00004E
	s_waitcnt lgkmcnt(10)                                      // 00000014DF8C: BF89FCA7
	v_fma_mixlo_f16 v59, v59, s18, 0                           // 00000014DF90: CC21003B 0200253B
	v_fma_mixhi_f16 v59, v60, s18, 0                           // 00000014DF98: CC22003B 0200253C
	v_fma_mixlo_f16 v60, v61, s18, 0                           // 00000014DFA0: CC21003C 0200253D
	v_fma_mixhi_f16 v60, v62, s18, 0                           // 00000014DFA8: CC22003C 0200253E
	s_waitcnt lgkmcnt(9)                                       // 00000014DFB0: BF89FC97
	v_fma_mixlo_f16 v61, v63, s18, 0                           // 00000014DFB4: CC21003D 0200253F
	v_fma_mixhi_f16 v61, v64, s18, 0                           // 00000014DFBC: CC22003D 02002540
	v_fma_mixlo_f16 v62, v65, s18, 0                           // 00000014DFC4: CC21003E 02002541
	v_fma_mixhi_f16 v62, v66, s18, 0                           // 00000014DFCC: CC22003E 02002542
	s_waitcnt lgkmcnt(8)                                       // 00000014DFD4: BF89FC87
	v_fma_mixlo_f16 v63, v90, s18, 0                           // 00000014DFD8: CC21003F 0200255A
	v_fma_mixhi_f16 v63, v91, s18, 0                           // 00000014DFE0: CC22003F 0200255B
	v_fma_mixlo_f16 v64, v92, s18, 0                           // 00000014DFE8: CC210040 0200255C
	v_fma_mixhi_f16 v64, v93, s18, 0                           // 00000014DFF0: CC220040 0200255D
	s_waitcnt lgkmcnt(7)                                       // 00000014DFF8: BF89FC77
	v_fma_mixlo_f16 v65, v94, s18, 0                           // 00000014DFFC: CC210041 0200255E
	v_fma_mixhi_f16 v65, v95, s18, 0                           // 00000014E004: CC220041 0200255F
	v_fma_mixlo_f16 v66, v96, s18, 0                           // 00000014E00C: CC210042 02002560
	v_fma_mixhi_f16 v66, v97, s18, 0                           // 00000014E014: CC220042 02002561
	s_waitcnt lgkmcnt(6)                                       // 00000014E01C: BF89FC67
	v_fma_mixlo_f16 v90, v98, s18, 0                           // 00000014E020: CC21005A 02002562
	v_fma_mixhi_f16 v90, v99, s18, 0                           // 00000014E028: CC22005A 02002563
	v_fma_mixlo_f16 v91, v100, s18, 0                          // 00000014E030: CC21005B 02002564
	v_fma_mixhi_f16 v91, v101, s18, 0                          // 00000014E038: CC22005B 02002565
	s_waitcnt lgkmcnt(5)                                       // 00000014E040: BF89FC57
	v_fma_mixlo_f16 v92, v102, s18, 0                          // 00000014E044: CC21005C 02002566
	v_fma_mixhi_f16 v92, v103, s18, 0                          // 00000014E04C: CC22005C 02002567
	v_fma_mixlo_f16 v93, v104, s18, 0                          // 00000014E054: CC21005D 02002568
	v_fma_mixhi_f16 v93, v105, s18, 0                          // 00000014E05C: CC22005D 02002569
	s_waitcnt lgkmcnt(4)                                       // 00000014E064: BF89FC47
	v_fma_mixlo_f16 v94, v106, s18, 0                          // 00000014E068: CC21005E 0200256A
	ds_load_b128 v[102:105], v78 offset:17184                  // 00000014E070: DBFC4320 6600004E
	v_fma_mixhi_f16 v94, v107, s18, 0                          // 00000014E078: CC22005E 0200256B
	v_fma_mixlo_f16 v95, v108, s18, 0                          // 00000014E080: CC21005F 0200256C
	v_fma_mixhi_f16 v95, v109, s18, 0                          // 00000014E088: CC22005F 0200256D
	s_waitcnt lgkmcnt(4)                                       // 00000014E090: BF89FC47
	v_fma_mixlo_f16 v96, v110, s18, 0                          // 00000014E094: CC210060 0200256E
	ds_load_b128 v[106:109], v78 offset:17200                  // 00000014E09C: DBFC4330 6A00004E
	v_fma_mixhi_f16 v96, v111, s18, 0                          // 00000014E0A4: CC220060 0200256F
	v_fma_mixlo_f16 v97, v112, s18, 0                          // 00000014E0AC: CC210061 02002570
	v_fma_mixhi_f16 v97, v113, s18, 0                          // 00000014E0B4: CC220061 02002571
	ds_load_b128 v[110:113], v78 offset:25600                  // 00000014E0BC: DBFC6400 6E00004E
	s_waitcnt lgkmcnt(5)                                       // 00000014E0C4: BF89FC57
	v_fma_mixlo_f16 v98, v114, s18, 0                          // 00000014E0C8: CC210062 02002572
	v_fma_mixhi_f16 v98, v115, s18, 0                          // 00000014E0D0: CC220062 02002573
	v_fma_mixlo_f16 v99, v116, s18, 0                          // 00000014E0D8: CC210063 02002574
	v_fma_mixhi_f16 v99, v117, s18, 0                          // 00000014E0E0: CC220063 02002575
	s_waitcnt lgkmcnt(4)                                       // 00000014E0E8: BF89FC47
	v_fma_mixlo_f16 v100, v118, s18, 0                         // 00000014E0EC: CC210064 02002576
	v_fma_mixhi_f16 v100, v119, s18, 0                         // 00000014E0F4: CC220064 02002577
	ds_load_b128 v[114:117], v78 offset:25632                  // 00000014E0FC: DBFC6420 7200004E
	v_fma_mixlo_f16 v101, v120, s18, 0                         // 00000014E104: CC210065 02002578
	v_fma_mixhi_f16 v101, v121, s18, 0                         // 00000014E10C: CC220065 02002579
	ds_load_b128 v[118:121], v78 offset:25648                  // 00000014E114: DBFC6430 7600004E
	s_waitcnt lgkmcnt(4)                                       // 00000014E11C: BF89FC47
	v_fma_mixlo_f16 v102, v102, s18, 0                         // 00000014E120: CC210066 02002566
	v_fma_mixhi_f16 v102, v103, s18, 0                         // 00000014E128: CC220066 02002567
	v_fma_mixlo_f16 v103, v104, s18, 0                         // 00000014E130: CC210067 02002568
	v_fma_mixhi_f16 v103, v105, s18, 0                         // 00000014E138: CC220067 02002569
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[59:66], v[42:49]// 00000014E140: CC40402A 1CAA7732
	s_waitcnt lgkmcnt(3)                                       // 00000014E148: BF89FC37
	v_fma_mixlo_f16 v104, v106, s18, 0                         // 00000014E14C: CC210068 0200256A
	v_fma_mixhi_f16 v104, v107, s18, 0                         // 00000014E154: CC220068 0200256B
	v_fma_mixlo_f16 v105, v108, s18, 0                         // 00000014E15C: CC210069 0200256C
	v_fma_mixhi_f16 v105, v109, s18, 0                         // 00000014E164: CC220069 0200256D
	s_waitcnt lgkmcnt(2)                                       // 00000014E16C: BF89FC27
	v_fma_mixlo_f16 v106, v110, s18, 0                         // 00000014E170: CC21006A 0200256E
	v_fma_mixhi_f16 v106, v111, s18, 0                         // 00000014E178: CC22006A 0200256F
	v_fma_mixlo_f16 v107, v112, s18, 0                         // 00000014E180: CC21006B 02002570
	v_fma_mixhi_f16 v107, v113, s18, 0                         // 00000014E188: CC22006B 02002571
	v_fma_mixlo_f16 v108, v122, s18, 0                         // 00000014E190: CC21006C 0200257A
	v_fma_mixhi_f16 v108, v123, s18, 0                         // 00000014E198: CC22006C 0200257B
	v_fma_mixlo_f16 v109, v124, s18, 0                         // 00000014E1A0: CC21006D 0200257C
	v_fma_mixhi_f16 v109, v125, s18, 0                         // 00000014E1A8: CC22006D 0200257D
	s_waitcnt lgkmcnt(1)                                       // 00000014E1B0: BF89FC17
	v_fma_mixlo_f16 v110, v114, s18, 0                         // 00000014E1B4: CC21006E 02002572
	v_fma_mixhi_f16 v110, v115, s18, 0                         // 00000014E1BC: CC22006E 02002573
	v_fma_mixlo_f16 v111, v116, s18, 0                         // 00000014E1C4: CC21006F 02002574
	v_fma_mixhi_f16 v111, v117, s18, 0                         // 00000014E1CC: CC22006F 02002575
	s_waitcnt lgkmcnt(0)                                       // 00000014E1D4: BF89FC07
	v_fma_mixlo_f16 v112, v118, s18, 0                         // 00000014E1D8: CC210070 02002576
	v_fma_mixhi_f16 v112, v119, s18, 0                         // 00000014E1E0: CC220070 02002577
	v_fma_mixlo_f16 v113, v120, s18, 0                         // 00000014E1E8: CC210071 02002578
	v_fma_mixhi_f16 v113, v121, s18, 0                         // 00000014E1F0: CC220071 02002579
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[90:97], v[34:41]// 00000014E1F8: CC404022 1C8AB532
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[98:105], v[26:33]// 00000014E200: CC40401A 1C6AC532
	s_delay_alu instid0(VALU_DEP_3)                            // 00000014E208: BF870003
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[106:113], v[18:25]// 00000014E20C: CC404012 1C4AD532
	.long 0x7f7039ba                                           // 00000014E214: 7F7039BA
	.long 0x7e7039ba                                           // 00000014E218: 7E7039BA
	.long 0x7f6e39ba                                           // 00000014E21C: 7F6E39BA
	.long 0x7e6e39ba                                           // 00000014E220: 7E6E39BA
	s_and_saveexec_b32 s1, s0                                  // 00000014E224: BE812000
	s_cbranch_execz 11                                         // 00000014E228: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1958>
	global_load_b128 v[50:53], v[3:4], off offset:320          // 00000014E22C: DC5E0140 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014E234: BF8903F7
	v_fma_mixlo_f16 v55, v50, s18, 0                           // 00000014E238: CC210037 02002532
	v_fma_mixhi_f16 v55, v51, s18, 0                           // 00000014E240: CC220037 02002533
	v_fma_mixlo_f16 v56, v52, s18, 0                           // 00000014E248: CC210038 02002534
	v_fma_mixhi_f16 v56, v53, s18, 0                           // 00000014E250: CC220038 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014E258: 8C7E017E
	.long 0x7e7439ba                                           // 00000014E25C: 7E7439BA
	.long 0x7f7239ba                                           // 00000014E260: 7F7239BA
	.long 0x7e7239ba                                           // 00000014E264: 7E7239BA
	s_and_saveexec_b32 s1, s0                                  // 00000014E268: BE812000
	s_cbranch_execz 11                                         // 00000014E26C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x199c>
	global_load_b128 v[50:53], v[3:4], off offset:336          // 00000014E270: DC5E0150 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014E278: BF8903F7
	v_fma_mixlo_f16 v57, v50, s18, 0                           // 00000014E27C: CC210039 02002532
	v_fma_mixhi_f16 v57, v51, s18, 0                           // 00000014E284: CC220039 02002533
	v_fma_mixlo_f16 v58, v52, s18, 0                           // 00000014E28C: CC21003A 02002534
	v_fma_mixhi_f16 v58, v53, s18, 0                           // 00000014E294: CC22003A 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014E29C: 8C7E017E
	.long 0x7f7c3880                                           // 00000014E2A0: 7F7C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014E2A4: BF870001
	.long 0x7f7839be                                           // 00000014E2A8: 7F7839BE
	.long 0x7e7839be                                           // 00000014E2AC: 7E7839BE
	.long 0x7f7639be                                           // 00000014E2B0: 7F7639BE
	.long 0x7e7639be                                           // 00000014E2B4: 7E7639BE
	s_and_saveexec_b32 s1, s0                                  // 00000014E2B8: BE812000
	s_cbranch_execz 11                                         // 00000014E2BC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19ec>
	global_load_b128 v[50:53], v[3:4], off offset:352          // 00000014E2C0: DC5E0160 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014E2C8: BF8903F7
	v_fma_mixlo_f16 v59, v50, s18, 0                           // 00000014E2CC: CC21003B 02002532
	v_fma_mixhi_f16 v59, v51, s18, 0                           // 00000014E2D4: CC22003B 02002533
	v_fma_mixlo_f16 v60, v52, s18, 0                           // 00000014E2DC: CC21003C 02002534
	v_fma_mixhi_f16 v60, v53, s18, 0                           // 00000014E2E4: CC22003C 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014E2EC: 8C7E017E
	.long 0x7e7c39be                                           // 00000014E2F0: 7E7C39BE
	.long 0x7f7a39be                                           // 00000014E2F4: 7F7A39BE
	.long 0x7e7a39be                                           // 00000014E2F8: 7E7A39BE
	s_and_saveexec_b32 s1, s0                                  // 00000014E2FC: BE812000
	s_cbranch_execz 11                                         // 00000014E300: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a30>
	global_load_b128 v[50:53], v[3:4], off offset:368          // 00000014E304: DC5E0170 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014E30C: BF8903F7
	v_fma_mixlo_f16 v61, v50, s18, 0                           // 00000014E310: CC21003D 02002532
	v_fma_mixhi_f16 v61, v51, s18, 0                           // 00000014E318: CC22003D 02002533
	v_fma_mixlo_f16 v62, v52, s18, 0                           // 00000014E320: CC21003E 02002534
	v_fma_mixhi_f16 v62, v53, s18, 0                           // 00000014E328: CC22003E 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014E330: 8C7E017E
	ds_load_b128 v[50:53], v78 offset:320                      // 00000014E334: DBFC0140 3200004E
	ds_load_b128 v[63:66], v78 offset:336                      // 00000014E33C: DBFC0150 3F00004E
	ds_load_b128 v[94:97], v78 offset:352                      // 00000014E344: DBFC0160 5E00004E
	ds_load_b128 v[98:101], v78 offset:368                     // 00000014E34C: DBFC0170 6200004E
	ds_load_b128 v[102:105], v78 offset:8768                   // 00000014E354: DBFC2240 6600004E
	ds_load_b128 v[106:109], v78 offset:8784                   // 00000014E35C: DBFC2250 6A00004E
	ds_load_b128 v[110:113], v78 offset:8800                   // 00000014E364: DBFC2260 6E00004E
	ds_load_b128 v[114:117], v78 offset:8816                   // 00000014E36C: DBFC2270 7200004E
	ds_load_b128 v[118:121], v78 offset:17248                  // 00000014E374: DBFC4360 7600004E
	ds_load_b128 v[122:125], v78 offset:17264                  // 00000014E37C: DBFC4370 7A00004E
	ds_load_b128 v[126:129], v78 offset:25680                  // 00000014E384: DBFC6450 7E00004E
	s_waitcnt lgkmcnt(10)                                      // 00000014E38C: BF89FCA7
	v_fma_mixlo_f16 v90, v50, s18, 0                           // 00000014E390: CC21005A 02002532
	v_fma_mixhi_f16 v90, v51, s18, 0                           // 00000014E398: CC22005A 02002533
	v_fma_mixlo_f16 v91, v52, s18, 0                           // 00000014E3A0: CC21005B 02002534
	v_fma_mixhi_f16 v91, v53, s18, 0                           // 00000014E3A8: CC22005B 02002535
	s_waitcnt lgkmcnt(9)                                       // 00000014E3B0: BF89FC97
	v_fma_mixlo_f16 v92, v63, s18, 0                           // 00000014E3B4: CC21005C 0200253F
	v_fma_mixhi_f16 v92, v64, s18, 0                           // 00000014E3BC: CC22005C 02002540
	v_fma_mixlo_f16 v93, v65, s18, 0                           // 00000014E3C4: CC21005D 02002541
	v_fma_mixhi_f16 v93, v66, s18, 0                           // 00000014E3CC: CC22005D 02002542
	ds_load_b128 v[50:53], v78 offset:17216                    // 00000014E3D4: DBFC4340 3200004E
	ds_load_b128 v[63:66], v78 offset:17232                    // 00000014E3DC: DBFC4350 3F00004E
	s_waitcnt lgkmcnt(10)                                      // 00000014E3E4: BF89FCA7
	v_fma_mixlo_f16 v94, v94, s18, 0                           // 00000014E3E8: CC21005E 0200255E
	v_fma_mixhi_f16 v94, v95, s18, 0                           // 00000014E3F0: CC22005E 0200255F
	v_fma_mixlo_f16 v95, v96, s18, 0                           // 00000014E3F8: CC21005F 02002560
	v_fma_mixhi_f16 v95, v97, s18, 0                           // 00000014E400: CC22005F 02002561
	s_waitcnt lgkmcnt(9)                                       // 00000014E408: BF89FC97
	v_fma_mixhi_f16 v96, v99, s18, 0                           // 00000014E40C: CC220060 02002563
	v_fma_mixlo_f16 v97, v100, s18, 0                          // 00000014E414: CC210061 02002564
	v_fma_mixhi_f16 v97, v101, s18, 0                          // 00000014E41C: CC220061 02002565
	s_waitcnt lgkmcnt(8)                                       // 00000014E424: BF89FC87
	v_fma_mixlo_f16 v99, v104, s18, 0                          // 00000014E428: CC210063 02002568
	v_fma_mixhi_f16 v99, v105, s18, 0                          // 00000014E430: CC220063 02002569
	s_waitcnt lgkmcnt(7)                                       // 00000014E438: BF89FC77
	v_fma_mixlo_f16 v100, v106, s18, 0                         // 00000014E43C: CC210064 0200256A
	v_fma_mixhi_f16 v100, v107, s18, 0                         // 00000014E444: CC220064 0200256B
	v_fma_mixlo_f16 v101, v108, s18, 0                         // 00000014E44C: CC210065 0200256C
	v_fma_mixhi_f16 v101, v109, s18, 0                         // 00000014E454: CC220065 0200256D
	s_waitcnt lgkmcnt(5)                                       // 00000014E45C: BF89FC57
	v_fma_mixlo_f16 v104, v114, s18, 0                         // 00000014E460: CC210068 02002572
	v_fma_mixhi_f16 v104, v115, s18, 0                         // 00000014E468: CC220068 02002573
	v_fma_mixlo_f16 v105, v116, s18, 0                         // 00000014E470: CC210069 02002574
	v_fma_mixhi_f16 v105, v117, s18, 0                         // 00000014E478: CC220069 02002575
	ds_load_b128 v[114:117], v78 offset:25664                  // 00000014E480: DBFC6440 7200004E
	s_waitcnt lgkmcnt(2)                                       // 00000014E488: BF89FC27
	v_fma_mixlo_f16 v106, v50, s18, 0                          // 00000014E48C: CC21006A 02002532
	v_fma_mixhi_f16 v106, v51, s18, 0                          // 00000014E494: CC22006A 02002533
	v_fma_mixlo_f16 v107, v52, s18, 0                          // 00000014E49C: CC21006B 02002534
	v_fma_mixhi_f16 v107, v53, s18, 0                          // 00000014E4A4: CC22006B 02002535
	s_waitcnt lgkmcnt(1)                                       // 00000014E4AC: BF89FC17
	v_fma_mixlo_f16 v108, v63, s18, 0                          // 00000014E4B0: CC21006C 0200253F
	v_fma_mixhi_f16 v108, v64, s18, 0                          // 00000014E4B8: CC22006C 02002540
	ds_load_b128 v[50:53], v78 offset:25696                    // 00000014E4C0: DBFC6460 3200004E
	v_fma_mixlo_f16 v109, v65, s18, 0                          // 00000014E4C8: CC21006D 02002541
	v_fma_mixhi_f16 v109, v66, s18, 0                          // 00000014E4D0: CC22006D 02002542
	ds_load_b128 v[63:66], v78 offset:25712                    // 00000014E4D8: DBFC6470 3F00004E
	v_fma_mixlo_f16 v96, v98, s18, 0                           // 00000014E4E0: CC210060 02002562
	v_fma_mixlo_f16 v98, v102, s18, 0                          // 00000014E4E8: CC210062 02002566
	v_fma_mixhi_f16 v98, v103, s18, 0                          // 00000014E4F0: CC220062 02002567
	v_fma_mixlo_f16 v102, v110, s18, 0                         // 00000014E4F8: CC210066 0200256E
	v_fma_mixhi_f16 v102, v111, s18, 0                         // 00000014E500: CC220066 0200256F
	v_fma_mixlo_f16 v103, v112, s18, 0                         // 00000014E508: CC210067 02002570
	v_fma_mixhi_f16 v103, v113, s18, 0                         // 00000014E510: CC220067 02002571
	v_fma_mixlo_f16 v110, v118, s18, 0                         // 00000014E518: CC21006E 02002576
	v_fma_mixhi_f16 v110, v119, s18, 0                         // 00000014E520: CC22006E 02002577
	v_fma_mixlo_f16 v111, v120, s18, 0                         // 00000014E528: CC21006F 02002578
	v_fma_mixhi_f16 v111, v121, s18, 0                         // 00000014E530: CC22006F 02002579
	v_fma_mixlo_f16 v112, v122, s18, 0                         // 00000014E538: CC210070 0200257A
	v_fma_mixhi_f16 v112, v123, s18, 0                         // 00000014E540: CC220070 0200257B
	v_fma_mixlo_f16 v113, v124, s18, 0                         // 00000014E548: CC210071 0200257C
	v_fma_mixhi_f16 v113, v125, s18, 0                         // 00000014E550: CC220071 0200257D
	s_waitcnt lgkmcnt(2)                                       // 00000014E558: BF89FC27
	v_fma_mixlo_f16 v114, v114, s18, 0                         // 00000014E55C: CC210072 02002572
	v_fma_mixhi_f16 v114, v115, s18, 0                         // 00000014E564: CC220072 02002573
	v_fma_mixlo_f16 v115, v116, s18, 0                         // 00000014E56C: CC210073 02002574
	v_fma_mixhi_f16 v115, v117, s18, 0                         // 00000014E574: CC220073 02002575
	v_fma_mixlo_f16 v116, v126, s18, 0                         // 00000014E57C: CC210074 0200257E
	v_fma_mixhi_f16 v116, v127, s18, 0                         // 00000014E584: CC220074 0200257F
	v_fma_mixlo_f16 v117, v128, s18, 0                         // 00000014E58C: CC210075 02002580
	v_fma_mixhi_f16 v117, v129, s18, 0                         // 00000014E594: CC220075 02002581
	s_waitcnt lgkmcnt(1)                                       // 00000014E59C: BF89FC17
	v_fma_mixlo_f16 v118, v50, s18, 0                          // 00000014E5A0: CC210076 02002532
	v_fma_mixhi_f16 v118, v51, s18, 0                          // 00000014E5A8: CC220076 02002533
	v_fma_mixlo_f16 v119, v52, s18, 0                          // 00000014E5B0: CC210077 02002534
	v_fma_mixhi_f16 v119, v53, s18, 0                          // 00000014E5B8: CC220077 02002535
	s_waitcnt lgkmcnt(0)                                       // 00000014E5C0: BF89FC07
	v_fma_mixlo_f16 v120, v63, s18, 0                          // 00000014E5C4: CC210078 0200253F
	v_fma_mixhi_f16 v120, v64, s18, 0                          // 00000014E5CC: CC220078 02002540
	v_fma_mixlo_f16 v121, v65, s18, 0                          // 00000014E5D4: CC210079 02002541
	v_fma_mixhi_f16 v121, v66, s18, 0                          // 00000014E5DC: CC220079 02002542
	.long 0x7f7e3880                                           // 00000014E5E4: 7F7E3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[55:62], v[90:97], v[42:49]// 00000014E5E8: CC40402A 1CAAB537
	v_wmma_f32_16x16x16_f16 v[34:41], v[55:62], v[98:105], v[34:41]// 00000014E5F0: CC404022 1C8AC537
	v_wmma_f32_16x16x16_f16 v[26:33], v[55:62], v[106:113], v[26:33]// 00000014E5F8: CC40401A 1C6AD537
	v_wmma_f32_16x16x16_f16 v[18:25], v[55:62], v[114:121], v[18:25]// 00000014E600: CC404012 1C4AE537
	.long 0x7f7a39bf                                           // 00000014E608: 7F7A39BF
	.long 0x7e7a39bf                                           // 00000014E60C: 7E7A39BF
	.long 0x7f7839bf                                           // 00000014E610: 7F7839BF
	.long 0x7e7839bf                                           // 00000014E614: 7E7839BF
	s_and_saveexec_b32 s1, s0                                  // 00000014E618: BE812000
	s_cbranch_execz 11                                         // 00000014E61C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d4c>
	global_load_b128 v[50:53], v[3:4], off offset:384          // 00000014E620: DC5E0180 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014E628: BF8903F7
	v_fma_mixlo_f16 v60, v50, s18, 0                           // 00000014E62C: CC21003C 02002532
	v_fma_mixhi_f16 v60, v51, s18, 0                           // 00000014E634: CC22003C 02002533
	v_fma_mixlo_f16 v61, v52, s18, 0                           // 00000014E63C: CC21003D 02002534
	v_fma_mixhi_f16 v61, v53, s18, 0                           // 00000014E644: CC22003D 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014E64C: 8C7E017E
	.long 0x7e7e39bf                                           // 00000014E650: 7E7E39BF
	.long 0x7f7c39bf                                           // 00000014E654: 7F7C39BF
	.long 0x7e7c39bf                                           // 00000014E658: 7E7C39BF
	s_and_saveexec_b32 s1, s0                                  // 00000014E65C: BE812000
	s_cbranch_execz 11                                         // 00000014E660: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d90>
	global_load_b128 v[50:53], v[3:4], off offset:400          // 00000014E664: DC5E0190 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014E66C: BF8903F7
	v_fma_mixlo_f16 v62, v50, s18, 0                           // 00000014E670: CC21003E 02002532
	v_fma_mixhi_f16 v62, v51, s18, 0                           // 00000014E678: CC22003E 02002533
	v_fma_mixlo_f16 v63, v52, s18, 0                           // 00000014E680: CC21003F 02002534
	v_fma_mixhi_f16 v63, v53, s18, 0                           // 00000014E688: CC22003F 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014E690: 8C7E017E
	.long 0x7f863880                                           // 00000014E694: 7F863880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014E698: BF870001
	.long 0x7f8239c3                                           // 00000014E69C: 7F8239C3
	.long 0x7e8239c3                                           // 00000014E6A0: 7E8239C3
	.long 0x7f8039c3                                           // 00000014E6A4: 7F8039C3
	.long 0x7e8039c3                                           // 00000014E6A8: 7E8039C3
	s_and_saveexec_b32 s1, s0                                  // 00000014E6AC: BE812000
	s_cbranch_execz 11                                         // 00000014E6B0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1de0>
	global_load_b128 v[50:53], v[3:4], off offset:416          // 00000014E6B4: DC5E01A0 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014E6BC: BF8903F7
	v_fma_mixlo_f16 v64, v50, s18, 0                           // 00000014E6C0: CC210040 02002532
	v_fma_mixhi_f16 v64, v51, s18, 0                           // 00000014E6C8: CC220040 02002533
	v_fma_mixlo_f16 v65, v52, s18, 0                           // 00000014E6D0: CC210041 02002534
	v_fma_mixhi_f16 v65, v53, s18, 0                           // 00000014E6D8: CC220041 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014E6E0: 8C7E017E
	.long 0x7e8639c3                                           // 00000014E6E4: 7E8639C3
	.long 0x7f8439c3                                           // 00000014E6E8: 7F8439C3
	.long 0x7e8439c3                                           // 00000014E6EC: 7E8439C3
	s_and_saveexec_b32 s1, s0                                  // 00000014E6F0: BE812000
	s_cbranch_execz 11                                         // 00000014E6F4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e24>
	global_load_b128 v[50:53], v[3:4], off offset:432          // 00000014E6F8: DC5E01B0 327C0003
	s_waitcnt vmcnt(0)                                         // 00000014E700: BF8903F7
	v_fma_mixlo_f16 v66, v50, s18, 0                           // 00000014E704: CC210042 02002532
	v_fma_mixhi_f16 v66, v51, s18, 0                           // 00000014E70C: CC220042 02002533
	v_fma_mixlo_f16 v67, v52, s18, 0                           // 00000014E714: CC210043 02002534
	v_fma_mixhi_f16 v67, v53, s18, 0                           // 00000014E71C: CC220043 02002535
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014E724: 8C7E017E
	ds_load_b128 v[50:53], v78 offset:384                      // 00000014E728: DBFC0180 3200004E
	ds_load_b128 v[54:57], v78 offset:400                      // 00000014E730: DBFC0190 3600004E
	ds_load_b128 v[94:97], v78 offset:416                      // 00000014E738: DBFC01A0 5E00004E
	ds_load_b128 v[98:101], v78 offset:432                     // 00000014E740: DBFC01B0 6200004E
	ds_load_b128 v[102:105], v78 offset:8832                   // 00000014E748: DBFC2280 6600004E
	ds_load_b128 v[106:109], v78 offset:8848                   // 00000014E750: DBFC2290 6A00004E
	ds_load_b128 v[110:113], v78 offset:8864                   // 00000014E758: DBFC22A0 6E00004E
	ds_load_b128 v[114:117], v78 offset:8880                   // 00000014E760: DBFC22B0 7200004E
	ds_load_b128 v[118:121], v78 offset:17312                  // 00000014E768: DBFC43A0 7600004E
	ds_load_b128 v[122:125], v78 offset:17328                  // 00000014E770: DBFC43B0 7A00004E
	ds_load_b128 v[126:129], v78 offset:25744                  // 00000014E778: DBFC6490 7E00004E
	s_waitcnt lgkmcnt(10)                                      // 00000014E780: BF89FCA7
	v_fma_mixlo_f16 v90, v50, s18, 0                           // 00000014E784: CC21005A 02002532
	v_fma_mixhi_f16 v90, v51, s18, 0                           // 00000014E78C: CC22005A 02002533
	v_fma_mixlo_f16 v91, v52, s18, 0                           // 00000014E794: CC21005B 02002534
	v_fma_mixhi_f16 v91, v53, s18, 0                           // 00000014E79C: CC22005B 02002535
	s_waitcnt lgkmcnt(9)                                       // 00000014E7A4: BF89FC97
	v_fma_mixlo_f16 v92, v54, s18, 0                           // 00000014E7A8: CC21005C 02002536
	v_fma_mixhi_f16 v92, v55, s18, 0                           // 00000014E7B0: CC22005C 02002537
	v_fma_mixlo_f16 v93, v56, s18, 0                           // 00000014E7B8: CC21005D 02002538
	v_fma_mixhi_f16 v93, v57, s18, 0                           // 00000014E7C0: CC22005D 02002539
	ds_load_b128 v[50:53], v78 offset:17280                    // 00000014E7C8: DBFC4380 3200004E
	ds_load_b128 v[54:57], v78 offset:17296                    // 00000014E7D0: DBFC4390 3600004E
	s_waitcnt lgkmcnt(10)                                      // 00000014E7D8: BF89FCA7
	v_fma_mixlo_f16 v94, v94, s18, 0                           // 00000014E7DC: CC21005E 0200255E
	v_fma_mixhi_f16 v94, v95, s18, 0                           // 00000014E7E4: CC22005E 0200255F
	v_fma_mixlo_f16 v95, v96, s18, 0                           // 00000014E7EC: CC21005F 02002560
	v_fma_mixhi_f16 v95, v97, s18, 0                           // 00000014E7F4: CC22005F 02002561
	s_waitcnt lgkmcnt(9)                                       // 00000014E7FC: BF89FC97
	v_fma_mixhi_f16 v96, v99, s18, 0                           // 00000014E800: CC220060 02002563
	v_fma_mixlo_f16 v97, v100, s18, 0                          // 00000014E808: CC210061 02002564
	v_fma_mixhi_f16 v97, v101, s18, 0                          // 00000014E810: CC220061 02002565
	s_waitcnt lgkmcnt(8)                                       // 00000014E818: BF89FC87
	v_fma_mixlo_f16 v99, v104, s18, 0                          // 00000014E81C: CC210063 02002568
	v_fma_mixhi_f16 v99, v105, s18, 0                          // 00000014E824: CC220063 02002569
	s_waitcnt lgkmcnt(7)                                       // 00000014E82C: BF89FC77
	v_fma_mixlo_f16 v100, v106, s18, 0                         // 00000014E830: CC210064 0200256A
	v_fma_mixhi_f16 v100, v107, s18, 0                         // 00000014E838: CC220064 0200256B
	v_fma_mixlo_f16 v101, v108, s18, 0                         // 00000014E840: CC210065 0200256C
	v_fma_mixhi_f16 v101, v109, s18, 0                         // 00000014E848: CC220065 0200256D
	s_waitcnt lgkmcnt(5)                                       // 00000014E850: BF89FC57
	v_fma_mixlo_f16 v104, v114, s18, 0                         // 00000014E854: CC210068 02002572
	v_fma_mixhi_f16 v104, v115, s18, 0                         // 00000014E85C: CC220068 02002573
	v_fma_mixlo_f16 v105, v116, s18, 0                         // 00000014E864: CC210069 02002574
	v_fma_mixhi_f16 v105, v117, s18, 0                         // 00000014E86C: CC220069 02002575
	ds_load_b128 v[114:117], v78 offset:25728                  // 00000014E874: DBFC6480 7200004E
	s_waitcnt lgkmcnt(2)                                       // 00000014E87C: BF89FC27
	v_fma_mixlo_f16 v106, v50, s18, 0                          // 00000014E880: CC21006A 02002532
	v_fma_mixhi_f16 v106, v51, s18, 0                          // 00000014E888: CC22006A 02002533
	v_fma_mixlo_f16 v107, v52, s18, 0                          // 00000014E890: CC21006B 02002534
	v_fma_mixhi_f16 v107, v53, s18, 0                          // 00000014E898: CC22006B 02002535
	s_waitcnt lgkmcnt(1)                                       // 00000014E8A0: BF89FC17
	v_fma_mixlo_f16 v108, v54, s18, 0                          // 00000014E8A4: CC21006C 02002536
	v_fma_mixhi_f16 v108, v55, s18, 0                          // 00000014E8AC: CC22006C 02002537
	ds_load_b128 v[50:53], v78 offset:25760                    // 00000014E8B4: DBFC64A0 3200004E
	v_fma_mixlo_f16 v109, v56, s18, 0                          // 00000014E8BC: CC21006D 02002538
	v_fma_mixhi_f16 v109, v57, s18, 0                          // 00000014E8C4: CC22006D 02002539
	ds_load_b128 v[54:57], v78 offset:25776                    // 00000014E8CC: DBFC64B0 3600004E
	v_fma_mixlo_f16 v96, v98, s18, 0                           // 00000014E8D4: CC210060 02002562
	v_fma_mixlo_f16 v98, v102, s18, 0                          // 00000014E8DC: CC210062 02002566
	v_fma_mixhi_f16 v98, v103, s18, 0                          // 00000014E8E4: CC220062 02002567
	v_fma_mixlo_f16 v102, v110, s18, 0                         // 00000014E8EC: CC210066 0200256E
	v_fma_mixhi_f16 v102, v111, s18, 0                         // 00000014E8F4: CC220066 0200256F
	v_fma_mixlo_f16 v103, v112, s18, 0                         // 00000014E8FC: CC210067 02002570
	v_fma_mixhi_f16 v103, v113, s18, 0                         // 00000014E904: CC220067 02002571
	v_fma_mixlo_f16 v110, v118, s18, 0                         // 00000014E90C: CC21006E 02002576
	v_fma_mixhi_f16 v110, v119, s18, 0                         // 00000014E914: CC22006E 02002577
	v_fma_mixlo_f16 v111, v120, s18, 0                         // 00000014E91C: CC21006F 02002578
	v_fma_mixhi_f16 v111, v121, s18, 0                         // 00000014E924: CC22006F 02002579
	v_fma_mixlo_f16 v112, v122, s18, 0                         // 00000014E92C: CC210070 0200257A
	v_fma_mixhi_f16 v112, v123, s18, 0                         // 00000014E934: CC220070 0200257B
	v_fma_mixlo_f16 v113, v124, s18, 0                         // 00000014E93C: CC210071 0200257C
	v_fma_mixhi_f16 v113, v125, s18, 0                         // 00000014E944: CC220071 0200257D
	s_waitcnt lgkmcnt(2)                                       // 00000014E94C: BF89FC27
	v_fma_mixlo_f16 v114, v114, s18, 0                         // 00000014E950: CC210072 02002572
	v_fma_mixhi_f16 v114, v115, s18, 0                         // 00000014E958: CC220072 02002573
	v_fma_mixlo_f16 v115, v116, s18, 0                         // 00000014E960: CC210073 02002574
	v_fma_mixhi_f16 v115, v117, s18, 0                         // 00000014E968: CC220073 02002575
	v_fma_mixlo_f16 v116, v126, s18, 0                         // 00000014E970: CC210074 0200257E
	v_fma_mixhi_f16 v116, v127, s18, 0                         // 00000014E978: CC220074 0200257F
	v_fma_mixlo_f16 v117, v128, s18, 0                         // 00000014E980: CC210075 02002580
	v_fma_mixhi_f16 v117, v129, s18, 0                         // 00000014E988: CC220075 02002581
	s_waitcnt lgkmcnt(1)                                       // 00000014E990: BF89FC17
	v_fma_mixlo_f16 v118, v50, s18, 0                          // 00000014E994: CC210076 02002532
	v_fma_mixhi_f16 v118, v51, s18, 0                          // 00000014E99C: CC220076 02002533
	v_fma_mixlo_f16 v119, v52, s18, 0                          // 00000014E9A4: CC210077 02002534
	v_fma_mixhi_f16 v119, v53, s18, 0                          // 00000014E9AC: CC220077 02002535
	s_waitcnt lgkmcnt(0)                                       // 00000014E9B4: BF89FC07
	v_fma_mixlo_f16 v120, v54, s18, 0                          // 00000014E9B8: CC210078 02002536
	v_fma_mixhi_f16 v120, v55, s18, 0                          // 00000014E9C0: CC220078 02002537
	v_fma_mixlo_f16 v121, v56, s18, 0                          // 00000014E9C8: CC210079 02002538
	v_fma_mixhi_f16 v121, v57, s18, 0                          // 00000014E9D0: CC220079 02002539
	.long 0x7f6a3880                                           // 00000014E9D8: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[60:67], v[90:97], v[42:49]// 00000014E9DC: CC40402A 1CAAB53C
	v_wmma_f32_16x16x16_f16 v[34:41], v[60:67], v[98:105], v[34:41]// 00000014E9E4: CC404022 1C8AC53C
	v_wmma_f32_16x16x16_f16 v[26:33], v[60:67], v[106:113], v[26:33]// 00000014E9EC: CC40401A 1C6AD53C
	v_wmma_f32_16x16x16_f16 v[18:25], v[60:67], v[114:121], v[18:25]// 00000014E9F4: CC404012 1C4AE53C
	.long 0x7f6639b5                                           // 00000014E9FC: 7F6639B5
	.long 0x7e6639b5                                           // 00000014EA00: 7E6639B5
	.long 0x7f6439b5                                           // 00000014EA04: 7F6439B5
	.long 0x7e6439b5                                           // 00000014EA08: 7E6439B5
	s_and_saveexec_b32 s1, s0                                  // 00000014EA0C: BE812000
	s_cbranch_execz 11                                         // 00000014EA10: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2140>
	global_load_b128 v[54:57], v[3:4], off offset:448          // 00000014EA14: DC5E01C0 367C0003
	s_waitcnt vmcnt(0)                                         // 00000014EA1C: BF8903F7
	v_fma_mixlo_f16 v50, v54, s18, 0                           // 00000014EA20: CC210032 02002536
	v_fma_mixhi_f16 v50, v55, s18, 0                           // 00000014EA28: CC220032 02002537
	v_fma_mixlo_f16 v51, v56, s18, 0                           // 00000014EA30: CC210033 02002538
	v_fma_mixhi_f16 v51, v57, s18, 0                           // 00000014EA38: CC220033 02002539
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014EA40: 8C7E017E
	.long 0x7e6a39b5                                           // 00000014EA44: 7E6A39B5
	.long 0x7f6839b5                                           // 00000014EA48: 7F6839B5
	.long 0x7e6839b5                                           // 00000014EA4C: 7E6839B5
	s_and_saveexec_b32 s1, s0                                  // 00000014EA50: BE812000
	s_cbranch_execz 11                                         // 00000014EA54: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2184>
	global_load_b128 v[52:55], v[3:4], off offset:464          // 00000014EA58: DC5E01D0 347C0003
	s_waitcnt vmcnt(0)                                         // 00000014EA60: BF8903F7
	v_fma_mixlo_f16 v52, v52, s18, 0                           // 00000014EA64: CC210034 02002534
	v_fma_mixhi_f16 v52, v53, s18, 0                           // 00000014EA6C: CC220034 02002535
	v_fma_mixlo_f16 v53, v54, s18, 0                           // 00000014EA74: CC210035 02002536
	v_fma_mixhi_f16 v53, v55, s18, 0                           // 00000014EA7C: CC220035 02002537
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014EA84: 8C7E017E
	.long 0x7f723880                                           // 00000014EA88: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014EA8C: BF870001
	.long 0x7f6e39b9                                           // 00000014EA90: 7F6E39B9
	.long 0x7e6e39b9                                           // 00000014EA94: 7E6E39B9
	.long 0x7f6c39b9                                           // 00000014EA98: 7F6C39B9
	.long 0x7e6c39b9                                           // 00000014EA9C: 7E6C39B9
	s_and_saveexec_b32 s1, s0                                  // 00000014EAA0: BE812000
	s_cbranch_execz 11                                         // 00000014EAA4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x21d4>
	global_load_b128 v[58:61], v[3:4], off offset:480          // 00000014EAA8: DC5E01E0 3A7C0003
	s_waitcnt vmcnt(0)                                         // 00000014EAB0: BF8903F7
	v_fma_mixlo_f16 v54, v58, s18, 0                           // 00000014EAB4: CC210036 0200253A
	v_fma_mixhi_f16 v54, v59, s18, 0                           // 00000014EABC: CC220036 0200253B
	v_fma_mixlo_f16 v55, v60, s18, 0                           // 00000014EAC4: CC210037 0200253C
	v_fma_mixhi_f16 v55, v61, s18, 0                           // 00000014EACC: CC220037 0200253D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014EAD4: 8C7E017E
	.long 0x7e7239b9                                           // 00000014EAD8: 7E7239B9
	.long 0x7f7039b9                                           // 00000014EADC: 7F7039B9
	.long 0x7e7039b9                                           // 00000014EAE0: 7E7039B9
	s_and_saveexec_b32 s1, s0                                  // 00000014EAE4: BE812000
	s_cbranch_execz 11                                         // 00000014EAE8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2218>
	global_load_b128 v[56:59], v[3:4], off offset:496          // 00000014EAEC: DC5E01F0 387C0003
	s_waitcnt vmcnt(0)                                         // 00000014EAF4: BF8903F7
	v_fma_mixlo_f16 v56, v56, s18, 0                           // 00000014EAF8: CC210038 02002538
	v_fma_mixhi_f16 v56, v57, s18, 0                           // 00000014EB00: CC220038 02002539
	v_fma_mixlo_f16 v57, v58, s18, 0                           // 00000014EB08: CC210039 0200253A
	v_fma_mixhi_f16 v57, v59, s18, 0                           // 00000014EB10: CC220039 0200253B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014EB18: 8C7E017E
	ds_load_b128 v[58:61], v78 offset:448                      // 00000014EB1C: DBFC01C0 3A00004E
	ds_load_b128 v[62:65], v78 offset:464                      // 00000014EB24: DBFC01D0 3E00004E
	ds_load_b128 v[90:93], v78 offset:480                      // 00000014EB2C: DBFC01E0 5A00004E
	ds_load_b128 v[94:97], v78 offset:496                      // 00000014EB34: DBFC01F0 5E00004E
	ds_load_b128 v[98:101], v78 offset:8896                    // 00000014EB3C: DBFC22C0 6200004E
	ds_load_b128 v[102:105], v78 offset:8912                   // 00000014EB44: DBFC22D0 6600004E
	ds_load_b128 v[106:109], v78 offset:8928                   // 00000014EB4C: DBFC22E0 6A00004E
	ds_load_b128 v[110:113], v78 offset:8944                   // 00000014EB54: DBFC22F0 6E00004E
	ds_load_b128 v[118:121], v78 offset:25840                  // 00000014EB5C: DBFC64F0 7600004E
	v_add_nc_u32_e32 v7, s22, v81                              // 00000014EB64: 4A0EA216
	.long 0x7e063880                                           // 00000014EB68: 7E063880
	ds_load_b128 v[114:117], v78 offset:25824                  // 00000014EB6C: DBFC64E0 7200004E
	.long 0xd4440001                                           // 00000014EB74: D4440001
	v_cndmask_b32_e32 v1, s35, v7, vcc_lo                      // 00000014EB78: 02020E23
	.long 0x7f063903                                           // 00000014EB7C: 7F063903
	s_waitcnt lgkmcnt(9)                                       // 00000014EB80: BF89FC97
	v_fma_mixlo_f16 v58, v58, s18, 0                           // 00000014EB84: CC21003A 0200253A
	v_fma_mixhi_f16 v58, v59, s18, 0                           // 00000014EB8C: CC22003A 0200253B
	v_fma_mixlo_f16 v59, v60, s18, 0                           // 00000014EB94: CC21003B 0200253C
	v_fma_mixhi_f16 v59, v61, s18, 0                           // 00000014EB9C: CC22003B 0200253D
	s_waitcnt lgkmcnt(8)                                       // 00000014EBA4: BF89FC87
	v_fma_mixlo_f16 v60, v62, s18, 0                           // 00000014EBA8: CC21003C 0200253E
	v_fma_mixhi_f16 v60, v63, s18, 0                           // 00000014EBB0: CC22003C 0200253F
	v_fma_mixlo_f16 v61, v64, s18, 0                           // 00000014EBB8: CC21003D 02002540
	v_fma_mixhi_f16 v61, v65, s18, 0                           // 00000014EBC0: CC22003D 02002541
	s_waitcnt lgkmcnt(7)                                       // 00000014EBC8: BF89FC77
	v_fma_mixlo_f16 v62, v90, s18, 0                           // 00000014EBCC: CC21003E 0200255A
	v_fma_mixhi_f16 v62, v91, s18, 0                           // 00000014EBD4: CC22003E 0200255B
	v_fma_mixlo_f16 v63, v92, s18, 0                           // 00000014EBDC: CC21003F 0200255C
	v_fma_mixhi_f16 v63, v93, s18, 0                           // 00000014EBE4: CC22003F 0200255D
	s_waitcnt lgkmcnt(6)                                       // 00000014EBEC: BF89FC67
	v_fma_mixlo_f16 v64, v94, s18, 0                           // 00000014EBF0: CC210040 0200255E
	v_fma_mixhi_f16 v64, v95, s18, 0                           // 00000014EBF8: CC220040 0200255F
	v_fma_mixlo_f16 v65, v96, s18, 0                           // 00000014EC00: CC210041 02002560
	v_fma_mixhi_f16 v65, v97, s18, 0                           // 00000014EC08: CC220041 02002561
	s_waitcnt lgkmcnt(5)                                       // 00000014EC10: BF89FC57
	v_fma_mixlo_f16 v90, v98, s18, 0                           // 00000014EC14: CC21005A 02002562
	v_fma_mixhi_f16 v90, v99, s18, 0                           // 00000014EC1C: CC22005A 02002563
	v_fma_mixlo_f16 v91, v100, s18, 0                          // 00000014EC24: CC21005B 02002564
	v_fma_mixhi_f16 v91, v101, s18, 0                          // 00000014EC2C: CC22005B 02002565
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[58:65], v[42:49]// 00000014EC34: CC40402A 1CAA7532
	ds_load_b128 v[58:61], v78 offset:17344                    // 00000014EC3C: DBFC43C0 3A00004E
	s_waitcnt lgkmcnt(5)                                       // 00000014EC44: BF89FC57
	v_fma_mixlo_f16 v92, v102, s18, 0                          // 00000014EC48: CC21005C 02002566
	ds_load_b128 v[62:65], v78 offset:17360                    // 00000014EC50: DBFC43D0 3E00004E
	ds_load_b128 v[98:101], v78 offset:17376                   // 00000014EC58: DBFC43E0 6200004E
	v_fma_mixhi_f16 v92, v103, s18, 0                          // 00000014EC60: CC22005C 02002567
	v_fma_mixlo_f16 v93, v104, s18, 0                          // 00000014EC68: CC21005D 02002568
	v_fma_mixhi_f16 v93, v105, s18, 0                          // 00000014EC70: CC22005D 02002569
	s_waitcnt lgkmcnt(6)                                       // 00000014EC78: BF89FC67
	v_fma_mixlo_f16 v94, v106, s18, 0                          // 00000014EC7C: CC21005E 0200256A
	v_fma_mixhi_f16 v94, v107, s18, 0                          // 00000014EC84: CC22005E 0200256B
	v_fma_mixlo_f16 v95, v108, s18, 0                          // 00000014EC8C: CC21005F 0200256C
	v_fma_mixhi_f16 v95, v109, s18, 0                          // 00000014EC94: CC22005F 0200256D
	s_waitcnt lgkmcnt(5)                                       // 00000014EC9C: BF89FC57
	v_fma_mixlo_f16 v96, v110, s18, 0                          // 00000014ECA0: CC210060 0200256E
	ds_load_b128 v[102:105], v78 offset:17392                  // 00000014ECA8: DBFC43F0 6600004E
	ds_load_b128 v[106:109], v78 offset:25792                  // 00000014ECB0: DBFC64C0 6A00004E
	v_fma_mixhi_f16 v96, v111, s18, 0                          // 00000014ECB8: CC220060 0200256F
	v_fma_mixlo_f16 v97, v112, s18, 0                          // 00000014ECC0: CC210061 02002570
	v_fma_mixhi_f16 v97, v113, s18, 0                          // 00000014ECC8: CC220061 02002571
	ds_load_b128 v[110:113], v78 offset:25808                  // 00000014ECD0: DBFC64D0 6E00004E
	s_waitcnt lgkmcnt(5)                                       // 00000014ECD8: BF89FC57
	v_fma_mixlo_f16 v58, v58, s18, 0                           // 00000014ECDC: CC21003A 0200253A
	v_fma_mixhi_f16 v58, v59, s18, 0                           // 00000014ECE4: CC22003A 0200253B
	v_fma_mixlo_f16 v59, v60, s18, 0                           // 00000014ECEC: CC21003B 0200253C
	v_fma_mixhi_f16 v59, v61, s18, 0                           // 00000014ECF4: CC22003B 0200253D
	s_waitcnt lgkmcnt(4)                                       // 00000014ECFC: BF89FC47
	v_fma_mixlo_f16 v60, v62, s18, 0                           // 00000014ED00: CC21003C 0200253E
	v_fma_mixhi_f16 v60, v63, s18, 0                           // 00000014ED08: CC22003C 0200253F
	v_fma_mixlo_f16 v61, v64, s18, 0                           // 00000014ED10: CC21003D 02002540
	v_fma_mixhi_f16 v61, v65, s18, 0                           // 00000014ED18: CC22003D 02002541
	s_waitcnt lgkmcnt(3)                                       // 00000014ED20: BF89FC37
	v_fma_mixlo_f16 v62, v98, s18, 0                           // 00000014ED24: CC21003E 02002562
	v_fma_mixhi_f16 v62, v99, s18, 0                           // 00000014ED2C: CC22003E 02002563
	v_fma_mixlo_f16 v63, v100, s18, 0                          // 00000014ED34: CC21003F 02002564
	v_fma_mixhi_f16 v63, v101, s18, 0                          // 00000014ED3C: CC22003F 02002565
	s_waitcnt lgkmcnt(2)                                       // 00000014ED44: BF89FC27
	v_fma_mixlo_f16 v64, v102, s18, 0                          // 00000014ED48: CC210040 02002566
	v_fma_mixhi_f16 v64, v103, s18, 0                          // 00000014ED50: CC220040 02002567
	v_fma_mixlo_f16 v65, v104, s18, 0                          // 00000014ED58: CC210041 02002568
	v_fma_mixhi_f16 v65, v105, s18, 0                          // 00000014ED60: CC220041 02002569
	s_waitcnt lgkmcnt(1)                                       // 00000014ED68: BF89FC17
	v_fma_mixlo_f16 v98, v106, s18, 0                          // 00000014ED6C: CC210062 0200256A
	v_fma_mixhi_f16 v98, v107, s18, 0                          // 00000014ED74: CC220062 0200256B
	v_fma_mixlo_f16 v99, v108, s18, 0                          // 00000014ED7C: CC210063 0200256C
	v_fma_mixhi_f16 v99, v109, s18, 0                          // 00000014ED84: CC220063 0200256D
	s_waitcnt lgkmcnt(0)                                       // 00000014ED8C: BF89FC07
	v_fma_mixlo_f16 v100, v110, s18, 0                         // 00000014ED90: CC210064 0200256E
	v_fma_mixhi_f16 v100, v111, s18, 0                         // 00000014ED98: CC220064 0200256F
	v_fma_mixlo_f16 v101, v112, s18, 0                         // 00000014EDA0: CC210065 02002570
	v_fma_mixhi_f16 v101, v113, s18, 0                         // 00000014EDA8: CC220065 02002571
	v_fma_mixlo_f16 v102, v114, s18, 0                         // 00000014EDB0: CC210066 02002572
	v_fma_mixhi_f16 v102, v115, s18, 0                         // 00000014EDB8: CC220066 02002573
	v_fma_mixlo_f16 v103, v116, s18, 0                         // 00000014EDC0: CC210067 02002574
	v_fma_mixhi_f16 v103, v117, s18, 0                         // 00000014EDC8: CC220067 02002575
	v_fma_mixlo_f16 v104, v118, s18, 0                         // 00000014EDD0: CC210068 02002576
	v_fma_mixhi_f16 v104, v119, s18, 0                         // 00000014EDD8: CC220068 02002577
	v_fma_mixlo_f16 v105, v120, s18, 0                         // 00000014EDE0: CC210069 02002578
	v_fma_mixhi_f16 v105, v121, s18, 0                         // 00000014EDE8: CC220069 02002579
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[90:97], v[34:41]// 00000014EDF0: CC404022 1C8AB532
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[58:65], v[26:33]// 00000014EDF8: CC40401A 1C6A7532
	s_delay_alu instid0(VALU_DEP_3)                            // 00000014EE00: BF870003
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[98:105], v[18:25]// 00000014EE04: CC404012 1C4AC532
	s_and_saveexec_b32 s5, s1                                  // 00000014EE0C: BE852001
	s_cbranch_execz 17                                         // 00000014EE10: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2558>
	v_mad_u64_u32 v[8:9], null, v7, 48, s[2:3]                 // 00000014EE14: D6FE7C08 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EE1C: BF870091
	.long 0xd73c0008                                           // 00000014EE20: D73C0008
	v_cndmask_b32_e32 v1, 9, v8, vcc_lo                        // 00000014EE24: 02021089
	.long 0xd7000408                                           // 00000014EE28: D7000408
	v_cndmask_b32_e32 v1, v84, v8, vcc_lo                      // 00000014EE2C: 02021154
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014EE30: BF8700C1
	v_add_co_ci_u32_e64 v9, null, v85, v9, s4                  // 00000014EE34: D5207C09 00121355
	global_load_b32 v4, v[8:9], off                            // 00000014EE3C: DC520000 047C0008
	s_waitcnt vmcnt(0)                                         // 00000014EE44: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v42                         // 00000014EE48: 560854FF BB800000
	v_fma_mixhi_f16 v3, v4, s18, 0                             // 00000014EE50: CC220003 02002504
	s_or_b32 exec_lo, exec_lo, s5                              // 00000014EE58: 8C7E057E
	v_add_nc_u32_e32 v8, 2, v7                                 // 00000014EE5C: 4A100E82
	ds_store_b16_d16_hi v86, v3                                // 00000014EE60: DA840000 00000356
	.long 0xd4440004                                           // 00000014EE68: D4440004
	v_cndmask_b32_e32 v1, s35, v8, vcc_lo                      // 00000014EE6C: 02021023
	s_and_saveexec_b32 s6, s4                                  // 00000014EE70: BE862004
	s_cbranch_execz 17                                         // 00000014EE74: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25bc>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 00000014EE78: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EE80: BF870091
	.long 0xd73c0003                                           // 00000014EE84: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014EE88: 02020689
	.long 0xd7000503                                           // 00000014EE8C: D7000503
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014EE90: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014EE94: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s5                  // 00000014EE98: D5207C04 00160955
	global_load_b32 v3, v[3:4], off                            // 00000014EEA0: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014EEA8: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v43                         // 00000014EEAC: 560656FF BB800000
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 00000014EEB4: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s6                              // 00000014EEBC: 8C7E067E
	v_add_nc_u32_e32 v9, 4, v7                                 // 00000014EEC0: 4A120E84
	.long 0x7f063880                                           // 00000014EEC4: 7F063880
	ds_store_b16 v86, v3 offset:4                              // 00000014EEC8: D87C0004 00000356
	.long 0xd4440005                                           // 00000014EED0: D4440005
	v_cndmask_b32_e32 v1, s35, v9, vcc_lo                      // 00000014EED4: 02021223
	.long 0x7e083983                                           // 00000014EED8: 7E083983
	s_and_saveexec_b32 s7, s5                                  // 00000014EEDC: BE872005
	s_cbranch_execz 17                                         // 00000014EEE0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2628>
	v_mad_u64_u32 v[42:43], null, v9, 48, s[2:3]               // 00000014EEE4: D6FE7C2A 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EEEC: BF870091
	.long 0xd73c002a                                           // 00000014EEF0: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000014EEF4: 02025489
	.long 0xd700062a                                           // 00000014EEF8: D700062A
	v_cndmask_b32_e32 v1, v84, v42, vcc_lo                     // 00000014EEFC: 02025554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014EF00: BF8700C1
	v_add_co_ci_u32_e64 v43, null, v85, v43, s6                // 00000014EF04: D5207C2B 001A5755
	global_load_b32 v4, v[42:43], off                          // 00000014EF0C: DC520000 047C002A
	s_waitcnt vmcnt(0)                                         // 00000014EF14: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v44                         // 00000014EF18: 560858FF BB800000
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 00000014EF20: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014EF28: 8C7E077E
	v_add_nc_u32_e32 v90, 6, v7                                // 00000014EF2C: 4AB40E86
	ds_store_b16 v86, v4 offset:8                              // 00000014EF30: D87C0008 00000456
	.long 0xd4440006                                           // 00000014EF38: D4440006
	v_cndmask_b32_e32 v1, s35, v90, vcc_lo                     // 00000014EF3C: 0202B423
	s_and_saveexec_b32 s8, s6                                  // 00000014EF40: BE882006
	s_cbranch_execz 17                                         // 00000014EF44: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x268c>
	v_mad_u64_u32 v[3:4], null, v90, 48, s[2:3]                // 00000014EF48: D6FE7C03 0009615A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EF50: BF870091
	.long 0xd73c0003                                           // 00000014EF54: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014EF58: 02020689
	.long 0xd7000703                                           // 00000014EF5C: D7000703
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014EF60: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014EF64: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s7                  // 00000014EF68: D5207C04 001E0955
	global_load_b32 v3, v[3:4], off                            // 00000014EF70: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014EF78: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v45                         // 00000014EF7C: 56065AFF BB800000
	v_fma_mixhi_f16 v3, v3, s18, 0                             // 00000014EF84: CC220003 02002503
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014EF8C: 8C7E087E
	v_add_nc_u32_e32 v91, 8, v7                                // 00000014EF90: 4AB60E88
	.long 0x7e083880                                           // 00000014EF94: 7E083880
	ds_store_b16_d16_hi v86, v3 offset:12                      // 00000014EF98: DA84000C 00000356
	.long 0xd4440007                                           // 00000014EFA0: D4440007
	v_cndmask_b32_e32 v1, s35, v91, vcc_lo                     // 00000014EFA4: 0202B623
	.long 0x7e063904                                           // 00000014EFA8: 7E063904
	s_and_saveexec_b32 s9, s7                                  // 00000014EFAC: BE892007
	s_cbranch_execz 17                                         // 00000014EFB0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26f8>
	v_mad_u64_u32 v[42:43], null, v91, 48, s[2:3]              // 00000014EFB4: D6FE7C2A 0009615B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EFBC: BF870091
	.long 0xd73c002a                                           // 00000014EFC0: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000014EFC4: 02025489
	.long 0xd700082a                                           // 00000014EFC8: D700082A
	v_cndmask_b32_e32 v1, v84, v42, vcc_lo                     // 00000014EFCC: 02025554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014EFD0: BF8700C1
	v_add_co_ci_u32_e64 v43, null, v85, v43, s8                // 00000014EFD4: D5207C2B 00225755
	global_load_b32 v3, v[42:43], off                          // 00000014EFDC: DC520000 037C002A
	s_waitcnt vmcnt(0)                                         // 00000014EFE4: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v46                         // 00000014EFE8: 56065CFF BB800000
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 00000014EFF0: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s9                              // 00000014EFF8: 8C7E097E
	v_add_nc_u32_e32 v92, 10, v7                               // 00000014EFFC: 4AB80E8A
	ds_store_b16 v86, v3 offset:16                             // 00000014F000: D87C0010 00000356
	.long 0xd4440008                                           // 00000014F008: D4440008
	v_cndmask_b32_e32 v1, s35, v92, vcc_lo                     // 00000014F00C: 0202B823
	s_and_saveexec_b32 s10, s8                                 // 00000014F010: BE8A2008
	s_cbranch_execz 17                                         // 00000014F014: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x275c>
	v_mad_u64_u32 v[3:4], null, v92, 48, s[2:3]                // 00000014F018: D6FE7C03 0009615C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F020: BF870091
	.long 0xd73c0003                                           // 00000014F024: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014F028: 02020689
	.long 0xd7000903                                           // 00000014F02C: D7000903
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014F030: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F034: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s9                  // 00000014F038: D5207C04 00260955
	global_load_b32 v3, v[3:4], off                            // 00000014F040: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014F048: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v47                         // 00000014F04C: 56065EFF BB800000
	v_fma_mixlo_f16 v4, v3, s18, 0                             // 00000014F054: CC210004 02002503
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014F05C: 8C7E0A7E
	v_add_nc_u32_e32 v93, 12, v7                               // 00000014F060: 4ABA0E8C
	.long 0x7e063880                                           // 00000014F064: 7E063880
	ds_store_b16 v86, v4 offset:20                             // 00000014F068: D87C0014 00000456
	.long 0xd4440009                                           // 00000014F070: D4440009
	v_cndmask_b32_e32 v1, s35, v93, vcc_lo                     // 00000014F074: 0202BA23
	.long 0x7f063903                                           // 00000014F078: 7F063903
	s_and_saveexec_b32 s11, s9                                 // 00000014F07C: BE8B2009
	s_cbranch_execz 17                                         // 00000014F080: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27c8>
	v_mad_u64_u32 v[42:43], null, v93, 48, s[2:3]              // 00000014F084: D6FE7C2A 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F08C: BF870091
	.long 0xd73c002a                                           // 00000014F090: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000014F094: 02025489
	.long 0xd7000a2a                                           // 00000014F098: D7000A2A
	v_cndmask_b32_e32 v1, v84, v42, vcc_lo                     // 00000014F09C: 02025554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F0A0: BF8700C1
	v_add_co_ci_u32_e64 v43, null, v85, v43, s10               // 00000014F0A4: D5207C2B 002A5755
	global_load_b32 v4, v[42:43], off                          // 00000014F0AC: DC520000 047C002A
	s_waitcnt vmcnt(0)                                         // 00000014F0B4: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v48                         // 00000014F0B8: 560860FF BB800000
	v_fma_mixhi_f16 v3, v4, s18, 0                             // 00000014F0C0: CC220003 02002504
	s_or_b32 exec_lo, exec_lo, s11                             // 00000014F0C8: 8C7E0B7E
	v_add_nc_u32_e32 v94, 14, v7                               // 00000014F0CC: 4ABC0E8E
	ds_store_b16_d16_hi v86, v3 offset:24                      // 00000014F0D0: DA840018 00000356
	.long 0xd444000a                                           // 00000014F0D8: D444000A
	v_cndmask_b32_e32 v1, s35, v94, vcc_lo                     // 00000014F0DC: 0202BC23
	s_and_saveexec_b32 s26, s10                                // 00000014F0E0: BE9A200A
	s_cbranch_execz 17                                         // 00000014F0E4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x282c>
	v_mad_u64_u32 v[3:4], null, v94, 48, s[2:3]                // 00000014F0E8: D6FE7C03 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F0F0: BF870091
	.long 0xd73c0003                                           // 00000014F0F4: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014F0F8: 02020689
	.long 0xd7000b03                                           // 00000014F0FC: D7000B03
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014F100: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F104: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s11                 // 00000014F108: D5207C04 002E0955
	global_load_b32 v3, v[3:4], off                            // 00000014F110: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014F118: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v49                         // 00000014F11C: 560662FF BB800000
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 00000014F124: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F12C: 8C7E1A7E
	.long 0x7f063880                                           // 00000014F130: 7F063880
	ds_store_b16 v86, v3 offset:28                             // 00000014F134: D87C001C 00000356
	.long 0x7e083983                                           // 00000014F13C: 7E083983
	s_and_saveexec_b32 s26, s1                                 // 00000014F140: BE9A2001
	s_cbranch_execz 17                                         // 00000014F144: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x288c>
	v_mad_u64_u32 v[42:43], null, v7, 48, s[2:3]               // 00000014F148: D6FE7C2A 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F150: BF870091
	.long 0xd73c002a                                           // 00000014F154: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000014F158: 02025489
	.long 0xd7000b2a                                           // 00000014F15C: D7000B2A
	v_cndmask_b32_e32 v1, v84, v42, vcc_lo                     // 00000014F160: 02025554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F164: BF8700C1
	v_add_co_ci_u32_e64 v43, null, v85, v43, s11               // 00000014F168: D5207C2B 002E5755
	global_load_b32 v4, v[42:43], off offset:64                // 00000014F170: DC520040 047C002A
	s_waitcnt vmcnt(0)                                         // 00000014F178: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v34                         // 00000014F17C: 560844FF BB800000
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 00000014F184: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F18C: 8C7E1A7E
	ds_store_b16 v86, v4 offset:2560                           // 00000014F190: D87C0A00 00000456
	s_and_saveexec_b32 s26, s4                                 // 00000014F198: BE9A2004
	s_cbranch_execz 17                                         // 00000014F19C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x28e4>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 00000014F1A0: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F1A8: BF870091
	.long 0xd73c0003                                           // 00000014F1AC: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014F1B0: 02020689
	.long 0xd7000b03                                           // 00000014F1B4: D7000B03
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014F1B8: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F1BC: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s11                 // 00000014F1C0: D5207C04 002E0955
	global_load_b32 v3, v[3:4], off offset:64                  // 00000014F1C8: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014F1D0: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v35                         // 00000014F1D4: 560646FF BB800000
	v_fma_mixhi_f16 v3, v3, s18, 0                             // 00000014F1DC: CC220003 02002503
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F1E4: 8C7E1A7E
	.long 0x7e063880                                           // 00000014F1E8: 7E063880
	ds_store_b16_d16_hi v86, v3 offset:2564                    // 00000014F1EC: DA840A04 00000356
	.long 0x7e083903                                           // 00000014F1F4: 7E083903
	s_and_saveexec_b32 s26, s5                                 // 00000014F1F8: BE9A2005
	s_cbranch_execz 17                                         // 00000014F1FC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2944>
	v_mad_u64_u32 v[34:35], null, v9, 48, s[2:3]               // 00000014F200: D6FE7C22 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F208: BF870091
	.long 0xd73c0022                                           // 00000014F20C: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000014F210: 02024489
	.long 0xd7000b22                                           // 00000014F214: D7000B22
	v_cndmask_b32_e32 v1, v84, v34, vcc_lo                     // 00000014F218: 02024554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F21C: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v85, v35, s11               // 00000014F220: D5207C23 002E4755
	global_load_b32 v4, v[34:35], off offset:64                // 00000014F228: DC520040 047C0022
	s_waitcnt vmcnt(0)                                         // 00000014F230: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v36                         // 00000014F234: 560848FF BB800000
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 00000014F23C: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F244: 8C7E1A7E
	ds_store_b16 v86, v4 offset:2568                           // 00000014F248: D87C0A08 00000456
	s_and_saveexec_b32 s26, s6                                 // 00000014F250: BE9A2006
	s_cbranch_execz 17                                         // 00000014F254: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x299c>
	v_mad_u64_u32 v[3:4], null, v90, 48, s[2:3]                // 00000014F258: D6FE7C03 0009615A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F260: BF870091
	.long 0xd73c0003                                           // 00000014F264: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014F268: 02020689
	.long 0xd7000b03                                           // 00000014F26C: D7000B03
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014F270: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F274: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s11                 // 00000014F278: D5207C04 002E0955
	global_load_b32 v3, v[3:4], off offset:64                  // 00000014F280: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014F288: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v37                         // 00000014F28C: 56064AFF BB800000
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 00000014F294: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F29C: 8C7E1A7E
	.long 0x7f063880                                           // 00000014F2A0: 7F063880
	ds_store_b16 v86, v3 offset:2572                           // 00000014F2A4: D87C0A0C 00000356
	.long 0x7e083983                                           // 00000014F2AC: 7E083983
	s_and_saveexec_b32 s26, s7                                 // 00000014F2B0: BE9A2007
	s_cbranch_execz 17                                         // 00000014F2B4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29fc>
	v_mad_u64_u32 v[34:35], null, v91, 48, s[2:3]              // 00000014F2B8: D6FE7C22 0009615B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F2C0: BF870091
	.long 0xd73c0022                                           // 00000014F2C4: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000014F2C8: 02024489
	.long 0xd7000b22                                           // 00000014F2CC: D7000B22
	v_cndmask_b32_e32 v1, v84, v34, vcc_lo                     // 00000014F2D0: 02024554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F2D4: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v85, v35, s11               // 00000014F2D8: D5207C23 002E4755
	global_load_b32 v4, v[34:35], off offset:64                // 00000014F2E0: DC520040 047C0022
	s_waitcnt vmcnt(0)                                         // 00000014F2E8: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v38                         // 00000014F2EC: 56084CFF BB800000
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 00000014F2F4: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F2FC: 8C7E1A7E
	ds_store_b16 v86, v4 offset:2576                           // 00000014F300: D87C0A10 00000456
	s_and_saveexec_b32 s26, s8                                 // 00000014F308: BE9A2008
	s_cbranch_execz 17                                         // 00000014F30C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a54>
	v_mad_u64_u32 v[3:4], null, v92, 48, s[2:3]                // 00000014F310: D6FE7C03 0009615C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F318: BF870091
	.long 0xd73c0003                                           // 00000014F31C: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014F320: 02020689
	.long 0xd7000b03                                           // 00000014F324: D7000B03
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014F328: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F32C: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s11                 // 00000014F330: D5207C04 002E0955
	global_load_b32 v3, v[3:4], off offset:64                  // 00000014F338: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014F340: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v39                         // 00000014F344: 56064EFF BB800000
	v_fma_mixhi_f16 v3, v3, s18, 0                             // 00000014F34C: CC220003 02002503
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F354: 8C7E1A7E
	.long 0x7e063880                                           // 00000014F358: 7E063880
	ds_store_b16_d16_hi v86, v3 offset:2580                    // 00000014F35C: DA840A14 00000356
	.long 0x7e083903                                           // 00000014F364: 7E083903
	s_and_saveexec_b32 s26, s9                                 // 00000014F368: BE9A2009
	s_cbranch_execz 17                                         // 00000014F36C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ab4>
	v_mad_u64_u32 v[34:35], null, v93, 48, s[2:3]              // 00000014F370: D6FE7C22 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F378: BF870091
	.long 0xd73c0022                                           // 00000014F37C: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000014F380: 02024489
	.long 0xd7000b22                                           // 00000014F384: D7000B22
	v_cndmask_b32_e32 v1, v84, v34, vcc_lo                     // 00000014F388: 02024554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F38C: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v85, v35, s11               // 00000014F390: D5207C23 002E4755
	global_load_b32 v4, v[34:35], off offset:64                // 00000014F398: DC520040 047C0022
	s_waitcnt vmcnt(0)                                         // 00000014F3A0: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v40                         // 00000014F3A4: 560850FF BB800000
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 00000014F3AC: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F3B4: 8C7E1A7E
	ds_store_b16 v86, v4 offset:2584                           // 00000014F3B8: D87C0A18 00000456
	s_and_saveexec_b32 s26, s10                                // 00000014F3C0: BE9A200A
	s_cbranch_execz 17                                         // 00000014F3C4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b0c>
	v_mad_u64_u32 v[3:4], null, v94, 48, s[2:3]                // 00000014F3C8: D6FE7C03 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F3D0: BF870091
	.long 0xd73c0003                                           // 00000014F3D4: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014F3D8: 02020689
	.long 0xd7000b03                                           // 00000014F3DC: D7000B03
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014F3E0: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F3E4: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s11                 // 00000014F3E8: D5207C04 002E0955
	global_load_b32 v3, v[3:4], off offset:64                  // 00000014F3F0: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014F3F8: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v41                         // 00000014F3FC: 560652FF BB800000
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 00000014F404: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F40C: 8C7E1A7E
	.long 0x7f063880                                           // 00000014F410: 7F063880
	ds_store_b16 v86, v3 offset:2588                           // 00000014F414: D87C0A1C 00000356
	.long 0x7e083983                                           // 00000014F41C: 7E083983
	s_and_saveexec_b32 s26, s1                                 // 00000014F420: BE9A2001
	s_cbranch_execz 17                                         // 00000014F424: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b6c>
	v_mad_u64_u32 v[34:35], null, v7, 48, s[2:3]               // 00000014F428: D6FE7C22 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F430: BF870091
	.long 0xd73c0022                                           // 00000014F434: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000014F438: 02024489
	.long 0xd7000b22                                           // 00000014F43C: D7000B22
	v_cndmask_b32_e32 v1, v84, v34, vcc_lo                     // 00000014F440: 02024554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F444: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v85, v35, s11               // 00000014F448: D5207C23 002E4755
	global_load_b32 v4, v[34:35], off offset:128               // 00000014F450: DC520080 047C0022
	s_waitcnt vmcnt(0)                                         // 00000014F458: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v26                         // 00000014F45C: 560834FF BB800000
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 00000014F464: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F46C: 8C7E1A7E
	ds_store_b16 v86, v4 offset:5120                           // 00000014F470: D87C1400 00000456
	s_and_saveexec_b32 s26, s4                                 // 00000014F478: BE9A2004
	s_cbranch_execz 17                                         // 00000014F47C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2bc4>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 00000014F480: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F488: BF870091
	.long 0xd73c0003                                           // 00000014F48C: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014F490: 02020689
	.long 0xd7000b03                                           // 00000014F494: D7000B03
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014F498: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F49C: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s11                 // 00000014F4A0: D5207C04 002E0955
	global_load_b32 v3, v[3:4], off offset:128                 // 00000014F4A8: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014F4B0: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v27                         // 00000014F4B4: 560636FF BB800000
	v_fma_mixhi_f16 v3, v3, s18, 0                             // 00000014F4BC: CC220003 02002503
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F4C4: 8C7E1A7E
	.long 0x7e063880                                           // 00000014F4C8: 7E063880
	ds_store_b16_d16_hi v86, v3 offset:5124                    // 00000014F4CC: DA841404 00000356
	.long 0x7e083903                                           // 00000014F4D4: 7E083903
	s_and_saveexec_b32 s26, s5                                 // 00000014F4D8: BE9A2005
	s_cbranch_execz 17                                         // 00000014F4DC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c24>
	v_mad_u64_u32 v[26:27], null, v9, 48, s[2:3]               // 00000014F4E0: D6FE7C1A 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F4E8: BF870091
	.long 0xd73c001a                                           // 00000014F4EC: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000014F4F0: 02023489
	.long 0xd7000b1a                                           // 00000014F4F4: D7000B1A
	v_cndmask_b32_e32 v1, v84, v26, vcc_lo                     // 00000014F4F8: 02023554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F4FC: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v85, v27, s11               // 00000014F500: D5207C1B 002E3755
	global_load_b32 v4, v[26:27], off offset:128               // 00000014F508: DC520080 047C001A
	s_waitcnt vmcnt(0)                                         // 00000014F510: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v28                         // 00000014F514: 560838FF BB800000
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 00000014F51C: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F524: 8C7E1A7E
	ds_store_b16 v86, v4 offset:5128                           // 00000014F528: D87C1408 00000456
	s_and_saveexec_b32 s26, s6                                 // 00000014F530: BE9A2006
	s_cbranch_execz 17                                         // 00000014F534: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c7c>
	v_mad_u64_u32 v[3:4], null, v90, 48, s[2:3]                // 00000014F538: D6FE7C03 0009615A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F540: BF870091
	.long 0xd73c0003                                           // 00000014F544: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014F548: 02020689
	.long 0xd7000b03                                           // 00000014F54C: D7000B03
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014F550: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F554: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s11                 // 00000014F558: D5207C04 002E0955
	global_load_b32 v3, v[3:4], off offset:128                 // 00000014F560: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014F568: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v29                         // 00000014F56C: 56063AFF BB800000
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 00000014F574: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F57C: 8C7E1A7E
	.long 0x7f063880                                           // 00000014F580: 7F063880
	ds_store_b16 v86, v3 offset:5132                           // 00000014F584: D87C140C 00000356
	.long 0x7e083983                                           // 00000014F58C: 7E083983
	s_and_saveexec_b32 s26, s7                                 // 00000014F590: BE9A2007
	s_cbranch_execz 17                                         // 00000014F594: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2cdc>
	v_mad_u64_u32 v[26:27], null, v91, 48, s[2:3]              // 00000014F598: D6FE7C1A 0009615B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F5A0: BF870091
	.long 0xd73c001a                                           // 00000014F5A4: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000014F5A8: 02023489
	.long 0xd7000b1a                                           // 00000014F5AC: D7000B1A
	v_cndmask_b32_e32 v1, v84, v26, vcc_lo                     // 00000014F5B0: 02023554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F5B4: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v85, v27, s11               // 00000014F5B8: D5207C1B 002E3755
	global_load_b32 v4, v[26:27], off offset:128               // 00000014F5C0: DC520080 047C001A
	s_waitcnt vmcnt(0)                                         // 00000014F5C8: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v30                         // 00000014F5CC: 56083CFF BB800000
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 00000014F5D4: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F5DC: 8C7E1A7E
	ds_store_b16 v86, v4 offset:5136                           // 00000014F5E0: D87C1410 00000456
	s_and_saveexec_b32 s26, s8                                 // 00000014F5E8: BE9A2008
	s_cbranch_execz 17                                         // 00000014F5EC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d34>
	v_mad_u64_u32 v[3:4], null, v92, 48, s[2:3]                // 00000014F5F0: D6FE7C03 0009615C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F5F8: BF870091
	.long 0xd73c0003                                           // 00000014F5FC: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014F600: 02020689
	.long 0xd7000b03                                           // 00000014F604: D7000B03
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014F608: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F60C: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s11                 // 00000014F610: D5207C04 002E0955
	global_load_b32 v3, v[3:4], off offset:128                 // 00000014F618: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014F620: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v31                         // 00000014F624: 56063EFF BB800000
	v_fma_mixhi_f16 v3, v3, s18, 0                             // 00000014F62C: CC220003 02002503
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F634: 8C7E1A7E
	.long 0x7e063880                                           // 00000014F638: 7E063880
	ds_store_b16_d16_hi v86, v3 offset:5140                    // 00000014F63C: DA841414 00000356
	.long 0x7e083903                                           // 00000014F644: 7E083903
	s_and_saveexec_b32 s26, s9                                 // 00000014F648: BE9A2009
	s_cbranch_execz 17                                         // 00000014F64C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d94>
	v_mad_u64_u32 v[26:27], null, v93, 48, s[2:3]              // 00000014F650: D6FE7C1A 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F658: BF870091
	.long 0xd73c001a                                           // 00000014F65C: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000014F660: 02023489
	.long 0xd7000b1a                                           // 00000014F664: D7000B1A
	v_cndmask_b32_e32 v1, v84, v26, vcc_lo                     // 00000014F668: 02023554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F66C: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v85, v27, s11               // 00000014F670: D5207C1B 002E3755
	global_load_b32 v4, v[26:27], off offset:128               // 00000014F678: DC520080 047C001A
	s_waitcnt vmcnt(0)                                         // 00000014F680: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v32                         // 00000014F684: 560840FF BB800000
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 00000014F68C: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F694: 8C7E1A7E
	ds_store_b16 v86, v4 offset:5144                           // 00000014F698: D87C1418 00000456
	s_and_saveexec_b32 s26, s10                                // 00000014F6A0: BE9A200A
	s_cbranch_execz 17                                         // 00000014F6A4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2dec>
	v_mad_u64_u32 v[3:4], null, v94, 48, s[2:3]                // 00000014F6A8: D6FE7C03 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F6B0: BF870091
	.long 0xd73c0003                                           // 00000014F6B4: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014F6B8: 02020689
	.long 0xd7000b03                                           // 00000014F6BC: D7000B03
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014F6C0: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F6C4: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s11                 // 00000014F6C8: D5207C04 002E0955
	global_load_b32 v3, v[3:4], off offset:128                 // 00000014F6D0: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014F6D8: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v33                         // 00000014F6DC: 560642FF BB800000
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 00000014F6E4: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F6EC: 8C7E1A7E
	.long 0x7f063880                                           // 00000014F6F0: 7F063880
	ds_store_b16 v86, v3 offset:5148                           // 00000014F6F4: D87C141C 00000356
	.long 0x7e083983                                           // 00000014F6FC: 7E083983
	s_and_saveexec_b32 s26, s1                                 // 00000014F700: BE9A2001
	s_cbranch_execz 17                                         // 00000014F704: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e4c>
	v_mad_u64_u32 v[26:27], null, v7, 48, s[2:3]               // 00000014F708: D6FE7C1A 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F710: BF870091
	.long 0xd73c001a                                           // 00000014F714: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000014F718: 02023489
	.long 0xd7000b1a                                           // 00000014F71C: D7000B1A
	v_cndmask_b32_e32 v1, v84, v26, vcc_lo                     // 00000014F720: 02023554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F724: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v85, v27, s11               // 00000014F728: D5207C1B 002E3755
	global_load_b32 v4, v[26:27], off offset:192               // 00000014F730: DC5200C0 047C001A
	s_waitcnt vmcnt(0)                                         // 00000014F738: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v18                         // 00000014F73C: 560824FF BB800000
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 00000014F744: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F74C: 8C7E1A7E
	ds_store_b16 v86, v4 offset:7680                           // 00000014F750: D87C1E00 00000456
	s_and_saveexec_b32 s26, s4                                 // 00000014F758: BE9A2004
	s_cbranch_execz 17                                         // 00000014F75C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ea4>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 00000014F760: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F768: BF870091
	.long 0xd73c0003                                           // 00000014F76C: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014F770: 02020689
	.long 0xd7000b03                                           // 00000014F774: D7000B03
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014F778: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F77C: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s11                 // 00000014F780: D5207C04 002E0955
	global_load_b32 v3, v[3:4], off offset:192                 // 00000014F788: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014F790: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v19                         // 00000014F794: 560626FF BB800000
	v_fma_mixhi_f16 v3, v3, s18, 0                             // 00000014F79C: CC220003 02002503
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F7A4: 8C7E1A7E
	.long 0x7e063880                                           // 00000014F7A8: 7E063880
	ds_store_b16_d16_hi v86, v3 offset:7684                    // 00000014F7AC: DA841E04 00000356
	.long 0x7e083903                                           // 00000014F7B4: 7E083903
	s_and_saveexec_b32 s26, s5                                 // 00000014F7B8: BE9A2005
	s_cbranch_execz 17                                         // 00000014F7BC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2f04>
	v_mad_u64_u32 v[18:19], null, v9, 48, s[2:3]               // 00000014F7C0: D6FE7C12 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F7C8: BF870091
	.long 0xd73c0012                                           // 00000014F7CC: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 00000014F7D0: 02022489
	.long 0xd7000b12                                           // 00000014F7D4: D7000B12
	v_cndmask_b32_e32 v1, v84, v18, vcc_lo                     // 00000014F7D8: 02022554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F7DC: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v85, v19, s11               // 00000014F7E0: D5207C13 002E2755
	global_load_b32 v4, v[18:19], off offset:192               // 00000014F7E8: DC5200C0 047C0012
	s_waitcnt vmcnt(0)                                         // 00000014F7F0: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v20                         // 00000014F7F4: 560828FF BB800000
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 00000014F7FC: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F804: 8C7E1A7E
	ds_store_b16 v86, v4 offset:7688                           // 00000014F808: D87C1E08 00000456
	s_and_saveexec_b32 s26, s6                                 // 00000014F810: BE9A2006
	s_cbranch_execz 17                                         // 00000014F814: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2f5c>
	v_mad_u64_u32 v[3:4], null, v90, 48, s[2:3]                // 00000014F818: D6FE7C03 0009615A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F820: BF870091
	.long 0xd73c0003                                           // 00000014F824: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014F828: 02020689
	.long 0xd7000b03                                           // 00000014F82C: D7000B03
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014F830: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F834: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s11                 // 00000014F838: D5207C04 002E0955
	global_load_b32 v3, v[3:4], off offset:192                 // 00000014F840: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014F848: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v21                         // 00000014F84C: 56062AFF BB800000
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 00000014F854: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F85C: 8C7E1A7E
	.long 0x7f063880                                           // 00000014F860: 7F063880
	ds_store_b16 v86, v3 offset:7692                           // 00000014F864: D87C1E0C 00000356
	.long 0x7e083983                                           // 00000014F86C: 7E083983
	s_and_saveexec_b32 s26, s7                                 // 00000014F870: BE9A2007
	s_cbranch_execz 17                                         // 00000014F874: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2fbc>
	v_mad_u64_u32 v[18:19], null, v91, 48, s[2:3]              // 00000014F878: D6FE7C12 0009615B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F880: BF870091
	.long 0xd73c0012                                           // 00000014F884: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 00000014F888: 02022489
	.long 0xd7000b12                                           // 00000014F88C: D7000B12
	v_cndmask_b32_e32 v1, v84, v18, vcc_lo                     // 00000014F890: 02022554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F894: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v85, v19, s11               // 00000014F898: D5207C13 002E2755
	global_load_b32 v4, v[18:19], off offset:192               // 00000014F8A0: DC5200C0 047C0012
	s_waitcnt vmcnt(0)                                         // 00000014F8A8: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v22                         // 00000014F8AC: 56082CFF BB800000
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 00000014F8B4: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F8BC: 8C7E1A7E
	ds_store_b16 v86, v4 offset:7696                           // 00000014F8C0: D87C1E10 00000456
	s_and_saveexec_b32 s26, s8                                 // 00000014F8C8: BE9A2008
	s_cbranch_execz 17                                         // 00000014F8CC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3014>
	v_mad_u64_u32 v[3:4], null, v92, 48, s[2:3]                // 00000014F8D0: D6FE7C03 0009615C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F8D8: BF870091
	.long 0xd73c0003                                           // 00000014F8DC: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014F8E0: 02020689
	.long 0xd7000b03                                           // 00000014F8E4: D7000B03
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014F8E8: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F8EC: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s11                 // 00000014F8F0: D5207C04 002E0955
	global_load_b32 v3, v[3:4], off offset:192                 // 00000014F8F8: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014F900: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v23                         // 00000014F904: 56062EFF BB800000
	v_fma_mixhi_f16 v3, v3, s18, 0                             // 00000014F90C: CC220003 02002503
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F914: 8C7E1A7E
	.long 0x7e063880                                           // 00000014F918: 7E063880
	ds_store_b16_d16_hi v86, v3 offset:7700                    // 00000014F91C: DA841E14 00000356
	.long 0x7e083903                                           // 00000014F924: 7E083903
	s_and_saveexec_b32 s26, s9                                 // 00000014F928: BE9A2009
	s_cbranch_execz 17                                         // 00000014F92C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3074>
	v_mad_u64_u32 v[18:19], null, v93, 48, s[2:3]              // 00000014F930: D6FE7C12 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F938: BF870091
	.long 0xd73c0012                                           // 00000014F93C: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 00000014F940: 02022489
	.long 0xd7000b12                                           // 00000014F944: D7000B12
	v_cndmask_b32_e32 v1, v84, v18, vcc_lo                     // 00000014F948: 02022554
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F94C: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v85, v19, s11               // 00000014F950: D5207C13 002E2755
	global_load_b32 v4, v[18:19], off offset:192               // 00000014F958: DC5200C0 047C0012
	s_waitcnt vmcnt(0)                                         // 00000014F960: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v24                         // 00000014F964: 560830FF BB800000
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 00000014F96C: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F974: 8C7E1A7E
	ds_store_b16 v86, v4 offset:7704                           // 00000014F978: D87C1E18 00000456
	s_and_saveexec_b32 s26, s10                                // 00000014F980: BE9A200A
	s_cbranch_execz 17                                         // 00000014F984: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x30cc>
	v_mad_u64_u32 v[3:4], null, v94, 48, s[2:3]                // 00000014F988: D6FE7C03 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F990: BF870091
	.long 0xd73c0003                                           // 00000014F994: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014F998: 02020689
	.long 0xd7000b03                                           // 00000014F99C: D7000B03
	v_cndmask_b32_e32 v1, v84, v3, vcc_lo                      // 00000014F9A0: 02020754
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014F9A4: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v85, v4, s11                 // 00000014F9A8: D5207C04 002E0955
	global_load_b32 v3, v[3:4], off offset:192                 // 00000014F9B0: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014F9B8: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v25                         // 00000014F9BC: 560632FF BB800000
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 00000014F9C4: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014F9CC: 8C7E1A7E
	.long 0x7f7a3880                                           // 00000014F9D0: 7F7A3880
	.long 0xd7000b04                                           // 00000014F9D4: D7000B04
	v_cndmask_b32_e32 v1, s20, v5, vcc_lo                      // 00000014F9D8: 02020A14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000014F9DC: BF870191
	v_add_co_ci_u32_e64 v5, null, s21, v6, s11                 // 00000014F9E0: D5207C05 002E0C15
	.long 0x7f7639bd                                           // 00000014F9E8: 7F7639BD
	.long 0x7e7639bd                                           // 00000014F9EC: 7E7639BD
	.long 0x7f7439bd                                           // 00000014F9F0: 7F7439BD
	.long 0x7e7439bd                                           // 00000014F9F4: 7E7439BD
	ds_store_b16 v86, v3 offset:7708                           // 00000014F9F8: D87C1E1C 00000356
	s_waitcnt lgkmcnt(0)                                       // 00000014FA00: BF89FC07
	s_barrier                                                  // 00000014FA04: BFBD0000
	buffer_gl0_inv                                             // 00000014FA08: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 00000014FA10: BE8B2000
	s_cbranch_execz 11                                         // 00000014FA14: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3144>
	global_load_b128 v[18:21], v[4:5], off                     // 00000014FA18: DC5E0000 127C0004
	s_waitcnt vmcnt(0)                                         // 00000014FA20: BF8903F7
	v_fma_mixlo_f16 v58, v18, s18, 0                           // 00000014FA24: CC21003A 02002512
	v_fma_mixhi_f16 v58, v19, s18, 0                           // 00000014FA2C: CC22003A 02002513
	v_fma_mixlo_f16 v59, v20, s18, 0                           // 00000014FA34: CC21003B 02002514
	v_fma_mixhi_f16 v59, v21, s18, 0                           // 00000014FA3C: CC22003B 02002515
	s_or_b32 exec_lo, exec_lo, s11                             // 00000014FA44: 8C7E0B7E
	.long 0x7e7a39bd                                           // 00000014FA48: 7E7A39BD
	.long 0x7f7839bd                                           // 00000014FA4C: 7F7839BD
	.long 0x7e7839bd                                           // 00000014FA50: 7E7839BD
	s_and_saveexec_b32 s11, s0                                 // 00000014FA54: BE8B2000
	s_cbranch_execz 11                                         // 00000014FA58: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3188>
	global_load_b128 v[18:21], v[4:5], off offset:16           // 00000014FA5C: DC5E0010 127C0004
	s_waitcnt vmcnt(0)                                         // 00000014FA64: BF8903F7
	v_fma_mixlo_f16 v60, v18, s18, 0                           // 00000014FA68: CC21003C 02002512
	v_fma_mixhi_f16 v60, v19, s18, 0                           // 00000014FA70: CC22003C 02002513
	v_fma_mixlo_f16 v61, v20, s18, 0                           // 00000014FA78: CC21003D 02002514
	v_fma_mixhi_f16 v61, v21, s18, 0                           // 00000014FA80: CC22003D 02002515
	s_or_b32 exec_lo, exec_lo, s11                             // 00000014FA88: 8C7E0B7E
	.long 0x7f823880                                           // 00000014FA8C: 7F823880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014FA90: BF870001
	.long 0x7f7e39c1                                           // 00000014FA94: 7F7E39C1
	.long 0x7e7e39c1                                           // 00000014FA98: 7E7E39C1
	.long 0x7f7c39c1                                           // 00000014FA9C: 7F7C39C1
	.long 0x7e7c39c1                                           // 00000014FAA0: 7E7C39C1
	s_and_saveexec_b32 s11, s0                                 // 00000014FAA4: BE8B2000
	s_cbranch_execz 11                                         // 00000014FAA8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x31d8>
	global_load_b128 v[18:21], v[4:5], off offset:32           // 00000014FAAC: DC5E0020 127C0004
	s_waitcnt vmcnt(0)                                         // 00000014FAB4: BF8903F7
	v_fma_mixlo_f16 v62, v18, s18, 0                           // 00000014FAB8: CC21003E 02002512
	v_fma_mixhi_f16 v62, v19, s18, 0                           // 00000014FAC0: CC22003E 02002513
	v_fma_mixlo_f16 v63, v20, s18, 0                           // 00000014FAC8: CC21003F 02002514
	v_fma_mixhi_f16 v63, v21, s18, 0                           // 00000014FAD0: CC22003F 02002515
	s_or_b32 exec_lo, exec_lo, s11                             // 00000014FAD8: 8C7E0B7E
	.long 0x7e8239c1                                           // 00000014FADC: 7E8239C1
	.long 0x7f8039c1                                           // 00000014FAE0: 7F8039C1
	.long 0x7e8039c1                                           // 00000014FAE4: 7E8039C1
	s_and_saveexec_b32 s11, s0                                 // 00000014FAE8: BE8B2000
	s_cbranch_execz 11                                         // 00000014FAEC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x321c>
	global_load_b128 v[18:21], v[4:5], off offset:48           // 00000014FAF0: DC5E0030 127C0004
	s_waitcnt vmcnt(0)                                         // 00000014FAF8: BF8903F7
	v_fma_mixlo_f16 v64, v18, s18, 0                           // 00000014FAFC: CC210040 02002512
	v_fma_mixhi_f16 v64, v19, s18, 0                           // 00000014FB04: CC220040 02002513
	v_fma_mixlo_f16 v65, v20, s18, 0                           // 00000014FB0C: CC210041 02002514
	v_fma_mixhi_f16 v65, v21, s18, 0                           // 00000014FB14: CC220041 02002515
	s_or_b32 exec_lo, exec_lo, s11                             // 00000014FB1C: 8C7E0B7E
	ds_load_b128 v[18:21], v78                                 // 00000014FB20: DBFC0000 1200004E
	ds_load_b128 v[22:25], v78 offset:16                       // 00000014FB28: DBFC0010 1600004E
	ds_load_b128 v[26:29], v78 offset:32                       // 00000014FB30: DBFC0020 1A00004E
	ds_load_b128 v[30:33], v78 offset:48                       // 00000014FB38: DBFC0030 1E00004E
	ds_load_b128 v[34:37], v78 offset:8448                     // 00000014FB40: DBFC2100 2200004E
	ds_load_b128 v[38:41], v78 offset:8464                     // 00000014FB48: DBFC2110 2600004E
	ds_load_b128 v[42:45], v78 offset:8480                     // 00000014FB50: DBFC2120 2A00004E
	ds_load_b128 v[46:49], v78 offset:8496                     // 00000014FB58: DBFC2130 2E00004E
	ds_load_b128 v[50:53], v78 offset:16896                    // 00000014FB60: DBFC4200 3200004E
	ds_load_b128 v[54:57], v78 offset:16912                    // 00000014FB68: DBFC4210 3600004E
	v_dual_mov_b32 v102, s43 :: v_dual_mov_b32 v101, s42       // 00000014FB70: CA10002B 6664002A
	v_dual_mov_b32 v100, s41 :: v_dual_mov_b32 v99, s40        // 00000014FB78: CA100029 64620028
	v_dual_mov_b32 v98, s39 :: v_dual_mov_b32 v97, s38         // 00000014FB80: CA100027 62600026
	v_dual_mov_b32 v96, s37 :: v_dual_mov_b32 v95, s36         // 00000014FB88: CA100025 605E0024
	ds_load_b128 v[103:106], v78 offset:16928                  // 00000014FB90: DBFC4220 6700004E
	ds_load_b128 v[107:110], v78 offset:16944                  // 00000014FB98: DBFC4230 6B00004E
	s_waitcnt lgkmcnt(11)                                      // 00000014FBA0: BF89FCB7
	v_fma_mixlo_f16 v18, v18, s18, 0                           // 00000014FBA4: CC210012 02002512
	v_fma_mixhi_f16 v18, v19, s18, 0                           // 00000014FBAC: CC220012 02002513
	v_fma_mixlo_f16 v19, v20, s18, 0                           // 00000014FBB4: CC210013 02002514
	v_fma_mixhi_f16 v19, v21, s18, 0                           // 00000014FBBC: CC220013 02002515
	s_waitcnt lgkmcnt(10)                                      // 00000014FBC4: BF89FCA7
	v_fma_mixlo_f16 v20, v22, s18, 0                           // 00000014FBC8: CC210014 02002516
	v_fma_mixhi_f16 v20, v23, s18, 0                           // 00000014FBD0: CC220014 02002517
	v_fma_mixlo_f16 v21, v24, s18, 0                           // 00000014FBD8: CC210015 02002518
	v_fma_mixhi_f16 v21, v25, s18, 0                           // 00000014FBE0: CC220015 02002519
	s_waitcnt lgkmcnt(9)                                       // 00000014FBE8: BF89FC97
	v_fma_mixlo_f16 v22, v26, s18, 0                           // 00000014FBEC: CC210016 0200251A
	v_fma_mixhi_f16 v22, v27, s18, 0                           // 00000014FBF4: CC220016 0200251B
	v_fma_mixlo_f16 v23, v28, s18, 0                           // 00000014FBFC: CC210017 0200251C
	v_fma_mixhi_f16 v23, v29, s18, 0                           // 00000014FC04: CC220017 0200251D
	s_waitcnt lgkmcnt(8)                                       // 00000014FC0C: BF89FC87
	v_fma_mixlo_f16 v24, v30, s18, 0                           // 00000014FC10: CC210018 0200251E
	v_fma_mixhi_f16 v24, v31, s18, 0                           // 00000014FC18: CC220018 0200251F
	v_fma_mixlo_f16 v25, v32, s18, 0                           // 00000014FC20: CC210019 02002520
	v_fma_mixhi_f16 v25, v33, s18, 0                           // 00000014FC28: CC220019 02002521
	s_waitcnt lgkmcnt(7)                                       // 00000014FC30: BF89FC77
	v_fma_mixlo_f16 v26, v34, s18, 0                           // 00000014FC34: CC21001A 02002522
	v_fma_mixhi_f16 v26, v35, s18, 0                           // 00000014FC3C: CC22001A 02002523
	v_fma_mixlo_f16 v27, v36, s18, 0                           // 00000014FC44: CC21001B 02002524
	v_fma_mixhi_f16 v27, v37, s18, 0                           // 00000014FC4C: CC22001B 02002525
	s_waitcnt lgkmcnt(6)                                       // 00000014FC54: BF89FC67
	v_fma_mixlo_f16 v28, v38, s18, 0                           // 00000014FC58: CC21001C 02002526
	v_fma_mixhi_f16 v28, v39, s18, 0                           // 00000014FC60: CC22001C 02002527
	v_fma_mixlo_f16 v29, v40, s18, 0                           // 00000014FC68: CC21001D 02002528
	v_fma_mixhi_f16 v29, v41, s18, 0                           // 00000014FC70: CC22001D 02002529
	s_waitcnt lgkmcnt(5)                                       // 00000014FC78: BF89FC57
	v_fma_mixlo_f16 v30, v42, s18, 0                           // 00000014FC7C: CC21001E 0200252A
	v_fma_mixhi_f16 v30, v43, s18, 0                           // 00000014FC84: CC22001E 0200252B
	v_fma_mixlo_f16 v31, v44, s18, 0                           // 00000014FC8C: CC21001F 0200252C
	v_fma_mixhi_f16 v31, v45, s18, 0                           // 00000014FC94: CC22001F 0200252D
	s_waitcnt lgkmcnt(4)                                       // 00000014FC9C: BF89FC47
	v_fma_mixlo_f16 v32, v46, s18, 0                           // 00000014FCA0: CC210020 0200252E
	v_fma_mixhi_f16 v32, v47, s18, 0                           // 00000014FCA8: CC220020 0200252F
	v_fma_mixlo_f16 v33, v48, s18, 0                           // 00000014FCB0: CC210021 02002530
	v_fma_mixhi_f16 v33, v49, s18, 0                           // 00000014FCB8: CC220021 02002531
	v_wmma_f32_16x16x16_f16 v[42:49], v[58:65], v[18:25], v[95:102]// 00000014FCC0: CC40402A 1D7E253A
	s_waitcnt lgkmcnt(3)                                       // 00000014FCC8: BF89FC37
	v_fma_mixlo_f16 v18, v50, s18, 0                           // 00000014FCCC: CC210012 02002532
	v_fma_mixhi_f16 v18, v51, s18, 0                           // 00000014FCD4: CC220012 02002533
	v_wmma_f32_16x16x16_f16 v[34:41], v[58:65], v[26:33], v[95:102]// 00000014FCDC: CC404022 1D7E353A
	ds_load_b128 v[26:29], v78 offset:25344                    // 00000014FCE4: DBFC6300 1A00004E
	ds_load_b128 v[30:33], v78 offset:25360                    // 00000014FCEC: DBFC6310 1E00004E
	v_fma_mixlo_f16 v19, v52, s18, 0                           // 00000014FCF4: CC210013 02002534
	v_fma_mixhi_f16 v19, v53, s18, 0                           // 00000014FCFC: CC220013 02002535
	s_waitcnt lgkmcnt(4)                                       // 00000014FD04: BF89FC47
	v_fma_mixlo_f16 v20, v54, s18, 0                           // 00000014FD08: CC210014 02002536
	v_fma_mixhi_f16 v20, v55, s18, 0                           // 00000014FD10: CC220014 02002537
	ds_load_b128 v[50:53], v78 offset:25376                    // 00000014FD18: DBFC6320 3200004E
	v_fma_mixlo_f16 v21, v56, s18, 0                           // 00000014FD20: CC210015 02002538
	v_fma_mixhi_f16 v21, v57, s18, 0                           // 00000014FD28: CC220015 02002539
	ds_load_b128 v[54:57], v78 offset:25392                    // 00000014FD30: DBFC6330 3600004E
	s_waitcnt lgkmcnt(5)                                       // 00000014FD38: BF89FC57
	v_fma_mixlo_f16 v22, v103, s18, 0                          // 00000014FD3C: CC210016 02002567
	v_fma_mixhi_f16 v22, v104, s18, 0                          // 00000014FD44: CC220016 02002568
	v_fma_mixlo_f16 v23, v105, s18, 0                          // 00000014FD4C: CC210017 02002569
	v_fma_mixhi_f16 v23, v106, s18, 0                          // 00000014FD54: CC220017 0200256A
	s_waitcnt lgkmcnt(4)                                       // 00000014FD5C: BF89FC47
	v_fma_mixlo_f16 v24, v107, s18, 0                          // 00000014FD60: CC210018 0200256B
	v_fma_mixhi_f16 v24, v108, s18, 0                          // 00000014FD68: CC220018 0200256C
	v_fma_mixlo_f16 v25, v109, s18, 0                          // 00000014FD70: CC210019 0200256D
	v_fma_mixhi_f16 v25, v110, s18, 0                          // 00000014FD78: CC220019 0200256E
	s_waitcnt lgkmcnt(3)                                       // 00000014FD80: BF89FC37
	v_fma_mixlo_f16 v103, v26, s18, 0                          // 00000014FD84: CC210067 0200251A
	v_fma_mixhi_f16 v103, v27, s18, 0                          // 00000014FD8C: CC220067 0200251B
	v_fma_mixlo_f16 v104, v28, s18, 0                          // 00000014FD94: CC210068 0200251C
	v_fma_mixhi_f16 v104, v29, s18, 0                          // 00000014FD9C: CC220068 0200251D
	s_waitcnt lgkmcnt(2)                                       // 00000014FDA4: BF89FC27
	v_fma_mixlo_f16 v105, v30, s18, 0                          // 00000014FDA8: CC210069 0200251E
	v_fma_mixhi_f16 v105, v31, s18, 0                          // 00000014FDB0: CC220069 0200251F
	v_fma_mixlo_f16 v106, v32, s18, 0                          // 00000014FDB8: CC21006A 02002520
	v_fma_mixhi_f16 v106, v33, s18, 0                          // 00000014FDC0: CC22006A 02002521
	s_waitcnt lgkmcnt(1)                                       // 00000014FDC8: BF89FC17
	v_fma_mixlo_f16 v107, v50, s18, 0                          // 00000014FDCC: CC21006B 02002532
	v_fma_mixhi_f16 v107, v51, s18, 0                          // 00000014FDD4: CC22006B 02002533
	v_fma_mixlo_f16 v108, v52, s18, 0                          // 00000014FDDC: CC21006C 02002534
	v_fma_mixhi_f16 v108, v53, s18, 0                          // 00000014FDE4: CC22006C 02002535
	s_waitcnt lgkmcnt(0)                                       // 00000014FDEC: BF89FC07
	v_fma_mixlo_f16 v109, v54, s18, 0                          // 00000014FDF0: CC21006D 02002536
	v_fma_mixhi_f16 v109, v55, s18, 0                          // 00000014FDF8: CC22006D 02002537
	v_fma_mixlo_f16 v110, v56, s18, 0                          // 00000014FE00: CC21006E 02002538
	v_fma_mixhi_f16 v110, v57, s18, 0                          // 00000014FE08: CC22006E 02002539
	.long 0x7f723880                                           // 00000014FE10: 7F723880
	v_wmma_f32_16x16x16_f16 v[26:33], v[58:65], v[18:25], v[95:102]// 00000014FE14: CC40401A 1D7E253A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000014FE1C: BF870193
	v_wmma_f32_16x16x16_f16 v[18:25], v[58:65], v[103:110], v[95:102]// 00000014FE20: CC404012 1D7ECF3A
	.long 0x7f6e39b9                                           // 00000014FE28: 7F6E39B9
	.long 0x7e6e39b9                                           // 00000014FE2C: 7E6E39B9
	.long 0x7f6c39b9                                           // 00000014FE30: 7F6C39B9
	.long 0x7e6c39b9                                           // 00000014FE34: 7E6C39B9
	s_and_saveexec_b32 s11, s0                                 // 00000014FE38: BE8B2000
	s_cbranch_execz 11                                         // 00000014FE3C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x356c>
	global_load_b128 v[50:53], v[4:5], off offset:64           // 00000014FE40: DC5E0040 327C0004
	s_waitcnt vmcnt(0)                                         // 00000014FE48: BF8903F7
	v_fma_mixlo_f16 v54, v50, s18, 0                           // 00000014FE4C: CC210036 02002532
	v_fma_mixhi_f16 v54, v51, s18, 0                           // 00000014FE54: CC220036 02002533
	v_fma_mixlo_f16 v55, v52, s18, 0                           // 00000014FE5C: CC210037 02002534
	v_fma_mixhi_f16 v55, v53, s18, 0                           // 00000014FE64: CC220037 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 00000014FE6C: 8C7E0B7E
	.long 0x7e7239b9                                           // 00000014FE70: 7E7239B9
	.long 0x7f7039b9                                           // 00000014FE74: 7F7039B9
	.long 0x7e7039b9                                           // 00000014FE78: 7E7039B9
	s_and_saveexec_b32 s11, s0                                 // 00000014FE7C: BE8B2000
	s_cbranch_execz 11                                         // 00000014FE80: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x35b0>
	global_load_b128 v[50:53], v[4:5], off offset:80           // 00000014FE84: DC5E0050 327C0004
	s_waitcnt vmcnt(0)                                         // 00000014FE8C: BF8903F7
	v_fma_mixlo_f16 v56, v50, s18, 0                           // 00000014FE90: CC210038 02002532
	v_fma_mixhi_f16 v56, v51, s18, 0                           // 00000014FE98: CC220038 02002533
	v_fma_mixlo_f16 v57, v52, s18, 0                           // 00000014FEA0: CC210039 02002534
	v_fma_mixhi_f16 v57, v53, s18, 0                           // 00000014FEA8: CC220039 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 00000014FEB0: 8C7E0B7E
	.long 0x7f7a3880                                           // 00000014FEB4: 7F7A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014FEB8: BF870001
	.long 0x7f7639bd                                           // 00000014FEBC: 7F7639BD
	.long 0x7e7639bd                                           // 00000014FEC0: 7E7639BD
	.long 0x7f7439bd                                           // 00000014FEC4: 7F7439BD
	.long 0x7e7439bd                                           // 00000014FEC8: 7E7439BD
	s_and_saveexec_b32 s11, s0                                 // 00000014FECC: BE8B2000
	s_cbranch_execz 11                                         // 00000014FED0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3600>
	global_load_b128 v[50:53], v[4:5], off offset:96           // 00000014FED4: DC5E0060 327C0004
	s_waitcnt vmcnt(0)                                         // 00000014FEDC: BF8903F7
	v_fma_mixlo_f16 v58, v50, s18, 0                           // 00000014FEE0: CC21003A 02002532
	v_fma_mixhi_f16 v58, v51, s18, 0                           // 00000014FEE8: CC22003A 02002533
	v_fma_mixlo_f16 v59, v52, s18, 0                           // 00000014FEF0: CC21003B 02002534
	v_fma_mixhi_f16 v59, v53, s18, 0                           // 00000014FEF8: CC22003B 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 00000014FF00: 8C7E0B7E
	.long 0x7e7a39bd                                           // 00000014FF04: 7E7A39BD
	.long 0x7f7839bd                                           // 00000014FF08: 7F7839BD
	.long 0x7e7839bd                                           // 00000014FF0C: 7E7839BD
	s_and_saveexec_b32 s11, s0                                 // 00000014FF10: BE8B2000
	s_cbranch_execz 11                                         // 00000014FF14: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3644>
	global_load_b128 v[50:53], v[4:5], off offset:112          // 00000014FF18: DC5E0070 327C0004
	s_waitcnt vmcnt(0)                                         // 00000014FF20: BF8903F7
	v_fma_mixlo_f16 v60, v50, s18, 0                           // 00000014FF24: CC21003C 02002532
	v_fma_mixhi_f16 v60, v51, s18, 0                           // 00000014FF2C: CC22003C 02002533
	v_fma_mixlo_f16 v61, v52, s18, 0                           // 00000014FF34: CC21003D 02002534
	v_fma_mixhi_f16 v61, v53, s18, 0                           // 00000014FF3C: CC22003D 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 00000014FF44: 8C7E0B7E
	ds_load_b128 v[50:53], v78 offset:64                       // 00000014FF48: DBFC0040 3200004E
	ds_load_b128 v[62:65], v78 offset:80                       // 00000014FF50: DBFC0050 3E00004E
	ds_load_b128 v[99:102], v78 offset:96                      // 00000014FF58: DBFC0060 6300004E
	ds_load_b128 v[103:106], v78 offset:112                    // 00000014FF60: DBFC0070 6700004E
	ds_load_b128 v[107:110], v78 offset:8512                   // 00000014FF68: DBFC2140 6B00004E
	ds_load_b128 v[111:114], v78 offset:8528                   // 00000014FF70: DBFC2150 6F00004E
	ds_load_b128 v[115:118], v78 offset:8544                   // 00000014FF78: DBFC2160 7300004E
	ds_load_b128 v[119:122], v78 offset:8560                   // 00000014FF80: DBFC2170 7700004E
	ds_load_b128 v[123:126], v78 offset:16992                  // 00000014FF88: DBFC4260 7B00004E
	ds_load_b128 v[127:130], v78 offset:17008                  // 00000014FF90: DBFC4270 7F00004E
	ds_load_b128 v[131:134], v78 offset:25424                  // 00000014FF98: DBFC6350 8300004E
	s_waitcnt lgkmcnt(10)                                      // 00000014FFA0: BF89FCA7
	v_fma_mixlo_f16 v95, v50, s18, 0                           // 00000014FFA4: CC21005F 02002532
	v_fma_mixhi_f16 v95, v51, s18, 0                           // 00000014FFAC: CC22005F 02002533
	v_fma_mixlo_f16 v96, v52, s18, 0                           // 00000014FFB4: CC210060 02002534
	v_fma_mixhi_f16 v96, v53, s18, 0                           // 00000014FFBC: CC220060 02002535
	s_waitcnt lgkmcnt(9)                                       // 00000014FFC4: BF89FC97
	v_fma_mixlo_f16 v97, v62, s18, 0                           // 00000014FFC8: CC210061 0200253E
	v_fma_mixhi_f16 v97, v63, s18, 0                           // 00000014FFD0: CC220061 0200253F
	v_fma_mixlo_f16 v98, v64, s18, 0                           // 00000014FFD8: CC210062 02002540
	v_fma_mixhi_f16 v98, v65, s18, 0                           // 00000014FFE0: CC220062 02002541
	ds_load_b128 v[50:53], v78 offset:16960                    // 00000014FFE8: DBFC4240 3200004E
	ds_load_b128 v[62:65], v78 offset:16976                    // 00000014FFF0: DBFC4250 3E00004E
	s_waitcnt lgkmcnt(10)                                      // 00000014FFF8: BF89FCA7
	v_fma_mixlo_f16 v99, v99, s18, 0                           // 00000014FFFC: CC210063 02002563
	v_fma_mixhi_f16 v99, v100, s18, 0                          // 000000150004: CC220063 02002564
	v_fma_mixlo_f16 v100, v101, s18, 0                         // 00000015000C: CC210064 02002565
	v_fma_mixhi_f16 v100, v102, s18, 0                         // 000000150014: CC220064 02002566
	s_waitcnt lgkmcnt(9)                                       // 00000015001C: BF89FC97
	v_fma_mixhi_f16 v101, v104, s18, 0                         // 000000150020: CC220065 02002568
	v_fma_mixlo_f16 v102, v105, s18, 0                         // 000000150028: CC210066 02002569
	v_fma_mixhi_f16 v102, v106, s18, 0                         // 000000150030: CC220066 0200256A
	s_waitcnt lgkmcnt(8)                                       // 000000150038: BF89FC87
	v_fma_mixlo_f16 v104, v109, s18, 0                         // 00000015003C: CC210068 0200256D
	v_fma_mixhi_f16 v104, v110, s18, 0                         // 000000150044: CC220068 0200256E
	s_waitcnt lgkmcnt(7)                                       // 00000015004C: BF89FC77
	v_fma_mixlo_f16 v105, v111, s18, 0                         // 000000150050: CC210069 0200256F
	v_fma_mixhi_f16 v105, v112, s18, 0                         // 000000150058: CC220069 02002570
	v_fma_mixlo_f16 v106, v113, s18, 0                         // 000000150060: CC21006A 02002571
	v_fma_mixhi_f16 v106, v114, s18, 0                         // 000000150068: CC22006A 02002572
	s_waitcnt lgkmcnt(5)                                       // 000000150070: BF89FC57
	v_fma_mixlo_f16 v109, v119, s18, 0                         // 000000150074: CC21006D 02002577
	v_fma_mixhi_f16 v109, v120, s18, 0                         // 00000015007C: CC22006D 02002578
	v_fma_mixlo_f16 v110, v121, s18, 0                         // 000000150084: CC21006E 02002579
	v_fma_mixhi_f16 v110, v122, s18, 0                         // 00000015008C: CC22006E 0200257A
	ds_load_b128 v[119:122], v78 offset:25408                  // 000000150094: DBFC6340 7700004E
	s_waitcnt lgkmcnt(2)                                       // 00000015009C: BF89FC27
	v_fma_mixlo_f16 v111, v50, s18, 0                          // 0000001500A0: CC21006F 02002532
	v_fma_mixhi_f16 v111, v51, s18, 0                          // 0000001500A8: CC22006F 02002533
	v_fma_mixlo_f16 v112, v52, s18, 0                          // 0000001500B0: CC210070 02002534
	v_fma_mixhi_f16 v112, v53, s18, 0                          // 0000001500B8: CC220070 02002535
	s_waitcnt lgkmcnt(1)                                       // 0000001500C0: BF89FC17
	v_fma_mixlo_f16 v113, v62, s18, 0                          // 0000001500C4: CC210071 0200253E
	v_fma_mixhi_f16 v113, v63, s18, 0                          // 0000001500CC: CC220071 0200253F
	ds_load_b128 v[50:53], v78 offset:25440                    // 0000001500D4: DBFC6360 3200004E
	v_fma_mixlo_f16 v114, v64, s18, 0                          // 0000001500DC: CC210072 02002540
	v_fma_mixhi_f16 v114, v65, s18, 0                          // 0000001500E4: CC220072 02002541
	ds_load_b128 v[62:65], v78 offset:25456                    // 0000001500EC: DBFC6370 3E00004E
	v_fma_mixlo_f16 v101, v103, s18, 0                         // 0000001500F4: CC210065 02002567
	v_fma_mixlo_f16 v103, v107, s18, 0                         // 0000001500FC: CC210067 0200256B
	v_fma_mixhi_f16 v103, v108, s18, 0                         // 000000150104: CC220067 0200256C
	v_fma_mixlo_f16 v107, v115, s18, 0                         // 00000015010C: CC21006B 02002573
	v_fma_mixhi_f16 v107, v116, s18, 0                         // 000000150114: CC22006B 02002574
	v_fma_mixlo_f16 v108, v117, s18, 0                         // 00000015011C: CC21006C 02002575
	v_fma_mixhi_f16 v108, v118, s18, 0                         // 000000150124: CC22006C 02002576
	v_fma_mixlo_f16 v115, v123, s18, 0                         // 00000015012C: CC210073 0200257B
	v_fma_mixhi_f16 v115, v124, s18, 0                         // 000000150134: CC220073 0200257C
	v_fma_mixlo_f16 v116, v125, s18, 0                         // 00000015013C: CC210074 0200257D
	v_fma_mixhi_f16 v116, v126, s18, 0                         // 000000150144: CC220074 0200257E
	v_fma_mixlo_f16 v117, v127, s18, 0                         // 00000015014C: CC210075 0200257F
	v_fma_mixhi_f16 v117, v128, s18, 0                         // 000000150154: CC220075 02002580
	v_fma_mixlo_f16 v118, v129, s18, 0                         // 00000015015C: CC210076 02002581
	v_fma_mixhi_f16 v118, v130, s18, 0                         // 000000150164: CC220076 02002582
	s_waitcnt lgkmcnt(2)                                       // 00000015016C: BF89FC27
	v_fma_mixlo_f16 v119, v119, s18, 0                         // 000000150170: CC210077 02002577
	v_fma_mixhi_f16 v119, v120, s18, 0                         // 000000150178: CC220077 02002578
	v_fma_mixlo_f16 v120, v121, s18, 0                         // 000000150180: CC210078 02002579
	v_fma_mixhi_f16 v120, v122, s18, 0                         // 000000150188: CC220078 0200257A
	v_fma_mixlo_f16 v121, v131, s18, 0                         // 000000150190: CC210079 02002583
	v_fma_mixhi_f16 v121, v132, s18, 0                         // 000000150198: CC220079 02002584
	v_fma_mixlo_f16 v122, v133, s18, 0                         // 0000001501A0: CC21007A 02002585
	v_fma_mixhi_f16 v122, v134, s18, 0                         // 0000001501A8: CC22007A 02002586
	s_waitcnt lgkmcnt(1)                                       // 0000001501B0: BF89FC17
	v_fma_mixlo_f16 v123, v50, s18, 0                          // 0000001501B4: CC21007B 02002532
	v_fma_mixhi_f16 v123, v51, s18, 0                          // 0000001501BC: CC22007B 02002533
	v_fma_mixlo_f16 v124, v52, s18, 0                          // 0000001501C4: CC21007C 02002534
	v_fma_mixhi_f16 v124, v53, s18, 0                          // 0000001501CC: CC22007C 02002535
	s_waitcnt lgkmcnt(0)                                       // 0000001501D4: BF89FC07
	v_fma_mixlo_f16 v125, v62, s18, 0                          // 0000001501D8: CC21007D 0200253E
	v_fma_mixhi_f16 v125, v63, s18, 0                          // 0000001501E0: CC22007D 0200253F
	v_fma_mixlo_f16 v126, v64, s18, 0                          // 0000001501E8: CC21007E 02002540
	v_fma_mixhi_f16 v126, v65, s18, 0                          // 0000001501F0: CC22007E 02002541
	.long 0x7f6a3880                                           // 0000001501F8: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[54:61], v[95:102], v[42:49]// 0000001501FC: CC40402A 1CAABF36
	v_wmma_f32_16x16x16_f16 v[34:41], v[54:61], v[103:110], v[34:41]// 000000150204: CC404022 1C8ACF36
	v_wmma_f32_16x16x16_f16 v[26:33], v[54:61], v[111:118], v[26:33]// 00000015020C: CC40401A 1C6ADF36
	v_wmma_f32_16x16x16_f16 v[18:25], v[54:61], v[119:126], v[18:25]// 000000150214: CC404012 1C4AEF36
	.long 0x7f6639b5                                           // 00000015021C: 7F6639B5
	.long 0x7e6639b5                                           // 000000150220: 7E6639B5
	.long 0x7f6439b5                                           // 000000150224: 7F6439B5
	.long 0x7e6439b5                                           // 000000150228: 7E6439B5
	s_and_saveexec_b32 s11, s0                                 // 00000015022C: BE8B2000
	s_cbranch_execz 11                                         // 000000150230: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3960>
	global_load_b128 v[54:57], v[4:5], off offset:128          // 000000150234: DC5E0080 367C0004
	s_waitcnt vmcnt(0)                                         // 00000015023C: BF8903F7
	v_fma_mixlo_f16 v50, v54, s18, 0                           // 000000150240: CC210032 02002536
	v_fma_mixhi_f16 v50, v55, s18, 0                           // 000000150248: CC220032 02002537
	v_fma_mixlo_f16 v51, v56, s18, 0                           // 000000150250: CC210033 02002538
	v_fma_mixhi_f16 v51, v57, s18, 0                           // 000000150258: CC220033 02002539
	s_or_b32 exec_lo, exec_lo, s11                             // 000000150260: 8C7E0B7E
	.long 0x7e6a39b5                                           // 000000150264: 7E6A39B5
	.long 0x7f6839b5                                           // 000000150268: 7F6839B5
	.long 0x7e6839b5                                           // 00000015026C: 7E6839B5
	s_and_saveexec_b32 s11, s0                                 // 000000150270: BE8B2000
	s_cbranch_execz 11                                         // 000000150274: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x39a4>
	global_load_b128 v[52:55], v[4:5], off offset:144          // 000000150278: DC5E0090 347C0004
	s_waitcnt vmcnt(0)                                         // 000000150280: BF8903F7
	v_fma_mixlo_f16 v52, v52, s18, 0                           // 000000150284: CC210034 02002534
	v_fma_mixhi_f16 v52, v53, s18, 0                           // 00000015028C: CC220034 02002535
	v_fma_mixlo_f16 v53, v54, s18, 0                           // 000000150294: CC210035 02002536
	v_fma_mixhi_f16 v53, v55, s18, 0                           // 00000015029C: CC220035 02002537
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001502A4: 8C7E0B7E
	.long 0x7f723880                                           // 0000001502A8: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001502AC: BF870001
	.long 0x7f6e39b9                                           // 0000001502B0: 7F6E39B9
	.long 0x7e6e39b9                                           // 0000001502B4: 7E6E39B9
	.long 0x7f6c39b9                                           // 0000001502B8: 7F6C39B9
	.long 0x7e6c39b9                                           // 0000001502BC: 7E6C39B9
	s_and_saveexec_b32 s11, s0                                 // 0000001502C0: BE8B2000
	s_cbranch_execz 11                                         // 0000001502C4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x39f4>
	global_load_b128 v[58:61], v[4:5], off offset:160          // 0000001502C8: DC5E00A0 3A7C0004
	s_waitcnt vmcnt(0)                                         // 0000001502D0: BF8903F7
	v_fma_mixlo_f16 v54, v58, s18, 0                           // 0000001502D4: CC210036 0200253A
	v_fma_mixhi_f16 v54, v59, s18, 0                           // 0000001502DC: CC220036 0200253B
	v_fma_mixlo_f16 v55, v60, s18, 0                           // 0000001502E4: CC210037 0200253C
	v_fma_mixhi_f16 v55, v61, s18, 0                           // 0000001502EC: CC220037 0200253D
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001502F4: 8C7E0B7E
	.long 0x7e7239b9                                           // 0000001502F8: 7E7239B9
	.long 0x7f7039b9                                           // 0000001502FC: 7F7039B9
	.long 0x7e7039b9                                           // 000000150300: 7E7039B9
	s_and_saveexec_b32 s11, s0                                 // 000000150304: BE8B2000
	s_cbranch_execz 11                                         // 000000150308: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a38>
	global_load_b128 v[56:59], v[4:5], off offset:176          // 00000015030C: DC5E00B0 387C0004
	s_waitcnt vmcnt(0)                                         // 000000150314: BF8903F7
	v_fma_mixlo_f16 v56, v56, s18, 0                           // 000000150318: CC210038 02002538
	v_fma_mixhi_f16 v56, v57, s18, 0                           // 000000150320: CC220038 02002539
	v_fma_mixlo_f16 v57, v58, s18, 0                           // 000000150328: CC210039 0200253A
	v_fma_mixhi_f16 v57, v59, s18, 0                           // 000000150330: CC220039 0200253B
	s_or_b32 exec_lo, exec_lo, s11                             // 000000150338: 8C7E0B7E
	ds_load_b128 v[59:62], v78 offset:128                      // 00000015033C: DBFC0080 3B00004E
	ds_load_b128 v[63:66], v78 offset:144                      // 000000150344: DBFC0090 3F00004E
	ds_load_b128 v[95:98], v78 offset:160                      // 00000015034C: DBFC00A0 5F00004E
	ds_load_b128 v[99:102], v78 offset:176                     // 000000150354: DBFC00B0 6300004E
	ds_load_b128 v[103:106], v78 offset:8576                   // 00000015035C: DBFC2180 6700004E
	ds_load_b128 v[107:110], v78 offset:8592                   // 000000150364: DBFC2190 6B00004E
	ds_load_b128 v[111:114], v78 offset:8608                   // 00000015036C: DBFC21A0 6F00004E
	ds_load_b128 v[115:118], v78 offset:8624                   // 000000150374: DBFC21B0 7300004E
	ds_load_b128 v[119:122], v78 offset:17024                  // 00000015037C: DBFC4280 7700004E
	ds_load_b128 v[123:126], v78 offset:17040                  // 000000150384: DBFC4290 7B00004E
	.long 0x7f743880                                           // 00000015038C: 7F743880
	ds_load_b128 v[127:130], v78 offset:25488                  // 000000150390: DBFC6390 7F00004E
	s_waitcnt lgkmcnt(10)                                      // 000000150398: BF89FCA7
	v_fma_mixlo_f16 v59, v59, s18, 0                           // 00000015039C: CC21003B 0200253B
	v_fma_mixhi_f16 v59, v60, s18, 0                           // 0000001503A4: CC22003B 0200253C
	v_fma_mixlo_f16 v60, v61, s18, 0                           // 0000001503AC: CC21003C 0200253D
	v_fma_mixhi_f16 v60, v62, s18, 0                           // 0000001503B4: CC22003C 0200253E
	s_waitcnt lgkmcnt(9)                                       // 0000001503BC: BF89FC97
	v_fma_mixlo_f16 v61, v63, s18, 0                           // 0000001503C0: CC21003D 0200253F
	v_fma_mixhi_f16 v61, v64, s18, 0                           // 0000001503C8: CC22003D 02002540
	v_fma_mixlo_f16 v62, v65, s18, 0                           // 0000001503D0: CC21003E 02002541
	v_fma_mixhi_f16 v62, v66, s18, 0                           // 0000001503D8: CC22003E 02002542
	s_waitcnt lgkmcnt(8)                                       // 0000001503E0: BF89FC87
	v_fma_mixlo_f16 v63, v95, s18, 0                           // 0000001503E4: CC21003F 0200255F
	v_fma_mixhi_f16 v63, v96, s18, 0                           // 0000001503EC: CC22003F 02002560
	v_fma_mixlo_f16 v64, v97, s18, 0                           // 0000001503F4: CC210040 02002561
	v_fma_mixhi_f16 v64, v98, s18, 0                           // 0000001503FC: CC220040 02002562
	s_waitcnt lgkmcnt(7)                                       // 000000150404: BF89FC77
	v_fma_mixlo_f16 v65, v99, s18, 0                           // 000000150408: CC210041 02002563
	v_fma_mixhi_f16 v65, v100, s18, 0                          // 000000150410: CC220041 02002564
	v_fma_mixlo_f16 v66, v101, s18, 0                          // 000000150418: CC210042 02002565
	v_fma_mixhi_f16 v66, v102, s18, 0                          // 000000150420: CC220042 02002566
	s_waitcnt lgkmcnt(6)                                       // 000000150428: BF89FC67
	v_fma_mixlo_f16 v95, v103, s18, 0                          // 00000015042C: CC21005F 02002567
	v_fma_mixhi_f16 v95, v104, s18, 0                          // 000000150434: CC22005F 02002568
	v_fma_mixlo_f16 v96, v105, s18, 0                          // 00000015043C: CC210060 02002569
	v_fma_mixhi_f16 v96, v106, s18, 0                          // 000000150444: CC220060 0200256A
	s_waitcnt lgkmcnt(5)                                       // 00000015044C: BF89FC57
	v_fma_mixlo_f16 v97, v107, s18, 0                          // 000000150450: CC210061 0200256B
	v_fma_mixhi_f16 v97, v108, s18, 0                          // 000000150458: CC220061 0200256C
	v_fma_mixlo_f16 v98, v109, s18, 0                          // 000000150460: CC210062 0200256D
	v_fma_mixhi_f16 v98, v110, s18, 0                          // 000000150468: CC220062 0200256E
	s_waitcnt lgkmcnt(4)                                       // 000000150470: BF89FC47
	v_fma_mixlo_f16 v99, v111, s18, 0                          // 000000150474: CC210063 0200256F
	ds_load_b128 v[107:110], v78 offset:17056                  // 00000015047C: DBFC42A0 6B00004E
	v_fma_mixhi_f16 v99, v112, s18, 0                          // 000000150484: CC220063 02002570
	v_fma_mixlo_f16 v100, v113, s18, 0                         // 00000015048C: CC210064 02002571
	v_fma_mixhi_f16 v100, v114, s18, 0                         // 000000150494: CC220064 02002572
	s_waitcnt lgkmcnt(4)                                       // 00000015049C: BF89FC47
	v_fma_mixlo_f16 v101, v115, s18, 0                         // 0000001504A0: CC210065 02002573
	ds_load_b128 v[111:114], v78 offset:17072                  // 0000001504A8: DBFC42B0 6F00004E
	v_fma_mixhi_f16 v101, v116, s18, 0                         // 0000001504B0: CC220065 02002574
	v_fma_mixlo_f16 v102, v117, s18, 0                         // 0000001504B8: CC210066 02002575
	v_fma_mixhi_f16 v102, v118, s18, 0                         // 0000001504C0: CC220066 02002576
	ds_load_b128 v[115:118], v78 offset:25472                  // 0000001504C8: DBFC6380 7300004E
	s_waitcnt lgkmcnt(5)                                       // 0000001504D0: BF89FC57
	v_fma_mixlo_f16 v103, v119, s18, 0                         // 0000001504D4: CC210067 02002577
	v_fma_mixhi_f16 v103, v120, s18, 0                         // 0000001504DC: CC220067 02002578
	v_fma_mixlo_f16 v104, v121, s18, 0                         // 0000001504E4: CC210068 02002579
	v_fma_mixhi_f16 v104, v122, s18, 0                         // 0000001504EC: CC220068 0200257A
	s_waitcnt lgkmcnt(4)                                       // 0000001504F4: BF89FC47
	v_fma_mixlo_f16 v105, v123, s18, 0                         // 0000001504F8: CC210069 0200257B
	v_fma_mixhi_f16 v105, v124, s18, 0                         // 000000150500: CC220069 0200257C
	ds_load_b128 v[119:122], v78 offset:25504                  // 000000150508: DBFC63A0 7700004E
	v_fma_mixlo_f16 v106, v125, s18, 0                         // 000000150510: CC21006A 0200257D
	v_fma_mixhi_f16 v106, v126, s18, 0                         // 000000150518: CC22006A 0200257E
	ds_load_b128 v[123:126], v78 offset:25520                  // 000000150520: DBFC63B0 7B00004E
	s_waitcnt lgkmcnt(4)                                       // 000000150528: BF89FC47
	v_fma_mixlo_f16 v107, v107, s18, 0                         // 00000015052C: CC21006B 0200256B
	v_fma_mixhi_f16 v107, v108, s18, 0                         // 000000150534: CC22006B 0200256C
	v_fma_mixlo_f16 v108, v109, s18, 0                         // 00000015053C: CC21006C 0200256D
	v_fma_mixhi_f16 v108, v110, s18, 0                         // 000000150544: CC22006C 0200256E
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[59:66], v[42:49]// 00000015054C: CC40402A 1CAA7732
	s_waitcnt lgkmcnt(3)                                       // 000000150554: BF89FC37
	v_fma_mixlo_f16 v109, v111, s18, 0                         // 000000150558: CC21006D 0200256F
	v_fma_mixhi_f16 v109, v112, s18, 0                         // 000000150560: CC22006D 02002570
	v_fma_mixlo_f16 v110, v113, s18, 0                         // 000000150568: CC21006E 02002571
	v_fma_mixhi_f16 v110, v114, s18, 0                         // 000000150570: CC22006E 02002572
	s_waitcnt lgkmcnt(2)                                       // 000000150578: BF89FC27
	v_fma_mixlo_f16 v111, v115, s18, 0                         // 00000015057C: CC21006F 02002573
	v_fma_mixhi_f16 v111, v116, s18, 0                         // 000000150584: CC22006F 02002574
	v_fma_mixlo_f16 v112, v117, s18, 0                         // 00000015058C: CC210070 02002575
	v_fma_mixhi_f16 v112, v118, s18, 0                         // 000000150594: CC220070 02002576
	v_fma_mixlo_f16 v113, v127, s18, 0                         // 00000015059C: CC210071 0200257F
	v_fma_mixhi_f16 v113, v128, s18, 0                         // 0000001505A4: CC220071 02002580
	v_fma_mixlo_f16 v114, v129, s18, 0                         // 0000001505AC: CC210072 02002581
	v_fma_mixhi_f16 v114, v130, s18, 0                         // 0000001505B4: CC220072 02002582
	s_waitcnt lgkmcnt(1)                                       // 0000001505BC: BF89FC17
	v_fma_mixlo_f16 v115, v119, s18, 0                         // 0000001505C0: CC210073 02002577
	v_fma_mixhi_f16 v115, v120, s18, 0                         // 0000001505C8: CC220073 02002578
	v_fma_mixlo_f16 v116, v121, s18, 0                         // 0000001505D0: CC210074 02002579
	v_fma_mixhi_f16 v116, v122, s18, 0                         // 0000001505D8: CC220074 0200257A
	s_waitcnt lgkmcnt(0)                                       // 0000001505E0: BF89FC07
	v_fma_mixlo_f16 v117, v123, s18, 0                         // 0000001505E4: CC210075 0200257B
	v_fma_mixhi_f16 v117, v124, s18, 0                         // 0000001505EC: CC220075 0200257C
	v_fma_mixlo_f16 v118, v125, s18, 0                         // 0000001505F4: CC210076 0200257D
	v_fma_mixhi_f16 v118, v126, s18, 0                         // 0000001505FC: CC220076 0200257E
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[95:102], v[34:41]// 000000150604: CC404022 1C8ABF32
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[103:110], v[26:33]// 00000015060C: CC40401A 1C6ACF32
	s_delay_alu instid0(VALU_DEP_3)                            // 000000150614: BF870003
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[111:118], v[18:25]// 000000150618: CC404012 1C4ADF32
	.long 0x7f7039ba                                           // 000000150620: 7F7039BA
	.long 0x7e7039ba                                           // 000000150624: 7E7039BA
	.long 0x7f6e39ba                                           // 000000150628: 7F6E39BA
	.long 0x7e6e39ba                                           // 00000015062C: 7E6E39BA
	s_and_saveexec_b32 s11, s0                                 // 000000150630: BE8B2000
	s_cbranch_execz 11                                         // 000000150634: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d64>
	global_load_b128 v[50:53], v[4:5], off offset:192          // 000000150638: DC5E00C0 327C0004
	s_waitcnt vmcnt(0)                                         // 000000150640: BF8903F7
	v_fma_mixlo_f16 v55, v50, s18, 0                           // 000000150644: CC210037 02002532
	v_fma_mixhi_f16 v55, v51, s18, 0                           // 00000015064C: CC220037 02002533
	v_fma_mixlo_f16 v56, v52, s18, 0                           // 000000150654: CC210038 02002534
	v_fma_mixhi_f16 v56, v53, s18, 0                           // 00000015065C: CC220038 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 000000150664: 8C7E0B7E
	.long 0x7e7439ba                                           // 000000150668: 7E7439BA
	.long 0x7f7239ba                                           // 00000015066C: 7F7239BA
	.long 0x7e7239ba                                           // 000000150670: 7E7239BA
	s_and_saveexec_b32 s11, s0                                 // 000000150674: BE8B2000
	s_cbranch_execz 11                                         // 000000150678: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3da8>
	global_load_b128 v[50:53], v[4:5], off offset:208          // 00000015067C: DC5E00D0 327C0004
	s_waitcnt vmcnt(0)                                         // 000000150684: BF8903F7
	v_fma_mixlo_f16 v57, v50, s18, 0                           // 000000150688: CC210039 02002532
	v_fma_mixhi_f16 v57, v51, s18, 0                           // 000000150690: CC220039 02002533
	v_fma_mixlo_f16 v58, v52, s18, 0                           // 000000150698: CC21003A 02002534
	v_fma_mixhi_f16 v58, v53, s18, 0                           // 0000001506A0: CC22003A 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001506A8: 8C7E0B7E
	.long 0x7f7c3880                                           // 0000001506AC: 7F7C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001506B0: BF870001
	.long 0x7f7839be                                           // 0000001506B4: 7F7839BE
	.long 0x7e7839be                                           // 0000001506B8: 7E7839BE
	.long 0x7f7639be                                           // 0000001506BC: 7F7639BE
	.long 0x7e7639be                                           // 0000001506C0: 7E7639BE
	s_and_saveexec_b32 s11, s0                                 // 0000001506C4: BE8B2000
	s_cbranch_execz 11                                         // 0000001506C8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3df8>
	global_load_b128 v[50:53], v[4:5], off offset:224          // 0000001506CC: DC5E00E0 327C0004
	s_waitcnt vmcnt(0)                                         // 0000001506D4: BF8903F7
	v_fma_mixlo_f16 v59, v50, s18, 0                           // 0000001506D8: CC21003B 02002532
	v_fma_mixhi_f16 v59, v51, s18, 0                           // 0000001506E0: CC22003B 02002533
	v_fma_mixlo_f16 v60, v52, s18, 0                           // 0000001506E8: CC21003C 02002534
	v_fma_mixhi_f16 v60, v53, s18, 0                           // 0000001506F0: CC22003C 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001506F8: 8C7E0B7E
	.long 0x7e7c39be                                           // 0000001506FC: 7E7C39BE
	.long 0x7f7a39be                                           // 000000150700: 7F7A39BE
	.long 0x7e7a39be                                           // 000000150704: 7E7A39BE
	s_and_saveexec_b32 s11, s0                                 // 000000150708: BE8B2000
	s_cbranch_execz 11                                         // 00000015070C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3e3c>
	global_load_b128 v[50:53], v[4:5], off offset:240          // 000000150710: DC5E00F0 327C0004
	s_waitcnt vmcnt(0)                                         // 000000150718: BF8903F7
	v_fma_mixlo_f16 v61, v50, s18, 0                           // 00000015071C: CC21003D 02002532
	v_fma_mixhi_f16 v61, v51, s18, 0                           // 000000150724: CC22003D 02002533
	v_fma_mixlo_f16 v62, v52, s18, 0                           // 00000015072C: CC21003E 02002534
	v_fma_mixhi_f16 v62, v53, s18, 0                           // 000000150734: CC22003E 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015073C: 8C7E0B7E
	ds_load_b128 v[50:53], v78 offset:192                      // 000000150740: DBFC00C0 3200004E
	ds_load_b128 v[63:66], v78 offset:208                      // 000000150748: DBFC00D0 3F00004E
	ds_load_b128 v[99:102], v78 offset:224                     // 000000150750: DBFC00E0 6300004E
	ds_load_b128 v[103:106], v78 offset:240                    // 000000150758: DBFC00F0 6700004E
	ds_load_b128 v[107:110], v78 offset:8640                   // 000000150760: DBFC21C0 6B00004E
	ds_load_b128 v[111:114], v78 offset:8656                   // 000000150768: DBFC21D0 6F00004E
	ds_load_b128 v[115:118], v78 offset:8672                   // 000000150770: DBFC21E0 7300004E
	ds_load_b128 v[119:122], v78 offset:8688                   // 000000150778: DBFC21F0 7700004E
	ds_load_b128 v[123:126], v78 offset:17120                  // 000000150780: DBFC42E0 7B00004E
	ds_load_b128 v[127:130], v78 offset:17136                  // 000000150788: DBFC42F0 7F00004E
	ds_load_b128 v[131:134], v78 offset:25552                  // 000000150790: DBFC63D0 8300004E
	s_waitcnt lgkmcnt(10)                                      // 000000150798: BF89FCA7
	v_fma_mixlo_f16 v95, v50, s18, 0                           // 00000015079C: CC21005F 02002532
	v_fma_mixhi_f16 v95, v51, s18, 0                           // 0000001507A4: CC22005F 02002533
	v_fma_mixlo_f16 v96, v52, s18, 0                           // 0000001507AC: CC210060 02002534
	v_fma_mixhi_f16 v96, v53, s18, 0                           // 0000001507B4: CC220060 02002535
	s_waitcnt lgkmcnt(9)                                       // 0000001507BC: BF89FC97
	v_fma_mixlo_f16 v97, v63, s18, 0                           // 0000001507C0: CC210061 0200253F
	v_fma_mixhi_f16 v97, v64, s18, 0                           // 0000001507C8: CC220061 02002540
	v_fma_mixlo_f16 v98, v65, s18, 0                           // 0000001507D0: CC210062 02002541
	v_fma_mixhi_f16 v98, v66, s18, 0                           // 0000001507D8: CC220062 02002542
	ds_load_b128 v[50:53], v78 offset:17088                    // 0000001507E0: DBFC42C0 3200004E
	ds_load_b128 v[63:66], v78 offset:17104                    // 0000001507E8: DBFC42D0 3F00004E
	s_waitcnt lgkmcnt(10)                                      // 0000001507F0: BF89FCA7
	v_fma_mixlo_f16 v99, v99, s18, 0                           // 0000001507F4: CC210063 02002563
	v_fma_mixhi_f16 v99, v100, s18, 0                          // 0000001507FC: CC220063 02002564
	v_fma_mixlo_f16 v100, v101, s18, 0                         // 000000150804: CC210064 02002565
	v_fma_mixhi_f16 v100, v102, s18, 0                         // 00000015080C: CC220064 02002566
	s_waitcnt lgkmcnt(9)                                       // 000000150814: BF89FC97
	v_fma_mixhi_f16 v101, v104, s18, 0                         // 000000150818: CC220065 02002568
	v_fma_mixlo_f16 v102, v105, s18, 0                         // 000000150820: CC210066 02002569
	v_fma_mixhi_f16 v102, v106, s18, 0                         // 000000150828: CC220066 0200256A
	s_waitcnt lgkmcnt(8)                                       // 000000150830: BF89FC87
	v_fma_mixlo_f16 v104, v109, s18, 0                         // 000000150834: CC210068 0200256D
	v_fma_mixhi_f16 v104, v110, s18, 0                         // 00000015083C: CC220068 0200256E
	s_waitcnt lgkmcnt(7)                                       // 000000150844: BF89FC77
	v_fma_mixlo_f16 v105, v111, s18, 0                         // 000000150848: CC210069 0200256F
	v_fma_mixhi_f16 v105, v112, s18, 0                         // 000000150850: CC220069 02002570
	v_fma_mixlo_f16 v106, v113, s18, 0                         // 000000150858: CC21006A 02002571
	v_fma_mixhi_f16 v106, v114, s18, 0                         // 000000150860: CC22006A 02002572
	s_waitcnt lgkmcnt(5)                                       // 000000150868: BF89FC57
	v_fma_mixlo_f16 v109, v119, s18, 0                         // 00000015086C: CC21006D 02002577
	v_fma_mixhi_f16 v109, v120, s18, 0                         // 000000150874: CC22006D 02002578
	v_fma_mixlo_f16 v110, v121, s18, 0                         // 00000015087C: CC21006E 02002579
	v_fma_mixhi_f16 v110, v122, s18, 0                         // 000000150884: CC22006E 0200257A
	ds_load_b128 v[119:122], v78 offset:25536                  // 00000015088C: DBFC63C0 7700004E
	s_waitcnt lgkmcnt(2)                                       // 000000150894: BF89FC27
	v_fma_mixlo_f16 v111, v50, s18, 0                          // 000000150898: CC21006F 02002532
	v_fma_mixhi_f16 v111, v51, s18, 0                          // 0000001508A0: CC22006F 02002533
	v_fma_mixlo_f16 v112, v52, s18, 0                          // 0000001508A8: CC210070 02002534
	v_fma_mixhi_f16 v112, v53, s18, 0                          // 0000001508B0: CC220070 02002535
	s_waitcnt lgkmcnt(1)                                       // 0000001508B8: BF89FC17
	v_fma_mixlo_f16 v113, v63, s18, 0                          // 0000001508BC: CC210071 0200253F
	v_fma_mixhi_f16 v113, v64, s18, 0                          // 0000001508C4: CC220071 02002540
	ds_load_b128 v[50:53], v78 offset:25568                    // 0000001508CC: DBFC63E0 3200004E
	v_fma_mixlo_f16 v114, v65, s18, 0                          // 0000001508D4: CC210072 02002541
	v_fma_mixhi_f16 v114, v66, s18, 0                          // 0000001508DC: CC220072 02002542
	ds_load_b128 v[63:66], v78 offset:25584                    // 0000001508E4: DBFC63F0 3F00004E
	v_fma_mixlo_f16 v101, v103, s18, 0                         // 0000001508EC: CC210065 02002567
	v_fma_mixlo_f16 v103, v107, s18, 0                         // 0000001508F4: CC210067 0200256B
	v_fma_mixhi_f16 v103, v108, s18, 0                         // 0000001508FC: CC220067 0200256C
	v_fma_mixlo_f16 v107, v115, s18, 0                         // 000000150904: CC21006B 02002573
	v_fma_mixhi_f16 v107, v116, s18, 0                         // 00000015090C: CC22006B 02002574
	v_fma_mixlo_f16 v108, v117, s18, 0                         // 000000150914: CC21006C 02002575
	v_fma_mixhi_f16 v108, v118, s18, 0                         // 00000015091C: CC22006C 02002576
	v_fma_mixlo_f16 v115, v123, s18, 0                         // 000000150924: CC210073 0200257B
	v_fma_mixhi_f16 v115, v124, s18, 0                         // 00000015092C: CC220073 0200257C
	v_fma_mixlo_f16 v116, v125, s18, 0                         // 000000150934: CC210074 0200257D
	v_fma_mixhi_f16 v116, v126, s18, 0                         // 00000015093C: CC220074 0200257E
	v_fma_mixlo_f16 v117, v127, s18, 0                         // 000000150944: CC210075 0200257F
	v_fma_mixhi_f16 v117, v128, s18, 0                         // 00000015094C: CC220075 02002580
	v_fma_mixlo_f16 v118, v129, s18, 0                         // 000000150954: CC210076 02002581
	v_fma_mixhi_f16 v118, v130, s18, 0                         // 00000015095C: CC220076 02002582
	s_waitcnt lgkmcnt(2)                                       // 000000150964: BF89FC27
	v_fma_mixlo_f16 v119, v119, s18, 0                         // 000000150968: CC210077 02002577
	v_fma_mixhi_f16 v119, v120, s18, 0                         // 000000150970: CC220077 02002578
	v_fma_mixlo_f16 v120, v121, s18, 0                         // 000000150978: CC210078 02002579
	v_fma_mixhi_f16 v120, v122, s18, 0                         // 000000150980: CC220078 0200257A
	v_fma_mixlo_f16 v121, v131, s18, 0                         // 000000150988: CC210079 02002583
	v_fma_mixhi_f16 v121, v132, s18, 0                         // 000000150990: CC220079 02002584
	v_fma_mixlo_f16 v122, v133, s18, 0                         // 000000150998: CC21007A 02002585
	v_fma_mixhi_f16 v122, v134, s18, 0                         // 0000001509A0: CC22007A 02002586
	s_waitcnt lgkmcnt(1)                                       // 0000001509A8: BF89FC17
	v_fma_mixlo_f16 v123, v50, s18, 0                          // 0000001509AC: CC21007B 02002532
	v_fma_mixhi_f16 v123, v51, s18, 0                          // 0000001509B4: CC22007B 02002533
	v_fma_mixlo_f16 v124, v52, s18, 0                          // 0000001509BC: CC21007C 02002534
	v_fma_mixhi_f16 v124, v53, s18, 0                          // 0000001509C4: CC22007C 02002535
	s_waitcnt lgkmcnt(0)                                       // 0000001509CC: BF89FC07
	v_fma_mixlo_f16 v125, v63, s18, 0                          // 0000001509D0: CC21007D 0200253F
	v_fma_mixhi_f16 v125, v64, s18, 0                          // 0000001509D8: CC22007D 02002540
	v_fma_mixlo_f16 v126, v65, s18, 0                          // 0000001509E0: CC21007E 02002541
	v_fma_mixhi_f16 v126, v66, s18, 0                          // 0000001509E8: CC22007E 02002542
	.long 0x7f6a3880                                           // 0000001509F0: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[55:62], v[95:102], v[42:49]// 0000001509F4: CC40402A 1CAABF37
	v_wmma_f32_16x16x16_f16 v[34:41], v[55:62], v[103:110], v[34:41]// 0000001509FC: CC404022 1C8ACF37
	v_wmma_f32_16x16x16_f16 v[26:33], v[55:62], v[111:118], v[26:33]// 000000150A04: CC40401A 1C6ADF37
	v_wmma_f32_16x16x16_f16 v[18:25], v[55:62], v[119:126], v[18:25]// 000000150A0C: CC404012 1C4AEF37
	.long 0x7f6639b5                                           // 000000150A14: 7F6639B5
	.long 0x7e6639b5                                           // 000000150A18: 7E6639B5
	.long 0x7f6439b5                                           // 000000150A1C: 7F6439B5
	.long 0x7e6439b5                                           // 000000150A20: 7E6439B5
	s_and_saveexec_b32 s11, s0                                 // 000000150A24: BE8B2000
	s_cbranch_execz 11                                         // 000000150A28: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4158>
	global_load_b128 v[54:57], v[4:5], off offset:256          // 000000150A2C: DC5E0100 367C0004
	s_waitcnt vmcnt(0)                                         // 000000150A34: BF8903F7
	v_fma_mixlo_f16 v50, v54, s18, 0                           // 000000150A38: CC210032 02002536
	v_fma_mixhi_f16 v50, v55, s18, 0                           // 000000150A40: CC220032 02002537
	v_fma_mixlo_f16 v51, v56, s18, 0                           // 000000150A48: CC210033 02002538
	v_fma_mixhi_f16 v51, v57, s18, 0                           // 000000150A50: CC220033 02002539
	s_or_b32 exec_lo, exec_lo, s11                             // 000000150A58: 8C7E0B7E
	.long 0x7e6a39b5                                           // 000000150A5C: 7E6A39B5
	.long 0x7f6839b5                                           // 000000150A60: 7F6839B5
	.long 0x7e6839b5                                           // 000000150A64: 7E6839B5
	s_and_saveexec_b32 s11, s0                                 // 000000150A68: BE8B2000
	s_cbranch_execz 11                                         // 000000150A6C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x419c>
	global_load_b128 v[52:55], v[4:5], off offset:272          // 000000150A70: DC5E0110 347C0004
	s_waitcnt vmcnt(0)                                         // 000000150A78: BF8903F7
	v_fma_mixlo_f16 v52, v52, s18, 0                           // 000000150A7C: CC210034 02002534
	v_fma_mixhi_f16 v52, v53, s18, 0                           // 000000150A84: CC220034 02002535
	v_fma_mixlo_f16 v53, v54, s18, 0                           // 000000150A8C: CC210035 02002536
	v_fma_mixhi_f16 v53, v55, s18, 0                           // 000000150A94: CC220035 02002537
	s_or_b32 exec_lo, exec_lo, s11                             // 000000150A9C: 8C7E0B7E
	.long 0x7f723880                                           // 000000150AA0: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000150AA4: BF870001
	.long 0x7f6e39b9                                           // 000000150AA8: 7F6E39B9
	.long 0x7e6e39b9                                           // 000000150AAC: 7E6E39B9
	.long 0x7f6c39b9                                           // 000000150AB0: 7F6C39B9
	.long 0x7e6c39b9                                           // 000000150AB4: 7E6C39B9
	s_and_saveexec_b32 s11, s0                                 // 000000150AB8: BE8B2000
	s_cbranch_execz 11                                         // 000000150ABC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41ec>
	global_load_b128 v[58:61], v[4:5], off offset:288          // 000000150AC0: DC5E0120 3A7C0004
	s_waitcnt vmcnt(0)                                         // 000000150AC8: BF8903F7
	v_fma_mixlo_f16 v54, v58, s18, 0                           // 000000150ACC: CC210036 0200253A
	v_fma_mixhi_f16 v54, v59, s18, 0                           // 000000150AD4: CC220036 0200253B
	v_fma_mixlo_f16 v55, v60, s18, 0                           // 000000150ADC: CC210037 0200253C
	v_fma_mixhi_f16 v55, v61, s18, 0                           // 000000150AE4: CC220037 0200253D
	s_or_b32 exec_lo, exec_lo, s11                             // 000000150AEC: 8C7E0B7E
	.long 0x7e7239b9                                           // 000000150AF0: 7E7239B9
	.long 0x7f7039b9                                           // 000000150AF4: 7F7039B9
	.long 0x7e7039b9                                           // 000000150AF8: 7E7039B9
	s_and_saveexec_b32 s11, s0                                 // 000000150AFC: BE8B2000
	s_cbranch_execz 11                                         // 000000150B00: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4230>
	global_load_b128 v[56:59], v[4:5], off offset:304          // 000000150B04: DC5E0130 387C0004
	s_waitcnt vmcnt(0)                                         // 000000150B0C: BF8903F7
	v_fma_mixlo_f16 v56, v56, s18, 0                           // 000000150B10: CC210038 02002538
	v_fma_mixhi_f16 v56, v57, s18, 0                           // 000000150B18: CC220038 02002539
	v_fma_mixlo_f16 v57, v58, s18, 0                           // 000000150B20: CC210039 0200253A
	v_fma_mixhi_f16 v57, v59, s18, 0                           // 000000150B28: CC220039 0200253B
	s_or_b32 exec_lo, exec_lo, s11                             // 000000150B30: 8C7E0B7E
	ds_load_b128 v[59:62], v78 offset:256                      // 000000150B34: DBFC0100 3B00004E
	ds_load_b128 v[63:66], v78 offset:272                      // 000000150B3C: DBFC0110 3F00004E
	ds_load_b128 v[95:98], v78 offset:288                      // 000000150B44: DBFC0120 5F00004E
	ds_load_b128 v[99:102], v78 offset:304                     // 000000150B4C: DBFC0130 6300004E
	ds_load_b128 v[103:106], v78 offset:8704                   // 000000150B54: DBFC2200 6700004E
	ds_load_b128 v[107:110], v78 offset:8720                   // 000000150B5C: DBFC2210 6B00004E
	ds_load_b128 v[111:114], v78 offset:8736                   // 000000150B64: DBFC2220 6F00004E
	ds_load_b128 v[115:118], v78 offset:8752                   // 000000150B6C: DBFC2230 7300004E
	ds_load_b128 v[119:122], v78 offset:17152                  // 000000150B74: DBFC4300 7700004E
	ds_load_b128 v[123:126], v78 offset:17168                  // 000000150B7C: DBFC4310 7B00004E
	.long 0x7f743880                                           // 000000150B84: 7F743880
	ds_load_b128 v[127:130], v78 offset:25616                  // 000000150B88: DBFC6410 7F00004E
	s_waitcnt lgkmcnt(10)                                      // 000000150B90: BF89FCA7
	v_fma_mixlo_f16 v59, v59, s18, 0                           // 000000150B94: CC21003B 0200253B
	v_fma_mixhi_f16 v59, v60, s18, 0                           // 000000150B9C: CC22003B 0200253C
	v_fma_mixlo_f16 v60, v61, s18, 0                           // 000000150BA4: CC21003C 0200253D
	v_fma_mixhi_f16 v60, v62, s18, 0                           // 000000150BAC: CC22003C 0200253E
	s_waitcnt lgkmcnt(9)                                       // 000000150BB4: BF89FC97
	v_fma_mixlo_f16 v61, v63, s18, 0                           // 000000150BB8: CC21003D 0200253F
	v_fma_mixhi_f16 v61, v64, s18, 0                           // 000000150BC0: CC22003D 02002540
	v_fma_mixlo_f16 v62, v65, s18, 0                           // 000000150BC8: CC21003E 02002541
	v_fma_mixhi_f16 v62, v66, s18, 0                           // 000000150BD0: CC22003E 02002542
	s_waitcnt lgkmcnt(8)                                       // 000000150BD8: BF89FC87
	v_fma_mixlo_f16 v63, v95, s18, 0                           // 000000150BDC: CC21003F 0200255F
	v_fma_mixhi_f16 v63, v96, s18, 0                           // 000000150BE4: CC22003F 02002560
	v_fma_mixlo_f16 v64, v97, s18, 0                           // 000000150BEC: CC210040 02002561
	v_fma_mixhi_f16 v64, v98, s18, 0                           // 000000150BF4: CC220040 02002562
	s_waitcnt lgkmcnt(7)                                       // 000000150BFC: BF89FC77
	v_fma_mixlo_f16 v65, v99, s18, 0                           // 000000150C00: CC210041 02002563
	v_fma_mixhi_f16 v65, v100, s18, 0                          // 000000150C08: CC220041 02002564
	v_fma_mixlo_f16 v66, v101, s18, 0                          // 000000150C10: CC210042 02002565
	v_fma_mixhi_f16 v66, v102, s18, 0                          // 000000150C18: CC220042 02002566
	s_waitcnt lgkmcnt(6)                                       // 000000150C20: BF89FC67
	v_fma_mixlo_f16 v95, v103, s18, 0                          // 000000150C24: CC21005F 02002567
	v_fma_mixhi_f16 v95, v104, s18, 0                          // 000000150C2C: CC22005F 02002568
	v_fma_mixlo_f16 v96, v105, s18, 0                          // 000000150C34: CC210060 02002569
	v_fma_mixhi_f16 v96, v106, s18, 0                          // 000000150C3C: CC220060 0200256A
	s_waitcnt lgkmcnt(5)                                       // 000000150C44: BF89FC57
	v_fma_mixlo_f16 v97, v107, s18, 0                          // 000000150C48: CC210061 0200256B
	v_fma_mixhi_f16 v97, v108, s18, 0                          // 000000150C50: CC220061 0200256C
	v_fma_mixlo_f16 v98, v109, s18, 0                          // 000000150C58: CC210062 0200256D
	v_fma_mixhi_f16 v98, v110, s18, 0                          // 000000150C60: CC220062 0200256E
	s_waitcnt lgkmcnt(4)                                       // 000000150C68: BF89FC47
	v_fma_mixlo_f16 v99, v111, s18, 0                          // 000000150C6C: CC210063 0200256F
	ds_load_b128 v[107:110], v78 offset:17184                  // 000000150C74: DBFC4320 6B00004E
	v_fma_mixhi_f16 v99, v112, s18, 0                          // 000000150C7C: CC220063 02002570
	v_fma_mixlo_f16 v100, v113, s18, 0                         // 000000150C84: CC210064 02002571
	v_fma_mixhi_f16 v100, v114, s18, 0                         // 000000150C8C: CC220064 02002572
	s_waitcnt lgkmcnt(4)                                       // 000000150C94: BF89FC47
	v_fma_mixlo_f16 v101, v115, s18, 0                         // 000000150C98: CC210065 02002573
	ds_load_b128 v[111:114], v78 offset:17200                  // 000000150CA0: DBFC4330 6F00004E
	v_fma_mixhi_f16 v101, v116, s18, 0                         // 000000150CA8: CC220065 02002574
	v_fma_mixlo_f16 v102, v117, s18, 0                         // 000000150CB0: CC210066 02002575
	v_fma_mixhi_f16 v102, v118, s18, 0                         // 000000150CB8: CC220066 02002576
	ds_load_b128 v[115:118], v78 offset:25600                  // 000000150CC0: DBFC6400 7300004E
	s_waitcnt lgkmcnt(5)                                       // 000000150CC8: BF89FC57
	v_fma_mixlo_f16 v103, v119, s18, 0                         // 000000150CCC: CC210067 02002577
	v_fma_mixhi_f16 v103, v120, s18, 0                         // 000000150CD4: CC220067 02002578
	v_fma_mixlo_f16 v104, v121, s18, 0                         // 000000150CDC: CC210068 02002579
	v_fma_mixhi_f16 v104, v122, s18, 0                         // 000000150CE4: CC220068 0200257A
	s_waitcnt lgkmcnt(4)                                       // 000000150CEC: BF89FC47
	v_fma_mixlo_f16 v105, v123, s18, 0                         // 000000150CF0: CC210069 0200257B
	v_fma_mixhi_f16 v105, v124, s18, 0                         // 000000150CF8: CC220069 0200257C
	ds_load_b128 v[119:122], v78 offset:25632                  // 000000150D00: DBFC6420 7700004E
	v_fma_mixlo_f16 v106, v125, s18, 0                         // 000000150D08: CC21006A 0200257D
	v_fma_mixhi_f16 v106, v126, s18, 0                         // 000000150D10: CC22006A 0200257E
	ds_load_b128 v[123:126], v78 offset:25648                  // 000000150D18: DBFC6430 7B00004E
	s_waitcnt lgkmcnt(4)                                       // 000000150D20: BF89FC47
	v_fma_mixlo_f16 v107, v107, s18, 0                         // 000000150D24: CC21006B 0200256B
	v_fma_mixhi_f16 v107, v108, s18, 0                         // 000000150D2C: CC22006B 0200256C
	v_fma_mixlo_f16 v108, v109, s18, 0                         // 000000150D34: CC21006C 0200256D
	v_fma_mixhi_f16 v108, v110, s18, 0                         // 000000150D3C: CC22006C 0200256E
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[59:66], v[42:49]// 000000150D44: CC40402A 1CAA7732
	s_waitcnt lgkmcnt(3)                                       // 000000150D4C: BF89FC37
	v_fma_mixlo_f16 v109, v111, s18, 0                         // 000000150D50: CC21006D 0200256F
	v_fma_mixhi_f16 v109, v112, s18, 0                         // 000000150D58: CC22006D 02002570
	v_fma_mixlo_f16 v110, v113, s18, 0                         // 000000150D60: CC21006E 02002571
	v_fma_mixhi_f16 v110, v114, s18, 0                         // 000000150D68: CC22006E 02002572
	s_waitcnt lgkmcnt(2)                                       // 000000150D70: BF89FC27
	v_fma_mixlo_f16 v111, v115, s18, 0                         // 000000150D74: CC21006F 02002573
	v_fma_mixhi_f16 v111, v116, s18, 0                         // 000000150D7C: CC22006F 02002574
	v_fma_mixlo_f16 v112, v117, s18, 0                         // 000000150D84: CC210070 02002575
	v_fma_mixhi_f16 v112, v118, s18, 0                         // 000000150D8C: CC220070 02002576
	v_fma_mixlo_f16 v113, v127, s18, 0                         // 000000150D94: CC210071 0200257F
	v_fma_mixhi_f16 v113, v128, s18, 0                         // 000000150D9C: CC220071 02002580
	v_fma_mixlo_f16 v114, v129, s18, 0                         // 000000150DA4: CC210072 02002581
	v_fma_mixhi_f16 v114, v130, s18, 0                         // 000000150DAC: CC220072 02002582
	s_waitcnt lgkmcnt(1)                                       // 000000150DB4: BF89FC17
	v_fma_mixlo_f16 v115, v119, s18, 0                         // 000000150DB8: CC210073 02002577
	v_fma_mixhi_f16 v115, v120, s18, 0                         // 000000150DC0: CC220073 02002578
	v_fma_mixlo_f16 v116, v121, s18, 0                         // 000000150DC8: CC210074 02002579
	v_fma_mixhi_f16 v116, v122, s18, 0                         // 000000150DD0: CC220074 0200257A
	s_waitcnt lgkmcnt(0)                                       // 000000150DD8: BF89FC07
	v_fma_mixlo_f16 v117, v123, s18, 0                         // 000000150DDC: CC210075 0200257B
	v_fma_mixhi_f16 v117, v124, s18, 0                         // 000000150DE4: CC220075 0200257C
	v_fma_mixlo_f16 v118, v125, s18, 0                         // 000000150DEC: CC210076 0200257D
	v_fma_mixhi_f16 v118, v126, s18, 0                         // 000000150DF4: CC220076 0200257E
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[95:102], v[34:41]// 000000150DFC: CC404022 1C8ABF32
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[103:110], v[26:33]// 000000150E04: CC40401A 1C6ACF32
	s_delay_alu instid0(VALU_DEP_3)                            // 000000150E0C: BF870003
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[111:118], v[18:25]// 000000150E10: CC404012 1C4ADF32
	.long 0x7f7039ba                                           // 000000150E18: 7F7039BA
	.long 0x7e7039ba                                           // 000000150E1C: 7E7039BA
	.long 0x7f6e39ba                                           // 000000150E20: 7F6E39BA
	.long 0x7e6e39ba                                           // 000000150E24: 7E6E39BA
	s_and_saveexec_b32 s11, s0                                 // 000000150E28: BE8B2000
	s_cbranch_execz 11                                         // 000000150E2C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x455c>
	global_load_b128 v[50:53], v[4:5], off offset:320          // 000000150E30: DC5E0140 327C0004
	s_waitcnt vmcnt(0)                                         // 000000150E38: BF8903F7
	v_fma_mixlo_f16 v55, v50, s18, 0                           // 000000150E3C: CC210037 02002532
	v_fma_mixhi_f16 v55, v51, s18, 0                           // 000000150E44: CC220037 02002533
	v_fma_mixlo_f16 v56, v52, s18, 0                           // 000000150E4C: CC210038 02002534
	v_fma_mixhi_f16 v56, v53, s18, 0                           // 000000150E54: CC220038 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 000000150E5C: 8C7E0B7E
	.long 0x7e7439ba                                           // 000000150E60: 7E7439BA
	.long 0x7f7239ba                                           // 000000150E64: 7F7239BA
	.long 0x7e7239ba                                           // 000000150E68: 7E7239BA
	s_and_saveexec_b32 s11, s0                                 // 000000150E6C: BE8B2000
	s_cbranch_execz 11                                         // 000000150E70: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x45a0>
	global_load_b128 v[50:53], v[4:5], off offset:336          // 000000150E74: DC5E0150 327C0004
	s_waitcnt vmcnt(0)                                         // 000000150E7C: BF8903F7
	v_fma_mixlo_f16 v57, v50, s18, 0                           // 000000150E80: CC210039 02002532
	v_fma_mixhi_f16 v57, v51, s18, 0                           // 000000150E88: CC220039 02002533
	v_fma_mixlo_f16 v58, v52, s18, 0                           // 000000150E90: CC21003A 02002534
	v_fma_mixhi_f16 v58, v53, s18, 0                           // 000000150E98: CC22003A 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 000000150EA0: 8C7E0B7E
	.long 0x7f7c3880                                           // 000000150EA4: 7F7C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000150EA8: BF870001
	.long 0x7f7839be                                           // 000000150EAC: 7F7839BE
	.long 0x7e7839be                                           // 000000150EB0: 7E7839BE
	.long 0x7f7639be                                           // 000000150EB4: 7F7639BE
	.long 0x7e7639be                                           // 000000150EB8: 7E7639BE
	s_and_saveexec_b32 s11, s0                                 // 000000150EBC: BE8B2000
	s_cbranch_execz 11                                         // 000000150EC0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x45f0>
	global_load_b128 v[50:53], v[4:5], off offset:352          // 000000150EC4: DC5E0160 327C0004
	s_waitcnt vmcnt(0)                                         // 000000150ECC: BF8903F7
	v_fma_mixlo_f16 v59, v50, s18, 0                           // 000000150ED0: CC21003B 02002532
	v_fma_mixhi_f16 v59, v51, s18, 0                           // 000000150ED8: CC22003B 02002533
	v_fma_mixlo_f16 v60, v52, s18, 0                           // 000000150EE0: CC21003C 02002534
	v_fma_mixhi_f16 v60, v53, s18, 0                           // 000000150EE8: CC22003C 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 000000150EF0: 8C7E0B7E
	.long 0x7e7c39be                                           // 000000150EF4: 7E7C39BE
	.long 0x7f7a39be                                           // 000000150EF8: 7F7A39BE
	.long 0x7e7a39be                                           // 000000150EFC: 7E7A39BE
	s_and_saveexec_b32 s11, s0                                 // 000000150F00: BE8B2000
	s_cbranch_execz 11                                         // 000000150F04: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4634>
	global_load_b128 v[50:53], v[4:5], off offset:368          // 000000150F08: DC5E0170 327C0004
	s_waitcnt vmcnt(0)                                         // 000000150F10: BF8903F7
	v_fma_mixlo_f16 v61, v50, s18, 0                           // 000000150F14: CC21003D 02002532
	v_fma_mixhi_f16 v61, v51, s18, 0                           // 000000150F1C: CC22003D 02002533
	v_fma_mixlo_f16 v62, v52, s18, 0                           // 000000150F24: CC21003E 02002534
	v_fma_mixhi_f16 v62, v53, s18, 0                           // 000000150F2C: CC22003E 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 000000150F34: 8C7E0B7E
	ds_load_b128 v[50:53], v78 offset:320                      // 000000150F38: DBFC0140 3200004E
	ds_load_b128 v[63:66], v78 offset:336                      // 000000150F40: DBFC0150 3F00004E
	ds_load_b128 v[99:102], v78 offset:352                     // 000000150F48: DBFC0160 6300004E
	ds_load_b128 v[103:106], v78 offset:368                    // 000000150F50: DBFC0170 6700004E
	ds_load_b128 v[107:110], v78 offset:8768                   // 000000150F58: DBFC2240 6B00004E
	ds_load_b128 v[111:114], v78 offset:8784                   // 000000150F60: DBFC2250 6F00004E
	ds_load_b128 v[115:118], v78 offset:8800                   // 000000150F68: DBFC2260 7300004E
	ds_load_b128 v[119:122], v78 offset:8816                   // 000000150F70: DBFC2270 7700004E
	ds_load_b128 v[123:126], v78 offset:17248                  // 000000150F78: DBFC4360 7B00004E
	ds_load_b128 v[127:130], v78 offset:17264                  // 000000150F80: DBFC4370 7F00004E
	ds_load_b128 v[131:134], v78 offset:25680                  // 000000150F88: DBFC6450 8300004E
	s_waitcnt lgkmcnt(10)                                      // 000000150F90: BF89FCA7
	v_fma_mixlo_f16 v95, v50, s18, 0                           // 000000150F94: CC21005F 02002532
	v_fma_mixhi_f16 v95, v51, s18, 0                           // 000000150F9C: CC22005F 02002533
	v_fma_mixlo_f16 v96, v52, s18, 0                           // 000000150FA4: CC210060 02002534
	v_fma_mixhi_f16 v96, v53, s18, 0                           // 000000150FAC: CC220060 02002535
	s_waitcnt lgkmcnt(9)                                       // 000000150FB4: BF89FC97
	v_fma_mixlo_f16 v97, v63, s18, 0                           // 000000150FB8: CC210061 0200253F
	v_fma_mixhi_f16 v97, v64, s18, 0                           // 000000150FC0: CC220061 02002540
	v_fma_mixlo_f16 v98, v65, s18, 0                           // 000000150FC8: CC210062 02002541
	v_fma_mixhi_f16 v98, v66, s18, 0                           // 000000150FD0: CC220062 02002542
	ds_load_b128 v[50:53], v78 offset:17216                    // 000000150FD8: DBFC4340 3200004E
	ds_load_b128 v[63:66], v78 offset:17232                    // 000000150FE0: DBFC4350 3F00004E
	s_waitcnt lgkmcnt(10)                                      // 000000150FE8: BF89FCA7
	v_fma_mixlo_f16 v99, v99, s18, 0                           // 000000150FEC: CC210063 02002563
	v_fma_mixhi_f16 v99, v100, s18, 0                          // 000000150FF4: CC220063 02002564
	v_fma_mixlo_f16 v100, v101, s18, 0                         // 000000150FFC: CC210064 02002565
	v_fma_mixhi_f16 v100, v102, s18, 0                         // 000000151004: CC220064 02002566
	s_waitcnt lgkmcnt(9)                                       // 00000015100C: BF89FC97
	v_fma_mixhi_f16 v101, v104, s18, 0                         // 000000151010: CC220065 02002568
	v_fma_mixlo_f16 v102, v105, s18, 0                         // 000000151018: CC210066 02002569
	v_fma_mixhi_f16 v102, v106, s18, 0                         // 000000151020: CC220066 0200256A
	s_waitcnt lgkmcnt(8)                                       // 000000151028: BF89FC87
	v_fma_mixlo_f16 v104, v109, s18, 0                         // 00000015102C: CC210068 0200256D
	v_fma_mixhi_f16 v104, v110, s18, 0                         // 000000151034: CC220068 0200256E
	s_waitcnt lgkmcnt(7)                                       // 00000015103C: BF89FC77
	v_fma_mixlo_f16 v105, v111, s18, 0                         // 000000151040: CC210069 0200256F
	v_fma_mixhi_f16 v105, v112, s18, 0                         // 000000151048: CC220069 02002570
	v_fma_mixlo_f16 v106, v113, s18, 0                         // 000000151050: CC21006A 02002571
	v_fma_mixhi_f16 v106, v114, s18, 0                         // 000000151058: CC22006A 02002572
	s_waitcnt lgkmcnt(5)                                       // 000000151060: BF89FC57
	v_fma_mixlo_f16 v109, v119, s18, 0                         // 000000151064: CC21006D 02002577
	v_fma_mixhi_f16 v109, v120, s18, 0                         // 00000015106C: CC22006D 02002578
	v_fma_mixlo_f16 v110, v121, s18, 0                         // 000000151074: CC21006E 02002579
	v_fma_mixhi_f16 v110, v122, s18, 0                         // 00000015107C: CC22006E 0200257A
	ds_load_b128 v[119:122], v78 offset:25664                  // 000000151084: DBFC6440 7700004E
	s_waitcnt lgkmcnt(2)                                       // 00000015108C: BF89FC27
	v_fma_mixlo_f16 v111, v50, s18, 0                          // 000000151090: CC21006F 02002532
	v_fma_mixhi_f16 v111, v51, s18, 0                          // 000000151098: CC22006F 02002533
	v_fma_mixlo_f16 v112, v52, s18, 0                          // 0000001510A0: CC210070 02002534
	v_fma_mixhi_f16 v112, v53, s18, 0                          // 0000001510A8: CC220070 02002535
	s_waitcnt lgkmcnt(1)                                       // 0000001510B0: BF89FC17
	v_fma_mixlo_f16 v113, v63, s18, 0                          // 0000001510B4: CC210071 0200253F
	v_fma_mixhi_f16 v113, v64, s18, 0                          // 0000001510BC: CC220071 02002540
	ds_load_b128 v[50:53], v78 offset:25696                    // 0000001510C4: DBFC6460 3200004E
	v_fma_mixlo_f16 v114, v65, s18, 0                          // 0000001510CC: CC210072 02002541
	v_fma_mixhi_f16 v114, v66, s18, 0                          // 0000001510D4: CC220072 02002542
	ds_load_b128 v[63:66], v78 offset:25712                    // 0000001510DC: DBFC6470 3F00004E
	v_fma_mixlo_f16 v101, v103, s18, 0                         // 0000001510E4: CC210065 02002567
	v_fma_mixlo_f16 v103, v107, s18, 0                         // 0000001510EC: CC210067 0200256B
	v_fma_mixhi_f16 v103, v108, s18, 0                         // 0000001510F4: CC220067 0200256C
	v_fma_mixlo_f16 v107, v115, s18, 0                         // 0000001510FC: CC21006B 02002573
	v_fma_mixhi_f16 v107, v116, s18, 0                         // 000000151104: CC22006B 02002574
	v_fma_mixlo_f16 v108, v117, s18, 0                         // 00000015110C: CC21006C 02002575
	v_fma_mixhi_f16 v108, v118, s18, 0                         // 000000151114: CC22006C 02002576
	v_fma_mixlo_f16 v115, v123, s18, 0                         // 00000015111C: CC210073 0200257B
	v_fma_mixhi_f16 v115, v124, s18, 0                         // 000000151124: CC220073 0200257C
	v_fma_mixlo_f16 v116, v125, s18, 0                         // 00000015112C: CC210074 0200257D
	v_fma_mixhi_f16 v116, v126, s18, 0                         // 000000151134: CC220074 0200257E
	v_fma_mixlo_f16 v117, v127, s18, 0                         // 00000015113C: CC210075 0200257F
	v_fma_mixhi_f16 v117, v128, s18, 0                         // 000000151144: CC220075 02002580
	v_fma_mixlo_f16 v118, v129, s18, 0                         // 00000015114C: CC210076 02002581
	v_fma_mixhi_f16 v118, v130, s18, 0                         // 000000151154: CC220076 02002582
	s_waitcnt lgkmcnt(2)                                       // 00000015115C: BF89FC27
	v_fma_mixlo_f16 v119, v119, s18, 0                         // 000000151160: CC210077 02002577
	v_fma_mixhi_f16 v119, v120, s18, 0                         // 000000151168: CC220077 02002578
	v_fma_mixlo_f16 v120, v121, s18, 0                         // 000000151170: CC210078 02002579
	v_fma_mixhi_f16 v120, v122, s18, 0                         // 000000151178: CC220078 0200257A
	v_fma_mixlo_f16 v121, v131, s18, 0                         // 000000151180: CC210079 02002583
	v_fma_mixhi_f16 v121, v132, s18, 0                         // 000000151188: CC220079 02002584
	v_fma_mixlo_f16 v122, v133, s18, 0                         // 000000151190: CC21007A 02002585
	v_fma_mixhi_f16 v122, v134, s18, 0                         // 000000151198: CC22007A 02002586
	s_waitcnt lgkmcnt(1)                                       // 0000001511A0: BF89FC17
	v_fma_mixlo_f16 v123, v50, s18, 0                          // 0000001511A4: CC21007B 02002532
	v_fma_mixhi_f16 v123, v51, s18, 0                          // 0000001511AC: CC22007B 02002533
	v_fma_mixlo_f16 v124, v52, s18, 0                          // 0000001511B4: CC21007C 02002534
	v_fma_mixhi_f16 v124, v53, s18, 0                          // 0000001511BC: CC22007C 02002535
	s_waitcnt lgkmcnt(0)                                       // 0000001511C4: BF89FC07
	v_fma_mixlo_f16 v125, v63, s18, 0                          // 0000001511C8: CC21007D 0200253F
	v_fma_mixhi_f16 v125, v64, s18, 0                          // 0000001511D0: CC22007D 02002540
	v_fma_mixlo_f16 v126, v65, s18, 0                          // 0000001511D8: CC21007E 02002541
	v_fma_mixhi_f16 v126, v66, s18, 0                          // 0000001511E0: CC22007E 02002542
	.long 0x7f7e3880                                           // 0000001511E8: 7F7E3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[55:62], v[95:102], v[42:49]// 0000001511EC: CC40402A 1CAABF37
	v_wmma_f32_16x16x16_f16 v[34:41], v[55:62], v[103:110], v[34:41]// 0000001511F4: CC404022 1C8ACF37
	v_wmma_f32_16x16x16_f16 v[26:33], v[55:62], v[111:118], v[26:33]// 0000001511FC: CC40401A 1C6ADF37
	v_wmma_f32_16x16x16_f16 v[18:25], v[55:62], v[119:126], v[18:25]// 000000151204: CC404012 1C4AEF37
	.long 0x7f7a39bf                                           // 00000015120C: 7F7A39BF
	.long 0x7e7a39bf                                           // 000000151210: 7E7A39BF
	.long 0x7f7839bf                                           // 000000151214: 7F7839BF
	.long 0x7e7839bf                                           // 000000151218: 7E7839BF
	s_and_saveexec_b32 s11, s0                                 // 00000015121C: BE8B2000
	s_cbranch_execz 11                                         // 000000151220: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4950>
	global_load_b128 v[50:53], v[4:5], off offset:384          // 000000151224: DC5E0180 327C0004
	s_waitcnt vmcnt(0)                                         // 00000015122C: BF8903F7
	v_fma_mixlo_f16 v60, v50, s18, 0                           // 000000151230: CC21003C 02002532
	v_fma_mixhi_f16 v60, v51, s18, 0                           // 000000151238: CC22003C 02002533
	v_fma_mixlo_f16 v61, v52, s18, 0                           // 000000151240: CC21003D 02002534
	v_fma_mixhi_f16 v61, v53, s18, 0                           // 000000151248: CC22003D 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 000000151250: 8C7E0B7E
	.long 0x7e7e39bf                                           // 000000151254: 7E7E39BF
	.long 0x7f7c39bf                                           // 000000151258: 7F7C39BF
	.long 0x7e7c39bf                                           // 00000015125C: 7E7C39BF
	s_and_saveexec_b32 s11, s0                                 // 000000151260: BE8B2000
	s_cbranch_execz 11                                         // 000000151264: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4994>
	global_load_b128 v[50:53], v[4:5], off offset:400          // 000000151268: DC5E0190 327C0004
	s_waitcnt vmcnt(0)                                         // 000000151270: BF8903F7
	v_fma_mixlo_f16 v62, v50, s18, 0                           // 000000151274: CC21003E 02002532
	v_fma_mixhi_f16 v62, v51, s18, 0                           // 00000015127C: CC22003E 02002533
	v_fma_mixlo_f16 v63, v52, s18, 0                           // 000000151284: CC21003F 02002534
	v_fma_mixhi_f16 v63, v53, s18, 0                           // 00000015128C: CC22003F 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 000000151294: 8C7E0B7E
	.long 0x7f863880                                           // 000000151298: 7F863880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015129C: BF870001
	.long 0x7f8239c3                                           // 0000001512A0: 7F8239C3
	.long 0x7e8239c3                                           // 0000001512A4: 7E8239C3
	.long 0x7f8039c3                                           // 0000001512A8: 7F8039C3
	.long 0x7e8039c3                                           // 0000001512AC: 7E8039C3
	s_and_saveexec_b32 s11, s0                                 // 0000001512B0: BE8B2000
	s_cbranch_execz 11                                         // 0000001512B4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x49e4>
	global_load_b128 v[50:53], v[4:5], off offset:416          // 0000001512B8: DC5E01A0 327C0004
	s_waitcnt vmcnt(0)                                         // 0000001512C0: BF8903F7
	v_fma_mixlo_f16 v64, v50, s18, 0                           // 0000001512C4: CC210040 02002532
	v_fma_mixhi_f16 v64, v51, s18, 0                           // 0000001512CC: CC220040 02002533
	v_fma_mixlo_f16 v65, v52, s18, 0                           // 0000001512D4: CC210041 02002534
	v_fma_mixhi_f16 v65, v53, s18, 0                           // 0000001512DC: CC220041 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001512E4: 8C7E0B7E
	.long 0x7e8639c3                                           // 0000001512E8: 7E8639C3
	.long 0x7f8439c3                                           // 0000001512EC: 7F8439C3
	.long 0x7e8439c3                                           // 0000001512F0: 7E8439C3
	s_and_saveexec_b32 s11, s0                                 // 0000001512F4: BE8B2000
	s_cbranch_execz 11                                         // 0000001512F8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4a28>
	global_load_b128 v[50:53], v[4:5], off offset:432          // 0000001512FC: DC5E01B0 327C0004
	s_waitcnt vmcnt(0)                                         // 000000151304: BF8903F7
	v_fma_mixlo_f16 v66, v50, s18, 0                           // 000000151308: CC210042 02002532
	v_fma_mixhi_f16 v66, v51, s18, 0                           // 000000151310: CC220042 02002533
	v_fma_mixlo_f16 v67, v52, s18, 0                           // 000000151318: CC210043 02002534
	v_fma_mixhi_f16 v67, v53, s18, 0                           // 000000151320: CC220043 02002535
	s_or_b32 exec_lo, exec_lo, s11                             // 000000151328: 8C7E0B7E
	ds_load_b128 v[50:53], v78 offset:384                      // 00000015132C: DBFC0180 3200004E
	ds_load_b128 v[54:57], v78 offset:400                      // 000000151334: DBFC0190 3600004E
	ds_load_b128 v[99:102], v78 offset:416                     // 00000015133C: DBFC01A0 6300004E
	ds_load_b128 v[103:106], v78 offset:432                    // 000000151344: DBFC01B0 6700004E
	ds_load_b128 v[107:110], v78 offset:8832                   // 00000015134C: DBFC2280 6B00004E
	ds_load_b128 v[111:114], v78 offset:8848                   // 000000151354: DBFC2290 6F00004E
	ds_load_b128 v[115:118], v78 offset:8864                   // 00000015135C: DBFC22A0 7300004E
	ds_load_b128 v[119:122], v78 offset:8880                   // 000000151364: DBFC22B0 7700004E
	ds_load_b128 v[123:126], v78 offset:17312                  // 00000015136C: DBFC43A0 7B00004E
	ds_load_b128 v[127:130], v78 offset:17328                  // 000000151374: DBFC43B0 7F00004E
	ds_load_b128 v[131:134], v78 offset:25744                  // 00000015137C: DBFC6490 8300004E
	s_waitcnt lgkmcnt(10)                                      // 000000151384: BF89FCA7
	v_fma_mixlo_f16 v95, v50, s18, 0                           // 000000151388: CC21005F 02002532
	v_fma_mixhi_f16 v95, v51, s18, 0                           // 000000151390: CC22005F 02002533
	v_fma_mixlo_f16 v96, v52, s18, 0                           // 000000151398: CC210060 02002534
	v_fma_mixhi_f16 v96, v53, s18, 0                           // 0000001513A0: CC220060 02002535
	s_waitcnt lgkmcnt(9)                                       // 0000001513A8: BF89FC97
	v_fma_mixlo_f16 v97, v54, s18, 0                           // 0000001513AC: CC210061 02002536
	v_fma_mixhi_f16 v97, v55, s18, 0                           // 0000001513B4: CC220061 02002537
	v_fma_mixlo_f16 v98, v56, s18, 0                           // 0000001513BC: CC210062 02002538
	v_fma_mixhi_f16 v98, v57, s18, 0                           // 0000001513C4: CC220062 02002539
	ds_load_b128 v[50:53], v78 offset:17280                    // 0000001513CC: DBFC4380 3200004E
	ds_load_b128 v[54:57], v78 offset:17296                    // 0000001513D4: DBFC4390 3600004E
	s_waitcnt lgkmcnt(10)                                      // 0000001513DC: BF89FCA7
	v_fma_mixlo_f16 v99, v99, s18, 0                           // 0000001513E0: CC210063 02002563
	v_fma_mixhi_f16 v99, v100, s18, 0                          // 0000001513E8: CC220063 02002564
	v_fma_mixlo_f16 v100, v101, s18, 0                         // 0000001513F0: CC210064 02002565
	v_fma_mixhi_f16 v100, v102, s18, 0                         // 0000001513F8: CC220064 02002566
	s_waitcnt lgkmcnt(9)                                       // 000000151400: BF89FC97
	v_fma_mixhi_f16 v101, v104, s18, 0                         // 000000151404: CC220065 02002568
	v_fma_mixlo_f16 v102, v105, s18, 0                         // 00000015140C: CC210066 02002569
	v_fma_mixhi_f16 v102, v106, s18, 0                         // 000000151414: CC220066 0200256A
	s_waitcnt lgkmcnt(8)                                       // 00000015141C: BF89FC87
	v_fma_mixlo_f16 v104, v109, s18, 0                         // 000000151420: CC210068 0200256D
	v_fma_mixhi_f16 v104, v110, s18, 0                         // 000000151428: CC220068 0200256E
	s_waitcnt lgkmcnt(7)                                       // 000000151430: BF89FC77
	v_fma_mixlo_f16 v105, v111, s18, 0                         // 000000151434: CC210069 0200256F
	v_fma_mixhi_f16 v105, v112, s18, 0                         // 00000015143C: CC220069 02002570
	v_fma_mixlo_f16 v106, v113, s18, 0                         // 000000151444: CC21006A 02002571
	v_fma_mixhi_f16 v106, v114, s18, 0                         // 00000015144C: CC22006A 02002572
	s_waitcnt lgkmcnt(5)                                       // 000000151454: BF89FC57
	v_fma_mixlo_f16 v109, v119, s18, 0                         // 000000151458: CC21006D 02002577
	v_fma_mixhi_f16 v109, v120, s18, 0                         // 000000151460: CC22006D 02002578
	v_fma_mixlo_f16 v110, v121, s18, 0                         // 000000151468: CC21006E 02002579
	v_fma_mixhi_f16 v110, v122, s18, 0                         // 000000151470: CC22006E 0200257A
	ds_load_b128 v[119:122], v78 offset:25728                  // 000000151478: DBFC6480 7700004E
	s_waitcnt lgkmcnt(2)                                       // 000000151480: BF89FC27
	v_fma_mixlo_f16 v111, v50, s18, 0                          // 000000151484: CC21006F 02002532
	v_fma_mixhi_f16 v111, v51, s18, 0                          // 00000015148C: CC22006F 02002533
	v_fma_mixlo_f16 v112, v52, s18, 0                          // 000000151494: CC210070 02002534
	v_fma_mixhi_f16 v112, v53, s18, 0                          // 00000015149C: CC220070 02002535
	s_waitcnt lgkmcnt(1)                                       // 0000001514A4: BF89FC17
	v_fma_mixlo_f16 v113, v54, s18, 0                          // 0000001514A8: CC210071 02002536
	v_fma_mixhi_f16 v113, v55, s18, 0                          // 0000001514B0: CC220071 02002537
	ds_load_b128 v[50:53], v78 offset:25760                    // 0000001514B8: DBFC64A0 3200004E
	v_fma_mixlo_f16 v114, v56, s18, 0                          // 0000001514C0: CC210072 02002538
	v_fma_mixhi_f16 v114, v57, s18, 0                          // 0000001514C8: CC220072 02002539
	ds_load_b128 v[54:57], v78 offset:25776                    // 0000001514D0: DBFC64B0 3600004E
	v_fma_mixlo_f16 v101, v103, s18, 0                         // 0000001514D8: CC210065 02002567
	v_fma_mixlo_f16 v103, v107, s18, 0                         // 0000001514E0: CC210067 0200256B
	v_fma_mixhi_f16 v103, v108, s18, 0                         // 0000001514E8: CC220067 0200256C
	v_fma_mixlo_f16 v107, v115, s18, 0                         // 0000001514F0: CC21006B 02002573
	v_fma_mixhi_f16 v107, v116, s18, 0                         // 0000001514F8: CC22006B 02002574
	v_fma_mixlo_f16 v108, v117, s18, 0                         // 000000151500: CC21006C 02002575
	v_fma_mixhi_f16 v108, v118, s18, 0                         // 000000151508: CC22006C 02002576
	v_fma_mixlo_f16 v115, v123, s18, 0                         // 000000151510: CC210073 0200257B
	v_fma_mixhi_f16 v115, v124, s18, 0                         // 000000151518: CC220073 0200257C
	v_fma_mixlo_f16 v116, v125, s18, 0                         // 000000151520: CC210074 0200257D
	v_fma_mixhi_f16 v116, v126, s18, 0                         // 000000151528: CC220074 0200257E
	v_fma_mixlo_f16 v117, v127, s18, 0                         // 000000151530: CC210075 0200257F
	v_fma_mixhi_f16 v117, v128, s18, 0                         // 000000151538: CC220075 02002580
	v_fma_mixlo_f16 v118, v129, s18, 0                         // 000000151540: CC210076 02002581
	v_fma_mixhi_f16 v118, v130, s18, 0                         // 000000151548: CC220076 02002582
	s_waitcnt lgkmcnt(2)                                       // 000000151550: BF89FC27
	v_fma_mixlo_f16 v119, v119, s18, 0                         // 000000151554: CC210077 02002577
	v_fma_mixhi_f16 v119, v120, s18, 0                         // 00000015155C: CC220077 02002578
	v_fma_mixlo_f16 v120, v121, s18, 0                         // 000000151564: CC210078 02002579
	v_fma_mixhi_f16 v120, v122, s18, 0                         // 00000015156C: CC220078 0200257A
	v_fma_mixlo_f16 v121, v131, s18, 0                         // 000000151574: CC210079 02002583
	v_fma_mixhi_f16 v121, v132, s18, 0                         // 00000015157C: CC220079 02002584
	v_fma_mixlo_f16 v122, v133, s18, 0                         // 000000151584: CC21007A 02002585
	v_fma_mixhi_f16 v122, v134, s18, 0                         // 00000015158C: CC22007A 02002586
	s_waitcnt lgkmcnt(1)                                       // 000000151594: BF89FC17
	v_fma_mixlo_f16 v123, v50, s18, 0                          // 000000151598: CC21007B 02002532
	v_fma_mixhi_f16 v123, v51, s18, 0                          // 0000001515A0: CC22007B 02002533
	v_fma_mixlo_f16 v124, v52, s18, 0                          // 0000001515A8: CC21007C 02002534
	v_fma_mixhi_f16 v124, v53, s18, 0                          // 0000001515B0: CC22007C 02002535
	s_waitcnt lgkmcnt(0)                                       // 0000001515B8: BF89FC07
	v_fma_mixlo_f16 v125, v54, s18, 0                          // 0000001515BC: CC21007D 02002536
	v_fma_mixhi_f16 v125, v55, s18, 0                          // 0000001515C4: CC22007D 02002537
	v_fma_mixlo_f16 v126, v56, s18, 0                          // 0000001515CC: CC21007E 02002538
	v_fma_mixhi_f16 v126, v57, s18, 0                          // 0000001515D4: CC22007E 02002539
	.long 0x7f6a3880                                           // 0000001515DC: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[60:67], v[95:102], v[42:49]// 0000001515E0: CC40402A 1CAABF3C
	v_wmma_f32_16x16x16_f16 v[34:41], v[60:67], v[103:110], v[34:41]// 0000001515E8: CC404022 1C8ACF3C
	v_wmma_f32_16x16x16_f16 v[26:33], v[60:67], v[111:118], v[26:33]// 0000001515F0: CC40401A 1C6ADF3C
	v_wmma_f32_16x16x16_f16 v[18:25], v[60:67], v[119:126], v[18:25]// 0000001515F8: CC404012 1C4AEF3C
	.long 0x7f6639b5                                           // 000000151600: 7F6639B5
	.long 0x7e6639b5                                           // 000000151604: 7E6639B5
	.long 0x7f6439b5                                           // 000000151608: 7F6439B5
	.long 0x7e6439b5                                           // 00000015160C: 7E6439B5
	s_and_saveexec_b32 s11, s0                                 // 000000151610: BE8B2000
	s_cbranch_execz 11                                         // 000000151614: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4d44>
	global_load_b128 v[54:57], v[4:5], off offset:448          // 000000151618: DC5E01C0 367C0004
	s_waitcnt vmcnt(0)                                         // 000000151620: BF8903F7
	v_fma_mixlo_f16 v50, v54, s18, 0                           // 000000151624: CC210032 02002536
	v_fma_mixhi_f16 v50, v55, s18, 0                           // 00000015162C: CC220032 02002537
	v_fma_mixlo_f16 v51, v56, s18, 0                           // 000000151634: CC210033 02002538
	v_fma_mixhi_f16 v51, v57, s18, 0                           // 00000015163C: CC220033 02002539
	s_or_b32 exec_lo, exec_lo, s11                             // 000000151644: 8C7E0B7E
	.long 0x7e6a39b5                                           // 000000151648: 7E6A39B5
	.long 0x7f6839b5                                           // 00000015164C: 7F6839B5
	.long 0x7e6839b5                                           // 000000151650: 7E6839B5
	s_and_saveexec_b32 s11, s0                                 // 000000151654: BE8B2000
	s_cbranch_execz 11                                         // 000000151658: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4d88>
	global_load_b128 v[52:55], v[4:5], off offset:464          // 00000015165C: DC5E01D0 347C0004
	s_waitcnt vmcnt(0)                                         // 000000151664: BF8903F7
	v_fma_mixlo_f16 v52, v52, s18, 0                           // 000000151668: CC210034 02002534
	v_fma_mixhi_f16 v52, v53, s18, 0                           // 000000151670: CC220034 02002535
	v_fma_mixlo_f16 v53, v54, s18, 0                           // 000000151678: CC210035 02002536
	v_fma_mixhi_f16 v53, v55, s18, 0                           // 000000151680: CC220035 02002537
	s_or_b32 exec_lo, exec_lo, s11                             // 000000151688: 8C7E0B7E
	.long 0x7f723880                                           // 00000015168C: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000151690: BF870001
	.long 0x7f6e39b9                                           // 000000151694: 7F6E39B9
	.long 0x7e6e39b9                                           // 000000151698: 7E6E39B9
	.long 0x7f6c39b9                                           // 00000015169C: 7F6C39B9
	.long 0x7e6c39b9                                           // 0000001516A0: 7E6C39B9
	s_and_saveexec_b32 s11, s0                                 // 0000001516A4: BE8B2000
	s_cbranch_execz 11                                         // 0000001516A8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4dd8>
	global_load_b128 v[58:61], v[4:5], off offset:480          // 0000001516AC: DC5E01E0 3A7C0004
	s_waitcnt vmcnt(0)                                         // 0000001516B4: BF8903F7
	v_fma_mixlo_f16 v54, v58, s18, 0                           // 0000001516B8: CC210036 0200253A
	v_fma_mixhi_f16 v54, v59, s18, 0                           // 0000001516C0: CC220036 0200253B
	v_fma_mixlo_f16 v55, v60, s18, 0                           // 0000001516C8: CC210037 0200253C
	v_fma_mixhi_f16 v55, v61, s18, 0                           // 0000001516D0: CC220037 0200253D
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001516D8: 8C7E0B7E
	.long 0x7e7239b9                                           // 0000001516DC: 7E7239B9
	.long 0x7f7039b9                                           // 0000001516E0: 7F7039B9
	.long 0x7e7039b9                                           // 0000001516E4: 7E7039B9
	s_and_saveexec_b32 s11, s0                                 // 0000001516E8: BE8B2000
	s_cbranch_execz 11                                         // 0000001516EC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4e1c>
	global_load_b128 v[3:6], v[4:5], off offset:496            // 0000001516F0: DC5E01F0 037C0004
	s_waitcnt vmcnt(0)                                         // 0000001516F8: BF8903F7
	v_fma_mixlo_f16 v56, v3, s18, 0                            // 0000001516FC: CC210038 02002503
	v_fma_mixhi_f16 v56, v4, s18, 0                            // 000000151704: CC220038 02002504
	v_fma_mixlo_f16 v57, v5, s18, 0                            // 00000015170C: CC210039 02002505
	v_fma_mixhi_f16 v57, v6, s18, 0                            // 000000151714: CC220039 02002506
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015171C: 8C7E0B7E
	ds_load_b128 v[3:6], v78 offset:448                        // 000000151720: DBFC01C0 0300004E
	ds_load_b128 v[60:63], v78 offset:464                      // 000000151728: DBFC01D0 3C00004E
	ds_load_b128 v[64:67], v78 offset:480                      // 000000151730: DBFC01E0 4000004E
	ds_load_b128 v[95:98], v78 offset:496                      // 000000151738: DBFC01F0 5F00004E
	ds_load_b128 v[99:102], v78 offset:8896                    // 000000151740: DBFC22C0 6300004E
	ds_load_b128 v[103:106], v78 offset:8912                   // 000000151748: DBFC22D0 6700004E
	ds_load_b128 v[107:110], v78 offset:8928                   // 000000151750: DBFC22E0 6B00004E
	ds_load_b128 v[111:114], v78 offset:8944                   // 000000151758: DBFC22F0 6F00004E
	ds_load_b128 v[119:122], v78 offset:17376                  // 000000151760: DBFC43E0 7700004E
	ds_load_b128 v[123:126], v78 offset:17392                  // 000000151768: DBFC43F0 7B00004E
	ds_load_b128 v[115:118], v78 offset:17360                  // 000000151770: DBFC43D0 7300004E
	ds_load_b128 v[127:130], v78 offset:25808                  // 000000151778: DBFC64D0 7F00004E
	ds_load_b128 v[131:134], v78 offset:25840                  // 000000151780: DBFC64F0 8300004E
	s_waitcnt lgkmcnt(12)                                      // 000000151788: BF89FCC7
	v_fma_mixlo_f16 v58, v3, s18, 0                            // 00000015178C: CC21003A 02002503
	v_fma_mixhi_f16 v58, v4, s18, 0                            // 000000151794: CC22003A 02002504
	v_fma_mixlo_f16 v59, v5, s18, 0                            // 00000015179C: CC21003B 02002505
	v_fma_mixhi_f16 v59, v6, s18, 0                            // 0000001517A4: CC22003B 02002506
	ds_load_b128 v[3:6], v78 offset:17344                      // 0000001517AC: DBFC43C0 0300004E
	s_waitcnt lgkmcnt(12)                                      // 0000001517B4: BF89FCC7
	v_fma_mixlo_f16 v60, v60, s18, 0                           // 0000001517B8: CC21003C 0200253C
	v_fma_mixhi_f16 v60, v61, s18, 0                           // 0000001517C0: CC22003C 0200253D
	v_fma_mixlo_f16 v61, v62, s18, 0                           // 0000001517C8: CC21003D 0200253E
	s_waitcnt lgkmcnt(11)                                      // 0000001517D0: BF89FCB7
	v_fma_mixlo_f16 v62, v64, s18, 0                           // 0000001517D4: CC21003E 02002540
	v_fma_mixhi_f16 v62, v65, s18, 0                           // 0000001517DC: CC22003E 02002541
	s_waitcnt lgkmcnt(10)                                      // 0000001517E4: BF89FCA7
	v_fma_mixhi_f16 v64, v96, s18, 0                           // 0000001517E8: CC220040 02002560
	v_fma_mixlo_f16 v65, v97, s18, 0                           // 0000001517F0: CC210041 02002561
	s_waitcnt lgkmcnt(9)                                       // 0000001517F8: BF89FC97
	v_fma_mixlo_f16 v96, v101, s18, 0                          // 0000001517FC: CC210060 02002565
	v_fma_mixhi_f16 v96, v102, s18, 0                          // 000000151804: CC220060 02002566
	s_waitcnt lgkmcnt(8)                                       // 00000015180C: BF89FC87
	v_fma_mixlo_f16 v97, v103, s18, 0                          // 000000151810: CC210061 02002567
	v_fma_mixhi_f16 v97, v104, s18, 0                          // 000000151818: CC220061 02002568
	s_waitcnt lgkmcnt(6)                                       // 000000151820: BF89FC67
	v_fma_mixlo_f16 v101, v111, s18, 0                         // 000000151824: CC210065 0200256F
	v_fma_mixhi_f16 v101, v112, s18, 0                         // 00000015182C: CC220065 02002570
	v_fma_mixlo_f16 v102, v113, s18, 0                         // 000000151834: CC210066 02002571
	v_fma_mixhi_f16 v102, v114, s18, 0                         // 00000015183C: CC220066 02002572
	ds_load_b128 v[111:114], v78 offset:25792                  // 000000151844: DBFC64C0 6F00004E
	v_fma_mixhi_f16 v61, v63, s18, 0                           // 00000015184C: CC22003D 0200253F
	v_fma_mixlo_f16 v63, v66, s18, 0                           // 000000151854: CC21003F 02002542
	v_fma_mixhi_f16 v63, v67, s18, 0                           // 00000015185C: CC22003F 02002543
	s_waitcnt lgkmcnt(1)                                       // 000000151864: BF89FC17
	v_fma_mixlo_f16 v103, v3, s18, 0                           // 000000151868: CC210067 02002503
	v_fma_mixhi_f16 v103, v4, s18, 0                           // 000000151870: CC220067 02002504
	v_fma_mixlo_f16 v104, v5, s18, 0                           // 000000151878: CC210068 02002505
	v_fma_mixhi_f16 v104, v6, s18, 0                           // 000000151880: CC220068 02002506
	ds_load_b128 v[3:6], v78 offset:25824                      // 000000151888: DBFC64E0 0300004E
	v_fma_mixlo_f16 v64, v95, s18, 0                           // 000000151890: CC210040 0200255F
	v_fma_mixhi_f16 v65, v98, s18, 0                           // 000000151898: CC220041 02002562
	v_fma_mixlo_f16 v95, v99, s18, 0                           // 0000001518A0: CC21005F 02002563
	v_fma_mixhi_f16 v95, v100, s18, 0                          // 0000001518A8: CC22005F 02002564
	v_fma_mixlo_f16 v98, v105, s18, 0                          // 0000001518B0: CC210062 02002569
	v_fma_mixhi_f16 v98, v106, s18, 0                          // 0000001518B8: CC220062 0200256A
	v_fma_mixlo_f16 v99, v107, s18, 0                          // 0000001518C0: CC210063 0200256B
	v_fma_mixhi_f16 v99, v108, s18, 0                          // 0000001518C8: CC220063 0200256C
	v_fma_mixlo_f16 v100, v109, s18, 0                         // 0000001518D0: CC210064 0200256D
	v_fma_mixhi_f16 v100, v110, s18, 0                         // 0000001518D8: CC220064 0200256E
	v_fma_mixlo_f16 v105, v115, s18, 0                         // 0000001518E0: CC210069 02002573
	v_fma_mixhi_f16 v105, v116, s18, 0                         // 0000001518E8: CC220069 02002574
	v_fma_mixlo_f16 v106, v117, s18, 0                         // 0000001518F0: CC21006A 02002575
	v_fma_mixhi_f16 v106, v118, s18, 0                         // 0000001518F8: CC22006A 02002576
	v_fma_mixlo_f16 v107, v119, s18, 0                         // 000000151900: CC21006B 02002577
	v_fma_mixhi_f16 v107, v120, s18, 0                         // 000000151908: CC22006B 02002578
	v_fma_mixlo_f16 v108, v121, s18, 0                         // 000000151910: CC21006C 02002579
	v_fma_mixhi_f16 v108, v122, s18, 0                         // 000000151918: CC22006C 0200257A
	v_fma_mixlo_f16 v109, v123, s18, 0                         // 000000151920: CC21006D 0200257B
	v_fma_mixhi_f16 v109, v124, s18, 0                         // 000000151928: CC22006D 0200257C
	v_fma_mixlo_f16 v110, v125, s18, 0                         // 000000151930: CC21006E 0200257D
	v_fma_mixhi_f16 v110, v126, s18, 0                         // 000000151938: CC22006E 0200257E
	s_waitcnt lgkmcnt(1)                                       // 000000151940: BF89FC17
	v_fma_mixlo_f16 v111, v111, s18, 0                         // 000000151944: CC21006F 0200256F
	v_fma_mixhi_f16 v111, v112, s18, 0                         // 00000015194C: CC22006F 02002570
	v_fma_mixlo_f16 v112, v113, s18, 0                         // 000000151954: CC210070 02002571
	v_fma_mixhi_f16 v112, v114, s18, 0                         // 00000015195C: CC220070 02002572
	v_fma_mixlo_f16 v113, v127, s18, 0                         // 000000151964: CC210071 0200257F
	v_fma_mixhi_f16 v113, v128, s18, 0                         // 00000015196C: CC220071 02002580
	v_fma_mixlo_f16 v114, v129, s18, 0                         // 000000151974: CC210072 02002581
	v_fma_mixhi_f16 v114, v130, s18, 0                         // 00000015197C: CC220072 02002582
	s_waitcnt lgkmcnt(0)                                       // 000000151984: BF89FC07
	v_fma_mixlo_f16 v115, v3, s18, 0                           // 000000151988: CC210073 02002503
	v_fma_mixhi_f16 v115, v4, s18, 0                           // 000000151990: CC220073 02002504
	v_fma_mixlo_f16 v116, v5, s18, 0                           // 000000151998: CC210074 02002505
	v_fma_mixhi_f16 v116, v6, s18, 0                           // 0000001519A0: CC220074 02002506
	v_fma_mixlo_f16 v117, v131, s18, 0                         // 0000001519A8: CC210075 02002583
	v_fma_mixhi_f16 v117, v132, s18, 0                         // 0000001519B0: CC220075 02002584
	v_fma_mixlo_f16 v118, v133, s18, 0                         // 0000001519B8: CC210076 02002585
	v_fma_mixhi_f16 v118, v134, s18, 0                         // 0000001519C0: CC220076 02002586
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[58:65], v[42:49]// 0000001519C8: CC40402A 1CAA7532
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[95:102], v[34:41]// 0000001519D0: CC404022 1C8ABF32
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[103:110], v[26:33]// 0000001519D8: CC40401A 1C6ACF32
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001519E0: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[111:118], v[18:25]// 0000001519E4: CC404012 1C4ADF32
	s_and_saveexec_b32 s0, s1                                  // 0000001519EC: BE802001
	s_cbranch_execnz 482                                       // 0000001519F0: BFA601E2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x587c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001519F4: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000001519F8: BE802004
	s_cbranch_execnz 501                                       // 0000001519FC: BFA601F5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x58d4>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151A00: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000151A04: BE802005
	s_cbranch_execnz 520                                       // 000000151A08: BFA60208 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x592c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151A0C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000151A10: BE802006
	s_cbranch_execnz 539                                       // 000000151A14: BFA6021B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5984>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151A18: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000151A1C: BE802007
	s_cbranch_execnz 558                                       // 000000151A20: BFA6022E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x59dc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151A24: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 000000151A28: BE802008
	s_cbranch_execnz 577                                       // 000000151A2C: BFA60241 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a34>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151A30: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000151A34: BE802009
	s_cbranch_execnz 596                                       // 000000151A38: BFA60254 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a8c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151A3C: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 000000151A40: BE80200A
	s_cbranch_execnz 615                                       // 000000151A44: BFA60267 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5ae4>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151A48: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 000000151A4C: BE802001
	s_cbranch_execnz 634                                       // 000000151A50: BFA6027A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5b3c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151A54: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000151A58: BE802004
	s_cbranch_execnz 653                                       // 000000151A5C: BFA6028D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5b94>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151A60: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000151A64: BE802005
	s_cbranch_execnz 672                                       // 000000151A68: BFA602A0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5bec>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151A6C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000151A70: BE802006
	s_cbranch_execnz 691                                       // 000000151A74: BFA602B3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c44>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151A78: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000151A7C: BE802007
	s_cbranch_execnz 710                                       // 000000151A80: BFA602C6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c9c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151A84: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 000000151A88: BE802008
	s_cbranch_execnz 729                                       // 000000151A8C: BFA602D9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5cf4>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151A90: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000151A94: BE802009
	s_cbranch_execnz 748                                       // 000000151A98: BFA602EC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5d4c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151A9C: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 000000151AA0: BE80200A
	s_cbranch_execnz 767                                       // 000000151AA4: BFA602FF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5da4>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151AA8: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 000000151AAC: BE802001
	s_cbranch_execnz 786                                       // 000000151AB0: BFA60312 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5dfc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151AB4: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000151AB8: BE802004
	s_cbranch_execnz 805                                       // 000000151ABC: BFA60325 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5e54>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151AC0: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000151AC4: BE802005
	s_cbranch_execnz 824                                       // 000000151AC8: BFA60338 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5eac>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151ACC: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000151AD0: BE802006
	s_cbranch_execnz 843                                       // 000000151AD4: BFA6034B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f04>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151AD8: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000151ADC: BE802007
	s_cbranch_execnz 862                                       // 000000151AE0: BFA6035E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f5c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151AE4: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 000000151AE8: BE802008
	s_cbranch_execnz 881                                       // 000000151AEC: BFA60371 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5fb4>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151AF0: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000151AF4: BE802009
	s_cbranch_execnz 900                                       // 000000151AF8: BFA60384 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x600c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151AFC: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 000000151B00: BE80200A
	s_cbranch_execnz 919                                       // 000000151B04: BFA60397 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6064>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151B08: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 000000151B0C: BE802001
	s_cbranch_execnz 938                                       // 000000151B10: BFA603AA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x60bc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151B14: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000151B18: BE802004
	s_cbranch_execnz 957                                       // 000000151B1C: BFA603BD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6114>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151B20: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000151B24: BE802005
	s_cbranch_execnz 976                                       // 000000151B28: BFA603D0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x616c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151B2C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000151B30: BE802006
	s_cbranch_execnz 995                                       // 000000151B34: BFA603E3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x61c4>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151B38: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000151B3C: BE802007
	s_cbranch_execnz 1014                                      // 000000151B40: BFA603F6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x621c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151B44: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 000000151B48: BE802008
	s_cbranch_execnz 1033                                      // 000000151B4C: BFA60409 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6274>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151B50: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000151B54: BE802009
	s_cbranch_execnz 1052                                      // 000000151B58: BFA6041C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x62cc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151B5C: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 000000151B60: BE80200A
	s_cbranch_execz 19                                         // 000000151B64: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x52b4>
	ds_load_b32 v3, v87 offset:56                              // 000000151B68: D8D80038 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000151B70: BF89FC07
	v_fma_f32 v3, v25, v3, 0                                   // 000000151B74: D6130003 02020719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000151B7C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000151B80: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v94, v[70:71]          // 000000151B88: D6FE7C03 051ABCFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000151B94: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000151B9C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000151BA0: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000151BAC: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000151BB4: 8C7E007E
	s_mul_f32 s0, s23, 0x3fb8aa3b                              // 000000151BB8: A200FF17 3FB8AA3B
	v_or_b32_e32 v4, s22, v74                                  // 000000151BC0: 38089416
	v_dual_mov_b32 v18, v72 :: v_dual_mov_b32 v19, v73         // 000000151BC4: CA100148 12120149
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000151BCC: BF870009
	s_xor_b32 s1, s0, 0x80000000                               // 000000151BD0: 8D01FF00 80000000
	s_rndne_f32 s4, s0                                         // 000000151BD8: BE846300
	s_fmamk_f32 s1, s23, 0x3fb8aa3b, s1                        // 000000151BDC: A3010117 3FB8AA3B
	s_cmp_nlt_f32 s23, 0xc2ce8ed0                              // 000000151BE4: BF4EFF17 C2CE8ED0
	s_mov_b32 s5, 0                                            // 000000151BEC: BE850080
	s_sub_f32 s0, s0, s4                                       // 000000151BF0: A0800400
	s_fmamk_f32 s1, s23, 0x32a5705f, s1                        // 000000151BF4: A3010117 32A5705F
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000151BFC: BF87059B
	s_add_f32 s0, s0, s1                                       // 000000151C00: A0000100
	v_exp_f32_e32 v3, s0                                       // 000000151C04: 7E064A00
	s_cvt_i32_f32 s0, s4                                       // 000000151C08: BE806604
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000151C0C: BF870585
	.long 0xd71c0003                                           // 000000151C10: D71C0003
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 000000151C14: 02000103
	s_cselect_b32 s0, -1, 0                                    // 000000151C18: 980080C1
	s_cmp_ngt_f32 s23, 0x42b17218                              // 000000151C1C: BF4BFF17 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000151C24: BF870131
	v_cndmask_b32_e64 v3, 0, v3, s0                            // 000000151C28: D5010003 00020680
	s_cselect_b32 s1, -1, 0                                    // 000000151C30: 980180C1
	.long 0xd4440000                                           // 000000151C34: D4440000
	v_cndmask_b32_e32 v1, s35, v4, vcc_lo                      // 000000151C38: 02020823
	v_cndmask_b32_e64 v20, 0x7f800000, v3, s1                  // 000000151C3C: D5010014 000606FF 7F800000
	s_branch 120                                               // 000000151C48: BFA00078 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x552c>
	s_set_inst_prefetch_distance 0x2                           // 000000151C4C: BF840002
	s_or_b32 exec_lo, exec_lo, s6                              // 000000151C50: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000151C54: BF89FC07
	s_barrier                                                  // 000000151C58: BFBD0000
	buffer_gl0_inv                                             // 000000151C5C: E0AC0000 00000000
	ds_load_b128 v[22:25], v79                                 // 000000151C64: DBFC0000 1600004F
	ds_load_b128 v[26:29], v79 offset:16                       // 000000151C6C: DBFC0010 1A00004F
	ds_load_b128 v[30:33], v82                                 // 000000151C74: DBFC0000 1E000052
	ds_load_b128 v[34:37], v82 offset:16                       // 000000151C7C: DBFC0010 22000052
	ds_load_b128 v[38:41], v79 offset:32                       // 000000151C84: DBFC0020 2600004F
	ds_load_b128 v[42:45], v79 offset:48                       // 000000151C8C: DBFC0030 2A00004F
	ds_load_b128 v[46:49], v82 offset:32                       // 000000151C94: DBFC0020 2E000052
	ds_load_b128 v[50:53], v82 offset:48                       // 000000151C9C: DBFC0030 32000052
	v_mov_b32_e32 v9, v2                                       // 000000151CA4: 7E120302
	v_mov_b32_e32 v3, v2                                       // 000000151CA8: 7E060302
	v_mov_b32_e32 v4, v2                                       // 000000151CAC: 7E080302
	v_mov_b32_e32 v5, v2                                       // 000000151CB0: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 000000151CB4: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 000000151CB8: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 000000151CBC: 7E100302
	v_mov_b32_e32 v61, v9                                      // 000000151CC0: 7E7A0309
	v_dual_mov_b32 v57, v5 :: v_dual_mov_b32 v56, v4           // 000000151CC4: CA100105 39380104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000151CCC: BF870214
	v_dual_mov_b32 v59, v7 :: v_dual_mov_b32 v58, v6           // 000000151CD0: CA100107 3B3A0106
	v_dual_mov_b32 v60, v8 :: v_dual_mov_b32 v55, v3           // 000000151CD8: CA100108 3C360103
	v_mov_b32_e32 v54, v2                                      // 000000151CE0: 7E6C0302
	ds_load_b128 v[94:97], v79 offset:80                       // 000000151CE4: DBFC0050 5E00004F
	ds_load_b128 v[90:93], v79 offset:64                       // 000000151CEC: DBFC0040 5A00004F
	ds_load_b128 v[102:105], v82 offset:80                     // 000000151CF4: DBFC0050 66000052
	ds_load_b128 v[98:101], v82 offset:64                      // 000000151CFC: DBFC0040 62000052
	ds_load_b128 v[110:113], v79 offset:112                    // 000000151D04: DBFC0070 6E00004F
	ds_load_b128 v[106:109], v79 offset:96                     // 000000151D0C: DBFC0060 6A00004F
	ds_load_2addr_b32 v[3:4], v21 offset0:16 offset1:18        // 000000151D14: D8DC1210 03000015
	ds_load_b128 v[118:121], v82 offset:112                    // 000000151D1C: DBFC0070 76000052
	ds_load_b128 v[114:117], v82 offset:96                     // 000000151D24: DBFC0060 72000052
	ds_load_2addr_b32 v[5:6], v21 offset0:20 offset1:22        // 000000151D2C: D8DC1614 05000015
	ds_load_2addr_b32 v[7:8], v21 offset0:24 offset1:26        // 000000151D34: D8DC1A18 07000015
	.long 0xd7000112                                           // 000000151D3C: D7000112
	v_cndmask_b32_e32 v1, 0x80, v18, vcc_lo                    // 000000151D40: 020224FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000151D48: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 000000151D4C: D5207C13 00062680
	s_waitcnt lgkmcnt(15)                                      // 000000151D54: BF89FCF7
	v_wmma_f32_16x16x16_f16 v[54:61], v[22:29], v[30:37], v[54:61]// 000000151D58: CC404036 1CDA3D16
	ds_load_2addr_b32 v[22:23], v21 offset0:28 offset1:30      // 000000151D60: D8DC1E1C 16000015
	s_add_i32 s1, s5, 32                                       // 000000151D68: 8101A005
	s_cmpk_gt_u32 s5, 0x5f                                     // 000000151D6C: B585005F
	s_mov_b32 s5, s1                                           // 000000151D70: BE850001
	s_waitcnt lgkmcnt(12)                                      // 000000151D74: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[54:61], v[38:45], v[46:53], v[54:61]// 000000151D78: CC404036 1CDA5D26
	s_waitcnt lgkmcnt(8)                                       // 000000151D80: BF89FC87
	s_delay_alu instid0(VALU_DEP_1)                            // 000000151D84: BF870001
	v_wmma_f32_16x16x16_f16 v[54:61], v[90:97], v[98:105], v[54:61]// 000000151D88: CC404036 1CDAC55A
	s_waitcnt lgkmcnt(5)                                       // 000000151D90: BF89FC57
	v_mul_f32_e32 v3, v20, v3                                  // 000000151D94: 10060714
	v_mul_f32_e32 v4, v20, v4                                  // 000000151D98: 10080914
	s_waitcnt lgkmcnt(2)                                       // 000000151D9C: BF89FC27
	v_mul_f32_e32 v5, v20, v5                                  // 000000151DA0: 100A0B14
	v_wmma_f32_16x16x16_f16 v[54:61], v[106:113], v[114:121], v[54:61]// 000000151DA4: CC404036 1CDAE56A
	s_waitcnt lgkmcnt(1)                                       // 000000151DAC: BF89FC17
	v_mul_f32_e32 v7, v20, v7                                  // 000000151DB0: 100E0F14
	v_mul_f32_e32 v6, v20, v6                                  // 000000151DB4: 100C0D14
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000151DB8: BF870193
	v_dual_mul_f32 v8, v20, v8 :: v_dual_fmac_f32 v3, 0x3b800000, v54// 000000151DBC: C8C01114 08026CFF 3B800000
	v_fmac_f32_e32 v7, 0x3b800000, v58                         // 000000151DC8: 560E74FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 000000151DD0: BF89FC07
	v_mul_f32_e32 v9, v20, v22                                 // 000000151DD4: 10122D14
	v_mul_f32_e32 v22, v20, v23                                // 000000151DD8: 102C2F14
	v_dual_fmac_f32 v4, 0x3b800000, v55 :: v_dual_fmac_f32 v5, 0x3b800000, v56// 000000151DDC: C8006EFF 040470FF 3B800000
	v_fmac_f32_e32 v8, 0x3b800000, v59                         // 000000151DE8: 561076FF 3B800000
	v_fmac_f32_e32 v6, 0x3b800000, v57                         // 000000151DF0: 560C72FF 3B800000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000151DF8: BF870004
	v_dual_fmac_f32 v22, 0x3b800000, v61 :: v_dual_fmac_f32 v9, 0x3b800000, v60// 000000151DFC: C8007AFF 160878FF 3B800000
	ds_store_2addr_b32 v21, v3, v4 offset0:16 offset1:18       // 000000151E08: D8381210 00040315
	ds_store_2addr_b32 v21, v5, v6 offset0:20 offset1:22       // 000000151E10: D8381614 00060515
	ds_store_2addr_b32 v21, v7, v8 offset0:24 offset1:26       // 000000151E18: D8381A18 00080715
	ds_store_2addr_b32 v21, v9, v22 offset0:28 offset1:30      // 000000151E20: D8381E1C 00160915
	s_cbranch_scc1 60288                                       // 000000151E28: BFA2EB80 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x32c>
	v_dual_mov_b32 v4, v18 :: v_dual_mov_b32 v5, v19           // 000000151E2C: CA100112 04040113
	v_dual_mov_b32 v6, v89 :: v_dual_mov_b32 v7, v75           // 000000151E34: CA100159 0606014B
	s_mov_b32 s6, 0                                            // 000000151E3C: BE860080
	s_waitcnt_vscnt null, 0x0                                  // 000000151E40: BC7C0000
	s_barrier                                                  // 000000151E44: BFBD0000
	buffer_gl0_inv                                             // 000000151E48: E0AC0000 00000000
	s_set_inst_prefetch_distance 0x1                           // 000000151E50: BF840001
	s_branch 28                                                // 000000151E54: BFA0001C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x55c8>
	s_nop 0                                                    // 000000151E58: BF800000
	s_nop 0                                                    // 000000151E5C: BF800000
	s_nop 0                                                    // 000000151E60: BF800000
	s_nop 0                                                    // 000000151E64: BF800000
	s_nop 0                                                    // 000000151E68: BF800000
	s_nop 0                                                    // 000000151E6C: BF800000
	s_nop 0                                                    // 000000151E70: BF800000
	s_nop 0                                                    // 000000151E74: BF800000
	s_nop 0                                                    // 000000151E78: BF800000
	s_nop 0                                                    // 000000151E7C: BF800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000151E80: 8C7E017E
	v_add_nc_u32_e32 v7, 0x80, v7                              // 000000151E84: 4A0E0EFF 00000080
	.long 0xd7000404                                           // 000000151E8C: D7000404
	v_cndmask_b32_e32 v0, v4, v136, vcc_lo                     // 000000151E90: 02011104
	ds_store_b16 v6, v3 offset:10240                           // 000000151E94: D87C2800 00000306
	v_add_nc_u32_e32 v6, 0x140, v6                             // 000000151E9C: 4A0C0CFF 00000140
	.long 0xd4490001                                           // 000000151EA4: D4490001
	v_cndmask_b32_e32 v1, 0x37f, v7, vcc_lo                    // 000000151EA8: 02020EFF 0000037F
	v_add_co_ci_u32_e64 v5, null, 0, v5, s4                    // 000000151EB0: D5207C05 00120A80
	s_or_b32 s6, s1, s6                                        // 000000151EB8: 8C060601
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000151EBC: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000151EC0: 917E067E
	s_cbranch_execz 13                                         // 000000151EC4: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x55fc>
	.long 0x7e063880                                           // 000000151EC8: 7E063880
	s_and_saveexec_b32 s1, s0                                  // 000000151ECC: BE812000
	s_cbranch_execz 65515                                      // 000000151ED0: BFA5FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5580>
	global_load_b32 v3, v[4:5], off                            // 000000151ED4: DC520000 037C0004
	ds_load_b32 v8, v88                                        // 000000151EDC: D8D80000 08000058
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000151EE4: BF890007
	v_mul_f32_e32 v3, v3, v8                                   // 000000151EE8: 10061103
	s_delay_alu instid0(VALU_DEP_1)                            // 000000151EEC: BF870001
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 000000151EF0: CC210003 02002503
	s_branch 65505                                             // 000000151EF8: BFA0FFE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5580>
	s_set_inst_prefetch_distance 0x2                           // 000000151EFC: BF840002
	s_or_b32 exec_lo, exec_lo, s6                              // 000000151F00: 8C7E067E
	v_lshl_add_u32 v21, s5, 2, v83                             // 000000151F04: D6460015 054D0405
	s_waitcnt lgkmcnt(0)                                       // 000000151F0C: BF89FC07
	s_barrier                                                  // 000000151F10: BFBD0000
	buffer_gl0_inv                                             // 000000151F14: E0AC0000 00000000
	ds_load_b128 v[22:25], v79                                 // 000000151F1C: DBFC0000 1600004F
	ds_load_b128 v[26:29], v79 offset:16                       // 000000151F24: DBFC0010 1A00004F
	ds_load_b128 v[30:33], v79 offset:32                       // 000000151F2C: DBFC0020 1E00004F
	ds_load_b128 v[34:37], v79 offset:48                       // 000000151F34: DBFC0030 2200004F
	ds_load_b128 v[38:41], v82                                 // 000000151F3C: DBFC0000 26000052
	ds_load_b128 v[42:45], v82 offset:16                       // 000000151F44: DBFC0010 2A000052
	ds_load_b128 v[46:49], v82 offset:32                       // 000000151F4C: DBFC0020 2E000052
	ds_load_b128 v[50:53], v82 offset:48                       // 000000151F54: DBFC0030 32000052
	ds_load_b128 v[58:61], v79 offset:80                       // 000000151F5C: DBFC0050 3A00004F
	ds_load_b128 v[54:57], v79 offset:64                       // 000000151F64: DBFC0040 3600004F
	ds_load_b128 v[94:97], v82 offset:80                       // 000000151F6C: DBFC0050 5E000052
	ds_load_b128 v[90:93], v82 offset:64                       // 000000151F74: DBFC0040 5A000052
	ds_load_b128 v[102:105], v79 offset:112                    // 000000151F7C: DBFC0070 6600004F
	ds_load_b128 v[98:101], v79 offset:96                      // 000000151F84: DBFC0060 6200004F
	ds_load_b128 v[110:113], v82 offset:112                    // 000000151F8C: DBFC0070 6E000052
	ds_load_b128 v[106:109], v82 offset:96                     // 000000151F94: DBFC0060 6A000052
	ds_load_2addr_b32 v[62:63], v21 offset1:2                  // 000000151F9C: D8DC0200 3E000015
	ds_load_2addr_b32 v[64:65], v21 offset0:4 offset1:6        // 000000151FA4: D8DC0604 40000015
	ds_load_2addr_b32 v[66:67], v21 offset0:8 offset1:10       // 000000151FAC: D8DC0A08 42000015
	ds_load_2addr_b32 v[122:123], v21 offset0:12 offset1:14    // 000000151FB4: D8DC0E0C 7A000015
	v_mov_b32_e32 v9, v2                                       // 000000151FBC: 7E120302
	v_mov_b32_e32 v3, v2                                       // 000000151FC0: 7E060302
	v_mov_b32_e32 v4, v2                                       // 000000151FC4: 7E080302
	v_mov_b32_e32 v5, v2                                       // 000000151FC8: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 000000151FCC: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 000000151FD0: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 000000151FD4: 7E100302
	v_mov_b32_e32 v121, v9                                     // 000000151FD8: 7EF20309
	v_dual_mov_b32 v117, v5 :: v_dual_mov_b32 v116, v4         // 000000151FDC: CA100105 75740104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000151FE4: BF870214
	v_dual_mov_b32 v119, v7 :: v_dual_mov_b32 v118, v6         // 000000151FE8: CA100107 77760106
	v_dual_mov_b32 v120, v8 :: v_dual_mov_b32 v115, v3         // 000000151FF0: CA100108 78720103
	v_mov_b32_e32 v114, v2                                     // 000000151FF8: 7EE40302
	s_waitcnt lgkmcnt(3)                                       // 000000151FFC: BF89FC37
	v_dual_mov_b32 v4, v18 :: v_dual_mul_f32 v3, v20, v62      // 000000152000: CA060112 04027D14
	v_mul_f32_e32 v8, v20, v63                                 // 000000152008: 10107F14
	s_waitcnt lgkmcnt(2)                                       // 00000015200C: BF89FC27
	v_mul_f32_e32 v9, v20, v64                                 // 000000152010: 10128114
	v_wmma_f32_16x16x16_f16 v[114:121], v[22:29], v[38:45], v[114:121]// 000000152014: CC404072 1DCA4D16
	v_mul_f32_e32 v22, v20, v65                                // 00000015201C: 102C8314
	s_waitcnt lgkmcnt(1)                                       // 000000152020: BF89FC17
	v_mul_f32_e32 v23, v20, v66                                // 000000152024: 102E8514
	v_dual_mul_f32 v24, v20, v67 :: v_dual_mov_b32 v5, v19     // 000000152028: C8D08714 18040113
	v_wmma_f32_16x16x16_f16 v[114:121], v[30:37], v[46:53], v[114:121]// 000000152030: CC404072 1DCA5D1E
	v_dual_mov_b32 v6, v89 :: v_dual_mov_b32 v7, v75           // 000000152038: CA100159 0606014B
	s_mov_b32 s6, 0                                            // 000000152040: BE860080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152044: BF870092
	v_wmma_f32_16x16x16_f16 v[114:121], v[54:61], v[90:97], v[114:121]// 000000152048: CC404072 1DCAB536
	v_wmma_f32_16x16x16_f16 v[114:121], v[98:105], v[106:113], v[114:121]// 000000152050: CC404072 1DCAD562
	s_waitcnt lgkmcnt(0)                                       // 000000152058: BF89FC07
	v_mul_f32_e32 v25, v20, v122                               // 00000015205C: 1032F514
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000152060: BF870192
	v_dual_mul_f32 v26, v20, v123 :: v_dual_fmac_f32 v3, 0x3b800000, v114// 000000152064: C8C0F714 1A02E4FF 3B800000
	v_dual_fmac_f32 v8, 0x3b800000, v115 :: v_dual_fmac_f32 v9, 0x3b800000, v116// 000000152070: C800E6FF 0808E8FF 3B800000
	v_dual_fmac_f32 v22, 0x3b800000, v117 :: v_dual_fmac_f32 v23, 0x3b800000, v118// 00000015207C: C800EAFF 1616ECFF 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000152088: BF870214
	v_dual_fmac_f32 v24, 0x3b800000, v119 :: v_dual_fmac_f32 v25, 0x3b800000, v120// 00000015208C: C800EEFF 1818F0FF 3B800000
	v_fmac_f32_e32 v26, 0x3b800000, v121                       // 000000152098: 5634F2FF 3B800000
	ds_store_2addr_b32 v21, v3, v8 offset1:2                   // 0000001520A0: D8380200 00080315
	ds_store_2addr_b32 v21, v9, v22 offset0:4 offset1:6        // 0000001520A8: D8380604 00160915
	ds_store_2addr_b32 v21, v23, v24 offset0:8 offset1:10      // 0000001520B0: D8380A08 00181715
	ds_store_2addr_b32 v21, v25, v26 offset0:12 offset1:14     // 0000001520B8: D8380E0C 001A1915
	s_waitcnt lgkmcnt(0)                                       // 0000001520C0: BF89FC07
	s_barrier                                                  // 0000001520C4: BFBD0000
	buffer_gl0_inv                                             // 0000001520C8: E0AC0000 00000000
	s_set_inst_prefetch_distance 0x1                           // 0000001520D0: BF840001
	s_branch 28                                                // 0000001520D4: BFA0001C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5848>
	s_nop 0                                                    // 0000001520D8: BF800000
	s_nop 0                                                    // 0000001520DC: BF800000
	s_nop 0                                                    // 0000001520E0: BF800000
	s_nop 0                                                    // 0000001520E4: BF800000
	s_nop 0                                                    // 0000001520E8: BF800000
	s_nop 0                                                    // 0000001520EC: BF800000
	s_nop 0                                                    // 0000001520F0: BF800000
	s_nop 0                                                    // 0000001520F4: BF800000
	s_nop 0                                                    // 0000001520F8: BF800000
	s_nop 0                                                    // 0000001520FC: BF800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000152100: 8C7E017E
	v_add_nc_u32_e32 v7, 0x80, v7                              // 000000152104: 4A0E0EFF 00000080
	.long 0xd7000404                                           // 00000015210C: D7000404
	v_cndmask_b32_e32 v0, v4, v136, vcc_lo                     // 000000152110: 02011104
	ds_store_b16 v6, v3 offset:10240                           // 000000152114: D87C2800 00000306
	v_add_nc_u32_e32 v6, 0x140, v6                             // 00000015211C: 4A0C0CFF 00000140
	.long 0xd4490001                                           // 000000152124: D4490001
	v_cndmask_b32_e32 v1, 0x37f, v7, vcc_lo                    // 000000152128: 02020EFF 0000037F
	v_add_co_ci_u32_e64 v5, null, 0, v5, s4                    // 000000152130: D5207C05 00120A80
	s_or_b32 s6, s1, s6                                        // 000000152138: 8C060601
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000015213C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000152140: 917E067E
	s_cbranch_execz 65217                                      // 000000152144: BFA5FEC1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534c>
	.long 0x7e063880                                           // 000000152148: 7E063880
	s_and_saveexec_b32 s1, s0                                  // 00000015214C: BE812000
	s_cbranch_execz 65515                                      // 000000152150: BFA5FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5800>
	global_load_b32 v3, v[4:5], off offset:64                  // 000000152154: DC520040 037C0004
	ds_load_b32 v8, v88                                        // 00000015215C: D8D80000 08000058
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000152164: BF890007
	v_mul_f32_e32 v3, v3, v8                                   // 000000152168: 10061103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015216C: BF870001
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 000000152170: CC210003 02002503
	s_branch 65505                                             // 000000152178: BFA0FFE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5800>
	ds_load_b32 v3, v87                                        // 00000015217C: D8D80000 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000152184: BF89FC07
	v_fma_f32 v3, v42, v3, 0                                   // 000000152188: D6130003 0202072A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152190: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000152194: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[70:71]           // 00000015219C: D6FE7C03 051A0EFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000001521A8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001521B0: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000001521B4: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 0000001521C0: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001521C8: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000001521CC: BE802004
	s_cbranch_execz 65035                                      // 0000001521D0: BFA5FE0B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5100>
	ds_load_b32 v3, v87 offset:8                               // 0000001521D4: D8D80008 03000057
	s_waitcnt lgkmcnt(0)                                       // 0000001521DC: BF89FC07
	v_fma_f32 v3, v43, v3, 0                                   // 0000001521E0: D6130003 0202072B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001521E8: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 0000001521EC: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[70:71]           // 0000001521F4: D6FE7C03 051A10FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152200: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152208: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000015220C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 000000152218: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152220: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000152224: BE802005
	s_cbranch_execz 65016                                      // 000000152228: BFA5FDF8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510c>
	ds_load_b32 v3, v87 offset:16                              // 00000015222C: D8D80010 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000152234: BF89FC07
	v_fma_f32 v3, v44, v3, 0                                   // 000000152238: D6130003 0202072C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152240: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000152244: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[70:71]           // 00000015224C: D6FE7C03 051A12FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152258: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152260: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000152264: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 000000152270: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152278: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000015227C: BE802006
	s_cbranch_execz 64997                                      // 000000152280: BFA5FDE5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5118>
	ds_load_b32 v3, v87 offset:24                              // 000000152284: D8D80018 03000057
	s_waitcnt lgkmcnt(0)                                       // 00000015228C: BF89FC07
	v_fma_f32 v3, v45, v3, 0                                   // 000000152290: D6130003 0202072D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152298: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000015229C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v90, v[70:71]          // 0000001522A4: D6FE7C03 051AB4FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000001522B0: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001522B8: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000001522BC: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 0000001522C8: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001522D0: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001522D4: BE802007
	s_cbranch_execz 64978                                      // 0000001522D8: BFA5FDD2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5124>
	ds_load_b32 v3, v87 offset:32                              // 0000001522DC: D8D80020 03000057
	s_waitcnt lgkmcnt(0)                                       // 0000001522E4: BF89FC07
	v_fma_f32 v3, v46, v3, 0                                   // 0000001522E8: D6130003 0202072E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001522F0: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 0000001522F4: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v91, v[70:71]          // 0000001522FC: D6FE7C03 051AB6FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152308: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152310: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000152314: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 000000152320: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152328: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000015232C: BE802008
	s_cbranch_execz 64959                                      // 000000152330: BFA5FDBF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5130>
	ds_load_b32 v3, v87 offset:40                              // 000000152334: D8D80028 03000057
	s_waitcnt lgkmcnt(0)                                       // 00000015233C: BF89FC07
	v_fma_f32 v3, v47, v3, 0                                   // 000000152340: D6130003 0202072F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152348: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000015234C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v92, v[70:71]          // 000000152354: D6FE7C03 051AB8FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152360: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152368: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000015236C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 000000152378: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152380: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000152384: BE802009
	s_cbranch_execz 64940                                      // 000000152388: BFA5FDAC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x513c>
	ds_load_b32 v3, v87 offset:48                              // 00000015238C: D8D80030 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000152394: BF89FC07
	v_fma_f32 v3, v48, v3, 0                                   // 000000152398: D6130003 02020730
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001523A0: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 0000001523A4: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v93, v[70:71]          // 0000001523AC: D6FE7C03 051ABAFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000001523B8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001523C0: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000001523C4: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 0000001523D0: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001523D8: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001523DC: BE80200A
	s_cbranch_execz 64921                                      // 0000001523E0: BFA5FD99 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5148>
	ds_load_b32 v3, v87 offset:56                              // 0000001523E4: D8D80038 03000057
	s_waitcnt lgkmcnt(0)                                       // 0000001523EC: BF89FC07
	v_fma_f32 v3, v49, v3, 0                                   // 0000001523F0: D6130003 02020731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001523F8: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 0000001523FC: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v94, v[70:71]          // 000000152404: D6FE7C03 051ABCFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152410: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152418: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000015241C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 000000152428: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152430: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 000000152434: BE802001
	s_cbranch_execz 64902                                      // 000000152438: BFA5FD86 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5154>
	ds_load_b32 v3, v87                                        // 00000015243C: D8D80000 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000152444: BF89FC07
	v_fma_f32 v3, v34, v3, 0                                   // 000000152448: D6130003 02020722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152450: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000152454: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[70:71]           // 00000015245C: D6FE7C03 051A0EFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152468: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152470: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000152474: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 000000152480: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152488: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000015248C: BE802004
	s_cbranch_execz 64883                                      // 000000152490: BFA5FD73 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5160>
	ds_load_b32 v3, v87 offset:8                               // 000000152494: D8D80008 03000057
	s_waitcnt lgkmcnt(0)                                       // 00000015249C: BF89FC07
	v_fma_f32 v3, v35, v3, 0                                   // 0000001524A0: D6130003 02020723
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001524A8: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 0000001524AC: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[70:71]           // 0000001524B4: D6FE7C03 051A10FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000001524C0: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001524C8: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000001524CC: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 0000001524D8: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001524E0: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000001524E4: BE802005
	s_cbranch_execz 64864                                      // 0000001524E8: BFA5FD60 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x516c>
	ds_load_b32 v3, v87 offset:16                              // 0000001524EC: D8D80010 03000057
	s_waitcnt lgkmcnt(0)                                       // 0000001524F4: BF89FC07
	v_fma_f32 v3, v36, v3, 0                                   // 0000001524F8: D6130003 02020724
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152500: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000152504: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[70:71]           // 00000015250C: D6FE7C03 051A12FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152518: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152520: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000152524: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 000000152530: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152538: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000015253C: BE802006
	s_cbranch_execz 64845                                      // 000000152540: BFA5FD4D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5178>
	ds_load_b32 v3, v87 offset:24                              // 000000152544: D8D80018 03000057
	s_waitcnt lgkmcnt(0)                                       // 00000015254C: BF89FC07
	v_fma_f32 v3, v37, v3, 0                                   // 000000152550: D6130003 02020725
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152558: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000015255C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v90, v[70:71]          // 000000152564: D6FE7C03 051AB4FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152570: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152578: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000015257C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 000000152588: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152590: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000152594: BE802007
	s_cbranch_execz 64826                                      // 000000152598: BFA5FD3A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5184>
	ds_load_b32 v3, v87 offset:32                              // 00000015259C: D8D80020 03000057
	s_waitcnt lgkmcnt(0)                                       // 0000001525A4: BF89FC07
	v_fma_f32 v3, v38, v3, 0                                   // 0000001525A8: D6130003 02020726
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001525B0: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 0000001525B4: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v91, v[70:71]          // 0000001525BC: D6FE7C03 051AB6FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000001525C8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001525D0: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000001525D4: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 0000001525E0: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001525E8: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001525EC: BE802008
	s_cbranch_execz 64807                                      // 0000001525F0: BFA5FD27 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5190>
	ds_load_b32 v3, v87 offset:40                              // 0000001525F4: D8D80028 03000057
	s_waitcnt lgkmcnt(0)                                       // 0000001525FC: BF89FC07
	v_fma_f32 v3, v39, v3, 0                                   // 000000152600: D6130003 02020727
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152608: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000015260C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v92, v[70:71]          // 000000152614: D6FE7C03 051AB8FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152620: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152628: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000015262C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 000000152638: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152640: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000152644: BE802009
	s_cbranch_execz 64788                                      // 000000152648: BFA5FD14 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x519c>
	ds_load_b32 v3, v87 offset:48                              // 00000015264C: D8D80030 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000152654: BF89FC07
	v_fma_f32 v3, v40, v3, 0                                   // 000000152658: D6130003 02020728
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152660: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000152664: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v93, v[70:71]          // 00000015266C: D6FE7C03 051ABAFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152678: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152680: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000152684: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 000000152690: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152698: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000015269C: BE80200A
	s_cbranch_execz 64769                                      // 0000001526A0: BFA5FD01 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51a8>
	ds_load_b32 v3, v87 offset:56                              // 0000001526A4: D8D80038 03000057
	s_waitcnt lgkmcnt(0)                                       // 0000001526AC: BF89FC07
	v_fma_f32 v3, v41, v3, 0                                   // 0000001526B0: D6130003 02020729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001526B8: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 0000001526BC: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v94, v[70:71]          // 0000001526C4: D6FE7C03 051ABCFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000001526D0: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001526D8: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000001526DC: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 0000001526E8: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001526F0: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001526F4: BE802001
	s_cbranch_execz 64750                                      // 0000001526F8: BFA5FCEE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51b4>
	ds_load_b32 v3, v87                                        // 0000001526FC: D8D80000 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000152704: BF89FC07
	v_fma_f32 v3, v26, v3, 0                                   // 000000152708: D6130003 0202071A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152710: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000152714: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[70:71]           // 00000015271C: D6FE7C03 051A0EFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152728: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152730: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000152734: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 000000152740: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152748: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000015274C: BE802004
	s_cbranch_execz 64731                                      // 000000152750: BFA5FCDB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51c0>
	ds_load_b32 v3, v87 offset:8                               // 000000152754: D8D80008 03000057
	s_waitcnt lgkmcnt(0)                                       // 00000015275C: BF89FC07
	v_fma_f32 v3, v27, v3, 0                                   // 000000152760: D6130003 0202071B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152768: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000015276C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[70:71]           // 000000152774: D6FE7C03 051A10FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152780: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152788: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000015278C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 000000152798: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001527A0: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000001527A4: BE802005
	s_cbranch_execz 64712                                      // 0000001527A8: BFA5FCC8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51cc>
	ds_load_b32 v3, v87 offset:16                              // 0000001527AC: D8D80010 03000057
	s_waitcnt lgkmcnt(0)                                       // 0000001527B4: BF89FC07
	v_fma_f32 v3, v28, v3, 0                                   // 0000001527B8: D6130003 0202071C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001527C0: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 0000001527C4: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[70:71]           // 0000001527CC: D6FE7C03 051A12FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000001527D8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001527E0: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000001527E4: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 0000001527F0: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001527F8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000001527FC: BE802006
	s_cbranch_execz 64693                                      // 000000152800: BFA5FCB5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51d8>
	ds_load_b32 v3, v87 offset:24                              // 000000152804: D8D80018 03000057
	s_waitcnt lgkmcnt(0)                                       // 00000015280C: BF89FC07
	v_fma_f32 v3, v29, v3, 0                                   // 000000152810: D6130003 0202071D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152818: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000015281C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v90, v[70:71]          // 000000152824: D6FE7C03 051AB4FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152830: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152838: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000015283C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 000000152848: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152850: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000152854: BE802007
	s_cbranch_execz 64674                                      // 000000152858: BFA5FCA2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51e4>
	ds_load_b32 v3, v87 offset:32                              // 00000015285C: D8D80020 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000152864: BF89FC07
	v_fma_f32 v3, v30, v3, 0                                   // 000000152868: D6130003 0202071E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152870: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000152874: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v91, v[70:71]          // 00000015287C: D6FE7C03 051AB6FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152888: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152890: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000152894: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 0000001528A0: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001528A8: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001528AC: BE802008
	s_cbranch_execz 64655                                      // 0000001528B0: BFA5FC8F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51f0>
	ds_load_b32 v3, v87 offset:40                              // 0000001528B4: D8D80028 03000057
	s_waitcnt lgkmcnt(0)                                       // 0000001528BC: BF89FC07
	v_fma_f32 v3, v31, v3, 0                                   // 0000001528C0: D6130003 0202071F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001528C8: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 0000001528CC: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v92, v[70:71]          // 0000001528D4: D6FE7C03 051AB8FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000001528E0: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001528E8: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000001528EC: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 0000001528F8: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152900: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000152904: BE802009
	s_cbranch_execz 64636                                      // 000000152908: BFA5FC7C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51fc>
	ds_load_b32 v3, v87 offset:48                              // 00000015290C: D8D80030 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000152914: BF89FC07
	v_fma_f32 v3, v32, v3, 0                                   // 000000152918: D6130003 02020720
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152920: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000152924: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v93, v[70:71]          // 00000015292C: D6FE7C03 051ABAFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152938: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152940: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000152944: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 000000152950: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152958: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000015295C: BE80200A
	s_cbranch_execz 64617                                      // 000000152960: BFA5FC69 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5208>
	ds_load_b32 v3, v87 offset:56                              // 000000152964: D8D80038 03000057
	s_waitcnt lgkmcnt(0)                                       // 00000015296C: BF89FC07
	v_fma_f32 v3, v33, v3, 0                                   // 000000152970: D6130003 02020721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152978: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000015297C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v94, v[70:71]          // 000000152984: D6FE7C03 051ABCFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152990: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152998: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000015299C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 0000001529A8: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001529B0: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001529B4: BE802001
	s_cbranch_execz 64598                                      // 0000001529B8: BFA5FC56 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5214>
	ds_load_b32 v3, v87                                        // 0000001529BC: D8D80000 03000057
	s_waitcnt lgkmcnt(0)                                       // 0000001529C4: BF89FC07
	v_fma_f32 v3, v18, v3, 0                                   // 0000001529C8: D6130003 02020712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001529D0: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 0000001529D4: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[70:71]           // 0000001529DC: D6FE7C03 051A0EFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000001529E8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001529F0: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000001529F4: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000152A00: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152A08: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000152A0C: BE802004
	s_cbranch_execz 64579                                      // 000000152A10: BFA5FC43 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5220>
	ds_load_b32 v3, v87 offset:8                               // 000000152A14: D8D80008 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000152A1C: BF89FC07
	v_fma_f32 v3, v19, v3, 0                                   // 000000152A20: D6130003 02020713
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152A28: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000152A2C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[70:71]           // 000000152A34: D6FE7C03 051A10FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152A40: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152A48: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000152A4C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000152A58: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152A60: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000152A64: BE802005
	s_cbranch_execz 64560                                      // 000000152A68: BFA5FC30 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x522c>
	ds_load_b32 v3, v87 offset:16                              // 000000152A6C: D8D80010 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000152A74: BF89FC07
	v_fma_f32 v3, v20, v3, 0                                   // 000000152A78: D6130003 02020714
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152A80: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000152A84: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[70:71]           // 000000152A8C: D6FE7C03 051A12FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152A98: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152AA0: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000152AA4: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000152AB0: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152AB8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000152ABC: BE802006
	s_cbranch_execz 64541                                      // 000000152AC0: BFA5FC1D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5238>
	ds_load_b32 v3, v87 offset:24                              // 000000152AC4: D8D80018 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000152ACC: BF89FC07
	v_fma_f32 v3, v21, v3, 0                                   // 000000152AD0: D6130003 02020715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152AD8: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000152ADC: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v90, v[70:71]          // 000000152AE4: D6FE7C03 051AB4FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152AF0: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152AF8: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000152AFC: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000152B08: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152B10: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000152B14: BE802007
	s_cbranch_execz 64522                                      // 000000152B18: BFA5FC0A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5244>
	ds_load_b32 v3, v87 offset:32                              // 000000152B1C: D8D80020 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000152B24: BF89FC07
	v_fma_f32 v3, v22, v3, 0                                   // 000000152B28: D6130003 02020716
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152B30: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000152B34: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v91, v[70:71]          // 000000152B3C: D6FE7C03 051AB6FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152B48: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152B50: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000152B54: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000152B60: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152B68: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 000000152B6C: BE802008
	s_cbranch_execz 64503                                      // 000000152B70: BFA5FBF7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5250>
	ds_load_b32 v3, v87 offset:40                              // 000000152B74: D8D80028 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000152B7C: BF89FC07
	v_fma_f32 v3, v23, v3, 0                                   // 000000152B80: D6130003 02020717
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152B88: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000152B8C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v92, v[70:71]          // 000000152B94: D6FE7C03 051AB8FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152BA0: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152BA8: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000152BAC: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000152BB8: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152BC0: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000152BC4: BE802009
	s_cbranch_execz 64484                                      // 000000152BC8: BFA5FBE4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x525c>
	ds_load_b32 v3, v87 offset:48                              // 000000152BCC: D8D80030 03000057
	s_waitcnt lgkmcnt(0)                                       // 000000152BD4: BF89FC07
	v_fma_f32 v3, v24, v3, 0                                   // 000000152BD8: D6130003 02020718
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152BE0: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000152BE4: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v93, v[70:71]          // 000000152BEC: D6FE7C03 051ABAFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000152BF8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152C00: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000152C04: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000152C10: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000152C18: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 000000152C1C: BE80200A
	s_cbranch_execnz 64465                                     // 000000152C20: BFA6FBD1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5268>
	s_branch 64483                                             // 000000152C24: BFA0FBE3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x52b4>
	v_dual_mov_b32 v2, v75 :: v_dual_mov_b32 v3, v1            // 000000152C28: CA10014B 02020101
	s_add_u32 s0, s33, s16                                     // 000000152C30: 80001021
	.long 0xd73c0000                                           // 000000152C34: D73C0000
	v_cndmask_b32_e32 v1, 9, v68, vcc_lo                       // 000000152C38: 02028889
	s_addc_u32 s1, s34, s17                                    // 000000152C3C: 82011122
	s_add_u32 s2, s28, s14                                     // 000000152C40: 80020E1C
	s_addc_u32 s3, s29, s15                                    // 000000152C44: 82030F1D
	s_add_u32 s0, s2, s0                                       // 000000152C48: 80000002
	s_addc_u32 s1, s3, s1                                      // 000000152C4C: 82010103
	v_lshlrev_b32_e32 v4, 2, v74                               // 000000152C50: 30089482
	.long 0xd7006a00                                           // 000000152C54: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000152C58: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000152C5C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000152C60: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000152C68: BE810080
	.long 0xd7006a00                                           // 000000152C6C: D7006A00
	v_cndmask_b32_e32 v1, v0, v4, vcc_lo                       // 000000152C70: 02020900
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000152C74: D5207C01 01AA0280
	v_mul_u32_u24_e32 v4, 0x210, v74                           // 000000152C7C: 160894FF 00000210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152C84: BF870093
	.long 0xd7006a00                                           // 000000152C88: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 000000152C8C: 0202000C
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 000000152C90: D5207C01 01AA020D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000152C98: BF870003
	v_lshl_add_u32 v3, v3, 2, v4                               // 000000152C9C: D6460003 04110503
	s_nop 0                                                    // 000000152CA4: BF800000
	s_nop 0                                                    // 000000152CA8: BF800000
	s_nop 0                                                    // 000000152CAC: BF800000
	s_nop 0                                                    // 000000152CB0: BF800000
	s_nop 0                                                    // 000000152CB4: BF800000
	s_nop 0                                                    // 000000152CB8: BF800000
	s_nop 0                                                    // 000000152CBC: BF800000
	ds_load_b32 v4, v3 offset:12800                            // 000000152CC0: D8D83200 04000003
	v_add_nc_u32_e32 v2, 0x80, v2                              // 000000152CC8: 4A0404FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 000000152CD0: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000152CD4: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v2                        // 000000152CD8: 7C9204FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 000000152CE0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 000000152CE4: BF89FC07
	global_store_b32 v[0:1], v4, off                           // 000000152CE8: DC6A0000 007C0400
	.long 0xd7000000                                           // 000000152CF0: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 000000152CF4: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 000000152CFC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000152D04: 917E017E
	s_cbranch_execnz 65517                                     // 000000152D08: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi3EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x63c0>
	s_nop 0                                                    // 000000152D0C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000152D10: BFB60003
	s_endpgm                                                   // 000000152D14: BFB00000
		...

