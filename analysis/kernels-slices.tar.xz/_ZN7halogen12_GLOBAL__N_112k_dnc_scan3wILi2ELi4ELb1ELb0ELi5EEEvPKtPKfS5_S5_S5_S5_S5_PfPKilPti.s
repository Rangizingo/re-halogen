0000000000159400 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_load_b512 s[12:27], s[0:1], 0x18                         // 000000159400: F4100300 F8000018
	s_lshl_b32 s4, s3, 6                                       // 000000159408: 84048603
	s_ashr_i32 s3, s2, 31                                      // 00000015940C: 86039F02
	s_ashr_i32 s5, s4, 31                                      // 000000159410: 86059F04
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v75, 63, v0        // 000000159414: CA240100 044A00BF
	s_movk_i32 s7, 0x210                                       // 00000015941C: B0070210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000159420: BF8704D1
	v_lshlrev_b32_e32 v2, 2, v75                               // 000000159424: 30049682
	v_mad_u32_u24 v1, v75, s7, 0x3200                          // 000000159428: D60B0001 03FC0F4B 00003200
	s_waitcnt lgkmcnt(0)                                       // 000000159434: BF89FC07
	s_load_b32 s6, s[22:23], null                              // 000000159438: F400018B F8000000
	s_lshl_b64 s[22:23], s[24:25], 2                           // 000000159440: 84968218
	s_add_u32 s8, s20, s22                                     // 000000159444: 80081614
	s_addc_u32 s9, s21, s23                                    // 000000159448: 82091715
	s_lshl_b64 s[34:35], s[2:3], 16                            // 00000015944C: 84A29002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000159450: BF870009
	s_add_u32 s8, s8, s34                                      // 000000159454: 80082208
	s_addc_u32 s9, s9, s35                                     // 000000159458: 82092309
	s_waitcnt lgkmcnt(0)                                       // 00000015945C: BF89FC07
	s_mul_i32 s40, s6, 0x9000000                               // 000000159460: 9628FF06 09000000
	s_mul_hi_i32 s33, s6, 0x9000000                            // 000000159468: 9721FF06 09000000
	s_add_u32 s6, s8, s40                                      // 000000159470: 80062808
	s_addc_u32 s8, s9, s33                                     // 000000159474: 82082109
	s_lshl_b64 s[36:37], s[4:5], 2                             // 000000159478: 84A48204
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000015947C: BF8700B9
	s_add_u32 s6, s6, s36                                      // 000000159480: 80062406
	s_addc_u32 s7, s8, s37                                     // 000000159484: 82072508
	.long 0xd7000602                                           // 000000159488: D7000602
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 00000015948C: 02020406
	v_add_co_ci_u32_e64 v3, null, s7, 0, s6                    // 000000159490: D5207C03 00190007
	s_mov_b32 s6, 0                                            // 000000159498: BE860080
	s_nop 0                                                    // 00000015949C: BF800000
	s_nop 0                                                    // 0000001594A0: BF800000
	s_nop 0                                                    // 0000001594A4: BF800000
	s_nop 0                                                    // 0000001594A8: BF800000
	s_nop 0                                                    // 0000001594AC: BF800000
	s_nop 0                                                    // 0000001594B0: BF800000
	s_nop 0                                                    // 0000001594B4: BF800000
	s_nop 0                                                    // 0000001594B8: BF800000
	s_nop 0                                                    // 0000001594BC: BF800000
	v_lshrrev_b32_e32 v7, 6, v4                                // 0000001594C0: 320E0886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001594C4: BF870121
	v_lshlrev_b32_e32 v5, 9, v7                                // 0000001594C8: 300A0E89
	v_lshl_add_u32 v7, v7, 2, v1                               // 0000001594CC: D6460007 04050507
	.long 0xd7006a05                                           // 0000001594D4: D7006A05
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 0000001594D8: 02020B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001594DC: BF8700D1
	v_add_co_ci_u32_e64 v6, null, 0, v3, vcc_lo                // 0000001594E0: D5207C06 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001594E8: 7C9208FF 00001F7F
	global_load_b32 v5, v[5:6], off                            // 0000001594F0: DC520000 057C0005
	v_add_nc_u32_e32 v6, 0x80, v4                              // 0000001594F8: 4A0C08FF 00000080
	s_or_b32 s6, vcc_lo, s6                                    // 000000159500: 8C06066A
	v_mov_b32_e32 v4, v6                                       // 000000159504: 7E080306
	s_waitcnt vmcnt(0)                                         // 000000159508: BF8903F7
	ds_store_b32 v7, v5                                        // 00000015950C: D8340000 00000507
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000159514: 917E067E
	s_cbranch_execnz 65513                                     // 000000159518: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000015951C: 8C7E067E
	s_mov_b32 s6, 0                                            // 000000159520: BE860080
	s_mov_b32 s7, 1                                            // 000000159524: BE870081
	s_mov_b32 s10, s6                                          // 000000159528: BE8A0006
	s_mov_b32 s8, s6                                           // 00000015952C: BE880006
	s_set_inst_prefetch_distance 0x1                           // 000000159530: BF840001
	s_branch 10                                                // 000000159534: BFA0000A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x160>
	s_nop 0                                                    // 000000159538: BF800000
	s_nop 0                                                    // 00000015953C: BF800000
	s_or_b32 exec_lo, exec_lo, s11                             // 000000159540: 8C7E0B7E
	s_add_i32 s8, s8, 2                                        // 000000159544: 81088208
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000159548: BF8704A9
	.long 0xd44a0009                                           // 00000015954C: D44A0009
	v_cndmask_b32_e32 v0, s8, v138, vcc_lo                     // 000000159550: 02011408
	s_or_b32 s10, s9, s10                                      // 000000159554: 8C0A0A09
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000159558: 917E0A7E
	s_cbranch_execz 21                                         // 00000015955C: BFA50015 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b4>
	s_mov_b32 s9, s8                                           // 000000159560: BE890008
	v_lshl_or_b32 v1, s8, 7, v0                                // 000000159564: D6560001 04010E08
	s_or_b64 s[24:25], s[8:9], s[6:7]                          // 00000015956C: 8C980608
	s_mov_b32 s11, exec_lo                                     // 000000159570: BE8B007E
	.long 0xd44b0009                                           // 000000159574: D44B0009
	v_cndmask_b32_e32 v0, s25, v137, vcc_lo                    // 000000159578: 02011219
	.long 0xd4cb007e                                           // 00000015957C: D4CB007E
	v_cndmask_b32_e32 v0, s24, v137, vcc_lo                    // 000000159580: 02011218
	v_lshlrev_b32_e32 v3, 1, v1                                // 000000159584: 30060281
	.long 0x7e043880                                           // 000000159588: 7E043880
	ds_store_b16 v3, v2 offset:10240                           // 00000015958C: D87C2800 00000203
	s_or_b32 exec_lo, exec_lo, s11                             // 000000159594: 8C7E0B7E
	s_and_saveexec_b32 s11, s9                                 // 000000159598: BE8B2009
	s_cbranch_execz 65512                                      // 00000015959C: BFA5FFE8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x140>
	v_lshlrev_b32_e32 v2, 1, v1                                // 0000001595A0: 30040281
	.long 0x7e023880                                           // 0000001595A4: 7E023880
	ds_store_b16 v2, v1 offset:10496                           // 0000001595A8: D87C2900 00000102
	s_branch 65507                                             // 0000001595B0: BFA0FFE3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x140>
	s_set_inst_prefetch_distance 0x2                           // 0000001595B4: BF840002
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001595B8: 8C7E0A7E
	s_load_b32 s41, s[0:1], 0x58                               // 0000001595BC: F4000A40 F8000058
	s_waitcnt lgkmcnt(0)                                       // 0000001595C4: BF89FC07
	s_barrier                                                  // 0000001595C8: BFBD0000
	buffer_gl0_inv                                             // 0000001595CC: E0AC0000 00000000
	s_cmp_lt_i32 s41, 1                                        // 0000001595D4: BF048129
	s_cbranch_scc1 6774                                        // 0000001595D8: BFA21A76 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6bb4>
	s_load_b64 s[38:39], s[0:1], 0x8                           // 0000001595DC: F4040980 F8000008
	s_add_i32 s0, s41, 63                                      // 0000001595E4: 8100BF29
	s_add_i32 s42, s2, 0xbd0                                   // 0000001595E8: 812AFF02 00000BD0
	s_lshr_b32 s43, s0, 6                                      // 0000001595F0: 852B8600
	s_add_u32 s6, s14, s36                                     // 0000001595F4: 8006240E
	s_addc_u32 s7, s15, s37                                    // 0000001595F8: 8207250F
	s_mov_b32 s15, 0                                           // 0000001595FC: BE8F0080
	v_lshrrev_b32_e32 v76, 5, v0                               // 000000159600: 32980085
	s_mov_b32 s24, s15                                         // 000000159604: BE98000F
	s_mov_b32 s25, s15                                         // 000000159608: BE99000F
	s_mov_b32 s28, s15                                         // 00000015960C: BE9C000F
	s_mov_b32 s29, s15                                         // 000000159610: BE9D000F
	s_mov_b32 s30, s15                                         // 000000159614: BE9E000F
	s_mov_b32 s31, s15                                         // 000000159618: BE9F000F
	v_lshlrev_b32_e32 v3, 8, v0                                // 00000015961C: 30060088
	v_and_b32_e32 v2, 15, v0                                   // 000000159620: 3604008F
	s_movk_i32 s0, 0x210                                       // 000000159624: B0000210
	v_bfe_u32 v4, v0, 4, 1                                     // 000000159628: D6100004 02050900
	v_mul_u32_u24_e32 v9, 0xa00, v76                           // 000000159630: 161298FF 00000A00
	v_and_b32_e32 v3, 0xf00, v3                                // 000000159638: 360606FF 00000F00
	v_mad_u32_u24 v79, v2, s0, 0x3200                          // 000000159640: D60B004F 03FC0102 00003200
	s_lshl_b32 s0, s2, 7                                       // 00000015964C: 84008702
	v_mul_u32_u24_e32 v83, 0xa0, v2                            // 000000159650: 16A604FF 000000A0
	s_ashr_i32 s1, s0, 31                                      // 000000159658: 86019F00
	v_lshl_or_b32 v3, v76, 12, v3                              // 00000015965C: D6560003 040D194C
	s_lshl_b64 s[0:1], s[0:1], 1                               // 000000159664: 84808100
	v_lshl_or_b32 v77, v0, 2, 0xb600                           // 000000159668: D656004D 03FD0500 0000B600
	s_mov_b32 s44, 0x41800000                                  // 000000159674: BEAC00FF 41800000
	s_mov_b32 s45, 0                                           // 00000015967C: BEAD0080
	.long 0xd7000851                                           // 000000159680: D7000851
	v_cndmask_b32_e32 v1, s18, v3, vcc_lo                      // 000000159684: 02020612
	s_delay_alu instid0(VALU_DEP_1)                            // 000000159688: BF870001
	v_add_co_ci_u32_e64 v82, null, s19, 0, s8                  // 00000015968C: D5207C52 00210013
	s_add_u32 s8, s26, s0                                      // 000000159694: 8008001A
	s_addc_u32 s9, s27, s1                                     // 000000159698: 8209011B
	s_mov_b32 s26, s15                                         // 00000015969C: BE9A000F
	s_mov_b32 s27, s15                                         // 0000001596A0: BE9B000F
	v_lshlrev_b32_e32 v1, 4, v76                               // 0000001596A4: 30029884
	v_lshlrev_b32_e32 v3, 2, v2                                // 0000001596A8: 30060482
	s_lshl_b64 s[0:1], s[4:5], 1                               // 0000001596AC: 84808104
	s_movk_i32 s4, 0x2800                                      // 0000001596B0: B0042800
	s_add_u32 s0, s8, s0                                       // 0000001596B4: 80000008
	v_or_b32_e32 v78, v1, v2                                   // 0000001596B8: 389C0501
	v_or_b32_e32 v80, v1, v4                                   // 0000001596BC: 38A00901
	v_mad_u32_u24 v1, 0x2100, v76, v79                         // 0000001596C0: D60B0001 053E98FF 00002100
	s_addc_u32 s1, s9, s1                                      // 0000001596CC: 82010109
	v_mad_u32_u24 v84, 0xa0, v2, s4                            // 0000001596D0: D60B0054 001204FF 000000A0
	.long 0xd7000456                                           // 0000001596DC: D7000456
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 0000001596E0: 02020606
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001596E4: BF870253
	v_lshl_or_b32 v85, v4, 2, v1                               // 0000001596E8: D6560055 04050504
	v_lshlrev_b32_e32 v1, 1, v2                                // 0000001596F0: 30020481
	v_add_co_ci_u32_e64 v87, null, s7, 0, s4                   // 0000001596F4: D5207C57 00110007
	v_lshl_add_u32 v88, v80, 1, v83                            // 0000001596FC: D6460058 054D0350
	v_lshl_or_b32 v89, v80, 2, 0xb600                          // 000000159704: D6560059 03FD0550 0000B600
	.long 0xd7000049                                           // 000000159710: D7000049
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 000000159714: 02020200
	v_mov_b32_e32 v1, s24                                      // 000000159718: 7E020218
	v_add_co_ci_u32_e64 v74, null, s1, 0, s0                   // 00000015971C: D5207C4A 00010001
	v_dual_mov_b32 v2, s25 :: v_dual_mov_b32 v3, s26           // 000000159724: CA100019 0202001A
	v_add_nc_u32_e32 v90, v83, v9                              // 00000015972C: 4AB41353
	v_dual_mov_b32 v4, s27 :: v_dual_mov_b32 v5, s28           // 000000159730: CA10001B 0404001C
	v_dual_mov_b32 v6, s29 :: v_dual_mov_b32 v7, s30           // 000000159738: CA10001D 0606001E
	v_mov_b32_e32 v8, s31                                      // 000000159740: 7E10021F
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 000000159744: 7C9800C0
	s_branch 828                                               // 000000159748: BFA0033C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x103c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015974C: 8C7E007E
	s_waitcnt_vscnt null, 0x0                                  // 000000159750: BC7C0000
	s_barrier                                                  // 000000159754: BFBD0000
	buffer_gl0_inv                                             // 000000159758: E0AC0000 00000000
	s_barrier                                                  // 000000159760: BFBD0000
	buffer_gl0_inv                                             // 000000159764: E0AC0000 00000000
	ds_load_b128 v[17:20], v84                                 // 00000015976C: DBFC0000 11000054
	ds_load_b128 v[21:24], v84 offset:16                       // 000000159774: DBFC0010 15000054
	ds_load_b128 v[25:28], v84 offset:32                       // 00000015977C: DBFC0020 19000054
	ds_load_b128 v[29:32], v84 offset:48                       // 000000159784: DBFC0030 1D000054
	ds_load_b128 v[33:36], v90                                 // 00000015978C: DBFC0000 2100005A
	ds_load_b128 v[37:40], v90 offset:16                       // 000000159794: DBFC0010 2500005A
	ds_load_b128 v[41:44], v90 offset:32                       // 00000015979C: DBFC0020 2900005A
	ds_load_b128 v[45:48], v90 offset:48                       // 0000001597A4: DBFC0030 2D00005A
	ds_load_b128 v[53:56], v84 offset:80                       // 0000001597AC: DBFC0050 35000054
	ds_load_b128 v[49:52], v84 offset:64                       // 0000001597B4: DBFC0040 31000054
	ds_load_b128 v[61:64], v90 offset:80                       // 0000001597BC: DBFC0050 3D00005A
	ds_load_b128 v[57:60], v90 offset:64                       // 0000001597C4: DBFC0040 3900005A
	ds_load_b128 v[69:72], v84 offset:112                      // 0000001597CC: DBFC0070 45000054
	ds_load_b128 v[65:68], v84 offset:96                       // 0000001597D4: DBFC0060 41000054
	ds_load_b128 v[95:98], v90 offset:112                      // 0000001597DC: DBFC0070 5F00005A
	ds_load_b128 v[91:94], v90 offset:96                       // 0000001597E4: DBFC0060 5B00005A
	ds_load_2addr_b32 v[107:108], v85 offset1:2                // 0000001597EC: D8DC0200 6B000055
	ds_load_2addr_b32 v[109:110], v85 offset0:4 offset1:6      // 0000001597F4: D8DC0604 6D000055
	ds_load_2addr_b32 v[111:112], v85 offset0:8 offset1:10     // 0000001597FC: D8DC0A08 6F000055
	ds_load_2addr_b32 v[113:114], v85 offset0:12 offset1:14    // 000000159804: D8DC0E0C 71000055
	s_mul_f32 s0, s46, 0x3fb8aa3b                              // 00000015980C: A200FF2E 3FB8AA3B
	v_dual_mov_b32 v9, s24 :: v_dual_mov_b32 v10, s25          // 000000159814: CA100018 090A0019
	v_dual_mov_b32 v11, s26 :: v_dual_mov_b32 v12, s27         // 00000015981C: CA10001A 0B0C001B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000159824: BF8704C9
	s_xor_b32 s1, s0, 0x80000000                               // 000000159828: 8D01FF00 80000000
	s_rndne_f32 s4, s0                                         // 000000159830: BE846300
	s_fmamk_f32 s1, s46, 0x3fb8aa3b, s1                        // 000000159834: A301012E 3FB8AA3B
	v_dual_mov_b32 v13, s28 :: v_dual_mov_b32 v14, s29         // 00000015983C: CA10001C 0D0E001D
	s_sub_f32 s0, s0, s4                                       // 000000159844: A0800400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000159848: BF8704B9
	s_fmamk_f32 s1, s46, 0x32a5705f, s1                        // 00000015984C: A301012E 32A5705F
	v_dual_mov_b32 v15, s30 :: v_dual_mov_b32 v16, s31         // 000000159854: CA10001E 0F10001F
	s_cmp_nlt_f32 s46, 0xc2ce8ed0                              // 00000015985C: BF4EFF2E C2CE8ED0
	s_add_f32 s0, s0, s1                                       // 000000159864: A0000100
	s_waitcnt lgkmcnt(14)                                      // 000000159868: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000015986C: BF870491
	v_wmma_f32_16x16x16_f16 v[99:106], v[17:24], v[33:40], v[9:16]// 000000159870: CC404063 1C264311
	v_exp_f32_e32 v115, s0                                     // 000000159878: 7EE64A00
	s_cvt_i32_f32 s0, s4                                       // 00000015987C: BE806604
	s_waitcnt lgkmcnt(12)                                      // 000000159880: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000159884: BF8700A1
	v_wmma_f32_16x16x16_f16 v[99:106], v[25:32], v[41:48], v[99:106]// 000000159888: CC404063 1D8E5319
	s_waitcnt lgkmcnt(8)                                       // 000000159890: BF89FC87
	v_wmma_f32_16x16x16_f16 v[99:106], v[49:56], v[57:64], v[99:106]// 000000159894: CC404063 1D8E7331
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000015989C: BF870005
	.long 0xd71c0011                                           // 0000001598A0: D71C0011
	v_cndmask_b32_e32 v0, v115, v0, vcc_lo                     // 0000001598A4: 02000173
	s_cselect_b32 s0, -1, 0                                    // 0000001598A8: 980080C1
	s_cmp_ngt_f32 s46, 0x42b17218                              // 0000001598AC: BF4BFF2E 42B17218
	s_waitcnt lgkmcnt(4)                                       // 0000001598B4: BF89FC47
	v_wmma_f32_16x16x16_f16 v[99:106], v[65:72], v[91:98], v[99:106]// 0000001598B8: CC404063 1D8EB741
	v_cndmask_b32_e64 v17, 0, v17, s0                          // 0000001598C0: D5010011 00022280
	s_cselect_b32 s0, -1, 0                                    // 0000001598C8: 980080C1
	s_add_i32 s45, s45, 1                                      // 0000001598CC: 812D812D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001598D0: BF870099
	s_cmp_eq_u32 s45, s43                                      // 0000001598D4: BF062B2D
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s0                 // 0000001598D8: D5010011 000222FF 7F800000
	s_waitcnt lgkmcnt(3)                                       // 0000001598E4: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001598E8: BF870001
	v_mul_f32_e32 v19, v17, v108                               // 0000001598EC: 1026D911
	v_mul_f32_e32 v18, v17, v107                               // 0000001598F0: 1024D711
	s_waitcnt lgkmcnt(2)                                       // 0000001598F4: BF89FC27
	v_mul_f32_e32 v21, v17, v110                               // 0000001598F8: 102ADD11
	v_mul_f32_e32 v20, v17, v109                               // 0000001598FC: 1028DB11
	s_waitcnt lgkmcnt(1)                                       // 000000159900: BF89FC17
	v_mul_f32_e32 v23, v17, v112                               // 000000159904: 102EE111
	v_mul_f32_e32 v22, v17, v111                               // 000000159908: 102CDF11
	s_waitcnt lgkmcnt(0)                                       // 00000015990C: BF89FC07
	v_mul_f32_e32 v25, v17, v114                               // 000000159910: 1032E511
	v_dual_mul_f32 v24, v17, v113 :: v_dual_fmac_f32 v19, 0x3b800000, v100// 000000159914: C8C0E311 1812C8FF 3B800000
	v_dual_fmac_f32 v18, 0x3b800000, v99 :: v_dual_fmac_f32 v21, 0x3b800000, v102// 000000159920: C800C6FF 1214CCFF 3B800000
	v_dual_fmac_f32 v20, 0x3b800000, v101 :: v_dual_fmac_f32 v23, 0x3b800000, v104// 00000015992C: C800CAFF 1416D0FF 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000159938: BF870214
	v_dual_fmac_f32 v22, 0x3b800000, v103 :: v_dual_fmac_f32 v25, 0x3b800000, v106// 00000015993C: C800CEFF 1618D4FF 3B800000
	v_fmac_f32_e32 v24, 0x3b800000, v105                       // 000000159948: 5630D2FF 3B800000
	ds_store_2addr_b32 v85, v18, v19 offset1:2                 // 000000159950: D8380200 00131255
	ds_store_2addr_b32 v85, v20, v21 offset0:4 offset1:6       // 000000159958: D8380604 00151455
	ds_store_2addr_b32 v85, v22, v23 offset0:8 offset1:10      // 000000159960: D8380A08 00171655
	ds_store_2addr_b32 v85, v24, v25 offset0:12 offset1:14     // 000000159968: D8380E0C 00191855
	s_waitcnt lgkmcnt(0)                                       // 000000159970: BF89FC07
	s_barrier                                                  // 000000159974: BFBD0000
	buffer_gl0_inv                                             // 000000159978: E0AC0000 00000000
	s_barrier                                                  // 000000159980: BFBD0000
	buffer_gl0_inv                                             // 000000159984: E0AC0000 00000000
	ds_load_b128 v[18:21], v84                                 // 00000015998C: DBFC0000 12000054
	ds_load_b128 v[22:25], v84 offset:16                       // 000000159994: DBFC0010 16000054
	ds_load_b128 v[26:29], v84 offset:32                       // 00000015999C: DBFC0020 1A000054
	ds_load_b128 v[30:33], v84 offset:48                       // 0000001599A4: DBFC0030 1E000054
	ds_load_b128 v[34:37], v90                                 // 0000001599AC: DBFC0000 2200005A
	ds_load_b128 v[38:41], v90 offset:16                       // 0000001599B4: DBFC0010 2600005A
	ds_load_b128 v[42:45], v90 offset:32                       // 0000001599BC: DBFC0020 2A00005A
	ds_load_b128 v[46:49], v90 offset:48                       // 0000001599C4: DBFC0030 2E00005A
	ds_load_b128 v[54:57], v84 offset:80                       // 0000001599CC: DBFC0050 36000054
	ds_load_b128 v[50:53], v84 offset:64                       // 0000001599D4: DBFC0040 32000054
	ds_load_b128 v[62:65], v90 offset:80                       // 0000001599DC: DBFC0050 3E00005A
	ds_load_b128 v[58:61], v90 offset:64                       // 0000001599E4: DBFC0040 3A00005A
	ds_load_b128 v[95:98], v84 offset:112                      // 0000001599EC: DBFC0070 5F000054
	ds_load_b128 v[91:94], v84 offset:96                       // 0000001599F4: DBFC0060 5B000054
	ds_load_b128 v[103:106], v90 offset:112                    // 0000001599FC: DBFC0070 6700005A
	ds_load_b128 v[99:102], v90 offset:96                      // 000000159A04: DBFC0060 6300005A
	ds_load_2addr_b32 v[66:67], v85 offset0:16 offset1:18      // 000000159A0C: D8DC1210 42000055
	ds_load_2addr_b32 v[68:69], v85 offset0:20 offset1:22      // 000000159A14: D8DC1614 44000055
	ds_load_2addr_b32 v[70:71], v85 offset0:24 offset1:26      // 000000159A1C: D8DC1A18 46000055
	ds_load_2addr_b32 v[115:116], v85 offset0:28 offset1:30    // 000000159A24: D8DC1E1C 73000055
	s_waitcnt lgkmcnt(14)                                      // 000000159A2C: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[107:114], v[18:25], v[34:41], v[9:16]// 000000159A30: CC40406B 1C264512
	s_waitcnt lgkmcnt(12)                                      // 000000159A38: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000159A3C: BF8700A1
	v_wmma_f32_16x16x16_f16 v[107:114], v[26:33], v[42:49], v[107:114]// 000000159A40: CC40406B 1DAE551A
	s_waitcnt lgkmcnt(8)                                       // 000000159A48: BF89FC87
	v_wmma_f32_16x16x16_f16 v[107:114], v[50:57], v[58:65], v[107:114]// 000000159A4C: CC40406B 1DAE7532
	s_waitcnt lgkmcnt(4)                                       // 000000159A54: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000159A58: BF870001
	v_wmma_f32_16x16x16_f16 v[107:114], v[91:98], v[99:106], v[107:114]// 000000159A5C: CC40406B 1DAEC75B
	s_waitcnt lgkmcnt(2)                                       // 000000159A64: BF89FC27
	v_mul_f32_e32 v21, v17, v69                                // 000000159A68: 102A8B11
	v_mul_f32_e32 v20, v17, v68                                // 000000159A6C: 10288911
	s_waitcnt lgkmcnt(0)                                       // 000000159A70: BF89FC07
	v_mul_f32_e32 v25, v17, v116                               // 000000159A74: 1032E911
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000159A78: BF870193
	v_dual_mul_f32 v24, v17, v115 :: v_dual_fmac_f32 v21, 0x3b800000, v110// 000000159A7C: C8C0E711 1814DCFF 3B800000
	v_dual_mul_f32 v19, v17, v67 :: v_dual_fmac_f32 v20, 0x3b800000, v109// 000000159A88: C8C08711 1314DAFF 3B800000
	v_mul_f32_e32 v18, v17, v66                                // 000000159A94: 10248511
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000159A98: BF870214
	v_fmac_f32_e32 v25, 0x3b800000, v114                       // 000000159A9C: 5632E4FF 3B800000
	v_dual_mul_f32 v23, v17, v71 :: v_dual_fmac_f32 v24, 0x3b800000, v113// 000000159AA4: C8C08F11 1718E2FF 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000159AB0: BF870114
	v_dual_mul_f32 v22, v17, v70 :: v_dual_fmac_f32 v19, 0x3b800000, v108// 000000159AB4: C8C08D11 1612D8FF 3B800000
	v_dual_fmac_f32 v18, 0x3b800000, v107 :: v_dual_fmac_f32 v23, 0x3b800000, v112// 000000159AC0: C800D6FF 1216E0FF 3B800000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000159ACC: BF870002
	v_fmac_f32_e32 v22, 0x3b800000, v111                       // 000000159AD0: 562CDEFF 3B800000
	ds_store_2addr_b32 v85, v18, v19 offset0:16 offset1:18     // 000000159AD8: D8381210 00131255
	ds_store_2addr_b32 v85, v20, v21 offset0:20 offset1:22     // 000000159AE0: D8381614 00151455
	ds_store_2addr_b32 v85, v22, v23 offset0:24 offset1:26     // 000000159AE8: D8381A18 00171655
	ds_store_2addr_b32 v85, v24, v25 offset0:28 offset1:30     // 000000159AF0: D8381E1C 00191855
	s_waitcnt lgkmcnt(0)                                       // 000000159AF8: BF89FC07
	s_barrier                                                  // 000000159AFC: BFBD0000
	buffer_gl0_inv                                             // 000000159B00: E0AC0000 00000000
	s_barrier                                                  // 000000159B08: BFBD0000
	buffer_gl0_inv                                             // 000000159B0C: E0AC0000 00000000
	ds_load_b128 v[18:21], v84                                 // 000000159B14: DBFC0000 12000054
	ds_load_b128 v[22:25], v84 offset:16                       // 000000159B1C: DBFC0010 16000054
	ds_load_b128 v[26:29], v84 offset:32                       // 000000159B24: DBFC0020 1A000054
	ds_load_b128 v[30:33], v84 offset:48                       // 000000159B2C: DBFC0030 1E000054
	ds_load_b128 v[34:37], v90                                 // 000000159B34: DBFC0000 2200005A
	ds_load_b128 v[38:41], v90 offset:16                       // 000000159B3C: DBFC0010 2600005A
	ds_load_b128 v[42:45], v90 offset:32                       // 000000159B44: DBFC0020 2A00005A
	ds_load_b128 v[46:49], v90 offset:48                       // 000000159B4C: DBFC0030 2E00005A
	ds_load_b128 v[54:57], v84 offset:80                       // 000000159B54: DBFC0050 36000054
	ds_load_b128 v[50:53], v84 offset:64                       // 000000159B5C: DBFC0040 32000054
	ds_load_b128 v[62:65], v90 offset:80                       // 000000159B64: DBFC0050 3E00005A
	ds_load_b128 v[58:61], v90 offset:64                       // 000000159B6C: DBFC0040 3A00005A
	ds_load_b128 v[95:98], v84 offset:112                      // 000000159B74: DBFC0070 5F000054
	ds_load_b128 v[91:94], v84 offset:96                       // 000000159B7C: DBFC0060 5B000054
	ds_load_b128 v[103:106], v90 offset:112                    // 000000159B84: DBFC0070 6700005A
	ds_load_b128 v[99:102], v90 offset:96                      // 000000159B8C: DBFC0060 6300005A
	ds_load_2addr_b32 v[66:67], v85 offset0:32 offset1:34      // 000000159B94: D8DC2220 42000055
	ds_load_2addr_b32 v[68:69], v85 offset0:36 offset1:38      // 000000159B9C: D8DC2624 44000055
	ds_load_2addr_b32 v[70:71], v85 offset0:40 offset1:42      // 000000159BA4: D8DC2A28 46000055
	ds_load_2addr_b32 v[115:116], v85 offset0:44 offset1:46    // 000000159BAC: D8DC2E2C 73000055
	s_waitcnt lgkmcnt(14)                                      // 000000159BB4: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[107:114], v[18:25], v[34:41], v[9:16]// 000000159BB8: CC40406B 1C264512
	s_waitcnt lgkmcnt(12)                                      // 000000159BC0: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000159BC4: BF8700A1
	v_wmma_f32_16x16x16_f16 v[107:114], v[26:33], v[42:49], v[107:114]// 000000159BC8: CC40406B 1DAE551A
	s_waitcnt lgkmcnt(8)                                       // 000000159BD0: BF89FC87
	v_wmma_f32_16x16x16_f16 v[107:114], v[50:57], v[58:65], v[107:114]// 000000159BD4: CC40406B 1DAE7532
	s_waitcnt lgkmcnt(4)                                       // 000000159BDC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000159BE0: BF870001
	v_wmma_f32_16x16x16_f16 v[107:114], v[91:98], v[99:106], v[107:114]// 000000159BE4: CC40406B 1DAEC75B
	s_waitcnt lgkmcnt(2)                                       // 000000159BEC: BF89FC27
	v_mul_f32_e32 v21, v17, v69                                // 000000159BF0: 102A8B11
	v_mul_f32_e32 v20, v17, v68                                // 000000159BF4: 10288911
	s_waitcnt lgkmcnt(0)                                       // 000000159BF8: BF89FC07
	v_mul_f32_e32 v25, v17, v116                               // 000000159BFC: 1032E911
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000159C00: BF870193
	v_dual_mul_f32 v24, v17, v115 :: v_dual_fmac_f32 v21, 0x3b800000, v110// 000000159C04: C8C0E711 1814DCFF 3B800000
	v_dual_mul_f32 v19, v17, v67 :: v_dual_fmac_f32 v20, 0x3b800000, v109// 000000159C10: C8C08711 1314DAFF 3B800000
	v_mul_f32_e32 v18, v17, v66                                // 000000159C1C: 10248511
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000159C20: BF870214
	v_fmac_f32_e32 v25, 0x3b800000, v114                       // 000000159C24: 5632E4FF 3B800000
	v_dual_mul_f32 v23, v17, v71 :: v_dual_fmac_f32 v24, 0x3b800000, v113// 000000159C2C: C8C08F11 1718E2FF 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000159C38: BF870114
	v_dual_mul_f32 v22, v17, v70 :: v_dual_fmac_f32 v19, 0x3b800000, v108// 000000159C3C: C8C08D11 1612D8FF 3B800000
	v_dual_fmac_f32 v18, 0x3b800000, v107 :: v_dual_fmac_f32 v23, 0x3b800000, v112// 000000159C48: C800D6FF 1216E0FF 3B800000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000159C54: BF870002
	v_fmac_f32_e32 v22, 0x3b800000, v111                       // 000000159C58: 562CDEFF 3B800000
	ds_store_2addr_b32 v85, v18, v19 offset0:32 offset1:34     // 000000159C60: D8382220 00131255
	ds_store_2addr_b32 v85, v20, v21 offset0:36 offset1:38     // 000000159C68: D8382624 00151455
	ds_store_2addr_b32 v85, v22, v23 offset0:40 offset1:42     // 000000159C70: D8382A28 00171655
	ds_store_2addr_b32 v85, v24, v25 offset0:44 offset1:46     // 000000159C78: D8382E2C 00191855
	s_waitcnt lgkmcnt(0)                                       // 000000159C80: BF89FC07
	s_barrier                                                  // 000000159C84: BFBD0000
	buffer_gl0_inv                                             // 000000159C88: E0AC0000 00000000
	s_barrier                                                  // 000000159C90: BFBD0000
	buffer_gl0_inv                                             // 000000159C94: E0AC0000 00000000
	ds_load_b128 v[18:21], v84                                 // 000000159C9C: DBFC0000 12000054
	ds_load_b128 v[22:25], v84 offset:16                       // 000000159CA4: DBFC0010 16000054
	ds_load_b128 v[26:29], v84 offset:32                       // 000000159CAC: DBFC0020 1A000054
	ds_load_b128 v[30:33], v84 offset:48                       // 000000159CB4: DBFC0030 1E000054
	ds_load_b128 v[34:37], v90                                 // 000000159CBC: DBFC0000 2200005A
	ds_load_b128 v[38:41], v90 offset:16                       // 000000159CC4: DBFC0010 2600005A
	ds_load_b128 v[42:45], v90 offset:32                       // 000000159CCC: DBFC0020 2A00005A
	ds_load_b128 v[46:49], v90 offset:48                       // 000000159CD4: DBFC0030 2E00005A
	ds_load_b128 v[54:57], v84 offset:80                       // 000000159CDC: DBFC0050 36000054
	ds_load_b128 v[50:53], v84 offset:64                       // 000000159CE4: DBFC0040 32000054
	ds_load_b128 v[62:65], v90 offset:80                       // 000000159CEC: DBFC0050 3E00005A
	ds_load_b128 v[58:61], v90 offset:64                       // 000000159CF4: DBFC0040 3A00005A
	ds_load_b128 v[95:98], v84 offset:112                      // 000000159CFC: DBFC0070 5F000054
	ds_load_b128 v[91:94], v84 offset:96                       // 000000159D04: DBFC0060 5B000054
	ds_load_b128 v[103:106], v90 offset:112                    // 000000159D0C: DBFC0070 6700005A
	ds_load_b128 v[99:102], v90 offset:96                      // 000000159D14: DBFC0060 6300005A
	ds_load_2addr_b32 v[66:67], v85 offset0:48 offset1:50      // 000000159D1C: D8DC3230 42000055
	ds_load_2addr_b32 v[68:69], v85 offset0:52 offset1:54      // 000000159D24: D8DC3634 44000055
	ds_load_2addr_b32 v[70:71], v85 offset0:56 offset1:58      // 000000159D2C: D8DC3A38 46000055
	ds_load_2addr_b32 v[115:116], v85 offset0:60 offset1:62    // 000000159D34: D8DC3E3C 73000055
	s_waitcnt lgkmcnt(14)                                      // 000000159D3C: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[107:114], v[18:25], v[34:41], v[9:16]// 000000159D40: CC40406B 1C264512
	s_waitcnt lgkmcnt(12)                                      // 000000159D48: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000159D4C: BF8700A1
	v_wmma_f32_16x16x16_f16 v[107:114], v[26:33], v[42:49], v[107:114]// 000000159D50: CC40406B 1DAE551A
	s_waitcnt lgkmcnt(8)                                       // 000000159D58: BF89FC87
	v_wmma_f32_16x16x16_f16 v[107:114], v[50:57], v[58:65], v[107:114]// 000000159D5C: CC40406B 1DAE7532
	s_waitcnt lgkmcnt(4)                                       // 000000159D64: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000159D68: BF870001
	v_wmma_f32_16x16x16_f16 v[107:114], v[91:98], v[99:106], v[107:114]// 000000159D6C: CC40406B 1DAEC75B
	s_waitcnt lgkmcnt(2)                                       // 000000159D74: BF89FC27
	v_mul_f32_e32 v21, v17, v69                                // 000000159D78: 102A8B11
	v_mul_f32_e32 v20, v17, v68                                // 000000159D7C: 10288911
	s_waitcnt lgkmcnt(0)                                       // 000000159D80: BF89FC07
	v_mul_f32_e32 v25, v17, v116                               // 000000159D84: 1032E911
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000159D88: BF870193
	v_dual_mul_f32 v24, v17, v115 :: v_dual_fmac_f32 v21, 0x3b800000, v110// 000000159D8C: C8C0E711 1814DCFF 3B800000
	v_dual_mul_f32 v19, v17, v67 :: v_dual_fmac_f32 v20, 0x3b800000, v109// 000000159D98: C8C08711 1314DAFF 3B800000
	v_mul_f32_e32 v18, v17, v66                                // 000000159DA4: 10248511
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000159DA8: BF870214
	v_fmac_f32_e32 v25, 0x3b800000, v114                       // 000000159DAC: 5632E4FF 3B800000
	v_dual_mul_f32 v23, v17, v71 :: v_dual_fmac_f32 v24, 0x3b800000, v113// 000000159DB4: C8C08F11 1718E2FF 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000159DC0: BF870114
	v_dual_mul_f32 v22, v17, v70 :: v_dual_fmac_f32 v19, 0x3b800000, v108// 000000159DC4: C8C08D11 1612D8FF 3B800000
	v_dual_fmac_f32 v18, 0x3b800000, v107 :: v_dual_fmac_f32 v23, 0x3b800000, v112// 000000159DD0: C800D6FF 1216E0FF 3B800000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000159DDC: BF870002
	v_fmac_f32_e32 v22, 0x3b800000, v111                       // 000000159DE0: 562CDEFF 3B800000
	ds_store_2addr_b32 v85, v18, v19 offset0:48 offset1:50     // 000000159DE8: D8383230 00131255
	ds_store_2addr_b32 v85, v20, v21 offset0:52 offset1:54     // 000000159DF0: D8383634 00151455
	ds_store_2addr_b32 v85, v22, v23 offset0:56 offset1:58     // 000000159DF8: D8383A38 00171655
	ds_store_2addr_b32 v85, v24, v25 offset0:60 offset1:62     // 000000159E00: D8383E3C 00191855
	s_waitcnt lgkmcnt(0)                                       // 000000159E08: BF89FC07
	s_barrier                                                  // 000000159E0C: BFBD0000
	buffer_gl0_inv                                             // 000000159E10: E0AC0000 00000000
	s_barrier                                                  // 000000159E18: BFBD0000
	buffer_gl0_inv                                             // 000000159E1C: E0AC0000 00000000
	ds_load_b128 v[18:21], v84                                 // 000000159E24: DBFC0000 12000054
	ds_load_b128 v[22:25], v84 offset:16                       // 000000159E2C: DBFC0010 16000054
	ds_load_b128 v[26:29], v84 offset:32                       // 000000159E34: DBFC0020 1A000054
	ds_load_b128 v[30:33], v84 offset:48                       // 000000159E3C: DBFC0030 1E000054
	ds_load_b128 v[34:37], v90                                 // 000000159E44: DBFC0000 2200005A
	ds_load_b128 v[38:41], v90 offset:16                       // 000000159E4C: DBFC0010 2600005A
	ds_load_b128 v[42:45], v90 offset:32                       // 000000159E54: DBFC0020 2A00005A
	ds_load_b128 v[46:49], v90 offset:48                       // 000000159E5C: DBFC0030 2E00005A
	ds_load_b128 v[54:57], v84 offset:80                       // 000000159E64: DBFC0050 36000054
	ds_load_b128 v[50:53], v84 offset:64                       // 000000159E6C: DBFC0040 32000054
	ds_load_b128 v[62:65], v90 offset:80                       // 000000159E74: DBFC0050 3E00005A
	ds_load_b128 v[58:61], v90 offset:64                       // 000000159E7C: DBFC0040 3A00005A
	ds_load_b128 v[95:98], v84 offset:112                      // 000000159E84: DBFC0070 5F000054
	ds_load_b128 v[91:94], v84 offset:96                       // 000000159E8C: DBFC0060 5B000054
	ds_load_b128 v[103:106], v90 offset:112                    // 000000159E94: DBFC0070 6700005A
	ds_load_b128 v[99:102], v90 offset:96                      // 000000159E9C: DBFC0060 6300005A
	ds_load_2addr_b32 v[66:67], v85 offset0:64 offset1:66      // 000000159EA4: D8DC4240 42000055
	ds_load_2addr_b32 v[68:69], v85 offset0:68 offset1:70      // 000000159EAC: D8DC4644 44000055
	ds_load_2addr_b32 v[70:71], v85 offset0:72 offset1:74      // 000000159EB4: D8DC4A48 46000055
	ds_load_2addr_b32 v[115:116], v85 offset0:76 offset1:78    // 000000159EBC: D8DC4E4C 73000055
	s_waitcnt lgkmcnt(14)                                      // 000000159EC4: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[107:114], v[18:25], v[34:41], v[9:16]// 000000159EC8: CC40406B 1C264512
	s_waitcnt lgkmcnt(12)                                      // 000000159ED0: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000159ED4: BF8700A1
	v_wmma_f32_16x16x16_f16 v[107:114], v[26:33], v[42:49], v[107:114]// 000000159ED8: CC40406B 1DAE551A
	s_waitcnt lgkmcnt(8)                                       // 000000159EE0: BF89FC87
	v_wmma_f32_16x16x16_f16 v[107:114], v[50:57], v[58:65], v[107:114]// 000000159EE4: CC40406B 1DAE7532
	s_waitcnt lgkmcnt(4)                                       // 000000159EEC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000159EF0: BF870001
	v_wmma_f32_16x16x16_f16 v[107:114], v[91:98], v[99:106], v[107:114]// 000000159EF4: CC40406B 1DAEC75B
	s_waitcnt lgkmcnt(2)                                       // 000000159EFC: BF89FC27
	v_mul_f32_e32 v21, v17, v69                                // 000000159F00: 102A8B11
	v_mul_f32_e32 v20, v17, v68                                // 000000159F04: 10288911
	s_waitcnt lgkmcnt(0)                                       // 000000159F08: BF89FC07
	v_mul_f32_e32 v25, v17, v116                               // 000000159F0C: 1032E911
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000159F10: BF870193
	v_dual_mul_f32 v24, v17, v115 :: v_dual_fmac_f32 v21, 0x3b800000, v110// 000000159F14: C8C0E711 1814DCFF 3B800000
	v_dual_mul_f32 v19, v17, v67 :: v_dual_fmac_f32 v20, 0x3b800000, v109// 000000159F20: C8C08711 1314DAFF 3B800000
	v_mul_f32_e32 v18, v17, v66                                // 000000159F2C: 10248511
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000159F30: BF870214
	v_fmac_f32_e32 v25, 0x3b800000, v114                       // 000000159F34: 5632E4FF 3B800000
	v_dual_mul_f32 v23, v17, v71 :: v_dual_fmac_f32 v24, 0x3b800000, v113// 000000159F3C: C8C08F11 1718E2FF 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000159F48: BF870114
	v_dual_mul_f32 v22, v17, v70 :: v_dual_fmac_f32 v19, 0x3b800000, v108// 000000159F4C: C8C08D11 1612D8FF 3B800000
	v_dual_fmac_f32 v18, 0x3b800000, v107 :: v_dual_fmac_f32 v23, 0x3b800000, v112// 000000159F58: C800D6FF 1216E0FF 3B800000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000159F64: BF870002
	v_fmac_f32_e32 v22, 0x3b800000, v111                       // 000000159F68: 562CDEFF 3B800000
	ds_store_2addr_b32 v85, v18, v19 offset0:64 offset1:66     // 000000159F70: D8384240 00131255
	ds_store_2addr_b32 v85, v20, v21 offset0:68 offset1:70     // 000000159F78: D8384644 00151455
	ds_store_2addr_b32 v85, v22, v23 offset0:72 offset1:74     // 000000159F80: D8384A48 00171655
	ds_store_2addr_b32 v85, v24, v25 offset0:76 offset1:78     // 000000159F88: D8384E4C 00191855
	s_waitcnt lgkmcnt(0)                                       // 000000159F90: BF89FC07
	s_barrier                                                  // 000000159F94: BFBD0000
	buffer_gl0_inv                                             // 000000159F98: E0AC0000 00000000
	s_barrier                                                  // 000000159FA0: BFBD0000
	buffer_gl0_inv                                             // 000000159FA4: E0AC0000 00000000
	ds_load_b128 v[18:21], v84                                 // 000000159FAC: DBFC0000 12000054
	ds_load_b128 v[22:25], v84 offset:16                       // 000000159FB4: DBFC0010 16000054
	ds_load_b128 v[26:29], v84 offset:32                       // 000000159FBC: DBFC0020 1A000054
	ds_load_b128 v[30:33], v84 offset:48                       // 000000159FC4: DBFC0030 1E000054
	ds_load_b128 v[34:37], v90                                 // 000000159FCC: DBFC0000 2200005A
	ds_load_b128 v[38:41], v90 offset:16                       // 000000159FD4: DBFC0010 2600005A
	ds_load_b128 v[42:45], v90 offset:32                       // 000000159FDC: DBFC0020 2A00005A
	ds_load_b128 v[46:49], v90 offset:48                       // 000000159FE4: DBFC0030 2E00005A
	ds_load_b128 v[54:57], v84 offset:80                       // 000000159FEC: DBFC0050 36000054
	ds_load_b128 v[50:53], v84 offset:64                       // 000000159FF4: DBFC0040 32000054
	ds_load_b128 v[62:65], v90 offset:80                       // 000000159FFC: DBFC0050 3E00005A
	ds_load_b128 v[58:61], v90 offset:64                       // 00000015A004: DBFC0040 3A00005A
	ds_load_b128 v[95:98], v84 offset:112                      // 00000015A00C: DBFC0070 5F000054
	ds_load_b128 v[91:94], v84 offset:96                       // 00000015A014: DBFC0060 5B000054
	ds_load_b128 v[103:106], v90 offset:112                    // 00000015A01C: DBFC0070 6700005A
	ds_load_b128 v[99:102], v90 offset:96                      // 00000015A024: DBFC0060 6300005A
	ds_load_2addr_b32 v[66:67], v85 offset0:80 offset1:82      // 00000015A02C: D8DC5250 42000055
	ds_load_2addr_b32 v[68:69], v85 offset0:84 offset1:86      // 00000015A034: D8DC5654 44000055
	ds_load_2addr_b32 v[70:71], v85 offset0:88 offset1:90      // 00000015A03C: D8DC5A58 46000055
	ds_load_2addr_b32 v[115:116], v85 offset0:92 offset1:94    // 00000015A044: D8DC5E5C 73000055
	s_waitcnt lgkmcnt(14)                                      // 00000015A04C: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[107:114], v[18:25], v[34:41], v[9:16]// 00000015A050: CC40406B 1C264512
	s_waitcnt lgkmcnt(12)                                      // 00000015A058: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000015A05C: BF8700A1
	v_wmma_f32_16x16x16_f16 v[107:114], v[26:33], v[42:49], v[107:114]// 00000015A060: CC40406B 1DAE551A
	s_waitcnt lgkmcnt(8)                                       // 00000015A068: BF89FC87
	v_wmma_f32_16x16x16_f16 v[107:114], v[50:57], v[58:65], v[107:114]// 00000015A06C: CC40406B 1DAE7532
	s_waitcnt lgkmcnt(4)                                       // 00000015A074: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015A078: BF870001
	v_wmma_f32_16x16x16_f16 v[107:114], v[91:98], v[99:106], v[107:114]// 00000015A07C: CC40406B 1DAEC75B
	s_waitcnt lgkmcnt(2)                                       // 00000015A084: BF89FC27
	v_mul_f32_e32 v21, v17, v69                                // 00000015A088: 102A8B11
	v_mul_f32_e32 v20, v17, v68                                // 00000015A08C: 10288911
	s_waitcnt lgkmcnt(0)                                       // 00000015A090: BF89FC07
	v_mul_f32_e32 v25, v17, v116                               // 00000015A094: 1032E911
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000015A098: BF870193
	v_dual_mul_f32 v24, v17, v115 :: v_dual_fmac_f32 v21, 0x3b800000, v110// 00000015A09C: C8C0E711 1814DCFF 3B800000
	v_dual_mul_f32 v19, v17, v67 :: v_dual_fmac_f32 v20, 0x3b800000, v109// 00000015A0A8: C8C08711 1314DAFF 3B800000
	v_mul_f32_e32 v18, v17, v66                                // 00000015A0B4: 10248511
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000015A0B8: BF870214
	v_fmac_f32_e32 v25, 0x3b800000, v114                       // 00000015A0BC: 5632E4FF 3B800000
	v_dual_mul_f32 v23, v17, v71 :: v_dual_fmac_f32 v24, 0x3b800000, v113// 00000015A0C4: C8C08F11 1718E2FF 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000015A0D0: BF870114
	v_dual_mul_f32 v22, v17, v70 :: v_dual_fmac_f32 v19, 0x3b800000, v108// 00000015A0D4: C8C08D11 1612D8FF 3B800000
	v_dual_fmac_f32 v18, 0x3b800000, v107 :: v_dual_fmac_f32 v23, 0x3b800000, v112// 00000015A0E0: C800D6FF 1216E0FF 3B800000
	s_delay_alu instid0(VALU_DEP_2)                            // 00000015A0EC: BF870002
	v_fmac_f32_e32 v22, 0x3b800000, v111                       // 00000015A0F0: 562CDEFF 3B800000
	ds_store_2addr_b32 v85, v18, v19 offset0:80 offset1:82     // 00000015A0F8: D8385250 00131255
	ds_store_2addr_b32 v85, v20, v21 offset0:84 offset1:86     // 00000015A100: D8385654 00151455
	ds_store_2addr_b32 v85, v22, v23 offset0:88 offset1:90     // 00000015A108: D8385A58 00171655
	ds_store_2addr_b32 v85, v24, v25 offset0:92 offset1:94     // 00000015A110: D8385E5C 00191855
	s_waitcnt lgkmcnt(0)                                       // 00000015A118: BF89FC07
	s_barrier                                                  // 00000015A11C: BFBD0000
	buffer_gl0_inv                                             // 00000015A120: E0AC0000 00000000
	s_barrier                                                  // 00000015A128: BFBD0000
	buffer_gl0_inv                                             // 00000015A12C: E0AC0000 00000000
	ds_load_b128 v[18:21], v84                                 // 00000015A134: DBFC0000 12000054
	ds_load_b128 v[22:25], v84 offset:16                       // 00000015A13C: DBFC0010 16000054
	ds_load_b128 v[26:29], v84 offset:32                       // 00000015A144: DBFC0020 1A000054
	ds_load_b128 v[30:33], v84 offset:48                       // 00000015A14C: DBFC0030 1E000054
	ds_load_b128 v[34:37], v90                                 // 00000015A154: DBFC0000 2200005A
	ds_load_b128 v[38:41], v90 offset:16                       // 00000015A15C: DBFC0010 2600005A
	ds_load_b128 v[42:45], v90 offset:32                       // 00000015A164: DBFC0020 2A00005A
	ds_load_b128 v[46:49], v90 offset:48                       // 00000015A16C: DBFC0030 2E00005A
	ds_load_b128 v[54:57], v84 offset:80                       // 00000015A174: DBFC0050 36000054
	ds_load_b128 v[50:53], v84 offset:64                       // 00000015A17C: DBFC0040 32000054
	ds_load_b128 v[62:65], v90 offset:80                       // 00000015A184: DBFC0050 3E00005A
	ds_load_b128 v[58:61], v90 offset:64                       // 00000015A18C: DBFC0040 3A00005A
	ds_load_b128 v[95:98], v84 offset:112                      // 00000015A194: DBFC0070 5F000054
	ds_load_b128 v[91:94], v84 offset:96                       // 00000015A19C: DBFC0060 5B000054
	ds_load_b128 v[103:106], v90 offset:112                    // 00000015A1A4: DBFC0070 6700005A
	ds_load_b128 v[99:102], v90 offset:96                      // 00000015A1AC: DBFC0060 6300005A
	ds_load_2addr_b32 v[66:67], v85 offset0:96 offset1:98      // 00000015A1B4: D8DC6260 42000055
	ds_load_2addr_b32 v[68:69], v85 offset0:100 offset1:102    // 00000015A1BC: D8DC6664 44000055
	ds_load_2addr_b32 v[70:71], v85 offset0:104 offset1:106    // 00000015A1C4: D8DC6A68 46000055
	ds_load_2addr_b32 v[115:116], v85 offset0:108 offset1:110  // 00000015A1CC: D8DC6E6C 73000055
	s_waitcnt lgkmcnt(14)                                      // 00000015A1D4: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[107:114], v[18:25], v[34:41], v[9:16]// 00000015A1D8: CC40406B 1C264512
	s_waitcnt lgkmcnt(12)                                      // 00000015A1E0: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000015A1E4: BF8700A1
	v_wmma_f32_16x16x16_f16 v[107:114], v[26:33], v[42:49], v[107:114]// 00000015A1E8: CC40406B 1DAE551A
	s_waitcnt lgkmcnt(8)                                       // 00000015A1F0: BF89FC87
	v_wmma_f32_16x16x16_f16 v[107:114], v[50:57], v[58:65], v[107:114]// 00000015A1F4: CC40406B 1DAE7532
	s_waitcnt lgkmcnt(4)                                       // 00000015A1FC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015A200: BF870001
	v_wmma_f32_16x16x16_f16 v[107:114], v[91:98], v[99:106], v[107:114]// 00000015A204: CC40406B 1DAEC75B
	s_waitcnt lgkmcnt(2)                                       // 00000015A20C: BF89FC27
	v_mul_f32_e32 v21, v17, v69                                // 00000015A210: 102A8B11
	v_mul_f32_e32 v20, v17, v68                                // 00000015A214: 10288911
	s_waitcnt lgkmcnt(0)                                       // 00000015A218: BF89FC07
	v_mul_f32_e32 v25, v17, v116                               // 00000015A21C: 1032E911
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000015A220: BF870193
	v_dual_mul_f32 v24, v17, v115 :: v_dual_fmac_f32 v21, 0x3b800000, v110// 00000015A224: C8C0E711 1814DCFF 3B800000
	v_dual_mul_f32 v19, v17, v67 :: v_dual_fmac_f32 v20, 0x3b800000, v109// 00000015A230: C8C08711 1314DAFF 3B800000
	v_mul_f32_e32 v18, v17, v66                                // 00000015A23C: 10248511
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000015A240: BF870214
	v_fmac_f32_e32 v25, 0x3b800000, v114                       // 00000015A244: 5632E4FF 3B800000
	v_dual_mul_f32 v23, v17, v71 :: v_dual_fmac_f32 v24, 0x3b800000, v113// 00000015A24C: C8C08F11 1718E2FF 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000015A258: BF870114
	v_dual_mul_f32 v22, v17, v70 :: v_dual_fmac_f32 v19, 0x3b800000, v108// 00000015A25C: C8C08D11 1612D8FF 3B800000
	v_dual_fmac_f32 v18, 0x3b800000, v107 :: v_dual_fmac_f32 v23, 0x3b800000, v112// 00000015A268: C800D6FF 1216E0FF 3B800000
	s_delay_alu instid0(VALU_DEP_2)                            // 00000015A274: BF870002
	v_fmac_f32_e32 v22, 0x3b800000, v111                       // 00000015A278: 562CDEFF 3B800000
	ds_store_2addr_b32 v85, v18, v19 offset0:96 offset1:98     // 00000015A280: D8386260 00131255
	ds_store_2addr_b32 v85, v20, v21 offset0:100 offset1:102   // 00000015A288: D8386664 00151455
	ds_store_2addr_b32 v85, v22, v23 offset0:104 offset1:106   // 00000015A290: D8386A68 00171655
	ds_store_2addr_b32 v85, v24, v25 offset0:108 offset1:110   // 00000015A298: D8386E6C 00191855
	s_waitcnt lgkmcnt(0)                                       // 00000015A2A0: BF89FC07
	s_barrier                                                  // 00000015A2A4: BFBD0000
	buffer_gl0_inv                                             // 00000015A2A8: E0AC0000 00000000
	s_barrier                                                  // 00000015A2B0: BFBD0000
	buffer_gl0_inv                                             // 00000015A2B4: E0AC0000 00000000
	ds_load_b128 v[18:21], v84                                 // 00000015A2BC: DBFC0000 12000054
	ds_load_b128 v[22:25], v84 offset:16                       // 00000015A2C4: DBFC0010 16000054
	ds_load_b128 v[26:29], v84 offset:32                       // 00000015A2CC: DBFC0020 1A000054
	ds_load_b128 v[30:33], v84 offset:48                       // 00000015A2D4: DBFC0030 1E000054
	ds_load_b128 v[34:37], v90                                 // 00000015A2DC: DBFC0000 2200005A
	ds_load_b128 v[38:41], v90 offset:16                       // 00000015A2E4: DBFC0010 2600005A
	ds_load_b128 v[42:45], v90 offset:32                       // 00000015A2EC: DBFC0020 2A00005A
	ds_load_b128 v[46:49], v90 offset:48                       // 00000015A2F4: DBFC0030 2E00005A
	ds_load_b128 v[54:57], v84 offset:80                       // 00000015A2FC: DBFC0050 36000054
	ds_load_b128 v[50:53], v84 offset:64                       // 00000015A304: DBFC0040 32000054
	ds_load_b128 v[62:65], v90 offset:80                       // 00000015A30C: DBFC0050 3E00005A
	ds_load_b128 v[58:61], v90 offset:64                       // 00000015A314: DBFC0040 3A00005A
	ds_load_b128 v[95:98], v84 offset:112                      // 00000015A31C: DBFC0070 5F000054
	ds_load_b128 v[91:94], v84 offset:96                       // 00000015A324: DBFC0060 5B000054
	ds_load_b128 v[103:106], v90 offset:112                    // 00000015A32C: DBFC0070 6700005A
	ds_load_b128 v[99:102], v90 offset:96                      // 00000015A334: DBFC0060 6300005A
	ds_load_2addr_b32 v[66:67], v85 offset0:112 offset1:114    // 00000015A33C: D8DC7270 42000055
	ds_load_2addr_b32 v[68:69], v85 offset0:116 offset1:118    // 00000015A344: D8DC7674 44000055
	ds_load_2addr_b32 v[70:71], v85 offset0:120 offset1:122    // 00000015A34C: D8DC7A78 46000055
	ds_load_2addr_b32 v[115:116], v85 offset0:124 offset1:126  // 00000015A354: D8DC7E7C 73000055
	s_waitcnt lgkmcnt(14)                                      // 00000015A35C: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[107:114], v[18:25], v[34:41], v[9:16]// 00000015A360: CC40406B 1C264512
	s_waitcnt lgkmcnt(12)                                      // 00000015A368: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000015A36C: BF8700A1
	v_wmma_f32_16x16x16_f16 v[107:114], v[26:33], v[42:49], v[107:114]// 00000015A370: CC40406B 1DAE551A
	s_waitcnt lgkmcnt(8)                                       // 00000015A378: BF89FC87
	v_wmma_f32_16x16x16_f16 v[107:114], v[50:57], v[58:65], v[107:114]// 00000015A37C: CC40406B 1DAE7532
	s_waitcnt lgkmcnt(4)                                       // 00000015A384: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015A388: BF870001
	v_wmma_f32_16x16x16_f16 v[107:114], v[91:98], v[99:106], v[107:114]// 00000015A38C: CC40406B 1DAEC75B
	s_waitcnt lgkmcnt(2)                                       // 00000015A394: BF89FC27
	v_mul_f32_e32 v12, v17, v69                                // 00000015A398: 10188B11
	v_mul_f32_e32 v11, v17, v68                                // 00000015A39C: 10168911
	s_waitcnt lgkmcnt(0)                                       // 00000015A3A0: BF89FC07
	v_mul_f32_e32 v16, v17, v116                               // 00000015A3A4: 1020E911
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000015A3A8: BF870193
	v_dual_mul_f32 v15, v17, v115 :: v_dual_fmac_f32 v12, 0x3b800000, v110// 00000015A3AC: C8C0E711 0F0CDCFF 3B800000
	v_dual_mul_f32 v10, v17, v67 :: v_dual_fmac_f32 v11, 0x3b800000, v109// 00000015A3B8: C8C08711 0A0ADAFF 3B800000
	v_mul_f32_e32 v9, v17, v66                                 // 00000015A3C4: 10128511
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000015A3C8: BF870214
	v_fmac_f32_e32 v16, 0x3b800000, v114                       // 00000015A3CC: 5620E4FF 3B800000
	v_dual_mul_f32 v14, v17, v71 :: v_dual_fmac_f32 v15, 0x3b800000, v113// 00000015A3D4: C8C08F11 0E0EE2FF 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000015A3E0: BF870114
	v_dual_mul_f32 v13, v17, v70 :: v_dual_fmac_f32 v10, 0x3b800000, v108// 00000015A3E4: C8C08D11 0D0AD8FF 3B800000
	v_dual_fmac_f32 v9, 0x3b800000, v107 :: v_dual_fmac_f32 v14, 0x3b800000, v112// 00000015A3F0: C800D6FF 090EE0FF 3B800000
	s_delay_alu instid0(VALU_DEP_2)                            // 00000015A3FC: BF870002
	v_fmac_f32_e32 v13, 0x3b800000, v111                       // 00000015A400: 561ADEFF 3B800000
	ds_store_2addr_b32 v85, v9, v10 offset0:112 offset1:114    // 00000015A408: D8387270 000A0955
	ds_store_2addr_b32 v85, v11, v12 offset0:116 offset1:118   // 00000015A410: D8387674 000C0B55
	ds_store_2addr_b32 v85, v13, v14 offset0:120 offset1:122   // 00000015A418: D8387A78 000E0D55
	ds_store_2addr_b32 v85, v15, v16 offset0:124 offset1:126   // 00000015A420: D8387E7C 00100F55
	s_waitcnt lgkmcnt(0)                                       // 00000015A428: BF89FC07
	s_barrier                                                  // 00000015A42C: BFBD0000
	buffer_gl0_inv                                             // 00000015A430: E0AC0000 00000000
	s_cbranch_scc1 5854                                        // 00000015A438: BFA216DE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6bb4>
	s_mul_i32 s0, s45, 0xc00                                   // 00000015A43C: 9600FF2D 00000C00
	s_lshl_b32 s4, s45, 6                                      // 00000015A444: 8404862D
	s_add_i32 s0, s42, s0                                      // 00000015A448: 8100002A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000015A44C: BF870499
	s_ashr_i32 s1, s0, 31                                      // 00000015A450: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000015A454: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000015A458: BF870009
	s_add_u32 s0, s12, s0                                      // 00000015A45C: 8000000C
	s_addc_u32 s1, s13, s1                                     // 00000015A460: 8201010D
	s_load_b32 s46, s[0:1], null                               // 00000015A464: F4000B80 F8000000
	s_and_saveexec_b32 s1, vcc_lo                              // 00000015A46C: BE81206A
	s_cbranch_execz 46                                         // 00000015A470: BFA5002E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x112c>
	v_or_b32_e32 v9, s4, v0                                    // 00000015A474: 38120004
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015A478: BF870091
	v_mad_u64_u32 v[9:10], null, v9, 48, s[2:3]                // 00000015A47C: D6FE7C09 00096109
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000015A484: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015A488: BF870091
	.long 0xd73c0009                                           // 00000015A48C: D73C0009
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 00000015A490: 02021282
	.long 0xd7000009                                           // 00000015A494: D7000009
	v_cndmask_b32_e32 v1, s12, v9, vcc_lo                      // 00000015A498: 0202120C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000015A49C: BF870151
	v_add_co_ci_u32_e64 v10, null, s13, v10, s0                // 00000015A4A0: D5207C0A 0002140D
	global_load_b32 v9, v[9:10], off                           // 00000015A4A8: DC520000 097C0009
	s_waitcnt vmcnt(0)                                         // 00000015A4B0: BF8903F7
	v_mul_f32_e32 v10, 0x3fb8aa3b, v9                          // 00000015A4B4: 101412FF 3FB8AA3B
	.long 0xd41b0000                                           // 00000015A4BC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v9, vcc_lo               // 00000015A4C0: 020212FF C2CE8ED0
	v_fma_f32 v11, 0x3fb8aa3b, v9, -v10                        // 00000015A4C8: D613000B 842A12FF 3FB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000015A4D4: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015A4D8: BF870091
	v_dual_fmac_f32 v11, 0x32a5705f, v9 :: v_dual_sub_f32 v10, v10, v12// 00000015A4DC: C80A12FF 0B0A190A 32A5705F
	v_add_f32_e32 v10, v10, v11                                // 00000015A4E8: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000015A4EC: 7E16110C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000015A4F0: BF870292
	v_exp_f32_e32 v10, v10                                     // 00000015A4F4: 7E144B0A
	.long 0xd71c000a                                           // 00000015A4F8: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000015A4FC: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000015A500: BF8700A1
	v_cndmask_b32_e64 v10, 0, v10, s0                          // 00000015A504: D501000A 00021480
	.long 0xd41e0000                                           // 00000015A50C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v9, vcc_lo               // 00000015A510: 020212FF 42B17218
	v_cndmask_b32_e64 v9, 0x7f800000, v10, s0                  // 00000015A518: D5010009 000214FF 7F800000
	ds_store_b32 v77, v9                                       // 00000015A524: D8340000 0000094D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015A52C: 8C7E017E
	v_add_nc_u32_e32 v11, s4, v78                              // 00000015A530: 4A169C04
	.long 0x7f683880                                           // 00000015A534: 7F683880
	s_waitcnt lgkmcnt(0)                                       // 00000015A538: BF89FC07
	s_barrier                                                  // 00000015A53C: BFBD0000
	buffer_gl0_inv                                             // 00000015A540: E0AC0000 00000000
	v_mad_u64_u32 v[9:10], null, v11, 48, s[2:3]               // 00000015A548: D6FE7C09 0009610B
	.long 0xd4440000                                           // 00000015A550: D4440000
	v_cndmask_b32_e32 v1, s41, v11, vcc_lo                     // 00000015A554: 02021629
	.long 0x7f6439b4                                           // 00000015A558: 7F6439B4
	.long 0x7e6439b4                                           // 00000015A55C: 7E6439B4
	.long 0x7f6239b4                                           // 00000015A560: 7F6239B4
	.long 0x7e6239b4                                           // 00000015A564: 7E6239B4
	.long 0xd73c003b                                           // 00000015A568: D73C003B
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 00000015A56C: 02021289
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015A570: BF870091
	.long 0xd700013d                                           // 00000015A574: D700013D
	v_cndmask_b32_e32 v1, s16, v59, vcc_lo                     // 00000015A578: 02027610
	v_add_co_ci_u32_e64 v62, null, s17, v60, s1                // 00000015A57C: D5207C3E 00067811
	s_and_saveexec_b32 s1, s0                                  // 00000015A584: BE812000
	s_cbranch_execz 11                                         // 00000015A588: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11b8>
	global_load_b128 v[9:12], v[61:62], off                    // 00000015A58C: DC5E0000 097C003D
	s_waitcnt vmcnt(0)                                         // 00000015A594: BF8903F7
	v_fma_mixlo_f16 v49, v9, s44, 0                            // 00000015A598: CC210031 02005909
	v_fma_mixhi_f16 v49, v10, s44, 0                           // 00000015A5A0: CC220031 0200590A
	v_fma_mixlo_f16 v50, v11, s44, 0                           // 00000015A5A8: CC210032 0200590B
	v_fma_mixhi_f16 v50, v12, s44, 0                           // 00000015A5B0: CC220032 0200590C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015A5B8: 8C7E017E
	.long 0x7e6839b4                                           // 00000015A5BC: 7E6839B4
	.long 0x7f6639b4                                           // 00000015A5C0: 7F6639B4
	.long 0x7e6639b4                                           // 00000015A5C4: 7E6639B4
	s_and_saveexec_b32 s1, s0                                  // 00000015A5C8: BE812000
	s_cbranch_execz 11                                         // 00000015A5CC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11fc>
	global_load_b128 v[9:12], v[61:62], off offset:16          // 00000015A5D0: DC5E0010 097C003D
	s_waitcnt vmcnt(0)                                         // 00000015A5D8: BF8903F7
	v_fma_mixlo_f16 v51, v9, s44, 0                            // 00000015A5DC: CC210033 02005909
	v_fma_mixhi_f16 v51, v10, s44, 0                           // 00000015A5E4: CC220033 0200590A
	v_fma_mixlo_f16 v52, v11, s44, 0                           // 00000015A5EC: CC210034 0200590B
	v_fma_mixhi_f16 v52, v12, s44, 0                           // 00000015A5F4: CC220034 0200590C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015A5FC: 8C7E017E
	.long 0x7f703880                                           // 00000015A600: 7F703880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015A604: BF870001
	.long 0x7f6c39b8                                           // 00000015A608: 7F6C39B8
	.long 0x7e6c39b8                                           // 00000015A60C: 7E6C39B8
	.long 0x7f6a39b8                                           // 00000015A610: 7F6A39B8
	.long 0x7e6a39b8                                           // 00000015A614: 7E6A39B8
	s_and_saveexec_b32 s1, s0                                  // 00000015A618: BE812000
	s_cbranch_execz 11                                         // 00000015A61C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x124c>
	global_load_b128 v[9:12], v[61:62], off offset:32          // 00000015A620: DC5E0020 097C003D
	s_waitcnt vmcnt(0)                                         // 00000015A628: BF8903F7
	v_fma_mixlo_f16 v53, v9, s44, 0                            // 00000015A62C: CC210035 02005909
	v_fma_mixhi_f16 v53, v10, s44, 0                           // 00000015A634: CC220035 0200590A
	v_fma_mixlo_f16 v54, v11, s44, 0                           // 00000015A63C: CC210036 0200590B
	v_fma_mixhi_f16 v54, v12, s44, 0                           // 00000015A644: CC220036 0200590C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015A64C: 8C7E017E
	.long 0x7e7039b8                                           // 00000015A650: 7E7039B8
	.long 0x7f6e39b8                                           // 00000015A654: 7F6E39B8
	.long 0x7e6e39b8                                           // 00000015A658: 7E6E39B8
	s_and_saveexec_b32 s1, s0                                  // 00000015A65C: BE812000
	s_cbranch_execz 11                                         // 00000015A660: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1290>
	global_load_b128 v[9:12], v[61:62], off offset:48          // 00000015A664: DC5E0030 097C003D
	s_waitcnt vmcnt(0)                                         // 00000015A66C: BF8903F7
	v_fma_mixlo_f16 v55, v9, s44, 0                            // 00000015A670: CC210037 02005909
	v_fma_mixhi_f16 v55, v10, s44, 0                           // 00000015A678: CC220037 0200590A
	v_fma_mixlo_f16 v56, v11, s44, 0                           // 00000015A680: CC210038 0200590B
	v_fma_mixhi_f16 v56, v12, s44, 0                           // 00000015A688: CC220038 0200590C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015A690: 8C7E017E
	ds_load_b128 v[9:12], v79                                  // 00000015A694: DBFC0000 0900004F
	ds_load_b128 v[13:16], v79 offset:16                       // 00000015A69C: DBFC0010 0D00004F
	ds_load_b128 v[17:20], v79 offset:32                       // 00000015A6A4: DBFC0020 1100004F
	ds_load_b128 v[21:24], v79 offset:48                       // 00000015A6AC: DBFC0030 1500004F
	ds_load_b128 v[25:28], v79 offset:8448                     // 00000015A6B4: DBFC2100 1900004F
	ds_load_b128 v[29:32], v79 offset:8464                     // 00000015A6BC: DBFC2110 1D00004F
	ds_load_b128 v[33:36], v79 offset:8480                     // 00000015A6C4: DBFC2120 2100004F
	ds_load_b128 v[37:40], v79 offset:8496                     // 00000015A6CC: DBFC2130 2500004F
	ds_load_b128 v[41:44], v79 offset:16896                    // 00000015A6D4: DBFC4200 2900004F
	ds_load_b128 v[45:48], v79 offset:16912                    // 00000015A6DC: DBFC4210 2D00004F
	ds_load_b128 v[63:66], v79 offset:16928                    // 00000015A6E4: DBFC4220 3F00004F
	ds_load_b128 v[67:70], v79 offset:16944                    // 00000015A6EC: DBFC4230 4300004F
	s_waitcnt lgkmcnt(11)                                      // 00000015A6F4: BF89FCB7
	v_fma_mixlo_f16 v9, v9, s44, 0                             // 00000015A6F8: CC210009 02005909
	v_fma_mixhi_f16 v9, v10, s44, 0                            // 00000015A700: CC220009 0200590A
	v_fma_mixlo_f16 v10, v11, s44, 0                           // 00000015A708: CC21000A 0200590B
	v_fma_mixhi_f16 v10, v12, s44, 0                           // 00000015A710: CC22000A 0200590C
	s_waitcnt lgkmcnt(10)                                      // 00000015A718: BF89FCA7
	v_fma_mixlo_f16 v11, v13, s44, 0                           // 00000015A71C: CC21000B 0200590D
	v_fma_mixhi_f16 v11, v14, s44, 0                           // 00000015A724: CC22000B 0200590E
	v_fma_mixlo_f16 v12, v15, s44, 0                           // 00000015A72C: CC21000C 0200590F
	v_fma_mixhi_f16 v12, v16, s44, 0                           // 00000015A734: CC22000C 02005910
	s_waitcnt lgkmcnt(9)                                       // 00000015A73C: BF89FC97
	v_fma_mixlo_f16 v13, v17, s44, 0                           // 00000015A740: CC21000D 02005911
	v_fma_mixhi_f16 v13, v18, s44, 0                           // 00000015A748: CC22000D 02005912
	v_fma_mixlo_f16 v14, v19, s44, 0                           // 00000015A750: CC21000E 02005913
	v_fma_mixhi_f16 v14, v20, s44, 0                           // 00000015A758: CC22000E 02005914
	s_waitcnt lgkmcnt(8)                                       // 00000015A760: BF89FC87
	v_fma_mixlo_f16 v15, v21, s44, 0                           // 00000015A764: CC21000F 02005915
	v_fma_mixhi_f16 v15, v22, s44, 0                           // 00000015A76C: CC22000F 02005916
	v_fma_mixlo_f16 v16, v23, s44, 0                           // 00000015A774: CC210010 02005917
	v_fma_mixhi_f16 v16, v24, s44, 0                           // 00000015A77C: CC220010 02005918
	s_waitcnt lgkmcnt(7)                                       // 00000015A784: BF89FC77
	v_fma_mixlo_f16 v17, v25, s44, 0                           // 00000015A788: CC210011 02005919
	v_fma_mixhi_f16 v17, v26, s44, 0                           // 00000015A790: CC220011 0200591A
	v_fma_mixlo_f16 v18, v27, s44, 0                           // 00000015A798: CC210012 0200591B
	v_fma_mixhi_f16 v18, v28, s44, 0                           // 00000015A7A0: CC220012 0200591C
	s_waitcnt lgkmcnt(6)                                       // 00000015A7A8: BF89FC67
	v_fma_mixlo_f16 v19, v29, s44, 0                           // 00000015A7AC: CC210013 0200591D
	v_fma_mixhi_f16 v19, v30, s44, 0                           // 00000015A7B4: CC220013 0200591E
	v_fma_mixlo_f16 v20, v31, s44, 0                           // 00000015A7BC: CC210014 0200591F
	v_fma_mixhi_f16 v20, v32, s44, 0                           // 00000015A7C4: CC220014 02005920
	s_waitcnt lgkmcnt(5)                                       // 00000015A7CC: BF89FC57
	v_fma_mixlo_f16 v21, v33, s44, 0                           // 00000015A7D0: CC210015 02005921
	v_fma_mixhi_f16 v21, v34, s44, 0                           // 00000015A7D8: CC220015 02005922
	v_fma_mixlo_f16 v22, v35, s44, 0                           // 00000015A7E0: CC210016 02005923
	v_fma_mixhi_f16 v22, v36, s44, 0                           // 00000015A7E8: CC220016 02005924
	s_waitcnt lgkmcnt(4)                                       // 00000015A7F0: BF89FC47
	v_fma_mixlo_f16 v23, v37, s44, 0                           // 00000015A7F4: CC210017 02005925
	v_fma_mixhi_f16 v23, v38, s44, 0                           // 00000015A7FC: CC220017 02005926
	v_fma_mixlo_f16 v24, v39, s44, 0                           // 00000015A804: CC210018 02005927
	v_fma_mixhi_f16 v24, v40, s44, 0                           // 00000015A80C: CC220018 02005928
	v_wmma_f32_16x16x16_f16 v[33:40], v[49:56], v[9:16], v[1:8]// 00000015A814: CC404021 1C061331
	s_waitcnt lgkmcnt(3)                                       // 00000015A81C: BF89FC37
	v_fma_mixlo_f16 v9, v41, s44, 0                            // 00000015A820: CC210009 02005929
	v_fma_mixhi_f16 v9, v42, s44, 0                            // 00000015A828: CC220009 0200592A
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[17:24], v[1:8]// 00000015A830: CC404019 1C062331
	ds_load_b128 v[17:20], v79 offset:25344                    // 00000015A838: DBFC6300 1100004F
	ds_load_b128 v[21:24], v79 offset:25360                    // 00000015A840: DBFC6310 1500004F
	v_fma_mixlo_f16 v10, v43, s44, 0                           // 00000015A848: CC21000A 0200592B
	v_fma_mixhi_f16 v10, v44, s44, 0                           // 00000015A850: CC22000A 0200592C
	s_waitcnt lgkmcnt(4)                                       // 00000015A858: BF89FC47
	v_fma_mixlo_f16 v11, v45, s44, 0                           // 00000015A85C: CC21000B 0200592D
	v_fma_mixhi_f16 v11, v46, s44, 0                           // 00000015A864: CC22000B 0200592E
	ds_load_b128 v[41:44], v79 offset:25376                    // 00000015A86C: DBFC6320 2900004F
	v_fma_mixlo_f16 v12, v47, s44, 0                           // 00000015A874: CC21000C 0200592F
	v_fma_mixhi_f16 v12, v48, s44, 0                           // 00000015A87C: CC22000C 02005930
	ds_load_b128 v[45:48], v79 offset:25392                    // 00000015A884: DBFC6330 2D00004F
	s_waitcnt lgkmcnt(5)                                       // 00000015A88C: BF89FC57
	v_fma_mixlo_f16 v13, v63, s44, 0                           // 00000015A890: CC21000D 0200593F
	v_fma_mixhi_f16 v13, v64, s44, 0                           // 00000015A898: CC22000D 02005940
	v_fma_mixlo_f16 v14, v65, s44, 0                           // 00000015A8A0: CC21000E 02005941
	v_fma_mixhi_f16 v14, v66, s44, 0                           // 00000015A8A8: CC22000E 02005942
	s_waitcnt lgkmcnt(4)                                       // 00000015A8B0: BF89FC47
	v_fma_mixlo_f16 v15, v67, s44, 0                           // 00000015A8B4: CC21000F 02005943
	v_fma_mixhi_f16 v15, v68, s44, 0                           // 00000015A8BC: CC22000F 02005944
	v_fma_mixlo_f16 v16, v69, s44, 0                           // 00000015A8C4: CC210010 02005945
	v_fma_mixhi_f16 v16, v70, s44, 0                           // 00000015A8CC: CC220010 02005946
	s_waitcnt lgkmcnt(3)                                       // 00000015A8D4: BF89FC37
	v_fma_mixlo_f16 v63, v17, s44, 0                           // 00000015A8D8: CC21003F 02005911
	v_fma_mixhi_f16 v63, v18, s44, 0                           // 00000015A8E0: CC22003F 02005912
	v_fma_mixlo_f16 v64, v19, s44, 0                           // 00000015A8E8: CC210040 02005913
	v_fma_mixhi_f16 v64, v20, s44, 0                           // 00000015A8F0: CC220040 02005914
	s_waitcnt lgkmcnt(2)                                       // 00000015A8F8: BF89FC27
	v_fma_mixlo_f16 v65, v21, s44, 0                           // 00000015A8FC: CC210041 02005915
	v_fma_mixhi_f16 v65, v22, s44, 0                           // 00000015A904: CC220041 02005916
	v_fma_mixlo_f16 v66, v23, s44, 0                           // 00000015A90C: CC210042 02005917
	v_fma_mixhi_f16 v66, v24, s44, 0                           // 00000015A914: CC220042 02005918
	s_waitcnt lgkmcnt(1)                                       // 00000015A91C: BF89FC17
	v_fma_mixlo_f16 v67, v41, s44, 0                           // 00000015A920: CC210043 02005929
	v_fma_mixhi_f16 v67, v42, s44, 0                           // 00000015A928: CC220043 0200592A
	v_fma_mixlo_f16 v68, v43, s44, 0                           // 00000015A930: CC210044 0200592B
	v_fma_mixhi_f16 v68, v44, s44, 0                           // 00000015A938: CC220044 0200592C
	s_waitcnt lgkmcnt(0)                                       // 00000015A940: BF89FC07
	v_fma_mixlo_f16 v69, v45, s44, 0                           // 00000015A944: CC210045 0200592D
	v_fma_mixhi_f16 v69, v46, s44, 0                           // 00000015A94C: CC220045 0200592E
	v_fma_mixlo_f16 v70, v47, s44, 0                           // 00000015A954: CC210046 0200592F
	v_fma_mixhi_f16 v70, v48, s44, 0                           // 00000015A95C: CC220046 02005930
	.long 0x7f603880                                           // 00000015A964: 7F603880
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[9:16], v[1:8]// 00000015A968: CC404011 1C061331
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000015A970: BF870193
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[63:70], v[1:8]// 00000015A974: CC404009 1C067F31
	.long 0x7f5c39b0                                           // 00000015A97C: 7F5C39B0
	.long 0x7e5c39b0                                           // 00000015A980: 7E5C39B0
	.long 0x7f5a39b0                                           // 00000015A984: 7F5A39B0
	.long 0x7e5a39b0                                           // 00000015A988: 7E5A39B0
	s_and_saveexec_b32 s1, s0                                  // 00000015A98C: BE812000
	s_cbranch_execz 11                                         // 00000015A990: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	global_load_b128 v[41:44], v[61:62], off offset:64         // 00000015A994: DC5E0040 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015A99C: BF8903F7
	v_fma_mixlo_f16 v45, v41, s44, 0                           // 00000015A9A0: CC21002D 02005929
	v_fma_mixhi_f16 v45, v42, s44, 0                           // 00000015A9A8: CC22002D 0200592A
	v_fma_mixlo_f16 v46, v43, s44, 0                           // 00000015A9B0: CC21002E 0200592B
	v_fma_mixhi_f16 v46, v44, s44, 0                           // 00000015A9B8: CC22002E 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015A9C0: 8C7E017E
	.long 0x7e6039b0                                           // 00000015A9C4: 7E6039B0
	.long 0x7f5e39b0                                           // 00000015A9C8: 7F5E39B0
	.long 0x7e5e39b0                                           // 00000015A9CC: 7E5E39B0
	s_and_saveexec_b32 s1, s0                                  // 00000015A9D0: BE812000
	s_cbranch_execz 11                                         // 00000015A9D4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1604>
	global_load_b128 v[41:44], v[61:62], off offset:80         // 00000015A9D8: DC5E0050 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015A9E0: BF8903F7
	v_fma_mixlo_f16 v47, v41, s44, 0                           // 00000015A9E4: CC21002F 02005929
	v_fma_mixhi_f16 v47, v42, s44, 0                           // 00000015A9EC: CC22002F 0200592A
	v_fma_mixlo_f16 v48, v43, s44, 0                           // 00000015A9F4: CC210030 0200592B
	v_fma_mixhi_f16 v48, v44, s44, 0                           // 00000015A9FC: CC220030 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015AA04: 8C7E017E
	.long 0x7f683880                                           // 00000015AA08: 7F683880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015AA0C: BF870001
	.long 0x7f6439b4                                           // 00000015AA10: 7F6439B4
	.long 0x7e6439b4                                           // 00000015AA14: 7E6439B4
	.long 0x7f6239b4                                           // 00000015AA18: 7F6239B4
	.long 0x7e6239b4                                           // 00000015AA1C: 7E6239B4
	s_and_saveexec_b32 s1, s0                                  // 00000015AA20: BE812000
	s_cbranch_execz 11                                         // 00000015AA24: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1654>
	global_load_b128 v[41:44], v[61:62], off offset:96         // 00000015AA28: DC5E0060 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015AA30: BF8903F7
	v_fma_mixlo_f16 v49, v41, s44, 0                           // 00000015AA34: CC210031 02005929
	v_fma_mixhi_f16 v49, v42, s44, 0                           // 00000015AA3C: CC220031 0200592A
	v_fma_mixlo_f16 v50, v43, s44, 0                           // 00000015AA44: CC210032 0200592B
	v_fma_mixhi_f16 v50, v44, s44, 0                           // 00000015AA4C: CC220032 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015AA54: 8C7E017E
	.long 0x7e6839b4                                           // 00000015AA58: 7E6839B4
	.long 0x7f6639b4                                           // 00000015AA5C: 7F6639B4
	.long 0x7e6639b4                                           // 00000015AA60: 7E6639B4
	s_and_saveexec_b32 s1, s0                                  // 00000015AA64: BE812000
	s_cbranch_execz 11                                         // 00000015AA68: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1698>
	global_load_b128 v[41:44], v[61:62], off offset:112        // 00000015AA6C: DC5E0070 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015AA74: BF8903F7
	v_fma_mixlo_f16 v51, v41, s44, 0                           // 00000015AA78: CC210033 02005929
	v_fma_mixhi_f16 v51, v42, s44, 0                           // 00000015AA80: CC220033 0200592A
	v_fma_mixlo_f16 v52, v43, s44, 0                           // 00000015AA88: CC210034 0200592B
	v_fma_mixhi_f16 v52, v44, s44, 0                           // 00000015AA90: CC220034 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015AA98: 8C7E017E
	ds_load_b128 v[41:44], v79 offset:64                       // 00000015AA9C: DBFC0040 2900004F
	ds_load_b128 v[53:56], v79 offset:80                       // 00000015AAA4: DBFC0050 3500004F
	ds_load_b128 v[67:70], v79 offset:96                       // 00000015AAAC: DBFC0060 4300004F
	ds_load_b128 v[91:94], v79 offset:112                      // 00000015AAB4: DBFC0070 5B00004F
	ds_load_b128 v[95:98], v79 offset:8512                     // 00000015AABC: DBFC2140 5F00004F
	ds_load_b128 v[99:102], v79 offset:8528                    // 00000015AAC4: DBFC2150 6300004F
	ds_load_b128 v[103:106], v79 offset:8544                   // 00000015AACC: DBFC2160 6700004F
	ds_load_b128 v[107:110], v79 offset:8560                   // 00000015AAD4: DBFC2170 6B00004F
	ds_load_b128 v[111:114], v79 offset:16992                  // 00000015AADC: DBFC4260 6F00004F
	ds_load_b128 v[115:118], v79 offset:17008                  // 00000015AAE4: DBFC4270 7300004F
	ds_load_b128 v[119:122], v79 offset:25424                  // 00000015AAEC: DBFC6350 7700004F
	s_waitcnt lgkmcnt(10)                                      // 00000015AAF4: BF89FCA7
	v_fma_mixlo_f16 v63, v41, s44, 0                           // 00000015AAF8: CC21003F 02005929
	v_fma_mixhi_f16 v63, v42, s44, 0                           // 00000015AB00: CC22003F 0200592A
	v_fma_mixlo_f16 v64, v43, s44, 0                           // 00000015AB08: CC210040 0200592B
	v_fma_mixhi_f16 v64, v44, s44, 0                           // 00000015AB10: CC220040 0200592C
	s_waitcnt lgkmcnt(9)                                       // 00000015AB18: BF89FC97
	v_fma_mixlo_f16 v65, v53, s44, 0                           // 00000015AB1C: CC210041 02005935
	v_fma_mixhi_f16 v65, v54, s44, 0                           // 00000015AB24: CC220041 02005936
	v_fma_mixlo_f16 v66, v55, s44, 0                           // 00000015AB2C: CC210042 02005937
	v_fma_mixhi_f16 v66, v56, s44, 0                           // 00000015AB34: CC220042 02005938
	ds_load_b128 v[41:44], v79 offset:16960                    // 00000015AB3C: DBFC4240 2900004F
	ds_load_b128 v[53:56], v79 offset:16976                    // 00000015AB44: DBFC4250 3500004F
	s_waitcnt lgkmcnt(10)                                      // 00000015AB4C: BF89FCA7
	v_fma_mixlo_f16 v67, v67, s44, 0                           // 00000015AB50: CC210043 02005943
	v_fma_mixhi_f16 v67, v68, s44, 0                           // 00000015AB58: CC220043 02005944
	v_fma_mixlo_f16 v68, v69, s44, 0                           // 00000015AB60: CC210044 02005945
	v_fma_mixhi_f16 v68, v70, s44, 0                           // 00000015AB68: CC220044 02005946
	s_waitcnt lgkmcnt(9)                                       // 00000015AB70: BF89FC97
	v_fma_mixhi_f16 v69, v92, s44, 0                           // 00000015AB74: CC220045 0200595C
	v_fma_mixlo_f16 v70, v93, s44, 0                           // 00000015AB7C: CC210046 0200595D
	v_fma_mixhi_f16 v70, v94, s44, 0                           // 00000015AB84: CC220046 0200595E
	s_waitcnt lgkmcnt(8)                                       // 00000015AB8C: BF89FC87
	v_fma_mixlo_f16 v92, v97, s44, 0                           // 00000015AB90: CC21005C 02005961
	v_fma_mixhi_f16 v92, v98, s44, 0                           // 00000015AB98: CC22005C 02005962
	s_waitcnt lgkmcnt(7)                                       // 00000015ABA0: BF89FC77
	v_fma_mixlo_f16 v93, v99, s44, 0                           // 00000015ABA4: CC21005D 02005963
	v_fma_mixhi_f16 v93, v100, s44, 0                          // 00000015ABAC: CC22005D 02005964
	v_fma_mixlo_f16 v94, v101, s44, 0                          // 00000015ABB4: CC21005E 02005965
	v_fma_mixhi_f16 v94, v102, s44, 0                          // 00000015ABBC: CC22005E 02005966
	s_waitcnt lgkmcnt(5)                                       // 00000015ABC4: BF89FC57
	v_fma_mixlo_f16 v97, v107, s44, 0                          // 00000015ABC8: CC210061 0200596B
	v_fma_mixhi_f16 v97, v108, s44, 0                          // 00000015ABD0: CC220061 0200596C
	v_fma_mixlo_f16 v98, v109, s44, 0                          // 00000015ABD8: CC210062 0200596D
	v_fma_mixhi_f16 v98, v110, s44, 0                          // 00000015ABE0: CC220062 0200596E
	ds_load_b128 v[107:110], v79 offset:25408                  // 00000015ABE8: DBFC6340 6B00004F
	s_waitcnt lgkmcnt(2)                                       // 00000015ABF0: BF89FC27
	v_fma_mixlo_f16 v99, v41, s44, 0                           // 00000015ABF4: CC210063 02005929
	v_fma_mixhi_f16 v99, v42, s44, 0                           // 00000015ABFC: CC220063 0200592A
	v_fma_mixlo_f16 v100, v43, s44, 0                          // 00000015AC04: CC210064 0200592B
	v_fma_mixhi_f16 v100, v44, s44, 0                          // 00000015AC0C: CC220064 0200592C
	s_waitcnt lgkmcnt(1)                                       // 00000015AC14: BF89FC17
	v_fma_mixlo_f16 v101, v53, s44, 0                          // 00000015AC18: CC210065 02005935
	v_fma_mixhi_f16 v101, v54, s44, 0                          // 00000015AC20: CC220065 02005936
	ds_load_b128 v[41:44], v79 offset:25440                    // 00000015AC28: DBFC6360 2900004F
	v_fma_mixlo_f16 v102, v55, s44, 0                          // 00000015AC30: CC210066 02005937
	v_fma_mixhi_f16 v102, v56, s44, 0                          // 00000015AC38: CC220066 02005938
	ds_load_b128 v[53:56], v79 offset:25456                    // 00000015AC40: DBFC6370 3500004F
	v_fma_mixlo_f16 v69, v91, s44, 0                           // 00000015AC48: CC210045 0200595B
	v_fma_mixlo_f16 v91, v95, s44, 0                           // 00000015AC50: CC21005B 0200595F
	v_fma_mixhi_f16 v91, v96, s44, 0                           // 00000015AC58: CC22005B 02005960
	v_fma_mixlo_f16 v95, v103, s44, 0                          // 00000015AC60: CC21005F 02005967
	v_fma_mixhi_f16 v95, v104, s44, 0                          // 00000015AC68: CC22005F 02005968
	v_fma_mixlo_f16 v96, v105, s44, 0                          // 00000015AC70: CC210060 02005969
	v_fma_mixhi_f16 v96, v106, s44, 0                          // 00000015AC78: CC220060 0200596A
	v_fma_mixlo_f16 v103, v111, s44, 0                         // 00000015AC80: CC210067 0200596F
	v_fma_mixhi_f16 v103, v112, s44, 0                         // 00000015AC88: CC220067 02005970
	v_fma_mixlo_f16 v104, v113, s44, 0                         // 00000015AC90: CC210068 02005971
	v_fma_mixhi_f16 v104, v114, s44, 0                         // 00000015AC98: CC220068 02005972
	v_fma_mixlo_f16 v105, v115, s44, 0                         // 00000015ACA0: CC210069 02005973
	v_fma_mixhi_f16 v105, v116, s44, 0                         // 00000015ACA8: CC220069 02005974
	v_fma_mixlo_f16 v106, v117, s44, 0                         // 00000015ACB0: CC21006A 02005975
	v_fma_mixhi_f16 v106, v118, s44, 0                         // 00000015ACB8: CC22006A 02005976
	s_waitcnt lgkmcnt(2)                                       // 00000015ACC0: BF89FC27
	v_fma_mixlo_f16 v107, v107, s44, 0                         // 00000015ACC4: CC21006B 0200596B
	v_fma_mixhi_f16 v107, v108, s44, 0                         // 00000015ACCC: CC22006B 0200596C
	v_fma_mixlo_f16 v108, v109, s44, 0                         // 00000015ACD4: CC21006C 0200596D
	v_fma_mixhi_f16 v108, v110, s44, 0                         // 00000015ACDC: CC22006C 0200596E
	v_fma_mixlo_f16 v109, v119, s44, 0                         // 00000015ACE4: CC21006D 02005977
	v_fma_mixhi_f16 v109, v120, s44, 0                         // 00000015ACEC: CC22006D 02005978
	v_fma_mixlo_f16 v110, v121, s44, 0                         // 00000015ACF4: CC21006E 02005979
	v_fma_mixhi_f16 v110, v122, s44, 0                         // 00000015ACFC: CC22006E 0200597A
	s_waitcnt lgkmcnt(1)                                       // 00000015AD04: BF89FC17
	v_fma_mixlo_f16 v111, v41, s44, 0                          // 00000015AD08: CC21006F 02005929
	v_fma_mixhi_f16 v111, v42, s44, 0                          // 00000015AD10: CC22006F 0200592A
	v_fma_mixlo_f16 v112, v43, s44, 0                          // 00000015AD18: CC210070 0200592B
	v_fma_mixhi_f16 v112, v44, s44, 0                          // 00000015AD20: CC220070 0200592C
	s_waitcnt lgkmcnt(0)                                       // 00000015AD28: BF89FC07
	v_fma_mixlo_f16 v113, v53, s44, 0                          // 00000015AD2C: CC210071 02005935
	v_fma_mixhi_f16 v113, v54, s44, 0                          // 00000015AD34: CC220071 02005936
	v_fma_mixlo_f16 v114, v55, s44, 0                          // 00000015AD3C: CC210072 02005937
	v_fma_mixhi_f16 v114, v56, s44, 0                          // 00000015AD44: CC220072 02005938
	.long 0x7f583880                                           // 00000015AD4C: 7F583880
	v_wmma_f32_16x16x16_f16 v[33:40], v[45:52], v[63:70], v[33:40]// 00000015AD50: CC404021 1C867F2D
	v_wmma_f32_16x16x16_f16 v[25:32], v[45:52], v[91:98], v[25:32]// 00000015AD58: CC404019 1C66B72D
	v_wmma_f32_16x16x16_f16 v[17:24], v[45:52], v[99:106], v[17:24]// 00000015AD60: CC404011 1C46C72D
	v_wmma_f32_16x16x16_f16 v[9:16], v[45:52], v[107:114], v[9:16]// 00000015AD68: CC404009 1C26D72D
	.long 0x7f5439ac                                           // 00000015AD70: 7F5439AC
	.long 0x7e5439ac                                           // 00000015AD74: 7E5439AC
	.long 0x7f5239ac                                           // 00000015AD78: 7F5239AC
	.long 0x7e5239ac                                           // 00000015AD7C: 7E5239AC
	s_and_saveexec_b32 s1, s0                                  // 00000015AD80: BE812000
	s_cbranch_execz 11                                         // 00000015AD84: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19b4>
	global_load_b128 v[45:48], v[61:62], off offset:128        // 00000015AD88: DC5E0080 2D7C003D
	s_waitcnt vmcnt(0)                                         // 00000015AD90: BF8903F7
	v_fma_mixlo_f16 v41, v45, s44, 0                           // 00000015AD94: CC210029 0200592D
	v_fma_mixhi_f16 v41, v46, s44, 0                           // 00000015AD9C: CC220029 0200592E
	v_fma_mixlo_f16 v42, v47, s44, 0                           // 00000015ADA4: CC21002A 0200592F
	v_fma_mixhi_f16 v42, v48, s44, 0                           // 00000015ADAC: CC22002A 02005930
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015ADB4: 8C7E017E
	.long 0x7e5839ac                                           // 00000015ADB8: 7E5839AC
	.long 0x7f5639ac                                           // 00000015ADBC: 7F5639AC
	.long 0x7e5639ac                                           // 00000015ADC0: 7E5639AC
	s_and_saveexec_b32 s1, s0                                  // 00000015ADC4: BE812000
	s_cbranch_execz 11                                         // 00000015ADC8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19f8>
	global_load_b128 v[43:46], v[61:62], off offset:144        // 00000015ADCC: DC5E0090 2B7C003D
	s_waitcnt vmcnt(0)                                         // 00000015ADD4: BF8903F7
	v_fma_mixlo_f16 v43, v43, s44, 0                           // 00000015ADD8: CC21002B 0200592B
	v_fma_mixhi_f16 v43, v44, s44, 0                           // 00000015ADE0: CC22002B 0200592C
	v_fma_mixlo_f16 v44, v45, s44, 0                           // 00000015ADE8: CC21002C 0200592D
	v_fma_mixhi_f16 v44, v46, s44, 0                           // 00000015ADF0: CC22002C 0200592E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015ADF8: 8C7E017E
	.long 0x7f603880                                           // 00000015ADFC: 7F603880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015AE00: BF870001
	.long 0x7f5c39b0                                           // 00000015AE04: 7F5C39B0
	.long 0x7e5c39b0                                           // 00000015AE08: 7E5C39B0
	.long 0x7f5a39b0                                           // 00000015AE0C: 7F5A39B0
	.long 0x7e5a39b0                                           // 00000015AE10: 7E5A39B0
	s_and_saveexec_b32 s1, s0                                  // 00000015AE14: BE812000
	s_cbranch_execz 11                                         // 00000015AE18: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a48>
	global_load_b128 v[49:52], v[61:62], off offset:160        // 00000015AE1C: DC5E00A0 317C003D
	s_waitcnt vmcnt(0)                                         // 00000015AE24: BF8903F7
	v_fma_mixlo_f16 v45, v49, s44, 0                           // 00000015AE28: CC21002D 02005931
	v_fma_mixhi_f16 v45, v50, s44, 0                           // 00000015AE30: CC22002D 02005932
	v_fma_mixlo_f16 v46, v51, s44, 0                           // 00000015AE38: CC21002E 02005933
	v_fma_mixhi_f16 v46, v52, s44, 0                           // 00000015AE40: CC22002E 02005934
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015AE48: 8C7E017E
	.long 0x7e6039b0                                           // 00000015AE4C: 7E6039B0
	.long 0x7f5e39b0                                           // 00000015AE50: 7F5E39B0
	.long 0x7e5e39b0                                           // 00000015AE54: 7E5E39B0
	s_and_saveexec_b32 s1, s0                                  // 00000015AE58: BE812000
	s_cbranch_execz 11                                         // 00000015AE5C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a8c>
	global_load_b128 v[47:50], v[61:62], off offset:176        // 00000015AE60: DC5E00B0 2F7C003D
	s_waitcnt vmcnt(0)                                         // 00000015AE68: BF8903F7
	v_fma_mixlo_f16 v47, v47, s44, 0                           // 00000015AE6C: CC21002F 0200592F
	v_fma_mixhi_f16 v47, v48, s44, 0                           // 00000015AE74: CC22002F 02005930
	v_fma_mixlo_f16 v48, v49, s44, 0                           // 00000015AE7C: CC210030 02005931
	v_fma_mixhi_f16 v48, v50, s44, 0                           // 00000015AE84: CC220030 02005932
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015AE8C: 8C7E017E
	ds_load_b128 v[50:53], v79 offset:128                      // 00000015AE90: DBFC0080 3200004F
	ds_load_b128 v[54:57], v79 offset:144                      // 00000015AE98: DBFC0090 3600004F
	ds_load_b128 v[63:66], v79 offset:160                      // 00000015AEA0: DBFC00A0 3F00004F
	ds_load_b128 v[67:70], v79 offset:176                      // 00000015AEA8: DBFC00B0 4300004F
	ds_load_b128 v[91:94], v79 offset:8576                     // 00000015AEB0: DBFC2180 5B00004F
	ds_load_b128 v[95:98], v79 offset:8592                     // 00000015AEB8: DBFC2190 5F00004F
	ds_load_b128 v[99:102], v79 offset:8608                    // 00000015AEC0: DBFC21A0 6300004F
	ds_load_b128 v[103:106], v79 offset:8624                   // 00000015AEC8: DBFC21B0 6700004F
	ds_load_b128 v[107:110], v79 offset:17024                  // 00000015AED0: DBFC4280 6B00004F
	ds_load_b128 v[111:114], v79 offset:17040                  // 00000015AED8: DBFC4290 6F00004F
	.long 0x7f623880                                           // 00000015AEE0: 7F623880
	ds_load_b128 v[115:118], v79 offset:25488                  // 00000015AEE4: DBFC6390 7300004F
	s_waitcnt lgkmcnt(10)                                      // 00000015AEEC: BF89FCA7
	v_fma_mixlo_f16 v50, v50, s44, 0                           // 00000015AEF0: CC210032 02005932
	v_fma_mixhi_f16 v50, v51, s44, 0                           // 00000015AEF8: CC220032 02005933
	v_fma_mixlo_f16 v51, v52, s44, 0                           // 00000015AF00: CC210033 02005934
	v_fma_mixhi_f16 v51, v53, s44, 0                           // 00000015AF08: CC220033 02005935
	s_waitcnt lgkmcnt(9)                                       // 00000015AF10: BF89FC97
	v_fma_mixlo_f16 v52, v54, s44, 0                           // 00000015AF14: CC210034 02005936
	v_fma_mixhi_f16 v52, v55, s44, 0                           // 00000015AF1C: CC220034 02005937
	v_fma_mixlo_f16 v53, v56, s44, 0                           // 00000015AF24: CC210035 02005938
	v_fma_mixhi_f16 v53, v57, s44, 0                           // 00000015AF2C: CC220035 02005939
	s_waitcnt lgkmcnt(8)                                       // 00000015AF34: BF89FC87
	v_fma_mixlo_f16 v54, v63, s44, 0                           // 00000015AF38: CC210036 0200593F
	v_fma_mixhi_f16 v54, v64, s44, 0                           // 00000015AF40: CC220036 02005940
	v_fma_mixlo_f16 v55, v65, s44, 0                           // 00000015AF48: CC210037 02005941
	v_fma_mixhi_f16 v55, v66, s44, 0                           // 00000015AF50: CC220037 02005942
	s_waitcnt lgkmcnt(7)                                       // 00000015AF58: BF89FC77
	v_fma_mixlo_f16 v56, v67, s44, 0                           // 00000015AF5C: CC210038 02005943
	v_fma_mixhi_f16 v56, v68, s44, 0                           // 00000015AF64: CC220038 02005944
	v_fma_mixlo_f16 v57, v69, s44, 0                           // 00000015AF6C: CC210039 02005945
	v_fma_mixhi_f16 v57, v70, s44, 0                           // 00000015AF74: CC220039 02005946
	s_waitcnt lgkmcnt(6)                                       // 00000015AF7C: BF89FC67
	v_fma_mixlo_f16 v63, v91, s44, 0                           // 00000015AF80: CC21003F 0200595B
	v_fma_mixhi_f16 v63, v92, s44, 0                           // 00000015AF88: CC22003F 0200595C
	v_fma_mixlo_f16 v64, v93, s44, 0                           // 00000015AF90: CC210040 0200595D
	v_fma_mixhi_f16 v64, v94, s44, 0                           // 00000015AF98: CC220040 0200595E
	s_waitcnt lgkmcnt(5)                                       // 00000015AFA0: BF89FC57
	v_fma_mixlo_f16 v65, v95, s44, 0                           // 00000015AFA4: CC210041 0200595F
	v_fma_mixhi_f16 v65, v96, s44, 0                           // 00000015AFAC: CC220041 02005960
	v_fma_mixlo_f16 v66, v97, s44, 0                           // 00000015AFB4: CC210042 02005961
	v_fma_mixhi_f16 v66, v98, s44, 0                           // 00000015AFBC: CC220042 02005962
	s_waitcnt lgkmcnt(4)                                       // 00000015AFC4: BF89FC47
	v_fma_mixlo_f16 v67, v99, s44, 0                           // 00000015AFC8: CC210043 02005963
	ds_load_b128 v[95:98], v79 offset:17056                    // 00000015AFD0: DBFC42A0 5F00004F
	v_fma_mixhi_f16 v67, v100, s44, 0                          // 00000015AFD8: CC220043 02005964
	v_fma_mixlo_f16 v68, v101, s44, 0                          // 00000015AFE0: CC210044 02005965
	v_fma_mixhi_f16 v68, v102, s44, 0                          // 00000015AFE8: CC220044 02005966
	s_waitcnt lgkmcnt(4)                                       // 00000015AFF0: BF89FC47
	v_fma_mixlo_f16 v69, v103, s44, 0                          // 00000015AFF4: CC210045 02005967
	ds_load_b128 v[99:102], v79 offset:17072                   // 00000015AFFC: DBFC42B0 6300004F
	v_fma_mixhi_f16 v69, v104, s44, 0                          // 00000015B004: CC220045 02005968
	v_fma_mixlo_f16 v70, v105, s44, 0                          // 00000015B00C: CC210046 02005969
	v_fma_mixhi_f16 v70, v106, s44, 0                          // 00000015B014: CC220046 0200596A
	ds_load_b128 v[103:106], v79 offset:25472                  // 00000015B01C: DBFC6380 6700004F
	s_waitcnt lgkmcnt(5)                                       // 00000015B024: BF89FC57
	v_fma_mixlo_f16 v91, v107, s44, 0                          // 00000015B028: CC21005B 0200596B
	v_fma_mixhi_f16 v91, v108, s44, 0                          // 00000015B030: CC22005B 0200596C
	v_fma_mixlo_f16 v92, v109, s44, 0                          // 00000015B038: CC21005C 0200596D
	v_fma_mixhi_f16 v92, v110, s44, 0                          // 00000015B040: CC22005C 0200596E
	s_waitcnt lgkmcnt(4)                                       // 00000015B048: BF89FC47
	v_fma_mixlo_f16 v93, v111, s44, 0                          // 00000015B04C: CC21005D 0200596F
	v_fma_mixhi_f16 v93, v112, s44, 0                          // 00000015B054: CC22005D 02005970
	ds_load_b128 v[107:110], v79 offset:25504                  // 00000015B05C: DBFC63A0 6B00004F
	v_fma_mixlo_f16 v94, v113, s44, 0                          // 00000015B064: CC21005E 02005971
	v_fma_mixhi_f16 v94, v114, s44, 0                          // 00000015B06C: CC22005E 02005972
	ds_load_b128 v[111:114], v79 offset:25520                  // 00000015B074: DBFC63B0 6F00004F
	s_waitcnt lgkmcnt(4)                                       // 00000015B07C: BF89FC47
	v_fma_mixlo_f16 v95, v95, s44, 0                           // 00000015B080: CC21005F 0200595F
	v_fma_mixhi_f16 v95, v96, s44, 0                           // 00000015B088: CC22005F 02005960
	v_fma_mixlo_f16 v96, v97, s44, 0                           // 00000015B090: CC210060 02005961
	v_fma_mixhi_f16 v96, v98, s44, 0                           // 00000015B098: CC220060 02005962
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[50:57], v[33:40]// 00000015B0A0: CC404021 1C866529
	s_waitcnt lgkmcnt(3)                                       // 00000015B0A8: BF89FC37
	v_fma_mixlo_f16 v97, v99, s44, 0                           // 00000015B0AC: CC210061 02005963
	v_fma_mixhi_f16 v97, v100, s44, 0                          // 00000015B0B4: CC220061 02005964
	v_fma_mixlo_f16 v98, v101, s44, 0                          // 00000015B0BC: CC210062 02005965
	v_fma_mixhi_f16 v98, v102, s44, 0                          // 00000015B0C4: CC220062 02005966
	s_waitcnt lgkmcnt(2)                                       // 00000015B0CC: BF89FC27
	v_fma_mixlo_f16 v99, v103, s44, 0                          // 00000015B0D0: CC210063 02005967
	v_fma_mixhi_f16 v99, v104, s44, 0                          // 00000015B0D8: CC220063 02005968
	v_fma_mixlo_f16 v100, v105, s44, 0                         // 00000015B0E0: CC210064 02005969
	v_fma_mixhi_f16 v100, v106, s44, 0                         // 00000015B0E8: CC220064 0200596A
	v_fma_mixlo_f16 v101, v115, s44, 0                         // 00000015B0F0: CC210065 02005973
	v_fma_mixhi_f16 v101, v116, s44, 0                         // 00000015B0F8: CC220065 02005974
	v_fma_mixlo_f16 v102, v117, s44, 0                         // 00000015B100: CC210066 02005975
	v_fma_mixhi_f16 v102, v118, s44, 0                         // 00000015B108: CC220066 02005976
	s_waitcnt lgkmcnt(1)                                       // 00000015B110: BF89FC17
	v_fma_mixlo_f16 v103, v107, s44, 0                         // 00000015B114: CC210067 0200596B
	v_fma_mixhi_f16 v103, v108, s44, 0                         // 00000015B11C: CC220067 0200596C
	v_fma_mixlo_f16 v104, v109, s44, 0                         // 00000015B124: CC210068 0200596D
	v_fma_mixhi_f16 v104, v110, s44, 0                         // 00000015B12C: CC220068 0200596E
	s_waitcnt lgkmcnt(0)                                       // 00000015B134: BF89FC07
	v_fma_mixlo_f16 v105, v111, s44, 0                         // 00000015B138: CC210069 0200596F
	v_fma_mixhi_f16 v105, v112, s44, 0                         // 00000015B140: CC220069 02005970
	v_fma_mixlo_f16 v106, v113, s44, 0                         // 00000015B148: CC21006A 02005971
	v_fma_mixhi_f16 v106, v114, s44, 0                         // 00000015B150: CC22006A 02005972
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[63:70], v[25:32]// 00000015B158: CC404019 1C667F29
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[91:98], v[17:24]// 00000015B160: CC404011 1C46B729
	s_delay_alu instid0(VALU_DEP_3)                            // 00000015B168: BF870003
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[99:106], v[9:16]// 00000015B16C: CC404009 1C26C729
	.long 0x7f5e39b1                                           // 00000015B174: 7F5E39B1
	.long 0x7e5e39b1                                           // 00000015B178: 7E5E39B1
	.long 0x7f5c39b1                                           // 00000015B17C: 7F5C39B1
	.long 0x7e5c39b1                                           // 00000015B180: 7E5C39B1
	s_and_saveexec_b32 s1, s0                                  // 00000015B184: BE812000
	s_cbranch_execz 11                                         // 00000015B188: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1db8>
	global_load_b128 v[41:44], v[61:62], off offset:192        // 00000015B18C: DC5E00C0 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015B194: BF8903F7
	v_fma_mixlo_f16 v46, v41, s44, 0                           // 00000015B198: CC21002E 02005929
	v_fma_mixhi_f16 v46, v42, s44, 0                           // 00000015B1A0: CC22002E 0200592A
	v_fma_mixlo_f16 v47, v43, s44, 0                           // 00000015B1A8: CC21002F 0200592B
	v_fma_mixhi_f16 v47, v44, s44, 0                           // 00000015B1B0: CC22002F 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015B1B8: 8C7E017E
	.long 0x7e6239b1                                           // 00000015B1BC: 7E6239B1
	.long 0x7f6039b1                                           // 00000015B1C0: 7F6039B1
	.long 0x7e6039b1                                           // 00000015B1C4: 7E6039B1
	s_and_saveexec_b32 s1, s0                                  // 00000015B1C8: BE812000
	s_cbranch_execz 11                                         // 00000015B1CC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dfc>
	global_load_b128 v[41:44], v[61:62], off offset:208        // 00000015B1D0: DC5E00D0 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015B1D8: BF8903F7
	v_fma_mixlo_f16 v48, v41, s44, 0                           // 00000015B1DC: CC210030 02005929
	v_fma_mixhi_f16 v48, v42, s44, 0                           // 00000015B1E4: CC220030 0200592A
	v_fma_mixlo_f16 v49, v43, s44, 0                           // 00000015B1EC: CC210031 0200592B
	v_fma_mixhi_f16 v49, v44, s44, 0                           // 00000015B1F4: CC220031 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015B1FC: 8C7E017E
	.long 0x7f6a3880                                           // 00000015B200: 7F6A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015B204: BF870001
	.long 0x7f6639b5                                           // 00000015B208: 7F6639B5
	.long 0x7e6639b5                                           // 00000015B20C: 7E6639B5
	.long 0x7f6439b5                                           // 00000015B210: 7F6439B5
	.long 0x7e6439b5                                           // 00000015B214: 7E6439B5
	s_and_saveexec_b32 s1, s0                                  // 00000015B218: BE812000
	s_cbranch_execz 11                                         // 00000015B21C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e4c>
	global_load_b128 v[41:44], v[61:62], off offset:224        // 00000015B220: DC5E00E0 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015B228: BF8903F7
	v_fma_mixlo_f16 v50, v41, s44, 0                           // 00000015B22C: CC210032 02005929
	v_fma_mixhi_f16 v50, v42, s44, 0                           // 00000015B234: CC220032 0200592A
	v_fma_mixlo_f16 v51, v43, s44, 0                           // 00000015B23C: CC210033 0200592B
	v_fma_mixhi_f16 v51, v44, s44, 0                           // 00000015B244: CC220033 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015B24C: 8C7E017E
	.long 0x7e6a39b5                                           // 00000015B250: 7E6A39B5
	.long 0x7f6839b5                                           // 00000015B254: 7F6839B5
	.long 0x7e6839b5                                           // 00000015B258: 7E6839B5
	s_and_saveexec_b32 s1, s0                                  // 00000015B25C: BE812000
	s_cbranch_execz 11                                         // 00000015B260: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e90>
	global_load_b128 v[41:44], v[61:62], off offset:240        // 00000015B264: DC5E00F0 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015B26C: BF8903F7
	v_fma_mixlo_f16 v52, v41, s44, 0                           // 00000015B270: CC210034 02005929
	v_fma_mixhi_f16 v52, v42, s44, 0                           // 00000015B278: CC220034 0200592A
	v_fma_mixlo_f16 v53, v43, s44, 0                           // 00000015B280: CC210035 0200592B
	v_fma_mixhi_f16 v53, v44, s44, 0                           // 00000015B288: CC220035 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015B290: 8C7E017E
	ds_load_b128 v[41:44], v79 offset:192                      // 00000015B294: DBFC00C0 2900004F
	ds_load_b128 v[54:57], v79 offset:208                      // 00000015B29C: DBFC00D0 3600004F
	ds_load_b128 v[67:70], v79 offset:224                      // 00000015B2A4: DBFC00E0 4300004F
	ds_load_b128 v[91:94], v79 offset:240                      // 00000015B2AC: DBFC00F0 5B00004F
	ds_load_b128 v[95:98], v79 offset:8640                     // 00000015B2B4: DBFC21C0 5F00004F
	ds_load_b128 v[99:102], v79 offset:8656                    // 00000015B2BC: DBFC21D0 6300004F
	ds_load_b128 v[103:106], v79 offset:8672                   // 00000015B2C4: DBFC21E0 6700004F
	ds_load_b128 v[107:110], v79 offset:8688                   // 00000015B2CC: DBFC21F0 6B00004F
	ds_load_b128 v[111:114], v79 offset:17120                  // 00000015B2D4: DBFC42E0 6F00004F
	ds_load_b128 v[115:118], v79 offset:17136                  // 00000015B2DC: DBFC42F0 7300004F
	ds_load_b128 v[119:122], v79 offset:25552                  // 00000015B2E4: DBFC63D0 7700004F
	s_waitcnt lgkmcnt(10)                                      // 00000015B2EC: BF89FCA7
	v_fma_mixlo_f16 v63, v41, s44, 0                           // 00000015B2F0: CC21003F 02005929
	v_fma_mixhi_f16 v63, v42, s44, 0                           // 00000015B2F8: CC22003F 0200592A
	v_fma_mixlo_f16 v64, v43, s44, 0                           // 00000015B300: CC210040 0200592B
	v_fma_mixhi_f16 v64, v44, s44, 0                           // 00000015B308: CC220040 0200592C
	s_waitcnt lgkmcnt(9)                                       // 00000015B310: BF89FC97
	v_fma_mixlo_f16 v65, v54, s44, 0                           // 00000015B314: CC210041 02005936
	v_fma_mixhi_f16 v65, v55, s44, 0                           // 00000015B31C: CC220041 02005937
	v_fma_mixlo_f16 v66, v56, s44, 0                           // 00000015B324: CC210042 02005938
	v_fma_mixhi_f16 v66, v57, s44, 0                           // 00000015B32C: CC220042 02005939
	ds_load_b128 v[41:44], v79 offset:17088                    // 00000015B334: DBFC42C0 2900004F
	ds_load_b128 v[54:57], v79 offset:17104                    // 00000015B33C: DBFC42D0 3600004F
	s_waitcnt lgkmcnt(10)                                      // 00000015B344: BF89FCA7
	v_fma_mixlo_f16 v67, v67, s44, 0                           // 00000015B348: CC210043 02005943
	v_fma_mixhi_f16 v67, v68, s44, 0                           // 00000015B350: CC220043 02005944
	v_fma_mixlo_f16 v68, v69, s44, 0                           // 00000015B358: CC210044 02005945
	v_fma_mixhi_f16 v68, v70, s44, 0                           // 00000015B360: CC220044 02005946
	s_waitcnt lgkmcnt(9)                                       // 00000015B368: BF89FC97
	v_fma_mixhi_f16 v69, v92, s44, 0                           // 00000015B36C: CC220045 0200595C
	v_fma_mixlo_f16 v70, v93, s44, 0                           // 00000015B374: CC210046 0200595D
	v_fma_mixhi_f16 v70, v94, s44, 0                           // 00000015B37C: CC220046 0200595E
	s_waitcnt lgkmcnt(8)                                       // 00000015B384: BF89FC87
	v_fma_mixlo_f16 v92, v97, s44, 0                           // 00000015B388: CC21005C 02005961
	v_fma_mixhi_f16 v92, v98, s44, 0                           // 00000015B390: CC22005C 02005962
	s_waitcnt lgkmcnt(7)                                       // 00000015B398: BF89FC77
	v_fma_mixlo_f16 v93, v99, s44, 0                           // 00000015B39C: CC21005D 02005963
	v_fma_mixhi_f16 v93, v100, s44, 0                          // 00000015B3A4: CC22005D 02005964
	v_fma_mixlo_f16 v94, v101, s44, 0                          // 00000015B3AC: CC21005E 02005965
	v_fma_mixhi_f16 v94, v102, s44, 0                          // 00000015B3B4: CC22005E 02005966
	s_waitcnt lgkmcnt(5)                                       // 00000015B3BC: BF89FC57
	v_fma_mixlo_f16 v97, v107, s44, 0                          // 00000015B3C0: CC210061 0200596B
	v_fma_mixhi_f16 v97, v108, s44, 0                          // 00000015B3C8: CC220061 0200596C
	v_fma_mixlo_f16 v98, v109, s44, 0                          // 00000015B3D0: CC210062 0200596D
	v_fma_mixhi_f16 v98, v110, s44, 0                          // 00000015B3D8: CC220062 0200596E
	ds_load_b128 v[107:110], v79 offset:25536                  // 00000015B3E0: DBFC63C0 6B00004F
	s_waitcnt lgkmcnt(2)                                       // 00000015B3E8: BF89FC27
	v_fma_mixlo_f16 v99, v41, s44, 0                           // 00000015B3EC: CC210063 02005929
	v_fma_mixhi_f16 v99, v42, s44, 0                           // 00000015B3F4: CC220063 0200592A
	v_fma_mixlo_f16 v100, v43, s44, 0                          // 00000015B3FC: CC210064 0200592B
	v_fma_mixhi_f16 v100, v44, s44, 0                          // 00000015B404: CC220064 0200592C
	s_waitcnt lgkmcnt(1)                                       // 00000015B40C: BF89FC17
	v_fma_mixlo_f16 v101, v54, s44, 0                          // 00000015B410: CC210065 02005936
	v_fma_mixhi_f16 v101, v55, s44, 0                          // 00000015B418: CC220065 02005937
	ds_load_b128 v[41:44], v79 offset:25568                    // 00000015B420: DBFC63E0 2900004F
	v_fma_mixlo_f16 v102, v56, s44, 0                          // 00000015B428: CC210066 02005938
	v_fma_mixhi_f16 v102, v57, s44, 0                          // 00000015B430: CC220066 02005939
	ds_load_b128 v[54:57], v79 offset:25584                    // 00000015B438: DBFC63F0 3600004F
	v_fma_mixlo_f16 v69, v91, s44, 0                           // 00000015B440: CC210045 0200595B
	v_fma_mixlo_f16 v91, v95, s44, 0                           // 00000015B448: CC21005B 0200595F
	v_fma_mixhi_f16 v91, v96, s44, 0                           // 00000015B450: CC22005B 02005960
	v_fma_mixlo_f16 v95, v103, s44, 0                          // 00000015B458: CC21005F 02005967
	v_fma_mixhi_f16 v95, v104, s44, 0                          // 00000015B460: CC22005F 02005968
	v_fma_mixlo_f16 v96, v105, s44, 0                          // 00000015B468: CC210060 02005969
	v_fma_mixhi_f16 v96, v106, s44, 0                          // 00000015B470: CC220060 0200596A
	v_fma_mixlo_f16 v103, v111, s44, 0                         // 00000015B478: CC210067 0200596F
	v_fma_mixhi_f16 v103, v112, s44, 0                         // 00000015B480: CC220067 02005970
	v_fma_mixlo_f16 v104, v113, s44, 0                         // 00000015B488: CC210068 02005971
	v_fma_mixhi_f16 v104, v114, s44, 0                         // 00000015B490: CC220068 02005972
	v_fma_mixlo_f16 v105, v115, s44, 0                         // 00000015B498: CC210069 02005973
	v_fma_mixhi_f16 v105, v116, s44, 0                         // 00000015B4A0: CC220069 02005974
	v_fma_mixlo_f16 v106, v117, s44, 0                         // 00000015B4A8: CC21006A 02005975
	v_fma_mixhi_f16 v106, v118, s44, 0                         // 00000015B4B0: CC22006A 02005976
	s_waitcnt lgkmcnt(2)                                       // 00000015B4B8: BF89FC27
	v_fma_mixlo_f16 v107, v107, s44, 0                         // 00000015B4BC: CC21006B 0200596B
	v_fma_mixhi_f16 v107, v108, s44, 0                         // 00000015B4C4: CC22006B 0200596C
	v_fma_mixlo_f16 v108, v109, s44, 0                         // 00000015B4CC: CC21006C 0200596D
	v_fma_mixhi_f16 v108, v110, s44, 0                         // 00000015B4D4: CC22006C 0200596E
	v_fma_mixlo_f16 v109, v119, s44, 0                         // 00000015B4DC: CC21006D 02005977
	v_fma_mixhi_f16 v109, v120, s44, 0                         // 00000015B4E4: CC22006D 02005978
	v_fma_mixlo_f16 v110, v121, s44, 0                         // 00000015B4EC: CC21006E 02005979
	v_fma_mixhi_f16 v110, v122, s44, 0                         // 00000015B4F4: CC22006E 0200597A
	s_waitcnt lgkmcnt(1)                                       // 00000015B4FC: BF89FC17
	v_fma_mixlo_f16 v111, v41, s44, 0                          // 00000015B500: CC21006F 02005929
	v_fma_mixhi_f16 v111, v42, s44, 0                          // 00000015B508: CC22006F 0200592A
	v_fma_mixlo_f16 v112, v43, s44, 0                          // 00000015B510: CC210070 0200592B
	v_fma_mixhi_f16 v112, v44, s44, 0                          // 00000015B518: CC220070 0200592C
	s_waitcnt lgkmcnt(0)                                       // 00000015B520: BF89FC07
	v_fma_mixlo_f16 v113, v54, s44, 0                          // 00000015B524: CC210071 02005936
	v_fma_mixhi_f16 v113, v55, s44, 0                          // 00000015B52C: CC220071 02005937
	v_fma_mixlo_f16 v114, v56, s44, 0                          // 00000015B534: CC210072 02005938
	v_fma_mixhi_f16 v114, v57, s44, 0                          // 00000015B53C: CC220072 02005939
	.long 0x7f583880                                           // 00000015B544: 7F583880
	v_wmma_f32_16x16x16_f16 v[33:40], v[46:53], v[63:70], v[33:40]// 00000015B548: CC404021 1C867F2E
	v_wmma_f32_16x16x16_f16 v[25:32], v[46:53], v[91:98], v[25:32]// 00000015B550: CC404019 1C66B72E
	v_wmma_f32_16x16x16_f16 v[17:24], v[46:53], v[99:106], v[17:24]// 00000015B558: CC404011 1C46C72E
	v_wmma_f32_16x16x16_f16 v[9:16], v[46:53], v[107:114], v[9:16]// 00000015B560: CC404009 1C26D72E
	.long 0x7f5439ac                                           // 00000015B568: 7F5439AC
	.long 0x7e5439ac                                           // 00000015B56C: 7E5439AC
	.long 0x7f5239ac                                           // 00000015B570: 7F5239AC
	.long 0x7e5239ac                                           // 00000015B574: 7E5239AC
	s_and_saveexec_b32 s1, s0                                  // 00000015B578: BE812000
	s_cbranch_execz 11                                         // 00000015B57C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x21ac>
	global_load_b128 v[45:48], v[61:62], off offset:256        // 00000015B580: DC5E0100 2D7C003D
	s_waitcnt vmcnt(0)                                         // 00000015B588: BF8903F7
	v_fma_mixlo_f16 v41, v45, s44, 0                           // 00000015B58C: CC210029 0200592D
	v_fma_mixhi_f16 v41, v46, s44, 0                           // 00000015B594: CC220029 0200592E
	v_fma_mixlo_f16 v42, v47, s44, 0                           // 00000015B59C: CC21002A 0200592F
	v_fma_mixhi_f16 v42, v48, s44, 0                           // 00000015B5A4: CC22002A 02005930
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015B5AC: 8C7E017E
	.long 0x7e5839ac                                           // 00000015B5B0: 7E5839AC
	.long 0x7f5639ac                                           // 00000015B5B4: 7F5639AC
	.long 0x7e5639ac                                           // 00000015B5B8: 7E5639AC
	s_and_saveexec_b32 s1, s0                                  // 00000015B5BC: BE812000
	s_cbranch_execz 11                                         // 00000015B5C0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x21f0>
	global_load_b128 v[43:46], v[61:62], off offset:272        // 00000015B5C4: DC5E0110 2B7C003D
	s_waitcnt vmcnt(0)                                         // 00000015B5CC: BF8903F7
	v_fma_mixlo_f16 v43, v43, s44, 0                           // 00000015B5D0: CC21002B 0200592B
	v_fma_mixhi_f16 v43, v44, s44, 0                           // 00000015B5D8: CC22002B 0200592C
	v_fma_mixlo_f16 v44, v45, s44, 0                           // 00000015B5E0: CC21002C 0200592D
	v_fma_mixhi_f16 v44, v46, s44, 0                           // 00000015B5E8: CC22002C 0200592E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015B5F0: 8C7E017E
	.long 0x7f603880                                           // 00000015B5F4: 7F603880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015B5F8: BF870001
	.long 0x7f5c39b0                                           // 00000015B5FC: 7F5C39B0
	.long 0x7e5c39b0                                           // 00000015B600: 7E5C39B0
	.long 0x7f5a39b0                                           // 00000015B604: 7F5A39B0
	.long 0x7e5a39b0                                           // 00000015B608: 7E5A39B0
	s_and_saveexec_b32 s1, s0                                  // 00000015B60C: BE812000
	s_cbranch_execz 11                                         // 00000015B610: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2240>
	global_load_b128 v[49:52], v[61:62], off offset:288        // 00000015B614: DC5E0120 317C003D
	s_waitcnt vmcnt(0)                                         // 00000015B61C: BF8903F7
	v_fma_mixlo_f16 v45, v49, s44, 0                           // 00000015B620: CC21002D 02005931
	v_fma_mixhi_f16 v45, v50, s44, 0                           // 00000015B628: CC22002D 02005932
	v_fma_mixlo_f16 v46, v51, s44, 0                           // 00000015B630: CC21002E 02005933
	v_fma_mixhi_f16 v46, v52, s44, 0                           // 00000015B638: CC22002E 02005934
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015B640: 8C7E017E
	.long 0x7e6039b0                                           // 00000015B644: 7E6039B0
	.long 0x7f5e39b0                                           // 00000015B648: 7F5E39B0
	.long 0x7e5e39b0                                           // 00000015B64C: 7E5E39B0
	s_and_saveexec_b32 s1, s0                                  // 00000015B650: BE812000
	s_cbranch_execz 11                                         // 00000015B654: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2284>
	global_load_b128 v[47:50], v[61:62], off offset:304        // 00000015B658: DC5E0130 2F7C003D
	s_waitcnt vmcnt(0)                                         // 00000015B660: BF8903F7
	v_fma_mixlo_f16 v47, v47, s44, 0                           // 00000015B664: CC21002F 0200592F
	v_fma_mixhi_f16 v47, v48, s44, 0                           // 00000015B66C: CC22002F 02005930
	v_fma_mixlo_f16 v48, v49, s44, 0                           // 00000015B674: CC210030 02005931
	v_fma_mixhi_f16 v48, v50, s44, 0                           // 00000015B67C: CC220030 02005932
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015B684: 8C7E017E
	ds_load_b128 v[50:53], v79 offset:256                      // 00000015B688: DBFC0100 3200004F
	ds_load_b128 v[54:57], v79 offset:272                      // 00000015B690: DBFC0110 3600004F
	ds_load_b128 v[63:66], v79 offset:288                      // 00000015B698: DBFC0120 3F00004F
	ds_load_b128 v[67:70], v79 offset:304                      // 00000015B6A0: DBFC0130 4300004F
	ds_load_b128 v[91:94], v79 offset:8704                     // 00000015B6A8: DBFC2200 5B00004F
	ds_load_b128 v[95:98], v79 offset:8720                     // 00000015B6B0: DBFC2210 5F00004F
	ds_load_b128 v[99:102], v79 offset:8736                    // 00000015B6B8: DBFC2220 6300004F
	ds_load_b128 v[103:106], v79 offset:8752                   // 00000015B6C0: DBFC2230 6700004F
	ds_load_b128 v[107:110], v79 offset:17152                  // 00000015B6C8: DBFC4300 6B00004F
	ds_load_b128 v[111:114], v79 offset:17168                  // 00000015B6D0: DBFC4310 6F00004F
	.long 0x7f623880                                           // 00000015B6D8: 7F623880
	ds_load_b128 v[115:118], v79 offset:25616                  // 00000015B6DC: DBFC6410 7300004F
	s_waitcnt lgkmcnt(10)                                      // 00000015B6E4: BF89FCA7
	v_fma_mixlo_f16 v50, v50, s44, 0                           // 00000015B6E8: CC210032 02005932
	v_fma_mixhi_f16 v50, v51, s44, 0                           // 00000015B6F0: CC220032 02005933
	v_fma_mixlo_f16 v51, v52, s44, 0                           // 00000015B6F8: CC210033 02005934
	v_fma_mixhi_f16 v51, v53, s44, 0                           // 00000015B700: CC220033 02005935
	s_waitcnt lgkmcnt(9)                                       // 00000015B708: BF89FC97
	v_fma_mixlo_f16 v52, v54, s44, 0                           // 00000015B70C: CC210034 02005936
	v_fma_mixhi_f16 v52, v55, s44, 0                           // 00000015B714: CC220034 02005937
	v_fma_mixlo_f16 v53, v56, s44, 0                           // 00000015B71C: CC210035 02005938
	v_fma_mixhi_f16 v53, v57, s44, 0                           // 00000015B724: CC220035 02005939
	s_waitcnt lgkmcnt(8)                                       // 00000015B72C: BF89FC87
	v_fma_mixlo_f16 v54, v63, s44, 0                           // 00000015B730: CC210036 0200593F
	v_fma_mixhi_f16 v54, v64, s44, 0                           // 00000015B738: CC220036 02005940
	v_fma_mixlo_f16 v55, v65, s44, 0                           // 00000015B740: CC210037 02005941
	v_fma_mixhi_f16 v55, v66, s44, 0                           // 00000015B748: CC220037 02005942
	s_waitcnt lgkmcnt(7)                                       // 00000015B750: BF89FC77
	v_fma_mixlo_f16 v56, v67, s44, 0                           // 00000015B754: CC210038 02005943
	v_fma_mixhi_f16 v56, v68, s44, 0                           // 00000015B75C: CC220038 02005944
	v_fma_mixlo_f16 v57, v69, s44, 0                           // 00000015B764: CC210039 02005945
	v_fma_mixhi_f16 v57, v70, s44, 0                           // 00000015B76C: CC220039 02005946
	s_waitcnt lgkmcnt(6)                                       // 00000015B774: BF89FC67
	v_fma_mixlo_f16 v63, v91, s44, 0                           // 00000015B778: CC21003F 0200595B
	v_fma_mixhi_f16 v63, v92, s44, 0                           // 00000015B780: CC22003F 0200595C
	v_fma_mixlo_f16 v64, v93, s44, 0                           // 00000015B788: CC210040 0200595D
	v_fma_mixhi_f16 v64, v94, s44, 0                           // 00000015B790: CC220040 0200595E
	s_waitcnt lgkmcnt(5)                                       // 00000015B798: BF89FC57
	v_fma_mixlo_f16 v65, v95, s44, 0                           // 00000015B79C: CC210041 0200595F
	v_fma_mixhi_f16 v65, v96, s44, 0                           // 00000015B7A4: CC220041 02005960
	v_fma_mixlo_f16 v66, v97, s44, 0                           // 00000015B7AC: CC210042 02005961
	v_fma_mixhi_f16 v66, v98, s44, 0                           // 00000015B7B4: CC220042 02005962
	s_waitcnt lgkmcnt(4)                                       // 00000015B7BC: BF89FC47
	v_fma_mixlo_f16 v67, v99, s44, 0                           // 00000015B7C0: CC210043 02005963
	ds_load_b128 v[95:98], v79 offset:17184                    // 00000015B7C8: DBFC4320 5F00004F
	v_fma_mixhi_f16 v67, v100, s44, 0                          // 00000015B7D0: CC220043 02005964
	v_fma_mixlo_f16 v68, v101, s44, 0                          // 00000015B7D8: CC210044 02005965
	v_fma_mixhi_f16 v68, v102, s44, 0                          // 00000015B7E0: CC220044 02005966
	s_waitcnt lgkmcnt(4)                                       // 00000015B7E8: BF89FC47
	v_fma_mixlo_f16 v69, v103, s44, 0                          // 00000015B7EC: CC210045 02005967
	ds_load_b128 v[99:102], v79 offset:17200                   // 00000015B7F4: DBFC4330 6300004F
	v_fma_mixhi_f16 v69, v104, s44, 0                          // 00000015B7FC: CC220045 02005968
	v_fma_mixlo_f16 v70, v105, s44, 0                          // 00000015B804: CC210046 02005969
	v_fma_mixhi_f16 v70, v106, s44, 0                          // 00000015B80C: CC220046 0200596A
	ds_load_b128 v[103:106], v79 offset:25600                  // 00000015B814: DBFC6400 6700004F
	s_waitcnt lgkmcnt(5)                                       // 00000015B81C: BF89FC57
	v_fma_mixlo_f16 v91, v107, s44, 0                          // 00000015B820: CC21005B 0200596B
	v_fma_mixhi_f16 v91, v108, s44, 0                          // 00000015B828: CC22005B 0200596C
	v_fma_mixlo_f16 v92, v109, s44, 0                          // 00000015B830: CC21005C 0200596D
	v_fma_mixhi_f16 v92, v110, s44, 0                          // 00000015B838: CC22005C 0200596E
	s_waitcnt lgkmcnt(4)                                       // 00000015B840: BF89FC47
	v_fma_mixlo_f16 v93, v111, s44, 0                          // 00000015B844: CC21005D 0200596F
	v_fma_mixhi_f16 v93, v112, s44, 0                          // 00000015B84C: CC22005D 02005970
	ds_load_b128 v[107:110], v79 offset:25632                  // 00000015B854: DBFC6420 6B00004F
	v_fma_mixlo_f16 v94, v113, s44, 0                          // 00000015B85C: CC21005E 02005971
	v_fma_mixhi_f16 v94, v114, s44, 0                          // 00000015B864: CC22005E 02005972
	ds_load_b128 v[111:114], v79 offset:25648                  // 00000015B86C: DBFC6430 6F00004F
	s_waitcnt lgkmcnt(4)                                       // 00000015B874: BF89FC47
	v_fma_mixlo_f16 v95, v95, s44, 0                           // 00000015B878: CC21005F 0200595F
	v_fma_mixhi_f16 v95, v96, s44, 0                           // 00000015B880: CC22005F 02005960
	v_fma_mixlo_f16 v96, v97, s44, 0                           // 00000015B888: CC210060 02005961
	v_fma_mixhi_f16 v96, v98, s44, 0                           // 00000015B890: CC220060 02005962
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[50:57], v[33:40]// 00000015B898: CC404021 1C866529
	s_waitcnt lgkmcnt(3)                                       // 00000015B8A0: BF89FC37
	v_fma_mixlo_f16 v97, v99, s44, 0                           // 00000015B8A4: CC210061 02005963
	v_fma_mixhi_f16 v97, v100, s44, 0                          // 00000015B8AC: CC220061 02005964
	v_fma_mixlo_f16 v98, v101, s44, 0                          // 00000015B8B4: CC210062 02005965
	v_fma_mixhi_f16 v98, v102, s44, 0                          // 00000015B8BC: CC220062 02005966
	s_waitcnt lgkmcnt(2)                                       // 00000015B8C4: BF89FC27
	v_fma_mixlo_f16 v99, v103, s44, 0                          // 00000015B8C8: CC210063 02005967
	v_fma_mixhi_f16 v99, v104, s44, 0                          // 00000015B8D0: CC220063 02005968
	v_fma_mixlo_f16 v100, v105, s44, 0                         // 00000015B8D8: CC210064 02005969
	v_fma_mixhi_f16 v100, v106, s44, 0                         // 00000015B8E0: CC220064 0200596A
	v_fma_mixlo_f16 v101, v115, s44, 0                         // 00000015B8E8: CC210065 02005973
	v_fma_mixhi_f16 v101, v116, s44, 0                         // 00000015B8F0: CC220065 02005974
	v_fma_mixlo_f16 v102, v117, s44, 0                         // 00000015B8F8: CC210066 02005975
	v_fma_mixhi_f16 v102, v118, s44, 0                         // 00000015B900: CC220066 02005976
	s_waitcnt lgkmcnt(1)                                       // 00000015B908: BF89FC17
	v_fma_mixlo_f16 v103, v107, s44, 0                         // 00000015B90C: CC210067 0200596B
	v_fma_mixhi_f16 v103, v108, s44, 0                         // 00000015B914: CC220067 0200596C
	v_fma_mixlo_f16 v104, v109, s44, 0                         // 00000015B91C: CC210068 0200596D
	v_fma_mixhi_f16 v104, v110, s44, 0                         // 00000015B924: CC220068 0200596E
	s_waitcnt lgkmcnt(0)                                       // 00000015B92C: BF89FC07
	v_fma_mixlo_f16 v105, v111, s44, 0                         // 00000015B930: CC210069 0200596F
	v_fma_mixhi_f16 v105, v112, s44, 0                         // 00000015B938: CC220069 02005970
	v_fma_mixlo_f16 v106, v113, s44, 0                         // 00000015B940: CC21006A 02005971
	v_fma_mixhi_f16 v106, v114, s44, 0                         // 00000015B948: CC22006A 02005972
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[63:70], v[25:32]// 00000015B950: CC404019 1C667F29
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[91:98], v[17:24]// 00000015B958: CC404011 1C46B729
	s_delay_alu instid0(VALU_DEP_3)                            // 00000015B960: BF870003
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[99:106], v[9:16]// 00000015B964: CC404009 1C26C729
	.long 0x7f5e39b1                                           // 00000015B96C: 7F5E39B1
	.long 0x7e5e39b1                                           // 00000015B970: 7E5E39B1
	.long 0x7f5c39b1                                           // 00000015B974: 7F5C39B1
	.long 0x7e5c39b1                                           // 00000015B978: 7E5C39B1
	s_and_saveexec_b32 s1, s0                                  // 00000015B97C: BE812000
	s_cbranch_execz 11                                         // 00000015B980: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25b0>
	global_load_b128 v[41:44], v[61:62], off offset:320        // 00000015B984: DC5E0140 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015B98C: BF8903F7
	v_fma_mixlo_f16 v46, v41, s44, 0                           // 00000015B990: CC21002E 02005929
	v_fma_mixhi_f16 v46, v42, s44, 0                           // 00000015B998: CC22002E 0200592A
	v_fma_mixlo_f16 v47, v43, s44, 0                           // 00000015B9A0: CC21002F 0200592B
	v_fma_mixhi_f16 v47, v44, s44, 0                           // 00000015B9A8: CC22002F 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015B9B0: 8C7E017E
	.long 0x7e6239b1                                           // 00000015B9B4: 7E6239B1
	.long 0x7f6039b1                                           // 00000015B9B8: 7F6039B1
	.long 0x7e6039b1                                           // 00000015B9BC: 7E6039B1
	s_and_saveexec_b32 s1, s0                                  // 00000015B9C0: BE812000
	s_cbranch_execz 11                                         // 00000015B9C4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25f4>
	global_load_b128 v[41:44], v[61:62], off offset:336        // 00000015B9C8: DC5E0150 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015B9D0: BF8903F7
	v_fma_mixlo_f16 v48, v41, s44, 0                           // 00000015B9D4: CC210030 02005929
	v_fma_mixhi_f16 v48, v42, s44, 0                           // 00000015B9DC: CC220030 0200592A
	v_fma_mixlo_f16 v49, v43, s44, 0                           // 00000015B9E4: CC210031 0200592B
	v_fma_mixhi_f16 v49, v44, s44, 0                           // 00000015B9EC: CC220031 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015B9F4: 8C7E017E
	.long 0x7f6a3880                                           // 00000015B9F8: 7F6A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015B9FC: BF870001
	.long 0x7f6639b5                                           // 00000015BA00: 7F6639B5
	.long 0x7e6639b5                                           // 00000015BA04: 7E6639B5
	.long 0x7f6439b5                                           // 00000015BA08: 7F6439B5
	.long 0x7e6439b5                                           // 00000015BA0C: 7E6439B5
	s_and_saveexec_b32 s1, s0                                  // 00000015BA10: BE812000
	s_cbranch_execz 11                                         // 00000015BA14: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2644>
	global_load_b128 v[41:44], v[61:62], off offset:352        // 00000015BA18: DC5E0160 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015BA20: BF8903F7
	v_fma_mixlo_f16 v50, v41, s44, 0                           // 00000015BA24: CC210032 02005929
	v_fma_mixhi_f16 v50, v42, s44, 0                           // 00000015BA2C: CC220032 0200592A
	v_fma_mixlo_f16 v51, v43, s44, 0                           // 00000015BA34: CC210033 0200592B
	v_fma_mixhi_f16 v51, v44, s44, 0                           // 00000015BA3C: CC220033 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015BA44: 8C7E017E
	.long 0x7e6a39b5                                           // 00000015BA48: 7E6A39B5
	.long 0x7f6839b5                                           // 00000015BA4C: 7F6839B5
	.long 0x7e6839b5                                           // 00000015BA50: 7E6839B5
	s_and_saveexec_b32 s1, s0                                  // 00000015BA54: BE812000
	s_cbranch_execz 11                                         // 00000015BA58: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2688>
	global_load_b128 v[41:44], v[61:62], off offset:368        // 00000015BA5C: DC5E0170 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015BA64: BF8903F7
	v_fma_mixlo_f16 v52, v41, s44, 0                           // 00000015BA68: CC210034 02005929
	v_fma_mixhi_f16 v52, v42, s44, 0                           // 00000015BA70: CC220034 0200592A
	v_fma_mixlo_f16 v53, v43, s44, 0                           // 00000015BA78: CC210035 0200592B
	v_fma_mixhi_f16 v53, v44, s44, 0                           // 00000015BA80: CC220035 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015BA88: 8C7E017E
	ds_load_b128 v[41:44], v79 offset:320                      // 00000015BA8C: DBFC0140 2900004F
	ds_load_b128 v[54:57], v79 offset:336                      // 00000015BA94: DBFC0150 3600004F
	ds_load_b128 v[67:70], v79 offset:352                      // 00000015BA9C: DBFC0160 4300004F
	ds_load_b128 v[91:94], v79 offset:368                      // 00000015BAA4: DBFC0170 5B00004F
	ds_load_b128 v[95:98], v79 offset:8768                     // 00000015BAAC: DBFC2240 5F00004F
	ds_load_b128 v[99:102], v79 offset:8784                    // 00000015BAB4: DBFC2250 6300004F
	ds_load_b128 v[103:106], v79 offset:8800                   // 00000015BABC: DBFC2260 6700004F
	ds_load_b128 v[107:110], v79 offset:8816                   // 00000015BAC4: DBFC2270 6B00004F
	ds_load_b128 v[111:114], v79 offset:17248                  // 00000015BACC: DBFC4360 6F00004F
	ds_load_b128 v[115:118], v79 offset:17264                  // 00000015BAD4: DBFC4370 7300004F
	ds_load_b128 v[119:122], v79 offset:25680                  // 00000015BADC: DBFC6450 7700004F
	s_waitcnt lgkmcnt(10)                                      // 00000015BAE4: BF89FCA7
	v_fma_mixlo_f16 v63, v41, s44, 0                           // 00000015BAE8: CC21003F 02005929
	v_fma_mixhi_f16 v63, v42, s44, 0                           // 00000015BAF0: CC22003F 0200592A
	v_fma_mixlo_f16 v64, v43, s44, 0                           // 00000015BAF8: CC210040 0200592B
	v_fma_mixhi_f16 v64, v44, s44, 0                           // 00000015BB00: CC220040 0200592C
	s_waitcnt lgkmcnt(9)                                       // 00000015BB08: BF89FC97
	v_fma_mixlo_f16 v65, v54, s44, 0                           // 00000015BB0C: CC210041 02005936
	v_fma_mixhi_f16 v65, v55, s44, 0                           // 00000015BB14: CC220041 02005937
	v_fma_mixlo_f16 v66, v56, s44, 0                           // 00000015BB1C: CC210042 02005938
	v_fma_mixhi_f16 v66, v57, s44, 0                           // 00000015BB24: CC220042 02005939
	ds_load_b128 v[41:44], v79 offset:17216                    // 00000015BB2C: DBFC4340 2900004F
	ds_load_b128 v[54:57], v79 offset:17232                    // 00000015BB34: DBFC4350 3600004F
	s_waitcnt lgkmcnt(10)                                      // 00000015BB3C: BF89FCA7
	v_fma_mixlo_f16 v67, v67, s44, 0                           // 00000015BB40: CC210043 02005943
	v_fma_mixhi_f16 v67, v68, s44, 0                           // 00000015BB48: CC220043 02005944
	v_fma_mixlo_f16 v68, v69, s44, 0                           // 00000015BB50: CC210044 02005945
	v_fma_mixhi_f16 v68, v70, s44, 0                           // 00000015BB58: CC220044 02005946
	s_waitcnt lgkmcnt(9)                                       // 00000015BB60: BF89FC97
	v_fma_mixhi_f16 v69, v92, s44, 0                           // 00000015BB64: CC220045 0200595C
	v_fma_mixlo_f16 v70, v93, s44, 0                           // 00000015BB6C: CC210046 0200595D
	v_fma_mixhi_f16 v70, v94, s44, 0                           // 00000015BB74: CC220046 0200595E
	s_waitcnt lgkmcnt(8)                                       // 00000015BB7C: BF89FC87
	v_fma_mixlo_f16 v92, v97, s44, 0                           // 00000015BB80: CC21005C 02005961
	v_fma_mixhi_f16 v92, v98, s44, 0                           // 00000015BB88: CC22005C 02005962
	s_waitcnt lgkmcnt(7)                                       // 00000015BB90: BF89FC77
	v_fma_mixlo_f16 v93, v99, s44, 0                           // 00000015BB94: CC21005D 02005963
	v_fma_mixhi_f16 v93, v100, s44, 0                          // 00000015BB9C: CC22005D 02005964
	v_fma_mixlo_f16 v94, v101, s44, 0                          // 00000015BBA4: CC21005E 02005965
	v_fma_mixhi_f16 v94, v102, s44, 0                          // 00000015BBAC: CC22005E 02005966
	s_waitcnt lgkmcnt(5)                                       // 00000015BBB4: BF89FC57
	v_fma_mixlo_f16 v97, v107, s44, 0                          // 00000015BBB8: CC210061 0200596B
	v_fma_mixhi_f16 v97, v108, s44, 0                          // 00000015BBC0: CC220061 0200596C
	v_fma_mixlo_f16 v98, v109, s44, 0                          // 00000015BBC8: CC210062 0200596D
	v_fma_mixhi_f16 v98, v110, s44, 0                          // 00000015BBD0: CC220062 0200596E
	ds_load_b128 v[107:110], v79 offset:25664                  // 00000015BBD8: DBFC6440 6B00004F
	s_waitcnt lgkmcnt(2)                                       // 00000015BBE0: BF89FC27
	v_fma_mixlo_f16 v99, v41, s44, 0                           // 00000015BBE4: CC210063 02005929
	v_fma_mixhi_f16 v99, v42, s44, 0                           // 00000015BBEC: CC220063 0200592A
	v_fma_mixlo_f16 v100, v43, s44, 0                          // 00000015BBF4: CC210064 0200592B
	v_fma_mixhi_f16 v100, v44, s44, 0                          // 00000015BBFC: CC220064 0200592C
	s_waitcnt lgkmcnt(1)                                       // 00000015BC04: BF89FC17
	v_fma_mixlo_f16 v101, v54, s44, 0                          // 00000015BC08: CC210065 02005936
	v_fma_mixhi_f16 v101, v55, s44, 0                          // 00000015BC10: CC220065 02005937
	ds_load_b128 v[41:44], v79 offset:25696                    // 00000015BC18: DBFC6460 2900004F
	v_fma_mixlo_f16 v102, v56, s44, 0                          // 00000015BC20: CC210066 02005938
	v_fma_mixhi_f16 v102, v57, s44, 0                          // 00000015BC28: CC220066 02005939
	ds_load_b128 v[54:57], v79 offset:25712                    // 00000015BC30: DBFC6470 3600004F
	v_fma_mixlo_f16 v69, v91, s44, 0                           // 00000015BC38: CC210045 0200595B
	v_fma_mixlo_f16 v91, v95, s44, 0                           // 00000015BC40: CC21005B 0200595F
	v_fma_mixhi_f16 v91, v96, s44, 0                           // 00000015BC48: CC22005B 02005960
	v_fma_mixlo_f16 v95, v103, s44, 0                          // 00000015BC50: CC21005F 02005967
	v_fma_mixhi_f16 v95, v104, s44, 0                          // 00000015BC58: CC22005F 02005968
	v_fma_mixlo_f16 v96, v105, s44, 0                          // 00000015BC60: CC210060 02005969
	v_fma_mixhi_f16 v96, v106, s44, 0                          // 00000015BC68: CC220060 0200596A
	v_fma_mixlo_f16 v103, v111, s44, 0                         // 00000015BC70: CC210067 0200596F
	v_fma_mixhi_f16 v103, v112, s44, 0                         // 00000015BC78: CC220067 02005970
	v_fma_mixlo_f16 v104, v113, s44, 0                         // 00000015BC80: CC210068 02005971
	v_fma_mixhi_f16 v104, v114, s44, 0                         // 00000015BC88: CC220068 02005972
	v_fma_mixlo_f16 v105, v115, s44, 0                         // 00000015BC90: CC210069 02005973
	v_fma_mixhi_f16 v105, v116, s44, 0                         // 00000015BC98: CC220069 02005974
	v_fma_mixlo_f16 v106, v117, s44, 0                         // 00000015BCA0: CC21006A 02005975
	v_fma_mixhi_f16 v106, v118, s44, 0                         // 00000015BCA8: CC22006A 02005976
	s_waitcnt lgkmcnt(2)                                       // 00000015BCB0: BF89FC27
	v_fma_mixlo_f16 v107, v107, s44, 0                         // 00000015BCB4: CC21006B 0200596B
	v_fma_mixhi_f16 v107, v108, s44, 0                         // 00000015BCBC: CC22006B 0200596C
	v_fma_mixlo_f16 v108, v109, s44, 0                         // 00000015BCC4: CC21006C 0200596D
	v_fma_mixhi_f16 v108, v110, s44, 0                         // 00000015BCCC: CC22006C 0200596E
	v_fma_mixlo_f16 v109, v119, s44, 0                         // 00000015BCD4: CC21006D 02005977
	v_fma_mixhi_f16 v109, v120, s44, 0                         // 00000015BCDC: CC22006D 02005978
	v_fma_mixlo_f16 v110, v121, s44, 0                         // 00000015BCE4: CC21006E 02005979
	v_fma_mixhi_f16 v110, v122, s44, 0                         // 00000015BCEC: CC22006E 0200597A
	s_waitcnt lgkmcnt(1)                                       // 00000015BCF4: BF89FC17
	v_fma_mixlo_f16 v111, v41, s44, 0                          // 00000015BCF8: CC21006F 02005929
	v_fma_mixhi_f16 v111, v42, s44, 0                          // 00000015BD00: CC22006F 0200592A
	v_fma_mixlo_f16 v112, v43, s44, 0                          // 00000015BD08: CC210070 0200592B
	v_fma_mixhi_f16 v112, v44, s44, 0                          // 00000015BD10: CC220070 0200592C
	s_waitcnt lgkmcnt(0)                                       // 00000015BD18: BF89FC07
	v_fma_mixlo_f16 v113, v54, s44, 0                          // 00000015BD1C: CC210071 02005936
	v_fma_mixhi_f16 v113, v55, s44, 0                          // 00000015BD24: CC220071 02005937
	v_fma_mixlo_f16 v114, v56, s44, 0                          // 00000015BD2C: CC210072 02005938
	v_fma_mixhi_f16 v114, v57, s44, 0                          // 00000015BD34: CC220072 02005939
	.long 0x7f6c3880                                           // 00000015BD3C: 7F6C3880
	v_wmma_f32_16x16x16_f16 v[33:40], v[46:53], v[63:70], v[33:40]// 00000015BD40: CC404021 1C867F2E
	v_wmma_f32_16x16x16_f16 v[25:32], v[46:53], v[91:98], v[25:32]// 00000015BD48: CC404019 1C66B72E
	v_wmma_f32_16x16x16_f16 v[17:24], v[46:53], v[99:106], v[17:24]// 00000015BD50: CC404011 1C46C72E
	v_wmma_f32_16x16x16_f16 v[9:16], v[46:53], v[107:114], v[9:16]// 00000015BD58: CC404009 1C26D72E
	.long 0x7f6839b6                                           // 00000015BD60: 7F6839B6
	.long 0x7e6839b6                                           // 00000015BD64: 7E6839B6
	.long 0x7f6639b6                                           // 00000015BD68: 7F6639B6
	.long 0x7e6639b6                                           // 00000015BD6C: 7E6639B6
	s_and_saveexec_b32 s1, s0                                  // 00000015BD70: BE812000
	s_cbranch_execz 11                                         // 00000015BD74: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29a4>
	global_load_b128 v[41:44], v[61:62], off offset:384        // 00000015BD78: DC5E0180 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015BD80: BF8903F7
	v_fma_mixlo_f16 v51, v41, s44, 0                           // 00000015BD84: CC210033 02005929
	v_fma_mixhi_f16 v51, v42, s44, 0                           // 00000015BD8C: CC220033 0200592A
	v_fma_mixlo_f16 v52, v43, s44, 0                           // 00000015BD94: CC210034 0200592B
	v_fma_mixhi_f16 v52, v44, s44, 0                           // 00000015BD9C: CC220034 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015BDA4: 8C7E017E
	.long 0x7e6c39b6                                           // 00000015BDA8: 7E6C39B6
	.long 0x7f6a39b6                                           // 00000015BDAC: 7F6A39B6
	.long 0x7e6a39b6                                           // 00000015BDB0: 7E6A39B6
	s_and_saveexec_b32 s1, s0                                  // 00000015BDB4: BE812000
	s_cbranch_execz 11                                         // 00000015BDB8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29e8>
	global_load_b128 v[41:44], v[61:62], off offset:400        // 00000015BDBC: DC5E0190 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015BDC4: BF8903F7
	v_fma_mixlo_f16 v53, v41, s44, 0                           // 00000015BDC8: CC210035 02005929
	v_fma_mixhi_f16 v53, v42, s44, 0                           // 00000015BDD0: CC220035 0200592A
	v_fma_mixlo_f16 v54, v43, s44, 0                           // 00000015BDD8: CC210036 0200592B
	v_fma_mixhi_f16 v54, v44, s44, 0                           // 00000015BDE0: CC220036 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015BDE8: 8C7E017E
	.long 0x7f743880                                           // 00000015BDEC: 7F743880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015BDF0: BF870001
	.long 0x7f7039ba                                           // 00000015BDF4: 7F7039BA
	.long 0x7e7039ba                                           // 00000015BDF8: 7E7039BA
	.long 0x7f6e39ba                                           // 00000015BDFC: 7F6E39BA
	.long 0x7e6e39ba                                           // 00000015BE00: 7E6E39BA
	s_and_saveexec_b32 s1, s0                                  // 00000015BE04: BE812000
	s_cbranch_execz 11                                         // 00000015BE08: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a38>
	global_load_b128 v[41:44], v[61:62], off offset:416        // 00000015BE0C: DC5E01A0 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015BE14: BF8903F7
	v_fma_mixlo_f16 v55, v41, s44, 0                           // 00000015BE18: CC210037 02005929
	v_fma_mixhi_f16 v55, v42, s44, 0                           // 00000015BE20: CC220037 0200592A
	v_fma_mixlo_f16 v56, v43, s44, 0                           // 00000015BE28: CC210038 0200592B
	v_fma_mixhi_f16 v56, v44, s44, 0                           // 00000015BE30: CC220038 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015BE38: 8C7E017E
	.long 0x7e7439ba                                           // 00000015BE3C: 7E7439BA
	.long 0x7f7239ba                                           // 00000015BE40: 7F7239BA
	.long 0x7e7239ba                                           // 00000015BE44: 7E7239BA
	s_and_saveexec_b32 s1, s0                                  // 00000015BE48: BE812000
	s_cbranch_execz 11                                         // 00000015BE4C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a7c>
	global_load_b128 v[41:44], v[61:62], off offset:432        // 00000015BE50: DC5E01B0 297C003D
	s_waitcnt vmcnt(0)                                         // 00000015BE58: BF8903F7
	v_fma_mixlo_f16 v57, v41, s44, 0                           // 00000015BE5C: CC210039 02005929
	v_fma_mixhi_f16 v57, v42, s44, 0                           // 00000015BE64: CC220039 0200592A
	v_fma_mixlo_f16 v58, v43, s44, 0                           // 00000015BE6C: CC21003A 0200592B
	v_fma_mixhi_f16 v58, v44, s44, 0                           // 00000015BE74: CC22003A 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015BE7C: 8C7E017E
	ds_load_b128 v[41:44], v79 offset:384                      // 00000015BE80: DBFC0180 2900004F
	ds_load_b128 v[45:48], v79 offset:400                      // 00000015BE88: DBFC0190 2D00004F
	ds_load_b128 v[67:70], v79 offset:416                      // 00000015BE90: DBFC01A0 4300004F
	ds_load_b128 v[91:94], v79 offset:432                      // 00000015BE98: DBFC01B0 5B00004F
	ds_load_b128 v[95:98], v79 offset:8832                     // 00000015BEA0: DBFC2280 5F00004F
	ds_load_b128 v[99:102], v79 offset:8848                    // 00000015BEA8: DBFC2290 6300004F
	ds_load_b128 v[103:106], v79 offset:8864                   // 00000015BEB0: DBFC22A0 6700004F
	ds_load_b128 v[107:110], v79 offset:8880                   // 00000015BEB8: DBFC22B0 6B00004F
	ds_load_b128 v[111:114], v79 offset:17312                  // 00000015BEC0: DBFC43A0 6F00004F
	ds_load_b128 v[115:118], v79 offset:17328                  // 00000015BEC8: DBFC43B0 7300004F
	ds_load_b128 v[119:122], v79 offset:25744                  // 00000015BED0: DBFC6490 7700004F
	s_waitcnt lgkmcnt(10)                                      // 00000015BED8: BF89FCA7
	v_fma_mixlo_f16 v63, v41, s44, 0                           // 00000015BEDC: CC21003F 02005929
	v_fma_mixhi_f16 v63, v42, s44, 0                           // 00000015BEE4: CC22003F 0200592A
	v_fma_mixlo_f16 v64, v43, s44, 0                           // 00000015BEEC: CC210040 0200592B
	v_fma_mixhi_f16 v64, v44, s44, 0                           // 00000015BEF4: CC220040 0200592C
	s_waitcnt lgkmcnt(9)                                       // 00000015BEFC: BF89FC97
	v_fma_mixlo_f16 v65, v45, s44, 0                           // 00000015BF00: CC210041 0200592D
	v_fma_mixhi_f16 v65, v46, s44, 0                           // 00000015BF08: CC220041 0200592E
	v_fma_mixlo_f16 v66, v47, s44, 0                           // 00000015BF10: CC210042 0200592F
	v_fma_mixhi_f16 v66, v48, s44, 0                           // 00000015BF18: CC220042 02005930
	ds_load_b128 v[41:44], v79 offset:17280                    // 00000015BF20: DBFC4380 2900004F
	ds_load_b128 v[45:48], v79 offset:17296                    // 00000015BF28: DBFC4390 2D00004F
	s_waitcnt lgkmcnt(10)                                      // 00000015BF30: BF89FCA7
	v_fma_mixlo_f16 v67, v67, s44, 0                           // 00000015BF34: CC210043 02005943
	v_fma_mixhi_f16 v67, v68, s44, 0                           // 00000015BF3C: CC220043 02005944
	v_fma_mixlo_f16 v68, v69, s44, 0                           // 00000015BF44: CC210044 02005945
	v_fma_mixhi_f16 v68, v70, s44, 0                           // 00000015BF4C: CC220044 02005946
	s_waitcnt lgkmcnt(9)                                       // 00000015BF54: BF89FC97
	v_fma_mixhi_f16 v69, v92, s44, 0                           // 00000015BF58: CC220045 0200595C
	v_fma_mixlo_f16 v70, v93, s44, 0                           // 00000015BF60: CC210046 0200595D
	v_fma_mixhi_f16 v70, v94, s44, 0                           // 00000015BF68: CC220046 0200595E
	s_waitcnt lgkmcnt(8)                                       // 00000015BF70: BF89FC87
	v_fma_mixlo_f16 v92, v97, s44, 0                           // 00000015BF74: CC21005C 02005961
	v_fma_mixhi_f16 v92, v98, s44, 0                           // 00000015BF7C: CC22005C 02005962
	s_waitcnt lgkmcnt(7)                                       // 00000015BF84: BF89FC77
	v_fma_mixlo_f16 v93, v99, s44, 0                           // 00000015BF88: CC21005D 02005963
	v_fma_mixhi_f16 v93, v100, s44, 0                          // 00000015BF90: CC22005D 02005964
	v_fma_mixlo_f16 v94, v101, s44, 0                          // 00000015BF98: CC21005E 02005965
	v_fma_mixhi_f16 v94, v102, s44, 0                          // 00000015BFA0: CC22005E 02005966
	s_waitcnt lgkmcnt(5)                                       // 00000015BFA8: BF89FC57
	v_fma_mixlo_f16 v97, v107, s44, 0                          // 00000015BFAC: CC210061 0200596B
	v_fma_mixhi_f16 v97, v108, s44, 0                          // 00000015BFB4: CC220061 0200596C
	v_fma_mixlo_f16 v98, v109, s44, 0                          // 00000015BFBC: CC210062 0200596D
	v_fma_mixhi_f16 v98, v110, s44, 0                          // 00000015BFC4: CC220062 0200596E
	ds_load_b128 v[107:110], v79 offset:25728                  // 00000015BFCC: DBFC6480 6B00004F
	s_waitcnt lgkmcnt(2)                                       // 00000015BFD4: BF89FC27
	v_fma_mixlo_f16 v99, v41, s44, 0                           // 00000015BFD8: CC210063 02005929
	v_fma_mixhi_f16 v99, v42, s44, 0                           // 00000015BFE0: CC220063 0200592A
	v_fma_mixlo_f16 v100, v43, s44, 0                          // 00000015BFE8: CC210064 0200592B
	v_fma_mixhi_f16 v100, v44, s44, 0                          // 00000015BFF0: CC220064 0200592C
	s_waitcnt lgkmcnt(1)                                       // 00000015BFF8: BF89FC17
	v_fma_mixlo_f16 v101, v45, s44, 0                          // 00000015BFFC: CC210065 0200592D
	v_fma_mixhi_f16 v101, v46, s44, 0                          // 00000015C004: CC220065 0200592E
	ds_load_b128 v[41:44], v79 offset:25760                    // 00000015C00C: DBFC64A0 2900004F
	v_fma_mixlo_f16 v102, v47, s44, 0                          // 00000015C014: CC210066 0200592F
	v_fma_mixhi_f16 v102, v48, s44, 0                          // 00000015C01C: CC220066 02005930
	ds_load_b128 v[45:48], v79 offset:25776                    // 00000015C024: DBFC64B0 2D00004F
	v_fma_mixlo_f16 v69, v91, s44, 0                           // 00000015C02C: CC210045 0200595B
	v_fma_mixlo_f16 v91, v95, s44, 0                           // 00000015C034: CC21005B 0200595F
	v_fma_mixhi_f16 v91, v96, s44, 0                           // 00000015C03C: CC22005B 02005960
	v_fma_mixlo_f16 v95, v103, s44, 0                          // 00000015C044: CC21005F 02005967
	v_fma_mixhi_f16 v95, v104, s44, 0                          // 00000015C04C: CC22005F 02005968
	v_fma_mixlo_f16 v96, v105, s44, 0                          // 00000015C054: CC210060 02005969
	v_fma_mixhi_f16 v96, v106, s44, 0                          // 00000015C05C: CC220060 0200596A
	v_fma_mixlo_f16 v103, v111, s44, 0                         // 00000015C064: CC210067 0200596F
	v_fma_mixhi_f16 v103, v112, s44, 0                         // 00000015C06C: CC220067 02005970
	v_fma_mixlo_f16 v104, v113, s44, 0                         // 00000015C074: CC210068 02005971
	v_fma_mixhi_f16 v104, v114, s44, 0                         // 00000015C07C: CC220068 02005972
	v_fma_mixlo_f16 v105, v115, s44, 0                         // 00000015C084: CC210069 02005973
	v_fma_mixhi_f16 v105, v116, s44, 0                         // 00000015C08C: CC220069 02005974
	v_fma_mixlo_f16 v106, v117, s44, 0                         // 00000015C094: CC21006A 02005975
	v_fma_mixhi_f16 v106, v118, s44, 0                         // 00000015C09C: CC22006A 02005976
	s_waitcnt lgkmcnt(2)                                       // 00000015C0A4: BF89FC27
	v_fma_mixlo_f16 v107, v107, s44, 0                         // 00000015C0A8: CC21006B 0200596B
	v_fma_mixhi_f16 v107, v108, s44, 0                         // 00000015C0B0: CC22006B 0200596C
	v_fma_mixlo_f16 v108, v109, s44, 0                         // 00000015C0B8: CC21006C 0200596D
	v_fma_mixhi_f16 v108, v110, s44, 0                         // 00000015C0C0: CC22006C 0200596E
	v_fma_mixlo_f16 v109, v119, s44, 0                         // 00000015C0C8: CC21006D 02005977
	v_fma_mixhi_f16 v109, v120, s44, 0                         // 00000015C0D0: CC22006D 02005978
	v_fma_mixlo_f16 v110, v121, s44, 0                         // 00000015C0D8: CC21006E 02005979
	v_fma_mixhi_f16 v110, v122, s44, 0                         // 00000015C0E0: CC22006E 0200597A
	s_waitcnt lgkmcnt(1)                                       // 00000015C0E8: BF89FC17
	v_fma_mixlo_f16 v111, v41, s44, 0                          // 00000015C0EC: CC21006F 02005929
	v_fma_mixhi_f16 v111, v42, s44, 0                          // 00000015C0F4: CC22006F 0200592A
	v_fma_mixlo_f16 v112, v43, s44, 0                          // 00000015C0FC: CC210070 0200592B
	v_fma_mixhi_f16 v112, v44, s44, 0                          // 00000015C104: CC220070 0200592C
	s_waitcnt lgkmcnt(0)                                       // 00000015C10C: BF89FC07
	v_fma_mixlo_f16 v113, v45, s44, 0                          // 00000015C110: CC210071 0200592D
	v_fma_mixhi_f16 v113, v46, s44, 0                          // 00000015C118: CC220071 0200592E
	v_fma_mixlo_f16 v114, v47, s44, 0                          // 00000015C120: CC210072 0200592F
	v_fma_mixhi_f16 v114, v48, s44, 0                          // 00000015C128: CC220072 02005930
	.long 0x7f583880                                           // 00000015C130: 7F583880
	v_wmma_f32_16x16x16_f16 v[33:40], v[51:58], v[63:70], v[33:40]// 00000015C134: CC404021 1C867F33
	v_wmma_f32_16x16x16_f16 v[25:32], v[51:58], v[91:98], v[25:32]// 00000015C13C: CC404019 1C66B733
	v_wmma_f32_16x16x16_f16 v[17:24], v[51:58], v[99:106], v[17:24]// 00000015C144: CC404011 1C46C733
	v_wmma_f32_16x16x16_f16 v[9:16], v[51:58], v[107:114], v[9:16]// 00000015C14C: CC404009 1C26D733
	.long 0x7f5439ac                                           // 00000015C154: 7F5439AC
	.long 0x7e5439ac                                           // 00000015C158: 7E5439AC
	.long 0x7f5239ac                                           // 00000015C15C: 7F5239AC
	.long 0x7e5239ac                                           // 00000015C160: 7E5239AC
	s_and_saveexec_b32 s1, s0                                  // 00000015C164: BE812000
	s_cbranch_execz 11                                         // 00000015C168: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d98>
	global_load_b128 v[45:48], v[61:62], off offset:448        // 00000015C16C: DC5E01C0 2D7C003D
	s_waitcnt vmcnt(0)                                         // 00000015C174: BF8903F7
	v_fma_mixlo_f16 v41, v45, s44, 0                           // 00000015C178: CC210029 0200592D
	v_fma_mixhi_f16 v41, v46, s44, 0                           // 00000015C180: CC220029 0200592E
	v_fma_mixlo_f16 v42, v47, s44, 0                           // 00000015C188: CC21002A 0200592F
	v_fma_mixhi_f16 v42, v48, s44, 0                           // 00000015C190: CC22002A 02005930
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015C198: 8C7E017E
	.long 0x7e5839ac                                           // 00000015C19C: 7E5839AC
	.long 0x7f5639ac                                           // 00000015C1A0: 7F5639AC
	.long 0x7e5639ac                                           // 00000015C1A4: 7E5639AC
	s_and_saveexec_b32 s1, s0                                  // 00000015C1A8: BE812000
	s_cbranch_execz 11                                         // 00000015C1AC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ddc>
	global_load_b128 v[43:46], v[61:62], off offset:464        // 00000015C1B0: DC5E01D0 2B7C003D
	s_waitcnt vmcnt(0)                                         // 00000015C1B8: BF8903F7
	v_fma_mixlo_f16 v43, v43, s44, 0                           // 00000015C1BC: CC21002B 0200592B
	v_fma_mixhi_f16 v43, v44, s44, 0                           // 00000015C1C4: CC22002B 0200592C
	v_fma_mixlo_f16 v44, v45, s44, 0                           // 00000015C1CC: CC21002C 0200592D
	v_fma_mixhi_f16 v44, v46, s44, 0                           // 00000015C1D4: CC22002C 0200592E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015C1DC: 8C7E017E
	.long 0x7f603880                                           // 00000015C1E0: 7F603880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015C1E4: BF870001
	.long 0x7f5c39b0                                           // 00000015C1E8: 7F5C39B0
	.long 0x7e5c39b0                                           // 00000015C1EC: 7E5C39B0
	.long 0x7f5a39b0                                           // 00000015C1F0: 7F5A39B0
	.long 0x7e5a39b0                                           // 00000015C1F4: 7E5A39B0
	s_and_saveexec_b32 s1, s0                                  // 00000015C1F8: BE812000
	s_cbranch_execz 11                                         // 00000015C1FC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e2c>
	global_load_b128 v[49:52], v[61:62], off offset:480        // 00000015C200: DC5E01E0 317C003D
	s_waitcnt vmcnt(0)                                         // 00000015C208: BF8903F7
	v_fma_mixlo_f16 v45, v49, s44, 0                           // 00000015C20C: CC21002D 02005931
	v_fma_mixhi_f16 v45, v50, s44, 0                           // 00000015C214: CC22002D 02005932
	v_fma_mixlo_f16 v46, v51, s44, 0                           // 00000015C21C: CC21002E 02005933
	v_fma_mixhi_f16 v46, v52, s44, 0                           // 00000015C224: CC22002E 02005934
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015C22C: 8C7E017E
	.long 0x7e6039b0                                           // 00000015C230: 7E6039B0
	.long 0x7f5e39b0                                           // 00000015C234: 7F5E39B0
	.long 0x7e5e39b0                                           // 00000015C238: 7E5E39B0
	s_and_saveexec_b32 s1, s0                                  // 00000015C23C: BE812000
	s_cbranch_execz 11                                         // 00000015C240: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e70>
	global_load_b128 v[47:50], v[61:62], off offset:496        // 00000015C244: DC5E01F0 2F7C003D
	s_waitcnt vmcnt(0)                                         // 00000015C24C: BF8903F7
	v_fma_mixlo_f16 v47, v47, s44, 0                           // 00000015C250: CC21002F 0200592F
	v_fma_mixhi_f16 v47, v48, s44, 0                           // 00000015C258: CC22002F 02005930
	v_fma_mixlo_f16 v48, v49, s44, 0                           // 00000015C260: CC210030 02005931
	v_fma_mixhi_f16 v48, v50, s44, 0                           // 00000015C268: CC220030 02005932
	s_or_b32 exec_lo, exec_lo, s1                              // 00000015C270: 8C7E017E
	ds_load_b128 v[49:52], v79 offset:448                      // 00000015C274: DBFC01C0 3100004F
	ds_load_b128 v[53:56], v79 offset:464                      // 00000015C27C: DBFC01D0 3500004F
	ds_load_b128 v[61:64], v79 offset:480                      // 00000015C284: DBFC01E0 3D00004F
	ds_load_b128 v[65:68], v79 offset:496                      // 00000015C28C: DBFC01F0 4100004F
	ds_load_b128 v[69:72], v79 offset:8896                     // 00000015C294: DBFC22C0 4500004F
	ds_load_b128 v[91:94], v79 offset:8912                     // 00000015C29C: DBFC22D0 5B00004F
	ds_load_b128 v[95:98], v79 offset:8928                     // 00000015C2A4: DBFC22E0 5F00004F
	ds_load_b128 v[99:102], v79 offset:8944                    // 00000015C2AC: DBFC22F0 6300004F
	ds_load_b128 v[107:110], v79 offset:25840                  // 00000015C2B4: DBFC64F0 6B00004F
	ds_load_b128 v[103:106], v79 offset:25824                  // 00000015C2BC: DBFC64E0 6700004F
	s_waitcnt lgkmcnt(9)                                       // 00000015C2C4: BF89FC97
	v_fma_mixlo_f16 v49, v49, s44, 0                           // 00000015C2C8: CC210031 02005931
	v_fma_mixhi_f16 v49, v50, s44, 0                           // 00000015C2D0: CC220031 02005932
	v_fma_mixlo_f16 v50, v51, s44, 0                           // 00000015C2D8: CC210032 02005933
	v_fma_mixhi_f16 v50, v52, s44, 0                           // 00000015C2E0: CC220032 02005934
	s_waitcnt lgkmcnt(8)                                       // 00000015C2E8: BF89FC87
	v_fma_mixlo_f16 v51, v53, s44, 0                           // 00000015C2EC: CC210033 02005935
	v_fma_mixhi_f16 v51, v54, s44, 0                           // 00000015C2F4: CC220033 02005936
	v_fma_mixlo_f16 v52, v55, s44, 0                           // 00000015C2FC: CC210034 02005937
	v_fma_mixhi_f16 v52, v56, s44, 0                           // 00000015C304: CC220034 02005938
	s_waitcnt lgkmcnt(7)                                       // 00000015C30C: BF89FC77
	v_fma_mixlo_f16 v53, v61, s44, 0                           // 00000015C310: CC210035 0200593D
	v_fma_mixhi_f16 v53, v62, s44, 0                           // 00000015C318: CC220035 0200593E
	v_fma_mixlo_f16 v54, v63, s44, 0                           // 00000015C320: CC210036 0200593F
	v_fma_mixhi_f16 v54, v64, s44, 0                           // 00000015C328: CC220036 02005940
	s_waitcnt lgkmcnt(6)                                       // 00000015C330: BF89FC67
	v_fma_mixlo_f16 v55, v65, s44, 0                           // 00000015C334: CC210037 02005941
	v_fma_mixhi_f16 v55, v66, s44, 0                           // 00000015C33C: CC220037 02005942
	v_fma_mixlo_f16 v56, v67, s44, 0                           // 00000015C344: CC210038 02005943
	v_fma_mixhi_f16 v56, v68, s44, 0                           // 00000015C34C: CC220038 02005944
	s_waitcnt lgkmcnt(5)                                       // 00000015C354: BF89FC57
	v_fma_mixlo_f16 v61, v69, s44, 0                           // 00000015C358: CC21003D 02005945
	v_fma_mixhi_f16 v61, v70, s44, 0                           // 00000015C360: CC22003D 02005946
	v_fma_mixlo_f16 v62, v71, s44, 0                           // 00000015C368: CC21003E 02005947
	v_fma_mixhi_f16 v62, v72, s44, 0                           // 00000015C370: CC22003E 02005948
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[49:56], v[33:40]// 00000015C378: CC404021 1C866329
	ds_load_b128 v[50:53], v79 offset:17344                    // 00000015C380: DBFC43C0 3200004F
	s_waitcnt lgkmcnt(5)                                       // 00000015C388: BF89FC57
	v_fma_mixlo_f16 v63, v91, s44, 0                           // 00000015C38C: CC21003F 0200595B
	ds_load_b128 v[54:57], v79 offset:17360                    // 00000015C394: DBFC43D0 3600004F
	ds_load_b128 v[69:72], v79 offset:17376                    // 00000015C39C: DBFC43E0 4500004F
	v_fma_mixhi_f16 v63, v92, s44, 0                           // 00000015C3A4: CC22003F 0200595C
	v_fma_mixlo_f16 v64, v93, s44, 0                           // 00000015C3AC: CC210040 0200595D
	v_fma_mixhi_f16 v64, v94, s44, 0                           // 00000015C3B4: CC220040 0200595E
	s_waitcnt lgkmcnt(6)                                       // 00000015C3BC: BF89FC67
	v_fma_mixlo_f16 v65, v95, s44, 0                           // 00000015C3C0: CC210041 0200595F
	v_fma_mixhi_f16 v65, v96, s44, 0                           // 00000015C3C8: CC220041 02005960
	v_fma_mixlo_f16 v66, v97, s44, 0                           // 00000015C3D0: CC210042 02005961
	v_fma_mixhi_f16 v66, v98, s44, 0                           // 00000015C3D8: CC220042 02005962
	s_waitcnt lgkmcnt(5)                                       // 00000015C3E0: BF89FC57
	v_fma_mixlo_f16 v67, v99, s44, 0                           // 00000015C3E4: CC210043 02005963
	ds_load_b128 v[91:94], v79 offset:17392                    // 00000015C3EC: DBFC43F0 5B00004F
	ds_load_b128 v[95:98], v79 offset:25792                    // 00000015C3F4: DBFC64C0 5F00004F
	v_fma_mixhi_f16 v67, v100, s44, 0                          // 00000015C3FC: CC220043 02005964
	v_fma_mixlo_f16 v68, v101, s44, 0                          // 00000015C404: CC210044 02005965
	v_fma_mixhi_f16 v68, v102, s44, 0                          // 00000015C40C: CC220044 02005966
	ds_load_b128 v[99:102], v79 offset:25808                   // 00000015C414: DBFC64D0 6300004F
	.long 0x7e623880                                           // 00000015C41C: 7E623880
	s_waitcnt lgkmcnt(5)                                       // 00000015C420: BF89FC57
	v_fma_mixlo_f16 v50, v50, s44, 0                           // 00000015C424: CC210032 02005932
	v_fma_mixhi_f16 v50, v51, s44, 0                           // 00000015C42C: CC220032 02005933
	v_fma_mixlo_f16 v51, v52, s44, 0                           // 00000015C434: CC210033 02005934
	v_fma_mixhi_f16 v51, v53, s44, 0                           // 00000015C43C: CC220033 02005935
	s_waitcnt lgkmcnt(4)                                       // 00000015C444: BF89FC47
	v_fma_mixlo_f16 v52, v54, s44, 0                           // 00000015C448: CC210034 02005936
	v_fma_mixhi_f16 v52, v55, s44, 0                           // 00000015C450: CC220034 02005937
	v_fma_mixlo_f16 v53, v56, s44, 0                           // 00000015C458: CC210035 02005938
	v_fma_mixhi_f16 v53, v57, s44, 0                           // 00000015C460: CC220035 02005939
	s_waitcnt lgkmcnt(3)                                       // 00000015C468: BF89FC37
	v_fma_mixlo_f16 v54, v69, s44, 0                           // 00000015C46C: CC210036 02005945
	v_fma_mixhi_f16 v54, v70, s44, 0                           // 00000015C474: CC220036 02005946
	v_fma_mixlo_f16 v55, v71, s44, 0                           // 00000015C47C: CC210037 02005947
	v_fma_mixhi_f16 v55, v72, s44, 0                           // 00000015C484: CC220037 02005948
	s_waitcnt lgkmcnt(2)                                       // 00000015C48C: BF89FC27
	v_fma_mixlo_f16 v56, v91, s44, 0                           // 00000015C490: CC210038 0200595B
	v_fma_mixhi_f16 v56, v92, s44, 0                           // 00000015C498: CC220038 0200595C
	v_fma_mixlo_f16 v57, v93, s44, 0                           // 00000015C4A0: CC210039 0200595D
	v_fma_mixhi_f16 v57, v94, s44, 0                           // 00000015C4A8: CC220039 0200595E
	s_waitcnt lgkmcnt(1)                                       // 00000015C4B0: BF89FC17
	v_fma_mixlo_f16 v92, v95, s44, 0                           // 00000015C4B4: CC21005C 0200595F
	v_fma_mixhi_f16 v92, v96, s44, 0                           // 00000015C4BC: CC22005C 02005960
	v_fma_mixlo_f16 v93, v97, s44, 0                           // 00000015C4C4: CC21005D 02005961
	v_fma_mixhi_f16 v93, v98, s44, 0                           // 00000015C4CC: CC22005D 02005962
	s_waitcnt lgkmcnt(0)                                       // 00000015C4D4: BF89FC07
	v_fma_mixlo_f16 v94, v99, s44, 0                           // 00000015C4D8: CC21005E 02005963
	v_fma_mixhi_f16 v94, v100, s44, 0                          // 00000015C4E0: CC22005E 02005964
	v_fma_mixlo_f16 v95, v101, s44, 0                          // 00000015C4E8: CC21005F 02005965
	v_fma_mixhi_f16 v95, v102, s44, 0                          // 00000015C4F0: CC22005F 02005966
	v_fma_mixlo_f16 v96, v103, s44, 0                          // 00000015C4F8: CC210060 02005967
	v_fma_mixhi_f16 v96, v104, s44, 0                          // 00000015C500: CC220060 02005968
	v_fma_mixlo_f16 v97, v105, s44, 0                          // 00000015C508: CC210061 02005969
	v_fma_mixhi_f16 v97, v106, s44, 0                          // 00000015C510: CC220061 0200596A
	v_fma_mixlo_f16 v98, v107, s44, 0                          // 00000015C518: CC210062 0200596B
	v_fma_mixhi_f16 v98, v108, s44, 0                          // 00000015C520: CC220062 0200596C
	v_fma_mixlo_f16 v99, v109, s44, 0                          // 00000015C528: CC210063 0200596D
	v_fma_mixhi_f16 v99, v110, s44, 0                          // 00000015C530: CC220063 0200596E
	v_add_nc_u32_e32 v91, s4, v80                              // 00000015C538: 4AB6A004
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[61:68], v[25:32]// 00000015C53C: CC404019 1C667B29
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[50:57], v[17:24]// 00000015C544: CC404011 1C466529
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000015C54C: BF870214
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[92:99], v[9:16]// 00000015C550: CC404009 1C26B929
	.long 0xd4440001                                           // 00000015C558: D4440001
	v_cndmask_b32_e32 v1, s41, v91, vcc_lo                     // 00000015C55C: 0202B629
	.long 0x7e523931                                           // 00000015C560: 7E523931
	s_and_saveexec_b32 s5, s1                                  // 00000015C564: BE852001
	s_cbranch_execz 17                                         // 00000015C568: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x31b0>
	v_mad_u64_u32 v[41:42], null, v91, 48, s[2:3]              // 00000015C56C: D6FE7C29 0009615B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015C574: BF870091
	.long 0xd73c0029                                           // 00000015C578: D73C0029
	v_cndmask_b32_e32 v1, 9, v41, vcc_lo                       // 00000015C57C: 02025289
	.long 0xd7000429                                           // 00000015C580: D7000429
	v_cndmask_b32_e32 v1, v86, v41, vcc_lo                     // 00000015C584: 02025356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015C588: BF8700C1
	v_add_co_ci_u32_e64 v42, null, v87, v42, s4                // 00000015C58C: D5207C2A 00125557
	global_load_b32 v41, v[41:42], off                         // 00000015C594: DC520000 297C0029
	s_waitcnt vmcnt(0)                                         // 00000015C59C: BF8903F7
	v_fmac_f32_e32 v41, 0xbb800000, v33                        // 00000015C5A0: 565242FF BB800000
	v_fma_mixlo_f16 v41, v41, s44, 0                           // 00000015C5A8: CC210029 02005929
	s_or_b32 exec_lo, exec_lo, s5                              // 00000015C5B0: 8C7E057E
	v_add_nc_u32_e32 v92, 2, v91                               // 00000015C5B4: 4AB8B682
	ds_store_b16 v88, v41                                      // 00000015C5B8: D87C0000 00002958
	.long 0xd4440004                                           // 00000015C5C0: D4440004
	v_cndmask_b32_e32 v1, s41, v92, vcc_lo                     // 00000015C5C4: 0202B829
	s_and_saveexec_b32 s6, s4                                  // 00000015C5C8: BE862004
	s_cbranch_execz 17                                         // 00000015C5CC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3214>
	v_mad_u64_u32 v[41:42], null, v92, 48, s[2:3]              // 00000015C5D0: D6FE7C29 0009615C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015C5D8: BF870091
	.long 0xd73c0029                                           // 00000015C5DC: D73C0029
	v_cndmask_b32_e32 v1, 9, v41, vcc_lo                       // 00000015C5E0: 02025289
	.long 0xd7000529                                           // 00000015C5E4: D7000529
	v_cndmask_b32_e32 v1, v86, v41, vcc_lo                     // 00000015C5E8: 02025356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015C5EC: BF8700C1
	v_add_co_ci_u32_e64 v42, null, v87, v42, s5                // 00000015C5F0: D5207C2A 00165557
	global_load_b32 v33, v[41:42], off                         // 00000015C5F8: DC520000 217C0029
	s_waitcnt vmcnt(0)                                         // 00000015C600: BF8903F7
	v_fmac_f32_e32 v33, 0xbb800000, v34                        // 00000015C604: 564244FF BB800000
	v_fma_mixlo_f16 v49, v33, s44, 0                           // 00000015C60C: CC210031 02005921
	s_or_b32 exec_lo, exec_lo, s6                              // 00000015C614: 8C7E067E
	v_add_nc_u32_e32 v93, 4, v91                               // 00000015C618: 4ABAB684
	.long 0x7e423880                                           // 00000015C61C: 7E423880
	ds_store_b16 v88, v49 offset:4                             // 00000015C620: D87C0004 00003158
	.long 0xd4440005                                           // 00000015C628: D4440005
	v_cndmask_b32_e32 v1, s41, v93, vcc_lo                     // 00000015C62C: 0202BA29
	.long 0x7f423921                                           // 00000015C630: 7F423921
	s_and_saveexec_b32 s7, s5                                  // 00000015C634: BE872005
	s_cbranch_execz 17                                         // 00000015C638: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3280>
	v_mad_u64_u32 v[41:42], null, v93, 48, s[2:3]              // 00000015C63C: D6FE7C29 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015C644: BF870091
	.long 0xd73c0029                                           // 00000015C648: D73C0029
	v_cndmask_b32_e32 v1, 9, v41, vcc_lo                       // 00000015C64C: 02025289
	.long 0xd7000629                                           // 00000015C650: D7000629
	v_cndmask_b32_e32 v1, v86, v41, vcc_lo                     // 00000015C654: 02025356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015C658: BF8700C1
	v_add_co_ci_u32_e64 v42, null, v87, v42, s6                // 00000015C65C: D5207C2A 001A5557
	global_load_b32 v34, v[41:42], off                         // 00000015C664: DC520000 227C0029
	s_waitcnt vmcnt(0)                                         // 00000015C66C: BF8903F7
	v_fmac_f32_e32 v34, 0xbb800000, v35                        // 00000015C670: 564446FF BB800000
	v_fma_mixhi_f16 v33, v34, s44, 0                           // 00000015C678: CC220021 02005922
	s_or_b32 exec_lo, exec_lo, s7                              // 00000015C680: 8C7E077E
	v_add_nc_u32_e32 v94, 6, v91                               // 00000015C684: 4ABCB686
	ds_store_b16_d16_hi v88, v33 offset:8                      // 00000015C688: DA840008 00002158
	.long 0xd4440006                                           // 00000015C690: D4440006
	v_cndmask_b32_e32 v1, s41, v94, vcc_lo                     // 00000015C694: 0202BC29
	s_and_saveexec_b32 s8, s6                                  // 00000015C698: BE882006
	s_cbranch_execz 17                                         // 00000015C69C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x32e4>
	v_mad_u64_u32 v[33:34], null, v94, 48, s[2:3]              // 00000015C6A0: D6FE7C21 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015C6A8: BF870091
	.long 0xd73c0021                                           // 00000015C6AC: D73C0021
	v_cndmask_b32_e32 v1, 9, v33, vcc_lo                       // 00000015C6B0: 02024289
	.long 0xd7000721                                           // 00000015C6B4: D7000721
	v_cndmask_b32_e32 v1, v86, v33, vcc_lo                     // 00000015C6B8: 02024356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015C6BC: BF8700C1
	v_add_co_ci_u32_e64 v34, null, v87, v34, s7                // 00000015C6C0: D5207C22 001E4557
	global_load_b32 v33, v[33:34], off                         // 00000015C6C8: DC520000 217C0021
	s_waitcnt vmcnt(0)                                         // 00000015C6D0: BF8903F7
	v_fmac_f32_e32 v33, 0xbb800000, v36                        // 00000015C6D4: 564248FF BB800000
	v_fma_mixlo_f16 v33, v33, s44, 0                           // 00000015C6DC: CC210021 02005921
	s_or_b32 exec_lo, exec_lo, s8                              // 00000015C6E4: 8C7E087E
	v_add_nc_u32_e32 v95, 8, v91                               // 00000015C6E8: 4ABEB688
	.long 0x7f423880                                           // 00000015C6EC: 7F423880
	ds_store_b16 v88, v33 offset:12                            // 00000015C6F0: D87C000C 00002158
	.long 0xd4440007                                           // 00000015C6F8: D4440007
	v_cndmask_b32_e32 v1, s41, v95, vcc_lo                     // 00000015C6FC: 0202BE29
	.long 0x7e4439a1                                           // 00000015C700: 7E4439A1
	s_and_saveexec_b32 s9, s7                                  // 00000015C704: BE892007
	s_cbranch_execz 17                                         // 00000015C708: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3350>
	v_mad_u64_u32 v[34:35], null, v95, 48, s[2:3]              // 00000015C70C: D6FE7C22 0009615F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015C714: BF870091
	.long 0xd73c0022                                           // 00000015C718: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000015C71C: 02024489
	.long 0xd7000822                                           // 00000015C720: D7000822
	v_cndmask_b32_e32 v1, v86, v34, vcc_lo                     // 00000015C724: 02024556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015C728: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v87, v35, s8                // 00000015C72C: D5207C23 00224757
	global_load_b32 v34, v[34:35], off                         // 00000015C734: DC520000 227C0022
	s_waitcnt vmcnt(0)                                         // 00000015C73C: BF8903F7
	v_fmac_f32_e32 v34, 0xbb800000, v37                        // 00000015C740: 56444AFF BB800000
	v_fma_mixlo_f16 v34, v34, s44, 0                           // 00000015C748: CC210022 02005922
	s_or_b32 exec_lo, exec_lo, s9                              // 00000015C750: 8C7E097E
	v_add_nc_u32_e32 v96, 10, v91                              // 00000015C754: 4AC0B68A
	ds_store_b16 v88, v34 offset:16                            // 00000015C758: D87C0010 00002258
	.long 0xd4440008                                           // 00000015C760: D4440008
	v_cndmask_b32_e32 v1, s41, v96, vcc_lo                     // 00000015C764: 0202C029
	s_and_saveexec_b32 s10, s8                                 // 00000015C768: BE8A2008
	s_cbranch_execz 17                                         // 00000015C76C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33b4>
	v_mad_u64_u32 v[33:34], null, v96, 48, s[2:3]              // 00000015C770: D6FE7C21 00096160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015C778: BF870091
	.long 0xd73c0021                                           // 00000015C77C: D73C0021
	v_cndmask_b32_e32 v1, 9, v33, vcc_lo                       // 00000015C780: 02024289
	.long 0xd7000921                                           // 00000015C784: D7000921
	v_cndmask_b32_e32 v1, v86, v33, vcc_lo                     // 00000015C788: 02024356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015C78C: BF8700C1
	v_add_co_ci_u32_e64 v34, null, v87, v34, s9                // 00000015C790: D5207C22 00264557
	global_load_b32 v33, v[33:34], off                         // 00000015C798: DC520000 217C0021
	s_waitcnt vmcnt(0)                                         // 00000015C7A0: BF8903F7
	v_fmac_f32_e32 v33, 0xbb800000, v38                        // 00000015C7A4: 56424CFF BB800000
	v_fma_mixhi_f16 v33, v33, s44, 0                           // 00000015C7AC: CC220021 02005921
	s_or_b32 exec_lo, exec_lo, s10                             // 00000015C7B4: 8C7E0A7E
	v_add_nc_u32_e32 v97, 12, v91                              // 00000015C7B8: 4AC2B68C
	.long 0x7e423880                                           // 00000015C7BC: 7E423880
	ds_store_b16_d16_hi v88, v33 offset:20                     // 00000015C7C0: DA840014 00002158
	.long 0xd4440009                                           // 00000015C7C8: D4440009
	v_cndmask_b32_e32 v1, s41, v97, vcc_lo                     // 00000015C7CC: 0202C229
	.long 0x7e443921                                           // 00000015C7D0: 7E443921
	s_and_saveexec_b32 s11, s9                                 // 00000015C7D4: BE8B2009
	s_cbranch_execz 17                                         // 00000015C7D8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3420>
	v_mad_u64_u32 v[34:35], null, v97, 48, s[2:3]              // 00000015C7DC: D6FE7C22 00096161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015C7E4: BF870091
	.long 0xd73c0022                                           // 00000015C7E8: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000015C7EC: 02024489
	.long 0xd7000a22                                           // 00000015C7F0: D7000A22
	v_cndmask_b32_e32 v1, v86, v34, vcc_lo                     // 00000015C7F4: 02024556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015C7F8: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v87, v35, s10               // 00000015C7FC: D5207C23 002A4757
	global_load_b32 v34, v[34:35], off                         // 00000015C804: DC520000 227C0022
	s_waitcnt vmcnt(0)                                         // 00000015C80C: BF8903F7
	v_fmac_f32_e32 v34, 0xbb800000, v39                        // 00000015C810: 56444EFF BB800000
	v_fma_mixlo_f16 v34, v34, s44, 0                           // 00000015C818: CC210022 02005922
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015C820: 8C7E0B7E
	v_add_nc_u32_e32 v98, 14, v91                              // 00000015C824: 4AC4B68E
	ds_store_b16 v88, v34 offset:24                            // 00000015C828: D87C0018 00002258
	.long 0xd444000a                                           // 00000015C830: D444000A
	v_cndmask_b32_e32 v1, s41, v98, vcc_lo                     // 00000015C834: 0202C429
	s_and_saveexec_b32 s14, s10                                // 00000015C838: BE8E200A
	s_cbranch_execz 17                                         // 00000015C83C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3484>
	v_mad_u64_u32 v[33:34], null, v98, 48, s[2:3]              // 00000015C840: D6FE7C21 00096162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015C848: BF870091
	.long 0xd73c0021                                           // 00000015C84C: D73C0021
	v_cndmask_b32_e32 v1, 9, v33, vcc_lo                       // 00000015C850: 02024289
	.long 0xd7000b21                                           // 00000015C854: D7000B21
	v_cndmask_b32_e32 v1, v86, v33, vcc_lo                     // 00000015C858: 02024356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015C85C: BF8700C1
	v_add_co_ci_u32_e64 v34, null, v87, v34, s11               // 00000015C860: D5207C22 002E4557
	global_load_b32 v33, v[33:34], off                         // 00000015C868: DC520000 217C0021
	s_waitcnt vmcnt(0)                                         // 00000015C870: BF8903F7
	v_fmac_f32_e32 v33, 0xbb800000, v40                        // 00000015C874: 564250FF BB800000
	v_fma_mixlo_f16 v33, v33, s44, 0                           // 00000015C87C: CC210021 02005921
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015C884: 8C7E0E7E
	.long 0x7f423880                                           // 00000015C888: 7F423880
	ds_store_b16 v88, v33 offset:28                            // 00000015C88C: D87C001C 00002158
	.long 0x7e4439a1                                           // 00000015C894: 7E4439A1
	s_and_saveexec_b32 s14, s1                                 // 00000015C898: BE8E2001
	s_cbranch_execz 17                                         // 00000015C89C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x34e4>
	v_mad_u64_u32 v[34:35], null, v91, 48, s[2:3]              // 00000015C8A0: D6FE7C22 0009615B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015C8A8: BF870091
	.long 0xd73c0022                                           // 00000015C8AC: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000015C8B0: 02024489
	.long 0xd7000b22                                           // 00000015C8B4: D7000B22
	v_cndmask_b32_e32 v1, v86, v34, vcc_lo                     // 00000015C8B8: 02024556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015C8BC: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v87, v35, s11               // 00000015C8C0: D5207C23 002E4757
	global_load_b32 v34, v[34:35], off offset:64               // 00000015C8C8: DC520040 227C0022
	s_waitcnt vmcnt(0)                                         // 00000015C8D0: BF8903F7
	v_fmac_f32_e32 v34, 0xbb800000, v25                        // 00000015C8D4: 564432FF BB800000
	v_fma_mixlo_f16 v34, v34, s44, 0                           // 00000015C8DC: CC210022 02005922
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015C8E4: 8C7E0E7E
	ds_store_b16 v88, v34 offset:2560                          // 00000015C8E8: D87C0A00 00002258
	s_and_saveexec_b32 s14, s4                                 // 00000015C8F0: BE8E2004
	s_cbranch_execz 17                                         // 00000015C8F4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x353c>
	v_mad_u64_u32 v[33:34], null, v92, 48, s[2:3]              // 00000015C8F8: D6FE7C21 0009615C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015C900: BF870091
	.long 0xd73c0021                                           // 00000015C904: D73C0021
	v_cndmask_b32_e32 v1, 9, v33, vcc_lo                       // 00000015C908: 02024289
	.long 0xd7000b21                                           // 00000015C90C: D7000B21
	v_cndmask_b32_e32 v1, v86, v33, vcc_lo                     // 00000015C910: 02024356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015C914: BF8700C1
	v_add_co_ci_u32_e64 v34, null, v87, v34, s11               // 00000015C918: D5207C22 002E4557
	global_load_b32 v25, v[33:34], off offset:64               // 00000015C920: DC520040 197C0021
	s_waitcnt vmcnt(0)                                         // 00000015C928: BF8903F7
	v_fmac_f32_e32 v25, 0xbb800000, v26                        // 00000015C92C: 563234FF BB800000
	v_fma_mixhi_f16 v33, v25, s44, 0                           // 00000015C934: CC220021 02005919
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015C93C: 8C7E0E7E
	.long 0x7e323880                                           // 00000015C940: 7E323880
	ds_store_b16_d16_hi v88, v33 offset:2564                   // 00000015C944: DA840A04 00002158
	.long 0x7f323919                                           // 00000015C94C: 7F323919
	s_and_saveexec_b32 s14, s5                                 // 00000015C950: BE8E2005
	s_cbranch_execz 17                                         // 00000015C954: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x359c>
	v_mad_u64_u32 v[33:34], null, v93, 48, s[2:3]              // 00000015C958: D6FE7C21 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015C960: BF870091
	.long 0xd73c0021                                           // 00000015C964: D73C0021
	v_cndmask_b32_e32 v1, 9, v33, vcc_lo                       // 00000015C968: 02024289
	.long 0xd7000b21                                           // 00000015C96C: D7000B21
	v_cndmask_b32_e32 v1, v86, v33, vcc_lo                     // 00000015C970: 02024356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015C974: BF8700C1
	v_add_co_ci_u32_e64 v34, null, v87, v34, s11               // 00000015C978: D5207C22 002E4557
	global_load_b32 v26, v[33:34], off offset:64               // 00000015C980: DC520040 1A7C0021
	s_waitcnt vmcnt(0)                                         // 00000015C988: BF8903F7
	v_fmac_f32_e32 v26, 0xbb800000, v27                        // 00000015C98C: 563436FF BB800000
	v_fma_mixhi_f16 v25, v26, s44, 0                           // 00000015C994: CC220019 0200591A
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015C99C: 8C7E0E7E
	ds_store_b16_d16_hi v88, v25 offset:2568                   // 00000015C9A0: DA840A08 00001958
	s_and_saveexec_b32 s14, s6                                 // 00000015C9A8: BE8E2006
	s_cbranch_execz 17                                         // 00000015C9AC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x35f4>
	v_mad_u64_u32 v[25:26], null, v94, 48, s[2:3]              // 00000015C9B0: D6FE7C19 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015C9B8: BF870091
	.long 0xd73c0019                                           // 00000015C9BC: D73C0019
	v_cndmask_b32_e32 v1, 9, v25, vcc_lo                       // 00000015C9C0: 02023289
	.long 0xd7000b19                                           // 00000015C9C4: D7000B19
	v_cndmask_b32_e32 v1, v86, v25, vcc_lo                     // 00000015C9C8: 02023356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015C9CC: BF8700C1
	v_add_co_ci_u32_e64 v26, null, v87, v26, s11               // 00000015C9D0: D5207C1A 002E3557
	global_load_b32 v25, v[25:26], off offset:64               // 00000015C9D8: DC520040 197C0019
	s_waitcnt vmcnt(0)                                         // 00000015C9E0: BF8903F7
	v_fmac_f32_e32 v25, 0xbb800000, v28                        // 00000015C9E4: 563238FF BB800000
	v_fma_mixlo_f16 v25, v25, s44, 0                           // 00000015C9EC: CC210019 02005919
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015C9F4: 8C7E0E7E
	.long 0x7f323880                                           // 00000015C9F8: 7F323880
	ds_store_b16 v88, v25 offset:2572                          // 00000015C9FC: D87C0A0C 00001958
	.long 0x7e343999                                           // 00000015CA04: 7E343999
	s_and_saveexec_b32 s14, s7                                 // 00000015CA08: BE8E2007
	s_cbranch_execz 17                                         // 00000015CA0C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3654>
	v_mad_u64_u32 v[26:27], null, v95, 48, s[2:3]              // 00000015CA10: D6FE7C1A 0009615F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CA18: BF870091
	.long 0xd73c001a                                           // 00000015CA1C: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000015CA20: 02023489
	.long 0xd7000b1a                                           // 00000015CA24: D7000B1A
	v_cndmask_b32_e32 v1, v86, v26, vcc_lo                     // 00000015CA28: 02023556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CA2C: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v87, v27, s11               // 00000015CA30: D5207C1B 002E3757
	global_load_b32 v26, v[26:27], off offset:64               // 00000015CA38: DC520040 1A7C001A
	s_waitcnt vmcnt(0)                                         // 00000015CA40: BF8903F7
	v_fmac_f32_e32 v26, 0xbb800000, v29                        // 00000015CA44: 56343AFF BB800000
	v_fma_mixlo_f16 v26, v26, s44, 0                           // 00000015CA4C: CC21001A 0200591A
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CA54: 8C7E0E7E
	ds_store_b16 v88, v26 offset:2576                          // 00000015CA58: D87C0A10 00001A58
	s_and_saveexec_b32 s14, s8                                 // 00000015CA60: BE8E2008
	s_cbranch_execz 17                                         // 00000015CA64: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x36ac>
	v_mad_u64_u32 v[25:26], null, v96, 48, s[2:3]              // 00000015CA68: D6FE7C19 00096160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CA70: BF870091
	.long 0xd73c0019                                           // 00000015CA74: D73C0019
	v_cndmask_b32_e32 v1, 9, v25, vcc_lo                       // 00000015CA78: 02023289
	.long 0xd7000b19                                           // 00000015CA7C: D7000B19
	v_cndmask_b32_e32 v1, v86, v25, vcc_lo                     // 00000015CA80: 02023356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CA84: BF8700C1
	v_add_co_ci_u32_e64 v26, null, v87, v26, s11               // 00000015CA88: D5207C1A 002E3557
	global_load_b32 v25, v[25:26], off offset:64               // 00000015CA90: DC520040 197C0019
	s_waitcnt vmcnt(0)                                         // 00000015CA98: BF8903F7
	v_fmac_f32_e32 v25, 0xbb800000, v30                        // 00000015CA9C: 56323CFF BB800000
	v_fma_mixhi_f16 v25, v25, s44, 0                           // 00000015CAA4: CC220019 02005919
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CAAC: 8C7E0E7E
	.long 0x7e323880                                           // 00000015CAB0: 7E323880
	ds_store_b16_d16_hi v88, v25 offset:2580                   // 00000015CAB4: DA840A14 00001958
	.long 0x7e343919                                           // 00000015CABC: 7E343919
	s_and_saveexec_b32 s14, s9                                 // 00000015CAC0: BE8E2009
	s_cbranch_execz 17                                         // 00000015CAC4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x370c>
	v_mad_u64_u32 v[26:27], null, v97, 48, s[2:3]              // 00000015CAC8: D6FE7C1A 00096161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CAD0: BF870091
	.long 0xd73c001a                                           // 00000015CAD4: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000015CAD8: 02023489
	.long 0xd7000b1a                                           // 00000015CADC: D7000B1A
	v_cndmask_b32_e32 v1, v86, v26, vcc_lo                     // 00000015CAE0: 02023556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CAE4: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v87, v27, s11               // 00000015CAE8: D5207C1B 002E3757
	global_load_b32 v26, v[26:27], off offset:64               // 00000015CAF0: DC520040 1A7C001A
	s_waitcnt vmcnt(0)                                         // 00000015CAF8: BF8903F7
	v_fmac_f32_e32 v26, 0xbb800000, v31                        // 00000015CAFC: 56343EFF BB800000
	v_fma_mixlo_f16 v26, v26, s44, 0                           // 00000015CB04: CC21001A 0200591A
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CB0C: 8C7E0E7E
	ds_store_b16 v88, v26 offset:2584                          // 00000015CB10: D87C0A18 00001A58
	s_and_saveexec_b32 s14, s10                                // 00000015CB18: BE8E200A
	s_cbranch_execz 17                                         // 00000015CB1C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3764>
	v_mad_u64_u32 v[25:26], null, v98, 48, s[2:3]              // 00000015CB20: D6FE7C19 00096162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CB28: BF870091
	.long 0xd73c0019                                           // 00000015CB2C: D73C0019
	v_cndmask_b32_e32 v1, 9, v25, vcc_lo                       // 00000015CB30: 02023289
	.long 0xd7000b19                                           // 00000015CB34: D7000B19
	v_cndmask_b32_e32 v1, v86, v25, vcc_lo                     // 00000015CB38: 02023356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CB3C: BF8700C1
	v_add_co_ci_u32_e64 v26, null, v87, v26, s11               // 00000015CB40: D5207C1A 002E3557
	global_load_b32 v25, v[25:26], off offset:64               // 00000015CB48: DC520040 197C0019
	s_waitcnt vmcnt(0)                                         // 00000015CB50: BF8903F7
	v_fmac_f32_e32 v25, 0xbb800000, v32                        // 00000015CB54: 563240FF BB800000
	v_fma_mixlo_f16 v25, v25, s44, 0                           // 00000015CB5C: CC210019 02005919
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CB64: 8C7E0E7E
	.long 0x7f323880                                           // 00000015CB68: 7F323880
	ds_store_b16 v88, v25 offset:2588                          // 00000015CB6C: D87C0A1C 00001958
	.long 0x7e343999                                           // 00000015CB74: 7E343999
	s_and_saveexec_b32 s14, s1                                 // 00000015CB78: BE8E2001
	s_cbranch_execz 17                                         // 00000015CB7C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x37c4>
	v_mad_u64_u32 v[26:27], null, v91, 48, s[2:3]              // 00000015CB80: D6FE7C1A 0009615B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CB88: BF870091
	.long 0xd73c001a                                           // 00000015CB8C: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000015CB90: 02023489
	.long 0xd7000b1a                                           // 00000015CB94: D7000B1A
	v_cndmask_b32_e32 v1, v86, v26, vcc_lo                     // 00000015CB98: 02023556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CB9C: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v87, v27, s11               // 00000015CBA0: D5207C1B 002E3757
	global_load_b32 v26, v[26:27], off offset:128              // 00000015CBA8: DC520080 1A7C001A
	s_waitcnt vmcnt(0)                                         // 00000015CBB0: BF8903F7
	v_fmac_f32_e32 v26, 0xbb800000, v17                        // 00000015CBB4: 563422FF BB800000
	v_fma_mixlo_f16 v26, v26, s44, 0                           // 00000015CBBC: CC21001A 0200591A
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CBC4: 8C7E0E7E
	ds_store_b16 v88, v26 offset:5120                          // 00000015CBC8: D87C1400 00001A58
	s_and_saveexec_b32 s14, s4                                 // 00000015CBD0: BE8E2004
	s_cbranch_execz 17                                         // 00000015CBD4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x381c>
	v_mad_u64_u32 v[25:26], null, v92, 48, s[2:3]              // 00000015CBD8: D6FE7C19 0009615C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CBE0: BF870091
	.long 0xd73c0019                                           // 00000015CBE4: D73C0019
	v_cndmask_b32_e32 v1, 9, v25, vcc_lo                       // 00000015CBE8: 02023289
	.long 0xd7000b19                                           // 00000015CBEC: D7000B19
	v_cndmask_b32_e32 v1, v86, v25, vcc_lo                     // 00000015CBF0: 02023356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CBF4: BF8700C1
	v_add_co_ci_u32_e64 v26, null, v87, v26, s11               // 00000015CBF8: D5207C1A 002E3557
	global_load_b32 v17, v[25:26], off offset:128              // 00000015CC00: DC520080 117C0019
	s_waitcnt vmcnt(0)                                         // 00000015CC08: BF8903F7
	v_fmac_f32_e32 v17, 0xbb800000, v18                        // 00000015CC0C: 562224FF BB800000
	v_fma_mixhi_f16 v25, v17, s44, 0                           // 00000015CC14: CC220019 02005911
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CC1C: 8C7E0E7E
	.long 0x7e223880                                           // 00000015CC20: 7E223880
	ds_store_b16_d16_hi v88, v25 offset:5124                   // 00000015CC24: DA841404 00001958
	.long 0x7f223911                                           // 00000015CC2C: 7F223911
	s_and_saveexec_b32 s14, s5                                 // 00000015CC30: BE8E2005
	s_cbranch_execz 17                                         // 00000015CC34: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x387c>
	v_mad_u64_u32 v[25:26], null, v93, 48, s[2:3]              // 00000015CC38: D6FE7C19 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CC40: BF870091
	.long 0xd73c0019                                           // 00000015CC44: D73C0019
	v_cndmask_b32_e32 v1, 9, v25, vcc_lo                       // 00000015CC48: 02023289
	.long 0xd7000b19                                           // 00000015CC4C: D7000B19
	v_cndmask_b32_e32 v1, v86, v25, vcc_lo                     // 00000015CC50: 02023356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CC54: BF8700C1
	v_add_co_ci_u32_e64 v26, null, v87, v26, s11               // 00000015CC58: D5207C1A 002E3557
	global_load_b32 v18, v[25:26], off offset:128              // 00000015CC60: DC520080 127C0019
	s_waitcnt vmcnt(0)                                         // 00000015CC68: BF8903F7
	v_fmac_f32_e32 v18, 0xbb800000, v19                        // 00000015CC6C: 562426FF BB800000
	v_fma_mixhi_f16 v17, v18, s44, 0                           // 00000015CC74: CC220011 02005912
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CC7C: 8C7E0E7E
	ds_store_b16_d16_hi v88, v17 offset:5128                   // 00000015CC80: DA841408 00001158
	s_and_saveexec_b32 s14, s6                                 // 00000015CC88: BE8E2006
	s_cbranch_execz 17                                         // 00000015CC8C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x38d4>
	v_mad_u64_u32 v[17:18], null, v94, 48, s[2:3]              // 00000015CC90: D6FE7C11 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CC98: BF870091
	.long 0xd73c0011                                           // 00000015CC9C: D73C0011
	v_cndmask_b32_e32 v1, 9, v17, vcc_lo                       // 00000015CCA0: 02022289
	.long 0xd7000b11                                           // 00000015CCA4: D7000B11
	v_cndmask_b32_e32 v1, v86, v17, vcc_lo                     // 00000015CCA8: 02022356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CCAC: BF8700C1
	v_add_co_ci_u32_e64 v18, null, v87, v18, s11               // 00000015CCB0: D5207C12 002E2557
	global_load_b32 v17, v[17:18], off offset:128              // 00000015CCB8: DC520080 117C0011
	s_waitcnt vmcnt(0)                                         // 00000015CCC0: BF8903F7
	v_fmac_f32_e32 v17, 0xbb800000, v20                        // 00000015CCC4: 562228FF BB800000
	v_fma_mixlo_f16 v17, v17, s44, 0                           // 00000015CCCC: CC210011 02005911
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CCD4: 8C7E0E7E
	.long 0x7f223880                                           // 00000015CCD8: 7F223880
	ds_store_b16 v88, v17 offset:5132                          // 00000015CCDC: D87C140C 00001158
	.long 0x7e243991                                           // 00000015CCE4: 7E243991
	s_and_saveexec_b32 s14, s7                                 // 00000015CCE8: BE8E2007
	s_cbranch_execz 17                                         // 00000015CCEC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3934>
	v_mad_u64_u32 v[18:19], null, v95, 48, s[2:3]              // 00000015CCF0: D6FE7C12 0009615F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CCF8: BF870091
	.long 0xd73c0012                                           // 00000015CCFC: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 00000015CD00: 02022489
	.long 0xd7000b12                                           // 00000015CD04: D7000B12
	v_cndmask_b32_e32 v1, v86, v18, vcc_lo                     // 00000015CD08: 02022556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CD0C: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v87, v19, s11               // 00000015CD10: D5207C13 002E2757
	global_load_b32 v18, v[18:19], off offset:128              // 00000015CD18: DC520080 127C0012
	s_waitcnt vmcnt(0)                                         // 00000015CD20: BF8903F7
	v_fmac_f32_e32 v18, 0xbb800000, v21                        // 00000015CD24: 56242AFF BB800000
	v_fma_mixlo_f16 v18, v18, s44, 0                           // 00000015CD2C: CC210012 02005912
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CD34: 8C7E0E7E
	ds_store_b16 v88, v18 offset:5136                          // 00000015CD38: D87C1410 00001258
	s_and_saveexec_b32 s14, s8                                 // 00000015CD40: BE8E2008
	s_cbranch_execz 17                                         // 00000015CD44: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x398c>
	v_mad_u64_u32 v[17:18], null, v96, 48, s[2:3]              // 00000015CD48: D6FE7C11 00096160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CD50: BF870091
	.long 0xd73c0011                                           // 00000015CD54: D73C0011
	v_cndmask_b32_e32 v1, 9, v17, vcc_lo                       // 00000015CD58: 02022289
	.long 0xd7000b11                                           // 00000015CD5C: D7000B11
	v_cndmask_b32_e32 v1, v86, v17, vcc_lo                     // 00000015CD60: 02022356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CD64: BF8700C1
	v_add_co_ci_u32_e64 v18, null, v87, v18, s11               // 00000015CD68: D5207C12 002E2557
	global_load_b32 v17, v[17:18], off offset:128              // 00000015CD70: DC520080 117C0011
	s_waitcnt vmcnt(0)                                         // 00000015CD78: BF8903F7
	v_fmac_f32_e32 v17, 0xbb800000, v22                        // 00000015CD7C: 56222CFF BB800000
	v_fma_mixhi_f16 v17, v17, s44, 0                           // 00000015CD84: CC220011 02005911
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CD8C: 8C7E0E7E
	.long 0x7e223880                                           // 00000015CD90: 7E223880
	ds_store_b16_d16_hi v88, v17 offset:5140                   // 00000015CD94: DA841414 00001158
	.long 0x7e243911                                           // 00000015CD9C: 7E243911
	s_and_saveexec_b32 s14, s9                                 // 00000015CDA0: BE8E2009
	s_cbranch_execz 17                                         // 00000015CDA4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x39ec>
	v_mad_u64_u32 v[18:19], null, v97, 48, s[2:3]              // 00000015CDA8: D6FE7C12 00096161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CDB0: BF870091
	.long 0xd73c0012                                           // 00000015CDB4: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 00000015CDB8: 02022489
	.long 0xd7000b12                                           // 00000015CDBC: D7000B12
	v_cndmask_b32_e32 v1, v86, v18, vcc_lo                     // 00000015CDC0: 02022556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CDC4: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v87, v19, s11               // 00000015CDC8: D5207C13 002E2757
	global_load_b32 v18, v[18:19], off offset:128              // 00000015CDD0: DC520080 127C0012
	s_waitcnt vmcnt(0)                                         // 00000015CDD8: BF8903F7
	v_fmac_f32_e32 v18, 0xbb800000, v23                        // 00000015CDDC: 56242EFF BB800000
	v_fma_mixlo_f16 v18, v18, s44, 0                           // 00000015CDE4: CC210012 02005912
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CDEC: 8C7E0E7E
	ds_store_b16 v88, v18 offset:5144                          // 00000015CDF0: D87C1418 00001258
	s_and_saveexec_b32 s14, s10                                // 00000015CDF8: BE8E200A
	s_cbranch_execz 17                                         // 00000015CDFC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a44>
	v_mad_u64_u32 v[17:18], null, v98, 48, s[2:3]              // 00000015CE00: D6FE7C11 00096162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CE08: BF870091
	.long 0xd73c0011                                           // 00000015CE0C: D73C0011
	v_cndmask_b32_e32 v1, 9, v17, vcc_lo                       // 00000015CE10: 02022289
	.long 0xd7000b11                                           // 00000015CE14: D7000B11
	v_cndmask_b32_e32 v1, v86, v17, vcc_lo                     // 00000015CE18: 02022356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CE1C: BF8700C1
	v_add_co_ci_u32_e64 v18, null, v87, v18, s11               // 00000015CE20: D5207C12 002E2557
	global_load_b32 v17, v[17:18], off offset:128              // 00000015CE28: DC520080 117C0011
	s_waitcnt vmcnt(0)                                         // 00000015CE30: BF8903F7
	v_fmac_f32_e32 v17, 0xbb800000, v24                        // 00000015CE34: 562230FF BB800000
	v_fma_mixlo_f16 v17, v17, s44, 0                           // 00000015CE3C: CC210011 02005911
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CE44: 8C7E0E7E
	.long 0x7f223880                                           // 00000015CE48: 7F223880
	ds_store_b16 v88, v17 offset:5148                          // 00000015CE4C: D87C141C 00001158
	.long 0x7e243991                                           // 00000015CE54: 7E243991
	s_and_saveexec_b32 s14, s1                                 // 00000015CE58: BE8E2001
	s_cbranch_execz 17                                         // 00000015CE5C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3aa4>
	v_mad_u64_u32 v[18:19], null, v91, 48, s[2:3]              // 00000015CE60: D6FE7C12 0009615B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CE68: BF870091
	.long 0xd73c0012                                           // 00000015CE6C: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 00000015CE70: 02022489
	.long 0xd7000b12                                           // 00000015CE74: D7000B12
	v_cndmask_b32_e32 v1, v86, v18, vcc_lo                     // 00000015CE78: 02022556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CE7C: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v87, v19, s11               // 00000015CE80: D5207C13 002E2757
	global_load_b32 v18, v[18:19], off offset:192              // 00000015CE88: DC5200C0 127C0012
	s_waitcnt vmcnt(0)                                         // 00000015CE90: BF8903F7
	v_fmac_f32_e32 v18, 0xbb800000, v9                         // 00000015CE94: 562412FF BB800000
	v_fma_mixlo_f16 v18, v18, s44, 0                           // 00000015CE9C: CC210012 02005912
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CEA4: 8C7E0E7E
	ds_store_b16 v88, v18 offset:7680                          // 00000015CEA8: D87C1E00 00001258
	s_and_saveexec_b32 s14, s4                                 // 00000015CEB0: BE8E2004
	s_cbranch_execz 17                                         // 00000015CEB4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3afc>
	v_mad_u64_u32 v[17:18], null, v92, 48, s[2:3]              // 00000015CEB8: D6FE7C11 0009615C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CEC0: BF870091
	.long 0xd73c0011                                           // 00000015CEC4: D73C0011
	v_cndmask_b32_e32 v1, 9, v17, vcc_lo                       // 00000015CEC8: 02022289
	.long 0xd7000b11                                           // 00000015CECC: D7000B11
	v_cndmask_b32_e32 v1, v86, v17, vcc_lo                     // 00000015CED0: 02022356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CED4: BF8700C1
	v_add_co_ci_u32_e64 v18, null, v87, v18, s11               // 00000015CED8: D5207C12 002E2557
	global_load_b32 v9, v[17:18], off offset:192               // 00000015CEE0: DC5200C0 097C0011
	s_waitcnt vmcnt(0)                                         // 00000015CEE8: BF8903F7
	v_fmac_f32_e32 v9, 0xbb800000, v10                         // 00000015CEEC: 561214FF BB800000
	v_fma_mixhi_f16 v17, v9, s44, 0                            // 00000015CEF4: CC220011 02005909
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CEFC: 8C7E0E7E
	.long 0x7e123880                                           // 00000015CF00: 7E123880
	ds_store_b16_d16_hi v88, v17 offset:7684                   // 00000015CF04: DA841E04 00001158
	.long 0x7f123909                                           // 00000015CF0C: 7F123909
	s_and_saveexec_b32 s14, s5                                 // 00000015CF10: BE8E2005
	s_cbranch_execz 17                                         // 00000015CF14: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b5c>
	v_mad_u64_u32 v[17:18], null, v93, 48, s[2:3]              // 00000015CF18: D6FE7C11 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CF20: BF870091
	.long 0xd73c0011                                           // 00000015CF24: D73C0011
	v_cndmask_b32_e32 v1, 9, v17, vcc_lo                       // 00000015CF28: 02022289
	.long 0xd7000b11                                           // 00000015CF2C: D7000B11
	v_cndmask_b32_e32 v1, v86, v17, vcc_lo                     // 00000015CF30: 02022356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CF34: BF8700C1
	v_add_co_ci_u32_e64 v18, null, v87, v18, s11               // 00000015CF38: D5207C12 002E2557
	global_load_b32 v10, v[17:18], off offset:192              // 00000015CF40: DC5200C0 0A7C0011
	s_waitcnt vmcnt(0)                                         // 00000015CF48: BF8903F7
	v_fmac_f32_e32 v10, 0xbb800000, v11                        // 00000015CF4C: 561416FF BB800000
	v_fma_mixhi_f16 v9, v10, s44, 0                            // 00000015CF54: CC220009 0200590A
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CF5C: 8C7E0E7E
	ds_store_b16_d16_hi v88, v9 offset:7688                    // 00000015CF60: DA841E08 00000958
	s_and_saveexec_b32 s14, s6                                 // 00000015CF68: BE8E2006
	s_cbranch_execz 17                                         // 00000015CF6C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3bb4>
	v_mad_u64_u32 v[9:10], null, v94, 48, s[2:3]               // 00000015CF70: D6FE7C09 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CF78: BF870091
	.long 0xd73c0009                                           // 00000015CF7C: D73C0009
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 00000015CF80: 02021289
	.long 0xd7000b09                                           // 00000015CF84: D7000B09
	v_cndmask_b32_e32 v1, v86, v9, vcc_lo                      // 00000015CF88: 02021356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CF8C: BF8700C1
	v_add_co_ci_u32_e64 v10, null, v87, v10, s11               // 00000015CF90: D5207C0A 002E1557
	global_load_b32 v9, v[9:10], off offset:192                // 00000015CF98: DC5200C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000015CFA0: BF8903F7
	v_fmac_f32_e32 v9, 0xbb800000, v12                         // 00000015CFA4: 561218FF BB800000
	v_fma_mixlo_f16 v9, v9, s44, 0                             // 00000015CFAC: CC210009 02005909
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015CFB4: 8C7E0E7E
	.long 0x7f123880                                           // 00000015CFB8: 7F123880
	ds_store_b16 v88, v9 offset:7692                           // 00000015CFBC: D87C1E0C 00000958
	.long 0x7e143989                                           // 00000015CFC4: 7E143989
	s_and_saveexec_b32 s14, s7                                 // 00000015CFC8: BE8E2007
	s_cbranch_execz 17                                         // 00000015CFCC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3c14>
	v_mad_u64_u32 v[10:11], null, v95, 48, s[2:3]              // 00000015CFD0: D6FE7C0A 0009615F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015CFD8: BF870091
	.long 0xd73c000a                                           // 00000015CFDC: D73C000A
	v_cndmask_b32_e32 v1, 9, v10, vcc_lo                       // 00000015CFE0: 02021489
	.long 0xd7000b0a                                           // 00000015CFE4: D7000B0A
	v_cndmask_b32_e32 v1, v86, v10, vcc_lo                     // 00000015CFE8: 02021556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015CFEC: BF8700C1
	v_add_co_ci_u32_e64 v11, null, v87, v11, s11               // 00000015CFF0: D5207C0B 002E1757
	global_load_b32 v10, v[10:11], off offset:192              // 00000015CFF8: DC5200C0 0A7C000A
	s_waitcnt vmcnt(0)                                         // 00000015D000: BF8903F7
	v_fmac_f32_e32 v10, 0xbb800000, v13                        // 00000015D004: 56141AFF BB800000
	v_fma_mixlo_f16 v10, v10, s44, 0                           // 00000015D00C: CC21000A 0200590A
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015D014: 8C7E0E7E
	ds_store_b16 v88, v10 offset:7696                          // 00000015D018: D87C1E10 00000A58
	s_and_saveexec_b32 s14, s8                                 // 00000015D020: BE8E2008
	s_cbranch_execz 17                                         // 00000015D024: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3c6c>
	v_mad_u64_u32 v[9:10], null, v96, 48, s[2:3]               // 00000015D028: D6FE7C09 00096160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015D030: BF870091
	.long 0xd73c0009                                           // 00000015D034: D73C0009
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 00000015D038: 02021289
	.long 0xd7000b09                                           // 00000015D03C: D7000B09
	v_cndmask_b32_e32 v1, v86, v9, vcc_lo                      // 00000015D040: 02021356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015D044: BF8700C1
	v_add_co_ci_u32_e64 v10, null, v87, v10, s11               // 00000015D048: D5207C0A 002E1557
	global_load_b32 v9, v[9:10], off offset:192                // 00000015D050: DC5200C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000015D058: BF8903F7
	v_fmac_f32_e32 v9, 0xbb800000, v14                         // 00000015D05C: 56121CFF BB800000
	v_fma_mixhi_f16 v9, v9, s44, 0                             // 00000015D064: CC220009 02005909
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015D06C: 8C7E0E7E
	.long 0x7e123880                                           // 00000015D070: 7E123880
	ds_store_b16_d16_hi v88, v9 offset:7700                    // 00000015D074: DA841E14 00000958
	.long 0x7e143909                                           // 00000015D07C: 7E143909
	s_and_saveexec_b32 s14, s9                                 // 00000015D080: BE8E2009
	s_cbranch_execz 17                                         // 00000015D084: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ccc>
	v_mad_u64_u32 v[10:11], null, v97, 48, s[2:3]              // 00000015D088: D6FE7C0A 00096161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015D090: BF870091
	.long 0xd73c000a                                           // 00000015D094: D73C000A
	v_cndmask_b32_e32 v1, 9, v10, vcc_lo                       // 00000015D098: 02021489
	.long 0xd7000b0a                                           // 00000015D09C: D7000B0A
	v_cndmask_b32_e32 v1, v86, v10, vcc_lo                     // 00000015D0A0: 02021556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015D0A4: BF8700C1
	v_add_co_ci_u32_e64 v11, null, v87, v11, s11               // 00000015D0A8: D5207C0B 002E1757
	global_load_b32 v10, v[10:11], off offset:192              // 00000015D0B0: DC5200C0 0A7C000A
	s_waitcnt vmcnt(0)                                         // 00000015D0B8: BF8903F7
	v_fmac_f32_e32 v10, 0xbb800000, v15                        // 00000015D0BC: 56141EFF BB800000
	v_fma_mixlo_f16 v10, v10, s44, 0                           // 00000015D0C4: CC21000A 0200590A
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015D0CC: 8C7E0E7E
	ds_store_b16 v88, v10 offset:7704                          // 00000015D0D0: D87C1E18 00000A58
	s_and_saveexec_b32 s14, s10                                // 00000015D0D8: BE8E200A
	s_cbranch_execz 17                                         // 00000015D0DC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d24>
	v_mad_u64_u32 v[9:10], null, v98, 48, s[2:3]               // 00000015D0E0: D6FE7C09 00096162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015D0E8: BF870091
	.long 0xd73c0009                                           // 00000015D0EC: D73C0009
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 00000015D0F0: 02021289
	.long 0xd7000b09                                           // 00000015D0F4: D7000B09
	v_cndmask_b32_e32 v1, v86, v9, vcc_lo                      // 00000015D0F8: 02021356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000015D0FC: BF8700C1
	v_add_co_ci_u32_e64 v10, null, v87, v10, s11               // 00000015D100: D5207C0A 002E1557
	global_load_b32 v9, v[9:10], off offset:192                // 00000015D108: DC5200C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000015D110: BF8903F7
	v_fmac_f32_e32 v9, 0xbb800000, v16                         // 00000015D114: 561220FF BB800000
	v_fma_mixlo_f16 v9, v9, s44, 0                             // 00000015D11C: CC210009 02005909
	s_or_b32 exec_lo, exec_lo, s14                             // 00000015D124: 8C7E0E7E
	.long 0x7f683880                                           // 00000015D128: 7F683880
	.long 0xd7000b3b                                           // 00000015D12C: D7000B3B
	v_cndmask_b32_e32 v1, s38, v59, vcc_lo                     // 00000015D130: 02027626
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000015D134: BF870191
	v_add_co_ci_u32_e64 v60, null, s39, v60, s11               // 00000015D138: D5207C3C 002E7827
	.long 0x7f6439b4                                           // 00000015D140: 7F6439B4
	.long 0x7e6439b4                                           // 00000015D144: 7E6439B4
	.long 0x7f6239b4                                           // 00000015D148: 7F6239B4
	.long 0x7e6239b4                                           // 00000015D14C: 7E6239B4
	ds_store_b16 v88, v9 offset:7708                           // 00000015D150: D87C1E1C 00000958
	s_waitcnt lgkmcnt(0)                                       // 00000015D158: BF89FC07
	s_barrier                                                  // 00000015D15C: BFBD0000
	buffer_gl0_inv                                             // 00000015D160: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 00000015D168: BE8B2000
	s_cbranch_execz 11                                         // 00000015D16C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d9c>
	global_load_b128 v[9:12], v[59:60], off                    // 00000015D170: DC5E0000 097C003B
	s_waitcnt vmcnt(0)                                         // 00000015D178: BF8903F7
	v_fma_mixlo_f16 v49, v9, s44, 0                            // 00000015D17C: CC210031 02005909
	v_fma_mixhi_f16 v49, v10, s44, 0                           // 00000015D184: CC220031 0200590A
	v_fma_mixlo_f16 v50, v11, s44, 0                           // 00000015D18C: CC210032 0200590B
	v_fma_mixhi_f16 v50, v12, s44, 0                           // 00000015D194: CC220032 0200590C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015D19C: 8C7E0B7E
	.long 0x7e6839b4                                           // 00000015D1A0: 7E6839B4
	.long 0x7f6639b4                                           // 00000015D1A4: 7F6639B4
	.long 0x7e6639b4                                           // 00000015D1A8: 7E6639B4
	s_and_saveexec_b32 s11, s0                                 // 00000015D1AC: BE8B2000
	s_cbranch_execz 11                                         // 00000015D1B0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3de0>
	global_load_b128 v[9:12], v[59:60], off offset:16          // 00000015D1B4: DC5E0010 097C003B
	s_waitcnt vmcnt(0)                                         // 00000015D1BC: BF8903F7
	v_fma_mixlo_f16 v51, v9, s44, 0                            // 00000015D1C0: CC210033 02005909
	v_fma_mixhi_f16 v51, v10, s44, 0                           // 00000015D1C8: CC220033 0200590A
	v_fma_mixlo_f16 v52, v11, s44, 0                           // 00000015D1D0: CC210034 0200590B
	v_fma_mixhi_f16 v52, v12, s44, 0                           // 00000015D1D8: CC220034 0200590C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015D1E0: 8C7E0B7E
	.long 0x7f703880                                           // 00000015D1E4: 7F703880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015D1E8: BF870001
	.long 0x7f6c39b8                                           // 00000015D1EC: 7F6C39B8
	.long 0x7e6c39b8                                           // 00000015D1F0: 7E6C39B8
	.long 0x7f6a39b8                                           // 00000015D1F4: 7F6A39B8
	.long 0x7e6a39b8                                           // 00000015D1F8: 7E6A39B8
	s_and_saveexec_b32 s11, s0                                 // 00000015D1FC: BE8B2000
	s_cbranch_execz 11                                         // 00000015D200: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3e30>
	global_load_b128 v[9:12], v[59:60], off offset:32          // 00000015D204: DC5E0020 097C003B
	s_waitcnt vmcnt(0)                                         // 00000015D20C: BF8903F7
	v_fma_mixlo_f16 v53, v9, s44, 0                            // 00000015D210: CC210035 02005909
	v_fma_mixhi_f16 v53, v10, s44, 0                           // 00000015D218: CC220035 0200590A
	v_fma_mixlo_f16 v54, v11, s44, 0                           // 00000015D220: CC210036 0200590B
	v_fma_mixhi_f16 v54, v12, s44, 0                           // 00000015D228: CC220036 0200590C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015D230: 8C7E0B7E
	.long 0x7e7039b8                                           // 00000015D234: 7E7039B8
	.long 0x7f6e39b8                                           // 00000015D238: 7F6E39B8
	.long 0x7e6e39b8                                           // 00000015D23C: 7E6E39B8
	s_and_saveexec_b32 s11, s0                                 // 00000015D240: BE8B2000
	s_cbranch_execz 11                                         // 00000015D244: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3e74>
	global_load_b128 v[9:12], v[59:60], off offset:48          // 00000015D248: DC5E0030 097C003B
	s_waitcnt vmcnt(0)                                         // 00000015D250: BF8903F7
	v_fma_mixlo_f16 v55, v9, s44, 0                            // 00000015D254: CC210037 02005909
	v_fma_mixhi_f16 v55, v10, s44, 0                           // 00000015D25C: CC220037 0200590A
	v_fma_mixlo_f16 v56, v11, s44, 0                           // 00000015D264: CC210038 0200590B
	v_fma_mixhi_f16 v56, v12, s44, 0                           // 00000015D26C: CC220038 0200590C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015D274: 8C7E0B7E
	ds_load_b128 v[9:12], v79                                  // 00000015D278: DBFC0000 0900004F
	ds_load_b128 v[13:16], v79 offset:16                       // 00000015D280: DBFC0010 0D00004F
	ds_load_b128 v[17:20], v79 offset:32                       // 00000015D288: DBFC0020 1100004F
	ds_load_b128 v[21:24], v79 offset:48                       // 00000015D290: DBFC0030 1500004F
	ds_load_b128 v[25:28], v79 offset:8448                     // 00000015D298: DBFC2100 1900004F
	ds_load_b128 v[29:32], v79 offset:8464                     // 00000015D2A0: DBFC2110 1D00004F
	ds_load_b128 v[33:36], v79 offset:8480                     // 00000015D2A8: DBFC2120 2100004F
	ds_load_b128 v[37:40], v79 offset:8496                     // 00000015D2B0: DBFC2130 2500004F
	ds_load_b128 v[41:44], v79 offset:16896                    // 00000015D2B8: DBFC4200 2900004F
	ds_load_b128 v[45:48], v79 offset:16912                    // 00000015D2C0: DBFC4210 2D00004F
	v_dual_mov_b32 v68, s31 :: v_dual_mov_b32 v67, s30         // 00000015D2C8: CA10001F 4442001E
	v_dual_mov_b32 v66, s29 :: v_dual_mov_b32 v65, s28         // 00000015D2D0: CA10001D 4240001C
	v_dual_mov_b32 v64, s27 :: v_dual_mov_b32 v63, s26         // 00000015D2D8: CA10001B 403E001A
	v_dual_mov_b32 v62, s25 :: v_dual_mov_b32 v61, s24         // 00000015D2E0: CA100019 3E3C0018
	ds_load_b128 v[69:72], v79 offset:16928                    // 00000015D2E8: DBFC4220 4500004F
	ds_load_b128 v[99:102], v79 offset:16944                   // 00000015D2F0: DBFC4230 6300004F
	s_waitcnt lgkmcnt(11)                                      // 00000015D2F8: BF89FCB7
	v_fma_mixlo_f16 v9, v9, s44, 0                             // 00000015D2FC: CC210009 02005909
	v_fma_mixhi_f16 v9, v10, s44, 0                            // 00000015D304: CC220009 0200590A
	v_fma_mixlo_f16 v10, v11, s44, 0                           // 00000015D30C: CC21000A 0200590B
	v_fma_mixhi_f16 v10, v12, s44, 0                           // 00000015D314: CC22000A 0200590C
	s_waitcnt lgkmcnt(10)                                      // 00000015D31C: BF89FCA7
	v_fma_mixlo_f16 v11, v13, s44, 0                           // 00000015D320: CC21000B 0200590D
	v_fma_mixhi_f16 v11, v14, s44, 0                           // 00000015D328: CC22000B 0200590E
	v_fma_mixlo_f16 v12, v15, s44, 0                           // 00000015D330: CC21000C 0200590F
	v_fma_mixhi_f16 v12, v16, s44, 0                           // 00000015D338: CC22000C 02005910
	s_waitcnt lgkmcnt(9)                                       // 00000015D340: BF89FC97
	v_fma_mixlo_f16 v13, v17, s44, 0                           // 00000015D344: CC21000D 02005911
	v_fma_mixhi_f16 v13, v18, s44, 0                           // 00000015D34C: CC22000D 02005912
	v_fma_mixlo_f16 v14, v19, s44, 0                           // 00000015D354: CC21000E 02005913
	v_fma_mixhi_f16 v14, v20, s44, 0                           // 00000015D35C: CC22000E 02005914
	s_waitcnt lgkmcnt(8)                                       // 00000015D364: BF89FC87
	v_fma_mixlo_f16 v15, v21, s44, 0                           // 00000015D368: CC21000F 02005915
	v_fma_mixhi_f16 v15, v22, s44, 0                           // 00000015D370: CC22000F 02005916
	v_fma_mixlo_f16 v16, v23, s44, 0                           // 00000015D378: CC210010 02005917
	v_fma_mixhi_f16 v16, v24, s44, 0                           // 00000015D380: CC220010 02005918
	s_waitcnt lgkmcnt(7)                                       // 00000015D388: BF89FC77
	v_fma_mixlo_f16 v17, v25, s44, 0                           // 00000015D38C: CC210011 02005919
	v_fma_mixhi_f16 v17, v26, s44, 0                           // 00000015D394: CC220011 0200591A
	v_fma_mixlo_f16 v18, v27, s44, 0                           // 00000015D39C: CC210012 0200591B
	v_fma_mixhi_f16 v18, v28, s44, 0                           // 00000015D3A4: CC220012 0200591C
	s_waitcnt lgkmcnt(6)                                       // 00000015D3AC: BF89FC67
	v_fma_mixlo_f16 v19, v29, s44, 0                           // 00000015D3B0: CC210013 0200591D
	v_fma_mixhi_f16 v19, v30, s44, 0                           // 00000015D3B8: CC220013 0200591E
	v_fma_mixlo_f16 v20, v31, s44, 0                           // 00000015D3C0: CC210014 0200591F
	v_fma_mixhi_f16 v20, v32, s44, 0                           // 00000015D3C8: CC220014 02005920
	s_waitcnt lgkmcnt(5)                                       // 00000015D3D0: BF89FC57
	v_fma_mixlo_f16 v21, v33, s44, 0                           // 00000015D3D4: CC210015 02005921
	v_fma_mixhi_f16 v21, v34, s44, 0                           // 00000015D3DC: CC220015 02005922
	v_fma_mixlo_f16 v22, v35, s44, 0                           // 00000015D3E4: CC210016 02005923
	v_fma_mixhi_f16 v22, v36, s44, 0                           // 00000015D3EC: CC220016 02005924
	s_waitcnt lgkmcnt(4)                                       // 00000015D3F4: BF89FC47
	v_fma_mixlo_f16 v23, v37, s44, 0                           // 00000015D3F8: CC210017 02005925
	v_fma_mixhi_f16 v23, v38, s44, 0                           // 00000015D400: CC220017 02005926
	v_fma_mixlo_f16 v24, v39, s44, 0                           // 00000015D408: CC210018 02005927
	v_fma_mixhi_f16 v24, v40, s44, 0                           // 00000015D410: CC220018 02005928
	v_wmma_f32_16x16x16_f16 v[33:40], v[49:56], v[9:16], v[61:68]// 00000015D418: CC404021 1CF61331
	s_waitcnt lgkmcnt(3)                                       // 00000015D420: BF89FC37
	v_fma_mixlo_f16 v9, v41, s44, 0                            // 00000015D424: CC210009 02005929
	v_fma_mixhi_f16 v9, v42, s44, 0                            // 00000015D42C: CC220009 0200592A
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[17:24], v[61:68]// 00000015D434: CC404019 1CF62331
	ds_load_b128 v[17:20], v79 offset:25344                    // 00000015D43C: DBFC6300 1100004F
	ds_load_b128 v[21:24], v79 offset:25360                    // 00000015D444: DBFC6310 1500004F
	v_fma_mixlo_f16 v10, v43, s44, 0                           // 00000015D44C: CC21000A 0200592B
	v_fma_mixhi_f16 v10, v44, s44, 0                           // 00000015D454: CC22000A 0200592C
	s_waitcnt lgkmcnt(4)                                       // 00000015D45C: BF89FC47
	v_fma_mixlo_f16 v11, v45, s44, 0                           // 00000015D460: CC21000B 0200592D
	v_fma_mixhi_f16 v11, v46, s44, 0                           // 00000015D468: CC22000B 0200592E
	ds_load_b128 v[41:44], v79 offset:25376                    // 00000015D470: DBFC6320 2900004F
	v_fma_mixlo_f16 v12, v47, s44, 0                           // 00000015D478: CC21000C 0200592F
	v_fma_mixhi_f16 v12, v48, s44, 0                           // 00000015D480: CC22000C 02005930
	ds_load_b128 v[45:48], v79 offset:25392                    // 00000015D488: DBFC6330 2D00004F
	s_waitcnt lgkmcnt(5)                                       // 00000015D490: BF89FC57
	v_fma_mixlo_f16 v13, v69, s44, 0                           // 00000015D494: CC21000D 02005945
	v_fma_mixhi_f16 v13, v70, s44, 0                           // 00000015D49C: CC22000D 02005946
	v_fma_mixlo_f16 v14, v71, s44, 0                           // 00000015D4A4: CC21000E 02005947
	v_fma_mixhi_f16 v14, v72, s44, 0                           // 00000015D4AC: CC22000E 02005948
	s_waitcnt lgkmcnt(4)                                       // 00000015D4B4: BF89FC47
	v_fma_mixlo_f16 v15, v99, s44, 0                           // 00000015D4B8: CC21000F 02005963
	v_fma_mixhi_f16 v15, v100, s44, 0                          // 00000015D4C0: CC22000F 02005964
	v_fma_mixlo_f16 v16, v101, s44, 0                          // 00000015D4C8: CC210010 02005965
	v_fma_mixhi_f16 v16, v102, s44, 0                          // 00000015D4D0: CC220010 02005966
	s_waitcnt lgkmcnt(3)                                       // 00000015D4D8: BF89FC37
	v_fma_mixlo_f16 v99, v17, s44, 0                           // 00000015D4DC: CC210063 02005911
	v_fma_mixhi_f16 v99, v18, s44, 0                           // 00000015D4E4: CC220063 02005912
	v_fma_mixlo_f16 v100, v19, s44, 0                          // 00000015D4EC: CC210064 02005913
	v_fma_mixhi_f16 v100, v20, s44, 0                          // 00000015D4F4: CC220064 02005914
	s_waitcnt lgkmcnt(2)                                       // 00000015D4FC: BF89FC27
	v_fma_mixlo_f16 v101, v21, s44, 0                          // 00000015D500: CC210065 02005915
	v_fma_mixhi_f16 v101, v22, s44, 0                          // 00000015D508: CC220065 02005916
	v_fma_mixlo_f16 v102, v23, s44, 0                          // 00000015D510: CC210066 02005917
	v_fma_mixhi_f16 v102, v24, s44, 0                          // 00000015D518: CC220066 02005918
	s_waitcnt lgkmcnt(1)                                       // 00000015D520: BF89FC17
	v_fma_mixlo_f16 v103, v41, s44, 0                          // 00000015D524: CC210067 02005929
	v_fma_mixhi_f16 v103, v42, s44, 0                          // 00000015D52C: CC220067 0200592A
	v_fma_mixlo_f16 v104, v43, s44, 0                          // 00000015D534: CC210068 0200592B
	v_fma_mixhi_f16 v104, v44, s44, 0                          // 00000015D53C: CC220068 0200592C
	s_waitcnt lgkmcnt(0)                                       // 00000015D544: BF89FC07
	v_fma_mixlo_f16 v105, v45, s44, 0                          // 00000015D548: CC210069 0200592D
	v_fma_mixhi_f16 v105, v46, s44, 0                          // 00000015D550: CC220069 0200592E
	v_fma_mixlo_f16 v106, v47, s44, 0                          // 00000015D558: CC21006A 0200592F
	v_fma_mixhi_f16 v106, v48, s44, 0                          // 00000015D560: CC22006A 02005930
	.long 0x7f603880                                           // 00000015D568: 7F603880
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[9:16], v[61:68]// 00000015D56C: CC404011 1CF61331
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000015D574: BF870193
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[99:106], v[61:68]// 00000015D578: CC404009 1CF6C731
	.long 0x7f5c39b0                                           // 00000015D580: 7F5C39B0
	.long 0x7e5c39b0                                           // 00000015D584: 7E5C39B0
	.long 0x7f5a39b0                                           // 00000015D588: 7F5A39B0
	.long 0x7e5a39b0                                           // 00000015D58C: 7E5A39B0
	s_and_saveexec_b32 s11, s0                                 // 00000015D590: BE8B2000
	s_cbranch_execz 11                                         // 00000015D594: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41c4>
	global_load_b128 v[41:44], v[59:60], off offset:64         // 00000015D598: DC5E0040 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015D5A0: BF8903F7
	v_fma_mixlo_f16 v45, v41, s44, 0                           // 00000015D5A4: CC21002D 02005929
	v_fma_mixhi_f16 v45, v42, s44, 0                           // 00000015D5AC: CC22002D 0200592A
	v_fma_mixlo_f16 v46, v43, s44, 0                           // 00000015D5B4: CC21002E 0200592B
	v_fma_mixhi_f16 v46, v44, s44, 0                           // 00000015D5BC: CC22002E 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015D5C4: 8C7E0B7E
	.long 0x7e6039b0                                           // 00000015D5C8: 7E6039B0
	.long 0x7f5e39b0                                           // 00000015D5CC: 7F5E39B0
	.long 0x7e5e39b0                                           // 00000015D5D0: 7E5E39B0
	s_and_saveexec_b32 s11, s0                                 // 00000015D5D4: BE8B2000
	s_cbranch_execz 11                                         // 00000015D5D8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4208>
	global_load_b128 v[41:44], v[59:60], off offset:80         // 00000015D5DC: DC5E0050 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015D5E4: BF8903F7
	v_fma_mixlo_f16 v47, v41, s44, 0                           // 00000015D5E8: CC21002F 02005929
	v_fma_mixhi_f16 v47, v42, s44, 0                           // 00000015D5F0: CC22002F 0200592A
	v_fma_mixlo_f16 v48, v43, s44, 0                           // 00000015D5F8: CC210030 0200592B
	v_fma_mixhi_f16 v48, v44, s44, 0                           // 00000015D600: CC220030 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015D608: 8C7E0B7E
	.long 0x7f683880                                           // 00000015D60C: 7F683880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015D610: BF870001
	.long 0x7f6439b4                                           // 00000015D614: 7F6439B4
	.long 0x7e6439b4                                           // 00000015D618: 7E6439B4
	.long 0x7f6239b4                                           // 00000015D61C: 7F6239B4
	.long 0x7e6239b4                                           // 00000015D620: 7E6239B4
	s_and_saveexec_b32 s11, s0                                 // 00000015D624: BE8B2000
	s_cbranch_execz 11                                         // 00000015D628: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4258>
	global_load_b128 v[41:44], v[59:60], off offset:96         // 00000015D62C: DC5E0060 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015D634: BF8903F7
	v_fma_mixlo_f16 v49, v41, s44, 0                           // 00000015D638: CC210031 02005929
	v_fma_mixhi_f16 v49, v42, s44, 0                           // 00000015D640: CC220031 0200592A
	v_fma_mixlo_f16 v50, v43, s44, 0                           // 00000015D648: CC210032 0200592B
	v_fma_mixhi_f16 v50, v44, s44, 0                           // 00000015D650: CC220032 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015D658: 8C7E0B7E
	.long 0x7e6839b4                                           // 00000015D65C: 7E6839B4
	.long 0x7f6639b4                                           // 00000015D660: 7F6639B4
	.long 0x7e6639b4                                           // 00000015D664: 7E6639B4
	s_and_saveexec_b32 s11, s0                                 // 00000015D668: BE8B2000
	s_cbranch_execz 11                                         // 00000015D66C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x429c>
	global_load_b128 v[41:44], v[59:60], off offset:112        // 00000015D670: DC5E0070 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015D678: BF8903F7
	v_fma_mixlo_f16 v51, v41, s44, 0                           // 00000015D67C: CC210033 02005929
	v_fma_mixhi_f16 v51, v42, s44, 0                           // 00000015D684: CC220033 0200592A
	v_fma_mixlo_f16 v52, v43, s44, 0                           // 00000015D68C: CC210034 0200592B
	v_fma_mixhi_f16 v52, v44, s44, 0                           // 00000015D694: CC220034 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015D69C: 8C7E0B7E
	ds_load_b128 v[41:44], v79 offset:64                       // 00000015D6A0: DBFC0040 2900004F
	ds_load_b128 v[53:56], v79 offset:80                       // 00000015D6A8: DBFC0050 3500004F
	ds_load_b128 v[65:68], v79 offset:96                       // 00000015D6B0: DBFC0060 4100004F
	ds_load_b128 v[69:72], v79 offset:112                      // 00000015D6B8: DBFC0070 4500004F
	ds_load_b128 v[99:102], v79 offset:8512                    // 00000015D6C0: DBFC2140 6300004F
	ds_load_b128 v[103:106], v79 offset:8528                   // 00000015D6C8: DBFC2150 6700004F
	ds_load_b128 v[107:110], v79 offset:8544                   // 00000015D6D0: DBFC2160 6B00004F
	ds_load_b128 v[111:114], v79 offset:8560                   // 00000015D6D8: DBFC2170 6F00004F
	ds_load_b128 v[119:122], v79 offset:25408                  // 00000015D6E0: DBFC6340 7700004F
	ds_load_b128 v[123:126], v79 offset:25424                  // 00000015D6E8: DBFC6350 7B00004F
	ds_load_b128 v[115:118], v79 offset:17008                  // 00000015D6F0: DBFC4270 7300004F
	s_waitcnt lgkmcnt(10)                                      // 00000015D6F8: BF89FCA7
	v_fma_mixlo_f16 v61, v41, s44, 0                           // 00000015D6FC: CC21003D 02005929
	v_fma_mixhi_f16 v61, v42, s44, 0                           // 00000015D704: CC22003D 0200592A
	v_fma_mixlo_f16 v62, v43, s44, 0                           // 00000015D70C: CC21003E 0200592B
	v_fma_mixhi_f16 v62, v44, s44, 0                           // 00000015D714: CC22003E 0200592C
	s_waitcnt lgkmcnt(9)                                       // 00000015D71C: BF89FC97
	v_fma_mixlo_f16 v63, v53, s44, 0                           // 00000015D720: CC21003F 02005935
	v_fma_mixhi_f16 v63, v54, s44, 0                           // 00000015D728: CC22003F 02005936
	v_fma_mixlo_f16 v64, v55, s44, 0                           // 00000015D730: CC210040 02005937
	v_fma_mixhi_f16 v64, v56, s44, 0                           // 00000015D738: CC220040 02005938
	ds_load_b128 v[41:44], v79 offset:16960                    // 00000015D740: DBFC4240 2900004F
	ds_load_b128 v[53:56], v79 offset:16976                    // 00000015D748: DBFC4250 3500004F
	s_waitcnt lgkmcnt(10)                                      // 00000015D750: BF89FCA7
	v_fma_mixlo_f16 v65, v65, s44, 0                           // 00000015D754: CC210041 02005941
	v_fma_mixhi_f16 v65, v66, s44, 0                           // 00000015D75C: CC220041 02005942
	v_fma_mixlo_f16 v66, v67, s44, 0                           // 00000015D764: CC210042 02005943
	v_fma_mixhi_f16 v66, v68, s44, 0                           // 00000015D76C: CC220042 02005944
	s_waitcnt lgkmcnt(9)                                       // 00000015D774: BF89FC97
	v_fma_mixlo_f16 v67, v69, s44, 0                           // 00000015D778: CC210043 02005945
	v_fma_mixhi_f16 v67, v70, s44, 0                           // 00000015D780: CC220043 02005946
	v_fma_mixlo_f16 v68, v71, s44, 0                           // 00000015D788: CC210044 02005947
	v_fma_mixhi_f16 v68, v72, s44, 0                           // 00000015D790: CC220044 02005948
	s_waitcnt lgkmcnt(8)                                       // 00000015D798: BF89FC87
	v_fma_mixlo_f16 v99, v99, s44, 0                           // 00000015D79C: CC210063 02005963
	v_fma_mixhi_f16 v99, v100, s44, 0                          // 00000015D7A4: CC220063 02005964
	v_fma_mixlo_f16 v100, v101, s44, 0                         // 00000015D7AC: CC210064 02005965
	s_waitcnt lgkmcnt(7)                                       // 00000015D7B4: BF89FC77
	v_fma_mixlo_f16 v101, v103, s44, 0                         // 00000015D7B8: CC210065 02005967
	v_fma_mixhi_f16 v101, v104, s44, 0                         // 00000015D7C0: CC220065 02005968
	s_waitcnt lgkmcnt(6)                                       // 00000015D7C8: BF89FC67
	v_fma_mixlo_f16 v103, v107, s44, 0                         // 00000015D7CC: CC210067 0200596B
	ds_load_b128 v[69:72], v79 offset:16992                    // 00000015D7D4: DBFC4260 4500004F
	v_fma_mixhi_f16 v103, v108, s44, 0                         // 00000015D7DC: CC220067 0200596C
	v_fma_mixlo_f16 v104, v109, s44, 0                         // 00000015D7E4: CC210068 0200596D
	v_fma_mixhi_f16 v104, v110, s44, 0                         // 00000015D7EC: CC220068 0200596E
	s_waitcnt lgkmcnt(2)                                       // 00000015D7F4: BF89FC27
	v_fma_mixlo_f16 v107, v41, s44, 0                          // 00000015D7F8: CC21006B 02005929
	v_fma_mixhi_f16 v107, v42, s44, 0                          // 00000015D800: CC22006B 0200592A
	v_fma_mixlo_f16 v108, v43, s44, 0                          // 00000015D808: CC21006C 0200592B
	v_fma_mixhi_f16 v108, v44, s44, 0                          // 00000015D810: CC22006C 0200592C
	s_waitcnt lgkmcnt(1)                                       // 00000015D818: BF89FC17
	v_fma_mixlo_f16 v109, v53, s44, 0                          // 00000015D81C: CC21006D 02005935
	v_fma_mixhi_f16 v109, v54, s44, 0                          // 00000015D824: CC22006D 02005936
	ds_load_b128 v[41:44], v79 offset:25440                    // 00000015D82C: DBFC6360 2900004F
	v_fma_mixlo_f16 v110, v55, s44, 0                          // 00000015D834: CC21006E 02005937
	v_fma_mixhi_f16 v110, v56, s44, 0                          // 00000015D83C: CC22006E 02005938
	ds_load_b128 v[53:56], v79 offset:25456                    // 00000015D844: DBFC6370 3500004F
	v_fma_mixhi_f16 v100, v102, s44, 0                         // 00000015D84C: CC220064 02005966
	v_fma_mixlo_f16 v102, v105, s44, 0                         // 00000015D854: CC210066 02005969
	v_fma_mixhi_f16 v102, v106, s44, 0                         // 00000015D85C: CC220066 0200596A
	v_fma_mixlo_f16 v105, v111, s44, 0                         // 00000015D864: CC210069 0200596F
	v_fma_mixhi_f16 v105, v112, s44, 0                         // 00000015D86C: CC220069 02005970
	v_fma_mixlo_f16 v106, v113, s44, 0                         // 00000015D874: CC21006A 02005971
	v_fma_mixhi_f16 v106, v114, s44, 0                         // 00000015D87C: CC22006A 02005972
	s_waitcnt lgkmcnt(2)                                       // 00000015D884: BF89FC27
	v_fma_mixlo_f16 v111, v69, s44, 0                          // 00000015D888: CC21006F 02005945
	v_fma_mixhi_f16 v111, v70, s44, 0                          // 00000015D890: CC22006F 02005946
	v_fma_mixlo_f16 v112, v71, s44, 0                          // 00000015D898: CC210070 02005947
	v_fma_mixhi_f16 v112, v72, s44, 0                          // 00000015D8A0: CC220070 02005948
	v_fma_mixlo_f16 v113, v115, s44, 0                         // 00000015D8A8: CC210071 02005973
	v_fma_mixhi_f16 v113, v116, s44, 0                         // 00000015D8B0: CC220071 02005974
	v_fma_mixlo_f16 v114, v117, s44, 0                         // 00000015D8B8: CC210072 02005975
	v_fma_mixhi_f16 v114, v118, s44, 0                         // 00000015D8C0: CC220072 02005976
	v_fma_mixlo_f16 v115, v119, s44, 0                         // 00000015D8C8: CC210073 02005977
	v_fma_mixhi_f16 v115, v120, s44, 0                         // 00000015D8D0: CC220073 02005978
	v_fma_mixlo_f16 v116, v121, s44, 0                         // 00000015D8D8: CC210074 02005979
	v_fma_mixhi_f16 v116, v122, s44, 0                         // 00000015D8E0: CC220074 0200597A
	v_fma_mixlo_f16 v117, v123, s44, 0                         // 00000015D8E8: CC210075 0200597B
	v_fma_mixhi_f16 v117, v124, s44, 0                         // 00000015D8F0: CC220075 0200597C
	v_fma_mixlo_f16 v118, v125, s44, 0                         // 00000015D8F8: CC210076 0200597D
	v_fma_mixhi_f16 v118, v126, s44, 0                         // 00000015D900: CC220076 0200597E
	s_waitcnt lgkmcnt(1)                                       // 00000015D908: BF89FC17
	v_fma_mixlo_f16 v119, v41, s44, 0                          // 00000015D90C: CC210077 02005929
	v_fma_mixhi_f16 v119, v42, s44, 0                          // 00000015D914: CC220077 0200592A
	v_fma_mixlo_f16 v120, v43, s44, 0                          // 00000015D91C: CC210078 0200592B
	v_fma_mixhi_f16 v120, v44, s44, 0                          // 00000015D924: CC220078 0200592C
	s_waitcnt lgkmcnt(0)                                       // 00000015D92C: BF89FC07
	v_fma_mixlo_f16 v121, v53, s44, 0                          // 00000015D930: CC210079 02005935
	v_fma_mixhi_f16 v121, v54, s44, 0                          // 00000015D938: CC220079 02005936
	v_fma_mixlo_f16 v122, v55, s44, 0                          // 00000015D940: CC21007A 02005937
	v_fma_mixhi_f16 v122, v56, s44, 0                          // 00000015D948: CC22007A 02005938
	.long 0x7f583880                                           // 00000015D950: 7F583880
	v_wmma_f32_16x16x16_f16 v[33:40], v[45:52], v[61:68], v[33:40]// 00000015D954: CC404021 1C867B2D
	v_wmma_f32_16x16x16_f16 v[25:32], v[45:52], v[99:106], v[25:32]// 00000015D95C: CC404019 1C66C72D
	v_wmma_f32_16x16x16_f16 v[17:24], v[45:52], v[107:114], v[17:24]// 00000015D964: CC404011 1C46D72D
	v_wmma_f32_16x16x16_f16 v[9:16], v[45:52], v[115:122], v[9:16]// 00000015D96C: CC404009 1C26E72D
	.long 0x7f5439ac                                           // 00000015D974: 7F5439AC
	.long 0x7e5439ac                                           // 00000015D978: 7E5439AC
	.long 0x7f5239ac                                           // 00000015D97C: 7F5239AC
	.long 0x7e5239ac                                           // 00000015D980: 7E5239AC
	s_and_saveexec_b32 s11, s0                                 // 00000015D984: BE8B2000
	s_cbranch_execz 11                                         // 00000015D988: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x45b8>
	global_load_b128 v[45:48], v[59:60], off offset:128        // 00000015D98C: DC5E0080 2D7C003B
	s_waitcnt vmcnt(0)                                         // 00000015D994: BF8903F7
	v_fma_mixlo_f16 v41, v45, s44, 0                           // 00000015D998: CC210029 0200592D
	v_fma_mixhi_f16 v41, v46, s44, 0                           // 00000015D9A0: CC220029 0200592E
	v_fma_mixlo_f16 v42, v47, s44, 0                           // 00000015D9A8: CC21002A 0200592F
	v_fma_mixhi_f16 v42, v48, s44, 0                           // 00000015D9B0: CC22002A 02005930
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015D9B8: 8C7E0B7E
	.long 0x7e5839ac                                           // 00000015D9BC: 7E5839AC
	.long 0x7f5639ac                                           // 00000015D9C0: 7F5639AC
	.long 0x7e5639ac                                           // 00000015D9C4: 7E5639AC
	s_and_saveexec_b32 s11, s0                                 // 00000015D9C8: BE8B2000
	s_cbranch_execz 11                                         // 00000015D9CC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x45fc>
	global_load_b128 v[43:46], v[59:60], off offset:144        // 00000015D9D0: DC5E0090 2B7C003B
	s_waitcnt vmcnt(0)                                         // 00000015D9D8: BF8903F7
	v_fma_mixlo_f16 v43, v43, s44, 0                           // 00000015D9DC: CC21002B 0200592B
	v_fma_mixhi_f16 v43, v44, s44, 0                           // 00000015D9E4: CC22002B 0200592C
	v_fma_mixlo_f16 v44, v45, s44, 0                           // 00000015D9EC: CC21002C 0200592D
	v_fma_mixhi_f16 v44, v46, s44, 0                           // 00000015D9F4: CC22002C 0200592E
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015D9FC: 8C7E0B7E
	.long 0x7f603880                                           // 00000015DA00: 7F603880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015DA04: BF870001
	.long 0x7f5c39b0                                           // 00000015DA08: 7F5C39B0
	.long 0x7e5c39b0                                           // 00000015DA0C: 7E5C39B0
	.long 0x7f5a39b0                                           // 00000015DA10: 7F5A39B0
	.long 0x7e5a39b0                                           // 00000015DA14: 7E5A39B0
	s_and_saveexec_b32 s11, s0                                 // 00000015DA18: BE8B2000
	s_cbranch_execz 11                                         // 00000015DA1C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x464c>
	global_load_b128 v[49:52], v[59:60], off offset:160        // 00000015DA20: DC5E00A0 317C003B
	s_waitcnt vmcnt(0)                                         // 00000015DA28: BF8903F7
	v_fma_mixlo_f16 v45, v49, s44, 0                           // 00000015DA2C: CC21002D 02005931
	v_fma_mixhi_f16 v45, v50, s44, 0                           // 00000015DA34: CC22002D 02005932
	v_fma_mixlo_f16 v46, v51, s44, 0                           // 00000015DA3C: CC21002E 02005933
	v_fma_mixhi_f16 v46, v52, s44, 0                           // 00000015DA44: CC22002E 02005934
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015DA4C: 8C7E0B7E
	.long 0x7e6039b0                                           // 00000015DA50: 7E6039B0
	.long 0x7f5e39b0                                           // 00000015DA54: 7F5E39B0
	.long 0x7e5e39b0                                           // 00000015DA58: 7E5E39B0
	s_and_saveexec_b32 s11, s0                                 // 00000015DA5C: BE8B2000
	s_cbranch_execz 11                                         // 00000015DA60: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4690>
	global_load_b128 v[47:50], v[59:60], off offset:176        // 00000015DA64: DC5E00B0 2F7C003B
	s_waitcnt vmcnt(0)                                         // 00000015DA6C: BF8903F7
	v_fma_mixlo_f16 v47, v47, s44, 0                           // 00000015DA70: CC21002F 0200592F
	v_fma_mixhi_f16 v47, v48, s44, 0                           // 00000015DA78: CC22002F 02005930
	v_fma_mixlo_f16 v48, v49, s44, 0                           // 00000015DA80: CC210030 02005931
	v_fma_mixhi_f16 v48, v50, s44, 0                           // 00000015DA88: CC220030 02005932
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015DA90: 8C7E0B7E
	ds_load_b128 v[50:53], v79 offset:128                      // 00000015DA94: DBFC0080 3200004F
	ds_load_b128 v[54:57], v79 offset:144                      // 00000015DA9C: DBFC0090 3600004F
	ds_load_b128 v[61:64], v79 offset:160                      // 00000015DAA4: DBFC00A0 3D00004F
	ds_load_b128 v[65:68], v79 offset:176                      // 00000015DAAC: DBFC00B0 4100004F
	ds_load_b128 v[69:72], v79 offset:8576                     // 00000015DAB4: DBFC2180 4500004F
	ds_load_b128 v[99:102], v79 offset:8592                    // 00000015DABC: DBFC2190 6300004F
	ds_load_b128 v[103:106], v79 offset:8608                   // 00000015DAC4: DBFC21A0 6700004F
	ds_load_b128 v[107:110], v79 offset:8624                   // 00000015DACC: DBFC21B0 6B00004F
	ds_load_b128 v[111:114], v79 offset:17024                  // 00000015DAD4: DBFC4280 6F00004F
	ds_load_b128 v[115:118], v79 offset:17056                  // 00000015DADC: DBFC42A0 7300004F
	ds_load_b128 v[119:122], v79 offset:17072                  // 00000015DAE4: DBFC42B0 7700004F
	.long 0x7f623880                                           // 00000015DAEC: 7F623880
	ds_load_b128 v[123:126], v79 offset:25488                  // 00000015DAF0: DBFC6390 7B00004F
	s_waitcnt lgkmcnt(11)                                      // 00000015DAF8: BF89FCB7
	v_fma_mixlo_f16 v50, v50, s44, 0                           // 00000015DAFC: CC210032 02005932
	v_fma_mixhi_f16 v50, v51, s44, 0                           // 00000015DB04: CC220032 02005933
	v_fma_mixlo_f16 v51, v52, s44, 0                           // 00000015DB0C: CC210033 02005934
	s_waitcnt lgkmcnt(10)                                      // 00000015DB14: BF89FCA7
	v_fma_mixlo_f16 v52, v54, s44, 0                           // 00000015DB18: CC210034 02005936
	s_waitcnt lgkmcnt(9)                                       // 00000015DB20: BF89FC97
	v_fma_mixlo_f16 v54, v61, s44, 0                           // 00000015DB24: CC210036 0200593D
	v_fma_mixhi_f16 v54, v62, s44, 0                           // 00000015DB2C: CC220036 0200593E
	s_waitcnt lgkmcnt(7)                                       // 00000015DB34: BF89FC77
	v_fma_mixlo_f16 v61, v69, s44, 0                           // 00000015DB38: CC21003D 02005945
	v_fma_mixhi_f16 v61, v70, s44, 0                           // 00000015DB40: CC22003D 02005946
	v_fma_mixlo_f16 v62, v71, s44, 0                           // 00000015DB48: CC21003E 02005947
	v_fma_mixhi_f16 v62, v72, s44, 0                           // 00000015DB50: CC22003E 02005948
	ds_load_b128 v[69:72], v79 offset:17040                    // 00000015DB58: DBFC4290 4500004F
	v_fma_mixhi_f16 v51, v53, s44, 0                           // 00000015DB60: CC220033 02005935
	v_fma_mixhi_f16 v52, v55, s44, 0                           // 00000015DB68: CC220034 02005937
	v_fma_mixhi_f16 v53, v57, s44, 0                           // 00000015DB70: CC220035 02005939
	v_fma_mixlo_f16 v55, v63, s44, 0                           // 00000015DB78: CC210037 0200593F
	v_fma_mixhi_f16 v55, v64, s44, 0                           // 00000015DB80: CC220037 02005940
	v_fma_mixlo_f16 v57, v67, s44, 0                           // 00000015DB88: CC210039 02005943
	v_fma_mixhi_f16 v57, v68, s44, 0                           // 00000015DB90: CC220039 02005944
	s_waitcnt lgkmcnt(7)                                       // 00000015DB98: BF89FC77
	v_fma_mixlo_f16 v63, v99, s44, 0                           // 00000015DB9C: CC21003F 02005963
	v_fma_mixhi_f16 v63, v100, s44, 0                          // 00000015DBA4: CC22003F 02005964
	v_fma_mixlo_f16 v64, v101, s44, 0                          // 00000015DBAC: CC210040 02005965
	v_fma_mixhi_f16 v64, v102, s44, 0                          // 00000015DBB4: CC220040 02005966
	s_waitcnt lgkmcnt(5)                                       // 00000015DBBC: BF89FC57
	v_fma_mixlo_f16 v67, v107, s44, 0                          // 00000015DBC0: CC210043 0200596B
	v_fma_mixhi_f16 v67, v108, s44, 0                          // 00000015DBC8: CC220043 0200596C
	v_fma_mixlo_f16 v68, v109, s44, 0                          // 00000015DBD0: CC210044 0200596D
	v_fma_mixhi_f16 v68, v110, s44, 0                          // 00000015DBD8: CC220044 0200596E
	ds_load_b128 v[107:110], v79 offset:25472                  // 00000015DBE0: DBFC6380 6B00004F
	s_waitcnt lgkmcnt(5)                                       // 00000015DBE8: BF89FC57
	v_fma_mixlo_f16 v99, v111, s44, 0                          // 00000015DBEC: CC210063 0200596F
	v_fma_mixhi_f16 v99, v112, s44, 0                          // 00000015DBF4: CC220063 02005970
	v_fma_mixlo_f16 v100, v113, s44, 0                         // 00000015DBFC: CC210064 02005971
	v_fma_mixhi_f16 v100, v114, s44, 0                         // 00000015DC04: CC220064 02005972
	s_waitcnt lgkmcnt(1)                                       // 00000015DC0C: BF89FC17
	v_fma_mixlo_f16 v101, v69, s44, 0                          // 00000015DC10: CC210065 02005945
	v_fma_mixhi_f16 v101, v70, s44, 0                          // 00000015DC18: CC220065 02005946
	ds_load_b128 v[111:114], v79 offset:25504                  // 00000015DC20: DBFC63A0 6F00004F
	v_fma_mixlo_f16 v102, v71, s44, 0                          // 00000015DC28: CC210066 02005947
	v_fma_mixhi_f16 v102, v72, s44, 0                          // 00000015DC30: CC220066 02005948
	ds_load_b128 v[69:72], v79 offset:25520                    // 00000015DC38: DBFC63B0 4500004F
	v_fma_mixlo_f16 v53, v56, s44, 0                           // 00000015DC40: CC210035 02005938
	v_fma_mixlo_f16 v56, v65, s44, 0                           // 00000015DC48: CC210038 02005941
	v_fma_mixhi_f16 v56, v66, s44, 0                           // 00000015DC50: CC220038 02005942
	v_fma_mixlo_f16 v65, v103, s44, 0                          // 00000015DC58: CC210041 02005967
	v_fma_mixhi_f16 v65, v104, s44, 0                          // 00000015DC60: CC220041 02005968
	v_fma_mixlo_f16 v66, v105, s44, 0                          // 00000015DC68: CC210042 02005969
	v_fma_mixhi_f16 v66, v106, s44, 0                          // 00000015DC70: CC220042 0200596A
	v_fma_mixlo_f16 v103, v115, s44, 0                         // 00000015DC78: CC210067 02005973
	v_fma_mixhi_f16 v103, v116, s44, 0                         // 00000015DC80: CC220067 02005974
	v_fma_mixlo_f16 v104, v117, s44, 0                         // 00000015DC88: CC210068 02005975
	v_fma_mixhi_f16 v104, v118, s44, 0                         // 00000015DC90: CC220068 02005976
	v_fma_mixlo_f16 v105, v119, s44, 0                         // 00000015DC98: CC210069 02005977
	v_fma_mixhi_f16 v105, v120, s44, 0                         // 00000015DCA0: CC220069 02005978
	v_fma_mixlo_f16 v106, v121, s44, 0                         // 00000015DCA8: CC21006A 02005979
	v_fma_mixhi_f16 v106, v122, s44, 0                         // 00000015DCB0: CC22006A 0200597A
	s_waitcnt lgkmcnt(2)                                       // 00000015DCB8: BF89FC27
	v_fma_mixlo_f16 v107, v107, s44, 0                         // 00000015DCBC: CC21006B 0200596B
	v_fma_mixhi_f16 v107, v108, s44, 0                         // 00000015DCC4: CC22006B 0200596C
	v_fma_mixlo_f16 v108, v109, s44, 0                         // 00000015DCCC: CC21006C 0200596D
	v_fma_mixhi_f16 v108, v110, s44, 0                         // 00000015DCD4: CC22006C 0200596E
	v_fma_mixlo_f16 v109, v123, s44, 0                         // 00000015DCDC: CC21006D 0200597B
	v_fma_mixhi_f16 v109, v124, s44, 0                         // 00000015DCE4: CC22006D 0200597C
	v_fma_mixlo_f16 v110, v125, s44, 0                         // 00000015DCEC: CC21006E 0200597D
	v_fma_mixhi_f16 v110, v126, s44, 0                         // 00000015DCF4: CC22006E 0200597E
	s_waitcnt lgkmcnt(1)                                       // 00000015DCFC: BF89FC17
	v_fma_mixlo_f16 v111, v111, s44, 0                         // 00000015DD00: CC21006F 0200596F
	v_fma_mixhi_f16 v111, v112, s44, 0                         // 00000015DD08: CC22006F 02005970
	v_fma_mixlo_f16 v112, v113, s44, 0                         // 00000015DD10: CC210070 02005971
	v_fma_mixhi_f16 v112, v114, s44, 0                         // 00000015DD18: CC220070 02005972
	s_waitcnt lgkmcnt(0)                                       // 00000015DD20: BF89FC07
	v_fma_mixlo_f16 v113, v69, s44, 0                          // 00000015DD24: CC210071 02005945
	v_fma_mixhi_f16 v113, v70, s44, 0                          // 00000015DD2C: CC220071 02005946
	v_fma_mixlo_f16 v114, v71, s44, 0                          // 00000015DD34: CC210072 02005947
	v_fma_mixhi_f16 v114, v72, s44, 0                          // 00000015DD3C: CC220072 02005948
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[50:57], v[33:40]// 00000015DD44: CC404021 1C866529
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[61:68], v[25:32]// 00000015DD4C: CC404019 1C667B29
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[99:106], v[17:24]// 00000015DD54: CC404011 1C46C729
	s_delay_alu instid0(VALU_DEP_4)                            // 00000015DD5C: BF870004
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[107:114], v[9:16]// 00000015DD60: CC404009 1C26D729
	.long 0x7f5e39b1                                           // 00000015DD68: 7F5E39B1
	.long 0x7e5e39b1                                           // 00000015DD6C: 7E5E39B1
	.long 0x7f5c39b1                                           // 00000015DD70: 7F5C39B1
	.long 0x7e5c39b1                                           // 00000015DD74: 7E5C39B1
	s_and_saveexec_b32 s11, s0                                 // 00000015DD78: BE8B2000
	s_cbranch_execz 11                                         // 00000015DD7C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x49ac>
	global_load_b128 v[41:44], v[59:60], off offset:192        // 00000015DD80: DC5E00C0 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015DD88: BF8903F7
	v_fma_mixlo_f16 v46, v41, s44, 0                           // 00000015DD8C: CC21002E 02005929
	v_fma_mixhi_f16 v46, v42, s44, 0                           // 00000015DD94: CC22002E 0200592A
	v_fma_mixlo_f16 v47, v43, s44, 0                           // 00000015DD9C: CC21002F 0200592B
	v_fma_mixhi_f16 v47, v44, s44, 0                           // 00000015DDA4: CC22002F 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015DDAC: 8C7E0B7E
	.long 0x7e6239b1                                           // 00000015DDB0: 7E6239B1
	.long 0x7f6039b1                                           // 00000015DDB4: 7F6039B1
	.long 0x7e6039b1                                           // 00000015DDB8: 7E6039B1
	s_and_saveexec_b32 s11, s0                                 // 00000015DDBC: BE8B2000
	s_cbranch_execz 11                                         // 00000015DDC0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x49f0>
	global_load_b128 v[41:44], v[59:60], off offset:208        // 00000015DDC4: DC5E00D0 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015DDCC: BF8903F7
	v_fma_mixlo_f16 v48, v41, s44, 0                           // 00000015DDD0: CC210030 02005929
	v_fma_mixhi_f16 v48, v42, s44, 0                           // 00000015DDD8: CC220030 0200592A
	v_fma_mixlo_f16 v49, v43, s44, 0                           // 00000015DDE0: CC210031 0200592B
	v_fma_mixhi_f16 v49, v44, s44, 0                           // 00000015DDE8: CC220031 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015DDF0: 8C7E0B7E
	.long 0x7f6a3880                                           // 00000015DDF4: 7F6A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015DDF8: BF870001
	.long 0x7f6639b5                                           // 00000015DDFC: 7F6639B5
	.long 0x7e6639b5                                           // 00000015DE00: 7E6639B5
	.long 0x7f6439b5                                           // 00000015DE04: 7F6439B5
	.long 0x7e6439b5                                           // 00000015DE08: 7E6439B5
	s_and_saveexec_b32 s11, s0                                 // 00000015DE0C: BE8B2000
	s_cbranch_execz 11                                         // 00000015DE10: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4a40>
	global_load_b128 v[41:44], v[59:60], off offset:224        // 00000015DE14: DC5E00E0 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015DE1C: BF8903F7
	v_fma_mixlo_f16 v50, v41, s44, 0                           // 00000015DE20: CC210032 02005929
	v_fma_mixhi_f16 v50, v42, s44, 0                           // 00000015DE28: CC220032 0200592A
	v_fma_mixlo_f16 v51, v43, s44, 0                           // 00000015DE30: CC210033 0200592B
	v_fma_mixhi_f16 v51, v44, s44, 0                           // 00000015DE38: CC220033 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015DE40: 8C7E0B7E
	.long 0x7e6a39b5                                           // 00000015DE44: 7E6A39B5
	.long 0x7f6839b5                                           // 00000015DE48: 7F6839B5
	.long 0x7e6839b5                                           // 00000015DE4C: 7E6839B5
	s_and_saveexec_b32 s11, s0                                 // 00000015DE50: BE8B2000
	s_cbranch_execz 11                                         // 00000015DE54: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4a84>
	global_load_b128 v[41:44], v[59:60], off offset:240        // 00000015DE58: DC5E00F0 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015DE60: BF8903F7
	v_fma_mixlo_f16 v52, v41, s44, 0                           // 00000015DE64: CC210034 02005929
	v_fma_mixhi_f16 v52, v42, s44, 0                           // 00000015DE6C: CC220034 0200592A
	v_fma_mixlo_f16 v53, v43, s44, 0                           // 00000015DE74: CC210035 0200592B
	v_fma_mixhi_f16 v53, v44, s44, 0                           // 00000015DE7C: CC220035 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015DE84: 8C7E0B7E
	ds_load_b128 v[41:44], v79 offset:192                      // 00000015DE88: DBFC00C0 2900004F
	ds_load_b128 v[54:57], v79 offset:208                      // 00000015DE90: DBFC00D0 3600004F
	ds_load_b128 v[65:68], v79 offset:224                      // 00000015DE98: DBFC00E0 4100004F
	ds_load_b128 v[69:72], v79 offset:240                      // 00000015DEA0: DBFC00F0 4500004F
	ds_load_b128 v[99:102], v79 offset:8640                    // 00000015DEA8: DBFC21C0 6300004F
	ds_load_b128 v[103:106], v79 offset:8656                   // 00000015DEB0: DBFC21D0 6700004F
	ds_load_b128 v[107:110], v79 offset:8672                   // 00000015DEB8: DBFC21E0 6B00004F
	ds_load_b128 v[111:114], v79 offset:8688                   // 00000015DEC0: DBFC21F0 6F00004F
	ds_load_b128 v[119:122], v79 offset:25536                  // 00000015DEC8: DBFC63C0 7700004F
	ds_load_b128 v[123:126], v79 offset:25552                  // 00000015DED0: DBFC63D0 7B00004F
	ds_load_b128 v[115:118], v79 offset:17136                  // 00000015DED8: DBFC42F0 7300004F
	s_waitcnt lgkmcnt(10)                                      // 00000015DEE0: BF89FCA7
	v_fma_mixlo_f16 v61, v41, s44, 0                           // 00000015DEE4: CC21003D 02005929
	v_fma_mixhi_f16 v61, v42, s44, 0                           // 00000015DEEC: CC22003D 0200592A
	v_fma_mixlo_f16 v62, v43, s44, 0                           // 00000015DEF4: CC21003E 0200592B
	v_fma_mixhi_f16 v62, v44, s44, 0                           // 00000015DEFC: CC22003E 0200592C
	s_waitcnt lgkmcnt(9)                                       // 00000015DF04: BF89FC97
	v_fma_mixlo_f16 v63, v54, s44, 0                           // 00000015DF08: CC21003F 02005936
	v_fma_mixhi_f16 v63, v55, s44, 0                           // 00000015DF10: CC22003F 02005937
	v_fma_mixlo_f16 v64, v56, s44, 0                           // 00000015DF18: CC210040 02005938
	v_fma_mixhi_f16 v64, v57, s44, 0                           // 00000015DF20: CC220040 02005939
	ds_load_b128 v[41:44], v79 offset:17088                    // 00000015DF28: DBFC42C0 2900004F
	ds_load_b128 v[54:57], v79 offset:17104                    // 00000015DF30: DBFC42D0 3600004F
	s_waitcnt lgkmcnt(10)                                      // 00000015DF38: BF89FCA7
	v_fma_mixlo_f16 v65, v65, s44, 0                           // 00000015DF3C: CC210041 02005941
	v_fma_mixhi_f16 v65, v66, s44, 0                           // 00000015DF44: CC220041 02005942
	v_fma_mixlo_f16 v66, v67, s44, 0                           // 00000015DF4C: CC210042 02005943
	v_fma_mixhi_f16 v66, v68, s44, 0                           // 00000015DF54: CC220042 02005944
	s_waitcnt lgkmcnt(9)                                       // 00000015DF5C: BF89FC97
	v_fma_mixlo_f16 v67, v69, s44, 0                           // 00000015DF60: CC210043 02005945
	v_fma_mixhi_f16 v67, v70, s44, 0                           // 00000015DF68: CC220043 02005946
	v_fma_mixlo_f16 v68, v71, s44, 0                           // 00000015DF70: CC210044 02005947
	v_fma_mixhi_f16 v68, v72, s44, 0                           // 00000015DF78: CC220044 02005948
	s_waitcnt lgkmcnt(8)                                       // 00000015DF80: BF89FC87
	v_fma_mixlo_f16 v99, v99, s44, 0                           // 00000015DF84: CC210063 02005963
	v_fma_mixhi_f16 v99, v100, s44, 0                          // 00000015DF8C: CC220063 02005964
	v_fma_mixlo_f16 v100, v101, s44, 0                         // 00000015DF94: CC210064 02005965
	s_waitcnt lgkmcnt(7)                                       // 00000015DF9C: BF89FC77
	v_fma_mixlo_f16 v101, v103, s44, 0                         // 00000015DFA0: CC210065 02005967
	v_fma_mixhi_f16 v101, v104, s44, 0                         // 00000015DFA8: CC220065 02005968
	s_waitcnt lgkmcnt(6)                                       // 00000015DFB0: BF89FC67
	v_fma_mixlo_f16 v103, v107, s44, 0                         // 00000015DFB4: CC210067 0200596B
	ds_load_b128 v[69:72], v79 offset:17120                    // 00000015DFBC: DBFC42E0 4500004F
	v_fma_mixhi_f16 v103, v108, s44, 0                         // 00000015DFC4: CC220067 0200596C
	v_fma_mixlo_f16 v104, v109, s44, 0                         // 00000015DFCC: CC210068 0200596D
	v_fma_mixhi_f16 v104, v110, s44, 0                         // 00000015DFD4: CC220068 0200596E
	s_waitcnt lgkmcnt(2)                                       // 00000015DFDC: BF89FC27
	v_fma_mixlo_f16 v107, v41, s44, 0                          // 00000015DFE0: CC21006B 02005929
	v_fma_mixhi_f16 v107, v42, s44, 0                          // 00000015DFE8: CC22006B 0200592A
	v_fma_mixlo_f16 v108, v43, s44, 0                          // 00000015DFF0: CC21006C 0200592B
	v_fma_mixhi_f16 v108, v44, s44, 0                          // 00000015DFF8: CC22006C 0200592C
	s_waitcnt lgkmcnt(1)                                       // 00000015E000: BF89FC17
	v_fma_mixlo_f16 v109, v54, s44, 0                          // 00000015E004: CC21006D 02005936
	v_fma_mixhi_f16 v109, v55, s44, 0                          // 00000015E00C: CC22006D 02005937
	ds_load_b128 v[41:44], v79 offset:25568                    // 00000015E014: DBFC63E0 2900004F
	v_fma_mixlo_f16 v110, v56, s44, 0                          // 00000015E01C: CC21006E 02005938
	v_fma_mixhi_f16 v110, v57, s44, 0                          // 00000015E024: CC22006E 02005939
	ds_load_b128 v[54:57], v79 offset:25584                    // 00000015E02C: DBFC63F0 3600004F
	v_fma_mixhi_f16 v100, v102, s44, 0                         // 00000015E034: CC220064 02005966
	v_fma_mixlo_f16 v102, v105, s44, 0                         // 00000015E03C: CC210066 02005969
	v_fma_mixhi_f16 v102, v106, s44, 0                         // 00000015E044: CC220066 0200596A
	v_fma_mixlo_f16 v105, v111, s44, 0                         // 00000015E04C: CC210069 0200596F
	v_fma_mixhi_f16 v105, v112, s44, 0                         // 00000015E054: CC220069 02005970
	v_fma_mixlo_f16 v106, v113, s44, 0                         // 00000015E05C: CC21006A 02005971
	v_fma_mixhi_f16 v106, v114, s44, 0                         // 00000015E064: CC22006A 02005972
	s_waitcnt lgkmcnt(2)                                       // 00000015E06C: BF89FC27
	v_fma_mixlo_f16 v111, v69, s44, 0                          // 00000015E070: CC21006F 02005945
	v_fma_mixhi_f16 v111, v70, s44, 0                          // 00000015E078: CC22006F 02005946
	v_fma_mixlo_f16 v112, v71, s44, 0                          // 00000015E080: CC210070 02005947
	v_fma_mixhi_f16 v112, v72, s44, 0                          // 00000015E088: CC220070 02005948
	v_fma_mixlo_f16 v113, v115, s44, 0                         // 00000015E090: CC210071 02005973
	v_fma_mixhi_f16 v113, v116, s44, 0                         // 00000015E098: CC220071 02005974
	v_fma_mixlo_f16 v114, v117, s44, 0                         // 00000015E0A0: CC210072 02005975
	v_fma_mixhi_f16 v114, v118, s44, 0                         // 00000015E0A8: CC220072 02005976
	v_fma_mixlo_f16 v115, v119, s44, 0                         // 00000015E0B0: CC210073 02005977
	v_fma_mixhi_f16 v115, v120, s44, 0                         // 00000015E0B8: CC220073 02005978
	v_fma_mixlo_f16 v116, v121, s44, 0                         // 00000015E0C0: CC210074 02005979
	v_fma_mixhi_f16 v116, v122, s44, 0                         // 00000015E0C8: CC220074 0200597A
	v_fma_mixlo_f16 v117, v123, s44, 0                         // 00000015E0D0: CC210075 0200597B
	v_fma_mixhi_f16 v117, v124, s44, 0                         // 00000015E0D8: CC220075 0200597C
	v_fma_mixlo_f16 v118, v125, s44, 0                         // 00000015E0E0: CC210076 0200597D
	v_fma_mixhi_f16 v118, v126, s44, 0                         // 00000015E0E8: CC220076 0200597E
	s_waitcnt lgkmcnt(1)                                       // 00000015E0F0: BF89FC17
	v_fma_mixlo_f16 v119, v41, s44, 0                          // 00000015E0F4: CC210077 02005929
	v_fma_mixhi_f16 v119, v42, s44, 0                          // 00000015E0FC: CC220077 0200592A
	v_fma_mixlo_f16 v120, v43, s44, 0                          // 00000015E104: CC210078 0200592B
	v_fma_mixhi_f16 v120, v44, s44, 0                          // 00000015E10C: CC220078 0200592C
	s_waitcnt lgkmcnt(0)                                       // 00000015E114: BF89FC07
	v_fma_mixlo_f16 v121, v54, s44, 0                          // 00000015E118: CC210079 02005936
	v_fma_mixhi_f16 v121, v55, s44, 0                          // 00000015E120: CC220079 02005937
	v_fma_mixlo_f16 v122, v56, s44, 0                          // 00000015E128: CC21007A 02005938
	v_fma_mixhi_f16 v122, v57, s44, 0                          // 00000015E130: CC22007A 02005939
	.long 0x7f583880                                           // 00000015E138: 7F583880
	v_wmma_f32_16x16x16_f16 v[33:40], v[46:53], v[61:68], v[33:40]// 00000015E13C: CC404021 1C867B2E
	v_wmma_f32_16x16x16_f16 v[25:32], v[46:53], v[99:106], v[25:32]// 00000015E144: CC404019 1C66C72E
	v_wmma_f32_16x16x16_f16 v[17:24], v[46:53], v[107:114], v[17:24]// 00000015E14C: CC404011 1C46D72E
	v_wmma_f32_16x16x16_f16 v[9:16], v[46:53], v[115:122], v[9:16]// 00000015E154: CC404009 1C26E72E
	.long 0x7f5439ac                                           // 00000015E15C: 7F5439AC
	.long 0x7e5439ac                                           // 00000015E160: 7E5439AC
	.long 0x7f5239ac                                           // 00000015E164: 7F5239AC
	.long 0x7e5239ac                                           // 00000015E168: 7E5239AC
	s_and_saveexec_b32 s11, s0                                 // 00000015E16C: BE8B2000
	s_cbranch_execz 11                                         // 00000015E170: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4da0>
	global_load_b128 v[45:48], v[59:60], off offset:256        // 00000015E174: DC5E0100 2D7C003B
	s_waitcnt vmcnt(0)                                         // 00000015E17C: BF8903F7
	v_fma_mixlo_f16 v41, v45, s44, 0                           // 00000015E180: CC210029 0200592D
	v_fma_mixhi_f16 v41, v46, s44, 0                           // 00000015E188: CC220029 0200592E
	v_fma_mixlo_f16 v42, v47, s44, 0                           // 00000015E190: CC21002A 0200592F
	v_fma_mixhi_f16 v42, v48, s44, 0                           // 00000015E198: CC22002A 02005930
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015E1A0: 8C7E0B7E
	.long 0x7e5839ac                                           // 00000015E1A4: 7E5839AC
	.long 0x7f5639ac                                           // 00000015E1A8: 7F5639AC
	.long 0x7e5639ac                                           // 00000015E1AC: 7E5639AC
	s_and_saveexec_b32 s11, s0                                 // 00000015E1B0: BE8B2000
	s_cbranch_execz 11                                         // 00000015E1B4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4de4>
	global_load_b128 v[43:46], v[59:60], off offset:272        // 00000015E1B8: DC5E0110 2B7C003B
	s_waitcnt vmcnt(0)                                         // 00000015E1C0: BF8903F7
	v_fma_mixlo_f16 v43, v43, s44, 0                           // 00000015E1C4: CC21002B 0200592B
	v_fma_mixhi_f16 v43, v44, s44, 0                           // 00000015E1CC: CC22002B 0200592C
	v_fma_mixlo_f16 v44, v45, s44, 0                           // 00000015E1D4: CC21002C 0200592D
	v_fma_mixhi_f16 v44, v46, s44, 0                           // 00000015E1DC: CC22002C 0200592E
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015E1E4: 8C7E0B7E
	.long 0x7f603880                                           // 00000015E1E8: 7F603880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015E1EC: BF870001
	.long 0x7f5c39b0                                           // 00000015E1F0: 7F5C39B0
	.long 0x7e5c39b0                                           // 00000015E1F4: 7E5C39B0
	.long 0x7f5a39b0                                           // 00000015E1F8: 7F5A39B0
	.long 0x7e5a39b0                                           // 00000015E1FC: 7E5A39B0
	s_and_saveexec_b32 s11, s0                                 // 00000015E200: BE8B2000
	s_cbranch_execz 11                                         // 00000015E204: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4e34>
	global_load_b128 v[49:52], v[59:60], off offset:288        // 00000015E208: DC5E0120 317C003B
	s_waitcnt vmcnt(0)                                         // 00000015E210: BF8903F7
	v_fma_mixlo_f16 v45, v49, s44, 0                           // 00000015E214: CC21002D 02005931
	v_fma_mixhi_f16 v45, v50, s44, 0                           // 00000015E21C: CC22002D 02005932
	v_fma_mixlo_f16 v46, v51, s44, 0                           // 00000015E224: CC21002E 02005933
	v_fma_mixhi_f16 v46, v52, s44, 0                           // 00000015E22C: CC22002E 02005934
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015E234: 8C7E0B7E
	.long 0x7e6039b0                                           // 00000015E238: 7E6039B0
	.long 0x7f5e39b0                                           // 00000015E23C: 7F5E39B0
	.long 0x7e5e39b0                                           // 00000015E240: 7E5E39B0
	s_and_saveexec_b32 s11, s0                                 // 00000015E244: BE8B2000
	s_cbranch_execz 11                                         // 00000015E248: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4e78>
	global_load_b128 v[47:50], v[59:60], off offset:304        // 00000015E24C: DC5E0130 2F7C003B
	s_waitcnt vmcnt(0)                                         // 00000015E254: BF8903F7
	v_fma_mixlo_f16 v47, v47, s44, 0                           // 00000015E258: CC21002F 0200592F
	v_fma_mixhi_f16 v47, v48, s44, 0                           // 00000015E260: CC22002F 02005930
	v_fma_mixlo_f16 v48, v49, s44, 0                           // 00000015E268: CC210030 02005931
	v_fma_mixhi_f16 v48, v50, s44, 0                           // 00000015E270: CC220030 02005932
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015E278: 8C7E0B7E
	ds_load_b128 v[50:53], v79 offset:256                      // 00000015E27C: DBFC0100 3200004F
	ds_load_b128 v[54:57], v79 offset:272                      // 00000015E284: DBFC0110 3600004F
	ds_load_b128 v[61:64], v79 offset:288                      // 00000015E28C: DBFC0120 3D00004F
	ds_load_b128 v[65:68], v79 offset:304                      // 00000015E294: DBFC0130 4100004F
	ds_load_b128 v[69:72], v79 offset:8704                     // 00000015E29C: DBFC2200 4500004F
	ds_load_b128 v[99:102], v79 offset:8720                    // 00000015E2A4: DBFC2210 6300004F
	ds_load_b128 v[103:106], v79 offset:8736                   // 00000015E2AC: DBFC2220 6700004F
	ds_load_b128 v[107:110], v79 offset:8752                   // 00000015E2B4: DBFC2230 6B00004F
	ds_load_b128 v[111:114], v79 offset:17152                  // 00000015E2BC: DBFC4300 6F00004F
	ds_load_b128 v[115:118], v79 offset:17184                  // 00000015E2C4: DBFC4320 7300004F
	ds_load_b128 v[119:122], v79 offset:17200                  // 00000015E2CC: DBFC4330 7700004F
	.long 0x7f623880                                           // 00000015E2D4: 7F623880
	ds_load_b128 v[123:126], v79 offset:25616                  // 00000015E2D8: DBFC6410 7B00004F
	s_waitcnt lgkmcnt(11)                                      // 00000015E2E0: BF89FCB7
	v_fma_mixlo_f16 v50, v50, s44, 0                           // 00000015E2E4: CC210032 02005932
	v_fma_mixhi_f16 v50, v51, s44, 0                           // 00000015E2EC: CC220032 02005933
	v_fma_mixlo_f16 v51, v52, s44, 0                           // 00000015E2F4: CC210033 02005934
	s_waitcnt lgkmcnt(10)                                      // 00000015E2FC: BF89FCA7
	v_fma_mixlo_f16 v52, v54, s44, 0                           // 00000015E300: CC210034 02005936
	s_waitcnt lgkmcnt(9)                                       // 00000015E308: BF89FC97
	v_fma_mixlo_f16 v54, v61, s44, 0                           // 00000015E30C: CC210036 0200593D
	v_fma_mixhi_f16 v54, v62, s44, 0                           // 00000015E314: CC220036 0200593E
	s_waitcnt lgkmcnt(7)                                       // 00000015E31C: BF89FC77
	v_fma_mixlo_f16 v61, v69, s44, 0                           // 00000015E320: CC21003D 02005945
	v_fma_mixhi_f16 v61, v70, s44, 0                           // 00000015E328: CC22003D 02005946
	v_fma_mixlo_f16 v62, v71, s44, 0                           // 00000015E330: CC21003E 02005947
	v_fma_mixhi_f16 v62, v72, s44, 0                           // 00000015E338: CC22003E 02005948
	ds_load_b128 v[69:72], v79 offset:17168                    // 00000015E340: DBFC4310 4500004F
	v_fma_mixhi_f16 v51, v53, s44, 0                           // 00000015E348: CC220033 02005935
	v_fma_mixhi_f16 v52, v55, s44, 0                           // 00000015E350: CC220034 02005937
	v_fma_mixhi_f16 v53, v57, s44, 0                           // 00000015E358: CC220035 02005939
	v_fma_mixlo_f16 v55, v63, s44, 0                           // 00000015E360: CC210037 0200593F
	v_fma_mixhi_f16 v55, v64, s44, 0                           // 00000015E368: CC220037 02005940
	v_fma_mixlo_f16 v57, v67, s44, 0                           // 00000015E370: CC210039 02005943
	v_fma_mixhi_f16 v57, v68, s44, 0                           // 00000015E378: CC220039 02005944
	s_waitcnt lgkmcnt(7)                                       // 00000015E380: BF89FC77
	v_fma_mixlo_f16 v63, v99, s44, 0                           // 00000015E384: CC21003F 02005963
	v_fma_mixhi_f16 v63, v100, s44, 0                          // 00000015E38C: CC22003F 02005964
	v_fma_mixlo_f16 v64, v101, s44, 0                          // 00000015E394: CC210040 02005965
	v_fma_mixhi_f16 v64, v102, s44, 0                          // 00000015E39C: CC220040 02005966
	s_waitcnt lgkmcnt(5)                                       // 00000015E3A4: BF89FC57
	v_fma_mixlo_f16 v67, v107, s44, 0                          // 00000015E3A8: CC210043 0200596B
	v_fma_mixhi_f16 v67, v108, s44, 0                          // 00000015E3B0: CC220043 0200596C
	v_fma_mixlo_f16 v68, v109, s44, 0                          // 00000015E3B8: CC210044 0200596D
	v_fma_mixhi_f16 v68, v110, s44, 0                          // 00000015E3C0: CC220044 0200596E
	ds_load_b128 v[107:110], v79 offset:25600                  // 00000015E3C8: DBFC6400 6B00004F
	s_waitcnt lgkmcnt(5)                                       // 00000015E3D0: BF89FC57
	v_fma_mixlo_f16 v99, v111, s44, 0                          // 00000015E3D4: CC210063 0200596F
	v_fma_mixhi_f16 v99, v112, s44, 0                          // 00000015E3DC: CC220063 02005970
	v_fma_mixlo_f16 v100, v113, s44, 0                         // 00000015E3E4: CC210064 02005971
	v_fma_mixhi_f16 v100, v114, s44, 0                         // 00000015E3EC: CC220064 02005972
	s_waitcnt lgkmcnt(1)                                       // 00000015E3F4: BF89FC17
	v_fma_mixlo_f16 v101, v69, s44, 0                          // 00000015E3F8: CC210065 02005945
	v_fma_mixhi_f16 v101, v70, s44, 0                          // 00000015E400: CC220065 02005946
	ds_load_b128 v[111:114], v79 offset:25632                  // 00000015E408: DBFC6420 6F00004F
	v_fma_mixlo_f16 v102, v71, s44, 0                          // 00000015E410: CC210066 02005947
	v_fma_mixhi_f16 v102, v72, s44, 0                          // 00000015E418: CC220066 02005948
	ds_load_b128 v[69:72], v79 offset:25648                    // 00000015E420: DBFC6430 4500004F
	v_fma_mixlo_f16 v53, v56, s44, 0                           // 00000015E428: CC210035 02005938
	v_fma_mixlo_f16 v56, v65, s44, 0                           // 00000015E430: CC210038 02005941
	v_fma_mixhi_f16 v56, v66, s44, 0                           // 00000015E438: CC220038 02005942
	v_fma_mixlo_f16 v65, v103, s44, 0                          // 00000015E440: CC210041 02005967
	v_fma_mixhi_f16 v65, v104, s44, 0                          // 00000015E448: CC220041 02005968
	v_fma_mixlo_f16 v66, v105, s44, 0                          // 00000015E450: CC210042 02005969
	v_fma_mixhi_f16 v66, v106, s44, 0                          // 00000015E458: CC220042 0200596A
	v_fma_mixlo_f16 v103, v115, s44, 0                         // 00000015E460: CC210067 02005973
	v_fma_mixhi_f16 v103, v116, s44, 0                         // 00000015E468: CC220067 02005974
	v_fma_mixlo_f16 v104, v117, s44, 0                         // 00000015E470: CC210068 02005975
	v_fma_mixhi_f16 v104, v118, s44, 0                         // 00000015E478: CC220068 02005976
	v_fma_mixlo_f16 v105, v119, s44, 0                         // 00000015E480: CC210069 02005977
	v_fma_mixhi_f16 v105, v120, s44, 0                         // 00000015E488: CC220069 02005978
	v_fma_mixlo_f16 v106, v121, s44, 0                         // 00000015E490: CC21006A 02005979
	v_fma_mixhi_f16 v106, v122, s44, 0                         // 00000015E498: CC22006A 0200597A
	s_waitcnt lgkmcnt(2)                                       // 00000015E4A0: BF89FC27
	v_fma_mixlo_f16 v107, v107, s44, 0                         // 00000015E4A4: CC21006B 0200596B
	v_fma_mixhi_f16 v107, v108, s44, 0                         // 00000015E4AC: CC22006B 0200596C
	v_fma_mixlo_f16 v108, v109, s44, 0                         // 00000015E4B4: CC21006C 0200596D
	v_fma_mixhi_f16 v108, v110, s44, 0                         // 00000015E4BC: CC22006C 0200596E
	v_fma_mixlo_f16 v109, v123, s44, 0                         // 00000015E4C4: CC21006D 0200597B
	v_fma_mixhi_f16 v109, v124, s44, 0                         // 00000015E4CC: CC22006D 0200597C
	v_fma_mixlo_f16 v110, v125, s44, 0                         // 00000015E4D4: CC21006E 0200597D
	v_fma_mixhi_f16 v110, v126, s44, 0                         // 00000015E4DC: CC22006E 0200597E
	s_waitcnt lgkmcnt(1)                                       // 00000015E4E4: BF89FC17
	v_fma_mixlo_f16 v111, v111, s44, 0                         // 00000015E4E8: CC21006F 0200596F
	v_fma_mixhi_f16 v111, v112, s44, 0                         // 00000015E4F0: CC22006F 02005970
	v_fma_mixlo_f16 v112, v113, s44, 0                         // 00000015E4F8: CC210070 02005971
	v_fma_mixhi_f16 v112, v114, s44, 0                         // 00000015E500: CC220070 02005972
	s_waitcnt lgkmcnt(0)                                       // 00000015E508: BF89FC07
	v_fma_mixlo_f16 v113, v69, s44, 0                          // 00000015E50C: CC210071 02005945
	v_fma_mixhi_f16 v113, v70, s44, 0                          // 00000015E514: CC220071 02005946
	v_fma_mixlo_f16 v114, v71, s44, 0                          // 00000015E51C: CC210072 02005947
	v_fma_mixhi_f16 v114, v72, s44, 0                          // 00000015E524: CC220072 02005948
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[50:57], v[33:40]// 00000015E52C: CC404021 1C866529
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[61:68], v[25:32]// 00000015E534: CC404019 1C667B29
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[99:106], v[17:24]// 00000015E53C: CC404011 1C46C729
	s_delay_alu instid0(VALU_DEP_4)                            // 00000015E544: BF870004
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[107:114], v[9:16]// 00000015E548: CC404009 1C26D729
	.long 0x7f5e39b1                                           // 00000015E550: 7F5E39B1
	.long 0x7e5e39b1                                           // 00000015E554: 7E5E39B1
	.long 0x7f5c39b1                                           // 00000015E558: 7F5C39B1
	.long 0x7e5c39b1                                           // 00000015E55C: 7E5C39B1
	s_and_saveexec_b32 s11, s0                                 // 00000015E560: BE8B2000
	s_cbranch_execz 11                                         // 00000015E564: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5194>
	global_load_b128 v[41:44], v[59:60], off offset:320        // 00000015E568: DC5E0140 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015E570: BF8903F7
	v_fma_mixlo_f16 v46, v41, s44, 0                           // 00000015E574: CC21002E 02005929
	v_fma_mixhi_f16 v46, v42, s44, 0                           // 00000015E57C: CC22002E 0200592A
	v_fma_mixlo_f16 v47, v43, s44, 0                           // 00000015E584: CC21002F 0200592B
	v_fma_mixhi_f16 v47, v44, s44, 0                           // 00000015E58C: CC22002F 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015E594: 8C7E0B7E
	.long 0x7e6239b1                                           // 00000015E598: 7E6239B1
	.long 0x7f6039b1                                           // 00000015E59C: 7F6039B1
	.long 0x7e6039b1                                           // 00000015E5A0: 7E6039B1
	s_and_saveexec_b32 s11, s0                                 // 00000015E5A4: BE8B2000
	s_cbranch_execz 11                                         // 00000015E5A8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51d8>
	global_load_b128 v[41:44], v[59:60], off offset:336        // 00000015E5AC: DC5E0150 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015E5B4: BF8903F7
	v_fma_mixlo_f16 v48, v41, s44, 0                           // 00000015E5B8: CC210030 02005929
	v_fma_mixhi_f16 v48, v42, s44, 0                           // 00000015E5C0: CC220030 0200592A
	v_fma_mixlo_f16 v49, v43, s44, 0                           // 00000015E5C8: CC210031 0200592B
	v_fma_mixhi_f16 v49, v44, s44, 0                           // 00000015E5D0: CC220031 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015E5D8: 8C7E0B7E
	.long 0x7f6a3880                                           // 00000015E5DC: 7F6A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015E5E0: BF870001
	.long 0x7f6639b5                                           // 00000015E5E4: 7F6639B5
	.long 0x7e6639b5                                           // 00000015E5E8: 7E6639B5
	.long 0x7f6439b5                                           // 00000015E5EC: 7F6439B5
	.long 0x7e6439b5                                           // 00000015E5F0: 7E6439B5
	s_and_saveexec_b32 s11, s0                                 // 00000015E5F4: BE8B2000
	s_cbranch_execz 11                                         // 00000015E5F8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5228>
	global_load_b128 v[41:44], v[59:60], off offset:352        // 00000015E5FC: DC5E0160 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015E604: BF8903F7
	v_fma_mixlo_f16 v50, v41, s44, 0                           // 00000015E608: CC210032 02005929
	v_fma_mixhi_f16 v50, v42, s44, 0                           // 00000015E610: CC220032 0200592A
	v_fma_mixlo_f16 v51, v43, s44, 0                           // 00000015E618: CC210033 0200592B
	v_fma_mixhi_f16 v51, v44, s44, 0                           // 00000015E620: CC220033 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015E628: 8C7E0B7E
	.long 0x7e6a39b5                                           // 00000015E62C: 7E6A39B5
	.long 0x7f6839b5                                           // 00000015E630: 7F6839B5
	.long 0x7e6839b5                                           // 00000015E634: 7E6839B5
	s_and_saveexec_b32 s11, s0                                 // 00000015E638: BE8B2000
	s_cbranch_execz 11                                         // 00000015E63C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x526c>
	global_load_b128 v[41:44], v[59:60], off offset:368        // 00000015E640: DC5E0170 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015E648: BF8903F7
	v_fma_mixlo_f16 v52, v41, s44, 0                           // 00000015E64C: CC210034 02005929
	v_fma_mixhi_f16 v52, v42, s44, 0                           // 00000015E654: CC220034 0200592A
	v_fma_mixlo_f16 v53, v43, s44, 0                           // 00000015E65C: CC210035 0200592B
	v_fma_mixhi_f16 v53, v44, s44, 0                           // 00000015E664: CC220035 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015E66C: 8C7E0B7E
	ds_load_b128 v[41:44], v79 offset:320                      // 00000015E670: DBFC0140 2900004F
	ds_load_b128 v[54:57], v79 offset:336                      // 00000015E678: DBFC0150 3600004F
	ds_load_b128 v[65:68], v79 offset:352                      // 00000015E680: DBFC0160 4100004F
	ds_load_b128 v[69:72], v79 offset:368                      // 00000015E688: DBFC0170 4500004F
	ds_load_b128 v[99:102], v79 offset:8768                    // 00000015E690: DBFC2240 6300004F
	ds_load_b128 v[103:106], v79 offset:8784                   // 00000015E698: DBFC2250 6700004F
	ds_load_b128 v[107:110], v79 offset:8800                   // 00000015E6A0: DBFC2260 6B00004F
	ds_load_b128 v[111:114], v79 offset:8816                   // 00000015E6A8: DBFC2270 6F00004F
	ds_load_b128 v[119:122], v79 offset:25664                  // 00000015E6B0: DBFC6440 7700004F
	ds_load_b128 v[123:126], v79 offset:25680                  // 00000015E6B8: DBFC6450 7B00004F
	ds_load_b128 v[115:118], v79 offset:17264                  // 00000015E6C0: DBFC4370 7300004F
	s_waitcnt lgkmcnt(10)                                      // 00000015E6C8: BF89FCA7
	v_fma_mixlo_f16 v61, v41, s44, 0                           // 00000015E6CC: CC21003D 02005929
	v_fma_mixhi_f16 v61, v42, s44, 0                           // 00000015E6D4: CC22003D 0200592A
	v_fma_mixlo_f16 v62, v43, s44, 0                           // 00000015E6DC: CC21003E 0200592B
	v_fma_mixhi_f16 v62, v44, s44, 0                           // 00000015E6E4: CC22003E 0200592C
	s_waitcnt lgkmcnt(9)                                       // 00000015E6EC: BF89FC97
	v_fma_mixlo_f16 v63, v54, s44, 0                           // 00000015E6F0: CC21003F 02005936
	v_fma_mixhi_f16 v63, v55, s44, 0                           // 00000015E6F8: CC22003F 02005937
	v_fma_mixlo_f16 v64, v56, s44, 0                           // 00000015E700: CC210040 02005938
	v_fma_mixhi_f16 v64, v57, s44, 0                           // 00000015E708: CC220040 02005939
	ds_load_b128 v[41:44], v79 offset:17216                    // 00000015E710: DBFC4340 2900004F
	ds_load_b128 v[54:57], v79 offset:17232                    // 00000015E718: DBFC4350 3600004F
	s_waitcnt lgkmcnt(10)                                      // 00000015E720: BF89FCA7
	v_fma_mixlo_f16 v65, v65, s44, 0                           // 00000015E724: CC210041 02005941
	v_fma_mixhi_f16 v65, v66, s44, 0                           // 00000015E72C: CC220041 02005942
	v_fma_mixlo_f16 v66, v67, s44, 0                           // 00000015E734: CC210042 02005943
	v_fma_mixhi_f16 v66, v68, s44, 0                           // 00000015E73C: CC220042 02005944
	s_waitcnt lgkmcnt(9)                                       // 00000015E744: BF89FC97
	v_fma_mixlo_f16 v67, v69, s44, 0                           // 00000015E748: CC210043 02005945
	v_fma_mixhi_f16 v67, v70, s44, 0                           // 00000015E750: CC220043 02005946
	v_fma_mixlo_f16 v68, v71, s44, 0                           // 00000015E758: CC210044 02005947
	v_fma_mixhi_f16 v68, v72, s44, 0                           // 00000015E760: CC220044 02005948
	s_waitcnt lgkmcnt(8)                                       // 00000015E768: BF89FC87
	v_fma_mixlo_f16 v99, v99, s44, 0                           // 00000015E76C: CC210063 02005963
	v_fma_mixhi_f16 v99, v100, s44, 0                          // 00000015E774: CC220063 02005964
	v_fma_mixlo_f16 v100, v101, s44, 0                         // 00000015E77C: CC210064 02005965
	s_waitcnt lgkmcnt(7)                                       // 00000015E784: BF89FC77
	v_fma_mixlo_f16 v101, v103, s44, 0                         // 00000015E788: CC210065 02005967
	v_fma_mixhi_f16 v101, v104, s44, 0                         // 00000015E790: CC220065 02005968
	s_waitcnt lgkmcnt(6)                                       // 00000015E798: BF89FC67
	v_fma_mixlo_f16 v103, v107, s44, 0                         // 00000015E79C: CC210067 0200596B
	ds_load_b128 v[69:72], v79 offset:17248                    // 00000015E7A4: DBFC4360 4500004F
	v_fma_mixhi_f16 v103, v108, s44, 0                         // 00000015E7AC: CC220067 0200596C
	v_fma_mixlo_f16 v104, v109, s44, 0                         // 00000015E7B4: CC210068 0200596D
	v_fma_mixhi_f16 v104, v110, s44, 0                         // 00000015E7BC: CC220068 0200596E
	s_waitcnt lgkmcnt(2)                                       // 00000015E7C4: BF89FC27
	v_fma_mixlo_f16 v107, v41, s44, 0                          // 00000015E7C8: CC21006B 02005929
	v_fma_mixhi_f16 v107, v42, s44, 0                          // 00000015E7D0: CC22006B 0200592A
	v_fma_mixlo_f16 v108, v43, s44, 0                          // 00000015E7D8: CC21006C 0200592B
	v_fma_mixhi_f16 v108, v44, s44, 0                          // 00000015E7E0: CC22006C 0200592C
	s_waitcnt lgkmcnt(1)                                       // 00000015E7E8: BF89FC17
	v_fma_mixlo_f16 v109, v54, s44, 0                          // 00000015E7EC: CC21006D 02005936
	v_fma_mixhi_f16 v109, v55, s44, 0                          // 00000015E7F4: CC22006D 02005937
	ds_load_b128 v[41:44], v79 offset:25696                    // 00000015E7FC: DBFC6460 2900004F
	v_fma_mixlo_f16 v110, v56, s44, 0                          // 00000015E804: CC21006E 02005938
	v_fma_mixhi_f16 v110, v57, s44, 0                          // 00000015E80C: CC22006E 02005939
	ds_load_b128 v[54:57], v79 offset:25712                    // 00000015E814: DBFC6470 3600004F
	v_fma_mixhi_f16 v100, v102, s44, 0                         // 00000015E81C: CC220064 02005966
	v_fma_mixlo_f16 v102, v105, s44, 0                         // 00000015E824: CC210066 02005969
	v_fma_mixhi_f16 v102, v106, s44, 0                         // 00000015E82C: CC220066 0200596A
	v_fma_mixlo_f16 v105, v111, s44, 0                         // 00000015E834: CC210069 0200596F
	v_fma_mixhi_f16 v105, v112, s44, 0                         // 00000015E83C: CC220069 02005970
	v_fma_mixlo_f16 v106, v113, s44, 0                         // 00000015E844: CC21006A 02005971
	v_fma_mixhi_f16 v106, v114, s44, 0                         // 00000015E84C: CC22006A 02005972
	s_waitcnt lgkmcnt(2)                                       // 00000015E854: BF89FC27
	v_fma_mixlo_f16 v111, v69, s44, 0                          // 00000015E858: CC21006F 02005945
	v_fma_mixhi_f16 v111, v70, s44, 0                          // 00000015E860: CC22006F 02005946
	v_fma_mixlo_f16 v112, v71, s44, 0                          // 00000015E868: CC210070 02005947
	v_fma_mixhi_f16 v112, v72, s44, 0                          // 00000015E870: CC220070 02005948
	v_fma_mixlo_f16 v113, v115, s44, 0                         // 00000015E878: CC210071 02005973
	v_fma_mixhi_f16 v113, v116, s44, 0                         // 00000015E880: CC220071 02005974
	v_fma_mixlo_f16 v114, v117, s44, 0                         // 00000015E888: CC210072 02005975
	v_fma_mixhi_f16 v114, v118, s44, 0                         // 00000015E890: CC220072 02005976
	v_fma_mixlo_f16 v115, v119, s44, 0                         // 00000015E898: CC210073 02005977
	v_fma_mixhi_f16 v115, v120, s44, 0                         // 00000015E8A0: CC220073 02005978
	v_fma_mixlo_f16 v116, v121, s44, 0                         // 00000015E8A8: CC210074 02005979
	v_fma_mixhi_f16 v116, v122, s44, 0                         // 00000015E8B0: CC220074 0200597A
	v_fma_mixlo_f16 v117, v123, s44, 0                         // 00000015E8B8: CC210075 0200597B
	v_fma_mixhi_f16 v117, v124, s44, 0                         // 00000015E8C0: CC220075 0200597C
	v_fma_mixlo_f16 v118, v125, s44, 0                         // 00000015E8C8: CC210076 0200597D
	v_fma_mixhi_f16 v118, v126, s44, 0                         // 00000015E8D0: CC220076 0200597E
	s_waitcnt lgkmcnt(1)                                       // 00000015E8D8: BF89FC17
	v_fma_mixlo_f16 v119, v41, s44, 0                          // 00000015E8DC: CC210077 02005929
	v_fma_mixhi_f16 v119, v42, s44, 0                          // 00000015E8E4: CC220077 0200592A
	v_fma_mixlo_f16 v120, v43, s44, 0                          // 00000015E8EC: CC210078 0200592B
	v_fma_mixhi_f16 v120, v44, s44, 0                          // 00000015E8F4: CC220078 0200592C
	s_waitcnt lgkmcnt(0)                                       // 00000015E8FC: BF89FC07
	v_fma_mixlo_f16 v121, v54, s44, 0                          // 00000015E900: CC210079 02005936
	v_fma_mixhi_f16 v121, v55, s44, 0                          // 00000015E908: CC220079 02005937
	v_fma_mixlo_f16 v122, v56, s44, 0                          // 00000015E910: CC21007A 02005938
	v_fma_mixhi_f16 v122, v57, s44, 0                          // 00000015E918: CC22007A 02005939
	.long 0x7f6c3880                                           // 00000015E920: 7F6C3880
	v_wmma_f32_16x16x16_f16 v[33:40], v[46:53], v[61:68], v[33:40]// 00000015E924: CC404021 1C867B2E
	v_wmma_f32_16x16x16_f16 v[25:32], v[46:53], v[99:106], v[25:32]// 00000015E92C: CC404019 1C66C72E
	v_wmma_f32_16x16x16_f16 v[17:24], v[46:53], v[107:114], v[17:24]// 00000015E934: CC404011 1C46D72E
	v_wmma_f32_16x16x16_f16 v[9:16], v[46:53], v[115:122], v[9:16]// 00000015E93C: CC404009 1C26E72E
	.long 0x7f6839b6                                           // 00000015E944: 7F6839B6
	.long 0x7e6839b6                                           // 00000015E948: 7E6839B6
	.long 0x7f6639b6                                           // 00000015E94C: 7F6639B6
	.long 0x7e6639b6                                           // 00000015E950: 7E6639B6
	s_and_saveexec_b32 s11, s0                                 // 00000015E954: BE8B2000
	s_cbranch_execz 11                                         // 00000015E958: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5588>
	global_load_b128 v[41:44], v[59:60], off offset:384        // 00000015E95C: DC5E0180 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015E964: BF8903F7
	v_fma_mixlo_f16 v51, v41, s44, 0                           // 00000015E968: CC210033 02005929
	v_fma_mixhi_f16 v51, v42, s44, 0                           // 00000015E970: CC220033 0200592A
	v_fma_mixlo_f16 v52, v43, s44, 0                           // 00000015E978: CC210034 0200592B
	v_fma_mixhi_f16 v52, v44, s44, 0                           // 00000015E980: CC220034 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015E988: 8C7E0B7E
	.long 0x7e6c39b6                                           // 00000015E98C: 7E6C39B6
	.long 0x7f6a39b6                                           // 00000015E990: 7F6A39B6
	.long 0x7e6a39b6                                           // 00000015E994: 7E6A39B6
	s_and_saveexec_b32 s11, s0                                 // 00000015E998: BE8B2000
	s_cbranch_execz 11                                         // 00000015E99C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x55cc>
	global_load_b128 v[41:44], v[59:60], off offset:400        // 00000015E9A0: DC5E0190 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015E9A8: BF8903F7
	v_fma_mixlo_f16 v53, v41, s44, 0                           // 00000015E9AC: CC210035 02005929
	v_fma_mixhi_f16 v53, v42, s44, 0                           // 00000015E9B4: CC220035 0200592A
	v_fma_mixlo_f16 v54, v43, s44, 0                           // 00000015E9BC: CC210036 0200592B
	v_fma_mixhi_f16 v54, v44, s44, 0                           // 00000015E9C4: CC220036 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015E9CC: 8C7E0B7E
	.long 0x7f743880                                           // 00000015E9D0: 7F743880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015E9D4: BF870001
	.long 0x7f7039ba                                           // 00000015E9D8: 7F7039BA
	.long 0x7e7039ba                                           // 00000015E9DC: 7E7039BA
	.long 0x7f6e39ba                                           // 00000015E9E0: 7F6E39BA
	.long 0x7e6e39ba                                           // 00000015E9E4: 7E6E39BA
	s_and_saveexec_b32 s11, s0                                 // 00000015E9E8: BE8B2000
	s_cbranch_execz 11                                         // 00000015E9EC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x561c>
	global_load_b128 v[41:44], v[59:60], off offset:416        // 00000015E9F0: DC5E01A0 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015E9F8: BF8903F7
	v_fma_mixlo_f16 v55, v41, s44, 0                           // 00000015E9FC: CC210037 02005929
	v_fma_mixhi_f16 v55, v42, s44, 0                           // 00000015EA04: CC220037 0200592A
	v_fma_mixlo_f16 v56, v43, s44, 0                           // 00000015EA0C: CC210038 0200592B
	v_fma_mixhi_f16 v56, v44, s44, 0                           // 00000015EA14: CC220038 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015EA1C: 8C7E0B7E
	.long 0x7e7439ba                                           // 00000015EA20: 7E7439BA
	.long 0x7f7239ba                                           // 00000015EA24: 7F7239BA
	.long 0x7e7239ba                                           // 00000015EA28: 7E7239BA
	s_and_saveexec_b32 s11, s0                                 // 00000015EA2C: BE8B2000
	s_cbranch_execz 11                                         // 00000015EA30: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5660>
	global_load_b128 v[41:44], v[59:60], off offset:432        // 00000015EA34: DC5E01B0 297C003B
	s_waitcnt vmcnt(0)                                         // 00000015EA3C: BF8903F7
	v_fma_mixlo_f16 v57, v41, s44, 0                           // 00000015EA40: CC210039 02005929
	v_fma_mixhi_f16 v57, v42, s44, 0                           // 00000015EA48: CC220039 0200592A
	v_fma_mixlo_f16 v58, v43, s44, 0                           // 00000015EA50: CC21003A 0200592B
	v_fma_mixhi_f16 v58, v44, s44, 0                           // 00000015EA58: CC22003A 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015EA60: 8C7E0B7E
	ds_load_b128 v[41:44], v79 offset:384                      // 00000015EA64: DBFC0180 2900004F
	ds_load_b128 v[45:48], v79 offset:400                      // 00000015EA6C: DBFC0190 2D00004F
	ds_load_b128 v[65:68], v79 offset:416                      // 00000015EA74: DBFC01A0 4100004F
	ds_load_b128 v[69:72], v79 offset:432                      // 00000015EA7C: DBFC01B0 4500004F
	ds_load_b128 v[99:102], v79 offset:8832                    // 00000015EA84: DBFC2280 6300004F
	ds_load_b128 v[103:106], v79 offset:8848                   // 00000015EA8C: DBFC2290 6700004F
	ds_load_b128 v[107:110], v79 offset:8864                   // 00000015EA94: DBFC22A0 6B00004F
	ds_load_b128 v[111:114], v79 offset:8880                   // 00000015EA9C: DBFC22B0 6F00004F
	ds_load_b128 v[119:122], v79 offset:25728                  // 00000015EAA4: DBFC6480 7700004F
	ds_load_b128 v[123:126], v79 offset:25744                  // 00000015EAAC: DBFC6490 7B00004F
	ds_load_b128 v[115:118], v79 offset:17328                  // 00000015EAB4: DBFC43B0 7300004F
	s_waitcnt lgkmcnt(10)                                      // 00000015EABC: BF89FCA7
	v_fma_mixlo_f16 v61, v41, s44, 0                           // 00000015EAC0: CC21003D 02005929
	v_fma_mixhi_f16 v61, v42, s44, 0                           // 00000015EAC8: CC22003D 0200592A
	v_fma_mixlo_f16 v62, v43, s44, 0                           // 00000015EAD0: CC21003E 0200592B
	v_fma_mixhi_f16 v62, v44, s44, 0                           // 00000015EAD8: CC22003E 0200592C
	s_waitcnt lgkmcnt(9)                                       // 00000015EAE0: BF89FC97
	v_fma_mixlo_f16 v63, v45, s44, 0                           // 00000015EAE4: CC21003F 0200592D
	v_fma_mixhi_f16 v63, v46, s44, 0                           // 00000015EAEC: CC22003F 0200592E
	v_fma_mixlo_f16 v64, v47, s44, 0                           // 00000015EAF4: CC210040 0200592F
	v_fma_mixhi_f16 v64, v48, s44, 0                           // 00000015EAFC: CC220040 02005930
	ds_load_b128 v[41:44], v79 offset:17280                    // 00000015EB04: DBFC4380 2900004F
	ds_load_b128 v[45:48], v79 offset:17296                    // 00000015EB0C: DBFC4390 2D00004F
	s_waitcnt lgkmcnt(10)                                      // 00000015EB14: BF89FCA7
	v_fma_mixlo_f16 v65, v65, s44, 0                           // 00000015EB18: CC210041 02005941
	v_fma_mixhi_f16 v65, v66, s44, 0                           // 00000015EB20: CC220041 02005942
	v_fma_mixlo_f16 v66, v67, s44, 0                           // 00000015EB28: CC210042 02005943
	v_fma_mixhi_f16 v66, v68, s44, 0                           // 00000015EB30: CC220042 02005944
	s_waitcnt lgkmcnt(9)                                       // 00000015EB38: BF89FC97
	v_fma_mixlo_f16 v67, v69, s44, 0                           // 00000015EB3C: CC210043 02005945
	v_fma_mixhi_f16 v67, v70, s44, 0                           // 00000015EB44: CC220043 02005946
	v_fma_mixlo_f16 v68, v71, s44, 0                           // 00000015EB4C: CC210044 02005947
	v_fma_mixhi_f16 v68, v72, s44, 0                           // 00000015EB54: CC220044 02005948
	s_waitcnt lgkmcnt(8)                                       // 00000015EB5C: BF89FC87
	v_fma_mixlo_f16 v99, v99, s44, 0                           // 00000015EB60: CC210063 02005963
	v_fma_mixhi_f16 v99, v100, s44, 0                          // 00000015EB68: CC220063 02005964
	v_fma_mixlo_f16 v100, v101, s44, 0                         // 00000015EB70: CC210064 02005965
	s_waitcnt lgkmcnt(7)                                       // 00000015EB78: BF89FC77
	v_fma_mixlo_f16 v101, v103, s44, 0                         // 00000015EB7C: CC210065 02005967
	v_fma_mixhi_f16 v101, v104, s44, 0                         // 00000015EB84: CC220065 02005968
	s_waitcnt lgkmcnt(6)                                       // 00000015EB8C: BF89FC67
	v_fma_mixlo_f16 v103, v107, s44, 0                         // 00000015EB90: CC210067 0200596B
	ds_load_b128 v[69:72], v79 offset:17312                    // 00000015EB98: DBFC43A0 4500004F
	v_fma_mixhi_f16 v103, v108, s44, 0                         // 00000015EBA0: CC220067 0200596C
	v_fma_mixlo_f16 v104, v109, s44, 0                         // 00000015EBA8: CC210068 0200596D
	v_fma_mixhi_f16 v104, v110, s44, 0                         // 00000015EBB0: CC220068 0200596E
	s_waitcnt lgkmcnt(2)                                       // 00000015EBB8: BF89FC27
	v_fma_mixlo_f16 v107, v41, s44, 0                          // 00000015EBBC: CC21006B 02005929
	v_fma_mixhi_f16 v107, v42, s44, 0                          // 00000015EBC4: CC22006B 0200592A
	v_fma_mixlo_f16 v108, v43, s44, 0                          // 00000015EBCC: CC21006C 0200592B
	v_fma_mixhi_f16 v108, v44, s44, 0                          // 00000015EBD4: CC22006C 0200592C
	s_waitcnt lgkmcnt(1)                                       // 00000015EBDC: BF89FC17
	v_fma_mixlo_f16 v109, v45, s44, 0                          // 00000015EBE0: CC21006D 0200592D
	v_fma_mixhi_f16 v109, v46, s44, 0                          // 00000015EBE8: CC22006D 0200592E
	ds_load_b128 v[41:44], v79 offset:25760                    // 00000015EBF0: DBFC64A0 2900004F
	v_fma_mixlo_f16 v110, v47, s44, 0                          // 00000015EBF8: CC21006E 0200592F
	v_fma_mixhi_f16 v110, v48, s44, 0                          // 00000015EC00: CC22006E 02005930
	ds_load_b128 v[45:48], v79 offset:25776                    // 00000015EC08: DBFC64B0 2D00004F
	v_fma_mixhi_f16 v100, v102, s44, 0                         // 00000015EC10: CC220064 02005966
	v_fma_mixlo_f16 v102, v105, s44, 0                         // 00000015EC18: CC210066 02005969
	v_fma_mixhi_f16 v102, v106, s44, 0                         // 00000015EC20: CC220066 0200596A
	v_fma_mixlo_f16 v105, v111, s44, 0                         // 00000015EC28: CC210069 0200596F
	v_fma_mixhi_f16 v105, v112, s44, 0                         // 00000015EC30: CC220069 02005970
	v_fma_mixlo_f16 v106, v113, s44, 0                         // 00000015EC38: CC21006A 02005971
	v_fma_mixhi_f16 v106, v114, s44, 0                         // 00000015EC40: CC22006A 02005972
	s_waitcnt lgkmcnt(2)                                       // 00000015EC48: BF89FC27
	v_fma_mixlo_f16 v111, v69, s44, 0                          // 00000015EC4C: CC21006F 02005945
	v_fma_mixhi_f16 v111, v70, s44, 0                          // 00000015EC54: CC22006F 02005946
	v_fma_mixlo_f16 v112, v71, s44, 0                          // 00000015EC5C: CC210070 02005947
	v_fma_mixhi_f16 v112, v72, s44, 0                          // 00000015EC64: CC220070 02005948
	v_fma_mixlo_f16 v113, v115, s44, 0                         // 00000015EC6C: CC210071 02005973
	v_fma_mixhi_f16 v113, v116, s44, 0                         // 00000015EC74: CC220071 02005974
	v_fma_mixlo_f16 v114, v117, s44, 0                         // 00000015EC7C: CC210072 02005975
	v_fma_mixhi_f16 v114, v118, s44, 0                         // 00000015EC84: CC220072 02005976
	v_fma_mixlo_f16 v115, v119, s44, 0                         // 00000015EC8C: CC210073 02005977
	v_fma_mixhi_f16 v115, v120, s44, 0                         // 00000015EC94: CC220073 02005978
	v_fma_mixlo_f16 v116, v121, s44, 0                         // 00000015EC9C: CC210074 02005979
	v_fma_mixhi_f16 v116, v122, s44, 0                         // 00000015ECA4: CC220074 0200597A
	v_fma_mixlo_f16 v117, v123, s44, 0                         // 00000015ECAC: CC210075 0200597B
	v_fma_mixhi_f16 v117, v124, s44, 0                         // 00000015ECB4: CC220075 0200597C
	v_fma_mixlo_f16 v118, v125, s44, 0                         // 00000015ECBC: CC210076 0200597D
	v_fma_mixhi_f16 v118, v126, s44, 0                         // 00000015ECC4: CC220076 0200597E
	s_waitcnt lgkmcnt(1)                                       // 00000015ECCC: BF89FC17
	v_fma_mixlo_f16 v119, v41, s44, 0                          // 00000015ECD0: CC210077 02005929
	v_fma_mixhi_f16 v119, v42, s44, 0                          // 00000015ECD8: CC220077 0200592A
	v_fma_mixlo_f16 v120, v43, s44, 0                          // 00000015ECE0: CC210078 0200592B
	v_fma_mixhi_f16 v120, v44, s44, 0                          // 00000015ECE8: CC220078 0200592C
	s_waitcnt lgkmcnt(0)                                       // 00000015ECF0: BF89FC07
	v_fma_mixlo_f16 v121, v45, s44, 0                          // 00000015ECF4: CC210079 0200592D
	v_fma_mixhi_f16 v121, v46, s44, 0                          // 00000015ECFC: CC220079 0200592E
	v_fma_mixlo_f16 v122, v47, s44, 0                          // 00000015ED04: CC21007A 0200592F
	v_fma_mixhi_f16 v122, v48, s44, 0                          // 00000015ED0C: CC22007A 02005930
	.long 0x7f583880                                           // 00000015ED14: 7F583880
	v_wmma_f32_16x16x16_f16 v[33:40], v[51:58], v[61:68], v[33:40]// 00000015ED18: CC404021 1C867B33
	v_wmma_f32_16x16x16_f16 v[25:32], v[51:58], v[99:106], v[25:32]// 00000015ED20: CC404019 1C66C733
	v_wmma_f32_16x16x16_f16 v[17:24], v[51:58], v[107:114], v[17:24]// 00000015ED28: CC404011 1C46D733
	v_wmma_f32_16x16x16_f16 v[9:16], v[51:58], v[115:122], v[9:16]// 00000015ED30: CC404009 1C26E733
	.long 0x7f5439ac                                           // 00000015ED38: 7F5439AC
	.long 0x7e5439ac                                           // 00000015ED3C: 7E5439AC
	.long 0x7f5239ac                                           // 00000015ED40: 7F5239AC
	.long 0x7e5239ac                                           // 00000015ED44: 7E5239AC
	s_and_saveexec_b32 s11, s0                                 // 00000015ED48: BE8B2000
	s_cbranch_execz 11                                         // 00000015ED4C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x597c>
	global_load_b128 v[45:48], v[59:60], off offset:448        // 00000015ED50: DC5E01C0 2D7C003B
	s_waitcnt vmcnt(0)                                         // 00000015ED58: BF8903F7
	v_fma_mixlo_f16 v41, v45, s44, 0                           // 00000015ED5C: CC210029 0200592D
	v_fma_mixhi_f16 v41, v46, s44, 0                           // 00000015ED64: CC220029 0200592E
	v_fma_mixlo_f16 v42, v47, s44, 0                           // 00000015ED6C: CC21002A 0200592F
	v_fma_mixhi_f16 v42, v48, s44, 0                           // 00000015ED74: CC22002A 02005930
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015ED7C: 8C7E0B7E
	.long 0x7e5839ac                                           // 00000015ED80: 7E5839AC
	.long 0x7f5639ac                                           // 00000015ED84: 7F5639AC
	.long 0x7e5639ac                                           // 00000015ED88: 7E5639AC
	s_and_saveexec_b32 s11, s0                                 // 00000015ED8C: BE8B2000
	s_cbranch_execz 11                                         // 00000015ED90: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x59c0>
	global_load_b128 v[43:46], v[59:60], off offset:464        // 00000015ED94: DC5E01D0 2B7C003B
	s_waitcnt vmcnt(0)                                         // 00000015ED9C: BF8903F7
	v_fma_mixlo_f16 v43, v43, s44, 0                           // 00000015EDA0: CC21002B 0200592B
	v_fma_mixhi_f16 v43, v44, s44, 0                           // 00000015EDA8: CC22002B 0200592C
	v_fma_mixlo_f16 v44, v45, s44, 0                           // 00000015EDB0: CC21002C 0200592D
	v_fma_mixhi_f16 v44, v46, s44, 0                           // 00000015EDB8: CC22002C 0200592E
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015EDC0: 8C7E0B7E
	.long 0x7f603880                                           // 00000015EDC4: 7F603880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015EDC8: BF870001
	.long 0x7f5c39b0                                           // 00000015EDCC: 7F5C39B0
	.long 0x7e5c39b0                                           // 00000015EDD0: 7E5C39B0
	.long 0x7f5a39b0                                           // 00000015EDD4: 7F5A39B0
	.long 0x7e5a39b0                                           // 00000015EDD8: 7E5A39B0
	s_and_saveexec_b32 s11, s0                                 // 00000015EDDC: BE8B2000
	s_cbranch_execz 11                                         // 00000015EDE0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a10>
	global_load_b128 v[49:52], v[59:60], off offset:480        // 00000015EDE4: DC5E01E0 317C003B
	s_waitcnt vmcnt(0)                                         // 00000015EDEC: BF8903F7
	v_fma_mixlo_f16 v45, v49, s44, 0                           // 00000015EDF0: CC21002D 02005931
	v_fma_mixhi_f16 v45, v50, s44, 0                           // 00000015EDF8: CC22002D 02005932
	v_fma_mixlo_f16 v46, v51, s44, 0                           // 00000015EE00: CC21002E 02005933
	v_fma_mixhi_f16 v46, v52, s44, 0                           // 00000015EE08: CC22002E 02005934
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015EE10: 8C7E0B7E
	.long 0x7e6039b0                                           // 00000015EE14: 7E6039B0
	.long 0x7f5e39b0                                           // 00000015EE18: 7F5E39B0
	.long 0x7e5e39b0                                           // 00000015EE1C: 7E5E39B0
	s_and_saveexec_b32 s11, s0                                 // 00000015EE20: BE8B2000
	s_cbranch_execz 11                                         // 00000015EE24: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a54>
	global_load_b128 v[47:50], v[59:60], off offset:496        // 00000015EE28: DC5E01F0 2F7C003B
	s_waitcnt vmcnt(0)                                         // 00000015EE30: BF8903F7
	v_fma_mixlo_f16 v47, v47, s44, 0                           // 00000015EE34: CC21002F 0200592F
	v_fma_mixhi_f16 v47, v48, s44, 0                           // 00000015EE3C: CC22002F 02005930
	v_fma_mixlo_f16 v48, v49, s44, 0                           // 00000015EE44: CC210030 02005931
	v_fma_mixhi_f16 v48, v50, s44, 0                           // 00000015EE4C: CC220030 02005932
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015EE54: 8C7E0B7E
	ds_load_b128 v[49:52], v79 offset:448                      // 00000015EE58: DBFC01C0 3100004F
	ds_load_b128 v[53:56], v79 offset:464                      // 00000015EE60: DBFC01D0 3500004F
	ds_load_b128 v[57:60], v79 offset:480                      // 00000015EE68: DBFC01E0 3900004F
	ds_load_b128 v[61:64], v79 offset:496                      // 00000015EE70: DBFC01F0 3D00004F
	ds_load_b128 v[65:68], v79 offset:8896                     // 00000015EE78: DBFC22C0 4100004F
	ds_load_b128 v[69:72], v79 offset:8912                     // 00000015EE80: DBFC22D0 4500004F
	ds_load_b128 v[99:102], v79 offset:8928                    // 00000015EE88: DBFC22E0 6300004F
	ds_load_b128 v[103:106], v79 offset:8944                   // 00000015EE90: DBFC22F0 6700004F
	ds_load_b128 v[107:110], v79 offset:17344                  // 00000015EE98: DBFC43C0 6B00004F
	ds_load_b128 v[111:114], v79 offset:17360                  // 00000015EEA0: DBFC43D0 6F00004F
	ds_load_b128 v[115:118], v79 offset:25808                  // 00000015EEA8: DBFC64D0 7300004F
	s_mul_i32 s11, s45, 48                                     // 00000015EEB0: 960BB02D
	s_mul_hi_u32 s0, s45, 48                                   // 00000015EEB4: 9680B02D
	s_add_u32 s18, s11, s2                                     // 00000015EEB8: 8012020B
	s_addc_u32 s19, s0, s3                                     // 00000015EEBC: 82130300
	s_mov_b32 s11, 0                                           // 00000015EEC0: BE8B0080
	s_lshl_b64 s[18:19], s[18:19], 14                          // 00000015EEC4: 84928E12
	s_waitcnt lgkmcnt(10)                                      // 00000015EEC8: BF89FCA7
	v_fma_mixlo_f16 v49, v49, s44, 0                           // 00000015EECC: CC210031 02005931
	v_fma_mixhi_f16 v49, v50, s44, 0                           // 00000015EED4: CC220031 02005932
	v_fma_mixlo_f16 v50, v51, s44, 0                           // 00000015EEDC: CC210032 02005933
	v_fma_mixhi_f16 v50, v52, s44, 0                           // 00000015EEE4: CC220032 02005934
	s_waitcnt lgkmcnt(9)                                       // 00000015EEEC: BF89FC97
	v_fma_mixhi_f16 v51, v54, s44, 0                           // 00000015EEF0: CC220033 02005936
	v_fma_mixlo_f16 v52, v55, s44, 0                           // 00000015EEF8: CC210034 02005937
	s_waitcnt lgkmcnt(8)                                       // 00000015EF00: BF89FC87
	v_fma_mixlo_f16 v54, v59, s44, 0                           // 00000015EF04: CC210036 0200593B
	v_fma_mixhi_f16 v54, v60, s44, 0                           // 00000015EF0C: CC220036 0200593C
	s_waitcnt lgkmcnt(7)                                       // 00000015EF14: BF89FC77
	v_fma_mixlo_f16 v55, v61, s44, 0                           // 00000015EF18: CC210037 0200593D
	v_fma_mixhi_f16 v55, v62, s44, 0                           // 00000015EF20: CC220037 0200593E
	s_waitcnt lgkmcnt(5)                                       // 00000015EF28: BF89FC57
	v_fma_mixlo_f16 v59, v69, s44, 0                           // 00000015EF2C: CC21003B 02005945
	v_fma_mixhi_f16 v59, v70, s44, 0                           // 00000015EF34: CC22003B 02005946
	v_fma_mixlo_f16 v60, v71, s44, 0                           // 00000015EF3C: CC21003C 02005947
	v_fma_mixhi_f16 v60, v72, s44, 0                           // 00000015EF44: CC22003C 02005948
	s_waitcnt lgkmcnt(4)                                       // 00000015EF4C: BF89FC47
	v_fma_mixlo_f16 v61, v99, s44, 0                           // 00000015EF50: CC21003D 02005963
	ds_load_b128 v[69:72], v79 offset:17376                    // 00000015EF58: DBFC43E0 4500004F
	v_fma_mixhi_f16 v61, v100, s44, 0                          // 00000015EF60: CC22003D 02005964
	v_fma_mixlo_f16 v62, v101, s44, 0                          // 00000015EF68: CC21003E 02005965
	v_fma_mixhi_f16 v62, v102, s44, 0                          // 00000015EF70: CC22003E 02005966
	ds_load_b128 v[99:102], v79 offset:17392                   // 00000015EF78: DBFC43F0 6300004F
	v_fma_mixlo_f16 v51, v53, s44, 0                           // 00000015EF80: CC210033 02005935
	v_fma_mixhi_f16 v52, v56, s44, 0                           // 00000015EF88: CC220034 02005938
	v_fma_mixlo_f16 v53, v57, s44, 0                           // 00000015EF90: CC210035 02005939
	v_fma_mixhi_f16 v53, v58, s44, 0                           // 00000015EF98: CC220035 0200593A
	v_fma_mixlo_f16 v56, v63, s44, 0                           // 00000015EFA0: CC210038 0200593F
	v_fma_mixhi_f16 v56, v64, s44, 0                           // 00000015EFA8: CC220038 02005940
	v_fma_mixlo_f16 v57, v65, s44, 0                           // 00000015EFB0: CC210039 02005941
	v_fma_mixhi_f16 v57, v66, s44, 0                           // 00000015EFB8: CC220039 02005942
	v_fma_mixlo_f16 v58, v67, s44, 0                           // 00000015EFC0: CC21003A 02005943
	v_fma_mixhi_f16 v58, v68, s44, 0                           // 00000015EFC8: CC22003A 02005944
	s_waitcnt lgkmcnt(5)                                       // 00000015EFD0: BF89FC57
	v_fma_mixlo_f16 v63, v103, s44, 0                          // 00000015EFD4: CC21003F 02005967
	v_fma_mixhi_f16 v63, v104, s44, 0                          // 00000015EFDC: CC22003F 02005968
	v_fma_mixlo_f16 v64, v105, s44, 0                          // 00000015EFE4: CC210040 02005969
	v_fma_mixhi_f16 v64, v106, s44, 0                          // 00000015EFEC: CC220040 0200596A
	ds_load_b128 v[103:106], v79 offset:25792                  // 00000015EFF4: DBFC64C0 6700004F
	s_waitcnt lgkmcnt(5)                                       // 00000015EFFC: BF89FC57
	v_fma_mixlo_f16 v65, v107, s44, 0                          // 00000015F000: CC210041 0200596B
	v_fma_mixhi_f16 v65, v108, s44, 0                          // 00000015F008: CC220041 0200596C
	v_fma_mixlo_f16 v66, v109, s44, 0                          // 00000015F010: CC210042 0200596D
	v_fma_mixhi_f16 v66, v110, s44, 0                          // 00000015F018: CC220042 0200596E
	s_waitcnt lgkmcnt(4)                                       // 00000015F020: BF89FC47
	v_fma_mixlo_f16 v67, v111, s44, 0                          // 00000015F024: CC210043 0200596F
	v_fma_mixhi_f16 v67, v112, s44, 0                          // 00000015F02C: CC220043 02005970
	ds_load_b128 v[107:110], v79 offset:25824                  // 00000015F034: DBFC64E0 6B00004F
	v_fma_mixlo_f16 v68, v113, s44, 0                          // 00000015F03C: CC210044 02005971
	v_fma_mixhi_f16 v68, v114, s44, 0                          // 00000015F044: CC220044 02005972
	ds_load_b128 v[111:114], v79 offset:25840                  // 00000015F04C: DBFC64F0 6F00004F
	s_waitcnt lgkmcnt(4)                                       // 00000015F054: BF89FC47
	v_fma_mixlo_f16 v69, v69, s44, 0                           // 00000015F058: CC210045 02005945
	v_fma_mixhi_f16 v69, v70, s44, 0                           // 00000015F060: CC220045 02005946
	v_fma_mixlo_f16 v70, v71, s44, 0                           // 00000015F068: CC210046 02005947
	v_fma_mixhi_f16 v70, v72, s44, 0                           // 00000015F070: CC220046 02005948
	s_waitcnt lgkmcnt(3)                                       // 00000015F078: BF89FC37
	v_fma_mixlo_f16 v71, v99, s44, 0                           // 00000015F07C: CC210047 02005963
	v_fma_mixhi_f16 v71, v100, s44, 0                          // 00000015F084: CC220047 02005964
	v_fma_mixlo_f16 v72, v101, s44, 0                          // 00000015F08C: CC210048 02005965
	v_fma_mixhi_f16 v72, v102, s44, 0                          // 00000015F094: CC220048 02005966
	v_fma_mixlo_f16 v101, v115, s44, 0                         // 00000015F09C: CC210065 02005973
	s_waitcnt lgkmcnt(2)                                       // 00000015F0A4: BF89FC27
	v_fma_mixlo_f16 v99, v103, s44, 0                          // 00000015F0A8: CC210063 02005967
	v_fma_mixhi_f16 v99, v104, s44, 0                          // 00000015F0B0: CC220063 02005968
	v_fma_mixlo_f16 v100, v105, s44, 0                         // 00000015F0B8: CC210064 02005969
	v_fma_mixhi_f16 v100, v106, s44, 0                         // 00000015F0C0: CC220064 0200596A
	v_fma_mixhi_f16 v101, v116, s44, 0                         // 00000015F0C8: CC220065 02005974
	v_fma_mixlo_f16 v102, v117, s44, 0                         // 00000015F0D0: CC210066 02005975
	v_fma_mixhi_f16 v102, v118, s44, 0                         // 00000015F0D8: CC220066 02005976
	s_waitcnt lgkmcnt(1)                                       // 00000015F0E0: BF89FC17
	v_fma_mixlo_f16 v103, v107, s44, 0                         // 00000015F0E4: CC210067 0200596B
	v_fma_mixhi_f16 v103, v108, s44, 0                         // 00000015F0EC: CC220067 0200596C
	v_fma_mixlo_f16 v104, v109, s44, 0                         // 00000015F0F4: CC210068 0200596D
	v_fma_mixhi_f16 v104, v110, s44, 0                         // 00000015F0FC: CC220068 0200596E
	s_waitcnt lgkmcnt(0)                                       // 00000015F104: BF89FC07
	v_fma_mixlo_f16 v105, v111, s44, 0                         // 00000015F108: CC210069 0200596F
	v_fma_mixhi_f16 v105, v112, s44, 0                         // 00000015F110: CC220069 02005970
	v_fma_mixlo_f16 v106, v113, s44, 0                         // 00000015F118: CC21006A 02005971
	v_fma_mixhi_f16 v106, v114, s44, 0                         // 00000015F120: CC22006A 02005972
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[65:72], v[17:24]// 00000015F128: CC404011 1C468329
	v_mov_b32_e32 v65, 0                                       // 00000015F130: 7E820280
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[49:56], v[33:40]// 00000015F134: CC404021 1C866329
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[57:64], v[25:32]// 00000015F13C: CC404019 1C667329
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[99:106], v[9:16]// 00000015F144: CC404009 1C26C729
	.long 0xd7000063                                           // 00000015F14C: D7000063
	v_cndmask_b32_e32 v0, v81, v18, vcc_lo                     // 00000015F150: 02002551
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F154: BF870001
	v_add_co_ci_u32_e64 v100, null, s19, v82, s0               // 00000015F158: D5207C64 0002A413
	v_mov_b32_e32 v66, v65                                     // 00000015F160: 7E840341
	v_mov_b32_e32 v67, v65                                     // 00000015F164: 7E860341
	v_mov_b32_e32 v68, v65                                     // 00000015F168: 7E880341
	v_mov_b32_e32 v69, v65                                     // 00000015F16C: 7E8A0341
	v_mov_b32_e32 v70, v65                                     // 00000015F170: 7E8C0341
	v_mov_b32_e32 v71, v65                                     // 00000015F174: 7E8E0341
	v_mov_b32_e32 v72, v65                                     // 00000015F178: 7E900341
	v_mov_b32_e32 v57, v65                                     // 00000015F17C: 7E720341
	v_mov_b32_e32 v58, v65                                     // 00000015F180: 7E740341
	v_mov_b32_e32 v59, v65                                     // 00000015F184: 7E760341
	v_mov_b32_e32 v60, v65                                     // 00000015F188: 7E780341
	v_mov_b32_e32 v61, v65                                     // 00000015F18C: 7E7A0341
	v_mov_b32_e32 v62, v65                                     // 00000015F190: 7E7C0341
	v_mov_b32_e32 v63, v65                                     // 00000015F194: 7E7E0341
	v_mov_b32_e32 v64, v65                                     // 00000015F198: 7E800341
	v_mov_b32_e32 v49, v65                                     // 00000015F19C: 7E620341
	v_mov_b32_e32 v50, v65                                     // 00000015F1A0: 7E640341
	v_mov_b32_e32 v51, v65                                     // 00000015F1A4: 7E660341
	v_mov_b32_e32 v52, v65                                     // 00000015F1A8: 7E680341
	v_mov_b32_e32 v53, v65                                     // 00000015F1AC: 7E6A0341
	v_mov_b32_e32 v54, v65                                     // 00000015F1B0: 7E6C0341
	v_mov_b32_e32 v55, v65                                     // 00000015F1B4: 7E6E0341
	v_mov_b32_e32 v56, v65                                     // 00000015F1B8: 7E700341
	v_mov_b32_e32 v41, v65                                     // 00000015F1BC: 7E520341
	v_mov_b32_e32 v42, v65                                     // 00000015F1C0: 7E540341
	v_mov_b32_e32 v43, v65                                     // 00000015F1C4: 7E560341
	v_mov_b32_e32 v44, v65                                     // 00000015F1C8: 7E580341
	v_mov_b32_e32 v45, v65                                     // 00000015F1CC: 7E5A0341
	v_mov_b32_e32 v46, v65                                     // 00000015F1D0: 7E5C0341
	v_mov_b32_e32 v47, v65                                     // 00000015F1D4: 7E5E0341
	v_mov_b32_e32 v48, v65                                     // 00000015F1D8: 7E600341
	s_mov_b32 s18, 0                                           // 00000015F1DC: BE920080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000015F1E0: BF8704B9
	s_lshl_b32 s14, s18, 4                                     // 00000015F1E4: 840E8412
	v_lshl_add_u32 v125, s18, 5, v83                           // 00000015F1E8: D646007D 054D0A12
	s_lshl_b64 s[48:49], s[14:15], 2                           // 00000015F1F0: 84B0820E
	.long 0xd7000065                                           // 00000015F1F4: D7000065
	v_cndmask_b32_e32 v0, v99, v48, vcc_lo                     // 00000015F1F8: 02006163
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F1FC: BF870001
	v_add_co_ci_u32_e64 v102, null, s49, v100, s0              // 00000015F200: D5207C66 0002C831
	.long 0xd44a0000                                           // 00000015F208: D44A0000
	v_cndmask_b32_e32 v1, s18, v76, vcc_lo                     // 00000015F20C: 02029812
	s_add_i32 s18, s18, 1                                      // 00000015F210: 81128112
	s_clause 0x3                                               // 00000015F214: BF850003
	global_load_b128 v[133:136], v[101:102], off               // 00000015F218: DC5E0000 857C0065
	global_load_b128 v[137:140], v[101:102], off offset:16     // 00000015F220: DC5E0010 897C0065
	global_load_b128 v[141:144], v[101:102], off offset:32     // 00000015F228: DC5E0020 8D7C0065
	global_load_b128 v[145:148], v[101:102], off offset:48     // 00000015F230: DC5E0030 917C0065
	ds_load_b128 v[101:104], v125                              // 00000015F238: DBFC0000 6500007D
	ds_load_b128 v[105:108], v125 offset:16                    // 00000015F240: DBFC0010 6900007D
	ds_load_b128 v[113:116], v125 offset:2576                  // 00000015F248: DBFC0A10 7100007D
	ds_load_b128 v[109:112], v125 offset:2560                  // 00000015F250: DBFC0A00 6D00007D
	ds_load_b128 v[121:124], v125 offset:5136                  // 00000015F258: DBFC1410 7900007D
	ds_load_b128 v[117:120], v125 offset:5120                  // 00000015F260: DBFC1400 7500007D
	ds_load_b128 v[129:132], v125 offset:7696                  // 00000015F268: DBFC1E10 8100007D
	ds_load_b128 v[125:128], v125 offset:7680                  // 00000015F270: DBFC1E00 7D00007D
	s_or_b32 s11, s0, s11                                      // 00000015F278: 8C0B0B00
	s_waitcnt vmcnt(3)                                         // 00000015F27C: BF890FF7
	v_fma_mixlo_f16 v133, v133, s44, 0                         // 00000015F280: CC210085 02005985
	v_fma_mixhi_f16 v133, v134, s44, 0                         // 00000015F288: CC220085 02005986
	v_fma_mixlo_f16 v134, v135, s44, 0                         // 00000015F290: CC210086 02005987
	v_fma_mixhi_f16 v134, v136, s44, 0                         // 00000015F298: CC220086 02005988
	s_waitcnt vmcnt(2)                                         // 00000015F2A0: BF890BF7
	v_fma_mixlo_f16 v135, v137, s44, 0                         // 00000015F2A4: CC210087 02005989
	v_fma_mixhi_f16 v135, v138, s44, 0                         // 00000015F2AC: CC220087 0200598A
	v_fma_mixlo_f16 v136, v139, s44, 0                         // 00000015F2B4: CC210088 0200598B
	v_fma_mixhi_f16 v136, v140, s44, 0                         // 00000015F2BC: CC220088 0200598C
	s_waitcnt vmcnt(1)                                         // 00000015F2C4: BF8907F7
	v_fma_mixlo_f16 v137, v141, s44, 0                         // 00000015F2C8: CC210089 0200598D
	v_fma_mixhi_f16 v137, v142, s44, 0                         // 00000015F2D0: CC220089 0200598E
	v_fma_mixlo_f16 v138, v143, s44, 0                         // 00000015F2D8: CC21008A 0200598F
	v_fma_mixhi_f16 v138, v144, s44, 0                         // 00000015F2E0: CC22008A 02005990
	s_waitcnt vmcnt(0)                                         // 00000015F2E8: BF8903F7
	v_fma_mixlo_f16 v139, v145, s44, 0                         // 00000015F2EC: CC21008B 02005991
	v_fma_mixhi_f16 v139, v146, s44, 0                         // 00000015F2F4: CC22008B 02005992
	v_fma_mixlo_f16 v140, v147, s44, 0                         // 00000015F2FC: CC21008C 02005993
	v_fma_mixhi_f16 v140, v148, s44, 0                         // 00000015F304: CC22008C 02005994
	s_waitcnt lgkmcnt(6)                                       // 00000015F30C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F310: BF870001
	v_wmma_f32_16x16x16_f16 v[65:72], v[133:140], v[101:108], v[65:72]// 00000015F314: CC404041 1D06CB85
	s_waitcnt lgkmcnt(4)                                       // 00000015F31C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[57:64], v[133:140], v[109:116], v[57:64]// 00000015F320: CC404039 1CE6DB85
	s_waitcnt lgkmcnt(2)                                       // 00000015F328: BF89FC27
	v_wmma_f32_16x16x16_f16 v[49:56], v[133:140], v[117:124], v[49:56]// 00000015F32C: CC404031 1CC6EB85
	s_waitcnt lgkmcnt(0)                                       // 00000015F334: BF89FC07
	v_wmma_f32_16x16x16_f16 v[41:48], v[133:140], v[125:132], v[41:48]// 00000015F338: CC404029 1CA6FB85
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000015F340: 917E0B7E
	s_cbranch_execnz 65446                                     // 00000015F344: BFA6FFA6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5de0>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000015F348: 8C7E0B7E
	s_and_saveexec_b32 s0, s1                                  // 00000015F34C: BE802001
	s_cbranch_execnz 94                                        // 00000015F350: BFA6005E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x60cc>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F354: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000015F358: BE802004
	s_cbranch_execnz 113                                       // 00000015F35C: BFA60071 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6124>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F360: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000015F364: BE802005
	s_cbranch_execnz 132                                       // 00000015F368: BFA60084 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x617c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F36C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000015F370: BE802006
	s_cbranch_execnz 151                                       // 00000015F374: BFA60097 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x61d4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F378: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000015F37C: BE802007
	s_cbranch_execnz 170                                       // 00000015F380: BFA600AA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x622c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F384: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000015F388: BE802008
	s_cbranch_execnz 189                                       // 00000015F38C: BFA600BD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6284>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F390: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000015F394: BE802009
	s_cbranch_execnz 208                                       // 00000015F398: BFA600D0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x62dc>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F39C: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000015F3A0: BE80200A
	s_cbranch_execnz 227                                       // 00000015F3A4: BFA600E3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6334>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F3A8: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000015F3AC: BE802001
	s_cbranch_execnz 245                                       // 00000015F3B0: BFA600F5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6388>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F3B4: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000015F3B8: BE802004
	s_cbranch_execnz 264                                       // 00000015F3BC: BFA60108 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x63e0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F3C0: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000015F3C4: BE802005
	s_cbranch_execnz 283                                       // 00000015F3C8: BFA6011B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6438>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F3CC: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000015F3D0: BE802006
	s_cbranch_execnz 302                                       // 00000015F3D4: BFA6012E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6490>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F3D8: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000015F3DC: BE802007
	s_cbranch_execnz 321                                       // 00000015F3E0: BFA60141 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x64e8>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F3E4: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000015F3E8: BE802008
	s_cbranch_execnz 340                                       // 00000015F3EC: BFA60154 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6540>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F3F0: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000015F3F4: BE802009
	s_cbranch_execnz 359                                       // 00000015F3F8: BFA60167 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6598>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F3FC: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000015F400: BE80200A
	s_cbranch_execnz 378                                       // 00000015F404: BFA6017A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x65f0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F408: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000015F40C: BE802001
	s_cbranch_execnz 396                                       // 00000015F410: BFA6018C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6644>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F414: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000015F418: BE802004
	s_cbranch_execnz 415                                       // 00000015F41C: BFA6019F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x669c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F420: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000015F424: BE802005
	s_cbranch_execnz 434                                       // 00000015F428: BFA601B2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x66f4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F42C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000015F430: BE802006
	s_cbranch_execnz 453                                       // 00000015F434: BFA601C5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x674c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F438: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000015F43C: BE802007
	s_cbranch_execnz 472                                       // 00000015F440: BFA601D8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x67a4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F444: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000015F448: BE802008
	s_cbranch_execnz 491                                       // 00000015F44C: BFA601EB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x67fc>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F450: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000015F454: BE802009
	s_cbranch_execnz 510                                       // 00000015F458: BFA601FE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6854>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F45C: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000015F460: BE80200A
	s_cbranch_execnz 529                                       // 00000015F464: BFA60211 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x68ac>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F468: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000015F46C: BE802001
	s_cbranch_execnz 547                                       // 00000015F470: BFA60223 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6900>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F474: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000015F478: BE802004
	s_cbranch_execnz 566                                       // 00000015F47C: BFA60236 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6958>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F480: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000015F484: BE802005
	s_cbranch_execnz 585                                       // 00000015F488: BFA60249 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x69b0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F48C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000015F490: BE802006
	s_cbranch_execnz 604                                       // 00000015F494: BFA6025C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6a08>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F498: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000015F49C: BE802007
	s_cbranch_execnz 623                                       // 00000015F4A0: BFA6026F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6a60>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F4A4: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000015F4A8: BE802008
	s_cbranch_execnz 642                                       // 00000015F4AC: BFA60282 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6ab8>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F4B0: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000015F4B4: BE802009
	s_cbranch_execnz 661                                       // 00000015F4B8: BFA60295 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6b10>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F4BC: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000015F4C0: BE80200A
	s_cbranch_execz 59553                                      // 00000015F4C4: BFA5E8A1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x34c>
	s_branch 679                                               // 00000015F4C8: BFA002A7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6b68>
	ds_load_b32 v99, v89                                       // 00000015F4CC: D8D80000 63000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F4D4: BF89FC07
	v_fma_f32 v33, v33, v99, v65                               // 00000015F4D8: D6130021 0506C721
	v_mad_u64_u32 v[99:100], null, 0x3000, v91, v[73:74]       // 00000015F4E0: D6FE7C63 0526B6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015F4EC: BF870092
	v_mul_f32_e32 v33, 0x3b800000, v33                         // 00000015F4F0: 104242FF 3B800000
	v_bfe_u32 v65, v33, 16, 1                                  // 00000015F4F8: D6100041 02052121
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F500: BF870001
	v_add3_u32 v33, v33, v65, 0x7fff                           // 00000015F504: D6550021 03FE8321 00007FFF
	global_store_d16_hi_b16 v[99:100], v33, off                // 00000015F510: DC960000 007C2163
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F518: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000015F51C: BE802004
	s_cbranch_execz 65423                                      // 00000015F520: BFA5FF8F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f60>
	ds_load_b32 v33, v89 offset:8                              // 00000015F524: D8D80008 21000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F52C: BF89FC07
	v_fma_f32 v33, v34, v33, v66                               // 00000015F530: D6130021 050A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015F538: BF870121
	v_mul_f32_e32 v65, 0x3b800000, v33                         // 00000015F53C: 108242FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v92, v[73:74]        // 00000015F544: D6FE7C21 0526B8FF 00003000
	v_bfe_u32 v66, v65, 16, 1                                  // 00000015F550: D6100042 02052141
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F558: BF870001
	v_add3_u32 v65, v65, v66, 0x7fff                           // 00000015F55C: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[33:34], v65, off                 // 00000015F568: DC960000 007C4121
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F570: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000015F574: BE802005
	s_cbranch_execz 65404                                      // 00000015F578: BFA5FF7C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f6c>
	ds_load_b32 v33, v89 offset:16                             // 00000015F57C: D8D80010 21000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F584: BF89FC07
	v_fma_f32 v33, v35, v33, v67                               // 00000015F588: D6130021 050E4323
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015F590: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 00000015F594: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v93, v[73:74]        // 00000015F59C: D6FE7C21 0526BAFF 00003000
	v_bfe_u32 v65, v35, 16, 1                                  // 00000015F5A8: D6100041 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F5B0: BF870001
	v_add3_u32 v35, v35, v65, 0x7fff                           // 00000015F5B4: D6550023 03FE8323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 00000015F5C0: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F5C8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000015F5CC: BE802006
	s_cbranch_execz 65385                                      // 00000015F5D0: BFA5FF69 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f78>
	ds_load_b32 v33, v89 offset:24                             // 00000015F5D4: D8D80018 21000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F5DC: BF89FC07
	v_fma_f32 v33, v36, v33, v68                               // 00000015F5E0: D6130021 05124324
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015F5E8: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 00000015F5EC: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v94, v[73:74]        // 00000015F5F4: D6FE7C21 0526BCFF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 00000015F600: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F608: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000015F60C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 00000015F618: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F620: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000015F624: BE802007
	s_cbranch_execz 65366                                      // 00000015F628: BFA5FF56 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f84>
	ds_load_b32 v33, v89 offset:32                             // 00000015F62C: D8D80020 21000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F634: BF89FC07
	v_fma_f32 v33, v37, v33, v69                               // 00000015F638: D6130021 05164325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015F640: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 00000015F644: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v95, v[73:74]        // 00000015F64C: D6FE7C21 0526BEFF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 00000015F658: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F660: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000015F664: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 00000015F670: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F678: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000015F67C: BE802008
	s_cbranch_execz 65347                                      // 00000015F680: BFA5FF43 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f90>
	ds_load_b32 v33, v89 offset:40                             // 00000015F684: D8D80028 21000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F68C: BF89FC07
	v_fma_f32 v33, v38, v33, v70                               // 00000015F690: D6130021 051A4326
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015F698: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 00000015F69C: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v96, v[73:74]        // 00000015F6A4: D6FE7C21 0526C0FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 00000015F6B0: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F6B8: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000015F6BC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 00000015F6C8: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F6D0: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000015F6D4: BE802009
	s_cbranch_execz 65328                                      // 00000015F6D8: BFA5FF30 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f9c>
	ds_load_b32 v33, v89 offset:48                             // 00000015F6DC: D8D80030 21000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F6E4: BF89FC07
	v_fma_f32 v33, v39, v33, v71                               // 00000015F6E8: D6130021 051E4327
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015F6F0: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 00000015F6F4: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v97, v[73:74]        // 00000015F6FC: D6FE7C21 0526C2FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 00000015F708: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F710: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000015F714: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 00000015F720: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F728: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000015F72C: BE80200A
	s_cbranch_execz 65309                                      // 00000015F730: BFA5FF1D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5fa8>
	ds_load_b32 v33, v89 offset:56                             // 00000015F734: D8D80038 21000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F73C: BF89FC07
	v_fmac_f32_e32 v72, v40, v33                               // 00000015F740: 56904328
	v_mad_u64_u32 v[33:34], null, 0x3000, v98, v[73:74]        // 00000015F744: D6FE7C21 0526C4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015F750: BF870092
	v_mul_f32_e32 v35, 0x3b800000, v72                         // 00000015F754: 104690FF 3B800000
	v_bfe_u32 v36, v35, 16, 1                                  // 00000015F75C: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F764: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000015F768: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 00000015F774: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F77C: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000015F780: BE802001
	s_cbranch_execz 65291                                      // 00000015F784: BFA5FF0B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5fb4>
	ds_load_b32 v33, v89                                       // 00000015F788: D8D80000 21000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F790: BF89FC07
	v_fma_f32 v25, v25, v33, v57                               // 00000015F794: D6130019 04E64319
	v_mad_u64_u32 v[33:34], null, 0x3000, v91, v[73:74]        // 00000015F79C: D6FE7C21 0526B6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015F7A8: BF870092
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 00000015F7AC: 103232FF 3B800000
	v_bfe_u32 v35, v25, 16, 1                                  // 00000015F7B4: D6100023 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F7BC: BF870001
	v_add3_u32 v25, v25, v35, 0x7fff                           // 00000015F7C0: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:32       // 00000015F7CC: DC960020 007C1921
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F7D4: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000015F7D8: BE802004
	s_cbranch_execz 65272                                      // 00000015F7DC: BFA5FEF8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5fc0>
	ds_load_b32 v25, v89 offset:8                              // 00000015F7E0: D8D80008 19000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F7E8: BF89FC07
	v_fma_f32 v25, v26, v25, v58                               // 00000015F7EC: D6130019 04EA331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015F7F4: BF870121
	v_mul_f32_e32 v33, 0x3b800000, v25                         // 00000015F7F8: 104232FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v92, v[73:74]        // 00000015F800: D6FE7C19 0526B8FF 00003000
	v_bfe_u32 v34, v33, 16, 1                                  // 00000015F80C: D6100022 02052121
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F814: BF870001
	v_add3_u32 v33, v33, v34, 0x7fff                           // 00000015F818: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:32       // 00000015F824: DC960020 007C2119
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F82C: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000015F830: BE802005
	s_cbranch_execz 65253                                      // 00000015F834: BFA5FEE5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5fcc>
	ds_load_b32 v25, v89 offset:16                             // 00000015F838: D8D80010 19000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F840: BF89FC07
	v_fma_f32 v25, v27, v25, v59                               // 00000015F844: D6130019 04EE331B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015F84C: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 00000015F850: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v93, v[73:74]        // 00000015F858: D6FE7C19 0526BAFF 00003000
	v_bfe_u32 v33, v27, 16, 1                                  // 00000015F864: D6100021 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F86C: BF870001
	v_add3_u32 v27, v27, v33, 0x7fff                           // 00000015F870: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:32       // 00000015F87C: DC960020 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F884: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000015F888: BE802006
	s_cbranch_execz 65234                                      // 00000015F88C: BFA5FED2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5fd8>
	ds_load_b32 v25, v89 offset:24                             // 00000015F890: D8D80018 19000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F898: BF89FC07
	v_fma_f32 v25, v28, v25, v60                               // 00000015F89C: D6130019 04F2331C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015F8A4: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 00000015F8A8: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v94, v[73:74]        // 00000015F8B0: D6FE7C19 0526BCFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000015F8BC: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F8C4: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000015F8C8: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:32       // 00000015F8D4: DC960020 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F8DC: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000015F8E0: BE802007
	s_cbranch_execz 65215                                      // 00000015F8E4: BFA5FEBF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5fe4>
	ds_load_b32 v25, v89 offset:32                             // 00000015F8E8: D8D80020 19000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F8F0: BF89FC07
	v_fma_f32 v25, v29, v25, v61                               // 00000015F8F4: D6130019 04F6331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015F8FC: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 00000015F900: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v95, v[73:74]        // 00000015F908: D6FE7C19 0526BEFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000015F914: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F91C: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000015F920: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:32       // 00000015F92C: DC960020 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F934: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000015F938: BE802008
	s_cbranch_execz 65196                                      // 00000015F93C: BFA5FEAC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5ff0>
	ds_load_b32 v25, v89 offset:40                             // 00000015F940: D8D80028 19000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F948: BF89FC07
	v_fma_f32 v25, v30, v25, v62                               // 00000015F94C: D6130019 04FA331E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015F954: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 00000015F958: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v96, v[73:74]        // 00000015F960: D6FE7C19 0526C0FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000015F96C: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F974: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000015F978: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:32       // 00000015F984: DC960020 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F98C: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000015F990: BE802009
	s_cbranch_execz 65177                                      // 00000015F994: BFA5FE99 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5ffc>
	ds_load_b32 v25, v89 offset:48                             // 00000015F998: D8D80030 19000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F9A0: BF89FC07
	v_fma_f32 v25, v31, v25, v63                               // 00000015F9A4: D6130019 04FE331F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015F9AC: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 00000015F9B0: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v97, v[73:74]        // 00000015F9B8: D6FE7C19 0526C2FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000015F9C4: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015F9CC: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000015F9D0: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:32       // 00000015F9DC: DC960020 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015F9E4: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000015F9E8: BE80200A
	s_cbranch_execz 65158                                      // 00000015F9EC: BFA5FE86 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6008>
	ds_load_b32 v25, v89 offset:56                             // 00000015F9F0: D8D80038 19000059
	s_waitcnt lgkmcnt(0)                                       // 00000015F9F8: BF89FC07
	v_fmac_f32_e32 v64, v32, v25                               // 00000015F9FC: 56803320
	v_mad_u64_u32 v[25:26], null, 0x3000, v98, v[73:74]        // 00000015FA00: D6FE7C19 0526C4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015FA0C: BF870092
	v_mul_f32_e32 v27, 0x3b800000, v64                         // 00000015FA10: 103680FF 3B800000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000015FA18: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FA20: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000015FA24: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:32       // 00000015FA30: DC960020 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FA38: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000015FA3C: BE802001
	s_cbranch_execz 65140                                      // 00000015FA40: BFA5FE74 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6014>
	ds_load_b32 v25, v89                                       // 00000015FA44: D8D80000 19000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FA4C: BF89FC07
	v_fma_f32 v17, v17, v25, v49                               // 00000015FA50: D6130011 04C63311
	v_mad_u64_u32 v[25:26], null, 0x3000, v91, v[73:74]        // 00000015FA58: D6FE7C19 0526B6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015FA64: BF870092
	v_mul_f32_e32 v17, 0x3b800000, v17                         // 00000015FA68: 102222FF 3B800000
	v_bfe_u32 v27, v17, 16, 1                                  // 00000015FA70: D610001B 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FA78: BF870001
	v_add3_u32 v17, v17, v27, 0x7fff                           // 00000015FA7C: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:64       // 00000015FA88: DC960040 007C1119
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FA90: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000015FA94: BE802004
	s_cbranch_execz 65121                                      // 00000015FA98: BFA5FE61 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6020>
	ds_load_b32 v17, v89 offset:8                              // 00000015FA9C: D8D80008 11000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FAA4: BF89FC07
	v_fma_f32 v17, v18, v17, v50                               // 00000015FAA8: D6130011 04CA2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015FAB0: BF870121
	v_mul_f32_e32 v25, 0x3b800000, v17                         // 00000015FAB4: 103222FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v92, v[73:74]        // 00000015FABC: D6FE7C11 0526B8FF 00003000
	v_bfe_u32 v26, v25, 16, 1                                  // 00000015FAC8: D610001A 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FAD0: BF870001
	v_add3_u32 v25, v25, v26, 0x7fff                           // 00000015FAD4: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:64       // 00000015FAE0: DC960040 007C1911
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FAE8: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000015FAEC: BE802005
	s_cbranch_execz 65102                                      // 00000015FAF0: BFA5FE4E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x602c>
	ds_load_b32 v17, v89 offset:16                             // 00000015FAF4: D8D80010 11000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FAFC: BF89FC07
	v_fma_f32 v17, v19, v17, v51                               // 00000015FB00: D6130011 04CE2313
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015FB08: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000015FB0C: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v93, v[73:74]        // 00000015FB14: D6FE7C11 0526BAFF 00003000
	v_bfe_u32 v25, v19, 16, 1                                  // 00000015FB20: D6100019 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FB28: BF870001
	v_add3_u32 v19, v19, v25, 0x7fff                           // 00000015FB2C: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 00000015FB38: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FB40: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000015FB44: BE802006
	s_cbranch_execz 65083                                      // 00000015FB48: BFA5FE3B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6038>
	ds_load_b32 v17, v89 offset:24                             // 00000015FB4C: D8D80018 11000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FB54: BF89FC07
	v_fma_f32 v17, v20, v17, v52                               // 00000015FB58: D6130011 04D22314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015FB60: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000015FB64: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v94, v[73:74]        // 00000015FB6C: D6FE7C11 0526BCFF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000015FB78: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FB80: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000015FB84: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 00000015FB90: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FB98: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000015FB9C: BE802007
	s_cbranch_execz 65064                                      // 00000015FBA0: BFA5FE28 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6044>
	ds_load_b32 v17, v89 offset:32                             // 00000015FBA4: D8D80020 11000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FBAC: BF89FC07
	v_fma_f32 v17, v21, v17, v53                               // 00000015FBB0: D6130011 04D62315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015FBB8: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000015FBBC: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v95, v[73:74]        // 00000015FBC4: D6FE7C11 0526BEFF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000015FBD0: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FBD8: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000015FBDC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 00000015FBE8: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FBF0: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000015FBF4: BE802008
	s_cbranch_execz 65045                                      // 00000015FBF8: BFA5FE15 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6050>
	ds_load_b32 v17, v89 offset:40                             // 00000015FBFC: D8D80028 11000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FC04: BF89FC07
	v_fma_f32 v17, v22, v17, v54                               // 00000015FC08: D6130011 04DA2316
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015FC10: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000015FC14: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v96, v[73:74]        // 00000015FC1C: D6FE7C11 0526C0FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000015FC28: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FC30: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000015FC34: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 00000015FC40: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FC48: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000015FC4C: BE802009
	s_cbranch_execz 65026                                      // 00000015FC50: BFA5FE02 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x605c>
	ds_load_b32 v17, v89 offset:48                             // 00000015FC54: D8D80030 11000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FC5C: BF89FC07
	v_fma_f32 v17, v23, v17, v55                               // 00000015FC60: D6130011 04DE2317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015FC68: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000015FC6C: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v97, v[73:74]        // 00000015FC74: D6FE7C11 0526C2FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000015FC80: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FC88: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000015FC8C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 00000015FC98: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FCA0: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000015FCA4: BE80200A
	s_cbranch_execz 65007                                      // 00000015FCA8: BFA5FDEF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6068>
	ds_load_b32 v17, v89 offset:56                             // 00000015FCAC: D8D80038 11000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FCB4: BF89FC07
	v_fmac_f32_e32 v56, v24, v17                               // 00000015FCB8: 56702318
	v_mad_u64_u32 v[17:18], null, 0x3000, v98, v[73:74]        // 00000015FCBC: D6FE7C11 0526C4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015FCC8: BF870092
	v_mul_f32_e32 v19, 0x3b800000, v56                         // 00000015FCCC: 102670FF 3B800000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000015FCD4: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FCDC: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000015FCE0: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 00000015FCEC: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FCF4: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000015FCF8: BE802001
	s_cbranch_execz 64989                                      // 00000015FCFC: BFA5FDDD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6074>
	ds_load_b32 v17, v89                                       // 00000015FD00: D8D80000 11000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FD08: BF89FC07
	v_fma_f32 v9, v9, v17, v41                                 // 00000015FD0C: D6130009 04A62309
	v_mad_u64_u32 v[17:18], null, 0x3000, v91, v[73:74]        // 00000015FD14: D6FE7C11 0526B6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015FD20: BF870092
	v_mul_f32_e32 v9, 0x3b800000, v9                           // 00000015FD24: 101212FF 3B800000
	v_bfe_u32 v19, v9, 16, 1                                   // 00000015FD2C: D6100013 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FD34: BF870001
	v_add3_u32 v9, v9, v19, 0x7fff                             // 00000015FD38: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:96        // 00000015FD44: DC960060 007C0911
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FD4C: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000015FD50: BE802004
	s_cbranch_execz 64970                                      // 00000015FD54: BFA5FDCA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6080>
	ds_load_b32 v9, v89 offset:8                               // 00000015FD58: D8D80008 09000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FD60: BF89FC07
	v_fma_f32 v9, v10, v9, v42                                 // 00000015FD64: D6130009 04AA130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015FD6C: BF870121
	v_mul_f32_e32 v17, 0x3b800000, v9                          // 00000015FD70: 102212FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v92, v[73:74]         // 00000015FD78: D6FE7C09 0526B8FF 00003000
	v_bfe_u32 v18, v17, 16, 1                                  // 00000015FD84: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FD8C: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 00000015FD90: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:96        // 00000015FD9C: DC960060 007C1109
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FDA4: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000015FDA8: BE802005
	s_cbranch_execz 64951                                      // 00000015FDAC: BFA5FDB7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x608c>
	ds_load_b32 v9, v89 offset:16                              // 00000015FDB0: D8D80010 09000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FDB8: BF89FC07
	v_fma_f32 v9, v11, v9, v43                                 // 00000015FDBC: D6130009 04AE130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015FDC4: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000015FDC8: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v93, v[73:74]         // 00000015FDD0: D6FE7C09 0526BAFF 00003000
	v_bfe_u32 v17, v11, 16, 1                                  // 00000015FDDC: D6100011 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FDE4: BF870001
	v_add3_u32 v11, v11, v17, 0x7fff                           // 00000015FDE8: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 00000015FDF4: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FDFC: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000015FE00: BE802006
	s_cbranch_execz 64932                                      // 00000015FE04: BFA5FDA4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6098>
	ds_load_b32 v9, v89 offset:24                              // 00000015FE08: D8D80018 09000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FE10: BF89FC07
	v_fma_f32 v9, v12, v9, v44                                 // 00000015FE14: D6130009 04B2130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015FE1C: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000015FE20: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v94, v[73:74]         // 00000015FE28: D6FE7C09 0526BCFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000015FE34: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FE3C: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000015FE40: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 00000015FE4C: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FE54: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000015FE58: BE802007
	s_cbranch_execz 64913                                      // 00000015FE5C: BFA5FD91 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x60a4>
	ds_load_b32 v9, v89 offset:32                              // 00000015FE60: D8D80020 09000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FE68: BF89FC07
	v_fma_f32 v9, v13, v9, v45                                 // 00000015FE6C: D6130009 04B6130D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015FE74: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000015FE78: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v95, v[73:74]         // 00000015FE80: D6FE7C09 0526BEFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000015FE8C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FE94: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000015FE98: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 00000015FEA4: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FEAC: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000015FEB0: BE802008
	s_cbranch_execz 64894                                      // 00000015FEB4: BFA5FD7E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x60b0>
	ds_load_b32 v9, v89 offset:40                              // 00000015FEB8: D8D80028 09000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FEC0: BF89FC07
	v_fma_f32 v9, v14, v9, v46                                 // 00000015FEC4: D6130009 04BA130E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015FECC: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000015FED0: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v96, v[73:74]         // 00000015FED8: D6FE7C09 0526C0FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000015FEE4: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FEEC: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000015FEF0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 00000015FEFC: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FF04: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000015FF08: BE802009
	s_cbranch_execz 64875                                      // 00000015FF0C: BFA5FD6B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x60bc>
	ds_load_b32 v9, v89 offset:48                              // 00000015FF10: D8D80030 09000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FF18: BF89FC07
	v_fma_f32 v9, v15, v9, v47                                 // 00000015FF1C: D6130009 04BE130F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015FF24: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000015FF28: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v97, v[73:74]         // 00000015FF30: D6FE7C09 0526C2FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000015FF3C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FF44: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000015FF48: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 00000015FF54: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 00000015FF5C: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000015FF60: BE80200A
	s_cbranch_execz 58873                                      // 00000015FF64: BFA5E5F9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x34c>
	ds_load_b32 v9, v89 offset:56                              // 00000015FF68: D8D80038 09000059
	s_waitcnt lgkmcnt(0)                                       // 00000015FF70: BF89FC07
	v_fmac_f32_e32 v48, v16, v9                                // 00000015FF74: 56601310
	v_mad_u64_u32 v[9:10], null, 0x3000, v98, v[73:74]         // 00000015FF78: D6FE7C09 0526C4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015FF84: BF870092
	v_mul_f32_e32 v11, 0x3b800000, v48                         // 00000015FF88: 101660FF 3B800000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000015FF90: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000015FF98: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000015FF9C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 00000015FFA8: DC960060 007C0B09
	s_branch 58854                                             // 00000015FFB0: BFA0E5E6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x34c>
	v_lshlrev_b32_e32 v1, 3, v0                                // 00000015FFB4: 30020083
	s_add_u32 s0, s40, s34                                     // 00000015FFB8: 80002228
	s_addc_u32 s1, s33, s35                                    // 00000015FFBC: 82012321
	s_add_u32 s2, s36, s22                                     // 00000015FFC0: 80021624
	s_addc_u32 s3, s37, s23                                    // 00000015FFC4: 82031725
	v_and_b32_e32 v1, 0x200, v1                                // 00000015FFC8: 360202FF 00000200
	s_add_u32 s0, s2, s0                                       // 00000015FFD0: 80000002
	v_lshlrev_b32_e32 v3, 2, v75                               // 00000015FFD4: 30069682
	s_addc_u32 s1, s3, s1                                      // 00000015FFD8: 82010103
	v_lshrrev_b32_e32 v5, 4, v0                                // 00000015FFDC: 320A0084
	.long 0xd7000001                                           // 00000015FFE0: D7000001
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 00000015FFE4: 02020200
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000015FFE8: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s1, 0, s0                    // 00000015FFEC: D5207C04 00010001
	v_or_b32_e32 v2, 0xffffff80, v0                            // 00000015FFF4: 380400FF FFFFFF80
	.long 0xd7006a01                                           // 00000015FFFC: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000160000: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000160004: BF8701A1
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 000000160008: D5207C03 01AA0880
	v_mul_u32_u24_e32 v4, 0x210, v75                           // 000000160010: 160896FF 00000210
	.long 0xd7006a00                                           // 000000160018: D7006A00
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 00000016001C: 02020214
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000160020: BF870191
	v_add_co_ci_u32_e64 v1, null, s21, v3, vcc_lo              // 000000160024: D5207C01 01AA0615
	v_and_or_b32 v3, v5, 4, v4                                 // 00000016002C: D6570003 04110905
	s_mov_b32 s1, 0                                            // 000000160034: BE810080
	s_nop 0                                                    // 000000160038: BF800000
	s_nop 0                                                    // 00000016003C: BF800000
	ds_load_b32 v4, v3 offset:12800                            // 000000160040: D8D83200 04000003
	v_add_nc_u32_e32 v2, 0x80, v2                              // 000000160048: 4A0404FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 000000160050: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000160054: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v2                        // 000000160058: 7C9204FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 000000160060: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 000000160064: BF89FC07
	global_store_b32 v[0:1], v4, off                           // 000000160068: DC6A0000 007C0400
	.long 0xd7000000                                           // 000000160070: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 000000160074: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000016007C: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000160084: 917E017E
	s_cbranch_execnz 65517                                     // 000000160088: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi5EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6c40>
	s_nop 0                                                    // 00000016008C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000160090: BFB60003
	s_endpgm                                                   // 000000160094: BFB00000
		...

