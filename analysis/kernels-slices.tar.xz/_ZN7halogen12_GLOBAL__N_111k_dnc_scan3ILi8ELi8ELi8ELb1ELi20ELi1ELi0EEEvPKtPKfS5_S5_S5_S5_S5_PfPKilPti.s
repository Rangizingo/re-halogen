00000000000dfa00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000DFA00: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000DFA04: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000DFA0C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000DFA14: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000DFA18: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000DFA1C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000DFA20: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000DFA28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000DFA2C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000DFA30: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000DFA34: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000DFA3C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000DFA40: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000DFA44: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000DFA48: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DFA4C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000DFA50: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000DFA54: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000DFA58: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000DFA5C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000DFA64: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000DFA6C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000DFA70: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000DFA74: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000DFA78: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000DFA7C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000DFA80: 821E191E
	.long 0xd7001f02                                           // 0000000DFA84: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000DFA88: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000DFA8C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000DFA94: BE9E0080
	s_nop 0                                                    // 0000000DFA98: BF800000
	s_nop 0                                                    // 0000000DFA9C: BF800000
	s_nop 0                                                    // 0000000DFAA0: BF800000
	s_nop 0                                                    // 0000000DFAA4: BF800000
	s_nop 0                                                    // 0000000DFAA8: BF800000
	s_nop 0                                                    // 0000000DFAAC: BF800000
	s_nop 0                                                    // 0000000DFAB0: BF800000
	s_nop 0                                                    // 0000000DFAB4: BF800000
	s_nop 0                                                    // 0000000DFAB8: BF800000
	s_nop 0                                                    // 0000000DFABC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000DFAC0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000DFAC4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFACC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000DFAD0: 300C1089
	.long 0xd7006a06                                           // 0000000DFAD4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000DFAD8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DFADC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000DFAE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000DFAE8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000DFAF0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000DFAF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000DFAFC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000DFB08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000DFB0C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000DFB10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000DFB18: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000DFB1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000DFB20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000DFB24: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 0000000DFB2C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000DFB34: 32040084
	s_mov_b32 s0, 0                                            // 0000000DFB38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000DFB3C: BF89FC07
	s_barrier                                                  // 0000000DFB40: BFBD0000
	buffer_gl0_inv                                             // 0000000DFB44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000DFB4C: BF02801E
	s_cbranch_scc1 12                                          // 0000000DFB50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000DFB54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000DFB5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000DFB64: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 0000000DFB68: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000DFB70: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000DFB74: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000DFB78: 916A007E
	s_cbranch_vccz 2                                           // 0000000DFB7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2088                                              // 0000000DFB80: BFA00828 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2224>
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000DFB84: 304E0A82
	s_add_i32 s0, s30, 63                                      // 0000000DFB88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000DFB8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000DFB94: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000DFB98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000DFB9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000DFBA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000000DFBA4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000000DFBAC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000DFBB0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000DFBB4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000DFBB8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000DFBBC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000DFBC0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000DFBC4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000000DFBC8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000DFBD4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000DFBD8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000DFBDC: B00A0204
	.long 0xd7000b2c                                           // 0000000DFBE0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000000DFBE4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000DFBE8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000000DFBEC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000000DFBF4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000DFC00: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 0000000DFC04: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 0000000DFC10: 3816500A
	.long 0xd7000a05                                           // 0000000DFC14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000DFC18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DFC1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000DFC20: D5207C06 00290001
	.long 0xd7000107                                           // 0000000DFC28: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000DFC2C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DFC30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000DFC34: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000DFC3C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000DFC40: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000DFC44: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000DFC4C: 84848E02
	.long 0xd700010b                                           // 0000000DFC50: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000DFC54: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000DFC58: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000DFC5C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000DFC64: 8205050F
	.long 0xd700010d                                           // 0000000DFC68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000DFC6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DFC70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000DFC74: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000DFC7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000DFC80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000DFC88: D5207C10 00061880
	.long 0xd7000111                                           // 0000000DFC90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000DFC94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DFC9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000DFCA0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000DFCA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000DFCAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000DFCB4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000DFCBC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000DFCC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DFCC8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000DFCCC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000DFCD4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000DFCD8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000DFCE0: D5207C18 00061880
	.long 0xd7000119                                           // 0000000DFCE8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000DFCEC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DFCF4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000DFCF8: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000DFD00: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000DFD04: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 0000000DFD0C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 0000000DFD14: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000DFD18: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 0000000DFD20: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 0000000DFD24: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 0000000DFD2C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000DFD34: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 0000000DFD3C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 0000000DFD44: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 0000000DFD4C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 0000000DFD54: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 0000000DFD5C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 0000000DFD64: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 0000000DFD6C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 0000000DFD74: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 0000000DFD7C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 0000000DFD84: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 0000000DFD8C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 0000000DFD94: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 0000000DFD9C: BE850080
	s_mov_b32 s6, 0x45800000                                   // 0000000DFDA0: BE8600FF 45800000
	s_mov_b32 s7, 0x39800000                                   // 0000000DFDA8: BE8700FF 39800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000DFDB0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000DFDB4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000DFDBC: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000DFDC0: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000DFDC4: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DFDC8: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000DFDCC: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000DFDD0: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000DFDD4: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000DFDD8: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000DFDDC: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000DFDE4: BE84206A
	s_cbranch_execz 77                                         // 0000000DFDE8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x520>
	v_or_b32_e32 v29, s11, v0                                  // 0000000DFDEC: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFDF0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000DFDF4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000DFDFC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DFE00: BF870091
	.long 0xd73c001d                                           // 0000000DFE04: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000DFE08: 02023A82
	.long 0xd700011d                                           // 0000000DFE0C: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000DFE10: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000DFE14: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000DFE18: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000DFE20: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DFE28: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000DFE2C: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000DFE30: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000DFE3C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 0000000DFE40: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 0000000DFE4C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000DFE50: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000DFE5C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DFE60: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 0000000DFE64: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000DFE70: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DFE74: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 0000000DFE78: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 0000000DFE80: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000DFE84: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 0000000DFE8C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000DFE94: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 0000000DFE98: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DFE9C: BF870193
	v_exp_f32_e32 v32, v32                                     // 0000000DFEA0: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 0000000DFEA4: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000DFEA8: BF870296
	.long 0xd71c0020                                           // 0000000DFEAC: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000DFEB0: 02024520
	.long 0xd71c001f                                           // 0000000DFEB4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000DFEB8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DFEBC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000DFEC0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000DFEC8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000DFECC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000DFED4: D5010020 00064080
	.long 0xd41e0001                                           // 0000000DFEDC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000DFEE0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DFEE8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000DFEEC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000DFEF8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000DFEFC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000DFF04: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 0000000DFF10: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 0000000DFF18: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DFF20: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000DFF24: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000DFF2C: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000DFF30: BF89FC07
	s_barrier                                                  // 0000000DFF34: BFBD0000
	buffer_gl0_inv                                             // 0000000DFF38: E0AC0000 00000000
	s_branch 15                                                // 0000000DFF40: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DFF44: 8C7E047E
	.long 0xd700011d                                           // 0000000DFF48: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000DFF4C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DFF54: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000DFF58: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000DFF60: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000DFF64: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000DFF68: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000DFF6C: BF89FC07
	s_barrier                                                  // 0000000DFF70: BFBD0000
	buffer_gl0_inv                                             // 0000000DFF74: E0AC0000 00000000
	s_cbranch_scc1 182                                         // 0000000DFF7C: BFA200B6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x858>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000DFF80: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 0000000DFF88: CA100128 21220126
	s_mov_b32 s13, 0                                           // 0000000DFF90: BE8D0080
	s_nop 0                                                    // 0000000DFF94: BF800000
	s_nop 0                                                    // 0000000DFF98: BF800000
	s_nop 0                                                    // 0000000DFF9C: BF800000
	s_nop 0                                                    // 0000000DFFA0: BF800000
	s_nop 0                                                    // 0000000DFFA4: BF800000
	s_nop 0                                                    // 0000000DFFA8: BF800000
	s_nop 0                                                    // 0000000DFFAC: BF800000
	s_nop 0                                                    // 0000000DFFB0: BF800000
	s_nop 0                                                    // 0000000DFFB4: BF800000
	s_nop 0                                                    // 0000000DFFB8: BF800000
	s_nop 0                                                    // 0000000DFFBC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000000DFFC0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000DFFC8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000DFFD0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000DFFD4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DFFDC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000DFFE0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000DFFE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000DFFEC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000DFFF4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000DFFF8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000000DFFFC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000E0004: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000E000C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000E0010: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000E0014: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000E0018: BF89FC07
	s_barrier                                                  // 0000000E001C: BFBD0000
	buffer_gl0_inv                                             // 0000000E0020: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000E0028: BE842000
	s_cbranch_execz 65477                                      // 0000000E002C: BFA5FFC5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	v_or3_b32 v31, s12, s11, v2                                // 0000000E0030: D658001F 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0038: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 0000000E003C: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 0000000E0044: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 0000000E0048: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E004C: BF870091
	.long 0xd700011f                                           // 0000000E0050: D700011F
	v_cndmask_b32_e32 v1, v44, v31, vcc_lo                     // 0000000E0054: 02023F2C
	v_add_co_ci_u32_e64 v32, null, v45, v32, s1                // 0000000E0058: D5207C20 0006412D
	s_mov_b32 s1, 0                                            // 0000000E0060: BE810080
	global_load_b32 v31, v[31:32], off                         // 0000000E0064: DC520000 1F7C001F
	v_mad_u64_u32 v[32:33], null, 0x44, s1, v[1:2]             // 0000000E006C: D6FE7C20 040402FF 00000044
	s_add_i32 s13, s1, 8                                       // 0000000E0078: 810D8801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000E007C: B6810078
	ds_load_2addr_b32 v[33:34], v32 offset1:17                 // 0000000E0080: D8DC1100 21000020
	ds_load_2addr_b32 v[35:36], v32 offset0:34 offset1:51      // 0000000E0088: D8DC3322 23000020
	ds_load_2addr_b32 v[60:61], v32 offset0:68 offset1:85      // 0000000E0090: D8DC5544 3C000020
	ds_load_2addr_b32 v[62:63], v32 offset0:102 offset1:119    // 0000000E0098: D8DC7766 3E000020
	v_lshl_add_u32 v32, s1, 2, v46                             // 0000000E00A0: D6460020 04B90401
	s_mov_b32 s1, s13                                          // 0000000E00A8: BE81000D
	ds_load_2addr_b32 v[64:65], v32 offset1:1                  // 0000000E00AC: D8DC0100 40000020
	ds_load_2addr_b32 v[66:67], v32 offset0:2 offset1:3        // 0000000E00B4: D8DC0302 42000020
	ds_load_2addr_b32 v[68:69], v32 offset0:4 offset1:5        // 0000000E00BC: D8DC0504 44000020
	ds_load_2addr_b32 v[70:71], v32 offset0:6 offset1:7        // 0000000E00C4: D8DC0706 46000020
	s_waitcnt lgkmcnt(7)                                       // 0000000E00CC: BF89FC77
	v_fma_mixlo_f16 v32, v33, s6, 0                            // 0000000E00D0: CC210020 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000E00D8: CC210022 02000D22
	s_waitcnt lgkmcnt(6)                                       // 0000000E00E0: BF89FC67
	v_fma_mixlo_f16 v35, v35, s6, 0                            // 0000000E00E4: CC210023 02000D23
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000E00EC: BF870193
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E00F0: CC200020 8A000F20
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E00F8: CC200022 8A000F22
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000E0100: BF870003
	v_fma_mix_f32 v35, v35, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E0104: CC200023 8A000F23
	s_waitcnt lgkmcnt(3)                                       // 0000000E010C: BF89FC37
	v_fma_mixlo_f16 v33, v64, s6, 0                            // 0000000E0110: CC210021 02000D40
	v_fma_mixlo_f16 v64, v65, s6, 0                            // 0000000E0118: CC210040 02000D41
	s_waitcnt lgkmcnt(2)                                       // 0000000E0120: BF89FC27
	v_fma_mixlo_f16 v65, v66, s6, 0                            // 0000000E0124: CC210041 02000D42
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000E012C: BF870193
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E0130: CC200021 8A000F21
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E0138: CC200040 8A000F40
	s_waitcnt vmcnt(0)                                         // 0000000E0140: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000E0144: BF870242
	v_fma_f32 v31, -v33, v32, v31                              // 0000000E0148: D613001F 247E4121
	v_fma_mixlo_f16 v32, v36, s6, 0                            // 0000000E0150: CC210020 02000D24
	v_fma_mixlo_f16 v33, v67, s6, 0                            // 0000000E0158: CC210021 02000D43
	v_fma_mix_f32 v36, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E0160: CC200024 8A000F41
	v_fma_f32 v31, -v64, v34, v31                              // 0000000E0168: D613001F 247E4540
	v_fma_mixlo_f16 v34, v60, s6, 0                            // 0000000E0170: CC210022 02000D3C
	s_waitcnt lgkmcnt(1)                                       // 0000000E0178: BF89FC17
	v_fma_mixlo_f16 v60, v68, s6, 0                            // 0000000E017C: CC21003C 02000D44
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E0184: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E018C: CC200021 8A000F21
	v_fma_f32 v31, -v36, v35, v31                              // 0000000E0194: D613001F 247E4724
	v_fma_mixlo_f16 v35, v61, s6, 0                            // 0000000E019C: CC210023 02000D3D
	v_fma_mixlo_f16 v36, v69, s6, 0                            // 0000000E01A4: CC210024 02000D45
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E01AC: CC200022 8A000F22
	v_fma_mix_f32 v60, v60, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E01B4: CC20003C 8A000F3C
	v_fma_f32 v31, -v33, v32, v31                              // 0000000E01BC: D613001F 247E4121
	v_fma_mixlo_f16 v32, v62, s6, 0                            // 0000000E01C4: CC210020 02000D3E
	s_waitcnt lgkmcnt(0)                                       // 0000000E01CC: BF89FC07
	v_fma_mixlo_f16 v33, v70, s6, 0                            // 0000000E01D0: CC210021 02000D46
	v_fma_mix_f32 v35, v35, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E01D8: CC200023 8A000F23
	v_fma_mix_f32 v36, v36, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E01E0: CC200024 8A000F24
	v_fma_f32 v31, -v60, v34, v31                              // 0000000E01E8: D613001F 247E453C
	v_fma_mixlo_f16 v34, v63, s6, 0                            // 0000000E01F0: CC210022 02000D3F
	v_fma_mixlo_f16 v60, v71, s6, 0                            // 0000000E01F8: CC21003C 02000D47
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E0200: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E0208: CC200021 8A000F21
	v_fma_f32 v31, -v36, v35, v31                              // 0000000E0210: D613001F 247E4724
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E0218: CC200022 8A000F22
	v_fma_mix_f32 v35, v60, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000E0220: CC200023 8A000F3C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0228: BF870093
	v_fma_f32 v31, -v33, v32, v31                              // 0000000E022C: D613001F 247E4121
	v_fma_f32 v31, -v35, v34, v31                              // 0000000E0234: D613001F 247E4523
	s_cbranch_scc1 65419                                       // 0000000E023C: BFA2FF8B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x66c>
	v_mad_u64_u32 v[32:33], null, 0x44, s12, v[4:5]            // 0000000E0240: D6FE7C20 041018FF 00000044
	ds_store_b32 v32, v31                                      // 0000000E024C: D8340000 00001F20
	s_branch 65339                                             // 0000000E0254: BFA0FF3B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	v_mov_b32_e32 v30, v14                                     // 0000000E0258: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000E025C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000E0264: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 0000000E0268: 7E46032B
	s_mov_b32 s12, 0                                           // 0000000E026C: BE8C0080
	s_branch 21                                                // 0000000E0270: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8c8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000E0274: 8C7E0D7E
	.long 0xd700011f                                           // 0000000E0278: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000E027C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E0284: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000E0288: D5207C20 00064080
	.long 0xd700011d                                           // 0000000E0290: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000E0294: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000E029C: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000E02A0: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000E02A8: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000E02AC: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000E02B0: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000E02B4: BC7C0000
	s_barrier                                                  // 0000000E02B8: BFBD0000
	buffer_gl0_inv                                             // 0000000E02BC: E0AC0000 00000000
	s_cbranch_scc1 606                                         // 0000000E02C4: BFA2025E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1240>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000E02C8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000E02CC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000E02D4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000E02D8: 7E780326
	s_mov_b32 s13, 0                                           // 0000000E02DC: BE8D0080
	s_nop 0                                                    // 0000000E02E0: BF800000
	s_nop 0                                                    // 0000000E02E4: BF800000
	s_nop 0                                                    // 0000000E02E8: BF800000
	s_nop 0                                                    // 0000000E02EC: BF800000
	s_nop 0                                                    // 0000000E02F0: BF800000
	s_nop 0                                                    // 0000000E02F4: BF800000
	s_nop 0                                                    // 0000000E02F8: BF800000
	s_nop 0                                                    // 0000000E02FC: BF800000
	global_load_b32 v61, v[33:34], off                         // 0000000E0300: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000E0308: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000E0310: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000E0314: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000E031C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000E0320: D5207C22 00064480
	.long 0xd4490004                                           // 0000000E0328: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000E032C: 020278FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000E0334: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000E0338: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000000E033C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 0000000E0344: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000E034C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000E0350: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x900>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000E0354: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000E0358: BF89FC07
	s_barrier                                                  // 0000000E035C: BFBD0000
	buffer_gl0_inv                                             // 0000000E0360: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000E0368: BE8D2000
	s_cbranch_execz 65473                                      // 0000000E036C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x874>
	v_or_b32_e32 v33, s12, v2                                  // 0000000E0370: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0374: BF870091
	v_or_b32_e32 v36, s11, v33                                 // 0000000E0378: 3848420B
	.long 0xd4440001                                           // 0000000E037C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 0000000E0380: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000E0384: 8B7E017E
	s_cbranch_execz 65466                                      // 0000000E0388: BFA5FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x874>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 0000000E038C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000E0394: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 0000000E039C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 0000000E03A4: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 0000000E03AC: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 0000000E03B4: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 0000000E03BC: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 0000000E03C4: D8DC7766 4A000001
	s_mov_b32 s14, 0                                           // 0000000E03CC: BE8E0080
	s_waitcnt lgkmcnt(6)                                       // 0000000E03D0: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 0000000E03D4: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E03DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E03E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E03E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E03E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E03EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E03F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E03F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E03F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E03FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0400: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0404: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0408: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E040C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0410: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:8 offset1:9        // 0000000E0414: D8DC0908 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 0000000E041C: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 0000000E0424: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 0000000E042C: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:12 offset1:13      // 0000000E0434: D8DC0D0C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 0000000E043C: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 0000000E0444: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 0000000E044C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 0000000E0454: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E0458: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E045C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E0460: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E0464: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E0468: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E046C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E0470: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E0474: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E0478: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E047C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0480: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0484: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0488: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E048C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0490: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 0000000E0494: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 0000000E049C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 0000000E04A4: D8DC1312 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000E04AC: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:20 offset1:21      // 0000000E04B4: D8DC1514 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 0000000E04BC: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 0000000E04C4: D8DC6554 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000E04CC: D8DC8776 4A000030
	s_waitcnt lgkmcnt(6)                                       // 0000000E04D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E04D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E04DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E04E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E04E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E04E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E04EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E04F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E04F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E04F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E04FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0500: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0504: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0508: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E050C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0510: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 0000000E0514: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 0000000E051C: D8DCA998 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 0000000E0524: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 0000000E052C: D8DCCBBA 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:28 offset1:29      // 0000000E0534: D8DC1D1C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000E053C: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 0000000E0544: D8DCEDDC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:126 offset1:143    // 0000000E054C: D8DC8F7E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 0000000E0554: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E0558: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E055C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E0560: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E0564: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E0568: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E056C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E0570: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E0574: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E0578: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E057C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0580: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0584: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0588: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E058C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0590: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 0000000E0594: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 0000000E059C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 0000000E05A4: D8DC2322 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:66 offset1:83      // 0000000E05AC: D8DC5342 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:36 offset1:37      // 0000000E05B4: D8DC2524 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 0000000E05BC: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000E05C4: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000E05CC: D8DC9786 4A000032
	s_waitcnt lgkmcnt(6)                                       // 0000000E05D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E05D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E05DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E05E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E05E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E05E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E05EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E05F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E05F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E05F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E05FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0600: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0604: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0608: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E060C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0610: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:40 offset1:41      // 0000000E0614: D8DC2928 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:168 offset1:185    // 0000000E061C: D8DCB9A8 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 0000000E0624: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:202 offset1:219    // 0000000E062C: D8DCDBCA 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:44 offset1:45      // 0000000E0634: D8DC2D2C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 0000000E063C: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 0000000E0644: D8DCFDEC 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:14 offset1:31      // 0000000E064C: D8DC1F0E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000E0654: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E0658: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E065C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E0660: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E0664: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E0668: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E066C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E0670: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E0674: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E0678: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E067C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0680: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0684: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0688: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E068C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0690: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 0000000E0694: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 0000000E069C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 0000000E06A4: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 0000000E06AC: D8DC6352 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:52 offset1:53      // 0000000E06B4: D8DC3534 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 0000000E06BC: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000E06C4: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000E06CC: D8DCA796 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000E06D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E06D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E06DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E06E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E06E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E06E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E06EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E06F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E06F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E06F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E06FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0700: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0704: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0708: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E070C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0710: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:56 offset1:57      // 0000000E0714: D8DC3938 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:184 offset1:201    // 0000000E071C: D8DCC9B8 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 0000000E0724: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:218 offset1:235    // 0000000E072C: D8DCEBDA 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:60 offset1:61      // 0000000E0734: D8DC3D3C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 0000000E073C: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 0000000E0744: D8DC8D7C 48000034
	ds_load_2addr_b32 v[74:75], v53 offset0:30 offset1:47      // 0000000E074C: D8DC2F1E 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000E0754: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E0758: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E075C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E0760: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E0764: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E0768: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E076C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E0770: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E0774: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E0778: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E077C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0780: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0784: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0788: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E078C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0790: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 0000000E0794: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 0000000E079C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 0000000E07A4: D8DC4342 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:98 offset1:115     // 0000000E07AC: D8DC7362 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:68 offset1:69      // 0000000E07B4: D8DC4544 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 0000000E07BC: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000E07C4: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000E07CC: D8DCB7A6 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000E07D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E07D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E07DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E07E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E07E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E07E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E07EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E07F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E07F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E07F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E07FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0800: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0804: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0808: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E080C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0810: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 0000000E0814: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 0000000E081C: D8DCD9C8 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 0000000E0824: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 0000000E082C: D8DCFBEA 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:76 offset1:77      // 0000000E0834: D8DC4D4C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 0000000E083C: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 0000000E0844: D8DC1D0C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:46 offset1:63      // 0000000E084C: D8DC3F2E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000E0854: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E0858: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E085C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E0860: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E0864: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E0868: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E086C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E0870: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E0874: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E0878: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E087C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0880: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0884: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0888: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E088C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0890: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 0000000E0894: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 0000000E089C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 0000000E08A4: D8DC5352 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:114 offset1:131    // 0000000E08AC: D8DC8372 42000036
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:85      // 0000000E08B4: D8DC5554 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 0000000E08BC: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000E08C4: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000E08CC: D8DCC7B6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000E08D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E08D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E08DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E08E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E08E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E08E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E08EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E08F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E08F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E08F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E08FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0900: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0904: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0908: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E090C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0910: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:88 offset1:89      // 0000000E0914: D8DC5958 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:216 offset1:233    // 0000000E091C: D8DCE9D8 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:90 offset1:91      // 0000000E0924: D8DC5B5A 4000002E
	ds_load_2addr_b32 v[66:67], v55 offset0:122 offset1:139    // 0000000E092C: D8DC8B7A 42000037
	ds_load_2addr_b32 v[68:69], v46 offset0:92 offset1:93      // 0000000E0934: D8DC5D5C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 0000000E093C: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 0000000E0944: D8DC2D1C 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:62 offset1:79      // 0000000E094C: D8DC4F3E 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000E0954: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E0958: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E095C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E0960: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E0964: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E0968: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E096C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E0970: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E0974: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E0978: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E097C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0980: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0984: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0988: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E098C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0990: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 0000000E0994: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 0000000E099C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 0000000E09A4: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 0000000E09AC: D8DC9382 42000038
	ds_load_2addr_b32 v[68:69], v46 offset0:100 offset1:101    // 0000000E09B4: D8DC6564 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 0000000E09BC: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000E09C4: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000E09CC: D8DCD7C6 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000E09D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E09D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E09DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E09E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E09E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E09E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E09EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E09F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E09F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E09F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E09FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0A00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0A04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0A08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E0A0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0A10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:104 offset1:105    // 0000000E0A14: D8DC6968 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:232 offset1:249    // 0000000E0A1C: D8DCF9E8 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 0000000E0A24: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:10 offset1:27      // 0000000E0A2C: D8DC1B0A 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:108 offset1:109    // 0000000E0A34: D8DC6D6C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 0000000E0A3C: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 0000000E0A44: D8DC3D2C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:78 offset1:95      // 0000000E0A4C: D8DC5F4E 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000E0A54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E0A58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E0A5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E0A60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E0A64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E0A68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E0A6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E0A70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E0A74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E0A78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E0A7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0A80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0A84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0A88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E0A8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0A90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 0000000E0A94: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 0000000E0A9C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 0000000E0AA4: D8DC7372 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:146 offset1:163    // 0000000E0AAC: D8DCA392 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:116 offset1:117    // 0000000E0AB4: D8DC7574 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 0000000E0ABC: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000E0AC4: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000E0ACC: D8DCE7D6 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000E0AD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E0AD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E0ADC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E0AE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000E0AE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E0AE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E0AEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E0AF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000E0AF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E0AF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E0AFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0B00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000E0B04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0B08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E0B0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0B10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 0000000E0B14: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 0000000E0B1C: D8DC8978 3E00003A
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 0000000E0B24: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:26 offset1:43      // 0000000E0B2C: D8DC2B1A 4200003B
	ds_load_2addr_b32 v[68:69], v46 offset0:124 offset1:125    // 0000000E0B34: D8DC7D7C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 0000000E0B3C: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 0000000E0B44: D8DC4D3C 4800003B
	ds_load_2addr_b32 v[74:75], v59 offset0:94 offset1:111     // 0000000E0B4C: D8DC6F5E 4A00003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000E0B54: 30424282
	s_waitcnt lgkmcnt(6)                                       // 0000000E0B58: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000E0B5C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 0000000E0B60: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000E0B68: CA10011E 2220011D
	v_mov_b32_e32 v62, v35                                     // 0000000E0B70: 7E7C0323
	v_fmac_f32_e32 v76, v61, v63                               // 0000000E0B74: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 0000000E0B78: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 0000000E0B7C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0B80: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 0000000E0B84: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 0000000E0B88: 56988741
	s_waitcnt lgkmcnt(2)                                       // 0000000E0B8C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0B90: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 0000000E0B94: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 0000000E0B98: 56989345
	s_waitcnt lgkmcnt(1)                                       // 0000000E0B9C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0BA0: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 0000000E0BA4: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 0000000E0BA8: 56989747
	s_waitcnt lgkmcnt(0)                                       // 0000000E0BAC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E0BB0: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 0000000E0BB4: 1078794C
	s_nop 0                                                    // 0000000E0BB8: BF800000
	s_nop 0                                                    // 0000000E0BBC: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000E0BC0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000E0BC8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000E0BD0: 4A7C7CC1
	.long 0xd7000121                                           // 0000000E0BD4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000E0BD8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000E0BDC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000E0BE0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000E0BE8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000E0BEC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000E0BF0: 4A7A7AFF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000E0BF8: 8C0E0E04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E0BFC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 0000000E0C00: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000E0C04: 917E0E7E
	s_cbranch_execnz 65517                                     // 0000000E0C08: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11c0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000E0C0C: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E0C10: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 0000000E0C14: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 0000000E0C1C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 0000000E0C28: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 0000000E0C34: DC960000 007C2421
	s_branch 64909                                             // 0000000E0C3C: BFA0FD8D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x874>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000E0C40: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 0000000E0C48: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000E0C4C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000E0C50: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000E0C58: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000E0C5C: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000E0C64: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000E0C6C: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000E0C70: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000E0C74: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000E0C7C: A0010401
	s_mov_b32 s4, 0                                            // 0000000E0C80: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000E0C84: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000E0C88: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000E0C8C: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000E0C90: BF870585
	.long 0xd71c001d                                           // 0000000E0C94: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000E0C98: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000E0C9C: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000E0CA0: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000E0CA8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000E0CAC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000E0CB4: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000000E0CB8: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000E0CBC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000E0CC8: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000E0CD0: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E0CD8: BF870001
	.long 0xd4490001                                           // 0000000E0CDC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000E0CE0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000E0CE8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000E0CEC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000E0CF0: 1040411E
	ds_store_b32 v29, v32                                      // 0000000E0CF4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000E0CFC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000E0D04: 917E047E
	s_cbranch_execnz 65519                                     // 0000000E0D08: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x12c8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000E0D0C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000E0D10: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 0000000E0D18: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 0000000E0D20: 7E420326
	s_mov_b32 s10, 0                                           // 0000000E0D24: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000E0D28: BF89FC07
	s_barrier                                                  // 0000000E0D2C: BFBD0000
	buffer_gl0_inv                                             // 0000000E0D30: E0AC0000 00000000
	s_nop 0                                                    // 0000000E0D38: BF800000
	s_nop 0                                                    // 0000000E0D3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000E0D40: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 0000000E0D48: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000E0D50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000E0D58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000E0D5C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000E0D64: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000E0D68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000E0D70: BF870004
	.long 0xd4490004                                           // 0000000E0D74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000E0D78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000E0D80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E0D84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000E0D88: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 0000000E0D8C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000E0D94: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000E0D9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000E0DA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1340>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000E0DA4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000E0DA8: BF89FC07
	s_barrier                                                  // 0000000E0DAC: BFBD0000
	buffer_gl0_inv                                             // 0000000E0DB0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000E0DB8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000000E0DC0: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000000E0DC8: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000000E0DD0: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000E0DD8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000E0DDC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000E0DE0: BF840001
	s_nop 0                                                    // 0000000E0DE4: BF800000
	s_nop 0                                                    // 0000000E0DE8: BF800000
	s_nop 0                                                    // 0000000E0DEC: BF800000
	s_nop 0                                                    // 0000000E0DF0: BF800000
	s_nop 0                                                    // 0000000E0DF4: BF800000
	s_nop 0                                                    // 0000000E0DF8: BF800000
	s_nop 0                                                    // 0000000E0DFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E0E00: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000E0E04: 327A7884
	.long 0xd4490001                                           // 0000000E0E08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000E0E0C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000E0E14: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000E0E18: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000E0E24: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000E0E28: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000E0E30: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000E0E38: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000E0E40: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000E0E48: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000E0E50: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000E0E58: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000E0E60: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000E0E64: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000E0E70: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000E0E74: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000E0E78: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000E0E80: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000E0E84: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000E0E88: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000E0E8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0E90: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000E0E94: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000E0E98: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000E0E9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E0EA0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000E0EA4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000E0EB0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000E0EB8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000E0EC0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000E0EC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1400>
	s_set_inst_prefetch_distance 0x2                           // 0000000E0EC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000E0ECC: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000000E0ED0: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000E0ED8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000E0EE0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000E0EE4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000E0EE8: BF89FC07
	s_barrier                                                  // 0000000E0EEC: BFBD0000
	buffer_gl0_inv                                             // 0000000E0EF0: E0AC0000 00000000
	s_nop 0                                                    // 0000000E0EF8: BF800000
	s_nop 0                                                    // 0000000E0EFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000E0F00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 0000000E0F08: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000E0F10: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000E0F18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000E0F1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000E0F24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000E0F28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000E0F30: BF870004
	.long 0xd4490004                                           // 0000000E0F34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000E0F38: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000E0F40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E0F44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000E0F48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000E0F4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000E0F54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000E0F5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000E0F60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1500>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000E0F64: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000E0F68: BF89FC07
	s_barrier                                                  // 0000000E0F6C: BFBD0000
	buffer_gl0_inv                                             // 0000000E0F70: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000E0F78: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000000E0F80: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000000E0F88: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000000E0F90: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000E0F98: 7E780300
	s_mov_b32 s4, 0                                            // 0000000E0F9C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000E0FA0: BF840001
	s_nop 0                                                    // 0000000E0FA4: BF800000
	s_nop 0                                                    // 0000000E0FA8: BF800000
	s_nop 0                                                    // 0000000E0FAC: BF800000
	s_nop 0                                                    // 0000000E0FB0: BF800000
	s_nop 0                                                    // 0000000E0FB4: BF800000
	s_nop 0                                                    // 0000000E0FB8: BF800000
	s_nop 0                                                    // 0000000E0FBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E0FC0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000E0FC4: 327A7884
	.long 0xd4490001                                           // 0000000E0FC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000E0FCC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000E0FD4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000E0FD8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000E0FE4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000E0FE8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000E0FF0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000E0FF8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000E1000: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000E1008: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000E1010: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000E1018: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000E1020: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000E1024: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000E1030: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000E1034: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000E1038: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000E1040: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000E1044: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000E1048: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000E104C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1050: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000E1054: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000E1058: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000E105C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1060: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000E1064: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000E1070: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000E1078: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000E1080: 917E047E
	s_cbranch_execnz 65486                                     // 0000000E1084: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000E1088: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000E108C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000000E1090: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000E1098: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000E10A0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000E10A4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000E10A8: BF89FC07
	s_barrier                                                  // 0000000E10AC: BFBD0000
	buffer_gl0_inv                                             // 0000000E10B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000E10B8: BF800000
	s_nop 0                                                    // 0000000E10BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000E10C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000000E10C8: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000E10D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000E10D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000E10DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000E10E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000E10E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000E10F0: BF870004
	.long 0xd4490004                                           // 0000000E10F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000E10F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000E1100: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E1104: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000E1108: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000E110C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000E1114: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000E111C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000E1120: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000E1124: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000E1128: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000E1130: BF89FC07
	s_barrier                                                  // 0000000E1134: BFBD0000
	buffer_gl0_inv                                             // 0000000E1138: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000E1140: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 0000000E1144: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 0000000E114C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 0000000E1154: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 0000000E115C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000E1164: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000E1168: BF840001
	s_nop 0                                                    // 0000000E116C: BF800000
	s_nop 0                                                    // 0000000E1170: BF800000
	s_nop 0                                                    // 0000000E1174: BF800000
	s_nop 0                                                    // 0000000E1178: BF800000
	s_nop 0                                                    // 0000000E117C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000E1180: 327C7A84
	.long 0xd4490001                                           // 0000000E1184: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000E1188: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000E1190: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000E1194: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000E1198: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000E11A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000E11A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000E11B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000E11B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000E11C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000E11C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000E11D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000E11D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000E11E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000E11E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000E11E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000E11EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000E11F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000E1200: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000E1204: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000E1208: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000E120C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1210: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000E1214: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000E1218: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000E121C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1220: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000E1224: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000E1230: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000E1238: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000E1240: 917E047E
	s_cbranch_execnz 65486                                     // 0000000E1244: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1780>
	s_set_inst_prefetch_distance 0x2                           // 0000000E1248: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000E124C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000E1250: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000E1258: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000E1260: 7E420326
	s_mov_b32 s10, 0                                           // 0000000E1264: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000E1268: BF89FC07
	s_barrier                                                  // 0000000E126C: BFBD0000
	buffer_gl0_inv                                             // 0000000E1270: E0AC0000 00000000
	s_nop 0                                                    // 0000000E1278: BF800000
	s_nop 0                                                    // 0000000E127C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000E1280: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000000E1288: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000E1290: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000E1298: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000E129C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000E12A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000E12A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000E12B0: BF870004
	.long 0xd4490004                                           // 0000000E12B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000E12B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000E12C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E12C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000E12C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000E12CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000E12D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000E12DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000E12E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1880>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000E12E4: 8C7E0A7E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000E12E8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000E12F0: BF89FC07
	s_barrier                                                  // 0000000E12F4: BFBD0000
	buffer_gl0_inv                                             // 0000000E12F8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 0000000E1300: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 0000000E1308: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 0000000E1310: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 0000000E1318: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000E1320: 7E780300
	s_mov_b32 s4, 0                                            // 0000000E1324: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000E1328: BF840001
	s_nop 0                                                    // 0000000E132C: BF800000
	s_nop 0                                                    // 0000000E1330: BF800000
	s_nop 0                                                    // 0000000E1334: BF800000
	s_nop 0                                                    // 0000000E1338: BF800000
	s_nop 0                                                    // 0000000E133C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1340: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000E1344: 327A7884
	.long 0xd4490001                                           // 0000000E1348: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000E134C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000E1354: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000E1358: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000E1364: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000E1368: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000E1370: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000E1378: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000E1380: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000E1388: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000E1390: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000E1398: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000E13A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000E13A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000E13B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000E13B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000E13B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000E13C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000E13C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000E13C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000E13CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E13D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000E13D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000E13D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000E13DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E13E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000E13E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000E13F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000E13F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000E1400: 917E047E
	s_cbranch_execnz 65486                                     // 0000000E1404: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_set_inst_prefetch_distance 0x2                           // 0000000E1408: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000E140C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 0000000E1410: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000E1418: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000E1420: 7E420326
	s_mov_b32 s10, 0                                           // 0000000E1424: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000E1428: BF89FC07
	s_barrier                                                  // 0000000E142C: BFBD0000
	buffer_gl0_inv                                             // 0000000E1430: E0AC0000 00000000
	s_nop 0                                                    // 0000000E1438: BF800000
	s_nop 0                                                    // 0000000E143C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000E1440: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 0000000E1448: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000E1450: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000E1458: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000E145C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000E1464: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000E1468: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000E1470: BF870004
	.long 0xd4490004                                           // 0000000E1474: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000E1478: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000E1480: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E1484: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000E1488: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000E148C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000E1494: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000E149C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000E14A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000E14A4: 8C7E0A7E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000000E14A8: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000E14B0: BF89FC07
	s_barrier                                                  // 0000000E14B4: BFBD0000
	buffer_gl0_inv                                             // 0000000E14B8: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000000E14C0: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000000E14C4: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000000E14CC: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000000E14D4: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000000E14DC: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000E14E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000E14E8: BF840001
	s_nop 0                                                    // 0000000E14EC: BF800000
	s_nop 0                                                    // 0000000E14F0: BF800000
	s_nop 0                                                    // 0000000E14F4: BF800000
	s_nop 0                                                    // 0000000E14F8: BF800000
	s_nop 0                                                    // 0000000E14FC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 0000000E1500: 327C7884
	.long 0xd4490001                                           // 0000000E1504: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000E1508: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000E1510: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000E1514: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000E1518: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000E1524: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000E1528: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000E1530: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000E1538: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000E1540: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000E1548: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000E1550: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000E1558: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000E1560: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000E1564: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000E1568: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000E156C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000E1578: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000E1580: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000E1584: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000E1588: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000E158C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1590: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000E1594: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000E1598: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000E159C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E15A0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000000E15A4: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 0000000E15B0: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000E15B4: BF870002
	v_mov_b32_e32 v60, v63                                     // 0000000E15B8: 7E78033F
	ds_store_b32 v62, v70                                      // 0000000E15BC: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000E15C4: 917E047E
	s_cbranch_execnz 65485                                     // 0000000E15C8: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_set_inst_prefetch_distance 0x2                           // 0000000E15CC: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000E15D0: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000000E15D4: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000E15DC: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000E15E4: 7E420326
	s_mov_b32 s10, 0                                           // 0000000E15E8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000E15EC: BF89FC07
	s_barrier                                                  // 0000000E15F0: BFBD0000
	buffer_gl0_inv                                             // 0000000E15F4: E0AC0000 00000000
	s_nop 0                                                    // 0000000E15FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000E1600: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 0000000E1608: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000E1610: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000E1618: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000E161C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000E1624: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000E1628: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000E1630: BF870004
	.long 0xd4490004                                           // 0000000E1634: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000E1638: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000E1640: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E1644: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000E1648: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000E164C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000E1654: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000E165C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000E1660: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000E1664: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000000E1668: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000E1670: BF89FC07
	s_barrier                                                  // 0000000E1674: BFBD0000
	buffer_gl0_inv                                             // 0000000E1678: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000000E1680: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000000E1688: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000000E1690: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000000E1698: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000E16A0: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000E16A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000E16A8: BF840001
	s_nop 0                                                    // 0000000E16AC: BF800000
	s_nop 0                                                    // 0000000E16B0: BF800000
	s_nop 0                                                    // 0000000E16B4: BF800000
	s_nop 0                                                    // 0000000E16B8: BF800000
	s_nop 0                                                    // 0000000E16BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E16C0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000E16C4: 327C7A84
	.long 0xd4490001                                           // 0000000E16C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000E16CC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000E16D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000E16D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000E16E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000E16E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000E16F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000E16F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000E1700: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000E1708: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000E1710: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000E1718: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000E1720: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000E1724: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000E1728: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000E172C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000E1738: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000E1740: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000E1744: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000E1748: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000E174C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1750: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000E1754: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000E1758: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000E175C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1760: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000E1764: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000E1770: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000E1778: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000E1780: 917E047E
	s_cbranch_execnz 65486                                     // 0000000E1784: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_set_inst_prefetch_distance 0x2                           // 0000000E1788: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000E178C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 0000000E1790: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000E1798: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000E17A0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000E17A4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000E17A8: BF89FC07
	s_barrier                                                  // 0000000E17AC: BFBD0000
	buffer_gl0_inv                                             // 0000000E17B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000E17B8: BF800000
	s_nop 0                                                    // 0000000E17BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000E17C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000E17C8: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000E17D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000E17D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000E17DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000E17E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000E17E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000E17F0: BF870004
	.long 0xd4490004                                           // 0000000E17F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000E17F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000E1800: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E1804: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000E1808: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000E180C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000E1814: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000E181C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000E1820: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000E1824: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000E1828: BF89FC07
	s_barrier                                                  // 0000000E182C: BFBD0000
	buffer_gl0_inv                                             // 0000000E1830: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 0000000E1838: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 0000000E1840: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 0000000E1848: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 0000000E1850: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000E1858: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000E185C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000E1860: BF840001
	s_nop 0                                                    // 0000000E1864: BF800000
	s_nop 0                                                    // 0000000E1868: BF800000
	s_nop 0                                                    // 0000000E186C: BF800000
	s_nop 0                                                    // 0000000E1870: BF800000
	s_nop 0                                                    // 0000000E1874: BF800000
	s_nop 0                                                    // 0000000E1878: BF800000
	s_nop 0                                                    // 0000000E187C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1880: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000E1884: 327C7A84
	.long 0xd4490001                                           // 0000000E1888: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000E188C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000E1894: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000E1898: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000E18A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000E18A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000E18B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000E18B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000E18C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000E18C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000E18D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000E18D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000E18E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000E18E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000E18E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000E18EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000E18F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000E1900: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000E1904: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000E1908: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000E190C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1910: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000E1914: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000E1918: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000E191C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1920: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000E1924: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000E1930: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000E1938: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000E1940: 917E047E
	s_cbranch_execnz 65486                                     // 0000000E1944: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e80>
	s_set_inst_prefetch_distance 0x2                           // 0000000E1948: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000E194C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000E1950: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000E1958: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000E1960: 7E420326
	s_mov_b32 s10, 0                                           // 0000000E1964: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000E1968: BF89FC07
	s_barrier                                                  // 0000000E196C: BFBD0000
	buffer_gl0_inv                                             // 0000000E1970: E0AC0000 00000000
	s_nop 0                                                    // 0000000E1978: BF800000
	s_nop 0                                                    // 0000000E197C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000E1980: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000000E1988: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000E1990: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000E1998: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000E199C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000E19A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000E19A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000E19B0: BF870004
	.long 0xd4490004                                           // 0000000E19B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000E19B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000E19C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000E19C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000E19C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000E19CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000E19D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000E19DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000E19E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000E19E4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000E19E8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000E19F0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000E19F8: BF89FC07
	s_barrier                                                  // 0000000E19FC: BFBD0000
	buffer_gl0_inv                                             // 0000000E1A00: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 0000000E1A08: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 0000000E1A10: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000E1A18: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 0000000E1A20: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000E1A28: 7E780300
	s_mov_b32 s4, 0                                            // 0000000E1A2C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000E1A30: BF840001
	s_nop 0                                                    // 0000000E1A34: BF800000
	s_nop 0                                                    // 0000000E1A38: BF800000
	s_nop 0                                                    // 0000000E1A3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000E1A40: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000E1A44: 327A7884
	.long 0xd4490001                                           // 0000000E1A48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000E1A4C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000E1A54: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000E1A58: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000E1A64: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000E1A68: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000E1A70: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000E1A78: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000E1A80: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000E1A88: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000E1A90: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000E1A98: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000E1AA0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000E1AA4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000E1AB0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000E1AB4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000E1AB8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000E1AC0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000E1AC4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000E1AC8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000E1ACC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1AD0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000E1AD4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000E1AD8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000E1ADC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1AE0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000E1AE4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000E1AF0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000E1AF8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000E1B00: 917E047E
	s_cbranch_execnz 65486                                     // 0000000E1B04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_set_inst_prefetch_distance 0x2                           // 0000000E1B08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000E1B0C: 8C7E047E
	.long 0xd7000107                                           // 0000000E1B10: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000E1B14: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E1B1C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000E1B20: D5207C08 00061080
	.long 0xd7000109                                           // 0000000E1B28: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000E1B2C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000E1B34: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000E1B3C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000E1B40: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E1B48: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000E1B4C: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000E1B54: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000E1B58: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000E1B60: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000E1B68: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000E1B6C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E1B74: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000E1B78: D5207C10 00062080
	.long 0xd7000111                                           // 0000000E1B80: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000E1B84: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000E1B8C: D5207C12 00062480
	.long 0xd7000113                                           // 0000000E1B94: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000E1B98: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E1BA0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000E1BA4: D5207C14 00062880
	.long 0xd7000115                                           // 0000000E1BAC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000E1BB0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000E1BB8: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000E1BC0: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000E1BC4: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000E1BCC: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000E1BD0: D5207C18 00063080
	.long 0xd7000119                                           // 0000000E1BD8: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000E1BDC: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000E1BE4: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000E1BEC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000E1BF0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000E1BF8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000E1BFC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000E1C04: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000E1C08: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000E1C0C: BF062105
	s_barrier                                                  // 0000000E1C10: BFBD0000
	buffer_gl0_inv                                             // 0000000E1C14: E0AC0000 00000000
	s_cbranch_scc0 63589                                       // 0000000E1C1C: BFA1F865 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b4>
	v_mov_b32_e32 v4, v38                                      // 0000000E1C20: 7E080326
	s_add_u32 s0, s28, s20                                     // 0000000E1C24: 8000141C
	.long 0xd73c0000                                           // 0000000E1C28: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000E1C2C: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000E1C30: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000E1C34: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000E1C38: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000E1C3C: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000E1C40: 82010103
	.long 0xd7006a00                                           // 0000000E1C44: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000E1C48: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000E1C4C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000E1C50: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000E1C58: BE810080
	.long 0xd7006a00                                           // 0000000E1C5C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 0000000E1C60: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000E1C64: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000E1C6C: BF870092
	.long 0xd7006a00                                           // 0000000E1C70: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000E1C74: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000E1C78: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 0000000E1C80: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000E1C88: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000000E1C90: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000E1C98: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000E1C9C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000E1CA4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000E1CA8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000E1CAC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000E1CB4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000E1CB8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000E1CC0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000E1CC8: 917E017E
	s_cbranch_execnz 65516                                     // 0000000E1CCC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi20ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2280>
	s_endpgm                                                   // 0000000E1CD0: BFB00000
		...

