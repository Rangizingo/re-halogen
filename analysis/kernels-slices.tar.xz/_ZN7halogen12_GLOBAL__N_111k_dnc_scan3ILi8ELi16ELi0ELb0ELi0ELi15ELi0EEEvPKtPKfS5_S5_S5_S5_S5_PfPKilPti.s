00000000000ec700 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000EC700: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000EC704: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000EC70C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000EC714: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000EC718: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000EC71C: 861B9F1A
	v_and_b32_e32 v8, 15, v0                                   // 0000000EC720: 3610008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000EC724: BF8704C1
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v1, 2, v8      // 0000000EC728: CA220100 04001082
	s_waitcnt lgkmcnt(0)                                       // 0000000EC730: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000EC734: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000EC73C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000EC740: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000EC744: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000EC748: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EC74C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000EC750: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000EC754: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000EC758: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000EC75C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000EC764: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000EC76C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000EC770: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000EC774: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000EC778: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000EC77C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000EC780: 821E191E
	.long 0xd7001f02                                           // 0000000EC784: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000EC788: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000EC78C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000EC794: BE9E0080
	s_nop 0                                                    // 0000000EC798: BF800000
	s_nop 0                                                    // 0000000EC79C: BF800000
	s_nop 0                                                    // 0000000EC7A0: BF800000
	s_nop 0                                                    // 0000000EC7A4: BF800000
	s_nop 0                                                    // 0000000EC7A8: BF800000
	s_nop 0                                                    // 0000000EC7AC: BF800000
	s_nop 0                                                    // 0000000EC7B0: BF800000
	s_nop 0                                                    // 0000000EC7B4: BF800000
	s_nop 0                                                    // 0000000EC7B8: BF800000
	s_nop 0                                                    // 0000000EC7BC: BF800000
	v_lshrrev_b32_e32 v7, 4, v4                                // 0000000EC7C0: 320E0884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000EC7C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EC7CC: BF870092
	v_lshlrev_b32_e32 v5, 9, v7                                // 0000000EC7D0: 300A0E89
	.long 0xd7006a05                                           // 0000000EC7D4: D7006A05
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 0000000EC7D8: 02020B02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EC7DC: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v3, vcc_lo                // 0000000EC7E0: D5207C06 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000EC7E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000EC7F0: 7E08030A
	global_load_b32 v9, v[5:6], off                            // 0000000EC7F4: DC520000 097C0005
	v_mad_u64_u32 v[5:6], null, 0x44, v7, v[1:2]               // 0000000EC7FC: D6FE7C05 04060EFF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000EC808: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000EC80C: BF8903F7
	ds_store_b32 v5, v9                                        // 0000000EC810: D8340000 00000905
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000EC818: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000EC81C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000EC820: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000EC824: F4000780 F8000058
	v_or_b32_e32 v43, 0xffffff80, v0                           // 0000000EC82C: 385600FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000EC834: 32040084
	s_mov_b32 s0, 0                                            // 0000000EC838: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000EC83C: BF89FC07
	s_barrier                                                  // 0000000EC840: BFBD0000
	buffer_gl0_inv                                             // 0000000EC844: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000EC84C: BF02801E
	s_cbranch_scc1 11                                          // 0000000EC850: BFA2000B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x180>
	v_lshrrev_b32_e32 v3, 4, v0                                // 0000000EC854: 32060084
	v_mov_b32_e32 v4, 0                                        // 0000000EC858: 7E080280
	v_or_b32_e32 v7, 0xffffff80, v0                            // 0000000EC85C: 380E00FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EC864: BF870002
	v_dual_mov_b32 v6, v4 :: v_dual_mov_b32 v5, v3             // 0000000EC868: CA100104 06040103
	v_lshlrev_b32_e32 v4, 2, v8                                // 0000000EC870: 30081082
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000EC874: 916A007E
	s_cbranch_vccz 2                                           // 0000000EC878: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	s_branch 2570                                              // 0000000EC87C: BFA00A0A <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29a8>
	v_lshlrev_b32_e32 v4, 2, v8                                // 0000000EC880: 30081082
	s_add_i32 s0, s30, 63                                      // 0000000EC884: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000EC888: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000EC890: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000EC894: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000EC898: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000EC89C: 84008702
	v_lshlrev_b32_e32 v5, 1, v8                                // 0000000EC8A0: 300A1081
	s_ashr_i32 s1, s0, 31                                      // 0000000EC8A4: 86019F00
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v44, 2, v0      // 0000000EC8A8: CA220080 032C0082
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000EC8B0: 84808100
	v_lshlrev_b32_e32 v11, 8, v2                               // 0000000EC8B4: 30160488
	s_add_u32 s22, s22, s0                                     // 0000000EC8B8: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000EC8BC: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000EC8C0: 848A811A
	v_add_nc_u32_e32 v45, 0x5340, v44                          // 0000000EC8C4: 4A5A58FF 00005340
	s_add_u32 s10, s22, s10                                    // 0000000EC8CC: 800A0A16
	s_addc_u32 s1, s1, s11                                     // 0000000EC8D0: 82010B01
	.long 0xd7000a09                                           // 0000000EC8D4: D7000A09
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000000EC8D8: 02020A0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EC8DC: BF870001
	v_add_co_ci_u32_e64 v10, null, s1, 0, s10                  // 0000000EC8E0: D5207C0A 00290001
	.long 0xd7000137                                           // 0000000EC8E8: D7000137
	v_cndmask_b32_e32 v1, s4, v44, vcc_lo                      // 0000000EC8EC: 02025804
	.long 0xd7000439                                           // 0000000EC8F0: D7000439
	v_cndmask_b32_e32 v1, s6, v44, vcc_lo                      // 0000000EC8F4: 02025806
	v_add_co_ci_u32_e64 v56, null, s5, 0, s1                   // 0000000EC8F8: D5207C38 00050005
	s_movk_i32 s1, 0x204                                       // 0000000EC900: B0010204
	v_add_co_ci_u32_e64 v58, null, s7, 0, s4                   // 0000000EC904: D5207C3A 00110007
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000EC90C: 84848E02
	v_mad_u32_u24 v59, v2, s1, 0x2200                          // 0000000EC910: D60B003B 03FC0302 00002200
	s_add_u32 s1, s14, s4                                      // 0000000EC91C: 8001040E
	s_addc_u32 s4, s15, s5                                     // 0000000EC920: 8204050F
	.long 0xd700010b                                           // 0000000EC924: D700010B
	v_cndmask_b32_e32 v1, s1, v11, vcc_lo                      // 0000000EC928: 02021601
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EC92C: BF870001
	v_add_co_ci_u32_e64 v12, null, s4, 0, s1                   // 0000000EC930: D5207C0C 00050004
	s_lshl_b64 s[4:5], s[2:3], 9                               // 0000000EC938: 84848902
	v_mov_b32_e32 v6, v3                                       // 0000000EC93C: 7E0C0303
	v_dual_mov_b32 v5, v2 :: v_dual_add_nc_u32 v46, 0x5440, v44// 0000000EC940: CA200102 052E58FF 00005440
	v_or_b32_e32 v3, s4, v44                                   // 0000000EC94C: 38065804
	.long 0xd700010d                                           // 0000000EC950: D700010D
	v_cndmask_b32_e32 v1, 0x1000, v11, vcc_lo                  // 0000000EC954: 020216FF 00001000
	v_dual_mov_b32 v18, s5 :: v_dual_add_nc_u32 v47, 1, v2     // 0000000EC95C: CA200005 122E0481
	v_add_co_ci_u32_e64 v14, null, 0, v12, s1                  // 0000000EC964: D5207C0E 00061880
	.long 0xd700010f                                           // 0000000EC96C: D700010F
	v_cndmask_b32_e32 v1, 0x2000, v11, vcc_lo                  // 0000000EC970: 020216FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EC978: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000EC97C: D5207C10 00061880
	.long 0xd7000111                                           // 0000000EC984: D7000111
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 0000000EC988: 02020606
	v_add_co_ci_u32_e64 v18, null, s7, v18, s1                 // 0000000EC98C: D5207C12 00062407
	.long 0xd7000113                                           // 0000000EC994: D7000113
	v_cndmask_b32_e32 v1, 0x3000, v11, vcc_lo                  // 0000000EC998: 020216FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EC9A0: BF870211
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000EC9A4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000EC9AC: D7000115
	v_cndmask_b32_e32 v1, 0x60000, v17, vcc_lo                 // 0000000EC9B0: 020222FF 00060000
	.long 0xd7000b30                                           // 0000000EC9B8: D7000B30
	v_cndmask_b32_e32 v1, s12, v44, vcc_lo                     // 0000000EC9BC: 0202580C
	v_add_co_ci_u32_e64 v22, null, 0, v18, s1                  // 0000000EC9C0: D5207C16 00062480
	.long 0xd7000117                                           // 0000000EC9C8: D7000117
	v_cndmask_b32_e32 v1, 0xc0000, v17, vcc_lo                 // 0000000EC9CC: 020222FF 000C0000
	v_add_co_ci_u32_e64 v49, null, s13, 0, s11                 // 0000000EC9D4: D5207C31 002D000D
	.long 0xd7000b32                                           // 0000000EC9DC: D7000B32
	v_cndmask_b32_e32 v1, s34, v4, vcc_lo                      // 0000000EC9E0: 02020822
	v_add_co_ci_u32_e64 v24, null, 0, v18, s1                  // 0000000EC9E4: D5207C18 00062480
	.long 0xd7000119                                           // 0000000EC9EC: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v17, vcc_lo                // 0000000EC9F0: 020222FF 00120000
	.long 0xd44c0000                                           // 0000000EC9F8: D44C0000
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 0000000EC9FC: 020200FF 00000100
	v_or_b32_e32 v7, 0x2200, v44                               // 0000000ECA04: 380E58FF 00002200
	v_add_co_ci_u32_e64 v51, null, s35, 0, s11                 // 0000000ECA0C: D5207C33 002D0023
	v_or_b32_e32 v8, 0x4240, v1                                // 0000000ECA14: 381002FF 00004240
	v_add_nc_u32_e32 v52, 17, v2                               // 0000000ECA1C: 4A680491
	v_add_nc_u32_e32 v53, 33, v2                               // 0000000ECA20: 4A6A04A1
	v_add_nc_u32_e32 v54, 49, v2                               // 0000000ECA24: 4A6C04B1
	v_add_co_ci_u32_e64 v26, null, 0, v18, s1                  // 0000000ECA28: D5207C1A 00062480
	s_mov_b32 s5, 0                                            // 0000000ECA30: BE850080
	s_mov_b32 s6, 0                                            // 0000000ECA34: BE860080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000ECA38: 7C9800C0
	s_mul_i32 s1, s6, 0xc00                                    // 0000000ECA3C: 9601FF06 00000C00
	s_lshl_b32 s7, s6, 6                                       // 0000000ECA44: 84078606
	s_add_i32 s10, s31, s1                                     // 0000000ECA48: 810A011F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000ECA4C: BF870499
	s_ashr_i32 s11, s10, 31                                    // 0000000ECA50: 860B9F0A
	s_lshl_b64 s[10:11], s[10:11], 2                           // 0000000ECA54: 848A820A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000ECA58: BF870009
	s_add_u32 s10, s8, s10                                     // 0000000ECA5C: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 0000000ECA60: 820B0B09
	s_load_b32 s10, s[10:11], null                             // 0000000ECA64: F4000285 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000ECA6C: BE84206A
	s_cbranch_execz 79                                         // 0000000ECA70: BFA5004F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4b0>
	v_or_b32_e32 v3, s7, v0                                    // 0000000ECA74: 38060007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECA78: BF870091
	v_mad_u64_u32 v[27:28], null, v3, 48, s[2:3]               // 0000000ECA7C: D6FE7C1B 00096103
	v_ashrrev_i32_e32 v28, 31, v27                             // 0000000ECA84: 3438369F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECA88: BF870091
	.long 0xd73c001b                                           // 0000000ECA8C: D73C001B
	v_cndmask_b32_e32 v1, 2, v27, vcc_lo                       // 0000000ECA90: 02023682
	.long 0xd700011b                                           // 0000000ECA94: D700011B
	v_cndmask_b32_e32 v1, s8, v27, vcc_lo                      // 0000000ECA98: 02023608
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000ECA9C: BF8700D1
	v_add_co_ci_u32_e64 v28, null, s9, v28, s1                 // 0000000ECAA0: D5207C1C 00063809
	global_load_b32 v3, v[27:28], off                          // 0000000ECAA8: DC520000 037C001B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000ECAB0: BF890007
	v_sub_f32_e32 v27, s10, v3                                 // 0000000ECAB4: 0836060A
	v_mul_f32_e32 v29, 0x3fb8aa3b, v3                          // 0000000ECAB8: 103A06FF 3FB8AA3B
	v_rndne_f32_e32 v33, v29                                   // 0000000ECAC0: 7E42471D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000ECAC4: BF8701A3
	v_mul_f32_e32 v28, 0x3fb8aa3b, v27                         // 0000000ECAC8: 103836FF 3FB8AA3B
	v_fma_f32 v32, 0x3fb8aa3b, v3, -v29                        // 0000000ECAD0: D6130020 847606FF 3FB8AA3B
	v_sub_f32_e32 v29, v29, v33                                // 0000000ECADC: 083A431D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ECAE0: BF870223
	v_fma_f32 v30, 0x3fb8aa3b, v27, -v28                       // 0000000ECAE4: D613001E 847236FF 3FB8AA3B
	v_rndne_f32_e32 v31, v28                                   // 0000000ECAF0: 7E3E471C
	v_fmac_f32_e32 v32, 0x32a5705f, v3                         // 0000000ECAF4: 564006FF 32A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ECAFC: BF870113
	v_fmac_f32_e32 v30, 0x32a5705f, v27                        // 0000000ECB00: 563C36FF 32A5705F
	v_dual_sub_f32 v28, v28, v31 :: v_dual_add_f32 v29, v29, v32// 0000000ECB08: C9483F1C 1C1C411D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ECB10: BF870111
	v_add_f32_e32 v28, v28, v30                                // 0000000ECB14: 06383D1C
	v_exp_f32_e32 v29, v29                                     // 0000000ECB18: 7E3A4B1D
	v_cvt_i32_f32_e32 v30, v31                                 // 0000000ECB1C: 7E3C111F
	v_cvt_i32_f32_e32 v31, v33                                 // 0000000ECB20: 7E3E1121
	.long 0xd41b0001                                           // 0000000ECB24: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v27, vcc_lo              // 0000000ECB28: 020236FF C2CE8ED0
	v_exp_f32_e32 v28, v28                                     // 0000000ECB30: 7E384B1C
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 0000000ECB34: BF870106
	.long 0xd71c001d                                           // 0000000ECB38: D71C001D
	v_cndmask_b32_e32 v1, v29, v31, vcc_lo                     // 0000000ECB3C: 02023F1D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECB40: BF870095
	.long 0xd71c001c                                           // 0000000ECB44: D71C001C
	v_cndmask_b32_e32 v1, v28, v30, vcc_lo                     // 0000000ECB48: 02023D1C
	v_cndmask_b32_e64 v28, 0, v28, s1                          // 0000000ECB4C: D501001C 00063880
	.long 0xd41b0001                                           // 0000000ECB54: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v3, vcc_lo               // 0000000ECB58: 020206FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000ECB60: BF8700A1
	v_cndmask_b32_e64 v29, 0, v29, s1                          // 0000000ECB64: D501001D 00063A80
	.long 0xd41e0001                                           // 0000000ECB6C: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v27, vcc_lo              // 0000000ECB70: 020236FF 42B17218
	v_cndmask_b32_e64 v27, 0x7f800000, v28, s1                 // 0000000ECB78: D501001B 000638FF 7F800000
	.long 0xd41e0001                                           // 0000000ECB84: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v3, vcc_lo               // 0000000ECB88: 020206FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ECB90: BF870001
	v_cndmask_b32_e64 v3, 0x7f800000, v29, s1                  // 0000000ECB94: D5010003 00063AFF 7F800000
	ds_store_b32 v45, v27                                      // 0000000ECBA0: D8340000 00001B2D
	ds_store_b32 v46, v3                                       // 0000000ECBA8: D8340000 0000032E
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000ECBB0: 8C7E047E
	v_mov_b32_e32 v3, v0                                       // 0000000ECBB4: 7E060300
	s_mov_b32 s4, 0                                            // 0000000ECBB8: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000ECBBC: BF89FC07
	s_barrier                                                  // 0000000ECBC0: BFBD0000
	buffer_gl0_inv                                             // 0000000ECBC4: E0AC0000 00000000
	s_nop 0                                                    // 0000000ECBCC: BF800000
	s_nop 0                                                    // 0000000ECBD0: BF800000
	s_nop 0                                                    // 0000000ECBD4: BF800000
	s_nop 0                                                    // 0000000ECBD8: BF800000
	s_nop 0                                                    // 0000000ECBDC: BF800000
	s_nop 0                                                    // 0000000ECBE0: BF800000
	s_nop 0                                                    // 0000000ECBE4: BF800000
	s_nop 0                                                    // 0000000ECBE8: BF800000
	s_nop 0                                                    // 0000000ECBEC: BF800000
	s_nop 0                                                    // 0000000ECBF0: BF800000
	s_nop 0                                                    // 0000000ECBF4: BF800000
	s_nop 0                                                    // 0000000ECBF8: BF800000
	s_nop 0                                                    // 0000000ECBFC: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000ECC00: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000ECC04: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECC0C: BF870092
	v_or_b32_e32 v27, s7, v29                                  // 0000000ECC10: 38363A07
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000ECC14: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECC1C: BF870091
	.long 0xd73c001b                                           // 0000000ECC20: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000ECC24: 02023689
	.long 0xd700011b                                           // 0000000ECC28: D700011B
	v_cndmask_b32_e32 v1, v48, v27, vcc_lo                     // 0000000ECC2C: 02023730
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ECC30: BF870001
	v_add_co_ci_u32_e64 v28, null, v49, v28, s1                // 0000000ECC34: D5207C1C 00063931
	.long 0xd4490001                                           // 0000000ECC3C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000ECC40: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000ECC48: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000ECC4C: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000ECC54: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000ECC60: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000ECC64: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000ECC68: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000ECC70: 917E047E
	s_cbranch_execnz 65506                                     // 0000000ECC74: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x500>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000ECC78: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000ECC7C: BF89FC07
	s_barrier                                                  // 0000000ECC80: BFBD0000
	buffer_gl0_inv                                             // 0000000ECC84: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000ECC8C: BE842000
	s_cbranch_execz 120                                        // 0000000ECC90: BFA50078 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x774>
	v_mov_b32_e32 v3, v59                                      // 0000000ECC94: 7E06033B
	v_mov_b32_e32 v27, v0                                      // 0000000ECC98: 7E360300
	s_mov_b32 s11, 0                                           // 0000000ECC9C: BE8B0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECCA0: BF870091
	v_lshrrev_b32_e32 v28, 4, v27                              // 0000000ECCA4: 32383684
	v_or_b32_e32 v29, s7, v28                                  // 0000000ECCA8: 383A3807
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECCAC: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000ECCB0: D6FE7C1D 0009611D
	.long 0xd73c001d                                           // 0000000ECCB8: D73C001D
	v_cndmask_b32_e32 v1, 9, v29, vcc_lo                       // 0000000ECCBC: 02023A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECCC0: BF870091
	.long 0xd700011d                                           // 0000000ECCC4: D700011D
	v_cndmask_b32_e32 v1, v50, v29, vcc_lo                     // 0000000ECCC8: 02023B32
	v_add_co_ci_u32_e64 v30, null, v51, v30, s1                // 0000000ECCCC: D5207C1E 00063D33
	s_movk_i32 s1, 0xfe00                                      // 0000000ECCD4: B001FE00
	global_load_b32 v30, v[29:30], off                         // 0000000ECCD8: DC520000 1E7C001D
	v_mov_b32_e32 v29, v1                                      // 0000000ECCE0: 7E3A0301
	v_add_nc_u32_e32 v62, s1, v3                               // 0000000ECCE4: 4A7C0601
	s_add_i32 s1, s1, 64                                       // 0000000ECCE8: 8101C001
	ds_load_2addr_b32 v[31:32], v29 offset1:17                 // 0000000ECCEC: D8DC1100 1F00001D
	ds_load_2addr_b32 v[33:34], v62 offset0:128 offset1:129    // 0000000ECCF4: D8DC8180 2100003E
	ds_load_2addr_b32 v[35:36], v29 offset0:34 offset1:51      // 0000000ECCFC: D8DC3322 2300001D
	ds_load_2addr_b32 v[37:38], v62 offset0:130 offset1:131    // 0000000ECD04: D8DC8382 2500003E
	ds_load_2addr_b32 v[39:40], v29 offset0:68 offset1:85      // 0000000ECD0C: D8DC5544 2700001D
	ds_load_2addr_b32 v[41:42], v62 offset0:132 offset1:133    // 0000000ECD14: D8DC8584 2900003E
	ds_load_2addr_b32 v[60:61], v62 offset0:134 offset1:135    // 0000000ECD1C: D8DC8786 3C00003E
	s_cmp_eq_u32 s1, 0                                         // 0000000ECD24: BF068001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000ECD28: BF890057
	v_fma_f32 v30, -v33, v31, v30                              // 0000000ECD2C: D613001E 247A3F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000ECD34: BF8700C1
	v_fma_f32 v32, -v34, v32, v30                              // 0000000ECD38: D6130020 247A4122
	ds_load_2addr_b32 v[30:31], v29 offset0:102 offset1:119    // 0000000ECD40: D8DC7766 1E00001D
	s_waitcnt lgkmcnt(4)                                       // 0000000ECD48: BF89FC47
	v_fma_f32 v32, -v37, v35, v32                              // 0000000ECD4C: D6130020 24824725
	v_fma_f32 v36, -v38, v36, v32                              // 0000000ECD54: D6130024 24824926
	ds_load_2addr_b32 v[32:33], v29 offset0:136 offset1:153    // 0000000ECD5C: D8DC9988 2000001D
	ds_load_2addr_b32 v[34:35], v62 offset0:136 offset1:137    // 0000000ECD64: D8DC8988 2200003E
	s_waitcnt lgkmcnt(4)                                       // 0000000ECD6C: BF89FC47
	v_fma_f32 v36, -v41, v39, v36                              // 0000000ECD70: D6130024 24924F29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000ECD78: BF8700D1
	v_fma_f32 v40, -v42, v40, v36                              // 0000000ECD7C: D6130028 2492512A
	ds_load_2addr_b32 v[36:37], v29 offset0:170 offset1:187    // 0000000ECD84: D8DCBBAA 2400001D
	ds_load_2addr_b32 v[38:39], v62 offset0:138 offset1:139    // 0000000ECD8C: D8DC8B8A 2600003E
	s_waitcnt lgkmcnt(4)                                       // 0000000ECD94: BF89FC47
	v_fma_f32 v30, -v60, v30, v40                              // 0000000ECD98: D613001E 24A23D3C
	v_fma_f32 v42, -v61, v31, v30                              // 0000000ECDA0: D613002A 247A3F3D
	ds_load_2addr_b32 v[30:31], v29 offset0:204 offset1:221    // 0000000ECDA8: D8DCDDCC 1E00001D
	ds_load_2addr_b32 v[40:41], v62 offset0:140 offset1:141    // 0000000ECDB0: D8DC8D8C 2800003E
	ds_load_2addr_b32 v[60:61], v62 offset0:142 offset1:143    // 0000000ECDB8: D8DC8F8E 3C00003E
	s_waitcnt lgkmcnt(5)                                       // 0000000ECDC0: BF89FC57
	v_fma_f32 v32, -v34, v32, v42                              // 0000000ECDC4: D6130020 24AA4122
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000ECDCC: BF8700D1
	v_fma_f32 v34, -v35, v33, v32                              // 0000000ECDD0: D6130022 24824323
	ds_load_2addr_b32 v[32:33], v29 offset0:238 offset1:255    // 0000000ECDD8: D8DCFFEE 2000001D
	v_add_nc_u32_e32 v29, 0x440, v29                           // 0000000ECDE0: 4A3A3AFF 00000440
	s_waitcnt lgkmcnt(4)                                       // 0000000ECDE8: BF89FC47
	v_fma_f32 v34, -v38, v36, v34                              // 0000000ECDEC: D6130022 248A4926
	v_fma_f32 v34, -v39, v37, v34                              // 0000000ECDF4: D6130022 248A4B27
	s_waitcnt lgkmcnt(2)                                       // 0000000ECDFC: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECE00: BF870091
	v_fma_f32 v30, -v40, v30, v34                              // 0000000ECE04: D613001E 248A3D28
	v_fma_f32 v30, -v41, v31, v30                              // 0000000ECE0C: D613001E 247A3F29
	s_waitcnt lgkmcnt(0)                                       // 0000000ECE14: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECE18: BF870091
	v_fma_f32 v30, -v60, v32, v30                              // 0000000ECE1C: D613001E 247A413C
	v_fma_f32 v30, -v61, v33, v30                              // 0000000ECE24: D613001E 247A433D
	s_cbranch_scc0 65453                                       // 0000000ECE2C: BFA1FFAD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5e4>
	v_add_nc_u32_e32 v31, 0x80, v27                            // 0000000ECE30: 4A3E36FF 00000080
	v_mad_u64_u32 v[28:29], null, 0x44, v28, v[8:9]            // 0000000ECE38: D6FE7C1C 042238FF 00000044
	.long 0xd4490001                                           // 0000000ECE44: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v27, vcc_lo                    // 0000000ECE48: 020236FF 0000007F
	v_add_nc_u32_e32 v3, 0x1020, v3                            // 0000000ECE50: 4A0606FF 00001020
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000ECE58: BF870004
	v_mov_b32_e32 v27, v31                                     // 0000000ECE5C: 7E36031F
	s_or_b32 s11, s1, s11                                      // 0000000ECE60: 8C0B0B01
	ds_store_b32 v28, v30                                      // 0000000ECE64: D8340000 00001E1C
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000ECE6C: 917E0B7E
	s_cbranch_execnz 65419                                     // 0000000ECE70: BFA6FF8B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000ECE74: 8C7E047E
	v_mov_b32_e32 v3, v0                                       // 0000000ECE78: 7E060300
	s_or_b32 s13, s7, 16                                       // 0000000ECE7C: 8C0D9007
	s_mov_b32 s4, 0                                            // 0000000ECE80: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000ECE84: BF89FC07
	s_barrier                                                  // 0000000ECE88: BFBD0000
	buffer_gl0_inv                                             // 0000000ECE8C: E0AC0000 00000000
	s_nop 0                                                    // 0000000ECE94: BF800000
	s_nop 0                                                    // 0000000ECE98: BF800000
	s_nop 0                                                    // 0000000ECE9C: BF800000
	s_nop 0                                                    // 0000000ECEA0: BF800000
	s_nop 0                                                    // 0000000ECEA4: BF800000
	s_nop 0                                                    // 0000000ECEA8: BF800000
	s_nop 0                                                    // 0000000ECEAC: BF800000
	s_nop 0                                                    // 0000000ECEB0: BF800000
	s_nop 0                                                    // 0000000ECEB4: BF800000
	s_nop 0                                                    // 0000000ECEB8: BF800000
	s_nop 0                                                    // 0000000ECEBC: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000ECEC0: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000ECEC4: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECECC: BF870092
	v_or_b32_e32 v27, s13, v29                                 // 0000000ECED0: 38363A0D
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000ECED4: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECEDC: BF870091
	.long 0xd73c001b                                           // 0000000ECEE0: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000ECEE4: 02023689
	.long 0xd700011b                                           // 0000000ECEE8: D700011B
	v_cndmask_b32_e32 v1, v48, v27, vcc_lo                     // 0000000ECEEC: 02023730
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ECEF0: BF870001
	v_add_co_ci_u32_e64 v28, null, v49, v28, s1                // 0000000ECEF4: D5207C1C 00063931
	.long 0xd4490001                                           // 0000000ECEFC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000ECF00: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000ECF08: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000ECF0C: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000ECF14: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000ECF20: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000ECF24: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000ECF28: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000ECF30: 917E047E
	s_cbranch_execnz 65506                                     // 0000000ECF34: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x7c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000ECF38: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000ECF3C: BF89FC07
	s_barrier                                                  // 0000000ECF40: BFBD0000
	buffer_gl0_inv                                             // 0000000ECF44: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000ECF4C: BE842000
	s_cbranch_execz 120                                        // 0000000ECF50: BFA50078 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa34>
	v_mov_b32_e32 v3, v59                                      // 0000000ECF54: 7E06033B
	v_mov_b32_e32 v27, v0                                      // 0000000ECF58: 7E360300
	s_mov_b32 s11, 0                                           // 0000000ECF5C: BE8B0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECF60: BF870091
	v_lshrrev_b32_e32 v28, 4, v27                              // 0000000ECF64: 32383684
	v_or_b32_e32 v29, s13, v28                                 // 0000000ECF68: 383A380D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECF6C: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000ECF70: D6FE7C1D 0009611D
	.long 0xd73c001d                                           // 0000000ECF78: D73C001D
	v_cndmask_b32_e32 v1, 9, v29, vcc_lo                       // 0000000ECF7C: 02023A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ECF80: BF870091
	.long 0xd700011d                                           // 0000000ECF84: D700011D
	v_cndmask_b32_e32 v1, v50, v29, vcc_lo                     // 0000000ECF88: 02023B32
	v_add_co_ci_u32_e64 v30, null, v51, v30, s1                // 0000000ECF8C: D5207C1E 00063D33
	s_movk_i32 s1, 0xfe00                                      // 0000000ECF94: B001FE00
	global_load_b32 v30, v[29:30], off                         // 0000000ECF98: DC520000 1E7C001D
	v_mov_b32_e32 v29, v1                                      // 0000000ECFA0: 7E3A0301
	v_add_nc_u32_e32 v62, s1, v3                               // 0000000ECFA4: 4A7C0601
	s_add_i32 s1, s1, 64                                       // 0000000ECFA8: 8101C001
	ds_load_2addr_b32 v[31:32], v29 offset1:17                 // 0000000ECFAC: D8DC1100 1F00001D
	ds_load_2addr_b32 v[33:34], v62 offset0:128 offset1:129    // 0000000ECFB4: D8DC8180 2100003E
	ds_load_2addr_b32 v[35:36], v29 offset0:34 offset1:51      // 0000000ECFBC: D8DC3322 2300001D
	ds_load_2addr_b32 v[37:38], v62 offset0:130 offset1:131    // 0000000ECFC4: D8DC8382 2500003E
	ds_load_2addr_b32 v[39:40], v29 offset0:68 offset1:85      // 0000000ECFCC: D8DC5544 2700001D
	ds_load_2addr_b32 v[41:42], v62 offset0:132 offset1:133    // 0000000ECFD4: D8DC8584 2900003E
	ds_load_2addr_b32 v[60:61], v62 offset0:134 offset1:135    // 0000000ECFDC: D8DC8786 3C00003E
	s_cmp_lg_u32 s1, 0                                         // 0000000ECFE4: BF078001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000ECFE8: BF890057
	v_fma_f32 v30, -v33, v31, v30                              // 0000000ECFEC: D613001E 247A3F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000ECFF4: BF8700C1
	v_fma_f32 v32, -v34, v32, v30                              // 0000000ECFF8: D6130020 247A4122
	ds_load_2addr_b32 v[30:31], v29 offset0:102 offset1:119    // 0000000ED000: D8DC7766 1E00001D
	s_waitcnt lgkmcnt(4)                                       // 0000000ED008: BF89FC47
	v_fma_f32 v32, -v37, v35, v32                              // 0000000ED00C: D6130020 24824725
	v_fma_f32 v36, -v38, v36, v32                              // 0000000ED014: D6130024 24824926
	ds_load_2addr_b32 v[32:33], v29 offset0:136 offset1:153    // 0000000ED01C: D8DC9988 2000001D
	ds_load_2addr_b32 v[34:35], v62 offset0:136 offset1:137    // 0000000ED024: D8DC8988 2200003E
	s_waitcnt lgkmcnt(4)                                       // 0000000ED02C: BF89FC47
	v_fma_f32 v36, -v41, v39, v36                              // 0000000ED030: D6130024 24924F29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000ED038: BF8700D1
	v_fma_f32 v40, -v42, v40, v36                              // 0000000ED03C: D6130028 2492512A
	ds_load_2addr_b32 v[36:37], v29 offset0:170 offset1:187    // 0000000ED044: D8DCBBAA 2400001D
	ds_load_2addr_b32 v[38:39], v62 offset0:138 offset1:139    // 0000000ED04C: D8DC8B8A 2600003E
	s_waitcnt lgkmcnt(4)                                       // 0000000ED054: BF89FC47
	v_fma_f32 v30, -v60, v30, v40                              // 0000000ED058: D613001E 24A23D3C
	v_fma_f32 v42, -v61, v31, v30                              // 0000000ED060: D613002A 247A3F3D
	ds_load_2addr_b32 v[30:31], v29 offset0:204 offset1:221    // 0000000ED068: D8DCDDCC 1E00001D
	ds_load_2addr_b32 v[40:41], v62 offset0:140 offset1:141    // 0000000ED070: D8DC8D8C 2800003E
	ds_load_2addr_b32 v[60:61], v62 offset0:142 offset1:143    // 0000000ED078: D8DC8F8E 3C00003E
	s_waitcnt lgkmcnt(5)                                       // 0000000ED080: BF89FC57
	v_fma_f32 v32, -v34, v32, v42                              // 0000000ED084: D6130020 24AA4122
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000ED08C: BF8700D1
	v_fma_f32 v34, -v35, v33, v32                              // 0000000ED090: D6130022 24824323
	ds_load_2addr_b32 v[32:33], v29 offset0:238 offset1:255    // 0000000ED098: D8DCFFEE 2000001D
	v_add_nc_u32_e32 v29, 0x440, v29                           // 0000000ED0A0: 4A3A3AFF 00000440
	s_waitcnt lgkmcnt(4)                                       // 0000000ED0A8: BF89FC47
	v_fma_f32 v34, -v38, v36, v34                              // 0000000ED0AC: D6130022 248A4926
	v_fma_f32 v34, -v39, v37, v34                              // 0000000ED0B4: D6130022 248A4B27
	s_waitcnt lgkmcnt(2)                                       // 0000000ED0BC: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED0C0: BF870091
	v_fma_f32 v30, -v40, v30, v34                              // 0000000ED0C4: D613001E 248A3D28
	v_fma_f32 v30, -v41, v31, v30                              // 0000000ED0CC: D613001E 247A3F29
	s_waitcnt lgkmcnt(0)                                       // 0000000ED0D4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED0D8: BF870091
	v_fma_f32 v30, -v60, v32, v30                              // 0000000ED0DC: D613001E 247A413C
	v_fma_f32 v30, -v61, v33, v30                              // 0000000ED0E4: D613001E 247A433D
	s_cbranch_scc1 65453                                       // 0000000ED0EC: BFA2FFAD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8a4>
	v_add_nc_u32_e32 v31, 0x80, v27                            // 0000000ED0F0: 4A3E36FF 00000080
	v_mad_u64_u32 v[28:29], null, 0x44, v28, v[8:9]            // 0000000ED0F8: D6FE7C1C 042238FF 00000044
	.long 0xd4490001                                           // 0000000ED104: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v27, vcc_lo                    // 0000000ED108: 020236FF 0000007F
	v_add_nc_u32_e32 v3, 0x1020, v3                            // 0000000ED110: 4A0606FF 00001020
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000ED118: BF870004
	v_mov_b32_e32 v27, v31                                     // 0000000ED11C: 7E36031F
	s_or_b32 s11, s1, s11                                      // 0000000ED120: 8C0B0B01
	ds_store_b32 v28, v30 offset:1088                          // 0000000ED124: D8340440 00001E1C
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000ED12C: 917E0B7E
	s_cbranch_execnz 65419                                     // 0000000ED130: BFA6FF8B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x860>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000ED134: 8C7E047E
	v_mov_b32_e32 v3, v0                                       // 0000000ED138: 7E060300
	s_or_b32 s12, s7, 32                                       // 0000000ED13C: 8C0CA007
	s_mov_b32 s4, 0                                            // 0000000ED140: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000ED144: BF89FC07
	s_barrier                                                  // 0000000ED148: BFBD0000
	buffer_gl0_inv                                             // 0000000ED14C: E0AC0000 00000000
	s_nop 0                                                    // 0000000ED154: BF800000
	s_nop 0                                                    // 0000000ED158: BF800000
	s_nop 0                                                    // 0000000ED15C: BF800000
	s_nop 0                                                    // 0000000ED160: BF800000
	s_nop 0                                                    // 0000000ED164: BF800000
	s_nop 0                                                    // 0000000ED168: BF800000
	s_nop 0                                                    // 0000000ED16C: BF800000
	s_nop 0                                                    // 0000000ED170: BF800000
	s_nop 0                                                    // 0000000ED174: BF800000
	s_nop 0                                                    // 0000000ED178: BF800000
	s_nop 0                                                    // 0000000ED17C: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000ED180: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000ED184: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED18C: BF870092
	v_or_b32_e32 v27, s12, v29                                 // 0000000ED190: 38363A0C
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000ED194: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED19C: BF870091
	.long 0xd73c001b                                           // 0000000ED1A0: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000ED1A4: 02023689
	.long 0xd700011b                                           // 0000000ED1A8: D700011B
	v_cndmask_b32_e32 v1, v48, v27, vcc_lo                     // 0000000ED1AC: 02023730
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ED1B0: BF870001
	v_add_co_ci_u32_e64 v28, null, v49, v28, s1                // 0000000ED1B4: D5207C1C 00063931
	.long 0xd4490001                                           // 0000000ED1BC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000ED1C0: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000ED1C8: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000ED1CC: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000ED1D4: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000ED1E0: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000ED1E4: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000ED1E8: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000ED1F0: 917E047E
	s_cbranch_execnz 65506                                     // 0000000ED1F4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa80>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000ED1F8: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000ED1FC: BF89FC07
	s_barrier                                                  // 0000000ED200: BFBD0000
	buffer_gl0_inv                                             // 0000000ED204: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000ED20C: BE842000
	s_cbranch_execz 120                                        // 0000000ED210: BFA50078 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xcf4>
	v_mov_b32_e32 v3, v59                                      // 0000000ED214: 7E06033B
	v_mov_b32_e32 v27, v0                                      // 0000000ED218: 7E360300
	s_mov_b32 s11, 0                                           // 0000000ED21C: BE8B0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED220: BF870091
	v_lshrrev_b32_e32 v28, 4, v27                              // 0000000ED224: 32383684
	v_or_b32_e32 v29, s12, v28                                 // 0000000ED228: 383A380C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED22C: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000ED230: D6FE7C1D 0009611D
	.long 0xd73c001d                                           // 0000000ED238: D73C001D
	v_cndmask_b32_e32 v1, 9, v29, vcc_lo                       // 0000000ED23C: 02023A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED240: BF870091
	.long 0xd700011d                                           // 0000000ED244: D700011D
	v_cndmask_b32_e32 v1, v50, v29, vcc_lo                     // 0000000ED248: 02023B32
	v_add_co_ci_u32_e64 v30, null, v51, v30, s1                // 0000000ED24C: D5207C1E 00063D33
	s_movk_i32 s1, 0xfe00                                      // 0000000ED254: B001FE00
	global_load_b32 v30, v[29:30], off                         // 0000000ED258: DC520000 1E7C001D
	v_mov_b32_e32 v29, v1                                      // 0000000ED260: 7E3A0301
	v_add_nc_u32_e32 v62, s1, v3                               // 0000000ED264: 4A7C0601
	s_add_i32 s1, s1, 64                                       // 0000000ED268: 8101C001
	ds_load_2addr_b32 v[31:32], v29 offset1:17                 // 0000000ED26C: D8DC1100 1F00001D
	ds_load_2addr_b32 v[33:34], v62 offset0:128 offset1:129    // 0000000ED274: D8DC8180 2100003E
	ds_load_2addr_b32 v[35:36], v29 offset0:34 offset1:51      // 0000000ED27C: D8DC3322 2300001D
	ds_load_2addr_b32 v[37:38], v62 offset0:130 offset1:131    // 0000000ED284: D8DC8382 2500003E
	ds_load_2addr_b32 v[39:40], v29 offset0:68 offset1:85      // 0000000ED28C: D8DC5544 2700001D
	ds_load_2addr_b32 v[41:42], v62 offset0:132 offset1:133    // 0000000ED294: D8DC8584 2900003E
	ds_load_2addr_b32 v[60:61], v62 offset0:134 offset1:135    // 0000000ED29C: D8DC8786 3C00003E
	s_cmp_lg_u32 s1, 0                                         // 0000000ED2A4: BF078001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000ED2A8: BF890057
	v_fma_f32 v30, -v33, v31, v30                              // 0000000ED2AC: D613001E 247A3F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000ED2B4: BF8700C1
	v_fma_f32 v32, -v34, v32, v30                              // 0000000ED2B8: D6130020 247A4122
	ds_load_2addr_b32 v[30:31], v29 offset0:102 offset1:119    // 0000000ED2C0: D8DC7766 1E00001D
	s_waitcnt lgkmcnt(4)                                       // 0000000ED2C8: BF89FC47
	v_fma_f32 v32, -v37, v35, v32                              // 0000000ED2CC: D6130020 24824725
	v_fma_f32 v36, -v38, v36, v32                              // 0000000ED2D4: D6130024 24824926
	ds_load_2addr_b32 v[32:33], v29 offset0:136 offset1:153    // 0000000ED2DC: D8DC9988 2000001D
	ds_load_2addr_b32 v[34:35], v62 offset0:136 offset1:137    // 0000000ED2E4: D8DC8988 2200003E
	s_waitcnt lgkmcnt(4)                                       // 0000000ED2EC: BF89FC47
	v_fma_f32 v36, -v41, v39, v36                              // 0000000ED2F0: D6130024 24924F29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000ED2F8: BF8700D1
	v_fma_f32 v40, -v42, v40, v36                              // 0000000ED2FC: D6130028 2492512A
	ds_load_2addr_b32 v[36:37], v29 offset0:170 offset1:187    // 0000000ED304: D8DCBBAA 2400001D
	ds_load_2addr_b32 v[38:39], v62 offset0:138 offset1:139    // 0000000ED30C: D8DC8B8A 2600003E
	s_waitcnt lgkmcnt(4)                                       // 0000000ED314: BF89FC47
	v_fma_f32 v30, -v60, v30, v40                              // 0000000ED318: D613001E 24A23D3C
	v_fma_f32 v42, -v61, v31, v30                              // 0000000ED320: D613002A 247A3F3D
	ds_load_2addr_b32 v[30:31], v29 offset0:204 offset1:221    // 0000000ED328: D8DCDDCC 1E00001D
	ds_load_2addr_b32 v[40:41], v62 offset0:140 offset1:141    // 0000000ED330: D8DC8D8C 2800003E
	ds_load_2addr_b32 v[60:61], v62 offset0:142 offset1:143    // 0000000ED338: D8DC8F8E 3C00003E
	s_waitcnt lgkmcnt(5)                                       // 0000000ED340: BF89FC57
	v_fma_f32 v32, -v34, v32, v42                              // 0000000ED344: D6130020 24AA4122
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000ED34C: BF8700D1
	v_fma_f32 v34, -v35, v33, v32                              // 0000000ED350: D6130022 24824323
	ds_load_2addr_b32 v[32:33], v29 offset0:238 offset1:255    // 0000000ED358: D8DCFFEE 2000001D
	v_add_nc_u32_e32 v29, 0x440, v29                           // 0000000ED360: 4A3A3AFF 00000440
	s_waitcnt lgkmcnt(4)                                       // 0000000ED368: BF89FC47
	v_fma_f32 v34, -v38, v36, v34                              // 0000000ED36C: D6130022 248A4926
	v_fma_f32 v34, -v39, v37, v34                              // 0000000ED374: D6130022 248A4B27
	s_waitcnt lgkmcnt(2)                                       // 0000000ED37C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED380: BF870091
	v_fma_f32 v30, -v40, v30, v34                              // 0000000ED384: D613001E 248A3D28
	v_fma_f32 v30, -v41, v31, v30                              // 0000000ED38C: D613001E 247A3F29
	s_waitcnt lgkmcnt(0)                                       // 0000000ED394: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED398: BF870091
	v_fma_f32 v30, -v60, v32, v30                              // 0000000ED39C: D613001E 247A413C
	v_fma_f32 v30, -v61, v33, v30                              // 0000000ED3A4: D613001E 247A433D
	s_cbranch_scc1 65453                                       // 0000000ED3AC: BFA2FFAD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb64>
	v_add_nc_u32_e32 v31, 0x80, v27                            // 0000000ED3B0: 4A3E36FF 00000080
	v_mad_u64_u32 v[28:29], null, 0x44, v28, v[8:9]            // 0000000ED3B8: D6FE7C1C 042238FF 00000044
	.long 0xd4490001                                           // 0000000ED3C4: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v27, vcc_lo                    // 0000000ED3C8: 020236FF 0000007F
	v_add_nc_u32_e32 v3, 0x1020, v3                            // 0000000ED3D0: 4A0606FF 00001020
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000ED3D8: BF870004
	v_mov_b32_e32 v27, v31                                     // 0000000ED3DC: 7E36031F
	s_or_b32 s11, s1, s11                                      // 0000000ED3E0: 8C0B0B01
	ds_store_b32 v28, v30 offset:2176                          // 0000000ED3E4: D8340880 00001E1C
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000ED3EC: 917E0B7E
	s_cbranch_execnz 65419                                     // 0000000ED3F0: BFA6FF8B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb20>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000ED3F4: 8C7E047E
	v_mov_b32_e32 v3, v0                                       // 0000000ED3F8: 7E060300
	s_or_b32 s11, s7, 48                                       // 0000000ED3FC: 8C0BB007
	s_mov_b32 s4, 0                                            // 0000000ED400: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000ED404: BF89FC07
	s_barrier                                                  // 0000000ED408: BFBD0000
	buffer_gl0_inv                                             // 0000000ED40C: E0AC0000 00000000
	s_nop 0                                                    // 0000000ED414: BF800000
	s_nop 0                                                    // 0000000ED418: BF800000
	s_nop 0                                                    // 0000000ED41C: BF800000
	s_nop 0                                                    // 0000000ED420: BF800000
	s_nop 0                                                    // 0000000ED424: BF800000
	s_nop 0                                                    // 0000000ED428: BF800000
	s_nop 0                                                    // 0000000ED42C: BF800000
	s_nop 0                                                    // 0000000ED430: BF800000
	s_nop 0                                                    // 0000000ED434: BF800000
	s_nop 0                                                    // 0000000ED438: BF800000
	s_nop 0                                                    // 0000000ED43C: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000ED440: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000ED444: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED44C: BF870092
	v_or_b32_e32 v27, s11, v29                                 // 0000000ED450: 38363A0B
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000ED454: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED45C: BF870091
	.long 0xd73c001b                                           // 0000000ED460: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000ED464: 02023689
	.long 0xd700011b                                           // 0000000ED468: D700011B
	v_cndmask_b32_e32 v1, v48, v27, vcc_lo                     // 0000000ED46C: 02023730
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ED470: BF870001
	v_add_co_ci_u32_e64 v28, null, v49, v28, s1                // 0000000ED474: D5207C1C 00063931
	.long 0xd4490001                                           // 0000000ED47C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000ED480: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000ED488: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000ED48C: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000ED494: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000ED4A0: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000ED4A4: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000ED4A8: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000ED4B0: 917E047E
	s_cbranch_execnz 65506                                     // 0000000ED4B4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd40>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000ED4B8: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000ED4BC: BF89FC07
	s_barrier                                                  // 0000000ED4C0: BFBD0000
	buffer_gl0_inv                                             // 0000000ED4C4: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000ED4CC: BE842000
	s_cbranch_execz 120                                        // 0000000ED4D0: BFA50078 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfb4>
	v_mov_b32_e32 v3, v59                                      // 0000000ED4D4: 7E06033B
	v_mov_b32_e32 v27, v0                                      // 0000000ED4D8: 7E360300
	s_mov_b32 s14, 0                                           // 0000000ED4DC: BE8E0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED4E0: BF870091
	v_lshrrev_b32_e32 v28, 4, v27                              // 0000000ED4E4: 32383684
	v_or_b32_e32 v29, s11, v28                                 // 0000000ED4E8: 383A380B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED4EC: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000ED4F0: D6FE7C1D 0009611D
	.long 0xd73c001d                                           // 0000000ED4F8: D73C001D
	v_cndmask_b32_e32 v1, 9, v29, vcc_lo                       // 0000000ED4FC: 02023A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED500: BF870091
	.long 0xd700011d                                           // 0000000ED504: D700011D
	v_cndmask_b32_e32 v1, v50, v29, vcc_lo                     // 0000000ED508: 02023B32
	v_add_co_ci_u32_e64 v30, null, v51, v30, s1                // 0000000ED50C: D5207C1E 00063D33
	s_movk_i32 s1, 0xfe00                                      // 0000000ED514: B001FE00
	global_load_b32 v30, v[29:30], off                         // 0000000ED518: DC520000 1E7C001D
	v_mov_b32_e32 v29, v1                                      // 0000000ED520: 7E3A0301
	v_add_nc_u32_e32 v62, s1, v3                               // 0000000ED524: 4A7C0601
	s_add_i32 s1, s1, 64                                       // 0000000ED528: 8101C001
	ds_load_2addr_b32 v[31:32], v29 offset1:17                 // 0000000ED52C: D8DC1100 1F00001D
	ds_load_2addr_b32 v[33:34], v62 offset0:128 offset1:129    // 0000000ED534: D8DC8180 2100003E
	ds_load_2addr_b32 v[35:36], v29 offset0:34 offset1:51      // 0000000ED53C: D8DC3322 2300001D
	ds_load_2addr_b32 v[37:38], v62 offset0:130 offset1:131    // 0000000ED544: D8DC8382 2500003E
	ds_load_2addr_b32 v[39:40], v29 offset0:68 offset1:85      // 0000000ED54C: D8DC5544 2700001D
	ds_load_2addr_b32 v[41:42], v62 offset0:132 offset1:133    // 0000000ED554: D8DC8584 2900003E
	ds_load_2addr_b32 v[60:61], v62 offset0:134 offset1:135    // 0000000ED55C: D8DC8786 3C00003E
	s_cmp_lg_u32 s1, 0                                         // 0000000ED564: BF078001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000ED568: BF890057
	v_fma_f32 v30, -v33, v31, v30                              // 0000000ED56C: D613001E 247A3F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000ED574: BF8700C1
	v_fma_f32 v32, -v34, v32, v30                              // 0000000ED578: D6130020 247A4122
	ds_load_2addr_b32 v[30:31], v29 offset0:102 offset1:119    // 0000000ED580: D8DC7766 1E00001D
	s_waitcnt lgkmcnt(4)                                       // 0000000ED588: BF89FC47
	v_fma_f32 v32, -v37, v35, v32                              // 0000000ED58C: D6130020 24824725
	v_fma_f32 v36, -v38, v36, v32                              // 0000000ED594: D6130024 24824926
	ds_load_2addr_b32 v[32:33], v29 offset0:136 offset1:153    // 0000000ED59C: D8DC9988 2000001D
	ds_load_2addr_b32 v[34:35], v62 offset0:136 offset1:137    // 0000000ED5A4: D8DC8988 2200003E
	s_waitcnt lgkmcnt(4)                                       // 0000000ED5AC: BF89FC47
	v_fma_f32 v36, -v41, v39, v36                              // 0000000ED5B0: D6130024 24924F29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000ED5B8: BF8700D1
	v_fma_f32 v40, -v42, v40, v36                              // 0000000ED5BC: D6130028 2492512A
	ds_load_2addr_b32 v[36:37], v29 offset0:170 offset1:187    // 0000000ED5C4: D8DCBBAA 2400001D
	ds_load_2addr_b32 v[38:39], v62 offset0:138 offset1:139    // 0000000ED5CC: D8DC8B8A 2600003E
	s_waitcnt lgkmcnt(4)                                       // 0000000ED5D4: BF89FC47
	v_fma_f32 v30, -v60, v30, v40                              // 0000000ED5D8: D613001E 24A23D3C
	v_fma_f32 v42, -v61, v31, v30                              // 0000000ED5E0: D613002A 247A3F3D
	ds_load_2addr_b32 v[30:31], v29 offset0:204 offset1:221    // 0000000ED5E8: D8DCDDCC 1E00001D
	ds_load_2addr_b32 v[40:41], v62 offset0:140 offset1:141    // 0000000ED5F0: D8DC8D8C 2800003E
	ds_load_2addr_b32 v[60:61], v62 offset0:142 offset1:143    // 0000000ED5F8: D8DC8F8E 3C00003E
	s_waitcnt lgkmcnt(5)                                       // 0000000ED600: BF89FC57
	v_fma_f32 v32, -v34, v32, v42                              // 0000000ED604: D6130020 24AA4122
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000ED60C: BF8700D1
	v_fma_f32 v34, -v35, v33, v32                              // 0000000ED610: D6130022 24824323
	ds_load_2addr_b32 v[32:33], v29 offset0:238 offset1:255    // 0000000ED618: D8DCFFEE 2000001D
	v_add_nc_u32_e32 v29, 0x440, v29                           // 0000000ED620: 4A3A3AFF 00000440
	s_waitcnt lgkmcnt(4)                                       // 0000000ED628: BF89FC47
	v_fma_f32 v34, -v38, v36, v34                              // 0000000ED62C: D6130022 248A4926
	v_fma_f32 v34, -v39, v37, v34                              // 0000000ED634: D6130022 248A4B27
	s_waitcnt lgkmcnt(2)                                       // 0000000ED63C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED640: BF870091
	v_fma_f32 v30, -v40, v30, v34                              // 0000000ED644: D613001E 248A3D28
	v_fma_f32 v30, -v41, v31, v30                              // 0000000ED64C: D613001E 247A3F29
	s_waitcnt lgkmcnt(0)                                       // 0000000ED654: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED658: BF870091
	v_fma_f32 v30, -v60, v32, v30                              // 0000000ED65C: D613001E 247A413C
	v_fma_f32 v30, -v61, v33, v30                              // 0000000ED664: D613001E 247A433D
	s_cbranch_scc1 65453                                       // 0000000ED66C: BFA2FFAD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe24>
	v_add_nc_u32_e32 v31, 0x80, v27                            // 0000000ED670: 4A3E36FF 00000080
	v_mad_u64_u32 v[28:29], null, 0x44, v28, v[8:9]            // 0000000ED678: D6FE7C1C 042238FF 00000044
	.long 0xd4490001                                           // 0000000ED684: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v27, vcc_lo                    // 0000000ED688: 020236FF 0000007F
	v_add_nc_u32_e32 v3, 0x1020, v3                            // 0000000ED690: 4A0606FF 00001020
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000ED698: BF870004
	v_mov_b32_e32 v27, v31                                     // 0000000ED69C: 7E36031F
	s_or_b32 s14, s1, s14                                      // 0000000ED6A0: 8C0E0E01
	ds_store_b32 v28, v30 offset:3264                          // 0000000ED6A4: D8340CC0 00001E1C
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000ED6AC: 917E0E7E
	s_cbranch_execnz 65419                                     // 0000000ED6B0: BFA6FF8B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xde0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000ED6B4: 8C7E047E
	v_mov_b32_e32 v3, v0                                       // 0000000ED6B8: 7E060300
	s_mov_b32 s4, 0                                            // 0000000ED6BC: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000ED6C0: BF89FC07
	s_barrier                                                  // 0000000ED6C4: BFBD0000
	buffer_gl0_inv                                             // 0000000ED6C8: E0AC0000 00000000
	s_nop 0                                                    // 0000000ED6D0: BF800000
	s_nop 0                                                    // 0000000ED6D4: BF800000
	s_nop 0                                                    // 0000000ED6D8: BF800000
	s_nop 0                                                    // 0000000ED6DC: BF800000
	s_nop 0                                                    // 0000000ED6E0: BF800000
	s_nop 0                                                    // 0000000ED6E4: BF800000
	s_nop 0                                                    // 0000000ED6E8: BF800000
	s_nop 0                                                    // 0000000ED6EC: BF800000
	s_nop 0                                                    // 0000000ED6F0: BF800000
	s_nop 0                                                    // 0000000ED6F4: BF800000
	s_nop 0                                                    // 0000000ED6F8: BF800000
	s_nop 0                                                    // 0000000ED6FC: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000ED700: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000ED704: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED70C: BF870092
	v_or_b32_e32 v27, s7, v29                                  // 0000000ED710: 38363A07
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000ED714: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED71C: BF870091
	.long 0xd73c001b                                           // 0000000ED720: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000ED724: 02023689
	.long 0xd700011b                                           // 0000000ED728: D700011B
	v_cndmask_b32_e32 v1, v55, v27, vcc_lo                     // 0000000ED72C: 02023737
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ED730: BF870001
	v_add_co_ci_u32_e64 v28, null, v56, v28, s1                // 0000000ED734: D5207C1C 00063938
	.long 0xd4490001                                           // 0000000ED73C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000ED740: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000ED748: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000ED74C: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000ED754: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000ED760: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000ED764: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000ED768: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000ED770: 917E047E
	s_cbranch_execnz 65506                                     // 0000000ED774: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1000>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000ED778: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000ED77C: BF89FC07
	s_barrier                                                  // 0000000ED780: BFBD0000
	buffer_gl0_inv                                             // 0000000ED784: E0AC0000 00000000
	s_and_saveexec_b32 s14, s0                                 // 0000000ED78C: BE8E2000
	s_cbranch_execz 155                                        // 0000000ED790: BFA5009B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1300>
	v_dual_mov_b32 v28, v12 :: v_dual_mov_b32 v27, v11         // 0000000ED794: CA10010C 1C1A010B
	v_dual_mov_b32 v3, v59 :: v_dual_mov_b32 v32, v0           // 0000000ED79C: CA10013B 03200100
	v_mov_b32_e32 v31, v47                                     // 0000000ED7A4: 7E3E032F
	s_mov_b32 s15, 0                                           // 0000000ED7A8: BE8F0080
	s_branch 19                                                // 0000000ED7AC: BFA00013 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10fc>
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000ED7B0: 8C7E167E
	v_add_nc_u32_e32 v29, 0x80, v32                            // 0000000ED7B4: 4A3A40FF 00000080
	.long 0xd4490001                                           // 0000000ED7BC: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v32, vcc_lo                    // 0000000ED7C0: 020240FF 0000007F
	.long 0xd700041b                                           // 0000000ED7C8: D700041B
	v_cndmask_b32_e32 v1, 0x800, v27, vcc_lo                   // 0000000ED7CC: 020236FF 00000800
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000ED7D4: BF8704C3
	v_dual_mov_b32 v32, v29 :: v_dual_add_nc_u32 v31, 8, v31   // 0000000ED7D8: CA20011D 201E3E88
	v_add_nc_u32_e32 v3, 0x1020, v3                            // 0000000ED7E0: 4A0606FF 00001020
	v_add_co_ci_u32_e64 v28, null, 0, v28, s4                  // 0000000ED7E8: D5207C1C 00123880
	s_or_b32 s15, s1, s15                                      // 0000000ED7F0: 8C0F0F01
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000000ED7F4: 917E0F7E
	s_cbranch_execz 129                                        // 0000000ED7F8: BFA50081 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1300>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000ED7FC: BF8700A2
	v_lshrrev_b32_e32 v29, 4, v32                              // 0000000ED800: 323A4084
	s_mov_b32 s22, exec_lo                                     // 0000000ED804: BE96007E
	v_or_b32_e32 v33, s7, v29                                  // 0000000ED808: 38423A07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ED80C: BF870001
	.long 0xd4c4007e                                           // 0000000ED810: D4C4007E
	v_cndmask_b32_e32 v1, s30, v33, vcc_lo                     // 0000000ED814: 0202421E
	s_cbranch_execz 65509                                      // 0000000ED818: BFA5FFE5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10b0>
	v_mov_b32_e32 v34, 0                                       // 0000000ED81C: 7E440280
	v_mov_b32_e32 v30, v1                                      // 0000000ED820: 7E3C0301
	s_movk_i32 s1, 0xfe00                                      // 0000000ED824: B001FE00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000ED828: BF870009
	v_add_nc_u32_e32 v66, s1, v3                               // 0000000ED82C: 4A840601
	s_add_i32 s1, s1, 64                                       // 0000000ED830: 8101C001
	ds_load_2addr_b32 v[35:36], v30 offset1:17                 // 0000000ED834: D8DC1100 2300001E
	ds_load_2addr_b32 v[37:38], v66 offset0:128 offset1:129    // 0000000ED83C: D8DC8180 25000042
	ds_load_2addr_b32 v[39:40], v30 offset0:34 offset1:51      // 0000000ED844: D8DC3322 2700001E
	ds_load_2addr_b32 v[41:42], v66 offset0:130 offset1:131    // 0000000ED84C: D8DC8382 29000042
	ds_load_2addr_b32 v[60:61], v30 offset0:68 offset1:85      // 0000000ED854: D8DC5544 3C00001E
	ds_load_2addr_b32 v[62:63], v66 offset0:132 offset1:133    // 0000000ED85C: D8DC8584 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:134 offset1:135    // 0000000ED864: D8DC8786 40000042
	s_cmp_eq_u32 s1, 0                                         // 0000000ED86C: BF068001
	s_waitcnt lgkmcnt(5)                                       // 0000000ED870: BF89FC57
	v_fmac_f32_e32 v34, v37, v35                               // 0000000ED874: 56444725
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000ED878: BF8700C1
	v_fmac_f32_e32 v34, v38, v36                               // 0000000ED87C: 56444926
	ds_load_2addr_b32 v[35:36], v30 offset0:102 offset1:119    // 0000000ED880: D8DC7766 2300001E
	s_waitcnt lgkmcnt(4)                                       // 0000000ED888: BF89FC47
	v_fmac_f32_e32 v34, v41, v39                               // 0000000ED88C: 56444F29
	v_fmac_f32_e32 v34, v42, v40                               // 0000000ED890: 5644512A
	ds_load_2addr_b32 v[37:38], v30 offset0:136 offset1:153    // 0000000ED894: D8DC9988 2500001E
	ds_load_2addr_b32 v[39:40], v66 offset0:136 offset1:137    // 0000000ED89C: D8DC8988 27000042
	s_waitcnt lgkmcnt(4)                                       // 0000000ED8A4: BF89FC47
	v_fmac_f32_e32 v34, v62, v60                               // 0000000ED8A8: 5644793E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000ED8AC: BF8700D1
	v_fmac_f32_e32 v34, v63, v61                               // 0000000ED8B0: 56447B3F
	ds_load_2addr_b32 v[41:42], v30 offset0:170 offset1:187    // 0000000ED8B4: D8DCBBAA 2900001E
	ds_load_2addr_b32 v[60:61], v66 offset0:138 offset1:139    // 0000000ED8BC: D8DC8B8A 3C000042
	s_waitcnt lgkmcnt(4)                                       // 0000000ED8C4: BF89FC47
	v_fmac_f32_e32 v34, v64, v35                               // 0000000ED8C8: 56444740
	v_fmac_f32_e32 v34, v65, v36                               // 0000000ED8CC: 56444941
	ds_load_2addr_b32 v[35:36], v30 offset0:204 offset1:221    // 0000000ED8D0: D8DCDDCC 2300001E
	ds_load_2addr_b32 v[62:63], v66 offset0:140 offset1:141    // 0000000ED8D8: D8DC8D8C 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:142 offset1:143    // 0000000ED8E0: D8DC8F8E 40000042
	s_waitcnt lgkmcnt(5)                                       // 0000000ED8E8: BF89FC57
	v_fmac_f32_e32 v34, v39, v37                               // 0000000ED8EC: 56444B27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000ED8F0: BF8700D1
	v_fmac_f32_e32 v34, v40, v38                               // 0000000ED8F4: 56444D28
	ds_load_2addr_b32 v[37:38], v30 offset0:238 offset1:255    // 0000000ED8F8: D8DCFFEE 2500001E
	v_add_nc_u32_e32 v30, 0x440, v30                           // 0000000ED900: 4A3C3CFF 00000440
	s_waitcnt lgkmcnt(4)                                       // 0000000ED908: BF89FC47
	v_fmac_f32_e32 v34, v60, v41                               // 0000000ED90C: 5644533C
	v_fmac_f32_e32 v34, v61, v42                               // 0000000ED910: 5644553D
	s_waitcnt lgkmcnt(2)                                       // 0000000ED914: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED918: BF870091
	v_fmac_f32_e32 v34, v62, v35                               // 0000000ED91C: 5644473E
	v_fmac_f32_e32 v34, v63, v36                               // 0000000ED920: 5644493F
	s_waitcnt lgkmcnt(0)                                       // 0000000ED924: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ED928: BF870091
	v_fmac_f32_e32 v34, v64, v37                               // 0000000ED92C: 56444B40
	v_fmac_f32_e32 v34, v65, v38                               // 0000000ED930: 56444D41
	s_cbranch_scc0 65468                                       // 0000000ED934: BFA1FFBC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1128>
	v_lshlrev_b32_e32 v29, 2, v29                              // 0000000ED938: 303A3A82
	s_mov_b32 s23, 0                                           // 0000000ED93C: BE970080
	ds_load_b32 v36, v29 offset:21568                          // 0000000ED940: D8D85440 2400001D
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v35, v1          // 0000000ED948: CA10011C 1E220101
	s_waitcnt lgkmcnt(0)                                       // 0000000ED950: BF89FC07
	v_dual_mov_b32 v29, v27 :: v_dual_mul_f32 v34, v34, v36    // 0000000ED954: CA06011B 1D224922
	v_mov_b32_e32 v36, v31                                     // 0000000ED95C: 7E48031F
	s_nop 0                                                    // 0000000ED960: BF800000
	s_nop 0                                                    // 0000000ED964: BF800000
	s_nop 0                                                    // 0000000ED968: BF800000
	s_nop 0                                                    // 0000000ED96C: BF800000
	s_nop 0                                                    // 0000000ED970: BF800000
	s_nop 0                                                    // 0000000ED974: BF800000
	s_nop 0                                                    // 0000000ED978: BF800000
	s_nop 0                                                    // 0000000ED97C: BF800000
	global_load_b32 v37, v[29:30], off                         // 0000000ED980: DC520000 257C001D
	ds_load_b32 v38, v35 offset:16960                          // 0000000ED988: D8D84240 26000023
	v_add_nc_u32_e32 v36, -1, v36                              // 0000000ED990: 4A4848C1
	.long 0xd700011d                                           // 0000000ED994: D700011D
	v_cndmask_b32_e32 v0, v29, v132, vcc_lo                    // 0000000ED998: 0201091D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000ED99C: BF870191
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000ED9A0: D5207C1E 00063C80
	.long 0xd44a0004                                           // 0000000ED9A8: D44A0004
	v_cndmask_b32_e32 v1, 0, v36, vcc_lo                       // 0000000ED9AC: 02024880
	v_add_nc_u32_e32 v35, 0x44, v35                            // 0000000ED9B0: 4A4646FF 00000044
	s_or_b32 s23, s4, s23                                      // 0000000ED9B8: 8C171704
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000ED9BC: BF890007
	v_fmac_f32_e32 v34, v37, v38                               // 0000000ED9C0: 56444D25
	s_and_not1_b32 exec_lo, exec_lo, s23                       // 0000000ED9C4: 917E177E
	s_cbranch_execnz 65517                                     // 0000000ED9C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1280>
	s_or_b32 exec_lo, exec_lo, s23                             // 0000000ED9CC: 8C7E177E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ED9D0: BF870121
	v_bfe_u32 v35, v34, 16, 1                                  // 0000000ED9D4: D6100023 02052122
	v_mad_u64_u32 v[29:30], null, 0x3000, v33, v[9:10]         // 0000000ED9DC: D6FE7C1D 042642FF 00003000
	v_add3_u32 v33, v34, v35, 0x7fff                           // 0000000ED9E8: D6550021 03FE4722 00007FFF
	global_store_d16_hi_b16 v[29:30], v33, off                 // 0000000ED9F4: DC960000 007C211D
	s_branch 65388                                             // 0000000ED9FC: BFA0FF6C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10b0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000EDA00: 8C7E0E7E
	v_mov_b32_e32 v3, v0                                       // 0000000EDA04: 7E060300
	s_mov_b32 s4, 0                                            // 0000000EDA08: BE840080
	s_waitcnt_vscnt null, 0x0                                  // 0000000EDA0C: BC7C0000
	s_barrier                                                  // 0000000EDA10: BFBD0000
	buffer_gl0_inv                                             // 0000000EDA14: E0AC0000 00000000
	s_nop 0                                                    // 0000000EDA1C: BF800000
	s_nop 0                                                    // 0000000EDA20: BF800000
	s_nop 0                                                    // 0000000EDA24: BF800000
	s_nop 0                                                    // 0000000EDA28: BF800000
	s_nop 0                                                    // 0000000EDA2C: BF800000
	s_nop 0                                                    // 0000000EDA30: BF800000
	s_nop 0                                                    // 0000000EDA34: BF800000
	s_nop 0                                                    // 0000000EDA38: BF800000
	s_nop 0                                                    // 0000000EDA3C: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000EDA40: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000EDA44: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDA4C: BF870092
	v_or_b32_e32 v27, s13, v29                                 // 0000000EDA50: 38363A0D
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000EDA54: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDA5C: BF870091
	.long 0xd73c001b                                           // 0000000EDA60: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000EDA64: 02023689
	.long 0xd700011b                                           // 0000000EDA68: D700011B
	v_cndmask_b32_e32 v1, v55, v27, vcc_lo                     // 0000000EDA6C: 02023737
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EDA70: BF870001
	v_add_co_ci_u32_e64 v28, null, v56, v28, s1                // 0000000EDA74: D5207C1C 00063938
	.long 0xd4490001                                           // 0000000EDA7C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000EDA80: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000EDA88: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000EDA8C: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000EDA94: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000EDAA0: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000EDAA4: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000EDAA8: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EDAB0: 917E047E
	s_cbranch_execnz 65506                                     // 0000000EDAB4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1340>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EDAB8: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000EDABC: BF89FC07
	s_barrier                                                  // 0000000EDAC0: BFBD0000
	buffer_gl0_inv                                             // 0000000EDAC4: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000EDACC: BE8D2000
	s_cbranch_execz 155                                        // 0000000EDAD0: BFA5009B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1640>
	v_dual_mov_b32 v28, v14 :: v_dual_mov_b32 v27, v13         // 0000000EDAD4: CA10010E 1C1A010D
	v_dual_mov_b32 v3, v59 :: v_dual_mov_b32 v32, v0           // 0000000EDADC: CA10013B 03200100
	v_mov_b32_e32 v31, v52                                     // 0000000EDAE4: 7E3E0334
	s_mov_b32 s14, 0                                           // 0000000EDAE8: BE8E0080
	s_branch 19                                                // 0000000EDAEC: BFA00013 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x143c>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000000EDAF0: 8C7E0F7E
	v_add_nc_u32_e32 v29, 0x80, v32                            // 0000000EDAF4: 4A3A40FF 00000080
	.long 0xd4490001                                           // 0000000EDAFC: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v32, vcc_lo                    // 0000000EDB00: 020240FF 0000007F
	.long 0xd700041b                                           // 0000000EDB08: D700041B
	v_cndmask_b32_e32 v1, 0x800, v27, vcc_lo                   // 0000000EDB0C: 020236FF 00000800
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000EDB14: BF8704C3
	v_dual_mov_b32 v32, v29 :: v_dual_add_nc_u32 v31, 8, v31   // 0000000EDB18: CA20011D 201E3E88
	v_add_nc_u32_e32 v3, 0x1020, v3                            // 0000000EDB20: 4A0606FF 00001020
	v_add_co_ci_u32_e64 v28, null, 0, v28, s4                  // 0000000EDB28: D5207C1C 00123880
	s_or_b32 s14, s1, s14                                      // 0000000EDB30: 8C0E0E01
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000EDB34: 917E0E7E
	s_cbranch_execz 129                                        // 0000000EDB38: BFA50081 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1640>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EDB3C: BF8700A2
	v_lshrrev_b32_e32 v29, 4, v32                              // 0000000EDB40: 323A4084
	s_mov_b32 s15, exec_lo                                     // 0000000EDB44: BE8F007E
	v_or3_b32 v33, v29, s7, 16                                 // 0000000EDB48: D6580021 02400F1D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EDB50: BF870001
	.long 0xd4c4007e                                           // 0000000EDB54: D4C4007E
	v_cndmask_b32_e32 v1, s30, v33, vcc_lo                     // 0000000EDB58: 0202421E
	s_cbranch_execz 65508                                      // 0000000EDB5C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13f0>
	v_mov_b32_e32 v34, 0                                       // 0000000EDB60: 7E440280
	v_mov_b32_e32 v30, v1                                      // 0000000EDB64: 7E3C0301
	s_movk_i32 s1, 0xfe00                                      // 0000000EDB68: B001FE00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EDB6C: BF870009
	v_add_nc_u32_e32 v66, s1, v3                               // 0000000EDB70: 4A840601
	s_add_i32 s1, s1, 64                                       // 0000000EDB74: 8101C001
	ds_load_2addr_b32 v[35:36], v30 offset1:17                 // 0000000EDB78: D8DC1100 2300001E
	ds_load_2addr_b32 v[37:38], v66 offset0:128 offset1:129    // 0000000EDB80: D8DC8180 25000042
	ds_load_2addr_b32 v[39:40], v30 offset0:34 offset1:51      // 0000000EDB88: D8DC3322 2700001E
	ds_load_2addr_b32 v[41:42], v66 offset0:130 offset1:131    // 0000000EDB90: D8DC8382 29000042
	ds_load_2addr_b32 v[60:61], v30 offset0:68 offset1:85      // 0000000EDB98: D8DC5544 3C00001E
	ds_load_2addr_b32 v[62:63], v66 offset0:132 offset1:133    // 0000000EDBA0: D8DC8584 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:134 offset1:135    // 0000000EDBA8: D8DC8786 40000042
	s_cmp_lg_u32 s1, 0                                         // 0000000EDBB0: BF078001
	s_waitcnt lgkmcnt(5)                                       // 0000000EDBB4: BF89FC57
	v_fmac_f32_e32 v34, v37, v35                               // 0000000EDBB8: 56444725
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000EDBBC: BF8700C1
	v_fmac_f32_e32 v34, v38, v36                               // 0000000EDBC0: 56444926
	ds_load_2addr_b32 v[35:36], v30 offset0:102 offset1:119    // 0000000EDBC4: D8DC7766 2300001E
	s_waitcnt lgkmcnt(4)                                       // 0000000EDBCC: BF89FC47
	v_fmac_f32_e32 v34, v41, v39                               // 0000000EDBD0: 56444F29
	v_fmac_f32_e32 v34, v42, v40                               // 0000000EDBD4: 5644512A
	ds_load_2addr_b32 v[37:38], v30 offset0:136 offset1:153    // 0000000EDBD8: D8DC9988 2500001E
	ds_load_2addr_b32 v[39:40], v66 offset0:136 offset1:137    // 0000000EDBE0: D8DC8988 27000042
	s_waitcnt lgkmcnt(4)                                       // 0000000EDBE8: BF89FC47
	v_fmac_f32_e32 v34, v62, v60                               // 0000000EDBEC: 5644793E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000EDBF0: BF8700D1
	v_fmac_f32_e32 v34, v63, v61                               // 0000000EDBF4: 56447B3F
	ds_load_2addr_b32 v[41:42], v30 offset0:170 offset1:187    // 0000000EDBF8: D8DCBBAA 2900001E
	ds_load_2addr_b32 v[60:61], v66 offset0:138 offset1:139    // 0000000EDC00: D8DC8B8A 3C000042
	s_waitcnt lgkmcnt(4)                                       // 0000000EDC08: BF89FC47
	v_fmac_f32_e32 v34, v64, v35                               // 0000000EDC0C: 56444740
	v_fmac_f32_e32 v34, v65, v36                               // 0000000EDC10: 56444941
	ds_load_2addr_b32 v[35:36], v30 offset0:204 offset1:221    // 0000000EDC14: D8DCDDCC 2300001E
	ds_load_2addr_b32 v[62:63], v66 offset0:140 offset1:141    // 0000000EDC1C: D8DC8D8C 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:142 offset1:143    // 0000000EDC24: D8DC8F8E 40000042
	s_waitcnt lgkmcnt(5)                                       // 0000000EDC2C: BF89FC57
	v_fmac_f32_e32 v34, v39, v37                               // 0000000EDC30: 56444B27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000EDC34: BF8700D1
	v_fmac_f32_e32 v34, v40, v38                               // 0000000EDC38: 56444D28
	ds_load_2addr_b32 v[37:38], v30 offset0:238 offset1:255    // 0000000EDC3C: D8DCFFEE 2500001E
	v_add_nc_u32_e32 v30, 0x440, v30                           // 0000000EDC44: 4A3C3CFF 00000440
	s_waitcnt lgkmcnt(4)                                       // 0000000EDC4C: BF89FC47
	v_fmac_f32_e32 v34, v60, v41                               // 0000000EDC50: 5644533C
	v_fmac_f32_e32 v34, v61, v42                               // 0000000EDC54: 5644553D
	s_waitcnt lgkmcnt(2)                                       // 0000000EDC58: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDC5C: BF870091
	v_fmac_f32_e32 v34, v62, v35                               // 0000000EDC60: 5644473E
	v_fmac_f32_e32 v34, v63, v36                               // 0000000EDC64: 5644493F
	s_waitcnt lgkmcnt(0)                                       // 0000000EDC68: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDC6C: BF870091
	v_fmac_f32_e32 v34, v64, v37                               // 0000000EDC70: 56444B40
	v_fmac_f32_e32 v34, v65, v38                               // 0000000EDC74: 56444D41
	s_cbranch_scc1 65468                                       // 0000000EDC78: BFA2FFBC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x146c>
	v_lshlrev_b32_e32 v29, 2, v29                              // 0000000EDC7C: 303A3A82
	v_mov_b32_e32 v35, v1                                      // 0000000EDC80: 7E460301
	s_mov_b32 s22, 0                                           // 0000000EDC84: BE960080
	ds_load_b32 v36, v29 offset:21632                          // 0000000EDC88: D8D85480 2400001D
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000EDC90: CA10011C 1E1C011B
	s_waitcnt lgkmcnt(0)                                       // 0000000EDC98: BF89FC07
	v_mul_f32_e32 v34, v34, v36                                // 0000000EDC9C: 10444922
	v_mov_b32_e32 v36, v31                                     // 0000000EDCA0: 7E48031F
	s_nop 0                                                    // 0000000EDCA4: BF800000
	s_nop 0                                                    // 0000000EDCA8: BF800000
	s_nop 0                                                    // 0000000EDCAC: BF800000
	s_nop 0                                                    // 0000000EDCB0: BF800000
	s_nop 0                                                    // 0000000EDCB4: BF800000
	s_nop 0                                                    // 0000000EDCB8: BF800000
	s_nop 0                                                    // 0000000EDCBC: BF800000
	global_load_b32 v37, v[29:30], off                         // 0000000EDCC0: DC520000 257C001D
	ds_load_b32 v38, v35 offset:16960                          // 0000000EDCC8: D8D84240 26000023
	v_add_nc_u32_e32 v36, -1, v36                              // 0000000EDCD0: 4A4848C1
	.long 0xd700011d                                           // 0000000EDCD4: D700011D
	v_cndmask_b32_e32 v0, v29, v132, vcc_lo                    // 0000000EDCD8: 0201091D
	v_add_nc_u32_e32 v35, 0x44, v35                            // 0000000EDCDC: 4A4646FF 00000044
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000EDCE4: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EDCEC: BF870004
	.long 0xd44a0004                                           // 0000000EDCF0: D44A0004
	v_cndmask_b32_e32 v1, 0, v36, vcc_lo                       // 0000000EDCF4: 02024880
	s_or_b32 s22, s4, s22                                      // 0000000EDCF8: 8C161604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EDCFC: BF890007
	v_fmac_f32_e32 v34, v37, v38                               // 0000000EDD00: 56444D25
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000000EDD04: 917E167E
	s_cbranch_execnz 65517                                     // 0000000EDD08: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000EDD0C: 8C7E167E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EDD10: BF870121
	v_bfe_u32 v35, v34, 16, 1                                  // 0000000EDD14: D6100023 02052122
	v_mad_u64_u32 v[29:30], null, 0x3000, v33, v[9:10]         // 0000000EDD1C: D6FE7C1D 042642FF 00003000
	v_add3_u32 v33, v34, v35, 0x7fff                           // 0000000EDD28: D6550021 03FE4722 00007FFF
	global_store_d16_hi_b16 v[29:30], v33, off                 // 0000000EDD34: DC960000 007C211D
	s_branch 65388                                             // 0000000EDD3C: BFA0FF6C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13f0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000EDD40: 8C7E0D7E
	v_mov_b32_e32 v3, v0                                       // 0000000EDD44: 7E060300
	s_mov_b32 s4, 0                                            // 0000000EDD48: BE840080
	s_waitcnt_vscnt null, 0x0                                  // 0000000EDD4C: BC7C0000
	s_barrier                                                  // 0000000EDD50: BFBD0000
	buffer_gl0_inv                                             // 0000000EDD54: E0AC0000 00000000
	s_nop 0                                                    // 0000000EDD5C: BF800000
	s_nop 0                                                    // 0000000EDD60: BF800000
	s_nop 0                                                    // 0000000EDD64: BF800000
	s_nop 0                                                    // 0000000EDD68: BF800000
	s_nop 0                                                    // 0000000EDD6C: BF800000
	s_nop 0                                                    // 0000000EDD70: BF800000
	s_nop 0                                                    // 0000000EDD74: BF800000
	s_nop 0                                                    // 0000000EDD78: BF800000
	s_nop 0                                                    // 0000000EDD7C: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000EDD80: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000EDD84: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDD8C: BF870092
	v_or_b32_e32 v27, s12, v29                                 // 0000000EDD90: 38363A0C
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000EDD94: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDD9C: BF870091
	.long 0xd73c001b                                           // 0000000EDDA0: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000EDDA4: 02023689
	.long 0xd700011b                                           // 0000000EDDA8: D700011B
	v_cndmask_b32_e32 v1, v55, v27, vcc_lo                     // 0000000EDDAC: 02023737
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EDDB0: BF870001
	v_add_co_ci_u32_e64 v28, null, v56, v28, s1                // 0000000EDDB4: D5207C1C 00063938
	.long 0xd4490001                                           // 0000000EDDBC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000EDDC0: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000EDDC8: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000EDDCC: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000EDDD4: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000EDDE0: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000EDDE4: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000EDDE8: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EDDF0: 917E047E
	s_cbranch_execnz 65506                                     // 0000000EDDF4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1680>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EDDF8: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000EDDFC: BF89FC07
	s_barrier                                                  // 0000000EDE00: BFBD0000
	buffer_gl0_inv                                             // 0000000EDE04: E0AC0000 00000000
	s_and_saveexec_b32 s12, s0                                 // 0000000EDE0C: BE8C2000
	s_cbranch_execz 155                                        // 0000000EDE10: BFA5009B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1980>
	v_dual_mov_b32 v28, v16 :: v_dual_mov_b32 v27, v15         // 0000000EDE14: CA100110 1C1A010F
	v_dual_mov_b32 v3, v59 :: v_dual_mov_b32 v32, v0           // 0000000EDE1C: CA10013B 03200100
	v_mov_b32_e32 v31, v53                                     // 0000000EDE24: 7E3E0335
	s_mov_b32 s13, 0                                           // 0000000EDE28: BE8D0080
	s_branch 19                                                // 0000000EDE2C: BFA00013 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x177c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000EDE30: 8C7E0E7E
	v_add_nc_u32_e32 v29, 0x80, v32                            // 0000000EDE34: 4A3A40FF 00000080
	.long 0xd4490001                                           // 0000000EDE3C: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v32, vcc_lo                    // 0000000EDE40: 020240FF 0000007F
	.long 0xd700041b                                           // 0000000EDE48: D700041B
	v_cndmask_b32_e32 v1, 0x800, v27, vcc_lo                   // 0000000EDE4C: 020236FF 00000800
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000EDE54: BF8704C3
	v_dual_mov_b32 v32, v29 :: v_dual_add_nc_u32 v31, 8, v31   // 0000000EDE58: CA20011D 201E3E88
	v_add_nc_u32_e32 v3, 0x1020, v3                            // 0000000EDE60: 4A0606FF 00001020
	v_add_co_ci_u32_e64 v28, null, 0, v28, s4                  // 0000000EDE68: D5207C1C 00123880
	s_or_b32 s13, s1, s13                                      // 0000000EDE70: 8C0D0D01
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000EDE74: 917E0D7E
	s_cbranch_execz 129                                        // 0000000EDE78: BFA50081 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1980>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EDE7C: BF8700A2
	v_lshrrev_b32_e32 v29, 4, v32                              // 0000000EDE80: 323A4084
	s_mov_b32 s14, exec_lo                                     // 0000000EDE84: BE8E007E
	v_or3_b32 v33, v29, s7, 32                                 // 0000000EDE88: D6580021 02800F1D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EDE90: BF870001
	.long 0xd4c4007e                                           // 0000000EDE94: D4C4007E
	v_cndmask_b32_e32 v1, s30, v33, vcc_lo                     // 0000000EDE98: 0202421E
	s_cbranch_execz 65508                                      // 0000000EDE9C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1730>
	v_mov_b32_e32 v34, 0                                       // 0000000EDEA0: 7E440280
	v_mov_b32_e32 v30, v1                                      // 0000000EDEA4: 7E3C0301
	s_movk_i32 s1, 0xfe00                                      // 0000000EDEA8: B001FE00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EDEAC: BF870009
	v_add_nc_u32_e32 v66, s1, v3                               // 0000000EDEB0: 4A840601
	s_add_i32 s1, s1, 64                                       // 0000000EDEB4: 8101C001
	ds_load_2addr_b32 v[35:36], v30 offset1:17                 // 0000000EDEB8: D8DC1100 2300001E
	ds_load_2addr_b32 v[37:38], v66 offset0:128 offset1:129    // 0000000EDEC0: D8DC8180 25000042
	ds_load_2addr_b32 v[39:40], v30 offset0:34 offset1:51      // 0000000EDEC8: D8DC3322 2700001E
	ds_load_2addr_b32 v[41:42], v66 offset0:130 offset1:131    // 0000000EDED0: D8DC8382 29000042
	ds_load_2addr_b32 v[60:61], v30 offset0:68 offset1:85      // 0000000EDED8: D8DC5544 3C00001E
	ds_load_2addr_b32 v[62:63], v66 offset0:132 offset1:133    // 0000000EDEE0: D8DC8584 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:134 offset1:135    // 0000000EDEE8: D8DC8786 40000042
	s_cmp_lg_u32 s1, 0                                         // 0000000EDEF0: BF078001
	s_waitcnt lgkmcnt(5)                                       // 0000000EDEF4: BF89FC57
	v_fmac_f32_e32 v34, v37, v35                               // 0000000EDEF8: 56444725
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000EDEFC: BF8700C1
	v_fmac_f32_e32 v34, v38, v36                               // 0000000EDF00: 56444926
	ds_load_2addr_b32 v[35:36], v30 offset0:102 offset1:119    // 0000000EDF04: D8DC7766 2300001E
	s_waitcnt lgkmcnt(4)                                       // 0000000EDF0C: BF89FC47
	v_fmac_f32_e32 v34, v41, v39                               // 0000000EDF10: 56444F29
	v_fmac_f32_e32 v34, v42, v40                               // 0000000EDF14: 5644512A
	ds_load_2addr_b32 v[37:38], v30 offset0:136 offset1:153    // 0000000EDF18: D8DC9988 2500001E
	ds_load_2addr_b32 v[39:40], v66 offset0:136 offset1:137    // 0000000EDF20: D8DC8988 27000042
	s_waitcnt lgkmcnt(4)                                       // 0000000EDF28: BF89FC47
	v_fmac_f32_e32 v34, v62, v60                               // 0000000EDF2C: 5644793E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000EDF30: BF8700D1
	v_fmac_f32_e32 v34, v63, v61                               // 0000000EDF34: 56447B3F
	ds_load_2addr_b32 v[41:42], v30 offset0:170 offset1:187    // 0000000EDF38: D8DCBBAA 2900001E
	ds_load_2addr_b32 v[60:61], v66 offset0:138 offset1:139    // 0000000EDF40: D8DC8B8A 3C000042
	s_waitcnt lgkmcnt(4)                                       // 0000000EDF48: BF89FC47
	v_fmac_f32_e32 v34, v64, v35                               // 0000000EDF4C: 56444740
	v_fmac_f32_e32 v34, v65, v36                               // 0000000EDF50: 56444941
	ds_load_2addr_b32 v[35:36], v30 offset0:204 offset1:221    // 0000000EDF54: D8DCDDCC 2300001E
	ds_load_2addr_b32 v[62:63], v66 offset0:140 offset1:141    // 0000000EDF5C: D8DC8D8C 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:142 offset1:143    // 0000000EDF64: D8DC8F8E 40000042
	s_waitcnt lgkmcnt(5)                                       // 0000000EDF6C: BF89FC57
	v_fmac_f32_e32 v34, v39, v37                               // 0000000EDF70: 56444B27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000EDF74: BF8700D1
	v_fmac_f32_e32 v34, v40, v38                               // 0000000EDF78: 56444D28
	ds_load_2addr_b32 v[37:38], v30 offset0:238 offset1:255    // 0000000EDF7C: D8DCFFEE 2500001E
	v_add_nc_u32_e32 v30, 0x440, v30                           // 0000000EDF84: 4A3C3CFF 00000440
	s_waitcnt lgkmcnt(4)                                       // 0000000EDF8C: BF89FC47
	v_fmac_f32_e32 v34, v60, v41                               // 0000000EDF90: 5644533C
	v_fmac_f32_e32 v34, v61, v42                               // 0000000EDF94: 5644553D
	s_waitcnt lgkmcnt(2)                                       // 0000000EDF98: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDF9C: BF870091
	v_fmac_f32_e32 v34, v62, v35                               // 0000000EDFA0: 5644473E
	v_fmac_f32_e32 v34, v63, v36                               // 0000000EDFA4: 5644493F
	s_waitcnt lgkmcnt(0)                                       // 0000000EDFA8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EDFAC: BF870091
	v_fmac_f32_e32 v34, v64, v37                               // 0000000EDFB0: 56444B40
	v_fmac_f32_e32 v34, v65, v38                               // 0000000EDFB4: 56444D41
	s_cbranch_scc1 65468                                       // 0000000EDFB8: BFA2FFBC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17ac>
	v_lshlrev_b32_e32 v29, 2, v29                              // 0000000EDFBC: 303A3A82
	v_mov_b32_e32 v35, v1                                      // 0000000EDFC0: 7E460301
	s_mov_b32 s15, 0                                           // 0000000EDFC4: BE8F0080
	ds_load_b32 v36, v29 offset:21696                          // 0000000EDFC8: D8D854C0 2400001D
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000EDFD0: CA10011C 1E1C011B
	s_waitcnt lgkmcnt(0)                                       // 0000000EDFD8: BF89FC07
	v_mul_f32_e32 v34, v34, v36                                // 0000000EDFDC: 10444922
	v_mov_b32_e32 v36, v31                                     // 0000000EDFE0: 7E48031F
	s_nop 0                                                    // 0000000EDFE4: BF800000
	s_nop 0                                                    // 0000000EDFE8: BF800000
	s_nop 0                                                    // 0000000EDFEC: BF800000
	s_nop 0                                                    // 0000000EDFF0: BF800000
	s_nop 0                                                    // 0000000EDFF4: BF800000
	s_nop 0                                                    // 0000000EDFF8: BF800000
	s_nop 0                                                    // 0000000EDFFC: BF800000
	global_load_b32 v37, v[29:30], off                         // 0000000EE000: DC520000 257C001D
	ds_load_b32 v38, v35 offset:16960                          // 0000000EE008: D8D84240 26000023
	v_add_nc_u32_e32 v36, -1, v36                              // 0000000EE010: 4A4848C1
	.long 0xd700011d                                           // 0000000EE014: D700011D
	v_cndmask_b32_e32 v0, v29, v132, vcc_lo                    // 0000000EE018: 0201091D
	v_add_nc_u32_e32 v35, 0x44, v35                            // 0000000EE01C: 4A4646FF 00000044
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000EE024: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EE02C: BF870004
	.long 0xd44a0004                                           // 0000000EE030: D44A0004
	v_cndmask_b32_e32 v1, 0, v36, vcc_lo                       // 0000000EE034: 02024880
	s_or_b32 s15, s4, s15                                      // 0000000EE038: 8C0F0F04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EE03C: BF890007
	v_fmac_f32_e32 v34, v37, v38                               // 0000000EE040: 56444D25
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000000EE044: 917E0F7E
	s_cbranch_execnz 65517                                     // 0000000EE048: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1900>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000000EE04C: 8C7E0F7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EE050: BF870121
	v_bfe_u32 v35, v34, 16, 1                                  // 0000000EE054: D6100023 02052122
	v_mad_u64_u32 v[29:30], null, 0x3000, v33, v[9:10]         // 0000000EE05C: D6FE7C1D 042642FF 00003000
	v_add3_u32 v33, v34, v35, 0x7fff                           // 0000000EE068: D6550021 03FE4722 00007FFF
	global_store_d16_hi_b16 v[29:30], v33, off                 // 0000000EE074: DC960000 007C211D
	s_branch 65388                                             // 0000000EE07C: BFA0FF6C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1730>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000000EE080: 8C7E0C7E
	v_mov_b32_e32 v3, v0                                       // 0000000EE084: 7E060300
	s_mov_b32 s4, 0                                            // 0000000EE088: BE840080
	s_waitcnt_vscnt null, 0x0                                  // 0000000EE08C: BC7C0000
	s_barrier                                                  // 0000000EE090: BFBD0000
	buffer_gl0_inv                                             // 0000000EE094: E0AC0000 00000000
	s_nop 0                                                    // 0000000EE09C: BF800000
	s_nop 0                                                    // 0000000EE0A0: BF800000
	s_nop 0                                                    // 0000000EE0A4: BF800000
	s_nop 0                                                    // 0000000EE0A8: BF800000
	s_nop 0                                                    // 0000000EE0AC: BF800000
	s_nop 0                                                    // 0000000EE0B0: BF800000
	s_nop 0                                                    // 0000000EE0B4: BF800000
	s_nop 0                                                    // 0000000EE0B8: BF800000
	s_nop 0                                                    // 0000000EE0BC: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000EE0C0: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000EE0C4: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE0CC: BF870092
	v_or_b32_e32 v27, s11, v29                                 // 0000000EE0D0: 38363A0B
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000EE0D4: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE0DC: BF870091
	.long 0xd73c001b                                           // 0000000EE0E0: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000EE0E4: 02023689
	.long 0xd700011b                                           // 0000000EE0E8: D700011B
	v_cndmask_b32_e32 v1, v55, v27, vcc_lo                     // 0000000EE0EC: 02023737
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EE0F0: BF870001
	v_add_co_ci_u32_e64 v28, null, v56, v28, s1                // 0000000EE0F4: D5207C1C 00063938
	.long 0xd4490001                                           // 0000000EE0FC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000EE100: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000EE108: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000EE10C: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000EE114: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000EE120: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000EE124: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000EE128: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EE130: 917E047E
	s_cbranch_execnz 65506                                     // 0000000EE134: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EE138: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000EE13C: BF89FC07
	s_barrier                                                  // 0000000EE140: BFBD0000
	buffer_gl0_inv                                             // 0000000EE144: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 0000000EE14C: BE8B2000
	s_cbranch_execz 155                                        // 0000000EE150: BFA5009B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	v_dual_mov_b32 v28, v20 :: v_dual_mov_b32 v27, v19         // 0000000EE154: CA100114 1C1A0113
	v_dual_mov_b32 v3, v59 :: v_dual_mov_b32 v32, v0           // 0000000EE15C: CA10013B 03200100
	v_mov_b32_e32 v31, v54                                     // 0000000EE164: 7E3E0336
	s_mov_b32 s12, 0                                           // 0000000EE168: BE8C0080
	s_branch 19                                                // 0000000EE16C: BFA00013 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1abc>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000EE170: 8C7E0D7E
	v_add_nc_u32_e32 v29, 0x80, v32                            // 0000000EE174: 4A3A40FF 00000080
	.long 0xd4490001                                           // 0000000EE17C: D4490001
	v_cndmask_b32_e32 v1, 0x7f, v32, vcc_lo                    // 0000000EE180: 020240FF 0000007F
	.long 0xd700041b                                           // 0000000EE188: D700041B
	v_cndmask_b32_e32 v1, 0x800, v27, vcc_lo                   // 0000000EE18C: 020236FF 00000800
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000EE194: BF8704C3
	v_dual_mov_b32 v32, v29 :: v_dual_add_nc_u32 v31, 8, v31   // 0000000EE198: CA20011D 201E3E88
	v_add_nc_u32_e32 v3, 0x1020, v3                            // 0000000EE1A0: 4A0606FF 00001020
	v_add_co_ci_u32_e64 v28, null, 0, v28, s4                  // 0000000EE1A8: D5207C1C 00123880
	s_or_b32 s12, s1, s12                                      // 0000000EE1B0: 8C0C0C01
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 0000000EE1B4: 917E0C7E
	s_cbranch_execz 129                                        // 0000000EE1B8: BFA50081 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EE1BC: BF8700A2
	v_lshrrev_b32_e32 v29, 4, v32                              // 0000000EE1C0: 323A4084
	s_mov_b32 s13, exec_lo                                     // 0000000EE1C4: BE8D007E
	v_or3_b32 v33, v29, s7, 48                                 // 0000000EE1C8: D6580021 02C00F1D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EE1D0: BF870001
	.long 0xd4c4007e                                           // 0000000EE1D4: D4C4007E
	v_cndmask_b32_e32 v1, s30, v33, vcc_lo                     // 0000000EE1D8: 0202421E
	s_cbranch_execz 65508                                      // 0000000EE1DC: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a70>
	v_mov_b32_e32 v34, 0                                       // 0000000EE1E0: 7E440280
	v_mov_b32_e32 v30, v1                                      // 0000000EE1E4: 7E3C0301
	s_movk_i32 s1, 0xfe00                                      // 0000000EE1E8: B001FE00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EE1EC: BF870009
	v_add_nc_u32_e32 v66, s1, v3                               // 0000000EE1F0: 4A840601
	s_add_i32 s1, s1, 64                                       // 0000000EE1F4: 8101C001
	ds_load_2addr_b32 v[35:36], v30 offset1:17                 // 0000000EE1F8: D8DC1100 2300001E
	ds_load_2addr_b32 v[37:38], v66 offset0:128 offset1:129    // 0000000EE200: D8DC8180 25000042
	ds_load_2addr_b32 v[39:40], v30 offset0:34 offset1:51      // 0000000EE208: D8DC3322 2700001E
	ds_load_2addr_b32 v[41:42], v66 offset0:130 offset1:131    // 0000000EE210: D8DC8382 29000042
	ds_load_2addr_b32 v[60:61], v30 offset0:68 offset1:85      // 0000000EE218: D8DC5544 3C00001E
	ds_load_2addr_b32 v[62:63], v66 offset0:132 offset1:133    // 0000000EE220: D8DC8584 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:134 offset1:135    // 0000000EE228: D8DC8786 40000042
	s_cmp_lg_u32 s1, 0                                         // 0000000EE230: BF078001
	s_waitcnt lgkmcnt(5)                                       // 0000000EE234: BF89FC57
	v_fmac_f32_e32 v34, v37, v35                               // 0000000EE238: 56444725
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000EE23C: BF8700C1
	v_fmac_f32_e32 v34, v38, v36                               // 0000000EE240: 56444926
	ds_load_2addr_b32 v[35:36], v30 offset0:102 offset1:119    // 0000000EE244: D8DC7766 2300001E
	s_waitcnt lgkmcnt(4)                                       // 0000000EE24C: BF89FC47
	v_fmac_f32_e32 v34, v41, v39                               // 0000000EE250: 56444F29
	v_fmac_f32_e32 v34, v42, v40                               // 0000000EE254: 5644512A
	ds_load_2addr_b32 v[37:38], v30 offset0:136 offset1:153    // 0000000EE258: D8DC9988 2500001E
	ds_load_2addr_b32 v[39:40], v66 offset0:136 offset1:137    // 0000000EE260: D8DC8988 27000042
	s_waitcnt lgkmcnt(4)                                       // 0000000EE268: BF89FC47
	v_fmac_f32_e32 v34, v62, v60                               // 0000000EE26C: 5644793E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000EE270: BF8700D1
	v_fmac_f32_e32 v34, v63, v61                               // 0000000EE274: 56447B3F
	ds_load_2addr_b32 v[41:42], v30 offset0:170 offset1:187    // 0000000EE278: D8DCBBAA 2900001E
	ds_load_2addr_b32 v[60:61], v66 offset0:138 offset1:139    // 0000000EE280: D8DC8B8A 3C000042
	s_waitcnt lgkmcnt(4)                                       // 0000000EE288: BF89FC47
	v_fmac_f32_e32 v34, v64, v35                               // 0000000EE28C: 56444740
	v_fmac_f32_e32 v34, v65, v36                               // 0000000EE290: 56444941
	ds_load_2addr_b32 v[35:36], v30 offset0:204 offset1:221    // 0000000EE294: D8DCDDCC 2300001E
	ds_load_2addr_b32 v[62:63], v66 offset0:140 offset1:141    // 0000000EE29C: D8DC8D8C 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:142 offset1:143    // 0000000EE2A4: D8DC8F8E 40000042
	s_waitcnt lgkmcnt(5)                                       // 0000000EE2AC: BF89FC57
	v_fmac_f32_e32 v34, v39, v37                               // 0000000EE2B0: 56444B27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000EE2B4: BF8700D1
	v_fmac_f32_e32 v34, v40, v38                               // 0000000EE2B8: 56444D28
	ds_load_2addr_b32 v[37:38], v30 offset0:238 offset1:255    // 0000000EE2BC: D8DCFFEE 2500001E
	v_add_nc_u32_e32 v30, 0x440, v30                           // 0000000EE2C4: 4A3C3CFF 00000440
	s_waitcnt lgkmcnt(4)                                       // 0000000EE2CC: BF89FC47
	v_fmac_f32_e32 v34, v60, v41                               // 0000000EE2D0: 5644533C
	v_fmac_f32_e32 v34, v61, v42                               // 0000000EE2D4: 5644553D
	s_waitcnt lgkmcnt(2)                                       // 0000000EE2D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE2DC: BF870091
	v_fmac_f32_e32 v34, v62, v35                               // 0000000EE2E0: 5644473E
	v_fmac_f32_e32 v34, v63, v36                               // 0000000EE2E4: 5644493F
	s_waitcnt lgkmcnt(0)                                       // 0000000EE2E8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE2EC: BF870091
	v_fmac_f32_e32 v34, v64, v37                               // 0000000EE2F0: 56444B40
	v_fmac_f32_e32 v34, v65, v38                               // 0000000EE2F4: 56444D41
	s_cbranch_scc1 65468                                       // 0000000EE2F8: BFA2FFBC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1aec>
	v_lshlrev_b32_e32 v29, 2, v29                              // 0000000EE2FC: 303A3A82
	v_mov_b32_e32 v35, v1                                      // 0000000EE300: 7E460301
	s_mov_b32 s14, 0                                           // 0000000EE304: BE8E0080
	ds_load_b32 v36, v29 offset:21760                          // 0000000EE308: D8D85500 2400001D
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000EE310: CA10011C 1E1C011B
	s_waitcnt lgkmcnt(0)                                       // 0000000EE318: BF89FC07
	v_mul_f32_e32 v34, v34, v36                                // 0000000EE31C: 10444922
	v_mov_b32_e32 v36, v31                                     // 0000000EE320: 7E48031F
	s_nop 0                                                    // 0000000EE324: BF800000
	s_nop 0                                                    // 0000000EE328: BF800000
	s_nop 0                                                    // 0000000EE32C: BF800000
	s_nop 0                                                    // 0000000EE330: BF800000
	s_nop 0                                                    // 0000000EE334: BF800000
	s_nop 0                                                    // 0000000EE338: BF800000
	s_nop 0                                                    // 0000000EE33C: BF800000
	global_load_b32 v37, v[29:30], off                         // 0000000EE340: DC520000 257C001D
	ds_load_b32 v38, v35 offset:16960                          // 0000000EE348: D8D84240 26000023
	v_add_nc_u32_e32 v36, -1, v36                              // 0000000EE350: 4A4848C1
	.long 0xd700011d                                           // 0000000EE354: D700011D
	v_cndmask_b32_e32 v0, v29, v132, vcc_lo                    // 0000000EE358: 0201091D
	v_add_nc_u32_e32 v35, 0x44, v35                            // 0000000EE35C: 4A4646FF 00000044
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000EE364: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EE36C: BF870004
	.long 0xd44a0004                                           // 0000000EE370: D44A0004
	v_cndmask_b32_e32 v1, 0, v36, vcc_lo                       // 0000000EE374: 02024880
	s_or_b32 s14, s4, s14                                      // 0000000EE378: 8C0E0E04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EE37C: BF890007
	v_fmac_f32_e32 v34, v37, v38                               // 0000000EE380: 56444D25
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000EE384: 917E0E7E
	s_cbranch_execnz 65517                                     // 0000000EE388: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000EE38C: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EE390: BF870121
	v_bfe_u32 v35, v34, 16, 1                                  // 0000000EE394: D6100023 02052122
	v_mad_u64_u32 v[29:30], null, 0x3000, v33, v[9:10]         // 0000000EE39C: D6FE7C1D 042642FF 00003000
	v_add3_u32 v33, v34, v35, 0x7fff                           // 0000000EE3A8: D6550021 03FE4722 00007FFF
	global_store_d16_hi_b16 v[29:30], v33, off                 // 0000000EE3B4: DC960000 007C211D
	s_branch 65388                                             // 0000000EE3BC: BFA0FF6C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a70>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000000EE3C0: 8C7E0B7E
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000EE3C4: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v27, v0                                      // 0000000EE3CC: 7E360300
	s_waitcnt_vscnt null, 0x0                                  // 0000000EE3D0: BC7C0000
	s_barrier                                                  // 0000000EE3D4: BFBD0000
	s_xor_b32 s4, s1, 0x80000000                               // 0000000EE3D8: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000EE3E0: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000EE3E4: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000EE3EC: BF4EFF0A C2CE8ED0
	buffer_gl0_inv                                             // 0000000EE3F4: E0AC0000 00000000
	s_sub_f32 s1, s1, s11                                      // 0000000EE3FC: A0810B01
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000EE400: A304040A 32A5705F
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 0000000EE408: BF87052B
	s_add_f32 s1, s1, s4                                       // 0000000EE40C: A0010401
	s_mov_b32 s4, 0                                            // 0000000EE410: BE840080
	v_exp_f32_e32 v3, s1                                       // 0000000EE414: 7E064A01
	s_cvt_i32_f32 s1, s11                                      // 0000000EE418: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000EE41C: BF870585
	.long 0xd71c0003                                           // 0000000EE420: D71C0003
	v_cndmask_b32_e32 v0, v3, v1, vcc_lo                       // 0000000EE424: 02000303
	s_cselect_b32 s1, -1, 0                                    // 0000000EE428: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000EE42C: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EE434: BF870001
	v_cndmask_b32_e64 v3, 0, v3, s1                            // 0000000EE438: D5010003 00060680
	s_cselect_b32 s1, -1, 0                                    // 0000000EE440: 980180C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000EE444: BF870481
	v_cndmask_b32_e64 v3, 0x7f800000, v3, s1                   // 0000000EE448: D5010003 000606FF 7F800000
	s_nop 0                                                    // 0000000EE454: BF800000
	s_nop 0                                                    // 0000000EE458: BF800000
	s_nop 0                                                    // 0000000EE45C: BF800000
	s_nop 0                                                    // 0000000EE460: BF800000
	s_nop 0                                                    // 0000000EE464: BF800000
	s_nop 0                                                    // 0000000EE468: BF800000
	s_nop 0                                                    // 0000000EE46C: BF800000
	s_nop 0                                                    // 0000000EE470: BF800000
	s_nop 0                                                    // 0000000EE474: BF800000
	s_nop 0                                                    // 0000000EE478: BF800000
	s_nop 0                                                    // 0000000EE47C: BF800000
	v_lshrrev_b32_e32 v28, 4, v27                              // 0000000EE480: 32383684
	.long 0xd4490001                                           // 0000000EE484: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v27, vcc_lo                   // 0000000EE488: 020236FF 0000077F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000EE490: BF8700D2
	v_mad_u64_u32 v[28:29], null, 0x44, v28, v[1:2]            // 0000000EE494: D6FE7C1C 040638FF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000EE4A0: 8C040401
	ds_load_b32 v29, v28                                       // 0000000EE4A4: D8D80000 1D00001C
	s_waitcnt lgkmcnt(0)                                       // 0000000EE4AC: BF89FC07
	v_dual_mul_f32 v29, v3, v29 :: v_dual_add_nc_u32 v30, 0x80, v27// 0000000EE4B0: C8E03B03 1D1E36FF 00000080
	v_mov_b32_e32 v27, v30                                     // 0000000EE4BC: 7E36031E
	ds_store_b32 v28, v29                                      // 0000000EE4C0: D8340000 00001D1C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EE4C8: 917E047E
	s_cbranch_execnz 65516                                     // 0000000EE4CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d80>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EE4D0: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000EE4D4: BF89FC07
	s_barrier                                                  // 0000000EE4D8: BFBD0000
	buffer_gl0_inv                                             // 0000000EE4DC: E0AC0000 00000000
	s_and_saveexec_b32 s10, s5                                 // 0000000EE4E4: BE8A2005
	s_cbranch_execz 45                                         // 0000000EE4E8: BFA5002D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ea0>
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v28, v18            // 0000000EE4EC: CA100080 031C0112
	v_dual_mov_b32 v27, v17 :: v_dual_mov_b32 v30, v44         // 0000000EE4F4: CA100111 1B1E012C
	v_mov_b32_e32 v29, 0                                       // 0000000EE4FC: 7E3A0280
	s_mov_b32 s11, 0                                           // 0000000EE500: BE8B0080
	s_nop 0                                                    // 0000000EE504: BF800000
	s_nop 0                                                    // 0000000EE508: BF800000
	s_nop 0                                                    // 0000000EE50C: BF800000
	s_nop 0                                                    // 0000000EE510: BF800000
	s_nop 0                                                    // 0000000EE514: BF800000
	s_nop 0                                                    // 0000000EE518: BF800000
	s_nop 0                                                    // 0000000EE51C: BF800000
	s_nop 0                                                    // 0000000EE520: BF800000
	s_nop 0                                                    // 0000000EE524: BF800000
	s_nop 0                                                    // 0000000EE528: BF800000
	s_nop 0                                                    // 0000000EE52C: BF800000
	s_nop 0                                                    // 0000000EE530: BF800000
	s_nop 0                                                    // 0000000EE534: BF800000
	s_nop 0                                                    // 0000000EE538: BF800000
	s_nop 0                                                    // 0000000EE53C: BF800000
	global_load_b32 v31, v[27:28], off                         // 0000000EE540: DC520000 1F7C001B
	ds_load_b32 v32, v29 offset:21312                          // 0000000EE548: D8D85340 2000001D
	v_add_nc_u32_e32 v3, -1, v3                                // 0000000EE550: 4A0606C1
	.long 0xd700011b                                           // 0000000EE554: D700011B
	v_cndmask_b32_e32 v1, 0x6000, v27, vcc_lo                  // 0000000EE558: 020236FF 00006000
	v_add_nc_u32_e32 v29, 4, v29                               // 0000000EE560: 4A3A3A84
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000EE564: D5207C1C 00063880
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EE56C: BF870004
	.long 0xd44a0004                                           // 0000000EE570: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 0000000EE574: 02020680
	s_or_b32 s11, s4, s11                                      // 0000000EE578: 8C0B0B04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EE57C: BF890007
	v_mul_f32_e32 v31, v31, v32                                // 0000000EE580: 103E411F
	ds_store_b32 v30, v31 offset:8704                          // 0000000EE584: D8342200 00001F1E
	v_add_nc_u32_e32 v30, 0x204, v30                           // 0000000EE58C: 4A3C3CFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000EE594: 917E0B7E
	s_cbranch_execnz 65513                                     // 0000000EE598: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e40>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000000EE59C: 8C7E0B7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EE5A0: BF870009
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000EE5A4: 8C7E0A7E
	v_mov_b32_e32 v3, v0                                       // 0000000EE5A8: 7E060300
	s_mov_b32 s4, 0                                            // 0000000EE5AC: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000EE5B0: BF870241
	v_add_nc_u32_e32 v27, 0x80, v3                             // 0000000EE5B4: 4A3606FF 00000080
	v_add_nc_u32_e32 v28, 0x100, v3                            // 0000000EE5BC: 4A3806FF 00000100
	v_lshrrev_b32_e32 v35, 7, v3                               // 0000000EE5C4: 32460687
	v_add_nc_u32_e32 v29, 0x180, v3                            // 0000000EE5C8: 4A3A06FF 00000180
	v_lshrrev_b32_e32 v36, 7, v27                              // 0000000EE5D0: 32483687
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EE5D4: BF870214
	v_lshrrev_b32_e32 v37, 7, v28                              // 0000000EE5D8: 324A3887
	v_or_b32_e32 v27, s7, v35                                  // 0000000EE5DC: 38364607
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EE5E0: BF870214
	v_lshrrev_b32_e32 v38, 7, v29                              // 0000000EE5E4: 324C3A87
	v_or_b32_e32 v29, s7, v36                                  // 0000000EE5E8: 383A4807
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EE5EC: BF870214
	v_or_b32_e32 v31, s7, v37                                  // 0000000EE5F0: 383E4A07
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000EE5F4: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EE5FC: BF870214
	v_or_b32_e32 v33, s7, v38                                  // 0000000EE600: 38424C07
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000EE604: D6FE7C1D 0009611D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EE60C: BF870194
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 0000000EE610: D6FE7C1F 0009611F
	v_mad_u64_u32 v[33:34], null, v33, 48, s[2:3]              // 0000000EE618: D6FE7C21 00096121
	.long 0xd73c001b                                           // 0000000EE620: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000EE624: 02023689
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EE628: BF870214
	.long 0xd73c001d                                           // 0000000EE62C: D73C001D
	v_cndmask_b32_e32 v1, 9, v29, vcc_lo                       // 0000000EE630: 02023A89
	.long 0xd73c001f                                           // 0000000EE634: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 0000000EE638: 02023E89
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000EE63C: BF870214
	.long 0xd73c0021                                           // 0000000EE640: D73C0021
	v_cndmask_b32_e32 v1, 9, v33, vcc_lo                       // 0000000EE644: 02024289
	.long 0xd700011b                                           // 0000000EE648: D700011B
	v_cndmask_b32_e32 v1, v57, v27, vcc_lo                     // 0000000EE64C: 02023739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EE650: BF8700A1
	v_add_co_ci_u32_e64 v28, null, v58, v28, s1                // 0000000EE654: D5207C1C 0006393A
	.long 0xd700011d                                           // 0000000EE65C: D700011D
	v_cndmask_b32_e32 v1, v57, v29, vcc_lo                     // 0000000EE660: 02023B39
	v_add_co_ci_u32_e64 v30, null, v58, v30, s1                // 0000000EE664: D5207C1E 00063D3A
	.long 0xd700011f                                           // 0000000EE66C: D700011F
	v_cndmask_b32_e32 v1, v57, v31, vcc_lo                     // 0000000EE670: 02023F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EE674: BF8700A1
	v_add_co_ci_u32_e64 v32, null, v58, v32, s1                // 0000000EE678: D5207C20 0006413A
	.long 0xd7000121                                           // 0000000EE680: D7000121
	v_cndmask_b32_e32 v1, v57, v33, vcc_lo                     // 0000000EE684: 02024339
	v_add_co_ci_u32_e64 v34, null, v58, v34, s1                // 0000000EE688: D5207C22 0006453A
	s_clause 0x3                                               // 0000000EE690: BF850003
	global_load_b32 v39, v[27:28], off                         // 0000000EE694: DC520000 277C001B
	global_load_b32 v40, v[29:30], off                         // 0000000EE69C: DC520000 287C001D
	global_load_b32 v32, v[31:32], off                         // 0000000EE6A4: DC520000 207C001F
	global_load_b32 v33, v[33:34], off                         // 0000000EE6AC: DC520000 217C0021
	v_lshlrev_b32_e32 v27, 2, v35                              // 0000000EE6B4: 30364682
	v_lshlrev_b32_e32 v28, 2, v36                              // 0000000EE6B8: 30384882
	v_lshlrev_b32_e32 v29, 2, v37                              // 0000000EE6BC: 303A4A82
	v_lshlrev_b32_e32 v30, 2, v38                              // 0000000EE6C0: 303C4C82
	ds_load_b32 v34, v27 offset:21312                          // 0000000EE6C4: D8D85340 2200001B
	ds_load_b32 v41, v28 offset:21312                          // 0000000EE6CC: D8D85340 2900001C
	ds_load_b32 v42, v29 offset:21312                          // 0000000EE6D4: D8D85340 2A00001D
	ds_load_b32 v60, v30 offset:21312                          // 0000000EE6DC: D8D85340 3C00001E
	v_mad_u64_u32 v[27:28], null, 0x204, v35, v[7:8]           // 0000000EE6E4: D6FE7C1B 041E46FF 00000204
	v_mad_u64_u32 v[28:29], null, 0x204, v36, v[7:8]           // 0000000EE6F0: D6FE7C1C 041E48FF 00000204
	.long 0xd4490001                                           // 0000000EE6FC: D4490001
	v_cndmask_b32_e32 v1, 0x5ff, v3, vcc_lo                    // 0000000EE700: 020206FF 000005FF
	v_mad_u64_u32 v[29:30], null, 0x204, v37, v[7:8]           // 0000000EE708: D6FE7C1D 041E4AFF 00000204
	v_mad_u64_u32 v[30:31], null, 0x204, v38, v[7:8]           // 0000000EE714: D6FE7C1E 041E4CFF 00000204
	v_add_nc_u32_e32 v3, 0x200, v3                             // 0000000EE720: 4A0606FF 00000200
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000EE728: BF870004
	s_or_b32 s4, s1, s4                                        // 0000000EE72C: 8C040401
	s_waitcnt vmcnt(2) lgkmcnt(2)                              // 0000000EE730: BF890827
	v_dual_mul_f32 v31, v39, v34 :: v_dual_mul_f32 v34, v40, v41// 0000000EE734: C8C64527 1F225328
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EE73C: BF890007
	v_dual_mul_f32 v32, v32, v42 :: v_dual_mul_f32 v33, v33, v60// 0000000EE740: C8C65520 20207921
	ds_store_b32 v27, v31                                      // 0000000EE748: D8340000 00001F1B
	ds_store_b32 v28, v34                                      // 0000000EE750: D8340000 0000221C
	ds_store_b32 v29, v32                                      // 0000000EE758: D8340000 0000201D
	ds_store_b32 v30, v33                                      // 0000000EE760: D8340000 0000211E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EE768: 917E047E
	s_cbranch_execnz 65424                                     // 0000000EE76C: BFA6FF90 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1eb0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EE770: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000EE774: BF89FC07
	s_barrier                                                  // 0000000EE778: BFBD0000
	buffer_gl0_inv                                             // 0000000EE77C: E0AC0000 00000000
	ds_load_2addr_b32 v[27:28], v8 offset1:17                  // 0000000EE784: D8DC1100 1B000008
	ds_load_2addr_b32 v[29:30], v8 offset0:34 offset1:51       // 0000000EE78C: D8DC3322 1D000008
	ds_load_2addr_b32 v[31:32], v8 offset0:68 offset1:85       // 0000000EE794: D8DC5544 1F000008
	ds_load_2addr_b32 v[33:34], v8 offset0:102 offset1:119     // 0000000EE79C: D8DC7766 21000008
	ds_load_2addr_b32 v[35:36], v8 offset0:136 offset1:153     // 0000000EE7A4: D8DC9988 23000008
	ds_load_2addr_b32 v[37:38], v8 offset0:170 offset1:187     // 0000000EE7AC: D8DCBBAA 25000008
	ds_load_2addr_b32 v[39:40], v8 offset0:204 offset1:221     // 0000000EE7B4: D8DCDDCC 27000008
	ds_load_2addr_b32 v[41:42], v8 offset0:238 offset1:255     // 0000000EE7BC: D8DCFFEE 29000008
	v_mov_b32_e32 v3, v0                                       // 0000000EE7C4: 7E060300
	s_mov_b32 s4, 0                                            // 0000000EE7C8: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EE7CC: BF870121
	v_lshrrev_b32_e32 v60, 4, v3                               // 0000000EE7D0: 32780684
	.long 0xd4490001                                           // 0000000EE7D4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000EE7D8: 020206FF 0000077F
	v_lshlrev_b32_e32 v67, 2, v60                              // 0000000EE7E0: 30867882
	v_mad_u64_u32 v[60:61], null, 0x44, v60, v[1:2]            // 0000000EE7E4: D6FE7C3C 040678FF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000EE7F0: 8C040401
	v_add_nc_u32_e32 v61, 0x2200, v67                          // 0000000EE7F4: 4A7A86FF 00002200
	ds_load_b32 v68, v60                                       // 0000000EE7FC: D8D80000 4400003C
	ds_load_2addr_b32 v[61:62], v61 offset1:129                // 0000000EE804: D8DC8100 3D00003D
	s_waitcnt lgkmcnt(0)                                       // 0000000EE80C: BF89FC07
	v_fmac_f32_e32 v68, v61, v27                               // 0000000EE810: 5688373D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EE814: BF870001
	v_dual_fmac_f32 v68, v62, v28 :: v_dual_add_nc_u32 v63, 0x2600, v67// 0000000EE818: C820393E 443E86FF 00002600
	ds_load_2addr_b32 v[63:64], v63 offset0:2 offset1:131      // 0000000EE824: D8DC8302 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000EE82C: BF89FC07
	v_dual_fmac_f32 v68, v63, v29 :: v_dual_add_nc_u32 v65, 0x2a00, v67// 0000000EE830: C8203B3F 444086FF 00002A00
	ds_load_2addr_b32 v[65:66], v65 offset0:4 offset1:133      // 0000000EE83C: D8DC8504 41000041
	v_fmac_f32_e32 v68, v64, v30                               // 0000000EE844: 56883D40
	s_waitcnt lgkmcnt(0)                                       // 0000000EE848: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE84C: BF870091
	v_fmac_f32_e32 v68, v65, v31                               // 0000000EE850: 56883F41
	v_dual_fmac_f32 v68, v66, v32 :: v_dual_add_nc_u32 v61, 0x2e00, v67// 0000000EE854: C8204142 443C86FF 00002E00
	ds_load_2addr_b32 v[61:62], v61 offset0:6 offset1:135      // 0000000EE860: D8DC8706 3D00003D
	s_waitcnt lgkmcnt(0)                                       // 0000000EE868: BF89FC07
	v_dual_fmac_f32 v68, v61, v33 :: v_dual_add_nc_u32 v63, 0x3200, v67// 0000000EE86C: C820433D 443E86FF 00003200
	ds_load_2addr_b32 v[63:64], v63 offset0:8 offset1:137      // 0000000EE878: D8DC8908 3F00003F
	v_dual_fmac_f32 v68, v62, v34 :: v_dual_add_nc_u32 v65, 0x3600, v67// 0000000EE880: C820453E 444086FF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:10 offset1:139     // 0000000EE88C: D8DC8B0A 41000041
	s_waitcnt lgkmcnt(1)                                       // 0000000EE894: BF89FC17
	v_fmac_f32_e32 v68, v63, v35                               // 0000000EE898: 5688473F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EE89C: BF870001
	v_dual_fmac_f32 v68, v64, v36 :: v_dual_add_nc_u32 v61, 0x3a00, v67// 0000000EE8A0: C8204940 443C86FF 00003A00
	ds_load_2addr_b32 v[61:62], v61 offset0:12 offset1:141     // 0000000EE8AC: D8DC8D0C 3D00003D
	s_waitcnt lgkmcnt(1)                                       // 0000000EE8B4: BF89FC17
	v_dual_fmac_f32 v68, v65, v37 :: v_dual_add_nc_u32 v63, 0x3e00, v67// 0000000EE8B8: C8204B41 443E86FF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:14 offset1:143     // 0000000EE8C4: D8DC8F0E 3F00003F
	v_fmac_f32_e32 v68, v66, v38                               // 0000000EE8CC: 56884D42
	s_waitcnt lgkmcnt(1)                                       // 0000000EE8D0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE8D4: BF870091
	v_fmac_f32_e32 v68, v61, v39                               // 0000000EE8D8: 56884F3D
	v_dual_fmac_f32 v68, v62, v40 :: v_dual_add_nc_u32 v61, 0x80, v3// 0000000EE8DC: C820513E 443C06FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 0000000EE8E8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EE8EC: BF870091
	v_dual_mov_b32 v3, v61 :: v_dual_fmac_f32 v68, v63, v41    // 0000000EE8F0: CA00013D 0344533F
	v_fmac_f32_e32 v68, v64, v42                               // 0000000EE8F8: 56885540
	ds_store_b32 v60, v68                                      // 0000000EE8FC: D8340000 0000443C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EE904: 917E047E
	s_cbranch_execnz 65456                                     // 0000000EE908: BFA6FFB0 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x20cc>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EE90C: 8C7E047E
	v_dual_mov_b32 v28, v22 :: v_dual_mov_b32 v27, v21         // 0000000EE910: CA100116 1C1A0115
	v_dual_mov_b32 v3, v44 :: v_dual_mov_b32 v30, v43          // 0000000EE918: CA10012C 031E012B
	v_mov_b32_e32 v29, 0                                       // 0000000EE920: 7E3A0280
	s_mov_b32 s7, 0                                            // 0000000EE924: BE870080
	s_waitcnt lgkmcnt(0)                                       // 0000000EE928: BF89FC07
	s_barrier                                                  // 0000000EE92C: BFBD0000
	buffer_gl0_inv                                             // 0000000EE930: E0AC0000 00000000
	s_nop 0                                                    // 0000000EE938: BF800000
	s_nop 0                                                    // 0000000EE93C: BF800000
	global_load_b32 v31, v[27:28], off                         // 0000000EE940: DC520000 1F7C001B
	ds_load_b32 v32, v29 offset:21376                          // 0000000EE948: D8D85380 2000001D
	v_add_nc_u32_e32 v30, 0x80, v30                            // 0000000EE950: 4A3C3CFF 00000080
	.long 0xd700011b                                           // 0000000EE958: D700011B
	v_cndmask_b32_e32 v1, 0x6000, v27, vcc_lo                  // 0000000EE95C: 020236FF 00006000
	v_add_nc_u32_e32 v29, 4, v29                               // 0000000EE964: 4A3A3A84
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000EE968: D5207C1C 00063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EE970: BF890007
	v_mul_f32_e32 v31, v31, v32                                // 0000000EE974: 103E411F
	.long 0xd4490004                                           // 0000000EE978: D4490004
	v_cndmask_b32_e32 v1, 0x77f, v30, vcc_lo                   // 0000000EE97C: 02023CFF 0000077F
	ds_store_b32 v3, v31 offset:8704                           // 0000000EE984: D8342200 00001F03
	v_add_nc_u32_e32 v3, 0x204, v3                             // 0000000EE98C: 4A0606FF 00000204
	s_or_b32 s7, s4, s7                                        // 0000000EE994: 8C070704
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EE998: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000000EE99C: 917E077E
	s_cbranch_execnz 65511                                     // 0000000EE9A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2240>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000EE9A4: 8C7E077E
	v_add_nc_u32_e32 v3, 0x400, v8                             // 0000000EE9A8: 4A0610FF 00000400
	v_add_nc_u32_e32 v41, 0x600, v8                            // 0000000EE9B0: 4A5210FF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000EE9B8: BF89FC07
	s_barrier                                                  // 0000000EE9BC: BFBD0000
	buffer_gl0_inv                                             // 0000000EE9C0: E0AC0000 00000000
	ds_load_2addr_b32 v[33:34], v3 offset0:118 offset1:135     // 0000000EE9C8: D8DC8776 21000003
	ds_load_2addr_b32 v[35:36], v3 offset0:152 offset1:169     // 0000000EE9D0: D8DCA998 23000003
	ds_load_2addr_b32 v[37:38], v3 offset0:186 offset1:203     // 0000000EE9D8: D8DCCBBA 25000003
	ds_load_2addr_b32 v[39:40], v3 offset0:220 offset1:237     // 0000000EE9E0: D8DCEDDC 27000003
	ds_load_2addr_b32 v[41:42], v41 offset0:126 offset1:143    // 0000000EE9E8: D8DC8F7E 29000029
	ds_load_2addr_b32 v[27:28], v3 offset0:16 offset1:33       // 0000000EE9F0: D8DC2110 1B000003
	ds_load_2addr_b32 v[29:30], v3 offset0:50 offset1:67       // 0000000EE9F8: D8DC4332 1D000003
	ds_load_2addr_b32 v[31:32], v3 offset0:84 offset1:101      // 0000000EEA00: D8DC6554 1F000003
	v_mov_b32_e32 v3, v0                                       // 0000000EEA08: 7E060300
	s_mov_b32 s4, 0                                            // 0000000EEA0C: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EEA10: BF870121
	v_lshrrev_b32_e32 v60, 4, v3                               // 0000000EEA14: 32780684
	.long 0xd4490001                                           // 0000000EEA18: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000EEA1C: 020206FF 0000077F
	v_lshlrev_b32_e32 v67, 2, v60                              // 0000000EEA24: 30867882
	v_mad_u64_u32 v[60:61], null, 0x44, v60, v[1:2]            // 0000000EEA28: D6FE7C3C 040678FF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000EEA34: 8C040401
	v_add_nc_u32_e32 v61, 0x2200, v67                          // 0000000EEA38: 4A7A86FF 00002200
	ds_load_b32 v68, v60                                       // 0000000EEA40: D8D80000 4400003C
	ds_load_2addr_b32 v[61:62], v61 offset1:129                // 0000000EEA48: D8DC8100 3D00003D
	s_waitcnt lgkmcnt(0)                                       // 0000000EEA50: BF89FC07
	v_fmac_f32_e32 v68, v61, v27                               // 0000000EEA54: 5688373D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EEA58: BF870001
	v_dual_fmac_f32 v68, v62, v28 :: v_dual_add_nc_u32 v63, 0x2600, v67// 0000000EEA5C: C820393E 443E86FF 00002600
	ds_load_2addr_b32 v[63:64], v63 offset0:2 offset1:131      // 0000000EEA68: D8DC8302 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000EEA70: BF89FC07
	v_dual_fmac_f32 v68, v63, v29 :: v_dual_add_nc_u32 v65, 0x2a00, v67// 0000000EEA74: C8203B3F 444086FF 00002A00
	ds_load_2addr_b32 v[65:66], v65 offset0:4 offset1:133      // 0000000EEA80: D8DC8504 41000041
	v_fmac_f32_e32 v68, v64, v30                               // 0000000EEA88: 56883D40
	s_waitcnt lgkmcnt(0)                                       // 0000000EEA8C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEA90: BF870091
	v_fmac_f32_e32 v68, v65, v31                               // 0000000EEA94: 56883F41
	v_dual_fmac_f32 v68, v66, v32 :: v_dual_add_nc_u32 v61, 0x2e00, v67// 0000000EEA98: C8204142 443C86FF 00002E00
	ds_load_2addr_b32 v[61:62], v61 offset0:6 offset1:135      // 0000000EEAA4: D8DC8706 3D00003D
	s_waitcnt lgkmcnt(0)                                       // 0000000EEAAC: BF89FC07
	v_dual_fmac_f32 v68, v61, v33 :: v_dual_add_nc_u32 v63, 0x3200, v67// 0000000EEAB0: C820433D 443E86FF 00003200
	ds_load_2addr_b32 v[63:64], v63 offset0:8 offset1:137      // 0000000EEABC: D8DC8908 3F00003F
	v_dual_fmac_f32 v68, v62, v34 :: v_dual_add_nc_u32 v65, 0x3600, v67// 0000000EEAC4: C820453E 444086FF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:10 offset1:139     // 0000000EEAD0: D8DC8B0A 41000041
	s_waitcnt lgkmcnt(1)                                       // 0000000EEAD8: BF89FC17
	v_fmac_f32_e32 v68, v63, v35                               // 0000000EEADC: 5688473F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EEAE0: BF870001
	v_dual_fmac_f32 v68, v64, v36 :: v_dual_add_nc_u32 v61, 0x3a00, v67// 0000000EEAE4: C8204940 443C86FF 00003A00
	ds_load_2addr_b32 v[61:62], v61 offset0:12 offset1:141     // 0000000EEAF0: D8DC8D0C 3D00003D
	s_waitcnt lgkmcnt(1)                                       // 0000000EEAF8: BF89FC17
	v_dual_fmac_f32 v68, v65, v37 :: v_dual_add_nc_u32 v63, 0x3e00, v67// 0000000EEAFC: C8204B41 443E86FF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:14 offset1:143     // 0000000EEB08: D8DC8F0E 3F00003F
	v_fmac_f32_e32 v68, v66, v38                               // 0000000EEB10: 56884D42
	s_waitcnt lgkmcnt(1)                                       // 0000000EEB14: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEB18: BF870091
	v_fmac_f32_e32 v68, v61, v39                               // 0000000EEB1C: 56884F3D
	v_dual_fmac_f32 v68, v62, v40 :: v_dual_add_nc_u32 v61, 0x80, v3// 0000000EEB20: C820513E 443C06FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 0000000EEB2C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEB30: BF870091
	v_dual_mov_b32 v3, v61 :: v_dual_fmac_f32 v68, v63, v41    // 0000000EEB34: CA00013D 0344533F
	v_fmac_f32_e32 v68, v64, v42                               // 0000000EEB3C: 56885540
	ds_store_b32 v60, v68                                      // 0000000EEB40: D8340000 0000443C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EEB48: 917E047E
	s_cbranch_execnz 65456                                     // 0000000EEB4C: BFA6FFB0 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2310>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EEB50: 8C7E047E
	v_dual_mov_b32 v28, v24 :: v_dual_mov_b32 v27, v23         // 0000000EEB54: CA100118 1C1A0117
	v_dual_mov_b32 v3, v44 :: v_dual_mov_b32 v30, v43          // 0000000EEB5C: CA10012C 031E012B
	v_mov_b32_e32 v29, 0                                       // 0000000EEB64: 7E3A0280
	s_mov_b32 s7, 0                                            // 0000000EEB68: BE870080
	s_waitcnt lgkmcnt(0)                                       // 0000000EEB6C: BF89FC07
	s_barrier                                                  // 0000000EEB70: BFBD0000
	buffer_gl0_inv                                             // 0000000EEB74: E0AC0000 00000000
	s_nop 0                                                    // 0000000EEB7C: BF800000
	global_load_b32 v31, v[27:28], off                         // 0000000EEB80: DC520000 1F7C001B
	ds_load_b32 v32, v29 offset:21440                          // 0000000EEB88: D8D853C0 2000001D
	v_add_nc_u32_e32 v30, 0x80, v30                            // 0000000EEB90: 4A3C3CFF 00000080
	.long 0xd700011b                                           // 0000000EEB98: D700011B
	v_cndmask_b32_e32 v1, 0x6000, v27, vcc_lo                  // 0000000EEB9C: 020236FF 00006000
	v_add_nc_u32_e32 v29, 4, v29                               // 0000000EEBA4: 4A3A3A84
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000EEBA8: D5207C1C 00063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EEBB0: BF890007
	v_mul_f32_e32 v31, v31, v32                                // 0000000EEBB4: 103E411F
	.long 0xd4490004                                           // 0000000EEBB8: D4490004
	v_cndmask_b32_e32 v1, 0x77f, v30, vcc_lo                   // 0000000EEBBC: 02023CFF 0000077F
	ds_store_b32 v3, v31 offset:8704                           // 0000000EEBC4: D8342200 00001F03
	v_add_nc_u32_e32 v3, 0x204, v3                             // 0000000EEBCC: 4A0606FF 00000204
	s_or_b32 s7, s4, s7                                        // 0000000EEBD4: 8C070704
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EEBD8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000000EEBDC: 917E077E
	s_cbranch_execnz 65511                                     // 0000000EEBE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2480>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000EEBE4: 8C7E077E
	v_dual_mov_b32 v60, v0 :: v_dual_add_nc_u32 v39, 0x800, v8 // 0000000EEBE8: CA200100 3C2610FF 00000800
	v_add_nc_u32_e32 v3, 0xc00, v8                             // 0000000EEBF4: 4A0610FF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000EEBFC: BF89FC07
	s_barrier                                                  // 0000000EEC00: BFBD0000
	buffer_gl0_inv                                             // 0000000EEC04: E0AC0000 00000000
	ds_load_2addr_b32 v[27:28], v39 offset0:32 offset1:49      // 0000000EEC0C: D8DC3120 1B000027
	ds_load_2addr_b32 v[29:30], v39 offset0:66 offset1:83      // 0000000EEC14: D8DC5342 1D000027
	ds_load_2addr_b32 v[31:32], v39 offset0:100 offset1:117    // 0000000EEC1C: D8DC7564 1F000027
	ds_load_2addr_b32 v[33:34], v39 offset0:134 offset1:151    // 0000000EEC24: D8DC9786 21000027
	ds_load_2addr_b32 v[35:36], v39 offset0:168 offset1:185    // 0000000EEC2C: D8DCB9A8 23000027
	ds_load_2addr_b32 v[37:38], v39 offset0:202 offset1:219    // 0000000EEC34: D8DCDBCA 25000027
	ds_load_2addr_b32 v[39:40], v39 offset0:236 offset1:253    // 0000000EEC3C: D8DCFDEC 27000027
	ds_load_2addr_b32 v[41:42], v3 offset0:14 offset1:31       // 0000000EEC44: D8DC1F0E 29000003
	s_mov_b32 s4, 0                                            // 0000000EEC4C: BE840080
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000EEC50: 327A7884
	.long 0xd4490001                                           // 0000000EEC54: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000EEC58: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000EEC60: BF870002
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000EEC64: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000EEC68: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000EEC74: 8C040401
	v_add_nc_u32_e32 v62, 0x2200, v68                          // 0000000EEC78: 4A7C88FF 00002200
	ds_load_b32 v69, v61                                       // 0000000EEC80: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset1:129                // 0000000EEC88: D8DC8100 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 0000000EEC90: BF89FC07
	v_dual_fmac_f32 v69, v62, v27 :: v_dual_add_nc_u32 v64, 0x2600, v68// 0000000EEC94: C820373E 454088FF 00002600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000EECA0: BF8700C1
	v_fmac_f32_e32 v69, v63, v28                               // 0000000EECA4: 568A393F
	ds_load_2addr_b32 v[64:65], v64 offset0:2 offset1:131      // 0000000EECA8: D8DC8302 40000040
	s_waitcnt lgkmcnt(0)                                       // 0000000EECB0: BF89FC07
	v_fmac_f32_e32 v69, v64, v29                               // 0000000EECB4: 568A3B40
	v_dual_fmac_f32 v69, v65, v30 :: v_dual_add_nc_u32 v62, 0x2e00, v68// 0000000EECB8: C8203D41 453E88FF 00002E00
	ds_load_2addr_b32 v[62:63], v62 offset0:6 offset1:135      // 0000000EECC4: D8DC8706 3E00003E
	v_add_nc_u32_e32 v66, 0x2a00, v68                          // 0000000EECCC: 4A8488FF 00002A00
	ds_load_2addr_b32 v[66:67], v66 offset0:4 offset1:133      // 0000000EECD4: D8DC8504 42000042
	s_waitcnt lgkmcnt(0)                                       // 0000000EECDC: BF89FC07
	v_fmac_f32_e32 v69, v66, v31                               // 0000000EECE0: 568A3F42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EECE4: BF870091
	v_fmac_f32_e32 v69, v67, v32                               // 0000000EECE8: 568A4143
	v_dual_fmac_f32 v69, v62, v33 :: v_dual_add_nc_u32 v64, 0x3200, v68// 0000000EECEC: C820433E 454088FF 00003200
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EECF8: BF870001
	v_fmac_f32_e32 v69, v63, v34                               // 0000000EECFC: 568A453F
	ds_load_2addr_b32 v[64:65], v64 offset0:8 offset1:137      // 0000000EED00: D8DC8908 40000040
	s_waitcnt lgkmcnt(0)                                       // 0000000EED08: BF89FC07
	v_dual_fmac_f32 v69, v64, v35 :: v_dual_add_nc_u32 v66, 0x3600, v68// 0000000EED0C: C8204740 454288FF 00003600
	ds_load_2addr_b32 v[66:67], v66 offset0:10 offset1:139     // 0000000EED18: D8DC8B0A 42000042
	v_fmac_f32_e32 v69, v65, v36                               // 0000000EED20: 568A4941
	s_waitcnt lgkmcnt(0)                                       // 0000000EED24: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EED28: BF870001
	v_dual_fmac_f32 v69, v66, v37 :: v_dual_add_nc_u32 v62, 0x3a00, v68// 0000000EED2C: C8204B42 453E88FF 00003A00
	ds_load_2addr_b32 v[62:63], v62 offset0:12 offset1:141     // 0000000EED38: D8DC8D0C 3E00003E
	v_dual_fmac_f32 v69, v67, v38 :: v_dual_add_nc_u32 v64, 0x3e00, v68// 0000000EED40: C8204D43 454088FF 00003E00
	ds_load_2addr_b32 v[64:65], v64 offset0:14 offset1:143     // 0000000EED4C: D8DC8F0E 40000040
	s_waitcnt lgkmcnt(1)                                       // 0000000EED54: BF89FC17
	v_dual_fmac_f32 v69, v62, v39 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000EED58: C8204F3E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EED64: BF8700A1
	v_dual_fmac_f32 v69, v63, v40 :: v_dual_mov_b32 v60, v62   // 0000000EED68: C810513F 453C013E
	s_waitcnt lgkmcnt(0)                                       // 0000000EED70: BF89FC07
	v_fmac_f32_e32 v69, v64, v41                               // 0000000EED74: 568A5340
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EED78: BF870001
	v_fmac_f32_e32 v69, v65, v42                               // 0000000EED7C: 568A5541
	ds_store_b32 v61, v69                                      // 0000000EED80: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EED88: 917E047E
	s_cbranch_execnz 65456                                     // 0000000EED8C: BFA6FFB0 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2550>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EED90: 8C7E047E
	v_dual_mov_b32 v28, v26 :: v_dual_mov_b32 v27, v25         // 0000000EED94: CA10011A 1C1A0119
	v_dual_mov_b32 v29, v44 :: v_dual_mov_b32 v30, 0           // 0000000EED9C: CA10012C 1D1E0080
	v_mov_b32_e32 v31, v43                                     // 0000000EEDA4: 7E3E032B
	s_mov_b32 s7, 0                                            // 0000000EEDA8: BE870080
	s_waitcnt lgkmcnt(0)                                       // 0000000EEDAC: BF89FC07
	s_barrier                                                  // 0000000EEDB0: BFBD0000
	buffer_gl0_inv                                             // 0000000EEDB4: E0AC0000 00000000
	s_nop 0                                                    // 0000000EEDBC: BF800000
	global_load_b32 v32, v[27:28], off                         // 0000000EEDC0: DC520000 207C001B
	ds_load_b32 v33, v30 offset:21504                          // 0000000EEDC8: D8D85400 2100001E
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000EEDD0: 4A3E3EFF 00000080
	.long 0xd700011b                                           // 0000000EEDD8: D700011B
	v_cndmask_b32_e32 v1, 0x6000, v27, vcc_lo                  // 0000000EEDDC: 020236FF 00006000
	v_add_nc_u32_e32 v30, 4, v30                               // 0000000EEDE4: 4A3C3C84
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000EEDE8: D5207C1C 00063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000EEDF0: BF890007
	v_mul_f32_e32 v32, v32, v33                                // 0000000EEDF4: 10404320
	.long 0xd4490004                                           // 0000000EEDF8: D4490004
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000EEDFC: 02023EFF 0000077F
	ds_store_b32 v29, v32 offset:8704                          // 0000000EEE04: D8342200 0000201D
	v_add_nc_u32_e32 v29, 0x204, v29                           // 0000000EEE0C: 4A3A3AFF 00000204
	s_or_b32 s7, s4, s7                                        // 0000000EEE14: 8C070704
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000EEE18: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000000EEE1C: 917E077E
	s_cbranch_execnz 65511                                     // 0000000EEE20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26c0>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000EEE24: 8C7E077E
	v_add_nc_u32_e32 v39, 0xe00, v8                            // 0000000EEE28: 4A4E10FF 00000E00
	v_add_nc_u32_e32 v41, 0x1000, v8                           // 0000000EEE30: 4A5210FF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000EEE38: BF89FC07
	s_barrier                                                  // 0000000EEE3C: BFBD0000
	buffer_gl0_inv                                             // 0000000EEE40: E0AC0000 00000000
	ds_load_2addr_b32 v[33:34], v3 offset0:150 offset1:167     // 0000000EEE48: D8DCA796 21000003
	ds_load_2addr_b32 v[35:36], v3 offset0:184 offset1:201     // 0000000EEE50: D8DCC9B8 23000003
	ds_load_2addr_b32 v[37:38], v3 offset0:218 offset1:235     // 0000000EEE58: D8DCEBDA 25000003
	ds_load_2addr_b32 v[39:40], v39 offset0:124 offset1:141    // 0000000EEE60: D8DC8D7C 27000027
	ds_load_2addr_b32 v[41:42], v41 offset0:30 offset1:47      // 0000000EEE68: D8DC2F1E 29000029
	ds_load_2addr_b32 v[27:28], v3 offset0:48 offset1:65       // 0000000EEE70: D8DC4130 1B000003
	ds_load_2addr_b32 v[29:30], v3 offset0:82 offset1:99       // 0000000EEE78: D8DC6352 1D000003
	ds_load_2addr_b32 v[31:32], v3 offset0:116 offset1:133     // 0000000EEE80: D8DC8574 1F000003
	v_mov_b32_e32 v3, v0                                       // 0000000EEE88: 7E060300
	s_mov_b32 s4, 0                                            // 0000000EEE8C: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000EEE90: BF870121
	v_lshrrev_b32_e32 v60, 4, v3                               // 0000000EEE94: 32780684
	.long 0xd4490001                                           // 0000000EEE98: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000EEE9C: 020206FF 0000077F
	v_lshlrev_b32_e32 v67, 2, v60                              // 0000000EEEA4: 30867882
	v_mad_u64_u32 v[60:61], null, 0x44, v60, v[1:2]            // 0000000EEEA8: D6FE7C3C 040678FF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000EEEB4: 8C040401
	v_add_nc_u32_e32 v61, 0x2200, v67                          // 0000000EEEB8: 4A7A86FF 00002200
	ds_load_b32 v68, v60                                       // 0000000EEEC0: D8D80000 4400003C
	ds_load_2addr_b32 v[61:62], v61 offset1:129                // 0000000EEEC8: D8DC8100 3D00003D
	s_waitcnt lgkmcnt(0)                                       // 0000000EEED0: BF89FC07
	v_fmac_f32_e32 v68, v61, v27                               // 0000000EEED4: 5688373D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EEED8: BF870001
	v_dual_fmac_f32 v68, v62, v28 :: v_dual_add_nc_u32 v63, 0x2600, v67// 0000000EEEDC: C820393E 443E86FF 00002600
	ds_load_2addr_b32 v[63:64], v63 offset0:2 offset1:131      // 0000000EEEE8: D8DC8302 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000EEEF0: BF89FC07
	v_dual_fmac_f32 v68, v63, v29 :: v_dual_add_nc_u32 v65, 0x2a00, v67// 0000000EEEF4: C8203B3F 444086FF 00002A00
	ds_load_2addr_b32 v[65:66], v65 offset0:4 offset1:133      // 0000000EEF00: D8DC8504 41000041
	v_fmac_f32_e32 v68, v64, v30                               // 0000000EEF08: 56883D40
	s_waitcnt lgkmcnt(0)                                       // 0000000EEF0C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEF10: BF870091
	v_fmac_f32_e32 v68, v65, v31                               // 0000000EEF14: 56883F41
	v_dual_fmac_f32 v68, v66, v32 :: v_dual_add_nc_u32 v61, 0x2e00, v67// 0000000EEF18: C8204142 443C86FF 00002E00
	ds_load_2addr_b32 v[61:62], v61 offset0:6 offset1:135      // 0000000EEF24: D8DC8706 3D00003D
	s_waitcnt lgkmcnt(0)                                       // 0000000EEF2C: BF89FC07
	v_dual_fmac_f32 v68, v61, v33 :: v_dual_add_nc_u32 v63, 0x3200, v67// 0000000EEF30: C820433D 443E86FF 00003200
	ds_load_2addr_b32 v[63:64], v63 offset0:8 offset1:137      // 0000000EEF3C: D8DC8908 3F00003F
	v_dual_fmac_f32 v68, v62, v34 :: v_dual_add_nc_u32 v65, 0x3600, v67// 0000000EEF44: C820453E 444086FF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:10 offset1:139     // 0000000EEF50: D8DC8B0A 41000041
	s_waitcnt lgkmcnt(1)                                       // 0000000EEF58: BF89FC17
	v_fmac_f32_e32 v68, v63, v35                               // 0000000EEF5C: 5688473F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EEF60: BF870001
	v_dual_fmac_f32 v68, v64, v36 :: v_dual_add_nc_u32 v61, 0x3a00, v67// 0000000EEF64: C8204940 443C86FF 00003A00
	ds_load_2addr_b32 v[61:62], v61 offset0:12 offset1:141     // 0000000EEF70: D8DC8D0C 3D00003D
	s_waitcnt lgkmcnt(1)                                       // 0000000EEF78: BF89FC17
	v_dual_fmac_f32 v68, v65, v37 :: v_dual_add_nc_u32 v63, 0x3e00, v67// 0000000EEF7C: C8204B41 443E86FF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:14 offset1:143     // 0000000EEF88: D8DC8F0E 3F00003F
	v_fmac_f32_e32 v68, v66, v38                               // 0000000EEF90: 56884D42
	s_waitcnt lgkmcnt(1)                                       // 0000000EEF94: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEF98: BF870091
	v_fmac_f32_e32 v68, v61, v39                               // 0000000EEF9C: 56884F3D
	v_dual_fmac_f32 v68, v62, v40 :: v_dual_add_nc_u32 v61, 0x80, v3// 0000000EEFA0: C820513E 443C06FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 0000000EEFAC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000EEFB0: BF870091
	v_dual_mov_b32 v3, v61 :: v_dual_fmac_f32 v68, v63, v41    // 0000000EEFB4: CA00013D 0344533F
	v_fmac_f32_e32 v68, v64, v42                               // 0000000EEFBC: 56885540
	ds_store_b32 v60, v68                                      // 0000000EEFC0: D8340000 0000443C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000EEFC8: 917E047E
	s_cbranch_execnz 65456                                     // 0000000EEFCC: BFA6FFB0 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2790>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000EEFD0: 8C7E047E
	.long 0xd700010b                                           // 0000000EEFD4: D700010B
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000EEFD8: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EEFE0: BF8700A1
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000EEFE4: D5207C0C 00061880
	.long 0xd700010d                                           // 0000000EEFEC: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000EEFF0: 02021AFF 000C0000
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000EEFF8: D5207C0E 00061C80
	.long 0xd700010f                                           // 0000000EF000: D700010F
	v_cndmask_b32_e32 v1, 0xc0000, v15, vcc_lo                 // 0000000EF004: 02021EFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EF00C: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000EF010: D5207C10 00062080
	.long 0xd7000113                                           // 0000000EF018: D7000113
	v_cndmask_b32_e32 v1, 0xc0000, v19, vcc_lo                 // 0000000EF01C: 020226FF 000C0000
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000EF024: D5207C14 00062880
	.long 0xd7000111                                           // 0000000EF02C: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000EF030: 020222FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EF038: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000EF03C: D5207C12 00062480
	.long 0xd7000115                                           // 0000000EF044: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000EF048: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000EF050: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000EF058: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000EF05C: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000EF064: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000EF068: D5207C18 00063080
	.long 0xd7000119                                           // 0000000EF070: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000EF074: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000EF07C: D5207C1A 00063480
	s_add_i32 s6, s6, 1                                        // 0000000EF084: 81068106
	s_waitcnt lgkmcnt(0)                                       // 0000000EF088: BF89FC07
	s_cmp_eq_u32 s6, s33                                       // 0000000EF08C: BF062106
	s_barrier                                                  // 0000000EF090: BFBD0000
	buffer_gl0_inv                                             // 0000000EF094: E0AC0000 00000000
	s_cbranch_scc0 63079                                       // 0000000EF09C: BFA1F667 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33c>
	v_mov_b32_e32 v7, v43                                      // 0000000EF0A0: 7E0E032B
	v_mov_b32_e32 v3, v2                                       // 0000000EF0A4: 7E060302
	s_add_u32 s0, s28, s20                                     // 0000000EF0A8: 8000141C
	.long 0xd73c0000                                           // 0000000EF0AC: D73C0000
	v_cndmask_b32_e32 v1, 9, v5, vcc_lo                        // 0000000EF0B0: 02020A89
	s_addc_u32 s1, s29, s21                                    // 0000000EF0B4: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000EF0B8: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000EF0BC: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000EF0C0: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000EF0C4: 82010103
	.long 0xd7006a00                                           // 0000000EF0C8: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000EF0CC: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000EF0D0: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000EF0D4: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000EF0DC: BE810080
	.long 0xd7006a02                                           // 0000000EF0E0: D7006A02
	v_cndmask_b32_e32 v1, v0, v4, vcc_lo                       // 0000000EF0E4: 02020900
	v_add_co_ci_u32_e64 v5, null, 0, v1, vcc_lo                // 0000000EF0E8: D5207C05 01AA0280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000EF0F0: BF870191
	v_mad_u64_u32 v[0:1], null, 0x44, v3, v[4:5]               // 0000000EF0F4: D6FE7C00 041206FF 00000044
	.long 0xd7006a01                                           // 0000000EF100: D7006A01
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 0000000EF104: 02020410
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000EF108: BF870001
	v_add_co_ci_u32_e64 v2, null, s17, v5, vcc_lo              // 0000000EF10C: D5207C02 01AA0A11
	s_nop 0                                                    // 0000000EF114: BF800000
	s_nop 0                                                    // 0000000EF118: BF800000
	s_nop 0                                                    // 0000000EF11C: BF800000
	s_nop 0                                                    // 0000000EF120: BF800000
	s_nop 0                                                    // 0000000EF124: BF800000
	s_nop 0                                                    // 0000000EF128: BF800000
	s_nop 0                                                    // 0000000EF12C: BF800000
	s_nop 0                                                    // 0000000EF130: BF800000
	s_nop 0                                                    // 0000000EF134: BF800000
	s_nop 0                                                    // 0000000EF138: BF800000
	s_nop 0                                                    // 0000000EF13C: BF800000
	ds_load_b32 v3, v0                                         // 0000000EF140: D8D80000 03000000
	v_add_nc_u32_e32 v7, 0x80, v7                              // 0000000EF148: 4A0E0EFF 00000080
	v_add_nc_u32_e32 v0, 0x220, v0                             // 0000000EF150: 4A0000FF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000EF158: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v7                         // 0000000EF15C: 7C920EFF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000EF164: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000EF168: BF89FC07
	global_store_b32 v[1:2], v3, off                           // 0000000EF16C: DC6A0000 007C0301
	.long 0xd7000001                                           // 0000000EF174: D7000001
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 0000000EF178: 020202FF 00001000
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000000EF180: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000EF188: 917E017E
	s_cbranch_execnz 65516                                     // 0000000EF18C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a40>
	s_endpgm                                                   // 0000000EF190: BFB00000
		...

