00000000000b8200 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 0000000B8200: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 0000000B8204: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 0000000B820C: F4080500 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 0000000B8214: 3706009F
	v_lshrrev_b32_e32 v157, 5, v0                              // 0000000B8218: 333A0085
	s_mov_b32 s24, s3                                          // 0000000B821C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B8220: BF870112
	.long 0xd44c0003                                           // 0000000B8224: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 0000000B8228: 02030690
	v_lshlrev_b32_e32 v132, 6, v157                            // 0000000B822C: 31093A86
	s_waitcnt lgkmcnt(0)                                       // 0000000B8230: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 0000000B8234: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 0000000B823C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B8240: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 0000000B8244: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 0000000B824C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:156 offset1:162// 0000000B8258: D83CA29C 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B8260: 8C7E047E
	v_mul_u32_u24_e32 v1, 0xab, v0                             // 0000000B8264: 160200FF 000000AB
	.long 0x7f043880                                           // 0000000B826C: 7F043880
	v_dual_mov_b32 v142, 0 :: v_dual_and_b32 v155, 15, v0      // 0000000B8270: CA240080 8E9A008F
	s_cmp_eq_u64 s[14:15], 0                                   // 0000000B8278: BF10800E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000B827C: BF8704B3
	.long 0x7e043981                                           // 0000000B8280: 7E043981
	v_mov_b32_e32 v141, 0                                      // 0000000B8284: 7F1A0280
	s_cselect_b32 s25, -1, 0                                   // 0000000B8288: 981980C1
	s_and_b32 vcc_lo, exec_lo, s25                             // 0000000B828C: 8B6A197E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8290: BF870092
	v_add_lshl_u32 v156, s2, v2, 4                             // 0000000B8294: D647009C 02120402
	v_or_b32_e32 v129, v156, v155                              // 0000000B829C: 3903379C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B82A0: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000B82A4: 3505029F
	s_cbranch_vccnz 10                                         // 0000000B82A8: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xd4>
	v_mad_i64_i32 v[1:2], null, s23, v129, 0                   // 0000000B82AC: D6FF7C01 02030217
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B82B4: BF870091
	.long 0xd73c0001                                           // 0000000B82B8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000000B82BC: 02020282
	.long 0xd7006a8d                                           // 0000000B82C0: D7006A8D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000000B82C4: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B82C8: BF870001
	v_add_co_ci_u32_e64 v142, null, s15, v2, vcc_lo            // 0000000B82CC: D5207C8E 01AA040F
	s_clause 0x2                                               // 0000000B82D4: BF850002
	s_load_b64 s[14:15], s[0:1], 0x38                          // 0000000B82D8: F4040380 F8000038
	s_load_b128 s[16:19], s[0:1], 0x20                         // 0000000B82E0: F4080400 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000000B82E8: F40C0100 F8000000
	v_mov_b32_e32 v159, 0                                      // 0000000B82F0: 7F3E0280
	s_xor_b32 s0, s25, -1                                      // 0000000B82F4: 8D00C119
	s_waitcnt lgkmcnt(0)                                       // 0000000B82F8: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v129                         // 0000000B82FC: 7C89020E
	s_and_b32 s23, s0, vcc_lo                                  // 0000000B8300: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B8304: BF870009
	s_and_saveexec_b32 s0, s23                                 // 0000000B8308: BE802017
	s_cbranch_execz 9                                          // 0000000B830C: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x134>
	.long 0xd73c0001                                           // 0000000B8310: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 0000000B8314: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8318: BF870091
	.long 0xd7006a01                                           // 0000000B831C: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 0000000B8320: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 0000000B8324: D5207C02 01AA0415
	global_load_b32 v159, v[1:2], off                          // 0000000B832C: DC520000 9F7C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000B8334: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 0000000B8338: BF10800C
	s_mov_b64 s[20:21], 0                                      // 0000000B833C: BE940180
	s_cbranch_scc1 10                                          // 0000000B8340: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c>
	s_ashr_i32 s0, s22, 31                                     // 0000000B8344: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 0000000B8348: 96810216
	s_mul_i32 s0, s0, s2                                       // 0000000B834C: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000B8350: BF8704A9
	s_add_i32 s1, s1, s0                                       // 0000000B8354: 81010001
	s_mul_i32 s0, s22, s2                                      // 0000000B8358: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000000B835C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B8360: BF870009
	s_add_u32 s20, s12, s0                                     // 0000000B8364: 8014000C
	s_addc_u32 s21, s13, s1                                    // 0000000B8368: 8215010D
	.long 0xd7050001                                           // 0000000B836C: D7050001
	v_cndmask_b32_e32 v0, v157, v150, vcc_lo                   // 0000000B8370: 02012D9D
	s_lshl_b32 s0, s2, 4                                       // 0000000B8374: 84008402
	s_add_i32 s1, s14, -1                                      // 0000000B8378: 8101C10E
	s_or_b32 s0, s0, 15                                        // 0000000B837C: 8C008F00
	v_lshrrev_b32_e32 v158, 4, v131                            // 0000000B8380: 333D0684
	.long 0xd7390001                                           // 0000000B8384: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000000B8388: 02020288
	s_min_i32 s0, s0, s1                                       // 0000000B838C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000B8390: BF870499
	s_add_i32 s0, s26, s0                                      // 0000000B8394: 8100001A
	s_cmp_lt_i32 s0, -15                                       // 0000000B8398: BF04CF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B839C: BF870091
	.long 0xd7050001                                           // 0000000B83A0: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 0000000B83A4: 02011901
	.long 0xd7040001                                           // 0000000B83A8: D7040001
	v_cndmask_b32_e32 v1, v157, v1, vcc_lo                     // 0000000B83AC: 0202039D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B83B0: BF870091
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 0000000B83B4: CA240080 480002FF 000000FF
	v_mov_b32_e32 v71, v72                                     // 0000000B83C0: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 0000000B83C4: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 0000000B83C8: 7E880348
	v_mov_b32_e32 v67, v72                                     // 0000000B83CC: 7E860348
	v_mad_u64_u32 v[138:139], null, s24, 12, v[1:2]            // 0000000B83D0: D6FE7C8A 04051818
	v_mov_b32_e32 v70, v72                                     // 0000000B83D8: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 0000000B83DC: 7E840348
	v_mov_b32_e32 v65, v72                                     // 0000000B83E0: 7E820348
	v_mov_b32_e32 v80, v72                                     // 0000000B83E4: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 0000000B83E8: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 0000000B83EC: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 0000000B83F0: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 0000000B83F4: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 0000000B83FC: 7E960348
	v_mov_b32_e32 v74, v72                                     // 0000000B8400: 7E940348
	v_mov_b32_e32 v73, v72                                     // 0000000B8404: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B8408: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000000B840C: 3404029F
	v_mov_b32_e32 v88, v72                                     // 0000000B8410: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 0000000B8414: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 0000000B8418: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 0000000B841C: 7EAA0348
	.long 0xd73c008b                                           // 0000000B8420: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000000B8424: 02020281
	v_mov_b32_e32 v84, v72                                     // 0000000B8428: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 0000000B842C: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 0000000B8430: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 0000000B8434: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 0000000B8438: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 0000000B843C: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 0000000B8440: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 0000000B8444: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 0000000B8448: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 0000000B844C: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 0000000B8450: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 0000000B8454: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 0000000B8458: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 0000000B845C: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 0000000B8460: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 0000000B8464: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 0000000B8468: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 0000000B846C: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 0000000B8470: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 0000000B8474: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 0000000B8478: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 0000000B847C: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 0000000B8480: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 0000000B8484: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 0000000B8488: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 0000000B848C: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 0000000B8490: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 0000000B8494: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 0000000B8498: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 0000000B849C: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 0000000B84A0: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 0000000B84A4: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 0000000B84A8: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 0000000B84AC: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 0000000B84B0: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 0000000B84B4: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 0000000B84B8: 7F000348
	v_mov_b32_e32 v127, v72                                    // 0000000B84BC: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 0000000B84C0: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 0000000B84C4: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 0000000B84C8: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 0000000B84CC: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 0000000B84D0: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 0000000B84D4: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 0000000B84D8: 7E800348
	v_mov_b32_e32 v63, v72                                     // 0000000B84DC: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 0000000B84E0: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 0000000B84E4: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 0000000B84E8: 7E780348
	v_mov_b32_e32 v59, v72                                     // 0000000B84EC: 7E760348
	v_mov_b32_e32 v58, v72                                     // 0000000B84F0: 7E740348
	v_mov_b32_e32 v57, v72                                     // 0000000B84F4: 7E720348
	v_mov_b32_e32 v56, v72                                     // 0000000B84F8: 7E700348
	v_mov_b32_e32 v55, v72                                     // 0000000B84FC: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 0000000B8500: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 0000000B8504: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 0000000B8508: 7E680348
	v_mov_b32_e32 v51, v72                                     // 0000000B850C: 7E660348
	v_mov_b32_e32 v50, v72                                     // 0000000B8510: 7E640348
	v_mov_b32_e32 v49, v72                                     // 0000000B8514: 7E620348
	v_mov_b32_e32 v48, v72                                     // 0000000B8518: 7E600348
	v_mov_b32_e32 v47, v72                                     // 0000000B851C: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 0000000B8520: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 0000000B8524: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 0000000B8528: 7E580348
	v_mov_b32_e32 v43, v72                                     // 0000000B852C: 7E560348
	v_mov_b32_e32 v42, v72                                     // 0000000B8530: 7E540348
	v_mov_b32_e32 v41, v72                                     // 0000000B8534: 7E520348
	v_mov_b32_e32 v40, v72                                     // 0000000B8538: 7E500348
	v_mov_b32_e32 v39, v72                                     // 0000000B853C: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 0000000B8540: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 0000000B8544: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 0000000B8548: 7E480348
	v_mov_b32_e32 v35, v72                                     // 0000000B854C: 7E460348
	v_mov_b32_e32 v34, v72                                     // 0000000B8550: 7E440348
	v_mov_b32_e32 v33, v72                                     // 0000000B8554: 7E420348
	v_mov_b32_e32 v32, v72                                     // 0000000B8558: 7E400348
	v_mov_b32_e32 v31, v72                                     // 0000000B855C: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 0000000B8560: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 0000000B8564: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 0000000B8568: 7E380348
	v_mov_b32_e32 v27, v72                                     // 0000000B856C: 7E360348
	v_mov_b32_e32 v26, v72                                     // 0000000B8570: 7E340348
	v_mov_b32_e32 v25, v72                                     // 0000000B8574: 7E320348
	v_mov_b32_e32 v24, v72                                     // 0000000B8578: 7E300348
	v_mov_b32_e32 v23, v72                                     // 0000000B857C: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 0000000B8580: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 0000000B8584: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 0000000B8588: 7E280348
	v_mov_b32_e32 v19, v72                                     // 0000000B858C: 7E260348
	v_mov_b32_e32 v18, v72                                     // 0000000B8590: 7E240348
	v_mov_b32_e32 v17, v72                                     // 0000000B8594: 7E220348
	v_mov_b32_e32 v16, v72                                     // 0000000B8598: 7E200348
	v_mov_b32_e32 v15, v72                                     // 0000000B859C: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 0000000B85A0: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 0000000B85A4: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 0000000B85A8: 7E180348
	v_mov_b32_e32 v11, v72                                     // 0000000B85AC: 7E160348
	v_mov_b32_e32 v10, v72                                     // 0000000B85B0: 7E140348
	v_mov_b32_e32 v9, v72                                      // 0000000B85B4: 7E120348
	v_mov_b32_e32 v8, v72                                      // 0000000B85B8: 7E100348
	v_mov_b32_e32 v7, v72                                      // 0000000B85BC: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 0000000B85C0: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 0000000B85C4: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 0000000B85C8: 7E080348
	v_mov_b32_e32 v3, v72                                      // 0000000B85CC: 7E060348
	v_mov_b32_e32 v2, v72                                      // 0000000B85D0: 7E040348
	v_mov_b32_e32 v1, v72                                      // 0000000B85D4: 7E020348
	s_cbranch_scc1 2257                                        // 0000000B85D8: BFA208D1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2720>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[4:5]           // 0000000B85DC: D6FF7C01 001302FF 00003000
	s_ashr_i32 s1, s0, 31                                      // 0000000B85E8: 86019F00
	v_add3_u32 v163, v156, v131, s26                           // 0000000B85EC: D65500A3 006B079C
	s_lshr_b32 s1, s1, 28                                      // 0000000B85F4: 85019C01
	v_mad_u32_u24 v171, v155, 48, 0x4b00                       // 0000000B85F8: D60B00AB 03FD619B 00004B00
	s_add_i32 s0, s0, s1                                       // 0000000B8604: 81000100
	s_movk_i32 s1, 0x440                                       // 0000000B8608: B0010440
	s_ashr_i32 s5, s0, 4                                       // 0000000B860C: 86058400
	.long 0xd7006a8f                                           // 0000000B8610: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 0000000B8614: 02031701
	v_add3_u32 v1, v129, s26, 1                                // 0000000B8618: D6550001 02043581
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 0000000B8620: D5207C90 01AB1902
	v_mad_u32_u24 v3, v157, s1, 0x1800                         // 0000000B8628: D60B0003 03FC039D 00001800
	s_cmp_eq_u64 s[20:21], 0                                   // 0000000B8634: BF108014
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000B8638: BF870003
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000000B863C: 3404029F
	v_mov_b32_e32 v129, 0                                      // 0000000B8640: 7F020280
	v_lshlrev_b32_e32 v5, 2, v131                              // 0000000B8644: 300B0682
	v_mad_u32_u24 v4, 0x44, v158, v3                           // 0000000B8648: D60B0004 040F3CFF 00000044
	s_cselect_b32 s12, -1, 0                                   // 0000000B8654: 980C80C1
	v_lshrrev_b32_e32 v2, 30, v2                               // 0000000B8658: 3204049E
	s_cmp_lg_u64 s[20:21], 0                                   // 0000000B865C: BF118014
	v_add_nc_u32_e32 v6, 0x9f00, v132                          // 0000000B8660: 4A0D08FF 00009F00
	v_lshl_add_u32 v161, v155, 2, v4                           // 0000000B8668: D64600A1 0411059B
	v_lshlrev_b32_e32 v4, 9, v157                              // 0000000B8670: 30093A89
	v_dual_mov_b32 v146, 0 :: v_dual_add_nc_u32 v1, v1, v2     // 0000000B8674: CA200080 92000501
	v_add_nc_u32_e32 v2, v5, v132                              // 0000000B867C: 4A050905
	s_cselect_b32 s13, -1, 0                                   // 0000000B8680: 980D80C1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B8684: BF870193
	v_lshl_add_u32 v166, v131, 5, v4                           // 0000000B8688: D64600A6 04110B83
	v_ashrrev_i32_e32 v162, 2, v1                              // 0000000B8690: 35440282
	v_lshlrev_b32_e32 v1, 3, v0                                // 0000000B8694: 30020083
	v_lshl_or_b32 v170, v155, 5, v4                            // 0000000B8698: D65600AA 04110B9B
	v_mov_b32_e32 v4, v129                                     // 0000000B86A0: 7E080381
	s_ashr_i32 s25, s24, 31                                    // 0000000B86A4: 86199F18
	v_add_nc_u32_e32 v164, 0x9c00, v2                          // 0000000B86A8: 4B4804FF 00009C00
	v_and_b32_e32 v1, 0xf8, v1                                 // 0000000B86B0: 360202FF 000000F8
	v_dual_mov_b32 v8, v129 :: v_dual_add_nc_u32 v167, 0xa200, v2// 0000000B86B8: CA200181 08A604FF 0000A200
	s_lshl_b64 s[24:25], s[24:25], 9                           // 0000000B86C4: 84988918
	s_add_i32 s15, s15, -1                                     // 0000000B86C8: 810FC10F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B86CC: BF8700C2
	v_dual_mov_b32 v9, 0 :: v_dual_lshlrev_b32 v2, 1, v1       // 0000000B86D0: CA220080 09020281
	s_add_u32 s2, s6, s24                                      // 0000000B86D8: 80021806
	s_addc_u32 s1, s7, s25                                     // 0000000B86DC: 82011907
	s_add_u32 s4, s8, s24                                      // 0000000B86E0: 80041808
	.long 0xd70002ac                                           // 0000000B86E4: D70002AC
	v_cndmask_b32_e32 v1, s2, v2, vcc_lo                       // 0000000B86E8: 02020402
	s_movk_i32 s6, 0x210                                       // 0000000B86EC: B0060210
	s_addc_u32 s7, s9, s25                                     // 0000000B86F0: 82071909
	v_add_co_ci_u32_e64 v173, null, s1, 0, s2                  // 0000000B86F4: D5207CAD 00090001
	.long 0xd70001ae                                           // 0000000B86FC: D70001AE
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 0000000B8700: 02020404
	.long 0xd44c0000                                           // 0000000B8704: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000000B8708: 020200FF 00000200
	v_mad_u32_u24 v160, v155, s6, 0x7b00                       // 0000000B8710: D60B00A0 03FC0D9B 00007B00
	v_mad_u32_u24 v165, 0x44, v131, v3                         // 0000000B871C: D60B00A5 040F06FF 00000044
	v_dual_mov_b32 v10, v129 :: v_dual_add_nc_u32 v145, 0x7b00, v2// 0000000B8728: CA200181 0A9004FF 00007B00
	v_add_co_ci_u32_e64 v175, null, s7, 0, s1                  // 0000000B8734: D5207CAF 00050007
	v_mov_b32_e32 v2, v129                                     // 0000000B873C: 7E040381
	v_dual_mov_b32 v7, v129 :: v_dual_add_nc_u32 v168, v6, v5  // 0000000B8740: CA200181 07A80B06
	v_mov_b32_e32 v3, v129                                     // 0000000B8748: 7E060381
	v_mov_b32_e32 v5, v129                                     // 0000000B874C: 7E0A0381
	v_lshl_or_b32 v169, v158, 2, v6                            // 0000000B8750: D65600A9 0419059E
	v_mov_b32_e32 v6, v129                                     // 0000000B8758: 7E0C0381
	v_mad_u32_u24 v176, v1, 48, 0x4b00                         // 0000000B875C: D60B00B0 03FD6101 00004B00
	v_mov_b32_e32 v1, 0                                        // 0000000B8768: 7E020280
	v_mov_b32_e32 v11, v129                                    // 0000000B876C: 7E160381
	v_dual_mov_b32 v12, v129 :: v_dual_mov_b32 v17, 0          // 0000000B8770: CA100181 0C100080
	v_mov_b32_e32 v13, v129                                    // 0000000B8778: 7E1A0381
	v_dual_mov_b32 v14, v129 :: v_dual_mov_b32 v25, 0          // 0000000B877C: CA100181 0E180080
	v_mov_b32_e32 v15, v129                                    // 0000000B8784: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v33, 0          // 0000000B8788: CA100181 10200080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v41, 0          // 0000000B8790: CA100181 12280080
	v_mov_b32_e32 v19, v129                                    // 0000000B8798: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v49, 0          // 0000000B879C: CA100181 14300080
	v_mov_b32_e32 v21, v129                                    // 0000000B87A4: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v57, 0          // 0000000B87A8: CA100181 16380080
	v_mov_b32_e32 v23, v129                                    // 0000000B87B0: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v121, 0         // 0000000B87B4: CA100181 18780080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v113, 0         // 0000000B87BC: CA100181 1A700080
	v_mov_b32_e32 v27, v129                                    // 0000000B87C4: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v105, 0         // 0000000B87C8: CA100181 1C680080
	v_mov_b32_e32 v29, v129                                    // 0000000B87D0: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v97, 0          // 0000000B87D4: CA100181 1E600080
	v_mov_b32_e32 v31, v129                                    // 0000000B87DC: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v89, 0          // 0000000B87E0: CA100181 20580080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v81, 0          // 0000000B87E8: CA100181 22500080
	v_mov_b32_e32 v35, v129                                    // 0000000B87F0: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v73, 0          // 0000000B87F4: CA100181 24480080
	v_mov_b32_e32 v37, v129                                    // 0000000B87FC: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v65, 0          // 0000000B8800: CA100181 26400080
	v_mov_b32_e32 v39, v129                                    // 0000000B8808: 7E4E0381
	v_mov_b32_e32 v40, v129                                    // 0000000B880C: 7E500381
	v_mov_b32_e32 v42, v129                                    // 0000000B8810: 7E540381
	v_mov_b32_e32 v43, v129                                    // 0000000B8814: 7E560381
	v_mov_b32_e32 v44, v129                                    // 0000000B8818: 7E580381
	v_mov_b32_e32 v45, v129                                    // 0000000B881C: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 0000000B8820: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 0000000B8824: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 0000000B8828: 7E600381
	v_mov_b32_e32 v50, v129                                    // 0000000B882C: 7E640381
	v_mov_b32_e32 v51, v129                                    // 0000000B8830: 7E660381
	v_mov_b32_e32 v52, v129                                    // 0000000B8834: 7E680381
	v_mov_b32_e32 v53, v129                                    // 0000000B8838: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 0000000B883C: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 0000000B8840: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 0000000B8844: 7E700381
	v_mov_b32_e32 v58, v129                                    // 0000000B8848: 7E740381
	v_mov_b32_e32 v59, v129                                    // 0000000B884C: 7E760381
	v_mov_b32_e32 v60, v129                                    // 0000000B8850: 7E780381
	v_mov_b32_e32 v61, v129                                    // 0000000B8854: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 0000000B8858: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 0000000B885C: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 0000000B8860: 7E800381
	v_mov_b32_e32 v122, v129                                   // 0000000B8864: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 0000000B8868: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 0000000B886C: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 0000000B8870: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 0000000B8874: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 0000000B8878: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 0000000B887C: 7F000381
	v_mov_b32_e32 v114, v129                                   // 0000000B8880: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 0000000B8884: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 0000000B8888: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 0000000B888C: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 0000000B8890: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 0000000B8894: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 0000000B8898: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 0000000B889C: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 0000000B88A0: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 0000000B88A4: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 0000000B88A8: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 0000000B88AC: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 0000000B88B0: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 0000000B88B4: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 0000000B88B8: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 0000000B88BC: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 0000000B88C0: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 0000000B88C4: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 0000000B88C8: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 0000000B88CC: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 0000000B88D0: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 0000000B88D4: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 0000000B88D8: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 0000000B88DC: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 0000000B88E0: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 0000000B88E4: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 0000000B88E8: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 0000000B88EC: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 0000000B88F0: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 0000000B88F4: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 0000000B88F8: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 0000000B88FC: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 0000000B8900: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 0000000B8904: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 0000000B8908: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 0000000B890C: 7E940381
	v_mov_b32_e32 v75, v129                                    // 0000000B8910: 7E960381
	v_mov_b32_e32 v76, v129                                    // 0000000B8914: 7E980381
	v_mov_b32_e32 v77, v129                                    // 0000000B8918: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 0000000B891C: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 0000000B8920: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 0000000B8924: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 0000000B8928: 7E840381
	v_mov_b32_e32 v67, v129                                    // 0000000B892C: 7E860381
	v_mov_b32_e32 v68, v129                                    // 0000000B8930: 7E880381
	v_mov_b32_e32 v69, v129                                    // 0000000B8934: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 0000000B8938: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 0000000B893C: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 0000000B8940: 7E900381
	s_mov_b32 s6, 0                                            // 0000000B8944: BE860080
	s_branch 116                                               // 0000000B8948: BFA00074 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x91c>
	ds_load_b128 v[147:150], v171                              // 0000000B894C: DBFC0000 930000AB
	ds_load_b128 v[151:154], v171 offset:16                    // 0000000B8954: DBFC0010 970000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B895C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[147:154], v[121:128]// 0000000B8960: CC414079 1DE72782
	ds_load_b128 v[151:154], v171 offset:784                   // 0000000B8968: DBFC0310 970000AB
	ds_load_b128 v[147:150], v171 offset:768                   // 0000000B8970: DBFC0300 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B8978: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[147:154], v[113:120]// 0000000B897C: CC414071 1DC72782
	ds_load_b128 v[151:154], v171 offset:1552                  // 0000000B8984: DBFC0610 970000AB
	ds_load_b128 v[147:150], v171 offset:1536                  // 0000000B898C: DBFC0600 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B8994: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[147:154], v[105:112]// 0000000B8998: CC414069 1DA72782
	ds_load_b128 v[151:154], v171 offset:2320                  // 0000000B89A0: DBFC0910 970000AB
	ds_load_b128 v[147:150], v171 offset:2304                  // 0000000B89A8: DBFC0900 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B89B0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[147:154], v[97:104]// 0000000B89B4: CC414061 1D872782
	ds_load_b128 v[151:154], v171 offset:3088                  // 0000000B89BC: DBFC0C10 970000AB
	ds_load_b128 v[147:150], v171 offset:3072                  // 0000000B89C4: DBFC0C00 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B89CC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[147:154], v[89:96]// 0000000B89D0: CC414059 1D672782
	ds_load_b128 v[151:154], v171 offset:3856                  // 0000000B89D8: DBFC0F10 970000AB
	ds_load_b128 v[147:150], v171 offset:3840                  // 0000000B89E0: DBFC0F00 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B89E8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[147:154], v[81:88]// 0000000B89EC: CC414051 1D472782
	ds_load_b128 v[151:154], v171 offset:4624                  // 0000000B89F4: DBFC1210 970000AB
	ds_load_b128 v[147:150], v171 offset:4608                  // 0000000B89FC: DBFC1200 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B8A04: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[147:154], v[73:80]// 0000000B8A08: CC414049 1D272782
	ds_load_b128 v[151:154], v171 offset:5392                  // 0000000B8A10: DBFC1510 970000AB
	ds_load_b128 v[147:150], v171 offset:5376                  // 0000000B8A18: DBFC1500 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B8A20: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[147:154], v[65:72]// 0000000B8A24: CC414041 1D072782
	ds_load_b128 v[151:154], v171 offset:6160                  // 0000000B8A2C: DBFC1810 970000AB
	ds_load_b128 v[147:150], v171 offset:6144                  // 0000000B8A34: DBFC1800 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B8A3C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[147:154], v[57:64]// 0000000B8A40: CC414039 1CE72782
	ds_load_b128 v[151:154], v171 offset:6928                  // 0000000B8A48: DBFC1B10 970000AB
	ds_load_b128 v[147:150], v171 offset:6912                  // 0000000B8A50: DBFC1B00 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B8A58: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[147:154], v[49:56]// 0000000B8A5C: CC414031 1CC72782
	ds_load_b128 v[151:154], v171 offset:7696                  // 0000000B8A64: DBFC1E10 970000AB
	ds_load_b128 v[147:150], v171 offset:7680                  // 0000000B8A6C: DBFC1E00 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B8A74: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[147:154], v[41:48]// 0000000B8A78: CC414029 1CA72782
	ds_load_b128 v[151:154], v171 offset:8464                  // 0000000B8A80: DBFC2110 970000AB
	ds_load_b128 v[147:150], v171 offset:8448                  // 0000000B8A88: DBFC2100 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B8A90: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[147:154], v[33:40]// 0000000B8A94: CC414021 1C872782
	ds_load_b128 v[151:154], v171 offset:9232                  // 0000000B8A9C: DBFC2410 970000AB
	ds_load_b128 v[147:150], v171 offset:9216                  // 0000000B8AA4: DBFC2400 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B8AAC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[147:154], v[25:32]// 0000000B8AB0: CC414019 1C672782
	ds_load_b128 v[151:154], v171 offset:10000                 // 0000000B8AB8: DBFC2710 970000AB
	ds_load_b128 v[147:150], v171 offset:9984                  // 0000000B8AC0: DBFC2700 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B8AC8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[147:154], v[17:24]// 0000000B8ACC: CC414011 1C472782
	ds_load_b128 v[151:154], v171 offset:10768                 // 0000000B8AD4: DBFC2A10 970000AB
	ds_load_b128 v[147:150], v171 offset:10752                 // 0000000B8ADC: DBFC2A00 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B8AE4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[147:154], v[9:16]// 0000000B8AE8: CC414009 1C272782
	ds_load_b128 v[151:154], v171 offset:11536                 // 0000000B8AF0: DBFC2D10 970000AB
	ds_load_b128 v[147:150], v171 offset:11520                 // 0000000B8AF8: DBFC2D00 930000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000B8B00: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[147:154], v[1:8]// 0000000B8B04: CC414001 1C072782
	s_add_i32 s1, s6, 1                                        // 0000000B8B0C: 81018106
	s_cmp_eq_u32 s6, s5                                        // 0000000B8B10: BF060506
	s_mov_b32 s6, s1                                           // 0000000B8B14: BE860001
	s_cbranch_scc1 1921                                        // 0000000B8B18: BFA20781 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2720>
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 0000000B8B1C: 916A0D7E
	s_mov_b32 s1, s12                                          // 0000000B8B20: BE81000C
	s_cbranch_vccz 3                                           // 0000000B8B24: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x934>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000000B8B28: 916A017E
	s_cbranch_vccnz 65527                                      // 0000000B8B2C: BFA4FFF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x90c>
	s_branch 15                                                // 0000000B8B30: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x970>
	s_lshr_b32 s1, s6, 3                                       // 0000000B8B34: 85018306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000B8B38: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 0000000B8B3C: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 0000000B8B44: 7F040201
	global_load_b32 v130, v130, s[20:21]                       // 0000000B8B48: DC520000 82140082
	s_waitcnt vmcnt(0)                                         // 0000000B8B50: BF8903F7
	v_lshrrev_b32_e32 v130, s6, v130                           // 0000000B8B54: 33050406
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8B58: BF870091
	v_and_b32_e32 v130, 1, v130                                // 0000000B8B5C: 37050481
	.long 0xd44a0001                                           // 0000000B8B60: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000B8B64: 02030481
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000000B8B68: 916A017E
	s_cbranch_vccnz 65511                                      // 0000000B8B6C: BFA4FFE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x90c>
	s_lshl_b32 s2, s6, 4                                       // 0000000B8B70: 84028406
	s_waitcnt vmcnt(0)                                         // 0000000B8B74: BF8903F7
	s_barrier                                                  // 0000000B8B78: BFBD0000
	buffer_gl0_inv                                             // 0000000B8B7C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000000B8B84: BE812000
	s_cbranch_execz 67                                         // 0000000B8B88: BFA50043 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa98>
	v_mov_b32_e32 v130, v0                                     // 0000000B8B8C: 7F040300
	s_mov_b32 s4, 0                                            // 0000000B8B90: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B8B94: BF870121
	v_lshrrev_b32_e32 v137, 5, v130                            // 0000000B8B98: 33130485
	v_add_nc_u32_e32 v151, 0x180, v130                         // 0000000B8B9C: 4B2F04FF 00000180
	v_or_b32_e32 v131, s2, v137                                // 0000000B8BA4: 39071202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8BA8: BF870091
	v_min_i32_e32 v131, s15, v131                              // 0000000B8BAC: 2307060F
	v_ashrrev_i32_e32 v133, 31, v131                           // 0000000B8BB0: 350B069F
	.long 0xd72c0086                                           // 0000000B8BB4: D72C0086
	v_cndmask_b32_e32 v1, s11, v131, vcc_lo                    // 0000000B8BB8: 0203060B
	v_mad_u64_u32 v[131:132], null, s10, v131, 0               // 0000000B8BBC: D6FE7C83 0203060A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8BC4: BF870093
	.long 0xd72c0085                                           // 0000000B8BC8: D72C0085
	v_cndmask_b32_e32 v1, s10, v133, vcc_lo                    // 0000000B8BCC: 02030A0A
	v_add3_u32 v132, v132, v133, v134                          // 0000000B8BD0: D6550084 061B0B84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8BD8: BF870091
	.long 0xd73c0083                                           // 0000000B8BDC: D73C0083
	v_cndmask_b32_e32 v1, 1, v131, vcc_lo                      // 0000000B8BE0: 02030681
	.long 0xd7006a85                                           // 0000000B8BE4: D7006A85
	v_cndmask_b32_e32 v1, v172, v131, vcc_lo                   // 0000000B8BE8: 020307AC
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B8BEC: BF8700A1
	v_add_co_ci_u32_e64 v134, null, v173, v132, vcc_lo         // 0000000B8BF0: D5207C86 01AB09AD
	.long 0xd7006a87                                           // 0000000B8BF8: D7006A87
	v_cndmask_b32_e32 v1, v174, v131, vcc_lo                   // 0000000B8BFC: 020307AE
	v_add_co_ci_u32_e64 v136, null, v175, v132, vcc_lo         // 0000000B8C00: D5207C88 01AB09AF
	global_load_b128 v[131:134], v[133:134], off               // 0000000B8C08: DC5E0000 837C0085
	global_load_b128 v[147:150], v[135:136], off               // 0000000B8C10: DC5E0000 937C0087
	v_mad_u64_u32 v[135:136], null, 0x210, v137, v[145:146]    // 0000000B8C18: D6FE7C87 064712FF 00000210
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v130                        // 0000000B8C24: 7C9304FF 0000007F
	v_mov_b32_e32 v130, v151                                   // 0000000B8C2C: 7F040397
	v_lshl_add_u32 v136, v137, 1, v176                         // 0000000B8C30: D6460088 06C10389
	s_waitcnt vmcnt(1)                                         // 0000000B8C38: BF8907F7
	ds_store_b128 v135, v[131:134]                             // 0000000B8C3C: DB7C0000 00008387
	s_waitcnt vmcnt(0)                                         // 0000000B8C44: BF8903F7
	ds_store_b16 v136, v147                                    // 0000000B8C48: D87C0000 00009388
	ds_store_b16_d16_hi v136, v147 offset:48                   // 0000000B8C50: DA840030 00009388
	ds_store_b16 v136, v148 offset:96                          // 0000000B8C58: D87C0060 00009488
	ds_store_b16_d16_hi v136, v148 offset:144                  // 0000000B8C60: DA840090 00009488
	ds_store_b16 v136, v149 offset:192                         // 0000000B8C68: D87C00C0 00009588
	ds_store_b16_d16_hi v136, v149 offset:240                  // 0000000B8C70: DA8400F0 00009588
	ds_store_b16 v136, v150 offset:288                         // 0000000B8C78: D87C0120 00009688
	ds_store_b16_d16_hi v136, v150 offset:336                  // 0000000B8C80: DA840150 00009688
	s_or_b32 s4, vcc_lo, s4                                    // 0000000B8C88: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B8C8C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B8C90: 917E047E
	s_cbranch_execnz 65471                                     // 0000000B8C94: BFA6FFBF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x994>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B8C98: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 0000000B8C9C: BF89FC07
	s_barrier                                                  // 0000000B8CA0: BFBD0000
	buffer_gl0_inv                                             // 0000000B8CA4: E0AC0000 00000000
	s_clause 0x3                                               // 0000000B8CAC: BF850003
	global_load_b128 v[151:154], v[143:144], off offset:16     // 0000000B8CB0: DC5E0010 977C008F
	global_load_b128 v[147:150], v[143:144], off               // 0000000B8CB8: DC5E0000 937C008F
	global_load_b128 v[181:184], v[143:144], off offset:48     // 0000000B8CC0: DC5E0030 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:32     // 0000000B8CC8: DC5E0020 B17C008F
	ds_load_b128 v[185:188], v160                              // 0000000B8CD0: DBFC0000 B90000A0
	ds_load_b128 v[189:192], v160 offset:16                    // 0000000B8CD8: DBFC0010 BD0000A0
	v_mov_b32_e32 v136, v129                                   // 0000000B8CE0: 7F100381
	v_mov_b32_e32 v130, v129                                   // 0000000B8CE4: 7F040381
	v_mov_b32_e32 v131, v129                                   // 0000000B8CE8: 7F060381
	v_mov_b32_e32 v132, v129                                   // 0000000B8CEC: 7F080381
	v_mov_b32_e32 v133, v129                                   // 0000000B8CF0: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 0000000B8CF4: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 0000000B8CF8: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 0000000B8CFC: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000B8D00: BF870212
	v_mov_b32_e32 v136, v135                                   // 0000000B8D04: 7F100387
	v_mov_b32_e32 v135, v134                                   // 0000000B8D08: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 0000000B8D0C: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 0000000B8D10: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 0000000B8D14: 7F080383
	v_mov_b32_e32 v131, v130                                   // 0000000B8D18: 7F060382
	v_mov_b32_e32 v130, v129                                   // 0000000B8D1C: 7F040381
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8D20: BF890807
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B8D24: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[147:154], v[185:192], v[130:137]// 0000000B8D28: CC414082 1E0B7393
	s_clause 0x1                                               // 0000000B8D30: BF850001
	global_load_b128 v[151:154], v[143:144], off offset:80     // 0000000B8D34: DC5E0050 977C008F
	global_load_b128 v[147:150], v[143:144], off offset:64     // 0000000B8D3C: DC5E0040 937C008F
	ds_load_b128 v[185:188], v160 offset:32                    // 0000000B8D44: DBFC0020 B90000A0
	ds_load_b128 v[189:192], v160 offset:48                    // 0000000B8D4C: DBFC0030 BD0000A0
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8D54: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000B8D58: CC414082 1E0B73B1
	s_clause 0x1                                               // 0000000B8D60: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:112    // 0000000B8D64: DC5E0070 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:96     // 0000000B8D6C: DC5E0060 B17C008F
	ds_load_b128 v[189:192], v160 offset:80                    // 0000000B8D74: DBFC0050 BD0000A0
	ds_load_b128 v[185:188], v160 offset:64                    // 0000000B8D7C: DBFC0040 B90000A0
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8D84: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[147:154], v[185:192], v[130:137]// 0000000B8D88: CC414082 1E0B7393
	s_clause 0x1                                               // 0000000B8D90: BF850001
	global_load_b128 v[151:154], v[143:144], off offset:144    // 0000000B8D94: DC5E0090 977C008F
	global_load_b128 v[147:150], v[143:144], off offset:128    // 0000000B8D9C: DC5E0080 937C008F
	ds_load_b128 v[189:192], v160 offset:112                   // 0000000B8DA4: DBFC0070 BD0000A0
	ds_load_b128 v[185:188], v160 offset:96                    // 0000000B8DAC: DBFC0060 B90000A0
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8DB4: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000B8DB8: CC414082 1E0B73B1
	s_clause 0x1                                               // 0000000B8DC0: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:176    // 0000000B8DC4: DC5E00B0 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:160    // 0000000B8DCC: DC5E00A0 B17C008F
	ds_load_b128 v[189:192], v160 offset:144                   // 0000000B8DD4: DBFC0090 BD0000A0
	ds_load_b128 v[185:188], v160 offset:128                   // 0000000B8DDC: DBFC0080 B90000A0
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8DE4: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[147:154], v[185:192], v[130:137]// 0000000B8DE8: CC414082 1E0B7393
	s_clause 0x1                                               // 0000000B8DF0: BF850001
	global_load_b128 v[151:154], v[143:144], off offset:208    // 0000000B8DF4: DC5E00D0 977C008F
	global_load_b128 v[147:150], v[143:144], off offset:192    // 0000000B8DFC: DC5E00C0 937C008F
	ds_load_b128 v[189:192], v160 offset:176                   // 0000000B8E04: DBFC00B0 BD0000A0
	ds_load_b128 v[185:188], v160 offset:160                   // 0000000B8E0C: DBFC00A0 B90000A0
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8E14: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000B8E18: CC414082 1E0B73B1
	s_clause 0x1                                               // 0000000B8E20: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:240    // 0000000B8E24: DC5E00F0 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:224    // 0000000B8E2C: DC5E00E0 B17C008F
	ds_load_b128 v[189:192], v160 offset:208                   // 0000000B8E34: DBFC00D0 BD0000A0
	ds_load_b128 v[185:188], v160 offset:192                   // 0000000B8E3C: DBFC00C0 B90000A0
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8E44: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[147:154], v[185:192], v[130:137]// 0000000B8E48: CC414082 1E0B7393
	s_clause 0x1                                               // 0000000B8E50: BF850001
	global_load_b128 v[151:154], v[143:144], off offset:272    // 0000000B8E54: DC5E0110 977C008F
	global_load_b128 v[147:150], v[143:144], off offset:256    // 0000000B8E5C: DC5E0100 937C008F
	ds_load_b128 v[189:192], v160 offset:240                   // 0000000B8E64: DBFC00F0 BD0000A0
	ds_load_b128 v[185:188], v160 offset:224                   // 0000000B8E6C: DBFC00E0 B90000A0
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8E74: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000B8E78: CC414082 1E0B73B1
	s_clause 0x1                                               // 0000000B8E80: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:304    // 0000000B8E84: DC5E0130 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:288    // 0000000B8E8C: DC5E0120 B17C008F
	ds_load_b128 v[189:192], v160 offset:272                   // 0000000B8E94: DBFC0110 BD0000A0
	ds_load_b128 v[185:188], v160 offset:256                   // 0000000B8E9C: DBFC0100 B90000A0
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8EA4: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[147:154], v[185:192], v[130:137]// 0000000B8EA8: CC414082 1E0B7393
	s_clause 0x1                                               // 0000000B8EB0: BF850001
	global_load_b128 v[151:154], v[143:144], off offset:336    // 0000000B8EB4: DC5E0150 977C008F
	global_load_b128 v[147:150], v[143:144], off offset:320    // 0000000B8EBC: DC5E0140 937C008F
	ds_load_b128 v[189:192], v160 offset:304                   // 0000000B8EC4: DBFC0130 BD0000A0
	ds_load_b128 v[185:188], v160 offset:288                   // 0000000B8ECC: DBFC0120 B90000A0
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8ED4: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000B8ED8: CC414082 1E0B73B1
	s_clause 0x1                                               // 0000000B8EE0: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:368    // 0000000B8EE4: DC5E0170 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:352    // 0000000B8EEC: DC5E0160 B17C008F
	ds_load_b128 v[189:192], v160 offset:336                   // 0000000B8EF4: DBFC0150 BD0000A0
	ds_load_b128 v[185:188], v160 offset:320                   // 0000000B8EFC: DBFC0140 B90000A0
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8F04: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[147:154], v[185:192], v[130:137]// 0000000B8F08: CC414082 1E0B7393
	s_clause 0x1                                               // 0000000B8F10: BF850001
	global_load_b128 v[151:154], v[143:144], off offset:400    // 0000000B8F14: DC5E0190 977C008F
	global_load_b128 v[147:150], v[143:144], off offset:384    // 0000000B8F1C: DC5E0180 937C008F
	ds_load_b128 v[189:192], v160 offset:368                   // 0000000B8F24: DBFC0170 BD0000A0
	ds_load_b128 v[185:188], v160 offset:352                   // 0000000B8F2C: DBFC0160 B90000A0
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8F34: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000B8F38: CC414082 1E0B73B1
	ds_load_b128 v[181:184], v160 offset:400                   // 0000000B8F40: DBFC0190 B50000A0
	ds_load_b128 v[177:180], v160 offset:384                   // 0000000B8F48: DBFC0180 B10000A0
	s_clause 0x1                                               // 0000000B8F50: BF850001
	global_load_b128 v[189:192], v[143:144], off offset:432    // 0000000B8F54: DC5E01B0 BD7C008F
	global_load_b128 v[185:188], v[143:144], off offset:416    // 0000000B8F5C: DC5E01A0 B97C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8F64: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[147:154], v[177:184], v[130:137]// 0000000B8F68: CC414082 1E0B6393
	s_clause 0x1                                               // 0000000B8F70: BF850001
	global_load_b128 v[151:154], v[143:144], off offset:464    // 0000000B8F74: DC5E01D0 977C008F
	global_load_b128 v[147:150], v[143:144], off offset:448    // 0000000B8F7C: DC5E01C0 937C008F
	ds_load_b128 v[181:184], v160 offset:432                   // 0000000B8F84: DBFC01B0 B50000A0
	ds_load_b128 v[177:180], v160 offset:416                   // 0000000B8F8C: DBFC01A0 B10000A0
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8F94: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[185:192], v[177:184], v[130:137]// 0000000B8F98: CC414082 1E0B63B9
	ds_load_b128 v[181:184], v160 offset:464                   // 0000000B8FA0: DBFC01D0 B50000A0
	ds_load_b128 v[177:180], v160 offset:448                   // 0000000B8FA8: DBFC01C0 B10000A0
	s_clause 0x1                                               // 0000000B8FB0: BF850001
	global_load_b128 v[189:192], v[143:144], off offset:496    // 0000000B8FB4: DC5E01F0 BD7C008F
	global_load_b128 v[185:188], v[143:144], off offset:480    // 0000000B8FBC: DC5E01E0 B97C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000B8FC4: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[147:154], v[177:184], v[130:137]// 0000000B8FC8: CC414082 1E0B6393
	ds_load_b128 v[151:154], v160 offset:496                   // 0000000B8FD0: DBFC01F0 970000A0
	ds_load_b128 v[147:150], v160 offset:480                   // 0000000B8FD8: DBFC01E0 930000A0
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B8FE0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[185:192], v[147:154], v[130:137]// 0000000B8FE4: CC414082 1E0B27B9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B8FEC: BF870111
	v_dual_mul_f32 v130, 0x3d800000, v130 :: v_dual_mul_f32 v131, 0x3d800000, v131// 0000000B8FF0: C8C704FF 828306FF 3D800000
	v_mul_f32_e32 v147, 0x3d800000, v133                       // 0000000B8FFC: 11270AFF 3D800000
	v_mov_b32_e32 v133, 0xffff                                 // 0000000B9004: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B900C: BF870004
	v_mul_f32_e32 v132, 0x3d800000, v132                       // 0000000B9010: 110908FF 3D800000
	v_dual_mul_f32 v134, 0x3d800000, v134 :: v_dual_mul_f32 v135, 0x3d800000, v135// 0000000B9018: C8C70CFF 86870EFF 3D800000
	v_dual_mul_f32 v136, 0x3d800000, v136 :: v_dual_mul_f32 v137, 0x3d800000, v137// 0000000B9024: C8C710FF 888912FF 3D800000
	ds_store_2addr_b32 v161, v130, v131 offset1:34             // 0000000B9030: D8382200 008382A1
	ds_store_2addr_b32 v161, v132, v147 offset0:68 offset1:102 // 0000000B9038: D8386644 009384A1
	ds_store_2addr_b32 v161, v134, v135 offset0:136 offset1:170// 0000000B9040: D838AA88 008786A1
	ds_store_2addr_b32 v161, v136, v137 offset0:204 offset1:238// 0000000B9048: D838EECC 008988A1
	s_waitcnt lgkmcnt(0)                                       // 0000000B9050: BF89FC07
	s_barrier                                                  // 0000000B9054: BFBD0000
	buffer_gl0_inv                                             // 0000000B9058: E0AC0000 00000000
	s_and_saveexec_b32 s4, s23                                 // 0000000B9060: BE842017
	s_cbranch_execz 362                                        // 0000000B9064: BFA5016A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1410>
	s_lshl_b32 s7, s6, 2                                       // 0000000B9068: 84078206
	s_mov_b32 s8, exec_lo                                      // 0000000B906C: BE88007E
	.long 0xd4c1007e                                           // 0000000B9070: D4C1007E
	v_cndmask_b32_e32 v1, v146, v159, vcc_lo                   // 0000000B9074: 02033F92
	s_cbranch_execz 47                                         // 0000000B9078: BFA5002F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf38>
	v_ashrrev_i32_e32 v147, 31, v146                           // 0000000B907C: 3527249F
	s_mov_b32 s9, 0                                            // 0000000B9080: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9084: BF870091
	.long 0xd73c0082                                           // 0000000B9088: D73C0082
	v_cndmask_b32_e32 v1, 2, v146, vcc_lo                      // 0000000B908C: 02032482
	.long 0xd7006a82                                           // 0000000B9090: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 0000000B9094: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9098: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 0000000B909C: D5207C83 01AB078E
	s_branch 14                                                // 0000000B90A4: BFA0000E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xee0>
	s_nop 0                                                    // 0000000B90A8: BF800000
	s_nop 0                                                    // 0000000B90AC: BF800000
	s_nop 0                                                    // 0000000B90B0: BF800000
	s_nop 0                                                    // 0000000B90B4: BF800000
	s_nop 0                                                    // 0000000B90B8: BF800000
	s_nop 0                                                    // 0000000B90BC: BF800000
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000B90C0: 8C7E187E
	v_dual_mov_b32 v133, v146 :: v_dual_mov_b32 v146, v132     // 0000000B90C4: CA100192 85920184
	s_and_b32 s1, exec_lo, s22                                 // 0000000B90CC: 8B01167E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000B90D0: BF870499
	s_or_b32 s9, s1, s9                                        // 0000000B90D4: 8C090901
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000B90D8: 917E097E
	s_cbranch_execz 20                                         // 0000000B90DC: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf30>
	global_load_b32 v132, v[130:131], off                      // 0000000B90E0: DC520000 847C0082
	s_or_b32 s22, s22, exec_lo                                 // 0000000B90E8: 8C167E16
	s_waitcnt vmcnt(0)                                         // 0000000B90EC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s7, v132                          // 0000000B90F0: 7C890807
	s_and_saveexec_b32 s24, vcc_lo                             // 0000000B90F4: BE98206A
	s_cbranch_execz 65521                                      // 0000000B90F8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xec0>
	v_add_nc_u32_e32 v132, 1, v146                             // 0000000B90FC: 4B092481
	.long 0xd7000182                                           // 0000000B9100: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 0000000B9104: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B9108: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 0000000B910C: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v159, v132                        // 0000000B9114: 7C95099F
	v_mov_b32_e32 v146, v159                                   // 0000000B9118: 7F24039F
	s_and_not1_b32 s1, s22, exec_lo                            // 0000000B911C: 91017E16
	s_and_b32 s22, vcc_lo, exec_lo                             // 0000000B9120: 8B167E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9124: BF870009
	s_or_b32 s22, s1, s22                                      // 0000000B9128: 8C161601
	s_branch 65508                                             // 0000000B912C: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xec0>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000B9130: 8C7E097E
	v_mov_b32_e32 v146, v133                                   // 0000000B9134: 7F240385
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B9138: 8C7E087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B913C: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v146       // 0000000B9140: CA10008F 85820192
	s_mov_b32 s1, exec_lo                                      // 0000000B9148: BE81007E
	.long 0xd4c1007e                                           // 0000000B914C: D4C1007E
	v_cndmask_b32_e32 v1, s7, v162, vcc_lo                     // 0000000B9150: 02034407
	s_cbranch_execz 62                                         // 0000000B9154: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1050>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v146        // 0000000B9158: CA100080 85820192
	s_mov_b32 s8, exec_lo                                      // 0000000B9160: BE88007E
	.long 0xd4c1007e                                           // 0000000B9164: D4C1007E
	v_cndmask_b32_e32 v1, v146, v159, vcc_lo                   // 0000000B9168: 02033F92
	s_cbranch_execz 54                                         // 0000000B916C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1048>
	v_mov_b32_e32 v130, v146                                   // 0000000B9170: 7F040392
	s_mov_b32 s22, 0                                           // 0000000B9174: BE960080
	s_set_inst_prefetch_distance 0x1                           // 0000000B9178: BF840001
	s_branch 10                                                // 0000000B917C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfa8>
	s_or_b32 exec_lo, exec_lo, s26                             // 0000000B9180: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000B9184: BF870499
	s_and_b32 s26, exec_lo, s25                                // 0000000B9188: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 0000000B918C: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 0000000B9190: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 0000000B9194: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9198: BF870009
	s_or_b32 s9, s9, s26                                       // 0000000B919C: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000000B91A0: 917E167E
	s_cbranch_execz 28                                         // 0000000B91A4: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1018>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B91A8: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 0000000B91AC: 7F060382
	s_or_b32 s24, s24, exec_lo                                 // 0000000B91B0: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 0000000B91B4: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 0000000B91B8: BE9A007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000B91BC: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B91C0: BF870091
	.long 0xd73c0084                                           // 0000000B91C4: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000B91C8: 02030682
	.long 0xd7006a84                                           // 0000000B91CC: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 0000000B91D0: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B91D4: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 0000000B91D8: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 0000000B91E0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 0000000B91E8: BF8903F7
	.long 0xd4c4007e                                           // 0000000B91EC: D4C4007E
	v_cndmask_b32_e32 v1, s7, v132, vcc_lo                     // 0000000B91F0: 02030807
	s_cbranch_execz 65506                                      // 0000000B91F4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000B91F8: 4B050681
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000B91FC: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 0000000B9200: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000B9204: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v159, v130                        // 0000000B9208: 7C95059F
	s_and_b32 s27, vcc_lo, exec_lo                             // 0000000B920C: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 0000000B9210: 8C191B19
	s_branch 65498                                             // 0000000B9214: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	s_set_inst_prefetch_distance 0x2                           // 0000000B9218: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000B921C: 8C7E167E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v159        // 0000000B9220: CA100080 8582019F
	s_and_saveexec_b32 s22, s9                                 // 0000000B9228: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B922C: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 0000000B9230: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v132                          // 0000000B9234: 7C950807
	v_mov_b32_e32 v130, v131                                   // 0000000B9238: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 0000000B923C: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000B9244: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9248: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B924C: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9250: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B9254: 8C7E017E
	s_or_b32 s8, s7, 1                                         // 0000000B9258: 8C088107
	s_mov_b32 s1, exec_lo                                      // 0000000B925C: BE81007E
	.long 0xd4c6007e                                           // 0000000B9260: D4C6007E
	v_cndmask_b32_e32 v1, s8, v162, vcc_lo                     // 0000000B9264: 02034408
	s_xor_b32 s1, exec_lo, s1                                  // 0000000B9268: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 0000000B926C: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 0000000B9274: BE813001
	s_cbranch_execz 70                                         // 0000000B9278: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1194>
	s_mov_b32 s9, exec_lo                                      // 0000000B927C: BE89007E
	.long 0xd4c1007e                                           // 0000000B9280: D4C1007E
	v_cndmask_b32_e32 v1, v130, v159, vcc_lo                   // 0000000B9284: 02033F82
	s_cbranch_execz 64                                         // 0000000B9288: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x118c>
	s_mov_b32 s24, 0                                           // 0000000B928C: BE980080
	s_set_inst_prefetch_distance 0x1                           // 0000000B9290: BF840001
	s_branch 20                                                // 0000000B9294: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10e8>
	s_nop 0                                                    // 0000000B9298: BF800000
	s_nop 0                                                    // 0000000B929C: BF800000
	s_nop 0                                                    // 0000000B92A0: BF800000
	s_nop 0                                                    // 0000000B92A4: BF800000
	s_nop 0                                                    // 0000000B92A8: BF800000
	s_nop 0                                                    // 0000000B92AC: BF800000
	s_nop 0                                                    // 0000000B92B0: BF800000
	s_nop 0                                                    // 0000000B92B4: BF800000
	s_nop 0                                                    // 0000000B92B8: BF800000
	s_nop 0                                                    // 0000000B92BC: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 0000000B92C0: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000B92C4: BF870499
	s_and_b32 s27, exec_lo, s26                                // 0000000B92C8: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 0000000B92CC: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 0000000B92D0: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 0000000B92D4: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B92D8: BF870009
	s_or_b32 s22, s22, s27                                     // 0000000B92DC: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 0000000B92E0: 917E187E
	s_cbranch_execz 27                                         // 0000000B92E4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1154>
	v_mov_b32_e32 v131, v130                                   // 0000000B92E8: 7F060382
	s_or_b32 s25, s25, exec_lo                                 // 0000000B92EC: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 0000000B92F0: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 0000000B92F4: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B92F8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000B92FC: 3509069F
	.long 0xd73c0086                                           // 0000000B9300: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000B9304: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9308: BF870091
	.long 0xd7006a86                                           // 0000000B930C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 0000000B9310: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 0000000B9314: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 0000000B931C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 0000000B9324: BF8903F7
	.long 0xd4c6007e                                           // 0000000B9328: D4C6007E
	v_cndmask_b32_e32 v1, s7, v132, vcc_lo                     // 0000000B932C: 02030807
	s_cbranch_execz 65507                                      // 0000000B9330: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000B9334: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000B9338: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000B933C: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000B9340: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v159, v130                        // 0000000B9344: 7C95059F
	s_and_b32 s28, vcc_lo, exec_lo                             // 0000000B9348: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 0000000B934C: 8C1A1C1A
	s_branch 65499                                             // 0000000B9350: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000B9354: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000B9358: 8C7E187E
	v_mov_b32_e32 v130, v159                                   // 0000000B935C: 7F04039F
	s_and_saveexec_b32 s24, s22                                // 0000000B9360: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9364: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 0000000B9368: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v132                          // 0000000B936C: 7C950808
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 0000000B9370: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B937C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000B9380: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 0000000B9384: 7F040383
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000B9388: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B938C: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000B9390: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9394: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B9398: 8C7E017E
	s_or_b32 s8, s7, 2                                         // 0000000B939C: 8C088207
	s_mov_b32 s1, exec_lo                                      // 0000000B93A0: BE81007E
	.long 0xd4c6007e                                           // 0000000B93A4: D4C6007E
	v_cndmask_b32_e32 v1, s8, v162, vcc_lo                     // 0000000B93A8: 02034408
	s_xor_b32 s1, exec_lo, s1                                  // 0000000B93AC: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 0000000B93B0: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 0000000B93B8: BE813001
	s_cbranch_execz 69                                         // 0000000B93BC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12d4>
	s_mov_b32 s9, exec_lo                                      // 0000000B93C0: BE89007E
	.long 0xd4c1007e                                           // 0000000B93C4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v159, vcc_lo                   // 0000000B93C8: 02033F82
	s_cbranch_execz 63                                         // 0000000B93CC: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12cc>
	s_mov_b32 s24, 0                                           // 0000000B93D0: BE980080
	s_set_inst_prefetch_distance 0x1                           // 0000000B93D4: BF840001
	s_branch 19                                                // 0000000B93D8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1228>
	s_nop 0                                                    // 0000000B93DC: BF800000
	s_nop 0                                                    // 0000000B93E0: BF800000
	s_nop 0                                                    // 0000000B93E4: BF800000
	s_nop 0                                                    // 0000000B93E8: BF800000
	s_nop 0                                                    // 0000000B93EC: BF800000
	s_nop 0                                                    // 0000000B93F0: BF800000
	s_nop 0                                                    // 0000000B93F4: BF800000
	s_nop 0                                                    // 0000000B93F8: BF800000
	s_nop 0                                                    // 0000000B93FC: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 0000000B9400: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000B9404: BF870499
	s_and_b32 s27, exec_lo, s26                                // 0000000B9408: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 0000000B940C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 0000000B9410: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 0000000B9414: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9418: BF870009
	s_or_b32 s22, s22, s27                                     // 0000000B941C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 0000000B9420: 917E187E
	s_cbranch_execz 27                                         // 0000000B9424: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1294>
	v_mov_b32_e32 v131, v130                                   // 0000000B9428: 7F060382
	s_or_b32 s25, s25, exec_lo                                 // 0000000B942C: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 0000000B9430: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 0000000B9434: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9438: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000B943C: 3509069F
	.long 0xd73c0086                                           // 0000000B9440: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000B9444: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9448: BF870091
	.long 0xd7006a86                                           // 0000000B944C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 0000000B9450: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 0000000B9454: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 0000000B945C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 0000000B9464: BF8903F7
	.long 0xd4c4007e                                           // 0000000B9468: D4C4007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 0000000B946C: 02030808
	s_cbranch_execz 65507                                      // 0000000B9470: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1200>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000B9474: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000B9478: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000B947C: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000B9480: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v159, v130                        // 0000000B9484: 7C95059F
	s_and_b32 s28, vcc_lo, exec_lo                             // 0000000B9488: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 0000000B948C: 8C1A1C1A
	s_branch 65499                                             // 0000000B9490: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1200>
	s_set_inst_prefetch_distance 0x2                           // 0000000B9494: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000B9498: 8C7E187E
	v_mov_b32_e32 v130, v159                                   // 0000000B949C: 7F04039F
	s_and_saveexec_b32 s24, s22                                // 0000000B94A0: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B94A4: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 0000000B94A8: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v132                          // 0000000B94AC: 7C950808
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 0000000B94B0: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B94BC: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000B94C0: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 0000000B94C4: 7F040383
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000B94C8: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B94CC: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000B94D0: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B94D4: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B94D8: 8C7E017E
	s_or_b32 s7, s7, 3                                         // 0000000B94DC: 8C078307
	s_mov_b32 s1, exec_lo                                      // 0000000B94E0: BE81007E
	.long 0xd4c6007e                                           // 0000000B94E4: D4C6007E
	v_cndmask_b32_e32 v1, s7, v162, vcc_lo                     // 0000000B94E8: 02034407
	s_xor_b32 s1, exec_lo, s1                                  // 0000000B94EC: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 0000000B94F0: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 0000000B94F8: BE813001
	s_cbranch_execz 66                                         // 0000000B94FC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1408>
	s_mov_b32 s8, exec_lo                                      // 0000000B9500: BE88007E
	.long 0xd4c1007e                                           // 0000000B9504: D4C1007E
	v_cndmask_b32_e32 v1, v130, v159, vcc_lo                   // 0000000B9508: 02033F82
	s_cbranch_execz 60                                         // 0000000B950C: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	s_mov_b32 s22, 0                                           // 0000000B9510: BE960080
	s_set_inst_prefetch_distance 0x1                           // 0000000B9514: BF840001
	s_branch 19                                                // 0000000B9518: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1368>
	s_nop 0                                                    // 0000000B951C: BF800000
	s_nop 0                                                    // 0000000B9520: BF800000
	s_nop 0                                                    // 0000000B9524: BF800000
	s_nop 0                                                    // 0000000B9528: BF800000
	s_nop 0                                                    // 0000000B952C: BF800000
	s_nop 0                                                    // 0000000B9530: BF800000
	s_nop 0                                                    // 0000000B9534: BF800000
	s_nop 0                                                    // 0000000B9538: BF800000
	s_nop 0                                                    // 0000000B953C: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 0000000B9540: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000B9544: BF870499
	s_and_b32 s26, exec_lo, s25                                // 0000000B9548: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 0000000B954C: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 0000000B9550: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 0000000B9554: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9558: BF870009
	s_or_b32 s9, s9, s26                                       // 0000000B955C: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000000B9560: 917E167E
	s_cbranch_execz 26                                         // 0000000B9564: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13d0>
	v_ashrrev_i32_e32 v131, 31, v130                           // 0000000B9568: 3507049F
	s_or_b32 s24, s24, exec_lo                                 // 0000000B956C: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 0000000B9570: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 0000000B9574: BE9A007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9578: BF870091
	.long 0xd73c0083                                           // 0000000B957C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 0000000B9580: 02030482
	.long 0xd7006a83                                           // 0000000B9584: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 0000000B9588: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B958C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 0000000B9590: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 0000000B9598: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 0000000B95A0: BF8903F7
	.long 0xd4c4007e                                           // 0000000B95A4: D4C4007E
	v_cndmask_b32_e32 v1, s7, v131, vcc_lo                     // 0000000B95A8: 02030607
	s_cbranch_execz 65508                                      // 0000000B95AC: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1340>
	v_add_nc_u32_e32 v130, 1, v130                             // 0000000B95B0: 4B050481
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000B95B4: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 0000000B95B8: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000B95BC: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v159, v130                        // 0000000B95C0: 7C95059F
	s_and_b32 s27, vcc_lo, exec_lo                             // 0000000B95C4: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 0000000B95C8: 8C191B19
	s_branch 65500                                             // 0000000B95CC: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1340>
	s_set_inst_prefetch_distance 0x2                           // 0000000B95D0: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000B95D4: 8C7E167E
	s_and_saveexec_b32 s22, s9                                 // 0000000B95D8: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B95DC: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 0000000B95E0: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v131                          // 0000000B95E4: 7C950607
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 0000000B95E8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B95F4: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000B95F8: 390B0B82
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000B95FC: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9600: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B9604: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9608: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B960C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9610: BF870009
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B9614: 8C7E047E
	s_and_saveexec_b32 s4, s3                                  // 0000000B9618: BE842003
	s_cbranch_execz 1030                                       // 0000000B961C: BFA50406 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2438>
	ds_load_b32 v131, v164                                     // 0000000B9620: D8D80000 830000A4
	v_and_b32_e32 v130, 1, v133                                // 0000000B9628: 37050A81
	v_cmp_le_i32_e32 vcc_lo, s2, v163                          // 0000000B962C: 7C874602
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B9630: BF870002
	.long 0xd44a0001                                           // 0000000B9634: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000B9638: 02030481
	s_and_b32 s35, vcc_lo, s1                                  // 0000000B963C: 8B23016A
	s_waitcnt lgkmcnt(0)                                       // 0000000B9640: BF89FC07
	v_mov_b32_e32 v130, v131                                   // 0000000B9644: 7F040383
	s_and_saveexec_b32 s1, s35                                 // 0000000B9648: BE812023
	s_cbranch_execz 7                                          // 0000000B964C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x146c>
	ds_load_b32 v130, v165                                     // 0000000B9650: D8D80000 820000A5
	v_max_f32_e32 v132, v131, v131                             // 0000000B9658: 21090783
	s_waitcnt lgkmcnt(0)                                       // 0000000B965C: BF89FC07
	v_max_f32_e32 v130, v130, v130                             // 0000000B9660: 21050582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9664: BF870001
	v_max_f32_e32 v130, v132, v130                             // 0000000B9668: 21050584
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B966C: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 0000000B9670: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s2, v163                          // 0000000B9674: 7C834602
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000B9678: BF8704A2
	.long 0xd44d0001                                           // 0000000B967C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B9680: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 0000000B9684: 8B22016A
	s_and_saveexec_b32 s1, s34                                 // 0000000B9688: BE812022
	s_cbranch_execz 7                                          // 0000000B968C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14ac>
	ds_load_b32 v132, v165 offset:4                            // 0000000B9690: D8D80004 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B9698: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B969C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B96A0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B96A4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B96A8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B96AC: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 0000000B96B0: 37090A84
	s_or_b32 s1, s2, 2                                         // 0000000B96B4: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B96B8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 0000000B96BC: 7C874601
	.long 0xd44d0001                                           // 0000000B96C0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B96C4: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 0000000B96C8: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B96CC: BF870009
	s_and_saveexec_b32 s1, s33                                 // 0000000B96D0: BE812021
	s_cbranch_execz 7                                          // 0000000B96D4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14f4>
	ds_load_b32 v132, v165 offset:8                            // 0000000B96D8: D8D80008 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B96E0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B96E4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B96E8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B96EC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B96F0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B96F4: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 0000000B96F8: 37090A88
	s_or_b32 s1, s2, 3                                         // 0000000B96FC: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B9700: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 0000000B9704: 7C874601
	.long 0xd44d0001                                           // 0000000B9708: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B970C: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 0000000B9710: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9714: BF870009
	s_and_saveexec_b32 s1, s31                                 // 0000000B9718: BE81201F
	s_cbranch_execz 7                                          // 0000000B971C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x153c>
	ds_load_b32 v132, v165 offset:12                           // 0000000B9720: D8D8000C 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B9728: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B972C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B9730: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9734: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B9738: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B973C: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 0000000B9740: 37090A90
	s_or_b32 s1, s2, 4                                         // 0000000B9744: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B9748: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 0000000B974C: 7C874601
	.long 0xd44d0001                                           // 0000000B9750: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B9754: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 0000000B9758: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B975C: BF870009
	s_and_saveexec_b32 s1, s30                                 // 0000000B9760: BE81201E
	s_cbranch_execz 7                                          // 0000000B9764: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1584>
	ds_load_b32 v132, v165 offset:16                           // 0000000B9768: D8D80010 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B9770: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B9774: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B9778: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B977C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B9780: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B9784: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 0000000B9788: 37090AA0
	s_or_b32 s1, s2, 5                                         // 0000000B978C: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B9790: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 0000000B9794: 7C874601
	.long 0xd44d0001                                           // 0000000B9798: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B979C: 02030880
	s_and_b32 s29, vcc_lo, s1                                  // 0000000B97A0: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B97A4: BF870009
	s_and_saveexec_b32 s1, s29                                 // 0000000B97A8: BE81201D
	s_cbranch_execz 7                                          // 0000000B97AC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15cc>
	ds_load_b32 v132, v165 offset:20                           // 0000000B97B0: D8D80014 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B97B8: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B97BC: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B97C0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B97C4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B97C8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B97CC: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 0000000B97D0: 37090AC0
	s_or_b32 s1, s2, 6                                         // 0000000B97D4: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B97D8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 0000000B97DC: 7C874601
	.long 0xd44d0001                                           // 0000000B97E0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B97E4: 02030880
	s_and_b32 s28, vcc_lo, s1                                  // 0000000B97E8: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B97EC: BF870009
	s_and_saveexec_b32 s1, s28                                 // 0000000B97F0: BE81201C
	s_cbranch_execz 7                                          // 0000000B97F4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1614>
	ds_load_b32 v132, v165 offset:24                           // 0000000B97F8: D8D80018 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B9800: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B9804: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B9808: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B980C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B9810: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B9814: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 0000000B9818: 37090AFF 00000080
	s_or_b32 s1, s2, 7                                         // 0000000B9820: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B9824: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 0000000B9828: 7C874601
	.long 0xd44d0001                                           // 0000000B982C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B9830: 02030880
	s_and_b32 s27, vcc_lo, s1                                  // 0000000B9834: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9838: BF870009
	s_and_saveexec_b32 s1, s27                                 // 0000000B983C: BE81201B
	s_cbranch_execz 7                                          // 0000000B9840: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1660>
	ds_load_b32 v132, v165 offset:28                           // 0000000B9844: D8D8001C 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B984C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B9850: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B9854: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9858: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B985C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B9860: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 0000000B9864: 37090AFF 00000100
	s_or_b32 s1, s2, 8                                         // 0000000B986C: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B9870: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 0000000B9874: 7C874601
	.long 0xd44d0001                                           // 0000000B9878: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B987C: 02030880
	s_and_b32 s26, vcc_lo, s1                                  // 0000000B9880: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9884: BF870009
	s_and_saveexec_b32 s1, s26                                 // 0000000B9888: BE81201A
	s_cbranch_execz 7                                          // 0000000B988C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16ac>
	ds_load_b32 v132, v165 offset:32                           // 0000000B9890: D8D80020 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B9898: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B989C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B98A0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B98A4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B98A8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B98AC: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 0000000B98B0: 37090AFF 00000200
	s_or_b32 s1, s2, 9                                         // 0000000B98B8: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B98BC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 0000000B98C0: 7C874601
	.long 0xd44d0001                                           // 0000000B98C4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B98C8: 02030880
	s_and_b32 s25, vcc_lo, s1                                  // 0000000B98CC: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B98D0: BF870009
	s_and_saveexec_b32 s1, s25                                 // 0000000B98D4: BE812019
	s_cbranch_execz 7                                          // 0000000B98D8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16f8>
	ds_load_b32 v132, v165 offset:36                           // 0000000B98DC: D8D80024 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B98E4: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B98E8: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B98EC: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B98F0: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B98F4: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B98F8: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 0000000B98FC: 37090AFF 00000400
	s_or_b32 s1, s2, 10                                        // 0000000B9904: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B9908: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 0000000B990C: 7C874601
	.long 0xd44d0001                                           // 0000000B9910: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B9914: 02030880
	s_and_b32 s24, vcc_lo, s1                                  // 0000000B9918: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B991C: BF870009
	s_and_saveexec_b32 s1, s24                                 // 0000000B9920: BE812018
	s_cbranch_execz 7                                          // 0000000B9924: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1744>
	ds_load_b32 v132, v165 offset:40                           // 0000000B9928: D8D80028 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B9930: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B9934: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B9938: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B993C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B9940: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B9944: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 0000000B9948: 37090AFF 00000800
	s_or_b32 s1, s2, 11                                        // 0000000B9950: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B9954: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 0000000B9958: 7C874601
	.long 0xd44d0001                                           // 0000000B995C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B9960: 02030880
	s_and_b32 s22, vcc_lo, s1                                  // 0000000B9964: 8B16016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9968: BF870009
	s_and_saveexec_b32 s1, s22                                 // 0000000B996C: BE812016
	s_cbranch_execz 7                                          // 0000000B9970: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1790>
	ds_load_b32 v132, v165 offset:44                           // 0000000B9974: D8D8002C 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B997C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B9980: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B9984: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9988: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B998C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B9990: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 0000000B9994: 37090AFF 00001000
	s_or_b32 s1, s2, 12                                        // 0000000B999C: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B99A0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 0000000B99A4: 7C874601
	.long 0xd44d0001                                           // 0000000B99A8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B99AC: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 0000000B99B0: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B99B4: BF870009
	s_and_saveexec_b32 s1, s9                                  // 0000000B99B8: BE812009
	s_cbranch_execz 7                                          // 0000000B99BC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17dc>
	ds_load_b32 v132, v165 offset:48                           // 0000000B99C0: D8D80030 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B99C8: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B99CC: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B99D0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B99D4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B99D8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B99DC: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 0000000B99E0: 37090AFF 00002000
	s_or_b32 s1, s2, 13                                        // 0000000B99E8: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B99EC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 0000000B99F0: 7C874601
	.long 0xd44d0001                                           // 0000000B99F4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B99F8: 02030880
	s_and_b32 s8, vcc_lo, s1                                   // 0000000B99FC: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9A00: BF870009
	s_and_saveexec_b32 s1, s8                                  // 0000000B9A04: BE812008
	s_cbranch_execz 7                                          // 0000000B9A08: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1828>
	ds_load_b32 v132, v165 offset:52                           // 0000000B9A0C: D8D80034 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B9A14: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B9A18: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B9A1C: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9A20: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B9A24: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B9A28: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 0000000B9A2C: 37090AFF 00004000
	s_or_b32 s1, s2, 14                                        // 0000000B9A34: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B9A38: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 0000000B9A3C: 7C874601
	.long 0xd44d0001                                           // 0000000B9A40: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B9A44: 02030880
	s_and_b32 s7, vcc_lo, s1                                   // 0000000B9A48: 8B07016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9A4C: BF870009
	s_and_saveexec_b32 s1, s7                                  // 0000000B9A50: BE812007
	s_cbranch_execz 7                                          // 0000000B9A54: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1874>
	ds_load_b32 v132, v165 offset:56                           // 0000000B9A58: D8D80038 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B9A60: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B9A64: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B9A68: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9A6C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B9A70: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000B9A74: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 0000000B9A78: 37090AFF 00008000
	s_or_b32 s2, s2, 15                                        // 0000000B9A80: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B9A84: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v163                          // 0000000B9A88: 7C874602
	.long 0xd44d0001                                           // 0000000B9A8C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000B9A90: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 0000000B9A94: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B9A98: BF870009
	s_and_saveexec_b32 s2, s1                                  // 0000000B9A9C: BE822001
	s_cbranch_execz 7                                          // 0000000B9AA0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18c0>
	ds_load_b32 v132, v165 offset:60                           // 0000000B9AA4: D8D8003C 840000A5
	v_max_f32_e32 v130, v130, v130                             // 0000000B9AAC: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000B9AB0: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000B9AB4: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9AB8: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000B9ABC: 21050982
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000B9AC0: 8C7E027E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 0000000B9AC4: CA100080 84840080
	s_and_saveexec_b32 s2, s35                                 // 0000000B9ACC: BE822023
	s_cbranch_execz 30                                         // 0000000B9AD0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x194c>
	ds_load_b32 v133, v165                                     // 0000000B9AD4: D8D80000 850000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000B9ADC: BF89FC07
	v_sub_f32_e32 v133, v133, v130                             // 0000000B9AE0: 090B0585
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9AE4: BF870091
	v_mul_f32_e32 v134, 0x3fb8aa3b, v133                       // 0000000B9AE8: 110D0AFF 3FB8AA3B
	v_fma_f32 v135, 0x3fb8aa3b, v133, -v134                    // 0000000B9AF0: D6130087 861B0AFF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 0000000B9AFC: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B9B00: BF870221
	v_sub_f32_e32 v134, v134, v136                             // 0000000B9B04: 090D1186
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 0000000B9B08: 7C370AFF C2CE8ED0
	v_fmac_f32_e32 v135, 0x32a5705f, v133                      // 0000000B9B10: 570F0AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9B18: BF870121
	v_add_f32_e32 v134, v134, v135                             // 0000000B9B1C: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 0000000B9B20: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 0000000B9B24: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9B28: BF870095
	.long 0xd71c0086                                           // 0000000B9B2C: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 0000000B9B30: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000000B9B34: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 0000000B9B38: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B9B40: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v134, vcc_lo           // 0000000B9B44: 030B0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000B9B4C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9B50: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 0000000B9B54: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 0000000B9B5C: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v166, v134                             // 0000000B9B68: DA840000 000086A6
	s_and_saveexec_b32 s2, s34                                 // 0000000B9B70: BE822022
	s_cbranch_execz 30                                         // 0000000B9B74: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19f0>
	ds_load_b32 v132, v165 offset:4                            // 0000000B9B78: D8D80004 840000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000B9B80: BF89FC07
	v_sub_f32_e32 v132, v132, v130                             // 0000000B9B84: 09090584
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9B88: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v132                       // 0000000B9B8C: 110D08FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v132                 // 0000000B9B94: 7C3708FF C2CE8ED0
	v_fma_f32 v135, 0x3fb8aa3b, v132, -v134                    // 0000000B9B9C: D6130087 861B08FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 0000000B9BA8: 7F104786
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B9BAC: BF870112
	v_fmac_f32_e32 v135, 0x32a5705f, v132                      // 0000000B9BB0: 570F08FF 32A5705F
	v_sub_f32_e32 v134, v134, v136                             // 0000000B9BB8: 090D1186
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9BBC: BF870121
	v_add_f32_e32 v134, v134, v135                             // 0000000B9BC0: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 0000000B9BC4: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 0000000B9BC8: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9BCC: BF870095
	.long 0xd71c0086                                           // 0000000B9BD0: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 0000000B9BD4: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000000B9BD8: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v132                 // 0000000B9BDC: 7C3D08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B9BE4: BF870002
	v_cndmask_b32_e32 v132, 0x7f800000, v134, vcc_lo           // 0000000B9BE8: 03090CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000B9BF0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9BF4: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 0000000B9BF8: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 0000000B9C00: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 0000000B9C04: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 0000000B9C10: 7F0C0280
	ds_store_b16_d16_hi v166, v136 offset:2                    // 0000000B9C14: DA840002 000088A6
	s_and_saveexec_b32 s2, s33                                 // 0000000B9C1C: BE822021
	s_cbranch_execz 30                                         // 0000000B9C20: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a9c>
	ds_load_b32 v135, v165 offset:8                            // 0000000B9C24: D8D80008 870000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000B9C2C: BF89FC07
	v_sub_f32_e32 v135, v135, v130                             // 0000000B9C30: 090F0587
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9C34: BF870091
	v_mul_f32_e32 v136, 0x3fb8aa3b, v135                       // 0000000B9C38: 11110EFF 3FB8AA3B
	v_fma_f32 v137, 0x3fb8aa3b, v135, -v136                    // 0000000B9C40: D6130089 86230EFF 3FB8AA3B
	v_rndne_f32_e32 v147, v136                                 // 0000000B9C4C: 7F264788
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B9C50: BF870221
	v_sub_f32_e32 v136, v136, v147                             // 0000000B9C54: 09112788
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 0000000B9C58: 7C370EFF C2CE8ED0
	v_fmac_f32_e32 v137, 0x32a5705f, v135                      // 0000000B9C60: 57130EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9C68: BF870121
	v_add_f32_e32 v136, v136, v137                             // 0000000B9C6C: 07111388
	v_cvt_i32_f32_e32 v137, v147                               // 0000000B9C70: 7F121193
	v_exp_f32_e32 v136, v136                                   // 0000000B9C74: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9C78: BF870095
	.long 0xd71c0088                                           // 0000000B9C7C: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 0000000B9C80: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000000B9C84: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 0000000B9C88: 7C3D0EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B9C90: BF870002
	v_cndmask_b32_e32 v135, 0x7f800000, v136, vcc_lo           // 0000000B9C94: 030F10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000B9C9C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9CA0: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 0000000B9CA4: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 0000000B9CAC: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v166, v136 offset:4                    // 0000000B9CB8: DA840004 000088A6
	s_and_saveexec_b32 s2, s31                                 // 0000000B9CC0: BE82201F
	s_cbranch_execz 29                                         // 0000000B9CC4: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b3c>
	ds_load_b32 v134, v165 offset:12                           // 0000000B9CC8: D8D8000C 860000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000B9CD0: BF89FC07
	v_sub_f32_e32 v134, v134, v130                             // 0000000B9CD4: 090D0586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9CD8: BF870121
	v_mul_f32_e32 v136, 0x3fb8aa3b, v134                       // 0000000B9CDC: 11110CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 0000000B9CE4: 7C370CFF C2CE8ED0
	v_fma_f32 v137, 0x3fb8aa3b, v134, -v136                    // 0000000B9CEC: D6130089 86230CFF 3FB8AA3B
	v_rndne_f32_e32 v147, v136                                 // 0000000B9CF8: 7F264788
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9CFC: BF870091
	v_dual_fmac_f32 v137, 0x32a5705f, v134 :: v_dual_sub_f32 v136, v136, v147// 0000000B9D00: C80B0CFF 89892788 32A5705F
	v_add_f32_e32 v136, v136, v137                             // 0000000B9D0C: 07111388
	v_cvt_i32_f32_e32 v137, v147                               // 0000000B9D10: 7F121193
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B9D14: BF870292
	v_exp_f32_e32 v136, v136                                   // 0000000B9D18: 7F104B88
	.long 0xd71c0088                                           // 0000000B9D1C: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 0000000B9D20: 02031388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9D24: BF870121
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000000B9D28: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 0000000B9D2C: 7C3D0CFF 42B17218
	v_cndmask_b32_e32 v134, 0x7f800000, v136, vcc_lo           // 0000000B9D34: 030D10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000B9D3C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9D40: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 0000000B9D44: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 0000000B9D4C: 7F120280
	v_add3_u32 v147, v134, v136, 0x7fff                        // 0000000B9D50: D6550093 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 0000000B9D5C: 7F100280
	ds_store_b16_d16_hi v166, v147 offset:6                    // 0000000B9D60: DA840006 000093A6
	s_and_saveexec_b32 s2, s30                                 // 0000000B9D68: BE82201E
	s_cbranch_execz 30                                         // 0000000B9D6C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1be8>
	ds_load_b32 v137, v165 offset:16                           // 0000000B9D70: D8D80010 890000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000B9D78: BF89FC07
	v_sub_f32_e32 v137, v137, v130                             // 0000000B9D7C: 09130589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9D80: BF870121
	v_mul_f32_e32 v147, 0x3fb8aa3b, v137                       // 0000000B9D84: 112712FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v137                 // 0000000B9D8C: 7C3712FF C2CE8ED0
	v_fma_f32 v148, 0x3fb8aa3b, v137, -v147                    // 0000000B9D94: D6130094 864F12FF 3FB8AA3B
	v_rndne_f32_e32 v149, v147                                 // 0000000B9DA0: 7F2A4793
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B9DA4: BF870112
	v_fmac_f32_e32 v148, 0x32a5705f, v137                      // 0000000B9DA8: 572912FF 32A5705F
	v_sub_f32_e32 v147, v147, v149                             // 0000000B9DB0: 09272B93
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9DB4: BF870121
	v_add_f32_e32 v147, v147, v148                             // 0000000B9DB8: 07272993
	v_cvt_i32_f32_e32 v148, v149                               // 0000000B9DBC: 7F281195
	v_exp_f32_e32 v147, v147                                   // 0000000B9DC0: 7F264B93
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9DC4: BF870095
	.long 0xd71c0093                                           // 0000000B9DC8: D71C0093
	v_cndmask_b32_e32 v1, v147, v148, vcc_lo                   // 0000000B9DCC: 02032993
	v_cndmask_b32_e32 v147, 0, v147, vcc_lo                    // 0000000B9DD0: 03272680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v137                 // 0000000B9DD4: 7C3D12FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B9DDC: BF870002
	v_cndmask_b32_e32 v137, 0x7f800000, v147, vcc_lo           // 0000000B9DE0: 031326FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000B9DE8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9DEC: BF870091
	v_bfe_u32 v147, v137, 16, 1                                // 0000000B9DF0: D6100093 02052189
	v_add3_u32 v147, v137, v147, 0x7fff                        // 0000000B9DF8: D6550093 03FF2789 00007FFF
	ds_store_b16_d16_hi v166, v147 offset:8                    // 0000000B9E04: DA840008 000093A6
	s_and_saveexec_b32 s2, s29                                 // 0000000B9E0C: BE82201D
	s_cbranch_execz 30                                         // 0000000B9E10: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c8c>
	ds_load_b32 v136, v165 offset:20                           // 0000000B9E14: D8D80014 880000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000B9E1C: BF89FC07
	v_sub_f32_e32 v136, v136, v130                             // 0000000B9E20: 09110588
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9E24: BF870091
	v_mul_f32_e32 v147, 0x3fb8aa3b, v136                       // 0000000B9E28: 112710FF 3FB8AA3B
	v_fma_f32 v148, 0x3fb8aa3b, v136, -v147                    // 0000000B9E30: D6130094 864F10FF 3FB8AA3B
	v_rndne_f32_e32 v149, v147                                 // 0000000B9E3C: 7F2A4793
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B9E40: BF870221
	v_sub_f32_e32 v147, v147, v149                             // 0000000B9E44: 09272B93
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 0000000B9E48: 7C3710FF C2CE8ED0
	v_fmac_f32_e32 v148, 0x32a5705f, v136                      // 0000000B9E50: 572910FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9E58: BF870121
	v_add_f32_e32 v147, v147, v148                             // 0000000B9E5C: 07272993
	v_cvt_i32_f32_e32 v148, v149                               // 0000000B9E60: 7F281195
	v_exp_f32_e32 v147, v147                                   // 0000000B9E64: 7F264B93
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9E68: BF870095
	.long 0xd71c0093                                           // 0000000B9E6C: D71C0093
	v_cndmask_b32_e32 v1, v147, v148, vcc_lo                   // 0000000B9E70: 02032993
	v_cndmask_b32_e32 v147, 0, v147, vcc_lo                    // 0000000B9E74: 03272680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 0000000B9E78: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B9E80: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v147, vcc_lo           // 0000000B9E84: 031126FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000B9E8C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9E90: BF870121
	v_bfe_u32 v147, v136, 16, 1                                // 0000000B9E94: D6100093 02052188
	v_mov_b32_e32 v148, 0                                      // 0000000B9E9C: 7F280280
	v_add3_u32 v149, v136, v147, 0x7fff                        // 0000000B9EA0: D6550095 03FF2788 00007FFF
	v_mov_b32_e32 v147, 0                                      // 0000000B9EAC: 7F260280
	ds_store_b16_d16_hi v166, v149 offset:10                   // 0000000B9EB0: DA84000A 000095A6
	s_and_saveexec_b32 s2, s28                                 // 0000000B9EB8: BE82201C
	s_cbranch_execz 30                                         // 0000000B9EBC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d38>
	ds_load_b32 v148, v165 offset:24                           // 0000000B9EC0: D8D80018 940000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000B9EC8: BF89FC07
	v_sub_f32_e32 v148, v148, v130                             // 0000000B9ECC: 09290594
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9ED0: BF870091
	v_mul_f32_e32 v149, 0x3fb8aa3b, v148                       // 0000000B9ED4: 112B28FF 3FB8AA3B
	v_fma_f32 v150, 0x3fb8aa3b, v148, -v149                    // 0000000B9EDC: D6130096 865728FF 3FB8AA3B
	v_rndne_f32_e32 v151, v149                                 // 0000000B9EE8: 7F2E4795
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B9EEC: BF870221
	v_sub_f32_e32 v149, v149, v151                             // 0000000B9EF0: 092B2F95
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 0000000B9EF4: 7C3728FF C2CE8ED0
	v_fmac_f32_e32 v150, 0x32a5705f, v148                      // 0000000B9EFC: 572D28FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9F04: BF870121
	v_add_f32_e32 v149, v149, v150                             // 0000000B9F08: 072B2D95
	v_cvt_i32_f32_e32 v150, v151                               // 0000000B9F0C: 7F2C1197
	v_exp_f32_e32 v149, v149                                   // 0000000B9F10: 7F2A4B95
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9F14: BF870095
	.long 0xd71c0095                                           // 0000000B9F18: D71C0095
	v_cndmask_b32_e32 v1, v149, v150, vcc_lo                   // 0000000B9F1C: 02032D95
	v_cndmask_b32_e32 v149, 0, v149, vcc_lo                    // 0000000B9F20: 032B2A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 0000000B9F24: 7C3D28FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B9F2C: BF870002
	v_cndmask_b32_e32 v148, 0x7f800000, v149, vcc_lo           // 0000000B9F30: 03292AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000B9F38: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9F3C: BF870091
	v_bfe_u32 v149, v148, 16, 1                                // 0000000B9F40: D6100095 02052194
	v_add3_u32 v149, v148, v149, 0x7fff                        // 0000000B9F48: D6550095 03FF2B94 00007FFF
	ds_store_b16_d16_hi v166, v149 offset:12                   // 0000000B9F54: DA84000C 000095A6
	s_and_saveexec_b32 s2, s27                                 // 0000000B9F5C: BE82201B
	s_cbranch_execz 30                                         // 0000000B9F60: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ddc>
	ds_load_b32 v147, v165 offset:28                           // 0000000B9F64: D8D8001C 930000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000B9F6C: BF89FC07
	v_sub_f32_e32 v147, v147, v130                             // 0000000B9F70: 09270593
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9F74: BF870121
	v_mul_f32_e32 v149, 0x3fb8aa3b, v147                       // 0000000B9F78: 112B26FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 0000000B9F80: 7C3726FF C2CE8ED0
	v_fma_f32 v150, 0x3fb8aa3b, v147, -v149                    // 0000000B9F88: D6130096 865726FF 3FB8AA3B
	v_rndne_f32_e32 v151, v149                                 // 0000000B9F94: 7F2E4795
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B9F98: BF870112
	v_fmac_f32_e32 v150, 0x32a5705f, v147                      // 0000000B9F9C: 572D26FF 32A5705F
	v_sub_f32_e32 v149, v149, v151                             // 0000000B9FA4: 092B2F95
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9FA8: BF870121
	v_add_f32_e32 v149, v149, v150                             // 0000000B9FAC: 072B2D95
	v_cvt_i32_f32_e32 v150, v151                               // 0000000B9FB0: 7F2C1197
	v_exp_f32_e32 v149, v149                                   // 0000000B9FB4: 7F2A4B95
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9FB8: BF870095
	.long 0xd71c0095                                           // 0000000B9FBC: D71C0095
	v_cndmask_b32_e32 v1, v149, v150, vcc_lo                   // 0000000B9FC0: 02032D95
	v_cndmask_b32_e32 v149, 0, v149, vcc_lo                    // 0000000B9FC4: 032B2A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 0000000B9FC8: 7C3D26FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B9FD0: BF870002
	v_cndmask_b32_e32 v147, 0x7f800000, v149, vcc_lo           // 0000000B9FD4: 03272AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000B9FDC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9FE0: BF870121
	v_bfe_u32 v149, v147, 16, 1                                // 0000000B9FE4: D6100095 02052193
	v_mov_b32_e32 v150, 0                                      // 0000000B9FEC: 7F2C0280
	v_add3_u32 v151, v147, v149, 0x7fff                        // 0000000B9FF0: D6550097 03FF2B93 00007FFF
	v_mov_b32_e32 v149, 0                                      // 0000000B9FFC: 7F2A0280
	ds_store_b16_d16_hi v166, v151 offset:14                   // 0000000BA000: DA84000E 000097A6
	s_and_saveexec_b32 s2, s26                                 // 0000000BA008: BE82201A
	s_cbranch_execz 30                                         // 0000000BA00C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e88>
	ds_load_b32 v150, v165 offset:32                           // 0000000BA010: D8D80020 960000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000BA018: BF89FC07
	v_sub_f32_e32 v150, v150, v130                             // 0000000BA01C: 092D0596
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA020: BF870091
	v_mul_f32_e32 v151, 0x3fb8aa3b, v150                       // 0000000BA024: 112F2CFF 3FB8AA3B
	v_fma_f32 v152, 0x3fb8aa3b, v150, -v151                    // 0000000BA02C: D6130098 865F2CFF 3FB8AA3B
	v_rndne_f32_e32 v153, v151                                 // 0000000BA038: 7F324797
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BA03C: BF870221
	v_sub_f32_e32 v151, v151, v153                             // 0000000BA040: 092F3397
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 0000000BA044: 7C372CFF C2CE8ED0
	v_fmac_f32_e32 v152, 0x32a5705f, v150                      // 0000000BA04C: 57312CFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA054: BF870121
	v_add_f32_e32 v151, v151, v152                             // 0000000BA058: 072F3197
	v_cvt_i32_f32_e32 v152, v153                               // 0000000BA05C: 7F301199
	v_exp_f32_e32 v151, v151                                   // 0000000BA060: 7F2E4B97
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA064: BF870095
	.long 0xd71c0097                                           // 0000000BA068: D71C0097
	v_cndmask_b32_e32 v1, v151, v152, vcc_lo                   // 0000000BA06C: 02033197
	v_cndmask_b32_e32 v151, 0, v151, vcc_lo                    // 0000000BA070: 032F2E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 0000000BA074: 7C3D2CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BA07C: BF870002
	v_cndmask_b32_e32 v150, 0x7f800000, v151, vcc_lo           // 0000000BA080: 032D2EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000BA088: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA08C: BF870091
	v_bfe_u32 v151, v150, 16, 1                                // 0000000BA090: D6100097 02052196
	v_add3_u32 v151, v150, v151, 0x7fff                        // 0000000BA098: D6550097 03FF2F96 00007FFF
	ds_store_b16_d16_hi v166, v151 offset:16                   // 0000000BA0A4: DA840010 000097A6
	s_and_saveexec_b32 s2, s25                                 // 0000000BA0AC: BE822019
	s_cbranch_execz 30                                         // 0000000BA0B0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f2c>
	ds_load_b32 v149, v165 offset:36                           // 0000000BA0B4: D8D80024 950000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000BA0BC: BF89FC07
	v_sub_f32_e32 v149, v149, v130                             // 0000000BA0C0: 092B0595
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA0C4: BF870121
	v_mul_f32_e32 v151, 0x3fb8aa3b, v149                       // 0000000BA0C8: 112F2AFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 0000000BA0D0: 7C372AFF C2CE8ED0
	v_fma_f32 v152, 0x3fb8aa3b, v149, -v151                    // 0000000BA0D8: D6130098 865F2AFF 3FB8AA3B
	v_rndne_f32_e32 v153, v151                                 // 0000000BA0E4: 7F324797
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BA0E8: BF870112
	v_fmac_f32_e32 v152, 0x32a5705f, v149                      // 0000000BA0EC: 57312AFF 32A5705F
	v_sub_f32_e32 v151, v151, v153                             // 0000000BA0F4: 092F3397
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA0F8: BF870121
	v_add_f32_e32 v151, v151, v152                             // 0000000BA0FC: 072F3197
	v_cvt_i32_f32_e32 v152, v153                               // 0000000BA100: 7F301199
	v_exp_f32_e32 v151, v151                                   // 0000000BA104: 7F2E4B97
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA108: BF870095
	.long 0xd71c0097                                           // 0000000BA10C: D71C0097
	v_cndmask_b32_e32 v1, v151, v152, vcc_lo                   // 0000000BA110: 02033197
	v_cndmask_b32_e32 v151, 0, v151, vcc_lo                    // 0000000BA114: 032F2E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 0000000BA118: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BA120: BF870002
	v_cndmask_b32_e32 v149, 0x7f800000, v151, vcc_lo           // 0000000BA124: 032B2EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000BA12C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA130: BF870121
	v_bfe_u32 v151, v149, 16, 1                                // 0000000BA134: D6100097 02052195
	v_mov_b32_e32 v152, 0                                      // 0000000BA13C: 7F300280
	v_add3_u32 v153, v149, v151, 0x7fff                        // 0000000BA140: D6550099 03FF2F95 00007FFF
	v_mov_b32_e32 v151, 0                                      // 0000000BA14C: 7F2E0280
	ds_store_b16_d16_hi v166, v153 offset:18                   // 0000000BA150: DA840012 000099A6
	s_and_saveexec_b32 s2, s24                                 // 0000000BA158: BE822018
	s_cbranch_execz 30                                         // 0000000BA15C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1fd8>
	ds_load_b32 v152, v165 offset:40                           // 0000000BA160: D8D80028 980000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000BA168: BF89FC07
	v_sub_f32_e32 v152, v152, v130                             // 0000000BA16C: 09310598
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA170: BF870091
	v_mul_f32_e32 v153, 0x3fb8aa3b, v152                       // 0000000BA174: 113330FF 3FB8AA3B
	v_fma_f32 v154, 0x3fb8aa3b, v152, -v153                    // 0000000BA17C: D613009A 866730FF 3FB8AA3B
	v_rndne_f32_e32 v177, v153                                 // 0000000BA188: 7F624799
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BA18C: BF870221
	v_sub_f32_e32 v153, v153, v177                             // 0000000BA190: 09336399
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 0000000BA194: 7C3730FF C2CE8ED0
	v_fmac_f32_e32 v154, 0x32a5705f, v152                      // 0000000BA19C: 573530FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA1A4: BF870121
	v_add_f32_e32 v153, v153, v154                             // 0000000BA1A8: 07333599
	v_cvt_i32_f32_e32 v154, v177                               // 0000000BA1AC: 7F3411B1
	v_exp_f32_e32 v153, v153                                   // 0000000BA1B0: 7F324B99
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA1B4: BF870095
	.long 0xd71c0099                                           // 0000000BA1B8: D71C0099
	v_cndmask_b32_e32 v1, v153, v154, vcc_lo                   // 0000000BA1BC: 02033599
	v_cndmask_b32_e32 v153, 0, v153, vcc_lo                    // 0000000BA1C0: 03333280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 0000000BA1C4: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BA1CC: BF870002
	v_cndmask_b32_e32 v152, 0x7f800000, v153, vcc_lo           // 0000000BA1D0: 033132FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000BA1D8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA1DC: BF870091
	v_bfe_u32 v153, v152, 16, 1                                // 0000000BA1E0: D6100099 02052198
	v_add3_u32 v153, v152, v153, 0x7fff                        // 0000000BA1E8: D6550099 03FF3398 00007FFF
	ds_store_b16_d16_hi v166, v153 offset:20                   // 0000000BA1F4: DA840014 000099A6
	s_and_saveexec_b32 s2, s22                                 // 0000000BA1FC: BE822016
	s_cbranch_execz 29                                         // 0000000BA200: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2078>
	ds_load_b32 v151, v165 offset:44                           // 0000000BA204: D8D8002C 970000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000BA20C: BF89FC07
	v_sub_f32_e32 v151, v151, v130                             // 0000000BA210: 092F0597
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA214: BF870121
	v_mul_f32_e32 v153, 0x3fb8aa3b, v151                       // 0000000BA218: 11332EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 0000000BA220: 7C372EFF C2CE8ED0
	v_fma_f32 v154, 0x3fb8aa3b, v151, -v153                    // 0000000BA228: D613009A 86672EFF 3FB8AA3B
	v_rndne_f32_e32 v177, v153                                 // 0000000BA234: 7F624799
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA238: BF870091
	v_dual_fmac_f32 v154, 0x32a5705f, v151 :: v_dual_sub_f32 v153, v153, v177// 0000000BA23C: C80B2EFF 9A996399 32A5705F
	v_add_f32_e32 v153, v153, v154                             // 0000000BA248: 07333599
	v_cvt_i32_f32_e32 v154, v177                               // 0000000BA24C: 7F3411B1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BA250: BF870292
	v_exp_f32_e32 v153, v153                                   // 0000000BA254: 7F324B99
	.long 0xd71c0099                                           // 0000000BA258: D71C0099
	v_cndmask_b32_e32 v1, v153, v154, vcc_lo                   // 0000000BA25C: 02033599
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA260: BF870121
	v_cndmask_b32_e32 v153, 0, v153, vcc_lo                    // 0000000BA264: 03333280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 0000000BA268: 7C3D2EFF 42B17218
	v_cndmask_b32_e32 v151, 0x7f800000, v153, vcc_lo           // 0000000BA270: 032F32FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000BA278: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA27C: BF870121
	v_bfe_u32 v153, v151, 16, 1                                // 0000000BA280: D6100099 02052197
	v_mov_b32_e32 v154, 0                                      // 0000000BA288: 7F340280
	v_add3_u32 v177, v151, v153, 0x7fff                        // 0000000BA28C: D65500B1 03FF3397 00007FFF
	v_mov_b32_e32 v153, 0                                      // 0000000BA298: 7F320280
	ds_store_b16_d16_hi v166, v177 offset:22                   // 0000000BA29C: DA840016 0000B1A6
	s_and_saveexec_b32 s2, s9                                  // 0000000BA2A4: BE822009
	s_cbranch_execz 30                                         // 0000000BA2A8: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2124>
	ds_load_b32 v154, v165 offset:48                           // 0000000BA2AC: D8D80030 9A0000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000BA2B4: BF89FC07
	v_sub_f32_e32 v154, v154, v130                             // 0000000BA2B8: 0935059A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA2BC: BF870091
	v_mul_f32_e32 v177, 0x3fb8aa3b, v154                       // 0000000BA2C0: 116334FF 3FB8AA3B
	v_fma_f32 v178, 0x3fb8aa3b, v154, -v177                    // 0000000BA2C8: D61300B2 86C734FF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 0000000BA2D4: 7F6647B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BA2D8: BF870221
	v_sub_f32_e32 v177, v177, v179                             // 0000000BA2DC: 096367B1
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v154                 // 0000000BA2E0: 7C3734FF C2CE8ED0
	v_fmac_f32_e32 v178, 0x32a5705f, v154                      // 0000000BA2E8: 576534FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA2F0: BF870121
	v_add_f32_e32 v177, v177, v178                             // 0000000BA2F4: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 0000000BA2F8: 7F6411B3
	v_exp_f32_e32 v177, v177                                   // 0000000BA2FC: 7F624BB1
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA300: BF870095
	.long 0xd71c00b1                                           // 0000000BA304: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 0000000BA308: 020365B1
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 0000000BA30C: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v154                 // 0000000BA310: 7C3D34FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BA318: BF870002
	v_cndmask_b32_e32 v154, 0x7f800000, v177, vcc_lo           // 0000000BA31C: 033562FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000BA324: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA328: BF870091
	v_bfe_u32 v177, v154, 16, 1                                // 0000000BA32C: D61000B1 0205219A
	v_add3_u32 v177, v154, v177, 0x7fff                        // 0000000BA334: D65500B1 03FF639A 00007FFF
	ds_store_b16_d16_hi v166, v177 offset:24                   // 0000000BA340: DA840018 0000B1A6
	s_and_saveexec_b32 s2, s8                                  // 0000000BA348: BE822008
	s_cbranch_execz 29                                         // 0000000BA34C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21c4>
	ds_load_b32 v153, v165 offset:52                           // 0000000BA350: D8D80034 990000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000BA358: BF89FC07
	v_sub_f32_e32 v153, v153, v130                             // 0000000BA35C: 09330599
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA360: BF870121
	v_mul_f32_e32 v177, 0x3fb8aa3b, v153                       // 0000000BA364: 116332FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 0000000BA36C: 7C3732FF C2CE8ED0
	v_fma_f32 v178, 0x3fb8aa3b, v153, -v177                    // 0000000BA374: D61300B2 86C732FF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 0000000BA380: 7F6647B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA384: BF870091
	v_dual_fmac_f32 v178, 0x32a5705f, v153 :: v_dual_sub_f32 v177, v177, v179// 0000000BA388: C80B32FF B2B167B1 32A5705F
	v_add_f32_e32 v177, v177, v178                             // 0000000BA394: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 0000000BA398: 7F6411B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BA39C: BF870292
	v_exp_f32_e32 v177, v177                                   // 0000000BA3A0: 7F624BB1
	.long 0xd71c00b1                                           // 0000000BA3A4: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 0000000BA3A8: 020365B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA3AC: BF870121
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 0000000BA3B0: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 0000000BA3B4: 7C3D32FF 42B17218
	v_cndmask_b32_e32 v153, 0x7f800000, v177, vcc_lo           // 0000000BA3BC: 033362FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000BA3C4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA3C8: BF870121
	v_bfe_u32 v177, v153, 16, 1                                // 0000000BA3CC: D61000B1 02052199
	v_mov_b32_e32 v178, 0                                      // 0000000BA3D4: 7F640280
	v_add3_u32 v179, v153, v177, 0x7fff                        // 0000000BA3D8: D65500B3 03FF6399 00007FFF
	v_mov_b32_e32 v177, 0                                      // 0000000BA3E4: 7F620280
	ds_store_b16_d16_hi v166, v179 offset:26                   // 0000000BA3E8: DA84001A 0000B3A6
	s_and_saveexec_b32 s2, s7                                  // 0000000BA3F0: BE822007
	s_cbranch_execz 30                                         // 0000000BA3F4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2270>
	ds_load_b32 v178, v165 offset:56                           // 0000000BA3F8: D8D80038 B20000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000BA400: BF89FC07
	v_sub_f32_e32 v178, v178, v130                             // 0000000BA404: 096505B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA408: BF870091
	v_mul_f32_e32 v179, 0x3fb8aa3b, v178                       // 0000000BA40C: 116764FF 3FB8AA3B
	v_fma_f32 v180, 0x3fb8aa3b, v178, -v179                    // 0000000BA414: D61300B4 86CF64FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000BA420: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BA424: BF870221
	v_sub_f32_e32 v179, v179, v181                             // 0000000BA428: 09676BB3
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 0000000BA42C: 7C3764FF C2CE8ED0
	v_fmac_f32_e32 v180, 0x32a5705f, v178                      // 0000000BA434: 576964FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA43C: BF870121
	v_add_f32_e32 v179, v179, v180                             // 0000000BA440: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000BA444: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 0000000BA448: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA44C: BF870095
	.long 0xd71c00b3                                           // 0000000BA450: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000BA454: 020369B3
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000BA458: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 0000000BA45C: 7C3D64FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BA464: BF870002
	v_cndmask_b32_e32 v178, 0x7f800000, v179, vcc_lo           // 0000000BA468: 036566FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000BA470: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA474: BF870091
	v_bfe_u32 v179, v178, 16, 1                                // 0000000BA478: D61000B3 020521B2
	v_add3_u32 v179, v178, v179, 0x7fff                        // 0000000BA480: D65500B3 03FF67B2 00007FFF
	ds_store_b16_d16_hi v166, v179 offset:28                   // 0000000BA48C: DA84001C 0000B3A6
	s_and_saveexec_b32 s2, s1                                  // 0000000BA494: BE822001
	s_cbranch_execz 30                                         // 0000000BA498: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2314>
	ds_load_b32 v177, v165 offset:60                           // 0000000BA49C: D8D8003C B10000A5
	s_waitcnt lgkmcnt(0)                                       // 0000000BA4A4: BF89FC07
	v_sub_f32_e32 v177, v177, v130                             // 0000000BA4A8: 096305B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA4AC: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v177                       // 0000000BA4B0: 116762FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v177                 // 0000000BA4B8: 7C3762FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v177, -v179                    // 0000000BA4C0: D61300B4 86CF62FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000BA4CC: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BA4D0: BF870112
	v_fmac_f32_e32 v180, 0x32a5705f, v177                      // 0000000BA4D4: 576962FF 32A5705F
	v_sub_f32_e32 v179, v179, v181                             // 0000000BA4DC: 09676BB3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA4E0: BF870121
	v_add_f32_e32 v179, v179, v180                             // 0000000BA4E4: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000BA4E8: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 0000000BA4EC: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA4F0: BF870095
	.long 0xd71c00b3                                           // 0000000BA4F4: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000BA4F8: 020369B3
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000BA4FC: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v177                 // 0000000BA500: 7C3D62FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BA508: BF870002
	v_cndmask_b32_e32 v177, 0x7f800000, v179, vcc_lo           // 0000000BA50C: 036366FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000BA514: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA518: BF8700A1
	v_bfe_u32 v179, v177, 16, 1                                // 0000000BA51C: D61000B3 020521B1
	s_mov_b32 s1, exec_lo                                      // 0000000BA524: BE81007E
	v_add3_u32 v180, v177, v179, 0x7fff                        // 0000000BA528: D65500B4 03FF67B1 00007FFF
	v_mov_b32_e32 v179, 0                                      // 0000000BA534: 7F660280
	ds_store_b16_d16_hi v166, v180 offset:30                   // 0000000BA538: DA84001E 0000B4A6
	v_cmpx_lt_f32_e32 0xefa18f08, v131                         // 0000000BA540: 7D2306FF EFA18F08
	s_cbranch_execz 26                                         // 0000000BA548: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x23b4>
	v_sub_f32_e32 v131, v131, v130                             // 0000000BA54C: 09070583
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA550: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v131                       // 0000000BA554: 116706FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 0000000BA55C: 7C3706FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v131, -v179                    // 0000000BA564: D61300B4 86CF06FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000BA570: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA574: BF870091
	v_dual_fmac_f32 v180, 0x32a5705f, v131 :: v_dual_sub_f32 v179, v179, v181// 0000000BA578: C80B06FF B4B36BB3 32A5705F
	v_add_f32_e32 v179, v179, v180                             // 0000000BA584: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000BA588: 7F6811B5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BA58C: BF870292
	v_exp_f32_e32 v179, v179                                   // 0000000BA590: 7F664BB3
	.long 0xd71c00b3                                           // 0000000BA594: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000BA598: 020369B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA59C: BF870121
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000BA5A0: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 0000000BA5A4: 7C3D06FF 42B17218
	v_cndmask_b32_e32 v179, 0x7f800000, v179, vcc_lo           // 0000000BA5AC: 036766FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000BA5B4: 8C7E017E
	v_add_f32_e32 v131, v133, v132                             // 0000000BA5B8: 07070985
	ds_load_b32 v132, v167                                     // 0000000BA5BC: D8D80000 840000A7
	v_add_f32_e32 v131, v131, v135                             // 0000000BA5C4: 07070F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA5C8: BF870091
	v_add_f32_e32 v131, v131, v134                             // 0000000BA5CC: 07070D83
	v_add_f32_e32 v131, v131, v137                             // 0000000BA5D0: 07071383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA5D4: BF870091
	v_add_f32_e32 v131, v131, v136                             // 0000000BA5D8: 07071183
	v_add_f32_e32 v131, v131, v148                             // 0000000BA5DC: 07072983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA5E0: BF870091
	v_add_f32_e32 v131, v131, v147                             // 0000000BA5E4: 07072783
	v_add_f32_e32 v131, v131, v150                             // 0000000BA5E8: 07072D83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA5EC: BF870091
	v_add_f32_e32 v131, v131, v149                             // 0000000BA5F0: 07072B83
	v_add_f32_e32 v131, v131, v152                             // 0000000BA5F4: 07073183
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA5F8: BF870091
	v_add_f32_e32 v131, v131, v151                             // 0000000BA5FC: 07072F83
	v_add_f32_e32 v131, v131, v154                             // 0000000BA600: 07073583
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA604: BF870091
	v_add_f32_e32 v131, v131, v153                             // 0000000BA608: 07073383
	v_add_f32_e32 v131, v131, v178                             // 0000000BA60C: 07076583
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA610: BF8700A1
	v_add_f32_e32 v131, v131, v177                             // 0000000BA614: 07076383
	s_waitcnt lgkmcnt(0)                                       // 0000000BA618: BF89FC07
	v_fmac_f32_e32 v131, v179, v132                            // 0000000BA61C: 570709B3
	ds_store_b32 v164, v130                                    // 0000000BA620: D8340000 000082A4
	ds_store_b32 v167, v131                                    // 0000000BA628: D8340000 000083A7
	ds_store_b32 v168, v179                                    // 0000000BA630: D8340000 0000B3A8
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BA638: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000BA63C: BF89FC07
	s_barrier                                                  // 0000000BA640: BFBD0000
	buffer_gl0_inv                                             // 0000000BA644: E0AC0000 00000000
	ds_load_2addr_b32 v[153:154], v169 offset1:2               // 0000000BA64C: D8DC0200 990000A9
	ds_load_2addr_b32 v[151:152], v169 offset0:4 offset1:6     // 0000000BA654: D8DC0604 970000A9
	ds_load_2addr_b32 v[149:150], v169 offset0:8 offset1:10    // 0000000BA65C: D8DC0A08 950000A9
	ds_load_2addr_b32 v[147:148], v169 offset0:12 offset1:14   // 0000000BA664: D8DC0E0C 930000A9
	s_waitcnt lgkmcnt(3)                                       // 0000000BA66C: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v153                         // 0000000BA670: 7C2532F2
	.long 0xd4120001                                           // 0000000BA674: D4120001
	v_cndmask_b32_e32 v1, 1.0, v154, vcc_lo                    // 0000000BA678: 020334F2
	s_waitcnt lgkmcnt(2)                                       // 0000000BA67C: BF89FC27
	.long 0xd4120002                                           // 0000000BA680: D4120002
	v_cndmask_b32_e32 v1, 1.0, v151, vcc_lo                    // 0000000BA684: 02032EF2
	.long 0xd4120004                                           // 0000000BA688: D4120004
	v_cndmask_b32_e32 v1, 1.0, v152, vcc_lo                    // 0000000BA68C: 020330F2
	s_and_b32 s1, vcc_lo, s1                                   // 0000000BA690: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 0000000BA694: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v149                         // 0000000BA698: 7C252AF2
	s_and_b32 s2, s1, s2                                       // 0000000BA69C: 8B020201
	.long 0xd4120001                                           // 0000000BA6A0: D4120001
	v_cndmask_b32_e32 v1, 1.0, v150, vcc_lo                    // 0000000BA6A4: 02032CF2
	s_and_b32 s4, s2, s4                                       // 0000000BA6A8: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 0000000BA6AC: BF89FC07
	.long 0xd4120002                                           // 0000000BA6B0: D4120002
	v_cndmask_b32_e32 v1, 1.0, v147, vcc_lo                    // 0000000BA6B4: 020326F2
	s_and_b32 s4, s4, vcc_lo                                   // 0000000BA6B8: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v148                         // 0000000BA6BC: 7C2528F2
	s_and_b32 s1, s4, s1                                       // 0000000BA6C0: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000BA6C4: BF870499
	s_and_b32 s1, s1, s2                                       // 0000000BA6C8: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 0000000BA6CC: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA6D0: BF870099
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 0000000BA6D4: D5010082 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v130                           // 0000000BA6DC: 7C9B0480
	ds_load_b128 v[130:133], v170                              // 0000000BA6E0: DBFC0000 820000AA
	ds_load_b128 v[134:137], v170 offset:16                    // 0000000BA6E8: DBFC0010 860000AA
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 0000000BA6F0: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 0000000BA6F4: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA6F8: BF870099
	v_cndmask_b32_e64 v177, 0, 1, s1                           // 0000000BA6FC: D50100B1 00050280
	v_readfirstlane_b32 s1, v177                               // 0000000BA704: 7E0205B1
	s_bitcmp1_b32 s1, 0                                        // 0000000BA708: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 0000000BA70C: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000BA710: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 0000000BA714: 8B6A017E
	s_cbranch_vccnz 63628                                      // 0000000BA718: BFA4F88C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x74c>
	v_dual_mul_f32 v121, v153, v121 :: v_dual_mul_f32 v122, v154, v122// 0000000BA71C: C8C6F399 797AF59A
	v_dual_mul_f32 v123, v151, v123 :: v_dual_mul_f32 v124, v152, v124// 0000000BA724: C8C6F797 7B7CF998
	v_dual_mul_f32 v125, v149, v125 :: v_dual_mul_f32 v126, v150, v126// 0000000BA72C: C8C6FB95 7D7EFD96
	v_dual_mul_f32 v127, v147, v127 :: v_dual_mul_f32 v128, v148, v128// 0000000BA734: C8C6FF93 7F810194
	v_dual_mul_f32 v113, v153, v113 :: v_dual_mul_f32 v114, v154, v114// 0000000BA73C: C8C6E399 7172E59A
	v_dual_mul_f32 v115, v151, v115 :: v_dual_mul_f32 v116, v152, v116// 0000000BA744: C8C6E797 7374E998
	v_dual_mul_f32 v117, v149, v117 :: v_dual_mul_f32 v118, v150, v118// 0000000BA74C: C8C6EB95 7576ED96
	v_dual_mul_f32 v119, v147, v119 :: v_dual_mul_f32 v120, v148, v120// 0000000BA754: C8C6EF93 7778F194
	v_dual_mul_f32 v105, v153, v105 :: v_dual_mul_f32 v106, v154, v106// 0000000BA75C: C8C6D399 696AD59A
	v_dual_mul_f32 v107, v151, v107 :: v_dual_mul_f32 v108, v152, v108// 0000000BA764: C8C6D797 6B6CD998
	v_dual_mul_f32 v109, v149, v109 :: v_dual_mul_f32 v110, v150, v110// 0000000BA76C: C8C6DB95 6D6EDD96
	v_dual_mul_f32 v111, v147, v111 :: v_dual_mul_f32 v112, v148, v112// 0000000BA774: C8C6DF93 6F70E194
	v_dual_mul_f32 v97, v153, v97 :: v_dual_mul_f32 v98, v154, v98// 0000000BA77C: C8C6C399 6162C59A
	v_dual_mul_f32 v99, v151, v99 :: v_dual_mul_f32 v100, v152, v100// 0000000BA784: C8C6C797 6364C998
	v_dual_mul_f32 v101, v149, v101 :: v_dual_mul_f32 v102, v150, v102// 0000000BA78C: C8C6CB95 6566CD96
	v_dual_mul_f32 v103, v147, v103 :: v_dual_mul_f32 v104, v148, v104// 0000000BA794: C8C6CF93 6768D194
	v_dual_mul_f32 v89, v153, v89 :: v_dual_mul_f32 v90, v154, v90// 0000000BA79C: C8C6B399 595AB59A
	v_dual_mul_f32 v91, v151, v91 :: v_dual_mul_f32 v92, v152, v92// 0000000BA7A4: C8C6B797 5B5CB998
	v_dual_mul_f32 v93, v149, v93 :: v_dual_mul_f32 v94, v150, v94// 0000000BA7AC: C8C6BB95 5D5EBD96
	v_dual_mul_f32 v95, v147, v95 :: v_dual_mul_f32 v96, v148, v96// 0000000BA7B4: C8C6BF93 5F60C194
	v_dual_mul_f32 v81, v153, v81 :: v_dual_mul_f32 v82, v154, v82// 0000000BA7BC: C8C6A399 5152A59A
	v_dual_mul_f32 v83, v151, v83 :: v_dual_mul_f32 v84, v152, v84// 0000000BA7C4: C8C6A797 5354A998
	v_dual_mul_f32 v85, v149, v85 :: v_dual_mul_f32 v86, v150, v86// 0000000BA7CC: C8C6AB95 5556AD96
	v_dual_mul_f32 v87, v147, v87 :: v_dual_mul_f32 v88, v148, v88// 0000000BA7D4: C8C6AF93 5758B194
	v_dual_mul_f32 v73, v153, v73 :: v_dual_mul_f32 v74, v154, v74// 0000000BA7DC: C8C69399 494A959A
	v_dual_mul_f32 v75, v151, v75 :: v_dual_mul_f32 v76, v152, v76// 0000000BA7E4: C8C69797 4B4C9998
	v_dual_mul_f32 v77, v149, v77 :: v_dual_mul_f32 v78, v150, v78// 0000000BA7EC: C8C69B95 4D4E9D96
	v_dual_mul_f32 v79, v147, v79 :: v_dual_mul_f32 v80, v148, v80// 0000000BA7F4: C8C69F93 4F50A194
	v_dual_mul_f32 v65, v153, v65 :: v_dual_mul_f32 v66, v154, v66// 0000000BA7FC: C8C68399 4142859A
	v_dual_mul_f32 v67, v151, v67 :: v_dual_mul_f32 v68, v152, v68// 0000000BA804: C8C68797 43448998
	v_dual_mul_f32 v69, v149, v69 :: v_dual_mul_f32 v70, v150, v70// 0000000BA80C: C8C68B95 45468D96
	v_dual_mul_f32 v71, v147, v71 :: v_dual_mul_f32 v72, v148, v72// 0000000BA814: C8C68F93 47489194
	v_dual_mul_f32 v57, v153, v57 :: v_dual_mul_f32 v58, v154, v58// 0000000BA81C: C8C67399 393A759A
	v_dual_mul_f32 v59, v151, v59 :: v_dual_mul_f32 v60, v152, v60// 0000000BA824: C8C67797 3B3C7998
	v_dual_mul_f32 v61, v149, v61 :: v_dual_mul_f32 v62, v150, v62// 0000000BA82C: C8C67B95 3D3E7D96
	v_dual_mul_f32 v63, v147, v63 :: v_dual_mul_f32 v64, v148, v64// 0000000BA834: C8C67F93 3F408194
	v_dual_mul_f32 v49, v153, v49 :: v_dual_mul_f32 v50, v154, v50// 0000000BA83C: C8C66399 3132659A
	v_dual_mul_f32 v51, v151, v51 :: v_dual_mul_f32 v52, v152, v52// 0000000BA844: C8C66797 33346998
	v_dual_mul_f32 v53, v149, v53 :: v_dual_mul_f32 v54, v150, v54// 0000000BA84C: C8C66B95 35366D96
	v_dual_mul_f32 v55, v147, v55 :: v_dual_mul_f32 v56, v148, v56// 0000000BA854: C8C66F93 37387194
	v_dual_mul_f32 v41, v153, v41 :: v_dual_mul_f32 v42, v154, v42// 0000000BA85C: C8C65399 292A559A
	v_dual_mul_f32 v43, v151, v43 :: v_dual_mul_f32 v44, v152, v44// 0000000BA864: C8C65797 2B2C5998
	v_dual_mul_f32 v45, v149, v45 :: v_dual_mul_f32 v46, v150, v46// 0000000BA86C: C8C65B95 2D2E5D96
	v_dual_mul_f32 v47, v147, v47 :: v_dual_mul_f32 v48, v148, v48// 0000000BA874: C8C65F93 2F306194
	v_dual_mul_f32 v33, v153, v33 :: v_dual_mul_f32 v34, v154, v34// 0000000BA87C: C8C64399 2122459A
	v_dual_mul_f32 v35, v151, v35 :: v_dual_mul_f32 v36, v152, v36// 0000000BA884: C8C64797 23244998
	v_dual_mul_f32 v37, v149, v37 :: v_dual_mul_f32 v38, v150, v38// 0000000BA88C: C8C64B95 25264D96
	v_dual_mul_f32 v39, v147, v39 :: v_dual_mul_f32 v40, v148, v40// 0000000BA894: C8C64F93 27285194
	v_dual_mul_f32 v25, v153, v25 :: v_dual_mul_f32 v26, v154, v26// 0000000BA89C: C8C63399 191A359A
	v_dual_mul_f32 v27, v151, v27 :: v_dual_mul_f32 v28, v152, v28// 0000000BA8A4: C8C63797 1B1C3998
	v_dual_mul_f32 v29, v149, v29 :: v_dual_mul_f32 v30, v150, v30// 0000000BA8AC: C8C63B95 1D1E3D96
	v_dual_mul_f32 v31, v147, v31 :: v_dual_mul_f32 v32, v148, v32// 0000000BA8B4: C8C63F93 1F204194
	v_dual_mul_f32 v17, v153, v17 :: v_dual_mul_f32 v18, v154, v18// 0000000BA8BC: C8C62399 1112259A
	v_dual_mul_f32 v19, v151, v19 :: v_dual_mul_f32 v20, v152, v20// 0000000BA8C4: C8C62797 13142998
	v_dual_mul_f32 v21, v149, v21 :: v_dual_mul_f32 v22, v150, v22// 0000000BA8CC: C8C62B95 15162D96
	v_dual_mul_f32 v23, v147, v23 :: v_dual_mul_f32 v24, v148, v24// 0000000BA8D4: C8C62F93 17183194
	v_dual_mul_f32 v9, v153, v9 :: v_dual_mul_f32 v10, v154, v10// 0000000BA8DC: C8C61399 090A159A
	v_dual_mul_f32 v11, v151, v11 :: v_dual_mul_f32 v12, v152, v12// 0000000BA8E4: C8C61797 0B0C1998
	v_dual_mul_f32 v13, v149, v13 :: v_dual_mul_f32 v14, v150, v14// 0000000BA8EC: C8C61B95 0D0E1D96
	v_dual_mul_f32 v15, v147, v15 :: v_dual_mul_f32 v16, v148, v16// 0000000BA8F4: C8C61F93 0F102194
	v_dual_mul_f32 v1, v153, v1 :: v_dual_mul_f32 v2, v154, v2 // 0000000BA8FC: C8C60399 0102059A
	v_dual_mul_f32 v3, v151, v3 :: v_dual_mul_f32 v4, v152, v4 // 0000000BA904: C8C60797 03040998
	v_dual_mul_f32 v5, v149, v5 :: v_dual_mul_f32 v6, v150, v6 // 0000000BA90C: C8C60B95 05060D96
	v_dual_mul_f32 v7, v147, v7 :: v_dual_mul_f32 v8, v148, v8 // 0000000BA914: C8C60F93 07081194
	s_branch 63499                                             // 0000000BA91C: BFA0F80B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x74c>
	v_lshlrev_b32_e32 v0, 2, v158                              // 0000000BA920: 30013C82
	.long 0xd700008b                                           // 0000000BA924: D700008B
	v_cndmask_b32_e32 v1, s18, v139, vcc_lo                    // 0000000BA928: 02031612
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000BA92C: BF870191
	v_add_co_ci_u32_e64 v140, null, s19, v140, s0              // 0000000BA930: D5207C8C 00031813
	v_lshl_or_b32 v0, v157, 6, v0                              // 0000000BA938: D6560000 04010D9D
	v_lshlrev_b32_e32 v147, 1, v155                            // 0000000BA940: 31273681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000000BA944: BF870152
	v_add_nc_u32_e32 v133, 0xa000, v0                          // 0000000BA948: 4B0A00FF 0000A000
	ds_load_2addr_b32 v[141:142], v133 offset0:128 offset1:130 // 0000000BA950: D8DC8280 8D000085
	s_waitcnt lgkmcnt(0)                                       // 0000000BA958: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 0000000BA95C: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 0000000BA964: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 0000000BA96C: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000000BA970: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 0000000BA974: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 0000000BA97C: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:132 offset1:134 // 0000000BA980: D8DC8684 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:136 offset1:138 // 0000000BA988: D8DC8A88 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:140 offset1:142 // 0000000BA990: D8DC8E8C 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 0000000BA998: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000BA99C: 3505029F
	v_or_b32_e32 v0, v156, v158                                // 0000000BA9A0: 38013D9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000BA9A4: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 0000000BA9A8: 11252191
	.long 0xd73c0083                                           // 0000000BA9AC: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000000BA9B0: 02030281
	.long 0xd7000081                                           // 0000000BA9B4: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 0000000BA9B8: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000BA9BC: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 0000000BA9C0: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 0000000BA9C8: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA9D0: BF870094
	.long 0xd7000083                                           // 0000000BA9D4: D7000083
	v_cndmask_b32_e32 v1, s16, v131, vcc_lo                    // 0000000BA9D8: 02030610
	v_add_co_ci_u32_e64 v132, null, s17, v132, s0              // 0000000BA9DC: D5207C84 00030811
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA9E4: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 0000000BA9E8: 57252194
	.long 0xd4440000                                           // 0000000BA9EC: D4440000
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 0000000BA9F0: 0202000E
	v_fma_f32 v139, -v143, v146, v145                          // 0000000BA9F4: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA9FC: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 0000000BAA00: D637008B 064B218B
	.long 0xd7006a83                                           // 0000000BAA08: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 0000000BAA0C: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 0000000BAA10: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000BAA18: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 0000000BAA1C: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 0000000BAA24: BE812000
	s_cbranch_execz 70                                         // 0000000BAA28: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2944>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BAA2C: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 0000000BAA30: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 0000000BAA3C: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 0000000BAA40: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 0000000BAA48: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 0000000BAA4C: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAA50: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 0000000BAA54: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 0000000BAA5C: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 0000000BAA68: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BAA6C: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 0000000BAA70: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 0000000BAA78: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000BAA7C: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 0000000BAA80: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 0000000BAA84: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 0000000BAA88: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 0000000BAA90: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAA94: BF870095
	.long 0xd71c008d                                           // 0000000BAA98: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 0000000BAA9C: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000BAAA0: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 0000000BAAA4: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAAAC: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 0000000BAAB0: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 0000000BAAB8: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAABC: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 0000000BAAC0: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 0000000BAAC8: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAACC: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 0000000BAAD0: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 0000000BAAD8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 0000000BAADC: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAAE4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000BAAE8: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 0000000BAAEC: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAAF4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000BAAF8: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 0000000BAAFC: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAB04: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 0000000BAB08: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 0000000BAB10: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 0000000BAB18: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAB24: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 0000000BAB28: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 0000000BAB30: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 0000000BAB3C: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000BAB44: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 0000000BAB48: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 0000000BAB50: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BAB58: BF870292
	v_rcp_f32_e32 v140, v121                                   // 0000000BAB5C: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 0000000BAB60: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAB68: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 0000000BAB6C: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 0000000BAB70: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAB74: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 0000000BAB78: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 0000000BAB80: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAB84: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 0000000BAB88: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 0000000BAB90: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 0000000BAB98: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BAB9C: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 0000000BABA0: D627008C 03CB1D8C
	.long 0xd4440001                                           // 0000000BABA8: D4440001
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 0000000BABAC: 0202F20E
	s_and_saveexec_b32 s2, s1                                  // 0000000BABB0: BE822001
	s_cbranch_execz 69                                         // 0000000BABB4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2acc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000000BABB8: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 0000000BABC4: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 0000000BABC8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000BABD0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000BABD4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BABD8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000BABDC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000BABE4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000BABF0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BABF4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000BABF8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000BABFC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000BAC04: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BAC0C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000BAC10: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000BAC14: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000BAC18: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAC1C: BF870095
	.long 0xd71c008e                                           // 0000000BAC20: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000BAC24: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000BAC28: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000BAC2C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAC34: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000BAC38: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000BAC40: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAC44: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 0000000BAC48: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000BAC50: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAC54: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000BAC58: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000BAC60: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 0000000BAC64: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAC6C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000BAC70: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000BAC74: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAC7C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000BAC80: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000BAC84: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAC8C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000BAC90: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 0000000BAC98: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 0000000BACA0: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BACAC: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 0000000BACB0: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 0000000BACB8: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 0000000BACC4: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000BACCC: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 0000000BACD0: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 0000000BACD4: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 0000000BACDC: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BACE4: BF870292
	v_rcp_f32_e32 v141, v122                                   // 0000000BACE8: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 0000000BACEC: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BACF4: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000BACF8: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000BACFC: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAD00: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 0000000BAD04: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 0000000BAD0C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAD10: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 0000000BAD14: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 0000000BAD1C: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 0000000BAD24: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BAD28: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 0000000BAD2C: D6270089 03CB138D
	.long 0xd4440002                                           // 0000000BAD34: D4440002
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 0000000BAD38: 0202F40E
	s_and_saveexec_b32 s3, s2                                  // 0000000BAD3C: BE832002
	s_cbranch_execz 69                                         // 0000000BAD40: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2c58>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 0000000BAD44: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 0000000BAD50: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 0000000BAD54: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000BAD5C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000BAD60: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAD64: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000BAD68: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000BAD70: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000BAD7C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BAD80: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000BAD84: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000BAD88: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000BAD90: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BAD98: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000BAD9C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000BADA0: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000BADA4: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BADA8: BF870095
	.long 0xd71c008e                                           // 0000000BADAC: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000BADB0: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000BADB4: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000BADB8: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BADC0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000BADC4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000BADCC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BADD0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 0000000BADD4: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000BADDC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BADE0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000BADE4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000BADEC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 0000000BADF0: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BADF8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000BADFC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000BAE00: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAE08: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000BAE0C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000BAE10: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAE18: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000BAE1C: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 0000000BAE24: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 0000000BAE2C: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAE38: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 0000000BAE3C: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 0000000BAE44: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 0000000BAE50: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000BAE58: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 0000000BAE5C: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 0000000BAE64: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BAE6C: BF870292
	v_rcp_f32_e32 v141, v123                                   // 0000000BAE70: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 0000000BAE74: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAE7C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000BAE80: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000BAE84: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAE88: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 0000000BAE8C: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 0000000BAE94: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAE98: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 0000000BAE9C: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 0000000BAEA4: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 0000000BAEAC: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BAEB0: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 0000000BAEB4: D627008A 03CB158D
	.long 0xd4440003                                           // 0000000BAEBC: D4440003
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 0000000BAEC0: 0202F60E
	s_and_saveexec_b32 s4, s3                                  // 0000000BAEC4: BE842003
	s_cbranch_execz 69                                         // 0000000BAEC8: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2de0>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 0000000BAECC: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 0000000BAED8: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 0000000BAEDC: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000BAEE4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000BAEE8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAEEC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000BAEF0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000BAEF8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000BAF04: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BAF08: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000BAF0C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000BAF10: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000BAF18: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BAF20: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000BAF24: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000BAF28: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000BAF2C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAF30: BF870095
	.long 0xd71c008e                                           // 0000000BAF34: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000BAF38: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000BAF3C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000BAF40: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAF48: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000BAF4C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000BAF54: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAF58: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 0000000BAF5C: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000BAF64: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAF68: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000BAF6C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000BAF74: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 0000000BAF78: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAF80: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000BAF84: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000BAF88: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAF90: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000BAF94: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000BAF98: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAFA0: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000BAFA4: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 0000000BAFAC: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 0000000BAFB4: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAFC0: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 0000000BAFC4: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 0000000BAFCC: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 0000000BAFD8: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BAFE0: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 0000000BAFE4: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 0000000BAFE8: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 0000000BAFF0: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BAFF8: BF870292
	v_rcp_f32_e32 v141, v124                                   // 0000000BAFFC: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 0000000BB000: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB008: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000BB00C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000BB010: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB014: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 0000000BB018: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 0000000BB020: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB024: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 0000000BB028: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 0000000BB030: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 0000000BB038: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BB03C: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 0000000BB040: D6270087 03CB0F8D
	.long 0xd4440004                                           // 0000000BB048: D4440004
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 0000000BB04C: 0202F80E
	s_and_saveexec_b32 s5, s4                                  // 0000000BB050: BE852004
	s_cbranch_execz 69                                         // 0000000BB054: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2f6c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 0000000BB058: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 0000000BB064: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 0000000BB068: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000BB070: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000BB074: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB078: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000BB07C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000BB084: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000BB090: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BB094: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000BB098: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000BB09C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000BB0A4: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BB0AC: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000BB0B0: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000BB0B4: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000BB0B8: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB0BC: BF870095
	.long 0xd71c008e                                           // 0000000BB0C0: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000BB0C4: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000BB0C8: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000BB0CC: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB0D4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000BB0D8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000BB0E0: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB0E4: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 0000000BB0E8: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000BB0F0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB0F4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000BB0F8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000BB100: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 0000000BB104: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB10C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000BB110: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000BB114: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB11C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000BB120: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000BB124: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB12C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000BB130: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 0000000BB138: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 0000000BB140: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB14C: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 0000000BB150: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 0000000BB158: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 0000000BB164: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000BB16C: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 0000000BB170: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 0000000BB178: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BB180: BF870292
	v_rcp_f32_e32 v141, v125                                   // 0000000BB184: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 0000000BB188: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB190: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000BB194: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000BB198: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB19C: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 0000000BB1A0: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 0000000BB1A8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB1AC: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 0000000BB1B0: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 0000000BB1B8: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 0000000BB1C0: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BB1C4: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 0000000BB1C8: D6270088 03CB118D
	.long 0xd4440005                                           // 0000000BB1D0: D4440005
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 0000000BB1D4: 0202FA0E
	s_and_saveexec_b32 s6, s5                                  // 0000000BB1D8: BE862005
	s_cbranch_execz 69                                         // 0000000BB1DC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x30f4>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 0000000BB1E0: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 0000000BB1EC: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 0000000BB1F0: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000BB1F8: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000BB1FC: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB200: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000BB204: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000BB20C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000BB218: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BB21C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000BB220: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000BB224: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000BB22C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BB234: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000BB238: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000BB23C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000BB240: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB244: BF870095
	.long 0xd71c008e                                           // 0000000BB248: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000BB24C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000BB250: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000BB254: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB25C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000BB260: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000BB268: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB26C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 0000000BB270: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000BB278: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB27C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000BB280: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000BB288: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 0000000BB28C: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB294: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000BB298: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000BB29C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB2A4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000BB2A8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000BB2AC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB2B4: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000BB2B8: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 0000000BB2C0: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 0000000BB2C8: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB2D4: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 0000000BB2D8: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 0000000BB2E0: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 0000000BB2EC: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000BB2F4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000BB2F8: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 0000000BB2FC: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 0000000BB304: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BB30C: BF870292
	v_rcp_f32_e32 v141, v126                                   // 0000000BB310: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 0000000BB314: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB31C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000BB320: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000BB324: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB328: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 0000000BB32C: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 0000000BB334: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB338: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 0000000BB33C: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 0000000BB344: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 0000000BB34C: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BB350: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 0000000BB354: D6270085 03CB0B8D
	.long 0xd4440006                                           // 0000000BB35C: D4440006
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 0000000BB360: 0202FC0E
	s_and_saveexec_b32 s7, s6                                  // 0000000BB364: BE872006
	s_cbranch_execz 69                                         // 0000000BB368: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3280>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 0000000BB36C: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 0000000BB378: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 0000000BB37C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000BB384: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000BB388: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB38C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000BB390: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000BB398: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000BB3A4: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BB3A8: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000BB3AC: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000BB3B0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000BB3B8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BB3C0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000BB3C4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000BB3C8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000BB3CC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB3D0: BF870095
	.long 0xd71c008e                                           // 0000000BB3D4: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000BB3D8: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000BB3DC: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000BB3E0: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB3E8: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000BB3EC: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000BB3F4: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB3F8: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 0000000BB3FC: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000BB404: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB408: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000BB40C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000BB414: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 0000000BB418: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB420: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000BB424: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000BB428: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB430: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000BB434: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000BB438: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB440: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000BB444: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 0000000BB44C: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 0000000BB454: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB460: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 0000000BB464: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 0000000BB46C: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 0000000BB478: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000BB480: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 0000000BB484: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 0000000BB48C: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BB494: BF870292
	v_rcp_f32_e32 v141, v127                                   // 0000000BB498: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 0000000BB49C: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB4A4: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000BB4A8: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000BB4AC: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB4B0: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 0000000BB4B4: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 0000000BB4BC: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB4C0: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 0000000BB4C4: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 0000000BB4CC: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 0000000BB4D4: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BB4D8: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 0000000BB4DC: D6270086 03CB0D8D
	.long 0xd4440007                                           // 0000000BB4E4: D4440007
	v_cndmask_b32_e32 v1, s14, v127, vcc_lo                    // 0000000BB4E8: 0202FE0E
	s_and_saveexec_b32 s8, s7                                  // 0000000BB4EC: BE882007
	s_cbranch_execnz 363                                       // 0000000BB4F0: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38a0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB4F4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BB4F8: BE882000
	s_cbranch_execnz 432                                       // 0000000BB4FC: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39c0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB500: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BB504: BE882001
	s_cbranch_execnz 501                                       // 0000000BB508: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ae0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB50C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BB510: BE882002
	s_cbranch_execnz 570                                       // 0000000BB514: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c00>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB518: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BB51C: BE882003
	s_cbranch_execnz 639                                       // 0000000BB520: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d20>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB524: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BB528: BE882004
	s_cbranch_execnz 708                                       // 0000000BB52C: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e40>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB530: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BB534: BE882005
	s_cbranch_execnz 777                                       // 0000000BB538: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f60>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB53C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BB540: BE882006
	s_cbranch_execnz 846                                       // 0000000BB544: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4080>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB548: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BB54C: BE882007
	s_cbranch_execnz 915                                       // 0000000BB550: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41a0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB554: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BB558: BE882000
	s_cbranch_execnz 984                                       // 0000000BB55C: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42c0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB560: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BB564: BE882001
	s_cbranch_execnz 1053                                      // 0000000BB568: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x43e0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB56C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BB570: BE882002
	s_cbranch_execnz 1122                                      // 0000000BB574: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4500>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB578: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BB57C: BE882003
	s_cbranch_execnz 1191                                      // 0000000BB580: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4620>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB584: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BB588: BE882004
	s_cbranch_execnz 1260                                      // 0000000BB58C: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4740>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB590: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BB594: BE882005
	s_cbranch_execnz 1329                                      // 0000000BB598: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4860>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB59C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BB5A0: BE882006
	s_cbranch_execnz 1398                                      // 0000000BB5A4: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4980>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB5A8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BB5AC: BE882007
	s_cbranch_execnz 1467                                      // 0000000BB5B0: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4aa0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB5B4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BB5B8: BE882000
	s_cbranch_execnz 1536                                      // 0000000BB5BC: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4bc0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB5C0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BB5C4: BE882001
	s_cbranch_execnz 1605                                      // 0000000BB5C8: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4ce0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB5CC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BB5D0: BE882002
	s_cbranch_execnz 1674                                      // 0000000BB5D4: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4e00>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB5D8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BB5DC: BE882003
	s_cbranch_execnz 1743                                      // 0000000BB5E0: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4f20>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB5E4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BB5E8: BE882004
	s_cbranch_execnz 1812                                      // 0000000BB5EC: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5040>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB5F0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BB5F4: BE882005
	s_cbranch_execnz 1881                                      // 0000000BB5F8: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5160>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB5FC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BB600: BE882006
	s_cbranch_execnz 1950                                      // 0000000BB604: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5280>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB608: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BB60C: BE882007
	s_cbranch_execnz 2019                                      // 0000000BB610: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x53a0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB614: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BB618: BE882000
	s_cbranch_execnz 2088                                      // 0000000BB61C: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x54c0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB620: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BB624: BE882001
	s_cbranch_execnz 2157                                      // 0000000BB628: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x55e0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB62C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BB630: BE882002
	s_cbranch_execnz 2226                                      // 0000000BB634: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5700>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB638: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BB63C: BE882003
	s_cbranch_execnz 2295                                      // 0000000BB640: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5820>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB644: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BB648: BE882004
	s_cbranch_execnz 2364                                      // 0000000BB64C: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5940>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB650: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BB654: BE882005
	s_cbranch_execnz 2433                                      // 0000000BB658: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5a60>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB65C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BB660: BE882006
	s_cbranch_execnz 2502                                      // 0000000BB664: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5b80>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB668: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BB66C: BE882007
	s_cbranch_execnz 2571                                      // 0000000BB670: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5ca0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB674: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BB678: BE882000
	s_cbranch_execnz 2640                                      // 0000000BB67C: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5dc0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB680: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BB684: BE882001
	s_cbranch_execnz 2709                                      // 0000000BB688: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5ee0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB68C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BB690: BE882002
	s_cbranch_execnz 2778                                      // 0000000BB694: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6000>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB698: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BB69C: BE882003
	s_cbranch_execnz 2847                                      // 0000000BB6A0: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6120>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB6A4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BB6A8: BE882004
	s_cbranch_execnz 2916                                      // 0000000BB6AC: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6240>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB6B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BB6B4: BE882005
	s_cbranch_execnz 2985                                      // 0000000BB6B8: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6360>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB6BC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BB6C0: BE882006
	s_cbranch_execnz 3054                                      // 0000000BB6C4: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6480>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB6C8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BB6CC: BE882007
	s_cbranch_execnz 3123                                      // 0000000BB6D0: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x65a0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB6D4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BB6D8: BE882000
	s_cbranch_execnz 3192                                      // 0000000BB6DC: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x66c0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB6E0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BB6E4: BE882001
	s_cbranch_execnz 3261                                      // 0000000BB6E8: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x67e0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB6EC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BB6F0: BE882002
	s_cbranch_execnz 3330                                      // 0000000BB6F4: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6900>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB6F8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BB6FC: BE882003
	s_cbranch_execnz 3399                                      // 0000000BB700: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6a20>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB704: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BB708: BE882004
	s_cbranch_execnz 3468                                      // 0000000BB70C: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6b40>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB710: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BB714: BE882005
	s_cbranch_execnz 3537                                      // 0000000BB718: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6c60>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB71C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BB720: BE882006
	s_cbranch_execnz 3606                                      // 0000000BB724: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6d80>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB728: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BB72C: BE882007
	s_cbranch_execnz 3675                                      // 0000000BB730: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6ea0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB734: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BB738: BE882000
	s_cbranch_execnz 3744                                      // 0000000BB73C: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6fc0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB740: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BB744: BE882001
	s_cbranch_execnz 3813                                      // 0000000BB748: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x70e0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB74C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BB750: BE882002
	s_cbranch_execnz 3882                                      // 0000000BB754: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7200>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB758: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BB75C: BE882003
	s_cbranch_execnz 3951                                      // 0000000BB760: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7320>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB764: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BB768: BE882004
	s_cbranch_execnz 4020                                      // 0000000BB76C: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7440>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB770: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BB774: BE882005
	s_cbranch_execnz 4089                                      // 0000000BB778: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7560>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB77C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BB780: BE882006
	s_cbranch_execnz 4158                                      // 0000000BB784: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7680>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB788: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BB78C: BE882007
	s_cbranch_execnz 4227                                      // 0000000BB790: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x77a0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB794: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BB798: BE882000
	s_cbranch_execnz 4296                                      // 0000000BB79C: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x78c0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB7A0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BB7A4: BE882001
	s_cbranch_execnz 4365                                      // 0000000BB7A8: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x79e0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB7AC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BB7B0: BE882002
	s_cbranch_execnz 4434                                      // 0000000BB7B4: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7b00>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB7B8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BB7BC: BE882003
	s_cbranch_execnz 4503                                      // 0000000BB7C0: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7c20>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB7C4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BB7C8: BE882004
	s_cbranch_execnz 4572                                      // 0000000BB7CC: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7d40>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB7D0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BB7D4: BE882005
	s_cbranch_execnz 4641                                      // 0000000BB7D8: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7e60>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB7DC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BB7E0: BE882006
	s_cbranch_execnz 4710                                      // 0000000BB7E4: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7f80>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB7E8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BB7EC: BE882007
	s_cbranch_execnz 4779                                      // 0000000BB7F0: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x80a0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB7F4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BB7F8: BE882000
	s_cbranch_execnz 4848                                      // 0000000BB7FC: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x81c0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB800: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BB804: BE882001
	s_cbranch_execnz 4917                                      // 0000000BB808: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x82e0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB80C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BB810: BE882002
	s_cbranch_execnz 4986                                      // 0000000BB814: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8400>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB818: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BB81C: BE882003
	s_cbranch_execnz 5055                                      // 0000000BB820: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8520>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB824: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BB828: BE882004
	s_cbranch_execnz 5124                                      // 0000000BB82C: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8640>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB830: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BB834: BE882005
	s_cbranch_execnz 5193                                      // 0000000BB838: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8760>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB83C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BB840: BE882006
	s_cbranch_execnz 5262                                      // 0000000BB844: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8880>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB848: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BB84C: BE882007
	s_cbranch_execnz 5331                                      // 0000000BB850: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x89a0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB854: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BB858: BE882000
	s_cbranch_execnz 5400                                      // 0000000BB85C: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8ac0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB860: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BB864: BE882001
	s_cbranch_execnz 5469                                      // 0000000BB868: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8be0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB86C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BB870: BE882002
	s_cbranch_execnz 5538                                      // 0000000BB874: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8d00>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB878: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BB87C: BE882003
	s_cbranch_execnz 5607                                      // 0000000BB880: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8e20>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB884: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BB888: BE882004
	s_cbranch_execnz 5676                                      // 0000000BB88C: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8f40>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB890: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BB894: BE882005
	s_cbranch_execnz 5745                                      // 0000000BB898: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9060>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB89C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BB8A0: BE882006
	s_cbranch_execnz 5814                                      // 0000000BB8A4: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9180>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB8A8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BB8AC: BE882007
	s_cbranch_execnz 5883                                      // 0000000BB8B0: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x92a0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB8B4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BB8B8: BE882000
	s_cbranch_execnz 5952                                      // 0000000BB8BC: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x93c0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB8C0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BB8C4: BE882001
	s_cbranch_execnz 6021                                      // 0000000BB8C8: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x94e0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB8CC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BB8D0: BE882002
	s_cbranch_execnz 6090                                      // 0000000BB8D4: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9600>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB8D8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BB8DC: BE882003
	s_cbranch_execnz 6159                                      // 0000000BB8E0: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9720>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB8E4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BB8E8: BE882004
	s_cbranch_execnz 6228                                      // 0000000BB8EC: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9840>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB8F0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BB8F4: BE882005
	s_cbranch_execnz 6297                                      // 0000000BB8F8: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9960>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB8FC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BB900: BE882006
	s_cbranch_execnz 6366                                      // 0000000BB904: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9a80>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB908: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BB90C: BE882007
	s_cbranch_execnz 6435                                      // 0000000BB910: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9ba0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB914: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BB918: BE882000
	s_cbranch_execnz 6504                                      // 0000000BB91C: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9cc0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB920: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BB924: BE882001
	s_cbranch_execnz 6573                                      // 0000000BB928: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9de0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB92C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BB930: BE882002
	s_cbranch_execnz 6642                                      // 0000000BB934: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9f00>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB938: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BB93C: BE882003
	s_cbranch_execnz 6711                                      // 0000000BB940: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa020>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB944: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BB948: BE882004
	s_cbranch_execnz 6780                                      // 0000000BB94C: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa140>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB950: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BB954: BE882005
	s_cbranch_execnz 6849                                      // 0000000BB958: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa260>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB95C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BB960: BE882006
	s_cbranch_execnz 6918                                      // 0000000BB964: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa380>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB968: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BB96C: BE882007
	s_cbranch_execnz 6987                                      // 0000000BB970: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa4a0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB974: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BB978: BE882000
	s_cbranch_execnz 7056                                      // 0000000BB97C: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa5c0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB980: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BB984: BE882001
	s_cbranch_execnz 7125                                      // 0000000BB988: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa6e0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB98C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BB990: BE882002
	s_cbranch_execnz 7194                                      // 0000000BB994: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa800>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB998: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BB99C: BE882003
	s_cbranch_execnz 7263                                      // 0000000BB9A0: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa920>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB9A4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BB9A8: BE882004
	s_cbranch_execnz 7332                                      // 0000000BB9AC: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaa40>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB9B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BB9B4: BE882005
	s_cbranch_execnz 7401                                      // 0000000BB9B8: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xab60>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB9BC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BB9C0: BE882006
	s_cbranch_execnz 7470                                      // 0000000BB9C4: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac80>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB9C8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BB9CC: BE882007
	s_cbranch_execnz 7539                                      // 0000000BB9D0: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xada0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB9D4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BB9D8: BE882000
	s_cbranch_execnz 7608                                      // 0000000BB9DC: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaec0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB9E0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BB9E4: BE882001
	s_cbranch_execnz 7677                                      // 0000000BB9E8: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xafe0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB9EC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BB9F0: BE882002
	s_cbranch_execnz 7746                                      // 0000000BB9F4: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb100>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BB9F8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BB9FC: BE882003
	s_cbranch_execnz 7815                                      // 0000000BBA00: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb220>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BBA04: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BBA08: BE882004
	s_cbranch_execnz 7884                                      // 0000000BBA0C: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb340>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BBA10: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BBA14: BE882005
	s_cbranch_execnz 7953                                      // 0000000BBA18: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb460>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BBA1C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BBA20: BE882006
	s_cbranch_execnz 8022                                      // 0000000BBA24: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb580>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BBA28: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BBA2C: BE882007
	s_cbranch_execnz 8091                                      // 0000000BBA30: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb6a0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BBA34: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BBA38: BE882000
	s_cbranch_execnz 8160                                      // 0000000BBA3C: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb7c0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BBA40: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 0000000BBA44: BE802001
	s_cbranch_execnz 8229                                      // 0000000BBA48: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb8e0>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000BBA4C: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000BBA50: BE802002
	s_cbranch_execnz 8298                                      // 0000000BBA54: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xba00>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000BBA58: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000BBA5C: BE802003
	s_cbranch_execnz 8367                                      // 0000000BBA60: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbb20>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000BBA64: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000BBA68: BE802004
	s_cbranch_execnz 8436                                      // 0000000BBA6C: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbc40>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000BBA70: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000BBA74: BE802005
	s_cbranch_execnz 8505                                      // 0000000BBA78: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbd60>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000BBA7C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000BBA80: BE802006
	s_cbranch_execnz 8574                                      // 0000000BBA84: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbe80>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000BBA88: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000BBA8C: BE802007
	s_cbranch_execnz 8643                                      // 0000000BBA90: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbfa0>
	s_nop 0                                                    // 0000000BBA94: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000000BBA98: BFB60003
	s_endpgm                                                   // 0000000BBA9C: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 0000000BBAA0: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 0000000BBAAC: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 0000000BBAB0: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000BBAB8: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000BBABC: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBAC0: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000BBAC4: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000BBACC: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000BBAD8: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BBADC: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000BBAE0: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000BBAE4: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000BBAEC: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BBAF4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000BBAF8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000BBAFC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000BBB00: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBB04: BF870095
	.long 0xd71c008e                                           // 0000000BBB08: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000BBB0C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000BBB10: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000BBB14: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBB1C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000BBB20: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000BBB28: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBB2C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 0000000BBB30: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000BBB38: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBB3C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000BBB40: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000BBB48: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 0000000BBB4C: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBB54: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000BBB58: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000BBB5C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBB64: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000BBB68: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000BBB6C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBB74: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000BBB78: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 0000000BBB80: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 0000000BBB88: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBB94: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 0000000BBB98: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 0000000BBBA0: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 0000000BBBAC: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BBBB4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BBBB8: BE882000
	s_cbranch_execz 65104                                      // 0000000BBBBC: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3300>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 0000000BBBC0: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 0000000BBBCC: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 0000000BBBD0: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 0000000BBBD8: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 0000000BBBDC: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBBE0: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 0000000BBBE4: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 0000000BBBEC: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 0000000BBBF8: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BBBFC: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 0000000BBC00: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 0000000BBC04: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 0000000BBC0C: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BBC14: BF870121
	v_add_f32_e32 v141, v141, v142                             // 0000000BBC18: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 0000000BBC1C: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 0000000BBC20: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBC24: BF870095
	.long 0xd71c008d                                           // 0000000BBC28: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 0000000BBC2C: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000BBC30: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 0000000BBC34: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBC3C: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 0000000BBC40: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 0000000BBC48: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBC4C: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 0000000BBC50: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 0000000BBC58: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBC5C: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 0000000BBC60: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 0000000BBC68: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 0000000BBC6C: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBC74: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 0000000BBC78: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 0000000BBC7C: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBC84: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 0000000BBC88: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 0000000BBC8C: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBC94: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 0000000BBC98: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 0000000BBCA0: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 0000000BBCA8: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBCB4: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 0000000BBCB8: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 0000000BBCC0: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 0000000BBCCC: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BBCD4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BBCD8: BE882001
	s_cbranch_execz 65035                                      // 0000000BBCDC: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x330c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000000BBCE0: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 0000000BBCEC: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 0000000BBCF0: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 0000000BBCF8: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000BBCFC: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBD00: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 0000000BBD04: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 0000000BBD0C: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 0000000BBD18: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BBD1C: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 0000000BBD20: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000BBD24: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 0000000BBD2C: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BBD34: BF870121
	v_add_f32_e32 v128, v128, v141                             // 0000000BBD38: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 0000000BBD3C: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 0000000BBD40: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBD44: BF870095
	.long 0xd71c0080                                           // 0000000BBD48: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 0000000BBD4C: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 0000000BBD50: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000BBD54: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBD5C: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 0000000BBD60: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000BBD68: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBD6C: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 0000000BBD70: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 0000000BBD78: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBD7C: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 0000000BBD80: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 0000000BBD88: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 0000000BBD8C: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBD94: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 0000000BBD98: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 0000000BBD9C: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBDA4: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 0000000BBDA8: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 0000000BBDAC: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBDB4: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 0000000BBDB8: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 0000000BBDC0: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 0000000BBDC8: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBDD4: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 0000000BBDD8: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 0000000BBDE0: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 0000000BBDEC: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BBDF4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BBDF8: BE882002
	s_cbranch_execz 64966                                      // 0000000BBDFC: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3318>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 0000000BBE00: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000BBE0C: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000BBE14: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000BBE18: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBE1C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000BBE20: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 0000000BBE28: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 0000000BBE34: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BBE38: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 0000000BBE3C: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 0000000BBE44: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000BBE48: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 0000000BBE4C: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 0000000BBE50: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000BBE54: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 0000000BBE5C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBE60: BF870095
	.long 0xd71c0072                                           // 0000000BBE64: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 0000000BBE68: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000BBE6C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000BBE70: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBE78: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 0000000BBE7C: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000BBE88: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBE8C: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000BBE90: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 0000000BBE98: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBE9C: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 0000000BBEA0: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 0000000BBEA8: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 0000000BBEAC: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBEB4: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 0000000BBEB8: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 0000000BBEBC: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBEC4: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 0000000BBEC8: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 0000000BBECC: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBED4: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 0000000BBED8: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000BBEE0: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 0000000BBEE8: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBEF4: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 0000000BBEF8: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 0000000BBF00: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000BBF0C: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BBF14: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BBF18: BE882003
	s_cbranch_execz 64897                                      // 0000000BBF1C: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3324>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 0000000BBF20: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000BBF2C: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000BBF34: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000BBF38: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBF3C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000BBF40: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000BBF48: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 0000000BBF54: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BBF58: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 0000000BBF5C: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000BBF60: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000BBF68: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BBF70: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000BBF74: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 0000000BBF78: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 0000000BBF7C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBF80: BF870095
	.long 0xd71c0072                                           // 0000000BBF84: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000BBF88: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000BBF8C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000BBF90: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBF98: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 0000000BBF9C: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000BBFA8: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBFAC: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000BBFB0: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000BBFB8: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBFBC: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 0000000BBFC0: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 0000000BBFC8: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 0000000BBFCC: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBFD4: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 0000000BBFD8: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 0000000BBFDC: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBFE4: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 0000000BBFE8: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 0000000BBFEC: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBFF4: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 0000000BBFF8: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000BC000: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 0000000BC008: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC014: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000BC018: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000BC020: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000BC02C: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BC034: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BC038: BE882004
	s_cbranch_execz 64828                                      // 0000000BC03C: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3330>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 0000000BC040: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000BC04C: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000BC054: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000BC058: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC05C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000BC060: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000BC068: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000BC074: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BC078: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000BC07C: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000BC080: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000BC088: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BC090: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000BC094: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000BC098: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000BC09C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC0A0: BF870095
	.long 0xd71c0072                                           // 0000000BC0A4: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000BC0A8: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000BC0AC: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000BC0B0: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC0B8: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 0000000BC0BC: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000BC0C8: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC0CC: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000BC0D0: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000BC0D8: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC0DC: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000BC0E0: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000BC0E8: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000BC0EC: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC0F4: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 0000000BC0F8: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 0000000BC0FC: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC104: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 0000000BC108: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 0000000BC10C: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC114: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 0000000BC118: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000BC120: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 0000000BC128: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC134: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000BC138: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000BC140: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000BC14C: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BC154: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BC158: BE882005
	s_cbranch_execz 64759                                      // 0000000BC15C: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x333c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 0000000BC160: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000BC16C: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000BC174: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000BC178: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC17C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000BC180: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000BC188: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000BC194: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BC198: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000BC19C: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000BC1A0: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000BC1A8: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BC1B0: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000BC1B4: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000BC1B8: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000BC1BC: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC1C0: BF870095
	.long 0xd71c0072                                           // 0000000BC1C4: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000BC1C8: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000BC1CC: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000BC1D0: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC1D8: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000BC1DC: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 0000000BC1E4: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC1EC: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000BC1F0: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000BC1F8: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC1FC: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000BC200: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000BC208: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000BC20C: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC214: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000BC218: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 0000000BC21C: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC224: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 0000000BC228: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 0000000BC22C: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC234: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000BC238: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000BC240: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 0000000BC248: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC254: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000BC258: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000BC260: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000BC26C: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BC274: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BC278: BE882006
	s_cbranch_execz 64690                                      // 0000000BC27C: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3348>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 0000000BC280: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000BC28C: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000BC294: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000BC298: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC29C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000BC2A0: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000BC2A8: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000BC2B4: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BC2B8: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000BC2BC: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000BC2C0: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000BC2C8: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BC2D0: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000BC2D4: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000BC2D8: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000BC2DC: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC2E0: BF870095
	.long 0xd71c0072                                           // 0000000BC2E4: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000BC2E8: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000BC2EC: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000BC2F0: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC2F8: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 0000000BC2FC: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000BC308: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC30C: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000BC310: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000BC318: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC31C: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000BC320: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000BC328: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000BC32C: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC334: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000BC338: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000BC33C: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC344: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000BC348: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000BC34C: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC354: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000BC358: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000BC360: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 0000000BC368: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC374: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000BC378: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000BC380: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000BC38C: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BC394: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BC398: BE882007
	s_cbranch_execz 64621                                      // 0000000BC39C: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3354>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 0000000BC3A0: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000BC3AC: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000BC3B4: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000BC3B8: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC3BC: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000BC3C0: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000BC3C8: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000BC3D4: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BC3D8: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000BC3DC: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000BC3E0: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000BC3E8: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BC3F0: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000BC3F4: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000BC3F8: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000BC3FC: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC400: BF870095
	.long 0xd71c0072                                           // 0000000BC404: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000BC408: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000BC40C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000BC410: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC418: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 0000000BC41C: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000BC428: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC42C: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000BC430: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000BC438: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC43C: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000BC440: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000BC448: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000BC44C: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC454: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000BC458: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000BC45C: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC464: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000BC468: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000BC46C: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC474: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000BC478: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000BC480: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 0000000BC488: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC494: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000BC498: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000BC4A0: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000BC4AC: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BC4B4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BC4B8: BE882000
	s_cbranch_execz 64552                                      // 0000000BC4BC: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3360>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 0000000BC4C0: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 0000000BC4CC: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 0000000BC4D0: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000BC4D8: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000BC4DC: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC4E0: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000BC4E4: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000BC4EC: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000BC4F8: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BC4FC: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000BC500: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000BC504: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000BC50C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BC514: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000BC518: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000BC51C: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000BC520: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC524: BF870095
	.long 0xd71c0072                                           // 0000000BC528: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000BC52C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000BC530: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000BC534: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC53C: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000BC540: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000BC548: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC54C: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 0000000BC550: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 0000000BC558: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC55C: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 0000000BC560: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 0000000BC568: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 0000000BC56C: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC574: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 0000000BC578: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 0000000BC57C: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC584: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 0000000BC588: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 0000000BC58C: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC594: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 0000000BC598: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 0000000BC5A0: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 0000000BC5A8: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC5B4: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 0000000BC5B8: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 0000000BC5C0: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 0000000BC5CC: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BC5D4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BC5D8: BE882001
	s_cbranch_execz 64483                                      // 0000000BC5DC: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x336c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 0000000BC5E0: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 0000000BC5EC: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 0000000BC5F0: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 0000000BC5F8: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000BC5FC: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BC600: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 0000000BC604: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000BC60C: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 0000000BC614: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000000BC620: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BC624: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 0000000BC628: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 0000000BC630: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BC634: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000000BC638: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000000BC63C: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000000BC640: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC644: BF870095
	.long 0xd71c0071                                           // 0000000BC648: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000000BC64C: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000BC650: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000BC654: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC65C: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 0000000BC660: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000BC668: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC66C: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 0000000BC670: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 0000000BC678: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC67C: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 0000000BC680: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 0000000BC688: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 0000000BC68C: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC694: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 0000000BC698: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 0000000BC69C: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC6A4: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 0000000BC6A8: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 0000000BC6AC: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC6B4: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 0000000BC6B8: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 0000000BC6C0: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 0000000BC6C8: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC6D4: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 0000000BC6D8: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 0000000BC6E0: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 0000000BC6EC: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BC6F4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BC6F8: BE882002
	s_cbranch_execz 64414                                      // 0000000BC6FC: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3378>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 0000000BC700: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000BC70C: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000BC714: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000BC718: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC71C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000BC720: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 0000000BC728: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 0000000BC734: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BC738: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 0000000BC73C: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000BC740: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 0000000BC748: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BC750: BF870121
	v_add_f32_e32 v106, v106, v113                             // 0000000BC754: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 0000000BC758: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 0000000BC75C: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC760: BF870095
	.long 0xd71c006a                                           // 0000000BC764: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 0000000BC768: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000BC76C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000BC770: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC778: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 0000000BC77C: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000BC788: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC78C: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000BC790: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 0000000BC798: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC79C: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 0000000BC7A0: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 0000000BC7A8: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 0000000BC7AC: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC7B4: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 0000000BC7B8: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 0000000BC7BC: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC7C4: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 0000000BC7C8: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 0000000BC7CC: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC7D4: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 0000000BC7D8: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000BC7E0: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 0000000BC7E8: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC7F4: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 0000000BC7F8: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 0000000BC800: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000BC80C: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BC814: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BC818: BE882003
	s_cbranch_execz 64345                                      // 0000000BC81C: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3384>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 0000000BC820: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000BC82C: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000BC834: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000BC838: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC83C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000BC840: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000BC848: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 0000000BC854: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC858: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 0000000BC85C: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 0000000BC868: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 0000000BC86C: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000BC870: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BC878: BF870293
	v_exp_f32_e32 v106, v106                                   // 0000000BC87C: 7ED44B6A
	.long 0xd71c006a                                           // 0000000BC880: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000BC884: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BC888: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000BC88C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000BC890: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 0000000BC898: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC8A4: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 0000000BC8A8: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000BC8AC: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BC8B4: BF870291
	v_rcp_f32_e32 v108, v107                                   // 0000000BC8B8: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 0000000BC8BC: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BC8C4: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 0000000BC8C8: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 0000000BC8CC: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 0000000BC8D4: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC8D8: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 0000000BC8DC: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 0000000BC8E4: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC8E8: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 0000000BC8EC: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 0000000BC8F4: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BC8FC: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000BC900: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 0000000BC908: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 0000000BC914: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BC91C: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000BC920: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000BC92C: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BC934: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BC938: BE882004
	s_cbranch_execz 64276                                      // 0000000BC93C: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3390>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 0000000BC940: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000BC94C: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000BC954: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000BC958: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC95C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000BC960: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000BC968: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000BC974: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BC978: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000BC97C: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000BC980: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000BC988: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BC990: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000BC994: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000BC998: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000BC99C: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC9A0: BF870095
	.long 0xd71c006a                                           // 0000000BC9A4: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000BC9A8: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000BC9AC: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000BC9B0: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC9B8: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 0000000BC9BC: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000BC9C8: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC9CC: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000BC9D0: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000BC9D8: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC9DC: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000BC9E0: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000BC9E8: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000BC9EC: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC9F4: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 0000000BC9F8: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 0000000BC9FC: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCA04: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 0000000BCA08: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 0000000BCA0C: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCA14: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 0000000BCA18: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000BCA20: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 0000000BCA28: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCA34: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000BCA38: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000BCA40: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000BCA4C: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BCA54: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BCA58: BE882005
	s_cbranch_execz 64207                                      // 0000000BCA5C: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x339c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 0000000BCA60: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000BCA6C: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000BCA74: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000BCA78: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCA7C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000BCA80: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000BCA88: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000BCA94: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BCA98: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000BCA9C: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000BCAA0: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000BCAA8: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BCAB0: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000BCAB4: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000BCAB8: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000BCABC: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCAC0: BF870095
	.long 0xd71c006a                                           // 0000000BCAC4: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000BCAC8: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000BCACC: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000BCAD0: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCAD8: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000000BCADC: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 0000000BCAE4: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCAEC: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000BCAF0: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000BCAF8: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCAFC: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000BCB00: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000BCB08: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000BCB0C: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCB14: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000BCB18: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 0000000BCB1C: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCB24: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 0000000BCB28: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 0000000BCB2C: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCB34: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000BCB38: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000BCB40: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 0000000BCB48: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCB54: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000BCB58: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000BCB60: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000BCB6C: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BCB74: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BCB78: BE882006
	s_cbranch_execz 64138                                      // 0000000BCB7C: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33a8>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 0000000BCB80: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000BCB8C: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000BCB94: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000BCB98: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCB9C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000BCBA0: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000BCBA8: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000BCBB4: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BCBB8: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000BCBBC: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000BCBC0: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000BCBC8: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BCBD0: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000BCBD4: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000BCBD8: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000BCBDC: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCBE0: BF870095
	.long 0xd71c006a                                           // 0000000BCBE4: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000BCBE8: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000BCBEC: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000BCBF0: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCBF8: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 0000000BCBFC: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000BCC08: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCC0C: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000BCC10: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000BCC18: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCC1C: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000BCC20: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000BCC28: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000BCC2C: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCC34: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000BCC38: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 0000000BCC3C: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCC44: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 0000000BCC48: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 0000000BCC4C: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCC54: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000BCC58: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000BCC60: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 0000000BCC68: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCC74: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000BCC78: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000BCC80: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000BCC8C: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BCC94: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BCC98: BE882007
	s_cbranch_execz 64069                                      // 0000000BCC9C: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33b4>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 0000000BCCA0: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000BCCAC: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000BCCB4: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000BCCB8: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCCBC: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000BCCC0: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000BCCC8: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000BCCD4: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BCCD8: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000BCCDC: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000BCCE0: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000BCCE8: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BCCF0: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000BCCF4: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000BCCF8: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000BCCFC: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCD00: BF870095
	.long 0xd71c006a                                           // 0000000BCD04: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000BCD08: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000BCD0C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000BCD10: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCD18: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 0000000BCD1C: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000BCD28: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCD2C: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000BCD30: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000BCD38: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCD3C: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000BCD40: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000BCD48: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000BCD4C: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCD54: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000BCD58: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 0000000BCD5C: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCD64: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 0000000BCD68: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 0000000BCD6C: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCD74: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000BCD78: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000BCD80: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 0000000BCD88: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCD94: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000BCD98: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000BCDA0: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000BCDAC: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BCDB4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BCDB8: BE882000
	s_cbranch_execz 64000                                      // 0000000BCDBC: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33c0>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 0000000BCDC0: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 0000000BCDCC: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 0000000BCDD0: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000BCDD8: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000BCDDC: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCDE0: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000BCDE4: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000BCDEC: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000BCDF8: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BCDFC: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000BCE00: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000BCE04: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000BCE0C: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BCE14: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000BCE18: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000BCE1C: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000BCE20: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCE24: BF870095
	.long 0xd71c006a                                           // 0000000BCE28: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000BCE2C: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000BCE30: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000BCE34: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCE3C: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000000BCE40: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000BCE48: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCE4C: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 0000000BCE50: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 0000000BCE58: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCE5C: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 0000000BCE60: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 0000000BCE68: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 0000000BCE6C: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCE74: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 0000000BCE78: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 0000000BCE7C: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCE84: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 0000000BCE88: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 0000000BCE8C: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCE94: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 0000000BCE98: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 0000000BCEA0: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 0000000BCEA8: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCEB4: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 0000000BCEB8: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 0000000BCEC0: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 0000000BCECC: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BCED4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BCED8: BE882001
	s_cbranch_execz 63931                                      // 0000000BCEDC: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33cc>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 0000000BCEE0: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 0000000BCEEC: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 0000000BCEF0: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 0000000BCEF8: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000BCEFC: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BCF00: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 0000000BCF04: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000BCF0C: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 0000000BCF14: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000000BCF20: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BCF24: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 0000000BCF28: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 0000000BCF30: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BCF34: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000000BCF38: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000000BCF3C: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000000BCF40: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCF44: BF870095
	.long 0xd71c0069                                           // 0000000BCF48: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000000BCF4C: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000000BCF50: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000BCF54: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCF5C: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 0000000BCF60: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000BCF68: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCF6C: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 0000000BCF70: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 0000000BCF78: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCF7C: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 0000000BCF80: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 0000000BCF88: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 0000000BCF8C: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCF94: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 0000000BCF98: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 0000000BCF9C: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCFA4: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 0000000BCFA8: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 0000000BCFAC: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCFB4: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 0000000BCFB8: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 0000000BCFC0: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 0000000BCFC8: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCFD4: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 0000000BCFD8: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 0000000BCFE0: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 0000000BCFEC: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BCFF4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BCFF8: BE882002
	s_cbranch_execz 63862                                      // 0000000BCFFC: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33d8>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 0000000BD000: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000BD00C: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000BD014: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000BD018: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD01C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000BD020: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 0000000BD028: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 0000000BD034: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BD038: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 0000000BD03C: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000BD040: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 0000000BD048: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD050: BF870121
	v_add_f32_e32 v98, v98, v105                               // 0000000BD054: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 0000000BD058: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 0000000BD05C: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD060: BF870095
	.long 0xd71c0062                                           // 0000000BD064: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 0000000BD068: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000BD06C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000BD070: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD078: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 0000000BD07C: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000BD088: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD08C: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000BD090: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 0000000BD098: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD09C: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 0000000BD0A0: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 0000000BD0A8: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 0000000BD0AC: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD0B4: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 0000000BD0B8: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 0000000BD0BC: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD0C4: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 0000000BD0C8: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 0000000BD0CC: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD0D4: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 0000000BD0D8: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000BD0E0: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 0000000BD0E8: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD0F4: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 0000000BD0F8: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 0000000BD100: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000BD10C: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BD114: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BD118: BE882003
	s_cbranch_execz 63793                                      // 0000000BD11C: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33e4>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 0000000BD120: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000BD12C: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000BD134: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000BD138: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD13C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000BD140: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000BD148: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 0000000BD154: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD158: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 0000000BD15C: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 0000000BD168: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 0000000BD16C: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000BD170: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BD178: BF870293
	v_exp_f32_e32 v98, v98                                     // 0000000BD17C: 7EC44B62
	.long 0xd71c0062                                           // 0000000BD180: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000BD184: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD188: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000BD18C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000BD190: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 0000000BD198: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD1A4: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 0000000BD1A8: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000BD1AC: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BD1B4: BF870291
	v_rcp_f32_e32 v100, v99                                    // 0000000BD1B8: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 0000000BD1BC: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BD1C4: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 0000000BD1C8: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 0000000BD1CC: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 0000000BD1D4: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD1D8: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 0000000BD1DC: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 0000000BD1E4: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD1E8: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 0000000BD1EC: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 0000000BD1F4: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD1FC: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000BD200: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 0000000BD208: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000BD214: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BD21C: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000BD220: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000BD22C: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BD234: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BD238: BE882004
	s_cbranch_execz 63724                                      // 0000000BD23C: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33f0>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 0000000BD240: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000BD24C: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000BD254: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000BD258: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD25C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000BD260: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000BD268: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000BD274: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BD278: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000BD27C: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000BD280: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000BD288: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD290: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000BD294: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000BD298: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000BD29C: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD2A0: BF870095
	.long 0xd71c0062                                           // 0000000BD2A4: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000BD2A8: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000BD2AC: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000BD2B0: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD2B8: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 0000000BD2BC: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000BD2C8: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD2CC: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000BD2D0: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000BD2D8: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD2DC: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000BD2E0: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000BD2E8: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000BD2EC: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD2F4: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 0000000BD2F8: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 0000000BD2FC: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD304: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 0000000BD308: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 0000000BD30C: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD314: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 0000000BD318: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000BD320: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 0000000BD328: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD334: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000BD338: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000BD340: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000BD34C: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BD354: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BD358: BE882005
	s_cbranch_execz 63655                                      // 0000000BD35C: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33fc>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 0000000BD360: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000BD36C: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000BD374: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000BD378: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD37C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000BD380: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000BD388: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000BD394: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BD398: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000BD39C: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000BD3A0: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000BD3A8: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD3B0: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000BD3B4: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000BD3B8: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000BD3BC: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD3C0: BF870095
	.long 0xd71c0062                                           // 0000000BD3C4: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000BD3C8: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000BD3CC: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000BD3D0: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD3D8: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000BD3DC: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 0000000BD3E4: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD3EC: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000BD3F0: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000BD3F8: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD3FC: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000BD400: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000BD408: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000BD40C: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD414: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000BD418: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 0000000BD41C: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD424: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 0000000BD428: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 0000000BD42C: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD434: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000BD438: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000BD440: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 0000000BD448: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD454: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000BD458: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000BD460: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000BD46C: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BD474: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BD478: BE882006
	s_cbranch_execz 63586                                      // 0000000BD47C: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3408>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 0000000BD480: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000BD48C: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000BD494: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000BD498: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD49C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000BD4A0: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000BD4A8: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000BD4B4: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BD4B8: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000BD4BC: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000BD4C0: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000BD4C8: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD4D0: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000BD4D4: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000BD4D8: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000BD4DC: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD4E0: BF870095
	.long 0xd71c0062                                           // 0000000BD4E4: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000BD4E8: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000BD4EC: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000BD4F0: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD4F8: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 0000000BD4FC: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000BD508: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD50C: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000BD510: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000BD518: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD51C: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000BD520: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000BD528: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000BD52C: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD534: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000BD538: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000BD53C: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD544: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000BD548: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000BD54C: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD554: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000BD558: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000BD560: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 0000000BD568: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD574: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000BD578: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000BD580: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000BD58C: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BD594: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BD598: BE882007
	s_cbranch_execz 63517                                      // 0000000BD59C: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3414>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 0000000BD5A0: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000BD5AC: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000BD5B4: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000BD5B8: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD5BC: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000BD5C0: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000BD5C8: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000BD5D4: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BD5D8: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000BD5DC: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000BD5E0: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000BD5E8: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD5F0: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000BD5F4: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000BD5F8: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000BD5FC: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD600: BF870095
	.long 0xd71c0062                                           // 0000000BD604: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000BD608: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000BD60C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000BD610: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD618: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 0000000BD61C: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000BD628: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD62C: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000BD630: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000BD638: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD63C: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000BD640: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000BD648: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000BD64C: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD654: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000BD658: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000BD65C: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD664: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000BD668: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000BD66C: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD674: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000BD678: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000BD680: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 0000000BD688: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD694: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000BD698: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000BD6A0: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000BD6AC: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BD6B4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BD6B8: BE882000
	s_cbranch_execz 63448                                      // 0000000BD6BC: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3420>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 0000000BD6C0: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 0000000BD6CC: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 0000000BD6D0: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000BD6D8: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000BD6DC: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD6E0: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000BD6E4: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000BD6EC: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000BD6F8: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BD6FC: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000BD700: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000BD704: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000BD70C: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD714: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000BD718: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000BD71C: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000BD720: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD724: BF870095
	.long 0xd71c0062                                           // 0000000BD728: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000BD72C: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000BD730: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000BD734: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD73C: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000BD740: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000BD748: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD74C: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 0000000BD750: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 0000000BD758: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD75C: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000000BD760: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 0000000BD768: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 0000000BD76C: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD774: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 0000000BD778: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 0000000BD77C: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD784: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 0000000BD788: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 0000000BD78C: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD794: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 0000000BD798: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 0000000BD7A0: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 0000000BD7A8: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD7B4: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 0000000BD7B8: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 0000000BD7C0: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 0000000BD7CC: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BD7D4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BD7D8: BE882001
	s_cbranch_execz 63379                                      // 0000000BD7DC: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x342c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 0000000BD7E0: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 0000000BD7EC: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 0000000BD7F0: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 0000000BD7F8: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000BD7FC: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD800: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 0000000BD804: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000BD80C: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 0000000BD814: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000000BD820: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BD824: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 0000000BD828: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 0000000BD830: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD834: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000000BD838: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000000BD83C: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000000BD840: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD844: BF870095
	.long 0xd71c0061                                           // 0000000BD848: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000000BD84C: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000BD850: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000BD854: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD85C: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 0000000BD860: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000BD868: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD86C: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 0000000BD870: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 0000000BD878: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD87C: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 0000000BD880: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 0000000BD888: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 0000000BD88C: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD894: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 0000000BD898: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 0000000BD89C: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD8A4: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 0000000BD8A8: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 0000000BD8AC: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD8B4: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 0000000BD8B8: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 0000000BD8C0: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 0000000BD8C8: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD8D4: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 0000000BD8D8: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 0000000BD8E0: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 0000000BD8EC: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BD8F4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BD8F8: BE882002
	s_cbranch_execz 63310                                      // 0000000BD8FC: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3438>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 0000000BD900: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000BD90C: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000BD914: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000BD918: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD91C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000BD920: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 0000000BD928: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 0000000BD934: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BD938: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 0000000BD93C: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000BD940: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 0000000BD948: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD950: BF870121
	v_add_f32_e32 v90, v90, v97                                // 0000000BD954: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 0000000BD958: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 0000000BD95C: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD960: BF870095
	.long 0xd71c005a                                           // 0000000BD964: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 0000000BD968: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000BD96C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000BD970: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD978: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 0000000BD97C: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000BD988: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD98C: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000BD990: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 0000000BD998: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD99C: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 0000000BD9A0: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 0000000BD9A8: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 0000000BD9AC: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD9B4: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 0000000BD9B8: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 0000000BD9BC: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD9C4: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 0000000BD9C8: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 0000000BD9CC: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD9D4: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 0000000BD9D8: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000BD9E0: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 0000000BD9E8: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD9F4: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 0000000BD9F8: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 0000000BDA00: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000BDA0C: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BDA14: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BDA18: BE882003
	s_cbranch_execz 63241                                      // 0000000BDA1C: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3444>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 0000000BDA20: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000BDA2C: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000BDA34: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000BDA38: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDA3C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000BDA40: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000BDA48: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 0000000BDA54: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDA58: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 0000000BDA5C: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 0000000BDA68: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 0000000BDA6C: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000BDA70: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BDA78: BF870293
	v_exp_f32_e32 v90, v90                                     // 0000000BDA7C: 7EB44B5A
	.long 0xd71c005a                                           // 0000000BDA80: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000BDA84: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BDA88: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000BDA8C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000BDA90: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 0000000BDA98: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDAA4: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 0000000BDAA8: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000BDAAC: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BDAB4: BF870291
	v_rcp_f32_e32 v92, v91                                     // 0000000BDAB8: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 0000000BDABC: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BDAC4: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 0000000BDAC8: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 0000000BDACC: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 0000000BDAD4: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDAD8: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 0000000BDADC: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 0000000BDAE4: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDAE8: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 0000000BDAEC: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 0000000BDAF4: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BDAFC: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000BDB00: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 0000000BDB08: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000BDB14: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BDB1C: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000BDB20: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000BDB2C: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BDB34: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BDB38: BE882004
	s_cbranch_execz 63172                                      // 0000000BDB3C: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3450>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 0000000BDB40: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000BDB4C: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000BDB54: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000BDB58: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDB5C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000BDB60: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000BDB68: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000BDB74: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BDB78: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000BDB7C: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000BDB80: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000BDB88: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BDB90: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000BDB94: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000BDB98: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000BDB9C: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDBA0: BF870095
	.long 0xd71c005a                                           // 0000000BDBA4: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000BDBA8: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000BDBAC: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000BDBB0: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDBB8: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 0000000BDBBC: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000BDBC8: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDBCC: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000BDBD0: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000BDBD8: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDBDC: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000BDBE0: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000BDBE8: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000BDBEC: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDBF4: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 0000000BDBF8: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 0000000BDBFC: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDC04: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 0000000BDC08: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 0000000BDC0C: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDC14: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 0000000BDC18: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000BDC20: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 0000000BDC28: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDC34: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000BDC38: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000BDC40: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000BDC4C: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BDC54: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BDC58: BE882005
	s_cbranch_execz 63103                                      // 0000000BDC5C: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x345c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 0000000BDC60: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000BDC6C: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000BDC74: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000BDC78: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDC7C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000BDC80: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000BDC88: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000BDC94: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BDC98: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000BDC9C: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000BDCA0: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000BDCA8: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BDCB0: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000BDCB4: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000BDCB8: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000BDCBC: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDCC0: BF870095
	.long 0xd71c005a                                           // 0000000BDCC4: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000BDCC8: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000BDCCC: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000BDCD0: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDCD8: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000000BDCDC: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 0000000BDCE4: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDCEC: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000BDCF0: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000BDCF8: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDCFC: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000BDD00: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000BDD08: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000BDD0C: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDD14: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000BDD18: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 0000000BDD1C: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDD24: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 0000000BDD28: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 0000000BDD2C: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDD34: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000BDD38: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000BDD40: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 0000000BDD48: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDD54: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000BDD58: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000BDD60: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000BDD6C: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BDD74: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BDD78: BE882006
	s_cbranch_execz 63034                                      // 0000000BDD7C: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3468>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 0000000BDD80: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000BDD8C: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000BDD94: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000BDD98: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDD9C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000BDDA0: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000BDDA8: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000BDDB4: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BDDB8: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000BDDBC: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000BDDC0: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000BDDC8: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BDDD0: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000BDDD4: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000BDDD8: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000BDDDC: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDDE0: BF870095
	.long 0xd71c005a                                           // 0000000BDDE4: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000BDDE8: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000BDDEC: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000BDDF0: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDDF8: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 0000000BDDFC: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000BDE08: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDE0C: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000BDE10: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000BDE18: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDE1C: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000BDE20: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000BDE28: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000BDE2C: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDE34: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000BDE38: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000000BDE3C: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDE44: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000000BDE48: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000000BDE4C: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDE54: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000BDE58: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000BDE60: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 0000000BDE68: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDE74: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000BDE78: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000BDE80: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000BDE8C: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BDE94: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BDE98: BE882007
	s_cbranch_execz 62965                                      // 0000000BDE9C: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3474>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 0000000BDEA0: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000BDEAC: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000BDEB4: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000BDEB8: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDEBC: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000BDEC0: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000BDEC8: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000BDED4: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BDED8: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000BDEDC: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000BDEE0: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000BDEE8: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BDEF0: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000BDEF4: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000BDEF8: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000BDEFC: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDF00: BF870095
	.long 0xd71c005a                                           // 0000000BDF04: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000BDF08: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000BDF0C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000BDF10: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDF18: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 0000000BDF1C: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000BDF28: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDF2C: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000BDF30: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000BDF38: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDF3C: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000BDF40: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000BDF48: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000BDF4C: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDF54: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000BDF58: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000000BDF5C: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDF64: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000000BDF68: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000000BDF6C: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDF74: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000BDF78: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000BDF80: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 0000000BDF88: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDF94: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000BDF98: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000BDFA0: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000BDFAC: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BDFB4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BDFB8: BE882000
	s_cbranch_execz 62896                                      // 0000000BDFBC: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3480>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 0000000BDFC0: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 0000000BDFCC: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 0000000BDFD0: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000BDFD8: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000BDFDC: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDFE0: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000BDFE4: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000BDFEC: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000BDFF8: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BDFFC: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000BE000: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000BE004: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000BE00C: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BE014: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000BE018: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000BE01C: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000BE020: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE024: BF870095
	.long 0xd71c005a                                           // 0000000BE028: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000BE02C: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000BE030: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000BE034: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE03C: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000000BE040: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000BE048: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE04C: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 0000000BE050: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 0000000BE058: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE05C: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 0000000BE060: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 0000000BE068: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 0000000BE06C: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE074: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 0000000BE078: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 0000000BE07C: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE084: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 0000000BE088: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 0000000BE08C: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE094: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 0000000BE098: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 0000000BE0A0: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 0000000BE0A8: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE0B4: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 0000000BE0B8: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 0000000BE0C0: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 0000000BE0CC: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BE0D4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BE0D8: BE882001
	s_cbranch_execz 62827                                      // 0000000BE0DC: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x348c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 0000000BE0E0: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 0000000BE0EC: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 0000000BE0F0: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 0000000BE0F8: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000BE0FC: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BE100: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 0000000BE104: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000BE10C: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 0000000BE114: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000000BE120: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BE124: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 0000000BE128: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 0000000BE130: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BE134: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000000BE138: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000000BE13C: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000000BE140: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE144: BF870095
	.long 0xd71c0059                                           // 0000000BE148: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000000BE14C: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000BE150: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000BE154: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE15C: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 0000000BE160: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000BE168: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE16C: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 0000000BE170: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 0000000BE178: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE17C: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 0000000BE180: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 0000000BE188: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 0000000BE18C: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE194: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 0000000BE198: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 0000000BE19C: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE1A4: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 0000000BE1A8: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 0000000BE1AC: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE1B4: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 0000000BE1B8: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 0000000BE1C0: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 0000000BE1C8: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE1D4: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 0000000BE1D8: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 0000000BE1E0: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 0000000BE1EC: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BE1F4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BE1F8: BE882002
	s_cbranch_execz 62758                                      // 0000000BE1FC: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3498>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 0000000BE200: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000BE20C: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000BE214: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000BE218: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE21C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000BE220: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 0000000BE228: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 0000000BE234: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BE238: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 0000000BE23C: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000BE240: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 0000000BE248: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BE250: BF870121
	v_add_f32_e32 v82, v82, v89                                // 0000000BE254: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 0000000BE258: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 0000000BE25C: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE260: BF870095
	.long 0xd71c0052                                           // 0000000BE264: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 0000000BE268: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000BE26C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000BE270: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE278: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 0000000BE27C: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000BE288: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE28C: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000BE290: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 0000000BE298: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE29C: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 0000000BE2A0: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 0000000BE2A8: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 0000000BE2AC: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE2B4: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 0000000BE2B8: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 0000000BE2BC: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE2C4: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 0000000BE2C8: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 0000000BE2CC: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE2D4: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 0000000BE2D8: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000BE2E0: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 0000000BE2E8: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE2F4: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 0000000BE2F8: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 0000000BE300: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000BE30C: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BE314: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BE318: BE882003
	s_cbranch_execz 62689                                      // 0000000BE31C: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34a4>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 0000000BE320: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000BE32C: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000BE334: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000BE338: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE33C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000BE340: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000BE348: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 0000000BE354: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE358: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 0000000BE35C: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 0000000BE368: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 0000000BE36C: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000BE370: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BE378: BF870293
	v_exp_f32_e32 v82, v82                                     // 0000000BE37C: 7EA44B52
	.long 0xd71c0052                                           // 0000000BE380: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000BE384: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BE388: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000BE38C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000BE390: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 0000000BE398: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE3A4: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 0000000BE3A8: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000BE3AC: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BE3B4: BF870291
	v_rcp_f32_e32 v84, v83                                     // 0000000BE3B8: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 0000000BE3BC: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BE3C4: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 0000000BE3C8: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 0000000BE3CC: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 0000000BE3D4: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE3D8: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 0000000BE3DC: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 0000000BE3E4: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE3E8: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 0000000BE3EC: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 0000000BE3F4: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BE3FC: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000BE400: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 0000000BE408: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000BE414: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BE41C: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000BE420: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000BE42C: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BE434: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BE438: BE882004
	s_cbranch_execz 62620                                      // 0000000BE43C: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34b0>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 0000000BE440: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000BE44C: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000BE454: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000BE458: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE45C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000BE460: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000BE468: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000BE474: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BE478: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000BE47C: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000BE480: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000BE488: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BE490: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000BE494: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000BE498: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000BE49C: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE4A0: BF870095
	.long 0xd71c0052                                           // 0000000BE4A4: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000BE4A8: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000BE4AC: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000BE4B0: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE4B8: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 0000000BE4BC: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000BE4C8: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE4CC: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000BE4D0: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000BE4D8: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE4DC: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000BE4E0: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000BE4E8: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000BE4EC: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE4F4: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 0000000BE4F8: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 0000000BE4FC: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE504: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 0000000BE508: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 0000000BE50C: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE514: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 0000000BE518: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000BE520: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 0000000BE528: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE534: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000BE538: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000BE540: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000BE54C: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BE554: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BE558: BE882005
	s_cbranch_execz 62551                                      // 0000000BE55C: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34bc>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 0000000BE560: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000BE56C: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000BE574: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000BE578: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE57C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000BE580: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000BE588: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000BE594: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BE598: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000BE59C: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000BE5A0: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000BE5A8: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BE5B0: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000BE5B4: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000BE5B8: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000BE5BC: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE5C0: BF870095
	.long 0xd71c0052                                           // 0000000BE5C4: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000BE5C8: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000BE5CC: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000BE5D0: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE5D8: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 0000000BE5DC: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 0000000BE5E4: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE5EC: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000BE5F0: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000BE5F8: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE5FC: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000BE600: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000BE608: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000BE60C: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE614: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000BE618: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 0000000BE61C: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE624: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 0000000BE628: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 0000000BE62C: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE634: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000BE638: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000BE640: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 0000000BE648: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE654: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000BE658: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000BE660: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000BE66C: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BE674: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BE678: BE882006
	s_cbranch_execz 62482                                      // 0000000BE67C: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34c8>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 0000000BE680: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000BE68C: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000BE694: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000BE698: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE69C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000BE6A0: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000BE6A8: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000BE6B4: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BE6B8: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000BE6BC: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000BE6C0: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000BE6C8: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BE6D0: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000BE6D4: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000BE6D8: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000BE6DC: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE6E0: BF870095
	.long 0xd71c0052                                           // 0000000BE6E4: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000BE6E8: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000BE6EC: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000BE6F0: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE6F8: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 0000000BE6FC: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000BE708: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE70C: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000BE710: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000BE718: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE71C: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000BE720: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000BE728: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000BE72C: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE734: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000BE738: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000BE73C: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE744: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000BE748: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000BE74C: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE754: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000BE758: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000BE760: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 0000000BE768: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE774: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000BE778: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000BE780: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000BE78C: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BE794: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BE798: BE882007
	s_cbranch_execz 62413                                      // 0000000BE79C: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34d4>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 0000000BE7A0: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000BE7AC: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000BE7B4: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000BE7B8: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE7BC: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000BE7C0: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000BE7C8: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000BE7D4: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BE7D8: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000BE7DC: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000BE7E0: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000BE7E8: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BE7F0: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000BE7F4: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000BE7F8: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000BE7FC: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE800: BF870095
	.long 0xd71c0052                                           // 0000000BE804: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000BE808: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000BE80C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000BE810: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE818: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 0000000BE81C: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000BE828: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE82C: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000BE830: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000BE838: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE83C: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000BE840: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000BE848: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000BE84C: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE854: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000BE858: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000BE85C: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE864: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000BE868: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000BE86C: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE874: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000BE878: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000BE880: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 0000000BE888: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE894: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000BE898: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000BE8A0: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000BE8AC: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BE8B4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BE8B8: BE882000
	s_cbranch_execz 62344                                      // 0000000BE8BC: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34e0>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 0000000BE8C0: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 0000000BE8CC: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 0000000BE8D0: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000BE8D8: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000BE8DC: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE8E0: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000BE8E4: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000BE8EC: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000BE8F8: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BE8FC: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000BE900: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000BE904: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000BE90C: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BE914: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000BE918: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000BE91C: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000BE920: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE924: BF870095
	.long 0xd71c0052                                           // 0000000BE928: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000BE92C: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000BE930: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000BE934: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE93C: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 0000000BE940: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000BE948: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE94C: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 0000000BE950: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 0000000BE958: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE95C: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 0000000BE960: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 0000000BE968: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 0000000BE96C: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE974: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 0000000BE978: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 0000000BE97C: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE984: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 0000000BE988: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 0000000BE98C: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE994: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 0000000BE998: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 0000000BE9A0: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 0000000BE9A8: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BE9B4: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 0000000BE9B8: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 0000000BE9C0: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 0000000BE9CC: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BE9D4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BE9D8: BE882001
	s_cbranch_execz 62275                                      // 0000000BE9DC: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34ec>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 0000000BE9E0: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 0000000BE9EC: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 0000000BE9F0: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 0000000BE9F8: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000BE9FC: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BEA00: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 0000000BEA04: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000BEA0C: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 0000000BEA14: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 0000000BEA20: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BEA24: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 0000000BEA28: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 0000000BEA30: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BEA34: BF870121
	v_add_f32_e32 v81, v81, v82                                // 0000000BEA38: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 0000000BEA3C: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 0000000BEA40: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEA44: BF870095
	.long 0xd71c0051                                           // 0000000BEA48: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000000BEA4C: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000BEA50: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000BEA54: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEA5C: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 0000000BEA60: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000BEA68: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEA6C: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 0000000BEA70: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 0000000BEA78: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEA7C: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 0000000BEA80: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 0000000BEA88: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 0000000BEA8C: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEA94: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 0000000BEA98: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 0000000BEA9C: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEAA4: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 0000000BEAA8: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 0000000BEAAC: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEAB4: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 0000000BEAB8: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 0000000BEAC0: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 0000000BEAC8: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEAD4: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 0000000BEAD8: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 0000000BEAE0: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 0000000BEAEC: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BEAF4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BEAF8: BE882002
	s_cbranch_execz 62206                                      // 0000000BEAFC: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34f8>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 0000000BEB00: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000BEB0C: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000BEB14: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000BEB18: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEB1C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000BEB20: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 0000000BEB28: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 0000000BEB34: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BEB38: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 0000000BEB3C: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000BEB40: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 0000000BEB48: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BEB50: BF870121
	v_add_f32_e32 v74, v74, v81                                // 0000000BEB54: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 0000000BEB58: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 0000000BEB5C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEB60: BF870095
	.long 0xd71c004a                                           // 0000000BEB64: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 0000000BEB68: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000BEB6C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000BEB70: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEB78: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 0000000BEB7C: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000BEB88: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEB8C: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000BEB90: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 0000000BEB98: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEB9C: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 0000000BEBA0: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 0000000BEBA8: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 0000000BEBAC: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEBB4: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 0000000BEBB8: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 0000000BEBBC: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEBC4: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 0000000BEBC8: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 0000000BEBCC: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEBD4: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 0000000BEBD8: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000BEBE0: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 0000000BEBE8: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEBF4: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 0000000BEBF8: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 0000000BEC00: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000BEC0C: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BEC14: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BEC18: BE882003
	s_cbranch_execz 62137                                      // 0000000BEC1C: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3504>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 0000000BEC20: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000BEC2C: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000BEC34: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000BEC38: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEC3C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000BEC40: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000BEC48: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 0000000BEC54: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEC58: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 0000000BEC5C: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 0000000BEC68: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 0000000BEC6C: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000BEC70: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BEC78: BF870293
	v_exp_f32_e32 v74, v74                                     // 0000000BEC7C: 7E944B4A
	.long 0xd71c004a                                           // 0000000BEC80: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000BEC84: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BEC88: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000BEC8C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000BEC90: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 0000000BEC98: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BECA4: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 0000000BECA8: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000BECAC: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BECB4: BF870291
	v_rcp_f32_e32 v76, v75                                     // 0000000BECB8: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 0000000BECBC: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BECC4: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 0000000BECC8: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 0000000BECCC: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 0000000BECD4: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BECD8: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 0000000BECDC: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 0000000BECE4: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BECE8: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 0000000BECEC: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 0000000BECF4: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BECFC: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000BED00: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 0000000BED08: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000BED14: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BED1C: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000BED20: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000BED2C: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BED34: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BED38: BE882004
	s_cbranch_execz 62068                                      // 0000000BED3C: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3510>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 0000000BED40: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000BED4C: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000BED54: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000BED58: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BED5C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000BED60: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000BED68: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000BED74: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BED78: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000BED7C: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000BED80: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000BED88: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BED90: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000BED94: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000BED98: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000BED9C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEDA0: BF870095
	.long 0xd71c004a                                           // 0000000BEDA4: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000BEDA8: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000BEDAC: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000BEDB0: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEDB8: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 0000000BEDBC: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000BEDC8: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEDCC: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000BEDD0: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000BEDD8: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEDDC: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000BEDE0: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000BEDE8: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000BEDEC: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEDF4: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 0000000BEDF8: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 0000000BEDFC: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEE04: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 0000000BEE08: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 0000000BEE0C: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEE14: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 0000000BEE18: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000BEE20: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 0000000BEE28: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEE34: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000BEE38: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000BEE40: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000BEE4C: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BEE54: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BEE58: BE882005
	s_cbranch_execz 61999                                      // 0000000BEE5C: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x351c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 0000000BEE60: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000BEE6C: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000BEE74: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000BEE78: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEE7C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000BEE80: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000BEE88: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000BEE94: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BEE98: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000BEE9C: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000BEEA0: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000BEEA8: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BEEB0: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000BEEB4: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000BEEB8: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000BEEBC: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEEC0: BF870095
	.long 0xd71c004a                                           // 0000000BEEC4: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000BEEC8: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000BEECC: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000BEED0: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEED8: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000000BEEDC: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 0000000BEEE4: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEEEC: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000BEEF0: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000BEEF8: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEEFC: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000BEF00: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000BEF08: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000BEF0C: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEF14: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000BEF18: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 0000000BEF1C: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEF24: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 0000000BEF28: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 0000000BEF2C: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEF34: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000BEF38: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000BEF40: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 0000000BEF48: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEF54: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000BEF58: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000BEF60: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000BEF6C: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BEF74: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BEF78: BE882006
	s_cbranch_execz 61930                                      // 0000000BEF7C: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3528>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 0000000BEF80: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000BEF8C: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000BEF94: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000BEF98: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEF9C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000BEFA0: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000BEFA8: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000BEFB4: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BEFB8: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000BEFBC: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000BEFC0: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000BEFC8: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BEFD0: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000BEFD4: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000BEFD8: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000BEFDC: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEFE0: BF870095
	.long 0xd71c004a                                           // 0000000BEFE4: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000BEFE8: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000BEFEC: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000BEFF0: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BEFF8: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 0000000BEFFC: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000BF008: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF00C: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000BF010: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000BF018: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF01C: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000BF020: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000BF028: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000BF02C: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF034: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000BF038: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000BF03C: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF044: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000BF048: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000BF04C: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF054: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000BF058: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000BF060: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 0000000BF068: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF074: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000BF078: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000BF080: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000BF08C: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BF094: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BF098: BE882007
	s_cbranch_execz 61861                                      // 0000000BF09C: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3534>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 0000000BF0A0: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000BF0AC: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000BF0B4: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000BF0B8: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF0BC: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000BF0C0: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000BF0C8: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000BF0D4: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BF0D8: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000BF0DC: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000BF0E0: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000BF0E8: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BF0F0: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000BF0F4: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000BF0F8: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000BF0FC: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF100: BF870095
	.long 0xd71c004a                                           // 0000000BF104: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000BF108: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000BF10C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000BF110: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF118: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 0000000BF11C: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000BF128: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF12C: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000BF130: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000BF138: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF13C: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000BF140: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000BF148: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000BF14C: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF154: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000BF158: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000BF15C: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF164: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000BF168: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000BF16C: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF174: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000BF178: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000BF180: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 0000000BF188: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF194: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000BF198: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000BF1A0: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000BF1AC: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BF1B4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BF1B8: BE882000
	s_cbranch_execz 61792                                      // 0000000BF1BC: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3540>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 0000000BF1C0: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 0000000BF1CC: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 0000000BF1D0: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000BF1D8: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000BF1DC: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF1E0: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000BF1E4: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000BF1EC: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000BF1F8: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BF1FC: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000BF200: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000BF204: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000BF20C: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BF214: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000BF218: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000BF21C: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000BF220: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF224: BF870095
	.long 0xd71c004a                                           // 0000000BF228: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000BF22C: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000BF230: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000BF234: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF23C: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000000BF240: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000BF248: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF24C: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 0000000BF250: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 0000000BF258: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF25C: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000000BF260: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000000BF268: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 0000000BF26C: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF274: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 0000000BF278: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 0000000BF27C: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF284: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 0000000BF288: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 0000000BF28C: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF294: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 0000000BF298: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 0000000BF2A0: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 0000000BF2A8: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF2B4: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 0000000BF2B8: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 0000000BF2C0: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 0000000BF2CC: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BF2D4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BF2D8: BE882001
	s_cbranch_execz 61723                                      // 0000000BF2DC: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x354c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 0000000BF2E0: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 0000000BF2EC: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 0000000BF2F0: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 0000000BF2F8: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000BF2FC: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BF300: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 0000000BF304: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000BF30C: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 0000000BF314: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000000BF320: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BF324: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 0000000BF328: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 0000000BF330: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BF334: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000000BF338: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000000BF33C: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000000BF340: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF344: BF870095
	.long 0xd71c0049                                           // 0000000BF348: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000BF34C: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000BF350: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000BF354: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF35C: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 0000000BF360: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000BF368: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF36C: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 0000000BF370: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 0000000BF378: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF37C: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 0000000BF380: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 0000000BF388: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 0000000BF38C: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF394: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 0000000BF398: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 0000000BF39C: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF3A4: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 0000000BF3A8: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 0000000BF3AC: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF3B4: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 0000000BF3B8: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 0000000BF3C0: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 0000000BF3C8: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF3D4: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 0000000BF3D8: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 0000000BF3E0: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 0000000BF3EC: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BF3F4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BF3F8: BE882002
	s_cbranch_execz 61654                                      // 0000000BF3FC: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3558>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 0000000BF400: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000BF40C: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000BF414: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000BF418: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF41C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000BF420: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 0000000BF428: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 0000000BF434: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BF438: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 0000000BF43C: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000BF440: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 0000000BF448: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BF450: BF870121
	v_add_f32_e32 v66, v66, v73                                // 0000000BF454: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 0000000BF458: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 0000000BF45C: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF460: BF870095
	.long 0xd71c0042                                           // 0000000BF464: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 0000000BF468: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000BF46C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000BF470: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF478: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 0000000BF47C: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000BF488: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF48C: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000BF490: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 0000000BF498: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF49C: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 0000000BF4A0: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 0000000BF4A8: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 0000000BF4AC: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF4B4: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 0000000BF4B8: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 0000000BF4BC: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF4C4: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 0000000BF4C8: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 0000000BF4CC: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF4D4: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 0000000BF4D8: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000BF4E0: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 0000000BF4E8: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF4F4: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 0000000BF4F8: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 0000000BF500: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000BF50C: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BF514: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BF518: BE882003
	s_cbranch_execz 61585                                      // 0000000BF51C: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3564>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 0000000BF520: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000BF52C: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000BF534: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000BF538: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF53C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000BF540: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000BF548: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 0000000BF554: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF558: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 0000000BF55C: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 0000000BF568: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 0000000BF56C: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000BF570: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BF578: BF870293
	v_exp_f32_e32 v66, v66                                     // 0000000BF57C: 7E844B42
	.long 0xd71c0042                                           // 0000000BF580: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000BF584: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BF588: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000BF58C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000BF590: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 0000000BF598: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF5A4: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 0000000BF5A8: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000BF5AC: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BF5B4: BF870291
	v_rcp_f32_e32 v68, v67                                     // 0000000BF5B8: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 0000000BF5BC: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BF5C4: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 0000000BF5C8: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 0000000BF5CC: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 0000000BF5D4: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF5D8: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 0000000BF5DC: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 0000000BF5E4: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF5E8: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 0000000BF5EC: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 0000000BF5F4: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BF5FC: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000BF600: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 0000000BF608: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000BF614: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BF61C: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000BF620: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000BF62C: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BF634: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BF638: BE882004
	s_cbranch_execz 61516                                      // 0000000BF63C: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3570>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 0000000BF640: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000BF64C: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000BF654: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000BF658: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF65C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000BF660: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000BF668: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000BF674: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BF678: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000BF67C: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000BF680: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000BF688: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BF690: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000BF694: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000BF698: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000BF69C: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF6A0: BF870095
	.long 0xd71c0042                                           // 0000000BF6A4: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000BF6A8: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000BF6AC: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000BF6B0: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF6B8: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 0000000BF6BC: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000BF6C8: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF6CC: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000BF6D0: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000BF6D8: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF6DC: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000BF6E0: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000BF6E8: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000BF6EC: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF6F4: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 0000000BF6F8: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 0000000BF6FC: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF704: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 0000000BF708: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 0000000BF70C: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF714: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 0000000BF718: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000BF720: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 0000000BF728: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF734: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000BF738: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000BF740: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000BF74C: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BF754: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000BF758: BE882005
	s_cbranch_execz 61447                                      // 0000000BF75C: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x357c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 0000000BF760: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000BF76C: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000BF774: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000BF778: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF77C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000BF780: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000BF788: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000BF794: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BF798: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000BF79C: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000BF7A0: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000BF7A8: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BF7B0: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000BF7B4: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000BF7B8: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000BF7BC: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF7C0: BF870095
	.long 0xd71c0042                                           // 0000000BF7C4: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000BF7C8: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000BF7CC: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000BF7D0: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF7D8: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 0000000BF7DC: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 0000000BF7E4: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF7EC: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000BF7F0: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000BF7F8: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF7FC: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000BF800: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000BF808: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000BF80C: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF814: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000BF818: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 0000000BF81C: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF824: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 0000000BF828: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 0000000BF82C: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF834: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000BF838: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000BF840: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 0000000BF848: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF854: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000BF858: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000BF860: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000BF86C: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BF874: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000BF878: BE882006
	s_cbranch_execz 61378                                      // 0000000BF87C: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3588>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 0000000BF880: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000BF88C: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000BF894: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000BF898: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF89C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000BF8A0: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000BF8A8: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000BF8B4: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BF8B8: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000BF8BC: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000BF8C0: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000BF8C8: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BF8D0: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000BF8D4: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000BF8D8: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000BF8DC: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF8E0: BF870095
	.long 0xd71c0042                                           // 0000000BF8E4: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000BF8E8: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000BF8EC: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000BF8F0: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF8F8: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 0000000BF8FC: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000BF908: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF90C: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000BF910: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000BF918: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF91C: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000BF920: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000BF928: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000BF92C: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF934: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000BF938: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000BF93C: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF944: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000BF948: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000BF94C: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF954: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000BF958: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000BF960: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 0000000BF968: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF974: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000BF978: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000BF980: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000BF98C: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BF994: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000BF998: BE882007
	s_cbranch_execz 61309                                      // 0000000BF99C: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3594>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 0000000BF9A0: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000BF9AC: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000BF9B4: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000BF9B8: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BF9BC: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000BF9C0: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000BF9C8: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000BF9D4: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BF9D8: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000BF9DC: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000BF9E0: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000BF9E8: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BF9F0: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000BF9F4: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000BF9F8: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000BF9FC: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFA00: BF870095
	.long 0xd71c0042                                           // 0000000BFA04: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000BFA08: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000BFA0C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000BFA10: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFA18: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 0000000BFA1C: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000BFA28: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFA2C: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000BFA30: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000BFA38: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFA3C: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000BFA40: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000BFA48: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000BFA4C: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFA54: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000BFA58: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000BFA5C: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFA64: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000BFA68: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000BFA6C: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFA74: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000BFA78: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000BFA80: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 0000000BFA88: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFA94: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000BFA98: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000BFAA0: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000BFAAC: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BFAB4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000BFAB8: BE882000
	s_cbranch_execz 61240                                      // 0000000BFABC: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35a0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 0000000BFAC0: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 0000000BFACC: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 0000000BFAD0: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000BFAD8: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000BFADC: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFAE0: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000BFAE4: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000BFAEC: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000BFAF8: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BFAFC: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000BFB00: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000BFB04: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000BFB0C: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BFB14: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000BFB18: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000BFB1C: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000BFB20: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFB24: BF870095
	.long 0xd71c0042                                           // 0000000BFB28: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000BFB2C: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000BFB30: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000BFB34: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFB3C: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 0000000BFB40: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000BFB48: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFB4C: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 0000000BFB50: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 0000000BFB58: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFB5C: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 0000000BFB60: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 0000000BFB68: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 0000000BFB6C: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFB74: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 0000000BFB78: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 0000000BFB7C: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFB84: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 0000000BFB88: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 0000000BFB8C: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFB94: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 0000000BFB98: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 0000000BFBA0: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 0000000BFBA8: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFBB4: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 0000000BFBB8: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 0000000BFBC0: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 0000000BFBCC: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BFBD4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000BFBD8: BE882001
	s_cbranch_execz 61171                                      // 0000000BFBDC: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35ac>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 0000000BFBE0: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 0000000BFBEC: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 0000000BFBF0: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 0000000BFBF8: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000BFBFC: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BFC00: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 0000000BFC04: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000BFC0C: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 0000000BFC14: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 0000000BFC20: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BFC24: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 0000000BFC28: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 0000000BFC30: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BFC34: BF870121
	v_add_f32_e32 v65, v65, v66                                // 0000000BFC38: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 0000000BFC3C: 7E841143
	v_exp_f32_e32 v65, v65                                     // 0000000BFC40: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFC44: BF870095
	.long 0xd71c0041                                           // 0000000BFC48: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 0000000BFC4C: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 0000000BFC50: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000BFC54: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFC5C: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 0000000BFC60: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000BFC68: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFC6C: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 0000000BFC70: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 0000000BFC78: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFC7C: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 0000000BFC80: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 0000000BFC88: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 0000000BFC8C: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFC94: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 0000000BFC98: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 0000000BFC9C: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFCA4: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 0000000BFCA8: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 0000000BFCAC: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFCB4: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 0000000BFCB8: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 0000000BFCC0: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 0000000BFCC8: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFCD4: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 0000000BFCD8: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 0000000BFCE0: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 0000000BFCEC: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BFCF4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000BFCF8: BE882002
	s_cbranch_execz 61102                                      // 0000000BFCFC: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35b8>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 0000000BFD00: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000BFD0C: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000BFD14: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000BFD18: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFD1C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000BFD20: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 0000000BFD28: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 0000000BFD34: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BFD38: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 0000000BFD3C: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000BFD40: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 0000000BFD48: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BFD50: BF870121
	v_add_f32_e32 v58, v58, v65                                // 0000000BFD54: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 0000000BFD58: 7E821142
	v_exp_f32_e32 v58, v58                                     // 0000000BFD5C: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFD60: BF870095
	.long 0xd71c003a                                           // 0000000BFD64: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 0000000BFD68: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000BFD6C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000BFD70: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFD78: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 0000000BFD7C: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000BFD88: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFD8C: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000BFD90: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 0000000BFD98: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFD9C: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 0000000BFDA0: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 0000000BFDA8: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 0000000BFDAC: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFDB4: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 0000000BFDB8: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 0000000BFDBC: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFDC4: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 0000000BFDC8: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 0000000BFDCC: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFDD4: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 0000000BFDD8: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000BFDE0: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 0000000BFDE8: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFDF4: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 0000000BFDF8: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 0000000BFE00: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000BFE0C: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BFE14: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000BFE18: BE882003
	s_cbranch_execz 61033                                      // 0000000BFE1C: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35c4>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 0000000BFE20: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000BFE2C: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000BFE34: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000BFE38: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFE3C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000BFE40: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000BFE48: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 0000000BFE54: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFE58: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 0000000BFE5C: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 0000000BFE68: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 0000000BFE6C: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000BFE70: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BFE78: BF870293
	v_exp_f32_e32 v58, v58                                     // 0000000BFE7C: 7E744B3A
	.long 0xd71c003a                                           // 0000000BFE80: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000BFE84: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BFE88: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000BFE8C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000BFE90: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 0000000BFE98: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFEA4: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 0000000BFEA8: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000BFEAC: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BFEB4: BF870291
	v_rcp_f32_e32 v60, v59                                     // 0000000BFEB8: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 0000000BFEBC: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BFEC4: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 0000000BFEC8: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 0000000BFECC: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 0000000BFED4: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFED8: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 0000000BFEDC: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 0000000BFEE4: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFEE8: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 0000000BFEEC: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 0000000BFEF4: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BFEFC: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000BFF00: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 0000000BFF08: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000BFF14: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BFF1C: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000BFF20: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000BFF2C: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000BFF34: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000BFF38: BE882004
	s_cbranch_execz 60964                                      // 0000000BFF3C: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35d0>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 0000000BFF40: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000BFF4C: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000BFF54: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000BFF58: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFF5C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000BFF60: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000BFF68: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000BFF74: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000BFF78: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000BFF7C: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000BFF80: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000BFF88: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BFF90: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000BFF94: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000BFF98: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000BFF9C: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFFA0: BF870095
	.long 0xd71c003a                                           // 0000000BFFA4: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000BFFA8: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000BFFAC: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000BFFB0: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFFB8: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 0000000BFFBC: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000BFFC8: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFFCC: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000BFFD0: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000BFFD8: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFFDC: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000BFFE0: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000BFFE8: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000BFFEC: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BFFF4: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 0000000BFFF8: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 0000000BFFFC: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0004: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 0000000C0008: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 0000000C000C: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0014: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 0000000C0018: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000C0020: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 0000000C0028: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0034: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000C0038: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000C0040: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000C004C: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C0054: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C0058: BE882005
	s_cbranch_execz 60895                                      // 0000000C005C: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35dc>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 0000000C0060: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000C006C: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000C0074: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000C0078: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C007C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000C0080: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000C0088: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000C0094: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C0098: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000C009C: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000C00A0: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000C00A8: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C00B0: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000C00B4: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000C00B8: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000C00BC: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C00C0: BF870095
	.long 0xd71c003a                                           // 0000000C00C4: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000C00C8: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000C00CC: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000C00D0: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C00D8: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000C00DC: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 0000000C00E4: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C00EC: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000C00F0: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000C00F8: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C00FC: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000C0100: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000C0108: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000C010C: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0114: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000C0118: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 0000000C011C: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0124: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 0000000C0128: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 0000000C012C: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0134: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000C0138: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000C0140: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 0000000C0148: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0154: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000C0158: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000C0160: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000C016C: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C0174: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C0178: BE882006
	s_cbranch_execz 60826                                      // 0000000C017C: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35e8>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 0000000C0180: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000C018C: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000C0194: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000C0198: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C019C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000C01A0: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000C01A8: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000C01B4: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C01B8: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000C01BC: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000C01C0: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000C01C8: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C01D0: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000C01D4: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000C01D8: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000C01DC: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C01E0: BF870095
	.long 0xd71c003a                                           // 0000000C01E4: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000C01E8: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000C01EC: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000C01F0: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C01F8: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 0000000C01FC: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000C0208: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C020C: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000C0210: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000C0218: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C021C: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000C0220: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000C0228: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000C022C: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0234: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000C0238: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000C023C: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0244: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000C0248: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000C024C: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0254: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000C0258: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000C0260: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 0000000C0268: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0274: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000C0278: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000C0280: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000C028C: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C0294: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C0298: BE882007
	s_cbranch_execz 60757                                      // 0000000C029C: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35f4>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 0000000C02A0: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000C02AC: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000C02B4: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000C02B8: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C02BC: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000C02C0: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000C02C8: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000C02D4: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C02D8: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000C02DC: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000C02E0: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000C02E8: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C02F0: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000C02F4: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000C02F8: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000C02FC: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0300: BF870095
	.long 0xd71c003a                                           // 0000000C0304: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000C0308: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000C030C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000C0310: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0318: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 0000000C031C: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000C0328: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C032C: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000C0330: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000C0338: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C033C: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000C0340: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000C0348: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000C034C: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0354: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000C0358: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000C035C: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0364: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000C0368: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000C036C: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0374: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000C0378: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000C0380: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 0000000C0388: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0394: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000C0398: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000C03A0: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000C03AC: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C03B4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C03B8: BE882000
	s_cbranch_execz 60688                                      // 0000000C03BC: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3600>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 0000000C03C0: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 0000000C03CC: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 0000000C03D0: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000C03D8: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000C03DC: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C03E0: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000C03E4: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000C03EC: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000C03F8: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C03FC: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000C0400: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000C0404: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000C040C: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C0414: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000C0418: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000C041C: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000C0420: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0424: BF870095
	.long 0xd71c003a                                           // 0000000C0428: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000C042C: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000C0430: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000C0434: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C043C: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000C0440: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000C0448: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C044C: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 0000000C0450: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 0000000C0458: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C045C: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 0000000C0460: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 0000000C0468: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 0000000C046C: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0474: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 0000000C0478: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 0000000C047C: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0484: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 0000000C0488: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 0000000C048C: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0494: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 0000000C0498: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 0000000C04A0: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 0000000C04A8: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C04B4: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 0000000C04B8: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 0000000C04C0: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 0000000C04CC: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C04D4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C04D8: BE882001
	s_cbranch_execz 60619                                      // 0000000C04DC: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x360c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 0000000C04E0: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 0000000C04EC: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 0000000C04F0: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 0000000C04F8: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000C04FC: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C0500: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 0000000C0504: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000C050C: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 0000000C0514: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 0000000C0520: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C0524: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 0000000C0528: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 0000000C0530: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C0534: BF870121
	v_add_f32_e32 v57, v57, v58                                // 0000000C0538: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 0000000C053C: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 0000000C0540: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0544: BF870095
	.long 0xd71c0039                                           // 0000000C0548: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000000C054C: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000C0550: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000C0554: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C055C: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 0000000C0560: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000C0568: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C056C: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 0000000C0570: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 0000000C0578: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C057C: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 0000000C0580: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 0000000C0588: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 0000000C058C: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0594: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 0000000C0598: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 0000000C059C: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C05A4: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 0000000C05A8: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 0000000C05AC: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C05B4: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 0000000C05B8: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 0000000C05C0: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 0000000C05C8: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C05D4: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 0000000C05D8: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000000C05E0: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 0000000C05EC: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C05F4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C05F8: BE882002
	s_cbranch_execz 60550                                      // 0000000C05FC: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3618>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 0000000C0600: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000C060C: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000C0614: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000C0618: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C061C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000C0620: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 0000000C0628: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 0000000C0634: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C0638: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 0000000C063C: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000C0640: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 0000000C0648: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C0650: BF870121
	v_add_f32_e32 v50, v50, v57                                // 0000000C0654: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 0000000C0658: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 0000000C065C: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0660: BF870095
	.long 0xd71c0032                                           // 0000000C0664: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 0000000C0668: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000C066C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000C0670: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0678: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 0000000C067C: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000C0688: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C068C: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000C0690: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 0000000C0698: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C069C: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 0000000C06A0: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 0000000C06A8: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 0000000C06AC: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C06B4: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 0000000C06B8: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 0000000C06BC: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C06C4: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 0000000C06C8: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 0000000C06CC: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C06D4: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 0000000C06D8: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000C06E0: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 0000000C06E8: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C06F4: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 0000000C06F8: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 0000000C0700: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000C070C: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C0714: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C0718: BE882003
	s_cbranch_execz 60481                                      // 0000000C071C: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3624>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 0000000C0720: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000C072C: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000C0734: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000C0738: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C073C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000C0740: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000C0748: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 0000000C0754: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0758: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 0000000C075C: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 0000000C0768: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 0000000C076C: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000C0770: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C0778: BF870293
	v_exp_f32_e32 v50, v50                                     // 0000000C077C: 7E644B32
	.long 0xd71c0032                                           // 0000000C0780: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000C0784: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C0788: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000C078C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000C0790: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 0000000C0798: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C07A4: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 0000000C07A8: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000C07AC: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C07B4: BF870291
	v_rcp_f32_e32 v52, v51                                     // 0000000C07B8: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 0000000C07BC: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C07C4: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 0000000C07C8: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 0000000C07CC: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 0000000C07D4: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C07D8: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 0000000C07DC: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 0000000C07E4: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C07E8: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 0000000C07EC: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 0000000C07F4: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C07FC: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000C0800: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 0000000C0808: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000C0814: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C081C: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000C0820: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000C082C: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C0834: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C0838: BE882004
	s_cbranch_execz 60412                                      // 0000000C083C: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3630>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 0000000C0840: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000C084C: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000C0854: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000C0858: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C085C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000C0860: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000C0868: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000C0874: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C0878: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000C087C: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000C0880: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000C0888: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C0890: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000C0894: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000C0898: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000C089C: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C08A0: BF870095
	.long 0xd71c0032                                           // 0000000C08A4: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000C08A8: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000C08AC: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000C08B0: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C08B8: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 0000000C08BC: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000C08C8: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C08CC: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000C08D0: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000C08D8: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C08DC: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000C08E0: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000C08E8: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000C08EC: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C08F4: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 0000000C08F8: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 0000000C08FC: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0904: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 0000000C0908: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 0000000C090C: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0914: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 0000000C0918: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000C0920: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 0000000C0928: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0934: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000C0938: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000C0940: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000C094C: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C0954: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C0958: BE882005
	s_cbranch_execz 60343                                      // 0000000C095C: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x363c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 0000000C0960: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000C096C: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000C0974: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000C0978: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C097C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000C0980: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000C0988: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000C0994: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C0998: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000C099C: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000C09A0: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000C09A8: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C09B0: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000C09B4: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000C09B8: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000C09BC: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C09C0: BF870095
	.long 0xd71c0032                                           // 0000000C09C4: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000C09C8: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000C09CC: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000C09D0: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C09D8: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 0000000C09DC: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 0000000C09E4: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C09EC: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000C09F0: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000C09F8: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C09FC: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000C0A00: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000C0A08: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000C0A0C: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0A14: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000C0A18: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 0000000C0A1C: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0A24: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 0000000C0A28: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 0000000C0A2C: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0A34: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000C0A38: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000C0A40: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 0000000C0A48: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0A54: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000C0A58: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000C0A60: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000C0A6C: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C0A74: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C0A78: BE882006
	s_cbranch_execz 60274                                      // 0000000C0A7C: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3648>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 0000000C0A80: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000C0A8C: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000C0A94: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000C0A98: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0A9C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000C0AA0: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000C0AA8: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000C0AB4: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C0AB8: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000C0ABC: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000C0AC0: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000C0AC8: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C0AD0: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000C0AD4: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000C0AD8: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000C0ADC: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0AE0: BF870095
	.long 0xd71c0032                                           // 0000000C0AE4: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000C0AE8: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000C0AEC: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000C0AF0: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0AF8: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 0000000C0AFC: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000C0B08: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0B0C: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000C0B10: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000C0B18: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0B1C: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000C0B20: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000C0B28: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000C0B2C: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0B34: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000C0B38: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 0000000C0B3C: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0B44: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 0000000C0B48: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000C0B4C: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0B54: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000C0B58: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000C0B60: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 0000000C0B68: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0B74: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000C0B78: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000C0B80: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000C0B8C: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C0B94: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C0B98: BE882007
	s_cbranch_execz 60205                                      // 0000000C0B9C: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3654>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 0000000C0BA0: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000C0BAC: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000C0BB4: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000C0BB8: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0BBC: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000C0BC0: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000C0BC8: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000C0BD4: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C0BD8: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000C0BDC: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000C0BE0: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000C0BE8: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C0BF0: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000C0BF4: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000C0BF8: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000C0BFC: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0C00: BF870095
	.long 0xd71c0032                                           // 0000000C0C04: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000C0C08: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000C0C0C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000C0C10: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0C18: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 0000000C0C1C: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000C0C28: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0C2C: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000C0C30: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000C0C38: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0C3C: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000C0C40: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000C0C48: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000C0C4C: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0C54: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000C0C58: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 0000000C0C5C: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0C64: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 0000000C0C68: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000C0C6C: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0C74: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000C0C78: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000C0C80: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 0000000C0C88: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0C94: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000C0C98: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000C0CA0: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000C0CAC: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C0CB4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C0CB8: BE882000
	s_cbranch_execz 60136                                      // 0000000C0CBC: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3660>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 0000000C0CC0: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 0000000C0CCC: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 0000000C0CD0: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000C0CD8: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000C0CDC: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0CE0: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000C0CE4: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000C0CEC: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000C0CF8: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C0CFC: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000C0D00: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000C0D04: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000C0D0C: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C0D14: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000C0D18: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000C0D1C: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000C0D20: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0D24: BF870095
	.long 0xd71c0032                                           // 0000000C0D28: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000C0D2C: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000C0D30: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000C0D34: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0D3C: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 0000000C0D40: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000C0D48: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0D4C: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 0000000C0D50: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 0000000C0D58: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0D5C: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 0000000C0D60: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 0000000C0D68: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 0000000C0D6C: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0D74: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 0000000C0D78: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 0000000C0D7C: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0D84: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 0000000C0D88: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 0000000C0D8C: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0D94: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 0000000C0D98: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 0000000C0DA0: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 0000000C0DA8: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0DB4: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 0000000C0DB8: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 0000000C0DC0: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 0000000C0DCC: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C0DD4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C0DD8: BE882001
	s_cbranch_execz 60067                                      // 0000000C0DDC: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x366c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 0000000C0DE0: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 0000000C0DEC: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 0000000C0DF0: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 0000000C0DF8: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000C0DFC: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C0E00: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 0000000C0E04: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000C0E0C: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 0000000C0E14: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 0000000C0E20: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C0E24: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 0000000C0E28: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 0000000C0E30: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C0E34: BF870121
	v_add_f32_e32 v49, v49, v50                                // 0000000C0E38: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 0000000C0E3C: 7E641133
	v_exp_f32_e32 v49, v49                                     // 0000000C0E40: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0E44: BF870095
	.long 0xd71c0031                                           // 0000000C0E48: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 0000000C0E4C: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000000C0E50: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000C0E54: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0E5C: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 0000000C0E60: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000C0E68: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0E6C: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 0000000C0E70: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 0000000C0E78: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0E7C: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 0000000C0E80: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 0000000C0E88: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 0000000C0E8C: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0E94: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 0000000C0E98: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 0000000C0E9C: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0EA4: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 0000000C0EA8: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 0000000C0EAC: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0EB4: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 0000000C0EB8: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 0000000C0EC0: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 0000000C0EC8: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0ED4: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 0000000C0ED8: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 0000000C0EE0: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 0000000C0EEC: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C0EF4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C0EF8: BE882002
	s_cbranch_execz 59998                                      // 0000000C0EFC: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3678>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 0000000C0F00: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000C0F0C: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000C0F14: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000C0F18: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0F1C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000C0F20: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 0000000C0F28: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 0000000C0F34: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C0F38: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 0000000C0F3C: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000C0F40: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 0000000C0F48: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C0F50: BF870121
	v_add_f32_e32 v42, v42, v49                                // 0000000C0F54: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 0000000C0F58: 7E621132
	v_exp_f32_e32 v42, v42                                     // 0000000C0F5C: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0F60: BF870095
	.long 0xd71c002a                                           // 0000000C0F64: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 0000000C0F68: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000C0F6C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000C0F70: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0F78: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 0000000C0F7C: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000C0F88: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0F8C: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000C0F90: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 0000000C0F98: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0F9C: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 0000000C0FA0: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 0000000C0FA8: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 0000000C0FAC: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0FB4: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 0000000C0FB8: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 0000000C0FBC: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0FC4: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 0000000C0FC8: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 0000000C0FCC: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0FD4: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 0000000C0FD8: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000C0FE0: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 0000000C0FE8: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C0FF4: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 0000000C0FF8: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 0000000C1000: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000C100C: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C1014: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C1018: BE882003
	s_cbranch_execz 59929                                      // 0000000C101C: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3684>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 0000000C1020: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000C102C: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000C1034: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000C1038: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C103C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000C1040: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000C1048: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 0000000C1054: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1058: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 0000000C105C: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 0000000C1068: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 0000000C106C: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000C1070: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C1078: BF870293
	v_exp_f32_e32 v42, v42                                     // 0000000C107C: 7E544B2A
	.long 0xd71c002a                                           // 0000000C1080: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000C1084: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C1088: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000C108C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000C1090: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 0000000C1098: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C10A4: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 0000000C10A8: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000C10AC: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C10B4: BF870291
	v_rcp_f32_e32 v44, v43                                     // 0000000C10B8: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 0000000C10BC: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C10C4: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 0000000C10C8: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 0000000C10CC: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 0000000C10D4: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C10D8: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 0000000C10DC: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 0000000C10E4: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C10E8: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 0000000C10EC: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 0000000C10F4: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C10FC: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000C1100: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 0000000C1108: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000C1114: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C111C: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000C1120: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000C112C: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C1134: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C1138: BE882004
	s_cbranch_execz 59860                                      // 0000000C113C: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3690>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 0000000C1140: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000C114C: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000C1154: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000C1158: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C115C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000C1160: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000C1168: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000C1174: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C1178: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000C117C: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000C1180: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000C1188: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C1190: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000C1194: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000C1198: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000C119C: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C11A0: BF870095
	.long 0xd71c002a                                           // 0000000C11A4: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000C11A8: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000C11AC: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000C11B0: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C11B8: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 0000000C11BC: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000C11C8: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C11CC: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000C11D0: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000C11D8: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C11DC: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000C11E0: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000C11E8: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000C11EC: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C11F4: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 0000000C11F8: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 0000000C11FC: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1204: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 0000000C1208: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 0000000C120C: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1214: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 0000000C1218: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000C1220: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 0000000C1228: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1234: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000C1238: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000C1240: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000C124C: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C1254: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C1258: BE882005
	s_cbranch_execz 59791                                      // 0000000C125C: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x369c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 0000000C1260: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000C126C: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000C1274: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000C1278: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C127C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000C1280: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000C1288: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000C1294: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C1298: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000C129C: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000C12A0: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000C12A8: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C12B0: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000C12B4: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000C12B8: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000C12BC: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C12C0: BF870095
	.long 0xd71c002a                                           // 0000000C12C4: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000C12C8: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000C12CC: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000C12D0: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C12D8: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000C12DC: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 0000000C12E4: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C12EC: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000C12F0: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000C12F8: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C12FC: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000C1300: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000C1308: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000C130C: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1314: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000C1318: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 0000000C131C: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1324: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 0000000C1328: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 0000000C132C: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1334: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000C1338: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000C1340: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 0000000C1348: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1354: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000C1358: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000C1360: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000C136C: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C1374: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C1378: BE882006
	s_cbranch_execz 59722                                      // 0000000C137C: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36a8>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 0000000C1380: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000C138C: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000C1394: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000C1398: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C139C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000C13A0: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000C13A8: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000C13B4: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C13B8: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000C13BC: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000C13C0: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000C13C8: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C13D0: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000C13D4: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000C13D8: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000C13DC: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C13E0: BF870095
	.long 0xd71c002a                                           // 0000000C13E4: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000C13E8: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000C13EC: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000C13F0: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C13F8: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 0000000C13FC: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000C1408: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C140C: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000C1410: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000C1418: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C141C: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000C1420: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000C1428: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000C142C: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1434: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000C1438: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000C143C: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1444: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000C1448: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000C144C: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1454: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000C1458: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000C1460: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 0000000C1468: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1474: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000C1478: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000C1480: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000C148C: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C1494: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C1498: BE882007
	s_cbranch_execz 59653                                      // 0000000C149C: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36b4>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 0000000C14A0: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000C14AC: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000C14B4: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000C14B8: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C14BC: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000C14C0: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000C14C8: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000C14D4: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C14D8: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000C14DC: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000C14E0: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000C14E8: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C14F0: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000C14F4: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000C14F8: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000C14FC: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1500: BF870095
	.long 0xd71c002a                                           // 0000000C1504: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000C1508: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000C150C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000C1510: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1518: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 0000000C151C: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000C1528: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C152C: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000C1530: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000C1538: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C153C: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000C1540: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000C1548: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000C154C: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1554: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000C1558: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000C155C: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1564: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000C1568: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000C156C: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1574: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000C1578: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000C1580: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 0000000C1588: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1594: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000C1598: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000C15A0: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000C15AC: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C15B4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C15B8: BE882000
	s_cbranch_execz 59584                                      // 0000000C15BC: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36c0>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 0000000C15C0: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 0000000C15CC: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 0000000C15D0: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000C15D8: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000C15DC: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C15E0: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000C15E4: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000C15EC: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000C15F8: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C15FC: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000C1600: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000C1604: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000C160C: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C1614: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000C1618: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000C161C: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000C1620: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1624: BF870095
	.long 0xd71c002a                                           // 0000000C1628: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000C162C: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000C1630: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000C1634: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C163C: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000C1640: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000C1648: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C164C: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 0000000C1650: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 0000000C1658: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C165C: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000000C1660: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000000C1668: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 0000000C166C: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1674: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 0000000C1678: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 0000000C167C: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1684: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 0000000C1688: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 0000000C168C: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1694: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 0000000C1698: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 0000000C16A0: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 0000000C16A8: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C16B4: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 0000000C16B8: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 0000000C16C0: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 0000000C16CC: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C16D4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C16D8: BE882001
	s_cbranch_execz 59515                                      // 0000000C16DC: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36cc>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 0000000C16E0: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 0000000C16EC: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 0000000C16F0: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 0000000C16F8: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000C16FC: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C1700: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 0000000C1704: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000C170C: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 0000000C1714: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000000C1720: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C1724: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 0000000C1728: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 0000000C1730: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C1734: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000000C1738: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000000C173C: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 0000000C1740: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1744: BF870095
	.long 0xd71c0029                                           // 0000000C1748: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000000C174C: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000C1750: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000C1754: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C175C: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 0000000C1760: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000C1768: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C176C: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 0000000C1770: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 0000000C1778: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C177C: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 0000000C1780: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 0000000C1788: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 0000000C178C: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1794: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 0000000C1798: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 0000000C179C: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C17A4: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 0000000C17A8: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 0000000C17AC: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C17B4: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 0000000C17B8: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 0000000C17C0: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 0000000C17C8: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C17D4: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 0000000C17D8: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 0000000C17E0: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 0000000C17EC: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C17F4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C17F8: BE882002
	s_cbranch_execz 59446                                      // 0000000C17FC: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36d8>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 0000000C1800: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000C180C: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000C1814: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000C1818: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C181C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000C1820: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 0000000C1828: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 0000000C1834: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C1838: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 0000000C183C: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000C1840: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 0000000C1848: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C1850: BF870121
	v_add_f32_e32 v34, v34, v41                                // 0000000C1854: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 0000000C1858: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 0000000C185C: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1860: BF870095
	.long 0xd71c0022                                           // 0000000C1864: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 0000000C1868: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000C186C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000C1870: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1878: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 0000000C187C: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000C1888: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C188C: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000C1890: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 0000000C1898: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C189C: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 0000000C18A0: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 0000000C18A8: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 0000000C18AC: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C18B4: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 0000000C18B8: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 0000000C18BC: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C18C4: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 0000000C18C8: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 0000000C18CC: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C18D4: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 0000000C18D8: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000C18E0: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 0000000C18E8: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C18F4: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 0000000C18F8: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 0000000C1900: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000C190C: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C1914: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C1918: BE882003
	s_cbranch_execz 59377                                      // 0000000C191C: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36e4>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 0000000C1920: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000C192C: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000C1934: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000C1938: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C193C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000C1940: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000C1948: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 0000000C1954: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1958: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 0000000C195C: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 0000000C1968: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 0000000C196C: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000C1970: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C1978: BF870293
	v_exp_f32_e32 v34, v34                                     // 0000000C197C: 7E444B22
	.long 0xd71c0022                                           // 0000000C1980: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000C1984: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C1988: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000C198C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000C1990: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 0000000C1998: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C19A4: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 0000000C19A8: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000C19AC: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C19B4: BF870291
	v_rcp_f32_e32 v36, v35                                     // 0000000C19B8: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 0000000C19BC: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C19C4: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 0000000C19C8: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 0000000C19CC: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 0000000C19D4: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C19D8: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 0000000C19DC: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 0000000C19E4: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C19E8: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 0000000C19EC: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 0000000C19F4: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C19FC: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000C1A00: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 0000000C1A08: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000C1A14: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C1A1C: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000C1A20: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000C1A2C: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C1A34: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C1A38: BE882004
	s_cbranch_execz 59308                                      // 0000000C1A3C: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36f0>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 0000000C1A40: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000C1A4C: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000C1A54: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000C1A58: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1A5C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000C1A60: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000C1A68: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000C1A74: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C1A78: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000C1A7C: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000C1A80: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000C1A88: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C1A90: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000C1A94: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000C1A98: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000C1A9C: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1AA0: BF870095
	.long 0xd71c0022                                           // 0000000C1AA4: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000C1AA8: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000C1AAC: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000C1AB0: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1AB8: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 0000000C1ABC: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000C1AC8: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1ACC: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000C1AD0: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000C1AD8: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1ADC: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000C1AE0: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000C1AE8: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000C1AEC: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1AF4: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 0000000C1AF8: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 0000000C1AFC: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1B04: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 0000000C1B08: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 0000000C1B0C: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1B14: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 0000000C1B18: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000C1B20: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 0000000C1B28: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1B34: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000C1B38: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000C1B40: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000C1B4C: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C1B54: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C1B58: BE882005
	s_cbranch_execz 59239                                      // 0000000C1B5C: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36fc>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 0000000C1B60: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000C1B6C: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000C1B74: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000C1B78: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1B7C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000C1B80: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000C1B88: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000C1B94: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C1B98: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000C1B9C: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000C1BA0: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000C1BA8: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C1BB0: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000C1BB4: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000C1BB8: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000C1BBC: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1BC0: BF870095
	.long 0xd71c0022                                           // 0000000C1BC4: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000C1BC8: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000C1BCC: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000C1BD0: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1BD8: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000000C1BDC: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 0000000C1BE4: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1BEC: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000C1BF0: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000C1BF8: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1BFC: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000C1C00: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000C1C08: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000C1C0C: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1C14: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000C1C18: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 0000000C1C1C: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1C24: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 0000000C1C28: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 0000000C1C2C: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1C34: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000C1C38: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000C1C40: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 0000000C1C48: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1C54: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000C1C58: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000C1C60: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000C1C6C: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C1C74: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C1C78: BE882006
	s_cbranch_execz 59170                                      // 0000000C1C7C: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3708>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 0000000C1C80: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000C1C8C: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000C1C94: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000C1C98: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1C9C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000C1CA0: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000C1CA8: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000C1CB4: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C1CB8: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000C1CBC: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000C1CC0: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000C1CC8: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C1CD0: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000C1CD4: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000C1CD8: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000C1CDC: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1CE0: BF870095
	.long 0xd71c0022                                           // 0000000C1CE4: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000C1CE8: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000C1CEC: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000C1CF0: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1CF8: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 0000000C1CFC: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000C1D08: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1D0C: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000C1D10: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000C1D18: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1D1C: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000C1D20: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000C1D28: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000C1D2C: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1D34: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000C1D38: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 0000000C1D3C: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1D44: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 0000000C1D48: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000000C1D4C: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1D54: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000C1D58: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000C1D60: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 0000000C1D68: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1D74: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000C1D78: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000C1D80: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000C1D8C: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C1D94: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C1D98: BE882007
	s_cbranch_execz 59101                                      // 0000000C1D9C: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3714>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 0000000C1DA0: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000C1DAC: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000C1DB4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000C1DB8: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1DBC: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000C1DC0: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000C1DC8: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000C1DD4: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C1DD8: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000C1DDC: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000C1DE0: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000C1DE8: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C1DF0: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000C1DF4: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000C1DF8: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000C1DFC: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1E00: BF870095
	.long 0xd71c0022                                           // 0000000C1E04: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000C1E08: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000C1E0C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000C1E10: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1E18: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 0000000C1E1C: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000C1E28: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1E2C: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000C1E30: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000C1E38: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1E3C: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000C1E40: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000C1E48: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000C1E4C: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1E54: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000C1E58: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 0000000C1E5C: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1E64: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 0000000C1E68: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000000C1E6C: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1E74: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000C1E78: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000C1E80: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 0000000C1E88: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1E94: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000C1E98: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000C1EA0: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000C1EAC: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C1EB4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C1EB8: BE882000
	s_cbranch_execz 59032                                      // 0000000C1EBC: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3720>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 0000000C1EC0: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 0000000C1ECC: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 0000000C1ED0: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000C1ED8: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000C1EDC: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1EE0: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000C1EE4: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000C1EEC: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000C1EF8: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C1EFC: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000C1F00: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000C1F04: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000C1F0C: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C1F14: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000C1F18: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000C1F1C: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000C1F20: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1F24: BF870095
	.long 0xd71c0022                                           // 0000000C1F28: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000C1F2C: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000C1F30: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000C1F34: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1F3C: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000000C1F40: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000C1F48: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1F4C: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 0000000C1F50: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 0000000C1F58: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1F5C: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000000C1F60: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000000C1F68: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 0000000C1F6C: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1F74: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 0000000C1F78: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 0000000C1F7C: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1F84: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 0000000C1F88: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 0000000C1F8C: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1F94: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 0000000C1F98: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 0000000C1FA0: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 0000000C1FA8: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C1FB4: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 0000000C1FB8: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 0000000C1FC0: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 0000000C1FCC: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C1FD4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C1FD8: BE882001
	s_cbranch_execz 58963                                      // 0000000C1FDC: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x372c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 0000000C1FE0: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 0000000C1FEC: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 0000000C1FF0: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 0000000C1FF8: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000C1FFC: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2000: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 0000000C2004: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000C200C: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 0000000C2014: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000000C2020: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C2024: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 0000000C2028: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 0000000C2030: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2034: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000000C2038: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 0000000C203C: 7E441123
	v_exp_f32_e32 v33, v33                                     // 0000000C2040: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2044: BF870095
	.long 0xd71c0021                                           // 0000000C2048: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000C204C: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000C2050: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000C2054: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C205C: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 0000000C2060: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000C2068: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C206C: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 0000000C2070: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 0000000C2078: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C207C: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 0000000C2080: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 0000000C2088: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 0000000C208C: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2094: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 0000000C2098: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 0000000C209C: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C20A4: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 0000000C20A8: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 0000000C20AC: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C20B4: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 0000000C20B8: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 0000000C20C0: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 0000000C20C8: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C20D4: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 0000000C20D8: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 0000000C20E0: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 0000000C20EC: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C20F4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C20F8: BE882002
	s_cbranch_execz 58894                                      // 0000000C20FC: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3738>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 0000000C2100: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000C210C: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000C2114: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000C2118: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C211C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000C2120: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 0000000C2128: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 0000000C2134: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C2138: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 0000000C213C: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000C2140: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 0000000C2148: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2150: BF870121
	v_add_f32_e32 v26, v26, v33                                // 0000000C2154: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000C2158: 7E421122
	v_exp_f32_e32 v26, v26                                     // 0000000C215C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2160: BF870095
	.long 0xd71c001a                                           // 0000000C2164: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 0000000C2168: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000C216C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000C2170: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2178: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 0000000C217C: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000C2188: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C218C: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000C2190: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 0000000C2198: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C219C: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 0000000C21A0: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 0000000C21A8: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 0000000C21AC: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C21B4: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 0000000C21B8: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 0000000C21BC: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C21C4: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 0000000C21C8: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 0000000C21CC: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C21D4: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 0000000C21D8: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000C21E0: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 0000000C21E8: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C21F4: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 0000000C21F8: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 0000000C2200: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000C220C: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C2214: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C2218: BE882003
	s_cbranch_execz 58825                                      // 0000000C221C: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3744>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 0000000C2220: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000C222C: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000C2234: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000C2238: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C223C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000C2240: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000C2248: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 0000000C2254: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2258: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 0000000C225C: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 0000000C2268: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 0000000C226C: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000C2270: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C2278: BF870293
	v_exp_f32_e32 v26, v26                                     // 0000000C227C: 7E344B1A
	.long 0xd71c001a                                           // 0000000C2280: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000C2284: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2288: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000C228C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000C2290: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 0000000C2298: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C22A4: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 0000000C22A8: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000C22AC: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C22B4: BF870291
	v_rcp_f32_e32 v28, v27                                     // 0000000C22B8: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 0000000C22BC: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C22C4: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 0000000C22C8: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 0000000C22CC: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 0000000C22D4: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C22D8: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 0000000C22DC: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 0000000C22E4: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C22E8: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 0000000C22EC: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 0000000C22F4: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C22FC: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000C2300: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 0000000C2308: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000C2314: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C231C: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000C2320: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000C232C: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C2334: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C2338: BE882004
	s_cbranch_execz 58756                                      // 0000000C233C: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3750>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 0000000C2340: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000C234C: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000C2354: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000C2358: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C235C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000C2360: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000C2368: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000C2374: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C2378: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000C237C: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000C2380: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000C2388: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2390: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000C2394: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000C2398: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000C239C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C23A0: BF870095
	.long 0xd71c001a                                           // 0000000C23A4: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000C23A8: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000C23AC: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000C23B0: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C23B8: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 0000000C23BC: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000C23C8: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C23CC: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000C23D0: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000C23D8: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C23DC: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000C23E0: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000C23E8: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000C23EC: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C23F4: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 0000000C23F8: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 0000000C23FC: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2404: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 0000000C2408: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 0000000C240C: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2414: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 0000000C2418: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000C2420: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 0000000C2428: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2434: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000C2438: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000C2440: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000C244C: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C2454: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C2458: BE882005
	s_cbranch_execz 58687                                      // 0000000C245C: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x375c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 0000000C2460: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000C246C: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000C2474: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000C2478: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C247C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000C2480: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000C2488: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000C2494: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C2498: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000C249C: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000C24A0: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000C24A8: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C24B0: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000C24B4: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000C24B8: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000C24BC: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C24C0: BF870095
	.long 0xd71c001a                                           // 0000000C24C4: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000C24C8: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000C24CC: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000C24D0: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C24D8: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 0000000C24DC: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 0000000C24E4: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C24EC: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000C24F0: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000C24F8: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C24FC: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000C2500: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000C2508: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000C250C: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2514: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000C2518: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 0000000C251C: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2524: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 0000000C2528: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 0000000C252C: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2534: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000C2538: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000C2540: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 0000000C2548: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2554: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000C2558: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000C2560: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000C256C: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C2574: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C2578: BE882006
	s_cbranch_execz 58618                                      // 0000000C257C: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3768>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 0000000C2580: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000C258C: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000C2594: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000C2598: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C259C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000C25A0: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000C25A8: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000C25B4: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C25B8: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000C25BC: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000C25C0: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000C25C8: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C25D0: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000C25D4: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000C25D8: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000C25DC: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C25E0: BF870095
	.long 0xd71c001a                                           // 0000000C25E4: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000C25E8: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000C25EC: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000C25F0: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C25F8: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 0000000C25FC: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000C2608: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C260C: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000C2610: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000C2618: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C261C: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000C2620: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000C2628: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000C262C: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2634: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000C2638: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000C263C: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2644: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000C2648: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000C264C: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2654: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000C2658: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000C2660: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 0000000C2668: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2674: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000C2678: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000C2680: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000C268C: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C2694: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C2698: BE882007
	s_cbranch_execz 58549                                      // 0000000C269C: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3774>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 0000000C26A0: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000C26AC: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000C26B4: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000C26B8: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C26BC: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000C26C0: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000C26C8: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000C26D4: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C26D8: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000C26DC: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000C26E0: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000C26E8: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C26F0: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000C26F4: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000C26F8: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000C26FC: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2700: BF870095
	.long 0xd71c001a                                           // 0000000C2704: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000C2708: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000C270C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000C2710: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2718: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 0000000C271C: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000C2728: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C272C: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000C2730: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000C2738: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C273C: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000C2740: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000C2748: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000C274C: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2754: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000C2758: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000C275C: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2764: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000C2768: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000C276C: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2774: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000C2778: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000C2780: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 0000000C2788: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2794: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000C2798: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000C27A0: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000C27AC: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C27B4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C27B8: BE882000
	s_cbranch_execz 58480                                      // 0000000C27BC: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3780>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 0000000C27C0: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 0000000C27CC: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 0000000C27D0: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000C27D8: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000C27DC: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C27E0: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000C27E4: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000C27EC: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000C27F8: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C27FC: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000C2800: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000C2804: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000C280C: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2814: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000C2818: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000C281C: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000C2820: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2824: BF870095
	.long 0xd71c001a                                           // 0000000C2828: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000C282C: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000C2830: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000C2834: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C283C: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 0000000C2840: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000C2848: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C284C: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 0000000C2850: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 0000000C2858: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C285C: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 0000000C2860: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 0000000C2868: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 0000000C286C: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2874: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 0000000C2878: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 0000000C287C: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2884: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 0000000C2888: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 0000000C288C: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2894: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 0000000C2898: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 0000000C28A0: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 0000000C28A8: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C28B4: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 0000000C28B8: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 0000000C28C0: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 0000000C28CC: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C28D4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C28D8: BE882001
	s_cbranch_execz 58411                                      // 0000000C28DC: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x378c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 0000000C28E0: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 0000000C28EC: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 0000000C28F0: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 0000000C28F8: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000C28FC: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2900: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 0000000C2904: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000C290C: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 0000000C2914: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 0000000C2920: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C2924: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 0000000C2928: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 0000000C2930: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2934: BF870121
	v_add_f32_e32 v25, v25, v26                                // 0000000C2938: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 0000000C293C: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 0000000C2940: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2944: BF870095
	.long 0xd71c0019                                           // 0000000C2948: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000000C294C: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000000C2950: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000C2954: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C295C: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 0000000C2960: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000C2968: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C296C: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 0000000C2970: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 0000000C2978: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C297C: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 0000000C2980: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 0000000C2988: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 0000000C298C: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2994: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 0000000C2998: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 0000000C299C: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C29A4: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 0000000C29A8: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 0000000C29AC: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C29B4: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 0000000C29B8: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 0000000C29C0: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 0000000C29C8: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C29D4: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 0000000C29D8: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000000C29E0: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 0000000C29EC: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C29F4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C29F8: BE882002
	s_cbranch_execz 58342                                      // 0000000C29FC: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3798>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 0000000C2A00: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000C2A0C: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000C2A14: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000C2A18: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2A1C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000C2A20: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 0000000C2A28: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 0000000C2A34: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C2A38: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 0000000C2A3C: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000C2A40: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 0000000C2A48: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2A50: BF870121
	v_add_f32_e32 v18, v18, v25                                // 0000000C2A54: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 0000000C2A58: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 0000000C2A5C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2A60: BF870095
	.long 0xd71c0012                                           // 0000000C2A64: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 0000000C2A68: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000C2A6C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000C2A70: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2A78: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 0000000C2A7C: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000C2A88: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2A8C: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000C2A90: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 0000000C2A98: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2A9C: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 0000000C2AA0: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 0000000C2AA8: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 0000000C2AAC: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2AB4: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 0000000C2AB8: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 0000000C2ABC: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2AC4: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 0000000C2AC8: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 0000000C2ACC: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2AD4: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 0000000C2AD8: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000C2AE0: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 0000000C2AE8: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2AF4: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 0000000C2AF8: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 0000000C2B00: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000C2B0C: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C2B14: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C2B18: BE882003
	s_cbranch_execz 58273                                      // 0000000C2B1C: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37a4>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 0000000C2B20: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000C2B2C: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000C2B34: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000C2B38: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2B3C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000C2B40: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000C2B48: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 0000000C2B54: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2B58: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 0000000C2B5C: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 0000000C2B68: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 0000000C2B6C: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000C2B70: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C2B78: BF870293
	v_exp_f32_e32 v18, v18                                     // 0000000C2B7C: 7E244B12
	.long 0xd71c0012                                           // 0000000C2B80: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000C2B84: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2B88: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000C2B8C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000C2B90: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 0000000C2B98: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2BA4: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 0000000C2BA8: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000C2BAC: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C2BB4: BF870291
	v_rcp_f32_e32 v20, v19                                     // 0000000C2BB8: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 0000000C2BBC: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C2BC4: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 0000000C2BC8: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 0000000C2BCC: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 0000000C2BD4: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2BD8: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 0000000C2BDC: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 0000000C2BE4: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2BE8: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 0000000C2BEC: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 0000000C2BF4: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2BFC: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000C2C00: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 0000000C2C08: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000C2C14: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C2C1C: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000C2C20: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000C2C2C: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C2C34: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C2C38: BE882004
	s_cbranch_execz 58204                                      // 0000000C2C3C: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37b0>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 0000000C2C40: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000C2C4C: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000C2C54: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000C2C58: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2C5C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000C2C60: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000C2C68: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000C2C74: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C2C78: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000C2C7C: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000C2C80: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000C2C88: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2C90: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000C2C94: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000C2C98: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000C2C9C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2CA0: BF870095
	.long 0xd71c0012                                           // 0000000C2CA4: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000C2CA8: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000C2CAC: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000C2CB0: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2CB8: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 0000000C2CBC: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000C2CC8: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2CCC: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000C2CD0: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000C2CD8: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2CDC: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000C2CE0: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000C2CE8: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000C2CEC: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2CF4: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 0000000C2CF8: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 0000000C2CFC: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2D04: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 0000000C2D08: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 0000000C2D0C: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2D14: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 0000000C2D18: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000C2D20: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 0000000C2D28: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2D34: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000C2D38: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000C2D40: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000C2D4C: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C2D54: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C2D58: BE882005
	s_cbranch_execz 58135                                      // 0000000C2D5C: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37bc>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 0000000C2D60: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000C2D6C: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000C2D74: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000C2D78: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2D7C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000C2D80: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000C2D88: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000C2D94: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C2D98: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000C2D9C: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000C2DA0: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000C2DA8: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2DB0: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000C2DB4: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000C2DB8: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000C2DBC: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2DC0: BF870095
	.long 0xd71c0012                                           // 0000000C2DC4: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000C2DC8: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000C2DCC: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000C2DD0: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2DD8: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000C2DDC: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 0000000C2DE4: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2DEC: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000C2DF0: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000C2DF8: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2DFC: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000C2E00: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000C2E08: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000C2E0C: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2E14: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000C2E18: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 0000000C2E1C: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2E24: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 0000000C2E28: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 0000000C2E2C: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2E34: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000C2E38: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000C2E40: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 0000000C2E48: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2E54: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000C2E58: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000C2E60: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000C2E6C: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C2E74: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C2E78: BE882006
	s_cbranch_execz 58066                                      // 0000000C2E7C: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37c8>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 0000000C2E80: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000C2E8C: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000C2E94: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000C2E98: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2E9C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000C2EA0: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000C2EA8: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000C2EB4: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C2EB8: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000C2EBC: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000C2EC0: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000C2EC8: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2ED0: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000C2ED4: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000C2ED8: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000C2EDC: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2EE0: BF870095
	.long 0xd71c0012                                           // 0000000C2EE4: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000C2EE8: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000C2EEC: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000C2EF0: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2EF8: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 0000000C2EFC: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000C2F08: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2F0C: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000C2F10: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000C2F18: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2F1C: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000C2F20: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000C2F28: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000C2F2C: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2F34: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000C2F38: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000C2F3C: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2F44: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000C2F48: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000C2F4C: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2F54: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000C2F58: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000C2F60: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 0000000C2F68: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2F74: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000C2F78: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000C2F80: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000C2F8C: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C2F94: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C2F98: BE882007
	s_cbranch_execz 57997                                      // 0000000C2F9C: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37d4>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 0000000C2FA0: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000C2FAC: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000C2FB4: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000C2FB8: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C2FBC: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000C2FC0: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000C2FC8: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000C2FD4: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C2FD8: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000C2FDC: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000C2FE0: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000C2FE8: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C2FF0: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000C2FF4: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000C2FF8: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000C2FFC: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3000: BF870095
	.long 0xd71c0012                                           // 0000000C3004: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000C3008: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000C300C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000C3010: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3018: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 0000000C301C: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000C3028: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C302C: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000C3030: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000C3038: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C303C: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000C3040: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000C3048: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000C304C: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3054: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000C3058: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000C305C: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3064: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000C3068: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000C306C: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3074: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000C3078: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000C3080: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 0000000C3088: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3094: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000C3098: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000C30A0: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000C30AC: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C30B4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C30B8: BE882000
	s_cbranch_execz 57928                                      // 0000000C30BC: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37e0>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 0000000C30C0: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 0000000C30CC: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 0000000C30D0: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000C30D8: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000C30DC: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C30E0: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000C30E4: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000C30EC: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000C30F8: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C30FC: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000C3100: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000C3104: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000C310C: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C3114: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000C3118: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000C311C: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000C3120: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3124: BF870095
	.long 0xd71c0012                                           // 0000000C3128: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000C312C: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000C3130: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000C3134: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C313C: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000C3140: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000C3148: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C314C: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 0000000C3150: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 0000000C3158: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C315C: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000000C3160: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 0000000C3168: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 0000000C316C: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3174: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 0000000C3178: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 0000000C317C: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3184: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 0000000C3188: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 0000000C318C: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3194: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 0000000C3198: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 0000000C31A0: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 0000000C31A8: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C31B4: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 0000000C31B8: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 0000000C31C0: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 0000000C31CC: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C31D4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C31D8: BE882001
	s_cbranch_execz 57859                                      // 0000000C31DC: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37ec>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 0000000C31E0: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 0000000C31EC: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 0000000C31F0: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 0000000C31F8: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000C31FC: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C3200: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 0000000C3204: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000C320C: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 0000000C3214: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 0000000C3220: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C3224: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 0000000C3228: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 0000000C3230: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C3234: BF870121
	v_add_f32_e32 v17, v17, v18                                // 0000000C3238: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 0000000C323C: 7E241113
	v_exp_f32_e32 v17, v17                                     // 0000000C3240: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3244: BF870095
	.long 0xd71c0011                                           // 0000000C3248: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000000C324C: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000000C3250: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000C3254: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C325C: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 0000000C3260: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000C3268: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C326C: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 0000000C3270: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 0000000C3278: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C327C: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 0000000C3280: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 0000000C3288: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 0000000C328C: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3294: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 0000000C3298: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 0000000C329C: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C32A4: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 0000000C32A8: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 0000000C32AC: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C32B4: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 0000000C32B8: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 0000000C32C0: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 0000000C32C8: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C32D4: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 0000000C32D8: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000000C32E0: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 0000000C32EC: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C32F4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C32F8: BE882002
	s_cbranch_execz 57790                                      // 0000000C32FC: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37f8>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 0000000C3300: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000C330C: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000C3314: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000C3318: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C331C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000C3320: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 0000000C3328: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 0000000C3334: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C3338: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 0000000C333C: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000C3340: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 0000000C3348: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C3350: BF870121
	v_add_f32_e32 v10, v10, v17                                // 0000000C3354: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 0000000C3358: 7E221112
	v_exp_f32_e32 v10, v10                                     // 0000000C335C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3360: BF870095
	.long 0xd71c000a                                           // 0000000C3364: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 0000000C3368: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000C336C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000C3370: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3378: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 0000000C337C: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000C3388: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C338C: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000C3390: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 0000000C3398: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C339C: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 0000000C33A0: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 0000000C33A8: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 0000000C33AC: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C33B4: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 0000000C33B8: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 0000000C33BC: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C33C4: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 0000000C33C8: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 0000000C33CC: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C33D4: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 0000000C33D8: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000C33E0: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 0000000C33E8: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C33F4: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 0000000C33F8: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 0000000C3400: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000C340C: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C3414: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C3418: BE882003
	s_cbranch_execz 57721                                      // 0000000C341C: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3804>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 0000000C3420: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000C342C: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000C3434: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000C3438: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C343C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000C3440: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000C3448: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 0000000C3454: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3458: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 0000000C345C: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 0000000C3468: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 0000000C346C: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000C3470: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C3478: BF870293
	v_exp_f32_e32 v10, v10                                     // 0000000C347C: 7E144B0A
	.long 0xd71c000a                                           // 0000000C3480: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000C3484: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C3488: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000C348C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000C3490: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 0000000C3498: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C34A4: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000C34A8: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000C34AC: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C34B4: BF870291
	v_rcp_f32_e32 v12, v11                                     // 0000000C34B8: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 0000000C34BC: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C34C4: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 0000000C34C8: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 0000000C34CC: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 0000000C34D4: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C34D8: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 0000000C34DC: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 0000000C34E4: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C34E8: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 0000000C34EC: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 0000000C34F4: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C34FC: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000C3500: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 0000000C3508: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000C3514: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C351C: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000C3520: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000C352C: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C3534: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C3538: BE882004
	s_cbranch_execz 57652                                      // 0000000C353C: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3810>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 0000000C3540: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000C354C: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000C3554: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000C3558: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C355C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000C3560: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000C3568: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000C3574: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C3578: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000C357C: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000C3580: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000C3588: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C3590: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000C3594: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000C3598: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000C359C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C35A0: BF870095
	.long 0xd71c000a                                           // 0000000C35A4: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000C35A8: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000C35AC: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000C35B0: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C35B8: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 0000000C35BC: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000C35C8: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C35CC: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000C35D0: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000C35D8: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C35DC: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000C35E0: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000C35E8: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000C35EC: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C35F4: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 0000000C35F8: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 0000000C35FC: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3604: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 0000000C3608: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 0000000C360C: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3614: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 0000000C3618: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000C3620: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 0000000C3628: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3634: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000C3638: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000C3640: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000C364C: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C3654: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C3658: BE882005
	s_cbranch_execz 57583                                      // 0000000C365C: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x381c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 0000000C3660: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000C366C: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000C3674: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000C3678: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C367C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000C3680: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000C3688: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000C3694: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C3698: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000C369C: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000C36A0: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000C36A8: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C36B0: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000C36B4: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000C36B8: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000C36BC: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C36C0: BF870095
	.long 0xd71c000a                                           // 0000000C36C4: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000C36C8: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000C36CC: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000C36D0: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C36D8: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 0000000C36DC: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 0000000C36E4: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C36EC: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000C36F0: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000C36F8: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C36FC: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000C3700: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000C3708: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000C370C: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3714: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000C3718: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 0000000C371C: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3724: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 0000000C3728: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 0000000C372C: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3734: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000C3738: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000C3740: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 0000000C3748: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3754: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000C3758: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000C3760: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000C376C: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C3774: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C3778: BE882006
	s_cbranch_execz 57514                                      // 0000000C377C: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3828>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 0000000C3780: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000C378C: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000C3794: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000C3798: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C379C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000C37A0: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000C37A8: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000C37B4: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C37B8: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000C37BC: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000C37C0: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000C37C8: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C37D0: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000C37D4: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000C37D8: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000C37DC: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C37E0: BF870095
	.long 0xd71c000a                                           // 0000000C37E4: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000C37E8: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000C37EC: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000C37F0: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C37F8: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 0000000C37FC: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000C3808: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C380C: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000C3810: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000C3818: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C381C: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000C3820: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000C3828: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000C382C: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3834: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000C3838: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000000C383C: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3844: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000C3848: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000C384C: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3854: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000C3858: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000C3860: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 0000000C3868: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3874: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000C3878: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000C3880: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000C388C: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C3894: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C3898: BE882007
	s_cbranch_execz 57445                                      // 0000000C389C: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3834>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 0000000C38A0: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000C38AC: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000C38B4: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000C38B8: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C38BC: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000C38C0: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000C38C8: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000C38D4: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C38D8: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000C38DC: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000C38E0: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000C38E8: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C38F0: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000C38F4: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000C38F8: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000C38FC: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3900: BF870095
	.long 0xd71c000a                                           // 0000000C3904: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000C3908: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000C390C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000C3910: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3918: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 0000000C391C: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000C3928: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C392C: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000C3930: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000C3938: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C393C: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000C3940: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000C3948: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000C394C: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3954: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000C3958: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000000C395C: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3964: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000C3968: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000C396C: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3974: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000C3978: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000C3980: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 0000000C3988: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3994: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000C3998: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000C39A0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000C39AC: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C39B4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C39B8: BE882000
	s_cbranch_execz 57376                                      // 0000000C39BC: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3840>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 0000000C39C0: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 0000000C39CC: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 0000000C39D0: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000C39D8: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000C39DC: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C39E0: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000C39E4: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000C39EC: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000C39F8: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C39FC: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000C3A00: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000C3A04: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000C3A0C: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C3A14: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000C3A18: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000C3A1C: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000C3A20: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3A24: BF870095
	.long 0xd71c000a                                           // 0000000C3A28: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000C3A2C: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000C3A30: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000C3A34: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3A3C: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 0000000C3A40: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000C3A48: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3A4C: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 0000000C3A50: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 0000000C3A58: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3A5C: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 0000000C3A60: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 0000000C3A68: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 0000000C3A6C: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3A74: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 0000000C3A78: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 0000000C3A7C: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3A84: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 0000000C3A88: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 0000000C3A8C: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3A94: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 0000000C3A98: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 0000000C3AA0: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 0000000C3AA8: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3AB4: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 0000000C3AB8: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000000C3AC0: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 0000000C3ACC: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C3AD4: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 0000000C3AD8: BE802001
	s_cbranch_execz 57307                                      // 0000000C3ADC: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x384c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 0000000C3AE0: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000C3AEC: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000C3AF4: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000C3AF8: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3AFC: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000C3B00: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 0000000C3B08: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 0000000C3B14: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C3B18: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 0000000C3B1C: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 0000000C3B20: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000C3B28: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C3B30: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 0000000C3B34: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 0000000C3B38: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 0000000C3B3C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3B40: BF870095
	.long 0xd71c0001                                           // 0000000C3B44: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 0000000C3B48: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000C3B4C: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000C3B50: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3B58: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 0000000C3B5C: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000C3B68: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3B6C: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000C3B70: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 0000000C3B78: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3B7C: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 0000000C3B80: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 0000000C3B88: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 0000000C3B8C: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3B94: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 0000000C3B98: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 0000000C3B9C: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3BA4: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 0000000C3BA8: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 0000000C3BAC: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3BB4: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 0000000C3BB8: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000C3BC0: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 0000000C3BC8: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3BD4: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 0000000C3BD8: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 0000000C3BE0: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000C3BEC: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000C3BF4: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000C3BF8: BE802002
	s_cbranch_execz 57238                                      // 0000000C3BFC: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3858>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 0000000C3C00: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000C3C0C: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000C3C14: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000C3C18: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3C1C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000C3C20: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000C3C28: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 0000000C3C34: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C3C38: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 0000000C3C3C: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000C3C40: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000C3C48: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C3C50: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000C3C54: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 0000000C3C58: 7E041109
	v_exp_f32_e32 v1, v1                                       // 0000000C3C5C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3C60: BF870095
	.long 0xd71c0001                                           // 0000000C3C64: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000C3C68: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000C3C6C: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000C3C70: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3C78: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 0000000C3C7C: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000C3C88: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3C8C: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000C3C90: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000C3C98: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3C9C: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 0000000C3CA0: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 0000000C3CA8: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 0000000C3CAC: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3CB4: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 0000000C3CB8: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 0000000C3CBC: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3CC4: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 0000000C3CC8: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 0000000C3CCC: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3CD4: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 0000000C3CD8: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000C3CE0: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 0000000C3CE8: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3CF4: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000C3CF8: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000C3D00: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000C3D0C: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000C3D14: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000C3D18: BE802003
	s_cbranch_execz 57169                                      // 0000000C3D1C: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3864>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 0000000C3D20: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000C3D2C: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000C3D34: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000C3D38: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3D3C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000C3D40: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000C3D48: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000C3D54: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C3D58: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000C3D5C: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000C3D60: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000C3D68: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C3D70: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000C3D74: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000C3D78: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000C3D7C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3D80: BF870095
	.long 0xd71c0001                                           // 0000000C3D84: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000C3D88: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000C3D8C: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000C3D90: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3D98: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 0000000C3D9C: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000C3DA8: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3DAC: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000C3DB0: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000C3DB8: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3DBC: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000C3DC0: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000C3DC8: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000C3DCC: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3DD4: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 0000000C3DD8: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 0000000C3DDC: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3DE4: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 0000000C3DE8: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 0000000C3DEC: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3DF4: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 0000000C3DF8: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000C3E00: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 0000000C3E08: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3E14: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000C3E18: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000C3E20: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000C3E2C: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000C3E34: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000C3E38: BE802004
	s_cbranch_execz 57100                                      // 0000000C3E3C: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3870>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 0000000C3E40: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000C3E4C: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000C3E54: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000C3E58: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3E5C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000C3E60: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000C3E68: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000C3E74: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C3E78: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000C3E7C: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000C3E80: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000C3E88: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C3E90: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000C3E94: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000C3E98: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000C3E9C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3EA0: BF870095
	.long 0xd71c0001                                           // 0000000C3EA4: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000C3EA8: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000C3EAC: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000C3EB0: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3EB8: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 0000000C3EBC: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 0000000C3EC4: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3ECC: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000C3ED0: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000C3ED8: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3EDC: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000C3EE0: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000C3EE8: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000C3EEC: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3EF4: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000C3EF8: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 0000000C3EFC: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3F04: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 0000000C3F08: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000C3F0C: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3F14: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000C3F18: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000C3F20: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 0000000C3F28: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3F34: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000C3F38: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000C3F40: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000C3F4C: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000C3F54: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000C3F58: BE802005
	s_cbranch_execz 57031                                      // 0000000C3F5C: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x387c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 0000000C3F60: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000C3F6C: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000C3F74: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000C3F78: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3F7C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000C3F80: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000C3F88: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000C3F94: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C3F98: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000C3F9C: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000C3FA0: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000C3FA8: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C3FB0: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000C3FB4: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000C3FB8: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000C3FBC: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3FC0: BF870095
	.long 0xd71c0001                                           // 0000000C3FC4: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000C3FC8: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000C3FCC: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000C3FD0: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3FD8: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 0000000C3FDC: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000C3FE8: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3FEC: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000C3FF0: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000C3FF8: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3FFC: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000C4000: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000C4008: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000C400C: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4014: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000C4018: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000C401C: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4024: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000C4028: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000C402C: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4034: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000C4038: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000C4040: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 0000000C4048: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4054: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000C4058: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000C4060: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000C406C: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000C4074: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000C4078: BE802006
	s_cbranch_execz 56962                                      // 0000000C407C: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3888>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 0000000C4080: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000C408C: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000C4094: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000C4098: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C409C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000C40A0: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000C40A8: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000C40B4: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C40B8: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000C40BC: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000C40C0: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000C40C8: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C40D0: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000C40D4: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000C40D8: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000C40DC: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C40E0: BF870095
	.long 0xd71c0001                                           // 0000000C40E4: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000C40E8: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000C40EC: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000C40F0: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C40F8: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 0000000C40FC: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000C4108: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C410C: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000C4110: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000C4118: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C411C: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000C4120: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000C4128: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000C412C: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4134: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000C4138: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000C413C: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4144: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000C4148: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000C414C: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4154: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000C4158: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000C4160: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 0000000C4168: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4174: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000C4178: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000C4180: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000C418C: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000C4194: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000C4198: BE802007
	s_cbranch_execz 56893                                      // 0000000C419C: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3894>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 0000000C41A0: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000C41AC: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000C41B4: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000C41B8: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C41BC: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000C41C0: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000C41C8: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000C41D4: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C41D8: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000C41DC: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000C41E0: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000C41E8: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C41F0: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000C41F4: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000C41F8: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000C41FC: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4200: BF870095
	.long 0xd71c0001                                           // 0000000C4204: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000C4208: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000C420C: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000C4210: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4218: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 0000000C421C: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000C4228: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C422C: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000C4230: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000C4238: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C423C: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000C4240: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000C4248: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000C424C: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4254: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000C4258: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000C425C: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4264: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000C4268: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000C426C: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4274: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000C4278: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000C4280: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 0000000C4288: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4294: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000C4298: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000C42A0: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000C42AC: DC9601E0 007C0200
	s_nop 0                                                    // 0000000C42B4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000000C42B8: BFB60003
	s_endpgm                                                   // 0000000C42BC: BFB00000
		...

