0000000000030700 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE>:
; _ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE():
	s_clause 0x1                                               // 000000030700: BF850001
	s_load_b256 s[20:27], s[0:1], 0x20                         // 000000030704: F40C0500 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 00000003070C: F40C0200 F8000000
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 5, v0       // 000000030714: CA220080 02020085
	s_ashr_i32 s3, s2, 31                                      // 00000003071C: 86039F02
	s_mov_b32 s28, 0                                           // 000000030720: BE9C0080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000030724: BF870001
	v_and_b32_e32 v3, 0x200, v3                                // 000000030728: 360606FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 000000030730: BF89FC07
	s_load_b32 s16, s[20:21], null                             // 000000030734: F400040A F8000000
	v_readfirstlane_b32 s20, v0                                // 00000003073C: 7E280500
	s_lshl_b64 s[4:5], s[22:23], 2                             // 000000030740: 84848216
	s_lshr_b32 s21, s20, 5                                     // 000000030744: 85158514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000030748: BF8704D9
	s_lshl_b32 s33, s21, 4                                     // 00000003074C: 84218415
	s_add_u32 s4, s14, s4                                      // 000000030750: 8004040E
	v_and_or_b32 v1, v0, 15, s33                               // 000000030754: D6570001 00851F00
	s_addc_u32 s5, s15, s5                                     // 00000003075C: 8205050F
	s_lshl_b64 s[6:7], s[2:3], 16                              // 000000030760: 84869002
	s_add_u32 s4, s4, s6                                       // 000000030764: 80040604
	s_delay_alu instid0(VALU_DEP_1)                            // 000000030768: BF870001
	.long 0xd73c0001                                           // 00000003076C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000030770: 02020282
	s_addc_u32 s5, s5, s7                                      // 000000030774: 82050705
	s_waitcnt lgkmcnt(0)                                       // 000000030778: BF89FC07
	s_mul_i32 s14, s16, 0x9000000                              // 00000003077C: 960EFF10 09000000
	s_mul_hi_i32 s15, s16, 0x9000000                           // 000000030784: 970FFF10 09000000
	s_add_u32 s4, s4, s14                                      // 00000003078C: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000030790: 82050F05
	.long 0xd7006a01                                           // 000000030794: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000030798: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000003079C: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000000307A0: D5207C02 01AA0405
	s_or_b32 s5, s21, s2                                       // 0000000307A8: 8C050215
	.long 0xd7006a52                                           // 0000000307AC: D7006A52
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000000307B0: 02020701
	v_add_co_ci_u32_e64 v83, null, 0, v2, vcc_lo               // 0000000307B4: D5207C53 01AA0480
	s_cselect_b32 s38, 0, -1                                   // 0000000307BC: 9826C180
	.long 0xd7006a09                                           // 0000000307C0: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 0000000307C4: 0202A4FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000307CC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v83, vcc_lo              // 0000000307D0: D5207C0A 01AAA680
	.long 0xd7006a34                                           // 0000000307D8: D7006A34
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000307DC: 0201FF52
	.long 0x00002000                                           // 0000000307E0: 00002000
	v_add_co_ci_u32_e64 v53, null, 0, v83, vcc_lo              // 0000000307E4: D5207C35 01AAA680
	.long 0xd7006a0d                                           // 0000000307EC: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 0000000307F0: 0202A4FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000307F8: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v83, vcc_lo              // 0000000307FC: D5207C0E 01AAA680
	.long 0xd7006a0f                                           // 000000030804: D7006A0F
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 000000030808: 0202A4FF 00003000
	v_add_co_ci_u32_e64 v16, null, 0, v83, vcc_lo              // 000000030810: D5207C10 01AAA680
	.long 0xd7006a3c                                           // 000000030818: D7006A3C
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000003081C: 0201FF52
	.long 0x00004000                                           // 000000030820: 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000030824: BF870001
	v_add_co_ci_u32_e64 v61, null, 0, v83, vcc_lo              // 000000030828: D5207C3D 01AAA680
	.long 0xd7006a11                                           // 000000030830: D7006A11
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 000000030834: 0202A4FF 00004000
	s_clause 0x7                                               // 00000003083C: BF850007
	global_load_b32 v5, v[82:83], off                          // 000000030840: DC520000 057C0052
	global_load_b32 v6, v[82:83], off offset:1024              // 000000030848: DC520400 067C0052
	global_load_b32 v7, v[82:83], off offset:2048              // 000000030850: DC520800 077C0052
	global_load_b32 v8, v[82:83], off offset:3072              // 000000030858: DC520C00 087C0052
	global_load_b32 v2, v[9:10], off offset:1024               // 000000030860: DC520400 027C0009
	global_load_b32 v3, v[9:10], off offset:2048               // 000000030868: DC520800 037C0009
	global_load_b32 v4, v[9:10], off offset:3072               // 000000030870: DC520C00 047C0009
	global_load_b32 v1, v[13:14], off offset:1024              // 000000030878: DC520400 017C000D
	v_add_co_ci_u32_e64 v18, null, 0, v83, vcc_lo              // 000000030880: D5207C12 01AAA680
	s_clause 0x7                                               // 000000030888: BF850007
	global_load_b32 v12, v[13:14], off offset:2048             // 00000003088C: DC520800 0C7C000D
	global_load_b32 v13, v[13:14], off offset:3072             // 000000030894: DC520C00 0D7C000D
	global_load_b32 v9, v[15:16], off offset:1024              // 00000003089C: DC520400 097C000F
	global_load_b32 v10, v[15:16], off offset:2048             // 0000000308A4: DC520800 0A7C000F
	global_load_b32 v11, v[15:16], off offset:3072             // 0000000308AC: DC520C00 0B7C000F
	global_load_b32 v14, v[17:18], off offset:1024             // 0000000308B4: DC520400 0E7C0011
	global_load_b32 v15, v[17:18], off offset:2048             // 0000000308BC: DC520800 0F7C0011
	global_load_b32 v16, v[17:18], off offset:3072             // 0000000308C4: DC520C00 107C0011
	.long 0xd7006a11                                           // 0000000308CC: D7006A11
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 0000000308D0: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000308D8: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v83, vcc_lo              // 0000000308DC: D5207C12 01AAA680
	.long 0xd7006a41                                           // 0000000308E4: D7006A41
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000308E8: 0201FF52
	.long 0x00006000                                           // 0000000308EC: 00006000
	v_add_co_ci_u32_e64 v66, null, 0, v83, vcc_lo              // 0000000308F0: D5207C42 01AAA680
	.long 0xd7006a17                                           // 0000000308F8: D7006A17
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 0000000308FC: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000030904: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v83, vcc_lo              // 000000030908: D5207C18 01AAA680
	.long 0xd7006a19                                           // 000000030910: D7006A19
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 000000030914: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v26, null, 0, v83, vcc_lo              // 00000003091C: D5207C1A 01AAA680
	.long 0xd7006a29                                           // 000000030924: D7006A29
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000030928: 0201FF52
	.long 0x00008000                                           // 00000003092C: 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000030930: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v83, vcc_lo              // 000000030934: D5207C2A 01AAA680
	.long 0xd7006a20                                           // 00000003093C: D7006A20
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 000000030940: 0202A4FF 00008000
	v_add_co_ci_u32_e64 v33, null, 0, v83, vcc_lo              // 000000030948: D5207C21 01AAA680
	.long 0xd7006a22                                           // 000000030950: D7006A22
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 000000030954: 0202A4FF 00009000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003095C: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v83, vcc_lo              // 000000030960: D5207C23 01AAA680
	.long 0xd7006a2b                                           // 000000030968: D7006A2B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000003096C: 0201FF52
	.long 0x0000a000                                           // 000000030970: 0000A000
	v_add_co_ci_u32_e64 v44, null, 0, v83, vcc_lo              // 000000030974: D5207C2C 01AAA680
	.long 0xd7006a25                                           // 00000003097C: D7006A25
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 000000030980: 0202A4FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000030988: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v83, vcc_lo              // 00000003098C: D5207C26 01AAA680
	.long 0xd7006a27                                           // 000000030994: D7006A27
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 000000030998: 0202A4FF 0000B000
	v_add_co_ci_u32_e64 v40, null, 0, v83, vcc_lo              // 0000000309A0: D5207C28 01AAA680
	.long 0xd7006a2d                                           // 0000000309A8: D7006A2D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000309AC: 0201FF52
	.long 0x0000c000                                           // 0000000309B0: 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000309B4: BF8700A1
	v_add_co_ci_u32_e64 v46, null, 0, v83, vcc_lo              // 0000000309B8: D5207C2E 01AAA680
	.long 0xd7006a2f                                           // 0000000309C0: D7006A2F
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 0000000309C4: 0202A4FF 0000C000
	v_add_co_ci_u32_e64 v48, null, 0, v83, vcc_lo              // 0000000309CC: D5207C30 01AAA680
	.long 0xd7006a36                                           // 0000000309D4: D7006A36
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 0000000309D8: 0202A4FF 0000D000
	s_clause 0x17                                              // 0000000309E0: BF850017
	global_load_b32 v20, v[17:18], off offset:1024             // 0000000309E4: DC520400 147C0011
	global_load_b32 v21, v[17:18], off offset:2048             // 0000000309EC: DC520800 157C0011
	global_load_b32 v22, v[17:18], off offset:3072             // 0000000309F4: DC520C00 167C0011
	global_load_b32 v17, v[23:24], off offset:1024             // 0000000309FC: DC520400 117C0017
	global_load_b32 v18, v[23:24], off offset:2048             // 000000030A04: DC520800 127C0017
	global_load_b32 v19, v[23:24], off offset:3072             // 000000030A0C: DC520C00 137C0017
	global_load_b32 v23, v[25:26], off offset:1024             // 000000030A14: DC520400 177C0019
	global_load_b32 v24, v[25:26], off offset:2048             // 000000030A1C: DC520800 187C0019
	global_load_b32 v31, v[25:26], off offset:3072             // 000000030A24: DC520C00 1F7C0019
	global_load_b32 v28, v[32:33], off offset:1024             // 000000030A2C: DC520400 1C7C0020
	global_load_b32 v29, v[32:33], off offset:2048             // 000000030A34: DC520800 1D7C0020
	global_load_b32 v30, v[32:33], off offset:3072             // 000000030A3C: DC520C00 1E7C0020
	global_load_b32 v25, v[34:35], off offset:1024             // 000000030A44: DC520400 197C0022
	global_load_b32 v26, v[34:35], off offset:2048             // 000000030A4C: DC520800 1A7C0022
	global_load_b32 v27, v[34:35], off offset:3072             // 000000030A54: DC520C00 1B7C0022
	global_load_b32 v32, v[37:38], off offset:1024             // 000000030A5C: DC520400 207C0025
	global_load_b32 v36, v[37:38], off offset:2048             // 000000030A64: DC520800 247C0025
	global_load_b32 v37, v[37:38], off offset:3072             // 000000030A6C: DC520C00 257C0025
	global_load_b32 v33, v[39:40], off offset:1024             // 000000030A74: DC520400 217C0027
	global_load_b32 v34, v[39:40], off offset:2048             // 000000030A7C: DC520800 227C0027
	global_load_b32 v35, v[39:40], off offset:3072             // 000000030A84: DC520C00 237C0027
	global_load_b32 v38, v[47:48], off offset:1024             // 000000030A8C: DC520400 267C002F
	global_load_b32 v39, v[47:48], off offset:2048             // 000000030A94: DC520800 277C002F
	global_load_b32 v40, v[47:48], off offset:3072             // 000000030A9C: DC520C00 287C002F
	v_add_co_ci_u32_e64 v55, null, 0, v83, vcc_lo              // 000000030AA4: D5207C37 01AAA680
	.long 0xd7006a2f                                           // 000000030AAC: D7006A2F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000030AB0: 0201FF52
	.long 0x0000e000                                           // 000000030AB4: 0000E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000030AB8: BF8700A1
	v_add_co_ci_u32_e64 v48, null, 0, v83, vcc_lo              // 000000030ABC: D5207C30 01AAA680
	.long 0xd7006a3e                                           // 000000030AC4: D7006A3E
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 000000030AC8: 0202A4FF 0000E000
	v_add_co_ci_u32_e64 v63, null, 0, v83, vcc_lo              // 000000030AD0: D5207C3F 01AAA680
	.long 0xd7006a43                                           // 000000030AD8: D7006A43
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 000000030ADC: 0202A4FF 0000F000
	s_clause 0x7                                               // 000000030AE4: BF850007
	global_load_b32 v51, v[41:42], off offset:-4096            // 000000030AE8: DC521000 337C0029
	global_load_b32 v58, v[41:42], off                         // 000000030AF0: DC520000 3A7C0029
	global_load_b32 v50, v[43:44], off offset:-4096            // 000000030AF8: DC521000 327C002B
	global_load_b32 v56, v[43:44], off                         // 000000030B00: DC520000 387C002B
	global_load_b32 v44, v[45:46], off offset:-4096            // 000000030B08: DC521000 2C7C002D
	global_load_b32 v43, v[45:46], off                         // 000000030B10: DC520000 2B7C002D
	global_load_b32 v42, v[47:48], off offset:-4096            // 000000030B18: DC521000 2A7C002F
	global_load_b32 v41, v[47:48], off                         // 000000030B20: DC520000 297C002F
	v_add_co_ci_u32_e64 v68, null, 0, v83, vcc_lo              // 000000030B28: D5207C44 01AAA680
	s_clause 0xf                                               // 000000030B30: BF85000F
	global_load_b32 v48, v[54:55], off offset:1024             // 000000030B34: DC520400 307C0036
	global_load_b32 v49, v[54:55], off offset:2048             // 000000030B3C: DC520800 317C0036
	global_load_b32 v55, v[54:55], off offset:3072             // 000000030B44: DC520C00 377C0036
	global_load_b32 v45, v[62:63], off offset:1024             // 000000030B4C: DC520400 2D7C003E
	global_load_b32 v46, v[62:63], off offset:2048             // 000000030B54: DC520800 2E7C003E
	global_load_b32 v47, v[62:63], off offset:3072             // 000000030B5C: DC520C00 2F7C003E
	global_load_b32 v57, v[67:68], off                         // 000000030B64: DC520000 397C0043
	global_load_b32 v59, v[67:68], off offset:1024             // 000000030B6C: DC520400 3B7C0043
	global_load_b32 v54, v[52:53], off offset:-4096            // 000000030B74: DC521000 367C0034
	global_load_b32 v64, v[52:53], off                         // 000000030B7C: DC520000 407C0034
	global_load_b32 v53, v[60:61], off offset:-4096            // 000000030B84: DC521000 357C003C
	global_load_b32 v63, v[60:61], off                         // 000000030B8C: DC520000 3F7C003C
	global_load_b32 v52, v[65:66], off offset:-4096            // 000000030B94: DC521000 347C0041
	global_load_b32 v62, v[65:66], off                         // 000000030B9C: DC520000 3E7C0041
	global_load_b32 v60, v[67:68], off offset:2048             // 000000030BA4: DC520800 3C7C0043
	global_load_b32 v61, v[67:68], off offset:3072             // 000000030BAC: DC520C00 3D7C0043
	v_lshlrev_b32_e32 v65, 3, v0                               // 000000030BB4: 30820083
	s_cbranch_scc1 1                                           // 000000030BB8: BFA20001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4c0>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 000000030BBC: BE9C4D83
	s_load_b32 s39, s[0:1], 0x38                               // 000000030BC0: F40009C0 F8000038
	v_lshrrev_b32_e32 v69, 4, v0                               // 000000030BC8: 328A0084
	s_mul_hi_i32 s4, s2, 0x55555556                            // 000000030BCC: 9704FF02 55555556
	v_and_b32_e32 v67, 0x78, v65                               // 000000030BD4: 368682FF 00000078
	s_lshr_b32 s14, s4, 31                                     // 000000030BDC: 850E9F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000030BE0: BF870499
	s_add_i32 s4, s4, s14                                      // 000000030BE4: 81040E04
	s_lshl_b32 s14, s4, 7                                      // 000000030BE8: 840E8704
	s_delay_alu instid0(VALU_DEP_1)                            // 000000030BEC: BF870001
	v_lshlrev_b32_e32 v67, 1, v67                              // 000000030BF0: 30868681
	s_ashr_i32 s15, s14, 31                                    // 000000030BF4: 860F9F0E
	s_mov_b32 s4, exec_lo                                      // 000000030BF8: BE84007E
	s_lshl_b64 s[14:15], s[14:15], 1                           // 000000030BFC: 848E810E
	s_waitcnt lgkmcnt(0)                                       // 000000030C00: BF89FC07
	s_add_i32 s40, s39, -1                                     // 000000030C04: 8128C127
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000030C08: BF870099
	v_min_i32_e32 v66, s40, v69                                // 000000030C0C: 22848A28
	v_mad_i64_i32 v[65:66], null, 0x5000, v66, s[8:9]          // 000000030C10: D6FF7C41 002284FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000030C1C: BF870091
	.long 0xd7006a41                                           // 000000030C20: D7006A41
	v_cndmask_b32_e32 v0, v65, v14, vcc_lo                     // 000000030C24: 02001D41
	v_add_co_ci_u32_e64 v66, null, s15, v66, vcc_lo            // 000000030C28: D5207C42 01AA840F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000030C30: BF870092
	.long 0xd7006a41                                           // 000000030C34: D7006A41
	v_cndmask_b32_e32 v1, v65, v67, vcc_lo                     // 000000030C38: 02028741
	v_add_co_ci_u32_e64 v66, null, 0, v66, vcc_lo              // 000000030C3C: D5207C42 01AA8480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000030C44: BF870092
	.long 0xd7006a43                                           // 000000030C48: D7006A43
	v_cndmask_b32_e32 v1, 0x1000, v65, vcc_lo                  // 000000030C4C: 020282FF 00001000
	v_add_co_ci_u32_e64 v68, null, 0, v66, vcc_lo              // 000000030C54: D5207C44 01AA8480
	s_clause 0x1                                               // 000000030C5C: BF850001
	global_load_b128 v[74:77], v[65:66], off                   // 000000030C60: DC5E0000 4A7C0041
	global_load_b128 v[78:81], v[67:68], off                   // 000000030C68: DC5E0000 4E7C0043
	.long 0xd4c3007e                                           // 000000030C70: D4C3007E
	v_cndmask_b32_e32 v1, s39, v69, vcc_lo                     // 000000030C74: 02028A27
	s_cbranch_execz 11                                         // 000000030C78: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5a8>
	s_waitcnt vmcnt(1)                                         // 000000030C7C: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 000000030C80: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000030C84: BF870001
	v_mov_b32_e32 v75, v76                                     // 000000030C88: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 000000030C8C: 7E94034C
	s_waitcnt vmcnt(0)                                         // 000000030C90: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 000000030C94: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 000000030C98: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 000000030C9C: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 000000030CA0: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 000000030CA4: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s4                              // 000000030CA8: 8C7E047E
	v_cmp_gt_u32_e32 vcc_lo, 16, v0                            // 000000030CAC: 7C980090
	.long 0xd4440004                                           // 000000030CB0: D4440004
	v_cndmask_b32_e32 v1, s39, v0, vcc_lo                      // 000000030CB4: 02020027
	v_dual_mov_b32 v141, 0 :: v_dual_mov_b32 v140, 0           // 000000030CB8: CA100080 8D8C0080
	s_and_b32 s16, vcc_lo, s4                                  // 000000030CC0: 8B10046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000030CC4: BF870009
	s_and_saveexec_b32 s4, s16                                 // 000000030CC8: BE842010
	s_cbranch_execz 27                                         // 000000030CCC: BFA5001B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x63c>
	v_mul_u32_u24_e32 v65, 0xc0, v0                            // 000000030CD0: 168200FF 000000C0
	s_lshl_b64 s[16:17], s[2:3], 2                             // 000000030CD8: 84908202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000030CDC: BF870091
	.long 0xd7001242                                           // 000000030CE0: D7001242
	v_cndmask_b32_e32 v1, s10, v65, vcc_lo                     // 000000030CE4: 0202820A
	v_add_co_ci_u32_e64 v67, null, s11, 0, s18                 // 000000030CE8: D5207C43 0049000B
	.long 0xd7001244                                           // 000000030CF0: D7001244
	v_cndmask_b32_e32 v1, s12, v65, vcc_lo                     // 000000030CF4: 0202820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000030CF8: BF870211
	v_add_co_ci_u32_e64 v69, null, s13, 0, s18                 // 000000030CFC: D5207C45 0049000D
	.long 0xd7006a41                                           // 000000030D04: D7006A41
	v_cndmask_b32_e32 v0, v66, v16, vcc_lo                     // 000000030D08: 02002142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000030D0C: BF870211
	v_add_co_ci_u32_e64 v66, null, s17, v67, vcc_lo            // 000000030D10: D5207C42 01AA8611
	.long 0xd7006a43                                           // 000000030D18: D7006A43
	v_cndmask_b32_e32 v0, v68, v16, vcc_lo                     // 000000030D1C: 02002144
	s_delay_alu instid0(VALU_DEP_1)                            // 000000030D20: BF870001
	v_add_co_ci_u32_e64 v68, null, s17, v69, vcc_lo            // 000000030D24: D5207C44 01AA8A11
	global_load_b32 v140, v[65:66], off                        // 000000030D2C: DC520000 8C7C0041
	global_load_b32 v141, v[67:68], off                        // 000000030D34: DC520000 8D7C0043
	s_or_b32 exec_lo, exec_lo, s4                              // 000000030D3C: 8C7E047E
	s_waitcnt vmcnt(62)                                        // 000000030D40: BF89FBF7
	v_dual_mul_f32 v139, 0x43800000, v5 :: v_dual_mul_f32 v138, 0x43800000, v6// 000000030D44: C8C60AFF 8B8A0CFF 43800000
	v_dual_mul_f32 v137, 0x43800000, v7 :: v_dual_mul_f32 v136, 0x43800000, v8// 000000030D50: C8C60EFF 898810FF 43800000
	s_waitcnt vmcnt(9)                                         // 000000030D5C: BF8927F7
	v_dual_mul_f32 v135, 0x43800000, v54 :: v_dual_mul_f32 v54, 0x43800000, v4// 000000030D60: C8C66CFF 873608FF 43800000
	v_dual_mul_f32 v134, 0x43800000, v2 :: v_dual_mul_f32 v133, 0x43800000, v3// 000000030D6C: C8C604FF 868406FF 43800000
	s_waitcnt vmcnt(8)                                         // 000000030D78: BF8923F7
	v_dual_mul_f32 v132, 0x43800000, v64 :: v_dual_mul_f32 v131, 0x43800000, v1// 000000030D7C: C8C680FF 848202FF 43800000
	v_dual_mul_f32 v130, 0x43800000, v12 :: v_dual_mul_f32 v129, 0x43800000, v13// 000000030D88: C8C618FF 82801AFF 43800000
	s_waitcnt vmcnt(7)                                         // 000000030D94: BF891FF7
	v_dual_mul_f32 v128, 0x43800000, v53 :: v_dual_mul_f32 v53, 0x43800000, v11// 000000030D98: C8C66AFF 803416FF 43800000
	v_dual_mul_f32 v127, 0x43800000, v9 :: v_dual_mul_f32 v126, 0x43800000, v10// 000000030DA4: C8C612FF 7F7E14FF 43800000
	s_waitcnt vmcnt(6)                                         // 000000030DB0: BF891BF7
	v_dual_mul_f32 v125, 0x43800000, v63 :: v_dual_mul_f32 v124, 0x43800000, v14// 000000030DB4: C8C67EFF 7D7C1CFF 43800000
	v_dual_mul_f32 v123, 0x43800000, v15 :: v_dual_mul_f32 v122, 0x43800000, v16// 000000030DC0: C8C61EFF 7B7A20FF 43800000
	s_waitcnt vmcnt(5)                                         // 000000030DCC: BF8917F7
	v_dual_mul_f32 v121, 0x43800000, v52 :: v_dual_mul_f32 v52, 0x43800000, v22// 000000030DD0: C8C668FF 79342CFF 43800000
	v_dual_mul_f32 v120, 0x43800000, v20 :: v_dual_mul_f32 v119, 0x43800000, v21// 000000030DDC: C8C628FF 78762AFF 43800000
	s_waitcnt vmcnt(4)                                         // 000000030DE8: BF8913F7
	v_dual_mul_f32 v118, 0x43800000, v62 :: v_dual_mul_f32 v117, 0x43800000, v17// 000000030DEC: C8C67CFF 767422FF 43800000
	v_dual_mul_f32 v116, 0x43800000, v18 :: v_dual_mul_f32 v115, 0x43800000, v19// 000000030DF8: C8C624FF 747226FF 43800000
	v_dual_mul_f32 v114, 0x43800000, v51 :: v_dual_mul_f32 v111, 0x43800000, v58// 000000030E04: C8C666FF 726E74FF 43800000
	v_dual_mul_f32 v113, 0x43800000, v23 :: v_dual_mul_f32 v112, 0x43800000, v24// 000000030E10: C8C62EFF 717030FF 43800000
	v_dual_mul_f32 v51, 0x43800000, v31 :: v_dual_mul_f32 v110, 0x43800000, v28// 000000030E1C: C8C63EFF 336E38FF 43800000
	v_dual_mul_f32 v109, 0x43800000, v29 :: v_dual_mul_f32 v108, 0x43800000, v30// 000000030E28: C8C63AFF 6D6C3CFF 43800000
	v_dual_mul_f32 v107, 0x43800000, v50 :: v_dual_mul_f32 v106, 0x43800000, v25// 000000030E34: C8C664FF 6B6A32FF 43800000
	v_dual_mul_f32 v105, 0x43800000, v26 :: v_dual_mul_f32 v50, 0x43800000, v27// 000000030E40: C8C634FF 693236FF 43800000
	v_dual_mul_f32 v104, 0x43800000, v56 :: v_dual_mul_f32 v101, 0x43800000, v37// 000000030E4C: C8C670FF 68644AFF 43800000
	v_dual_mul_f32 v103, 0x43800000, v32 :: v_dual_mul_f32 v98, 0x43800000, v34// 000000030E58: C8C640FF 676244FF 43800000
	v_dual_mul_f32 v102, 0x43800000, v36 :: v_dual_mul_f32 v99, 0x43800000, v33// 000000030E64: C8C648FF 666242FF 43800000
	v_dual_mul_f32 v100, 0x43800000, v44 :: v_dual_mul_f32 v97, 0x43800000, v43// 000000030E70: C8C658FF 646056FF 43800000
	v_dual_mul_f32 v58, 0x43800000, v35 :: v_dual_mul_f32 v93, 0x43800000, v42// 000000030E7C: C8C646FF 3A5C54FF 43800000
	v_dual_mul_f32 v96, 0x43800000, v38 :: v_dual_mul_f32 v95, 0x43800000, v39// 000000030E88: C8C64CFF 605E4EFF 43800000
	v_dual_mul_f32 v94, 0x43800000, v40 :: v_dual_mul_f32 v91, 0x43800000, v49// 000000030E94: C8C650FF 5E5A62FF 43800000
	v_dual_mul_f32 v92, 0x43800000, v48 :: v_dual_mul_f32 v147, 0x43800000, v55// 000000030EA0: C8C660FF 5C926EFF 43800000
	v_dual_mul_f32 v90, 0x43800000, v41 :: v_dual_mul_f32 v87, 0x43800000, v47// 000000030EAC: C8C652FF 5A565EFF 43800000
	v_dual_mul_f32 v89, 0x43800000, v45 :: v_dual_mul_f32 v88, 0x43800000, v46// 000000030EB8: C8C65AFF 59585CFF 43800000
	s_waitcnt vmcnt(3)                                         // 000000030EC4: BF890FF7
	v_dual_mul_f32 v86, 0x43800000, v57 :: v_dual_mul_f32 v85, 0x43800000, v60// 000000030EC8: C8C672FF 565478FF 43800000
	v_mul_f32_e32 v84, 0x43800000, v59                         // 000000030ED4: 10A876FF 43800000
	s_waitcnt vmcnt(2)                                         // 000000030EDC: BF890BF7
	v_mul_f32_e32 v146, 0x43800000, v61                        // 000000030EE0: 11247AFF 43800000
	s_cmp_lt_i32 s39, 1                                        // 000000030EE8: BF048127
	s_cbranch_scc1 4708                                        // 000000030EEC: BFA21264 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5180>
	s_add_u32 s30, s8, s14                                     // 000000030EF0: 801E0E08
	s_addc_u32 s31, s9, s15                                    // 000000030EF4: 821F0F09
	s_lshl_b64 s[14:15], s[2:3], 2                             // 000000030EF8: 848E8202
	s_load_b64 s[26:27], s[0:1], 0x68                          // 000000030EFC: F4040680 F8000068
	s_add_u32 s10, s10, s14                                    // 000000030F04: 800A0E0A
	s_addc_u32 s11, s11, s15                                   // 000000030F08: 820B0F0B
	s_add_u32 s34, s12, s14                                    // 000000030F0C: 80220E0C
	s_addc_u32 s35, s13, s15                                   // 000000030F10: 82230F0D
	s_add_i32 s3, s39, 15                                      // 000000030F14: 81038F27
	s_load_b256 s[12:19], s[0:1], 0x48                         // 000000030F18: F40C0300 F8000048
	s_ashr_i32 s4, s3, 31                                      // 000000030F20: 86049F03
	v_rsq_f32_e32 v142, 0x43000000                             // 000000030F24: 7F1C5CFF 43000000
	s_lshr_b32 s4, s4, 28                                      // 000000030F2C: 85049C04
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v144, 0x1000504     // 000000030F30: CA100080 019000FF 01000504
	s_add_i32 s3, s3, s4                                       // 000000030F3C: 81030403
	.long 0xd71f008f                                           // 000000030F40: D71F008F
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000030F44: 020100C1
	s_waitcnt lgkmcnt(0)                                       // 000000030F48: BF89FC07
	s_ashr_i32 s15, s3, 4                                      // 000000030F4C: 860F8403
	s_cmp_lg_u32 s21, 0                                        // 000000030F50: BF078015
	s_movk_i32 s3, 0x5f40                                      // 000000030F54: B0035F40
	s_cselect_b32 s41, -1, 0                                   // 000000030F58: 982980C1
	s_lshl_b32 s22, s2, 7                                      // 000000030F5C: 84168702
	v_mov_b32_e32 v145, 0x3020706                              // 000000030F60: 7F2202FF 03020706
	s_ashr_i32 s23, s22, 31                                    // 000000030F68: 86179F16
	s_cmp_gt_u32 s20, 63                                       // 000000030F6C: BF08BF14
	s_mov_b32 s20, 0                                           // 000000030F70: BE940080
	s_cselect_b32 s42, -1, 0                                   // 000000030F74: 982A80C1
	s_cmp_eq_u32 s21, 0                                        // 000000030F78: BF068015
	s_mov_b32 s48, 0x41800000                                  // 000000030F7C: BEB000FF 41800000
	s_cselect_b32 s2, -1, 0                                    // 000000030F84: 980280C1
	s_movk_i32 s49, 0x1800                                     // 000000030F88: B0311800
	s_and_b32 s4, s2, exec_lo                                  // 000000030F8C: 8B047E02
	s_cselect_b32 s43, s3, 0x5f80                              // 000000030F90: 982BFF03 00005F80
	s_lshl_b64 s[36:37], s[22:23], 1                           // 000000030F98: 84A48116
	s_movk_i32 s50, 0x2900                                     // 000000030F9C: B0322900
	s_add_u32 s44, s24, s36                                    // 000000030FA0: 802C2418
	s_addc_u32 s45, s25, s37                                   // 000000030FA4: 822D2519
	s_max_i32 s46, s15, 1                                      // 000000030FA8: 8A2E810F
	s_add_u32 s16, s16, s6                                     // 000000030FAC: 80100610
	s_addc_u32 s17, s17, s7                                    // 000000030FB0: 82110711
	s_add_u32 s18, s18, s6                                     // 000000030FB4: 80120612
	s_addc_u32 s19, s19, s7                                    // 000000030FB8: 82130713
	s_add_u32 s47, s26, s6                                     // 000000030FBC: 802F061A
	s_addc_u32 s7, s27, s7                                     // 000000030FC0: 8207071B
	s_mov_b32 s21, s20                                         // 000000030FC4: BE950014
	s_mov_b32 s22, s20                                         // 000000030FC8: BE960014
	s_mov_b32 s23, s20                                         // 000000030FCC: BE970014
	s_mov_b32 s24, s20                                         // 000000030FD0: BE980014
	s_mov_b32 s25, s20                                         // 000000030FD4: BE990014
	s_mov_b32 s26, s20                                         // 000000030FD8: BE9A0014
	s_mov_b32 s27, s20                                         // 000000030FDC: BE9B0014
	s_mov_b32 s51, 0x3d800000                                  // 000000030FE0: BEB300FF 3D800000
	s_mov_b32 s52, 0x76543210                                  // 000000030FE8: BEB400FF 76543210
	s_mov_b32 s53, s20                                         // 000000030FF0: BEB50014
	s_mov_b32 s6, s20                                          // 000000030FF4: BE860014
	s_branch 10                                                // 000000030FF8: BFA0000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x924>
	v_mov_b32_e32 v146, v65                                    // 000000030FFC: 7F240341
	v_mov_b32_e32 v147, v57                                    // 000000031000: 7F260339
	v_mov_b32_e32 v58, v49                                     // 000000031004: 7E740331
	v_mov_b32_e32 v50, v9                                      // 000000031008: 7E640309
	v_mov_b32_e32 v51, v17                                     // 00000003100C: 7E660311
	v_mov_b32_e32 v52, v25                                     // 000000031010: 7E680319
	v_mov_b32_e32 v53, v33                                     // 000000031014: 7E6A0321
	v_mov_b32_e32 v54, v41                                     // 000000031018: 7E6C0329
	s_cmp_eq_u32 s53, s46                                      // 00000003101C: BF062E35
	s_cbranch_scc1 4621                                        // 000000031020: BFA2120D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5158>
	v_mov_b32_e32 v44, v0                                      // 000000031024: 7E580300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000031028: BF8701B1
	v_ashrrev_i32_e32 v2, 4, v44                               // 00000003102C: 34045884
	v_and_b32_e32 v55, 15, v44                                 // 000000031030: 366E588F
	.long 0xd4440003                                           // 000000031034: D4440003
	v_cndmask_b32_e32 v1, 16, v44, vcc_lo                      // 000000031038: 02025890
	.long 0xd72c0003                                           // 00000003103C: D72C0003
	v_cndmask_b32_e32 v1, 0x110, v2, vcc_lo                    // 000000031040: 020204FF 00000110
	s_delay_alu instid0(VALU_DEP_1)                            // 000000031048: BF870001
	v_lshl_add_u32 v3, v55, 4, v3                              // 00000003104C: D6460003 040D0937
	s_waitcnt vmcnt(1)                                         // 000000031054: BF8907F7
	ds_store_b128 v3, v[74:77] offset:10496                    // 000000031058: DB7C2900 00004A03
	s_waitcnt vmcnt(0)                                         // 000000031060: BF8903F7
	ds_store_b128 v3, v[78:81] offset:6144                     // 000000031064: DB7C1800 00004E03
	s_and_saveexec_b32 s4, s3                                  // 00000003106C: BE842003
	v_lshlrev_b32_e32 v3, 2, v44                               // 000000031070: 30065882
	ds_store_b32 v3, v141 offset:24064                         // 000000031074: D8345E00 00008D03
	s_or_b32 exec_lo, exec_lo, s4                              // 00000003107C: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000031080: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 000000031084: 916A267E
	s_cbranch_vccnz 1                                          // 000000031088: BFA40001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x990>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 00000003108C: BE9C4D83
	v_and_b32_e32 v34, 1, v44                                  // 000000031090: 36445881
	s_waitcnt lgkmcnt(0)                                       // 000000031094: BF89FC07
	s_lshl_b32 s29, s53, 4                                     // 000000031098: 841D8435
	v_or_b32_e32 v148, s33, v55                                // 00000003109C: 39286E21
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000310A0: BF870112
	v_or_b32_e32 v15, s29, v34                                 // 0000000310A4: 381E441D
	v_and_b32_e32 v6, 0x7ffffffe, v148                         // 0000000310A8: 360D28FF 7FFFFFFE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000000310B0: BF870232
	v_min_i32_e32 v3, s40, v15                                 // 0000000310B4: 22061E28
	v_or_b32_e32 v5, 2, v15                                    // 0000000310B8: 380A1E82
	v_or_b32_e32 v7, 4, v15                                    // 0000000310BC: 380E1E84
	v_lshlrev_b32_e32 v19, 1, v6                               // 0000000310C0: 30260C81
	v_or_b32_e32 v8, 6, v15                                    // 0000000310C4: 38101E86
	v_mad_i64_i32 v[3:4], null, 0x5000, v3, s[8:9]             // 0000000310C8: D6FF7C03 002206FF 00005000
	v_min_i32_e32 v5, s40, v5                                  // 0000000310D4: 220A0A28
	v_min_i32_e32 v7, s40, v7                                  // 0000000310D8: 220E0E28
	v_or_b32_e32 v17, 12, v15                                  // 0000000310DC: 38221E8C
	v_min_i32_e32 v8, s40, v8                                  // 0000000310E0: 22101028
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000310E4: BF8700A4
	v_mad_i64_i32 v[5:6], null, 0x5000, v5, s[8:9]             // 0000000310E8: D6FF7C05 00220AFF 00005000
	.long 0xd7006a09                                           // 0000000310F4: D7006A09
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 0000000310F8: 02004903
	v_add_co_ci_u32_e64 v10, null, s37, v4, vcc_lo             // 0000000310FC: D5207C0A 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v7, s[8:9]             // 000000031104: D6FF7C03 00220EFF 00005000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031110: BF870093
	.long 0xd7006a07                                           // 000000031114: D7006A07
	v_cndmask_b32_e32 v1, v9, v19, vcc_lo                      // 000000031118: 02022709
	v_add_co_ci_u32_e64 v9, null, 0, v10, vcc_lo               // 00000003111C: D5207C09 01AA1480
	.long 0xd7006a0a                                           // 000000031124: D7006A0A
	v_cndmask_b32_e32 v0, v5, v36, vcc_lo                      // 000000031128: 02004905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003112C: BF870211
	v_add_co_ci_u32_e64 v11, null, s37, v6, vcc_lo             // 000000031130: D5207C0B 01AA0C25
	.long 0xd7006a05                                           // 000000031138: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 00000003113C: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000031144: BF870211
	v_add_co_ci_u32_e64 v6, null, 0, v9, vcc_lo                // 000000031148: D5207C06 01AA1280
	.long 0xd7006a07                                           // 000000031150: D7006A07
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 000000031154: 0202270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031158: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v11, vcc_lo               // 00000003115C: D5207C09 01AA1680
	.long 0xd7006a0a                                           // 000000031164: D7006A0A
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000031168: 02004903
	v_add_co_ci_u32_e64 v11, null, s37, v4, vcc_lo             // 00000003116C: D5207C0B 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v8, s[8:9]             // 000000031174: D6FF7C03 002210FF 00005000
	.long 0xd7006a07                                           // 000000031180: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 000000031184: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003118C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v9, vcc_lo                // 000000031190: D5207C08 01AA1280
	.long 0xd7006a09                                           // 000000031198: D7006A09
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 00000003119C: 0202270A
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo              // 0000000311A0: D5207C0A 01AA1680
	v_or_b32_e32 v11, 8, v15                                   // 0000000311A8: 38161E88
	.long 0xd7006a03                                           // 0000000311AC: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 0000000311B0: 02004903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000311B4: BF870191
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 0000000311B8: D5207C04 01AA0825
	v_min_i32_e32 v11, s40, v11                                // 0000000311C0: 22161628
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000311C4: BF870093
	.long 0xd7006a0c                                           // 0000000311C8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 0000000311CC: 02022703
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 0000000311D0: D5207C0D 01AA0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000311D8: BF8700A3
	v_mad_i64_i32 v[3:4], null, 0x5000, v11, s[8:9]            // 0000000311DC: D6FF7C03 002216FF 00005000
	.long 0xd7006a09                                           // 0000000311E8: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v9, vcc_lo                   // 0000000311EC: 020212FF 00002000
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 0000000311F4: D5207C0A 01AA1480
	.long 0xd7006a0b                                           // 0000000311FC: D7006A0B
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 000000031200: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000031208: BF8700B1
	v_add_co_ci_u32_e64 v12, null, 0, v13, vcc_lo              // 00000003120C: D5207C0C 01AA1A80
	v_or_b32_e32 v13, 10, v15                                  // 000000031214: 381A1E8A
	.long 0xd7006a03                                           // 000000031218: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000003121C: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 000000031220: D5207C04 01AA0825
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000031228: BF870193
	v_min_i32_e32 v13, s40, v13                                // 00000003122C: 221A1A28
	.long 0xd7006a0e                                           // 000000031230: D7006A0E
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000031234: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000031238: BF870191
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000003123C: D5207C10 01AA0880
	v_mad_i64_i32 v[3:4], null, 0x5000, v13, s[8:9]            // 000000031244: D6FF7C03 00221AFF 00005000
	v_or_b32_e32 v15, 14, v15                                  // 000000031250: 381E1E8E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031254: BF870094
	.long 0xd7006a0d                                           // 000000031258: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v14, vcc_lo                  // 00000003125C: 02021CFF 00002000
	v_add_co_ci_u32_e64 v14, null, 0, v16, vcc_lo              // 000000031264: D5207C0E 01AA2080
	v_min_i32_e32 v16, s40, v17                                // 00000003126C: 22202228
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031270: BF8700A4
	v_min_i32_e32 v15, s40, v15                                // 000000031274: 221E1E28
	.long 0xd7006a11                                           // 000000031278: D7006A11
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000003127C: 02004903
	v_add_co_ci_u32_e64 v18, null, s37, v4, vcc_lo             // 000000031280: D5207C12 01AA0825
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000031288: BF870194
	v_mad_i64_i32 v[3:4], null, 0x5000, v16, s[8:9]            // 00000003128C: D6FF7C03 002220FF 00005000
	.long 0xd7006a11                                           // 000000031298: D7006A11
	v_cndmask_b32_e32 v1, v17, v19, vcc_lo                     // 00000003129C: 02022711
	v_mad_i64_i32 v[15:16], null, 0x5000, v15, s[8:9]          // 0000000312A0: D6FF7C0F 00221EFF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000312AC: BF870194
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 0000000312B0: D5207C12 01AA2480
	.long 0xd7006a11                                           // 0000000312B8: D7006A11
	v_cndmask_b32_e32 v1, 0x2000, v17, vcc_lo                  // 0000000312BC: 020222FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000312C4: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 0000000312C8: D5207C12 01AA2480
	.long 0xd7006a03                                           // 0000000312D0: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 0000000312D4: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 0000000312D8: D5207C04 01AA0825
	.long 0xd7006a0f                                           // 0000000312E0: D7006A0F
	v_cndmask_b32_e32 v0, v15, v36, vcc_lo                     // 0000000312E4: 0200490F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000312E8: BF870211
	v_add_co_ci_u32_e64 v16, null, s37, v16, vcc_lo            // 0000000312EC: D5207C10 01AA2025
	.long 0xd7006a03                                           // 0000000312F4: D7006A03
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 0000000312F8: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000312FC: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000031300: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 000000031308: D7006A0F
	v_cndmask_b32_e32 v1, v15, v19, vcc_lo                     // 00000003130C: 0202270F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000031310: BF870211
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000031314: D5207C10 01AA2080
	.long 0xd7006a03                                           // 00000003131C: D7006A03
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 000000031320: 020206FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000031328: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000003132C: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 000000031334: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v15, vcc_lo                  // 000000031338: 02021EFF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000031340: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000031344: D5207C10 01AA2080
	s_clause 0x7                                               // 00000003134C: BF850007
	global_load_b32 v42, v[5:6], off                           // 000000031350: DC520000 2A7C0005
	global_load_b32 v41, v[7:8], off                           // 000000031358: DC520000 297C0007
	global_load_b32 v40, v[9:10], off                          // 000000031360: DC520000 287C0009
	global_load_b32 v39, v[11:12], off                         // 000000031368: DC520000 277C000B
	global_load_b32 v38, v[13:14], off                         // 000000031370: DC520000 267C000D
	global_load_b32 v37, v[17:18], off                         // 000000031378: DC520000 257C0011
	global_load_b32 v35, v[3:4], off                           // 000000031380: DC520000 237C0003
	global_load_b32 v36, v[15:16], off                         // 000000031388: DC520000 247C000F
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 000000031390: 916A267E
	s_cbranch_vccnz 4                                          // 000000031394: BFA40004 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xca8>
	s_sendmsg_rtn_b64 s[54:55], sendmsg(MSG_RTN_GET_REALTIME)  // 000000031398: BEB64D83
	s_sub_i32 s4, s6, s28                                      // 00000003139C: 81841C06
	s_waitcnt lgkmcnt(0)                                       // 0000000313A0: BF89FC07
	s_add_i32 s6, s4, s54                                      // 0000000313A4: 81063604
	v_and_b32_e32 v4, 0xffff0000, v74                          // 0000000313A8: 360894FF FFFF0000
	v_lshlrev_b32_e32 v3, 16, v74                              // 0000000313B0: 30069490
	v_and_b32_e32 v9, 0xffff0000, v79                          // 0000000313B4: 36129EFF FFFF0000
	s_mov_b32 s54, exec_lo                                     // 0000000313BC: BEB6007E
	v_lshlrev_b32_e32 v10, 16, v76                             // 0000000313C0: 30149890
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000313C4: BF870243
	v_dual_mul_f32 v4, v4, v4 :: v_dual_mul_f32 v3, v3, v3     // 0000000313C8: C8C60904 04020703
	v_and_b32_e32 v8, 0xffff0000, v75                          // 0000000313D0: 361096FF FFFF0000
	v_and_b32_e32 v11, 0xffff0000, v76                         // 0000000313D8: 361698FF FFFF0000
	v_mul_f32_e32 v9, v9, v9                                   // 0000000313E0: 10121309
	v_add_f32_e32 v3, v3, v4                                   // 0000000313E4: 06060903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000313E8: BF870124
	v_dual_mul_f32 v8, v8, v8 :: v_dual_lshlrev_b32 v5, 16, v78// 0000000313EC: C8E21108 08049C90
	v_and_b32_e32 v6, 0xffff0000, v78                          // 0000000313F4: 360C9CFF FFFF0000
	v_dual_mul_f32 v5, v5, v5 :: v_dual_lshlrev_b32 v4, 16, v79// 0000000313FC: C8E20B05 05049E90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031404: BF870092
	v_dual_mul_f32 v6, v6, v6 :: v_dual_lshlrev_b32 v7, 16, v75// 000000031408: C8E20D06 06069690
	v_dual_mul_f32 v4, v4, v4 :: v_dual_mul_f32 v7, v7, v7     // 000000031410: C8C60904 04060F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000031418: BF870232
	v_add_f32_e32 v5, v5, v6                                   // 00000003141C: 060A0D05
	v_mul_f32_e32 v6, v10, v10                                 // 000000031420: 100C150A
	v_mul_f32_e32 v10, v11, v11                                // 000000031424: 1014170B
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v8     // 000000031428: C9081304 04061107
	v_and_b32_e32 v9, 0xffff0000, v80                          // 000000031430: 3612A0FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000031438: BF870193
	v_dual_add_f32 v6, v6, v10 :: v_dual_and_b32 v11, 0xffff0000, v77// 00000003143C: C9241506 060A9AFF FFFF0000
	v_dual_add_f32 v3, v3, v7 :: v_dual_lshlrev_b32 v10, 16, v77// 000000031448: C9220F03 030A9A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000031450: BF870112
	v_dual_mul_f32 v11, v11, v11 :: v_dual_lshlrev_b32 v8, 16, v80// 000000031454: C8E2170B 0B08A090
	v_dual_mul_f32 v10, v10, v10 :: v_dual_and_b32 v13, 0xffff0000, v81// 00000003145C: C8E4150A 0A0CA2FF FFFF0000
	v_dual_mul_f32 v9, v9, v9 :: v_dual_and_b32 v14, 16, v143  // 000000031468: C8E41309 090F1E90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000031470: BF870112
	v_dual_mul_f32 v8, v8, v8 :: v_dual_mul_f32 v13, v13, v13  // 000000031474: C8C61108 080C1B0D
	v_dual_add_f32 v10, v10, v11 :: v_dual_add_nc_u32 v11, 16, v14// 00000003147C: C920170A 0A0A1C90
	v_xor_b32_e32 v14, 1, v143                                 // 000000031484: 3A1D1E81
	v_add_f32_e32 v4, v5, v4                                   // 000000031488: 06080905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003148C: BF870223
	v_add_f32_e32 v6, v6, v10                                  // 000000031490: 060C1506
	v_add_f32_e32 v8, v8, v9                                   // 000000031494: 06101308
	v_cmp_lt_u32_e32 vcc_lo, v14, v11                          // 000000031498: 7C92170E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003149C: BF870093
	v_dual_add_f32 v3, v3, v6 :: v_dual_lshlrev_b32 v12, 16, v81// 0000000314A0: C9220D03 030CA290
	v_dual_cndmask_b32 v7, v143, v14 :: v_dual_mul_f32 v12, v12, v12// 0000000314A8: CA461D8F 070C190C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000314B0: BF870121
	v_dual_add_f32 v9, v12, v13 :: v_dual_lshlrev_b32 v6, 2, v7// 0000000314B4: C9221B0C 09060E82
	v_xor_b32_e32 v7, 2, v143                                  // 0000000314BC: 3A0F1E82
	v_add_f32_e32 v5, v8, v9                                   // 0000000314C0: 060A1308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000314C4: BF870112
	v_cmp_lt_u32_e32 vcc_lo, v7, v11                           // 0000000314C8: 7C921707
	v_dual_add_f32 v4, v4, v5 :: v_dual_cndmask_b32 v7, v143, v7// 0000000314CC: C9120B04 04060F8F
	ds_bpermute_b32 v5, v6, v3                                 // 0000000314D4: DACC0000 05000306
	s_waitcnt lgkmcnt(0)                                       // 0000000314DC: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 0000000314E0: 06060B03
	ds_bpermute_b32 v6, v6, v4                                 // 0000000314E4: DACC0000 06000406
	v_lshlrev_b32_e32 v5, 2, v7                                // 0000000314EC: 300A0E82
	v_xor_b32_e32 v7, 4, v143                                  // 0000000314F0: 3A0F1E84
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000314F4: BF870001
	v_cmp_lt_u32_e32 vcc_lo, v7, v11                           // 0000000314F8: 7C921707
	s_waitcnt lgkmcnt(0)                                       // 0000000314FC: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 000000031500: 06080D04
	ds_bpermute_b32 v6, v5, v3                                 // 000000031504: DACC0000 06000305
	ds_bpermute_b32 v5, v5, v4                                 // 00000003150C: DACC0000 05000405
	v_cndmask_b32_e32 v7, v143, v7, vcc_lo                     // 000000031514: 020E0F8F
	s_waitcnt lgkmcnt(0)                                       // 000000031518: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v5     // 00000003151C: C9080D03 03040B04
	s_delay_alu instid0(VALU_DEP_2)                            // 000000031524: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000031528: 300E0E82
	ds_bpermute_b32 v6, v7, v4                                 // 00000003152C: DACC0000 06000407
	s_waitcnt lgkmcnt(0)                                       // 000000031534: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 000000031538: 06080D04
	ds_bpermute_b32 v5, v7, v3                                 // 00000003153C: DACC0000 05000307
	v_xor_b32_e32 v7, 8, v143                                  // 000000031544: 3A0F1E88
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000031548: BF8700A1
	v_cmp_lt_u32_e32 vcc_lo, v7, v11                           // 00000003154C: 7C921707
	v_cndmask_b32_e32 v7, v143, v7, vcc_lo                     // 000000031550: 020E0F8F
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000031554: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 000000031558: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000003155C: 06060B03
	ds_bpermute_b32 v6, v7, v4                                 // 000000031560: DACC0000 06000407
	ds_bpermute_b32 v5, v7, v3                                 // 000000031568: DACC0000 05000307
	v_cmpx_eq_u32_e32 0, v55                                   // 000000031570: 7D946E80
	s_cbranch_execz 38                                         // 000000031574: BFA50026 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xf10>
	s_waitcnt lgkmcnt(0)                                       // 000000031578: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000003157C: C9080B03 03040D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031584: BF870091
	v_dual_add_f32 v3, 0x358637bd, v3 :: v_dual_add_f32 v4, 0x358637bd, v4// 000000031588: C90806FF 030408FF 358637BD
	v_dual_mul_f32 v5, 0x4b800000, v3 :: v_dual_mul_f32 v6, 0x4b800000, v4// 000000031594: C8C606FF 050608FF 4B800000
	.long 0xd4140004                                           // 0000000315A0: D4140004
	v_cndmask_b32_e32 v1, 0x800000, v4, vcc_lo                 // 0000000315A4: 020208FF 00800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v3                      // 0000000315AC: 7C2806FF 00800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000315B4: BF870092
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 0000000315B8: D5010004 00120D04
	v_rsq_f32_e32 v4, v4                                       // 0000000315C0: 7E085D04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000315C4: BF870095
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_mul_f32 v6, 0x45800000, v4// 0000000315C8: CA460B03 030608FF 45800000
	v_rsq_f32_e32 v3, v3                                       // 0000000315D4: 7E065D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000315D8: BF870291
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 0000000315DC: D5010004 00120D04
	v_mul_f32_e32 v5, 0x45800000, v3                           // 0000000315E4: 100A06FF 45800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000315EC: BF870121
	v_cndmask_b32_e32 v3, v3, v5, vcc_lo                       // 0000000315F0: 02060B03
	v_lshlrev_b32_e32 v5, 2, v2                                // 0000000315F4: 300A0482
	v_mul_f32_e32 v3, v142, v3                                 // 0000000315F8: 1006078E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000315FC: BF870002
	v_add_nc_u32_e32 v5, 0x5c00, v5                            // 000000031600: 4A0A0AFF 00005C00
	ds_store_2addr_b32 v5, v4, v3 offset0:208 offset1:224      // 000000031608: D838E0D0 00030405
	s_or_b32 exec_lo, exec_lo, s54                             // 000000031610: 8C7E367E
	v_and_b32_e32 v43, 31, v44                                 // 000000031614: 3656589F
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 000000031618: 916A027E
	s_cbranch_vccnz 119                                        // 00000003161C: BFA40077 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10fc>
	.long 0xd7600045                                           // 000000031620: D7600045
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                   // 000000031624: 0201018C
	.long 0xd7600044                                           // 000000031628: D7600044
	v_cndmask_b32_e32 v0, v140, v129, vcc_lo                   // 00000003162C: 0201038C
	.long 0xd7600043                                           // 000000031630: D7600043
	v_cndmask_b32_e32 v0, v140, v130, vcc_lo                   // 000000031634: 0201058C
	.long 0xd7600042                                           // 000000031638: D7600042
	v_cndmask_b32_e32 v0, v140, v131, vcc_lo                   // 00000003163C: 0201078C
	.long 0xd7600041                                           // 000000031640: D7600041
	v_cndmask_b32_e32 v0, v140, v132, vcc_lo                   // 000000031644: 0201098C
	.long 0xd7600040                                           // 000000031648: D7600040
	v_cndmask_b32_e32 v0, v140, v133, vcc_lo                   // 00000003164C: 02010B8C
	.long 0xd760003f                                           // 000000031650: D760003F
	v_cndmask_b32_e32 v0, v140, v134, vcc_lo                   // 000000031654: 02010D8C
	.long 0xd760003e                                           // 000000031658: D760003E
	v_cndmask_b32_e32 v0, v140, v135, vcc_lo                   // 00000003165C: 02010F8C
	.long 0xd760003d                                           // 000000031660: D760003D
	v_cndmask_b32_e32 v0, v140, v136, vcc_lo                   // 000000031664: 0201118C
	.long 0xd760003c                                           // 000000031668: D760003C
	v_cndmask_b32_e32 v0, v140, v137, vcc_lo                   // 00000003166C: 0201138C
	.long 0xd760003b                                           // 000000031670: D760003B
	v_cndmask_b32_e32 v0, v140, v138, vcc_lo                   // 000000031674: 0201158C
	.long 0xd760003a                                           // 000000031678: D760003A
	v_cndmask_b32_e32 v0, v140, v139, vcc_lo                   // 00000003167C: 0201178C
	.long 0xd7600039                                           // 000000031680: D7600039
	v_cndmask_b32_e32 v0, v140, v140, vcc_lo                   // 000000031684: 0201198C
	.long 0xd7600038                                           // 000000031688: D7600038
	v_cndmask_b32_e32 v0, v140, v141, vcc_lo                   // 00000003168C: 02011B8C
	.long 0xd7600037                                           // 000000031690: D7600037
	v_cndmask_b32_e32 v0, v140, v142, vcc_lo                   // 000000031694: 02011D8C
	.long 0xd7600036                                           // 000000031698: D7600036
	v_cndmask_b32_e32 v0, v140, v143, vcc_lo                   // 00000003169C: 02011F8C
	s_mov_b32 s4, exec_lo                                      // 0000000316A0: BE84007E
	v_cmpx_gt_u32_e32 16, v43                                  // 0000000316A4: 7D985690
	s_cbranch_execz 83                                         // 0000000316A8: BFA50053 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10f8>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 0000000316AC: 7C945680
	s_add_f32 s69, s69, 0                                      // 0000000316B0: A0458045
	v_lshlrev_b32_e32 v4, 2, v43                               // 0000000316B4: 30085682
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000316B8: BF8704BA
	s_add_f32 s68, s69, s68                                    // 0000000316BC: A0444445
	v_cndmask_b32_e64 v3, 0, s69, vcc_lo                       // 0000000316C0: D5010003 01A88A80
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 0000000316C8: 7C945681
	s_add_f32 s67, s68, s67                                    // 0000000316CC: A0434344
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000316D0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s68, vcc_lo                      // 0000000316D4: D5010003 01A88903
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 0000000316DC: 7C945682
	s_add_f32 s66, s67, s66                                    // 0000000316E0: A0424243
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000316E4: BF8704A2
	v_cndmask_b32_e64 v3, v3, s67, vcc_lo                      // 0000000316E8: D5010003 01A88703
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 0000000316F0: 7C945683
	s_add_f32 s65, s66, s65                                    // 0000000316F4: A0414142
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000316F8: BF8704A2
	v_cndmask_b32_e64 v3, v3, s66, vcc_lo                      // 0000000316FC: D5010003 01A88503
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 000000031704: 7C945684
	s_add_f32 s64, s65, s64                                    // 000000031708: A0404041
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003170C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s65, vcc_lo                      // 000000031710: D5010003 01A88303
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 000000031718: 7C945685
	s_add_f32 s63, s64, s63                                    // 00000003171C: A03F3F40
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000031720: BF8704A2
	v_cndmask_b32_e64 v3, v3, s64, vcc_lo                      // 000000031724: D5010003 01A88103
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 00000003172C: 7C945686
	s_add_f32 s62, s63, s62                                    // 000000031730: A03E3E3F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000031734: BF8704A2
	v_cndmask_b32_e64 v3, v3, s63, vcc_lo                      // 000000031738: D5010003 01A87F03
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 000000031740: 7C945687
	s_add_f32 s61, s62, s61                                    // 000000031744: A03D3D3E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000031748: BF8704A2
	v_cndmask_b32_e64 v3, v3, s62, vcc_lo                      // 00000003174C: D5010003 01A87D03
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 000000031754: 7C945688
	s_add_f32 s60, s61, s60                                    // 000000031758: A03C3C3D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003175C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s61, vcc_lo                      // 000000031760: D5010003 01A87B03
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 000000031768: 7C945689
	s_add_f32 s59, s60, s59                                    // 00000003176C: A03B3B3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000031770: BF8704A2
	v_cndmask_b32_e64 v3, v3, s60, vcc_lo                      // 000000031774: D5010003 01A87903
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000003177C: 7C94568A
	s_add_f32 s58, s59, s58                                    // 000000031780: A03A3A3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000031784: BF8704A2
	v_cndmask_b32_e64 v3, v3, s59, vcc_lo                      // 000000031788: D5010003 01A87703
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 000000031790: 7C94568B
	s_add_f32 s57, s58, s57                                    // 000000031794: A039393A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000031798: BF8704A2
	v_cndmask_b32_e64 v3, v3, s58, vcc_lo                      // 00000003179C: D5010003 01A87503
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 0000000317A4: 7C94568C
	s_add_f32 s56, s57, s56                                    // 0000000317A8: A0383839
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000317AC: BF8704A2
	v_cndmask_b32_e64 v3, v3, s57, vcc_lo                      // 0000000317B0: D5010003 01A87303
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 0000000317B8: 7C94568D
	s_add_f32 s55, s56, s55                                    // 0000000317BC: A0373738
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000317C0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s56, vcc_lo                      // 0000000317C4: D5010003 01A87103
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 0000000317CC: 7C94568E
	s_add_f32 s54, s55, s54                                    // 0000000317D0: A0363637
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000317D4: BF870002
	v_cndmask_b32_e64 v3, v3, s55, vcc_lo                      // 0000000317D8: D5010003 01A86F03
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 0000000317E0: 7C94568F
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000000317E4: BF870482
	v_cndmask_b32_e64 v3, v3, s54, vcc_lo                      // 0000000317E8: D5010003 01A86D03
	ds_store_b32 v4, v3 offset:24128                           // 0000000317F0: D8345E40 00000304
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000317F8: 8C7E047E
	s_add_i32 s53, s53, 1                                      // 0000000317FC: 81358135
	s_waitcnt lgkmcnt(0)                                       // 000000031800: BF89FC07
	s_barrier                                                  // 000000031804: BFBD0000
	s_cmp_ge_i32 s53, s15                                      // 000000031808: BF030F35
	s_cbranch_scc1 68                                          // 00000003180C: BFA20044 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1220>
	s_lshl_b32 s4, s53, 4                                      // 000000031810: 84048435
	v_lshlrev_b32_e32 v4, 4, v44                               // 000000031814: 30085884
	s_waitcnt lgkmcnt(1)                                       // 000000031818: BF89FC17
	v_add_nc_u32_e32 v6, s4, v2                                // 00000003181C: 4A0C0404
	s_mov_b32 s54, exec_lo                                     // 000000031820: BEB6007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000031824: BF870112
	v_and_b32_e32 v4, 0xf0, v4                                 // 000000031828: 360808FF 000000F0
	v_min_i32_e32 v2, s40, v6                                  // 000000031830: 22040C28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031834: BF870091
	v_mad_i64_i32 v[2:3], null, 0x5000, v2, s[30:31]           // 000000031838: D6FF7C02 007A04FF 00005000
	.long 0xd7006a02                                           // 000000031844: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000031848: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003184C: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000031850: D5207C03 01AA0680
	.long 0xd7006a04                                           // 000000031858: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000003185C: 020204FF 00001000
	s_waitcnt lgkmcnt(0)                                       // 000000031864: BF89FC07
	s_delay_alu instid0(VALU_DEP_2)                            // 000000031868: BF870002
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 00000003186C: D5207C05 01AA0680
	s_clause 0x1                                               // 000000031874: BF850001
	global_load_b128 v[74:77], v[2:3], off                     // 000000031878: DC5E0000 4A7C0002
	global_load_b128 v[78:81], v[4:5], off                     // 000000031880: DC5E0000 4E7C0004
	.long 0xd4c3007e                                           // 000000031888: D4C3007E
	v_cndmask_b32_e32 v1, s39, v6, vcc_lo                      // 00000003188C: 02020C27
	s_cbranch_execz 11                                         // 000000031890: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11c0>
	s_waitcnt vmcnt(1)                                         // 000000031894: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 000000031898: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003189C: BF870001
	v_mov_b32_e32 v75, v76                                     // 0000000318A0: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 0000000318A4: 7E94034C
	s_waitcnt vmcnt(0)                                         // 0000000318A8: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 0000000318AC: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 0000000318B0: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 0000000318B4: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 0000000318B8: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 0000000318BC: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s54                             // 0000000318C0: 8C7E367E
	s_and_saveexec_b32 s54, s3                                 // 0000000318C4: BEB62003
	s_cbranch_execz 19                                         // 0000000318C8: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1218>
	v_dual_mov_b32 v141, 0 :: v_dual_add_nc_u32 v2, s4, v44    // 0000000318CC: CA200080 8D025804
	v_mov_b32_e32 v140, 0                                      // 0000000318D4: 7F180280
	s_mov_b32 s3, exec_lo                                      // 0000000318D8: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000318DC: BF870002
	.long 0xd4c4007e                                           // 0000000318E0: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 0000000318E4: 02020427
	s_cbranch_execz 10                                         // 0000000318E8: BFA5000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1214>
	v_mad_i64_i32 v[3:4], null, 0xc0, v2, s[10:11]             // 0000000318EC: D6FF7C03 002A04FF 000000C0
	v_mad_i64_i32 v[5:6], null, 0xc0, v2, s[34:35]             // 0000000318F8: D6FF7C05 008A04FF 000000C0
	global_load_b32 v140, v[3:4], off                          // 000000031904: DC520000 8C7C0003
	global_load_b32 v141, v[5:6], off                          // 00000003190C: DC520000 8D7C0005
	s_or_b32 exec_lo, exec_lo, s3                              // 000000031914: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000031918: BF870009
	s_or_b32 exec_lo, exec_lo, s54                             // 00000003191C: 8C7E367E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000031920: BF870009
	s_and_b32 vcc_lo, exec_lo, s42                             // 000000031924: 8B6A2A7E
	s_mov_b32 s3, -1                                           // 000000031928: BE8300C1
	s_cbranch_vccz 80                                          // 00000003192C: BFA30050 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1370>
	v_and_b32_e32 v2, -16, v44                                 // 000000031930: 360458D0
	s_mov_b32 s3, exec_lo                                      // 000000031934: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000031938: BF870001
	v_cmpx_eq_u32_e32 64, v2                                   // 00000003193C: 7D9404C0
	s_cbranch_execz 73                                         // 000000031940: BFA50049 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1368>
	v_lshlrev_b32_e32 v4, 2, v44                               // 000000031944: 30085882
	s_waitcnt lgkmcnt(0)                                       // 000000031948: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003194C: BF870001
	v_add_nc_u32_e32 v5, 0x5c00, v4                            // 000000031950: 4A0A08FF 00005C00
	ds_load_2addr_b32 v[2:3], v5 offset0:64 offset1:80         // 000000031958: D8DC5040 02000005
	ds_load_b32 v6, v1 offset:24188                            // 000000031960: D8D85E7C 06000001
	s_waitcnt lgkmcnt(1)                                       // 000000031968: BF89FC17
	v_mul_f32_e32 v7, 0x3fb8aa3b, v3                           // 00000003196C: 100E06FF 3FB8AA3B
	ds_load_b32 v8, v4 offset:24128                            // 000000031974: D8D85E40 08000004
	s_waitcnt lgkmcnt(1)                                       // 00000003197C: BF89FC17
	v_sub_f32_e32 v6, v6, v3                                   // 000000031980: 080C0706
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000031984: 7C3606FF C2CE8ED0
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v7                          // 00000003198C: D6130009 841E06FF 3FB8AA3B
	v_rndne_f32_e32 v10, v7                                    // 000000031998: 7E144707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003199C: BF870114
	v_mul_f32_e32 v11, 0x3fb8aa3b, v6                          // 0000000319A0: 10160CFF 3FB8AA3B
	v_sub_f32_e32 v7, v7, v10                                  // 0000000319A8: 080E1507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000319AC: BF8701C2
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v11                        // 0000000319B0: D613000C 842E0CFF 3FB8AA3B
	v_fmac_f32_e32 v9, 0x32a5705f, v3                          // 0000000319BC: 561206FF 32A5705F
	v_cvt_i32_f32_e32 v10, v10                                 // 0000000319C4: 7E14110A
	v_rndne_f32_e32 v13, v11                                   // 0000000319C8: 7E1A470B
	v_dual_fmac_f32 v12, 0x32a5705f, v6 :: v_dual_add_f32 v7, v7, v9// 0000000319CC: C8080CFF 0C061307 32A5705F
	s_waitcnt lgkmcnt(0)                                       // 0000000319D8: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000319DC: BF870112
	v_dual_sub_f32 v9, v11, v13 :: v_dual_mul_f32 v2, v8, v2   // 0000000319E0: C9461B0B 09020508
	v_exp_f32_e32 v7, v7                                       // 0000000319E8: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000319EC: BF870125
	.long 0xd71c0007                                           // 0000000319F0: D71C0007
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 0000000319F4: 02021507
	v_cvt_i32_f32_e32 v10, v13                                 // 0000000319F8: 7E14110D
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 0000000319FC: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000031A00: 7C3C06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000031A08: BF8701B2
	v_cndmask_b32_e32 v3, 0x7f800000, v7, vcc_lo               // 000000031A0C: 02060EFF 7F800000
	v_add_f32_e32 v9, v9, v12                                  // 000000031A14: 06121909
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 000000031A18: 7C360CFF C2CE8ED0
	v_mul_f32_e32 v2, v3, v2                                   // 000000031A20: 10040503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031A24: BF870093
	v_exp_f32_e32 v9, v9                                       // 000000031A28: 7E124B09
	v_mul_f32_e32 v2, 0x41800000, v2                           // 000000031A2C: 100404FF 41800000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031A34: BF870095
	.long 0xd71c0009                                           // 000000031A38: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000031A3C: 02021509
	v_cndmask_b32_e32 v7, 0, v9, vcc_lo                        // 000000031A40: 020E1280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 000000031A44: 7C3C0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000031A4C: BF870002
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 000000031A50: 020C0EFF 7F800000
	ds_store_b32 v4, v3 offset:24064                           // 000000031A58: D8345E00 00000304
	ds_store_2addr_b32 v5, v6, v2 offset0:96 offset1:112       // 000000031A60: D8387060 00020605
	s_or_b32 exec_lo, exec_lo, s3                              // 000000031A68: 8C7E037E
	s_mov_b32 s3, 0                                            // 000000031A6C: BE830080
	v_lshrrev_b32_e32 v149, 4, v43                             // 000000031A70: 332A5684
	v_mul_u32_u24_e32 v57, 0x110, v55                          // 000000031A74: 16726EFF 00000110
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 000000031A7C: 916A037E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000031A80: BF870002
	v_lshlrev_b32_e32 v56, 2, v149                             // 000000031A84: 30712A82
	s_cbranch_vccnz 871                                        // 000000031A88: BFA40367 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2128>
	v_mad_u32_u24 v2, 0x110, v55, s49                          // 000000031A8C: D60B0002 00C66EFF 00000110
	s_and_b32 s3, s2, exec_lo                                  // 000000031A98: 8B037E02
	s_cselect_b32 s3, 0, 0x1100                                // 000000031A9C: 9803FF80 00001100
	v_mad_u32_u24 v3, 0x110, v55, s50                          // 000000031AA4: D60B0003 00CA6EFF 00000110
	ds_load_b128 v[10:13], v57 offset:6144                     // 000000031AB0: DBFC1800 0A000039
	ds_load_b128 v[14:17], v57 offset:6160                     // 000000031AB8: DBFC1810 0E000039
	v_add_nc_u32_e32 v4, s3, v2                                // 000000031AC0: 4A080403
	v_mov_b32_e32 v8, v1                                       // 000000031AC4: 7E100301
	s_waitcnt lgkmcnt(2)                                       // 000000031AC8: BF89FC27
	v_mov_b32_e32 v5, v1                                       // 000000031ACC: 7E0A0301
	v_cndmask_b32_e64 v45, v3, v2, s2                          // 000000031AD0: D501002D 000A0503
	v_mov_b32_e32 v3, v1                                       // 000000031AD8: 7E060301
	ds_load_b128 v[18:21], v4                                  // 000000031ADC: DBFC0000 12000004
	ds_load_b128 v[22:25], v4 offset:16                        // 000000031AE4: DBFC0010 16000004
	ds_load_b128 v[26:29], v57 offset:6176                     // 000000031AEC: DBFC1820 1A000039
	ds_load_b128 v[30:33], v57 offset:6192                     // 000000031AF4: DBFC1830 1E000039
	ds_load_b128 v[59:62], v45 offset:32                       // 000000031AFC: DBFC0020 3B00002D
	ds_load_b128 v[63:66], v45 offset:48                       // 000000031B04: DBFC0030 3F00002D
	ds_load_b128 v[150:153], v45 offset:64                     // 000000031B0C: DBFC0040 9600002D
	ds_load_b128 v[154:157], v45 offset:80                     // 000000031B14: DBFC0050 9A00002D
	ds_load_b128 v[162:165], v57 offset:6224                   // 000000031B1C: DBFC1850 A2000039
	ds_load_b128 v[158:161], v57 offset:6208                   // 000000031B24: DBFC1840 9E000039
	v_mov_b32_e32 v2, v1                                       // 000000031B2C: 7E040301
	v_mov_b32_e32 v4, v1                                       // 000000031B30: 7E080301
	v_mov_b32_e32 v6, v1                                       // 000000031B34: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000031B38: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 000000031B3C: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000031B40: BF870212
	v_mov_b32_e32 v8, v7                                       // 000000031B44: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000031B48: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 000000031B4C: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000031B50: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000031B54: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000031B58: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000031B5C: 7E040301
	ds_load_b128 v[170:173], v57 offset:6256                   // 000000031B60: DBFC1870 AA000039
	ds_load_b128 v[166:169], v57 offset:6240                   // 000000031B68: DBFC1860 A6000039
	ds_load_b128 v[178:181], v45 offset:112                    // 000000031B70: DBFC0070 B200002D
	ds_load_b128 v[174:177], v45 offset:96                     // 000000031B78: DBFC0060 AE00002D
	v_or_b32_e32 v49, 6, v149                                  // 000000031B80: 38632A86
	v_or_b32_e32 v48, 8, v149                                  // 000000031B84: 38612A88
	v_or_b32_e32 v47, 10, v149                                 // 000000031B88: 385F2A8A
	s_waitcnt lgkmcnt(12)                                      // 000000031B8C: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 000000031B90: CC414002 1C0A1512
	ds_load_b128 v[14:17], v57 offset:6288                     // 000000031B98: DBFC1890 0E000039
	ds_load_b128 v[10:13], v57 offset:6272                     // 000000031BA0: DBFC1880 0A000039
	ds_load_b128 v[22:25], v45 offset:144                      // 000000031BA8: DBFC0090 1600002D
	ds_load_b128 v[18:21], v45 offset:128                      // 000000031BB0: DBFC0080 1200002D
	s_and_not1_b32 vcc_lo, exec_lo, s41                        // 000000031BB8: 916A297E
	s_mov_b32 s3, -1                                           // 000000031BBC: BE8300C1
	s_waitcnt lgkmcnt(12)                                      // 000000031BC0: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[59:66], v[26:33], v[2:9]// 000000031BC4: CC414002 1C0A353B
	ds_load_b128 v[30:33], v57 offset:6320                     // 000000031BCC: DBFC18B0 1E000039
	ds_load_b128 v[26:29], v57 offset:6304                     // 000000031BD4: DBFC18A0 1A000039
	ds_load_b128 v[65:68], v45 offset:176                      // 000000031BDC: DBFC00B0 4100002D
	ds_load_b128 v[61:64], v45 offset:160                      // 000000031BE4: DBFC00A0 3D00002D
	v_lshlrev_b32_e32 v60, 2, v55                              // 000000031BEC: 30786E82
	v_or_b32_e32 v59, 4, v149                                  // 000000031BF0: 38772A84
	s_waitcnt lgkmcnt(12)                                      // 000000031BF4: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[150:157], v[158:165], v[2:9]// 000000031BF8: CC414002 1C0B3D96
	ds_load_b128 v[154:157], v57 offset:6352                   // 000000031C00: DBFC18D0 9A000039
	ds_load_b128 v[150:153], v57 offset:6336                   // 000000031C08: DBFC18C0 96000039
	v_add_nc_u32_e32 v46, 64, v60                              // 000000031C10: 4A5C78C0
	ds_load_b128 v[162:165], v57 offset:6384                   // 000000031C14: DBFC18F0 A2000039
	ds_load_b128 v[158:161], v57 offset:6368                   // 000000031C1C: DBFC18E0 9E000039
	s_waitcnt lgkmcnt(12)                                      // 000000031C24: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[174:181], v[166:173], v[2:9]// 000000031C28: CC414002 1C0B4DAE
	ds_load_b128 v[170:173], v45 offset:208                    // 000000031C30: DBFC00D0 AA00002D
	ds_load_b128 v[166:169], v45 offset:192                    // 000000031C38: DBFC00C0 A600002D
	s_waitcnt lgkmcnt(10)                                      // 000000031C40: BF89FCA7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 000000031C44: CC414002 1C0A1512
	v_add_nc_u32_e32 v10, 0x5c00, v56                          // 000000031C4C: 4A1470FF 00005C00
	v_add_nc_u32_e32 v11, s43, v56                             // 000000031C54: 4A16702B
	ds_load_b128 v[178:181], v45 offset:240                    // 000000031C58: DBFC00F0 B200002D
	ds_load_b128 v[174:177], v45 offset:224                    // 000000031C60: DBFC00E0 AE00002D
	ds_load_2addr_stride64_b32 v[12:13], v46 offset0:94 offset1:95// 000000031C68: D8E05F5E 0C00002E
	v_or_b32_e32 v46, 12, v149                                 // 000000031C70: 385D2A8C
	s_waitcnt lgkmcnt(9)                                       // 000000031C74: BF89FC97
	v_wmma_f32_16x16x16_bf16 v[2:9], v[61:68], v[26:33], v[2:9]// 000000031C78: CC414002 1C0A353D
	ds_load_2addr_b32 v[28:29], v10 offset0:144 offset1:146    // 000000031C80: D8DC9290 1C00000A
	ds_load_2addr_b32 v[24:25], v10 offset0:148 offset1:150    // 000000031C88: D8DC9694 1800000A
	ds_load_2addr_b32 v[20:21], v10 offset0:152 offset1:154    // 000000031C90: D8DC9A98 1400000A
	ds_load_2addr_b32 v[16:17], v10 offset0:156 offset1:158    // 000000031C98: D8DC9E9C 1000000A
	ds_load_2addr_b32 v[26:27], v11 offset1:2                  // 000000031CA0: D8DC0200 1A00000B
	ds_load_2addr_b32 v[22:23], v11 offset0:4 offset1:6        // 000000031CA8: D8DC0604 1600000B
	ds_load_2addr_b32 v[18:19], v11 offset0:8 offset1:10       // 000000031CB0: D8DC0A08 1200000B
	ds_load_2addr_b32 v[14:15], v11 offset0:12 offset1:14      // 000000031CB8: D8DC0E0C 0E00000B
	v_or_b32_e32 v61, 2, v149                                  // 000000031CC0: 387B2A82
	v_or_b32_e32 v45, 14, v149                                 // 000000031CC4: 385B2A8E
	s_waitcnt lgkmcnt(11)                                      // 000000031CC8: BF89FCB7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[166:173], v[150:157], v[2:9]// 000000031CCC: CC414002 1C0B2DA6
	s_waitcnt lgkmcnt(9)                                       // 000000031CD4: BF89FC97
	s_delay_alu instid0(VALU_DEP_1)                            // 000000031CD8: BF870001
	v_wmma_f32_16x16x16_bf16 v[2:9], v[174:181], v[158:165], v[2:9]// 000000031CDC: CC414002 1C0B3DAE
	s_cbranch_vccnz 353                                        // 000000031CE4: BFA40161 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b6c>
	.long 0x7e143880                                           // 000000031CE8: 7E143880
	s_mov_b32 s3, exec_lo                                      // 000000031CEC: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000031CF0: BF870001
	.long 0x7f14390a                                           // 000000031CF4: 7F14390A
	.long 0xd4cb007e                                           // 000000031CF8: D4CB007E
	v_cndmask_b32_e32 v1, v55, v149, vcc_lo                    // 000000031CFC: 02032B37
	s_cbranch_execz 34                                         // 000000031D00: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x168c>
	s_waitcnt lgkmcnt(7)                                       // 000000031D04: BF89FC77
	v_sub_f32_e32 v11, v28, v12                                // 000000031D08: 0816191C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031D0C: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v11                         // 000000031D10: 103C16FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v11, -v30                       // 000000031D18: D613001F 847A16FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 000000031D24: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031D28: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v11 :: v_dual_sub_f32 v30, v30, v32// 000000031D2C: C80A16FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 000000031D38: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 000000031D3C: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000031D40: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000031D48: BF870293
	v_exp_f32_e32 v30, v30                                     // 000000031D4C: 7E3C4B1E
	.long 0xd71c001e                                           // 000000031D50: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 000000031D54: 02023F1E
	s_waitcnt lgkmcnt(3)                                       // 000000031D58: BF89FC37
	v_mul_f32_e32 v31, v2, v26                                 // 000000031D5C: 103E3502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000031D60: BF870122
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 000000031D64: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000031D68: 7C3C16FF 42B17218
	v_dual_cndmask_b32 v11, 0x7f800000, v30 :: v_dual_mul_f32 v30, v13, v31// 000000031D70: CA463CFF 0B1E3F0D 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031D7C: BF870091
	v_mul_f32_e32 v11, v11, v30                                // 000000031D80: 10163D0B
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 000000031D84: CC22000A 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000031D8C: 8C7E037E
	v_mul_u32_u24_e32 v11, 48, v149                            // 000000031D90: 16172AB0
	s_mov_b32 s3, exec_lo                                      // 000000031D94: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000031D98: BF870001
	v_lshl_add_u32 v11, v55, 1, v11                            // 000000031D9C: D646000B 042D0337
	ds_store_b16_d16_hi v11, v10 offset:23296                  // 000000031DA4: DA845B00 00000A0B
	.long 0xd4cb007e                                           // 000000031DAC: D4CB007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 000000031DB0: 02027B37
	s_cbranch_execz 34                                         // 000000031DB4: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1740>
	s_waitcnt lgkmcnt(8)                                       // 000000031DB8: BF89FC87
	v_sub_f32_e32 v10, v29, v12                                // 000000031DBC: 0814191D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031DC0: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v10                         // 000000031DC4: 103C14FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v30                       // 000000031DCC: D613001F 847A14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 000000031DD8: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031DDC: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v10 :: v_dual_sub_f32 v30, v30, v32// 000000031DE0: C80A14FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 000000031DEC: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 000000031DF0: 7E3E1120
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000031DF4: BF870292
	v_exp_f32_e32 v30, v30                                     // 000000031DF8: 7E3C4B1E
	.long 0xd71c001e                                           // 000000031DFC: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 000000031E00: 02023F1E
	s_waitcnt lgkmcnt(4)                                       // 000000031E04: BF89FC47
	v_mul_f32_e32 v31, v3, v27                                 // 000000031E08: 103E3703
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000031E0C: 7C3614FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000031E14: BF870123
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 000000031E18: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000031E1C: 7C3C14FF 42B17218
	v_cndmask_b32_e32 v10, 0x7f800000, v30, vcc_lo             // 000000031E24: 02143CFF 7F800000
	v_mul_f32_e32 v30, v13, v31                                // 000000031E2C: 103C3F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031E30: BF870091
	v_mul_f32_e32 v10, v10, v30                                // 000000031E34: 10143D0A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 000000031E38: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000031E40: 8C7E037E
	.long 0x7f143880                                           // 000000031E44: 7F143880
	v_or_b32_e32 v30, 0x5b00, v11                              // 000000031E48: 383C16FF 00005B00
	s_mov_b32 s3, exec_lo                                      // 000000031E50: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000031E54: BF870002
	.long 0x7e16398a                                           // 000000031E58: 7E16398A
	ds_store_b16 v30, v10 offset:96                            // 000000031E5C: D87C0060 00000A1E
	.long 0xd4cb007e                                           // 000000031E64: D4CB007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 000000031E68: 02027737
	s_cbranch_execz 35                                         // 000000031E6C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x17fc>
	s_waitcnt lgkmcnt(8)                                       // 000000031E70: BF89FC87
	v_sub_f32_e32 v11, v24, v12                                // 000000031E74: 08161918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000031E78: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000031E7C: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000031E84: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000031E8C: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 000000031E98: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031E9C: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000031EA0: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000031EAC: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000031EB0: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000031EB4: BF870292
	v_exp_f32_e32 v31, v31                                     // 000000031EB8: 7E3E4B1F
	.long 0xd71c001f                                           // 000000031EBC: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000031EC0: 0202411F
	s_waitcnt lgkmcnt(4)                                       // 000000031EC4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000031EC8: BF870121
	v_dual_mul_f32 v32, v4, v22 :: v_dual_cndmask_b32 v31, 0, v31// 000000031ECC: C8D22D04 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000031ED4: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000031EDC: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031EE4: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 000000031EE8: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 000000031EEC: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000031EF0: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 000000031EF4: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000031EFC: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000031F00: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000031F04: BE83007E
	ds_store_b16 v30, v11 offset:192                           // 000000031F08: D87C00C0 00000B1E
	.long 0xd4cb007e                                           // 000000031F10: D4CB007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 000000031F14: 02026337
	s_cbranch_execz 35                                         // 000000031F18: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x18a8>
	s_waitcnt lgkmcnt(9)                                       // 000000031F1C: BF89FC97
	v_sub_f32_e32 v10, v25, v12                                // 000000031F20: 08141919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031F24: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000031F28: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000031F30: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000031F3C: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000031F40: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000031F44: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000031F4C: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000031F50: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000031F54: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 000000031F58: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000031F5C: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000031F64: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000031F68: BF870135
	.long 0xd71c000b                                           // 000000031F6C: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000031F70: 02023F0B
	s_waitcnt lgkmcnt(5)                                       // 000000031F74: BF89FC57
	v_mul_f32_e32 v31, v5, v23                                 // 000000031F78: 103E2F05
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000031F7C: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000031F80: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000031F88: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000031F8C: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000031F94: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031F98: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000031F9C: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 000000031FA0: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000031FA8: 8C7E037E
	.long 0x7e143880                                           // 000000031FAC: 7E143880
	s_mov_b32 s3, exec_lo                                      // 000000031FB0: BE83007E
	ds_store_b16_d16_hi v30, v10 offset:288                    // 000000031FB4: DA840120 00000A1E
	.long 0x7e16390a                                           // 000000031FBC: 7E16390A
	.long 0xd4cb007e                                           // 000000031FC0: D4CB007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 000000031FC4: 02026137
	s_cbranch_execz 34                                         // 000000031FC8: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1954>
	s_waitcnt lgkmcnt(9)                                       // 000000031FCC: BF89FC97
	v_sub_f32_e32 v11, v20, v12                                // 000000031FD0: 08161914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031FD4: BF870091
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000031FD8: 103E16FF 3FB8AA3B
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000031FE0: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 000000031FEC: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000031FF0: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000031FF4: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000032000: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000032004: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000032008: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000003200C: 7E3E4B1F
	.long 0xd71c001f                                           // 000000032010: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000032014: 0202411F
	s_waitcnt lgkmcnt(5)                                       // 000000032018: BF89FC57
	v_mul_f32_e32 v32, v6, v18                                 // 00000003201C: 10402506
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000032020: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000032028: BF870123
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 00000003202C: 023E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000032030: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000032038: 02163EFF 7F800000
	v_mul_f32_e32 v31, v13, v32                                // 000000032040: 103E410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032044: BF870091
	v_mul_f32_e32 v11, v11, v31                                // 000000032048: 10163F0B
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000003204C: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000032054: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000032058: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000003205C: BE83007E
	ds_store_b16 v30, v11 offset:384                           // 000000032060: D87C0180 00000B1E
	.long 0xd4cb007e                                           // 000000032068: D4CB007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 00000003206C: 02025F37
	s_cbranch_execz 35                                         // 000000032070: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1a00>
	s_waitcnt lgkmcnt(10)                                      // 000000032074: BF89FCA7
	v_sub_f32_e32 v10, v21, v12                                // 000000032078: 08141915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003207C: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000032080: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000032088: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000032094: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000032098: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000003209C: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 0000000320A4: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000320A8: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 0000000320AC: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 0000000320B0: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 0000000320B4: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 0000000320BC: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000320C0: BF870135
	.long 0xd71c000b                                           // 0000000320C4: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 0000000320C8: 02023F0B
	s_waitcnt lgkmcnt(6)                                       // 0000000320CC: BF89FC67
	v_mul_f32_e32 v31, v7, v19                                 // 0000000320D0: 103E2707
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 0000000320D4: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 0000000320D8: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000320E0: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 0000000320E4: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 0000000320EC: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000320F0: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 0000000320F4: 1014170A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 0000000320F8: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000032100: 8C7E037E
	.long 0x7f143880                                           // 000000032104: 7F143880
	s_mov_b32 s3, exec_lo                                      // 000000032108: BE83007E
	ds_store_b16 v30, v10 offset:480                           // 00000003210C: D87C01E0 00000A1E
	.long 0x7e16398a                                           // 000000032114: 7E16398A
	.long 0xd4cb007e                                           // 000000032118: D4CB007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 00000003211C: 02025D37
	s_cbranch_execz 35                                         // 000000032120: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1ab0>
	s_waitcnt lgkmcnt(10)                                      // 000000032124: BF89FCA7
	v_sub_f32_e32 v11, v16, v12                                // 000000032128: 08161910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003212C: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000032130: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000032138: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000032140: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000003214C: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032150: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000032154: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000032160: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000032164: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000032168: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000003216C: 7E3E4B1F
	.long 0xd71c001f                                           // 000000032170: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000032174: 0202411F
	s_waitcnt lgkmcnt(6)                                       // 000000032178: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003217C: BF870121
	v_dual_mul_f32 v32, v8, v14 :: v_dual_cndmask_b32 v31, 0, v31// 000000032180: C8D21D08 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000032188: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000032190: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032198: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 00000003219C: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 0000000321A0: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000321A4: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 0000000321A8: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000321B0: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000321B4: BF870009
	s_mov_b32 s3, exec_lo                                      // 0000000321B8: BE83007E
	ds_store_b16 v30, v11 offset:576                           // 0000000321BC: D87C0240 00000B1E
	.long 0xd4cb007e                                           // 0000000321C4: D4CB007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 0000000321C8: 02025B37
	s_cbranch_execz 35                                         // 0000000321CC: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b5c>
	s_waitcnt lgkmcnt(11)                                      // 0000000321D0: BF89FCB7
	v_sub_f32_e32 v10, v17, v12                                // 0000000321D4: 08141911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000321D8: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 0000000321DC: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 0000000321E4: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 0000000321F0: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000321F4: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 0000000321F8: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000032200: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000032204: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000032208: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000003220C: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000032210: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000032218: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000003221C: BF870135
	.long 0xd71c000b                                           // 000000032220: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000032224: 02023F0B
	s_waitcnt lgkmcnt(7)                                       // 000000032228: BF89FC77
	v_mul_f32_e32 v31, v9, v15                                 // 00000003222C: 103E1F09
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000032230: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000032234: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003223C: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000032240: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000032248: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003224C: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000032250: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 000000032254: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003225C: 8C7E037E
	s_mov_b32 s3, 0                                            // 000000032260: BE830080
	ds_store_b16_d16_hi v30, v10 offset:672                    // 000000032264: DA8402A0 00000A1E
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000003226C: 8B6A037E
	s_cbranch_vccz 365                                         // 000000032270: BFA3016D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2128>
	v_or_b32_e32 v10, 0x5e40, v56                              // 000000032274: 381470FF 00005E40
	v_mov_b32_e32 v63, 0                                       // 00000003227C: 7E7E0280
	v_mov_b32_e32 v65, 0                                       // 000000032280: 7E820280
	s_mov_b32 s3, exec_lo                                      // 000000032284: BE83007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000032288: BF870003
	v_subrev_nc_u32_e32 v64, 64, v10                           // 00000003228C: 4E8014C0
	ds_load_2addr_b32 v[32:33], v64 offset0:2 offset1:4        // 000000032290: D8DC0402 20000040
	ds_load_2addr_b32 v[30:31], v64 offset0:6 offset1:8        // 000000032298: D8DC0806 1E000040
	ds_load_2addr_b32 v[10:11], v64 offset0:10 offset1:12      // 0000000322A0: D8DC0C0A 0A000040
	ds_load_b32 v62, v64 offset:56                             // 0000000322A8: D8D80038 3E000040
	.long 0xd4c9007e                                           // 0000000322B0: D4C9007E
	v_cndmask_b32_e32 v1, v55, v149, vcc_lo                    // 0000000322B4: 02032B37
	s_cbranch_execz 37                                         // 0000000322B8: BFA50025 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1c50>
	s_waitcnt lgkmcnt(11)                                      // 0000000322BC: BF89FCB7
	v_sub_f32_e32 v28, v28, v12                                // 0000000322C0: 0838191C
	ds_load_b32 v64, v64                                       // 0000000322C4: D8D80000 40000040
	s_waitcnt lgkmcnt(8)                                       // 0000000322CC: BF89FC87
	v_dual_mul_f32 v2, v2, v26 :: v_dual_mul_f32 v65, 0x3fb8aa3b, v28// 0000000322D0: C8C63502 024038FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000322DC: BF870111
	v_mul_f32_e32 v2, v13, v2                                  // 0000000322E0: 1004050D
	v_fma_f32 v66, 0x3fb8aa3b, v28, -v65                       // 0000000322E4: D6130042 850638FF 3FB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 0000000322F0: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000322F4: BF8701C1
	v_dual_sub_f32 v65, v65, v67 :: v_dual_fmac_f32 v66, 0x32a5705f, v28// 0000000322F8: C9408741 414238FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v28                  // 000000032304: 7C3638FF C2CE8ED0
	s_waitcnt lgkmcnt(0)                                       // 00000003230C: BF89FC07
	v_mul_f32_e32 v2, v64, v2                                  // 000000032310: 10040540
	v_add_f32_e32 v65, v65, v66                                // 000000032314: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000032318: 7E841143
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003231C: BF870292
	v_exp_f32_e32 v65, v65                                     // 000000032320: 7E824B41
	.long 0xd71c0041                                           // 000000032324: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000032328: 02028541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003232C: BF870121
	v_cndmask_b32_e32 v26, 0, v65, vcc_lo                      // 000000032330: 02348280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v28                  // 000000032334: 7C3C38FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 00000003233C: 023434FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000032344: BF870001
	.long 0xd5080041                                           // 000000032348: D5080041
	v_sub_co_ci_u32_e32 v1, vcc_lo, v2, v26, vcc_lo            // 00000003234C: 42023502
	s_or_b32 exec_lo, exec_lo, s3                              // 000000032350: 8C7E037E
	v_or_b32_e32 v2, 0x5e40, v60                               // 000000032354: 380478FF 00005E40
	s_waitcnt lgkmcnt(7)                                       // 00000003235C: BF89FC77
	v_lshlrev_b32_e32 v26, 6, v149                             // 000000032360: 30352A86
	s_mov_b32 s3, exec_lo                                      // 000000032364: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000032368: BF870001
	v_add3_u32 v2, v2, v26, 0xfffff8c0                         // 00000003236C: D6550002 03FE3502 FFFFF8C0
	ds_store_b32 v2, v65                                       // 000000032378: D8340000 00004102
	.long 0xd4c9007e                                           // 000000032380: D4C9007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 000000032384: 02027B37
	s_cbranch_execz 33                                         // 000000032388: BFA50021 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1d10>
	v_dual_sub_f32 v26, v29, v12 :: v_dual_mul_f32 v3, v3, v27 // 00000003238C: C946191D 1A023703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000032394: BF870121
	v_dual_mul_f32 v28, 0x3fb8aa3b, v26 :: v_dual_mul_f32 v3, v13, v3// 000000032398: C8C634FF 1C02070D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v26                  // 0000000323A4: 7C3634FF C2CE8ED0
	v_fma_f32 v29, 0x3fb8aa3b, v26, -v28                       // 0000000323AC: D613001D 847234FF 3FB8AA3B
	v_rndne_f32_e32 v60, v28                                   // 0000000323B8: 7E78471C
	s_waitcnt lgkmcnt(4)                                       // 0000000323BC: BF89FC47
	v_mul_f32_e32 v3, v32, v3                                  // 0000000323C0: 10060720
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000323C4: BF870092
	v_dual_fmac_f32 v29, 0x32a5705f, v26 :: v_dual_sub_f32 v28, v28, v60// 0000000323C8: C80A34FF 1D1C791C 32A5705F
	v_add_f32_e32 v28, v28, v29                                // 0000000323D4: 06383B1C
	v_cvt_i32_f32_e32 v29, v60                                 // 0000000323D8: 7E3A113C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000323DC: BF870292
	v_exp_f32_e32 v28, v28                                     // 0000000323E0: 7E384B1C
	.long 0xd71c001c                                           // 0000000323E4: D71C001C
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                     // 0000000323E8: 02023B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000323EC: BF870121
	v_cndmask_b32_e32 v27, 0, v28, vcc_lo                      // 0000000323F0: 02363880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v26                  // 0000000323F4: 7C3C34FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v27, vcc_lo             // 0000000323FC: 023436FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000032404: BF870001
	.long 0xd508003f                                           // 000000032408: D508003F
	v_sub_co_ci_u32_e32 v1, vcc_lo, v3, v26, vcc_lo            // 00000003240C: 42023503
	s_or_b32 exec_lo, exec_lo, s3                              // 000000032410: 8C7E037E
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v26, 0              // 000000032414: CA100080 031A0080
	s_mov_b32 s3, exec_lo                                      // 00000003241C: BE83007E
	ds_store_b32 v2, v63 offset:128                            // 000000032420: D8340080 00003F02
	.long 0xd4c9007e                                           // 000000032428: D4C9007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 00000003242C: 02027737
	s_cbranch_execz 35                                         // 000000032430: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1dc0>
	v_sub_f32_e32 v24, v24, v12                                // 000000032434: 08301918
	s_waitcnt lgkmcnt(8)                                       // 000000032438: BF89FC87
	v_mul_f32_e32 v4, v4, v22                                  // 00000003243C: 10082D04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000032440: BF8701A2
	v_mul_f32_e32 v26, 0x3fb8aa3b, v24                         // 000000032444: 103430FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v24                  // 00000003244C: 7C3630FF C2CE8ED0
	v_mul_f32_e32 v4, v13, v4                                  // 000000032454: 1008090D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000032458: BF8701B3
	v_fma_f32 v27, 0x3fb8aa3b, v24, -v26                       // 00000003245C: D613001B 846A30FF 3FB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000032468: 7E38471A
	s_waitcnt lgkmcnt(5)                                       // 00000003246C: BF89FC57
	v_mul_f32_e32 v4, v33, v4                                  // 000000032470: 10080921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000032474: BF870193
	v_fmac_f32_e32 v27, 0x32a5705f, v24                        // 000000032478: 563630FF 32A5705F
	v_sub_f32_e32 v26, v26, v28                                // 000000032480: 0834391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000032484: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000032488: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000003248C: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000032490: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032494: BF870095
	.long 0xd71c001a                                           // 000000032498: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000003249C: 0202371A
	v_cndmask_b32_e32 v22, 0, v26, vcc_lo                      // 0000000324A0: 022C3480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v24                  // 0000000324A4: 7C3C30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000324AC: BF870092
	v_cndmask_b32_e32 v22, 0x7f800000, v22, vcc_lo             // 0000000324B0: 022C2CFF 7F800000
	.long 0xd508001a                                           // 0000000324B8: D508001A
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v22, vcc_lo            // 0000000324BC: 42022D04
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000324C0: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000324C4: BF870009
	s_mov_b32 s3, exec_lo                                      // 0000000324C8: BE83007E
	ds_store_b32 v2, v26 offset:256                            // 0000000324CC: D8340100 00001A02
	.long 0xd4c9007e                                           // 0000000324D4: D4C9007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 0000000324D8: 02026337
	s_cbranch_execz 34                                         // 0000000324DC: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1e68>
	v_sub_f32_e32 v3, v25, v12                                 // 0000000324E0: 08061919
	s_waitcnt lgkmcnt(9)                                       // 0000000324E4: BF89FC97
	v_mul_f32_e32 v5, v5, v23                                  // 0000000324E8: 100A2F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000324EC: BF870091
	v_dual_mul_f32 v4, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, v13, v5// 0000000324F0: C8C606FF 04040B0D 3FB8AA3B
	v_fma_f32 v22, 0x3fb8aa3b, v3, -v4                         // 0000000324FC: D6130016 841206FF 3FB8AA3B
	v_rndne_f32_e32 v24, v4                                    // 000000032508: 7E304704
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003250C: BF870112
	v_fmac_f32_e32 v22, 0x32a5705f, v3                         // 000000032510: 562C06FF 32A5705F
	v_sub_f32_e32 v4, v4, v24                                  // 000000032518: 08083104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000003251C: BF8701B1
	v_add_f32_e32 v4, v4, v22                                  // 000000032520: 06082D04
	v_cvt_i32_f32_e32 v22, v24                                 // 000000032524: 7E2C1118
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000032528: 7C3606FF C2CE8ED0
	v_exp_f32_e32 v4, v4                                       // 000000032530: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032534: BF870095
	.long 0xd71c0004                                           // 000000032538: D71C0004
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 00000003253C: 02022D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 000000032540: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000032544: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(5)                                       // 00000003254C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032550: BF870092
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v30, v5// 000000032554: CA4608FF 03040B1E 7F800000
	.long 0xd5080003                                           // 000000032560: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 000000032564: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 000000032568: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000003256C: CA100080 04040080
	s_mov_b32 s3, exec_lo                                      // 000000032574: BE83007E
	ds_store_b32 v2, v3 offset:384                             // 000000032578: D8340180 00000302
	.long 0xd4c9007e                                           // 000000032580: D4C9007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 000000032584: 02026137
	s_cbranch_execz 34                                         // 000000032588: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1f14>
	s_waitcnt lgkmcnt(9)                                       // 00000003258C: BF89FC97
	v_dual_sub_f32 v3, v20, v12 :: v_dual_mul_f32 v6, v6, v18  // 000000032590: C9461914 03062506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000032598: BF870121
	v_dual_mul_f32 v5, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v6, v13, v6// 00000003259C: C8C606FF 05060D0D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 0000000325A8: 7C3606FF C2CE8ED0
	v_fma_f32 v20, 0x3fb8aa3b, v3, -v5                         // 0000000325B0: D6130014 841606FF 3FB8AA3B
	v_rndne_f32_e32 v22, v5                                    // 0000000325BC: 7E2C4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000325C0: BF870091
	v_dual_fmac_f32 v20, 0x32a5705f, v3 :: v_dual_sub_f32 v5, v5, v22// 0000000325C4: C80A06FF 14042D05 32A5705F
	v_add_f32_e32 v5, v5, v20                                  // 0000000325D0: 060A2905
	v_cvt_i32_f32_e32 v20, v22                                 // 0000000325D4: 7E281116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000325D8: BF870292
	v_exp_f32_e32 v5, v5                                       // 0000000325DC: 7E0A4B05
	.long 0xd71c0005                                           // 0000000325E0: D71C0005
	v_cndmask_b32_e32 v1, v5, v20, vcc_lo                      // 0000000325E4: 02022905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000325E8: BF870121
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 0000000325EC: 020A0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 0000000325F0: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v3, 0x7f800000, v5, vcc_lo               // 0000000325F8: 02060AFF 7F800000
	s_waitcnt lgkmcnt(6)                                       // 000000032600: BF89FC67
	v_mul_f32_e32 v5, v31, v6                                  // 000000032604: 100A0D1F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000032608: BF870001
	.long 0xd5080005                                           // 00000003260C: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v3, vcc_lo             // 000000032610: 42020705
	s_or_b32 exec_lo, exec_lo, s3                              // 000000032614: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000032618: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000003261C: BE83007E
	ds_store_b32 v2, v5 offset:512                             // 000000032620: D8340200 00000502
	.long 0xd4c9007e                                           // 000000032628: D4C9007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 00000003262C: 02025F37
	s_cbranch_execz 35                                         // 000000032630: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1fc0>
	v_sub_f32_e32 v3, v21, v12                                 // 000000032634: 08061915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032638: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000003263C: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 000000032644: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 000000032650: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000032654: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 000000032658: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000003265C: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 000000032664: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003266C: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 000000032670: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 000000032674: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 000000032678: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003267C: BF8700A5
	.long 0xd71c0004                                           // 000000032680: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 000000032684: 02020B04
	s_waitcnt lgkmcnt(10)                                      // 000000032688: BF89FCA7
	v_dual_mul_f32 v5, v7, v19 :: v_dual_cndmask_b32 v4, 0, v4 // 00000003268C: C8D22707 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000032694: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 000000032698: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000003269C: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(6)                                       // 0000000326A4: BF89FC67
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v10, v5// 0000000326A8: CA4608FF 03040B0A 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000326B4: BF870001
	.long 0xd5080004                                           // 0000000326B8: D5080004
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 0000000326BC: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000326C0: 8C7E037E
	v_mov_b32_e32 v3, 0                                        // 0000000326C4: 7E060280
	v_mov_b32_e32 v5, 0                                        // 0000000326C8: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 0000000326CC: BE83007E
	ds_store_b32 v2, v4 offset:640                             // 0000000326D0: D8340280 00000402
	.long 0xd4c9007e                                           // 0000000326D8: D4C9007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 0000000326DC: 02025D37
	s_cbranch_execz 35                                         // 0000000326E0: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2070>
	v_sub_f32_e32 v4, v16, v12                                 // 0000000326E4: 08081910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000326E8: BF870091
	v_mul_f32_e32 v5, 0x3fb8aa3b, v4                           // 0000000326EC: 100A08FF 3FB8AA3B
	v_fma_f32 v6, 0x3fb8aa3b, v4, -v5                          // 0000000326F4: D6130006 841608FF 3FB8AA3B
	v_rndne_f32_e32 v7, v5                                     // 000000032700: 7E0E4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000032704: BF870221
	v_sub_f32_e32 v5, v5, v7                                   // 000000032708: 080A0F05
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 00000003270C: 7C3608FF C2CE8ED0
	v_fmac_f32_e32 v6, 0x32a5705f, v4                          // 000000032714: 560C08FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003271C: BF870121
	v_add_f32_e32 v5, v5, v6                                   // 000000032720: 060A0D05
	v_cvt_i32_f32_e32 v6, v7                                   // 000000032724: 7E0C1107
	v_exp_f32_e32 v5, v5                                       // 000000032728: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003272C: BF8700A5
	.long 0xd71c0005                                           // 000000032730: D71C0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 000000032734: 02020D05
	s_waitcnt lgkmcnt(10)                                      // 000000032738: BF89FCA7
	v_dual_mul_f32 v6, v8, v14 :: v_dual_cndmask_b32 v5, 0, v5 // 00000003273C: C8D21D08 06040A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000032744: BF870131
	v_mul_f32_e32 v6, v13, v6                                  // 000000032748: 100C0D0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 00000003274C: 7C3C08FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 000000032754: BF89FC77
	v_dual_cndmask_b32 v4, 0x7f800000, v5 :: v_dual_mul_f32 v5, v11, v6// 000000032758: CA460AFF 04040D0B 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000032764: BF870001
	.long 0xd5080005                                           // 000000032768: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v4, vcc_lo             // 00000003276C: 42020905
	s_or_b32 exec_lo, exec_lo, s3                              // 000000032770: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000032774: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000032778: BE83007E
	ds_store_b32 v2, v5 offset:768                             // 00000003277C: D8340300 00000502
	.long 0xd4c9007e                                           // 000000032784: D4C9007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 000000032788: 02025B37
	s_cbranch_execz 35                                         // 00000003278C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x211c>
	v_sub_f32_e32 v3, v17, v12                                 // 000000032790: 08061911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032794: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 000000032798: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 0000000327A0: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 0000000327AC: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000327B0: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 0000000327B4: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 0000000327B8: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 0000000327C0: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000327C8: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 0000000327CC: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 0000000327D0: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 0000000327D4: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000327D8: BF8700A5
	.long 0xd71c0004                                           // 0000000327DC: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 0000000327E0: 02020B04
	s_waitcnt lgkmcnt(11)                                      // 0000000327E4: BF89FCB7
	v_dual_mul_f32 v5, v9, v15 :: v_dual_cndmask_b32 v4, 0, v4 // 0000000327E8: C8D21F09 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000327F0: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 0000000327F4: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 0000000327F8: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 000000032800: BF89FC77
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v62, v5// 000000032804: CA4608FF 03040B3E 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000032810: BF870001
	.long 0xd5080003                                           // 000000032814: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 000000032818: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003281C: 8C7E037E
	ds_store_b32 v2, v3 offset:896                             // 000000032820: D8340380 00000302
	s_waitcnt lgkmcnt(0)                                       // 000000032828: BF89FC07
	s_barrier                                                  // 00000003282C: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s41                             // 000000032830: 8B6A297E
	s_mov_b32 s3, -1                                           // 000000032834: BE8300C1
	s_cbranch_vccz 176                                         // 000000032838: BFA300B0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x23fc>
	s_mov_b32 s3, exec_lo                                      // 00000003283C: BE83007E
	v_cmpx_gt_i32_e32 0x120, v44                               // 000000032840: 7D8858FF 00000120
	s_cbranch_execz 170                                        // 000000032848: BFA500AA <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x23f4>
	v_add_nc_u32_e32 v2, 0xffffff00, v44                       // 00000003284C: 4A0458FF FFFFFF00
	s_mov_b32 s4, 0                                            // 000000032854: BE840080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000032858: BF870001
	v_mov_b32_e32 v3, v2                                       // 00000003285C: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000032860: BF8700A1
	v_add_nc_u32_e32 v3, 0xe0, v3                              // 000000032864: 4A0606FF 000000E0
	s_waitcnt lgkmcnt(4)                                       // 00000003286C: BF89FC47
	v_ashrrev_i32_e32 v16, 7, v3                               // 000000032870: 34200687
	v_and_b32_e32 v12, 0x7f, v3                                // 000000032874: 361806FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003287C: BF870092
	.long 0xd72c0004                                           // 000000032880: D72C0004
	v_cndmask_b32_e32 v1, 0x880, v16, vcc_lo                   // 000000032884: 020220FF 00000880
	v_lshl_add_u32 v4, v12, 1, v4                              // 00000003288C: D6460004 0411030C
	ds_load_u16 v20, v4 offset:7776                            // 000000032894: D8F01E60 14000004
	ds_load_u16 v21, v4 offset:7232                            // 00000003289C: D8F01C40 15000004
	s_waitcnt lgkmcnt(4)                                       // 0000000328A4: BF89FC47
	ds_load_u16 v22, v4 offset:6688                            // 0000000328A8: D8F01A20 16000004
	ds_load_u16 v23, v4 offset:6144                            // 0000000328B0: D8F01800 17000004
	ds_load_u16 v24, v4 offset:6416                            // 0000000328B8: D8F01910 18000004
	s_waitcnt lgkmcnt(3)                                       // 0000000328C0: BF89FC37
	v_lshlrev_b32_e32 v21, 16, v21                             // 0000000328C4: 302A2A90
	s_waitcnt lgkmcnt(1)                                       // 0000000328C8: BF89FC17
	v_lshlrev_b32_e32 v23, 16, v23                             // 0000000328CC: 302E2E90
	v_lshlrev_b32_e32 v17, 5, v16                              // 0000000328D0: 30222085
	ds_load_u16 v25, v4 offset:6960                            // 0000000328D4: D8F01B30 19000004
	ds_load_u16 v26, v4 offset:7504                            // 0000000328DC: D8F01D50 1A000004
	ds_load_u16 v27, v4 offset:8048                            // 0000000328E4: D8F01F70 1B000004
	ds_load_b128 v[4:7], v17 offset:24384                      // 0000000328EC: DBFC5F40 04000011
	ds_load_b128 v[8:11], v17 offset:24400                     // 0000000328F4: DBFC5F50 08000011
	v_lshlrev_b32_e32 v20, 16, v20                             // 0000000328FC: 30282890
	s_waitcnt lgkmcnt(0)                                       // 000000032900: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032904: BF870091
	v_dual_mul_f32 v10, v10, v20 :: v_dual_lshlrev_b32 v25, 16, v25// 000000032908: C8E2290A 0A183290
	v_dual_mul_f32 v7, v7, v25 :: v_dual_lshlrev_b32 v24, 16, v24// 000000032910: C8E23307 07183090
	v_mul_f32_e32 v8, v8, v21                                  // 000000032918: 10102B08
	s_delay_alu instid0(VALU_DEP_2)                            // 00000003291C: BF870002
	v_dual_mul_f32 v4, v4, v23 :: v_dual_mul_f32 v5, v5, v24   // 000000032920: C8C62F04 04043105
	v_mul_u32_u24_e32 v18, 48, v12                             // 000000032928: 162418B0
	ds_load_b128 v[12:15], v17 offset:24192                    // 00000003292C: DBFC5E80 0C000011
	v_lshlrev_b32_e32 v26, 16, v26                             // 000000032934: 30343490
	v_lshlrev_b32_e32 v27, 16, v27                             // 000000032938: 30363690
	v_lshl_add_u32 v28, v16, 4, v18                            // 00000003293C: D646001C 04490910
	ds_load_b128 v[16:19], v17 offset:24208                    // 000000032944: DBFC5E90 10000011
	s_waitcnt lgkmcnt(1)                                       // 00000003294C: BF89FC17
	v_mul_f32_e32 v12, v12, v4                                 // 000000032950: 1018090C
	v_mul_f32_e32 v4, v13, v5                                  // 000000032954: 10080B0D
	v_dual_mul_f32 v11, v11, v27 :: v_dual_lshlrev_b32 v22, 16, v22// 000000032958: C8E2370B 0B162C90
	v_mul_f32_e32 v5, v15, v7                                  // 000000032960: 100A0F0F
	v_mul_f32_e32 v9, v9, v26                                  // 000000032964: 10123509
	s_waitcnt lgkmcnt(0)                                       // 000000032968: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000003296C: BF870243
	v_dual_mul_f32 v7, v16, v8 :: v_dual_mul_f32 v6, v6, v22   // 000000032970: C8C61110 07062D06
	v_cmp_lt_i32_e32 vcc_lo, 31, v3                            // 000000032978: 7C82069F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 00000003297C: CC220004 02006104
	v_dual_mul_f32 v8, v17, v9 :: v_dual_mul_f32 v9, v18, v10  // 000000032984: C8C61311 08081512
	v_mul_f32_e32 v6, v14, v6                                  // 00000003298C: 100C0D0E
	v_mul_f32_e32 v10, v19, v11                                // 000000032990: 10141713
	v_fma_mixlo_f16 v4, v12, s48, 0                            // 000000032994: CC210004 0200610C
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 00000003299C: CC220005 02006105
	s_or_b32 s4, vcc_lo, s4                                    // 0000000329A4: 8C04046A
	v_fma_mixlo_f16 v5, v6, s48, 0                             // 0000000329A8: CC210005 02006106
	v_fma_mixhi_f16 v6, v8, s48, 0                             // 0000000329B0: CC220006 02006108
	v_fma_mixlo_f16 v6, v7, s48, 0                             // 0000000329B8: CC210006 02006107
	v_fma_mixhi_f16 v7, v10, s48, 0                            // 0000000329C0: CC220007 0200610A
	v_fma_mixlo_f16 v7, v9, s48, 0                             // 0000000329C8: CC210007 02006109
	ds_store_b128 v28, v[4:7]                                  // 0000000329D0: DB7C0000 0000041C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000329D8: 917E047E
	s_cbranch_execnz 65440                                     // 0000000329DC: BFA6FFA0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2160>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000329E0: 8C7E047E
	v_lshl_add_u32 v3, v44, 3, 0xffffff00                      // 0000000329E4: D6460003 03FD072C FFFFFF00
	s_mov_b32 s4, 0                                            // 0000000329F0: BE840080
	v_add_nc_u32_e32 v2, 0xe0, v2                              // 0000000329F4: 4A0404FF 000000E0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000329FC: BF8701A2
	v_and_b32_e32 v4, 0x78, v3                                 // 000000032A00: 360806FF 00000078
	v_add_nc_u32_e32 v3, 0x700, v3                             // 000000032A08: 4A0606FF 00000700
	v_ashrrev_i32_e32 v5, 4, v2                                // 000000032A10: 340A0484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000032A14: BF870121
	.long 0xd72c0006                                           // 000000032A18: D72C0006
	v_cndmask_b32_e32 v1, 0x110, v5, vcc_lo                    // 000000032A1C: 02020AFF 00000110
	v_lshlrev_b32_e32 v8, 2, v5                                // 000000032A24: 30100A82
	v_lshl_add_u32 v9, v4, 1, v6                               // 000000032A28: D6460009 04190304
	ds_load_b128 v[4:7], v9 offset:10496                       // 000000032A30: DBFC2900 04000009
	ds_load_b32 v8, v8 offset:24448                            // 000000032A38: D8D85F80 08000008
	s_waitcnt lgkmcnt(1)                                       // 000000032A40: BF89FC17
	v_and_b32_e32 v12, 0xffff0000, v6                          // 000000032A44: 36180CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000032A4C: 300C0C90
	v_and_b32_e32 v13, 0xffff0000, v7                          // 000000032A50: 361A0EFF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v4                          // 000000032A58: 361408FF FFFF0000
	v_lshlrev_b32_e32 v4, 16, v4                               // 000000032A60: 30080890
	v_and_b32_e32 v11, 0xffff0000, v5                          // 000000032A64: 36160AFF FFFF0000
	v_lshlrev_b32_e32 v5, 16, v5                               // 000000032A6C: 300A0A90
	s_waitcnt lgkmcnt(0)                                       // 000000032A70: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000032A74: BF8701A3
	v_dual_mul_f32 v14, v8, v4 :: v_dual_lshlrev_b32 v7, 16, v7// 000000032A78: C8E20908 0E060E90
	v_mul_f32_e32 v4, v8, v10                                  // 000000032A80: 10081508
	v_mul_f32_e32 v10, v8, v5                                  // 000000032A84: 10140B08
	v_mul_f32_e32 v5, v8, v11                                  // 000000032A88: 100A1708
	v_mul_f32_e32 v11, v8, v6                                  // 000000032A8C: 10160D08
	v_mul_f32_e32 v6, v8, v12                                  // 000000032A90: 100C1908
	v_mul_f32_e32 v12, v8, v7                                  // 000000032A94: 10180F08
	v_mul_f32_e32 v7, v8, v13                                  // 000000032A98: 100E1B08
	v_cmp_lt_i32_e32 vcc_lo, 31, v2                            // 000000032A9C: 7C82049F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 000000032AA0: CC220004 02006104
	v_fma_mixlo_f16 v4, v14, s48, 0                            // 000000032AA8: CC210004 0200610E
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 000000032AB0: CC220005 02006105
	v_fma_mixlo_f16 v5, v10, s48, 0                            // 000000032AB8: CC210005 0200610A
	v_fma_mixhi_f16 v6, v6, s48, 0                             // 000000032AC0: CC220006 02006106
	v_fma_mixlo_f16 v6, v11, s48, 0                            // 000000032AC8: CC210006 0200610B
	v_fma_mixhi_f16 v7, v7, s48, 0                             // 000000032AD0: CC220007 02006107
	v_fma_mixlo_f16 v7, v12, s48, 0                            // 000000032AD8: CC210007 0200610C
	s_or_b32 s4, vcc_lo, s4                                    // 000000032AE0: 8C04046A
	ds_store_b128 v9, v[4:7] offset:10496                      // 000000032AE4: DB7C2900 00000409
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000032AEC: 917E047E
	s_cbranch_execnz 65472                                     // 000000032AF0: BFA6FFC0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x22f4>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000032AF4: 8C7E037E
	s_mov_b32 s3, 0                                            // 000000032AF8: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000032AFC: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 000000032B00: 916A037E
	s_cbranch_vccnz 533                                        // 000000032B04: BFA40215 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c5c>
	s_mov_b32 s3, exec_lo                                      // 000000032B08: BE83007E
	v_cmpx_gt_u32_e32 16, v43                                  // 000000032B0C: 7D985690
	s_cbranch_execz 529                                        // 000000032B10: BFA50211 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c58>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 000000032B14: 7C945680
	s_waitcnt lgkmcnt(0)                                       // 000000032B18: BF89FC07
	ds_load_b96 v[14:16], v1 offset:23280                      // 000000032B1C: DBF85AF0 0E000001
	ds_load_b128 v[59:62], v1 offset:23248                     // 000000032B24: DBFC5AD0 3B000001
	ds_load_b128 v[63:66], v1 offset:23264                     // 000000032B2C: DBFC5AE0 3F000001
	ds_load_b128 v[10:13], v1 offset:23168                     // 000000032B34: DBFC5A80 0A000001
	ds_load_b128 v[6:9], v1 offset:23184                       // 000000032B3C: DBFC5A90 06000001
	ds_load_b128 v[2:5], v1 offset:23200                       // 000000032B44: DBFC5AA0 02000001
	ds_load_b64 v[17:18], v1 offset:23216                      // 000000032B4C: D9D85AB0 11000001
	v_cndmask_b32_e64 v44, 0, 1.0, vcc_lo                      // 000000032B54: D501002C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 000000032B5C: 7C945681
	ds_load_b128 v[45:48], v1 offset:23232                     // 000000032B60: DBFC5AC0 2D000001
	v_cndmask_b32_e64 v33, 0, 1.0, vcc_lo                      // 000000032B68: D5010021 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 000000032B70: 7C945682
	v_cndmask_b32_e64 v32, 0, 1.0, vcc_lo                      // 000000032B74: D5010020 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 000000032B7C: 7C945683
	v_cndmask_b32_e64 v31, 0, 1.0, vcc_lo                      // 000000032B80: D501001F 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 000000032B88: 7C945684
	v_cndmask_b32_e64 v29, 0, 1.0, vcc_lo                      // 000000032B8C: D501001D 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 000000032B94: 7C945685
	v_cndmask_b32_e64 v30, 0, 1.0, vcc_lo                      // 000000032B98: D501001E 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 000000032BA0: 7C945686
	v_cndmask_b32_e64 v28, 0, 1.0, vcc_lo                      // 000000032BA4: D501001C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 000000032BAC: 7C945687
	v_cndmask_b32_e64 v27, 0, 1.0, vcc_lo                      // 000000032BB0: D501001B 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 000000032BB8: 7C945688
	v_cndmask_b32_e64 v25, 0, 1.0, vcc_lo                      // 000000032BBC: D5010019 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 000000032BC4: 7C945689
	v_cndmask_b32_e64 v23, 0, 1.0, vcc_lo                      // 000000032BC8: D5010017 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 000000032BD0: 7C94568A
	v_cndmask_b32_e64 v26, 0, 1.0, vcc_lo                      // 000000032BD4: D501001A 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 000000032BDC: 7C94568B
	v_cndmask_b32_e64 v24, 0, 1.0, vcc_lo                      // 000000032BE0: D5010018 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 000000032BE8: 7C94568C
	v_cndmask_b32_e64 v20, 0, 1.0, vcc_lo                      // 000000032BEC: D5010014 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 000000032BF4: 7C94568D
	v_cndmask_b32_e64 v22, 0, 1.0, vcc_lo                      // 000000032BF8: D5010016 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 000000032C00: 7C94568E
	v_cndmask_b32_e64 v21, 0, 1.0, vcc_lo                      // 000000032C04: D5010015 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 000000032C0C: 7C94568F
	v_cndmask_b32_e64 v19, 0, 1.0, vcc_lo                      // 000000032C10: D5010013 01A9E480
	s_waitcnt lgkmcnt(7)                                       // 000000032C18: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000032C1C: BF8700B1
	v_fmac_f32_e32 v22, v19, v15                               // 000000032C20: 562C1F13
	v_fmac_f32_e32 v21, v19, v16                               // 000000032C24: 562A2113
	s_waitcnt lgkmcnt(1)                                       // 000000032C28: BF89FC17
	v_dual_fmac_f32 v23, v19, v64 :: v_dual_fmac_f32 v22, v21, v18// 000000032C2C: C8008113 17162515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000032C34: BF8700D1
	v_dual_fmac_f32 v26, v19, v65 :: v_dual_fmac_f32 v23, v21, v3// 000000032C38: C8008313 1A160715
	v_fmac_f32_e32 v25, v19, v63                               // 000000032C40: 56327F13
	ds_load_b32 v18, v1 offset:22880                           // 000000032C44: D8D85960 12000001
	v_fmac_f32_e32 v26, v21, v4                                // 000000032C4C: 56340915
	v_dual_fmac_f32 v28, v19, v61 :: v_dual_fmac_f32 v25, v21, v2// 000000032C50: C8007B13 1C180515
	v_dual_fmac_f32 v29, v19, v59 :: v_dual_fmac_f32 v28, v21, v8// 000000032C58: C8007713 1D1C1115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032C60: BF870091
	v_dual_fmac_f32 v30, v19, v60 :: v_dual_fmac_f32 v29, v21, v6// 000000032C64: C8007913 1E1C0D15
	v_dual_fmac_f32 v27, v19, v62 :: v_dual_fmac_f32 v30, v21, v7// 000000032C6C: C8007D13 1B1E0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032C74: BF870091
	v_dual_fmac_f32 v24, v19, v66 :: v_dual_fmac_f32 v27, v21, v9// 000000032C78: C8008513 181A1315
	v_fmac_f32_e32 v24, v21, v5                                // 000000032C80: 56300B15
	ds_load_b128 v[2:5], v1 offset:23072                       // 000000032C84: DBFC5A20 02000001
	s_waitcnt lgkmcnt(2)                                       // 000000032C8C: BF89FC27
	v_fmac_f32_e32 v31, v19, v48                               // 000000032C90: 563E6113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000032C94: BF870091
	v_dual_fmac_f32 v32, v19, v47 :: v_dual_fmac_f32 v31, v21, v13// 000000032C98: C8005F13 201E1B15
	v_dual_fmac_f32 v33, v19, v46 :: v_dual_fmac_f32 v32, v21, v12// 000000032CA0: C8005D13 21201915
	v_fmac_f32_e32 v44, v19, v45                               // 000000032CA8: 56585B13
	ds_load_b128 v[45:48], v1 offset:24064                     // 000000032CAC: DBFC5E00 2D000001
	v_dual_fmac_f32 v33, v21, v11 :: v_dual_fmac_f32 v20, v19, v14// 000000032CB4: C8001715 21141D13
	ds_load_b128 v[59:62], v1 offset:23104                     // 000000032CBC: DBFC5A40 3B000001
	ds_load_b128 v[63:66], v1 offset:23136                     // 000000032CC4: DBFC5A60 3F000001
	ds_load_b128 v[67:70], v1 offset:23120                     // 000000032CCC: DBFC5A50 43000001
	ds_load_b32 v14, v1 offset:23152                           // 000000032CD4: D8D85A70 0E000001
	v_fmac_f32_e32 v44, v21, v10                               // 000000032CDC: 56581515
	ds_load_b128 v[6:9], v1 offset:23056                       // 000000032CE0: DBFC5A10 06000001
	ds_load_b128 v[10:13], v1 offset:23040                     // 000000032CE8: DBFC5A00 0A000001
	s_waitcnt lgkmcnt(5)                                       // 000000032CF0: BF89FC57
	v_fmac_f32_e32 v44, v22, v59                               // 000000032CF4: 56587716
	v_dual_fmac_f32 v33, v22, v60 :: v_dual_fmac_f32 v20, v21, v17// 000000032CF8: C8007916 21142315
	s_waitcnt lgkmcnt(3)                                       // 000000032D00: BF89FC37
	v_fmac_f32_e32 v29, v22, v67                               // 000000032D04: 563A8716
	v_fmac_f32_e32 v31, v22, v62                               // 000000032D08: 563E7D16
	s_waitcnt lgkmcnt(2)                                       // 000000032D0C: BF89FC27
	v_fmac_f32_e32 v20, v22, v14                               // 000000032D10: 56281D16
	ds_load_b128 v[14:17], v1 offset:22976                     // 000000032D14: DBFC59C0 0E000001
	v_fmac_f32_e32 v24, v22, v66                               // 000000032D1C: 56308516
	v_fmac_f32_e32 v32, v22, v61                               // 000000032D20: 56407B16
	ds_load_b64 v[66:67], v1 offset:22944                      // 000000032D24: D9D859A0 42000001
	s_waitcnt lgkmcnt(2)                                       // 000000032D2C: BF89FC27
	v_fmac_f32_e32 v33, v20, v11                               // 000000032D30: 56421714
	v_fmac_f32_e32 v24, v20, v5                                // 000000032D34: 56300B14
	s_waitcnt lgkmcnt(1)                                       // 000000032D38: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000032D3C: BF8701B1
	v_dual_fmac_f32 v33, v24, v15 :: v_dual_fmac_f32 v30, v22, v68// 000000032D40: C8001F18 211E8916
	v_fmac_f32_e32 v29, v20, v6                                // 000000032D48: 563A0D14
	v_dual_fmac_f32 v25, v22, v63 :: v_dual_fmac_f32 v44, v20, v10// 000000032D4C: C8007F16 192C1514
	v_dual_fmac_f32 v23, v22, v64 :: v_dual_fmac_f32 v30, v20, v7// 000000032D54: C8008116 171E0F14
	v_fmac_f32_e32 v26, v22, v65                               // 000000032D5C: 56348316
	ds_load_b128 v[59:62], v1 offset:22992                     // 000000032D60: DBFC59D0 3B000001
	ds_load_b96 v[63:65], v1 offset:23008                      // 000000032D68: DBF859E0 3F000001
	v_dual_fmac_f32 v28, v22, v69 :: v_dual_fmac_f32 v25, v20, v2// 000000032D70: C8008B16 1C180514
	v_dual_fmac_f32 v27, v22, v70 :: v_dual_fmac_f32 v32, v20, v12// 000000032D78: C8008D16 1B201914
	v_fmac_f32_e32 v23, v20, v3                                // 000000032D80: 562E0714
	v_fmac_f32_e32 v26, v20, v4                                // 000000032D84: 56340914
	v_fmac_f32_e32 v31, v20, v13                               // 000000032D88: 563E1B14
	s_delay_alu instid0(VALU_DEP_4)                            // 000000032D8C: BF870004
	v_fmac_f32_e32 v27, v20, v9                                // 000000032D90: 56361314
	ds_load_b128 v[2:5], v1 offset:22848                       // 000000032D94: DBFC5940 02000001
	s_waitcnt lgkmcnt(1)                                       // 000000032D9C: BF89FC17
	v_fmac_f32_e32 v26, v24, v65                               // 000000032DA0: 56348318
	v_fmac_f32_e32 v28, v20, v8                                // 000000032DA4: 56381114
	ds_load_b128 v[6:9], v1 offset:22928                       // 000000032DA8: DBFC5990 06000001
	ds_load_b128 v[10:13], v1 offset:22912                     // 000000032DB0: DBFC5980 0A000001
	v_fmac_f32_e32 v29, v24, v59                               // 000000032DB8: 563A7718
	s_waitcnt lgkmcnt(1)                                       // 000000032DBC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000032DC0: BF870001
	v_fmac_f32_e32 v29, v26, v6                                // 000000032DC4: 563A0D1A
	v_fmac_f32_e32 v31, v24, v17                               // 000000032DC8: 563E2318
	v_fmac_f32_e32 v44, v24, v14                               // 000000032DCC: 56581D18
	v_fmac_f32_e32 v23, v24, v64                               // 000000032DD0: 562E8118
	v_fmac_f32_e32 v32, v24, v16                               // 000000032DD4: 56402118
	ds_load_b128 v[14:17], v1 offset:22864                     // 000000032DD8: DBFC5950 0E000001
	v_fmac_f32_e32 v23, v26, v67                               // 000000032DE0: 562E871A
	s_waitcnt lgkmcnt(0)                                       // 000000032DE4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000032DE8: BF870001
	v_fmac_f32_e32 v29, v23, v14                               // 000000032DEC: 563A1D17
	v_fmac_f32_e32 v27, v24, v62                               // 000000032DF0: 56367D18
	v_fmac_f32_e32 v30, v24, v60                               // 000000032DF4: 563C7918
	v_fmac_f32_e32 v25, v24, v63                               // 000000032DF8: 56327F18
	v_dual_fmac_f32 v33, v26, v11 :: v_dual_fmac_f32 v28, v24, v61// 000000032DFC: C800171A 211C7B18
	ds_load_b128 v[59:62], v1 offset:22800                     // 000000032E04: DBFC5910 3B000001
	v_fmac_f32_e32 v32, v26, v12                               // 000000032E0C: 5640191A
	v_fmac_f32_e32 v31, v26, v13                               // 000000032E10: 563E1B1A
	v_fmac_f32_e32 v44, v26, v10                               // 000000032E14: 5658151A
	ds_load_b128 v[10:13], v1 offset:22784                     // 000000032E18: DBFC5900 0A000001
	ds_load_b96 v[63:65], v1 offset:22736                      // 000000032E20: DBF858D0 3F000001
	v_fmac_f32_e32 v27, v26, v9                                // 000000032E28: 5636131A
	v_fmac_f32_e32 v30, v26, v7                                // 000000032E2C: 563C0F1A
	v_fmac_f32_e32 v25, v26, v66                               // 000000032E30: 5632851A
	v_fmac_f32_e32 v28, v26, v8                                // 000000032E34: 5638111A
	ds_load_b128 v[6:9], v1 offset:22720                       // 000000032E38: DBFC58C0 06000001
	ds_load_b64 v[66:67], v1 offset:22672                      // 000000032E40: D9D85890 42000001
	v_fmac_f32_e32 v33, v23, v3                                // 000000032E48: 56420717
	v_fmac_f32_e32 v25, v23, v18                               // 000000032E4C: 56322517
	v_fmac_f32_e32 v28, v23, v16                               // 000000032E50: 56382117
	v_fmac_f32_e32 v27, v23, v17                               // 000000032E54: 56362317
	v_fmac_f32_e32 v30, v23, v15                               // 000000032E58: 563C1F17
	ds_load_b128 v[14:17], v1 offset:22528                     // 000000032E5C: DBFC5800 0E000001
	s_waitcnt lgkmcnt(5)                                       // 000000032E64: BF89FC57
	v_fmac_f32_e32 v27, v25, v62                               // 000000032E68: 56367D19
	v_fmac_f32_e32 v28, v25, v61                               // 000000032E6C: 56387B19
	v_fmac_f32_e32 v30, v25, v60                               // 000000032E70: 563C7919
	s_waitcnt lgkmcnt(3)                                       // 000000032E74: BF89FC37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000032E78: BF870112
	v_fmac_f32_e32 v28, v27, v65                               // 000000032E7C: 5638831B
	v_fmac_f32_e32 v30, v27, v64                               // 000000032E80: 563C811B
	s_waitcnt lgkmcnt(1)                                       // 000000032E84: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000032E88: BF870001
	v_fmac_f32_e32 v30, v28, v67                               // 000000032E8C: 563C871C
	v_dual_fmac_f32 v44, v23, v2 :: v_dual_fmac_f32 v33, v25, v11// 000000032E90: C8000517 2C201719
	v_fmac_f32_e32 v31, v23, v5                                // 000000032E98: 563E0B17
	v_fmac_f32_e32 v32, v23, v4                                // 000000032E9C: 56400917
	ds_load_b128 v[2:5], v1 offset:22656                       // 000000032EA0: DBFC5880 02000001
	v_fmac_f32_e32 v44, v25, v10                               // 000000032EA8: 56581519
	v_fmac_f32_e32 v29, v25, v59                               // 000000032EAC: 563A7719
	v_fmac_f32_e32 v31, v25, v13                               // 000000032EB0: 563E1B19
	v_fmac_f32_e32 v32, v25, v12                               // 000000032EB4: 56401919
	ds_load_b128 v[10:13], v1 offset:22592                     // 000000032EB8: DBFC5840 0A000001
	ds_load_b32 v18, v1 offset:22608                           // 000000032EC0: D8D85850 12000001
	v_fmac_f32_e32 v33, v27, v7                                // 000000032EC8: 56420F1B
	v_fmac_f32_e32 v29, v27, v63                               // 000000032ECC: 563A7F1B
	ds_load_b64 v[59:60], v1 offset:22400                      // 000000032ED0: D9D85780 3B000001
	v_dual_fmac_f32 v32, v27, v8 :: v_dual_fmac_f32 v29, v28, v66// 000000032ED8: C800111B 201C851C
	ds_load_b128 v[63:66], v1 offset:24304                     // 000000032EE0: DBFC5EF0 3F000001
	s_waitcnt lgkmcnt(2)                                       // 000000032EE8: BF89FC27
	v_fmac_f32_e32 v29, v30, v18                               // 000000032EEC: 563A251E
	v_dual_fmac_f32 v44, v27, v6 :: v_dual_fmac_f32 v33, v28, v3// 000000032EF0: C8000D1B 2C20071C
	v_fmac_f32_e32 v31, v27, v9                                // 000000032EF8: 563E131B
	ds_load_b96 v[6:8], v1 offset:22464                        // 000000032EFC: DBF857C0 06000001
	ds_load_b32 v9, v1 offset:22336                            // 000000032F04: D8D85740 09000001
	v_fmac_f32_e32 v44, v28, v2                                // 000000032F0C: 5658051C
	v_fmac_f32_e32 v32, v28, v4                                // 000000032F10: 5640091C
	v_fmac_f32_e32 v31, v28, v5                                // 000000032F14: 563E0B1C
	v_fmac_f32_e32 v33, v30, v11                               // 000000032F18: 5642171E
	ds_load_b128 v[2:5], v1 offset:24256                       // 000000032F1C: DBFC5EC0 02000001
	v_fmac_f32_e32 v44, v30, v10                               // 000000032F24: 5658151E
	v_fmac_f32_e32 v32, v30, v12                               // 000000032F28: 5640191E
	v_fmac_f32_e32 v31, v30, v13                               // 000000032F2C: 563E1B1E
	v_fmac_f32_e32 v33, v29, v15                               // 000000032F30: 56421F1D
	s_waitcnt lgkmcnt(3)                                       // 000000032F34: BF89FC37
	v_mul_f32_e32 v72, v65, v21                                // 000000032F38: 10902B41
	v_fmac_f32_e32 v44, v29, v14                               // 000000032F3C: 56581D1D
	v_fmac_f32_e32 v32, v29, v16                               // 000000032F40: 5640211D
	v_fmac_f32_e32 v31, v29, v17                               // 000000032F44: 563E231D
	s_waitcnt lgkmcnt(2)                                       // 000000032F48: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000032F4C: BF8700A1
	v_fmac_f32_e32 v32, v31, v8                                // 000000032F50: 5640111F
	v_fmac_f32_e32 v33, v31, v7                                // 000000032F54: 56420F1F
	v_dual_fmac_f32 v44, v31, v6 :: v_dual_fmac_f32 v33, v32, v60// 000000032F58: C8000D1F 2C207920
	s_delay_alu instid0(VALU_DEP_1)                            // 000000032F60: BF870001
	v_fmac_f32_e32 v44, v32, v59                               // 000000032F64: 56587720
	ds_load_b128 v[59:62], v1 offset:24288                     // 000000032F68: DBFC5EE0 3B000001
	s_waitcnt lgkmcnt(1)                                       // 000000032F70: BF89FC17
	v_fma_mixlo_f16 v49, v5, v31, 0                            // 000000032F74: CC210031 02023F05
	v_mul_f32_e32 v15, v3, v33                                 // 000000032F7C: 101E4303
	v_fmac_f32_e32 v44, v33, v9                                // 000000032F80: 56581321
	ds_load_b128 v[6:9], v1 offset:24272                       // 000000032F84: DBFC5ED0 06000001
	ds_load_b128 v[10:13], v1 offset:24112                     // 000000032F8C: DBFC5E30 0A000001
	v_fma_mixlo_f16 v18, v3, v33, 0                            // 000000032F94: CC210012 02024303
	v_mul_f32_e32 v14, v2, v44                                 // 000000032F9C: 101C5902
	v_fma_mixlo_f16 v2, v2, v44, 0                             // 000000032FA0: CC210002 02025902
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000032FA8: BF870113
	v_fma_mix_f32 v15, v18, -1.0, v15 op_sel_hi:[1,1,0]        // 000000032FAC: CC20000F 1C3DE712
	v_fma_mix_f32 v3, v2, -1.0, v14 op_sel_hi:[1,1,0]          // 000000032FB4: CC200003 1C39E702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000032FBC: BF870232
	.long 0x7f1c150f                                           // 000000032FC0: 7F1C150F
	v_mul_f32_e32 v15, v4, v32                                 // 000000032FC4: 101E4104
	.long 0x7f043912                                           // 000000032FC8: 7F043912
	v_cvt_f16_f32_e32 v14, v3                                  // 000000032FCC: 7E1C1503
	v_fma_mixlo_f16 v3, v4, v32, 0                             // 000000032FD0: CC210003 02024104
	v_mul_f32_e32 v4, v5, v31                                  // 000000032FD8: 10083F05
	s_waitcnt lgkmcnt(2)                                       // 000000032FDC: BF89FC27
	v_fma_mixlo_f16 v69, v60, v23, 0                           // 000000032FE0: CC210045 02022F3C
	s_waitcnt lgkmcnt(1)                                       // 000000032FE8: BF89FC17
	v_mul_f32_e32 v16, v7, v30                                 // 000000032FEC: 10203D07
	v_fma_mixlo_f16 v67, v7, v30, 0                            // 000000032FF0: CC210043 02023D07
	v_fma_mix_f32 v7, v3, -1.0, v15 op_sel_hi:[1,1,0]          // 000000032FF8: CC200007 1C3DE703
	v_mul_f32_e32 v5, v6, v29                                  // 000000033000: 100A3B06
	v_fma_mixlo_f16 v68, v9, v27, 0                            // 000000033004: CC210044 02023709
	.long 0x7f063931                                           // 00000003300C: 7F063931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000033010: BF8701D4
	v_cvt_f16_f32_e32 v15, v7                                  // 000000033014: 7E1E1507
	v_mul_f32_e32 v7, v8, v28                                  // 000000033018: 100E3908
	v_fma_mix_f32 v17, v49, -1.0, v4 op_sel_hi:[1,1,0]         // 00000003301C: CC200011 1C11E731
	v_fma_mixlo_f16 v4, v6, v29, 0                             // 000000033024: CC210004 02023B06
	v_fma_mix_f32 v6, v67, -1.0, v16 op_sel_hi:[1,1,0]         // 00000003302C: CC200006 1C41E743
	.long 0x7f1e1511                                           // 000000033034: 7F1E1511
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000033038: BF870193
	v_fma_mix_f32 v5, v4, -1.0, v5 op_sel_hi:[1,1,0]           // 00000003303C: CC200005 1C15E704
	.long 0x7f201506                                           // 000000033044: 7F201506
	v_fma_mixlo_f16 v6, v59, v25, 0                            // 000000033048: CC210006 0202333B
	.long 0x7f083943                                           // 000000033050: 7F083943
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000033054: BF8701C4
	v_cvt_f16_f32_e32 v16, v5                                  // 000000033058: 7E201505
	v_fma_mixlo_f16 v5, v8, v28, 0                             // 00000003305C: CC210005 02023908
	v_dual_mul_f32 v8, v9, v27 :: v_dual_mul_f32 v9, v59, v25  // 000000033064: C8C63709 0808333B
	v_dual_mul_f32 v59, v60, v23 :: v_dual_mul_f32 v60, v61, v26// 00000003306C: C8C62F3C 3B3C353D
	v_fma_mix_f32 v7, v5, -1.0, v7 op_sel_hi:[1,1,0]           // 000000033074: CC200007 1C1DE705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003307C: BF870213
	v_fma_mix_f32 v8, v68, -1.0, v8 op_sel_hi:[1,1,0]          // 000000033080: CC200008 1C21E744
	v_fma_mix_f32 v9, v6, -1.0, v9 op_sel_hi:[1,1,0]           // 000000033088: CC200009 1C25E706
	s_delay_alu instid0(VALU_DEP_4)                            // 000000033090: BF870004
	v_fma_mix_f32 v70, v69, -1.0, v59 op_sel_hi:[1,1,0]        // 000000033094: CC200046 1CEDE745
	.long 0x7f0c3945                                           // 00000003309C: 7F0C3945
	v_cvt_f16_f32_e32 v17, v7                                  // 0000000330A0: 7E221507
	v_fma_mixlo_f16 v7, v61, v26, 0                            // 0000000330A4: CC210007 0202353D
	.long 0x7f221508                                           // 0000000330AC: 7F221508
	v_cvt_f16_f32_e32 v59, v9                                  // 0000000330B0: 7E761509
	.long 0x7f761546                                           // 0000000330B4: 7F761546
	v_mul_f32_e32 v9, v62, v24                                 // 0000000330B8: 1012313E
	v_fma_mix_f32 v8, v7, -1.0, v60 op_sel_hi:[1,1,0]          // 0000000330BC: CC200008 1CF1E707
	v_fma_mixlo_f16 v70, v62, v24, 0                           // 0000000330C4: CC210046 0202313E
	v_dual_mul_f32 v61, v63, v20 :: v_dual_mul_f32 v62, v64, v22// 0000000330CC: C8C6293F 3D3E2D40
	v_fma_mixlo_f16 v64, v64, v22, 0                           // 0000000330D4: CC210040 02022D40
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000330DC: BF870214
	v_cvt_f16_f32_e32 v60, v8                                  // 0000000330E0: 7E781508
	v_fma_mix_f32 v71, v70, -1.0, v9 op_sel_hi:[1,1,0]         // 0000000330E4: CC200047 1C25E746
	v_fma_mixlo_f16 v8, v63, v20, 0                            // 0000000330EC: CC210008 0202293F
	v_fma_mixlo_f16 v9, v65, v21, 0                            // 0000000330F4: CC210009 02022B41
	v_fma_mix_f32 v62, v64, -1.0, v62 op_sel_hi:[1,1,0]        // 0000000330FC: CC20003E 1CF9E740
	v_mul_f32_e32 v65, v66, v19                                // 000000033104: 10822742
	v_fma_mixlo_f16 v66, v66, v19, 0                           // 000000033108: CC210042 02022742
	v_fma_mix_f32 v61, v8, -1.0, v61 op_sel_hi:[1,1,0]         // 000000033110: CC20003D 1CF5E708
	v_fma_mix_f32 v63, v9, -1.0, v72 op_sel_hi:[1,1,0]         // 000000033118: CC20003F 1D21E709
	.long 0x7f781547                                           // 000000033120: 7F781547
	.long 0x7f103940                                           // 000000033124: 7F103940
	v_fma_mix_f32 v71, v66, -1.0, v65 op_sel_hi:[1,1,0]        // 000000033128: CC200047 1D05E742
	v_cvt_f16_f32_e32 v61, v61                                 // 000000033130: 7E7A153D
	.long 0x7f7a153e                                           // 000000033134: 7F7A153E
	v_cvt_f16_f32_e32 v62, v63                                 // 000000033138: 7E7C153F
	.long 0x7f123942                                           // 00000003313C: 7F123942
	ds_load_b128 v[63:66], v1 offset:24080                     // 000000033140: DBFC5E10 3F000001
	v_mul_u32_u24_e32 v72, 48, v43                             // 000000033148: 169056B0
	.long 0x7f0e3946                                           // 00000003314C: 7F0E3946
	.long 0x7f0a3944                                           // 000000033150: 7F0A3944
	v_mul_f32_e32 v18, v45, v44                                // 000000033154: 1024592D
	v_fma_mixlo_f16 v43, v45, v44, 0                           // 000000033158: CC21002B 0202592D
	v_mul_f32_e32 v44, v46, v33                                // 000000033160: 1058432E
	v_fma_mixlo_f16 v33, v46, v33, 0                           // 000000033164: CC210021 0202432E
	ds_store_b128 v72, v[6:9] offset:19216                     // 00000003316C: DB7C4B10 00000648
	ds_store_b128 v72, v[2:5] offset:19200                     // 000000033174: DB7C4B00 00000248
	ds_load_b128 v[2:5], v1 offset:24096                       // 00000003317C: DBFC5E20 02000001
	v_dual_mul_f32 v7, v47, v32 :: v_dual_mul_f32 v8, v48, v31 // 000000033184: C8C6412F 07083F30
	v_fma_mix_f32 v44, v33, -1.0, v44 op_sel_hi:[1,1,0]        // 00000003318C: CC20002C 1CB1E721
	.long 0x7f7c1547                                           // 000000033194: 7F7C1547
	s_delay_alu instid0(VALU_DEP_2)                            // 000000033198: BF870002
	.long 0x7f0c152c                                           // 00000003319C: 7F0C152C
	v_fma_mixlo_f16 v44, v47, v32, 0                           // 0000000331A0: CC21002C 0202412F
	s_waitcnt lgkmcnt(3)                                       // 0000000331A8: BF89FC37
	v_mul_f32_e32 v9, v63, v29                                 // 0000000331AC: 10123B3F
	v_fma_mix_f32 v18, v43, -1.0, v18 op_sel_hi:[1,1,0]        // 0000000331B0: CC200012 1C49E72B
	v_fma_mixlo_f16 v45, v63, v29, 0                           // 0000000331B8: CC21002D 02023B3F
	v_fma_mix_f32 v7, v44, -1.0, v7 op_sel_hi:[1,1,0]          // 0000000331C0: CC200007 1C1DE72C
	v_fma_mixlo_f16 v46, v65, v28, 0                           // 0000000331C8: CC21002E 02023941
	.long 0x7f563921                                           // 0000000331D0: 7F563921
	v_cvt_f16_f32_e32 v6, v18                                  // 0000000331D4: 7E0C1512
	v_fma_mixlo_f16 v18, v48, v31, 0                           // 0000000331D8: CC210012 02023F30
	v_mul_f32_e32 v31, v64, v30                                // 0000000331E0: 103E3D40
	v_fma_mixlo_f16 v30, v64, v30, 0                           // 0000000331E4: CC21001E 02023D40
	v_fma_mix_f32 v9, v45, -1.0, v9 op_sel_hi:[1,1,0]          // 0000000331EC: CC200009 1C25E72D
	v_cvt_f16_f32_e32 v7, v7                                   // 0000000331F4: 7E0E1507
	.long 0x7f583912                                           // 0000000331F8: 7F583912
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000331FC: BF870004
	v_fma_mix_f32 v29, v30, -1.0, v31 op_sel_hi:[1,1,0]        // 000000033200: CC20001D 1C7DE71E
	v_mul_f32_e32 v31, v65, v28                                // 000000033208: 103E3941
	v_fma_mix_f32 v8, v18, -1.0, v8 op_sel_hi:[1,1,0]          // 00000003320C: CC200008 1C21E712
	v_mul_f32_e32 v28, v66, v27                                // 000000033214: 10383742
	v_fma_mixlo_f16 v27, v66, v27, 0                           // 000000033218: CC21001B 02023742
	.long 0x7f5a391e                                           // 000000033220: 7F5A391E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000033224: BF870004
	.long 0x7f0e1508                                           // 000000033228: 7F0E1508
	v_cvt_f16_f32_e32 v8, v9                                   // 00000003322C: 7E101509
	.long 0x7f10151d                                           // 000000033230: 7F10151D
	v_fma_mix_f32 v9, v46, -1.0, v31 op_sel_hi:[1,1,0]         // 000000033234: CC200009 1C7DE72E
	s_waitcnt lgkmcnt(0)                                       // 00000003323C: BF89FC07
	v_mul_f32_e32 v29, v2, v25                                 // 000000033240: 103A3302
	v_fma_mixlo_f16 v2, v2, v25, 0                             // 000000033244: CC210002 02023302
	v_mul_f32_e32 v25, v3, v23                                 // 00000003324C: 10322F03
	v_fma_mixlo_f16 v31, v3, v23, 0                            // 000000033250: CC21001F 02022F03
	v_fma_mix_f32 v3, v27, -1.0, v28 op_sel_hi:[1,1,0]         // 000000033258: CC200003 1C71E71B
	v_cvt_f16_f32_e32 v9, v9                                   // 000000033260: 7E121509
	v_mul_f32_e32 v23, v4, v26                                 // 000000033264: 102E3504
	.long 0x7f5c391b                                           // 000000033268: 7F5C391B
	v_fma_mix_f32 v25, v31, -1.0, v25 op_sel_hi:[1,1,0]        // 00000003326C: CC200019 1C65E71F
	.long 0x7f121503                                           // 000000033274: 7F121503
	v_fma_mixlo_f16 v3, v4, v26, 0                             // 000000033278: CC210003 02023504
	v_mul_f32_e32 v26, v11, v22                                // 000000033280: 10342D0B
	v_fma_mix_f32 v28, v2, -1.0, v29 op_sel_hi:[1,1,0]         // 000000033284: CC20001C 1C75E702
	v_fma_mixlo_f16 v11, v11, v22, 0                           // 00000003328C: CC21000B 02022D0B
	.long 0x7f04391f                                           // 000000033294: 7F04391F
	v_fma_mix_f32 v4, v3, -1.0, v23 op_sel_hi:[1,1,0]          // 000000033298: CC200004 1C5DE703
	.long 0x7f2e1519                                           // 0000000332A0: 7F2E1519
	v_cvt_f16_f32_e32 v23, v28                                 // 0000000332A4: 7E2E151C
	v_mul_f32_e32 v25, v5, v24                                 // 0000000332A8: 10323105
	v_fma_mixlo_f16 v28, v5, v24, 0                            // 0000000332AC: CC21001C 02023105
	v_cvt_f16_f32_e32 v24, v4                                  // 0000000332B4: 7E301504
	v_mul_f32_e32 v5, v10, v20                                 // 0000000332B8: 100A290A
	v_fma_mixlo_f16 v4, v10, v20, 0                            // 0000000332BC: CC210004 0202290A
	v_fma_mix_f32 v20, v11, -1.0, v26 op_sel_hi:[1,1,0]        // 0000000332C4: CC200014 1C69E70B
	v_fma_mix_f32 v22, v28, -1.0, v25 op_sel_hi:[1,1,0]        // 0000000332CC: CC200016 1C65E71C
	v_mul_f32_e32 v25, v12, v21                                // 0000000332D4: 10322B0C
	.long 0x7f06391c                                           // 0000000332D8: 7F06391C
	v_fma_mix_f32 v10, v4, -1.0, v5 op_sel_hi:[1,1,0]          // 0000000332DC: CC20000A 1C15E704
	v_fma_mixlo_f16 v5, v12, v21, 0                            // 0000000332E4: CC210005 02022B0C
	v_mul_f32_e32 v21, v13, v19                                // 0000000332EC: 102A270D
	v_fma_mixlo_f16 v13, v13, v19, 0                           // 0000000332F0: CC21000D 0202270D
	.long 0x7f08390b                                           // 0000000332F8: 7F08390B
	.long 0x7f301516                                           // 0000000332FC: 7F301516
	v_fma_mix_f32 v12, v5, -1.0, v25 op_sel_hi:[1,1,0]         // 000000033300: CC20000C 1C65E705
	v_cvt_f16_f32_e32 v25, v10                                 // 000000033308: 7E32150A
	v_fma_mix_f32 v10, v13, -1.0, v21 op_sel_hi:[1,1,0]        // 00000003330C: CC20000A 1C55E70D
	.long 0x7f0a390d                                           // 000000033314: 7F0A390D
	.long 0x7f321514                                           // 000000033318: 7F321514
	v_cvt_f16_f32_e32 v26, v12                                 // 00000003331C: 7E34150C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000033320: BF870004
	.long 0x7f34150a                                           // 000000033324: 7F34150A
	ds_store_b128 v72, v[59:62] offset:19984                   // 000000033328: DB7C4E10 00003B48
	ds_store_b128 v72, v[14:17] offset:19968                   // 000000033330: DB7C4E00 00000E48
	ds_store_b128 v72, v[2:5] offset:20752                     // 000000033338: DB7C5110 00000248
	ds_store_b128 v72, v[43:46] offset:20736                   // 000000033340: DB7C5100 00002B48
	ds_store_b128 v72, v[23:26] offset:21520                   // 000000033348: DB7C5410 00001748
	ds_store_b128 v72, v[6:9] offset:21504                     // 000000033350: DB7C5400 00000648
	s_or_b32 exec_lo, exec_lo, s3                              // 000000033358: 8C7E037E
	v_lshlrev_b32_e32 v59, 1, v148                             // 00000003335C: 30772881
	s_waitcnt lgkmcnt(0)                                       // 000000033360: BF89FC07
	s_barrier                                                  // 000000033364: BFBD0000
	v_cmp_eq_u32_e32 vcc_lo, 0, v34                            // 000000033368: 7C944480
	v_mul_u32_u24_e32 v60, 48, v55                             // 00000003336C: 16786EB0
	s_cmp_lt_i32 s29, s39                                      // 000000033370: BF04271D
	ds_load_u16 v2, v59 offset:6416                            // 000000033374: D8F01910 0200003B
	ds_load_u16 v3, v59 offset:7776                            // 00000003337C: D8F01E60 0300003B
	ds_load_u16 v4, v59 offset:7232                            // 000000033384: D8F01C40 0400003B
	s_waitcnt lgkmcnt(3)                                       // 00000003338C: BF89FC37
	ds_load_u16 v5, v59 offset:6688                            // 000000033390: D8F01A20 0500003B
	ds_load_u16 v6, v59 offset:6144                            // 000000033398: D8F01800 0600003B
	ds_load_b128 v[22:25], v60 offset:19984                    // 0000000333A0: DBFC4E10 1600003C
	ds_load_b128 v[18:21], v60 offset:19968                    // 0000000333A8: DBFC4E00 1200003C
	ds_load_b128 v[26:29], v60 offset:19200                    // 0000000333B0: DBFC4B00 1A00003C
	ds_load_b128 v[30:33], v60 offset:19216                    // 0000000333B8: DBFC4B10 1E00003C
	s_cselect_b32 s3, -1, 0                                    // 0000000333C0: 980380C1
	s_or_b32 s4, s29, 1                                        // 0000000333C4: 8C04811D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000333C8: BF870009
	s_cmp_lt_i32 s4, s39                                       // 0000000333CC: BF042704
	s_cselect_b32 s4, -1, 0                                    // 0000000333D0: 980480C1
	s_waitcnt lgkmcnt(8)                                       // 0000000333D4: BF89FC87
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000333D8: 30040490
	s_waitcnt lgkmcnt(4)                                       // 0000000333DC: BF89FC47
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000000333E0: 300C0C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000333E4: BF8700D2
	.long 0x7f141502                                           // 0000000333E8: 7F141502
	ds_load_u16 v2, v59 offset:6960                            // 0000000333EC: D8F01B30 0200003B
	v_cvt_f16_f32_e32 v10, v6                                  // 0000000333F4: 7E141506
	s_waitcnt lgkmcnt(0)                                       // 0000000333F8: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000333FC: 30040490
	.long 0x7f161502                                           // 000000033400: 7F161502
	v_lshlrev_b32_e32 v2, 16, v5                               // 000000033404: 30040A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000033408: BF8700C1
	v_cvt_f16_f32_e32 v11, v2                                  // 00000003340C: 7E161502
	ds_load_u16 v2, v59 offset:7504                            // 000000033410: D8F01D50 0200003B
	s_waitcnt lgkmcnt(0)                                       // 000000033418: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000003341C: 30040490
	.long 0x7f181502                                           // 000000033420: 7F181502
	v_lshlrev_b32_e32 v2, 16, v4                               // 000000033424: 30040890
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000033428: BF8700C1
	v_cvt_f16_f32_e32 v12, v2                                  // 00000003342C: 7E181502
	ds_load_u16 v2, v59 offset:8048                            // 000000033430: D8F01F70 0200003B
	s_waitcnt lgkmcnt(0)                                       // 000000033438: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000003343C: 30040490
	.long 0x7f1a1502                                           // 000000033440: 7F1A1502
	v_lshlrev_b32_e32 v2, 16, v3                               // 000000033444: 30040690
	s_delay_alu instid0(VALU_DEP_1)                            // 000000033448: BF870001
	v_cvt_f16_f32_e32 v13, v2                                  // 00000003344C: 7E1A1502
	ds_load_u16 v2, v59 offset:8592                            // 000000033450: D8F02190 0200003B
	ds_load_u16 v3, v59 offset:9952                            // 000000033458: D8F026E0 0300003B
	ds_load_u16 v4, v59 offset:9408                            // 000000033460: D8F024C0 0400003B
	ds_load_u16 v5, v59 offset:8864                            // 000000033468: D8F022A0 0500003B
	ds_load_u16 v6, v59 offset:8320                            // 000000033470: D8F02080 0600003B
	s_waitcnt lgkmcnt(4)                                       // 000000033478: BF89FC47
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000003347C: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000033480: BF8700B1
	.long 0x7f1c1502                                           // 000000033484: 7F1C1502
	s_waitcnt lgkmcnt(0)                                       // 000000033488: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v6                               // 00000003348C: 30040C90
	v_cvt_f16_f32_e32 v14, v2                                  // 000000033490: 7E1C1502
	ds_load_u16 v2, v59 offset:9136                            // 000000033494: D8F023B0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000003349C: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000334A0: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000334A4: BF8700A1
	.long 0x7f1e1502                                           // 0000000334A8: 7F1E1502
	v_lshlrev_b32_e32 v2, 16, v5                               // 0000000334AC: 30040A90
	v_cvt_f16_f32_e32 v15, v2                                  // 0000000334B0: 7E1E1502
	ds_load_u16 v2, v59 offset:9680                            // 0000000334B4: D8F025D0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 0000000334BC: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000334C0: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000334C4: BF8700A1
	.long 0x7f201502                                           // 0000000334C8: 7F201502
	v_lshlrev_b32_e32 v2, 16, v4                               // 0000000334CC: 30040890
	v_cvt_f16_f32_e32 v16, v2                                  // 0000000334D0: 7E201502
	ds_load_u16 v2, v59 offset:10224                           // 0000000334D4: D8F027F0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 0000000334DC: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000334E0: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000334E4: BF8700A1
	.long 0x7f221502                                           // 0000000334E8: 7F221502
	v_lshlrev_b32_e32 v2, 16, v3                               // 0000000334EC: 30040690
	v_cvt_f16_f32_e32 v17, v2                                  // 0000000334F0: 7E221502
	v_dual_mov_b32 v2, s20 :: v_dual_mov_b32 v3, s21           // 0000000334F4: CA100014 02020015
	v_dual_mov_b32 v4, s22 :: v_dual_mov_b32 v5, s23           // 0000000334FC: CA100016 04040017
	v_dual_mov_b32 v6, s24 :: v_dual_mov_b32 v7, s25           // 000000033504: CA100018 06060019
	v_dual_mov_b32 v8, s26 :: v_dual_mov_b32 v9, s27           // 00000003350C: CA10001A 0808001B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000033514: BF870121
	v_wmma_f32_16x16x16_f16 v[61:68], v[18:25], v[10:17], v[2:9]// 000000033518: CC40403D 1C0A1512
	v_mov_b32_e32 v18, 0                                       // 000000033520: 7E240280
	v_wmma_f32_16x16x16_f16 v[61:68], v[26:33], v[10:17], v[61:68]// 000000033524: CC40403D 1CF6151A
	v_dual_mov_b32 v10, 0 :: v_dual_cndmask_b32 v11, 0x7060302, v144// 00000003352C: CA120080 0A0B20FF 07060302
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 000000033538: CA100080 0C0C0080
	v_mov_b32_e32 v14, 0                                       // 000000033540: 7E1C0280
	s_waitcnt vmcnt(7)                                         // 000000033544: BF891FF7
	s_delay_alu instid0(VALU_DEP_3)                            // 000000033548: BF870003
	v_mov_b32_dpp v10, v42 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000003354C: 7E1402FA FF00B12A
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 000000033554: CA100080 0F100080
	v_mov_b32_e32 v17, 0                                       // 00000003355C: 7E220280
	s_waitcnt vmcnt(6)                                         // 000000033560: BF891BF7
	v_mov_b32_dpp v12, v41 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000033564: 7E1802FA FF00B129
	v_perm_b32 v10, v42, v10, v11                              // 00000003356C: D644000A 042E152A
	s_waitcnt vmcnt(5)                                         // 000000033574: BF8917F7
	v_mov_b32_dpp v13, v40 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000033578: 7E1A02FA FF00B128
	s_waitcnt vmcnt(4)                                         // 000000033580: BF8913F7
	v_mov_b32_dpp v14, v39 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000033584: 7E1C02FA FF00B127
	s_waitcnt vmcnt(3)                                         // 00000003358C: BF890FF7
	v_mov_b32_dpp v15, v38 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000033590: 7E1E02FA FF00B126
	s_waitcnt vmcnt(2)                                         // 000000033598: BF890BF7
	v_mov_b32_dpp v16, v37 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000003359C: 7E2002FA FF00B125
	s_waitcnt vmcnt(1)                                         // 0000000335A4: BF8907F7
	v_mov_b32_dpp v17, v35 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000335A8: 7E2202FA FF00B123
	s_waitcnt vmcnt(0)                                         // 0000000335B0: BF8903F7
	v_mov_b32_dpp v18, v36 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000335B4: 7E2402FA FF00B124
	v_perm_b32 v12, v41, v12, v11                              // 0000000335BC: D644000C 042E1929
	v_perm_b32 v13, v40, v13, v11                              // 0000000335C4: D644000D 042E1B28
	v_perm_b32 v14, v39, v14, v11                              // 0000000335CC: D644000E 042E1D27
	v_perm_b32 v15, v38, v15, v11                              // 0000000335D4: D644000F 042E1F26
	v_perm_b32 v16, v37, v16, v11                              // 0000000335DC: D6440010 042E2125
	v_perm_b32 v17, v35, v17, v11                              // 0000000335E4: D6440011 042E2323
	v_perm_b32 v11, v36, v18, v11                              // 0000000335EC: D644000B 042E2524
	v_lshlrev_b32_e32 v18, 16, v10                             // 0000000335F4: 30241490
	v_and_b32_e32 v19, 0xffff0000, v10                         // 0000000335F8: 362614FF FFFF0000
	ds_load_b128 v[30:33], v60 offset:21520                    // 000000033600: DBFC5410 1E00003C
	ds_load_b128 v[26:29], v60 offset:21504                    // 000000033608: DBFC5400 1A00003C
	ds_load_b128 v[38:41], v60 offset:20752                    // 000000033610: DBFC5110 2600003C
	ds_load_b128 v[34:37], v60 offset:20736                    // 000000033618: DBFC5100 2200003C
	v_cmp_eq_u32_e32 vcc_lo, 0, v149                           // 000000033620: 7C952A80
	v_cvt_f16_f32_e32 v10, v18                                 // 000000033624: 7E141512
	.long 0x7f141513                                           // 000000033628: 7F141513
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003362C: BF870112
	v_cndmask_b16 v18, 0, v10, s3                              // 000000033630: D65D0012 000E1480
	v_cndmask_b16 v18, 0, v10, s4                              // 000000033638: D65D5012 00121480
	v_lshlrev_b32_e32 v10, 16, v12                             // 000000033640: 30141890
	s_or_b32 s3, s29, 2                                        // 000000033644: 8C03821D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033648: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003364C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000033650: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000033654: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000033658: BF870481
	v_cndmask_b16 v19, 0, v10, s3                              // 00000003365C: D65D0013 000E1480
	v_and_b32_e32 v10, 0xffff0000, v12                         // 000000033664: 361418FF FFFF0000
	s_or_b32 s3, s29, 3                                        // 00000003366C: 8C03831D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033670: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000033674: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000033678: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003367C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000033680: BF870481
	v_cndmask_b16 v19, 0, v10, s3                              // 000000033684: D65D4013 000E1480
	v_lshlrev_b32_e32 v10, 16, v13                             // 00000003368C: 30141A90
	s_or_b32 s3, s29, 4                                        // 000000033690: 8C03841D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033694: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000033698: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003369C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000336A0: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000336A4: BF870481
	v_cndmask_b16 v20, 0, v10, s3                              // 0000000336A8: D65D0014 000E1480
	v_and_b32_e32 v10, 0xffff0000, v13                         // 0000000336B0: 36141AFF FFFF0000
	s_or_b32 s3, s29, 5                                        // 0000000336B8: 8C03851D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000336BC: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000336C0: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000336C4: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000336C8: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000336CC: BF870481
	v_cndmask_b16 v20, 0, v10, s3                              // 0000000336D0: D65D4014 000E1480
	v_lshlrev_b32_e32 v10, 16, v14                             // 0000000336D8: 30141C90
	s_or_b32 s3, s29, 6                                        // 0000000336DC: 8C03861D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000336E0: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000336E4: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000336E8: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000336EC: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000336F0: BF870481
	v_cndmask_b16 v21, 0, v10, s3                              // 0000000336F4: D65D0015 000E1480
	v_and_b32_e32 v10, 0xffff0000, v14                         // 0000000336FC: 36141CFF FFFF0000
	s_or_b32 s3, s29, 7                                        // 000000033704: 8C03871D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033708: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003370C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000033710: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000033714: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000033718: BF870481
	v_cndmask_b16 v21, 0, v10, s3                              // 00000003371C: D65D4015 000E1480
	v_lshlrev_b32_e32 v10, 16, v15                             // 000000033724: 30141E90
	s_or_b32 s3, s29, 8                                        // 000000033728: 8C03881D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003372C: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000033730: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000033734: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000033738: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003373C: BF870481
	v_cndmask_b16 v22, 0, v10, s3                              // 000000033740: D65D0016 000E1480
	v_and_b32_e32 v10, 0xffff0000, v15                         // 000000033748: 36141EFF FFFF0000
	s_or_b32 s3, s29, 9                                        // 000000033750: 8C03891D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033754: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000033758: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003375C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000033760: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000033764: BF870481
	v_cndmask_b16 v22, 0, v10, s3                              // 000000033768: D65D4016 000E1480
	v_lshlrev_b32_e32 v10, 16, v16                             // 000000033770: 30142090
	s_or_b32 s3, s29, 10                                       // 000000033774: 8C038A1D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033778: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003377C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000033780: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000033784: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000033788: BF870481
	v_cndmask_b16 v23, 0, v10, s3                              // 00000003378C: D65D0017 000E1480
	v_and_b32_e32 v10, 0xffff0000, v16                         // 000000033794: 361420FF FFFF0000
	s_or_b32 s3, s29, 11                                       // 00000003379C: 8C038B1D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000337A0: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000337A4: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000337A8: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000337AC: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000337B0: BF870481
	v_cndmask_b16 v23, 0, v10, s3                              // 0000000337B4: D65D4017 000E1480
	v_lshlrev_b32_e32 v10, 16, v17                             // 0000000337BC: 30142290
	s_or_b32 s3, s29, 12                                       // 0000000337C0: 8C038C1D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000337C4: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000337C8: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000337CC: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000337D0: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000337D4: BF870481
	v_cndmask_b16 v24, 0, v10, s3                              // 0000000337D8: D65D0018 000E1480
	v_and_b32_e32 v10, 0xffff0000, v17                         // 0000000337E0: 361422FF FFFF0000
	s_or_b32 s3, s29, 13                                       // 0000000337E8: 8C038D1D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000337EC: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000337F0: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000337F4: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000337F8: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000337FC: BF870481
	v_cndmask_b16 v24, 0, v10, s3                              // 000000033800: D65D4018 000E1480
	v_lshlrev_b32_e32 v10, 16, v11                             // 000000033808: 30141690
	s_or_b32 s3, s29, 14                                       // 00000003380C: 8C038E1D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033810: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000033814: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000033818: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003381C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000033820: BF870481
	v_cndmask_b16 v25, 0, v10, s3                              // 000000033824: D65D0019 000E1480
	v_and_b32_e32 v10, 0xffff0000, v11                         // 00000003382C: 361416FF FFFF0000
	s_or_b32 s3, s29, 15                                       // 000000033834: 8C038F1D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033838: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003383C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000033840: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000033844: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000033848: BF870481
	v_cndmask_b16 v25, 0, v10, s3                              // 00000003384C: D65D4019 000E1480
	s_waitcnt lgkmcnt(2)                                       // 000000033854: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000033858: BF8700A1
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[18:25], v[2:9]// 00000003385C: CC40400A 1C0A251A
	s_waitcnt lgkmcnt(0)                                       // 000000033864: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[34:41], v[18:25], v[10:17]// 000000033868: CC40400A 1C2A2522
	v_cvt_f16_f32_e32 v18, v61                                 // 000000033870: 7E24153D
	v_mad_u32_u24 v22, 0x110, v149, v59                        // 000000033874: D60B0016 04EF2AFF 00000110
	.long 0x7f24153e                                           // 000000033880: 7F24153E
	v_cvt_f16_f32_e32 v19, v63                                 // 000000033884: 7E26153F
	.long 0x7f261540                                           // 000000033888: 7F261540
	v_cvt_f16_f32_e32 v20, v65                                 // 00000003388C: 7E281541
	.long 0x7f281542                                           // 000000033890: 7F281542
	v_cvt_f16_f32_e32 v21, v67                                 // 000000033894: 7E2A1543
	.long 0x7f2a1544                                           // 000000033898: 7F2A1544
	ds_store_b16 v22, v18 offset:14848                         // 00000003389C: D87C3A00 00001216
	ds_store_b16_d16_hi v22, v18 offset:15392                  // 0000000338A4: DA843C20 00001216
	ds_store_b16 v22, v19 offset:15936                         // 0000000338AC: D87C3E40 00001316
	ds_store_b16_d16_hi v22, v19 offset:16480                  // 0000000338B4: DA844060 00001316
	ds_store_b16 v22, v20 offset:17024                         // 0000000338BC: D87C4280 00001416
	ds_store_b16_d16_hi v22, v20 offset:17568                  // 0000000338C4: DA8444A0 00001416
	ds_store_b16 v22, v21 offset:18112                         // 0000000338CC: D87C46C0 00001516
	ds_store_b16_d16_hi v22, v21 offset:18656                  // 0000000338D4: DA8448E0 00001516
	v_fma_mixlo_f16 v18, v139, s51, 0                          // 0000000338DC: CC210012 0200678B
	v_fma_mixhi_f16 v18, v138, s51, 0                          // 0000000338E4: CC220012 0200678A
	v_cndmask_b32_e32 v61, 0x5040100, v144, vcc_lo             // 0000000338EC: 027B20FF 05040100
	v_cndmask_b32_e32 v62, 0x7060302, v145, vcc_lo             // 0000000338F4: 027D22FF 07060302
	s_waitcnt lgkmcnt(0)                                       // 0000000338FC: BF89FC07
	s_barrier                                                  // 000000033900: BFBD0000
	ds_load_b128 v[46:49], v57 offset:14864                    // 000000033904: DBFC3A10 2E000039
	ds_load_b128 v[42:45], v57 offset:14848                    // 00000003390C: DBFC3A00 2A000039
	ds_load_b128 v[67:70], v57 offset:14896                    // 000000033914: DBFC3A30 43000039
	ds_load_b128 v[63:66], v57 offset:14880                    // 00000003391C: DBFC3A20 3F000039
	v_mov_b32_e32 v19, v18                                     // 000000033924: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033928: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000003392C: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v26, v18, v19, v61                              // 000000033938: D644001A 04F62712
	v_perm_b32 v27, v18, v19, v62                              // 000000033940: D644001B 04FA2712
	v_fma_mixlo_f16 v18, v137, s51, 0                          // 000000033948: CC210012 02006789
	v_fma_mixhi_f16 v18, v136, s51, 0                          // 000000033950: CC220012 02006788
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033958: BF870091
	v_mov_b32_e32 v19, v18                                     // 00000003395C: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000033960: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000003396C: BF8700C1
	v_perm_b32 v28, v18, v19, v61                              // 000000033970: D644001C 04F62712
	v_perm_b32 v29, v18, v19, v62                              // 000000033978: D644001D 04FA2712
	v_fma_mixlo_f16 v18, v135, s51, 0                          // 000000033980: CC210012 02006787
	v_fma_mixhi_f16 v18, v134, s51, 0                          // 000000033988: CC220012 02006786
	v_mov_b32_e32 v19, v18                                     // 000000033990: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033994: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000033998: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v30, v18, v19, v61                              // 0000000339A4: D644001E 04F62712
	v_perm_b32 v31, v18, v19, v62                              // 0000000339AC: D644001F 04FA2712
	v_fma_mixlo_f16 v18, v133, s51, 0                          // 0000000339B4: CC210012 02006785
	v_fma_mixhi_f16 v18, v54, s51, 0                           // 0000000339BC: CC220012 02006736
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000339C4: BF870091
	v_mov_b32_e32 v19, v18                                     // 0000000339C8: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 0000000339CC: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000339D8: BF8700C1
	v_perm_b32 v32, v18, v19, v61                              // 0000000339DC: D6440020 04F62712
	v_perm_b32 v33, v18, v19, v62                              // 0000000339E4: D6440021 04FA2712
	v_fma_mixlo_f16 v18, v132, s51, 0                          // 0000000339EC: CC210012 02006784
	v_fma_mixhi_f16 v18, v131, s51, 0                          // 0000000339F4: CC220012 02006783
	v_mov_b32_e32 v19, v18                                     // 0000000339FC: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033A00: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000033A04: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v34, v18, v19, v61                              // 000000033A10: D6440022 04F62712
	v_perm_b32 v35, v18, v19, v62                              // 000000033A18: D6440023 04FA2712
	v_fma_mixlo_f16 v18, v130, s51, 0                          // 000000033A20: CC210012 02006782
	v_fma_mixhi_f16 v18, v129, s51, 0                          // 000000033A28: CC220012 02006781
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033A30: BF870091
	v_mov_b32_e32 v19, v18                                     // 000000033A34: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000033A38: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000033A44: BF8700C1
	v_perm_b32 v36, v18, v19, v61                              // 000000033A48: D6440024 04F62712
	v_perm_b32 v37, v18, v19, v62                              // 000000033A50: D6440025 04FA2712
	v_fma_mixlo_f16 v18, v128, s51, 0                          // 000000033A58: CC210012 02006780
	v_fma_mixhi_f16 v18, v127, s51, 0                          // 000000033A60: CC220012 0200677F
	v_mov_b32_e32 v19, v18                                     // 000000033A68: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033A6C: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000033A70: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v38, v18, v19, v61                              // 000000033A7C: D6440026 04F62712
	v_perm_b32 v39, v18, v19, v62                              // 000000033A84: D6440027 04FA2712
	v_fma_mixlo_f16 v18, v126, s51, 0                          // 000000033A8C: CC210012 0200677E
	v_fma_mixhi_f16 v18, v53, s51, 0                           // 000000033A94: CC220012 02006735
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000033A9C: BF870091
	v_mov_b32_e32 v19, v18                                     // 000000033AA0: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000033AA4: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000033AB0: BF8700D1
	v_perm_b32 v40, v18, v19, v61                              // 000000033AB4: D6440028 04F62712
	v_perm_b32 v41, v18, v19, v62                              // 000000033ABC: D6440029 04FA2712
	s_waitcnt lgkmcnt(2)                                       // 000000033AC4: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[26:33], v[2:9]// 000000033AC8: CC404012 1C0A352A
	s_waitcnt lgkmcnt(0)                                       // 000000033AD0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[63:70], v[34:41], v[18:25]// 000000033AD4: CC404012 1C4A453F
	ds_load_b128 v[63:66], v57 offset:10496                    // 000000033ADC: DBFC2900 3F000039
	ds_load_b128 v[67:70], v57 offset:10512                    // 000000033AE4: DBFC2910 43000039
	s_waitcnt lgkmcnt(0)                                       // 000000033AEC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[63:70], v[26:33], v[2:9]// 000000033AF0: CC40402A 1C0A353F
	ds_load_b128 v[26:29], v57 offset:10528                    // 000000033AF8: DBFC2920 1A000039
	ds_load_b128 v[30:33], v57 offset:10544                    // 000000033B00: DBFC2930 1E000039
	s_waitcnt lgkmcnt(0)                                       // 000000033B08: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[26:33], v[34:41], v[42:49]// 000000033B0C: CC40402A 1CAA451A
	v_fma_mixlo_f16 v27, v125, s51, 0                          // 000000033B14: CC21001B 0200677D
	v_fma_mixhi_f16 v27, v124, s51, 0                          // 000000033B1C: CC22001B 0200677C
	v_fma_mixlo_f16 v29, v123, s51, 0                          // 000000033B24: CC21001D 0200677B
	v_fma_mixhi_f16 v29, v122, s51, 0                          // 000000033B2C: CC22001D 0200677A
	v_fma_mixlo_f16 v31, v121, s51, 0                          // 000000033B34: CC21001F 02006779
	v_fma_mixhi_f16 v31, v120, s51, 0                          // 000000033B3C: CC22001F 02006778
	v_fma_mixlo_f16 v33, v119, s51, 0                          // 000000033B44: CC210021 02006777
	v_fma_mixhi_f16 v33, v52, s51, 0                           // 000000033B4C: CC220021 02006734
	v_mov_b32_e32 v28, v27                                     // 000000033B54: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000033B58: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000033B5C: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033B60: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000033B64: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000033B68: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033B74: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000033B78: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000033B84: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033B90: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000033B94: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 000000033BA0: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 000000033BA8: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000033BB0: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000033BB8: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000033BC0: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000033BC8: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000033BD0: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000033BD8: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14928                    // 000000033BE0: DBFC3A50 26000039
	ds_load_b128 v[34:37], v57 offset:14912                    // 000000033BE8: DBFC3A40 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000033BF0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000033BF4: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10576                    // 000000033BFC: DBFC2950 26000039
	ds_load_b128 v[34:37], v57 offset:10560                    // 000000033C04: DBFC2940 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000033C0C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000033C10: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v118, s51, 0                          // 000000033C18: CC21001B 02006776
	v_fma_mixhi_f16 v27, v117, s51, 0                          // 000000033C20: CC22001B 02006775
	v_fma_mixlo_f16 v29, v116, s51, 0                          // 000000033C28: CC21001D 02006774
	v_fma_mixhi_f16 v29, v115, s51, 0                          // 000000033C30: CC22001D 02006773
	v_fma_mixlo_f16 v31, v114, s51, 0                          // 000000033C38: CC21001F 02006772
	v_fma_mixhi_f16 v31, v113, s51, 0                          // 000000033C40: CC22001F 02006771
	v_fma_mixlo_f16 v33, v112, s51, 0                          // 000000033C48: CC210021 02006770
	v_fma_mixhi_f16 v33, v51, s51, 0                           // 000000033C50: CC220021 02006733
	v_mov_b32_e32 v28, v27                                     // 000000033C58: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000033C5C: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000033C60: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033C64: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000033C68: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000033C6C: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033C78: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000033C7C: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000033C88: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033C94: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000033C98: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 000000033CA4: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 000000033CAC: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000033CB4: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000033CBC: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000033CC4: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000033CCC: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000033CD4: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000033CDC: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14960                    // 000000033CE4: DBFC3A70 26000039
	ds_load_b128 v[34:37], v57 offset:14944                    // 000000033CEC: DBFC3A60 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000033CF4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000033CF8: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10608                    // 000000033D00: DBFC2970 26000039
	ds_load_b128 v[34:37], v57 offset:10592                    // 000000033D08: DBFC2960 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000033D10: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000033D14: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v111, s51, 0                          // 000000033D1C: CC21001B 0200676F
	v_fma_mixhi_f16 v27, v110, s51, 0                          // 000000033D24: CC22001B 0200676E
	v_fma_mixlo_f16 v29, v109, s51, 0                          // 000000033D2C: CC21001D 0200676D
	v_fma_mixhi_f16 v29, v108, s51, 0                          // 000000033D34: CC22001D 0200676C
	v_fma_mixlo_f16 v31, v107, s51, 0                          // 000000033D3C: CC21001F 0200676B
	v_fma_mixhi_f16 v31, v106, s51, 0                          // 000000033D44: CC22001F 0200676A
	v_fma_mixlo_f16 v33, v105, s51, 0                          // 000000033D4C: CC210021 02006769
	v_fma_mixhi_f16 v33, v50, s51, 0                           // 000000033D54: CC220021 02006732
	v_mov_b32_e32 v28, v27                                     // 000000033D5C: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000033D60: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000033D64: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033D68: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000033D6C: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000033D70: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033D7C: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000033D80: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000033D8C: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033D98: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000033D9C: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 000000033DA8: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 000000033DB0: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000033DB8: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000033DC0: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000033DC8: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000033DD0: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000033DD8: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000033DE0: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14992                    // 000000033DE8: DBFC3A90 26000039
	ds_load_b128 v[34:37], v57 offset:14976                    // 000000033DF0: DBFC3A80 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000033DF8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000033DFC: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10640                    // 000000033E04: DBFC2990 26000039
	ds_load_b128 v[34:37], v57 offset:10624                    // 000000033E0C: DBFC2980 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000033E14: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000033E18: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v104, s51, 0                          // 000000033E20: CC21001B 02006768
	v_fma_mixhi_f16 v27, v103, s51, 0                          // 000000033E28: CC22001B 02006767
	v_fma_mixlo_f16 v29, v102, s51, 0                          // 000000033E30: CC21001D 02006766
	v_fma_mixhi_f16 v29, v101, s51, 0                          // 000000033E38: CC22001D 02006765
	v_fma_mixlo_f16 v31, v100, s51, 0                          // 000000033E40: CC21001F 02006764
	v_fma_mixhi_f16 v31, v99, s51, 0                           // 000000033E48: CC22001F 02006763
	v_fma_mixlo_f16 v33, v98, s51, 0                           // 000000033E50: CC210021 02006762
	v_fma_mixhi_f16 v33, v58, s51, 0                           // 000000033E58: CC220021 0200673A
	v_mov_b32_e32 v28, v27                                     // 000000033E60: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000033E64: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000033E68: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033E6C: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000033E70: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000033E74: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033E80: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000033E84: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000033E90: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033E9C: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000033EA0: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 000000033EAC: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 000000033EB4: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000033EBC: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000033EC4: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000033ECC: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000033ED4: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000033EDC: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000033EE4: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15024                    // 000000033EEC: DBFC3AB0 26000039
	ds_load_b128 v[34:37], v57 offset:15008                    // 000000033EF4: DBFC3AA0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000033EFC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000033F00: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10672                    // 000000033F08: DBFC29B0 26000039
	ds_load_b128 v[34:37], v57 offset:10656                    // 000000033F10: DBFC29A0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000033F18: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000033F1C: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v97, s51, 0                           // 000000033F24: CC21001B 02006761
	v_fma_mixhi_f16 v27, v96, s51, 0                           // 000000033F2C: CC22001B 02006760
	v_fma_mixlo_f16 v29, v95, s51, 0                           // 000000033F34: CC21001D 0200675F
	v_fma_mixhi_f16 v29, v94, s51, 0                           // 000000033F3C: CC22001D 0200675E
	v_fma_mixlo_f16 v31, v93, s51, 0                           // 000000033F44: CC21001F 0200675D
	v_fma_mixhi_f16 v31, v92, s51, 0                           // 000000033F4C: CC22001F 0200675C
	v_fma_mixlo_f16 v33, v91, s51, 0                           // 000000033F54: CC210021 0200675B
	v_fma_mixhi_f16 v33, v147, s51, 0                          // 000000033F5C: CC220021 02006793
	v_mov_b32_e32 v28, v27                                     // 000000033F64: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000033F68: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000033F6C: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033F70: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000033F74: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000033F78: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033F84: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000033F88: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000033F94: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000033FA0: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000033FA4: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 000000033FB0: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 000000033FB8: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000033FC0: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000033FC8: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000033FD0: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000033FD8: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000033FE0: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000033FE8: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15056                    // 000000033FF0: DBFC3AD0 26000039
	ds_load_b128 v[34:37], v57 offset:15040                    // 000000033FF8: DBFC3AC0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000034000: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000034004: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10704                    // 00000003400C: DBFC29D0 26000039
	ds_load_b128 v[34:37], v57 offset:10688                    // 000000034014: DBFC29C0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000003401C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000034020: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v90, s51, 0                           // 000000034028: CC21001B 0200675A
	v_fma_mixhi_f16 v27, v89, s51, 0                           // 000000034030: CC22001B 02006759
	v_fma_mixlo_f16 v29, v88, s51, 0                           // 000000034038: CC21001D 02006758
	v_fma_mixhi_f16 v29, v87, s51, 0                           // 000000034040: CC22001D 02006757
	v_fma_mixlo_f16 v31, v86, s51, 0                           // 000000034048: CC21001F 02006756
	v_fma_mixhi_f16 v31, v84, s51, 0                           // 000000034050: CC22001F 02006754
	v_fma_mixlo_f16 v33, v85, s51, 0                           // 000000034058: CC210021 02006755
	v_fma_mixhi_f16 v33, v146, s51, 0                          // 000000034060: CC220021 02006792
	v_mov_b32_e32 v28, v27                                     // 000000034068: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000003406C: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000034070: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000034074: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000034078: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000003407C: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000034088: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000003408C: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000034098: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000340A4: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000340A8: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000340B4: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000340BC: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000340C4: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 0000000340CC: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 0000000340D4: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 0000000340DC: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 0000000340E4: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 0000000340EC: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15088                    // 0000000340F4: DBFC3AF0 26000039
	ds_load_b128 v[34:37], v57 offset:15072                    // 0000000340FC: DBFC3AE0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000034104: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000034108: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10736                    // 000000034110: DBFC29F0 26000039
	ds_load_b128 v[34:37], v57 offset:10720                    // 000000034118: DBFC29E0 22000039
	v_dual_mul_f32 v18, 0x3b800000, v18 :: v_dual_mul_f32 v19, 0x3b800000, v19// 000000034120: C8C624FF 121226FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v20 :: v_dual_mul_f32 v21, 0x3b800000, v21// 00000003412C: C8C628FF 14142AFF 3B800000
	v_mul_f32_e32 v22, 0x3b800000, v22                         // 000000034138: 102C2CFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000034140: BF870223
	v_sub_f32_e32 v10, v10, v18                                // 000000034144: 0814250A
	v_or_b32_e32 v18, s29, v149                                // 000000034148: 38252A1D
	v_dual_sub_f32 v11, v11, v19 :: v_dual_sub_f32 v12, v12, v20// 00000003414C: C94A270B 0B0C290C
	v_sub_f32_e32 v13, v13, v21                                // 000000034154: 081A2B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000034158: BF870214
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 00000003415C: CC21000A 0200610A
	v_or_b32_e32 v19, 2, v18                                   // 000000034164: 38262482
	.long 0xd4440003                                           // 000000034168: D4440003
	v_cndmask_b32_e32 v1, s39, v18, vcc_lo                     // 00000003416C: 02022427
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 000000034170: CC22000A 0200610B
	v_dual_mul_f32 v23, 0x3b800000, v23 :: v_dual_sub_f32 v14, v14, v22// 000000034178: C8CA2EFF 170E2D0E 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000034184: BF870214
	v_cmp_gt_i32_e32 vcc_lo, s39, v19                          // 000000034188: 7C882627
	v_cndmask_b16 v10, 0, v10, s3                              // 00000003418C: D65D000A 000E1480
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000034194: BF8701D3
	v_dual_mul_f32 v24, 0x3b800000, v24 :: v_dual_sub_f32 v15, v15, v23// 000000034198: C8CA30FF 180E2F0F 3B800000
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 0000000341A4: 103232FF 3B800000
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 0000000341AC: D65D500A 01AA1480
	s_waitcnt lgkmcnt(0)                                       // 0000000341B4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 0000000341B8: CC40402A 1CAA3522
	v_dual_sub_f32 v16, v16, v24 :: v_dual_sub_f32 v17, v17, v25// 0000000341C0: C94A3110 10103311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000341C8: BF8700C3
	v_mov_b32_e32 v11, v10                                     // 0000000341CC: 7E16030A
	ds_load_b128 v[19:22], v60 offset:23296                    // 0000000341D0: DBFC5B00 1300003C
	ds_load_b128 v[23:26], v60 offset:23312                    // 0000000341D8: DBFC5B10 1700003C
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 0000000341E0: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v66, v10, v11, v61                              // 0000000341EC: D6440042 04F6170A
	v_perm_b32 v67, v10, v11, v62                              // 0000000341F4: D6440043 04FA170A
	v_or_b32_e32 v10, 4, v18                                   // 0000000341FC: 38142484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000034200: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 000000034204: 7C881427
	v_or_b32_e32 v10, 6, v18                                   // 000000034208: 38142486
	.long 0xd4440004                                           // 00000003420C: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 000000034210: 02021427
	v_fma_mixlo_f16 v10, v12, s48, 0                           // 000000034214: CC21000A 0200610C
	v_fma_mixhi_f16 v10, v13, s48, 0                           // 00000003421C: CC22000A 0200610D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000034224: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000034228: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s4                              // 000000034230: D65D500A 00121480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034238: BF870091
	v_mov_b32_e32 v11, v10                                     // 00000003423C: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000034240: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000003424C: BF8700B1
	v_perm_b32 v68, v10, v11, v61                              // 000000034250: D6440044 04F6170A
	v_perm_b32 v69, v10, v11, v62                              // 000000034258: D6440045 04FA170A
	v_or_b32_e32 v10, 8, v18                                   // 000000034260: 38142488
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 000000034264: 7C881427
	v_or_b32_e32 v10, 10, v18                                  // 000000034268: 3814248A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000003426C: BF870131
	.long 0xd4440004                                           // 000000034270: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 000000034274: 02021427
	v_fma_mixlo_f16 v10, v14, s48, 0                           // 000000034278: CC21000A 0200610E
	v_fma_mixhi_f16 v10, v15, s48, 0                           // 000000034280: CC22000A 0200610F
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000034288: D65D000A 01AA1480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034290: BF870092
	v_cndmask_b16 v10, 0, v10, s4                              // 000000034294: D65D500A 00121480
	v_mov_b32_e32 v11, v10                                     // 00000003429C: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000342A0: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 0000000342A4: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v70, v10, v11, v61                              // 0000000342B0: D6440046 04F6170A
	v_perm_b32 v71, v10, v11, v62                              // 0000000342B8: D6440047 04FA170A
	v_or_b32_e32 v10, 12, v18                                  // 0000000342C0: 3814248C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000342C4: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 0000000342C8: 7C881427
	v_or_b32_e32 v10, 14, v18                                  // 0000000342CC: 3814248E
	.long 0xd4440004                                           // 0000000342D0: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 0000000342D4: 02021427
	v_fma_mixlo_f16 v10, v16, s48, 0                           // 0000000342D8: CC21000A 02006110
	v_fma_mixhi_f16 v10, v17, s48, 0                           // 0000000342E0: CC22000A 02006111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000342E8: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 0000000342EC: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s4                              // 0000000342F4: D65D500A 00121480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000342FC: BF870091
	v_mov_b32_e32 v11, v10                                     // 000000034300: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000034304: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000034310: BF8700B1
	v_perm_b32 v72, v10, v11, v61                              // 000000034314: D6440048 04F6170A
	v_perm_b32 v73, v10, v11, v62                              // 00000003431C: D6440049 04FA170A
	s_waitcnt lgkmcnt(0)                                       // 000000034324: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[19:26], v[66:73], v[2:9]// 000000034328: CC40400A 1C0A8513
	.long 0xd7000402                                           // 000000034330: D7000402
	v_cndmask_b32_e32 v1, s44, v59, vcc_lo                     // 000000034334: 0202762C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000034338: BF870001
	v_add_co_ci_u32_e64 v3, null, s45, 0, s4                   // 00000003433C: D5207C03 0011002D
	s_and_saveexec_b32 s4, s3                                  // 000000034344: BE842003
	s_cbranch_execz 19                                         // 000000034348: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3c98>
	ds_load_b32 v4, v56 offset:24320                           // 00000003434C: D8D85F00 04000038
	s_waitcnt lgkmcnt(0)                                       // 000000034354: BF89FC07
	v_mul_f32_e32 v4, v42, v4                                  // 000000034358: 1008092A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003435C: BF870091
	v_add_f32_e32 v4, v10, v4                                  // 000000034360: 0608090A
	v_mul_f32_e32 v6, 0x3b800000, v4                           // 000000034364: 100C08FF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v18, v[2:3]            // 00000003436C: D6FE7C04 040A24FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034378: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000003437C: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000034384: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000034390: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s4                              // 000000034398: 8C7E047E
	v_or3_b32 v4, v149, s29, 2                                 // 00000003439C: D6580004 02083B95
	s_mov_b32 s3, exec_lo                                      // 0000000343A4: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000343A8: BF870001
	.long 0xd4c4007e                                           // 0000000343AC: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 0000000343B0: 02020827
	s_cbranch_execz 19                                         // 0000000343B4: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d04>
	ds_load_b32 v5, v56 offset:24328                           // 0000000343B8: D8D85F08 05000038
	s_waitcnt lgkmcnt(0)                                       // 0000000343C0: BF89FC07
	v_mul_f32_e32 v5, v43, v5                                  // 0000000343C4: 100A0B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000343C8: BF870091
	v_add_f32_e32 v5, v11, v5                                  // 0000000343CC: 060A0B0B
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 0000000343D0: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 0000000343D8: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000343E4: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 0000000343E8: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000000343F0: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000000343FC: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000034404: 8C7E037E
	v_or3_b32 v4, v149, s29, 4                                 // 000000034408: D6580004 02103B95
	s_mov_b32 s3, exec_lo                                      // 000000034410: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000034414: BF870001
	.long 0xd4c4007e                                           // 000000034418: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000003441C: 02020827
	s_cbranch_execz 19                                         // 000000034420: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d70>
	ds_load_b32 v5, v56 offset:24336                           // 000000034424: D8D85F10 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000003442C: BF89FC07
	v_mul_f32_e32 v5, v44, v5                                  // 000000034430: 100A0B2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034434: BF870091
	v_add_f32_e32 v5, v12, v5                                  // 000000034438: 060A0B0C
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000003443C: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000034444: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034450: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000034454: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000003445C: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000034468: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000034470: 8C7E037E
	v_or3_b32 v4, v149, s29, 6                                 // 000000034474: D6580004 02183B95
	s_mov_b32 s3, exec_lo                                      // 00000003447C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000034480: BF870001
	.long 0xd4c4007e                                           // 000000034484: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000034488: 02020827
	s_cbranch_execz 19                                         // 00000003448C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3ddc>
	ds_load_b32 v5, v56 offset:24344                           // 000000034490: D8D85F18 05000038
	s_waitcnt lgkmcnt(0)                                       // 000000034498: BF89FC07
	v_mul_f32_e32 v5, v45, v5                                  // 00000003449C: 100A0B2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000344A0: BF870091
	v_add_f32_e32 v5, v13, v5                                  // 0000000344A4: 060A0B0D
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 0000000344A8: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 0000000344B0: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000344BC: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 0000000344C0: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000000344C8: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000000344D4: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000344DC: 8C7E037E
	v_or3_b32 v4, v149, s29, 8                                 // 0000000344E0: D6580004 02203B95
	s_mov_b32 s3, exec_lo                                      // 0000000344E8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000344EC: BF870001
	.long 0xd4c4007e                                           // 0000000344F0: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 0000000344F4: 02020827
	s_cbranch_execz 19                                         // 0000000344F8: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3e48>
	ds_load_b32 v5, v56 offset:24352                           // 0000000344FC: D8D85F20 05000038
	s_waitcnt lgkmcnt(0)                                       // 000000034504: BF89FC07
	v_mul_f32_e32 v5, v46, v5                                  // 000000034508: 100A0B2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003450C: BF870091
	v_add_f32_e32 v5, v14, v5                                  // 000000034510: 060A0B0E
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000034514: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000003451C: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034528: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000003452C: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000034534: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000034540: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000034548: 8C7E037E
	v_or3_b32 v4, v149, s29, 10                                // 00000003454C: D6580004 02283B95
	s_mov_b32 s3, exec_lo                                      // 000000034554: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000034558: BF870001
	.long 0xd4c4007e                                           // 00000003455C: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000034560: 02020827
	s_cbranch_execz 19                                         // 000000034564: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3eb4>
	ds_load_b32 v5, v56 offset:24360                           // 000000034568: D8D85F28 05000038
	s_waitcnt lgkmcnt(0)                                       // 000000034570: BF89FC07
	v_mul_f32_e32 v5, v47, v5                                  // 000000034574: 100A0B2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034578: BF870091
	v_add_f32_e32 v5, v15, v5                                  // 00000003457C: 060A0B0F
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000034580: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000034588: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034594: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000034598: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000000345A0: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000000345AC: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000345B4: 8C7E037E
	v_or3_b32 v4, v149, s29, 12                                // 0000000345B8: D6580004 02303B95
	s_mov_b32 s3, exec_lo                                      // 0000000345C0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000345C4: BF870001
	.long 0xd4c4007e                                           // 0000000345C8: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 0000000345CC: 02020827
	s_cbranch_execz 19                                         // 0000000345D0: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3f20>
	ds_load_b32 v5, v56 offset:24368                           // 0000000345D4: D8D85F30 05000038
	s_waitcnt lgkmcnt(0)                                       // 0000000345DC: BF89FC07
	v_mul_f32_e32 v5, v48, v5                                  // 0000000345E0: 100A0B30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000345E4: BF870091
	v_add_f32_e32 v5, v16, v5                                  // 0000000345E8: 060A0B10
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 0000000345EC: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 0000000345F4: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034600: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000034604: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000003460C: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000034618: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000034620: 8C7E037E
	v_or3_b32 v4, v149, s29, 14                                // 000000034624: D6580004 02383B95
	s_mov_b32 s3, exec_lo                                      // 00000003462C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000034630: BF870001
	.long 0xd4c4007e                                           // 000000034634: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000034638: 02020827
	s_cbranch_execz 19                                         // 00000003463C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3f8c>
	ds_load_b32 v5, v56 offset:24376                           // 000000034640: D8D85F38 05000038
	v_mad_u64_u32 v[2:3], null, 0x3000, v4, v[2:3]             // 000000034648: D6FE7C02 040A08FF 00003000
	s_waitcnt lgkmcnt(0)                                       // 000000034654: BF89FC07
	v_mul_f32_e32 v5, v49, v5                                  // 000000034658: 100A0B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003465C: BF870091
	v_add_f32_e32 v5, v17, v5                                  // 000000034660: 060A0B11
	v_mul_f32_e32 v5, 0x3b800000, v5                           // 000000034664: 100A0AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003466C: BF870091
	v_bfe_u32 v6, v5, 16, 1                                    // 000000034670: D6100006 02052105
	v_add3_u32 v4, v5, v6, 0x7fff                              // 000000034678: D6550004 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 000000034684: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003468C: 8C7E037E
	ds_load_b32 v56, v1 offset:24188                           // 000000034690: D8D85E7C 38000001
	v_mad_u32_u24 v2, v55, 48, 0x4b00                          // 000000034698: D60B0002 03FD6137 00004B00
	v_dual_mov_b32 v173, s27 :: v_dual_mov_b32 v170, s24       // 0000000346A4: CA10001B ADAA0018
	v_dual_mov_b32 v168, s22 :: v_dual_mov_b32 v167, s21       // 0000000346AC: CA100016 A8A60015
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000346B4: BF870003
	v_dual_mov_b32 v172, s26 :: v_dual_add_nc_u32 v55, 0xffffb500, v2// 0000000346B8: CA20001A AC3604FF FFFFB500
	v_mov_b32_e32 v166, s20                                    // 0000000346C4: 7F4C0214
	s_add_i32 s29, s29, 16                                     // 0000000346C8: 811D901D
	ds_load_b128 v[154:157], v55 offset:2320                   // 0000000346CC: DBFC0910 9A000037
	ds_load_b128 v[150:153], v55 offset:2304                   // 0000000346D4: DBFC0900 96000037
	ds_load_b128 v[162:165], v55 offset:3088                   // 0000000346DC: DBFC0C10 A2000037
	ds_load_b128 v[158:161], v55 offset:3072                   // 0000000346E4: DBFC0C00 9E000037
	ds_load_b128 v[2:5], v55                                   // 0000000346EC: DBFC0000 02000037
	ds_load_b128 v[6:9], v55 offset:16                         // 0000000346F4: DBFC0010 06000037
	ds_load_b128 v[182:185], v55 offset:4608                   // 0000000346FC: DBFC1200 B6000037
	ds_load_b128 v[178:181], v55 offset:3856                   // 000000034704: DBFC0F10 B2000037
	ds_load_b128 v[174:177], v55 offset:3840                   // 00000003470C: DBFC0F00 AE000037
	ds_load_b128 v[186:189], v55 offset:4624                   // 000000034714: DBFC1210 BA000037
	v_mov_b32_e32 v171, s25                                    // 00000003471C: 7F560219
	v_mov_b32_e32 v169, s23                                    // 000000034720: 7F520217
	s_waitcnt lgkmcnt(10)                                      // 000000034724: BF89FCA7
	v_readfirstlane_b32 s3, v56                                // 000000034728: 7E060538
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v56                  // 00000003472C: 7C3670FF C2CE8ED0
	s_mul_f32 s3, s3, 0x3fb8aa3b                               // 000000034734: A203FF03 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 00000003473C: BF87000B
	s_xor_b32 s4, s3, 0x80000000                               // 000000034740: 8D04FF03 80000000
	s_cmp_lg_u32 s12, s29                                      // 000000034748: BF071D0C
	v_fma_f32 v10, 0x3fb8aa3b, v56, s4                         // 00000003474C: D613000A 001270FF 3FB8AA3B
	s_rndne_f32 s4, s3                                         // 000000034758: BE846303
	s_waitcnt lgkmcnt(4)                                       // 00000003475C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[34:41], v[2:9], v[66:73], v[166:173]// 000000034760: CC404022 1E9A8502
	s_delay_alu instid0(VALU_DEP_2)                            // 000000034768: BF870002
	v_fmac_f32_e32 v10, 0x32a5705f, v56                        // 00000003476C: 561470FF 32A5705F
	s_sub_f32 s3, s3, s4                                       // 000000034774: A0830403
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_3)    // 000000034778: BF870581
	v_add_f32_e32 v18, s3, v10                                 // 00000003477C: 06241403
	s_cvt_i32_f32 s3, s4                                       // 000000034780: BE836604
	ds_load_b128 v[14:17], v55 offset:784                      // 000000034784: DBFC0310 0E000037
	ds_load_b128 v[10:13], v55 offset:768                      // 00000003478C: DBFC0300 0A000037
	ds_load_b128 v[46:49], v55 offset:1552                     // 000000034794: DBFC0610 2E000037
	ds_load_b128 v[42:45], v55 offset:1536                     // 00000003479C: DBFC0600 2A000037
	v_exp_f32_e32 v18, v18                                     // 0000000347A4: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000347A8: BF870095
	.long 0xd71c0012                                           // 0000000347AC: D71C0012
	v_cndmask_b32_e32 v0, v18, v3, vcc_lo                      // 0000000347B0: 02000712
	v_cndmask_b32_e32 v2, 0, v18, vcc_lo                       // 0000000347B4: 02042480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v56                  // 0000000347B8: 7C3C70FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000347C0: BF870092
	v_cndmask_b32_e32 v190, 0x7f800000, v2, vcc_lo             // 0000000347C4: 037C04FF 7F800000
	v_fmac_f32_e32 v41, v54, v190                              // 0000000347CC: 56537D36
	s_waitcnt lgkmcnt(2)                                       // 0000000347D0: BF89FC27
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[66:73], v[166:173]// 0000000347D4: CC40401A 1E9A850A
	v_wmma_f32_16x16x16_f16 v[10:17], v[150:157], v[66:73], v[166:173]// 0000000347DC: CC40400A 1E9A8596
	ds_load_b128 v[154:157], v55 offset:5392                   // 0000000347E4: DBFC1510 9A000037
	ds_load_b128 v[150:153], v55 offset:5376                   // 0000000347EC: DBFC1500 96000037
	s_waitcnt lgkmcnt(2)                                       // 0000000347F4: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[66:73], v[166:173]// 0000000347F8: CC404012 1E9A852A
	v_wmma_f32_16x16x16_f16 v[2:9], v[158:165], v[66:73], v[166:173]// 000000034800: CC404002 1E9A859E
	v_wmma_f32_16x16x16_f16 v[42:49], v[174:181], v[66:73], v[166:173]// 000000034808: CC40402A 1E9A85AE
	v_fma_f32 v136, v136, v190, v37                            // 000000034810: D6130088 04977D88
	v_fma_f32 v135, v135, v190, v38                            // 000000034818: D6130087 049B7D87
	v_fma_f32 v133, v133, v190, v40                            // 000000034820: D6130085 04A37D85
	v_fma_f32 v131, v131, v190, v27                            // 000000034828: D6130083 046F7D83
	v_fma_f32 v128, v128, v190, v30                            // 000000034830: D6130080 047B7D80
	v_fmac_f32_e32 v33, v53, v190                              // 000000034838: 56437D35
	v_fmac_f32_e32 v25, v52, v190                              // 00000003483C: 56337D34
	v_fmac_f32_e32 v17, v51, v190                              // 000000034840: 56237D33
	v_fmac_f32_e32 v9, v50, v190                               // 000000034844: 56137D32
	v_wmma_f32_16x16x16_f16 v[50:57], v[182:189], v[66:73], v[166:173]// 000000034848: CC404032 1E9A85B6
	v_fmac_f32_e32 v49, v58, v190                              // 000000034850: 56637D3A
	v_fma_f32 v139, v139, v190, v34                            // 000000034854: D613008B 048B7D8B
	s_waitcnt lgkmcnt(0)                                       // 00000003485C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[58:65], v[150:157], v[66:73], v[166:173]// 000000034860: CC40403A 1E9A8596
	v_fma_f32 v138, v138, v190, v35                            // 000000034868: D613008A 048F7D8A
	v_fma_f32 v137, v137, v190, v36                            // 000000034870: D6130089 04937D89
	v_fma_f32 v134, v134, v190, v39                            // 000000034878: D6130086 049F7D86
	v_fma_f32 v132, v132, v190, v26                            // 000000034880: D6130084 046B7D84
	v_fma_f32 v130, v130, v190, v28                            // 000000034888: D6130082 04737D82
	v_fma_f32 v129, v129, v190, v29                            // 000000034890: D6130081 04777D81
	v_fma_f32 v127, v127, v190, v31                            // 000000034898: D613007F 047F7D7F
	v_fma_f32 v126, v126, v190, v32                            // 0000000348A0: D613007E 04837D7E
	v_fma_f32 v125, v125, v190, v18                            // 0000000348A8: D613007D 044B7D7D
	v_fma_f32 v124, v124, v190, v19                            // 0000000348B0: D613007C 044F7D7C
	v_fma_f32 v123, v123, v190, v20                            // 0000000348B8: D613007B 04537D7B
	v_fma_f32 v122, v122, v190, v21                            // 0000000348C0: D613007A 04577D7A
	v_fma_f32 v121, v121, v190, v22                            // 0000000348C8: D6130079 045B7D79
	v_fma_f32 v120, v120, v190, v23                            // 0000000348D0: D6130078 045F7D78
	v_fma_f32 v119, v119, v190, v24                            // 0000000348D8: D6130077 04637D77
	v_fma_f32 v118, v118, v190, v10                            // 0000000348E0: D6130076 042B7D76
	v_fma_f32 v117, v117, v190, v11                            // 0000000348E8: D6130075 042F7D75
	v_fma_f32 v116, v116, v190, v12                            // 0000000348F0: D6130074 04337D74
	v_fma_f32 v115, v115, v190, v13                            // 0000000348F8: D6130073 04377D73
	v_fma_f32 v114, v114, v190, v14                            // 000000034900: D6130072 043B7D72
	v_fma_f32 v113, v113, v190, v15                            // 000000034908: D6130071 043F7D71
	v_fma_f32 v112, v112, v190, v16                            // 000000034910: D6130070 04437D70
	v_fma_f32 v111, v111, v190, v2                             // 000000034918: D613006F 040B7D6F
	v_fma_f32 v110, v110, v190, v3                             // 000000034920: D613006E 040F7D6E
	v_fma_f32 v109, v109, v190, v4                             // 000000034928: D613006D 04137D6D
	v_fma_f32 v108, v108, v190, v5                             // 000000034930: D613006C 04177D6C
	v_fma_f32 v107, v107, v190, v6                             // 000000034938: D613006B 041B7D6B
	v_fma_f32 v106, v106, v190, v7                             // 000000034940: D613006A 041F7D6A
	v_fma_f32 v105, v105, v190, v8                             // 000000034948: D6130069 04237D69
	v_fma_f32 v104, v104, v190, v42                            // 000000034950: D6130068 04AB7D68
	v_fma_f32 v103, v103, v190, v43                            // 000000034958: D6130067 04AF7D67
	v_fma_f32 v102, v102, v190, v44                            // 000000034960: D6130066 04B37D66
	v_fma_f32 v101, v101, v190, v45                            // 000000034968: D6130065 04B77D65
	v_fma_f32 v100, v100, v190, v46                            // 000000034970: D6130064 04BB7D64
	v_fma_f32 v99, v99, v190, v47                              // 000000034978: D6130063 04BF7D63
	v_fma_f32 v98, v98, v190, v48                              // 000000034980: D6130062 04C37D62
	v_fma_f32 v97, v97, v190, v50                              // 000000034988: D6130061 04CB7D61
	v_fma_f32 v96, v96, v190, v51                              // 000000034990: D6130060 04CF7D60
	v_fma_f32 v95, v95, v190, v52                              // 000000034998: D613005F 04D37D5F
	v_fma_f32 v94, v94, v190, v53                              // 0000000349A0: D613005E 04D77D5E
	v_fma_f32 v93, v93, v190, v54                              // 0000000349A8: D613005D 04DB7D5D
	v_fma_f32 v92, v92, v190, v55                              // 0000000349B0: D613005C 04DF7D5C
	v_fma_f32 v91, v91, v190, v56                              // 0000000349B8: D613005B 04E37D5B
	v_fmac_f32_e32 v57, v147, v190                             // 0000000349C0: 56737D93
	v_fma_f32 v90, v90, v190, v58                              // 0000000349C4: D613005A 04EB7D5A
	v_fma_f32 v89, v89, v190, v59                              // 0000000349CC: D6130059 04EF7D59
	v_fma_f32 v88, v88, v190, v60                              // 0000000349D4: D6130058 04F37D58
	v_fma_f32 v87, v87, v190, v61                              // 0000000349DC: D6130057 04F77D57
	v_fma_f32 v86, v86, v190, v62                              // 0000000349E4: D6130056 04FB7D56
	v_fma_f32 v84, v84, v190, v63                              // 0000000349EC: D6130054 04FF7D54
	v_fma_f32 v85, v85, v190, v64                              // 0000000349F4: D6130055 05037D55
	v_dual_fmac_f32 v65, v146, v190 :: v_dual_mul_f32 v60, 0x3b800000, v123// 0000000349FC: C8077D92 413CF6FF 3B800000
	v_lshl_add_u32 v2, v149, 7, v148                           // 000000034A08: D6460002 06510F95
	v_dual_mul_f32 v69, 0x3b800000, v139 :: v_dual_mul_f32 v70, 0x3b800000, v138// 000000034A10: C8C716FF 454714FF 3B800000
	v_dual_mul_f32 v71, 0x3b800000, v137 :: v_dual_mul_f32 v72, 0x3b800000, v136// 000000034A1C: C8C712FF 474910FF 3B800000
	v_dual_mul_f32 v4, 0x3b800000, v135 :: v_dual_mul_f32 v73, 0x3b800000, v134// 000000034A28: C8C70EFF 04490CFF 3B800000
	v_mul_f32_e32 v8, 0x3b800000, v121                         // 000000034A34: 1010F2FF 3B800000
	v_mul_f32_e32 v146, 0x3b800000, v133                       // 000000034A3C: 11250AFF 3B800000
	v_dual_mul_f32 v147, 0x3b800000, v41 :: v_dual_mul_f32 v62, 0x3b800000, v130// 000000034A44: C8C652FF 933F04FF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v132 :: v_dual_mul_f32 v66, 0x3b800000, v126// 000000034A50: C8C708FF 0542FCFF 3B800000
	v_dual_mul_f32 v68, 0x3b800000, v131 :: v_dual_mul_f32 v63, 0x3b800000, v129// 000000034A5C: C8C706FF 443F02FF 3B800000
	v_mul_f32_e32 v52, 0x3b800000, v120                        // 000000034A68: 1068F0FF 3B800000
	v_mul_f32_e32 v6, 0x3b800000, v128                         // 000000034A70: 100D00FF 3B800000
	v_dual_mul_f32 v64, 0x3b800000, v127 :: v_dual_mul_f32 v67, 0x3b800000, v33// 000000034A78: C8C6FEFF 404242FF 3B800000
	v_dual_mul_f32 v10, 0x3b800000, v118 :: v_dual_mul_f32 v7, 0x3b800000, v125// 000000034A84: C8C6ECFF 0A06FAFF 3B800000
	v_mul_f32_e32 v56, 0x3b800000, v116                        // 000000034A90: 1070E8FF 3B800000
	v_dual_mul_f32 v59, 0x3b800000, v124 :: v_dual_mul_f32 v54, 0x3b800000, v25// 000000034A98: C8C6F8FF 3B3632FF 3B800000
	v_dual_mul_f32 v61, 0x3b800000, v122 :: v_dual_mul_f32 v58, 0x3b800000, v115// 000000034AA4: C8C6F4FF 3D3AE6FF 3B800000
	v_dual_mul_f32 v53, 0x3b800000, v119 :: v_dual_mul_f32 v50, 0x3b800000, v113// 000000034AB0: C8C6EEFF 3532E2FF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v117 :: v_dual_mul_f32 v12, 0x3b800000, v111// 000000034ABC: C8C6EAFF 370CDEFF 3B800000
	v_dual_mul_f32 v11, 0x3b800000, v114 :: v_dual_mul_f32 v40, 0x3b800000, v17// 000000034AC8: C8C6E4FF 0B2822FF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v112 :: v_dual_mul_f32 v44, 0x3b800000, v109// 000000034AD4: C8C6E0FF 332CDAFF 3B800000
	v_dual_mul_f32 v43, 0x3b800000, v110 :: v_dual_mul_f32 v14, 0x3b800000, v107// 000000034AE0: C8C6DCFF 2B0ED6FF 3B800000
	v_dual_mul_f32 v45, 0x3b800000, v108 :: v_dual_mul_f32 v46, 0x3b800000, v106// 000000034AEC: C8C6D8FF 2D2ED4FF 3B800000
	v_dual_mul_f32 v47, 0x3b800000, v105 :: v_dual_mul_f32 v42, 0x3b800000, v103// 000000034AF8: C8C6D2FF 2F2ACEFF 3B800000
	v_dual_mul_f32 v48, 0x3b800000, v9 :: v_dual_mul_f32 v15, 0x3b800000, v104// 000000034B04: C8C612FF 300ED0FF 3B800000
	v_dual_mul_f32 v35, 0x3b800000, v102 :: v_dual_mul_f32 v36, 0x3b800000, v101// 000000034B10: C8C6CCFF 2324CAFF 3B800000
	v_dual_mul_f32 v27, 0x3b800000, v100 :: v_dual_mul_f32 v38, 0x3b800000, v98// 000000034B1C: C8C6C8FF 1B26C4FF 3B800000
	v_dual_mul_f32 v37, 0x3b800000, v99 :: v_dual_mul_f32 v28, 0x3b800000, v97// 000000034B28: C8C6C6FF 251CC2FF 3B800000
	v_dual_mul_f32 v39, 0x3b800000, v49 :: v_dual_mul_f32 v32, 0x3b800000, v95// 000000034B34: C8C662FF 2720BEFF 3B800000
	v_dual_mul_f32 v31, 0x3b800000, v96 :: v_dual_mul_f32 v34, 0x3b800000, v94// 000000034B40: C8C6C0FF 1F22BCFF 3B800000
	v_dual_mul_f32 v29, 0x3b800000, v93 :: v_dual_mul_f32 v20, 0x3b800000, v92// 000000034B4C: C8C6BAFF 1D14B8FF 3B800000
	v_dual_mul_f32 v21, 0x3b800000, v91 :: v_dual_mul_f32 v22, 0x3b800000, v57// 000000034B58: C8C6B6FF 151672FF 3B800000
	v_dual_mul_f32 v30, 0x3b800000, v90 :: v_dual_mul_f32 v23, 0x3b800000, v89// 000000034B64: C8C6B4FF 1E16B2FF 3B800000
	v_dual_mul_f32 v24, 0x3b800000, v88 :: v_dual_mul_f32 v19, 0x3b800000, v85// 000000034B70: C8C6B0FF 1812AAFF 3B800000
	v_dual_mul_f32 v26, 0x3b800000, v87 :: v_dual_mul_f32 v13, 0x3b800000, v65// 000000034B7C: C8C6AEFF 1A0C82FF 3B800000
	v_mul_f32_e32 v16, 0x3b800000, v86                         // 000000034B88: 1020ACFF 3B800000
	v_mul_f32_e32 v18, 0x3b800000, v84                         // 000000034B90: 1024A8FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 000000034B98: BF89FC07
	s_barrier                                                  // 000000034B9C: BFBD0000
	s_cbranch_scc0 5                                           // 000000034BA0: BFA10005 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44b8>
	s_cmp_lg_u32 s13, s29                                      // 000000034BA4: BF071D0D
	s_cbranch_scc0 273                                         // 000000034BA8: BFA10111 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x48f0>
	s_cmp_lg_u32 s14, s29                                      // 000000034BAC: BF071D0E
	s_cbranch_scc1 61714                                       // 000000034BB0: BFA2F112 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x8fc>
	s_branch 540                                               // 000000034BB4: BFA0021C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4d28>
	v_mov_b32_e32 v148, v2                                     // 000000034BB8: 7F280302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034BBC: BF870091
	v_ashrrev_i32_e32 v149, 31, v148                           // 000000034BC0: 352B289F
	.long 0xd73c0094                                           // 000000034BC4: D73C0094
	v_cndmask_b32_e32 v1, 2, v148, vcc_lo                      // 000000034BC8: 02032882
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034BCC: BF870091
	.long 0xd7006a94                                           // 000000034BD0: D7006A94
	v_cndmask_b32_e32 v1, s16, v148, vcc_lo                    // 000000034BD4: 02032810
	v_add_co_ci_u32_e64 v149, null, s17, v149, vcc_lo          // 000000034BD8: D5207C95 01AB2A11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034BE0: BF870092
	.long 0xd7006a96                                           // 000000034BE4: D7006A96
	v_cndmask_b32_e32 v1, 0x1000, v148, vcc_lo                 // 000000034BE8: 020328FF 00001000
	v_add_co_ci_u32_e64 v151, null, 0, v149, vcc_lo            // 000000034BF0: D5207C97 01AB2A80
	.long 0xd7006a98                                           // 000000034BF8: D7006A98
	v_cndmask_b32_e32 v0, v148, v255, vcc_lo                   // 000000034BFC: 0201FF94
	.long 0x00002000                                           // 000000034C00: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000034C04: BF8700A1
	v_add_co_ci_u32_e64 v153, null, 0, v149, vcc_lo            // 000000034C08: D5207C99 01AB2A80
	.long 0xd7006a9a                                           // 000000034C10: D7006A9A
	v_cndmask_b32_e32 v1, 0x2000, v148, vcc_lo                 // 000000034C14: 020328FF 00002000
	v_add_co_ci_u32_e64 v155, null, 0, v149, vcc_lo            // 000000034C1C: D5207C9B 01AB2A80
	s_clause 0x7                                               // 000000034C24: BF850007
	global_store_b32 v[148:149], v69, off                      // 000000034C28: DC6A0000 007C4594
	global_store_b32 v[148:149], v70, off offset:1024          // 000000034C30: DC6A0400 007C4694
	global_store_b32 v[148:149], v71, off offset:2048          // 000000034C38: DC6A0800 007C4794
	global_store_b32 v[148:149], v72, off offset:3072          // 000000034C40: DC6A0C00 007C4894
	global_store_b32 v[150:151], v73, off offset:1024          // 000000034C48: DC6A0400 007C4996
	global_store_b32 v[150:151], v146, off offset:2048         // 000000034C50: DC6A0800 007C9296
	global_store_b32 v[150:151], v147, off offset:3072         // 000000034C58: DC6A0C00 007C9396
	global_store_b32 v[154:155], v68, off offset:1024          // 000000034C60: DC6A0400 007C449A
	.long 0xd7006a96                                           // 000000034C68: D7006A96
	v_cndmask_b32_e32 v1, 0x3000, v148, vcc_lo                 // 000000034C6C: 020328FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000034C74: BF8700A1
	v_add_co_ci_u32_e64 v151, null, 0, v149, vcc_lo            // 000000034C78: D5207C97 01AB2A80
	.long 0xd7006a9c                                           // 000000034C80: D7006A9C
	v_cndmask_b32_e32 v0, v148, v255, vcc_lo                   // 000000034C84: 0201FF94
	.long 0x00004000                                           // 000000034C88: 00004000
	v_add_co_ci_u32_e64 v157, null, 0, v149, vcc_lo            // 000000034C8C: D5207C9D 01AB2A80
	.long 0xd7006a9e                                           // 000000034C94: D7006A9E
	v_cndmask_b32_e32 v1, 0x4000, v148, vcc_lo                 // 000000034C98: 020328FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000034CA0: BF870001
	v_add_co_ci_u32_e64 v159, null, 0, v149, vcc_lo            // 000000034CA4: D5207C9F 01AB2A80
	s_clause 0x7                                               // 000000034CAC: BF850007
	global_store_b32 v[154:155], v62, off offset:2048          // 000000034CB0: DC6A0800 007C3E9A
	global_store_b32 v[154:155], v63, off offset:3072          // 000000034CB8: DC6A0C00 007C3F9A
	global_store_b32 v[150:151], v64, off offset:1024          // 000000034CC0: DC6A0400 007C4096
	global_store_b32 v[150:151], v66, off offset:2048          // 000000034CC8: DC6A0800 007C4296
	global_store_b32 v[150:151], v67, off offset:3072          // 000000034CD0: DC6A0C00 007C4396
	global_store_b32 v[158:159], v59, off offset:1024          // 000000034CD8: DC6A0400 007C3B9E
	global_store_b32 v[158:159], v60, off offset:2048          // 000000034CE0: DC6A0800 007C3C9E
	global_store_b32 v[158:159], v61, off offset:3072          // 000000034CE8: DC6A0C00 007C3D9E
	.long 0xd7006a96                                           // 000000034CF0: D7006A96
	v_cndmask_b32_e32 v1, 0x5000, v148, vcc_lo                 // 000000034CF4: 020328FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000034CFC: BF8700A1
	v_add_co_ci_u32_e64 v151, null, 0, v149, vcc_lo            // 000000034D00: D5207C97 01AB2A80
	.long 0xd7006a9a                                           // 000000034D08: D7006A9A
	v_cndmask_b32_e32 v0, v148, v255, vcc_lo                   // 000000034D0C: 0201FF94
	.long 0x00006000                                           // 000000034D10: 00006000
	v_add_co_ci_u32_e64 v155, null, 0, v149, vcc_lo            // 000000034D14: D5207C9B 01AB2A80
	.long 0xd7006a9e                                           // 000000034D1C: D7006A9E
	v_cndmask_b32_e32 v1, 0x6000, v148, vcc_lo                 // 000000034D20: 020328FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000034D28: BF8700A1
	v_add_co_ci_u32_e64 v159, null, 0, v149, vcc_lo            // 000000034D2C: D5207C9F 01AB2A80
	.long 0xd7006aa0                                           // 000000034D34: D7006AA0
	v_cndmask_b32_e32 v1, 0x7000, v148, vcc_lo                 // 000000034D38: 020328FF 00007000
	v_add_co_ci_u32_e64 v161, null, 0, v149, vcc_lo            // 000000034D40: D5207CA1 01AB2A80
	.long 0xd7006aa2                                           // 000000034D48: D7006AA2
	v_cndmask_b32_e32 v0, v148, v255, vcc_lo                   // 000000034D4C: 0201FF94
	.long 0x00008000                                           // 000000034D50: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000034D54: BF870001
	v_add_co_ci_u32_e64 v163, null, 0, v149, vcc_lo            // 000000034D58: D5207CA3 01AB2A80
	s_clause 0x7                                               // 000000034D60: BF850007
	global_store_b32 v[150:151], v52, off offset:1024          // 000000034D64: DC6A0400 007C3496
	global_store_b32 v[150:151], v53, off offset:2048          // 000000034D6C: DC6A0800 007C3596
	global_store_b32 v[150:151], v54, off offset:3072          // 000000034D74: DC6A0C00 007C3696
	global_store_b32 v[158:159], v55, off offset:1024          // 000000034D7C: DC6A0400 007C379E
	global_store_b32 v[158:159], v56, off offset:2048          // 000000034D84: DC6A0800 007C389E
	global_store_b32 v[158:159], v58, off offset:3072          // 000000034D8C: DC6A0C00 007C3A9E
	global_store_b32 v[160:161], v50, off offset:1024          // 000000034D94: DC6A0400 007C32A0
	global_store_b32 v[160:161], v51, off offset:2048          // 000000034D9C: DC6A0800 007C33A0
	.long 0xd7006a96                                           // 000000034DA4: D7006A96
	v_cndmask_b32_e32 v1, 0x8000, v148, vcc_lo                 // 000000034DA8: 020328FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000034DB0: BF8700A1
	v_add_co_ci_u32_e64 v151, null, 0, v149, vcc_lo            // 000000034DB4: D5207C97 01AB2A80
	.long 0xd7006a9e                                           // 000000034DBC: D7006A9E
	v_cndmask_b32_e32 v1, 0x9000, v148, vcc_lo                 // 000000034DC0: 020328FF 00009000
	v_add_co_ci_u32_e64 v159, null, 0, v149, vcc_lo            // 000000034DC8: D5207C9F 01AB2A80
	.long 0xd7006aa4                                           // 000000034DD0: D7006AA4
	v_cndmask_b32_e32 v0, v148, v255, vcc_lo                   // 000000034DD4: 0201FF94
	.long 0x0000a000                                           // 000000034DD8: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000034DDC: BF8700A1
	v_add_co_ci_u32_e64 v165, null, 0, v149, vcc_lo            // 000000034DE0: D5207CA5 01AB2A80
	.long 0xd7006aa6                                           // 000000034DE8: D7006AA6
	v_cndmask_b32_e32 v1, 0xa000, v148, vcc_lo                 // 000000034DEC: 020328FF 0000A000
	v_add_co_ci_u32_e64 v167, null, 0, v149, vcc_lo            // 000000034DF4: D5207CA7 01AB2A80
	s_clause 0x7                                               // 000000034DFC: BF850007
	global_store_b32 v[160:161], v40, off offset:3072          // 000000034E00: DC6A0C00 007C28A0
	global_store_b32 v[150:151], v43, off offset:1024          // 000000034E08: DC6A0400 007C2B96
	global_store_b32 v[150:151], v44, off offset:2048          // 000000034E10: DC6A0800 007C2C96
	global_store_b32 v[150:151], v45, off offset:3072          // 000000034E18: DC6A0C00 007C2D96
	global_store_b32 v[158:159], v46, off offset:1024          // 000000034E20: DC6A0400 007C2E9E
	global_store_b32 v[158:159], v47, off offset:2048          // 000000034E28: DC6A0800 007C2F9E
	global_store_b32 v[158:159], v48, off offset:3072          // 000000034E30: DC6A0C00 007C309E
	global_store_b32 v[166:167], v42, off offset:1024          // 000000034E38: DC6A0400 007C2AA6
	.long 0xd7006a96                                           // 000000034E40: D7006A96
	v_cndmask_b32_e32 v1, 0xb000, v148, vcc_lo                 // 000000034E44: 020328FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000034E4C: BF8700A1
	v_add_co_ci_u32_e64 v151, null, 0, v149, vcc_lo            // 000000034E50: D5207C97 01AB2A80
	.long 0xd7006a9e                                           // 000000034E58: D7006A9E
	v_cndmask_b32_e32 v0, v148, v255, vcc_lo                   // 000000034E5C: 0201FF94
	.long 0x0000c000                                           // 000000034E60: 0000C000
	v_add_co_ci_u32_e64 v159, null, 0, v149, vcc_lo            // 000000034E64: D5207C9F 01AB2A80
	.long 0xd7006aa0                                           // 000000034E6C: D7006AA0
	v_cndmask_b32_e32 v1, 0xc000, v148, vcc_lo                 // 000000034E70: 020328FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000034E78: BF870001
	v_add_co_ci_u32_e64 v161, null, 0, v149, vcc_lo            // 000000034E7C: D5207CA1 01AB2A80
	s_clause 0x7                                               // 000000034E84: BF850007
	global_store_b32 v[166:167], v35, off offset:2048          // 000000034E88: DC6A0800 007C23A6
	global_store_b32 v[166:167], v36, off offset:3072          // 000000034E90: DC6A0C00 007C24A6
	global_store_b32 v[150:151], v37, off offset:1024          // 000000034E98: DC6A0400 007C2596
	global_store_b32 v[150:151], v38, off offset:2048          // 000000034EA0: DC6A0800 007C2696
	global_store_b32 v[150:151], v39, off offset:3072          // 000000034EA8: DC6A0C00 007C2796
	global_store_b32 v[160:161], v31, off offset:1024          // 000000034EB0: DC6A0400 007C1FA0
	global_store_b32 v[160:161], v32, off offset:2048          // 000000034EB8: DC6A0800 007C20A0
	global_store_b32 v[160:161], v34, off offset:3072          // 000000034EC0: DC6A0C00 007C22A0
	.long 0xd7006a96                                           // 000000034EC8: D7006A96
	v_cndmask_b32_e32 v1, 0xd000, v148, vcc_lo                 // 000000034ECC: 020328FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000034ED4: BF8700A1
	v_add_co_ci_u32_e64 v151, null, 0, v149, vcc_lo            // 000000034ED8: D5207C97 01AB2A80
	.long 0xd7006aa0                                           // 000000034EE0: D7006AA0
	v_cndmask_b32_e32 v0, v148, v255, vcc_lo                   // 000000034EE4: 0201FF94
	.long 0x0000e000                                           // 000000034EE8: 0000E000
	v_add_co_ci_u32_e64 v161, null, 0, v149, vcc_lo            // 000000034EEC: D5207CA1 01AB2A80
	.long 0xd7006aa6                                           // 000000034EF4: D7006AA6
	v_cndmask_b32_e32 v1, 0xe000, v148, vcc_lo                 // 000000034EF8: 020328FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000034F00: BF870001
	v_add_co_ci_u32_e64 v167, null, 0, v149, vcc_lo            // 000000034F04: D5207CA7 01AB2A80
	.long 0xd7006a94                                           // 000000034F0C: D7006A94
	v_cndmask_b32_e32 v1, 0xf000, v148, vcc_lo                 // 000000034F10: 020328FF 0000F000
	s_clause 0x7                                               // 000000034F18: BF850007
	global_store_b32 v[162:163], v11, off offset:-4096         // 000000034F1C: DC6A1000 007C0BA2
	global_store_b32 v[162:163], v12, off                      // 000000034F24: DC6A0000 007C0CA2
	global_store_b32 v[164:165], v14, off offset:-4096         // 000000034F2C: DC6A1000 007C0EA4
	global_store_b32 v[164:165], v15, off                      // 000000034F34: DC6A0000 007C0FA4
	global_store_b32 v[158:159], v27, off offset:-4096         // 000000034F3C: DC6A1000 007C1B9E
	global_store_b32 v[158:159], v28, off                      // 000000034F44: DC6A0000 007C1C9E
	global_store_b32 v[160:161], v29, off offset:-4096         // 000000034F4C: DC6A1000 007C1DA0
	global_store_b32 v[160:161], v30, off                      // 000000034F54: DC6A0000 007C1EA0
	v_add_co_ci_u32_e64 v149, null, 0, v149, vcc_lo            // 000000034F5C: D5207C95 01AB2A80
	s_clause 0xf                                               // 000000034F64: BF85000F
	global_store_b32 v[150:151], v20, off offset:1024          // 000000034F68: DC6A0400 007C1496
	global_store_b32 v[150:151], v21, off offset:2048          // 000000034F70: DC6A0800 007C1596
	global_store_b32 v[150:151], v22, off offset:3072          // 000000034F78: DC6A0C00 007C1696
	global_store_b32 v[166:167], v23, off offset:1024          // 000000034F80: DC6A0400 007C17A6
	global_store_b32 v[166:167], v24, off offset:2048          // 000000034F88: DC6A0800 007C18A6
	global_store_b32 v[166:167], v26, off offset:3072          // 000000034F90: DC6A0C00 007C1AA6
	global_store_b32 v[148:149], v16, off                      // 000000034F98: DC6A0000 007C1094
	global_store_b32 v[148:149], v18, off offset:1024          // 000000034FA0: DC6A0400 007C1294
	global_store_b32 v[148:149], v19, off offset:2048          // 000000034FA8: DC6A0800 007C1394
	global_store_b32 v[152:153], v4, off offset:-4096          // 000000034FB0: DC6A1000 007C0498
	global_store_b32 v[152:153], v5, off                       // 000000034FB8: DC6A0000 007C0598
	global_store_b32 v[156:157], v6, off offset:-4096          // 000000034FC0: DC6A1000 007C069C
	global_store_b32 v[156:157], v7, off                       // 000000034FC8: DC6A0000 007C079C
	global_store_b32 v[154:155], v8, off offset:-4096          // 000000034FD0: DC6A1000 007C089A
	global_store_b32 v[154:155], v10, off                      // 000000034FD8: DC6A0000 007C0A9A
	global_store_b32 v[148:149], v13, off offset:3072          // 000000034FE0: DC6A0C00 007C0D94
	s_cmp_lg_u32 s13, s29                                      // 000000034FE8: BF071D0D
	s_cbranch_scc1 65263                                       // 000000034FEC: BFA2FEEF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44ac>
	v_mov_b32_e32 v148, v2                                     // 000000034FF0: 7F280302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000034FF4: BF870091
	v_ashrrev_i32_e32 v149, 31, v148                           // 000000034FF8: 352B289F
	.long 0xd73c0094                                           // 000000034FFC: D73C0094
	v_cndmask_b32_e32 v1, 2, v148, vcc_lo                      // 000000035000: 02032882
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035004: BF870091
	.long 0xd7006a94                                           // 000000035008: D7006A94
	v_cndmask_b32_e32 v1, s18, v148, vcc_lo                    // 00000003500C: 02032812
	v_add_co_ci_u32_e64 v149, null, s19, v149, vcc_lo          // 000000035010: D5207C95 01AB2A13
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000035018: BF870092
	.long 0xd7006a96                                           // 00000003501C: D7006A96
	v_cndmask_b32_e32 v1, 0x1000, v148, vcc_lo                 // 000000035020: 020328FF 00001000
	v_add_co_ci_u32_e64 v151, null, 0, v149, vcc_lo            // 000000035028: D5207C97 01AB2A80
	.long 0xd7006a98                                           // 000000035030: D7006A98
	v_cndmask_b32_e32 v0, v148, v255, vcc_lo                   // 000000035034: 0201FF94
	.long 0x00002000                                           // 000000035038: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003503C: BF8700A1
	v_add_co_ci_u32_e64 v153, null, 0, v149, vcc_lo            // 000000035040: D5207C99 01AB2A80
	.long 0xd7006a9a                                           // 000000035048: D7006A9A
	v_cndmask_b32_e32 v1, 0x2000, v148, vcc_lo                 // 00000003504C: 020328FF 00002000
	v_add_co_ci_u32_e64 v155, null, 0, v149, vcc_lo            // 000000035054: D5207C9B 01AB2A80
	s_clause 0x7                                               // 00000003505C: BF850007
	global_store_b32 v[148:149], v69, off                      // 000000035060: DC6A0000 007C4594
	global_store_b32 v[148:149], v70, off offset:1024          // 000000035068: DC6A0400 007C4694
	global_store_b32 v[148:149], v71, off offset:2048          // 000000035070: DC6A0800 007C4794
	global_store_b32 v[148:149], v72, off offset:3072          // 000000035078: DC6A0C00 007C4894
	global_store_b32 v[150:151], v73, off offset:1024          // 000000035080: DC6A0400 007C4996
	global_store_b32 v[150:151], v146, off offset:2048         // 000000035088: DC6A0800 007C9296
	global_store_b32 v[150:151], v147, off offset:3072         // 000000035090: DC6A0C00 007C9396
	global_store_b32 v[154:155], v68, off offset:1024          // 000000035098: DC6A0400 007C449A
	.long 0xd7006a96                                           // 0000000350A0: D7006A96
	v_cndmask_b32_e32 v1, 0x3000, v148, vcc_lo                 // 0000000350A4: 020328FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000350AC: BF8700A1
	v_add_co_ci_u32_e64 v151, null, 0, v149, vcc_lo            // 0000000350B0: D5207C97 01AB2A80
	.long 0xd7006a9c                                           // 0000000350B8: D7006A9C
	v_cndmask_b32_e32 v0, v148, v255, vcc_lo                   // 0000000350BC: 0201FF94
	.long 0x00004000                                           // 0000000350C0: 00004000
	v_add_co_ci_u32_e64 v157, null, 0, v149, vcc_lo            // 0000000350C4: D5207C9D 01AB2A80
	.long 0xd7006a9e                                           // 0000000350CC: D7006A9E
	v_cndmask_b32_e32 v1, 0x4000, v148, vcc_lo                 // 0000000350D0: 020328FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000350D8: BF870001
	v_add_co_ci_u32_e64 v159, null, 0, v149, vcc_lo            // 0000000350DC: D5207C9F 01AB2A80
	s_clause 0x7                                               // 0000000350E4: BF850007
	global_store_b32 v[154:155], v62, off offset:2048          // 0000000350E8: DC6A0800 007C3E9A
	global_store_b32 v[154:155], v63, off offset:3072          // 0000000350F0: DC6A0C00 007C3F9A
	global_store_b32 v[150:151], v64, off offset:1024          // 0000000350F8: DC6A0400 007C4096
	global_store_b32 v[150:151], v66, off offset:2048          // 000000035100: DC6A0800 007C4296
	global_store_b32 v[150:151], v67, off offset:3072          // 000000035108: DC6A0C00 007C4396
	global_store_b32 v[158:159], v59, off offset:1024          // 000000035110: DC6A0400 007C3B9E
	global_store_b32 v[158:159], v60, off offset:2048          // 000000035118: DC6A0800 007C3C9E
	global_store_b32 v[158:159], v61, off offset:3072          // 000000035120: DC6A0C00 007C3D9E
	.long 0xd7006a96                                           // 000000035128: D7006A96
	v_cndmask_b32_e32 v1, 0x5000, v148, vcc_lo                 // 00000003512C: 020328FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000035134: BF8700A1
	v_add_co_ci_u32_e64 v151, null, 0, v149, vcc_lo            // 000000035138: D5207C97 01AB2A80
	.long 0xd7006a9a                                           // 000000035140: D7006A9A
	v_cndmask_b32_e32 v0, v148, v255, vcc_lo                   // 000000035144: 0201FF94
	.long 0x00006000                                           // 000000035148: 00006000
	v_add_co_ci_u32_e64 v155, null, 0, v149, vcc_lo            // 00000003514C: D5207C9B 01AB2A80
	.long 0xd7006a9e                                           // 000000035154: D7006A9E
	v_cndmask_b32_e32 v1, 0x6000, v148, vcc_lo                 // 000000035158: 020328FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000035160: BF8700A1
	v_add_co_ci_u32_e64 v159, null, 0, v149, vcc_lo            // 000000035164: D5207C9F 01AB2A80
	.long 0xd7006aa0                                           // 00000003516C: D7006AA0
	v_cndmask_b32_e32 v1, 0x7000, v148, vcc_lo                 // 000000035170: 020328FF 00007000
	v_add_co_ci_u32_e64 v161, null, 0, v149, vcc_lo            // 000000035178: D5207CA1 01AB2A80
	.long 0xd7006aa2                                           // 000000035180: D7006AA2
	v_cndmask_b32_e32 v0, v148, v255, vcc_lo                   // 000000035184: 0201FF94
	.long 0x00008000                                           // 000000035188: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003518C: BF870001
	v_add_co_ci_u32_e64 v163, null, 0, v149, vcc_lo            // 000000035190: D5207CA3 01AB2A80
	s_clause 0x7                                               // 000000035198: BF850007
	global_store_b32 v[150:151], v52, off offset:1024          // 00000003519C: DC6A0400 007C3496
	global_store_b32 v[150:151], v53, off offset:2048          // 0000000351A4: DC6A0800 007C3596
	global_store_b32 v[150:151], v54, off offset:3072          // 0000000351AC: DC6A0C00 007C3696
	global_store_b32 v[158:159], v55, off offset:1024          // 0000000351B4: DC6A0400 007C379E
	global_store_b32 v[158:159], v56, off offset:2048          // 0000000351BC: DC6A0800 007C389E
	global_store_b32 v[158:159], v58, off offset:3072          // 0000000351C4: DC6A0C00 007C3A9E
	global_store_b32 v[160:161], v50, off offset:1024          // 0000000351CC: DC6A0400 007C32A0
	global_store_b32 v[160:161], v51, off offset:2048          // 0000000351D4: DC6A0800 007C33A0
	.long 0xd7006a96                                           // 0000000351DC: D7006A96
	v_cndmask_b32_e32 v1, 0x8000, v148, vcc_lo                 // 0000000351E0: 020328FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000351E8: BF8700A1
	v_add_co_ci_u32_e64 v151, null, 0, v149, vcc_lo            // 0000000351EC: D5207C97 01AB2A80
	.long 0xd7006a9e                                           // 0000000351F4: D7006A9E
	v_cndmask_b32_e32 v1, 0x9000, v148, vcc_lo                 // 0000000351F8: 020328FF 00009000
	v_add_co_ci_u32_e64 v159, null, 0, v149, vcc_lo            // 000000035200: D5207C9F 01AB2A80
	.long 0xd7006aa4                                           // 000000035208: D7006AA4
	v_cndmask_b32_e32 v0, v148, v255, vcc_lo                   // 00000003520C: 0201FF94
	.long 0x0000a000                                           // 000000035210: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000035214: BF8700A1
	v_add_co_ci_u32_e64 v165, null, 0, v149, vcc_lo            // 000000035218: D5207CA5 01AB2A80
	.long 0xd7006aa6                                           // 000000035220: D7006AA6
	v_cndmask_b32_e32 v1, 0xa000, v148, vcc_lo                 // 000000035224: 020328FF 0000A000
	v_add_co_ci_u32_e64 v167, null, 0, v149, vcc_lo            // 00000003522C: D5207CA7 01AB2A80
	s_clause 0x7                                               // 000000035234: BF850007
	global_store_b32 v[160:161], v40, off offset:3072          // 000000035238: DC6A0C00 007C28A0
	global_store_b32 v[150:151], v43, off offset:1024          // 000000035240: DC6A0400 007C2B96
	global_store_b32 v[150:151], v44, off offset:2048          // 000000035248: DC6A0800 007C2C96
	global_store_b32 v[150:151], v45, off offset:3072          // 000000035250: DC6A0C00 007C2D96
	global_store_b32 v[158:159], v46, off offset:1024          // 000000035258: DC6A0400 007C2E9E
	global_store_b32 v[158:159], v47, off offset:2048          // 000000035260: DC6A0800 007C2F9E
	global_store_b32 v[158:159], v48, off offset:3072          // 000000035268: DC6A0C00 007C309E
	global_store_b32 v[166:167], v42, off offset:1024          // 000000035270: DC6A0400 007C2AA6
	.long 0xd7006a96                                           // 000000035278: D7006A96
	v_cndmask_b32_e32 v1, 0xb000, v148, vcc_lo                 // 00000003527C: 020328FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000035284: BF8700A1
	v_add_co_ci_u32_e64 v151, null, 0, v149, vcc_lo            // 000000035288: D5207C97 01AB2A80
	.long 0xd7006a9e                                           // 000000035290: D7006A9E
	v_cndmask_b32_e32 v0, v148, v255, vcc_lo                   // 000000035294: 0201FF94
	.long 0x0000c000                                           // 000000035298: 0000C000
	v_add_co_ci_u32_e64 v159, null, 0, v149, vcc_lo            // 00000003529C: D5207C9F 01AB2A80
	.long 0xd7006aa0                                           // 0000000352A4: D7006AA0
	v_cndmask_b32_e32 v1, 0xc000, v148, vcc_lo                 // 0000000352A8: 020328FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000352B0: BF870001
	v_add_co_ci_u32_e64 v161, null, 0, v149, vcc_lo            // 0000000352B4: D5207CA1 01AB2A80
	s_clause 0x7                                               // 0000000352BC: BF850007
	global_store_b32 v[166:167], v35, off offset:2048          // 0000000352C0: DC6A0800 007C23A6
	global_store_b32 v[166:167], v36, off offset:3072          // 0000000352C8: DC6A0C00 007C24A6
	global_store_b32 v[150:151], v37, off offset:1024          // 0000000352D0: DC6A0400 007C2596
	global_store_b32 v[150:151], v38, off offset:2048          // 0000000352D8: DC6A0800 007C2696
	global_store_b32 v[150:151], v39, off offset:3072          // 0000000352E0: DC6A0C00 007C2796
	global_store_b32 v[160:161], v31, off offset:1024          // 0000000352E8: DC6A0400 007C1FA0
	global_store_b32 v[160:161], v32, off offset:2048          // 0000000352F0: DC6A0800 007C20A0
	global_store_b32 v[160:161], v34, off offset:3072          // 0000000352F8: DC6A0C00 007C22A0
	.long 0xd7006a96                                           // 000000035300: D7006A96
	v_cndmask_b32_e32 v1, 0xd000, v148, vcc_lo                 // 000000035304: 020328FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003530C: BF8700A1
	v_add_co_ci_u32_e64 v151, null, 0, v149, vcc_lo            // 000000035310: D5207C97 01AB2A80
	.long 0xd7006aa0                                           // 000000035318: D7006AA0
	v_cndmask_b32_e32 v0, v148, v255, vcc_lo                   // 00000003531C: 0201FF94
	.long 0x0000e000                                           // 000000035320: 0000E000
	v_add_co_ci_u32_e64 v161, null, 0, v149, vcc_lo            // 000000035324: D5207CA1 01AB2A80
	.long 0xd7006aa6                                           // 00000003532C: D7006AA6
	v_cndmask_b32_e32 v1, 0xe000, v148, vcc_lo                 // 000000035330: 020328FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000035338: BF870001
	v_add_co_ci_u32_e64 v167, null, 0, v149, vcc_lo            // 00000003533C: D5207CA7 01AB2A80
	.long 0xd7006a94                                           // 000000035344: D7006A94
	v_cndmask_b32_e32 v1, 0xf000, v148, vcc_lo                 // 000000035348: 020328FF 0000F000
	s_clause 0x7                                               // 000000035350: BF850007
	global_store_b32 v[162:163], v11, off offset:-4096         // 000000035354: DC6A1000 007C0BA2
	global_store_b32 v[162:163], v12, off                      // 00000003535C: DC6A0000 007C0CA2
	global_store_b32 v[164:165], v14, off offset:-4096         // 000000035364: DC6A1000 007C0EA4
	global_store_b32 v[164:165], v15, off                      // 00000003536C: DC6A0000 007C0FA4
	global_store_b32 v[158:159], v27, off offset:-4096         // 000000035374: DC6A1000 007C1B9E
	global_store_b32 v[158:159], v28, off                      // 00000003537C: DC6A0000 007C1C9E
	global_store_b32 v[160:161], v29, off offset:-4096         // 000000035384: DC6A1000 007C1DA0
	global_store_b32 v[160:161], v30, off                      // 00000003538C: DC6A0000 007C1EA0
	v_add_co_ci_u32_e64 v149, null, 0, v149, vcc_lo            // 000000035394: D5207C95 01AB2A80
	s_clause 0xf                                               // 00000003539C: BF85000F
	global_store_b32 v[150:151], v20, off offset:1024          // 0000000353A0: DC6A0400 007C1496
	global_store_b32 v[150:151], v21, off offset:2048          // 0000000353A8: DC6A0800 007C1596
	global_store_b32 v[150:151], v22, off offset:3072          // 0000000353B0: DC6A0C00 007C1696
	global_store_b32 v[166:167], v23, off offset:1024          // 0000000353B8: DC6A0400 007C17A6
	global_store_b32 v[166:167], v24, off offset:2048          // 0000000353C0: DC6A0800 007C18A6
	global_store_b32 v[166:167], v26, off offset:3072          // 0000000353C8: DC6A0C00 007C1AA6
	global_store_b32 v[148:149], v16, off                      // 0000000353D0: DC6A0000 007C1094
	global_store_b32 v[148:149], v18, off offset:1024          // 0000000353D8: DC6A0400 007C1294
	global_store_b32 v[148:149], v19, off offset:2048          // 0000000353E0: DC6A0800 007C1394
	global_store_b32 v[152:153], v4, off offset:-4096          // 0000000353E8: DC6A1000 007C0498
	global_store_b32 v[152:153], v5, off                       // 0000000353F0: DC6A0000 007C0598
	global_store_b32 v[156:157], v6, off offset:-4096          // 0000000353F8: DC6A1000 007C069C
	global_store_b32 v[156:157], v7, off                       // 000000035400: DC6A0000 007C079C
	global_store_b32 v[154:155], v8, off offset:-4096          // 000000035408: DC6A1000 007C089A
	global_store_b32 v[154:155], v10, off                      // 000000035410: DC6A0000 007C0A9A
	global_store_b32 v[148:149], v13, off offset:3072          // 000000035418: DC6A0C00 007C0D94
	s_cmp_lg_u32 s14, s29                                      // 000000035420: BF071D0E
	s_cbranch_scc1 61173                                       // 000000035424: BFA2EEF5 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x8fc>
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000035428: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003542C: BF870091
	.long 0xd73c0002                                           // 000000035430: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000035434: 02020482
	.long 0xd7006a02                                           // 000000035438: D7006A02
	v_cndmask_b32_e32 v1, s47, v2, vcc_lo                      // 00000003543C: 0202042F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000035440: BF870111
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 000000035444: D5207C03 01AA0607
	.long 0xd7006a94                                           // 00000003544C: D7006A94
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 000000035450: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000035458: BF8700A1
	v_add_co_ci_u32_e64 v149, null, 0, v3, vcc_lo              // 00000003545C: D5207C95 01AA0680
	.long 0xd7006a96                                           // 000000035464: D7006A96
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000035468: 0201FF02
	.long 0x00002000                                           // 00000003546C: 00002000
	v_add_co_ci_u32_e64 v151, null, 0, v3, vcc_lo              // 000000035470: D5207C97 01AA0680
	.long 0xd7006a98                                           // 000000035478: D7006A98
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 00000003547C: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000035484: BF870001
	v_add_co_ci_u32_e64 v153, null, 0, v3, vcc_lo              // 000000035488: D5207C99 01AA0680
	s_clause 0x7                                               // 000000035490: BF850007
	global_store_b32 v[2:3], v69, off                          // 000000035494: DC6A0000 007C4502
	global_store_b32 v[2:3], v70, off offset:1024              // 00000003549C: DC6A0400 007C4602
	global_store_b32 v[2:3], v71, off offset:2048              // 0000000354A4: DC6A0800 007C4702
	global_store_b32 v[2:3], v72, off offset:3072              // 0000000354AC: DC6A0C00 007C4802
	global_store_b32 v[148:149], v73, off offset:1024          // 0000000354B4: DC6A0400 007C4994
	global_store_b32 v[148:149], v146, off offset:2048         // 0000000354BC: DC6A0800 007C9294
	global_store_b32 v[148:149], v147, off offset:3072         // 0000000354C4: DC6A0C00 007C9394
	global_store_b32 v[152:153], v68, off offset:1024          // 0000000354CC: DC6A0400 007C4498
	.long 0xd7006a44                                           // 0000000354D4: D7006A44
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 0000000354D8: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000354E0: BF8700A1
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 0000000354E4: D5207C45 01AA0680
	.long 0xd7006a46                                           // 0000000354EC: D7006A46
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 0000000354F0: 0201FF02
	.long 0x00004000                                           // 0000000354F4: 00004000
	v_add_co_ci_u32_e64 v71, null, 0, v3, vcc_lo               // 0000000354F8: D5207C47 01AA0680
	.long 0xd7006a48                                           // 000000035500: D7006A48
	v_cndmask_b32_e32 v1, 0x4000, v2, vcc_lo                   // 000000035504: 020204FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003550C: BF870001
	v_add_co_ci_u32_e64 v73, null, 0, v3, vcc_lo               // 000000035510: D5207C49 01AA0680
	s_clause 0x7                                               // 000000035518: BF850007
	global_store_b32 v[152:153], v62, off offset:2048          // 00000003551C: DC6A0800 007C3E98
	global_store_b32 v[152:153], v63, off offset:3072          // 000000035524: DC6A0C00 007C3F98
	global_store_b32 v[68:69], v64, off offset:1024            // 00000003552C: DC6A0400 007C4044
	global_store_b32 v[68:69], v66, off offset:2048            // 000000035534: DC6A0800 007C4244
	global_store_b32 v[68:69], v67, off offset:3072            // 00000003553C: DC6A0C00 007C4344
	global_store_b32 v[72:73], v59, off offset:1024            // 000000035544: DC6A0400 007C3B48
	global_store_b32 v[72:73], v60, off offset:2048            // 00000003554C: DC6A0800 007C3C48
	global_store_b32 v[72:73], v61, off offset:3072            // 000000035554: DC6A0C00 007C3D48
	.long 0xd7006a3b                                           // 00000003555C: D7006A3B
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 000000035560: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000035568: BF8700A1
	v_add_co_ci_u32_e64 v60, null, 0, v3, vcc_lo               // 00000003556C: D5207C3C 01AA0680
	.long 0xd7006a3d                                           // 000000035574: D7006A3D
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000035578: 0201FF02
	.long 0x00006000                                           // 00000003557C: 00006000
	v_add_co_ci_u32_e64 v62, null, 0, v3, vcc_lo               // 000000035580: D5207C3E 01AA0680
	.long 0xd7006a3f                                           // 000000035588: D7006A3F
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 00000003558C: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000035594: BF8700A1
	v_add_co_ci_u32_e64 v64, null, 0, v3, vcc_lo               // 000000035598: D5207C40 01AA0680
	.long 0xd7006a42                                           // 0000000355A0: D7006A42
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 0000000355A4: 020204FF 00007000
	v_add_co_ci_u32_e64 v67, null, 0, v3, vcc_lo               // 0000000355AC: D5207C43 01AA0680
	.long 0xd7006a44                                           // 0000000355B4: D7006A44
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 0000000355B8: 0201FF02
	.long 0x00008000                                           // 0000000355BC: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000355C0: BF870001
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 0000000355C4: D5207C45 01AA0680
	s_clause 0x7                                               // 0000000355CC: BF850007
	global_store_b32 v[59:60], v52, off offset:1024            // 0000000355D0: DC6A0400 007C343B
	global_store_b32 v[59:60], v53, off offset:2048            // 0000000355D8: DC6A0800 007C353B
	global_store_b32 v[59:60], v54, off offset:3072            // 0000000355E0: DC6A0C00 007C363B
	global_store_b32 v[63:64], v55, off offset:1024            // 0000000355E8: DC6A0400 007C373F
	global_store_b32 v[63:64], v56, off offset:2048            // 0000000355F0: DC6A0800 007C383F
	global_store_b32 v[63:64], v58, off offset:3072            // 0000000355F8: DC6A0C00 007C3A3F
	global_store_b32 v[66:67], v50, off offset:1024            // 000000035600: DC6A0400 007C3242
	global_store_b32 v[66:67], v51, off offset:2048            // 000000035608: DC6A0800 007C3342
	.long 0xd7006a32                                           // 000000035610: D7006A32
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 000000035614: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003561C: BF8700A1
	v_add_co_ci_u32_e64 v51, null, 0, v3, vcc_lo               // 000000035620: D5207C33 01AA0680
	.long 0xd7006a34                                           // 000000035628: D7006A34
	v_cndmask_b32_e32 v1, 0x9000, v2, vcc_lo                   // 00000003562C: 020204FF 00009000
	v_add_co_ci_u32_e64 v53, null, 0, v3, vcc_lo               // 000000035634: D5207C35 01AA0680
	.long 0xd7006a36                                           // 00000003563C: D7006A36
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000035640: 0201FF02
	.long 0x0000a000                                           // 000000035644: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000035648: BF8700A1
	v_add_co_ci_u32_e64 v55, null, 0, v3, vcc_lo               // 00000003564C: D5207C37 01AA0680
	.long 0xd7006a3a                                           // 000000035654: D7006A3A
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 000000035658: 020204FF 0000A000
	v_add_co_ci_u32_e64 v59, null, 0, v3, vcc_lo               // 000000035660: D5207C3B 01AA0680
	s_clause 0x7                                               // 000000035668: BF850007
	global_store_b32 v[66:67], v40, off offset:3072            // 00000003566C: DC6A0C00 007C2842
	global_store_b32 v[50:51], v43, off offset:1024            // 000000035674: DC6A0400 007C2B32
	global_store_b32 v[50:51], v44, off offset:2048            // 00000003567C: DC6A0800 007C2C32
	global_store_b32 v[50:51], v45, off offset:3072            // 000000035684: DC6A0C00 007C2D32
	global_store_b32 v[52:53], v46, off offset:1024            // 00000003568C: DC6A0400 007C2E34
	global_store_b32 v[52:53], v47, off offset:2048            // 000000035694: DC6A0800 007C2F34
	global_store_b32 v[52:53], v48, off offset:3072            // 00000003569C: DC6A0C00 007C3034
	global_store_b32 v[58:59], v42, off offset:1024            // 0000000356A4: DC6A0400 007C2A3A
	.long 0xd7006a2a                                           // 0000000356AC: D7006A2A
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 0000000356B0: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000356B8: BF8700A1
	v_add_co_ci_u32_e64 v43, null, 0, v3, vcc_lo               // 0000000356BC: D5207C2B 01AA0680
	.long 0xd7006a2c                                           // 0000000356C4: D7006A2C
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 0000000356C8: 0201FF02
	.long 0x0000c000                                           // 0000000356CC: 0000C000
	v_add_co_ci_u32_e64 v45, null, 0, v3, vcc_lo               // 0000000356D0: D5207C2D 01AA0680
	.long 0xd7006a2e                                           // 0000000356D8: D7006A2E
	v_cndmask_b32_e32 v1, 0xc000, v2, vcc_lo                   // 0000000356DC: 020204FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000356E4: BF870001
	v_add_co_ci_u32_e64 v47, null, 0, v3, vcc_lo               // 0000000356E8: D5207C2F 01AA0680
	s_clause 0x7                                               // 0000000356F0: BF850007
	global_store_b32 v[58:59], v35, off offset:2048            // 0000000356F4: DC6A0800 007C233A
	global_store_b32 v[58:59], v36, off offset:3072            // 0000000356FC: DC6A0C00 007C243A
	global_store_b32 v[42:43], v37, off offset:1024            // 000000035704: DC6A0400 007C252A
	global_store_b32 v[42:43], v38, off offset:2048            // 00000003570C: DC6A0800 007C262A
	global_store_b32 v[42:43], v39, off offset:3072            // 000000035714: DC6A0C00 007C272A
	global_store_b32 v[46:47], v31, off offset:1024            // 00000003571C: DC6A0400 007C1F2E
	global_store_b32 v[46:47], v32, off offset:2048            // 000000035724: DC6A0800 007C202E
	global_store_b32 v[46:47], v34, off offset:3072            // 00000003572C: DC6A0C00 007C222E
	.long 0xd7006a1f                                           // 000000035734: D7006A1F
	v_cndmask_b32_e32 v1, 0xd000, v2, vcc_lo                   // 000000035738: 020204FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000035740: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v3, vcc_lo               // 000000035744: D5207C20 01AA0680
	.long 0xd7006a22                                           // 00000003574C: D7006A22
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000035750: 0201FF02
	.long 0x0000e000                                           // 000000035754: 0000E000
	v_add_co_ci_u32_e64 v35, null, 0, v3, vcc_lo               // 000000035758: D5207C23 01AA0680
	.long 0xd7006a24                                           // 000000035760: D7006A24
	v_cndmask_b32_e32 v1, 0xe000, v2, vcc_lo                   // 000000035764: 020204FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003576C: BF870001
	v_add_co_ci_u32_e64 v37, null, 0, v3, vcc_lo               // 000000035770: D5207C25 01AA0680
	.long 0xd7006a02                                           // 000000035778: D7006A02
	v_cndmask_b32_e32 v1, 0xf000, v2, vcc_lo                   // 00000003577C: 020204FF 0000F000
	s_clause 0x7                                               // 000000035784: BF850007
	global_store_b32 v[68:69], v11, off offset:-4096           // 000000035788: DC6A1000 007C0B44
	global_store_b32 v[68:69], v12, off                        // 000000035790: DC6A0000 007C0C44
	global_store_b32 v[54:55], v14, off offset:-4096           // 000000035798: DC6A1000 007C0E36
	global_store_b32 v[54:55], v15, off                        // 0000000357A0: DC6A0000 007C0F36
	global_store_b32 v[44:45], v27, off offset:-4096           // 0000000357A8: DC6A1000 007C1B2C
	global_store_b32 v[44:45], v28, off                        // 0000000357B0: DC6A0000 007C1C2C
	global_store_b32 v[34:35], v29, off offset:-4096           // 0000000357B8: DC6A1000 007C1D22
	global_store_b32 v[34:35], v30, off                        // 0000000357C0: DC6A0000 007C1E22
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000000357C8: D5207C03 01AA0680
	s_clause 0xf                                               // 0000000357D0: BF85000F
	global_store_b32 v[31:32], v20, off offset:1024            // 0000000357D4: DC6A0400 007C141F
	global_store_b32 v[31:32], v21, off offset:2048            // 0000000357DC: DC6A0800 007C151F
	global_store_b32 v[31:32], v22, off offset:3072            // 0000000357E4: DC6A0C00 007C161F
	global_store_b32 v[36:37], v23, off offset:1024            // 0000000357EC: DC6A0400 007C1724
	global_store_b32 v[36:37], v24, off offset:2048            // 0000000357F4: DC6A0800 007C1824
	global_store_b32 v[36:37], v26, off offset:3072            // 0000000357FC: DC6A0C00 007C1A24
	global_store_b32 v[2:3], v16, off                          // 000000035804: DC6A0000 007C1002
	global_store_b32 v[2:3], v18, off offset:1024              // 00000003580C: DC6A0400 007C1202
	global_store_b32 v[2:3], v19, off offset:2048              // 000000035814: DC6A0800 007C1302
	global_store_b32 v[150:151], v4, off offset:-4096          // 00000003581C: DC6A1000 007C0496
	global_store_b32 v[150:151], v5, off                       // 000000035824: DC6A0000 007C0596
	global_store_b32 v[70:71], v6, off offset:-4096            // 00000003582C: DC6A1000 007C0646
	global_store_b32 v[70:71], v7, off                         // 000000035834: DC6A0000 007C0746
	global_store_b32 v[61:62], v8, off offset:-4096            // 00000003583C: DC6A1000 007C083D
	global_store_b32 v[61:62], v10, off                        // 000000035844: DC6A0000 007C0A3D
	global_store_b32 v[2:3], v13, off offset:3072              // 00000003584C: DC6A0C00 007C0D02
	s_branch 60905                                             // 000000035854: BFA0EDE9 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x8fc>
	v_mov_b32_e32 v54, v41                                     // 000000035858: 7E6C0329
	v_mov_b32_e32 v53, v33                                     // 00000003585C: 7E6A0321
	v_mov_b32_e32 v52, v25                                     // 000000035860: 7E680319
	v_mov_b32_e32 v51, v17                                     // 000000035864: 7E660311
	v_mov_b32_e32 v50, v9                                      // 000000035868: 7E640309
	v_mov_b32_e32 v58, v49                                     // 00000003586C: 7E740331
	v_mov_b32_e32 v147, v57                                    // 000000035870: 7F260339
	v_mov_b32_e32 v146, v65                                    // 000000035874: 7F240341
	s_mov_b32 s7, 0                                            // 000000035878: BE870080
	s_branch 1                                                 // 00000003587C: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5184>
	s_mov_b64 s[6:7], 0                                        // 000000035880: BE860180
	v_dual_mul_f32 v3, 0x3b800000, v139 :: v_dual_mul_f32 v4, 0x3b800000, v138// 000000035884: C8C716FF 030514FF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v137 :: v_dual_mul_f32 v6, 0x3b800000, v136// 000000035890: C8C712FF 050710FF 3B800000
	.long 0xd7006a01                                           // 00000003589C: D7006A01
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000358A0: 0201FF52
	.long 0x00002000                                           // 0000000358A4: 00002000
	v_dual_mul_f32 v7, 0x3b800000, v135 :: v_dual_mul_f32 v8, 0x3b800000, v134// 0000000358A8: C8C70EFF 07090CFF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v83, vcc_lo               // 0000000358B4: D5207C02 01AAA680
	v_dual_mul_f32 v9, 0x3b800000, v133 :: v_dual_mul_f32 v10, 0x3b800000, v54// 0000000358BC: C8C70AFF 090A6CFF 3B800000
	s_clause 0x7                                               // 0000000358C8: BF850007
	global_store_b32 v[82:83], v3, off                         // 0000000358CC: DC6A0000 007C0352
	global_store_b32 v[82:83], v4, off offset:1024             // 0000000358D4: DC6A0400 007C0452
	global_store_b32 v[82:83], v5, off offset:2048             // 0000000358DC: DC6A0800 007C0552
	global_store_b32 v[82:83], v6, off offset:3072             // 0000000358E4: DC6A0C00 007C0652
	global_store_b32 v[1:2], v7, off offset:-4096              // 0000000358EC: DC6A1000 007C0701
	global_store_b32 v[1:2], v8, off offset:-3072              // 0000000358F4: DC6A1400 007C0801
	global_store_b32 v[1:2], v9, off offset:-2048              // 0000000358FC: DC6A1800 007C0901
	global_store_b32 v[1:2], v10, off offset:-1024             // 000000035904: DC6A1C00 007C0A01
	v_dual_mul_f32 v5, 0x3b800000, v132 :: v_dual_mul_f32 v6, 0x3b800000, v131// 00000003590C: C8C708FF 050706FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v130 :: v_dual_mul_f32 v8, 0x3b800000, v129// 000000035918: C8C704FF 070902FF 3B800000
	.long 0xd7006a03                                           // 000000035924: D7006A03
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000035928: 0201FF52
	.long 0x00004000                                           // 00000003592C: 00004000
	v_dual_mul_f32 v9, 0x3b800000, v128 :: v_dual_mul_f32 v10, 0x3b800000, v127// 000000035930: C8C700FF 090AFEFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v83, vcc_lo               // 00000003593C: D5207C04 01AAA680
	v_dual_mul_f32 v11, 0x3b800000, v126 :: v_dual_mul_f32 v12, 0x3b800000, v53// 000000035944: C8C6FCFF 0B0C6AFF 3B800000
	s_clause 0x7                                               // 000000035950: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000035954: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 00000003595C: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 000000035964: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 00000003596C: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 000000035974: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 00000003597C: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 000000035984: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 00000003598C: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v125 :: v_dual_mul_f32 v6, 0x3b800000, v124// 000000035994: C8C6FAFF 0506F8FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v123 :: v_dual_mul_f32 v8, 0x3b800000, v122// 0000000359A0: C8C6F6FF 0708F4FF 3B800000
	.long 0xd7006a01                                           // 0000000359AC: D7006A01
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000359B0: 0201FF52
	.long 0x00006000                                           // 0000000359B4: 00006000
	v_dual_mul_f32 v9, 0x3b800000, v121 :: v_dual_mul_f32 v10, 0x3b800000, v120// 0000000359B8: C8C6F2FF 090AF0FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v83, vcc_lo               // 0000000359C4: D5207C02 01AAA680
	v_dual_mul_f32 v11, 0x3b800000, v119 :: v_dual_mul_f32 v12, 0x3b800000, v52// 0000000359CC: C8C6EEFF 0B0C68FF 3B800000
	s_clause 0x7                                               // 0000000359D8: BF850007
	global_store_b32 v[3:4], v5, off                           // 0000000359DC: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 0000000359E4: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 0000000359EC: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 0000000359F4: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 0000000359FC: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000035A04: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000035A0C: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000035A14: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v118 :: v_dual_mul_f32 v6, 0x3b800000, v117// 000000035A1C: C8C6ECFF 0506EAFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v116 :: v_dual_mul_f32 v8, 0x3b800000, v115// 000000035A28: C8C6E8FF 0708E6FF 3B800000
	.long 0xd7006a03                                           // 000000035A34: D7006A03
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000035A38: 0201FF52
	.long 0x00008000                                           // 000000035A3C: 00008000
	v_dual_mul_f32 v9, 0x3b800000, v114 :: v_dual_mul_f32 v10, 0x3b800000, v113// 000000035A40: C8C6E4FF 090AE2FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v83, vcc_lo               // 000000035A4C: D5207C04 01AAA680
	v_dual_mul_f32 v11, 0x3b800000, v112 :: v_dual_mul_f32 v12, 0x3b800000, v51// 000000035A54: C8C6E0FF 0B0C66FF 3B800000
	s_clause 0x7                                               // 000000035A60: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000035A64: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000035A6C: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 000000035A74: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 000000035A7C: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 000000035A84: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 000000035A8C: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 000000035A94: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 000000035A9C: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v111 :: v_dual_mul_f32 v6, 0x3b800000, v110// 000000035AA4: C8C6DEFF 0506DCFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v109 :: v_dual_mul_f32 v8, 0x3b800000, v108// 000000035AB0: C8C6DAFF 0708D8FF 3B800000
	.long 0xd7006a01                                           // 000000035ABC: D7006A01
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000035AC0: 0201FF52
	.long 0x0000a000                                           // 000000035AC4: 0000A000
	v_dual_mul_f32 v9, 0x3b800000, v107 :: v_dual_mul_f32 v10, 0x3b800000, v106// 000000035AC8: C8C6D6FF 090AD4FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v83, vcc_lo               // 000000035AD4: D5207C02 01AAA680
	v_dual_mul_f32 v11, 0x3b800000, v105 :: v_dual_mul_f32 v12, 0x3b800000, v50// 000000035ADC: C8C6D2FF 0B0C64FF 3B800000
	s_clause 0x7                                               // 000000035AE8: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000035AEC: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 000000035AF4: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000035AFC: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 000000035B04: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000035B0C: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000035B14: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000035B1C: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000035B24: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v104 :: v_dual_mul_f32 v6, 0x3b800000, v103// 000000035B2C: C8C6D0FF 0506CEFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v102 :: v_dual_mul_f32 v8, 0x3b800000, v101// 000000035B38: C8C6CCFF 0708CAFF 3B800000
	.long 0xd7006a03                                           // 000000035B44: D7006A03
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000035B48: 0201FF52
	.long 0x0000c000                                           // 000000035B4C: 0000C000
	v_dual_mul_f32 v9, 0x3b800000, v100 :: v_dual_mul_f32 v10, 0x3b800000, v99// 000000035B50: C8C6C8FF 090AC6FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v83, vcc_lo               // 000000035B5C: D5207C04 01AAA680
	v_mul_f32_e32 v11, 0x3b800000, v98                         // 000000035B64: 1016C4FF 3B800000
	v_mul_f32_e32 v12, 0x3b800000, v58                         // 000000035B6C: 101874FF 3B800000
	s_clause 0x7                                               // 000000035B74: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000035B78: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000035B80: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 000000035B88: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 000000035B90: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 000000035B98: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 000000035BA0: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 000000035BA8: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 000000035BB0: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v97 :: v_dual_mul_f32 v6, 0x3b800000, v96// 000000035BB8: C8C6C2FF 0506C0FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v95 :: v_dual_mul_f32 v8, 0x3b800000, v94// 000000035BC4: C8C6BEFF 0708BCFF 3B800000
	.long 0xd7006a01                                           // 000000035BD0: D7006A01
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000035BD4: 0201FF52
	.long 0x0000e000                                           // 000000035BD8: 0000E000
	v_dual_mul_f32 v9, 0x3b800000, v93 :: v_dual_mul_f32 v10, 0x3b800000, v92// 000000035BDC: C8C6BAFF 090AB8FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v83, vcc_lo               // 000000035BE8: D5207C02 01AAA680
	v_mul_f32_e32 v11, 0x3b800000, v91                         // 000000035BF0: 1016B6FF 3B800000
	v_mul_f32_e32 v12, 0x3b800000, v147                        // 000000035BF8: 101926FF 3B800000
	s_clause 0x7                                               // 000000035C00: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000035C04: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 000000035C0C: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000035C14: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 000000035C1C: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000035C24: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000035C2C: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000035C34: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000035C3C: DC6A1C00 007C0C01
	v_mul_f32_e32 v5, 0x3b800000, v90                          // 000000035C44: 100AB4FF 3B800000
	v_and_or_b32 v0, v0, 31, s5                                // 000000035C4C: D6570000 00153F00
	v_dual_mul_f32 v6, 0x3b800000, v89 :: v_dual_mul_f32 v7, 0x3b800000, v88// 000000035C54: C8C6B2FF 0606B0FF 3B800000
	v_mul_f32_e32 v8, 0x3b800000, v87                          // 000000035C60: 1010AEFF 3B800000
	.long 0xd7006a03                                           // 000000035C68: D7006A03
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000035C6C: 0201FF52
	.long 0x0000fc00                                           // 000000035C70: 0000FC00
	v_dual_mul_f32 v9, 0x3b800000, v86 :: v_dual_mul_f32 v10, 0x3b800000, v84// 000000035C74: C8C6ACFF 090AA8FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v83, vcc_lo               // 000000035C80: D5207C04 01AAA680
	v_dual_mul_f32 v11, 0x3b800000, v85 :: v_dual_mul_f32 v12, 0x3b800000, v146// 000000035C88: C8C6AAFF 0B0D24FF 3B800000
	s_clause 0x7                                               // 000000035C94: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000035C98: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000035CA0: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 000000035CA8: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 000000035CB0: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-3072              // 000000035CB8: DC6A1400 007C0903
	global_store_b32 v[3:4], v10, off offset:-2048             // 000000035CC0: DC6A1800 007C0A03
	global_store_b32 v[3:4], v11, off offset:-1024             // 000000035CC8: DC6A1C00 007C0B03
	global_store_b32 v[3:4], v12, off                          // 000000035CD0: DC6A0000 007C0C03
	s_mov_b32 s2, exec_lo                                      // 000000035CD8: BE82007E
	v_cmpx_eq_u32_e32 0, v0                                    // 000000035CDC: 7D940080
	s_cbranch_execz 8                                          // 000000035CE0: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi3ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5604>
	s_load_b64 s[0:1], s[0:1], 0x40                            // 000000035CE4: F4040000 F8000040
	v_mov_b32_e32 v0, s6                                       // 000000035CEC: 7E000206
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, s7              // 000000035CF0: CA100080 02000007
	s_waitcnt lgkmcnt(0)                                       // 000000035CF8: BF89FC07
	global_store_b64 v2, v[0:1], s[0:1] offset:16              // 000000035CFC: DC6E0010 00000002
	s_nop 0                                                    // 000000035D04: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000035D08: BFB60003
	s_endpgm                                                   // 000000035D0C: BFB00000
		...

