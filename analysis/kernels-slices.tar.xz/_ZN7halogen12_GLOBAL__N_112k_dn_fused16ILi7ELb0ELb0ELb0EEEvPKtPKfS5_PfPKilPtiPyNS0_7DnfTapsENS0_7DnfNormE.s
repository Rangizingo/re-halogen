0000000000046300 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE>:
; _ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE():
	s_clause 0x1                                               // 000000046300: BF850001
	s_load_b256 s[20:27], s[0:1], 0x20                         // 000000046304: F40C0500 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 00000004630C: F40C0200 F8000000
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 5, v0       // 000000046314: CA220080 02020085
	s_ashr_i32 s3, s2, 31                                      // 00000004631C: 86039F02
	s_mov_b32 s28, 0                                           // 000000046320: BE9C0080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000046324: BF870001
	v_and_b32_e32 v3, 0x200, v3                                // 000000046328: 360606FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 000000046330: BF89FC07
	s_load_b32 s16, s[20:21], null                             // 000000046334: F400040A F8000000
	v_readfirstlane_b32 s20, v0                                // 00000004633C: 7E280500
	s_lshl_b64 s[4:5], s[22:23], 2                             // 000000046340: 84848216
	s_lshr_b32 s21, s20, 5                                     // 000000046344: 85158514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000046348: BF8704D9
	s_lshl_b32 s33, s21, 4                                     // 00000004634C: 84218415
	s_add_u32 s4, s14, s4                                      // 000000046350: 8004040E
	v_and_or_b32 v1, v0, 15, s33                               // 000000046354: D6570001 00851F00
	s_addc_u32 s5, s15, s5                                     // 00000004635C: 8205050F
	s_lshl_b64 s[6:7], s[2:3], 16                              // 000000046360: 84869002
	s_add_u32 s4, s4, s6                                       // 000000046364: 80040604
	s_delay_alu instid0(VALU_DEP_1)                            // 000000046368: BF870001
	.long 0xd73c0001                                           // 00000004636C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000046370: 02020282
	s_addc_u32 s5, s5, s7                                      // 000000046374: 82050705
	s_waitcnt lgkmcnt(0)                                       // 000000046378: BF89FC07
	s_mul_i32 s14, s16, 0x9000000                              // 00000004637C: 960EFF10 09000000
	s_mul_hi_i32 s15, s16, 0x9000000                           // 000000046384: 970FFF10 09000000
	s_add_u32 s4, s4, s14                                      // 00000004638C: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000046390: 82050F05
	.long 0xd7006a01                                           // 000000046394: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000046398: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000004639C: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000000463A0: D5207C02 01AA0405
	s_or_b32 s5, s21, s2                                       // 0000000463A8: 8C050215
	.long 0xd7006abb                                           // 0000000463AC: D7006ABB
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000000463B0: 02020701
	v_add_co_ci_u32_e64 v188, null, 0, v2, vcc_lo              // 0000000463B4: D5207CBC 01AA0480
	s_cselect_b32 s38, 0, -1                                   // 0000000463BC: 9826C180
	.long 0xd7006a09                                           // 0000000463C0: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v187, vcc_lo                 // 0000000463C4: 020376FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000463CC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v188, vcc_lo             // 0000000463D0: D5207C0A 01AB7880
	.long 0xd7006a34                                           // 0000000463D8: D7006A34
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000463DC: 0201FFBB
	.long 0x00002000                                           // 0000000463E0: 00002000
	v_add_co_ci_u32_e64 v53, null, 0, v188, vcc_lo             // 0000000463E4: D5207C35 01AB7880
	.long 0xd7006a0d                                           // 0000000463EC: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v187, vcc_lo                 // 0000000463F0: 020376FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000463F8: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v188, vcc_lo             // 0000000463FC: D5207C0E 01AB7880
	.long 0xd7006a0f                                           // 000000046404: D7006A0F
	v_cndmask_b32_e32 v1, 0x3000, v187, vcc_lo                 // 000000046408: 020376FF 00003000
	v_add_co_ci_u32_e64 v16, null, 0, v188, vcc_lo             // 000000046410: D5207C10 01AB7880
	.long 0xd7006a3c                                           // 000000046418: D7006A3C
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004641C: 0201FFBB
	.long 0x00004000                                           // 000000046420: 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000046424: BF870001
	v_add_co_ci_u32_e64 v61, null, 0, v188, vcc_lo             // 000000046428: D5207C3D 01AB7880
	.long 0xd7006a11                                           // 000000046430: D7006A11
	v_cndmask_b32_e32 v1, 0x4000, v187, vcc_lo                 // 000000046434: 020376FF 00004000
	s_clause 0x7                                               // 00000004643C: BF850007
	global_load_b32 v5, v[187:188], off                        // 000000046440: DC520000 057C00BB
	global_load_b32 v6, v[187:188], off offset:1024            // 000000046448: DC520400 067C00BB
	global_load_b32 v7, v[187:188], off offset:2048            // 000000046450: DC520800 077C00BB
	global_load_b32 v8, v[187:188], off offset:3072            // 000000046458: DC520C00 087C00BB
	global_load_b32 v2, v[9:10], off offset:1024               // 000000046460: DC520400 027C0009
	global_load_b32 v3, v[9:10], off offset:2048               // 000000046468: DC520800 037C0009
	global_load_b32 v4, v[9:10], off offset:3072               // 000000046470: DC520C00 047C0009
	global_load_b32 v1, v[13:14], off offset:1024              // 000000046478: DC520400 017C000D
	v_add_co_ci_u32_e64 v18, null, 0, v188, vcc_lo             // 000000046480: D5207C12 01AB7880
	s_clause 0x7                                               // 000000046488: BF850007
	global_load_b32 v12, v[13:14], off offset:2048             // 00000004648C: DC520800 0C7C000D
	global_load_b32 v13, v[13:14], off offset:3072             // 000000046494: DC520C00 0D7C000D
	global_load_b32 v9, v[15:16], off offset:1024              // 00000004649C: DC520400 097C000F
	global_load_b32 v10, v[15:16], off offset:2048             // 0000000464A4: DC520800 0A7C000F
	global_load_b32 v11, v[15:16], off offset:3072             // 0000000464AC: DC520C00 0B7C000F
	global_load_b32 v14, v[17:18], off offset:1024             // 0000000464B4: DC520400 0E7C0011
	global_load_b32 v15, v[17:18], off offset:2048             // 0000000464BC: DC520800 0F7C0011
	global_load_b32 v16, v[17:18], off offset:3072             // 0000000464C4: DC520C00 107C0011
	.long 0xd7006a11                                           // 0000000464CC: D7006A11
	v_cndmask_b32_e32 v1, 0x5000, v187, vcc_lo                 // 0000000464D0: 020376FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000464D8: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v188, vcc_lo             // 0000000464DC: D5207C12 01AB7880
	.long 0xd7006a41                                           // 0000000464E4: D7006A41
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000464E8: 0201FFBB
	.long 0x00006000                                           // 0000000464EC: 00006000
	v_add_co_ci_u32_e64 v66, null, 0, v188, vcc_lo             // 0000000464F0: D5207C42 01AB7880
	.long 0xd7006a17                                           // 0000000464F8: D7006A17
	v_cndmask_b32_e32 v1, 0x6000, v187, vcc_lo                 // 0000000464FC: 020376FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000046504: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v188, vcc_lo             // 000000046508: D5207C18 01AB7880
	.long 0xd7006a19                                           // 000000046510: D7006A19
	v_cndmask_b32_e32 v1, 0x7000, v187, vcc_lo                 // 000000046514: 020376FF 00007000
	v_add_co_ci_u32_e64 v26, null, 0, v188, vcc_lo             // 00000004651C: D5207C1A 01AB7880
	.long 0xd7006a29                                           // 000000046524: D7006A29
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000046528: 0201FFBB
	.long 0x00008000                                           // 00000004652C: 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000046530: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v188, vcc_lo             // 000000046534: D5207C2A 01AB7880
	.long 0xd7006a20                                           // 00000004653C: D7006A20
	v_cndmask_b32_e32 v1, 0x8000, v187, vcc_lo                 // 000000046540: 020376FF 00008000
	v_add_co_ci_u32_e64 v33, null, 0, v188, vcc_lo             // 000000046548: D5207C21 01AB7880
	.long 0xd7006a22                                           // 000000046550: D7006A22
	v_cndmask_b32_e32 v1, 0x9000, v187, vcc_lo                 // 000000046554: 020376FF 00009000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004655C: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v188, vcc_lo             // 000000046560: D5207C23 01AB7880
	.long 0xd7006a2b                                           // 000000046568: D7006A2B
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004656C: 0201FFBB
	.long 0x0000a000                                           // 000000046570: 0000A000
	v_add_co_ci_u32_e64 v44, null, 0, v188, vcc_lo             // 000000046574: D5207C2C 01AB7880
	.long 0xd7006a25                                           // 00000004657C: D7006A25
	v_cndmask_b32_e32 v1, 0xa000, v187, vcc_lo                 // 000000046580: 020376FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000046588: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v188, vcc_lo             // 00000004658C: D5207C26 01AB7880
	.long 0xd7006a27                                           // 000000046594: D7006A27
	v_cndmask_b32_e32 v1, 0xb000, v187, vcc_lo                 // 000000046598: 020376FF 0000B000
	v_add_co_ci_u32_e64 v40, null, 0, v188, vcc_lo             // 0000000465A0: D5207C28 01AB7880
	.long 0xd7006a2d                                           // 0000000465A8: D7006A2D
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000465AC: 0201FFBB
	.long 0x0000c000                                           // 0000000465B0: 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000465B4: BF8700A1
	v_add_co_ci_u32_e64 v46, null, 0, v188, vcc_lo             // 0000000465B8: D5207C2E 01AB7880
	.long 0xd7006a2f                                           // 0000000465C0: D7006A2F
	v_cndmask_b32_e32 v1, 0xc000, v187, vcc_lo                 // 0000000465C4: 020376FF 0000C000
	v_add_co_ci_u32_e64 v48, null, 0, v188, vcc_lo             // 0000000465CC: D5207C30 01AB7880
	.long 0xd7006a36                                           // 0000000465D4: D7006A36
	v_cndmask_b32_e32 v1, 0xd000, v187, vcc_lo                 // 0000000465D8: 020376FF 0000D000
	s_clause 0x17                                              // 0000000465E0: BF850017
	global_load_b32 v20, v[17:18], off offset:1024             // 0000000465E4: DC520400 147C0011
	global_load_b32 v21, v[17:18], off offset:2048             // 0000000465EC: DC520800 157C0011
	global_load_b32 v22, v[17:18], off offset:3072             // 0000000465F4: DC520C00 167C0011
	global_load_b32 v17, v[23:24], off offset:1024             // 0000000465FC: DC520400 117C0017
	global_load_b32 v18, v[23:24], off offset:2048             // 000000046604: DC520800 127C0017
	global_load_b32 v19, v[23:24], off offset:3072             // 00000004660C: DC520C00 137C0017
	global_load_b32 v23, v[25:26], off offset:1024             // 000000046614: DC520400 177C0019
	global_load_b32 v24, v[25:26], off offset:2048             // 00000004661C: DC520800 187C0019
	global_load_b32 v31, v[25:26], off offset:3072             // 000000046624: DC520C00 1F7C0019
	global_load_b32 v28, v[32:33], off offset:1024             // 00000004662C: DC520400 1C7C0020
	global_load_b32 v29, v[32:33], off offset:2048             // 000000046634: DC520800 1D7C0020
	global_load_b32 v30, v[32:33], off offset:3072             // 00000004663C: DC520C00 1E7C0020
	global_load_b32 v25, v[34:35], off offset:1024             // 000000046644: DC520400 197C0022
	global_load_b32 v26, v[34:35], off offset:2048             // 00000004664C: DC520800 1A7C0022
	global_load_b32 v27, v[34:35], off offset:3072             // 000000046654: DC520C00 1B7C0022
	global_load_b32 v32, v[37:38], off offset:1024             // 00000004665C: DC520400 207C0025
	global_load_b32 v36, v[37:38], off offset:2048             // 000000046664: DC520800 247C0025
	global_load_b32 v37, v[37:38], off offset:3072             // 00000004666C: DC520C00 257C0025
	global_load_b32 v33, v[39:40], off offset:1024             // 000000046674: DC520400 217C0027
	global_load_b32 v34, v[39:40], off offset:2048             // 00000004667C: DC520800 227C0027
	global_load_b32 v35, v[39:40], off offset:3072             // 000000046684: DC520C00 237C0027
	global_load_b32 v38, v[47:48], off offset:1024             // 00000004668C: DC520400 267C002F
	global_load_b32 v39, v[47:48], off offset:2048             // 000000046694: DC520800 277C002F
	global_load_b32 v40, v[47:48], off offset:3072             // 00000004669C: DC520C00 287C002F
	v_add_co_ci_u32_e64 v55, null, 0, v188, vcc_lo             // 0000000466A4: D5207C37 01AB7880
	.long 0xd7006a2f                                           // 0000000466AC: D7006A2F
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000466B0: 0201FFBB
	.long 0x0000e000                                           // 0000000466B4: 0000E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000466B8: BF8700A1
	v_add_co_ci_u32_e64 v48, null, 0, v188, vcc_lo             // 0000000466BC: D5207C30 01AB7880
	.long 0xd7006a3e                                           // 0000000466C4: D7006A3E
	v_cndmask_b32_e32 v1, 0xe000, v187, vcc_lo                 // 0000000466C8: 020376FF 0000E000
	v_add_co_ci_u32_e64 v63, null, 0, v188, vcc_lo             // 0000000466D0: D5207C3F 01AB7880
	.long 0xd7006a43                                           // 0000000466D8: D7006A43
	v_cndmask_b32_e32 v1, 0xf000, v187, vcc_lo                 // 0000000466DC: 020376FF 0000F000
	s_clause 0x7                                               // 0000000466E4: BF850007
	global_load_b32 v51, v[41:42], off offset:-4096            // 0000000466E8: DC521000 337C0029
	global_load_b32 v58, v[41:42], off                         // 0000000466F0: DC520000 3A7C0029
	global_load_b32 v50, v[43:44], off offset:-4096            // 0000000466F8: DC521000 327C002B
	global_load_b32 v56, v[43:44], off                         // 000000046700: DC520000 387C002B
	global_load_b32 v44, v[45:46], off offset:-4096            // 000000046708: DC521000 2C7C002D
	global_load_b32 v43, v[45:46], off                         // 000000046710: DC520000 2B7C002D
	global_load_b32 v42, v[47:48], off offset:-4096            // 000000046718: DC521000 2A7C002F
	global_load_b32 v41, v[47:48], off                         // 000000046720: DC520000 297C002F
	v_add_co_ci_u32_e64 v68, null, 0, v188, vcc_lo             // 000000046728: D5207C44 01AB7880
	s_clause 0xf                                               // 000000046730: BF85000F
	global_load_b32 v48, v[54:55], off offset:1024             // 000000046734: DC520400 307C0036
	global_load_b32 v49, v[54:55], off offset:2048             // 00000004673C: DC520800 317C0036
	global_load_b32 v55, v[54:55], off offset:3072             // 000000046744: DC520C00 377C0036
	global_load_b32 v45, v[62:63], off offset:1024             // 00000004674C: DC520400 2D7C003E
	global_load_b32 v46, v[62:63], off offset:2048             // 000000046754: DC520800 2E7C003E
	global_load_b32 v47, v[62:63], off offset:3072             // 00000004675C: DC520C00 2F7C003E
	global_load_b32 v57, v[67:68], off                         // 000000046764: DC520000 397C0043
	global_load_b32 v59, v[67:68], off offset:1024             // 00000004676C: DC520400 3B7C0043
	global_load_b32 v54, v[52:53], off offset:-4096            // 000000046774: DC521000 367C0034
	global_load_b32 v64, v[52:53], off                         // 00000004677C: DC520000 407C0034
	global_load_b32 v53, v[60:61], off offset:-4096            // 000000046784: DC521000 357C003C
	global_load_b32 v63, v[60:61], off                         // 00000004678C: DC520000 3F7C003C
	global_load_b32 v52, v[65:66], off offset:-4096            // 000000046794: DC521000 347C0041
	global_load_b32 v62, v[65:66], off                         // 00000004679C: DC520000 3E7C0041
	global_load_b32 v60, v[67:68], off offset:2048             // 0000000467A4: DC520800 3C7C0043
	global_load_b32 v61, v[67:68], off offset:3072             // 0000000467AC: DC520C00 3D7C0043
	v_lshlrev_b32_e32 v65, 3, v0                               // 0000000467B4: 30820083
	s_cbranch_scc1 1                                           // 0000000467B8: BFA20001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4c0>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 0000000467BC: BE9C4D83
	s_load_b32 s39, s[0:1], 0x38                               // 0000000467C0: F40009C0 F8000038
	v_lshrrev_b32_e32 v69, 4, v0                               // 0000000467C8: 328A0084
	s_mul_hi_i32 s4, s2, 0x55555556                            // 0000000467CC: 9704FF02 55555556
	v_and_b32_e32 v67, 0x78, v65                               // 0000000467D4: 368682FF 00000078
	s_lshr_b32 s14, s4, 31                                     // 0000000467DC: 850E9F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000467E0: BF870499
	s_add_i32 s4, s4, s14                                      // 0000000467E4: 81040E04
	s_lshl_b32 s14, s4, 7                                      // 0000000467E8: 840E8704
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000467EC: BF870001
	v_lshlrev_b32_e32 v67, 1, v67                              // 0000000467F0: 30868681
	s_ashr_i32 s15, s14, 31                                    // 0000000467F4: 860F9F0E
	s_mov_b32 s4, exec_lo                                      // 0000000467F8: BE84007E
	s_lshl_b64 s[14:15], s[14:15], 1                           // 0000000467FC: 848E810E
	s_waitcnt lgkmcnt(0)                                       // 000000046800: BF89FC07
	s_add_i32 s40, s39, -1                                     // 000000046804: 8128C127
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046808: BF870099
	v_min_i32_e32 v66, s40, v69                                // 00000004680C: 22848A28
	v_mad_i64_i32 v[65:66], null, 0x5000, v66, s[8:9]          // 000000046810: D6FF7C41 002284FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004681C: BF870091
	.long 0xd7006a41                                           // 000000046820: D7006A41
	v_cndmask_b32_e32 v0, v65, v14, vcc_lo                     // 000000046824: 02001D41
	v_add_co_ci_u32_e64 v66, null, s15, v66, vcc_lo            // 000000046828: D5207C42 01AA840F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046830: BF870092
	.long 0xd7006a41                                           // 000000046834: D7006A41
	v_cndmask_b32_e32 v1, v65, v67, vcc_lo                     // 000000046838: 02028741
	v_add_co_ci_u32_e64 v66, null, 0, v66, vcc_lo              // 00000004683C: D5207C42 01AA8480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046844: BF870092
	.long 0xd7006a43                                           // 000000046848: D7006A43
	v_cndmask_b32_e32 v1, 0x1000, v65, vcc_lo                  // 00000004684C: 020282FF 00001000
	v_add_co_ci_u32_e64 v68, null, 0, v66, vcc_lo              // 000000046854: D5207C44 01AA8480
	s_clause 0x1                                               // 00000004685C: BF850001
	global_load_b128 v[74:77], v[65:66], off                   // 000000046860: DC5E0000 4A7C0041
	global_load_b128 v[78:81], v[67:68], off                   // 000000046868: DC5E0000 4E7C0043
	.long 0xd4c3007e                                           // 000000046870: D4C3007E
	v_cndmask_b32_e32 v1, s39, v69, vcc_lo                     // 000000046874: 02028A27
	s_cbranch_execz 11                                         // 000000046878: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5a8>
	s_waitcnt vmcnt(1)                                         // 00000004687C: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 000000046880: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000046884: BF870001
	v_mov_b32_e32 v75, v76                                     // 000000046888: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 00000004688C: 7E94034C
	s_waitcnt vmcnt(0)                                         // 000000046890: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 000000046894: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 000000046898: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 00000004689C: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 0000000468A0: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 0000000468A4: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000468A8: 8C7E047E
	v_cmp_gt_u32_e32 vcc_lo, 16, v0                            // 0000000468AC: 7C980090
	.long 0xd4440004                                           // 0000000468B0: D4440004
	v_cndmask_b32_e32 v1, s39, v0, vcc_lo                      // 0000000468B4: 02020027
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v140, 0            // 0000000468B8: CA100080 418C0080
	s_and_b32 s16, vcc_lo, s4                                  // 0000000468C0: 8B10046A
	scratch_store_b32 off, v65, off                            // 0000000468C4: DC690000 007C4100
	s_and_saveexec_b32 s4, s16                                 // 0000000468CC: BE842010
	s_cbranch_execz 30                                         // 0000000468D0: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x64c>
	v_mul_u32_u24_e32 v65, 0xc0, v0                            // 0000000468D4: 168200FF 000000C0
	s_lshl_b64 s[16:17], s[2:3], 2                             // 0000000468DC: 84908202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000468E0: BF870091
	.long 0xd7001242                                           // 0000000468E4: D7001242
	v_cndmask_b32_e32 v1, s10, v65, vcc_lo                     // 0000000468E8: 0202820A
	v_add_co_ci_u32_e64 v67, null, s11, 0, s18                 // 0000000468EC: D5207C43 0049000B
	.long 0xd7001244                                           // 0000000468F4: D7001244
	v_cndmask_b32_e32 v1, s12, v65, vcc_lo                     // 0000000468F8: 0202820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000468FC: BF870211
	v_add_co_ci_u32_e64 v69, null, s13, 0, s18                 // 000000046900: D5207C45 0049000D
	.long 0xd7006a41                                           // 000000046908: D7006A41
	v_cndmask_b32_e32 v0, v66, v16, vcc_lo                     // 00000004690C: 02002142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000046910: BF870211
	v_add_co_ci_u32_e64 v66, null, s17, v67, vcc_lo            // 000000046914: D5207C42 01AA8611
	.long 0xd7006a43                                           // 00000004691C: D7006A43
	v_cndmask_b32_e32 v0, v68, v16, vcc_lo                     // 000000046920: 02002144
	s_delay_alu instid0(VALU_DEP_1)                            // 000000046924: BF870001
	v_add_co_ci_u32_e64 v68, null, s17, v69, vcc_lo            // 000000046928: D5207C44 01AA8A11
	global_load_b32 v140, v[65:66], off                        // 000000046930: DC520000 8C7C0041
	global_load_b32 v65, v[67:68], off                         // 000000046938: DC520000 417C0043
	s_waitcnt vmcnt(0)                                         // 000000046940: BF8903F7
	scratch_store_b32 off, v65, off                            // 000000046944: DC690000 007C4100
	s_or_b32 exec_lo, exec_lo, s4                              // 00000004694C: 8C7E047E
	s_waitcnt vmcnt(62)                                        // 000000046950: BF89FBF7
	v_dual_mul_f32 v139, 0x43800000, v5 :: v_dual_mul_f32 v138, 0x43800000, v6// 000000046954: C8C60AFF 8B8A0CFF 43800000
	v_dual_mul_f32 v137, 0x43800000, v7 :: v_dual_mul_f32 v136, 0x43800000, v8// 000000046960: C8C60EFF 898810FF 43800000
	s_waitcnt vmcnt(9)                                         // 00000004696C: BF8927F7
	v_dual_mul_f32 v135, 0x43800000, v54 :: v_dual_mul_f32 v54, 0x43800000, v4// 000000046970: C8C66CFF 873608FF 43800000
	v_dual_mul_f32 v134, 0x43800000, v2 :: v_dual_mul_f32 v133, 0x43800000, v3// 00000004697C: C8C604FF 868406FF 43800000
	s_waitcnt vmcnt(8)                                         // 000000046988: BF8923F7
	v_dual_mul_f32 v132, 0x43800000, v64 :: v_dual_mul_f32 v131, 0x43800000, v1// 00000004698C: C8C680FF 848202FF 43800000
	v_dual_mul_f32 v130, 0x43800000, v12 :: v_dual_mul_f32 v129, 0x43800000, v13// 000000046998: C8C618FF 82801AFF 43800000
	s_waitcnt vmcnt(7)                                         // 0000000469A4: BF891FF7
	v_dual_mul_f32 v128, 0x43800000, v53 :: v_dual_mul_f32 v53, 0x43800000, v11// 0000000469A8: C8C66AFF 803416FF 43800000
	v_dual_mul_f32 v127, 0x43800000, v9 :: v_dual_mul_f32 v126, 0x43800000, v10// 0000000469B4: C8C612FF 7F7E14FF 43800000
	s_waitcnt vmcnt(6)                                         // 0000000469C0: BF891BF7
	v_dual_mul_f32 v125, 0x43800000, v63 :: v_dual_mul_f32 v124, 0x43800000, v14// 0000000469C4: C8C67EFF 7D7C1CFF 43800000
	v_dual_mul_f32 v123, 0x43800000, v15 :: v_dual_mul_f32 v122, 0x43800000, v16// 0000000469D0: C8C61EFF 7B7A20FF 43800000
	s_waitcnt vmcnt(5)                                         // 0000000469DC: BF8917F7
	v_dual_mul_f32 v121, 0x43800000, v52 :: v_dual_mul_f32 v52, 0x43800000, v22// 0000000469E0: C8C668FF 79342CFF 43800000
	v_dual_mul_f32 v120, 0x43800000, v20 :: v_dual_mul_f32 v119, 0x43800000, v21// 0000000469EC: C8C628FF 78762AFF 43800000
	s_waitcnt vmcnt(4)                                         // 0000000469F8: BF8913F7
	v_dual_mul_f32 v118, 0x43800000, v62 :: v_dual_mul_f32 v117, 0x43800000, v17// 0000000469FC: C8C67CFF 767422FF 43800000
	v_dual_mul_f32 v116, 0x43800000, v18 :: v_dual_mul_f32 v115, 0x43800000, v19// 000000046A08: C8C624FF 747226FF 43800000
	v_dual_mul_f32 v114, 0x43800000, v51 :: v_dual_mul_f32 v111, 0x43800000, v58// 000000046A14: C8C666FF 726E74FF 43800000
	v_dual_mul_f32 v113, 0x43800000, v23 :: v_dual_mul_f32 v112, 0x43800000, v24// 000000046A20: C8C62EFF 717030FF 43800000
	v_dual_mul_f32 v51, 0x43800000, v31 :: v_dual_mul_f32 v110, 0x43800000, v28// 000000046A2C: C8C63EFF 336E38FF 43800000
	v_dual_mul_f32 v109, 0x43800000, v29 :: v_dual_mul_f32 v108, 0x43800000, v30// 000000046A38: C8C63AFF 6D6C3CFF 43800000
	v_dual_mul_f32 v107, 0x43800000, v50 :: v_dual_mul_f32 v106, 0x43800000, v25// 000000046A44: C8C664FF 6B6A32FF 43800000
	v_dual_mul_f32 v105, 0x43800000, v26 :: v_dual_mul_f32 v50, 0x43800000, v27// 000000046A50: C8C634FF 693236FF 43800000
	v_dual_mul_f32 v104, 0x43800000, v56 :: v_dual_mul_f32 v101, 0x43800000, v37// 000000046A5C: C8C670FF 68644AFF 43800000
	v_dual_mul_f32 v103, 0x43800000, v32 :: v_dual_mul_f32 v98, 0x43800000, v34// 000000046A68: C8C640FF 676244FF 43800000
	v_dual_mul_f32 v102, 0x43800000, v36 :: v_dual_mul_f32 v99, 0x43800000, v33// 000000046A74: C8C648FF 666242FF 43800000
	v_dual_mul_f32 v100, 0x43800000, v44 :: v_dual_mul_f32 v97, 0x43800000, v43// 000000046A80: C8C658FF 646056FF 43800000
	v_dual_mul_f32 v58, 0x43800000, v35 :: v_dual_mul_f32 v93, 0x43800000, v42// 000000046A8C: C8C646FF 3A5C54FF 43800000
	v_dual_mul_f32 v96, 0x43800000, v38 :: v_dual_mul_f32 v95, 0x43800000, v39// 000000046A98: C8C64CFF 605E4EFF 43800000
	v_dual_mul_f32 v94, 0x43800000, v40 :: v_dual_mul_f32 v91, 0x43800000, v49// 000000046AA4: C8C650FF 5E5A62FF 43800000
	v_dual_mul_f32 v92, 0x43800000, v48 :: v_dual_mul_f32 v141, 0x43800000, v45// 000000046AB0: C8C660FF 5C8C5AFF 43800000
	v_dual_mul_f32 v152, 0x43800000, v55 :: v_dual_mul_f32 v191, 0x43800000, v57// 000000046ABC: C8C66EFF 98BE72FF 43800000
	v_dual_mul_f32 v90, 0x43800000, v41 :: v_dual_mul_f32 v189, 0x43800000, v59// 000000046AC8: C8C652FF 5ABC76FF 43800000
	s_waitcnt vmcnt(2)                                         // 000000046AD4: BF890BF7
	v_dual_mul_f32 v150, 0x43800000, v46 :: v_dual_mul_f32 v151, 0x43800000, v61// 000000046AD8: C8C65CFF 96967AFF 43800000
	v_mul_f32_e32 v142, 0x43800000, v47                        // 000000046AE4: 111C5EFF 43800000
	v_mul_f32_e32 v190, 0x43800000, v60                        // 000000046AEC: 117C78FF 43800000
	s_cmp_lt_i32 s39, 1                                        // 000000046AF4: BF048127
	s_cbranch_scc1 4716                                        // 000000046AF8: BFA2126C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x51ac>
	s_add_u32 s30, s8, s14                                     // 000000046AFC: 801E0E08
	s_addc_u32 s31, s9, s15                                    // 000000046B00: 821F0F09
	s_lshl_b64 s[14:15], s[2:3], 2                             // 000000046B04: 848E8202
	s_load_b64 s[26:27], s[0:1], 0x68                          // 000000046B08: F4040680 F8000068
	s_add_u32 s10, s10, s14                                    // 000000046B10: 800A0E0A
	s_addc_u32 s11, s11, s15                                   // 000000046B14: 820B0F0B
	s_add_u32 s34, s12, s14                                    // 000000046B18: 80220E0C
	s_addc_u32 s35, s13, s15                                   // 000000046B1C: 82230F0D
	s_add_i32 s3, s39, 15                                      // 000000046B20: 81038F27
	s_load_b256 s[12:19], s[0:1], 0x48                         // 000000046B24: F40C0300 F8000048
	s_ashr_i32 s4, s3, 31                                      // 000000046B2C: 86049F03
	.long 0xd71f008f                                           // 000000046B30: D71F008F
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000046B34: 020100C1
	s_lshr_b32 s4, s4, 28                                      // 000000046B38: 85049C04
	v_mov_b32_e32 v1, 0                                        // 000000046B3C: 7E020280
	s_add_i32 s3, s3, s4                                       // 000000046B40: 81030403
	v_mov_b32_e32 v149, 0x1000504                              // 000000046B44: 7F2A02FF 01000504
	s_waitcnt lgkmcnt(0)                                       // 000000046B4C: BF89FC07
	s_ashr_i32 s15, s3, 4                                      // 000000046B50: 860F8403
	s_cmp_lg_u32 s21, 0                                        // 000000046B54: BF078015
	s_movk_i32 s3, 0x5f40                                      // 000000046B58: B0035F40
	s_cselect_b32 s41, -1, 0                                   // 000000046B5C: 982980C1
	s_lshl_b32 s22, s2, 7                                      // 000000046B60: 84168702
	v_and_b32_e32 v2, 16, v143                                 // 000000046B64: 36051E90
	s_ashr_i32 s23, s22, 31                                    // 000000046B68: 86179F16
	s_cmp_gt_u32 s20, 63                                       // 000000046B6C: BF08BF14
	v_xor_b32_e32 v146, 2, v143                                // 000000046B70: 3B251E82
	s_cselect_b32 s42, -1, 0                                   // 000000046B74: 982A80C1
	s_cmp_eq_u32 s21, 0                                        // 000000046B78: BF068015
	v_add_nc_u32_e32 v144, 16, v2                              // 000000046B7C: 4B200490
	s_cselect_b32 s2, -1, 0                                    // 000000046B80: 980280C1
	v_xor_b32_e32 v147, 4, v143                                // 000000046B84: 3B271E84
	s_and_b32 s4, s2, exec_lo                                  // 000000046B88: 8B047E02
	s_cselect_b32 s43, s3, 0x5f80                              // 000000046B8C: 982BFF03 00005F80
	s_lshl_b64 s[36:37], s[22:23], 1                           // 000000046B94: 84A48116
	v_xor_b32_e32 v148, 8, v143                                // 000000046B98: 3B291E88
	s_add_u32 s44, s24, s36                                    // 000000046B9C: 802C2418
	s_addc_u32 s45, s25, s37                                   // 000000046BA0: 822D2519
	s_max_i32 s46, s15, 1                                      // 000000046BA4: 8A2E810F
	s_add_u32 s16, s16, s6                                     // 000000046BA8: 80100610
	s_addc_u32 s17, s17, s7                                    // 000000046BAC: 82110711
	s_add_u32 s18, s18, s6                                     // 000000046BB0: 80120612
	s_mov_b32 s20, 0                                           // 000000046BB4: BE940080
	s_addc_u32 s19, s19, s7                                    // 000000046BB8: 82130713
	s_add_u32 s47, s26, s6                                     // 000000046BBC: 802F061A
	s_addc_u32 s7, s27, s7                                     // 000000046BC0: 8207071B
	s_mov_b32 s48, 0x41800000                                  // 000000046BC4: BEB000FF 41800000
	s_movk_i32 s49, 0x1800                                     // 000000046BCC: B0311800
	s_movk_i32 s50, 0x2900                                     // 000000046BD0: B0322900
	s_mov_b32 s21, s20                                         // 000000046BD4: BE950014
	s_mov_b32 s22, s20                                         // 000000046BD8: BE960014
	s_mov_b32 s23, s20                                         // 000000046BDC: BE970014
	s_mov_b32 s24, s20                                         // 000000046BE0: BE980014
	s_mov_b32 s25, s20                                         // 000000046BE4: BE990014
	s_mov_b32 s26, s20                                         // 000000046BE8: BE9A0014
	s_mov_b32 s27, s20                                         // 000000046BEC: BE9B0014
	s_mov_b32 s51, 0x3d800000                                  // 000000046BF0: BEB300FF 3D800000
	s_mov_b32 s52, 0x76543210                                  // 000000046BF8: BEB400FF 76543210
	s_mov_b32 s53, s20                                         // 000000046C00: BEB50014
	s_mov_b32 s6, s20                                          // 000000046C04: BE860014
	s_branch 10                                                // 000000046C08: BFA0000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x934>
	v_mov_b32_e32 v151, v65                                    // 000000046C0C: 7F2E0341
	v_mov_b32_e32 v152, v57                                    // 000000046C10: 7F300339
	v_mov_b32_e32 v58, v49                                     // 000000046C14: 7E740331
	v_mov_b32_e32 v50, v9                                      // 000000046C18: 7E640309
	v_mov_b32_e32 v51, v17                                     // 000000046C1C: 7E660311
	v_mov_b32_e32 v52, v25                                     // 000000046C20: 7E680319
	v_mov_b32_e32 v53, v33                                     // 000000046C24: 7E6A0321
	v_mov_b32_e32 v54, v41                                     // 000000046C28: 7E6C0329
	s_cmp_eq_u32 s53, s46                                      // 000000046C2C: BF062E35
	s_cbranch_scc1 4628                                        // 000000046C30: BFA21214 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5184>
	v_mov_b32_e32 v44, v0                                      // 000000046C34: 7E580300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000046C38: BF8701B1
	v_ashrrev_i32_e32 v2, 4, v44                               // 000000046C3C: 34045884
	v_and_b32_e32 v55, 15, v44                                 // 000000046C40: 366E588F
	.long 0xd4440003                                           // 000000046C44: D4440003
	v_cndmask_b32_e32 v1, 16, v44, vcc_lo                      // 000000046C48: 02025890
	.long 0xd72c0003                                           // 000000046C4C: D72C0003
	v_cndmask_b32_e32 v1, 0x110, v2, vcc_lo                    // 000000046C50: 020204FF 00000110
	s_delay_alu instid0(VALU_DEP_1)                            // 000000046C58: BF870001
	v_lshl_add_u32 v3, v55, 4, v3                              // 000000046C5C: D6460003 040D0937
	s_waitcnt vmcnt(1)                                         // 000000046C64: BF8907F7
	ds_store_b128 v3, v[74:77] offset:10496                    // 000000046C68: DB7C2900 00004A03
	s_waitcnt vmcnt(0)                                         // 000000046C70: BF8903F7
	ds_store_b128 v3, v[78:81] offset:6144                     // 000000046C74: DB7C1800 00004E03
	s_and_saveexec_b32 s4, s3                                  // 000000046C7C: BE842003
	s_cbranch_execz 6                                          // 000000046C80: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x99c>
	scratch_load_b32 v4, off, off                              // 000000046C84: DC510000 047C0000
	v_lshlrev_b32_e32 v3, 2, v44                               // 000000046C8C: 30065882
	s_waitcnt vmcnt(0)                                         // 000000046C90: BF8903F7
	ds_store_b32 v3, v4 offset:24064                           // 000000046C94: D8345E00 00000403
	s_or_b32 exec_lo, exec_lo, s4                              // 000000046C9C: 8C7E047E
	v_and_b32_e32 v34, 1, v44                                  // 000000046CA0: 36445881
	s_lshl_b32 s54, s53, 4                                     // 000000046CA4: 84368435
	v_or_b32_e32 v153, s33, v55                                // 000000046CA8: 39326E21
	s_mov_b32 s29, exec_lo                                     // 000000046CAC: BE9D007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000046CB0: BF870112
	v_or_b32_e32 v15, s54, v34                                 // 000000046CB4: 381E4436
	v_and_b32_e32 v6, 0x7ffffffe, v153                         // 000000046CB8: 360D32FF 7FFFFFFE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000046CC0: BF870232
	v_min_i32_e32 v3, s40, v15                                 // 000000046CC4: 22061E28
	v_or_b32_e32 v5, 2, v15                                    // 000000046CC8: 380A1E82
	v_or_b32_e32 v7, 4, v15                                    // 000000046CCC: 380E1E84
	v_lshlrev_b32_e32 v19, 1, v6                               // 000000046CD0: 30260C81
	v_or_b32_e32 v8, 6, v15                                    // 000000046CD4: 38101E86
	v_mad_i64_i32 v[3:4], null, 0x5000, v3, s[8:9]             // 000000046CD8: D6FF7C03 002206FF 00005000
	v_min_i32_e32 v5, s40, v5                                  // 000000046CE4: 220A0A28
	v_min_i32_e32 v7, s40, v7                                  // 000000046CE8: 220E0E28
	v_or_b32_e32 v17, 12, v15                                  // 000000046CEC: 38221E8C
	v_min_i32_e32 v8, s40, v8                                  // 000000046CF0: 22101028
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000046CF4: BF8700A4
	v_mad_i64_i32 v[5:6], null, 0x5000, v5, s[8:9]             // 000000046CF8: D6FF7C05 00220AFF 00005000
	.long 0xd7006a09                                           // 000000046D04: D7006A09
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000046D08: 02004903
	v_add_co_ci_u32_e64 v10, null, s37, v4, vcc_lo             // 000000046D0C: D5207C0A 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v7, s[8:9]             // 000000046D14: D6FF7C03 00220EFF 00005000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046D20: BF870093
	.long 0xd7006a07                                           // 000000046D24: D7006A07
	v_cndmask_b32_e32 v1, v9, v19, vcc_lo                      // 000000046D28: 02022709
	v_add_co_ci_u32_e64 v9, null, 0, v10, vcc_lo               // 000000046D2C: D5207C09 01AA1480
	.long 0xd7006a0a                                           // 000000046D34: D7006A0A
	v_cndmask_b32_e32 v0, v5, v36, vcc_lo                      // 000000046D38: 02004905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000046D3C: BF870211
	v_add_co_ci_u32_e64 v11, null, s37, v6, vcc_lo             // 000000046D40: D5207C0B 01AA0C25
	.long 0xd7006a05                                           // 000000046D48: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 000000046D4C: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000046D54: BF870211
	v_add_co_ci_u32_e64 v6, null, 0, v9, vcc_lo                // 000000046D58: D5207C06 01AA1280
	.long 0xd7006a07                                           // 000000046D60: D7006A07
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 000000046D64: 0202270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000046D68: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v11, vcc_lo               // 000000046D6C: D5207C09 01AA1680
	.long 0xd7006a0a                                           // 000000046D74: D7006A0A
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000046D78: 02004903
	v_add_co_ci_u32_e64 v11, null, s37, v4, vcc_lo             // 000000046D7C: D5207C0B 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v8, s[8:9]             // 000000046D84: D6FF7C03 002210FF 00005000
	.long 0xd7006a07                                           // 000000046D90: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 000000046D94: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000046D9C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v9, vcc_lo                // 000000046DA0: D5207C08 01AA1280
	.long 0xd7006a09                                           // 000000046DA8: D7006A09
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 000000046DAC: 0202270A
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo              // 000000046DB0: D5207C0A 01AA1680
	v_or_b32_e32 v11, 8, v15                                   // 000000046DB8: 38161E88
	.long 0xd7006a03                                           // 000000046DBC: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000046DC0: 02004903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000046DC4: BF870191
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 000000046DC8: D5207C04 01AA0825
	v_min_i32_e32 v11, s40, v11                                // 000000046DD0: 22161628
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046DD4: BF870093
	.long 0xd7006a0c                                           // 000000046DD8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000046DDC: 02022703
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 000000046DE0: D5207C0D 01AA0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000046DE8: BF8700A3
	v_mad_i64_i32 v[3:4], null, 0x5000, v11, s[8:9]            // 000000046DEC: D6FF7C03 002216FF 00005000
	.long 0xd7006a09                                           // 000000046DF8: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v9, vcc_lo                   // 000000046DFC: 020212FF 00002000
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 000000046E04: D5207C0A 01AA1480
	.long 0xd7006a0b                                           // 000000046E0C: D7006A0B
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 000000046E10: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000046E18: BF8700B1
	v_add_co_ci_u32_e64 v12, null, 0, v13, vcc_lo              // 000000046E1C: D5207C0C 01AA1A80
	v_or_b32_e32 v13, 10, v15                                  // 000000046E24: 381A1E8A
	.long 0xd7006a03                                           // 000000046E28: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000046E2C: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 000000046E30: D5207C04 01AA0825
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000046E38: BF870193
	v_min_i32_e32 v13, s40, v13                                // 000000046E3C: 221A1A28
	.long 0xd7006a0e                                           // 000000046E40: D7006A0E
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000046E44: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000046E48: BF870191
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 000000046E4C: D5207C10 01AA0880
	v_mad_i64_i32 v[3:4], null, 0x5000, v13, s[8:9]            // 000000046E54: D6FF7C03 00221AFF 00005000
	v_or_b32_e32 v15, 14, v15                                  // 000000046E60: 381E1E8E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046E64: BF870094
	.long 0xd7006a0d                                           // 000000046E68: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v14, vcc_lo                  // 000000046E6C: 02021CFF 00002000
	v_add_co_ci_u32_e64 v14, null, 0, v16, vcc_lo              // 000000046E74: D5207C0E 01AA2080
	v_min_i32_e32 v16, s40, v17                                // 000000046E7C: 22202228
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000046E80: BF8700A4
	v_min_i32_e32 v15, s40, v15                                // 000000046E84: 221E1E28
	.long 0xd7006a11                                           // 000000046E88: D7006A11
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000046E8C: 02004903
	v_add_co_ci_u32_e64 v18, null, s37, v4, vcc_lo             // 000000046E90: D5207C12 01AA0825
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000046E98: BF870194
	v_mad_i64_i32 v[3:4], null, 0x5000, v16, s[8:9]            // 000000046E9C: D6FF7C03 002220FF 00005000
	.long 0xd7006a11                                           // 000000046EA8: D7006A11
	v_cndmask_b32_e32 v1, v17, v19, vcc_lo                     // 000000046EAC: 02022711
	v_mad_i64_i32 v[15:16], null, 0x5000, v15, s[8:9]          // 000000046EB0: D6FF7C0F 00221EFF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000046EBC: BF870194
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 000000046EC0: D5207C12 01AA2480
	.long 0xd7006a11                                           // 000000046EC8: D7006A11
	v_cndmask_b32_e32 v1, 0x2000, v17, vcc_lo                  // 000000046ECC: 020222FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000046ED4: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 000000046ED8: D5207C12 01AA2480
	.long 0xd7006a03                                           // 000000046EE0: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000046EE4: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 000000046EE8: D5207C04 01AA0825
	.long 0xd7006a0f                                           // 000000046EF0: D7006A0F
	v_cndmask_b32_e32 v0, v15, v36, vcc_lo                     // 000000046EF4: 0200490F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000046EF8: BF870211
	v_add_co_ci_u32_e64 v16, null, s37, v16, vcc_lo            // 000000046EFC: D5207C10 01AA2025
	.long 0xd7006a03                                           // 000000046F04: D7006A03
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000046F08: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000046F0C: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000046F10: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 000000046F18: D7006A0F
	v_cndmask_b32_e32 v1, v15, v19, vcc_lo                     // 000000046F1C: 0202270F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000046F20: BF870211
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000046F24: D5207C10 01AA2080
	.long 0xd7006a03                                           // 000000046F2C: D7006A03
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 000000046F30: 020206FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000046F38: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000046F3C: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 000000046F44: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v15, vcc_lo                  // 000000046F48: 02021EFF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000046F50: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000046F54: D5207C10 01AA2080
	s_clause 0x7                                               // 000000046F5C: BF850007
	global_load_b32 v42, v[5:6], off                           // 000000046F60: DC520000 2A7C0005
	global_load_b32 v41, v[7:8], off                           // 000000046F68: DC520000 297C0007
	global_load_b32 v40, v[9:10], off                          // 000000046F70: DC520000 287C0009
	global_load_b32 v39, v[11:12], off                         // 000000046F78: DC520000 277C000B
	global_load_b32 v38, v[13:14], off                         // 000000046F80: DC520000 267C000D
	global_load_b32 v37, v[17:18], off                         // 000000046F88: DC520000 257C0011
	global_load_b32 v35, v[3:4], off                           // 000000046F90: DC520000 237C0003
	global_load_b32 v36, v[15:16], off                         // 000000046F98: DC520000 247C000F
	v_lshlrev_b32_e32 v5, 16, v78                              // 000000046FA0: 300A9C90
	v_and_b32_e32 v4, 0xffff0000, v74                          // 000000046FA4: 360894FF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v75                          // 000000046FAC: 361096FF FFFF0000
	v_lshlrev_b32_e32 v3, 16, v74                              // 000000046FB4: 30069490
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000046FB8: BF8701A4
	v_dual_mul_f32 v5, v5, v5 :: v_dual_lshlrev_b32 v12, 16, v80// 000000046FBC: C8E20B05 050CA090
	v_lshlrev_b32_e32 v7, 16, v75                              // 000000046FC4: 300E9690
	v_dual_mul_f32 v3, v3, v3 :: v_dual_and_b32 v6, 0xffff0000, v78// 000000046FC8: C8E40703 03069CFF FFFF0000
	v_mul_f32_e32 v4, v4, v4                                   // 000000046FD4: 10080904
	v_and_b32_e32 v13, 0xffff0000, v80                         // 000000046FD8: 361AA0FF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v76                         // 000000046FE0: 361498FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000046FE8: BF8701B4
	v_dual_mul_f32 v6, v6, v6 :: v_dual_and_b32 v11, 0xffff0000, v77// 000000046FEC: C8E40D06 060A9AFF FFFF0000
	v_mul_f32_e32 v12, v12, v12                                // 000000046FF8: 1018190C
	v_add_f32_e32 v3, v3, v4                                   // 000000046FFC: 06060903
	v_dual_add_f32 v4, v5, v6 :: v_dual_lshlrev_b32 v9, 16, v76// 000000047000: C9220D05 04089890
	v_dual_mul_f32 v5, v7, v7 :: v_dual_mul_f32 v6, v8, v8     // 000000047008: C8C60F07 05061108
	v_lshlrev_b32_e32 v7, 16, v79                              // 000000047010: 300E9E90
	v_dual_mul_f32 v13, v13, v13 :: v_dual_and_b32 v8, 0xffff0000, v79// 000000047014: C8E41B0D 0D089EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000047020: BF870113
	v_dual_add_f32 v5, v5, v6 :: v_dual_and_b32 v14, 0xffff0000, v81// 000000047024: C9240D05 050EA2FF FFFF0000
	v_dual_mul_f32 v6, v7, v7 :: v_dual_mul_f32 v7, v8, v8     // 000000047030: C8C60F07 06061108
	v_dual_mul_f32 v8, v9, v9 :: v_dual_mul_f32 v9, v10, v10   // 000000047038: C8C61309 0808150A
	v_lshlrev_b32_e32 v10, 16, v77                             // 000000047040: 30149A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000047044: BF870113
	v_dual_add_f32 v6, v6, v7 :: v_dual_add_f32 v7, v12, v13   // 000000047048: C9080F06 06061B0C
	v_dual_add_f32 v8, v8, v9 :: v_dual_mul_f32 v9, v10, v10   // 000000047050: C9061308 0808150A
	v_dual_mul_f32 v10, v11, v11 :: v_dual_lshlrev_b32 v11, 16, v81// 000000047058: C8E2170B 0A0AA290
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000047060: BF870113
	v_add_f32_e32 v4, v4, v6                                   // 000000047064: 06080D04
	v_dual_add_f32 v9, v9, v10 :: v_dual_mul_f32 v10, v11, v11 // 000000047068: C9061509 090A170B
	v_mul_f32_e32 v11, v14, v14                                // 000000047070: 10161D0E
	v_add_f32_e32 v3, v3, v5                                   // 000000047074: 06060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047078: BF870123
	v_add_f32_e32 v5, v8, v9                                   // 00000004707C: 060A1308
	v_xor_b32_e32 v9, 1, v143                                  // 000000047080: 3A131E81
	v_dual_add_f32 v8, v10, v11 :: v_dual_add_f32 v3, v3, v5   // 000000047084: C908170A 08020B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000004708C: BF8701A2
	v_cmp_lt_u32_e32 vcc_lo, v9, v144                          // 000000047090: 7C932109
	v_cndmask_b32_e32 v9, v143, v9, vcc_lo                     // 000000047094: 0212138F
	v_add_f32_e32 v5, v7, v8                                   // 000000047098: 060A1107
	v_cmp_lt_u32_e32 vcc_lo, v146, v144                        // 00000004709C: 7C932192
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000470A0: BF870193
	v_lshlrev_b32_e32 v6, 2, v9                                // 0000000470A4: 300C1282
	v_dual_add_f32 v4, v4, v5 :: v_dual_cndmask_b32 v7, v143, v146// 0000000470A8: C9120B04 0407258F
	v_cmp_lt_u32_e32 vcc_lo, v147, v144                        // 0000000470B0: 7C932193
	ds_bpermute_b32 v5, v6, v3                                 // 0000000470B4: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 0000000470BC: DACC0000 06000406
	s_waitcnt lgkmcnt(0)                                       // 0000000470C4: BF89FC07
	v_dual_add_f32 v4, v4, v6 :: v_dual_add_f32 v3, v3, v5     // 0000000470C8: C9080D04 04020B03
	v_lshlrev_b32_e32 v5, 2, v7                                // 0000000470D0: 300A0E82
	ds_bpermute_b32 v6, v5, v3                                 // 0000000470D4: DACC0000 06000305
	ds_bpermute_b32 v5, v5, v4                                 // 0000000470DC: DACC0000 05000405
	v_cndmask_b32_e32 v7, v143, v147, vcc_lo                   // 0000000470E4: 020F278F
	v_cmp_lt_u32_e32 vcc_lo, v148, v144                        // 0000000470E8: 7C932194
	s_waitcnt lgkmcnt(0)                                       // 0000000470EC: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v5     // 0000000470F0: C9080D03 03040B04
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000470F8: BF870003
	v_dual_cndmask_b32 v7, v143, v148 :: v_dual_lshlrev_b32 v6, 2, v7// 0000000470FC: CA63298F 07060E82
	ds_bpermute_b32 v5, v6, v3                                 // 000000047104: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 00000004710C: DACC0000 06000406
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000047114: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 000000047118: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000004711C: C9080B03 03040D04
	ds_bpermute_b32 v5, v7, v3                                 // 000000047124: DACC0000 05000307
	ds_bpermute_b32 v6, v7, v4                                 // 00000004712C: DACC0000 06000407
	v_cmpx_eq_u32_e32 0, v55                                   // 000000047134: 7D946E80
	s_cbranch_execz 41                                         // 000000047138: BFA50029 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xee0>
	s_waitcnt lgkmcnt(0)                                       // 00000004713C: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 000000047140: C9080B03 03040D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047148: BF870091
	v_dual_add_f32 v3, 0x358637bd, v3 :: v_dual_add_f32 v4, 0x358637bd, v4// 00000004714C: C90806FF 030408FF 358637BD
	v_dual_mul_f32 v5, 0x4b800000, v3 :: v_dual_mul_f32 v6, 0x4b800000, v4// 000000047158: C8C606FF 050608FF 4B800000
	.long 0xd4140004                                           // 000000047164: D4140004
	v_cndmask_b32_e32 v1, 0x800000, v4, vcc_lo                 // 000000047168: 020208FF 00800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v3                      // 000000047170: 7C2806FF 00800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047178: BF870092
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 00000004717C: D5010004 00120D04
	v_rsq_f32_e32 v4, v4                                       // 000000047184: 7E085D04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047188: BF870095
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_mul_f32 v6, 0x45800000, v4// 00000004718C: CA460B03 030608FF 45800000
	v_rsq_f32_e32 v3, v3                                       // 000000047198: 7E065D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 00000004719C: BF870321
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 0000000471A0: D5010004 00120D04
	v_rsq_f32_e32 v6, 0x43000000                               // 0000000471A8: 7E0C5CFF 43000000
	v_mul_f32_e32 v5, 0x45800000, v3                           // 0000000471B0: 100A06FF 45800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000471B8: BF870001
	v_cndmask_b32_e32 v3, v3, v5, vcc_lo                       // 0000000471BC: 02060B03
	v_lshlrev_b32_e32 v5, 2, v2                                // 0000000471C0: 300A0482
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 0000000471C4: BF870105
	v_mul_f32_e32 v3, v6, v3                                   // 0000000471C8: 10060706
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000471CC: BF870002
	v_add_nc_u32_e32 v5, 0x5c00, v5                            // 0000000471D0: 4A0A0AFF 00005C00
	ds_store_2addr_b32 v5, v4, v3 offset0:208 offset1:224      // 0000000471D8: D838E0D0 00030405
	s_or_b32 exec_lo, exec_lo, s29                             // 0000000471E0: 8C7E1D7E
	v_and_b32_e32 v43, 31, v44                                 // 0000000471E4: 3656589F
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 0000000471E8: 916A027E
	s_cbranch_vccnz 119                                        // 0000000471EC: BFA40077 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10cc>
	.long 0xd7600045                                           // 0000000471F0: D7600045
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                   // 0000000471F4: 0201018C
	.long 0xd7600044                                           // 0000000471F8: D7600044
	v_cndmask_b32_e32 v0, v140, v129, vcc_lo                   // 0000000471FC: 0201038C
	.long 0xd7600043                                           // 000000047200: D7600043
	v_cndmask_b32_e32 v0, v140, v130, vcc_lo                   // 000000047204: 0201058C
	.long 0xd7600042                                           // 000000047208: D7600042
	v_cndmask_b32_e32 v0, v140, v131, vcc_lo                   // 00000004720C: 0201078C
	.long 0xd7600041                                           // 000000047210: D7600041
	v_cndmask_b32_e32 v0, v140, v132, vcc_lo                   // 000000047214: 0201098C
	.long 0xd7600040                                           // 000000047218: D7600040
	v_cndmask_b32_e32 v0, v140, v133, vcc_lo                   // 00000004721C: 02010B8C
	.long 0xd760003f                                           // 000000047220: D760003F
	v_cndmask_b32_e32 v0, v140, v134, vcc_lo                   // 000000047224: 02010D8C
	.long 0xd760003e                                           // 000000047228: D760003E
	v_cndmask_b32_e32 v0, v140, v135, vcc_lo                   // 00000004722C: 02010F8C
	.long 0xd760003d                                           // 000000047230: D760003D
	v_cndmask_b32_e32 v0, v140, v136, vcc_lo                   // 000000047234: 0201118C
	.long 0xd760003c                                           // 000000047238: D760003C
	v_cndmask_b32_e32 v0, v140, v137, vcc_lo                   // 00000004723C: 0201138C
	.long 0xd760003b                                           // 000000047240: D760003B
	v_cndmask_b32_e32 v0, v140, v138, vcc_lo                   // 000000047244: 0201158C
	.long 0xd760003a                                           // 000000047248: D760003A
	v_cndmask_b32_e32 v0, v140, v139, vcc_lo                   // 00000004724C: 0201178C
	.long 0xd7600039                                           // 000000047250: D7600039
	v_cndmask_b32_e32 v0, v140, v140, vcc_lo                   // 000000047254: 0201198C
	.long 0xd7600038                                           // 000000047258: D7600038
	v_cndmask_b32_e32 v0, v140, v141, vcc_lo                   // 00000004725C: 02011B8C
	.long 0xd7600037                                           // 000000047260: D7600037
	v_cndmask_b32_e32 v0, v140, v142, vcc_lo                   // 000000047264: 02011D8C
	.long 0xd760001d                                           // 000000047268: D760001D
	v_cndmask_b32_e32 v0, v140, v143, vcc_lo                   // 00000004726C: 02011F8C
	s_mov_b32 s4, exec_lo                                      // 000000047270: BE84007E
	v_cmpx_gt_u32_e32 16, v43                                  // 000000047274: 7D985690
	s_cbranch_execz 83                                         // 000000047278: BFA50053 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10c8>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000004727C: 7C945680
	s_add_f32 s69, s69, 0                                      // 000000047280: A0458045
	v_lshlrev_b32_e32 v4, 2, v43                               // 000000047284: 30085682
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000047288: BF8704BA
	s_add_f32 s68, s69, s68                                    // 00000004728C: A0444445
	v_cndmask_b32_e64 v3, 0, s69, vcc_lo                       // 000000047290: D5010003 01A88A80
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 000000047298: 7C945681
	s_add_f32 s67, s68, s67                                    // 00000004729C: A0434344
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000472A0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s68, vcc_lo                      // 0000000472A4: D5010003 01A88903
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 0000000472AC: 7C945682
	s_add_f32 s66, s67, s66                                    // 0000000472B0: A0424243
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000472B4: BF8704A2
	v_cndmask_b32_e64 v3, v3, s67, vcc_lo                      // 0000000472B8: D5010003 01A88703
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 0000000472C0: 7C945683
	s_add_f32 s65, s66, s65                                    // 0000000472C4: A0414142
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000472C8: BF8704A2
	v_cndmask_b32_e64 v3, v3, s66, vcc_lo                      // 0000000472CC: D5010003 01A88503
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 0000000472D4: 7C945684
	s_add_f32 s64, s65, s64                                    // 0000000472D8: A0404041
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000472DC: BF8704A2
	v_cndmask_b32_e64 v3, v3, s65, vcc_lo                      // 0000000472E0: D5010003 01A88303
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 0000000472E8: 7C945685
	s_add_f32 s63, s64, s63                                    // 0000000472EC: A03F3F40
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000472F0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s64, vcc_lo                      // 0000000472F4: D5010003 01A88103
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 0000000472FC: 7C945686
	s_add_f32 s62, s63, s62                                    // 000000047300: A03E3E3F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000047304: BF8704A2
	v_cndmask_b32_e64 v3, v3, s63, vcc_lo                      // 000000047308: D5010003 01A87F03
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 000000047310: 7C945687
	s_add_f32 s61, s62, s61                                    // 000000047314: A03D3D3E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000047318: BF8704A2
	v_cndmask_b32_e64 v3, v3, s62, vcc_lo                      // 00000004731C: D5010003 01A87D03
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 000000047324: 7C945688
	s_add_f32 s60, s61, s60                                    // 000000047328: A03C3C3D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004732C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s61, vcc_lo                      // 000000047330: D5010003 01A87B03
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 000000047338: 7C945689
	s_add_f32 s59, s60, s59                                    // 00000004733C: A03B3B3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000047340: BF8704A2
	v_cndmask_b32_e64 v3, v3, s60, vcc_lo                      // 000000047344: D5010003 01A87903
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000004734C: 7C94568A
	s_add_f32 s58, s59, s58                                    // 000000047350: A03A3A3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000047354: BF8704A2
	v_cndmask_b32_e64 v3, v3, s59, vcc_lo                      // 000000047358: D5010003 01A87703
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 000000047360: 7C94568B
	s_add_f32 s57, s58, s57                                    // 000000047364: A039393A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000047368: BF8704A2
	v_cndmask_b32_e64 v3, v3, s58, vcc_lo                      // 00000004736C: D5010003 01A87503
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 000000047374: 7C94568C
	s_add_f32 s56, s57, s56                                    // 000000047378: A0383839
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004737C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s57, vcc_lo                      // 000000047380: D5010003 01A87303
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 000000047388: 7C94568D
	s_add_f32 s55, s56, s55                                    // 00000004738C: A0373738
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000047390: BF8704A2
	v_cndmask_b32_e64 v3, v3, s56, vcc_lo                      // 000000047394: D5010003 01A87103
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 00000004739C: 7C94568E
	s_add_f32 s29, s55, s29                                    // 0000000473A0: A01D1D37
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000473A4: BF870002
	v_cndmask_b32_e64 v3, v3, s55, vcc_lo                      // 0000000473A8: D5010003 01A86F03
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 0000000473B0: 7C94568F
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000000473B4: BF870482
	v_cndmask_b32_e64 v3, v3, s29, vcc_lo                      // 0000000473B8: D5010003 01A83B03
	ds_store_b32 v4, v3 offset:24128                           // 0000000473C0: D8345E40 00000304
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000473C8: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000473CC: BF89FC07
	s_barrier                                                  // 0000000473D0: BFBD0000
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 0000000473D4: 916A267E
	s_cbranch_vccz 10                                          // 0000000473D8: BFA3000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1104>
	s_add_i32 s53, s53, 1                                      // 0000000473DC: 81358135
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000473E0: BF870009
	s_cmp_ge_i32 s53, s15                                      // 0000000473E4: BF030F35
	s_cbranch_scc0 11                                          // 0000000473E8: BFA1000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1118>
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 0000000473EC: 916A267E
	s_cbranch_vccz 82                                          // 0000000473F0: BFA30052 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x123c>
	s_and_b32 vcc_lo, exec_lo, s42                             // 0000000473F4: 8B6A2A7E
	s_mov_b32 s3, -1                                           // 0000000473F8: BE8300C1
	s_cbranch_vccnz 87                                         // 0000000473FC: BFA40057 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x125c>
	s_branch 166                                               // 000000047400: BFA000A6 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x139c>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 000000047404: BE9C4D83
	s_add_i32 s53, s53, 1                                      // 000000047408: 81358135
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004740C: BF870009
	s_cmp_ge_i32 s53, s15                                      // 000000047410: BF030F35
	s_cbranch_scc1 65525                                       // 000000047414: BFA2FFF5 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10ec>
	s_lshl_b32 s4, s53, 4                                      // 000000047418: 84048435
	v_lshlrev_b32_e32 v4, 4, v44                               // 00000004741C: 30085884
	s_waitcnt lgkmcnt(0)                                       // 000000047420: BF89FC07
	v_add_nc_u32_e32 v6, s4, v2                                // 000000047424: 4A0C0404
	s_mov_b32 s29, exec_lo                                     // 000000047428: BE9D007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004742C: BF870112
	v_and_b32_e32 v4, 0xf0, v4                                 // 000000047430: 360808FF 000000F0
	v_min_i32_e32 v2, s40, v6                                  // 000000047438: 22040C28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004743C: BF870091
	v_mad_i64_i32 v[2:3], null, 0x5000, v2, s[30:31]           // 000000047440: D6FF7C02 007A04FF 00005000
	.long 0xd7006a02                                           // 00000004744C: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000047450: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000047454: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000047458: D5207C03 01AA0680
	.long 0xd7006a04                                           // 000000047460: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 000000047464: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004746C: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000047470: D5207C05 01AA0680
	s_clause 0x1                                               // 000000047478: BF850001
	global_load_b128 v[74:77], v[2:3], off                     // 00000004747C: DC5E0000 4A7C0002
	global_load_b128 v[78:81], v[4:5], off                     // 000000047484: DC5E0000 4E7C0004
	.long 0xd4c3007e                                           // 00000004748C: D4C3007E
	v_cndmask_b32_e32 v1, s39, v6, vcc_lo                      // 000000047490: 02020C27
	s_cbranch_execz 11                                         // 000000047494: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11c4>
	s_waitcnt vmcnt(1)                                         // 000000047498: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 00000004749C: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000474A0: BF870001
	v_mov_b32_e32 v75, v76                                     // 0000000474A4: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 0000000474A8: 7E94034C
	s_waitcnt vmcnt(0)                                         // 0000000474AC: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 0000000474B0: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 0000000474B4: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 0000000474B8: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 0000000474BC: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 0000000474C0: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s29                             // 0000000474C4: 8C7E1D7E
	s_and_saveexec_b32 s29, s3                                 // 0000000474C8: BE9D2003
	s_cbranch_execz 23                                         // 0000000474CC: BFA50017 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x122c>
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, s4, v44      // 0000000474D0: CA200080 03025804
	v_mov_b32_e32 v140, 0                                      // 0000000474D8: 7F180280
	s_mov_b32 s3, exec_lo                                      // 0000000474DC: BE83007E
	scratch_store_b32 off, v3, off                             // 0000000474E0: DC690000 007C0300
	.long 0xd4c4007e                                           // 0000000474E8: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 0000000474EC: 02020427
	s_cbranch_execz 13                                         // 0000000474F0: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1228>
	v_mad_i64_i32 v[3:4], null, 0xc0, v2, s[10:11]             // 0000000474F4: D6FF7C03 002A04FF 000000C0
	v_mad_i64_i32 v[5:6], null, 0xc0, v2, s[34:35]             // 000000047500: D6FF7C05 008A04FF 000000C0
	global_load_b32 v140, v[3:4], off                          // 00000004750C: DC520000 8C7C0003
	global_load_b32 v2, v[5:6], off                            // 000000047514: DC520000 027C0005
	s_waitcnt vmcnt(0)                                         // 00000004751C: BF8903F7
	scratch_store_b32 off, v2, off                             // 000000047520: DC690000 007C0200
	s_or_b32 exec_lo, exec_lo, s3                              // 000000047528: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000004752C: BF870499
	s_or_b32 exec_lo, exec_lo, s29                             // 000000047530: 8C7E1D7E
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 000000047534: 916A267E
	s_cbranch_vccnz 65454                                      // 000000047538: BFA4FFAE <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10f4>
	s_sendmsg_rtn_b64 s[56:57], sendmsg(MSG_RTN_GET_REALTIME)  // 00000004753C: BEB84D83
	s_waitcnt lgkmcnt(0)                                       // 000000047540: BF89FC07
	s_sub_i32 s3, s6, s28                                      // 000000047544: 81831C06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000047548: BF870009
	s_add_i32 s6, s3, s56                                      // 00000004754C: 81063803
	s_and_b32 vcc_lo, exec_lo, s42                             // 000000047550: 8B6A2A7E
	s_mov_b32 s3, -1                                           // 000000047554: BE8300C1
	s_cbranch_vccz 80                                          // 000000047558: BFA30050 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x139c>
	v_and_b32_e32 v2, -16, v44                                 // 00000004755C: 360458D0
	s_mov_b32 s3, exec_lo                                      // 000000047560: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000047564: BF870001
	v_cmpx_eq_u32_e32 64, v2                                   // 000000047568: 7D9404C0
	s_cbranch_execz 73                                         // 00000004756C: BFA50049 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1394>
	v_lshlrev_b32_e32 v4, 2, v44                               // 000000047570: 30085882
	s_waitcnt lgkmcnt(0)                                       // 000000047574: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000047578: BF870001
	v_add_nc_u32_e32 v5, 0x5c00, v4                            // 00000004757C: 4A0A08FF 00005C00
	ds_load_2addr_b32 v[2:3], v5 offset0:64 offset1:80         // 000000047584: D8DC5040 02000005
	ds_load_b32 v6, v1 offset:24188                            // 00000004758C: D8D85E7C 06000001
	s_waitcnt lgkmcnt(1)                                       // 000000047594: BF89FC17
	v_mul_f32_e32 v7, 0x3fb8aa3b, v3                           // 000000047598: 100E06FF 3FB8AA3B
	ds_load_b32 v8, v4 offset:24128                            // 0000000475A0: D8D85E40 08000004
	s_waitcnt lgkmcnt(1)                                       // 0000000475A8: BF89FC17
	v_sub_f32_e32 v6, v6, v3                                   // 0000000475AC: 080C0706
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 0000000475B0: 7C3606FF C2CE8ED0
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v7                          // 0000000475B8: D6130009 841E06FF 3FB8AA3B
	v_rndne_f32_e32 v10, v7                                    // 0000000475C4: 7E144707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000475C8: BF870114
	v_mul_f32_e32 v11, 0x3fb8aa3b, v6                          // 0000000475CC: 10160CFF 3FB8AA3B
	v_sub_f32_e32 v7, v7, v10                                  // 0000000475D4: 080E1507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000475D8: BF8701C2
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v11                        // 0000000475DC: D613000C 842E0CFF 3FB8AA3B
	v_fmac_f32_e32 v9, 0x32a5705f, v3                          // 0000000475E8: 561206FF 32A5705F
	v_cvt_i32_f32_e32 v10, v10                                 // 0000000475F0: 7E14110A
	v_rndne_f32_e32 v13, v11                                   // 0000000475F4: 7E1A470B
	v_dual_fmac_f32 v12, 0x32a5705f, v6 :: v_dual_add_f32 v7, v7, v9// 0000000475F8: C8080CFF 0C061307 32A5705F
	s_waitcnt lgkmcnt(0)                                       // 000000047604: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000047608: BF870112
	v_dual_sub_f32 v9, v11, v13 :: v_dual_mul_f32 v2, v8, v2   // 00000004760C: C9461B0B 09020508
	v_exp_f32_e32 v7, v7                                       // 000000047614: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047618: BF870125
	.long 0xd71c0007                                           // 00000004761C: D71C0007
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 000000047620: 02021507
	v_cvt_i32_f32_e32 v10, v13                                 // 000000047624: 7E14110D
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 000000047628: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000004762C: 7C3C06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000047634: BF8701B2
	v_cndmask_b32_e32 v3, 0x7f800000, v7, vcc_lo               // 000000047638: 02060EFF 7F800000
	v_add_f32_e32 v9, v9, v12                                  // 000000047640: 06121909
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 000000047644: 7C360CFF C2CE8ED0
	v_mul_f32_e32 v2, v3, v2                                   // 00000004764C: 10040503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047650: BF870093
	v_exp_f32_e32 v9, v9                                       // 000000047654: 7E124B09
	v_mul_f32_e32 v2, 0x41800000, v2                           // 000000047658: 100404FF 41800000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047660: BF870095
	.long 0xd71c0009                                           // 000000047664: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000047668: 02021509
	v_cndmask_b32_e32 v7, 0, v9, vcc_lo                        // 00000004766C: 020E1280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 000000047670: 7C3C0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000047678: BF870002
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 00000004767C: 020C0EFF 7F800000
	ds_store_b32 v4, v3 offset:24064                           // 000000047684: D8345E00 00000304
	ds_store_2addr_b32 v5, v6, v2 offset0:96 offset1:112       // 00000004768C: D8387060 00020605
	s_or_b32 exec_lo, exec_lo, s3                              // 000000047694: 8C7E037E
	s_mov_b32 s3, 0                                            // 000000047698: BE830080
	v_lshrrev_b32_e32 v154, 4, v43                             // 00000004769C: 33345684
	v_mul_u32_u24_e32 v57, 0x110, v55                          // 0000000476A0: 16726EFF 00000110
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 0000000476A8: 916A037E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000476AC: BF870002
	v_lshlrev_b32_e32 v56, 2, v154                             // 0000000476B0: 30713482
	s_cbranch_vccnz 871                                        // 0000000476B4: BFA40367 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2154>
	v_mad_u32_u24 v2, 0x110, v55, s49                          // 0000000476B8: D60B0002 00C66EFF 00000110
	s_and_b32 s3, s2, exec_lo                                  // 0000000476C4: 8B037E02
	s_cselect_b32 s3, 0, 0x1100                                // 0000000476C8: 9803FF80 00001100
	v_mad_u32_u24 v3, 0x110, v55, s50                          // 0000000476D0: D60B0003 00CA6EFF 00000110
	ds_load_b128 v[10:13], v57 offset:6144                     // 0000000476DC: DBFC1800 0A000039
	ds_load_b128 v[14:17], v57 offset:6160                     // 0000000476E4: DBFC1810 0E000039
	v_add_nc_u32_e32 v4, s3, v2                                // 0000000476EC: 4A080403
	v_mov_b32_e32 v8, v1                                       // 0000000476F0: 7E100301
	s_waitcnt lgkmcnt(0)                                       // 0000000476F4: BF89FC07
	v_mov_b32_e32 v5, v1                                       // 0000000476F8: 7E0A0301
	v_cndmask_b32_e64 v45, v3, v2, s2                          // 0000000476FC: D501002D 000A0503
	v_mov_b32_e32 v3, v1                                       // 000000047704: 7E060301
	ds_load_b128 v[18:21], v4                                  // 000000047708: DBFC0000 12000004
	ds_load_b128 v[22:25], v4 offset:16                        // 000000047710: DBFC0010 16000004
	ds_load_b128 v[26:29], v57 offset:6176                     // 000000047718: DBFC1820 1A000039
	ds_load_b128 v[30:33], v57 offset:6192                     // 000000047720: DBFC1830 1E000039
	ds_load_b128 v[59:62], v45 offset:32                       // 000000047728: DBFC0020 3B00002D
	ds_load_b128 v[63:66], v45 offset:48                       // 000000047730: DBFC0030 3F00002D
	ds_load_b128 v[155:158], v45 offset:64                     // 000000047738: DBFC0040 9B00002D
	ds_load_b128 v[159:162], v45 offset:80                     // 000000047740: DBFC0050 9F00002D
	ds_load_b128 v[167:170], v57 offset:6224                   // 000000047748: DBFC1850 A7000039
	ds_load_b128 v[163:166], v57 offset:6208                   // 000000047750: DBFC1840 A3000039
	v_mov_b32_e32 v2, v1                                       // 000000047758: 7E040301
	v_mov_b32_e32 v4, v1                                       // 00000004775C: 7E080301
	v_mov_b32_e32 v6, v1                                       // 000000047760: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000047764: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 000000047768: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004776C: BF870212
	v_mov_b32_e32 v8, v7                                       // 000000047770: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000047774: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 000000047778: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 00000004777C: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000047780: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000047784: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000047788: 7E040301
	ds_load_b128 v[175:178], v57 offset:6256                   // 00000004778C: DBFC1870 AF000039
	ds_load_b128 v[171:174], v57 offset:6240                   // 000000047794: DBFC1860 AB000039
	ds_load_b128 v[183:186], v45 offset:112                    // 00000004779C: DBFC0070 B700002D
	ds_load_b128 v[179:182], v45 offset:96                     // 0000000477A4: DBFC0060 B300002D
	v_or_b32_e32 v49, 6, v154                                  // 0000000477AC: 38633486
	v_or_b32_e32 v48, 8, v154                                  // 0000000477B0: 38613488
	v_or_b32_e32 v47, 10, v154                                 // 0000000477B4: 385F348A
	s_waitcnt lgkmcnt(12)                                      // 0000000477B8: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 0000000477BC: CC414002 1C0A1512
	ds_load_b128 v[14:17], v57 offset:6288                     // 0000000477C4: DBFC1890 0E000039
	ds_load_b128 v[10:13], v57 offset:6272                     // 0000000477CC: DBFC1880 0A000039
	ds_load_b128 v[22:25], v45 offset:144                      // 0000000477D4: DBFC0090 1600002D
	ds_load_b128 v[18:21], v45 offset:128                      // 0000000477DC: DBFC0080 1200002D
	s_and_not1_b32 vcc_lo, exec_lo, s41                        // 0000000477E4: 916A297E
	s_mov_b32 s3, -1                                           // 0000000477E8: BE8300C1
	s_waitcnt lgkmcnt(12)                                      // 0000000477EC: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[59:66], v[26:33], v[2:9]// 0000000477F0: CC414002 1C0A353B
	ds_load_b128 v[30:33], v57 offset:6320                     // 0000000477F8: DBFC18B0 1E000039
	ds_load_b128 v[26:29], v57 offset:6304                     // 000000047800: DBFC18A0 1A000039
	ds_load_b128 v[65:68], v45 offset:176                      // 000000047808: DBFC00B0 4100002D
	ds_load_b128 v[61:64], v45 offset:160                      // 000000047810: DBFC00A0 3D00002D
	v_lshlrev_b32_e32 v60, 2, v55                              // 000000047818: 30786E82
	v_or_b32_e32 v59, 4, v154                                  // 00000004781C: 38773484
	s_waitcnt lgkmcnt(12)                                      // 000000047820: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[155:162], v[163:170], v[2:9]// 000000047824: CC414002 1C0B479B
	ds_load_b128 v[159:162], v57 offset:6352                   // 00000004782C: DBFC18D0 9F000039
	ds_load_b128 v[155:158], v57 offset:6336                   // 000000047834: DBFC18C0 9B000039
	v_add_nc_u32_e32 v46, 64, v60                              // 00000004783C: 4A5C78C0
	ds_load_b128 v[167:170], v57 offset:6384                   // 000000047840: DBFC18F0 A7000039
	ds_load_b128 v[163:166], v57 offset:6368                   // 000000047848: DBFC18E0 A3000039
	s_waitcnt lgkmcnt(12)                                      // 000000047850: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[179:186], v[171:178], v[2:9]// 000000047854: CC414002 1C0B57B3
	ds_load_b128 v[175:178], v45 offset:208                    // 00000004785C: DBFC00D0 AF00002D
	ds_load_b128 v[171:174], v45 offset:192                    // 000000047864: DBFC00C0 AB00002D
	s_waitcnt lgkmcnt(10)                                      // 00000004786C: BF89FCA7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 000000047870: CC414002 1C0A1512
	v_add_nc_u32_e32 v10, 0x5c00, v56                          // 000000047878: 4A1470FF 00005C00
	v_add_nc_u32_e32 v11, s43, v56                             // 000000047880: 4A16702B
	ds_load_b128 v[183:186], v45 offset:240                    // 000000047884: DBFC00F0 B700002D
	ds_load_b128 v[179:182], v45 offset:224                    // 00000004788C: DBFC00E0 B300002D
	ds_load_2addr_stride64_b32 v[12:13], v46 offset0:94 offset1:95// 000000047894: D8E05F5E 0C00002E
	v_or_b32_e32 v46, 12, v154                                 // 00000004789C: 385D348C
	s_waitcnt lgkmcnt(9)                                       // 0000000478A0: BF89FC97
	v_wmma_f32_16x16x16_bf16 v[2:9], v[61:68], v[26:33], v[2:9]// 0000000478A4: CC414002 1C0A353D
	ds_load_2addr_b32 v[28:29], v10 offset0:144 offset1:146    // 0000000478AC: D8DC9290 1C00000A
	ds_load_2addr_b32 v[24:25], v10 offset0:148 offset1:150    // 0000000478B4: D8DC9694 1800000A
	ds_load_2addr_b32 v[20:21], v10 offset0:152 offset1:154    // 0000000478BC: D8DC9A98 1400000A
	ds_load_2addr_b32 v[16:17], v10 offset0:156 offset1:158    // 0000000478C4: D8DC9E9C 1000000A
	ds_load_2addr_b32 v[26:27], v11 offset1:2                  // 0000000478CC: D8DC0200 1A00000B
	ds_load_2addr_b32 v[22:23], v11 offset0:4 offset1:6        // 0000000478D4: D8DC0604 1600000B
	ds_load_2addr_b32 v[18:19], v11 offset0:8 offset1:10       // 0000000478DC: D8DC0A08 1200000B
	ds_load_2addr_b32 v[14:15], v11 offset0:12 offset1:14      // 0000000478E4: D8DC0E0C 0E00000B
	v_or_b32_e32 v61, 2, v154                                  // 0000000478EC: 387B3482
	v_or_b32_e32 v45, 14, v154                                 // 0000000478F0: 385B348E
	s_waitcnt lgkmcnt(11)                                      // 0000000478F4: BF89FCB7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[171:178], v[155:162], v[2:9]// 0000000478F8: CC414002 1C0B37AB
	s_waitcnt lgkmcnt(9)                                       // 000000047900: BF89FC97
	s_delay_alu instid0(VALU_DEP_1)                            // 000000047904: BF870001
	v_wmma_f32_16x16x16_bf16 v[2:9], v[179:186], v[163:170], v[2:9]// 000000047908: CC414002 1C0B47B3
	s_cbranch_vccnz 353                                        // 000000047910: BFA40161 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b98>
	.long 0x7e143880                                           // 000000047914: 7E143880
	s_mov_b32 s3, exec_lo                                      // 000000047918: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004791C: BF870001
	.long 0x7f14390a                                           // 000000047920: 7F14390A
	.long 0xd4cb007e                                           // 000000047924: D4CB007E
	v_cndmask_b32_e32 v1, v55, v154, vcc_lo                    // 000000047928: 02033537
	s_cbranch_execz 34                                         // 00000004792C: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x16b8>
	s_waitcnt lgkmcnt(7)                                       // 000000047930: BF89FC77
	v_sub_f32_e32 v11, v28, v12                                // 000000047934: 0816191C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047938: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v11                         // 00000004793C: 103C16FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v11, -v30                       // 000000047944: D613001F 847A16FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 000000047950: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047954: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v11 :: v_dual_sub_f32 v30, v30, v32// 000000047958: C80A16FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 000000047964: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 000000047968: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000004796C: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000047974: BF870293
	v_exp_f32_e32 v30, v30                                     // 000000047978: 7E3C4B1E
	.long 0xd71c001e                                           // 00000004797C: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 000000047980: 02023F1E
	s_waitcnt lgkmcnt(3)                                       // 000000047984: BF89FC37
	v_mul_f32_e32 v31, v2, v26                                 // 000000047988: 103E3502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004798C: BF870122
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 000000047990: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000047994: 7C3C16FF 42B17218
	v_dual_cndmask_b32 v11, 0x7f800000, v30 :: v_dual_mul_f32 v30, v13, v31// 00000004799C: CA463CFF 0B1E3F0D 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000479A8: BF870091
	v_mul_f32_e32 v11, v11, v30                                // 0000000479AC: 10163D0B
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 0000000479B0: CC22000A 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000479B8: 8C7E037E
	v_mul_u32_u24_e32 v11, 48, v154                            // 0000000479BC: 161734B0
	s_mov_b32 s3, exec_lo                                      // 0000000479C0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000479C4: BF870001
	v_lshl_add_u32 v11, v55, 1, v11                            // 0000000479C8: D646000B 042D0337
	ds_store_b16_d16_hi v11, v10 offset:23296                  // 0000000479D0: DA845B00 00000A0B
	.long 0xd4cb007e                                           // 0000000479D8: D4CB007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 0000000479DC: 02027B37
	s_cbranch_execz 34                                         // 0000000479E0: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x176c>
	s_waitcnt lgkmcnt(8)                                       // 0000000479E4: BF89FC87
	v_sub_f32_e32 v10, v29, v12                                // 0000000479E8: 0814191D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000479EC: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v10                         // 0000000479F0: 103C14FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v30                       // 0000000479F8: D613001F 847A14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 000000047A04: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047A08: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v10 :: v_dual_sub_f32 v30, v30, v32// 000000047A0C: C80A14FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 000000047A18: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 000000047A1C: 7E3E1120
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000047A20: BF870292
	v_exp_f32_e32 v30, v30                                     // 000000047A24: 7E3C4B1E
	.long 0xd71c001e                                           // 000000047A28: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 000000047A2C: 02023F1E
	s_waitcnt lgkmcnt(4)                                       // 000000047A30: BF89FC47
	v_mul_f32_e32 v31, v3, v27                                 // 000000047A34: 103E3703
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000047A38: 7C3614FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047A40: BF870123
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 000000047A44: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000047A48: 7C3C14FF 42B17218
	v_cndmask_b32_e32 v10, 0x7f800000, v30, vcc_lo             // 000000047A50: 02143CFF 7F800000
	v_mul_f32_e32 v30, v13, v31                                // 000000047A58: 103C3F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047A5C: BF870091
	v_mul_f32_e32 v10, v10, v30                                // 000000047A60: 10143D0A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 000000047A64: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000047A6C: 8C7E037E
	.long 0x7f143880                                           // 000000047A70: 7F143880
	v_or_b32_e32 v30, 0x5b00, v11                              // 000000047A74: 383C16FF 00005B00
	s_mov_b32 s3, exec_lo                                      // 000000047A7C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000047A80: BF870002
	.long 0x7e16398a                                           // 000000047A84: 7E16398A
	ds_store_b16 v30, v10 offset:96                            // 000000047A88: D87C0060 00000A1E
	.long 0xd4cb007e                                           // 000000047A90: D4CB007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 000000047A94: 02027737
	s_cbranch_execz 35                                         // 000000047A98: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1828>
	s_waitcnt lgkmcnt(8)                                       // 000000047A9C: BF89FC87
	v_sub_f32_e32 v11, v24, v12                                // 000000047AA0: 08161918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047AA4: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000047AA8: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000047AB0: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000047AB8: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 000000047AC4: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047AC8: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000047ACC: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000047AD8: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000047ADC: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000047AE0: BF870292
	v_exp_f32_e32 v31, v31                                     // 000000047AE4: 7E3E4B1F
	.long 0xd71c001f                                           // 000000047AE8: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000047AEC: 0202411F
	s_waitcnt lgkmcnt(4)                                       // 000000047AF0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047AF4: BF870121
	v_dual_mul_f32 v32, v4, v22 :: v_dual_cndmask_b32 v31, 0, v31// 000000047AF8: C8D22D04 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000047B00: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000047B08: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047B10: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 000000047B14: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 000000047B18: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000047B1C: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 000000047B20: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000047B28: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000047B2C: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000047B30: BE83007E
	ds_store_b16 v30, v11 offset:192                           // 000000047B34: D87C00C0 00000B1E
	.long 0xd4cb007e                                           // 000000047B3C: D4CB007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 000000047B40: 02026337
	s_cbranch_execz 35                                         // 000000047B44: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x18d4>
	s_waitcnt lgkmcnt(9)                                       // 000000047B48: BF89FC97
	v_sub_f32_e32 v10, v25, v12                                // 000000047B4C: 08141919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047B50: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000047B54: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000047B5C: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000047B68: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000047B6C: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000047B70: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000047B78: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000047B7C: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000047B80: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 000000047B84: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000047B88: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000047B90: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000047B94: BF870135
	.long 0xd71c000b                                           // 000000047B98: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000047B9C: 02023F0B
	s_waitcnt lgkmcnt(5)                                       // 000000047BA0: BF89FC57
	v_mul_f32_e32 v31, v5, v23                                 // 000000047BA4: 103E2F05
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000047BA8: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000047BAC: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000047BB4: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000047BB8: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000047BC0: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047BC4: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000047BC8: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 000000047BCC: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000047BD4: 8C7E037E
	.long 0x7e143880                                           // 000000047BD8: 7E143880
	s_mov_b32 s3, exec_lo                                      // 000000047BDC: BE83007E
	ds_store_b16_d16_hi v30, v10 offset:288                    // 000000047BE0: DA840120 00000A1E
	.long 0x7e16390a                                           // 000000047BE8: 7E16390A
	.long 0xd4cb007e                                           // 000000047BEC: D4CB007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 000000047BF0: 02026137
	s_cbranch_execz 34                                         // 000000047BF4: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1980>
	s_waitcnt lgkmcnt(9)                                       // 000000047BF8: BF89FC97
	v_sub_f32_e32 v11, v20, v12                                // 000000047BFC: 08161914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047C00: BF870091
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000047C04: 103E16FF 3FB8AA3B
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000047C0C: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 000000047C18: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047C1C: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000047C20: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000047C2C: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000047C30: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000047C34: BF870292
	v_exp_f32_e32 v31, v31                                     // 000000047C38: 7E3E4B1F
	.long 0xd71c001f                                           // 000000047C3C: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000047C40: 0202411F
	s_waitcnt lgkmcnt(5)                                       // 000000047C44: BF89FC57
	v_mul_f32_e32 v32, v6, v18                                 // 000000047C48: 10402506
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000047C4C: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047C54: BF870123
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 000000047C58: 023E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000047C5C: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000047C64: 02163EFF 7F800000
	v_mul_f32_e32 v31, v13, v32                                // 000000047C6C: 103E410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047C70: BF870091
	v_mul_f32_e32 v11, v11, v31                                // 000000047C74: 10163F0B
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 000000047C78: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000047C80: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000047C84: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000047C88: BE83007E
	ds_store_b16 v30, v11 offset:384                           // 000000047C8C: D87C0180 00000B1E
	.long 0xd4cb007e                                           // 000000047C94: D4CB007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 000000047C98: 02025F37
	s_cbranch_execz 35                                         // 000000047C9C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1a2c>
	s_waitcnt lgkmcnt(10)                                      // 000000047CA0: BF89FCA7
	v_sub_f32_e32 v10, v21, v12                                // 000000047CA4: 08141915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047CA8: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000047CAC: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000047CB4: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000047CC0: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000047CC4: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000047CC8: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000047CD0: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000047CD4: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000047CD8: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 000000047CDC: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000047CE0: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000047CE8: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000047CEC: BF870135
	.long 0xd71c000b                                           // 000000047CF0: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000047CF4: 02023F0B
	s_waitcnt lgkmcnt(6)                                       // 000000047CF8: BF89FC67
	v_mul_f32_e32 v31, v7, v19                                 // 000000047CFC: 103E2707
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000047D00: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000047D04: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000047D0C: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000047D10: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000047D18: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047D1C: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000047D20: 1014170A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 000000047D24: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000047D2C: 8C7E037E
	.long 0x7f143880                                           // 000000047D30: 7F143880
	s_mov_b32 s3, exec_lo                                      // 000000047D34: BE83007E
	ds_store_b16 v30, v10 offset:480                           // 000000047D38: D87C01E0 00000A1E
	.long 0x7e16398a                                           // 000000047D40: 7E16398A
	.long 0xd4cb007e                                           // 000000047D44: D4CB007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 000000047D48: 02025D37
	s_cbranch_execz 35                                         // 000000047D4C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1adc>
	s_waitcnt lgkmcnt(10)                                      // 000000047D50: BF89FCA7
	v_sub_f32_e32 v11, v16, v12                                // 000000047D54: 08161910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047D58: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000047D5C: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000047D64: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000047D6C: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 000000047D78: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047D7C: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000047D80: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000047D8C: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000047D90: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000047D94: BF870292
	v_exp_f32_e32 v31, v31                                     // 000000047D98: 7E3E4B1F
	.long 0xd71c001f                                           // 000000047D9C: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000047DA0: 0202411F
	s_waitcnt lgkmcnt(6)                                       // 000000047DA4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047DA8: BF870121
	v_dual_mul_f32 v32, v8, v14 :: v_dual_cndmask_b32 v31, 0, v31// 000000047DAC: C8D21D08 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000047DB4: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000047DBC: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047DC4: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 000000047DC8: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 000000047DCC: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000047DD0: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 000000047DD4: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000047DDC: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000047DE0: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000047DE4: BE83007E
	ds_store_b16 v30, v11 offset:576                           // 000000047DE8: D87C0240 00000B1E
	.long 0xd4cb007e                                           // 000000047DF0: D4CB007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 000000047DF4: 02025B37
	s_cbranch_execz 35                                         // 000000047DF8: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b88>
	s_waitcnt lgkmcnt(11)                                      // 000000047DFC: BF89FCB7
	v_sub_f32_e32 v10, v17, v12                                // 000000047E00: 08141911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047E04: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000047E08: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000047E10: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000047E1C: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000047E20: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000047E24: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000047E2C: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000047E30: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000047E34: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 000000047E38: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000047E3C: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000047E44: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000047E48: BF870135
	.long 0xd71c000b                                           // 000000047E4C: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000047E50: 02023F0B
	s_waitcnt lgkmcnt(7)                                       // 000000047E54: BF89FC77
	v_mul_f32_e32 v31, v9, v15                                 // 000000047E58: 103E1F09
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000047E5C: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000047E60: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000047E68: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000047E6C: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000047E74: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047E78: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000047E7C: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 000000047E80: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000047E88: 8C7E037E
	s_mov_b32 s3, 0                                            // 000000047E8C: BE830080
	ds_store_b16_d16_hi v30, v10 offset:672                    // 000000047E90: DA8402A0 00000A1E
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000047E98: 8B6A037E
	s_cbranch_vccz 365                                         // 000000047E9C: BFA3016D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2154>
	v_or_b32_e32 v10, 0x5e40, v56                              // 000000047EA0: 381470FF 00005E40
	v_mov_b32_e32 v63, 0                                       // 000000047EA8: 7E7E0280
	v_mov_b32_e32 v65, 0                                       // 000000047EAC: 7E820280
	s_mov_b32 s3, exec_lo                                      // 000000047EB0: BE83007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000047EB4: BF870003
	v_subrev_nc_u32_e32 v64, 64, v10                           // 000000047EB8: 4E8014C0
	ds_load_2addr_b32 v[32:33], v64 offset0:2 offset1:4        // 000000047EBC: D8DC0402 20000040
	ds_load_2addr_b32 v[30:31], v64 offset0:6 offset1:8        // 000000047EC4: D8DC0806 1E000040
	ds_load_2addr_b32 v[10:11], v64 offset0:10 offset1:12      // 000000047ECC: D8DC0C0A 0A000040
	ds_load_b32 v62, v64 offset:56                             // 000000047ED4: D8D80038 3E000040
	.long 0xd4c9007e                                           // 000000047EDC: D4C9007E
	v_cndmask_b32_e32 v1, v55, v154, vcc_lo                    // 000000047EE0: 02033537
	s_cbranch_execz 37                                         // 000000047EE4: BFA50025 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1c7c>
	s_waitcnt lgkmcnt(11)                                      // 000000047EE8: BF89FCB7
	v_sub_f32_e32 v28, v28, v12                                // 000000047EEC: 0838191C
	ds_load_b32 v64, v64                                       // 000000047EF0: D8D80000 40000040
	s_waitcnt lgkmcnt(8)                                       // 000000047EF8: BF89FC87
	v_dual_mul_f32 v2, v2, v26 :: v_dual_mul_f32 v65, 0x3fb8aa3b, v28// 000000047EFC: C8C63502 024038FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000047F08: BF870111
	v_mul_f32_e32 v2, v13, v2                                  // 000000047F0C: 1004050D
	v_fma_f32 v66, 0x3fb8aa3b, v28, -v65                       // 000000047F10: D6130042 850638FF 3FB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 000000047F1C: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000047F20: BF8701C1
	v_dual_sub_f32 v65, v65, v67 :: v_dual_fmac_f32 v66, 0x32a5705f, v28// 000000047F24: C9408741 414238FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v28                  // 000000047F30: 7C3638FF C2CE8ED0
	s_waitcnt lgkmcnt(0)                                       // 000000047F38: BF89FC07
	v_mul_f32_e32 v2, v64, v2                                  // 000000047F3C: 10040540
	v_add_f32_e32 v65, v65, v66                                // 000000047F40: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000047F44: 7E841143
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000047F48: BF870292
	v_exp_f32_e32 v65, v65                                     // 000000047F4C: 7E824B41
	.long 0xd71c0041                                           // 000000047F50: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000047F54: 02028541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047F58: BF870121
	v_cndmask_b32_e32 v26, 0, v65, vcc_lo                      // 000000047F5C: 02348280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v28                  // 000000047F60: 7C3C38FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 000000047F68: 023434FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000047F70: BF870001
	.long 0xd5080041                                           // 000000047F74: D5080041
	v_sub_co_ci_u32_e32 v1, vcc_lo, v2, v26, vcc_lo            // 000000047F78: 42023502
	s_or_b32 exec_lo, exec_lo, s3                              // 000000047F7C: 8C7E037E
	v_or_b32_e32 v2, 0x5e40, v60                               // 000000047F80: 380478FF 00005E40
	s_waitcnt lgkmcnt(7)                                       // 000000047F88: BF89FC77
	v_lshlrev_b32_e32 v26, 6, v154                             // 000000047F8C: 30353486
	s_mov_b32 s3, exec_lo                                      // 000000047F90: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000047F94: BF870001
	v_add3_u32 v2, v2, v26, 0xfffff8c0                         // 000000047F98: D6550002 03FE3502 FFFFF8C0
	ds_store_b32 v2, v65                                       // 000000047FA4: D8340000 00004102
	.long 0xd4c9007e                                           // 000000047FAC: D4C9007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 000000047FB0: 02027B37
	s_cbranch_execz 33                                         // 000000047FB4: BFA50021 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1d3c>
	v_dual_sub_f32 v26, v29, v12 :: v_dual_mul_f32 v3, v3, v27 // 000000047FB8: C946191D 1A023703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047FC0: BF870121
	v_dual_mul_f32 v28, 0x3fb8aa3b, v26 :: v_dual_mul_f32 v3, v13, v3// 000000047FC4: C8C634FF 1C02070D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v26                  // 000000047FD0: 7C3634FF C2CE8ED0
	v_fma_f32 v29, 0x3fb8aa3b, v26, -v28                       // 000000047FD8: D613001D 847234FF 3FB8AA3B
	v_rndne_f32_e32 v60, v28                                   // 000000047FE4: 7E78471C
	s_waitcnt lgkmcnt(4)                                       // 000000047FE8: BF89FC47
	v_mul_f32_e32 v3, v32, v3                                  // 000000047FEC: 10060720
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047FF0: BF870092
	v_dual_fmac_f32 v29, 0x32a5705f, v26 :: v_dual_sub_f32 v28, v28, v60// 000000047FF4: C80A34FF 1D1C791C 32A5705F
	v_add_f32_e32 v28, v28, v29                                // 000000048000: 06383B1C
	v_cvt_i32_f32_e32 v29, v60                                 // 000000048004: 7E3A113C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000048008: BF870292
	v_exp_f32_e32 v28, v28                                     // 00000004800C: 7E384B1C
	.long 0xd71c001c                                           // 000000048010: D71C001C
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                     // 000000048014: 02023B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000048018: BF870121
	v_cndmask_b32_e32 v27, 0, v28, vcc_lo                      // 00000004801C: 02363880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v26                  // 000000048020: 7C3C34FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v27, vcc_lo             // 000000048028: 023436FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000048030: BF870001
	.long 0xd508003f                                           // 000000048034: D508003F
	v_sub_co_ci_u32_e32 v1, vcc_lo, v3, v26, vcc_lo            // 000000048038: 42023503
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004803C: 8C7E037E
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v26, 0              // 000000048040: CA100080 031A0080
	s_mov_b32 s3, exec_lo                                      // 000000048048: BE83007E
	ds_store_b32 v2, v63 offset:128                            // 00000004804C: D8340080 00003F02
	.long 0xd4c9007e                                           // 000000048054: D4C9007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 000000048058: 02027737
	s_cbranch_execz 35                                         // 00000004805C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1dec>
	v_sub_f32_e32 v24, v24, v12                                // 000000048060: 08301918
	s_waitcnt lgkmcnt(8)                                       // 000000048064: BF89FC87
	v_mul_f32_e32 v4, v4, v22                                  // 000000048068: 10082D04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000004806C: BF8701A2
	v_mul_f32_e32 v26, 0x3fb8aa3b, v24                         // 000000048070: 103430FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v24                  // 000000048078: 7C3630FF C2CE8ED0
	v_mul_f32_e32 v4, v13, v4                                  // 000000048080: 1008090D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000048084: BF8701B3
	v_fma_f32 v27, 0x3fb8aa3b, v24, -v26                       // 000000048088: D613001B 846A30FF 3FB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000048094: 7E38471A
	s_waitcnt lgkmcnt(5)                                       // 000000048098: BF89FC57
	v_mul_f32_e32 v4, v33, v4                                  // 00000004809C: 10080921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000480A0: BF870193
	v_fmac_f32_e32 v27, 0x32a5705f, v24                        // 0000000480A4: 563630FF 32A5705F
	v_sub_f32_e32 v26, v26, v28                                // 0000000480AC: 0834391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000480B0: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000480B4: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000480B8: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000480BC: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000480C0: BF870095
	.long 0xd71c001a                                           // 0000000480C4: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000480C8: 0202371A
	v_cndmask_b32_e32 v22, 0, v26, vcc_lo                      // 0000000480CC: 022C3480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v24                  // 0000000480D0: 7C3C30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000480D8: BF870092
	v_cndmask_b32_e32 v22, 0x7f800000, v22, vcc_lo             // 0000000480DC: 022C2CFF 7F800000
	.long 0xd508001a                                           // 0000000480E4: D508001A
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v22, vcc_lo            // 0000000480E8: 42022D04
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000480EC: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000480F0: BF870009
	s_mov_b32 s3, exec_lo                                      // 0000000480F4: BE83007E
	ds_store_b32 v2, v26 offset:256                            // 0000000480F8: D8340100 00001A02
	.long 0xd4c9007e                                           // 000000048100: D4C9007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 000000048104: 02026337
	s_cbranch_execz 34                                         // 000000048108: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1e94>
	v_sub_f32_e32 v3, v25, v12                                 // 00000004810C: 08061919
	s_waitcnt lgkmcnt(9)                                       // 000000048110: BF89FC97
	v_mul_f32_e32 v5, v5, v23                                  // 000000048114: 100A2F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048118: BF870091
	v_dual_mul_f32 v4, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, v13, v5// 00000004811C: C8C606FF 04040B0D 3FB8AA3B
	v_fma_f32 v22, 0x3fb8aa3b, v3, -v4                         // 000000048128: D6130016 841206FF 3FB8AA3B
	v_rndne_f32_e32 v24, v4                                    // 000000048134: 7E304704
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000048138: BF870112
	v_fmac_f32_e32 v22, 0x32a5705f, v3                         // 00000004813C: 562C06FF 32A5705F
	v_sub_f32_e32 v4, v4, v24                                  // 000000048144: 08083104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000048148: BF8701B1
	v_add_f32_e32 v4, v4, v22                                  // 00000004814C: 06082D04
	v_cvt_i32_f32_e32 v22, v24                                 // 000000048150: 7E2C1118
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000048154: 7C3606FF C2CE8ED0
	v_exp_f32_e32 v4, v4                                       // 00000004815C: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048160: BF870095
	.long 0xd71c0004                                           // 000000048164: D71C0004
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 000000048168: 02022D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 00000004816C: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000048170: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(5)                                       // 000000048178: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004817C: BF870092
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v30, v5// 000000048180: CA4608FF 03040B1E 7F800000
	.long 0xd5080003                                           // 00000004818C: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 000000048190: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 000000048194: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 000000048198: CA100080 04040080
	s_mov_b32 s3, exec_lo                                      // 0000000481A0: BE83007E
	ds_store_b32 v2, v3 offset:384                             // 0000000481A4: D8340180 00000302
	.long 0xd4c9007e                                           // 0000000481AC: D4C9007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 0000000481B0: 02026137
	s_cbranch_execz 34                                         // 0000000481B4: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1f40>
	s_waitcnt lgkmcnt(9)                                       // 0000000481B8: BF89FC97
	v_dual_sub_f32 v3, v20, v12 :: v_dual_mul_f32 v6, v6, v18  // 0000000481BC: C9461914 03062506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000481C4: BF870121
	v_dual_mul_f32 v5, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v6, v13, v6// 0000000481C8: C8C606FF 05060D0D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 0000000481D4: 7C3606FF C2CE8ED0
	v_fma_f32 v20, 0x3fb8aa3b, v3, -v5                         // 0000000481DC: D6130014 841606FF 3FB8AA3B
	v_rndne_f32_e32 v22, v5                                    // 0000000481E8: 7E2C4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000481EC: BF870091
	v_dual_fmac_f32 v20, 0x32a5705f, v3 :: v_dual_sub_f32 v5, v5, v22// 0000000481F0: C80A06FF 14042D05 32A5705F
	v_add_f32_e32 v5, v5, v20                                  // 0000000481FC: 060A2905
	v_cvt_i32_f32_e32 v20, v22                                 // 000000048200: 7E281116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000048204: BF870292
	v_exp_f32_e32 v5, v5                                       // 000000048208: 7E0A4B05
	.long 0xd71c0005                                           // 00000004820C: D71C0005
	v_cndmask_b32_e32 v1, v5, v20, vcc_lo                      // 000000048210: 02022905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000048214: BF870121
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 000000048218: 020A0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000004821C: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v3, 0x7f800000, v5, vcc_lo               // 000000048224: 02060AFF 7F800000
	s_waitcnt lgkmcnt(6)                                       // 00000004822C: BF89FC67
	v_mul_f32_e32 v5, v31, v6                                  // 000000048230: 100A0D1F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000048234: BF870001
	.long 0xd5080005                                           // 000000048238: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v3, vcc_lo             // 00000004823C: 42020705
	s_or_b32 exec_lo, exec_lo, s3                              // 000000048240: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000048244: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000048248: BE83007E
	ds_store_b32 v2, v5 offset:512                             // 00000004824C: D8340200 00000502
	.long 0xd4c9007e                                           // 000000048254: D4C9007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 000000048258: 02025F37
	s_cbranch_execz 35                                         // 00000004825C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1fec>
	v_sub_f32_e32 v3, v21, v12                                 // 000000048260: 08061915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048264: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 000000048268: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 000000048270: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 00000004827C: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000048280: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 000000048284: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000048288: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 000000048290: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000048298: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 00000004829C: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 0000000482A0: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 0000000482A4: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000482A8: BF8700A5
	.long 0xd71c0004                                           // 0000000482AC: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 0000000482B0: 02020B04
	s_waitcnt lgkmcnt(10)                                      // 0000000482B4: BF89FCA7
	v_dual_mul_f32 v5, v7, v19 :: v_dual_cndmask_b32 v4, 0, v4 // 0000000482B8: C8D22707 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000482C0: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 0000000482C4: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 0000000482C8: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(6)                                       // 0000000482D0: BF89FC67
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v10, v5// 0000000482D4: CA4608FF 03040B0A 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000482E0: BF870001
	.long 0xd5080004                                           // 0000000482E4: D5080004
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 0000000482E8: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000482EC: 8C7E037E
	v_mov_b32_e32 v3, 0                                        // 0000000482F0: 7E060280
	v_mov_b32_e32 v5, 0                                        // 0000000482F4: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 0000000482F8: BE83007E
	ds_store_b32 v2, v4 offset:640                             // 0000000482FC: D8340280 00000402
	.long 0xd4c9007e                                           // 000000048304: D4C9007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 000000048308: 02025D37
	s_cbranch_execz 35                                         // 00000004830C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x209c>
	v_sub_f32_e32 v4, v16, v12                                 // 000000048310: 08081910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048314: BF870091
	v_mul_f32_e32 v5, 0x3fb8aa3b, v4                           // 000000048318: 100A08FF 3FB8AA3B
	v_fma_f32 v6, 0x3fb8aa3b, v4, -v5                          // 000000048320: D6130006 841608FF 3FB8AA3B
	v_rndne_f32_e32 v7, v5                                     // 00000004832C: 7E0E4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000048330: BF870221
	v_sub_f32_e32 v5, v5, v7                                   // 000000048334: 080A0F05
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 000000048338: 7C3608FF C2CE8ED0
	v_fmac_f32_e32 v6, 0x32a5705f, v4                          // 000000048340: 560C08FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000048348: BF870121
	v_add_f32_e32 v5, v5, v6                                   // 00000004834C: 060A0D05
	v_cvt_i32_f32_e32 v6, v7                                   // 000000048350: 7E0C1107
	v_exp_f32_e32 v5, v5                                       // 000000048354: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000048358: BF8700A5
	.long 0xd71c0005                                           // 00000004835C: D71C0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 000000048360: 02020D05
	s_waitcnt lgkmcnt(10)                                      // 000000048364: BF89FCA7
	v_dual_mul_f32 v6, v8, v14 :: v_dual_cndmask_b32 v5, 0, v5 // 000000048368: C8D21D08 06040A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000048370: BF870131
	v_mul_f32_e32 v6, v13, v6                                  // 000000048374: 100C0D0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 000000048378: 7C3C08FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 000000048380: BF89FC77
	v_dual_cndmask_b32 v4, 0x7f800000, v5 :: v_dual_mul_f32 v5, v11, v6// 000000048384: CA460AFF 04040D0B 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000048390: BF870001
	.long 0xd5080005                                           // 000000048394: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v4, vcc_lo             // 000000048398: 42020905
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004839C: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000483A0: BF870009
	s_mov_b32 s3, exec_lo                                      // 0000000483A4: BE83007E
	ds_store_b32 v2, v5 offset:768                             // 0000000483A8: D8340300 00000502
	.long 0xd4c9007e                                           // 0000000483B0: D4C9007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 0000000483B4: 02025B37
	s_cbranch_execz 35                                         // 0000000483B8: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2148>
	v_sub_f32_e32 v3, v17, v12                                 // 0000000483BC: 08061911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000483C0: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 0000000483C4: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 0000000483CC: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 0000000483D8: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000483DC: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 0000000483E0: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 0000000483E4: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 0000000483EC: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000483F4: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 0000000483F8: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 0000000483FC: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 000000048400: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000048404: BF8700A5
	.long 0xd71c0004                                           // 000000048408: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000004840C: 02020B04
	s_waitcnt lgkmcnt(11)                                      // 000000048410: BF89FCB7
	v_dual_mul_f32 v5, v9, v15 :: v_dual_cndmask_b32 v4, 0, v4 // 000000048414: C8D21F09 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000004841C: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 000000048420: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000048424: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 00000004842C: BF89FC77
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v62, v5// 000000048430: CA4608FF 03040B3E 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004843C: BF870001
	.long 0xd5080003                                           // 000000048440: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 000000048444: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 000000048448: 8C7E037E
	ds_store_b32 v2, v3 offset:896                             // 00000004844C: D8340380 00000302
	s_waitcnt lgkmcnt(0)                                       // 000000048454: BF89FC07
	s_barrier                                                  // 000000048458: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s41                             // 00000004845C: 8B6A297E
	s_mov_b32 s3, -1                                           // 000000048460: BE8300C1
	s_cbranch_vccz 175                                         // 000000048464: BFA300AF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2424>
	s_mov_b32 s3, exec_lo                                      // 000000048468: BE83007E
	v_cmpx_gt_i32_e32 0x120, v44                               // 00000004846C: 7D8858FF 00000120
	s_cbranch_execz 169                                        // 000000048474: BFA500A9 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x241c>
	v_add_nc_u32_e32 v2, 0xffffff00, v44                       // 000000048478: 4A0458FF FFFFFF00
	s_mov_b32 s4, 0                                            // 000000048480: BE840080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000048484: BF870001
	v_mov_b32_e32 v3, v2                                       // 000000048488: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004848C: BF8700A1
	v_add_nc_u32_e32 v3, 0xe0, v3                              // 000000048490: 4A0606FF 000000E0
	s_waitcnt lgkmcnt(0)                                       // 000000048498: BF89FC07
	v_ashrrev_i32_e32 v16, 7, v3                               // 00000004849C: 34200687
	v_and_b32_e32 v12, 0x7f, v3                                // 0000000484A0: 361806FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000484A8: BF870092
	.long 0xd72c0004                                           // 0000000484AC: D72C0004
	v_cndmask_b32_e32 v1, 0x880, v16, vcc_lo                   // 0000000484B0: 020220FF 00000880
	v_lshl_add_u32 v4, v12, 1, v4                              // 0000000484B8: D6460004 0411030C
	ds_load_u16 v20, v4 offset:7776                            // 0000000484C0: D8F01E60 14000004
	ds_load_u16 v21, v4 offset:7232                            // 0000000484C8: D8F01C40 15000004
	ds_load_u16 v22, v4 offset:6688                            // 0000000484D0: D8F01A20 16000004
	ds_load_u16 v23, v4 offset:6144                            // 0000000484D8: D8F01800 17000004
	ds_load_u16 v24, v4 offset:6416                            // 0000000484E0: D8F01910 18000004
	s_waitcnt lgkmcnt(3)                                       // 0000000484E8: BF89FC37
	v_lshlrev_b32_e32 v21, 16, v21                             // 0000000484EC: 302A2A90
	s_waitcnt lgkmcnt(1)                                       // 0000000484F0: BF89FC17
	v_lshlrev_b32_e32 v23, 16, v23                             // 0000000484F4: 302E2E90
	v_lshlrev_b32_e32 v17, 5, v16                              // 0000000484F8: 30222085
	ds_load_u16 v25, v4 offset:6960                            // 0000000484FC: D8F01B30 19000004
	ds_load_u16 v26, v4 offset:7504                            // 000000048504: D8F01D50 1A000004
	ds_load_u16 v27, v4 offset:8048                            // 00000004850C: D8F01F70 1B000004
	ds_load_b128 v[4:7], v17 offset:24384                      // 000000048514: DBFC5F40 04000011
	ds_load_b128 v[8:11], v17 offset:24400                     // 00000004851C: DBFC5F50 08000011
	v_lshlrev_b32_e32 v20, 16, v20                             // 000000048524: 30282890
	s_waitcnt lgkmcnt(0)                                       // 000000048528: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004852C: BF870091
	v_dual_mul_f32 v10, v10, v20 :: v_dual_lshlrev_b32 v25, 16, v25// 000000048530: C8E2290A 0A183290
	v_dual_mul_f32 v7, v7, v25 :: v_dual_lshlrev_b32 v24, 16, v24// 000000048538: C8E23307 07183090
	v_mul_f32_e32 v8, v8, v21                                  // 000000048540: 10102B08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000048544: BF870002
	v_dual_mul_f32 v4, v4, v23 :: v_dual_mul_f32 v5, v5, v24   // 000000048548: C8C62F04 04043105
	v_mul_u32_u24_e32 v18, 48, v12                             // 000000048550: 162418B0
	ds_load_b128 v[12:15], v17 offset:24192                    // 000000048554: DBFC5E80 0C000011
	v_lshlrev_b32_e32 v26, 16, v26                             // 00000004855C: 30343490
	v_lshlrev_b32_e32 v27, 16, v27                             // 000000048560: 30363690
	v_lshl_add_u32 v28, v16, 4, v18                            // 000000048564: D646001C 04490910
	ds_load_b128 v[16:19], v17 offset:24208                    // 00000004856C: DBFC5E90 10000011
	s_waitcnt lgkmcnt(1)                                       // 000000048574: BF89FC17
	v_mul_f32_e32 v12, v12, v4                                 // 000000048578: 1018090C
	v_mul_f32_e32 v4, v13, v5                                  // 00000004857C: 10080B0D
	v_dual_mul_f32 v11, v11, v27 :: v_dual_lshlrev_b32 v22, 16, v22// 000000048580: C8E2370B 0B162C90
	v_mul_f32_e32 v5, v15, v7                                  // 000000048588: 100A0F0F
	v_mul_f32_e32 v9, v9, v26                                  // 00000004858C: 10123509
	s_waitcnt lgkmcnt(0)                                       // 000000048590: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000048594: BF870243
	v_dual_mul_f32 v7, v16, v8 :: v_dual_mul_f32 v6, v6, v22   // 000000048598: C8C61110 07062D06
	v_cmp_lt_i32_e32 vcc_lo, 31, v3                            // 0000000485A0: 7C82069F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 0000000485A4: CC220004 02006104
	v_dual_mul_f32 v8, v17, v9 :: v_dual_mul_f32 v9, v18, v10  // 0000000485AC: C8C61311 08081512
	v_mul_f32_e32 v6, v14, v6                                  // 0000000485B4: 100C0D0E
	v_mul_f32_e32 v10, v19, v11                                // 0000000485B8: 10141713
	v_fma_mixlo_f16 v4, v12, s48, 0                            // 0000000485BC: CC210004 0200610C
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 0000000485C4: CC220005 02006105
	s_or_b32 s4, vcc_lo, s4                                    // 0000000485CC: 8C04046A
	v_fma_mixlo_f16 v5, v6, s48, 0                             // 0000000485D0: CC210005 02006106
	v_fma_mixhi_f16 v6, v8, s48, 0                             // 0000000485D8: CC220006 02006108
	v_fma_mixlo_f16 v6, v7, s48, 0                             // 0000000485E0: CC210006 02006107
	v_fma_mixhi_f16 v7, v10, s48, 0                            // 0000000485E8: CC220007 0200610A
	v_fma_mixlo_f16 v7, v9, s48, 0                             // 0000000485F0: CC210007 02006109
	ds_store_b128 v28, v[4:7]                                  // 0000000485F8: DB7C0000 0000041C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000048600: 917E047E
	s_cbranch_execnz 65441                                     // 000000048604: BFA6FFA1 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x218c>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000048608: 8C7E047E
	v_lshl_add_u32 v3, v44, 3, 0xffffff00                      // 00000004860C: D6460003 03FD072C FFFFFF00
	s_mov_b32 s4, 0                                            // 000000048618: BE840080
	v_add_nc_u32_e32 v2, 0xe0, v2                              // 00000004861C: 4A0404FF 000000E0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000048624: BF8701A2
	v_and_b32_e32 v4, 0x78, v3                                 // 000000048628: 360806FF 00000078
	v_add_nc_u32_e32 v3, 0x700, v3                             // 000000048630: 4A0606FF 00000700
	v_ashrrev_i32_e32 v5, 4, v2                                // 000000048638: 340A0484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004863C: BF870121
	.long 0xd72c0006                                           // 000000048640: D72C0006
	v_cndmask_b32_e32 v1, 0x110, v5, vcc_lo                    // 000000048644: 02020AFF 00000110
	v_lshlrev_b32_e32 v8, 2, v5                                // 00000004864C: 30100A82
	v_lshl_add_u32 v9, v4, 1, v6                               // 000000048650: D6460009 04190304
	ds_load_b128 v[4:7], v9 offset:10496                       // 000000048658: DBFC2900 04000009
	ds_load_b32 v8, v8 offset:24448                            // 000000048660: D8D85F80 08000008
	s_waitcnt lgkmcnt(1)                                       // 000000048668: BF89FC17
	v_and_b32_e32 v12, 0xffff0000, v6                          // 00000004866C: 36180CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000048674: 300C0C90
	v_and_b32_e32 v13, 0xffff0000, v7                          // 000000048678: 361A0EFF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v4                          // 000000048680: 361408FF FFFF0000
	v_lshlrev_b32_e32 v4, 16, v4                               // 000000048688: 30080890
	v_and_b32_e32 v11, 0xffff0000, v5                          // 00000004868C: 36160AFF FFFF0000
	v_lshlrev_b32_e32 v5, 16, v5                               // 000000048694: 300A0A90
	s_waitcnt lgkmcnt(0)                                       // 000000048698: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000004869C: BF8701A3
	v_dual_mul_f32 v14, v8, v4 :: v_dual_lshlrev_b32 v7, 16, v7// 0000000486A0: C8E20908 0E060E90
	v_mul_f32_e32 v4, v8, v10                                  // 0000000486A8: 10081508
	v_mul_f32_e32 v10, v8, v5                                  // 0000000486AC: 10140B08
	v_mul_f32_e32 v5, v8, v11                                  // 0000000486B0: 100A1708
	v_mul_f32_e32 v11, v8, v6                                  // 0000000486B4: 10160D08
	v_mul_f32_e32 v6, v8, v12                                  // 0000000486B8: 100C1908
	v_mul_f32_e32 v12, v8, v7                                  // 0000000486BC: 10180F08
	v_mul_f32_e32 v7, v8, v13                                  // 0000000486C0: 100E1B08
	v_cmp_lt_i32_e32 vcc_lo, 31, v2                            // 0000000486C4: 7C82049F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 0000000486C8: CC220004 02006104
	v_fma_mixlo_f16 v4, v14, s48, 0                            // 0000000486D0: CC210004 0200610E
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 0000000486D8: CC220005 02006105
	v_fma_mixlo_f16 v5, v10, s48, 0                            // 0000000486E0: CC210005 0200610A
	v_fma_mixhi_f16 v6, v6, s48, 0                             // 0000000486E8: CC220006 02006106
	v_fma_mixlo_f16 v6, v11, s48, 0                            // 0000000486F0: CC210006 0200610B
	v_fma_mixhi_f16 v7, v7, s48, 0                             // 0000000486F8: CC220007 02006107
	v_fma_mixlo_f16 v7, v12, s48, 0                            // 000000048700: CC210007 0200610C
	s_or_b32 s4, vcc_lo, s4                                    // 000000048708: 8C04046A
	ds_store_b128 v9, v[4:7] offset:10496                      // 00000004870C: DB7C2900 00000409
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000048714: 917E047E
	s_cbranch_execnz 65472                                     // 000000048718: BFA6FFC0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x231c>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004871C: 8C7E037E
	s_mov_b32 s3, 0                                            // 000000048720: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000048724: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 000000048728: 916A037E
	s_cbranch_vccnz 533                                        // 00000004872C: BFA40215 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c84>
	s_mov_b32 s3, exec_lo                                      // 000000048730: BE83007E
	v_cmpx_gt_u32_e32 16, v43                                  // 000000048734: 7D985690
	s_cbranch_execz 529                                        // 000000048738: BFA50211 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c80>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000004873C: 7C945680
	s_waitcnt lgkmcnt(0)                                       // 000000048740: BF89FC07
	ds_load_b96 v[14:16], v1 offset:23280                      // 000000048744: DBF85AF0 0E000001
	ds_load_b128 v[59:62], v1 offset:23248                     // 00000004874C: DBFC5AD0 3B000001
	ds_load_b128 v[63:66], v1 offset:23264                     // 000000048754: DBFC5AE0 3F000001
	ds_load_b128 v[10:13], v1 offset:23168                     // 00000004875C: DBFC5A80 0A000001
	ds_load_b128 v[6:9], v1 offset:23184                       // 000000048764: DBFC5A90 06000001
	ds_load_b128 v[2:5], v1 offset:23200                       // 00000004876C: DBFC5AA0 02000001
	ds_load_b64 v[17:18], v1 offset:23216                      // 000000048774: D9D85AB0 11000001
	v_cndmask_b32_e64 v44, 0, 1.0, vcc_lo                      // 00000004877C: D501002C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 000000048784: 7C945681
	ds_load_b128 v[45:48], v1 offset:23232                     // 000000048788: DBFC5AC0 2D000001
	v_cndmask_b32_e64 v33, 0, 1.0, vcc_lo                      // 000000048790: D5010021 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 000000048798: 7C945682
	v_cndmask_b32_e64 v32, 0, 1.0, vcc_lo                      // 00000004879C: D5010020 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 0000000487A4: 7C945683
	v_cndmask_b32_e64 v31, 0, 1.0, vcc_lo                      // 0000000487A8: D501001F 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 0000000487B0: 7C945684
	v_cndmask_b32_e64 v29, 0, 1.0, vcc_lo                      // 0000000487B4: D501001D 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 0000000487BC: 7C945685
	v_cndmask_b32_e64 v30, 0, 1.0, vcc_lo                      // 0000000487C0: D501001E 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 0000000487C8: 7C945686
	v_cndmask_b32_e64 v28, 0, 1.0, vcc_lo                      // 0000000487CC: D501001C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 0000000487D4: 7C945687
	v_cndmask_b32_e64 v27, 0, 1.0, vcc_lo                      // 0000000487D8: D501001B 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 0000000487E0: 7C945688
	v_cndmask_b32_e64 v25, 0, 1.0, vcc_lo                      // 0000000487E4: D5010019 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 0000000487EC: 7C945689
	v_cndmask_b32_e64 v23, 0, 1.0, vcc_lo                      // 0000000487F0: D5010017 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 0000000487F8: 7C94568A
	v_cndmask_b32_e64 v26, 0, 1.0, vcc_lo                      // 0000000487FC: D501001A 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 000000048804: 7C94568B
	v_cndmask_b32_e64 v24, 0, 1.0, vcc_lo                      // 000000048808: D5010018 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 000000048810: 7C94568C
	v_cndmask_b32_e64 v20, 0, 1.0, vcc_lo                      // 000000048814: D5010014 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 00000004881C: 7C94568D
	v_cndmask_b32_e64 v22, 0, 1.0, vcc_lo                      // 000000048820: D5010016 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 000000048828: 7C94568E
	v_cndmask_b32_e64 v21, 0, 1.0, vcc_lo                      // 00000004882C: D5010015 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 000000048834: 7C94568F
	v_cndmask_b32_e64 v19, 0, 1.0, vcc_lo                      // 000000048838: D5010013 01A9E480
	s_waitcnt lgkmcnt(7)                                       // 000000048840: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000048844: BF8700B1
	v_fmac_f32_e32 v22, v19, v15                               // 000000048848: 562C1F13
	v_fmac_f32_e32 v21, v19, v16                               // 00000004884C: 562A2113
	s_waitcnt lgkmcnt(1)                                       // 000000048850: BF89FC17
	v_dual_fmac_f32 v23, v19, v64 :: v_dual_fmac_f32 v22, v21, v18// 000000048854: C8008113 17162515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000004885C: BF8700D1
	v_dual_fmac_f32 v26, v19, v65 :: v_dual_fmac_f32 v23, v21, v3// 000000048860: C8008313 1A160715
	v_fmac_f32_e32 v25, v19, v63                               // 000000048868: 56327F13
	ds_load_b32 v18, v1 offset:22880                           // 00000004886C: D8D85960 12000001
	v_fmac_f32_e32 v26, v21, v4                                // 000000048874: 56340915
	v_dual_fmac_f32 v28, v19, v61 :: v_dual_fmac_f32 v25, v21, v2// 000000048878: C8007B13 1C180515
	v_dual_fmac_f32 v29, v19, v59 :: v_dual_fmac_f32 v28, v21, v8// 000000048880: C8007713 1D1C1115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048888: BF870091
	v_dual_fmac_f32 v30, v19, v60 :: v_dual_fmac_f32 v29, v21, v6// 00000004888C: C8007913 1E1C0D15
	v_dual_fmac_f32 v27, v19, v62 :: v_dual_fmac_f32 v30, v21, v7// 000000048894: C8007D13 1B1E0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004889C: BF870091
	v_dual_fmac_f32 v24, v19, v66 :: v_dual_fmac_f32 v27, v21, v9// 0000000488A0: C8008513 181A1315
	v_fmac_f32_e32 v24, v21, v5                                // 0000000488A8: 56300B15
	ds_load_b128 v[2:5], v1 offset:23072                       // 0000000488AC: DBFC5A20 02000001
	s_waitcnt lgkmcnt(2)                                       // 0000000488B4: BF89FC27
	v_fmac_f32_e32 v31, v19, v48                               // 0000000488B8: 563E6113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000488BC: BF870091
	v_dual_fmac_f32 v32, v19, v47 :: v_dual_fmac_f32 v31, v21, v13// 0000000488C0: C8005F13 201E1B15
	v_dual_fmac_f32 v33, v19, v46 :: v_dual_fmac_f32 v32, v21, v12// 0000000488C8: C8005D13 21201915
	v_fmac_f32_e32 v44, v19, v45                               // 0000000488D0: 56585B13
	ds_load_b128 v[45:48], v1 offset:24064                     // 0000000488D4: DBFC5E00 2D000001
	v_dual_fmac_f32 v33, v21, v11 :: v_dual_fmac_f32 v20, v19, v14// 0000000488DC: C8001715 21141D13
	ds_load_b128 v[59:62], v1 offset:23104                     // 0000000488E4: DBFC5A40 3B000001
	ds_load_b128 v[63:66], v1 offset:23136                     // 0000000488EC: DBFC5A60 3F000001
	ds_load_b128 v[67:70], v1 offset:23120                     // 0000000488F4: DBFC5A50 43000001
	ds_load_b32 v14, v1 offset:23152                           // 0000000488FC: D8D85A70 0E000001
	v_fmac_f32_e32 v44, v21, v10                               // 000000048904: 56581515
	ds_load_b128 v[6:9], v1 offset:23056                       // 000000048908: DBFC5A10 06000001
	ds_load_b128 v[10:13], v1 offset:23040                     // 000000048910: DBFC5A00 0A000001
	s_waitcnt lgkmcnt(5)                                       // 000000048918: BF89FC57
	v_fmac_f32_e32 v44, v22, v59                               // 00000004891C: 56587716
	v_dual_fmac_f32 v33, v22, v60 :: v_dual_fmac_f32 v20, v21, v17// 000000048920: C8007916 21142315
	s_waitcnt lgkmcnt(3)                                       // 000000048928: BF89FC37
	v_fmac_f32_e32 v29, v22, v67                               // 00000004892C: 563A8716
	v_fmac_f32_e32 v31, v22, v62                               // 000000048930: 563E7D16
	s_waitcnt lgkmcnt(2)                                       // 000000048934: BF89FC27
	v_fmac_f32_e32 v20, v22, v14                               // 000000048938: 56281D16
	ds_load_b128 v[14:17], v1 offset:22976                     // 00000004893C: DBFC59C0 0E000001
	v_fmac_f32_e32 v24, v22, v66                               // 000000048944: 56308516
	v_fmac_f32_e32 v32, v22, v61                               // 000000048948: 56407B16
	ds_load_b64 v[66:67], v1 offset:22944                      // 00000004894C: D9D859A0 42000001
	s_waitcnt lgkmcnt(2)                                       // 000000048954: BF89FC27
	v_fmac_f32_e32 v33, v20, v11                               // 000000048958: 56421714
	v_fmac_f32_e32 v24, v20, v5                                // 00000004895C: 56300B14
	s_waitcnt lgkmcnt(1)                                       // 000000048960: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000048964: BF8701B1
	v_dual_fmac_f32 v33, v24, v15 :: v_dual_fmac_f32 v30, v22, v68// 000000048968: C8001F18 211E8916
	v_fmac_f32_e32 v29, v20, v6                                // 000000048970: 563A0D14
	v_dual_fmac_f32 v25, v22, v63 :: v_dual_fmac_f32 v44, v20, v10// 000000048974: C8007F16 192C1514
	v_dual_fmac_f32 v23, v22, v64 :: v_dual_fmac_f32 v30, v20, v7// 00000004897C: C8008116 171E0F14
	v_fmac_f32_e32 v26, v22, v65                               // 000000048984: 56348316
	ds_load_b128 v[59:62], v1 offset:22992                     // 000000048988: DBFC59D0 3B000001
	ds_load_b96 v[63:65], v1 offset:23008                      // 000000048990: DBF859E0 3F000001
	v_dual_fmac_f32 v28, v22, v69 :: v_dual_fmac_f32 v25, v20, v2// 000000048998: C8008B16 1C180514
	v_dual_fmac_f32 v27, v22, v70 :: v_dual_fmac_f32 v32, v20, v12// 0000000489A0: C8008D16 1B201914
	v_fmac_f32_e32 v23, v20, v3                                // 0000000489A8: 562E0714
	v_fmac_f32_e32 v26, v20, v4                                // 0000000489AC: 56340914
	v_fmac_f32_e32 v31, v20, v13                               // 0000000489B0: 563E1B14
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000489B4: BF870004
	v_fmac_f32_e32 v27, v20, v9                                // 0000000489B8: 56361314
	ds_load_b128 v[2:5], v1 offset:22848                       // 0000000489BC: DBFC5940 02000001
	s_waitcnt lgkmcnt(1)                                       // 0000000489C4: BF89FC17
	v_fmac_f32_e32 v26, v24, v65                               // 0000000489C8: 56348318
	v_fmac_f32_e32 v28, v20, v8                                // 0000000489CC: 56381114
	ds_load_b128 v[6:9], v1 offset:22928                       // 0000000489D0: DBFC5990 06000001
	ds_load_b128 v[10:13], v1 offset:22912                     // 0000000489D8: DBFC5980 0A000001
	v_fmac_f32_e32 v29, v24, v59                               // 0000000489E0: 563A7718
	s_waitcnt lgkmcnt(1)                                       // 0000000489E4: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000489E8: BF870001
	v_fmac_f32_e32 v29, v26, v6                                // 0000000489EC: 563A0D1A
	v_fmac_f32_e32 v31, v24, v17                               // 0000000489F0: 563E2318
	v_fmac_f32_e32 v44, v24, v14                               // 0000000489F4: 56581D18
	v_fmac_f32_e32 v23, v24, v64                               // 0000000489F8: 562E8118
	v_fmac_f32_e32 v32, v24, v16                               // 0000000489FC: 56402118
	ds_load_b128 v[14:17], v1 offset:22864                     // 000000048A00: DBFC5950 0E000001
	v_fmac_f32_e32 v23, v26, v67                               // 000000048A08: 562E871A
	s_waitcnt lgkmcnt(0)                                       // 000000048A0C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000048A10: BF870001
	v_fmac_f32_e32 v29, v23, v14                               // 000000048A14: 563A1D17
	v_fmac_f32_e32 v27, v24, v62                               // 000000048A18: 56367D18
	v_fmac_f32_e32 v30, v24, v60                               // 000000048A1C: 563C7918
	v_fmac_f32_e32 v25, v24, v63                               // 000000048A20: 56327F18
	v_dual_fmac_f32 v33, v26, v11 :: v_dual_fmac_f32 v28, v24, v61// 000000048A24: C800171A 211C7B18
	ds_load_b128 v[59:62], v1 offset:22800                     // 000000048A2C: DBFC5910 3B000001
	v_fmac_f32_e32 v32, v26, v12                               // 000000048A34: 5640191A
	v_fmac_f32_e32 v31, v26, v13                               // 000000048A38: 563E1B1A
	v_fmac_f32_e32 v44, v26, v10                               // 000000048A3C: 5658151A
	ds_load_b128 v[10:13], v1 offset:22784                     // 000000048A40: DBFC5900 0A000001
	ds_load_b96 v[63:65], v1 offset:22736                      // 000000048A48: DBF858D0 3F000001
	v_fmac_f32_e32 v27, v26, v9                                // 000000048A50: 5636131A
	v_fmac_f32_e32 v30, v26, v7                                // 000000048A54: 563C0F1A
	v_fmac_f32_e32 v25, v26, v66                               // 000000048A58: 5632851A
	v_fmac_f32_e32 v28, v26, v8                                // 000000048A5C: 5638111A
	ds_load_b128 v[6:9], v1 offset:22720                       // 000000048A60: DBFC58C0 06000001
	ds_load_b64 v[66:67], v1 offset:22672                      // 000000048A68: D9D85890 42000001
	v_fmac_f32_e32 v33, v23, v3                                // 000000048A70: 56420717
	v_fmac_f32_e32 v25, v23, v18                               // 000000048A74: 56322517
	v_fmac_f32_e32 v28, v23, v16                               // 000000048A78: 56382117
	v_fmac_f32_e32 v27, v23, v17                               // 000000048A7C: 56362317
	v_fmac_f32_e32 v30, v23, v15                               // 000000048A80: 563C1F17
	ds_load_b128 v[14:17], v1 offset:22528                     // 000000048A84: DBFC5800 0E000001
	s_waitcnt lgkmcnt(5)                                       // 000000048A8C: BF89FC57
	v_fmac_f32_e32 v27, v25, v62                               // 000000048A90: 56367D19
	v_fmac_f32_e32 v28, v25, v61                               // 000000048A94: 56387B19
	v_fmac_f32_e32 v30, v25, v60                               // 000000048A98: 563C7919
	s_waitcnt lgkmcnt(3)                                       // 000000048A9C: BF89FC37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000048AA0: BF870112
	v_fmac_f32_e32 v28, v27, v65                               // 000000048AA4: 5638831B
	v_fmac_f32_e32 v30, v27, v64                               // 000000048AA8: 563C811B
	s_waitcnt lgkmcnt(1)                                       // 000000048AAC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000048AB0: BF870001
	v_fmac_f32_e32 v30, v28, v67                               // 000000048AB4: 563C871C
	v_dual_fmac_f32 v44, v23, v2 :: v_dual_fmac_f32 v33, v25, v11// 000000048AB8: C8000517 2C201719
	v_fmac_f32_e32 v31, v23, v5                                // 000000048AC0: 563E0B17
	v_fmac_f32_e32 v32, v23, v4                                // 000000048AC4: 56400917
	ds_load_b128 v[2:5], v1 offset:22656                       // 000000048AC8: DBFC5880 02000001
	v_fmac_f32_e32 v44, v25, v10                               // 000000048AD0: 56581519
	v_fmac_f32_e32 v29, v25, v59                               // 000000048AD4: 563A7719
	v_fmac_f32_e32 v31, v25, v13                               // 000000048AD8: 563E1B19
	v_fmac_f32_e32 v32, v25, v12                               // 000000048ADC: 56401919
	ds_load_b128 v[10:13], v1 offset:22592                     // 000000048AE0: DBFC5840 0A000001
	ds_load_b32 v18, v1 offset:22608                           // 000000048AE8: D8D85850 12000001
	v_fmac_f32_e32 v33, v27, v7                                // 000000048AF0: 56420F1B
	v_fmac_f32_e32 v29, v27, v63                               // 000000048AF4: 563A7F1B
	ds_load_b64 v[59:60], v1 offset:22400                      // 000000048AF8: D9D85780 3B000001
	v_dual_fmac_f32 v32, v27, v8 :: v_dual_fmac_f32 v29, v28, v66// 000000048B00: C800111B 201C851C
	ds_load_b128 v[63:66], v1 offset:24304                     // 000000048B08: DBFC5EF0 3F000001
	s_waitcnt lgkmcnt(2)                                       // 000000048B10: BF89FC27
	v_fmac_f32_e32 v29, v30, v18                               // 000000048B14: 563A251E
	v_dual_fmac_f32 v44, v27, v6 :: v_dual_fmac_f32 v33, v28, v3// 000000048B18: C8000D1B 2C20071C
	v_fmac_f32_e32 v31, v27, v9                                // 000000048B20: 563E131B
	ds_load_b96 v[6:8], v1 offset:22464                        // 000000048B24: DBF857C0 06000001
	ds_load_b32 v9, v1 offset:22336                            // 000000048B2C: D8D85740 09000001
	v_fmac_f32_e32 v44, v28, v2                                // 000000048B34: 5658051C
	v_fmac_f32_e32 v32, v28, v4                                // 000000048B38: 5640091C
	v_fmac_f32_e32 v31, v28, v5                                // 000000048B3C: 563E0B1C
	v_fmac_f32_e32 v33, v30, v11                               // 000000048B40: 5642171E
	ds_load_b128 v[2:5], v1 offset:24256                       // 000000048B44: DBFC5EC0 02000001
	v_fmac_f32_e32 v44, v30, v10                               // 000000048B4C: 5658151E
	v_fmac_f32_e32 v32, v30, v12                               // 000000048B50: 5640191E
	v_fmac_f32_e32 v31, v30, v13                               // 000000048B54: 563E1B1E
	v_fmac_f32_e32 v33, v29, v15                               // 000000048B58: 56421F1D
	s_waitcnt lgkmcnt(3)                                       // 000000048B5C: BF89FC37
	v_mul_f32_e32 v72, v65, v21                                // 000000048B60: 10902B41
	v_fmac_f32_e32 v44, v29, v14                               // 000000048B64: 56581D1D
	v_fmac_f32_e32 v32, v29, v16                               // 000000048B68: 5640211D
	v_fmac_f32_e32 v31, v29, v17                               // 000000048B6C: 563E231D
	s_waitcnt lgkmcnt(2)                                       // 000000048B70: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000048B74: BF8700A1
	v_fmac_f32_e32 v32, v31, v8                                // 000000048B78: 5640111F
	v_fmac_f32_e32 v33, v31, v7                                // 000000048B7C: 56420F1F
	v_dual_fmac_f32 v44, v31, v6 :: v_dual_fmac_f32 v33, v32, v60// 000000048B80: C8000D1F 2C207920
	s_delay_alu instid0(VALU_DEP_1)                            // 000000048B88: BF870001
	v_fmac_f32_e32 v44, v32, v59                               // 000000048B8C: 56587720
	ds_load_b128 v[59:62], v1 offset:24288                     // 000000048B90: DBFC5EE0 3B000001
	s_waitcnt lgkmcnt(1)                                       // 000000048B98: BF89FC17
	v_fma_mixlo_f16 v49, v5, v31, 0                            // 000000048B9C: CC210031 02023F05
	v_mul_f32_e32 v15, v3, v33                                 // 000000048BA4: 101E4303
	v_fmac_f32_e32 v44, v33, v9                                // 000000048BA8: 56581321
	ds_load_b128 v[6:9], v1 offset:24272                       // 000000048BAC: DBFC5ED0 06000001
	ds_load_b128 v[10:13], v1 offset:24112                     // 000000048BB4: DBFC5E30 0A000001
	v_fma_mixlo_f16 v18, v3, v33, 0                            // 000000048BBC: CC210012 02024303
	v_mul_f32_e32 v14, v2, v44                                 // 000000048BC4: 101C5902
	v_fma_mixlo_f16 v2, v2, v44, 0                             // 000000048BC8: CC210002 02025902
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000048BD0: BF870113
	v_fma_mix_f32 v15, v18, -1.0, v15 op_sel_hi:[1,1,0]        // 000000048BD4: CC20000F 1C3DE712
	v_fma_mix_f32 v3, v2, -1.0, v14 op_sel_hi:[1,1,0]          // 000000048BDC: CC200003 1C39E702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000048BE4: BF870232
	.long 0x7f1c150f                                           // 000000048BE8: 7F1C150F
	v_mul_f32_e32 v15, v4, v32                                 // 000000048BEC: 101E4104
	.long 0x7f043912                                           // 000000048BF0: 7F043912
	v_cvt_f16_f32_e32 v14, v3                                  // 000000048BF4: 7E1C1503
	v_fma_mixlo_f16 v3, v4, v32, 0                             // 000000048BF8: CC210003 02024104
	v_mul_f32_e32 v4, v5, v31                                  // 000000048C00: 10083F05
	s_waitcnt lgkmcnt(2)                                       // 000000048C04: BF89FC27
	v_fma_mixlo_f16 v69, v60, v23, 0                           // 000000048C08: CC210045 02022F3C
	s_waitcnt lgkmcnt(1)                                       // 000000048C10: BF89FC17
	v_mul_f32_e32 v16, v7, v30                                 // 000000048C14: 10203D07
	v_fma_mixlo_f16 v67, v7, v30, 0                            // 000000048C18: CC210043 02023D07
	v_fma_mix_f32 v7, v3, -1.0, v15 op_sel_hi:[1,1,0]          // 000000048C20: CC200007 1C3DE703
	v_mul_f32_e32 v5, v6, v29                                  // 000000048C28: 100A3B06
	v_fma_mixlo_f16 v68, v9, v27, 0                            // 000000048C2C: CC210044 02023709
	.long 0x7f063931                                           // 000000048C34: 7F063931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000048C38: BF8701D4
	v_cvt_f16_f32_e32 v15, v7                                  // 000000048C3C: 7E1E1507
	v_mul_f32_e32 v7, v8, v28                                  // 000000048C40: 100E3908
	v_fma_mix_f32 v17, v49, -1.0, v4 op_sel_hi:[1,1,0]         // 000000048C44: CC200011 1C11E731
	v_fma_mixlo_f16 v4, v6, v29, 0                             // 000000048C4C: CC210004 02023B06
	v_fma_mix_f32 v6, v67, -1.0, v16 op_sel_hi:[1,1,0]         // 000000048C54: CC200006 1C41E743
	.long 0x7f1e1511                                           // 000000048C5C: 7F1E1511
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000048C60: BF870193
	v_fma_mix_f32 v5, v4, -1.0, v5 op_sel_hi:[1,1,0]           // 000000048C64: CC200005 1C15E704
	.long 0x7f201506                                           // 000000048C6C: 7F201506
	v_fma_mixlo_f16 v6, v59, v25, 0                            // 000000048C70: CC210006 0202333B
	.long 0x7f083943                                           // 000000048C78: 7F083943
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000048C7C: BF8701C4
	v_cvt_f16_f32_e32 v16, v5                                  // 000000048C80: 7E201505
	v_fma_mixlo_f16 v5, v8, v28, 0                             // 000000048C84: CC210005 02023908
	v_dual_mul_f32 v8, v9, v27 :: v_dual_mul_f32 v9, v59, v25  // 000000048C8C: C8C63709 0808333B
	v_dual_mul_f32 v59, v60, v23 :: v_dual_mul_f32 v60, v61, v26// 000000048C94: C8C62F3C 3B3C353D
	v_fma_mix_f32 v7, v5, -1.0, v7 op_sel_hi:[1,1,0]           // 000000048C9C: CC200007 1C1DE705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000048CA4: BF870213
	v_fma_mix_f32 v8, v68, -1.0, v8 op_sel_hi:[1,1,0]          // 000000048CA8: CC200008 1C21E744
	v_fma_mix_f32 v9, v6, -1.0, v9 op_sel_hi:[1,1,0]           // 000000048CB0: CC200009 1C25E706
	s_delay_alu instid0(VALU_DEP_4)                            // 000000048CB8: BF870004
	v_fma_mix_f32 v70, v69, -1.0, v59 op_sel_hi:[1,1,0]        // 000000048CBC: CC200046 1CEDE745
	.long 0x7f0c3945                                           // 000000048CC4: 7F0C3945
	v_cvt_f16_f32_e32 v17, v7                                  // 000000048CC8: 7E221507
	v_fma_mixlo_f16 v7, v61, v26, 0                            // 000000048CCC: CC210007 0202353D
	.long 0x7f221508                                           // 000000048CD4: 7F221508
	v_cvt_f16_f32_e32 v59, v9                                  // 000000048CD8: 7E761509
	.long 0x7f761546                                           // 000000048CDC: 7F761546
	v_mul_f32_e32 v9, v62, v24                                 // 000000048CE0: 1012313E
	v_fma_mix_f32 v8, v7, -1.0, v60 op_sel_hi:[1,1,0]          // 000000048CE4: CC200008 1CF1E707
	v_fma_mixlo_f16 v70, v62, v24, 0                           // 000000048CEC: CC210046 0202313E
	v_dual_mul_f32 v61, v63, v20 :: v_dual_mul_f32 v62, v64, v22// 000000048CF4: C8C6293F 3D3E2D40
	v_fma_mixlo_f16 v64, v64, v22, 0                           // 000000048CFC: CC210040 02022D40
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000048D04: BF870214
	v_cvt_f16_f32_e32 v60, v8                                  // 000000048D08: 7E781508
	v_fma_mix_f32 v71, v70, -1.0, v9 op_sel_hi:[1,1,0]         // 000000048D0C: CC200047 1C25E746
	v_fma_mixlo_f16 v8, v63, v20, 0                            // 000000048D14: CC210008 0202293F
	v_fma_mixlo_f16 v9, v65, v21, 0                            // 000000048D1C: CC210009 02022B41
	v_fma_mix_f32 v62, v64, -1.0, v62 op_sel_hi:[1,1,0]        // 000000048D24: CC20003E 1CF9E740
	v_mul_f32_e32 v65, v66, v19                                // 000000048D2C: 10822742
	v_fma_mixlo_f16 v66, v66, v19, 0                           // 000000048D30: CC210042 02022742
	v_fma_mix_f32 v61, v8, -1.0, v61 op_sel_hi:[1,1,0]         // 000000048D38: CC20003D 1CF5E708
	v_fma_mix_f32 v63, v9, -1.0, v72 op_sel_hi:[1,1,0]         // 000000048D40: CC20003F 1D21E709
	.long 0x7f781547                                           // 000000048D48: 7F781547
	.long 0x7f103940                                           // 000000048D4C: 7F103940
	v_fma_mix_f32 v71, v66, -1.0, v65 op_sel_hi:[1,1,0]        // 000000048D50: CC200047 1D05E742
	v_cvt_f16_f32_e32 v61, v61                                 // 000000048D58: 7E7A153D
	.long 0x7f7a153e                                           // 000000048D5C: 7F7A153E
	v_cvt_f16_f32_e32 v62, v63                                 // 000000048D60: 7E7C153F
	.long 0x7f123942                                           // 000000048D64: 7F123942
	ds_load_b128 v[63:66], v1 offset:24080                     // 000000048D68: DBFC5E10 3F000001
	v_mul_u32_u24_e32 v72, 48, v43                             // 000000048D70: 169056B0
	.long 0x7f0e3946                                           // 000000048D74: 7F0E3946
	.long 0x7f0a3944                                           // 000000048D78: 7F0A3944
	v_mul_f32_e32 v18, v45, v44                                // 000000048D7C: 1024592D
	v_fma_mixlo_f16 v43, v45, v44, 0                           // 000000048D80: CC21002B 0202592D
	v_mul_f32_e32 v44, v46, v33                                // 000000048D88: 1058432E
	v_fma_mixlo_f16 v33, v46, v33, 0                           // 000000048D8C: CC210021 0202432E
	ds_store_b128 v72, v[6:9] offset:19216                     // 000000048D94: DB7C4B10 00000648
	ds_store_b128 v72, v[2:5] offset:19200                     // 000000048D9C: DB7C4B00 00000248
	ds_load_b128 v[2:5], v1 offset:24096                       // 000000048DA4: DBFC5E20 02000001
	v_dual_mul_f32 v7, v47, v32 :: v_dual_mul_f32 v8, v48, v31 // 000000048DAC: C8C6412F 07083F30
	v_fma_mix_f32 v44, v33, -1.0, v44 op_sel_hi:[1,1,0]        // 000000048DB4: CC20002C 1CB1E721
	.long 0x7f7c1547                                           // 000000048DBC: 7F7C1547
	s_delay_alu instid0(VALU_DEP_2)                            // 000000048DC0: BF870002
	.long 0x7f0c152c                                           // 000000048DC4: 7F0C152C
	v_fma_mixlo_f16 v44, v47, v32, 0                           // 000000048DC8: CC21002C 0202412F
	s_waitcnt lgkmcnt(3)                                       // 000000048DD0: BF89FC37
	v_mul_f32_e32 v9, v63, v29                                 // 000000048DD4: 10123B3F
	v_fma_mix_f32 v18, v43, -1.0, v18 op_sel_hi:[1,1,0]        // 000000048DD8: CC200012 1C49E72B
	v_fma_mixlo_f16 v45, v63, v29, 0                           // 000000048DE0: CC21002D 02023B3F
	v_fma_mix_f32 v7, v44, -1.0, v7 op_sel_hi:[1,1,0]          // 000000048DE8: CC200007 1C1DE72C
	v_fma_mixlo_f16 v46, v65, v28, 0                           // 000000048DF0: CC21002E 02023941
	.long 0x7f563921                                           // 000000048DF8: 7F563921
	v_cvt_f16_f32_e32 v6, v18                                  // 000000048DFC: 7E0C1512
	v_fma_mixlo_f16 v18, v48, v31, 0                           // 000000048E00: CC210012 02023F30
	v_mul_f32_e32 v31, v64, v30                                // 000000048E08: 103E3D40
	v_fma_mixlo_f16 v30, v64, v30, 0                           // 000000048E0C: CC21001E 02023D40
	v_fma_mix_f32 v9, v45, -1.0, v9 op_sel_hi:[1,1,0]          // 000000048E14: CC200009 1C25E72D
	v_cvt_f16_f32_e32 v7, v7                                   // 000000048E1C: 7E0E1507
	.long 0x7f583912                                           // 000000048E20: 7F583912
	s_delay_alu instid0(VALU_DEP_4)                            // 000000048E24: BF870004
	v_fma_mix_f32 v29, v30, -1.0, v31 op_sel_hi:[1,1,0]        // 000000048E28: CC20001D 1C7DE71E
	v_mul_f32_e32 v31, v65, v28                                // 000000048E30: 103E3941
	v_fma_mix_f32 v8, v18, -1.0, v8 op_sel_hi:[1,1,0]          // 000000048E34: CC200008 1C21E712
	v_mul_f32_e32 v28, v66, v27                                // 000000048E3C: 10383742
	v_fma_mixlo_f16 v27, v66, v27, 0                           // 000000048E40: CC21001B 02023742
	.long 0x7f5a391e                                           // 000000048E48: 7F5A391E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000048E4C: BF870004
	.long 0x7f0e1508                                           // 000000048E50: 7F0E1508
	v_cvt_f16_f32_e32 v8, v9                                   // 000000048E54: 7E101509
	.long 0x7f10151d                                           // 000000048E58: 7F10151D
	v_fma_mix_f32 v9, v46, -1.0, v31 op_sel_hi:[1,1,0]         // 000000048E5C: CC200009 1C7DE72E
	s_waitcnt lgkmcnt(0)                                       // 000000048E64: BF89FC07
	v_mul_f32_e32 v29, v2, v25                                 // 000000048E68: 103A3302
	v_fma_mixlo_f16 v2, v2, v25, 0                             // 000000048E6C: CC210002 02023302
	v_mul_f32_e32 v25, v3, v23                                 // 000000048E74: 10322F03
	v_fma_mixlo_f16 v31, v3, v23, 0                            // 000000048E78: CC21001F 02022F03
	v_fma_mix_f32 v3, v27, -1.0, v28 op_sel_hi:[1,1,0]         // 000000048E80: CC200003 1C71E71B
	v_cvt_f16_f32_e32 v9, v9                                   // 000000048E88: 7E121509
	v_mul_f32_e32 v23, v4, v26                                 // 000000048E8C: 102E3504
	.long 0x7f5c391b                                           // 000000048E90: 7F5C391B
	v_fma_mix_f32 v25, v31, -1.0, v25 op_sel_hi:[1,1,0]        // 000000048E94: CC200019 1C65E71F
	.long 0x7f121503                                           // 000000048E9C: 7F121503
	v_fma_mixlo_f16 v3, v4, v26, 0                             // 000000048EA0: CC210003 02023504
	v_mul_f32_e32 v26, v11, v22                                // 000000048EA8: 10342D0B
	v_fma_mix_f32 v28, v2, -1.0, v29 op_sel_hi:[1,1,0]         // 000000048EAC: CC20001C 1C75E702
	v_fma_mixlo_f16 v11, v11, v22, 0                           // 000000048EB4: CC21000B 02022D0B
	.long 0x7f04391f                                           // 000000048EBC: 7F04391F
	v_fma_mix_f32 v4, v3, -1.0, v23 op_sel_hi:[1,1,0]          // 000000048EC0: CC200004 1C5DE703
	.long 0x7f2e1519                                           // 000000048EC8: 7F2E1519
	v_cvt_f16_f32_e32 v23, v28                                 // 000000048ECC: 7E2E151C
	v_mul_f32_e32 v25, v5, v24                                 // 000000048ED0: 10323105
	v_fma_mixlo_f16 v28, v5, v24, 0                            // 000000048ED4: CC21001C 02023105
	v_cvt_f16_f32_e32 v24, v4                                  // 000000048EDC: 7E301504
	v_mul_f32_e32 v5, v10, v20                                 // 000000048EE0: 100A290A
	v_fma_mixlo_f16 v4, v10, v20, 0                            // 000000048EE4: CC210004 0202290A
	v_fma_mix_f32 v20, v11, -1.0, v26 op_sel_hi:[1,1,0]        // 000000048EEC: CC200014 1C69E70B
	v_fma_mix_f32 v22, v28, -1.0, v25 op_sel_hi:[1,1,0]        // 000000048EF4: CC200016 1C65E71C
	v_mul_f32_e32 v25, v12, v21                                // 000000048EFC: 10322B0C
	.long 0x7f06391c                                           // 000000048F00: 7F06391C
	v_fma_mix_f32 v10, v4, -1.0, v5 op_sel_hi:[1,1,0]          // 000000048F04: CC20000A 1C15E704
	v_fma_mixlo_f16 v5, v12, v21, 0                            // 000000048F0C: CC210005 02022B0C
	v_mul_f32_e32 v21, v13, v19                                // 000000048F14: 102A270D
	v_fma_mixlo_f16 v13, v13, v19, 0                           // 000000048F18: CC21000D 0202270D
	.long 0x7f08390b                                           // 000000048F20: 7F08390B
	.long 0x7f301516                                           // 000000048F24: 7F301516
	v_fma_mix_f32 v12, v5, -1.0, v25 op_sel_hi:[1,1,0]         // 000000048F28: CC20000C 1C65E705
	v_cvt_f16_f32_e32 v25, v10                                 // 000000048F30: 7E32150A
	v_fma_mix_f32 v10, v13, -1.0, v21 op_sel_hi:[1,1,0]        // 000000048F34: CC20000A 1C55E70D
	.long 0x7f0a390d                                           // 000000048F3C: 7F0A390D
	.long 0x7f321514                                           // 000000048F40: 7F321514
	v_cvt_f16_f32_e32 v26, v12                                 // 000000048F44: 7E34150C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000048F48: BF870004
	.long 0x7f34150a                                           // 000000048F4C: 7F34150A
	ds_store_b128 v72, v[59:62] offset:19984                   // 000000048F50: DB7C4E10 00003B48
	ds_store_b128 v72, v[14:17] offset:19968                   // 000000048F58: DB7C4E00 00000E48
	ds_store_b128 v72, v[2:5] offset:20752                     // 000000048F60: DB7C5110 00000248
	ds_store_b128 v72, v[43:46] offset:20736                   // 000000048F68: DB7C5100 00002B48
	ds_store_b128 v72, v[23:26] offset:21520                   // 000000048F70: DB7C5410 00001748
	ds_store_b128 v72, v[6:9] offset:21504                     // 000000048F78: DB7C5400 00000648
	s_or_b32 exec_lo, exec_lo, s3                              // 000000048F80: 8C7E037E
	v_lshlrev_b32_e32 v59, 1, v153                             // 000000048F84: 30773281
	s_waitcnt lgkmcnt(0)                                       // 000000048F88: BF89FC07
	s_barrier                                                  // 000000048F8C: BFBD0000
	v_cmp_eq_u32_e32 vcc_lo, 0, v34                            // 000000048F90: 7C944480
	v_mul_u32_u24_e32 v60, 48, v55                             // 000000048F94: 16786EB0
	s_cmp_lt_i32 s54, s39                                      // 000000048F98: BF042736
	ds_load_u16 v2, v59 offset:6416                            // 000000048F9C: D8F01910 0200003B
	ds_load_u16 v3, v59 offset:7776                            // 000000048FA4: D8F01E60 0300003B
	ds_load_u16 v4, v59 offset:7232                            // 000000048FAC: D8F01C40 0400003B
	s_waitcnt lgkmcnt(0)                                       // 000000048FB4: BF89FC07
	ds_load_u16 v5, v59 offset:6688                            // 000000048FB8: D8F01A20 0500003B
	ds_load_u16 v6, v59 offset:6144                            // 000000048FC0: D8F01800 0600003B
	ds_load_b128 v[22:25], v60 offset:19984                    // 000000048FC8: DBFC4E10 1600003C
	ds_load_b128 v[18:21], v60 offset:19968                    // 000000048FD0: DBFC4E00 1200003C
	ds_load_b128 v[26:29], v60 offset:19200                    // 000000048FD8: DBFC4B00 1A00003C
	ds_load_b128 v[30:33], v60 offset:19216                    // 000000048FE0: DBFC4B10 1E00003C
	s_cselect_b32 s3, -1, 0                                    // 000000048FE8: 980380C1
	s_or_b32 s4, s54, 1                                        // 000000048FEC: 8C048136
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000048FF0: BF870159
	s_cmp_lt_i32 s4, s39                                       // 000000048FF4: BF042704
	s_cselect_b32 s4, -1, 0                                    // 000000048FF8: 980480C1
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000048FFC: 30040490
	s_waitcnt lgkmcnt(4)                                       // 000000049000: BF89FC47
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000049004: 300C0C90
	.long 0x7f141502                                           // 000000049008: 7F141502
	ds_load_u16 v2, v59 offset:6960                            // 00000004900C: D8F01B30 0200003B
	v_cvt_f16_f32_e32 v10, v6                                  // 000000049014: 7E141506
	s_waitcnt lgkmcnt(0)                                       // 000000049018: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000004901C: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000049020: BF8700A1
	.long 0x7f161502                                           // 000000049024: 7F161502
	v_lshlrev_b32_e32 v2, 16, v5                               // 000000049028: 30040A90
	v_cvt_f16_f32_e32 v11, v2                                  // 00000004902C: 7E161502
	ds_load_u16 v2, v59 offset:7504                            // 000000049030: D8F01D50 0200003B
	s_waitcnt lgkmcnt(0)                                       // 000000049038: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000004903C: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000049040: BF8700A1
	.long 0x7f181502                                           // 000000049044: 7F181502
	v_lshlrev_b32_e32 v2, 16, v4                               // 000000049048: 30040890
	v_cvt_f16_f32_e32 v12, v2                                  // 00000004904C: 7E181502
	ds_load_u16 v2, v59 offset:8048                            // 000000049050: D8F01F70 0200003B
	s_waitcnt lgkmcnt(0)                                       // 000000049058: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000004905C: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000049060: BF8700A1
	.long 0x7f1a1502                                           // 000000049064: 7F1A1502
	v_lshlrev_b32_e32 v2, 16, v3                               // 000000049068: 30040690
	v_cvt_f16_f32_e32 v13, v2                                  // 00000004906C: 7E1A1502
	ds_load_u16 v2, v59 offset:8592                            // 000000049070: D8F02190 0200003B
	ds_load_u16 v3, v59 offset:9952                            // 000000049078: D8F026E0 0300003B
	ds_load_u16 v4, v59 offset:9408                            // 000000049080: D8F024C0 0400003B
	ds_load_u16 v5, v59 offset:8864                            // 000000049088: D8F022A0 0500003B
	ds_load_u16 v6, v59 offset:8320                            // 000000049090: D8F02080 0600003B
	s_waitcnt lgkmcnt(4)                                       // 000000049098: BF89FC47
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000004909C: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000490A0: BF8700B1
	.long 0x7f1c1502                                           // 0000000490A4: 7F1C1502
	s_waitcnt lgkmcnt(0)                                       // 0000000490A8: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v6                               // 0000000490AC: 30040C90
	v_cvt_f16_f32_e32 v14, v2                                  // 0000000490B0: 7E1C1502
	ds_load_u16 v2, v59 offset:9136                            // 0000000490B4: D8F023B0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 0000000490BC: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000490C0: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000490C4: BF8700A1
	.long 0x7f1e1502                                           // 0000000490C8: 7F1E1502
	v_lshlrev_b32_e32 v2, 16, v5                               // 0000000490CC: 30040A90
	v_cvt_f16_f32_e32 v15, v2                                  // 0000000490D0: 7E1E1502
	ds_load_u16 v2, v59 offset:9680                            // 0000000490D4: D8F025D0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 0000000490DC: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000490E0: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000490E4: BF8700A1
	.long 0x7f201502                                           // 0000000490E8: 7F201502
	v_lshlrev_b32_e32 v2, 16, v4                               // 0000000490EC: 30040890
	v_cvt_f16_f32_e32 v16, v2                                  // 0000000490F0: 7E201502
	ds_load_u16 v2, v59 offset:10224                           // 0000000490F4: D8F027F0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 0000000490FC: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000049100: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000049104: BF8700A1
	.long 0x7f221502                                           // 000000049108: 7F221502
	v_lshlrev_b32_e32 v2, 16, v3                               // 00000004910C: 30040690
	v_cvt_f16_f32_e32 v17, v2                                  // 000000049110: 7E221502
	v_dual_mov_b32 v2, s20 :: v_dual_mov_b32 v3, s21           // 000000049114: CA100014 02020015
	v_dual_mov_b32 v4, s22 :: v_dual_mov_b32 v5, s23           // 00000004911C: CA100016 04040017
	v_dual_mov_b32 v6, s24 :: v_dual_mov_b32 v7, s25           // 000000049124: CA100018 06060019
	v_dual_mov_b32 v8, s26 :: v_dual_mov_b32 v9, s27           // 00000004912C: CA10001A 0808001B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000049134: BF870121
	v_wmma_f32_16x16x16_f16 v[61:68], v[18:25], v[10:17], v[2:9]// 000000049138: CC40403D 1C0A1512
	v_mov_b32_e32 v18, 0                                       // 000000049140: 7E240280
	v_wmma_f32_16x16x16_f16 v[61:68], v[26:33], v[10:17], v[61:68]// 000000049144: CC40403D 1CF6151A
	v_dual_mov_b32 v10, 0 :: v_dual_cndmask_b32 v11, 0x7060302, v149// 00000004914C: CA120080 0A0B2AFF 07060302
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 000000049158: CA100080 0C0C0080
	v_mov_b32_e32 v14, 0                                       // 000000049160: 7E1C0280
	s_waitcnt vmcnt(7)                                         // 000000049164: BF891FF7
	s_delay_alu instid0(VALU_DEP_3)                            // 000000049168: BF870003
	v_mov_b32_dpp v10, v42 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000004916C: 7E1402FA FF00B12A
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 000000049174: CA100080 0F100080
	v_mov_b32_e32 v17, 0                                       // 00000004917C: 7E220280
	s_waitcnt vmcnt(6)                                         // 000000049180: BF891BF7
	v_mov_b32_dpp v12, v41 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000049184: 7E1802FA FF00B129
	v_perm_b32 v10, v42, v10, v11                              // 00000004918C: D644000A 042E152A
	s_waitcnt vmcnt(5)                                         // 000000049194: BF8917F7
	v_mov_b32_dpp v13, v40 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000049198: 7E1A02FA FF00B128
	s_waitcnt vmcnt(4)                                         // 0000000491A0: BF8913F7
	v_mov_b32_dpp v14, v39 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000491A4: 7E1C02FA FF00B127
	s_waitcnt vmcnt(3)                                         // 0000000491AC: BF890FF7
	v_mov_b32_dpp v15, v38 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000491B0: 7E1E02FA FF00B126
	s_waitcnt vmcnt(2)                                         // 0000000491B8: BF890BF7
	v_mov_b32_dpp v16, v37 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000491BC: 7E2002FA FF00B125
	s_waitcnt vmcnt(1)                                         // 0000000491C4: BF8907F7
	v_mov_b32_dpp v17, v35 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000491C8: 7E2202FA FF00B123
	s_waitcnt vmcnt(0)                                         // 0000000491D0: BF8903F7
	v_mov_b32_dpp v18, v36 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000491D4: 7E2402FA FF00B124
	v_perm_b32 v12, v41, v12, v11                              // 0000000491DC: D644000C 042E1929
	v_perm_b32 v13, v40, v13, v11                              // 0000000491E4: D644000D 042E1B28
	v_perm_b32 v14, v39, v14, v11                              // 0000000491EC: D644000E 042E1D27
	v_perm_b32 v15, v38, v15, v11                              // 0000000491F4: D644000F 042E1F26
	v_perm_b32 v16, v37, v16, v11                              // 0000000491FC: D6440010 042E2125
	v_perm_b32 v17, v35, v17, v11                              // 000000049204: D6440011 042E2323
	v_perm_b32 v11, v36, v18, v11                              // 00000004920C: D644000B 042E2524
	v_lshlrev_b32_e32 v18, 16, v10                             // 000000049214: 30241490
	v_and_b32_e32 v19, 0xffff0000, v10                         // 000000049218: 362614FF FFFF0000
	ds_load_b128 v[30:33], v60 offset:21520                    // 000000049220: DBFC5410 1E00003C
	ds_load_b128 v[26:29], v60 offset:21504                    // 000000049228: DBFC5400 1A00003C
	ds_load_b128 v[38:41], v60 offset:20752                    // 000000049230: DBFC5110 2600003C
	ds_load_b128 v[34:37], v60 offset:20736                    // 000000049238: DBFC5100 2200003C
	v_cmp_eq_u32_e32 vcc_lo, 0, v154                           // 000000049240: 7C953480
	v_cvt_f16_f32_e32 v10, v18                                 // 000000049244: 7E141512
	.long 0x7f141513                                           // 000000049248: 7F141513
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004924C: BF870112
	v_cndmask_b16 v18, 0, v10, s3                              // 000000049250: D65D0012 000E1480
	v_cndmask_b16 v18, 0, v10, s4                              // 000000049258: D65D5012 00121480
	v_lshlrev_b32_e32 v10, 16, v12                             // 000000049260: 30141890
	s_or_b32 s3, s54, 2                                        // 000000049264: 8C038236
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049268: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004926C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000049270: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000049274: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000049278: BF870481
	v_cndmask_b16 v19, 0, v10, s3                              // 00000004927C: D65D0013 000E1480
	v_and_b32_e32 v10, 0xffff0000, v12                         // 000000049284: 361418FF FFFF0000
	s_or_b32 s3, s54, 3                                        // 00000004928C: 8C038336
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049290: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000049294: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000049298: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004929C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000492A0: BF870481
	v_cndmask_b16 v19, 0, v10, s3                              // 0000000492A4: D65D4013 000E1480
	v_lshlrev_b32_e32 v10, 16, v13                             // 0000000492AC: 30141A90
	s_or_b32 s3, s54, 4                                        // 0000000492B0: 8C038436
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000492B4: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000492B8: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000492BC: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000492C0: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000492C4: BF870481
	v_cndmask_b16 v20, 0, v10, s3                              // 0000000492C8: D65D0014 000E1480
	v_and_b32_e32 v10, 0xffff0000, v13                         // 0000000492D0: 36141AFF FFFF0000
	s_or_b32 s3, s54, 5                                        // 0000000492D8: 8C038536
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000492DC: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000492E0: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000492E4: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000492E8: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000492EC: BF870481
	v_cndmask_b16 v20, 0, v10, s3                              // 0000000492F0: D65D4014 000E1480
	v_lshlrev_b32_e32 v10, 16, v14                             // 0000000492F8: 30141C90
	s_or_b32 s3, s54, 6                                        // 0000000492FC: 8C038636
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049300: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000049304: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000049308: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004930C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000049310: BF870481
	v_cndmask_b16 v21, 0, v10, s3                              // 000000049314: D65D0015 000E1480
	v_and_b32_e32 v10, 0xffff0000, v14                         // 00000004931C: 36141CFF FFFF0000
	s_or_b32 s3, s54, 7                                        // 000000049324: 8C038736
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049328: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004932C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000049330: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000049334: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000049338: BF870481
	v_cndmask_b16 v21, 0, v10, s3                              // 00000004933C: D65D4015 000E1480
	v_lshlrev_b32_e32 v10, 16, v15                             // 000000049344: 30141E90
	s_or_b32 s3, s54, 8                                        // 000000049348: 8C038836
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004934C: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000049350: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000049354: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000049358: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004935C: BF870481
	v_cndmask_b16 v22, 0, v10, s3                              // 000000049360: D65D0016 000E1480
	v_and_b32_e32 v10, 0xffff0000, v15                         // 000000049368: 36141EFF FFFF0000
	s_or_b32 s3, s54, 9                                        // 000000049370: 8C038936
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049374: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000049378: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004937C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000049380: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000049384: BF870481
	v_cndmask_b16 v22, 0, v10, s3                              // 000000049388: D65D4016 000E1480
	v_lshlrev_b32_e32 v10, 16, v16                             // 000000049390: 30142090
	s_or_b32 s3, s54, 10                                       // 000000049394: 8C038A36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049398: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004939C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000493A0: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000493A4: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000493A8: BF870481
	v_cndmask_b16 v23, 0, v10, s3                              // 0000000493AC: D65D0017 000E1480
	v_and_b32_e32 v10, 0xffff0000, v16                         // 0000000493B4: 361420FF FFFF0000
	s_or_b32 s3, s54, 11                                       // 0000000493BC: 8C038B36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000493C0: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000493C4: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000493C8: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000493CC: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000493D0: BF870481
	v_cndmask_b16 v23, 0, v10, s3                              // 0000000493D4: D65D4017 000E1480
	v_lshlrev_b32_e32 v10, 16, v17                             // 0000000493DC: 30142290
	s_or_b32 s3, s54, 12                                       // 0000000493E0: 8C038C36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000493E4: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000493E8: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000493EC: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000493F0: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000493F4: BF870481
	v_cndmask_b16 v24, 0, v10, s3                              // 0000000493F8: D65D0018 000E1480
	v_and_b32_e32 v10, 0xffff0000, v17                         // 000000049400: 361422FF FFFF0000
	s_or_b32 s3, s54, 13                                       // 000000049408: 8C038D36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004940C: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000049410: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000049414: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000049418: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004941C: BF870481
	v_cndmask_b16 v24, 0, v10, s3                              // 000000049420: D65D4018 000E1480
	v_lshlrev_b32_e32 v10, 16, v11                             // 000000049428: 30141690
	s_or_b32 s3, s54, 14                                       // 00000004942C: 8C038E36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049430: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000049434: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000049438: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004943C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000049440: BF870481
	v_cndmask_b16 v25, 0, v10, s3                              // 000000049444: D65D0019 000E1480
	v_and_b32_e32 v10, 0xffff0000, v11                         // 00000004944C: 361416FF FFFF0000
	s_or_b32 s3, s54, 15                                       // 000000049454: 8C038F36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049458: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004945C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000049460: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000049464: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000049468: BF870481
	v_cndmask_b16 v25, 0, v10, s3                              // 00000004946C: D65D4019 000E1480
	s_waitcnt lgkmcnt(2)                                       // 000000049474: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000049478: BF8700A1
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[18:25], v[2:9]// 00000004947C: CC40400A 1C0A251A
	s_waitcnt lgkmcnt(0)                                       // 000000049484: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[34:41], v[18:25], v[10:17]// 000000049488: CC40400A 1C2A2522
	v_cvt_f16_f32_e32 v18, v61                                 // 000000049490: 7E24153D
	v_mad_u32_u24 v22, 0x110, v154, v59                        // 000000049494: D60B0016 04EF34FF 00000110
	.long 0x7f24153e                                           // 0000000494A0: 7F24153E
	v_cvt_f16_f32_e32 v19, v63                                 // 0000000494A4: 7E26153F
	.long 0x7f261540                                           // 0000000494A8: 7F261540
	v_cvt_f16_f32_e32 v20, v65                                 // 0000000494AC: 7E281541
	.long 0x7f281542                                           // 0000000494B0: 7F281542
	v_cvt_f16_f32_e32 v21, v67                                 // 0000000494B4: 7E2A1543
	.long 0x7f2a1544                                           // 0000000494B8: 7F2A1544
	ds_store_b16 v22, v18 offset:14848                         // 0000000494BC: D87C3A00 00001216
	ds_store_b16_d16_hi v22, v18 offset:15392                  // 0000000494C4: DA843C20 00001216
	ds_store_b16 v22, v19 offset:15936                         // 0000000494CC: D87C3E40 00001316
	ds_store_b16_d16_hi v22, v19 offset:16480                  // 0000000494D4: DA844060 00001316
	ds_store_b16 v22, v20 offset:17024                         // 0000000494DC: D87C4280 00001416
	ds_store_b16_d16_hi v22, v20 offset:17568                  // 0000000494E4: DA8444A0 00001416
	ds_store_b16 v22, v21 offset:18112                         // 0000000494EC: D87C46C0 00001516
	ds_store_b16_d16_hi v22, v21 offset:18656                  // 0000000494F4: DA8448E0 00001516
	v_fma_mixlo_f16 v18, v139, s51, 0                          // 0000000494FC: CC210012 0200678B
	v_fma_mixhi_f16 v18, v138, s51, 0                          // 000000049504: CC220012 0200678A
	v_mov_b32_e32 v20, 0x3020706                               // 00000004950C: 7E2802FF 03020706
	v_cndmask_b32_e32 v61, 0x5040100, v149, vcc_lo             // 000000049514: 027B2AFF 05040100
	s_waitcnt lgkmcnt(0)                                       // 00000004951C: BF89FC07
	s_barrier                                                  // 000000049520: BFBD0000
	ds_load_b128 v[46:49], v57 offset:14864                    // 000000049524: DBFC3A10 2E000039
	ds_load_b128 v[42:45], v57 offset:14848                    // 00000004952C: DBFC3A00 2A000039
	ds_load_b128 v[67:70], v57 offset:14896                    // 000000049534: DBFC3A30 43000039
	ds_load_b128 v[63:66], v57 offset:14880                    // 00000004953C: DBFC3A20 3F000039
	v_dual_mov_b32 v19, v18 :: v_dual_cndmask_b32 v62, 0x7060302, v20// 000000049544: CA120112 133E28FF 07060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049550: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000049554: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v26, v18, v19, v61                              // 000000049560: D644001A 04F62712
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000049568: BF8700B3
	v_perm_b32 v27, v18, v19, v62                              // 00000004956C: D644001B 04FA2712
	v_fma_mixlo_f16 v18, v137, s51, 0                          // 000000049574: CC210012 02006789
	v_fma_mixhi_f16 v18, v136, s51, 0                          // 00000004957C: CC220012 02006788
	v_mov_b32_e32 v19, v18                                     // 000000049584: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049588: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000004958C: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v28, v18, v19, v61                              // 000000049598: D644001C 04F62712
	v_perm_b32 v29, v18, v19, v62                              // 0000000495A0: D644001D 04FA2712
	v_fma_mixlo_f16 v18, v135, s51, 0                          // 0000000495A8: CC210012 02006787
	v_fma_mixhi_f16 v18, v134, s51, 0                          // 0000000495B0: CC220012 02006786
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000495B8: BF870091
	v_mov_b32_e32 v19, v18                                     // 0000000495BC: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 0000000495C0: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000495CC: BF8700C1
	v_perm_b32 v30, v18, v19, v61                              // 0000000495D0: D644001E 04F62712
	v_perm_b32 v31, v18, v19, v62                              // 0000000495D8: D644001F 04FA2712
	v_fma_mixlo_f16 v18, v133, s51, 0                          // 0000000495E0: CC210012 02006785
	v_fma_mixhi_f16 v18, v54, s51, 0                           // 0000000495E8: CC220012 02006736
	v_mov_b32_e32 v19, v18                                     // 0000000495F0: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000495F4: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 0000000495F8: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v32, v18, v19, v61                              // 000000049604: D6440020 04F62712
	v_perm_b32 v33, v18, v19, v62                              // 00000004960C: D6440021 04FA2712
	v_fma_mixlo_f16 v18, v132, s51, 0                          // 000000049614: CC210012 02006784
	v_fma_mixhi_f16 v18, v131, s51, 0                          // 00000004961C: CC220012 02006783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049624: BF870091
	v_mov_b32_e32 v19, v18                                     // 000000049628: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000004962C: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000049638: BF8700C1
	v_perm_b32 v34, v18, v19, v61                              // 00000004963C: D6440022 04F62712
	v_perm_b32 v35, v18, v19, v62                              // 000000049644: D6440023 04FA2712
	v_fma_mixlo_f16 v18, v130, s51, 0                          // 00000004964C: CC210012 02006782
	v_fma_mixhi_f16 v18, v129, s51, 0                          // 000000049654: CC220012 02006781
	v_mov_b32_e32 v19, v18                                     // 00000004965C: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049660: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000049664: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v36, v18, v19, v61                              // 000000049670: D6440024 04F62712
	v_perm_b32 v37, v18, v19, v62                              // 000000049678: D6440025 04FA2712
	v_fma_mixlo_f16 v18, v128, s51, 0                          // 000000049680: CC210012 02006780
	v_fma_mixhi_f16 v18, v127, s51, 0                          // 000000049688: CC220012 0200677F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049690: BF870091
	v_mov_b32_e32 v19, v18                                     // 000000049694: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000049698: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000496A4: BF8700C1
	v_perm_b32 v38, v18, v19, v61                              // 0000000496A8: D6440026 04F62712
	v_perm_b32 v39, v18, v19, v62                              // 0000000496B0: D6440027 04FA2712
	v_fma_mixlo_f16 v18, v126, s51, 0                          // 0000000496B8: CC210012 0200677E
	v_fma_mixhi_f16 v18, v53, s51, 0                           // 0000000496C0: CC220012 02006735
	v_mov_b32_e32 v19, v18                                     // 0000000496C8: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000496CC: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 0000000496D0: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v40, v18, v19, v61                              // 0000000496DC: D6440028 04F62712
	v_perm_b32 v41, v18, v19, v62                              // 0000000496E4: D6440029 04FA2712
	s_waitcnt lgkmcnt(2)                                       // 0000000496EC: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[26:33], v[2:9]// 0000000496F0: CC404012 1C0A352A
	s_waitcnt lgkmcnt(0)                                       // 0000000496F8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000496FC: BF870001
	v_wmma_f32_16x16x16_f16 v[18:25], v[63:70], v[34:41], v[18:25]// 000000049700: CC404012 1C4A453F
	ds_load_b128 v[63:66], v57 offset:10496                    // 000000049708: DBFC2900 3F000039
	ds_load_b128 v[67:70], v57 offset:10512                    // 000000049710: DBFC2910 43000039
	s_waitcnt lgkmcnt(0)                                       // 000000049718: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[63:70], v[26:33], v[2:9]// 00000004971C: CC40402A 1C0A353F
	ds_load_b128 v[26:29], v57 offset:10528                    // 000000049724: DBFC2920 1A000039
	ds_load_b128 v[30:33], v57 offset:10544                    // 00000004972C: DBFC2930 1E000039
	s_waitcnt lgkmcnt(0)                                       // 000000049734: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[26:33], v[34:41], v[42:49]// 000000049738: CC40402A 1CAA451A
	v_fma_mixlo_f16 v27, v125, s51, 0                          // 000000049740: CC21001B 0200677D
	v_fma_mixhi_f16 v27, v124, s51, 0                          // 000000049748: CC22001B 0200677C
	v_fma_mixlo_f16 v29, v123, s51, 0                          // 000000049750: CC21001D 0200677B
	v_fma_mixhi_f16 v29, v122, s51, 0                          // 000000049758: CC22001D 0200677A
	v_fma_mixlo_f16 v31, v121, s51, 0                          // 000000049760: CC21001F 02006779
	v_fma_mixhi_f16 v31, v120, s51, 0                          // 000000049768: CC22001F 02006778
	v_fma_mixlo_f16 v33, v119, s51, 0                          // 000000049770: CC210021 02006777
	v_fma_mixhi_f16 v33, v52, s51, 0                           // 000000049778: CC220021 02006734
	v_mov_b32_e32 v28, v27                                     // 000000049780: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000049784: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000049788: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004978C: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000049790: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000049794: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000497A0: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 0000000497A4: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 0000000497B0: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000497BC: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000497C0: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000497CC: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000497D4: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000497DC: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 0000000497E4: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 0000000497EC: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 0000000497F4: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 0000000497FC: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000049804: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14928                    // 00000004980C: DBFC3A50 26000039
	ds_load_b128 v[34:37], v57 offset:14912                    // 000000049814: DBFC3A40 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004981C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000049820: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10576                    // 000000049828: DBFC2950 26000039
	ds_load_b128 v[34:37], v57 offset:10560                    // 000000049830: DBFC2940 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000049838: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000004983C: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v118, s51, 0                          // 000000049844: CC21001B 02006776
	v_fma_mixhi_f16 v27, v117, s51, 0                          // 00000004984C: CC22001B 02006775
	v_fma_mixlo_f16 v29, v116, s51, 0                          // 000000049854: CC21001D 02006774
	v_fma_mixhi_f16 v29, v115, s51, 0                          // 00000004985C: CC22001D 02006773
	v_fma_mixlo_f16 v31, v114, s51, 0                          // 000000049864: CC21001F 02006772
	v_fma_mixhi_f16 v31, v113, s51, 0                          // 00000004986C: CC22001F 02006771
	v_fma_mixlo_f16 v33, v112, s51, 0                          // 000000049874: CC210021 02006770
	v_fma_mixhi_f16 v33, v51, s51, 0                           // 00000004987C: CC220021 02006733
	v_mov_b32_e32 v28, v27                                     // 000000049884: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000049888: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000004988C: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000049890: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000049894: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000049898: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000498A4: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 0000000498A8: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 0000000498B4: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000498C0: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000498C4: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000498D0: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000498D8: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000498E0: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 0000000498E8: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 0000000498F0: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 0000000498F8: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000049900: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000049908: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14960                    // 000000049910: DBFC3A70 26000039
	ds_load_b128 v[34:37], v57 offset:14944                    // 000000049918: DBFC3A60 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000049920: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000049924: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10608                    // 00000004992C: DBFC2970 26000039
	ds_load_b128 v[34:37], v57 offset:10592                    // 000000049934: DBFC2960 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004993C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000049940: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v111, s51, 0                          // 000000049948: CC21001B 0200676F
	v_fma_mixhi_f16 v27, v110, s51, 0                          // 000000049950: CC22001B 0200676E
	v_fma_mixlo_f16 v29, v109, s51, 0                          // 000000049958: CC21001D 0200676D
	v_fma_mixhi_f16 v29, v108, s51, 0                          // 000000049960: CC22001D 0200676C
	v_fma_mixlo_f16 v31, v107, s51, 0                          // 000000049968: CC21001F 0200676B
	v_fma_mixhi_f16 v31, v106, s51, 0                          // 000000049970: CC22001F 0200676A
	v_fma_mixlo_f16 v33, v105, s51, 0                          // 000000049978: CC210021 02006769
	v_fma_mixhi_f16 v33, v50, s51, 0                           // 000000049980: CC220021 02006732
	v_mov_b32_e32 v28, v27                                     // 000000049988: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000004998C: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000049990: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000049994: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000049998: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000004999C: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000499A8: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 0000000499AC: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 0000000499B8: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000499C4: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000499C8: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000499D4: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000499DC: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000499E4: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 0000000499EC: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 0000000499F4: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 0000000499FC: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000049A04: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000049A0C: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14992                    // 000000049A14: DBFC3A90 26000039
	ds_load_b128 v[34:37], v57 offset:14976                    // 000000049A1C: DBFC3A80 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000049A24: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000049A28: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10640                    // 000000049A30: DBFC2990 26000039
	ds_load_b128 v[34:37], v57 offset:10624                    // 000000049A38: DBFC2980 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000049A40: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000049A44: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v104, s51, 0                          // 000000049A4C: CC21001B 02006768
	v_fma_mixhi_f16 v27, v103, s51, 0                          // 000000049A54: CC22001B 02006767
	v_fma_mixlo_f16 v29, v102, s51, 0                          // 000000049A5C: CC21001D 02006766
	v_fma_mixhi_f16 v29, v101, s51, 0                          // 000000049A64: CC22001D 02006765
	v_fma_mixlo_f16 v31, v100, s51, 0                          // 000000049A6C: CC21001F 02006764
	v_fma_mixhi_f16 v31, v99, s51, 0                           // 000000049A74: CC22001F 02006763
	v_fma_mixlo_f16 v33, v98, s51, 0                           // 000000049A7C: CC210021 02006762
	v_fma_mixhi_f16 v33, v58, s51, 0                           // 000000049A84: CC220021 0200673A
	v_mov_b32_e32 v28, v27                                     // 000000049A8C: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000049A90: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000049A94: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000049A98: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000049A9C: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000049AA0: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000049AAC: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000049AB0: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000049ABC: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000049AC8: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000049ACC: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 000000049AD8: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 000000049AE0: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000049AE8: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000049AF0: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000049AF8: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000049B00: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000049B08: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000049B10: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15024                    // 000000049B18: DBFC3AB0 26000039
	ds_load_b128 v[34:37], v57 offset:15008                    // 000000049B20: DBFC3AA0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000049B28: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000049B2C: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10672                    // 000000049B34: DBFC29B0 26000039
	ds_load_b128 v[34:37], v57 offset:10656                    // 000000049B3C: DBFC29A0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000049B44: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000049B48: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v97, s51, 0                           // 000000049B50: CC21001B 02006761
	v_fma_mixhi_f16 v27, v96, s51, 0                           // 000000049B58: CC22001B 02006760
	v_fma_mixlo_f16 v29, v95, s51, 0                           // 000000049B60: CC21001D 0200675F
	v_fma_mixhi_f16 v29, v94, s51, 0                           // 000000049B68: CC22001D 0200675E
	v_fma_mixlo_f16 v31, v93, s51, 0                           // 000000049B70: CC21001F 0200675D
	v_fma_mixhi_f16 v31, v92, s51, 0                           // 000000049B78: CC22001F 0200675C
	v_fma_mixlo_f16 v33, v91, s51, 0                           // 000000049B80: CC210021 0200675B
	v_fma_mixhi_f16 v33, v152, s51, 0                          // 000000049B88: CC220021 02006798
	v_mov_b32_e32 v28, v27                                     // 000000049B90: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000049B94: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000049B98: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000049B9C: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000049BA0: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000049BA4: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000049BB0: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000049BB4: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000049BC0: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000049BCC: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000049BD0: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 000000049BDC: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 000000049BE4: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000049BEC: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000049BF4: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000049BFC: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000049C04: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000049C0C: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000049C14: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15056                    // 000000049C1C: DBFC3AD0 26000039
	ds_load_b128 v[34:37], v57 offset:15040                    // 000000049C24: DBFC3AC0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000049C2C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000049C30: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10704                    // 000000049C38: DBFC29D0 26000039
	ds_load_b128 v[34:37], v57 offset:10688                    // 000000049C40: DBFC29C0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000049C48: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000049C4C: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v90, s51, 0                           // 000000049C54: CC21001B 0200675A
	v_fma_mixhi_f16 v27, v141, s51, 0                          // 000000049C5C: CC22001B 0200678D
	v_fma_mixlo_f16 v29, v150, s51, 0                          // 000000049C64: CC21001D 02006796
	v_fma_mixhi_f16 v29, v142, s51, 0                          // 000000049C6C: CC22001D 0200678E
	v_fma_mixlo_f16 v31, v191, s51, 0                          // 000000049C74: CC21001F 020067BF
	v_fma_mixhi_f16 v31, v189, s51, 0                          // 000000049C7C: CC22001F 020067BD
	v_fma_mixlo_f16 v33, v190, s51, 0                          // 000000049C84: CC210021 020067BE
	v_fma_mixhi_f16 v33, v151, s51, 0                          // 000000049C8C: CC220021 02006797
	v_mov_b32_e32 v28, v27                                     // 000000049C94: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000049C98: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000049C9C: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000049CA0: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000049CA4: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000049CA8: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000049CB4: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000049CB8: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000049CC4: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000049CD0: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000049CD4: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 000000049CE0: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 000000049CE8: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000049CF0: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000049CF8: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000049D00: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000049D08: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000049D10: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000049D18: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15088                    // 000000049D20: DBFC3AF0 26000039
	ds_load_b128 v[34:37], v57 offset:15072                    // 000000049D28: DBFC3AE0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000049D30: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000049D34: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10736                    // 000000049D3C: DBFC29F0 26000039
	ds_load_b128 v[34:37], v57 offset:10720                    // 000000049D44: DBFC29E0 22000039
	v_dual_mul_f32 v18, 0x3b800000, v18 :: v_dual_mul_f32 v19, 0x3b800000, v19// 000000049D4C: C8C624FF 121226FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v20 :: v_dual_mul_f32 v21, 0x3b800000, v21// 000000049D58: C8C628FF 14142AFF 3B800000
	v_mul_f32_e32 v22, 0x3b800000, v22                         // 000000049D64: 102C2CFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000049D6C: BF870223
	v_sub_f32_e32 v10, v10, v18                                // 000000049D70: 0814250A
	v_or_b32_e32 v18, s54, v154                                // 000000049D74: 38253436
	v_dual_sub_f32 v11, v11, v19 :: v_dual_sub_f32 v12, v12, v20// 000000049D78: C94A270B 0B0C290C
	v_sub_f32_e32 v13, v13, v21                                // 000000049D80: 081A2B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000049D84: BF870214
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 000000049D88: CC21000A 0200610A
	v_or_b32_e32 v19, 2, v18                                   // 000000049D90: 38262482
	.long 0xd4440003                                           // 000000049D94: D4440003
	v_cndmask_b32_e32 v1, s39, v18, vcc_lo                     // 000000049D98: 02022427
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 000000049D9C: CC22000A 0200610B
	v_dual_mul_f32 v23, 0x3b800000, v23 :: v_dual_sub_f32 v14, v14, v22// 000000049DA4: C8CA2EFF 170E2D0E 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000049DB0: BF870214
	v_cmp_gt_i32_e32 vcc_lo, s39, v19                          // 000000049DB4: 7C882627
	v_cndmask_b16 v10, 0, v10, s3                              // 000000049DB8: D65D000A 000E1480
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000049DC0: BF8701D3
	v_dual_mul_f32 v24, 0x3b800000, v24 :: v_dual_sub_f32 v15, v15, v23// 000000049DC4: C8CA30FF 180E2F0F 3B800000
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 000000049DD0: 103232FF 3B800000
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000049DD8: D65D500A 01AA1480
	s_waitcnt lgkmcnt(0)                                       // 000000049DE0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000049DE4: CC40402A 1CAA3522
	v_dual_sub_f32 v16, v16, v24 :: v_dual_sub_f32 v17, v17, v25// 000000049DEC: C94A3110 10103311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000049DF4: BF8700C3
	v_mov_b32_e32 v11, v10                                     // 000000049DF8: 7E16030A
	ds_load_b128 v[19:22], v60 offset:23296                    // 000000049DFC: DBFC5B00 1300003C
	ds_load_b128 v[23:26], v60 offset:23312                    // 000000049E04: DBFC5B10 1700003C
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000049E0C: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v66, v10, v11, v61                              // 000000049E18: D6440042 04F6170A
	v_perm_b32 v67, v10, v11, v62                              // 000000049E20: D6440043 04FA170A
	v_or_b32_e32 v10, 4, v18                                   // 000000049E28: 38142484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000049E2C: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 000000049E30: 7C881427
	v_or_b32_e32 v10, 6, v18                                   // 000000049E34: 38142486
	.long 0xd4440004                                           // 000000049E38: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 000000049E3C: 02021427
	v_fma_mixlo_f16 v10, v12, s48, 0                           // 000000049E40: CC21000A 0200610C
	v_fma_mixhi_f16 v10, v13, s48, 0                           // 000000049E48: CC22000A 0200610D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000049E50: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000049E54: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s4                              // 000000049E5C: D65D500A 00121480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049E64: BF870091
	v_mov_b32_e32 v11, v10                                     // 000000049E68: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000049E6C: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000049E78: BF8700B1
	v_perm_b32 v68, v10, v11, v61                              // 000000049E7C: D6440044 04F6170A
	v_perm_b32 v69, v10, v11, v62                              // 000000049E84: D6440045 04FA170A
	v_or_b32_e32 v10, 8, v18                                   // 000000049E8C: 38142488
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 000000049E90: 7C881427
	v_or_b32_e32 v10, 10, v18                                  // 000000049E94: 3814248A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000049E98: BF870131
	.long 0xd4440004                                           // 000000049E9C: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 000000049EA0: 02021427
	v_fma_mixlo_f16 v10, v14, s48, 0                           // 000000049EA4: CC21000A 0200610E
	v_fma_mixhi_f16 v10, v15, s48, 0                           // 000000049EAC: CC22000A 0200610F
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000049EB4: D65D000A 01AA1480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049EBC: BF870092
	v_cndmask_b16 v10, 0, v10, s4                              // 000000049EC0: D65D500A 00121480
	v_mov_b32_e32 v11, v10                                     // 000000049EC8: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049ECC: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000049ED0: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v70, v10, v11, v61                              // 000000049EDC: D6440046 04F6170A
	v_perm_b32 v71, v10, v11, v62                              // 000000049EE4: D6440047 04FA170A
	v_or_b32_e32 v10, 12, v18                                  // 000000049EEC: 3814248C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000049EF0: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 000000049EF4: 7C881427
	v_or_b32_e32 v10, 14, v18                                  // 000000049EF8: 3814248E
	.long 0xd4440004                                           // 000000049EFC: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 000000049F00: 02021427
	v_fma_mixlo_f16 v10, v16, s48, 0                           // 000000049F04: CC21000A 02006110
	v_fma_mixhi_f16 v10, v17, s48, 0                           // 000000049F0C: CC22000A 02006111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000049F14: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000049F18: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s4                              // 000000049F20: D65D500A 00121480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049F28: BF870091
	v_mov_b32_e32 v11, v10                                     // 000000049F2C: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000049F30: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000049F3C: BF8700B1
	v_perm_b32 v72, v10, v11, v61                              // 000000049F40: D6440048 04F6170A
	v_perm_b32 v73, v10, v11, v62                              // 000000049F48: D6440049 04FA170A
	s_waitcnt lgkmcnt(0)                                       // 000000049F50: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[19:26], v[66:73], v[2:9]// 000000049F54: CC40400A 1C0A8513
	.long 0xd7000402                                           // 000000049F5C: D7000402
	v_cndmask_b32_e32 v1, s44, v59, vcc_lo                     // 000000049F60: 0202762C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049F64: BF870001
	v_add_co_ci_u32_e64 v3, null, s45, 0, s4                   // 000000049F68: D5207C03 0011002D
	s_and_saveexec_b32 s4, s3                                  // 000000049F70: BE842003
	s_cbranch_execz 19                                         // 000000049F74: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3cc4>
	ds_load_b32 v4, v56 offset:24320                           // 000000049F78: D8D85F00 04000038
	s_waitcnt lgkmcnt(0)                                       // 000000049F80: BF89FC07
	v_mul_f32_e32 v4, v42, v4                                  // 000000049F84: 1008092A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049F88: BF870091
	v_add_f32_e32 v4, v10, v4                                  // 000000049F8C: 0608090A
	v_mul_f32_e32 v6, 0x3b800000, v4                           // 000000049F90: 100C08FF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v18, v[2:3]            // 000000049F98: D6FE7C04 040A24FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049FA4: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000049FA8: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000049FB0: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000049FBC: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s4                              // 000000049FC4: 8C7E047E
	v_or3_b32 v4, v154, s54, 2                                 // 000000049FC8: D6580004 02086D9A
	s_mov_b32 s3, exec_lo                                      // 000000049FD0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049FD4: BF870001
	.long 0xd4c4007e                                           // 000000049FD8: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000049FDC: 02020827
	s_cbranch_execz 19                                         // 000000049FE0: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d30>
	ds_load_b32 v5, v56 offset:24328                           // 000000049FE4: D8D85F08 05000038
	s_waitcnt lgkmcnt(0)                                       // 000000049FEC: BF89FC07
	v_mul_f32_e32 v5, v43, v5                                  // 000000049FF0: 100A0B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049FF4: BF870091
	v_add_f32_e32 v5, v11, v5                                  // 000000049FF8: 060A0B0B
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000049FFC: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000004A004: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A010: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000004A014: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000004A01C: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000004A028: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004A030: 8C7E037E
	v_or3_b32 v4, v154, s54, 4                                 // 00000004A034: D6580004 02106D9A
	s_mov_b32 s3, exec_lo                                      // 00000004A03C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A040: BF870001
	.long 0xd4c4007e                                           // 00000004A044: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000004A048: 02020827
	s_cbranch_execz 19                                         // 00000004A04C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d9c>
	ds_load_b32 v5, v56 offset:24336                           // 00000004A050: D8D85F10 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000004A058: BF89FC07
	v_mul_f32_e32 v5, v44, v5                                  // 00000004A05C: 100A0B2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A060: BF870091
	v_add_f32_e32 v5, v12, v5                                  // 00000004A064: 060A0B0C
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000004A068: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000004A070: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A07C: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000004A080: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000004A088: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000004A094: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004A09C: 8C7E037E
	v_or3_b32 v4, v154, s54, 6                                 // 00000004A0A0: D6580004 02186D9A
	s_mov_b32 s3, exec_lo                                      // 00000004A0A8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A0AC: BF870001
	.long 0xd4c4007e                                           // 00000004A0B0: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000004A0B4: 02020827
	s_cbranch_execz 19                                         // 00000004A0B8: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3e08>
	ds_load_b32 v5, v56 offset:24344                           // 00000004A0BC: D8D85F18 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000004A0C4: BF89FC07
	v_mul_f32_e32 v5, v45, v5                                  // 00000004A0C8: 100A0B2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A0CC: BF870091
	v_add_f32_e32 v5, v13, v5                                  // 00000004A0D0: 060A0B0D
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000004A0D4: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000004A0DC: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A0E8: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000004A0EC: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000004A0F4: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000004A100: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004A108: 8C7E037E
	v_or3_b32 v4, v154, s54, 8                                 // 00000004A10C: D6580004 02206D9A
	s_mov_b32 s3, exec_lo                                      // 00000004A114: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A118: BF870001
	.long 0xd4c4007e                                           // 00000004A11C: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000004A120: 02020827
	s_cbranch_execz 19                                         // 00000004A124: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3e74>
	ds_load_b32 v5, v56 offset:24352                           // 00000004A128: D8D85F20 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000004A130: BF89FC07
	v_mul_f32_e32 v5, v46, v5                                  // 00000004A134: 100A0B2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A138: BF870091
	v_add_f32_e32 v5, v14, v5                                  // 00000004A13C: 060A0B0E
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000004A140: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000004A148: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A154: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000004A158: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000004A160: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000004A16C: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004A174: 8C7E037E
	v_or3_b32 v4, v154, s54, 10                                // 00000004A178: D6580004 02286D9A
	s_mov_b32 s3, exec_lo                                      // 00000004A180: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A184: BF870001
	.long 0xd4c4007e                                           // 00000004A188: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000004A18C: 02020827
	s_cbranch_execz 19                                         // 00000004A190: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3ee0>
	ds_load_b32 v5, v56 offset:24360                           // 00000004A194: D8D85F28 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000004A19C: BF89FC07
	v_mul_f32_e32 v5, v47, v5                                  // 00000004A1A0: 100A0B2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A1A4: BF870091
	v_add_f32_e32 v5, v15, v5                                  // 00000004A1A8: 060A0B0F
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000004A1AC: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000004A1B4: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A1C0: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000004A1C4: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000004A1CC: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000004A1D8: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004A1E0: 8C7E037E
	v_or3_b32 v4, v154, s54, 12                                // 00000004A1E4: D6580004 02306D9A
	s_mov_b32 s3, exec_lo                                      // 00000004A1EC: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A1F0: BF870001
	.long 0xd4c4007e                                           // 00000004A1F4: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000004A1F8: 02020827
	s_cbranch_execz 19                                         // 00000004A1FC: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3f4c>
	ds_load_b32 v5, v56 offset:24368                           // 00000004A200: D8D85F30 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000004A208: BF89FC07
	v_mul_f32_e32 v5, v48, v5                                  // 00000004A20C: 100A0B30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A210: BF870091
	v_add_f32_e32 v5, v16, v5                                  // 00000004A214: 060A0B10
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000004A218: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000004A220: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A22C: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000004A230: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000004A238: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000004A244: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004A24C: 8C7E037E
	v_or3_b32 v4, v154, s54, 14                                // 00000004A250: D6580004 02386D9A
	s_mov_b32 s3, exec_lo                                      // 00000004A258: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A25C: BF870001
	.long 0xd4c4007e                                           // 00000004A260: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000004A264: 02020827
	s_cbranch_execz 19                                         // 00000004A268: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3fb8>
	ds_load_b32 v5, v56 offset:24376                           // 00000004A26C: D8D85F38 05000038
	v_mad_u64_u32 v[2:3], null, 0x3000, v4, v[2:3]             // 00000004A274: D6FE7C02 040A08FF 00003000
	s_waitcnt lgkmcnt(0)                                       // 00000004A280: BF89FC07
	v_mul_f32_e32 v5, v49, v5                                  // 00000004A284: 100A0B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A288: BF870091
	v_add_f32_e32 v5, v17, v5                                  // 00000004A28C: 060A0B11
	v_mul_f32_e32 v5, 0x3b800000, v5                           // 00000004A290: 100A0AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A298: BF870091
	v_bfe_u32 v6, v5, 16, 1                                    // 00000004A29C: D6100006 02052105
	v_add3_u32 v4, v5, v6, 0x7fff                              // 00000004A2A4: D6550004 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000004A2B0: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004A2B8: 8C7E037E
	ds_load_b32 v56, v1 offset:24188                           // 00000004A2BC: D8D85E7C 38000001
	v_mad_u32_u24 v2, v55, 48, 0x4b00                          // 00000004A2C4: D60B0002 03FD6137 00004B00
	s_add_i32 s54, s54, 16                                     // 00000004A2D0: 81369036
	v_mov_b32_e32 v178, s27                                    // 00000004A2D4: 7F64021B
	v_dual_mov_b32 v176, s25 :: v_dual_mov_b32 v173, s22       // 00000004A2D8: CA100019 B0AC0016
	s_delay_alu instid0(VALU_DEP_3)                            // 00000004A2E0: BF870003
	v_dual_mov_b32 v174, s23 :: v_dual_add_nc_u32 v55, 0xffffb500, v2// 00000004A2E4: CA200017 AE3604FF FFFFB500
	v_dual_mov_b32 v171, s20 :: v_dual_mov_b32 v172, s21       // 00000004A2F0: CA100014 ABAC0015
	ds_load_b128 v[159:162], v55 offset:2320                   // 00000004A2F8: DBFC0910 9F000037
	ds_load_b128 v[155:158], v55 offset:2304                   // 00000004A300: DBFC0900 9B000037
	ds_load_b128 v[167:170], v55 offset:3088                   // 00000004A308: DBFC0C10 A7000037
	ds_load_b128 v[163:166], v55 offset:3072                   // 00000004A310: DBFC0C00 A3000037
	ds_load_b128 v[2:5], v55                                   // 00000004A318: DBFC0000 02000037
	ds_load_b128 v[6:9], v55 offset:16                         // 00000004A320: DBFC0010 06000037
	ds_load_b128 v[82:85], v55 offset:4608                     // 00000004A328: DBFC1200 52000037
	ds_load_b128 v[183:186], v55 offset:3856                   // 00000004A330: DBFC0F10 B7000037
	ds_load_b128 v[179:182], v55 offset:3840                   // 00000004A338: DBFC0F00 B3000037
	ds_load_b128 v[86:89], v55 offset:4624                     // 00000004A340: DBFC1210 56000037
	v_mov_b32_e32 v177, s26                                    // 00000004A348: 7F62021A
	v_mov_b32_e32 v175, s24                                    // 00000004A34C: 7F5E0218
	s_waitcnt lgkmcnt(10)                                      // 00000004A350: BF89FCA7
	v_readfirstlane_b32 s3, v56                                // 00000004A354: 7E060538
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v56                  // 00000004A358: 7C3670FF C2CE8ED0
	s_mul_f32 s3, s3, 0x3fb8aa3b                               // 00000004A360: A203FF03 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 00000004A368: BF87000B
	s_xor_b32 s4, s3, 0x80000000                               // 00000004A36C: 8D04FF03 80000000
	s_cmp_lg_u32 s12, s54                                      // 00000004A374: BF07360C
	v_fma_f32 v10, 0x3fb8aa3b, v56, s4                         // 00000004A378: D613000A 001270FF 3FB8AA3B
	s_rndne_f32 s4, s3                                         // 00000004A384: BE846303
	s_waitcnt lgkmcnt(4)                                       // 00000004A388: BF89FC47
	v_wmma_f32_16x16x16_f16 v[34:41], v[2:9], v[66:73], v[171:178]// 00000004A38C: CC404022 1EAE8502
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004A394: BF870002
	v_fmac_f32_e32 v10, 0x32a5705f, v56                        // 00000004A398: 561470FF 32A5705F
	s_sub_f32 s3, s3, s4                                       // 00000004A3A0: A0830403
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_3)    // 00000004A3A4: BF870581
	v_add_f32_e32 v18, s3, v10                                 // 00000004A3A8: 06241403
	s_cvt_i32_f32 s3, s4                                       // 00000004A3AC: BE836604
	ds_load_b128 v[14:17], v55 offset:784                      // 00000004A3B0: DBFC0310 0E000037
	ds_load_b128 v[10:13], v55 offset:768                      // 00000004A3B8: DBFC0300 0A000037
	ds_load_b128 v[46:49], v55 offset:1552                     // 00000004A3C0: DBFC0610 2E000037
	ds_load_b128 v[42:45], v55 offset:1536                     // 00000004A3C8: DBFC0600 2A000037
	v_exp_f32_e32 v18, v18                                     // 00000004A3D0: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A3D4: BF870095
	.long 0xd71c0012                                           // 00000004A3D8: D71C0012
	v_cndmask_b32_e32 v0, v18, v3, vcc_lo                      // 00000004A3DC: 02000712
	v_cndmask_b32_e32 v2, 0, v18, vcc_lo                       // 00000004A3E0: 02042480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v56                  // 00000004A3E4: 7C3C70FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A3EC: BF870092
	v_cndmask_b32_e32 v145, 0x7f800000, v2, vcc_lo             // 00000004A3F0: 032204FF 7F800000
	v_fmac_f32_e32 v41, v54, v145                              // 00000004A3F8: 56532336
	s_waitcnt lgkmcnt(2)                                       // 00000004A3FC: BF89FC27
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[66:73], v[171:178]// 00000004A400: CC40401A 1EAE850A
	v_wmma_f32_16x16x16_f16 v[10:17], v[155:162], v[66:73], v[171:178]// 00000004A408: CC40400A 1EAE859B
	ds_load_b128 v[159:162], v55 offset:5392                   // 00000004A410: DBFC1510 9F000037
	ds_load_b128 v[155:158], v55 offset:5376                   // 00000004A418: DBFC1500 9B000037
	s_waitcnt lgkmcnt(2)                                       // 00000004A420: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[66:73], v[171:178]// 00000004A424: CC404012 1EAE852A
	v_wmma_f32_16x16x16_f16 v[2:9], v[163:170], v[66:73], v[171:178]// 00000004A42C: CC404002 1EAE85A3
	v_wmma_f32_16x16x16_f16 v[42:49], v[179:186], v[66:73], v[171:178]// 00000004A434: CC40402A 1EAE85B3
	v_fma_f32 v138, v138, v145, v35                            // 00000004A43C: D613008A 048F238A
	v_fma_f32 v136, v136, v145, v37                            // 00000004A444: D6130088 04972388
	v_fma_f32 v135, v135, v145, v38                            // 00000004A44C: D6130087 049B2387
	v_fma_f32 v131, v131, v145, v27                            // 00000004A454: D6130083 046F2383
	v_fmac_f32_e32 v33, v53, v145                              // 00000004A45C: 56432335
	v_fmac_f32_e32 v25, v52, v145                              // 00000004A460: 56332334
	v_fmac_f32_e32 v17, v51, v145                              // 00000004A464: 56232333
	v_fmac_f32_e32 v9, v50, v145                               // 00000004A468: 56132332
	v_wmma_f32_16x16x16_f16 v[50:57], v[82:89], v[66:73], v[171:178]// 00000004A46C: CC404032 1EAE8552
	v_fmac_f32_e32 v49, v58, v145                              // 00000004A474: 5663233A
	v_fma_f32 v139, v139, v145, v34                            // 00000004A478: D613008B 048B238B
	v_fma_f32 v137, v137, v145, v36                            // 00000004A480: D6130089 04932389
	s_waitcnt lgkmcnt(0)                                       // 00000004A488: BF89FC07
	v_wmma_f32_16x16x16_f16 v[58:65], v[155:162], v[66:73], v[171:178]// 00000004A48C: CC40403A 1EAE859B
	v_fma_f32 v134, v134, v145, v39                            // 00000004A494: D6130086 049F2386
	v_fma_f32 v133, v133, v145, v40                            // 00000004A49C: D6130085 04A32385
	v_fma_f32 v132, v132, v145, v26                            // 00000004A4A4: D6130084 046B2384
	v_fma_f32 v130, v130, v145, v28                            // 00000004A4AC: D6130082 04732382
	v_fma_f32 v129, v129, v145, v29                            // 00000004A4B4: D6130081 04772381
	v_fma_f32 v128, v128, v145, v30                            // 00000004A4BC: D6130080 047B2380
	v_fma_f32 v127, v127, v145, v31                            // 00000004A4C4: D613007F 047F237F
	v_fma_f32 v126, v126, v145, v32                            // 00000004A4CC: D613007E 0483237E
	v_fma_f32 v125, v125, v145, v18                            // 00000004A4D4: D613007D 044B237D
	v_fma_f32 v124, v124, v145, v19                            // 00000004A4DC: D613007C 044F237C
	v_fma_f32 v123, v123, v145, v20                            // 00000004A4E4: D613007B 0453237B
	v_fma_f32 v122, v122, v145, v21                            // 00000004A4EC: D613007A 0457237A
	v_fma_f32 v121, v121, v145, v22                            // 00000004A4F4: D6130079 045B2379
	v_fma_f32 v120, v120, v145, v23                            // 00000004A4FC: D6130078 045F2378
	v_fma_f32 v119, v119, v145, v24                            // 00000004A504: D6130077 04632377
	v_fma_f32 v118, v118, v145, v10                            // 00000004A50C: D6130076 042B2376
	v_fma_f32 v117, v117, v145, v11                            // 00000004A514: D6130075 042F2375
	v_fma_f32 v116, v116, v145, v12                            // 00000004A51C: D6130074 04332374
	v_fma_f32 v115, v115, v145, v13                            // 00000004A524: D6130073 04372373
	v_fma_f32 v114, v114, v145, v14                            // 00000004A52C: D6130072 043B2372
	v_fma_f32 v113, v113, v145, v15                            // 00000004A534: D6130071 043F2371
	v_fma_f32 v112, v112, v145, v16                            // 00000004A53C: D6130070 04432370
	v_fma_f32 v111, v111, v145, v2                             // 00000004A544: D613006F 040B236F
	v_fma_f32 v110, v110, v145, v3                             // 00000004A54C: D613006E 040F236E
	v_fma_f32 v109, v109, v145, v4                             // 00000004A554: D613006D 0413236D
	v_fma_f32 v108, v108, v145, v5                             // 00000004A55C: D613006C 0417236C
	v_fma_f32 v107, v107, v145, v6                             // 00000004A564: D613006B 041B236B
	v_fma_f32 v106, v106, v145, v7                             // 00000004A56C: D613006A 041F236A
	v_fma_f32 v105, v105, v145, v8                             // 00000004A574: D6130069 04232369
	v_fma_f32 v104, v104, v145, v42                            // 00000004A57C: D6130068 04AB2368
	v_fma_f32 v103, v103, v145, v43                            // 00000004A584: D6130067 04AF2367
	v_fma_f32 v102, v102, v145, v44                            // 00000004A58C: D6130066 04B32366
	v_fma_f32 v101, v101, v145, v45                            // 00000004A594: D6130065 04B72365
	v_fma_f32 v100, v100, v145, v46                            // 00000004A59C: D6130064 04BB2364
	v_fma_f32 v99, v99, v145, v47                              // 00000004A5A4: D6130063 04BF2363
	v_fma_f32 v98, v98, v145, v48                              // 00000004A5AC: D6130062 04C32362
	v_fma_f32 v97, v97, v145, v50                              // 00000004A5B4: D6130061 04CB2361
	v_fma_f32 v96, v96, v145, v51                              // 00000004A5BC: D6130060 04CF2360
	v_fma_f32 v95, v95, v145, v52                              // 00000004A5C4: D613005F 04D3235F
	v_fma_f32 v94, v94, v145, v53                              // 00000004A5CC: D613005E 04D7235E
	v_fma_f32 v93, v93, v145, v54                              // 00000004A5D4: D613005D 04DB235D
	v_fma_f32 v92, v92, v145, v55                              // 00000004A5DC: D613005C 04DF235C
	v_fma_f32 v91, v91, v145, v56                              // 00000004A5E4: D613005B 04E3235B
	v_fmac_f32_e32 v57, v152, v145                             // 00000004A5EC: 56732398
	v_fma_f32 v90, v90, v145, v58                              // 00000004A5F0: D613005A 04EB235A
	v_fma_f32 v141, v141, v145, v59                            // 00000004A5F8: D613008D 04EF238D
	v_fma_f32 v150, v150, v145, v60                            // 00000004A600: D6130096 04F32396
	v_fma_f32 v142, v142, v145, v61                            // 00000004A608: D613008E 04F7238E
	v_fma_f32 v191, v191, v145, v62                            // 00000004A610: D61300BF 04FB23BF
	v_fma_f32 v189, v189, v145, v63                            // 00000004A618: D61300BD 04FF23BD
	v_fma_f32 v190, v190, v145, v64                            // 00000004A620: D61300BE 050323BE
	v_dual_fmac_f32 v65, v151, v145 :: v_dual_mul_f32 v6, 0x3b800000, v128// 00000004A628: C8072397 410700FF 3B800000
	v_lshl_add_u32 v2, v154, 7, v153                           // 00000004A634: D6460002 06650F9A
	v_dual_mul_f32 v69, 0x3b800000, v139 :: v_dual_mul_f32 v152, 0x3b800000, v41// 00000004A63C: C8C716FF 459852FF 3B800000
	v_dual_mul_f32 v70, 0x3b800000, v138 :: v_dual_mul_f32 v71, 0x3b800000, v137// 00000004A648: C8C714FF 464712FF 3B800000
	v_mul_f32_e32 v64, 0x3b800000, v127                        // 00000004A654: 1080FEFF 3B800000
	v_mul_f32_e32 v72, 0x3b800000, v136                        // 00000004A65C: 109110FF 3B800000
	v_dual_mul_f32 v4, 0x3b800000, v135 :: v_dual_mul_f32 v73, 0x3b800000, v134// 00000004A664: C8C70EFF 04490CFF 3B800000
	v_dual_mul_f32 v60, 0x3b800000, v123 :: v_dual_mul_f32 v151, 0x3b800000, v133// 00000004A670: C8C6F6FF 3C970AFF 3B800000
	v_dual_mul_f32 v66, 0x3b800000, v126 :: v_dual_mul_f32 v5, 0x3b800000, v132// 00000004A67C: C8C6FCFF 420508FF 3B800000
	v_mul_f32_e32 v8, 0x3b800000, v121                         // 00000004A688: 1010F2FF 3B800000
	v_mul_f32_e32 v68, 0x3b800000, v131                        // 00000004A690: 108906FF 3B800000
	v_dual_mul_f32 v62, 0x3b800000, v130 :: v_dual_mul_f32 v63, 0x3b800000, v129// 00000004A698: C8C704FF 3E3F02FF 3B800000
	v_dual_mul_f32 v52, 0x3b800000, v120 :: v_dual_mul_f32 v67, 0x3b800000, v33// 00000004A6A4: C8C6F0FF 344242FF 3B800000
	v_dual_mul_f32 v10, 0x3b800000, v118 :: v_dual_mul_f32 v7, 0x3b800000, v125// 00000004A6B0: C8C6ECFF 0A06FAFF 3B800000
	v_mul_f32_e32 v56, 0x3b800000, v116                        // 00000004A6BC: 1070E8FF 3B800000
	v_dual_mul_f32 v59, 0x3b800000, v124 :: v_dual_mul_f32 v54, 0x3b800000, v25// 00000004A6C4: C8C6F8FF 3B3632FF 3B800000
	v_dual_mul_f32 v61, 0x3b800000, v122 :: v_dual_mul_f32 v58, 0x3b800000, v115// 00000004A6D0: C8C6F4FF 3D3AE6FF 3B800000
	v_dual_mul_f32 v53, 0x3b800000, v119 :: v_dual_mul_f32 v50, 0x3b800000, v113// 00000004A6DC: C8C6EEFF 3532E2FF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v117 :: v_dual_mul_f32 v12, 0x3b800000, v111// 00000004A6E8: C8C6EAFF 370CDEFF 3B800000
	v_dual_mul_f32 v11, 0x3b800000, v114 :: v_dual_mul_f32 v40, 0x3b800000, v17// 00000004A6F4: C8C6E4FF 0B2822FF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v112 :: v_dual_mul_f32 v44, 0x3b800000, v109// 00000004A700: C8C6E0FF 332CDAFF 3B800000
	v_dual_mul_f32 v43, 0x3b800000, v110 :: v_dual_mul_f32 v14, 0x3b800000, v107// 00000004A70C: C8C6DCFF 2B0ED6FF 3B800000
	v_dual_mul_f32 v45, 0x3b800000, v108 :: v_dual_mul_f32 v46, 0x3b800000, v106// 00000004A718: C8C6D8FF 2D2ED4FF 3B800000
	v_dual_mul_f32 v47, 0x3b800000, v105 :: v_dual_mul_f32 v42, 0x3b800000, v103// 00000004A724: C8C6D2FF 2F2ACEFF 3B800000
	v_dual_mul_f32 v48, 0x3b800000, v9 :: v_dual_mul_f32 v15, 0x3b800000, v104// 00000004A730: C8C612FF 300ED0FF 3B800000
	v_dual_mul_f32 v35, 0x3b800000, v102 :: v_dual_mul_f32 v36, 0x3b800000, v101// 00000004A73C: C8C6CCFF 2324CAFF 3B800000
	v_dual_mul_f32 v27, 0x3b800000, v100 :: v_dual_mul_f32 v38, 0x3b800000, v98// 00000004A748: C8C6C8FF 1B26C4FF 3B800000
	v_dual_mul_f32 v37, 0x3b800000, v99 :: v_dual_mul_f32 v28, 0x3b800000, v97// 00000004A754: C8C6C6FF 251CC2FF 3B800000
	v_dual_mul_f32 v39, 0x3b800000, v49 :: v_dual_mul_f32 v32, 0x3b800000, v95// 00000004A760: C8C662FF 2720BEFF 3B800000
	v_dual_mul_f32 v31, 0x3b800000, v96 :: v_dual_mul_f32 v34, 0x3b800000, v94// 00000004A76C: C8C6C0FF 1F22BCFF 3B800000
	v_dual_mul_f32 v29, 0x3b800000, v93 :: v_dual_mul_f32 v20, 0x3b800000, v92// 00000004A778: C8C6BAFF 1D14B8FF 3B800000
	v_dual_mul_f32 v21, 0x3b800000, v91 :: v_dual_mul_f32 v22, 0x3b800000, v57// 00000004A784: C8C6B6FF 151672FF 3B800000
	v_dual_mul_f32 v30, 0x3b800000, v90 :: v_dual_mul_f32 v23, 0x3b800000, v141// 00000004A790: C8C6B4FF 1E171AFF 3B800000
	v_dual_mul_f32 v24, 0x3b800000, v150 :: v_dual_mul_f32 v13, 0x3b800000, v65// 00000004A79C: C8C72CFF 180C82FF 3B800000
	v_mul_f32_e32 v26, 0x3b800000, v142                        // 00000004A7A8: 10351CFF 3B800000
	v_dual_mul_f32 v16, 0x3b800000, v191 :: v_dual_mul_f32 v19, 0x3b800000, v190// 00000004A7B0: C8C77EFF 10137CFF 3B800000
	v_mul_f32_e32 v18, 0x3b800000, v189                        // 00000004A7BC: 10257AFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 00000004A7C4: BF89FC07
	s_barrier                                                  // 00000004A7C8: BFBD0000
	s_cbranch_scc0 5                                           // 00000004A7CC: BFA10005 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44e4>
	s_cmp_lg_u32 s13, s54                                      // 00000004A7D0: BF07360D
	s_cbranch_scc0 273                                         // 00000004A7D4: BFA10111 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x491c>
	s_cmp_lg_u32 s14, s54                                      // 00000004A7D8: BF07360E
	s_cbranch_scc1 61707                                       // 00000004A7DC: BFA2F10B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	s_branch 540                                               // 00000004A7E0: BFA0021C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4d54>
	v_mov_b32_e32 v82, v2                                      // 00000004A7E4: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A7E8: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 00000004A7EC: 34A6A49F
	.long 0xd73c0052                                           // 00000004A7F0: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 00000004A7F4: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A7F8: BF870091
	.long 0xd7006a52                                           // 00000004A7FC: D7006A52
	v_cndmask_b32_e32 v1, s16, v82, vcc_lo                     // 00000004A800: 0202A410
	v_add_co_ci_u32_e64 v83, null, s17, v83, vcc_lo            // 00000004A804: D5207C53 01AAA611
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A80C: BF870092
	.long 0xd7006a54                                           // 00000004A810: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 00000004A814: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004A81C: D5207C55 01AAA680
	.long 0xd7006a56                                           // 00000004A824: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004A828: 0201FF52
	.long 0x00002000                                           // 00000004A82C: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004A830: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 00000004A834: D5207C57 01AAA680
	.long 0xd7006a58                                           // 00000004A83C: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 00000004A840: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000004A848: D5207C59 01AAA680
	s_clause 0x7                                               // 00000004A850: BF850007
	global_store_b32 v[82:83], v69, off                        // 00000004A854: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 00000004A85C: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 00000004A864: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 00000004A86C: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 00000004A874: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 00000004A87C: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 00000004A884: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 00000004A88C: DC6A0400 007C4458
	.long 0xd7006a54                                           // 00000004A894: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 00000004A898: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004A8A0: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004A8A4: D5207C55 01AAA680
	.long 0xd7006a99                                           // 00000004A8AC: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004A8B0: 0201FF52
	.long 0x00004000                                           // 00000004A8B4: 00004000
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 00000004A8B8: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 00000004A8C0: D7006A9B
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 00000004A8C4: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A8CC: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000004A8D0: D5207C9C 01AAA680
	s_clause 0x7                                               // 00000004A8D8: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 00000004A8DC: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 00000004A8E4: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 00000004A8EC: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 00000004A8F4: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 00000004A8FC: DC6A0C00 007C4354
	global_store_b32 v[155:156], v59, off offset:1024          // 00000004A904: DC6A0400 007C3B9B
	global_store_b32 v[155:156], v60, off offset:2048          // 00000004A90C: DC6A0800 007C3C9B
	global_store_b32 v[155:156], v61, off offset:3072          // 00000004A914: DC6A0C00 007C3D9B
	.long 0xd7006a54                                           // 00000004A91C: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 00000004A920: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004A928: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004A92C: D5207C55 01AAA680
	.long 0xd7006a58                                           // 00000004A934: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004A938: 0201FF52
	.long 0x00006000                                           // 00000004A93C: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000004A940: D5207C59 01AAA680
	.long 0xd7006a9b                                           // 00000004A948: D7006A9B
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 00000004A94C: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004A954: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000004A958: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000004A960: D7006A9D
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 00000004A964: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000004A96C: D5207C9E 01AAA680
	.long 0xd7006a9f                                           // 00000004A974: D7006A9F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004A978: 0201FF52
	.long 0x00008000                                           // 00000004A97C: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A980: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v83, vcc_lo             // 00000004A984: D5207CA0 01AAA680
	s_clause 0x7                                               // 00000004A98C: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 00000004A990: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 00000004A998: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 00000004A9A0: DC6A0C00 007C3654
	global_store_b32 v[155:156], v55, off offset:1024          // 00000004A9A8: DC6A0400 007C379B
	global_store_b32 v[155:156], v56, off offset:2048          // 00000004A9B0: DC6A0800 007C389B
	global_store_b32 v[155:156], v58, off offset:3072          // 00000004A9B8: DC6A0C00 007C3A9B
	global_store_b32 v[157:158], v50, off offset:1024          // 00000004A9C0: DC6A0400 007C329D
	global_store_b32 v[157:158], v51, off offset:2048          // 00000004A9C8: DC6A0800 007C339D
	.long 0xd7006a54                                           // 00000004A9D0: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 00000004A9D4: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004A9DC: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004A9E0: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000004A9E8: D7006A9B
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 00000004A9EC: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000004A9F4: D5207C9C 01AAA680
	.long 0xd7006aa1                                           // 00000004A9FC: D7006AA1
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004AA00: 0201FF52
	.long 0x0000a000                                           // 00000004AA04: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004AA08: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v83, vcc_lo             // 00000004AA0C: D5207CA2 01AAA680
	.long 0xd7006aa3                                           // 00000004AA14: D7006AA3
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 00000004AA18: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000004AA20: D5207CA4 01AAA680
	s_clause 0x7                                               // 00000004AA28: BF850007
	global_store_b32 v[157:158], v40, off offset:3072          // 00000004AA2C: DC6A0C00 007C289D
	global_store_b32 v[84:85], v43, off offset:1024            // 00000004AA34: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 00000004AA3C: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 00000004AA44: DC6A0C00 007C2D54
	global_store_b32 v[155:156], v46, off offset:1024          // 00000004AA4C: DC6A0400 007C2E9B
	global_store_b32 v[155:156], v47, off offset:2048          // 00000004AA54: DC6A0800 007C2F9B
	global_store_b32 v[155:156], v48, off offset:3072          // 00000004AA5C: DC6A0C00 007C309B
	global_store_b32 v[163:164], v42, off offset:1024          // 00000004AA64: DC6A0400 007C2AA3
	.long 0xd7006a54                                           // 00000004AA6C: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 00000004AA70: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004AA78: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004AA7C: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000004AA84: D7006A9B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004AA88: 0201FF52
	.long 0x0000c000                                           // 00000004AA8C: 0000C000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000004AA90: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000004AA98: D7006A9D
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 00000004AA9C: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004AAA4: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000004AAA8: D5207C9E 01AAA680
	s_clause 0x7                                               // 00000004AAB0: BF850007
	global_store_b32 v[163:164], v35, off offset:2048          // 00000004AAB4: DC6A0800 007C23A3
	global_store_b32 v[163:164], v36, off offset:3072          // 00000004AABC: DC6A0C00 007C24A3
	global_store_b32 v[84:85], v37, off offset:1024            // 00000004AAC4: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 00000004AACC: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 00000004AAD4: DC6A0C00 007C2754
	global_store_b32 v[157:158], v31, off offset:1024          // 00000004AADC: DC6A0400 007C1F9D
	global_store_b32 v[157:158], v32, off offset:2048          // 00000004AAE4: DC6A0800 007C209D
	global_store_b32 v[157:158], v34, off offset:3072          // 00000004AAEC: DC6A0C00 007C229D
	.long 0xd7006a54                                           // 00000004AAF4: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 00000004AAF8: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004AB00: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004AB04: D5207C55 01AAA680
	.long 0xd7006a9d                                           // 00000004AB0C: D7006A9D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004AB10: 0201FF52
	.long 0x0000e000                                           // 00000004AB14: 0000E000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000004AB18: D5207C9E 01AAA680
	.long 0xd7006aa3                                           // 00000004AB20: D7006AA3
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 00000004AB24: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004AB2C: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000004AB30: D5207CA4 01AAA680
	.long 0xd7006a52                                           // 00000004AB38: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 00000004AB3C: 0202A4FF 0000F000
	s_clause 0x7                                               // 00000004AB44: BF850007
	global_store_b32 v[159:160], v11, off offset:-4096         // 00000004AB48: DC6A1000 007C0B9F
	global_store_b32 v[159:160], v12, off                      // 00000004AB50: DC6A0000 007C0C9F
	global_store_b32 v[161:162], v14, off offset:-4096         // 00000004AB58: DC6A1000 007C0EA1
	global_store_b32 v[161:162], v15, off                      // 00000004AB60: DC6A0000 007C0FA1
	global_store_b32 v[155:156], v27, off offset:-4096         // 00000004AB68: DC6A1000 007C1B9B
	global_store_b32 v[155:156], v28, off                      // 00000004AB70: DC6A0000 007C1C9B
	global_store_b32 v[157:158], v29, off offset:-4096         // 00000004AB78: DC6A1000 007C1D9D
	global_store_b32 v[157:158], v30, off                      // 00000004AB80: DC6A0000 007C1E9D
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 00000004AB88: D5207C53 01AAA680
	s_clause 0xf                                               // 00000004AB90: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 00000004AB94: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 00000004AB9C: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 00000004ABA4: DC6A0C00 007C1654
	global_store_b32 v[163:164], v23, off offset:1024          // 00000004ABAC: DC6A0400 007C17A3
	global_store_b32 v[163:164], v24, off offset:2048          // 00000004ABB4: DC6A0800 007C18A3
	global_store_b32 v[163:164], v26, off offset:3072          // 00000004ABBC: DC6A0C00 007C1AA3
	global_store_b32 v[82:83], v16, off                        // 00000004ABC4: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 00000004ABCC: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 00000004ABD4: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 00000004ABDC: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 00000004ABE4: DC6A0000 007C0556
	global_store_b32 v[153:154], v6, off offset:-4096          // 00000004ABEC: DC6A1000 007C0699
	global_store_b32 v[153:154], v7, off                       // 00000004ABF4: DC6A0000 007C0799
	global_store_b32 v[88:89], v8, off offset:-4096            // 00000004ABFC: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 00000004AC04: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 00000004AC0C: DC6A0C00 007C0D52
	s_cmp_lg_u32 s13, s54                                      // 00000004AC14: BF07360D
	s_cbranch_scc1 65263                                       // 00000004AC18: BFA2FEEF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44d8>
	v_mov_b32_e32 v82, v2                                      // 00000004AC1C: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004AC20: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 00000004AC24: 34A6A49F
	.long 0xd73c0052                                           // 00000004AC28: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 00000004AC2C: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004AC30: BF870091
	.long 0xd7006a52                                           // 00000004AC34: D7006A52
	v_cndmask_b32_e32 v1, s18, v82, vcc_lo                     // 00000004AC38: 0202A412
	v_add_co_ci_u32_e64 v83, null, s19, v83, vcc_lo            // 00000004AC3C: D5207C53 01AAA613
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004AC44: BF870092
	.long 0xd7006a54                                           // 00000004AC48: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 00000004AC4C: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004AC54: D5207C55 01AAA680
	.long 0xd7006a56                                           // 00000004AC5C: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004AC60: 0201FF52
	.long 0x00002000                                           // 00000004AC64: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004AC68: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 00000004AC6C: D5207C57 01AAA680
	.long 0xd7006a58                                           // 00000004AC74: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 00000004AC78: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000004AC80: D5207C59 01AAA680
	s_clause 0x7                                               // 00000004AC88: BF850007
	global_store_b32 v[82:83], v69, off                        // 00000004AC8C: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 00000004AC94: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 00000004AC9C: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 00000004ACA4: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 00000004ACAC: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 00000004ACB4: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 00000004ACBC: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 00000004ACC4: DC6A0400 007C4458
	.long 0xd7006a54                                           // 00000004ACCC: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 00000004ACD0: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004ACD8: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004ACDC: D5207C55 01AAA680
	.long 0xd7006a99                                           // 00000004ACE4: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004ACE8: 0201FF52
	.long 0x00004000                                           // 00000004ACEC: 00004000
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 00000004ACF0: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 00000004ACF8: D7006A9B
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 00000004ACFC: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004AD04: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000004AD08: D5207C9C 01AAA680
	s_clause 0x7                                               // 00000004AD10: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 00000004AD14: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 00000004AD1C: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 00000004AD24: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 00000004AD2C: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 00000004AD34: DC6A0C00 007C4354
	global_store_b32 v[155:156], v59, off offset:1024          // 00000004AD3C: DC6A0400 007C3B9B
	global_store_b32 v[155:156], v60, off offset:2048          // 00000004AD44: DC6A0800 007C3C9B
	global_store_b32 v[155:156], v61, off offset:3072          // 00000004AD4C: DC6A0C00 007C3D9B
	.long 0xd7006a54                                           // 00000004AD54: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 00000004AD58: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004AD60: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004AD64: D5207C55 01AAA680
	.long 0xd7006a58                                           // 00000004AD6C: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004AD70: 0201FF52
	.long 0x00006000                                           // 00000004AD74: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000004AD78: D5207C59 01AAA680
	.long 0xd7006a9b                                           // 00000004AD80: D7006A9B
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 00000004AD84: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004AD8C: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000004AD90: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000004AD98: D7006A9D
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 00000004AD9C: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000004ADA4: D5207C9E 01AAA680
	.long 0xd7006a9f                                           // 00000004ADAC: D7006A9F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004ADB0: 0201FF52
	.long 0x00008000                                           // 00000004ADB4: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004ADB8: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v83, vcc_lo             // 00000004ADBC: D5207CA0 01AAA680
	s_clause 0x7                                               // 00000004ADC4: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 00000004ADC8: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 00000004ADD0: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 00000004ADD8: DC6A0C00 007C3654
	global_store_b32 v[155:156], v55, off offset:1024          // 00000004ADE0: DC6A0400 007C379B
	global_store_b32 v[155:156], v56, off offset:2048          // 00000004ADE8: DC6A0800 007C389B
	global_store_b32 v[155:156], v58, off offset:3072          // 00000004ADF0: DC6A0C00 007C3A9B
	global_store_b32 v[157:158], v50, off offset:1024          // 00000004ADF8: DC6A0400 007C329D
	global_store_b32 v[157:158], v51, off offset:2048          // 00000004AE00: DC6A0800 007C339D
	.long 0xd7006a54                                           // 00000004AE08: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 00000004AE0C: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004AE14: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004AE18: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000004AE20: D7006A9B
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 00000004AE24: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000004AE2C: D5207C9C 01AAA680
	.long 0xd7006aa1                                           // 00000004AE34: D7006AA1
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004AE38: 0201FF52
	.long 0x0000a000                                           // 00000004AE3C: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004AE40: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v83, vcc_lo             // 00000004AE44: D5207CA2 01AAA680
	.long 0xd7006aa3                                           // 00000004AE4C: D7006AA3
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 00000004AE50: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000004AE58: D5207CA4 01AAA680
	s_clause 0x7                                               // 00000004AE60: BF850007
	global_store_b32 v[157:158], v40, off offset:3072          // 00000004AE64: DC6A0C00 007C289D
	global_store_b32 v[84:85], v43, off offset:1024            // 00000004AE6C: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 00000004AE74: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 00000004AE7C: DC6A0C00 007C2D54
	global_store_b32 v[155:156], v46, off offset:1024          // 00000004AE84: DC6A0400 007C2E9B
	global_store_b32 v[155:156], v47, off offset:2048          // 00000004AE8C: DC6A0800 007C2F9B
	global_store_b32 v[155:156], v48, off offset:3072          // 00000004AE94: DC6A0C00 007C309B
	global_store_b32 v[163:164], v42, off offset:1024          // 00000004AE9C: DC6A0400 007C2AA3
	.long 0xd7006a54                                           // 00000004AEA4: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 00000004AEA8: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004AEB0: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004AEB4: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000004AEBC: D7006A9B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004AEC0: 0201FF52
	.long 0x0000c000                                           // 00000004AEC4: 0000C000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000004AEC8: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000004AED0: D7006A9D
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 00000004AED4: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004AEDC: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000004AEE0: D5207C9E 01AAA680
	s_clause 0x7                                               // 00000004AEE8: BF850007
	global_store_b32 v[163:164], v35, off offset:2048          // 00000004AEEC: DC6A0800 007C23A3
	global_store_b32 v[163:164], v36, off offset:3072          // 00000004AEF4: DC6A0C00 007C24A3
	global_store_b32 v[84:85], v37, off offset:1024            // 00000004AEFC: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 00000004AF04: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 00000004AF0C: DC6A0C00 007C2754
	global_store_b32 v[157:158], v31, off offset:1024          // 00000004AF14: DC6A0400 007C1F9D
	global_store_b32 v[157:158], v32, off offset:2048          // 00000004AF1C: DC6A0800 007C209D
	global_store_b32 v[157:158], v34, off offset:3072          // 00000004AF24: DC6A0C00 007C229D
	.long 0xd7006a54                                           // 00000004AF2C: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 00000004AF30: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004AF38: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004AF3C: D5207C55 01AAA680
	.long 0xd7006a9d                                           // 00000004AF44: D7006A9D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004AF48: 0201FF52
	.long 0x0000e000                                           // 00000004AF4C: 0000E000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000004AF50: D5207C9E 01AAA680
	.long 0xd7006aa3                                           // 00000004AF58: D7006AA3
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 00000004AF5C: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004AF64: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000004AF68: D5207CA4 01AAA680
	.long 0xd7006a52                                           // 00000004AF70: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 00000004AF74: 0202A4FF 0000F000
	s_clause 0x7                                               // 00000004AF7C: BF850007
	global_store_b32 v[159:160], v11, off offset:-4096         // 00000004AF80: DC6A1000 007C0B9F
	global_store_b32 v[159:160], v12, off                      // 00000004AF88: DC6A0000 007C0C9F
	global_store_b32 v[161:162], v14, off offset:-4096         // 00000004AF90: DC6A1000 007C0EA1
	global_store_b32 v[161:162], v15, off                      // 00000004AF98: DC6A0000 007C0FA1
	global_store_b32 v[155:156], v27, off offset:-4096         // 00000004AFA0: DC6A1000 007C1B9B
	global_store_b32 v[155:156], v28, off                      // 00000004AFA8: DC6A0000 007C1C9B
	global_store_b32 v[157:158], v29, off offset:-4096         // 00000004AFB0: DC6A1000 007C1D9D
	global_store_b32 v[157:158], v30, off                      // 00000004AFB8: DC6A0000 007C1E9D
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 00000004AFC0: D5207C53 01AAA680
	s_clause 0xf                                               // 00000004AFC8: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 00000004AFCC: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 00000004AFD4: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 00000004AFDC: DC6A0C00 007C1654
	global_store_b32 v[163:164], v23, off offset:1024          // 00000004AFE4: DC6A0400 007C17A3
	global_store_b32 v[163:164], v24, off offset:2048          // 00000004AFEC: DC6A0800 007C18A3
	global_store_b32 v[163:164], v26, off offset:3072          // 00000004AFF4: DC6A0C00 007C1AA3
	global_store_b32 v[82:83], v16, off                        // 00000004AFFC: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 00000004B004: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 00000004B00C: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 00000004B014: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 00000004B01C: DC6A0000 007C0556
	global_store_b32 v[153:154], v6, off offset:-4096          // 00000004B024: DC6A1000 007C0699
	global_store_b32 v[153:154], v7, off                       // 00000004B02C: DC6A0000 007C0799
	global_store_b32 v[88:89], v8, off offset:-4096            // 00000004B034: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 00000004B03C: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 00000004B044: DC6A0C00 007C0D52
	s_cmp_lg_u32 s14, s54                                      // 00000004B04C: BF07360E
	s_cbranch_scc1 61166                                       // 00000004B050: BFA2EEEE <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000004B054: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004B058: BF870091
	.long 0xd73c0002                                           // 00000004B05C: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000004B060: 02020482
	.long 0xd7006a02                                           // 00000004B064: D7006A02
	v_cndmask_b32_e32 v1, s47, v2, vcc_lo                      // 00000004B068: 0202042F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004B06C: BF870111
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 00000004B070: D5207C03 01AA0607
	.long 0xd7006a52                                           // 00000004B078: D7006A52
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000004B07C: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004B084: BF8700A1
	v_add_co_ci_u32_e64 v83, null, 0, v3, vcc_lo               // 00000004B088: D5207C53 01AA0680
	.long 0xd7006a54                                           // 00000004B090: D7006A54
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000004B094: 0201FF02
	.long 0x00002000                                           // 00000004B098: 00002000
	v_add_co_ci_u32_e64 v85, null, 0, v3, vcc_lo               // 00000004B09C: D5207C55 01AA0680
	.long 0xd7006a56                                           // 00000004B0A4: D7006A56
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 00000004B0A8: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004B0B0: BF870001
	v_add_co_ci_u32_e64 v87, null, 0, v3, vcc_lo               // 00000004B0B4: D5207C57 01AA0680
	s_clause 0x7                                               // 00000004B0BC: BF850007
	global_store_b32 v[2:3], v69, off                          // 00000004B0C0: DC6A0000 007C4502
	global_store_b32 v[2:3], v70, off offset:1024              // 00000004B0C8: DC6A0400 007C4602
	global_store_b32 v[2:3], v71, off offset:2048              // 00000004B0D0: DC6A0800 007C4702
	global_store_b32 v[2:3], v72, off offset:3072              // 00000004B0D8: DC6A0C00 007C4802
	global_store_b32 v[82:83], v73, off offset:1024            // 00000004B0E0: DC6A0400 007C4952
	global_store_b32 v[82:83], v151, off offset:2048           // 00000004B0E8: DC6A0800 007C9752
	global_store_b32 v[82:83], v152, off offset:3072           // 00000004B0F0: DC6A0C00 007C9852
	global_store_b32 v[86:87], v68, off offset:1024            // 00000004B0F8: DC6A0400 007C4456
	.long 0xd7006a44                                           // 00000004B100: D7006A44
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 00000004B104: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004B10C: BF8700A1
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 00000004B110: D5207C45 01AA0680
	.long 0xd7006a46                                           // 00000004B118: D7006A46
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000004B11C: 0201FF02
	.long 0x00004000                                           // 00000004B120: 00004000
	v_add_co_ci_u32_e64 v71, null, 0, v3, vcc_lo               // 00000004B124: D5207C47 01AA0680
	.long 0xd7006a48                                           // 00000004B12C: D7006A48
	v_cndmask_b32_e32 v1, 0x4000, v2, vcc_lo                   // 00000004B130: 020204FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004B138: BF870001
	v_add_co_ci_u32_e64 v73, null, 0, v3, vcc_lo               // 00000004B13C: D5207C49 01AA0680
	s_clause 0x7                                               // 00000004B144: BF850007
	global_store_b32 v[86:87], v62, off offset:2048            // 00000004B148: DC6A0800 007C3E56
	global_store_b32 v[86:87], v63, off offset:3072            // 00000004B150: DC6A0C00 007C3F56
	global_store_b32 v[68:69], v64, off offset:1024            // 00000004B158: DC6A0400 007C4044
	global_store_b32 v[68:69], v66, off offset:2048            // 00000004B160: DC6A0800 007C4244
	global_store_b32 v[68:69], v67, off offset:3072            // 00000004B168: DC6A0C00 007C4344
	global_store_b32 v[72:73], v59, off offset:1024            // 00000004B170: DC6A0400 007C3B48
	global_store_b32 v[72:73], v60, off offset:2048            // 00000004B178: DC6A0800 007C3C48
	global_store_b32 v[72:73], v61, off offset:3072            // 00000004B180: DC6A0C00 007C3D48
	.long 0xd7006a3b                                           // 00000004B188: D7006A3B
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 00000004B18C: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004B194: BF8700A1
	v_add_co_ci_u32_e64 v60, null, 0, v3, vcc_lo               // 00000004B198: D5207C3C 01AA0680
	.long 0xd7006a3d                                           // 00000004B1A0: D7006A3D
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000004B1A4: 0201FF02
	.long 0x00006000                                           // 00000004B1A8: 00006000
	v_add_co_ci_u32_e64 v62, null, 0, v3, vcc_lo               // 00000004B1AC: D5207C3E 01AA0680
	.long 0xd7006a3f                                           // 00000004B1B4: D7006A3F
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 00000004B1B8: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004B1C0: BF8700A1
	v_add_co_ci_u32_e64 v64, null, 0, v3, vcc_lo               // 00000004B1C4: D5207C40 01AA0680
	.long 0xd7006a42                                           // 00000004B1CC: D7006A42
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 00000004B1D0: 020204FF 00007000
	v_add_co_ci_u32_e64 v67, null, 0, v3, vcc_lo               // 00000004B1D8: D5207C43 01AA0680
	.long 0xd7006a44                                           // 00000004B1E0: D7006A44
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000004B1E4: 0201FF02
	.long 0x00008000                                           // 00000004B1E8: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004B1EC: BF870001
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 00000004B1F0: D5207C45 01AA0680
	s_clause 0x7                                               // 00000004B1F8: BF850007
	global_store_b32 v[59:60], v52, off offset:1024            // 00000004B1FC: DC6A0400 007C343B
	global_store_b32 v[59:60], v53, off offset:2048            // 00000004B204: DC6A0800 007C353B
	global_store_b32 v[59:60], v54, off offset:3072            // 00000004B20C: DC6A0C00 007C363B
	global_store_b32 v[63:64], v55, off offset:1024            // 00000004B214: DC6A0400 007C373F
	global_store_b32 v[63:64], v56, off offset:2048            // 00000004B21C: DC6A0800 007C383F
	global_store_b32 v[63:64], v58, off offset:3072            // 00000004B224: DC6A0C00 007C3A3F
	global_store_b32 v[66:67], v50, off offset:1024            // 00000004B22C: DC6A0400 007C3242
	global_store_b32 v[66:67], v51, off offset:2048            // 00000004B234: DC6A0800 007C3342
	.long 0xd7006a32                                           // 00000004B23C: D7006A32
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 00000004B240: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004B248: BF8700A1
	v_add_co_ci_u32_e64 v51, null, 0, v3, vcc_lo               // 00000004B24C: D5207C33 01AA0680
	.long 0xd7006a34                                           // 00000004B254: D7006A34
	v_cndmask_b32_e32 v1, 0x9000, v2, vcc_lo                   // 00000004B258: 020204FF 00009000
	v_add_co_ci_u32_e64 v53, null, 0, v3, vcc_lo               // 00000004B260: D5207C35 01AA0680
	.long 0xd7006a36                                           // 00000004B268: D7006A36
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000004B26C: 0201FF02
	.long 0x0000a000                                           // 00000004B270: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004B274: BF8700A1
	v_add_co_ci_u32_e64 v55, null, 0, v3, vcc_lo               // 00000004B278: D5207C37 01AA0680
	.long 0xd7006a3a                                           // 00000004B280: D7006A3A
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 00000004B284: 020204FF 0000A000
	v_add_co_ci_u32_e64 v59, null, 0, v3, vcc_lo               // 00000004B28C: D5207C3B 01AA0680
	s_clause 0x7                                               // 00000004B294: BF850007
	global_store_b32 v[66:67], v40, off offset:3072            // 00000004B298: DC6A0C00 007C2842
	global_store_b32 v[50:51], v43, off offset:1024            // 00000004B2A0: DC6A0400 007C2B32
	global_store_b32 v[50:51], v44, off offset:2048            // 00000004B2A8: DC6A0800 007C2C32
	global_store_b32 v[50:51], v45, off offset:3072            // 00000004B2B0: DC6A0C00 007C2D32
	global_store_b32 v[52:53], v46, off offset:1024            // 00000004B2B8: DC6A0400 007C2E34
	global_store_b32 v[52:53], v47, off offset:2048            // 00000004B2C0: DC6A0800 007C2F34
	global_store_b32 v[52:53], v48, off offset:3072            // 00000004B2C8: DC6A0C00 007C3034
	global_store_b32 v[58:59], v42, off offset:1024            // 00000004B2D0: DC6A0400 007C2A3A
	.long 0xd7006a2a                                           // 00000004B2D8: D7006A2A
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 00000004B2DC: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004B2E4: BF8700A1
	v_add_co_ci_u32_e64 v43, null, 0, v3, vcc_lo               // 00000004B2E8: D5207C2B 01AA0680
	.long 0xd7006a2c                                           // 00000004B2F0: D7006A2C
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000004B2F4: 0201FF02
	.long 0x0000c000                                           // 00000004B2F8: 0000C000
	v_add_co_ci_u32_e64 v45, null, 0, v3, vcc_lo               // 00000004B2FC: D5207C2D 01AA0680
	.long 0xd7006a2e                                           // 00000004B304: D7006A2E
	v_cndmask_b32_e32 v1, 0xc000, v2, vcc_lo                   // 00000004B308: 020204FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004B310: BF870001
	v_add_co_ci_u32_e64 v47, null, 0, v3, vcc_lo               // 00000004B314: D5207C2F 01AA0680
	s_clause 0x7                                               // 00000004B31C: BF850007
	global_store_b32 v[58:59], v35, off offset:2048            // 00000004B320: DC6A0800 007C233A
	global_store_b32 v[58:59], v36, off offset:3072            // 00000004B328: DC6A0C00 007C243A
	global_store_b32 v[42:43], v37, off offset:1024            // 00000004B330: DC6A0400 007C252A
	global_store_b32 v[42:43], v38, off offset:2048            // 00000004B338: DC6A0800 007C262A
	global_store_b32 v[42:43], v39, off offset:3072            // 00000004B340: DC6A0C00 007C272A
	global_store_b32 v[46:47], v31, off offset:1024            // 00000004B348: DC6A0400 007C1F2E
	global_store_b32 v[46:47], v32, off offset:2048            // 00000004B350: DC6A0800 007C202E
	global_store_b32 v[46:47], v34, off offset:3072            // 00000004B358: DC6A0C00 007C222E
	.long 0xd7006a1f                                           // 00000004B360: D7006A1F
	v_cndmask_b32_e32 v1, 0xd000, v2, vcc_lo                   // 00000004B364: 020204FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004B36C: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v3, vcc_lo               // 00000004B370: D5207C20 01AA0680
	.long 0xd7006a22                                           // 00000004B378: D7006A22
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000004B37C: 0201FF02
	.long 0x0000e000                                           // 00000004B380: 0000E000
	v_add_co_ci_u32_e64 v35, null, 0, v3, vcc_lo               // 00000004B384: D5207C23 01AA0680
	.long 0xd7006a24                                           // 00000004B38C: D7006A24
	v_cndmask_b32_e32 v1, 0xe000, v2, vcc_lo                   // 00000004B390: 020204FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004B398: BF870001
	v_add_co_ci_u32_e64 v37, null, 0, v3, vcc_lo               // 00000004B39C: D5207C25 01AA0680
	.long 0xd7006a02                                           // 00000004B3A4: D7006A02
	v_cndmask_b32_e32 v1, 0xf000, v2, vcc_lo                   // 00000004B3A8: 020204FF 0000F000
	s_clause 0x7                                               // 00000004B3B0: BF850007
	global_store_b32 v[68:69], v11, off offset:-4096           // 00000004B3B4: DC6A1000 007C0B44
	global_store_b32 v[68:69], v12, off                        // 00000004B3BC: DC6A0000 007C0C44
	global_store_b32 v[54:55], v14, off offset:-4096           // 00000004B3C4: DC6A1000 007C0E36
	global_store_b32 v[54:55], v15, off                        // 00000004B3CC: DC6A0000 007C0F36
	global_store_b32 v[44:45], v27, off offset:-4096           // 00000004B3D4: DC6A1000 007C1B2C
	global_store_b32 v[44:45], v28, off                        // 00000004B3DC: DC6A0000 007C1C2C
	global_store_b32 v[34:35], v29, off offset:-4096           // 00000004B3E4: DC6A1000 007C1D22
	global_store_b32 v[34:35], v30, off                        // 00000004B3EC: DC6A0000 007C1E22
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000004B3F4: D5207C03 01AA0680
	s_clause 0xf                                               // 00000004B3FC: BF85000F
	global_store_b32 v[31:32], v20, off offset:1024            // 00000004B400: DC6A0400 007C141F
	global_store_b32 v[31:32], v21, off offset:2048            // 00000004B408: DC6A0800 007C151F
	global_store_b32 v[31:32], v22, off offset:3072            // 00000004B410: DC6A0C00 007C161F
	global_store_b32 v[36:37], v23, off offset:1024            // 00000004B418: DC6A0400 007C1724
	global_store_b32 v[36:37], v24, off offset:2048            // 00000004B420: DC6A0800 007C1824
	global_store_b32 v[36:37], v26, off offset:3072            // 00000004B428: DC6A0C00 007C1A24
	global_store_b32 v[2:3], v16, off                          // 00000004B430: DC6A0000 007C1002
	global_store_b32 v[2:3], v18, off offset:1024              // 00000004B438: DC6A0400 007C1202
	global_store_b32 v[2:3], v19, off offset:2048              // 00000004B440: DC6A0800 007C1302
	global_store_b32 v[84:85], v4, off offset:-4096            // 00000004B448: DC6A1000 007C0454
	global_store_b32 v[84:85], v5, off                         // 00000004B450: DC6A0000 007C0554
	global_store_b32 v[70:71], v6, off offset:-4096            // 00000004B458: DC6A1000 007C0646
	global_store_b32 v[70:71], v7, off                         // 00000004B460: DC6A0000 007C0746
	global_store_b32 v[61:62], v8, off offset:-4096            // 00000004B468: DC6A1000 007C083D
	global_store_b32 v[61:62], v10, off                        // 00000004B470: DC6A0000 007C0A3D
	global_store_b32 v[2:3], v13, off offset:3072              // 00000004B478: DC6A0C00 007C0D02
	s_branch 60898                                             // 00000004B480: BFA0EDE2 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	v_mov_b32_e32 v54, v41                                     // 00000004B484: 7E6C0329
	v_mov_b32_e32 v53, v33                                     // 00000004B488: 7E6A0321
	v_mov_b32_e32 v52, v25                                     // 00000004B48C: 7E680319
	v_mov_b32_e32 v51, v17                                     // 00000004B490: 7E660311
	v_mov_b32_e32 v50, v9                                      // 00000004B494: 7E640309
	v_mov_b32_e32 v58, v49                                     // 00000004B498: 7E740331
	v_mov_b32_e32 v152, v57                                    // 00000004B49C: 7F300339
	v_mov_b32_e32 v151, v65                                    // 00000004B4A0: 7F2E0341
	s_mov_b32 s7, 0                                            // 00000004B4A4: BE870080
	s_branch 1                                                 // 00000004B4A8: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x51b0>
	s_mov_b64 s[6:7], 0                                        // 00000004B4AC: BE860180
	v_dual_mul_f32 v3, 0x3b800000, v139 :: v_dual_mul_f32 v4, 0x3b800000, v138// 00000004B4B0: C8C716FF 030514FF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v137 :: v_dual_mul_f32 v6, 0x3b800000, v136// 00000004B4BC: C8C712FF 050710FF 3B800000
	.long 0xd7006a01                                           // 00000004B4C8: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004B4CC: 0201FFBB
	.long 0x00002000                                           // 00000004B4D0: 00002000
	v_dual_mul_f32 v7, 0x3b800000, v135 :: v_dual_mul_f32 v8, 0x3b800000, v134// 00000004B4D4: C8C70EFF 07090CFF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 00000004B4E0: D5207C02 01AB7880
	v_dual_mul_f32 v9, 0x3b800000, v133 :: v_dual_mul_f32 v10, 0x3b800000, v54// 00000004B4E8: C8C70AFF 090A6CFF 3B800000
	s_clause 0x7                                               // 00000004B4F4: BF850007
	global_store_b32 v[187:188], v3, off                       // 00000004B4F8: DC6A0000 007C03BB
	global_store_b32 v[187:188], v4, off offset:1024           // 00000004B500: DC6A0400 007C04BB
	global_store_b32 v[187:188], v5, off offset:2048           // 00000004B508: DC6A0800 007C05BB
	global_store_b32 v[187:188], v6, off offset:3072           // 00000004B510: DC6A0C00 007C06BB
	global_store_b32 v[1:2], v7, off offset:-4096              // 00000004B518: DC6A1000 007C0701
	global_store_b32 v[1:2], v8, off offset:-3072              // 00000004B520: DC6A1400 007C0801
	global_store_b32 v[1:2], v9, off offset:-2048              // 00000004B528: DC6A1800 007C0901
	global_store_b32 v[1:2], v10, off offset:-1024             // 00000004B530: DC6A1C00 007C0A01
	v_dual_mul_f32 v5, 0x3b800000, v132 :: v_dual_mul_f32 v6, 0x3b800000, v131// 00000004B538: C8C708FF 050706FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v130 :: v_dual_mul_f32 v8, 0x3b800000, v129// 00000004B544: C8C704FF 070902FF 3B800000
	.long 0xd7006a03                                           // 00000004B550: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004B554: 0201FFBB
	.long 0x00004000                                           // 00000004B558: 00004000
	v_dual_mul_f32 v9, 0x3b800000, v128 :: v_dual_mul_f32 v10, 0x3b800000, v127// 00000004B55C: C8C700FF 090AFEFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 00000004B568: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v126 :: v_dual_mul_f32 v12, 0x3b800000, v53// 00000004B570: C8C6FCFF 0B0C6AFF 3B800000
	s_clause 0x7                                               // 00000004B57C: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000004B580: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 00000004B588: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 00000004B590: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 00000004B598: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 00000004B5A0: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 00000004B5A8: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 00000004B5B0: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 00000004B5B8: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v125 :: v_dual_mul_f32 v6, 0x3b800000, v124// 00000004B5C0: C8C6FAFF 0506F8FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v123 :: v_dual_mul_f32 v8, 0x3b800000, v122// 00000004B5CC: C8C6F6FF 0708F4FF 3B800000
	.long 0xd7006a01                                           // 00000004B5D8: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004B5DC: 0201FFBB
	.long 0x00006000                                           // 00000004B5E0: 00006000
	v_dual_mul_f32 v9, 0x3b800000, v121 :: v_dual_mul_f32 v10, 0x3b800000, v120// 00000004B5E4: C8C6F2FF 090AF0FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 00000004B5F0: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v119 :: v_dual_mul_f32 v12, 0x3b800000, v52// 00000004B5F8: C8C6EEFF 0B0C68FF 3B800000
	s_clause 0x7                                               // 00000004B604: BF850007
	global_store_b32 v[3:4], v5, off                           // 00000004B608: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 00000004B610: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 00000004B618: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 00000004B620: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 00000004B628: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 00000004B630: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 00000004B638: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 00000004B640: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v118 :: v_dual_mul_f32 v6, 0x3b800000, v117// 00000004B648: C8C6ECFF 0506EAFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v116 :: v_dual_mul_f32 v8, 0x3b800000, v115// 00000004B654: C8C6E8FF 0708E6FF 3B800000
	.long 0xd7006a03                                           // 00000004B660: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004B664: 0201FFBB
	.long 0x00008000                                           // 00000004B668: 00008000
	v_dual_mul_f32 v9, 0x3b800000, v114 :: v_dual_mul_f32 v10, 0x3b800000, v113// 00000004B66C: C8C6E4FF 090AE2FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 00000004B678: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v112 :: v_dual_mul_f32 v12, 0x3b800000, v51// 00000004B680: C8C6E0FF 0B0C66FF 3B800000
	s_clause 0x7                                               // 00000004B68C: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000004B690: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 00000004B698: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 00000004B6A0: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 00000004B6A8: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 00000004B6B0: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 00000004B6B8: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 00000004B6C0: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 00000004B6C8: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v111 :: v_dual_mul_f32 v6, 0x3b800000, v110// 00000004B6D0: C8C6DEFF 0506DCFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v109 :: v_dual_mul_f32 v8, 0x3b800000, v108// 00000004B6DC: C8C6DAFF 0708D8FF 3B800000
	.long 0xd7006a01                                           // 00000004B6E8: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004B6EC: 0201FFBB
	.long 0x0000a000                                           // 00000004B6F0: 0000A000
	v_dual_mul_f32 v9, 0x3b800000, v107 :: v_dual_mul_f32 v10, 0x3b800000, v106// 00000004B6F4: C8C6D6FF 090AD4FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 00000004B700: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v105 :: v_dual_mul_f32 v12, 0x3b800000, v50// 00000004B708: C8C6D2FF 0B0C64FF 3B800000
	s_clause 0x7                                               // 00000004B714: BF850007
	global_store_b32 v[3:4], v5, off                           // 00000004B718: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 00000004B720: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 00000004B728: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 00000004B730: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 00000004B738: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 00000004B740: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 00000004B748: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 00000004B750: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v104 :: v_dual_mul_f32 v6, 0x3b800000, v103// 00000004B758: C8C6D0FF 0506CEFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v102 :: v_dual_mul_f32 v8, 0x3b800000, v101// 00000004B764: C8C6CCFF 0708CAFF 3B800000
	.long 0xd7006a03                                           // 00000004B770: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004B774: 0201FFBB
	.long 0x0000c000                                           // 00000004B778: 0000C000
	v_dual_mul_f32 v9, 0x3b800000, v100 :: v_dual_mul_f32 v10, 0x3b800000, v99// 00000004B77C: C8C6C8FF 090AC6FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 00000004B788: D5207C04 01AB7880
	v_mul_f32_e32 v11, 0x3b800000, v98                         // 00000004B790: 1016C4FF 3B800000
	v_mul_f32_e32 v12, 0x3b800000, v58                         // 00000004B798: 101874FF 3B800000
	s_clause 0x7                                               // 00000004B7A0: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000004B7A4: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 00000004B7AC: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 00000004B7B4: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 00000004B7BC: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 00000004B7C4: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 00000004B7CC: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 00000004B7D4: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 00000004B7DC: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v97 :: v_dual_mul_f32 v6, 0x3b800000, v96// 00000004B7E4: C8C6C2FF 0506C0FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v95 :: v_dual_mul_f32 v8, 0x3b800000, v94// 00000004B7F0: C8C6BEFF 0708BCFF 3B800000
	.long 0xd7006a01                                           // 00000004B7FC: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004B800: 0201FFBB
	.long 0x0000e000                                           // 00000004B804: 0000E000
	v_dual_mul_f32 v9, 0x3b800000, v93 :: v_dual_mul_f32 v10, 0x3b800000, v92// 00000004B808: C8C6BAFF 090AB8FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 00000004B814: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v91 :: v_dual_mul_f32 v12, 0x3b800000, v152// 00000004B81C: C8C6B6FF 0B0D30FF 3B800000
	s_clause 0x7                                               // 00000004B828: BF850007
	global_store_b32 v[3:4], v5, off                           // 00000004B82C: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 00000004B834: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 00000004B83C: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 00000004B844: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 00000004B84C: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 00000004B854: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 00000004B85C: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 00000004B864: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v90 :: v_dual_mul_f32 v6, 0x3b800000, v141// 00000004B86C: C8C6B4FF 05071AFF 3B800000
	v_and_or_b32 v0, v0, 31, s5                                // 00000004B878: D6570000 00153F00
	v_dual_mul_f32 v7, 0x3b800000, v150 :: v_dual_mul_f32 v10, 0x3b800000, v189// 00000004B880: C8C72CFF 070B7AFF 3B800000
	.long 0xd7006a03                                           // 00000004B88C: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004B890: 0201FFBB
	.long 0x0000fc00                                           // 00000004B894: 0000FC00
	v_dual_mul_f32 v8, 0x3b800000, v142 :: v_dual_mul_f32 v9, 0x3b800000, v191// 00000004B898: C8C71CFF 08097EFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 00000004B8A4: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v190 :: v_dual_mul_f32 v12, 0x3b800000, v151// 00000004B8AC: C8C77CFF 0B0D2EFF 3B800000
	s_clause 0x7                                               // 00000004B8B8: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000004B8BC: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 00000004B8C4: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 00000004B8CC: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 00000004B8D4: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-3072              // 00000004B8DC: DC6A1400 007C0903
	global_store_b32 v[3:4], v10, off offset:-2048             // 00000004B8E4: DC6A1800 007C0A03
	global_store_b32 v[3:4], v11, off offset:-1024             // 00000004B8EC: DC6A1C00 007C0B03
	global_store_b32 v[3:4], v12, off                          // 00000004B8F4: DC6A0000 007C0C03
	s_mov_b32 s2, exec_lo                                      // 00000004B8FC: BE82007E
	v_cmpx_eq_u32_e32 0, v0                                    // 00000004B900: 7D940080
	s_cbranch_execz 8                                          // 00000004B904: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi7ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5628>
	s_load_b64 s[0:1], s[0:1], 0x40                            // 00000004B908: F4040000 F8000040
	v_mov_b32_e32 v0, s6                                       // 00000004B910: 7E000206
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, s7              // 00000004B914: CA100080 02000007
	s_waitcnt lgkmcnt(0)                                       // 00000004B91C: BF89FC07
	global_store_b64 v2, v[0:1], s[0:1] offset:48              // 00000004B920: DC6E0030 00000002
	s_endpgm                                                   // 00000004B928: BFB00000
		...

