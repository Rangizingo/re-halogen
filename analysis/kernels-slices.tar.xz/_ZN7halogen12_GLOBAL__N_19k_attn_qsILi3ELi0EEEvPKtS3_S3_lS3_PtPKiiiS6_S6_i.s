0000000000179600 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i():
	s_load_b256 s[4:11], s[0:1], 0x18                          // 000000179600: F40C0100 F8000018
	s_mov_b32 s16, s3                                          // 000000179608: BE900003
	s_ashr_i32 s3, s2, 31                                      // 00000017960C: 86039F02
	s_mov_b32 s17, exec_lo                                     // 000000179610: BE91007E
	s_lshl_b64 s[18:19], s[2:3], 2                             // 000000179614: 84928202
	s_waitcnt lgkmcnt(0)                                       // 000000179618: BF89FC07
	s_load_b32 s10, s[10:11], null                             // 00000017961C: F4000285 F8000000
	s_load_b128 s[12:15], s[0:1], 0x40                         // 000000179624: F4080300 F8000040
	s_waitcnt lgkmcnt(0)                                       // 00000017962C: BF89FC07
	s_add_i32 s10, s10, s2                                     // 000000179630: 810A020A
	s_add_u32 s14, s14, s18                                    // 000000179634: 800E120E
	s_addc_u32 s15, s15, s19                                   // 000000179638: 820F130F
	s_add_i32 s11, s10, 1                                      // 00000017963C: 810B810A
	s_load_b32 s3, s[14:15], null                              // 000000179640: F40000C7 F8000000
	s_ashr_i32 s14, s11, 31                                    // 000000179648: 860E9F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000017964C: BF870499
	s_lshr_b32 s14, s14, 30                                    // 000000179650: 850E9E0E
	s_add_i32 s15, s11, s14                                    // 000000179654: 810F0E0B
	s_waitcnt lgkmcnt(0)                                       // 000000179658: BF89FC07
	s_lshl_b32 s14, s3, 2                                      // 00000017965C: 840E8203
	s_and_b32 s3, s15, -4                                      // 000000179660: 8B03C40F
	s_add_i32 s11, s11, s14                                    // 000000179664: 810B0E0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000179668: BF870499
	s_sub_i32 s11, s11, s3                                     // 00000017966C: 818B030B
	s_add_i32 s15, s11, 16                                     // 000000179670: 810F900B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000179674: BF870009
	.long 0xd4c4007e                                           // 000000179678: D4C4007E
	v_cndmask_b32_e32 v1, s15, v0, vcc_lo                      // 00000017967C: 0202000F
	s_cbranch_execz 64                                         // 000000179680: BFA50040 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x184>
	s_load_b32 s19, s[0:1], 0x50                               // 000000179684: F40004C0 F8000050
	v_and_b32_e32 v1, 0x7c, v0                                 // 00000017968C: 360200FF 0000007C
	s_sub_i32 s18, s3, s14                                     // 000000179694: 81920E03
	v_and_b32_e32 v3, 3, v0                                    // 000000179698: 36060083
	v_dual_mov_b32 v5, v0 :: v_dual_lshlrev_b32 v4, 2, v0      // 00000017969C: CA220100 05040082
	s_waitcnt lgkmcnt(0)                                       // 0000001796A4: BF89FC07
	s_mul_hi_i32 s21, s2, s19                                  // 0000001796A8: 97151302
	s_mul_i32 s20, s2, s19                                     // 0000001796AC: 96141302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001796B0: BF870499
	s_lshl_b64 s[20:21], s[20:21], 2                           // 0000001796B4: 84948214
	s_add_u32 s3, s12, s20                                     // 0000001796B8: 8003140C
	s_addc_u32 s12, s13, s21                                   // 0000001796BC: 820C150D
	.long 0xd7000301                                           // 0000001796C0: D7000301
	v_cndmask_b32_e32 v1, s3, v1, vcc_lo                       // 0000001796C4: 02020203
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001796C8: BF870001
	v_add_co_ci_u32_e64 v2, null, s12, 0, s3                   // 0000001796CC: D5207C02 000D000C
	s_mov_b32 s12, 0                                           // 0000001796D4: BE8C0080
	s_set_inst_prefetch_distance 0x1                           // 0000001796D8: BF840001
	s_branch 25                                                // 0000001796DC: BFA00019 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x144>
	s_nop 0                                                    // 0000001796E0: BF800000
	s_nop 0                                                    // 0000001796E4: BF800000
	s_nop 0                                                    // 0000001796E8: BF800000
	s_nop 0                                                    // 0000001796EC: BF800000
	s_nop 0                                                    // 0000001796F0: BF800000
	s_nop 0                                                    // 0000001796F4: BF800000
	s_nop 0                                                    // 0000001796F8: BF800000
	s_nop 0                                                    // 0000001796FC: BF800000
	s_or_b32 exec_lo, exec_lo, s3                              // 000000179700: 8C7E037E
	v_add_nc_u32_e32 v5, 0x80, v5                              // 000000179704: 4A0A0AFF 00000080
	.long 0xd7000301                                           // 00000017970C: D7000301
	v_cndmask_b32_e32 v1, 0x80, v1, vcc_lo                     // 000000179710: 020202FF 00000080
	ds_store_b32 v4, v6 offset:51200                           // 000000179718: D834C800 00000604
	v_add_co_ci_u32_e64 v2, null, 0, v2, s3                    // 000000179720: D5207C02 000E0480
	v_cmp_le_i32_e32 vcc_lo, s15, v5                           // 000000179728: 7C860A0F
	v_add_nc_u32_e32 v4, 0x200, v4                             // 00000017972C: 4A0808FF 00000200
	s_or_b32 s12, vcc_lo, s12                                  // 000000179734: 8C0C0C6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000179738: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 00000017973C: 917E0C7E
	s_cbranch_execz 16                                         // 000000179740: BFA50010 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x184>
	s_mov_b32 s3, exec_lo                                      // 000000179744: BE83007E
	.long 0xd4c3007e                                           // 000000179748: D4C3007E
	v_cndmask_b32_e32 v1, s14, v5, vcc_lo                      // 00000017974C: 02020A0E
	s_xor_b32 s3, exec_lo, s3                                  // 000000179750: 8D03037E
	v_add_nc_u32_e32 v6, s18, v5                               // 000000179754: 4A0C0A12
	v_cmp_gt_i32_e32 vcc_lo, s11, v5                           // 000000179758: 7C880A0B
	s_delay_alu instid0(VALU_DEP_2)                            // 00000017975C: BF870002
	v_cndmask_b32_e32 v6, s10, v6, vcc_lo                      // 000000179760: 020C0C0A
	s_and_not1_saveexec_b32 s3, s3                             // 000000179764: BE833003
	s_cbranch_execz 65509                                      // 000000179768: BFA5FFE5 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x100>
	global_load_b32 v6, v[1:2], off                            // 00000017976C: DC520000 067C0001
	s_waitcnt vmcnt(0)                                         // 000000179774: BF8903F7
	v_lshl_or_b32 v6, v6, 2, v3                                // 000000179778: D6560006 040D0506
	s_branch 65503                                             // 000000179780: BFA0FFDF <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x100>
	s_set_inst_prefetch_distance 0x2                           // 000000179784: BF840002
	s_or_b32 exec_lo, exec_lo, s17                             // 000000179788: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017978C: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000179790: BE83007E
	v_cmpx_eq_u32_e32 0, v0                                    // 000000179794: 7D940080
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, s11             // 000000179798: CA100080 0102000B
	ds_store_b32 v1, v2 offset:64336                           // 0000001797A0: D834FB50 00000201
	s_or_b32 exec_lo, exec_lo, s3                              // 0000001797A8: 8C7E037E
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v15, 31, v0         // 0000001797AC: CA240080 060E009F
	s_waitcnt lgkmcnt(0)                                       // 0000001797B4: BF89FC07
	s_barrier                                                  // 0000001797B8: BFBD0000
	buffer_gl0_inv                                             // 0000001797BC: E0AC0000 00000000
	ds_load_b32 v7, v6 offset:64336                            // 0000001797C4: D8D8FB50 07000006
	v_lshrrev_b32_e32 v176, 5, v0                              // 0000001797CC: 33600085
	v_dual_mov_b32 v255, 0xf149f2ca :: v_dual_and_b32 v16, 15, v0// 0000001797D0: CA2400FF FF10008F F149F2CA
	v_bfe_u32 v8, v0, 4, 1                                     // 0000001797DC: D6100008 02050900
	v_mov_b32_e32 v5, v6                                       // 0000001797E4: 7E0A0306
	v_mov_b32_e32 v4, v6                                       // 0000001797E8: 7E080306
	v_mov_b32_e32 v3, v6                                       // 0000001797EC: 7E060306
	v_mov_b32_e32 v2, v6                                       // 0000001797F0: 7E040306
	v_mov_b32_e32 v1, v6                                       // 0000001797F4: 7E020306
	v_mov_b32_e32 v14, v6                                      // 0000001797F8: 7E1C0306
	v_mov_b32_e32 v13, v6                                      // 0000001797FC: 7E1A0306
	v_mov_b32_e32 v12, v6                                      // 000000179800: 7E180306
	v_mov_b32_e32 v11, v6                                      // 000000179804: 7E160306
	v_mov_b32_e32 v10, v6                                      // 000000179808: 7E140306
	v_mov_b32_e32 v9, v6                                       // 00000017980C: 7E120306
	v_mov_b32_e32 v30, v6                                      // 000000179810: 7E3C0306
	v_mov_b32_e32 v29, v6                                      // 000000179814: 7E3A0306
	v_mov_b32_e32 v28, v6                                      // 000000179818: 7E380306
	v_mov_b32_e32 v27, v6                                      // 00000017981C: 7E360306
	s_waitcnt lgkmcnt(0)                                       // 000000179820: BF89FC07
	v_readfirstlane_b32 s3, v7                                 // 000000179824: 7E060507
	v_mov_b32_e32 v26, v6                                      // 000000179828: 7E340306
	v_mov_b32_e32 v25, v6                                      // 00000017982C: 7E320306
	v_mov_b32_e32 v22, v6                                      // 000000179830: 7E2C0306
	v_mov_b32_e32 v21, v6                                      // 000000179834: 7E2A0306
	s_add_i32 s3, s3, 15                                       // 000000179838: 81038F03
	v_mov_b32_e32 v20, v6                                      // 00000017983C: 7E280306
	s_ashr_i32 s10, s3, 31                                     // 000000179840: 860A9F03
	v_mov_b32_e32 v19, v6                                      // 000000179844: 7E260306
	s_lshr_b32 s10, s10, 28                                    // 000000179848: 850A9C0A
	v_mov_b32_e32 v18, v6                                      // 00000017984C: 7E240306
	s_add_i32 s3, s3, s10                                      // 000000179850: 81030A03
	v_mov_b32_e32 v17, v6                                      // 000000179854: 7E220306
	s_ashr_i32 s20, s3, 4                                      // 000000179858: 86148403
	v_mov_b32_e32 v46, v6                                      // 00000017985C: 7E5C0306
	v_cmp_gt_i32_e32 vcc_lo, s20, v176                         // 000000179860: 7C896014
	v_mov_b32_e32 v45, v6                                      // 000000179864: 7E5A0306
	v_mov_b32_e32 v44, v6                                      // 000000179868: 7E580306
	v_mov_b32_e32 v43, v6                                      // 00000017986C: 7E560306
	v_mov_b32_e32 v42, v6                                      // 000000179870: 7E540306
	v_mov_b32_e32 v41, v6                                      // 000000179874: 7E520306
	v_mov_b32_e32 v38, v6                                      // 000000179878: 7E4C0306
	v_mov_b32_e32 v37, v6                                      // 00000017987C: 7E4A0306
	v_mov_b32_e32 v36, v6                                      // 000000179880: 7E480306
	v_mov_b32_e32 v35, v6                                      // 000000179884: 7E460306
	v_mov_b32_e32 v34, v6                                      // 000000179888: 7E440306
	v_mov_b32_e32 v33, v6                                      // 00000017988C: 7E420306
	v_mov_b32_e32 v70, v6                                      // 000000179890: 7E8C0306
	v_mov_b32_e32 v69, v6                                      // 000000179894: 7E8A0306
	v_mov_b32_e32 v68, v6                                      // 000000179898: 7E880306
	v_mov_b32_e32 v67, v6                                      // 00000017989C: 7E860306
	v_mov_b32_e32 v66, v6                                      // 0000001798A0: 7E840306
	v_mov_b32_e32 v65, v6                                      // 0000001798A4: 7E820306
	v_mov_b32_e32 v54, v6                                      // 0000001798A8: 7E6C0306
	v_mov_b32_e32 v53, v6                                      // 0000001798AC: 7E6A0306
	v_mov_b32_e32 v52, v6                                      // 0000001798B0: 7E680306
	v_mov_b32_e32 v51, v6                                      // 0000001798B4: 7E660306
	v_mov_b32_e32 v50, v6                                      // 0000001798B8: 7E640306
	v_mov_b32_e32 v49, v6                                      // 0000001798BC: 7E620306
	v_mov_b32_e32 v86, v6                                      // 0000001798C0: 7EAC0306
	v_mov_b32_e32 v85, v6                                      // 0000001798C4: 7EAA0306
	v_mov_b32_e32 v84, v6                                      // 0000001798C8: 7EA80306
	v_mov_b32_e32 v83, v6                                      // 0000001798CC: 7EA60306
	v_mov_b32_e32 v82, v6                                      // 0000001798D0: 7EA40306
	v_mov_b32_e32 v81, v6                                      // 0000001798D4: 7EA20306
	v_mov_b32_e32 v62, v6                                      // 0000001798D8: 7E7C0306
	v_mov_b32_e32 v61, v6                                      // 0000001798DC: 7E7A0306
	v_mov_b32_e32 v60, v6                                      // 0000001798E0: 7E780306
	v_mov_b32_e32 v59, v6                                      // 0000001798E4: 7E760306
	v_mov_b32_e32 v58, v6                                      // 0000001798E8: 7E740306
	v_mov_b32_e32 v57, v6                                      // 0000001798EC: 7E720306
	v_mov_b32_e32 v102, v6                                     // 0000001798F0: 7ECC0306
	v_mov_b32_e32 v101, v6                                     // 0000001798F4: 7ECA0306
	v_mov_b32_e32 v100, v6                                     // 0000001798F8: 7EC80306
	v_mov_b32_e32 v99, v6                                      // 0000001798FC: 7EC60306
	v_mov_b32_e32 v98, v6                                      // 000000179900: 7EC40306
	v_mov_b32_e32 v97, v6                                      // 000000179904: 7EC20306
	v_mov_b32_e32 v78, v6                                      // 000000179908: 7E9C0306
	v_mov_b32_e32 v77, v6                                      // 00000017990C: 7E9A0306
	v_mov_b32_e32 v76, v6                                      // 000000179910: 7E980306
	v_mov_b32_e32 v75, v6                                      // 000000179914: 7E960306
	v_mov_b32_e32 v74, v6                                      // 000000179918: 7E940306
	v_mov_b32_e32 v73, v6                                      // 00000017991C: 7E920306
	v_mov_b32_e32 v118, v6                                     // 000000179920: 7EEC0306
	v_mov_b32_e32 v117, v6                                     // 000000179924: 7EEA0306
	v_mov_b32_e32 v116, v6                                     // 000000179928: 7EE80306
	v_mov_b32_e32 v115, v6                                     // 00000017992C: 7EE60306
	v_mov_b32_e32 v114, v6                                     // 000000179930: 7EE40306
	v_mov_b32_e32 v113, v6                                     // 000000179934: 7EE20306
	v_mov_b32_e32 v94, v6                                      // 000000179938: 7EBC0306
	v_mov_b32_e32 v93, v6                                      // 00000017993C: 7EBA0306
	v_mov_b32_e32 v92, v6                                      // 000000179940: 7EB80306
	v_mov_b32_e32 v91, v6                                      // 000000179944: 7EB60306
	v_mov_b32_e32 v90, v6                                      // 000000179948: 7EB40306
	v_mov_b32_e32 v89, v6                                      // 00000017994C: 7EB20306
	v_mov_b32_e32 v126, v6                                     // 000000179950: 7EFC0306
	v_mov_b32_e32 v125, v6                                     // 000000179954: 7EFA0306
	v_mov_b32_e32 v124, v6                                     // 000000179958: 7EF80306
	v_mov_b32_e32 v123, v6                                     // 00000017995C: 7EF60306
	v_mov_b32_e32 v122, v6                                     // 000000179960: 7EF40306
	v_mov_b32_e32 v121, v6                                     // 000000179964: 7EF20306
	v_mov_b32_e32 v110, v6                                     // 000000179968: 7EDC0306
	v_mov_b32_e32 v109, v6                                     // 00000017996C: 7EDA0306
	v_mov_b32_e32 v108, v6                                     // 000000179970: 7ED80306
	v_mov_b32_e32 v107, v6                                     // 000000179974: 7ED60306
	v_mov_b32_e32 v106, v6                                     // 000000179978: 7ED40306
	v_mov_b32_e32 v105, v6                                     // 00000017997C: 7ED20306
	v_mov_b32_e32 v252, v6                                     // 000000179980: 7FF80306
	s_mul_i32 s18, s16, 12                                     // 000000179984: 96128C10
	s_mul_hi_i32 s11, s2, 0x1800                               // 000000179988: 970BFF02 00001800
	s_mul_i32 s10, s2, 0x1800                                  // 000000179990: 960AFF02 00001800
	s_and_saveexec_b32 s19, vcc_lo                             // 000000179998: BE93206A
	s_cbranch_execz 1684                                       // 00000017999C: BFA50694 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1df0>
	v_cmp_gt_u32_e32 vcc_lo, 12, v16                           // 0000001799A0: 7C98208C
	s_load_b128 s[0:3], s[0:1], null                           // 0000001799A4: F4080000 F8000000
	v_dual_mov_b32 v137, 0 :: v_dual_mov_b32 v252, 0           // 0000001799AC: CA100080 89FC0080
	s_lshl_b64 s[12:13], s[10:11], 1                           // 0000001799B4: 848C810A
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 0000001799B8: 02022080
	v_mul_u32_u24_e32 v3, 0x44, v8                             // 0000001799BC: 160610FF 00000044
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001799C4: BF870223
	v_dual_mov_b32 v106, v137 :: v_dual_mov_b32 v175, v7       // 0000001799C8: CA100189 6AAE0107
	v_mov_b32_e32 v122, v137                                   // 0000001799D0: 7EF40389
	v_add_lshl_u32 v1, v1, s18, 8                              // 0000001799D4: D6470001 02202501
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v124, v137        // 0000001799DC: CA100080 697C0189
	v_dual_mov_b32 v107, v137 :: v_dual_mov_b32 v158, v176     // 0000001799E4: CA100189 6B9E01B0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001799EC: BF870243
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000001799F0: 3404029F
	v_mov_b32_e32 v109, v137                                   // 0000001799F4: 7EDA0389
	v_mov_b32_e32 v111, v137                                   // 0000001799F8: 7EDE0389
	v_dual_mov_b32 v121, 0 :: v_dual_mov_b32 v126, v137        // 0000001799FC: CA100080 797E0189
	.long 0xd73c0001                                           // 000000179A04: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000179A08: 02020281
	s_waitcnt lgkmcnt(0)                                       // 000000179A0C: BF89FC07
	s_add_u32 s0, s0, s12                                      // 000000179A10: 80000C00
	s_addc_u32 s1, s1, s13                                     // 000000179A14: 82010D01
	s_movk_i32 s13, 0x440                                      // 000000179A18: B00D0440
	s_ashr_i32 s17, s16, 31                                    // 000000179A1C: 86119F10
	v_mov_b32_e32 v123, v137                                   // 000000179A20: 7EF60389
	.long 0xd7006a01                                           // 000000179A24: D7006A01
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 000000179A28: 02020200
	s_delay_alu instid0(VALU_DEP_1)                            // 000000179A2C: BF870001
	v_add_co_ci_u32_e64 v2, null, s1, v2, vcc_lo               // 000000179A30: D5207C02 01AA0401
	s_lshl_b64 s[0:1], s[16:17], 9                             // 000000179A38: 84808910
	v_cmp_lt_u32_e32 vcc_lo, 11, v15                           // 000000179A3C: 7C921E8B
	s_add_u32 s16, s2, s0                                      // 000000179A40: 80100002
	s_clause 0x1                                               // 000000179A44: BF850001
	global_load_b128 v[21:24], v[1:2], off offset:16           // 000000179A48: DC5E0010 157C0001
	global_load_b128 v[17:20], v[1:2], off                     // 000000179A50: DC5E0000 117C0001
	.long 0xd44c0000                                           // 000000179A58: D44C0000
	v_cndmask_b32_e32 v1, 16, v15, vcc_lo                      // 000000179A5C: 02021E90
	v_mov_b32_e32 v125, v137                                   // 000000179A60: 7EFA0389
	v_mov_b32_e32 v127, v137                                   // 000000179A64: 7EFE0389
	v_dual_mov_b32 v128, v137 :: v_dual_mov_b32 v89, 0         // 000000179A68: CA100189 80580080
	v_dual_mov_b32 v90, v137 :: v_dual_mov_b32 v113, 0         // 000000179A70: CA100189 5A700080
	v_mov_b32_e32 v91, v137                                    // 000000179A78: 7EB60389
	v_dual_mov_b32 v92, v137 :: v_dual_mov_b32 v73, 0          // 000000179A7C: CA100189 5C480080
	v_mov_b32_e32 v93, v137                                    // 000000179A84: 7EBA0389
	v_dual_mov_b32 v94, v137 :: v_dual_mov_b32 v97, 0          // 000000179A88: CA100189 5E600080
	v_mov_b32_e32 v95, v137                                    // 000000179A90: 7EBE0389
	v_dual_mov_b32 v96, v137 :: v_dual_mov_b32 v57, 0          // 000000179A94: CA100189 60380080
	v_dual_mov_b32 v114, v137 :: v_dual_mov_b32 v81, 0         // 000000179A9C: CA100189 72500080
	v_mov_b32_e32 v115, v137                                   // 000000179AA4: 7EE60389
	v_dual_mov_b32 v116, v137 :: v_dual_mov_b32 v49, 0         // 000000179AA8: CA100189 74300080
	v_mov_b32_e32 v117, v137                                   // 000000179AB0: 7EEA0389
	v_dual_mov_b32 v118, v137 :: v_dual_mov_b32 v65, 0         // 000000179AB4: CA100189 76400080
	v_mov_b32_e32 v119, v137                                   // 000000179ABC: 7EEE0389
	v_dual_mov_b32 v120, v137 :: v_dual_mov_b32 v33, 0         // 000000179AC0: CA100189 78200080
	v_dual_mov_b32 v74, v137 :: v_dual_mov_b32 v41, 0          // 000000179AC8: CA100189 4A280080
	v_mov_b32_e32 v75, v137                                    // 000000179AD0: 7E960389
	v_mov_b32_e32 v76, v137                                    // 000000179AD4: 7E980389
	v_mov_b32_e32 v77, v137                                    // 000000179AD8: 7E9A0389
	v_dual_mov_b32 v78, v137 :: v_dual_mov_b32 v25, 0          // 000000179ADC: CA100189 4E180080
	v_mov_b32_e32 v79, v137                                    // 000000179AE4: 7E9E0389
	v_dual_mov_b32 v80, v137 :: v_dual_mov_b32 v9, 0           // 000000179AE8: CA100189 50080080
	v_mov_b32_e32 v98, v137                                    // 000000179AF0: 7EC40389
	v_mov_b32_e32 v99, v137                                    // 000000179AF4: 7EC60389
	v_dual_mov_b32 v100, v137 :: v_dual_mov_b32 v255, 0xf149f2ca// 000000179AF8: CA100189 64FE00FF F149F2CA
	v_mov_b32_e32 v101, v137                                   // 000000179B04: 7ECA0389
	v_mov_b32_e32 v102, v137                                   // 000000179B08: 7ECC0389
	v_mov_b32_e32 v103, v137                                   // 000000179B0C: 7ECE0389
	v_mov_b32_e32 v104, v137                                   // 000000179B10: 7ED00389
	v_mov_b32_e32 v58, v137                                    // 000000179B14: 7E740389
	v_mov_b32_e32 v59, v137                                    // 000000179B18: 7E760389
	v_mov_b32_e32 v60, v137                                    // 000000179B1C: 7E780389
	v_mov_b32_e32 v61, v137                                    // 000000179B20: 7E7A0389
	v_mov_b32_e32 v62, v137                                    // 000000179B24: 7E7C0389
	v_mov_b32_e32 v63, v137                                    // 000000179B28: 7E7E0389
	v_mov_b32_e32 v64, v137                                    // 000000179B2C: 7E800389
	v_mov_b32_e32 v82, v137                                    // 000000179B30: 7EA40389
	v_mov_b32_e32 v83, v137                                    // 000000179B34: 7EA60389
	v_mov_b32_e32 v84, v137                                    // 000000179B38: 7EA80389
	v_mov_b32_e32 v85, v137                                    // 000000179B3C: 7EAA0389
	v_mov_b32_e32 v86, v137                                    // 000000179B40: 7EAC0389
	v_mov_b32_e32 v87, v137                                    // 000000179B44: 7EAE0389
	v_mov_b32_e32 v88, v137                                    // 000000179B48: 7EB00389
	v_mov_b32_e32 v50, v137                                    // 000000179B4C: 7E640389
	v_mov_b32_e32 v51, v137                                    // 000000179B50: 7E660389
	v_mov_b32_e32 v52, v137                                    // 000000179B54: 7E680389
	v_mov_b32_e32 v53, v137                                    // 000000179B58: 7E6A0389
	v_mov_b32_e32 v54, v137                                    // 000000179B5C: 7E6C0389
	v_mov_b32_e32 v55, v137                                    // 000000179B60: 7E6E0389
	v_mov_b32_e32 v56, v137                                    // 000000179B64: 7E700389
	v_mov_b32_e32 v66, v137                                    // 000000179B68: 7E840389
	v_mov_b32_e32 v67, v137                                    // 000000179B6C: 7E860389
	v_mov_b32_e32 v68, v137                                    // 000000179B70: 7E880389
	v_mov_b32_e32 v69, v137                                    // 000000179B74: 7E8A0389
	v_mov_b32_e32 v70, v137                                    // 000000179B78: 7E8C0389
	v_mov_b32_e32 v71, v137                                    // 000000179B7C: 7E8E0389
	v_mov_b32_e32 v72, v137                                    // 000000179B80: 7E900389
	v_mov_b32_e32 v34, v137                                    // 000000179B84: 7E440389
	v_mov_b32_e32 v35, v137                                    // 000000179B88: 7E460389
	v_mov_b32_e32 v36, v137                                    // 000000179B8C: 7E480389
	v_mov_b32_e32 v37, v137                                    // 000000179B90: 7E4A0389
	v_mov_b32_e32 v38, v137                                    // 000000179B94: 7E4C0389
	v_mov_b32_e32 v39, v137                                    // 000000179B98: 7E4E0389
	v_mov_b32_e32 v40, v137                                    // 000000179B9C: 7E500389
	v_mov_b32_e32 v42, v137                                    // 000000179BA0: 7E540389
	v_mov_b32_e32 v43, v137                                    // 000000179BA4: 7E560389
	v_mov_b32_e32 v44, v137                                    // 000000179BA8: 7E580389
	v_mov_b32_e32 v45, v137                                    // 000000179BAC: 7E5A0389
	v_mov_b32_e32 v46, v137                                    // 000000179BB0: 7E5C0389
	v_mov_b32_e32 v47, v137                                    // 000000179BB4: 7E5E0389
	v_mov_b32_e32 v48, v137                                    // 000000179BB8: 7E600389
	v_mov_b32_e32 v26, v137                                    // 000000179BBC: 7E340389
	v_mov_b32_e32 v27, v137                                    // 000000179BC0: 7E360389
	v_mov_b32_e32 v28, v137                                    // 000000179BC4: 7E380389
	v_mov_b32_e32 v29, v137                                    // 000000179BC8: 7E3A0389
	v_mov_b32_e32 v30, v137                                    // 000000179BCC: 7E3C0389
	v_mov_b32_e32 v31, v137                                    // 000000179BD0: 7E3E0389
	v_mov_b32_e32 v32, v137                                    // 000000179BD4: 7E400389
	v_mov_b32_e32 v10, v137                                    // 000000179BD8: 7E140389
	v_mov_b32_e32 v11, v137                                    // 000000179BDC: 7E160389
	v_mov_b32_e32 v12, v137                                    // 000000179BE0: 7E180389
	v_mov_b32_e32 v13, v137                                    // 000000179BE4: 7E1A0389
	v_mov_b32_e32 v14, v137                                    // 000000179BE8: 7E1C0389
	v_mov_b32_e32 v4, v137                                     // 000000179BEC: 7E080389
	v_mov_b32_e32 v5, v137                                     // 000000179BF0: 7E0A0389
	v_mov_b32_e32 v6, v137                                     // 000000179BF4: 7E0C0389
	s_mov_b32 s12, 0                                           // 000000179BF8: BE8C0080
	s_addc_u32 s3, s3, s1                                      // 000000179BFC: 82030103
	s_mov_b32 s17, 0                                           // 000000179C00: BE910080
	s_waitcnt vmcnt(0)                                         // 000000179C04: BF8903F7
	s_clause 0x1                                               // 000000179C08: BF850001
	scratch_store_b128 off, v[17:20], off                      // 000000179C0C: DC750000 007C1100
	scratch_store_b128 off, v[21:24], off offset:16            // 000000179C14: DC750010 007C1500
	s_clause 0x1                                               // 000000179C1C: BF850001
	global_load_b128 v[21:24], v[1:2], off offset:48           // 000000179C20: DC5E0030 157C0001
	global_load_b128 v[17:20], v[1:2], off offset:32           // 000000179C28: DC5E0020 117C0001
	s_waitcnt vmcnt(0)                                         // 000000179C30: BF8903F7
	s_clause 0x1                                               // 000000179C34: BF850001
	scratch_store_b128 off, v[17:20], off offset:32            // 000000179C38: DC750020 007C1100
	scratch_store_b128 off, v[21:24], off offset:48            // 000000179C40: DC750030 007C1500
	s_clause 0x1                                               // 000000179C48: BF850001
	global_load_b128 v[21:24], v[1:2], off offset:80           // 000000179C4C: DC5E0050 157C0001
	global_load_b128 v[17:20], v[1:2], off offset:64           // 000000179C54: DC5E0040 117C0001
	s_waitcnt vmcnt(0)                                         // 000000179C5C: BF8903F7
	s_clause 0x1                                               // 000000179C60: BF850001
	scratch_store_b128 off, v[17:20], off offset:64            // 000000179C64: DC750040 007C1100
	scratch_store_b128 off, v[21:24], off offset:80            // 000000179C6C: DC750050 007C1500
	s_clause 0x1                                               // 000000179C74: BF850001
	global_load_b128 v[21:24], v[1:2], off offset:112          // 000000179C78: DC5E0070 157C0001
	global_load_b128 v[17:20], v[1:2], off offset:96           // 000000179C80: DC5E0060 117C0001
	s_waitcnt vmcnt(0)                                         // 000000179C88: BF8903F7
	s_clause 0x1                                               // 000000179C8C: BF850001
	scratch_store_b128 off, v[17:20], off offset:96            // 000000179C90: DC750060 007C1100
	scratch_store_b128 off, v[21:24], off offset:112           // 000000179C98: DC750070 007C1500
	s_clause 0x1                                               // 000000179CA0: BF850001
	global_load_b128 v[21:24], v[1:2], off offset:144          // 000000179CA4: DC5E0090 157C0001
	global_load_b128 v[17:20], v[1:2], off offset:128          // 000000179CAC: DC5E0080 117C0001
	s_waitcnt vmcnt(0)                                         // 000000179CB4: BF8903F7
	s_clause 0x1                                               // 000000179CB8: BF850001
	scratch_store_b128 off, v[17:20], off offset:128           // 000000179CBC: DC750080 007C1100
	scratch_store_b128 off, v[21:24], off offset:144           // 000000179CC4: DC750090 007C1500
	s_clause 0x1                                               // 000000179CCC: BF850001
	global_load_b128 v[21:24], v[1:2], off offset:176          // 000000179CD0: DC5E00B0 157C0001
	global_load_b128 v[17:20], v[1:2], off offset:160          // 000000179CD8: DC5E00A0 117C0001
	s_waitcnt vmcnt(0)                                         // 000000179CE0: BF8903F7
	s_clause 0x1                                               // 000000179CE4: BF850001
	scratch_store_b128 off, v[17:20], off offset:160           // 000000179CE8: DC7500A0 007C1100
	scratch_store_b128 off, v[21:24], off offset:176           // 000000179CF0: DC7500B0 007C1500
	s_clause 0x13                                              // 000000179CF8: BF850013
	global_load_b128 v[181:184], v[1:2], off offset:208        // 000000179CFC: DC5E00D0 B57C0001
	global_load_b128 v[177:180], v[1:2], off offset:192        // 000000179D04: DC5E00C0 B17C0001
	global_load_b128 v[189:192], v[1:2], off offset:240        // 000000179D0C: DC5E00F0 BD7C0001
	global_load_b128 v[185:188], v[1:2], off offset:224        // 000000179D14: DC5E00E0 B97C0001
	global_load_b128 v[197:200], v[1:2], off offset:272        // 000000179D1C: DC5E0110 C57C0001
	global_load_b128 v[193:196], v[1:2], off offset:256        // 000000179D24: DC5E0100 C17C0001
	global_load_b128 v[205:208], v[1:2], off offset:304        // 000000179D2C: DC5E0130 CD7C0001
	global_load_b128 v[201:204], v[1:2], off offset:288        // 000000179D34: DC5E0120 C97C0001
	global_load_b128 v[213:216], v[1:2], off offset:336        // 000000179D3C: DC5E0150 D57C0001
	global_load_b128 v[209:212], v[1:2], off offset:320        // 000000179D44: DC5E0140 D17C0001
	global_load_b128 v[221:224], v[1:2], off offset:368        // 000000179D4C: DC5E0170 DD7C0001
	global_load_b128 v[217:220], v[1:2], off offset:352        // 000000179D54: DC5E0160 D97C0001
	global_load_b128 v[229:232], v[1:2], off offset:400        // 000000179D5C: DC5E0190 E57C0001
	global_load_b128 v[225:228], v[1:2], off offset:384        // 000000179D64: DC5E0180 E17C0001
	global_load_b128 v[237:240], v[1:2], off offset:432        // 000000179D6C: DC5E01B0 ED7C0001
	global_load_b128 v[233:236], v[1:2], off offset:416        // 000000179D74: DC5E01A0 E97C0001
	global_load_b128 v[245:248], v[1:2], off offset:464        // 000000179D7C: DC5E01D0 F57C0001
	global_load_b128 v[241:244], v[1:2], off offset:448        // 000000179D84: DC5E01C0 F17C0001
	global_load_b128 v[133:136], v[1:2], off offset:496        // 000000179D8C: DC5E01F0 857C0001
	global_load_b128 v[129:132], v[1:2], off offset:480        // 000000179D94: DC5E01E0 817C0001
	v_mul_u32_u24_e32 v1, 0x3000, v176                         // 000000179D9C: 160360FF 00003000
	v_mul_u32_u24_e32 v2, 48, v16                              // 000000179DA4: 160420B0
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v18, v137          // 000000179DA8: CA100080 11120189
	v_mov_b32_e32 v108, v137                                   // 000000179DB0: 7ED80389
	v_mov_b32_e32 v19, v137                                    // 000000179DB4: 7E260389
	s_delay_alu instid0(VALU_DEP_4)                            // 000000179DB8: BF870004
	v_or3_b32 v251, v1, v2, 0x800                              // 000000179DBC: D65800FB 03FE0501 00000800
	v_lshlrev_b32_e32 v1, 2, v16                               // 000000179DC8: 30022082
	v_mad_u32_u24 v2, v176, s13, 0xe850                        // 000000179DCC: D60B0002 03FC1BB0 0000E850
	v_mov_b32_e32 v20, v137                                    // 000000179DD8: 7E280389
	v_mov_b32_e32 v21, v137                                    // 000000179DDC: 7E2A0389
	v_mov_b32_e32 v22, v137                                    // 000000179DE0: 7E2C0389
	v_or_b32_e32 v152, 0xc800, v1                              // 000000179DE4: 393002FF 0000C800
	v_add3_u32 v253, v2, v3, v1                                // 000000179DEC: D65500FD 04060702
	v_lshl_add_u32 v1, v176, 6, 0xfa50                         // 000000179DF4: D6460001 03FD0DB0 0000FA50
	v_mad_u32_u24 v254, 0x44, v15, v2                          // 000000179E00: D60B00FE 040A1EFF 00000044
	v_mov_b32_e32 v110, v137                                   // 000000179E0C: 7EDC0389
	v_mov_b32_e32 v23, v137                                    // 000000179E10: 7E2E0389
	v_mov_b32_e32 v24, v137                                    // 000000179E14: 7E300389
	v_lshl_add_u32 v2, v15, 2, v1                              // 000000179E18: D6460002 0405050F
	v_lshl_or_b32 v153, v8, 2, v1                              // 000000179E20: D6560099 04050508
	v_dual_mov_b32 v112, v137 :: v_dual_lshlrev_b32 v1, 9, v176// 000000179E28: CA220189 70016089
	v_mov_b32_e32 v3, v137                                     // 000000179E30: 7E060389
	scratch_store_b32 off, v2, off offset:192                  // 000000179E34: DC6900C0 007C0200
	v_mov_b32_e32 v2, v137                                     // 000000179E3C: 7E040389
	v_lshl_add_u32 v154, v15, 5, v1                            // 000000179E40: D646009A 04050B0F
	v_lshl_or_b32 v155, v16, 5, v1                             // 000000179E48: D656009B 04050B10
	v_dual_mov_b32 v16, v137 :: v_dual_lshlrev_b32 v1, 4, v176 // 000000179E50: CA220189 10016084
	v_mov_b32_e32 v8, v137                                     // 000000179E58: 7E100389
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000179E5C: BF8701C2
	v_sub_nc_u32_e32 v156, v7, v1                              // 000000179E60: 4D380307
	v_mul_u32_u24_e32 v1, 0x44, v15                            // 000000179E64: 16021EFF 00000044
	v_mov_b32_e32 v15, v137                                    // 000000179E6C: 7E1E0389
	v_mov_b32_e32 v7, v137                                     // 000000179E70: 7E0E0389
	v_mad_u32_u24 v157, 0x440, v176, v1                        // 000000179E74: D60B009D 040760FF 00000440
	v_mov_b32_e32 v1, 0                                        // 000000179E80: 7E020280
	s_branch 265                                               // 000000179E84: BFA00109 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0xcac>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000179E88: 8C7E017E
	ds_load_b128 v[138:141], v155                              // 000000179E8C: DBFC0000 8A00009B
	ds_load_b128 v[142:145], v155 offset:16                    // 000000179E94: DBFC0010 8E00009B
	ds_load_b128 v[159:162], v251                              // 000000179E9C: DBFC0000 9F0000FB
	ds_load_b128 v[163:166], v251 offset:16                    // 000000179EA4: DBFC0010 A30000FB
	ds_load_2addr_b32 v[146:147], v153 offset1:2               // 000000179EAC: D8DC0200 92000099
	ds_load_2addr_b32 v[148:149], v153 offset0:4 offset1:6     // 000000179EB4: D8DC0604 94000099
	ds_load_2addr_b32 v[150:151], v153 offset0:8 offset1:10    // 000000179EBC: D8DC0A08 96000099
	ds_load_2addr_b32 v[249:250], v153 offset0:12 offset1:14   // 000000179EC4: D8DC0E0C F9000099
	v_add_nc_u32_e32 v158, 4, v158                             // 000000179ECC: 4B3D3C84
	v_subrev_nc_u32_e32 v156, 64, v156                         // 000000179ED0: 4F3938C0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000179ED4: BF870002
	.long 0xd4430001                                           // 000000179ED8: D4430001
	v_cndmask_b32_e32 v1, s20, v158, vcc_lo                    // 000000179EDC: 02033C14
	s_or_b32 s17, s1, s17                                      // 000000179EE0: 8C111101
	s_waitcnt lgkmcnt(3)                                       // 000000179EE4: BF89FC37
	v_dual_mul_f32 v105, v146, v105 :: v_dual_mul_f32 v106, v147, v106// 000000179EE8: C8C6D392 696AD593
	s_waitcnt lgkmcnt(2)                                       // 000000179EF0: BF89FC27
	v_dual_mul_f32 v107, v148, v107 :: v_dual_mul_f32 v108, v149, v108// 000000179EF4: C8C6D794 6B6CD995
	s_waitcnt lgkmcnt(1)                                       // 000000179EFC: BF89FC17
	v_dual_mul_f32 v109, v150, v109 :: v_dual_mul_f32 v110, v151, v110// 000000179F00: C8C6DB96 6D6EDD97
	s_waitcnt lgkmcnt(0)                                       // 000000179F08: BF89FC07
	v_dual_mul_f32 v111, v249, v111 :: v_dual_mul_f32 v112, v250, v112// 000000179F0C: C8C6DFF9 6F70E1FA
	v_dual_mul_f32 v121, v146, v121 :: v_dual_mul_f32 v122, v147, v122// 000000179F14: C8C6F392 797AF593
	v_dual_mul_f32 v123, v148, v123 :: v_dual_mul_f32 v124, v149, v124// 000000179F1C: C8C6F794 7B7CF995
	s_delay_alu instid0(VALU_DEP_3)                            // 000000179F24: BF870003
	v_wmma_f32_16x16x16_bf16 v[105:112], v[138:145], v[159:166], v[105:112]// 000000179F28: CC414069 1DA73F8A
	ds_load_b128 v[163:166], v251 offset:784                   // 000000179F30: DBFC0310 A30000FB
	ds_load_b128 v[159:162], v251 offset:768                   // 000000179F38: DBFC0300 9F0000FB
	v_dual_mul_f32 v125, v150, v125 :: v_dual_mul_f32 v126, v151, v126// 000000179F40: C8C6FB96 7D7EFD97
	v_dual_mul_f32 v127, v249, v127 :: v_dual_mul_f32 v128, v250, v128// 000000179F48: C8C6FFF9 7F8101FA
	v_dual_mul_f32 v89, v146, v89 :: v_dual_mul_f32 v90, v147, v90// 000000179F50: C8C6B392 595AB593
	v_dual_mul_f32 v91, v148, v91 :: v_dual_mul_f32 v92, v149, v92// 000000179F58: C8C6B794 5B5CB995
	v_dual_mul_f32 v93, v150, v93 :: v_dual_mul_f32 v94, v151, v94// 000000179F60: C8C6BB96 5D5EBD97
	v_dual_mul_f32 v95, v249, v95 :: v_dual_mul_f32 v96, v250, v96// 000000179F68: C8C6BFF9 5F60C1FA
	v_dual_mul_f32 v113, v146, v113 :: v_dual_mul_f32 v114, v147, v114// 000000179F70: C8C6E392 7172E593
	v_dual_mul_f32 v115, v148, v115 :: v_dual_mul_f32 v116, v149, v116// 000000179F78: C8C6E794 7374E995
	v_dual_mul_f32 v117, v150, v117 :: v_dual_mul_f32 v118, v151, v118// 000000179F80: C8C6EB96 7576ED97
	v_dual_mul_f32 v119, v249, v119 :: v_dual_mul_f32 v120, v250, v120// 000000179F88: C8C6EFF9 7778F1FA
	s_waitcnt lgkmcnt(0)                                       // 000000179F90: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[138:145], v[159:166], v[121:128]// 000000179F94: CC414079 1DE73F8A
	ds_load_b128 v[163:166], v251 offset:1552                  // 000000179F9C: DBFC0610 A30000FB
	ds_load_b128 v[159:162], v251 offset:1536                  // 000000179FA4: DBFC0600 9F0000FB
	v_dual_mul_f32 v73, v146, v73 :: v_dual_mul_f32 v74, v147, v74// 000000179FAC: C8C69392 494A9593
	v_dual_mul_f32 v75, v148, v75 :: v_dual_mul_f32 v76, v149, v76// 000000179FB4: C8C69794 4B4C9995
	v_dual_mul_f32 v77, v150, v77 :: v_dual_mul_f32 v78, v151, v78// 000000179FBC: C8C69B96 4D4E9D97
	v_dual_mul_f32 v79, v249, v79 :: v_dual_mul_f32 v80, v250, v80// 000000179FC4: C8C69FF9 4F50A1FA
	v_dual_mul_f32 v97, v146, v97 :: v_dual_mul_f32 v98, v147, v98// 000000179FCC: C8C6C392 6162C593
	v_dual_mul_f32 v99, v148, v99 :: v_dual_mul_f32 v100, v149, v100// 000000179FD4: C8C6C794 6364C995
	v_dual_mul_f32 v101, v150, v101 :: v_dual_mul_f32 v102, v151, v102// 000000179FDC: C8C6CB96 6566CD97
	v_dual_mul_f32 v103, v249, v103 :: v_dual_mul_f32 v104, v250, v104// 000000179FE4: C8C6CFF9 6768D1FA
	v_dual_mul_f32 v57, v146, v57 :: v_dual_mul_f32 v58, v147, v58// 000000179FEC: C8C67392 393A7593
	v_dual_mul_f32 v59, v148, v59 :: v_dual_mul_f32 v60, v149, v60// 000000179FF4: C8C67794 3B3C7995
	s_waitcnt lgkmcnt(0)                                       // 000000179FFC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[138:145], v[159:166], v[89:96]// 00000017A000: CC414059 1D673F8A
	ds_load_b128 v[163:166], v251 offset:2320                  // 00000017A008: DBFC0910 A30000FB
	ds_load_b128 v[159:162], v251 offset:2304                  // 00000017A010: DBFC0900 9F0000FB
	v_dual_mul_f32 v61, v150, v61 :: v_dual_mul_f32 v62, v151, v62// 00000017A018: C8C67B96 3D3E7D97
	v_dual_mul_f32 v63, v249, v63 :: v_dual_mul_f32 v64, v250, v64// 00000017A020: C8C67FF9 3F4081FA
	v_dual_mul_f32 v81, v146, v81 :: v_dual_mul_f32 v82, v147, v82// 00000017A028: C8C6A392 5152A593
	v_dual_mul_f32 v83, v148, v83 :: v_dual_mul_f32 v84, v149, v84// 00000017A030: C8C6A794 5354A995
	v_dual_mul_f32 v85, v150, v85 :: v_dual_mul_f32 v86, v151, v86// 00000017A038: C8C6AB96 5556AD97
	v_dual_mul_f32 v87, v249, v87 :: v_dual_mul_f32 v88, v250, v88// 00000017A040: C8C6AFF9 5758B1FA
	v_dual_mul_f32 v49, v146, v49 :: v_dual_mul_f32 v50, v147, v50// 00000017A048: C8C66392 31326593
	v_dual_mul_f32 v51, v148, v51 :: v_dual_mul_f32 v52, v149, v52// 00000017A050: C8C66794 33346995
	v_dual_mul_f32 v53, v150, v53 :: v_dual_mul_f32 v54, v151, v54// 00000017A058: C8C66B96 35366D97
	v_dual_mul_f32 v55, v249, v55 :: v_dual_mul_f32 v56, v250, v56// 00000017A060: C8C66FF9 373871FA
	s_waitcnt lgkmcnt(0)                                       // 00000017A068: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[138:145], v[159:166], v[113:120]// 00000017A06C: CC414071 1DC73F8A
	ds_load_b128 v[163:166], v251 offset:3088                  // 00000017A074: DBFC0C10 A30000FB
	ds_load_b128 v[159:162], v251 offset:3072                  // 00000017A07C: DBFC0C00 9F0000FB
	v_dual_mul_f32 v65, v146, v65 :: v_dual_mul_f32 v66, v147, v66// 00000017A084: C8C68392 41428593
	v_dual_mul_f32 v67, v148, v67 :: v_dual_mul_f32 v68, v149, v68// 00000017A08C: C8C68794 43448995
	v_dual_mul_f32 v69, v150, v69 :: v_dual_mul_f32 v70, v151, v70// 00000017A094: C8C68B96 45468D97
	v_dual_mul_f32 v71, v249, v71 :: v_dual_mul_f32 v72, v250, v72// 00000017A09C: C8C68FF9 474891FA
	v_dual_mul_f32 v33, v146, v33 :: v_dual_mul_f32 v34, v147, v34// 00000017A0A4: C8C64392 21224593
	v_dual_mul_f32 v35, v148, v35 :: v_dual_mul_f32 v36, v149, v36// 00000017A0AC: C8C64794 23244995
	v_dual_mul_f32 v37, v150, v37 :: v_dual_mul_f32 v38, v151, v38// 00000017A0B4: C8C64B96 25264D97
	v_dual_mul_f32 v39, v249, v39 :: v_dual_mul_f32 v40, v250, v40// 00000017A0BC: C8C64FF9 272851FA
	v_dual_mul_f32 v41, v146, v41 :: v_dual_mul_f32 v42, v147, v42// 00000017A0C4: C8C65392 292A5593
	v_dual_mul_f32 v43, v148, v43 :: v_dual_mul_f32 v44, v149, v44// 00000017A0CC: C8C65794 2B2C5995
	s_waitcnt lgkmcnt(0)                                       // 00000017A0D4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[138:145], v[159:166], v[73:80]// 00000017A0D8: CC414049 1D273F8A
	ds_load_b128 v[163:166], v251 offset:3856                  // 00000017A0E0: DBFC0F10 A30000FB
	ds_load_b128 v[159:162], v251 offset:3840                  // 00000017A0E8: DBFC0F00 9F0000FB
	v_dual_mul_f32 v45, v150, v45 :: v_dual_mul_f32 v46, v151, v46// 00000017A0F0: C8C65B96 2D2E5D97
	v_dual_mul_f32 v47, v249, v47 :: v_dual_mul_f32 v48, v250, v48// 00000017A0F8: C8C65FF9 2F3061FA
	v_dual_mul_f32 v17, v146, v17 :: v_dual_mul_f32 v18, v147, v18// 00000017A100: C8C62392 11122593
	v_dual_mul_f32 v19, v148, v19 :: v_dual_mul_f32 v20, v149, v20// 00000017A108: C8C62794 13142995
	v_dual_mul_f32 v21, v150, v21 :: v_dual_mul_f32 v22, v151, v22// 00000017A110: C8C62B96 15162D97
	v_dual_mul_f32 v23, v249, v23 :: v_dual_mul_f32 v24, v250, v24// 00000017A118: C8C62FF9 171831FA
	v_dual_mul_f32 v25, v146, v25 :: v_dual_mul_f32 v26, v147, v26// 00000017A120: C8C63392 191A3593
	v_dual_mul_f32 v27, v148, v27 :: v_dual_mul_f32 v28, v149, v28// 00000017A128: C8C63794 1B1C3995
	v_dual_mul_f32 v29, v150, v29 :: v_dual_mul_f32 v30, v151, v30// 00000017A130: C8C63B96 1D1E3D97
	v_dual_mul_f32 v31, v249, v31 :: v_dual_mul_f32 v32, v250, v32// 00000017A138: C8C63FF9 1F2041FA
	s_waitcnt lgkmcnt(0)                                       // 00000017A140: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[138:145], v[159:166], v[97:104]// 00000017A144: CC414061 1D873F8A
	ds_load_b128 v[163:166], v251 offset:4624                  // 00000017A14C: DBFC1210 A30000FB
	ds_load_b128 v[159:162], v251 offset:4608                  // 00000017A154: DBFC1200 9F0000FB
	v_dual_mul_f32 v9, v146, v9 :: v_dual_mul_f32 v10, v147, v10// 00000017A15C: C8C61392 090A1593
	v_dual_mul_f32 v11, v148, v11 :: v_dual_mul_f32 v12, v149, v12// 00000017A164: C8C61794 0B0C1995
	v_dual_mul_f32 v13, v150, v13 :: v_dual_mul_f32 v14, v151, v14// 00000017A16C: C8C61B96 0D0E1D97
	v_dual_mul_f32 v15, v249, v15 :: v_dual_mul_f32 v16, v250, v16// 00000017A174: C8C61FF9 0F1021FA
	v_dual_mul_f32 v1, v146, v1 :: v_dual_mul_f32 v2, v147, v2 // 00000017A17C: C8C60392 01020593
	v_dual_mul_f32 v3, v148, v3 :: v_dual_mul_f32 v4, v149, v4 // 00000017A184: C8C60794 03040995
	v_dual_mul_f32 v5, v150, v5 :: v_dual_mul_f32 v6, v151, v6 // 00000017A18C: C8C60B96 05060D97
	v_dual_mul_f32 v7, v249, v7 :: v_dual_mul_f32 v8, v250, v8 // 00000017A194: C8C60FF9 070811FA
	s_waitcnt lgkmcnt(0)                                       // 00000017A19C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[138:145], v[159:166], v[57:64]// 00000017A1A0: CC414039 1CE73F8A
	ds_load_b128 v[163:166], v251 offset:5392                  // 00000017A1A8: DBFC1510 A30000FB
	ds_load_b128 v[159:162], v251 offset:5376                  // 00000017A1B0: DBFC1500 9F0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000017A1B8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[138:145], v[159:166], v[81:88]// 00000017A1BC: CC414051 1D473F8A
	ds_load_b128 v[163:166], v251 offset:6160                  // 00000017A1C4: DBFC1810 A30000FB
	ds_load_b128 v[159:162], v251 offset:6144                  // 00000017A1CC: DBFC1800 9F0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000017A1D4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[138:145], v[159:166], v[49:56]// 00000017A1D8: CC414031 1CC73F8A
	ds_load_b128 v[163:166], v251 offset:6928                  // 00000017A1E0: DBFC1B10 A30000FB
	ds_load_b128 v[159:162], v251 offset:6912                  // 00000017A1E8: DBFC1B00 9F0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000017A1F0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[138:145], v[159:166], v[65:72]// 00000017A1F4: CC414041 1D073F8A
	ds_load_b128 v[163:166], v251 offset:7696                  // 00000017A1FC: DBFC1E10 A30000FB
	ds_load_b128 v[159:162], v251 offset:7680                  // 00000017A204: DBFC1E00 9F0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000017A20C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[138:145], v[159:166], v[33:40]// 00000017A210: CC414021 1C873F8A
	ds_load_b128 v[163:166], v251 offset:8464                  // 00000017A218: DBFC2110 A30000FB
	ds_load_b128 v[159:162], v251 offset:8448                  // 00000017A220: DBFC2100 9F0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000017A228: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[138:145], v[159:166], v[41:48]// 00000017A22C: CC414029 1CA73F8A
	ds_load_b128 v[163:166], v251 offset:9232                  // 00000017A234: DBFC2410 A30000FB
	ds_load_b128 v[159:162], v251 offset:9216                  // 00000017A23C: DBFC2400 9F0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000017A244: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[138:145], v[159:166], v[17:24]// 00000017A248: CC414011 1C473F8A
	ds_load_b128 v[163:166], v251 offset:10000                 // 00000017A250: DBFC2710 A30000FB
	ds_load_b128 v[159:162], v251 offset:9984                  // 00000017A258: DBFC2700 9F0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000017A260: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[138:145], v[159:166], v[25:32]// 00000017A264: CC414019 1C673F8A
	ds_load_b128 v[163:166], v251 offset:10768                 // 00000017A26C: DBFC2A10 A30000FB
	ds_load_b128 v[159:162], v251 offset:10752                 // 00000017A274: DBFC2A00 9F0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000017A27C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[138:145], v[159:166], v[9:16]// 00000017A280: CC414009 1C273F8A
	ds_load_b128 v[163:166], v251 offset:11536                 // 00000017A288: DBFC2D10 A30000FB
	ds_load_b128 v[159:162], v251 offset:11520                 // 00000017A290: DBFC2D00 9F0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000017A298: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[138:145], v[159:166], v[1:8]// 00000017A29C: CC414001 1C073F8A
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 00000017A2A4: 917E117E
	s_cbranch_execz 1100                                       // 00000017A2A8: BFA5044C <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1ddc>
	v_lshl_add_u32 v138, v158, 6, v152                         // 00000017A2AC: D646008A 06610D9E
	s_clause 0x1                                               // 00000017A2B4: BF850001
	scratch_load_b128 v[167:170], off, off                     // 00000017A2B8: DC5D0000 A77C0000
	scratch_load_b128 v[171:174], off, off offset:16           // 00000017A2C0: DC5D0010 AB7C0000
	v_mov_b32_e32 v144, v137                                   // 00000017A2C8: 7F200389
	v_mov_b32_e32 v141, v137                                   // 00000017A2CC: 7F1A0389
	v_mov_b32_e32 v142, v137                                   // 00000017A2D0: 7F1C0389
	ds_load_b32 v138, v138                                     // 00000017A2D4: D8D80000 8A00008A
	v_mov_b32_e32 v143, v137                                   // 00000017A2DC: 7F1E0389
	s_mov_b32 s13, 0                                           // 00000017A2E0: BE8D0080
	s_waitcnt lgkmcnt(0)                                       // 00000017A2E4: BF89FC07
	v_and_b32_e32 v140, 0x1ff, v138                            // 00000017A2E8: 371914FF 000001FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017A2F0: BF870091
	v_mad_u64_u32 v[138:139], null, s4, v140, 0                // 00000017A2F4: D6FE7C8A 02031804
	v_mad_u64_u32 v[139:140], null, s5, v140, v[139:140]       // 00000017A2FC: D6FE7C8B 062F1805
	v_mov_b32_e32 v140, v137                                   // 00000017A304: 7F180389
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017A308: BF870092
	.long 0xd73c008a                                           // 00000017A30C: D73C008A
	v_cndmask_b32_e32 v1, 1, v138, vcc_lo                      // 00000017A310: 02031481
	.long 0xd7000192                                           // 00000017A314: D7000192
	v_cndmask_b32_e32 v1, s16, v138, vcc_lo                    // 00000017A318: 02031410
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017A31C: BF870001
	v_add_co_ci_u32_e64 v147, null, s3, v139, s1               // 00000017A320: D5207C93 00071603
	v_mov_b32_e32 v138, v137                                   // 00000017A328: 7F140389
	v_mov_b32_e32 v139, v137                                   // 00000017A32C: 7F160389
	v_mov_b32_e32 v145, v144                                   // 00000017A330: 7F220390
	s_clause 0x1                                               // 00000017A334: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:16     // 00000017A338: DC5E0010 A37C0092
	global_load_b128 v[159:162], v[146:147], off               // 00000017A340: DC5E0000 9F7C0092
	v_mov_b32_e32 v144, v143                                   // 00000017A348: 7F20038F
	v_mov_b32_e32 v143, v142                                   // 00000017A34C: 7F1E038E
	v_mov_b32_e32 v142, v141                                   // 00000017A350: 7F1C038D
	v_mov_b32_e32 v141, v140                                   // 00000017A354: 7F1A038C
	v_mov_b32_e32 v140, v139                                   // 00000017A358: 7F18038B
	v_mov_b32_e32 v139, v138                                   // 00000017A35C: 7F16038A
	v_mov_b32_e32 v138, v137                                   // 00000017A360: 7F140389
	s_waitcnt vmcnt(0)                                         // 00000017A364: BF8903F7
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017A368: BF870001
	v_wmma_f32_16x16x16_bf16 v[138:145], v[167:174], v[159:166], v[138:145]// 00000017A36C: CC41408A 1E2B3FA7
	s_clause 0x1                                               // 00000017A374: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:48     // 00000017A378: DC5E0030 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:32     // 00000017A380: DC5E0020 9F7C0092
	s_clause 0x1                                               // 00000017A388: BF850001
	scratch_load_b128 v[167:170], off, off offset:32           // 00000017A38C: DC5D0020 A77C0000
	scratch_load_b128 v[171:174], off, off offset:48           // 00000017A394: DC5D0030 AB7C0000
	s_waitcnt vmcnt(0)                                         // 00000017A39C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[167:174], v[159:166], v[138:145]// 00000017A3A0: CC41408A 1E2B3FA7
	s_clause 0x1                                               // 00000017A3A8: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:80     // 00000017A3AC: DC5E0050 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:64     // 00000017A3B4: DC5E0040 9F7C0092
	s_clause 0x1                                               // 00000017A3BC: BF850001
	scratch_load_b128 v[167:170], off, off offset:64           // 00000017A3C0: DC5D0040 A77C0000
	scratch_load_b128 v[171:174], off, off offset:80           // 00000017A3C8: DC5D0050 AB7C0000
	s_waitcnt vmcnt(0)                                         // 00000017A3D0: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[167:174], v[159:166], v[138:145]// 00000017A3D4: CC41408A 1E2B3FA7
	s_clause 0x1                                               // 00000017A3DC: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:112    // 00000017A3E0: DC5E0070 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:96     // 00000017A3E8: DC5E0060 9F7C0092
	s_clause 0x1                                               // 00000017A3F0: BF850001
	scratch_load_b128 v[167:170], off, off offset:96           // 00000017A3F4: DC5D0060 A77C0000
	scratch_load_b128 v[171:174], off, off offset:112          // 00000017A3FC: DC5D0070 AB7C0000
	s_waitcnt vmcnt(0)                                         // 00000017A404: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[167:174], v[159:166], v[138:145]// 00000017A408: CC41408A 1E2B3FA7
	s_clause 0x1                                               // 00000017A410: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:144    // 00000017A414: DC5E0090 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:128    // 00000017A41C: DC5E0080 9F7C0092
	s_clause 0x1                                               // 00000017A424: BF850001
	scratch_load_b128 v[167:170], off, off offset:128          // 00000017A428: DC5D0080 A77C0000
	scratch_load_b128 v[171:174], off, off offset:144          // 00000017A430: DC5D0090 AB7C0000
	s_waitcnt vmcnt(0)                                         // 00000017A438: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[167:174], v[159:166], v[138:145]// 00000017A43C: CC41408A 1E2B3FA7
	s_clause 0x1                                               // 00000017A444: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:176    // 00000017A448: DC5E00B0 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:160    // 00000017A450: DC5E00A0 9F7C0092
	s_clause 0x1                                               // 00000017A458: BF850001
	scratch_load_b128 v[167:170], off, off offset:160          // 00000017A45C: DC5D00A0 A77C0000
	scratch_load_b128 v[171:174], off, off offset:176          // 00000017A464: DC5D00B0 AB7C0000
	s_waitcnt vmcnt(0)                                         // 00000017A46C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[167:174], v[159:166], v[138:145]// 00000017A470: CC41408A 1E2B3FA7
	s_clause 0x1                                               // 00000017A478: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:208    // 00000017A47C: DC5E00D0 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:192    // 00000017A484: DC5E00C0 9F7C0092
	s_waitcnt vmcnt(0)                                         // 00000017A48C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[177:184], v[159:166], v[138:145]// 00000017A490: CC41408A 1E2B3FB1
	s_clause 0x1                                               // 00000017A498: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:240    // 00000017A49C: DC5E00F0 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:224    // 00000017A4A4: DC5E00E0 9F7C0092
	s_waitcnt vmcnt(0)                                         // 00000017A4AC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[185:192], v[159:166], v[138:145]// 00000017A4B0: CC41408A 1E2B3FB9
	s_clause 0x1                                               // 00000017A4B8: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:272    // 00000017A4BC: DC5E0110 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:256    // 00000017A4C4: DC5E0100 9F7C0092
	s_waitcnt vmcnt(0)                                         // 00000017A4CC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[193:200], v[159:166], v[138:145]// 00000017A4D0: CC41408A 1E2B3FC1
	s_clause 0x1                                               // 00000017A4D8: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:304    // 00000017A4DC: DC5E0130 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:288    // 00000017A4E4: DC5E0120 9F7C0092
	s_waitcnt vmcnt(0)                                         // 00000017A4EC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[201:208], v[159:166], v[138:145]// 00000017A4F0: CC41408A 1E2B3FC9
	s_clause 0x1                                               // 00000017A4F8: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:336    // 00000017A4FC: DC5E0150 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:320    // 00000017A504: DC5E0140 9F7C0092
	s_waitcnt vmcnt(0)                                         // 00000017A50C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[209:216], v[159:166], v[138:145]// 00000017A510: CC41408A 1E2B3FD1
	s_clause 0x1                                               // 00000017A518: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:368    // 00000017A51C: DC5E0170 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:352    // 00000017A524: DC5E0160 9F7C0092
	s_waitcnt vmcnt(0)                                         // 00000017A52C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[217:224], v[159:166], v[138:145]// 00000017A530: CC41408A 1E2B3FD9
	s_clause 0x1                                               // 00000017A538: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:400    // 00000017A53C: DC5E0190 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:384    // 00000017A544: DC5E0180 9F7C0092
	s_waitcnt vmcnt(0)                                         // 00000017A54C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[225:232], v[159:166], v[138:145]// 00000017A550: CC41408A 1E2B3FE1
	s_clause 0x1                                               // 00000017A558: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:432    // 00000017A55C: DC5E01B0 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:416    // 00000017A564: DC5E01A0 9F7C0092
	s_waitcnt vmcnt(0)                                         // 00000017A56C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[233:240], v[159:166], v[138:145]// 00000017A570: CC41408A 1E2B3FE9
	s_clause 0x1                                               // 00000017A578: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:464    // 00000017A57C: DC5E01D0 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:448    // 00000017A584: DC5E01C0 9F7C0092
	s_waitcnt vmcnt(0)                                         // 00000017A58C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[241:248], v[159:166], v[138:145]// 00000017A590: CC41408A 1E2B3FF1
	s_clause 0x1                                               // 00000017A598: BF850001
	global_load_b128 v[163:166], v[146:147], off offset:496    // 00000017A59C: DC5E01F0 A37C0092
	global_load_b128 v[159:162], v[146:147], off offset:480    // 00000017A5A4: DC5E01E0 9F7C0092
	s_waitcnt vmcnt(0)                                         // 00000017A5AC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[138:145], v[129:136], v[159:166], v[138:145]// 00000017A5B0: CC41408A 1E2B3F81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000017A5B8: BF870111
	v_dual_mul_f32 v138, 0x3d800000, v138 :: v_dual_mul_f32 v139, 0x3d800000, v139// 00000017A5BC: C8C714FF 8A8B16FF 3D800000
	v_dual_mul_f32 v140, 0x3d800000, v140 :: v_dual_mul_f32 v141, 0x3d800000, v141// 00000017A5C8: C8C718FF 8C8D1AFF 3D800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000017A5D4: BF870213
	v_dual_mul_f32 v142, 0x3d800000, v142 :: v_dual_mul_f32 v143, 0x3d800000, v143// 00000017A5D8: C8C71CFF 8E8F1EFF 3D800000
	v_dual_mul_f32 v144, 0x3d800000, v144 :: v_dual_mul_f32 v145, 0x3d800000, v145// 00000017A5E4: C8C720FF 909122FF 3D800000
	ds_store_2addr_b32 v253, v138, v139 offset1:34             // 00000017A5F0: D8382200 008B8AFD
	ds_store_2addr_b32 v253, v140, v141 offset0:68 offset1:102 // 00000017A5F8: D8386644 008D8CFD
	ds_store_2addr_b32 v253, v142, v143 offset0:136 offset1:170// 00000017A600: D838AA88 008F8EFD
	ds_store_2addr_b32 v253, v144, v145 offset0:204 offset1:238// 00000017A608: D838EECC 009190FD
	s_and_saveexec_b32 s1, vcc_lo                              // 00000017A610: BE81206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017A614: BF870009
	s_xor_b32 s1, exec_lo, s1                                  // 00000017A618: 8D01017E
	s_cbranch_execnz 8                                         // 00000017A61C: BFA60008 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1040>
	s_or_saveexec_b32 s14, s1                                  // 00000017A620: BE8E2201
	v_mov_b32_e32 v139, 1.0                                    // 00000017A624: 7F1602F2
	s_xor_b32 exec_lo, exec_lo, s14                            // 00000017A628: 8D7E0E7E
	s_cbranch_execnz 29                                        // 00000017A62C: BFA6001D <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x10a4>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000017A630: 8C7E0E7E
	s_and_saveexec_b32 s1, s13                                 // 00000017A634: BE81200D
	s_cbranch_execz 65043                                      // 00000017A638: BFA5FE13 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x888>
	s_branch 865                                               // 00000017A63C: BFA00361 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1dc4>
	s_mov_b32 s2, 0                                            // 00000017A640: BE820080
	s_and_saveexec_b32 s13, s0                                 // 00000017A644: BE8D2000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017A648: BF870009
	s_xor_b32 s21, exec_lo, s13                                // 00000017A64C: 8D150D7E
	s_cbranch_execz 13                                         // 00000017A650: BFA5000D <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1088>
	s_mov_b32 s15, s12                                         // 00000017A654: BE8F000C
	s_mov_b32 s13, s12                                         // 00000017A658: BE8D000C
	s_mov_b32 s14, s12                                         // 00000017A65C: BE8E000C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017A660: BF870009
	v_dual_mov_b32 v141, s15 :: v_dual_mov_b32 v140, s14       // 00000017A664: CA10000F 8D8C000E
	v_dual_mov_b32 v139, s13 :: v_dual_mov_b32 v138, s12       // 00000017A66C: CA10000D 8B8A000C
	s_mov_b32 s2, exec_lo                                      // 00000017A674: BE82007E
	ds_store_b128 v154, v[138:141]                             // 00000017A678: DB7C0000 00008A9A
	ds_store_b128 v154, v[138:141] offset:16                   // 00000017A680: DB7C0010 00008A9A
	s_or_b32 exec_lo, exec_lo, s21                             // 00000017A688: 8C7E157E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017A68C: BF870009
	s_and_b32 s13, s2, exec_lo                                 // 00000017A690: 8B0D7E02
	s_or_saveexec_b32 s14, s1                                  // 00000017A694: BE8E2201
	v_mov_b32_e32 v139, 1.0                                    // 00000017A698: 7F1602F2
	s_xor_b32 exec_lo, exec_lo, s14                            // 00000017A69C: 8D7E0E7E
	s_cbranch_execz 65507                                      // 00000017A6A0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1030>
	v_lshlrev_b32_e32 v138, 4, v158                            // 00000017A6A4: 31153C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017A6A8: BF870121
	v_sub_nc_u32_e32 v139, v175, v138                          // 00000017A6AC: 4D1715AF
	v_mov_b32_e32 v138, v255                                   // 00000017A6B0: 7F1403FF
	.long 0xd4410001                                           // 00000017A6B4: D4410001
	v_cndmask_b32_e32 v1, 0, v139, vcc_lo                      // 00000017A6B8: 02031680
	s_and_saveexec_b32 s15, s1                                 // 00000017A6BC: BE8F2001
	s_cbranch_execz 22                                         // 00000017A6C0: BFA50016 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x111c>
	v_med3_i32 v138, v156, 1, 16                               // 00000017A6C4: D620008A 0241039C
	v_mov_b32_e32 v140, v157                                   // 00000017A6CC: 7F18039D
	s_mov_b32 s21, 0                                           // 00000017A6D0: BE950080
	s_delay_alu instid0(VALU_DEP_2)                            // 00000017A6D4: BF870002
	v_dual_mov_b32 v138, v255 :: v_dual_lshlrev_b32 v141, 2, v138// 00000017A6D8: CA2201FF 8A8D1482
	ds_load_b32 v142, v140 offset:59472                        // 00000017A6E0: D8D8E850 8E00008C
	v_dual_max_f32 v138, v138, v138 :: v_dual_add_nc_u32 v141, -4, v141// 00000017A6E8: CAA1158A 8A8D1AC4
	v_add_nc_u32_e32 v140, 4, v140                             // 00000017A6F0: 4B191884
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000017A6F4: BF8700C2
	.long 0xd44a0002                                           // 00000017A6F8: D44A0002
	v_cndmask_b32_e32 v1, 0, v141, vcc_lo                      // 00000017A6FC: 02031A80
	s_or_b32 s21, s2, s21                                      // 00000017A700: 8C151502
	s_waitcnt lgkmcnt(0)                                       // 00000017A704: BF89FC07
	v_max_f32_e32 v142, v142, v142                             // 00000017A708: 211D1D8E
	v_max_f32_e32 v138, v138, v142                             // 00000017A70C: 21151D8A
	s_and_not1_b32 exec_lo, exec_lo, s21                       // 00000017A710: 917E157E
	s_cbranch_execnz 65522                                     // 00000017A714: BFA6FFF2 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x10e0>
	s_or_b32 exec_lo, exec_lo, s21                             // 00000017A718: 8C7E157E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017A71C: BF870009
	s_or_b32 exec_lo, exec_lo, s15                             // 00000017A720: 8C7E0F7E
	v_dual_mov_b32 v140, 0 :: v_dual_mov_b32 v141, 0           // 00000017A724: CA100080 8C8C0080
	s_and_saveexec_b32 s2, s1                                  // 00000017A72C: BE822001
	s_cbranch_execz 33                                         // 00000017A730: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x11b8>
	ds_load_b32 v141, v254                                     // 00000017A734: D8D80000 8D0000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017A73C: BF89FC07
	v_sub_f32_e32 v141, v141, v138                             // 00000017A740: 091B158D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017A744: BF870091
	v_mul_f32_e32 v142, 0x3fb8aa3b, v141                       // 00000017A748: 111D1AFF 3FB8AA3B
	v_fma_f32 v143, 0x3fb8aa3b, v141, -v142                    // 00000017A750: D613008F 863B1AFF 3FB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000017A75C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017A760: BF870121
	v_dual_sub_f32 v142, v142, v144 :: v_dual_fmac_f32 v143, 0x32a5705f, v141// 00000017A764: C941218E 8E8F1AFF 32A5705F
	.long 0xd41b0001                                           // 00000017A770: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v141, vcc_lo             // 00000017A774: 02031AFF C2CE8ED0
	v_add_f32_e32 v142, v142, v143                             // 00000017A77C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000017A780: 7F1E1190
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017A784: BF870292
	v_exp_f32_e32 v142, v142                                   // 00000017A788: 7F1C4B8E
	.long 0xd71c008e                                           // 00000017A78C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000017A790: 02031F8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017A794: BF8700A1
	v_cndmask_b32_e64 v142, 0, v142, s1                        // 00000017A798: D501008E 00071C80
	.long 0xd41e0001                                           // 00000017A7A0: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v141, vcc_lo             // 00000017A7A4: 02031AFF 42B17218
	v_cndmask_b32_e64 v141, 0x7f800000, v142, s1               // 00000017A7AC: D501008D 00071CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017A7B8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017A7BC: BF8700A1
	v_bfe_u32 v142, v141, 16, 1                                // 00000017A7C0: D610008E 0205218D
	s_mov_b32 s2, exec_lo                                      // 00000017A7C8: BE82007E
	v_add3_u32 v142, v141, v142, 0x7fff                        // 00000017A7CC: D655008E 03FF1D8D 00007FFF
	ds_store_b16_d16_hi v154, v142                             // 00000017A7D8: DA840000 00008E9A
	v_cmpx_lt_i32_e32 1, v139                                  // 00000017A7E0: 7D831681
	s_cbranch_execz 34                                         // 00000017A7E4: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1270>
	ds_load_b32 v140, v254 offset:4                            // 00000017A7E8: D8D80004 8C0000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017A7F0: BF89FC07
	v_sub_f32_e32 v140, v140, v138                             // 00000017A7F4: 0919158C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017A7F8: BF870121
	v_mul_f32_e32 v142, 0x3fb8aa3b, v140                       // 00000017A7FC: 111D18FF 3FB8AA3B
	.long 0xd41b0001                                           // 00000017A804: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v140, vcc_lo             // 00000017A808: 020318FF C2CE8ED0
	v_fma_f32 v143, 0x3fb8aa3b, v140, -v142                    // 00000017A810: D613008F 863B18FF 3FB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000017A81C: 7F20478E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000017A820: BF870112
	v_fmac_f32_e32 v143, 0x32a5705f, v140                      // 00000017A824: 571F18FF 32A5705F
	v_sub_f32_e32 v142, v142, v144                             // 00000017A82C: 091D218E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017A830: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000017A834: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000017A838: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000017A83C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017A840: BF870095
	.long 0xd71c008e                                           // 00000017A844: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000017A848: 02031F8E
	v_cndmask_b32_e64 v142, 0, v142, s1                        // 00000017A84C: D501008E 00071C80
	.long 0xd41e0001                                           // 00000017A854: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v140, vcc_lo             // 00000017A858: 020318FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017A860: BF870001
	v_cndmask_b32_e64 v140, 0x7f800000, v142, s1               // 00000017A864: D501008C 00071CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017A870: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000017A874: BF870131
	v_bfe_u32 v142, v140, 16, 1                                // 00000017A878: D610008E 0205218C
	s_mov_b32 s2, exec_lo                                      // 00000017A880: BE82007E
	v_mov_b32_e32 v143, 0                                      // 00000017A884: 7F1E0280
	v_add3_u32 v144, v140, v142, 0x7fff                        // 00000017A888: D6550090 03FF1D8C 00007FFF
	v_mov_b32_e32 v142, 0                                      // 00000017A894: 7F1C0280
	ds_store_b16_d16_hi v154, v144 offset:2                    // 00000017A898: DA840002 0000909A
	v_cmpx_lt_i32_e32 2, v139                                  // 00000017A8A0: 7D831682
	s_cbranch_execz 33                                         // 00000017A8A4: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x132c>
	ds_load_b32 v143, v254 offset:8                            // 00000017A8A8: D8D80008 8F0000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017A8B0: BF89FC07
	v_sub_f32_e32 v143, v143, v138                             // 00000017A8B4: 091F158F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017A8B8: BF870091
	v_mul_f32_e32 v144, 0x3fb8aa3b, v143                       // 00000017A8BC: 11211EFF 3FB8AA3B
	v_fma_f32 v145, 0x3fb8aa3b, v143, -v144                    // 00000017A8C4: D6130091 86431EFF 3FB8AA3B
	v_rndne_f32_e32 v146, v144                                 // 00000017A8D0: 7F244790
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017A8D4: BF870091
	v_dual_fmac_f32 v145, 0x32a5705f, v143 :: v_dual_sub_f32 v144, v144, v146// 00000017A8D8: C80B1EFF 91912590 32A5705F
	v_add_f32_e32 v144, v144, v145                             // 00000017A8E4: 07212390
	v_cvt_i32_f32_e32 v145, v146                               // 00000017A8E8: 7F221192
	.long 0xd41b0001                                           // 00000017A8EC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v143, vcc_lo             // 00000017A8F0: 02031EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017A8F8: BF870293
	v_exp_f32_e32 v144, v144                                   // 00000017A8FC: 7F204B90
	.long 0xd71c0090                                           // 00000017A900: D71C0090
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                   // 00000017A904: 02032390
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017A908: BF8700A1
	v_cndmask_b32_e64 v144, 0, v144, s1                        // 00000017A90C: D5010090 00072080
	.long 0xd41e0001                                           // 00000017A914: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v143, vcc_lo             // 00000017A918: 02031EFF 42B17218
	v_cndmask_b32_e64 v143, 0x7f800000, v144, s1               // 00000017A920: D501008F 000720FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017A92C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017A930: BF8700A1
	v_bfe_u32 v144, v143, 16, 1                                // 00000017A934: D6100090 0205218F
	s_mov_b32 s2, exec_lo                                      // 00000017A93C: BE82007E
	v_add3_u32 v144, v143, v144, 0x7fff                        // 00000017A940: D6550090 03FF218F 00007FFF
	ds_store_b16_d16_hi v154, v144 offset:4                    // 00000017A94C: DA840004 0000909A
	v_cmpx_lt_i32_e32 3, v139                                  // 00000017A954: 7D831683
	s_cbranch_execz 34                                         // 00000017A958: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x13e4>
	ds_load_b32 v142, v254 offset:12                           // 00000017A95C: D8D8000C 8E0000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017A964: BF89FC07
	v_sub_f32_e32 v142, v142, v138                             // 00000017A968: 091D158E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017A96C: BF870121
	v_mul_f32_e32 v144, 0x3fb8aa3b, v142                       // 00000017A970: 11211CFF 3FB8AA3B
	.long 0xd41b0001                                           // 00000017A978: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v142, vcc_lo             // 00000017A97C: 02031CFF C2CE8ED0
	v_fma_f32 v145, 0x3fb8aa3b, v142, -v144                    // 00000017A984: D6130091 86431CFF 3FB8AA3B
	v_rndne_f32_e32 v146, v144                                 // 00000017A990: 7F244790
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000017A994: BF870112
	v_fmac_f32_e32 v145, 0x32a5705f, v142                      // 00000017A998: 57231CFF 32A5705F
	v_sub_f32_e32 v144, v144, v146                             // 00000017A9A0: 09212590
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017A9A4: BF870121
	v_add_f32_e32 v144, v144, v145                             // 00000017A9A8: 07212390
	v_cvt_i32_f32_e32 v145, v146                               // 00000017A9AC: 7F221192
	v_exp_f32_e32 v144, v144                                   // 00000017A9B0: 7F204B90
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017A9B4: BF870095
	.long 0xd71c0090                                           // 00000017A9B8: D71C0090
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                   // 00000017A9BC: 02032390
	v_cndmask_b32_e64 v144, 0, v144, s1                        // 00000017A9C0: D5010090 00072080
	.long 0xd41e0001                                           // 00000017A9C8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v142, vcc_lo             // 00000017A9CC: 02031CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017A9D4: BF870001
	v_cndmask_b32_e64 v142, 0x7f800000, v144, s1               // 00000017A9D8: D501008E 000720FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017A9E4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000017A9E8: BF870131
	v_bfe_u32 v144, v142, 16, 1                                // 00000017A9EC: D6100090 0205218E
	s_mov_b32 s2, exec_lo                                      // 00000017A9F4: BE82007E
	v_mov_b32_e32 v145, 0                                      // 00000017A9F8: 7F220280
	v_add3_u32 v146, v142, v144, 0x7fff                        // 00000017A9FC: D6550092 03FF218E 00007FFF
	v_mov_b32_e32 v144, 0                                      // 00000017AA08: 7F200280
	ds_store_b16_d16_hi v154, v146 offset:6                    // 00000017AA0C: DA840006 0000929A
	v_cmpx_lt_i32_e32 4, v139                                  // 00000017AA14: 7D831684
	s_cbranch_execz 33                                         // 00000017AA18: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x14a0>
	ds_load_b32 v145, v254 offset:16                           // 00000017AA1C: D8D80010 910000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017AA24: BF89FC07
	v_sub_f32_e32 v145, v145, v138                             // 00000017AA28: 09231591
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017AA2C: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v145                       // 00000017AA30: 112522FF 3FB8AA3B
	v_fma_f32 v147, 0x3fb8aa3b, v145, -v146                    // 00000017AA38: D6130093 864B22FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 00000017AA44: 7F284792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017AA48: BF870121
	v_dual_sub_f32 v146, v146, v148 :: v_dual_fmac_f32 v147, 0x32a5705f, v145// 00000017AA4C: C9412992 929322FF 32A5705F
	.long 0xd41b0001                                           // 00000017AA58: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v145, vcc_lo             // 00000017AA5C: 020322FF C2CE8ED0
	v_add_f32_e32 v146, v146, v147                             // 00000017AA64: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 00000017AA68: 7F261194
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017AA6C: BF870292
	v_exp_f32_e32 v146, v146                                   // 00000017AA70: 7F244B92
	.long 0xd71c0092                                           // 00000017AA74: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 00000017AA78: 02032792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017AA7C: BF8700A1
	v_cndmask_b32_e64 v146, 0, v146, s1                        // 00000017AA80: D5010092 00072480
	.long 0xd41e0001                                           // 00000017AA88: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v145, vcc_lo             // 00000017AA8C: 020322FF 42B17218
	v_cndmask_b32_e64 v145, 0x7f800000, v146, s1               // 00000017AA94: D5010091 000724FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017AAA0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017AAA4: BF8700A1
	v_bfe_u32 v146, v145, 16, 1                                // 00000017AAA8: D6100092 02052191
	s_mov_b32 s2, exec_lo                                      // 00000017AAB0: BE82007E
	v_add3_u32 v146, v145, v146, 0x7fff                        // 00000017AAB4: D6550092 03FF2591 00007FFF
	ds_store_b16_d16_hi v154, v146 offset:8                    // 00000017AAC0: DA840008 0000929A
	v_cmpx_lt_i32_e32 5, v139                                  // 00000017AAC8: 7D831685
	s_cbranch_execz 34                                         // 00000017AACC: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1558>
	ds_load_b32 v144, v254 offset:20                           // 00000017AAD0: D8D80014 900000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017AAD8: BF89FC07
	v_sub_f32_e32 v144, v144, v138                             // 00000017AADC: 09211590
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017AAE0: BF870121
	v_mul_f32_e32 v146, 0x3fb8aa3b, v144                       // 00000017AAE4: 112520FF 3FB8AA3B
	.long 0xd41b0001                                           // 00000017AAEC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v144, vcc_lo             // 00000017AAF0: 020320FF C2CE8ED0
	v_fma_f32 v147, 0x3fb8aa3b, v144, -v146                    // 00000017AAF8: D6130093 864B20FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 00000017AB04: 7F284792
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000017AB08: BF870112
	v_fmac_f32_e32 v147, 0x32a5705f, v144                      // 00000017AB0C: 572720FF 32A5705F
	v_sub_f32_e32 v146, v146, v148                             // 00000017AB14: 09252992
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017AB18: BF870121
	v_add_f32_e32 v146, v146, v147                             // 00000017AB1C: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 00000017AB20: 7F261194
	v_exp_f32_e32 v146, v146                                   // 00000017AB24: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017AB28: BF870095
	.long 0xd71c0092                                           // 00000017AB2C: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 00000017AB30: 02032792
	v_cndmask_b32_e64 v146, 0, v146, s1                        // 00000017AB34: D5010092 00072480
	.long 0xd41e0001                                           // 00000017AB3C: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v144, vcc_lo             // 00000017AB40: 020320FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017AB48: BF870001
	v_cndmask_b32_e64 v144, 0x7f800000, v146, s1               // 00000017AB4C: D5010090 000724FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017AB58: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000017AB5C: BF870131
	v_bfe_u32 v146, v144, 16, 1                                // 00000017AB60: D6100092 02052190
	s_mov_b32 s2, exec_lo                                      // 00000017AB68: BE82007E
	v_mov_b32_e32 v147, 0                                      // 00000017AB6C: 7F260280
	v_add3_u32 v148, v144, v146, 0x7fff                        // 00000017AB70: D6550094 03FF2590 00007FFF
	v_mov_b32_e32 v146, 0                                      // 00000017AB7C: 7F240280
	ds_store_b16_d16_hi v154, v148 offset:10                   // 00000017AB80: DA84000A 0000949A
	v_cmpx_lt_i32_e32 6, v139                                  // 00000017AB88: 7D831686
	s_cbranch_execz 33                                         // 00000017AB8C: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1614>
	ds_load_b32 v147, v254 offset:24                           // 00000017AB90: D8D80018 930000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017AB98: BF89FC07
	v_sub_f32_e32 v147, v147, v138                             // 00000017AB9C: 09271593
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017ABA0: BF870091
	v_mul_f32_e32 v148, 0x3fb8aa3b, v147                       // 00000017ABA4: 112926FF 3FB8AA3B
	v_fma_f32 v149, 0x3fb8aa3b, v147, -v148                    // 00000017ABAC: D6130095 865326FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 00000017ABB8: 7F2C4794
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017ABBC: BF870091
	v_dual_fmac_f32 v149, 0x32a5705f, v147 :: v_dual_sub_f32 v148, v148, v150// 00000017ABC0: C80B26FF 95952D94 32A5705F
	v_add_f32_e32 v148, v148, v149                             // 00000017ABCC: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 00000017ABD0: 7F2A1196
	.long 0xd41b0001                                           // 00000017ABD4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v147, vcc_lo             // 00000017ABD8: 020326FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017ABE0: BF870293
	v_exp_f32_e32 v148, v148                                   // 00000017ABE4: 7F284B94
	.long 0xd71c0094                                           // 00000017ABE8: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 00000017ABEC: 02032B94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017ABF0: BF8700A1
	v_cndmask_b32_e64 v148, 0, v148, s1                        // 00000017ABF4: D5010094 00072880
	.long 0xd41e0001                                           // 00000017ABFC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v147, vcc_lo             // 00000017AC00: 020326FF 42B17218
	v_cndmask_b32_e64 v147, 0x7f800000, v148, s1               // 00000017AC08: D5010093 000728FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017AC14: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017AC18: BF8700A1
	v_bfe_u32 v148, v147, 16, 1                                // 00000017AC1C: D6100094 02052193
	s_mov_b32 s2, exec_lo                                      // 00000017AC24: BE82007E
	v_add3_u32 v148, v147, v148, 0x7fff                        // 00000017AC28: D6550094 03FF2993 00007FFF
	ds_store_b16_d16_hi v154, v148 offset:12                   // 00000017AC34: DA84000C 0000949A
	v_cmpx_lt_i32_e32 7, v139                                  // 00000017AC3C: 7D831687
	s_cbranch_execz 34                                         // 00000017AC40: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x16cc>
	ds_load_b32 v146, v254 offset:28                           // 00000017AC44: D8D8001C 920000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017AC4C: BF89FC07
	v_sub_f32_e32 v146, v146, v138                             // 00000017AC50: 09251592
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017AC54: BF870121
	v_mul_f32_e32 v148, 0x3fb8aa3b, v146                       // 00000017AC58: 112924FF 3FB8AA3B
	.long 0xd41b0001                                           // 00000017AC60: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v146, vcc_lo             // 00000017AC64: 020324FF C2CE8ED0
	v_fma_f32 v149, 0x3fb8aa3b, v146, -v148                    // 00000017AC6C: D6130095 865324FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 00000017AC78: 7F2C4794
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000017AC7C: BF870112
	v_fmac_f32_e32 v149, 0x32a5705f, v146                      // 00000017AC80: 572B24FF 32A5705F
	v_sub_f32_e32 v148, v148, v150                             // 00000017AC88: 09292D94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017AC8C: BF870121
	v_add_f32_e32 v148, v148, v149                             // 00000017AC90: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 00000017AC94: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 00000017AC98: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017AC9C: BF870095
	.long 0xd71c0094                                           // 00000017ACA0: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 00000017ACA4: 02032B94
	v_cndmask_b32_e64 v148, 0, v148, s1                        // 00000017ACA8: D5010094 00072880
	.long 0xd41e0001                                           // 00000017ACB0: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v146, vcc_lo             // 00000017ACB4: 020324FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017ACBC: BF870001
	v_cndmask_b32_e64 v146, 0x7f800000, v148, s1               // 00000017ACC0: D5010092 000728FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017ACCC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000017ACD0: BF870131
	v_bfe_u32 v148, v146, 16, 1                                // 00000017ACD4: D6100094 02052192
	s_mov_b32 s2, exec_lo                                      // 00000017ACDC: BE82007E
	v_mov_b32_e32 v149, 0                                      // 00000017ACE0: 7F2A0280
	v_add3_u32 v150, v146, v148, 0x7fff                        // 00000017ACE4: D6550096 03FF2992 00007FFF
	v_mov_b32_e32 v148, 0                                      // 00000017ACF0: 7F280280
	ds_store_b16_d16_hi v154, v150 offset:14                   // 00000017ACF4: DA84000E 0000969A
	v_cmpx_lt_i32_e32 8, v139                                  // 00000017ACFC: 7D831688
	s_cbranch_execz 33                                         // 00000017AD00: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1788>
	ds_load_b32 v149, v254 offset:32                           // 00000017AD04: D8D80020 950000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017AD0C: BF89FC07
	v_sub_f32_e32 v149, v149, v138                             // 00000017AD10: 092B1595
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017AD14: BF870091
	v_mul_f32_e32 v150, 0x3fb8aa3b, v149                       // 00000017AD18: 112D2AFF 3FB8AA3B
	v_fma_f32 v151, 0x3fb8aa3b, v149, -v150                    // 00000017AD20: D6130097 865B2AFF 3FB8AA3B
	v_rndne_f32_e32 v159, v150                                 // 00000017AD2C: 7F3E4796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017AD30: BF870121
	v_dual_sub_f32 v150, v150, v159 :: v_dual_fmac_f32 v151, 0x32a5705f, v149// 00000017AD34: C9413F96 96972AFF 32A5705F
	.long 0xd41b0001                                           // 00000017AD40: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v149, vcc_lo             // 00000017AD44: 02032AFF C2CE8ED0
	v_add_f32_e32 v150, v150, v151                             // 00000017AD4C: 072D2F96
	v_cvt_i32_f32_e32 v151, v159                               // 00000017AD50: 7F2E119F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017AD54: BF870292
	v_exp_f32_e32 v150, v150                                   // 00000017AD58: 7F2C4B96
	.long 0xd71c0096                                           // 00000017AD5C: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 00000017AD60: 02032F96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017AD64: BF8700A1
	v_cndmask_b32_e64 v150, 0, v150, s1                        // 00000017AD68: D5010096 00072C80
	.long 0xd41e0001                                           // 00000017AD70: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v149, vcc_lo             // 00000017AD74: 02032AFF 42B17218
	v_cndmask_b32_e64 v149, 0x7f800000, v150, s1               // 00000017AD7C: D5010095 00072CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017AD88: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017AD8C: BF8700A1
	v_bfe_u32 v150, v149, 16, 1                                // 00000017AD90: D6100096 02052195
	s_mov_b32 s2, exec_lo                                      // 00000017AD98: BE82007E
	v_add3_u32 v150, v149, v150, 0x7fff                        // 00000017AD9C: D6550096 03FF2D95 00007FFF
	ds_store_b16_d16_hi v154, v150 offset:16                   // 00000017ADA8: DA840010 0000969A
	v_cmpx_lt_i32_e32 9, v139                                  // 00000017ADB0: 7D831689
	s_cbranch_execz 33                                         // 00000017ADB4: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x183c>
	ds_load_b32 v148, v254 offset:36                           // 00000017ADB8: D8D80024 940000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017ADC0: BF89FC07
	v_sub_f32_e32 v148, v148, v138                             // 00000017ADC4: 09291594
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017ADC8: BF870121
	v_mul_f32_e32 v150, 0x3fb8aa3b, v148                       // 00000017ADCC: 112D28FF 3FB8AA3B
	.long 0xd41b0001                                           // 00000017ADD4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v148, vcc_lo             // 00000017ADD8: 020328FF C2CE8ED0
	v_fma_f32 v151, 0x3fb8aa3b, v148, -v150                    // 00000017ADE0: D6130097 865B28FF 3FB8AA3B
	v_rndne_f32_e32 v159, v150                                 // 00000017ADEC: 7F3E4796
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017ADF0: BF870091
	v_dual_fmac_f32 v151, 0x32a5705f, v148 :: v_dual_sub_f32 v150, v150, v159// 00000017ADF4: C80B28FF 97973F96 32A5705F
	v_add_f32_e32 v150, v150, v151                             // 00000017AE00: 072D2F96
	v_cvt_i32_f32_e32 v151, v159                               // 00000017AE04: 7F2E119F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017AE08: BF870292
	v_exp_f32_e32 v150, v150                                   // 00000017AE0C: 7F2C4B96
	.long 0xd71c0096                                           // 00000017AE10: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 00000017AE14: 02032F96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017AE18: BF8700A1
	v_cndmask_b32_e64 v150, 0, v150, s1                        // 00000017AE1C: D5010096 00072C80
	.long 0xd41e0001                                           // 00000017AE24: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v148, vcc_lo             // 00000017AE28: 020328FF 42B17218
	v_cndmask_b32_e64 v148, 0x7f800000, v150, s1               // 00000017AE30: D5010094 00072CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017AE3C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000017AE40: BF870131
	v_bfe_u32 v150, v148, 16, 1                                // 00000017AE44: D6100096 02052194
	s_mov_b32 s2, exec_lo                                      // 00000017AE4C: BE82007E
	v_mov_b32_e32 v151, 0                                      // 00000017AE50: 7F2E0280
	v_add3_u32 v159, v148, v150, 0x7fff                        // 00000017AE54: D655009F 03FF2D94 00007FFF
	v_mov_b32_e32 v150, 0                                      // 00000017AE60: 7F2C0280
	ds_store_b16_d16_hi v154, v159 offset:18                   // 00000017AE64: DA840012 00009F9A
	v_cmpx_lt_i32_e32 10, v139                                 // 00000017AE6C: 7D83168A
	s_cbranch_execz 33                                         // 00000017AE70: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x18f8>
	ds_load_b32 v151, v254 offset:40                           // 00000017AE74: D8D80028 970000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017AE7C: BF89FC07
	v_sub_f32_e32 v151, v151, v138                             // 00000017AE80: 092F1597
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017AE84: BF870121
	v_mul_f32_e32 v159, 0x3fb8aa3b, v151                       // 00000017AE88: 113F2EFF 3FB8AA3B
	.long 0xd41b0001                                           // 00000017AE90: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v151, vcc_lo             // 00000017AE94: 02032EFF C2CE8ED0
	v_fma_f32 v160, 0x3fb8aa3b, v151, -v159                    // 00000017AE9C: D61300A0 867F2EFF 3FB8AA3B
	v_rndne_f32_e32 v161, v159                                 // 00000017AEA8: 7F42479F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017AEAC: BF870091
	v_dual_fmac_f32 v160, 0x32a5705f, v151 :: v_dual_sub_f32 v159, v159, v161// 00000017AEB0: C80B2EFF A09F439F 32A5705F
	v_add_f32_e32 v159, v159, v160                             // 00000017AEBC: 073F419F
	v_cvt_i32_f32_e32 v160, v161                               // 00000017AEC0: 7F4011A1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017AEC4: BF870292
	v_exp_f32_e32 v159, v159                                   // 00000017AEC8: 7F3E4B9F
	.long 0xd71c009f                                           // 00000017AECC: D71C009F
	v_cndmask_b32_e32 v1, v159, v160, vcc_lo                   // 00000017AED0: 0203419F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017AED4: BF8700A1
	v_cndmask_b32_e64 v159, 0, v159, s1                        // 00000017AED8: D501009F 00073E80
	.long 0xd41e0001                                           // 00000017AEE0: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v151, vcc_lo             // 00000017AEE4: 02032EFF 42B17218
	v_cndmask_b32_e64 v151, 0x7f800000, v159, s1               // 00000017AEEC: D5010097 00073EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017AEF8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017AEFC: BF8700A1
	v_bfe_u32 v159, v151, 16, 1                                // 00000017AF00: D610009F 02052197
	s_mov_b32 s2, exec_lo                                      // 00000017AF08: BE82007E
	v_add3_u32 v159, v151, v159, 0x7fff                        // 00000017AF0C: D655009F 03FF3F97 00007FFF
	ds_store_b16_d16_hi v154, v159 offset:20                   // 00000017AF18: DA840014 00009F9A
	v_cmpx_lt_i32_e32 11, v139                                 // 00000017AF20: 7D83168B
	s_cbranch_execz 33                                         // 00000017AF24: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x19ac>
	ds_load_b32 v150, v254 offset:44                           // 00000017AF28: D8D8002C 960000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017AF30: BF89FC07
	v_sub_f32_e32 v150, v150, v138                             // 00000017AF34: 092D1596
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017AF38: BF870091
	v_mul_f32_e32 v159, 0x3fb8aa3b, v150                       // 00000017AF3C: 113F2CFF 3FB8AA3B
	v_fma_f32 v160, 0x3fb8aa3b, v150, -v159                    // 00000017AF44: D61300A0 867F2CFF 3FB8AA3B
	v_rndne_f32_e32 v161, v159                                 // 00000017AF50: 7F42479F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017AF54: BF870121
	v_dual_sub_f32 v159, v159, v161 :: v_dual_fmac_f32 v160, 0x32a5705f, v150// 00000017AF58: C941439F 9FA12CFF 32A5705F
	.long 0xd41b0001                                           // 00000017AF64: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v150, vcc_lo             // 00000017AF68: 02032CFF C2CE8ED0
	v_add_f32_e32 v159, v159, v160                             // 00000017AF70: 073F419F
	v_cvt_i32_f32_e32 v160, v161                               // 00000017AF74: 7F4011A1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017AF78: BF870292
	v_exp_f32_e32 v159, v159                                   // 00000017AF7C: 7F3E4B9F
	.long 0xd71c009f                                           // 00000017AF80: D71C009F
	v_cndmask_b32_e32 v1, v159, v160, vcc_lo                   // 00000017AF84: 0203419F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017AF88: BF8700A1
	v_cndmask_b32_e64 v159, 0, v159, s1                        // 00000017AF8C: D501009F 00073E80
	.long 0xd41e0001                                           // 00000017AF94: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v150, vcc_lo             // 00000017AF98: 02032CFF 42B17218
	v_cndmask_b32_e64 v150, 0x7f800000, v159, s1               // 00000017AFA0: D5010096 00073EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017AFAC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000017AFB0: BF870131
	v_bfe_u32 v159, v150, 16, 1                                // 00000017AFB4: D610009F 02052196
	s_mov_b32 s2, exec_lo                                      // 00000017AFBC: BE82007E
	v_mov_b32_e32 v160, 0                                      // 00000017AFC0: 7F400280
	v_add3_u32 v161, v150, v159, 0x7fff                        // 00000017AFC4: D65500A1 03FF3F96 00007FFF
	v_mov_b32_e32 v159, 0                                      // 00000017AFD0: 7F3E0280
	ds_store_b16_d16_hi v154, v161 offset:22                   // 00000017AFD4: DA840016 0000A19A
	v_cmpx_lt_i32_e32 12, v139                                 // 00000017AFDC: 7D83168C
	s_cbranch_execz 33                                         // 00000017AFE0: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1a68>
	ds_load_b32 v160, v254 offset:48                           // 00000017AFE4: D8D80030 A00000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017AFEC: BF89FC07
	v_sub_f32_e32 v160, v160, v138                             // 00000017AFF0: 094115A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017AFF4: BF870091
	v_mul_f32_e32 v161, 0x3fb8aa3b, v160                       // 00000017AFF8: 114340FF 3FB8AA3B
	v_fma_f32 v162, 0x3fb8aa3b, v160, -v161                    // 00000017B000: D61300A2 868740FF 3FB8AA3B
	v_rndne_f32_e32 v163, v161                                 // 00000017B00C: 7F4647A1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017B010: BF870121
	v_dual_sub_f32 v161, v161, v163 :: v_dual_fmac_f32 v162, 0x32a5705f, v160// 00000017B014: C94147A1 A1A340FF 32A5705F
	.long 0xd41b0001                                           // 00000017B020: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v160, vcc_lo             // 00000017B024: 020340FF C2CE8ED0
	v_add_f32_e32 v161, v161, v162                             // 00000017B02C: 074345A1
	v_cvt_i32_f32_e32 v162, v163                               // 00000017B030: 7F4411A3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017B034: BF870292
	v_exp_f32_e32 v161, v161                                   // 00000017B038: 7F424BA1
	.long 0xd71c00a1                                           // 00000017B03C: D71C00A1
	v_cndmask_b32_e32 v1, v161, v162, vcc_lo                   // 00000017B040: 020345A1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017B044: BF8700A1
	v_cndmask_b32_e64 v161, 0, v161, s1                        // 00000017B048: D50100A1 00074280
	.long 0xd41e0001                                           // 00000017B050: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v160, vcc_lo             // 00000017B054: 020340FF 42B17218
	v_cndmask_b32_e64 v160, 0x7f800000, v161, s1               // 00000017B05C: D50100A0 000742FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017B068: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017B06C: BF8700A1
	v_bfe_u32 v161, v160, 16, 1                                // 00000017B070: D61000A1 020521A0
	s_mov_b32 s2, exec_lo                                      // 00000017B078: BE82007E
	v_add3_u32 v161, v160, v161, 0x7fff                        // 00000017B07C: D65500A1 03FF43A0 00007FFF
	ds_store_b16_d16_hi v154, v161 offset:24                   // 00000017B088: DA840018 0000A19A
	v_cmpx_lt_i32_e32 13, v139                                 // 00000017B090: 7D83168D
	s_cbranch_execz 34                                         // 00000017B094: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1b20>
	ds_load_b32 v159, v254 offset:52                           // 00000017B098: D8D80034 9F0000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017B0A0: BF89FC07
	v_sub_f32_e32 v159, v159, v138                             // 00000017B0A4: 093F159F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017B0A8: BF870121
	v_mul_f32_e32 v161, 0x3fb8aa3b, v159                       // 00000017B0AC: 11433EFF 3FB8AA3B
	.long 0xd41b0001                                           // 00000017B0B4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v159, vcc_lo             // 00000017B0B8: 02033EFF C2CE8ED0
	v_fma_f32 v162, 0x3fb8aa3b, v159, -v161                    // 00000017B0C0: D61300A2 86873EFF 3FB8AA3B
	v_rndne_f32_e32 v163, v161                                 // 00000017B0CC: 7F4647A1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000017B0D0: BF870112
	v_fmac_f32_e32 v162, 0x32a5705f, v159                      // 00000017B0D4: 57453EFF 32A5705F
	v_sub_f32_e32 v161, v161, v163                             // 00000017B0DC: 094347A1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017B0E0: BF870121
	v_add_f32_e32 v161, v161, v162                             // 00000017B0E4: 074345A1
	v_cvt_i32_f32_e32 v162, v163                               // 00000017B0E8: 7F4411A3
	v_exp_f32_e32 v161, v161                                   // 00000017B0EC: 7F424BA1
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B0F0: BF870095
	.long 0xd71c00a1                                           // 00000017B0F4: D71C00A1
	v_cndmask_b32_e32 v1, v161, v162, vcc_lo                   // 00000017B0F8: 020345A1
	v_cndmask_b32_e64 v161, 0, v161, s1                        // 00000017B0FC: D50100A1 00074280
	.long 0xd41e0001                                           // 00000017B104: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v159, vcc_lo             // 00000017B108: 02033EFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017B110: BF870001
	v_cndmask_b32_e64 v159, 0x7f800000, v161, s1               // 00000017B114: D501009F 000742FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017B120: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000017B124: BF870131
	v_bfe_u32 v161, v159, 16, 1                                // 00000017B128: D61000A1 0205219F
	v_dual_mov_b32 v249, 0 :: v_dual_mov_b32 v250, 0           // 00000017B130: CA100080 F9FA0080
	s_mov_b32 s2, exec_lo                                      // 00000017B138: BE82007E
	v_add3_u32 v161, v159, v161, 0x7fff                        // 00000017B13C: D65500A1 03FF439F 00007FFF
	ds_store_b16_d16_hi v154, v161 offset:26                   // 00000017B148: DA84001A 0000A19A
	v_cmpx_lt_i32_e32 14, v139                                 // 00000017B150: 7D83168E
	s_cbranch_execz 33                                         // 00000017B154: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1bdc>
	ds_load_b32 v161, v254 offset:56                           // 00000017B158: D8D80038 A10000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017B160: BF89FC07
	v_sub_f32_e32 v161, v161, v138                             // 00000017B164: 094315A1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B168: BF870091
	v_mul_f32_e32 v162, 0x3fb8aa3b, v161                       // 00000017B16C: 114542FF 3FB8AA3B
	v_fma_f32 v163, 0x3fb8aa3b, v161, -v162                    // 00000017B174: D61300A3 868B42FF 3FB8AA3B
	v_rndne_f32_e32 v164, v162                                 // 00000017B180: 7F4847A2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017B184: BF870121
	v_dual_sub_f32 v162, v162, v164 :: v_dual_fmac_f32 v163, 0x32a5705f, v161// 00000017B188: C94149A2 A2A342FF 32A5705F
	.long 0xd41b0001                                           // 00000017B194: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v161, vcc_lo             // 00000017B198: 020342FF C2CE8ED0
	v_add_f32_e32 v162, v162, v163                             // 00000017B1A0: 074547A2
	v_cvt_i32_f32_e32 v163, v164                               // 00000017B1A4: 7F4611A4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017B1A8: BF870292
	v_exp_f32_e32 v162, v162                                   // 00000017B1AC: 7F444BA2
	.long 0xd71c00a2                                           // 00000017B1B0: D71C00A2
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                   // 00000017B1B4: 020347A2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017B1B8: BF8700A1
	v_cndmask_b32_e64 v162, 0, v162, s1                        // 00000017B1BC: D50100A2 00074480
	.long 0xd41e0001                                           // 00000017B1C4: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v161, vcc_lo             // 00000017B1C8: 020342FF 42B17218
	v_cndmask_b32_e64 v250, 0x7f800000, v162, s1               // 00000017B1D0: D50100FA 000744FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017B1DC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017B1E0: BF8700A1
	v_bfe_u32 v161, v250, 16, 1                                // 00000017B1E4: D61000A1 020521FA
	s_mov_b32 s2, exec_lo                                      // 00000017B1EC: BE82007E
	v_add3_u32 v161, v250, v161, 0x7fff                        // 00000017B1F0: D65500A1 03FF43FA 00007FFF
	ds_store_b16_d16_hi v154, v161 offset:28                   // 00000017B1FC: DA84001C 0000A19A
	v_cmpx_lt_i32_e32 15, v139                                 // 00000017B204: 7D83168F
	s_cbranch_execz 34                                         // 00000017B208: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1c94>
	ds_load_b32 v139, v254 offset:60                           // 00000017B20C: D8D8003C 8B0000FE
	s_waitcnt lgkmcnt(0)                                       // 00000017B214: BF89FC07
	v_sub_f32_e32 v139, v139, v138                             // 00000017B218: 0917158B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017B21C: BF870121
	v_mul_f32_e32 v161, 0x3fb8aa3b, v139                       // 00000017B220: 114316FF 3FB8AA3B
	.long 0xd41b0001                                           // 00000017B228: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v139, vcc_lo             // 00000017B22C: 020316FF C2CE8ED0
	v_fma_f32 v162, 0x3fb8aa3b, v139, -v161                    // 00000017B234: D61300A2 868716FF 3FB8AA3B
	v_rndne_f32_e32 v163, v161                                 // 00000017B240: 7F4647A1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000017B244: BF870112
	v_fmac_f32_e32 v162, 0x32a5705f, v139                      // 00000017B248: 574516FF 32A5705F
	v_sub_f32_e32 v161, v161, v163                             // 00000017B250: 094347A1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017B254: BF870121
	v_add_f32_e32 v161, v161, v162                             // 00000017B258: 074345A1
	v_cvt_i32_f32_e32 v162, v163                               // 00000017B25C: 7F4411A3
	v_exp_f32_e32 v161, v161                                   // 00000017B260: 7F424BA1
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B264: BF870095
	.long 0xd71c00a1                                           // 00000017B268: D71C00A1
	v_cndmask_b32_e32 v1, v161, v162, vcc_lo                   // 00000017B26C: 020345A1
	v_cndmask_b32_e64 v161, 0, v161, s1                        // 00000017B270: D50100A1 00074280
	.long 0xd41e0001                                           // 00000017B278: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v139, vcc_lo             // 00000017B27C: 020316FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017B284: BF870001
	v_cndmask_b32_e64 v249, 0x7f800000, v161, s1               // 00000017B288: D50100F9 000742FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017B294: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017B298: BF8700A1
	v_bfe_u32 v139, v249, 16, 1                                // 00000017B29C: D610008B 020521F9
	s_mov_b32 s2, exec_lo                                      // 00000017B2A4: BE82007E
	v_add3_u32 v161, v249, v139, 0x7fff                        // 00000017B2A8: D65500A1 03FF17F9 00007FFF
	v_mov_b32_e32 v139, 0                                      // 00000017B2B4: 7F160280
	ds_store_b16_d16_hi v154, v161 offset:30                   // 00000017B2B8: DA84001E 0000A19A
	v_cmpx_lt_f32_e32 0xefa18f08, v255                         // 00000017B2C0: 7D23FEFF EFA18F08
	s_cbranch_execz 31                                         // 00000017B2C8: BFA5001F <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1d48>
	v_sub_f32_e32 v139, v255, v138                             // 00000017B2CC: 091715FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017B2D0: BF870121
	v_mul_f32_e32 v161, 0x3fb8aa3b, v139                       // 00000017B2D4: 114316FF 3FB8AA3B
	.long 0xd41b0001                                           // 00000017B2DC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v139, vcc_lo             // 00000017B2E0: 020316FF C2CE8ED0
	v_fma_f32 v162, 0x3fb8aa3b, v139, -v161                    // 00000017B2E8: D61300A2 868716FF 3FB8AA3B
	v_rndne_f32_e32 v163, v161                                 // 00000017B2F4: 7F4647A1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000017B2F8: BF870112
	v_fmac_f32_e32 v162, 0x32a5705f, v139                      // 00000017B2FC: 574516FF 32A5705F
	v_sub_f32_e32 v161, v161, v163                             // 00000017B304: 094347A1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017B308: BF870121
	v_add_f32_e32 v161, v161, v162                             // 00000017B30C: 074345A1
	v_cvt_i32_f32_e32 v162, v163                               // 00000017B310: 7F4411A3
	v_exp_f32_e32 v161, v161                                   // 00000017B314: 7F424BA1
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B318: BF870095
	.long 0xd71c00a1                                           // 00000017B31C: D71C00A1
	v_cndmask_b32_e32 v1, v161, v162, vcc_lo                   // 00000017B320: 020345A1
	v_cndmask_b32_e64 v161, 0, v161, s1                        // 00000017B324: D50100A1 00074280
	.long 0xd41e0001                                           // 00000017B32C: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v139, vcc_lo             // 00000017B330: 020316FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017B338: BF870001
	v_cndmask_b32_e64 v139, 0x7f800000, v161, s1               // 00000017B33C: D501008B 000742FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017B348: 8C7E027E
	v_dual_add_f32 v140, v141, v140 :: v_dual_mov_b32 v255, v138// 00000017B34C: C911198D 8CFE018A
	s_or_b32 s13, s13, exec_lo                                 // 00000017B354: 8C0D7E0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B358: BF870091
	v_add_f32_e32 v140, v140, v143                             // 00000017B35C: 07191F8C
	v_add_f32_e32 v140, v140, v142                             // 00000017B360: 07191D8C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B364: BF870091
	v_add_f32_e32 v140, v140, v145                             // 00000017B368: 0719238C
	v_add_f32_e32 v140, v140, v144                             // 00000017B36C: 0719218C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B370: BF870091
	v_add_f32_e32 v140, v140, v147                             // 00000017B374: 0719278C
	v_add_f32_e32 v140, v140, v146                             // 00000017B378: 0719258C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B37C: BF870091
	v_add_f32_e32 v140, v140, v149                             // 00000017B380: 07192B8C
	v_add_f32_e32 v140, v140, v148                             // 00000017B384: 0719298C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B388: BF870091
	v_add_f32_e32 v140, v140, v151                             // 00000017B38C: 07192F8C
	v_add_f32_e32 v140, v140, v150                             // 00000017B390: 07192D8C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B394: BF870091
	v_add_f32_e32 v140, v140, v160                             // 00000017B398: 0719418C
	v_add_f32_e32 v140, v140, v159                             // 00000017B39C: 07193F8C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B3A0: BF870091
	v_add_f32_e32 v140, v140, v250                             // 00000017B3A4: 0719F58C
	v_add_f32_e32 v140, v140, v249                             // 00000017B3A8: 0719F38C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B3AC: BF870091
	v_fmac_f32_e32 v140, v252, v139                            // 00000017B3B0: 571917FC
	v_mov_b32_e32 v252, v140                                   // 00000017B3B4: 7FF8038C
	s_or_b32 exec_lo, exec_lo, s14                             // 00000017B3B8: 8C7E0E7E
	s_and_saveexec_b32 s1, s13                                 // 00000017B3BC: BE81200D
	s_cbranch_execz 64177                                      // 00000017B3C0: BFA5FAB1 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x888>
	scratch_load_b32 v138, off, off offset:192                 // 00000017B3C4: DC5100C0 8A7C0000
	s_waitcnt vmcnt(0)                                         // 00000017B3CC: BF8903F7
	ds_store_b32 v138, v139                                    // 00000017B3D0: D8340000 00008B8A
	s_branch 64171                                             // 00000017B3D8: BFA0FAAB <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x888>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000017B3DC: 8C7E117E
	v_bfe_u32 v8, v0, 4, 1                                     // 00000017B3E0: D6100008 02050900
	v_and_b32_e32 v15, 31, v0                                  // 00000017B3E8: 361E009F
	v_and_b32_e32 v16, 15, v0                                  // 00000017B3EC: 3620008F
	s_or_b32 exec_lo, exec_lo, s19                             // 00000017B3F0: 8C7E137E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017B3F4: BF870009
	s_mov_b32 s0, exec_lo                                      // 00000017B3F8: BE80007E
	s_waitcnt_vscnt null, 0x0                                  // 00000017B3FC: BC7C0000
	s_barrier                                                  // 00000017B400: BFBD0000
	buffer_gl0_inv                                             // 00000017B404: E0AC0000 00000000
	v_cmpx_gt_u32_e32 12, v15                                  // 00000017B40C: 7D981E8C
	s_cbranch_execz 8                                          // 00000017B410: BFA50008 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1e34>
	v_lshlrev_b32_e32 v7, 6, v176                              // 00000017B414: 300F6086
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B418: BF870091
	v_lshl_add_u32 v7, v15, 2, v7                              // 00000017B41C: D6460007 041D050F
	v_add_nc_u32_e32 v7, 0x50, v7                              // 00000017B424: 4A0E0EFF 00000050
	ds_store_2addr_stride64_b32 v7, v252, v255 offset0:249 offset1:250// 00000017B42C: D83CFAF9 00FFFC07
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017B434: 8C7E007E
	v_mul_u32_u24_e32 v7, 12, v176                             // 00000017B438: 160F608C
	s_mov_b32 s1, 0                                            // 00000017B43C: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B440: BF870091
	v_or_b32_e32 v7, v7, v8                                    // 00000017B444: 380E1107
	v_lshlrev_b32_e32 v7, 10, v7                               // 00000017B448: 300E0E8A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B44C: BF870091
	v_lshl_or_b32 v7, v16, 2, v7                               // 00000017B450: D6560007 041D0510
	v_add_nc_u32_e32 v8, 0x800, v7                             // 00000017B458: 4A100EFF 00000800
	v_add_nc_u32_e32 v15, 0x1000, v7                           // 00000017B460: 4A1E0EFF 00001000
	v_add_nc_u32_e32 v16, 0x1800, v7                           // 00000017B468: 4A200EFF 00001800
	v_add_nc_u32_e32 v23, 0x2000, v7                           // 00000017B470: 4A2E0EFF 00002000
	v_add_nc_u32_e32 v24, 0x2800, v7                           // 00000017B478: 4A300EFF 00002800
	v_add_nc_u32_e32 v7, 0x3000, v7                            // 00000017B480: 4A0E0EFF 00003000
	ds_store_2addr_b32 v8, v105, v121 offset1:16               // 00000017B488: D8381000 00796908
	ds_store_2addr_b32 v15, v106, v122 offset1:16              // 00000017B490: D8381000 007A6A0F
	ds_store_2addr_b32 v16, v107, v123 offset1:16              // 00000017B498: D8381000 007B6B10
	ds_store_2addr_b32 v23, v108, v124 offset1:16              // 00000017B4A0: D8381000 007C6C17
	ds_store_2addr_b32 v24, v109, v125 offset1:16              // 00000017B4A8: D8381000 007D6D18
	ds_store_2addr_b32 v7, v110, v126 offset1:16               // 00000017B4B0: D8381000 007E6E07
	ds_store_2addr_b32 v8, v89, v113 offset0:32 offset1:48     // 00000017B4B8: D8383020 00715908
	ds_store_2addr_b32 v15, v90, v114 offset0:32 offset1:48    // 00000017B4C0: D8383020 00725A0F
	ds_store_2addr_b32 v16, v91, v115 offset0:32 offset1:48    // 00000017B4C8: D8383020 00735B10
	ds_store_2addr_b32 v23, v92, v116 offset0:32 offset1:48    // 00000017B4D0: D8383020 00745C17
	ds_store_2addr_b32 v24, v93, v117 offset0:32 offset1:48    // 00000017B4D8: D8383020 00755D18
	ds_store_2addr_b32 v7, v94, v118 offset0:32 offset1:48     // 00000017B4E0: D8383020 00765E07
	ds_store_2addr_b32 v8, v73, v97 offset0:64 offset1:80      // 00000017B4E8: D8385040 00614908
	ds_store_2addr_b32 v15, v74, v98 offset0:64 offset1:80     // 00000017B4F0: D8385040 00624A0F
	ds_store_2addr_b32 v16, v75, v99 offset0:64 offset1:80     // 00000017B4F8: D8385040 00634B10
	ds_store_2addr_b32 v23, v76, v100 offset0:64 offset1:80    // 00000017B500: D8385040 00644C17
	ds_store_2addr_b32 v24, v77, v101 offset0:64 offset1:80    // 00000017B508: D8385040 00654D18
	ds_store_2addr_b32 v7, v78, v102 offset0:64 offset1:80     // 00000017B510: D8385040 00664E07
	ds_store_2addr_b32 v8, v57, v81 offset0:96 offset1:112     // 00000017B518: D8387060 00513908
	ds_store_2addr_b32 v15, v58, v82 offset0:96 offset1:112    // 00000017B520: D8387060 00523A0F
	ds_store_2addr_b32 v16, v59, v83 offset0:96 offset1:112    // 00000017B528: D8387060 00533B10
	ds_store_2addr_b32 v23, v60, v84 offset0:96 offset1:112    // 00000017B530: D8387060 00543C17
	ds_store_2addr_b32 v24, v61, v85 offset0:96 offset1:112    // 00000017B538: D8387060 00553D18
	ds_store_2addr_b32 v7, v62, v86 offset0:96 offset1:112     // 00000017B540: D8387060 00563E07
	ds_store_2addr_b32 v8, v49, v65 offset0:128 offset1:144    // 00000017B548: D8389080 00413108
	ds_store_2addr_b32 v15, v50, v66 offset0:128 offset1:144   // 00000017B550: D8389080 0042320F
	ds_store_2addr_b32 v16, v51, v67 offset0:128 offset1:144   // 00000017B558: D8389080 00433310
	ds_store_2addr_b32 v23, v52, v68 offset0:128 offset1:144   // 00000017B560: D8389080 00443417
	ds_store_2addr_b32 v24, v53, v69 offset0:128 offset1:144   // 00000017B568: D8389080 00453518
	ds_store_2addr_b32 v7, v54, v70 offset0:128 offset1:144    // 00000017B570: D8389080 00463607
	ds_store_2addr_b32 v8, v33, v41 offset0:160 offset1:176    // 00000017B578: D838B0A0 00292108
	ds_store_2addr_b32 v15, v34, v42 offset0:160 offset1:176   // 00000017B580: D838B0A0 002A220F
	ds_store_2addr_b32 v16, v35, v43 offset0:160 offset1:176   // 00000017B588: D838B0A0 002B2310
	ds_store_2addr_b32 v23, v36, v44 offset0:160 offset1:176   // 00000017B590: D838B0A0 002C2417
	ds_store_2addr_b32 v24, v37, v45 offset0:160 offset1:176   // 00000017B598: D838B0A0 002D2518
	ds_store_2addr_b32 v7, v38, v46 offset0:160 offset1:176    // 00000017B5A0: D838B0A0 002E2607
	ds_store_2addr_b32 v8, v17, v25 offset0:192 offset1:208    // 00000017B5A8: D838D0C0 00191108
	ds_store_2addr_b32 v15, v18, v26 offset0:192 offset1:208   // 00000017B5B0: D838D0C0 001A120F
	ds_store_2addr_b32 v16, v19, v27 offset0:192 offset1:208   // 00000017B5B8: D838D0C0 001B1310
	ds_store_2addr_b32 v23, v20, v28 offset0:192 offset1:208   // 00000017B5C0: D838D0C0 001C1417
	ds_store_2addr_b32 v24, v21, v29 offset0:192 offset1:208   // 00000017B5C8: D838D0C0 001D1518
	ds_store_2addr_b32 v7, v22, v30 offset0:192 offset1:208    // 00000017B5D0: D838D0C0 001E1607
	ds_store_2addr_b32 v8, v9, v1 offset0:224 offset1:240      // 00000017B5D8: D838F0E0 00010908
	ds_store_2addr_b32 v15, v10, v2 offset0:224 offset1:240    // 00000017B5E0: D838F0E0 00020A0F
	ds_store_2addr_b32 v16, v11, v3 offset0:224 offset1:240    // 00000017B5E8: D838F0E0 00030B10
	ds_store_2addr_b32 v23, v12, v4 offset0:224 offset1:240    // 00000017B5F0: D838F0E0 00040C17
	ds_store_2addr_b32 v24, v13, v5 offset0:224 offset1:240    // 00000017B5F8: D838F0E0 00050D18
	ds_store_2addr_b32 v7, v14, v6 offset0:224 offset1:240     // 00000017B600: D838F0E0 00060E07
	s_waitcnt lgkmcnt(0)                                       // 00000017B608: BF89FC07
	s_barrier                                                  // 00000017B60C: BFBD0000
	buffer_gl0_inv                                             // 00000017B610: E0AC0000 00000000
	s_branch 135                                               // 00000017B618: BFA00087 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x2238>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017B61C: 8C7E007E
	v_add_lshl_u32 v2, v5, s18, 8                              // 00000017B620: D6470002 02202505
	s_waitcnt lgkmcnt(5)                                       // 00000017B628: BF89FC57
	v_fma_f32 v7, v6, v7, 0                                    // 00000017B62C: D6130007 02020F06
	s_waitcnt lgkmcnt(4)                                       // 00000017B634: BF89FC47
	v_fma_f32 v6, v6, v8, 0                                    // 00000017B638: D6130006 02021106
	v_ashrrev_i32_e32 v5, 31, v2                               // 00000017B640: 340A049F
	.long 0xd7006a02                                           // 00000017B644: D7006A02
	v_cndmask_b32_e32 v1, s10, v2, vcc_lo                      // 00000017B648: 0202040A
	s_waitcnt lgkmcnt(2)                                       // 00000017B64C: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 00000017B650: BF870003
	v_fmac_f32_e32 v6, v13, v14                                // 00000017B654: 560C1D0D
	v_fmac_f32_e32 v7, v13, v4                                 // 00000017B658: 560E090D
	v_add_co_ci_u32_e64 v11, null, s11, v5, vcc_lo             // 00000017B65C: D5207C0B 01AA0A0B
	v_or_b32_e32 v10, v2, v10                                  // 00000017B664: 38141502
	ds_load_b32 v3, v3 offset:192                              // 00000017B668: D8D800C0 03000003
	ds_load_b32 v5, v9 offset:36864                            // 00000017B670: D8D89000 05000009
	s_waitcnt lgkmcnt(2)                                       // 00000017B678: BF89FC27
	v_fmac_f32_e32 v6, v12, v15                                // 00000017B67C: 560C1F0C
	v_fmac_f32_e32 v7, v12, v1                                 // 00000017B680: 560E030C
	.long 0xd73c000a                                           // 00000017B684: D73C000A
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 00000017B688: 02021481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B68C: BF870091
	.long 0xd7006a11                                           // 00000017B690: D7006A11
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 00000017B694: 02021406
	v_add_co_ci_u32_e64 v18, null, s7, v11, vcc_lo             // 00000017B698: D5207C12 01AA1607
	global_load_u16 v2, v[17:18], off                          // 00000017B6A0: DC4A0000 027C0011
	s_waitcnt vmcnt(0) lgkmcnt(1)                              // 00000017B6A8: BF890017
	v_dual_fmac_f32 v7, v16, v3 :: v_dual_lshlrev_b32 v2, 16, v2// 00000017B6AC: C8220710 07020490
	s_waitcnt lgkmcnt(0)                                       // 00000017B6B4: BF89FC07
	v_fmac_f32_e32 v6, v16, v5                                 // 00000017B6B8: 560C0B10
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017B6BC: BF870122
	v_mul_f32_e32 v4, 0xbfb8aa3b, v2                           // 00000017B6C0: 100804FF BFB8AA3B
	.long 0xd41e0000                                           // 00000017B6C8: D41E0000
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v2, vcc_lo               // 00000017B6CC: 020204FF 42CE8ED0
	v_fma_f32 v5, 0xbfb8aa3b, v2, -v4                          // 00000017B6D4: D6130005 841204FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000017B6E0: BF870131
	v_fmac_f32_e32 v5, 0xb2a5705f, v2                          // 00000017B6E4: 560A04FF B2A5705F
	v_div_scale_f32 v1, null, v7, v7, v6                       // 00000017B6EC: D6FC7C01 041A0F07
	v_div_scale_f32 v12, vcc_lo, v6, v7, v6                    // 00000017B6F4: D6FC6A0C 041A0F06
	v_rcp_f32_e32 v3, v1                                       // 00000017B6FC: 7E065501
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B700: BF870095
	v_fma_f32 v9, -v1, v3, 1.0                                 // 00000017B704: D6130009 23CA0701
	v_fmac_f32_e32 v3, v9, v3                                  // 00000017B70C: 56060709
	v_rndne_f32_e32 v8, v4                                     // 00000017B710: 7E104704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017B714: BF870121
	v_sub_f32_e32 v4, v4, v8                                   // 00000017B718: 08081104
	v_cvt_i32_f32_e32 v8, v8                                   // 00000017B71C: 7E101108
	v_add_f32_e32 v4, v4, v5                                   // 00000017B720: 06080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017B724: BF870291
	v_exp_f32_e32 v4, v4                                       // 00000017B728: 7E084B04
	.long 0xd71c0004                                           // 00000017B72C: D71C0004
	v_cndmask_b32_e32 v1, v4, v8, vcc_lo                       // 00000017B730: 02021104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017B734: BF8700A1
	v_cndmask_b32_e64 v4, 0, v4, s0                            // 00000017B738: D5010004 00020880
	v_mul_f32_e32 v5, v12, v3                                  // 00000017B740: 100A070C
	v_fma_f32 v9, -v1, v5, v12                                 // 00000017B744: D6130009 24320B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B74C: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 00000017B750: 560A0709
	v_fma_f32 v1, -v1, v5, v12                                 // 00000017B754: D6130001 24320B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017B75C: BF870121
	v_div_fmas_f32 v1, v1, v3, v5                              // 00000017B760: D6370001 04160701
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v2                   // 00000017B768: 7C3604FF C2B17218
	v_div_fixup_f32 v1, v1, v7, v6                             // 00000017B770: D6270001 041A0F01
	v_cndmask_b32_e32 v2, 0x7f800000, v4, vcc_lo               // 00000017B778: 020408FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B780: BF870091
	v_add_f32_e32 v2, 1.0, v2                                  // 00000017B784: 060404F2
	v_div_scale_f32 v3, null, v2, v2, v1                       // 00000017B788: D6FC7C03 04060502
	v_div_scale_f32 v6, vcc_lo, v1, v2, v1                     // 00000017B790: D6FC6A06 04060501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017B798: BF870292
	v_rcp_f32_e32 v4, v3                                       // 00000017B79C: 7E085503
	v_fma_f32 v5, -v3, v4, 1.0                                 // 00000017B7A0: D6130005 23CA0903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B7A8: BF870091
	v_fmac_f32_e32 v4, v5, v4                                  // 00000017B7AC: 56080905
	v_mul_f32_e32 v5, v6, v4                                   // 00000017B7B0: 100A0906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B7B4: BF870091
	v_fma_f32 v7, -v3, v5, v6                                  // 00000017B7B8: D6130007 241A0B03
	v_fmac_f32_e32 v5, v7, v4                                  // 00000017B7C0: 560A0907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B7C4: BF870091
	v_fma_f32 v3, -v3, v5, v6                                  // 00000017B7C8: D6130003 241A0B03
	v_div_fmas_f32 v3, v3, v4, v5                              // 00000017B7D0: D6370003 04160903
	v_cmp_lt_u32_e32 vcc_lo, 0xb7f, v0                         // 00000017B7D8: 7C9200FF 00000B7F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000017B7E0: BF870132
	v_div_fixup_f32 v1, v3, v2, v1                             // 00000017B7E4: D6270001 04060503
	v_add_nc_u32_e32 v3, 0x80, v0                              // 00000017B7EC: 4A0600FF 00000080
	s_or_b32 s1, vcc_lo, s1                                    // 00000017B7F4: 8C01016A
	v_bfe_u32 v2, v1, 16, 1                                    // 00000017B7F8: D6100002 02052101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000017B800: BF870112
	v_mov_b32_e32 v0, v3                                       // 00000017B804: 7E000303
	v_add3_u32 v4, v1, v2, 0x7fff                              // 00000017B808: D6550004 03FE0501 00007FFF
	.long 0xd7000001                                           // 00000017B814: D7000001
	v_cndmask_b32_e32 v1, s8, v10, vcc_lo                      // 00000017B818: 02021408
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017B81C: BF870001
	v_add_co_ci_u32_e64 v2, null, s9, v11, s0                  // 00000017B820: D5207C02 00021609
	global_store_d16_hi_b16 v[1:2], v4, off                    // 00000017B828: DC960000 007C0401
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000017B830: 917E017E
	s_cbranch_execz 173                                        // 00000017B834: BFA500AD <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x24ec>
	v_lshrrev_b32_e32 v5, 8, v0                                // 00000017B838: 320A0088
	s_mov_b32 s0, exec_lo                                      // 00000017B83C: BE80007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B840: BF870091
	v_lshlrev_b32_e32 v7, 2, v5                                // 00000017B844: 300E0A82
	v_add_nc_u32_e32 v1, 0xf800, v7                            // 00000017B848: 4A020EFF 0000F800
	ds_load_2addr_b32 v[3:4], v1 offset0:148 offset1:164       // 00000017B850: D8DCA494 03000001
	ds_load_2addr_b32 v[1:2], v1 offset0:180 offset1:196       // 00000017B858: D8DCC4B4 01000001
	s_waitcnt lgkmcnt(1)                                       // 00000017B860: BF89FC17
	v_max3_f32 v6, v3, 0xf149f2ca, v4                          // 00000017B864: D61C0006 0411FF03 F149F2CA
	s_waitcnt lgkmcnt(0)                                       // 00000017B870: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017B874: BF870001
	v_max3_f32 v11, v6, v1, v2                                 // 00000017B878: D61C000B 040A0306
	v_mov_b32_e32 v6, 0                                        // 00000017B880: 7E0C0280
	v_cmpx_lt_f32_e32 0xefa18f08, v3                           // 00000017B884: 7D2206FF EFA18F08
	s_cbranch_execz 27                                         // 00000017B88C: BFA5001B <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x22fc>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B890: BF870093
	v_sub_f32_e32 v3, v3, v11                                  // 00000017B894: 08061703
	v_mul_f32_e32 v6, 0x3fb8aa3b, v3                           // 00000017B898: 100C06FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017B8A0: BF8700A1
	v_fma_f32 v8, 0x3fb8aa3b, v3, -v6                          // 00000017B8A4: D6130008 841A06FF 3FB8AA3B
	v_rndne_f32_e32 v9, v6                                     // 00000017B8B0: 7E124706
	v_sub_f32_e32 v6, v6, v9                                   // 00000017B8B4: 080C1306
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017B8B8: BF870123
	v_fmac_f32_e32 v8, 0x32a5705f, v3                          // 00000017B8BC: 561006FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000017B8C4: 7C3606FF C2CE8ED0
	v_add_f32_e32 v6, v6, v8                                   // 00000017B8CC: 060C1106
	v_cvt_i32_f32_e32 v8, v9                                   // 00000017B8D0: 7E101109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017B8D4: BF870292
	v_exp_f32_e32 v6, v6                                       // 00000017B8D8: 7E0C4B06
	.long 0xd71c0006                                           // 00000017B8DC: D71C0006
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 00000017B8E0: 02021106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017B8E4: BF870121
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo                        // 00000017B8E8: 020C0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000017B8EC: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v6, 0x7f800000, v6, vcc_lo               // 00000017B8F4: 020C0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017B8FC: 8C7E007E
	v_dual_mov_b32 v13, 0 :: v_dual_and_b32 v10, 0xff, v0      // 00000017B900: CA240080 0D0A00FF 000000FF
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v3, 0xfa50, v7  // 00000017B90C: CA200080 0C020EFF 0000FA50
	v_lshlrev_b32_e32 v8, 10, v5                               // 00000017B918: 30100A8A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000017B91C: BF8701A3
	v_lshl_or_b32 v7, v10, 2, 0x800                            // 00000017B920: D6560007 03FD050A 00000800
	s_mov_b32 s0, exec_lo                                      // 00000017B92C: BE80007E
	v_add_nc_u32_e32 v3, 0xffffff00, v3                        // 00000017B930: 4A0606FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_2)                            // 00000017B938: BF870002
	v_add_nc_u32_e32 v9, v7, v8                                // 00000017B93C: 4A121107
	ds_load_b32 v7, v3                                         // 00000017B940: D8D80000 07000003
	ds_load_b32 v8, v9                                         // 00000017B948: D8D80000 08000009
	v_cmpx_lt_f32_e32 0xefa18f08, v4                           // 00000017B950: 7D2208FF EFA18F08
	s_cbranch_execz 26                                         // 00000017B958: BFA5001A <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x23c4>
	v_sub_f32_e32 v4, v4, v11                                  // 00000017B95C: 08081704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B960: BF870091
	v_mul_f32_e32 v13, 0x3fb8aa3b, v4                          // 00000017B964: 101A08FF 3FB8AA3B
	v_fma_f32 v14, 0x3fb8aa3b, v4, -v13                        // 00000017B96C: D613000E 843608FF 3FB8AA3B
	v_rndne_f32_e32 v15, v13                                   // 00000017B978: 7E1E470D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B97C: BF870091
	v_dual_fmac_f32 v14, 0x32a5705f, v4 :: v_dual_sub_f32 v13, v13, v15// 00000017B980: C80A08FF 0E0C1F0D 32A5705F
	v_add_f32_e32 v13, v13, v14                                // 00000017B98C: 061A1D0D
	v_cvt_i32_f32_e32 v14, v15                                 // 00000017B990: 7E1C110F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 00000017B994: 7C3608FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017B99C: BF870293
	v_exp_f32_e32 v13, v13                                     // 00000017B9A0: 7E1A4B0D
	.long 0xd71c000d                                           // 00000017B9A4: D71C000D
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                     // 00000017B9A8: 02021D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017B9AC: BF870121
	v_cndmask_b32_e32 v13, 0, v13, vcc_lo                      // 00000017B9B0: 021A1A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 00000017B9B4: 7C3C08FF 42B17218
	v_cndmask_b32_e32 v13, 0x7f800000, v13, vcc_lo             // 00000017B9BC: 021A1AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017B9C4: 8C7E007E
	ds_load_b32 v4, v3 offset:64                               // 00000017B9C8: D8D80040 04000003
	ds_load_b32 v14, v9 offset:12288                           // 00000017B9D0: D8D83000 0E000009
	s_mov_b32 s0, exec_lo                                      // 00000017B9D8: BE80007E
	v_cmpx_lt_f32_e32 0xefa18f08, v1                           // 00000017B9DC: 7D2202FF EFA18F08
	s_cbranch_execz 27                                         // 00000017B9E4: BFA5001B <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x2454>
	v_sub_f32_e32 v1, v1, v11                                  // 00000017B9E8: 08021701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017B9EC: BF870091
	v_mul_f32_e32 v12, 0x3fb8aa3b, v1                          // 00000017B9F0: 101802FF 3FB8AA3B
	v_fma_f32 v15, 0x3fb8aa3b, v1, -v12                        // 00000017B9F8: D613000F 843202FF 3FB8AA3B
	v_rndne_f32_e32 v16, v12                                   // 00000017BA04: 7E20470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000017BA08: BF870221
	v_sub_f32_e32 v12, v12, v16                                // 00000017BA0C: 0818210C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 00000017BA10: 7C3602FF C2CE8ED0
	v_fmac_f32_e32 v15, 0x32a5705f, v1                         // 00000017BA18: 561E02FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017BA20: BF870121
	v_add_f32_e32 v12, v12, v15                                // 00000017BA24: 06181F0C
	v_cvt_i32_f32_e32 v15, v16                                 // 00000017BA28: 7E1E1110
	v_exp_f32_e32 v12, v12                                     // 00000017BA2C: 7E184B0C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017BA30: BF870095
	.long 0xd71c000c                                           // 00000017BA34: D71C000C
	v_cndmask_b32_e32 v1, v12, v15, vcc_lo                     // 00000017BA38: 02021F0C
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 00000017BA3C: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 00000017BA40: 7C3C02FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000017BA48: BF870002
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 00000017BA4C: 021818FF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 00000017BA54: 8C7E007E
	ds_load_b32 v1, v3 offset:128                              // 00000017BA58: D8D80080 01000003
	ds_load_b32 v15, v9 offset:24576                           // 00000017BA60: D8D86000 0F000009
	v_mov_b32_e32 v16, 0                                       // 00000017BA68: 7E200280
	s_mov_b32 s0, exec_lo                                      // 00000017BA6C: BE80007E
	v_cmpx_lt_f32_e32 0xefa18f08, v2                           // 00000017BA70: 7D2204FF EFA18F08
	s_cbranch_execz 65256                                      // 00000017BA78: BFA5FEE8 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x201c>
	v_sub_f32_e32 v2, v2, v11                                  // 00000017BA7C: 08041702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017BA80: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v2                          // 00000017BA84: 101604FF 3FB8AA3B
	v_fma_f32 v16, 0x3fb8aa3b, v2, -v11                        // 00000017BA8C: D6130010 842E04FF 3FB8AA3B
	v_rndne_f32_e32 v17, v11                                   // 00000017BA98: 7E22470B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000017BA9C: BF870221
	v_sub_f32_e32 v11, v11, v17                                // 00000017BAA0: 0816230B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2                   // 00000017BAA4: 7C3604FF C2CE8ED0
	v_fmac_f32_e32 v16, 0x32a5705f, v2                         // 00000017BAAC: 562004FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017BAB4: BF870121
	v_add_f32_e32 v11, v11, v16                                // 00000017BAB8: 0616210B
	v_cvt_i32_f32_e32 v16, v17                                 // 00000017BABC: 7E201111
	v_exp_f32_e32 v11, v11                                     // 00000017BAC0: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017BAC4: BF870095
	.long 0xd71c000b                                           // 00000017BAC8: D71C000B
	v_cndmask_b32_e32 v1, v11, v16, vcc_lo                     // 00000017BACC: 0202210B
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000017BAD0: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2                   // 00000017BAD4: 7C3C04FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000017BADC: BF870002
	v_cndmask_b32_e32 v16, 0x7f800000, v11, vcc_lo             // 00000017BAE0: 022016FF 7F800000
	s_branch 65228                                             // 00000017BAE8: BFA0FECC <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi3ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x201c>
	s_nop 0                                                    // 00000017BAEC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000017BAF0: BFB60003
	s_endpgm                                                   // 00000017BAF4: BFB00000
		...

