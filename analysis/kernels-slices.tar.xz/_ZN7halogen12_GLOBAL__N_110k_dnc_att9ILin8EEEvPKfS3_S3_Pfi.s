0000000000218e00 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi():
	s_mov_b32 s12, s3                                          // 000000218E00: BE8C0003
	s_clause 0x1                                               // 000000218E04: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000218E08: F40C0100 F8000000
	s_load_b32 s3, s[0:1], 0x20                                // 000000218E10: F40000C0 F8000020
	v_and_b32_e32 v1, 0x7f, v0                                 // 000000218E18: 360200FF 0000007F
	s_lshl_b32 s0, s2, 6                                       // 000000218E20: 84008602
	s_ashr_i32 s13, s12, 31                                    // 000000218E24: 860D9F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000218E28: BF8700B1
	v_dual_mov_b32 v5, v0 :: v_dual_lshlrev_b32 v2, 1, v1      // 000000218E2C: CA220100 05020281
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000218E34: 30060282
	s_waitcnt lgkmcnt(0)                                       // 000000218E38: BF89FC07
	.long 0xd7000103                                           // 000000218E3C: D7000103
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 000000218E40: 02020606
	s_delay_alu instid0(VALU_DEP_1)                            // 000000218E44: BF870001
	v_add_co_ci_u32_e64 v4, null, s7, 0, s1                    // 000000218E48: D5207C04 00050007
	s_mov_b32 s1, 0                                            // 000000218E50: BE810080
	s_mov_b32 s6, 0x3b800000                                   // 000000218E54: BE8600FF 3B800000
	s_set_inst_prefetch_distance 0x1                           // 000000218E5C: BF840001
	s_branch 22                                                // 000000218E60: BFA00016 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xbc>
	s_nop 0                                                    // 000000218E64: BF800000
	s_nop 0                                                    // 000000218E68: BF800000
	s_nop 0                                                    // 000000218E6C: BF800000
	s_nop 0                                                    // 000000218E70: BF800000
	s_nop 0                                                    // 000000218E74: BF800000
	s_nop 0                                                    // 000000218E78: BF800000
	s_nop 0                                                    // 000000218E7C: BF800000
	s_or_b32 exec_lo, exec_lo, s7                              // 000000218E80: 8C7E077E
	v_add_nc_u32_e32 v8, 0x100, v5                             // 000000218E84: 4A100AFF 00000100
	v_mad_u64_u32 v[6:7], null, 0x120, v6, v[2:3]              // 000000218E8C: D6FE7C06 040A0CFF 00000120
	v_cmp_lt_u32_e32 vcc_lo, 0x1eff, v5                        // 000000218E98: 7C920AFF 00001EFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000218EA0: BF870003
	v_mov_b32_e32 v5, v8                                       // 000000218EA4: 7E0A0308
	s_or_b32 s1, vcc_lo, s1                                    // 000000218EA8: 8C01016A
	ds_store_b16 v6, v1                                        // 000000218EAC: D87C0000 00000106
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000218EB4: 917E017E
	s_cbranch_execz 24                                         // 000000218EB8: BFA50018 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x11c>
	v_lshrrev_b32_e32 v6, 7, v5                                // 000000218EBC: 320C0A87
	.long 0x7e023880                                           // 000000218EC0: 7E023880
	s_mov_b32 s7, exec_lo                                      // 000000218EC4: BE87007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000218EC8: BF870092
	v_or_b32_e32 v7, s0, v6                                    // 000000218ECC: 380E0C00
	.long 0xd4c4007e                                           // 000000218ED0: D4C4007E
	v_cndmask_b32_e32 v1, s3, v7, vcc_lo                       // 000000218ED4: 02020E03
	s_cbranch_execz 65513                                      // 000000218ED8: BFA5FFE9 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x80>
	v_mad_i64_i32 v[7:8], null, v7, 48, s[12:13]               // 000000218EDC: D6FF7C07 00316107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000218EE4: BF870091
	.long 0xd73c0007                                           // 000000218EE8: D73C0007
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 000000218EEC: 02020E89
	.long 0xd7006a07                                           // 000000218EF0: D7006A07
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 000000218EF4: 02020F03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000218EF8: BF870001
	v_add_co_ci_u32_e64 v8, null, v4, v8, vcc_lo               // 000000218EFC: D5207C08 01AA1104
	global_load_b32 v1, v[7:8], off                            // 000000218F04: DC520000 017C0007
	s_waitcnt vmcnt(0)                                         // 000000218F0C: BF8903F7
	v_fma_mixlo_f16 v1, v1, s6, 0                              // 000000218F10: CC210001 02000D01
	s_branch 65497                                             // 000000218F18: BFA0FFD9 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x80>
	s_set_inst_prefetch_distance 0x2                           // 000000218F1C: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 000000218F20: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000218F24: BF870009
	s_mov_b32 s1, exec_lo                                      // 000000218F28: BE81007E
	v_cmpx_gt_u32_e32 64, v0                                   // 000000218F2C: 7D9800C0
	s_cbranch_execz 17                                         // 000000218F30: BFA50011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x178>
	v_or_b32_e32 v1, s0, v0                                    // 000000218F34: 38020000
	s_lshl_b64 s[6:7], s[12:13], 2                             // 000000218F38: 8486820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000218F3C: BF870091
	v_mad_i64_i32 v[1:2], null, 0xc0, v1, s[8:9]               // 000000218F40: D6FF7C01 002202FF 000000C0
	.long 0xd7006a01                                           // 000000218F4C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000218F50: 02000D01
	s_delay_alu instid0(VALU_DEP_1)                            // 000000218F54: BF870001
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000218F58: D5207C02 01AA0407
	global_load_b32 v1, v[1:2], off                            // 000000218F60: DC520000 017C0001
	v_lshlrev_b32_e32 v2, 2, v0                                // 000000218F68: 30040082
	s_waitcnt vmcnt(0)                                         // 000000218F6C: BF8903F7
	ds_store_b32 v2, v1 offset:18432                           // 000000218F70: D8344800 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000218F78: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 000000218F7C: BF89FC07
	s_barrier                                                  // 000000218F80: BFBD0000
	buffer_gl0_inv                                             // 000000218F84: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 000000218F8C: BE81007E
	v_cmpx_gt_u32_e32 0x200, v0                                // 000000218F90: 7D9800FF 00000200
	s_cbranch_execz 1796                                       // 000000218F98: BFA50704 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1dac>
	v_and_b32_e32 v1, 15, v0                                   // 000000218F9C: 3602008F
	v_bfe_u32 v28, v0, 5, 2                                    // 000000218FA0: D610001C 02090B00
	s_mul_i32 s1, s2, 48                                       // 000000218FA8: 9601B002
	s_mul_hi_u32 s2, s2, 48                                    // 000000218FAC: 9682B002
	s_add_u32 s6, s1, s12                                      // 000000218FB0: 80060C01
	v_mul_u32_u24_e32 v2, 0x120, v1                            // 000000218FB4: 160402FF 00000120
	v_lshl_or_b32 v29, v28, 4, v1                              // 000000218FBC: D656001D 0405091C
	v_mul_u32_u24_e32 v3, 0x1200, v28                          // 000000218FC4: 160638FF 00001200
	s_addc_u32 s7, s2, s13                                     // 000000218FCC: 82070D02
	v_lshrrev_b32_e32 v33, 5, v0                               // 000000218FD0: 32420085
	s_lshl_b64 s[6:7], s[6:7], 14                              // 000000218FD4: 84868E06
	v_or_b32_e32 v30, s0, v1                                   // 000000218FD8: 383C0200
	v_bfe_u32 v31, v0, 4, 1                                    // 000000218FDC: D610001F 02050900
	v_lshl_or_b32 v32, v29, 2, 0x4800                          // 000000218FE4: D6560020 03FD051D 00004800
	v_dual_mov_b32 v1, 0 :: v_dual_add_nc_u32 v34, v2, v3      // 000000218FF0: CA200080 01220702
	s_add_u32 s2, s10, s6                                      // 000000218FF8: 8002060A
	s_addc_u32 s6, s11, s7                                     // 000000218FFC: 8206070B
	s_mov_b32 s7, 0                                            // 000000219000: BE870080
	s_mov_b32 s8, 0x3b800000                                   // 000000219004: BE8800FF 3B800000
	s_branch 19                                                // 00000021900C: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x25c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000219010: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 000000219014: D6560000 04750D03
	v_cmp_lt_u32_e32 vcc_lo, 7, v33                            // 00000021901C: 7C924287
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000219020: BF8700B2
	.long 0xd73c0003                                           // 000000219024: D73C0003
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000219028: 02020082
	v_add_nc_u32_e32 v0, 8, v33                                // 00000021902C: 4A004288
	s_or_b32 s7, vcc_lo, s7                                    // 000000219030: 8C07076A
	v_mov_b32_e32 v33, v0                                      // 000000219034: 7E420300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000219038: BF870093
	.long 0xd7000003                                           // 00000021903C: D7000003
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000219040: 02020602
	v_add_co_ci_u32_e64 v4, null, s6, v4, s0                   // 000000219044: D5207C04 00020806
	global_store_b32 v[3:4], v2, off                           // 00000021904C: DC6A0000 007C0203
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 000000219054: 917E077E
	s_cbranch_execz 1748                                       // 000000219058: BFA506D4 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1dac>
	v_lshrrev_b32_e32 v0, 2, v33                               // 00000021905C: 32004282
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 000000219060: CA100080 09080080
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v5, 0               // 000000219068: CA100080 06040080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000219070: BF870003
	v_cmp_lt_u32_e32 vcc_lo, v0, v28                           // 000000219074: 7C923900
	.long 0xd44e0000                                           // 000000219078: D44E0000
	v_cndmask_b32_e32 v1, v0, v28, vcc_lo                      // 00000021907C: 02023900
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v0, 4, v0       // 000000219080: CA220080 07000084
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 000000219088: CA100080 04020080
	v_mov_b32_e32 v2, 0                                        // 000000219090: 7E040280
	s_and_saveexec_b32 s9, s0                                  // 000000219094: BE892000
	s_cbranch_execz 1301                                       // 000000219098: BFA50515 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x16f0>
	v_add_nc_u32_e32 v4, v0, v30                               // 00000021909C: 4A083D00
	.long 0x7f143880                                           // 0000002190A0: 7F143880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002190A4: BF8701A2
	v_mad_i64_i32 v[2:3], null, v4, 48, s[12:13]               // 0000002190A8: D6FF7C02 00316104
	.long 0xd4440000                                           // 0000002190B0: D4440000
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 0000002190B4: 02020803
	.long 0x7e14398a                                           // 0000002190B8: 7E14398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002190BC: BF870093
	.long 0xd73c0002                                           // 0000002190C0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000002190C4: 02020489
	.long 0xd700011a                                           // 0000002190C8: D700011A
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 0000002190CC: 02020404
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002190D0: BF870001
	v_add_co_ci_u32_e64 v27, null, s5, v3, s1                  // 0000002190D4: D5207C1B 00060605
	s_and_saveexec_b32 s1, s0                                  // 0000002190DC: BE812000
	s_cbranch_execz 5                                          // 0000002190E0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x2f8>
	global_load_b32 v2, v[26:27], off                          // 0000002190E4: DC520000 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002190EC: BF8903F7
	v_fma_mixlo_f16 v10, v2, s8, 0                             // 0000002190F0: CC21000A 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002190F8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002190FC: BE812000
	s_cbranch_execz 5                                          // 000000219100: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x318>
	global_load_b32 v2, v[26:27], off offset:4                 // 000000219104: DC520004 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021910C: BF8903F7
	v_fma_mixhi_f16 v10, v2, s8, 0                             // 000000219110: CC22000A 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219118: 8C7E017E
	.long 0x7f163880                                           // 00000021911C: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219120: BF870001
	.long 0x7e16398b                                           // 000000219124: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 000000219128: BE812000
	s_cbranch_execz 5                                          // 00000021912C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x344>
	global_load_b32 v2, v[26:27], off offset:8                 // 000000219130: DC520008 027C001A
	s_waitcnt vmcnt(0)                                         // 000000219138: BF8903F7
	v_fma_mixlo_f16 v11, v2, s8, 0                             // 00000021913C: CC21000B 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219144: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219148: BE812000
	s_cbranch_execz 5                                          // 00000021914C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x364>
	global_load_b32 v2, v[26:27], off offset:12                // 000000219150: DC52000C 027C001A
	s_waitcnt vmcnt(0)                                         // 000000219158: BF8903F7
	v_fma_mixhi_f16 v11, v2, s8, 0                             // 00000021915C: CC22000B 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219164: 8C7E017E
	.long 0x7f183880                                           // 000000219168: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021916C: BF870001
	.long 0x7e18398c                                           // 000000219170: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 000000219174: BE812000
	s_cbranch_execz 5                                          // 000000219178: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x390>
	global_load_b32 v2, v[26:27], off offset:16                // 00000021917C: DC520010 027C001A
	s_waitcnt vmcnt(0)                                         // 000000219184: BF8903F7
	v_fma_mixlo_f16 v12, v2, s8, 0                             // 000000219188: CC21000C 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219190: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219194: BE812000
	s_cbranch_execz 5                                          // 000000219198: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x3b0>
	global_load_b32 v2, v[26:27], off offset:20                // 00000021919C: DC520014 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002191A4: BF8903F7
	v_fma_mixhi_f16 v12, v2, s8, 0                             // 0000002191A8: CC22000C 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002191B0: 8C7E017E
	.long 0x7f1a3880                                           // 0000002191B4: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002191B8: BF870001
	.long 0x7e1a398d                                           // 0000002191BC: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 0000002191C0: BE812000
	s_cbranch_execz 5                                          // 0000002191C4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x3dc>
	global_load_b32 v2, v[26:27], off offset:24                // 0000002191C8: DC520018 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002191D0: BF8903F7
	v_fma_mixlo_f16 v13, v2, s8, 0                             // 0000002191D4: CC21000D 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002191DC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002191E0: BE812000
	s_cbranch_execz 5                                          // 0000002191E4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x3fc>
	global_load_b32 v2, v[26:27], off offset:28                // 0000002191E8: DC52001C 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002191F0: BF8903F7
	v_fma_mixhi_f16 v13, v2, s8, 0                             // 0000002191F4: CC22000D 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002191FC: 8C7E017E
	.long 0x7f1c3880                                           // 000000219200: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219204: BF870001
	.long 0x7e1c398e                                           // 000000219208: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000021920C: BE812000
	s_cbranch_execz 5                                          // 000000219210: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x428>
	global_load_b32 v2, v[26:27], off offset:32                // 000000219214: DC520020 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021921C: BF8903F7
	v_fma_mixlo_f16 v14, v2, s8, 0                             // 000000219220: CC21000E 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219228: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021922C: BE812000
	s_cbranch_execz 5                                          // 000000219230: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x448>
	global_load_b32 v2, v[26:27], off offset:36                // 000000219234: DC520024 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021923C: BF8903F7
	v_fma_mixhi_f16 v14, v2, s8, 0                             // 000000219240: CC22000E 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219248: 8C7E017E
	.long 0x7f1e3880                                           // 00000021924C: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219250: BF870001
	.long 0x7e1e398f                                           // 000000219254: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 000000219258: BE812000
	s_cbranch_execz 5                                          // 00000021925C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x474>
	global_load_b32 v2, v[26:27], off offset:40                // 000000219260: DC520028 027C001A
	s_waitcnt vmcnt(0)                                         // 000000219268: BF8903F7
	v_fma_mixlo_f16 v15, v2, s8, 0                             // 00000021926C: CC21000F 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219274: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219278: BE812000
	s_cbranch_execz 5                                          // 00000021927C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x494>
	global_load_b32 v2, v[26:27], off offset:44                // 000000219280: DC52002C 027C001A
	s_waitcnt vmcnt(0)                                         // 000000219288: BF8903F7
	v_fma_mixhi_f16 v15, v2, s8, 0                             // 00000021928C: CC22000F 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219294: 8C7E017E
	.long 0x7f203880                                           // 000000219298: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021929C: BF870001
	.long 0x7e203990                                           // 0000002192A0: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 0000002192A4: BE812000
	s_cbranch_execz 5                                          // 0000002192A8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x4c0>
	global_load_b32 v2, v[26:27], off offset:48                // 0000002192AC: DC520030 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002192B4: BF8903F7
	v_fma_mixlo_f16 v16, v2, s8, 0                             // 0000002192B8: CC210010 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002192C0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002192C4: BE812000
	s_cbranch_execz 5                                          // 0000002192C8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x4e0>
	global_load_b32 v2, v[26:27], off offset:52                // 0000002192CC: DC520034 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002192D4: BF8903F7
	v_fma_mixhi_f16 v16, v2, s8, 0                             // 0000002192D8: CC220010 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002192E0: 8C7E017E
	.long 0x7f223880                                           // 0000002192E4: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002192E8: BF870001
	.long 0x7e223991                                           // 0000002192EC: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 0000002192F0: BE812000
	s_cbranch_execz 5                                          // 0000002192F4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x50c>
	global_load_b32 v2, v[26:27], off offset:56                // 0000002192F8: DC520038 027C001A
	s_waitcnt vmcnt(0)                                         // 000000219300: BF8903F7
	v_fma_mixlo_f16 v17, v2, s8, 0                             // 000000219304: CC210011 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021930C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219310: BE812000
	s_cbranch_execz 5                                          // 000000219314: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x52c>
	global_load_b32 v2, v[26:27], off offset:60                // 000000219318: DC52003C 027C001A
	s_waitcnt vmcnt(0)                                         // 000000219320: BF8903F7
	v_fma_mixhi_f16 v17, v2, s8, 0                             // 000000219324: CC220011 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021932C: 8C7E017E
	ds_load_b128 v[35:38], v34                                 // 000000219330: DBFC0000 23000022
	ds_load_b128 v[39:42], v34 offset:16                       // 000000219338: DBFC0010 27000022
	v_mov_b32_e32 v8, v1                                       // 000000219340: 7E100301
	v_mov_b32_e32 v2, v1                                       // 000000219344: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000219348: 7E060301
	v_mov_b32_e32 v4, v1                                       // 00000021934C: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000219350: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000219354: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000219358: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 00000021935C: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000219360: BF870212
	v_mov_b32_e32 v8, v7                                       // 000000219364: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000219368: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 00000021936C: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000219370: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000219374: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000219378: 7E060302
	v_mov_b32_e32 v2, v1                                       // 00000021937C: 7E040301
	.long 0x7f243880                                           // 000000219380: 7F243880
	s_waitcnt lgkmcnt(0)                                       // 000000219384: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000219388: BF870112
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000021938C: CC404002 1C0A470A
	.long 0x7e243992                                           // 000000219394: 7E243992
	s_and_saveexec_b32 s1, s0                                  // 000000219398: BE812000
	s_cbranch_execz 5                                          // 00000021939C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x5b4>
	global_load_b32 v10, v[26:27], off offset:64               // 0000002193A0: DC520040 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002193A8: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 0000002193AC: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002193B4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002193B8: BE812000
	s_cbranch_execz 5                                          // 0000002193BC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x5d4>
	global_load_b32 v10, v[26:27], off offset:68               // 0000002193C0: DC520044 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002193C8: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 0000002193CC: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002193D4: 8C7E017E
	.long 0x7f263880                                           // 0000002193D8: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002193DC: BF870001
	.long 0x7e263993                                           // 0000002193E0: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 0000002193E4: BE812000
	s_cbranch_execz 5                                          // 0000002193E8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x600>
	global_load_b32 v10, v[26:27], off offset:72               // 0000002193EC: DC520048 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002193F4: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 0000002193F8: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219400: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219404: BE812000
	s_cbranch_execz 5                                          // 000000219408: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x620>
	global_load_b32 v10, v[26:27], off offset:76               // 00000021940C: DC52004C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219414: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 000000219418: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219420: 8C7E017E
	.long 0x7f283880                                           // 000000219424: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219428: BF870001
	.long 0x7e283994                                           // 00000021942C: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 000000219430: BE812000
	s_cbranch_execz 5                                          // 000000219434: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x64c>
	global_load_b32 v10, v[26:27], off offset:80               // 000000219438: DC520050 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219440: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 000000219444: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021944C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219450: BE812000
	s_cbranch_execz 5                                          // 000000219454: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x66c>
	global_load_b32 v10, v[26:27], off offset:84               // 000000219458: DC520054 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219460: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 000000219464: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021946C: 8C7E017E
	.long 0x7f2a3880                                           // 000000219470: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219474: BF870001
	.long 0x7e2a3995                                           // 000000219478: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000021947C: BE812000
	s_cbranch_execz 5                                          // 000000219480: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x698>
	global_load_b32 v10, v[26:27], off offset:88               // 000000219484: DC520058 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021948C: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 000000219490: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219498: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021949C: BE812000
	s_cbranch_execz 5                                          // 0000002194A0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x6b8>
	global_load_b32 v10, v[26:27], off offset:92               // 0000002194A4: DC52005C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002194AC: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 0000002194B0: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002194B8: 8C7E017E
	.long 0x7f2c3880                                           // 0000002194BC: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002194C0: BF870001
	.long 0x7e2c3996                                           // 0000002194C4: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 0000002194C8: BE812000
	s_cbranch_execz 5                                          // 0000002194CC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x6e4>
	global_load_b32 v10, v[26:27], off offset:96               // 0000002194D0: DC520060 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002194D8: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 0000002194DC: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002194E4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002194E8: BE812000
	s_cbranch_execz 5                                          // 0000002194EC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x704>
	global_load_b32 v10, v[26:27], off offset:100              // 0000002194F0: DC520064 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002194F8: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 0000002194FC: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219504: 8C7E017E
	.long 0x7f2e3880                                           // 000000219508: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021950C: BF870001
	.long 0x7e2e3997                                           // 000000219510: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 000000219514: BE812000
	s_cbranch_execz 5                                          // 000000219518: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x730>
	global_load_b32 v10, v[26:27], off offset:104              // 00000021951C: DC520068 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219524: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 000000219528: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219530: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219534: BE812000
	s_cbranch_execz 5                                          // 000000219538: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x750>
	global_load_b32 v10, v[26:27], off offset:108              // 00000021953C: DC52006C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219544: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 000000219548: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219550: 8C7E017E
	.long 0x7f303880                                           // 000000219554: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219558: BF870001
	.long 0x7e303998                                           // 00000021955C: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 000000219560: BE812000
	s_cbranch_execz 5                                          // 000000219564: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x77c>
	global_load_b32 v10, v[26:27], off offset:112              // 000000219568: DC520070 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219570: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 000000219574: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021957C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219580: BE812000
	s_cbranch_execz 5                                          // 000000219584: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x79c>
	global_load_b32 v10, v[26:27], off offset:116              // 000000219588: DC520074 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219590: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 000000219594: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021959C: 8C7E017E
	.long 0x7f323880                                           // 0000002195A0: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002195A4: BF870001
	.long 0x7e323999                                           // 0000002195A8: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 0000002195AC: BE812000
	s_cbranch_execz 5                                          // 0000002195B0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x7c8>
	global_load_b32 v10, v[26:27], off offset:120              // 0000002195B4: DC520078 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002195BC: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 0000002195C0: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002195C8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002195CC: BE812000
	s_cbranch_execz 5                                          // 0000002195D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x7e8>
	global_load_b32 v10, v[26:27], off offset:124              // 0000002195D4: DC52007C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002195DC: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 0000002195E0: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002195E8: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:32                       // 0000002195EC: DBFC0020 23000022
	ds_load_b128 v[39:42], v34 offset:48                       // 0000002195F4: DBFC0030 27000022
	.long 0x7f143880                                           // 0000002195FC: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219600: BF870001
	.long 0x7e14398a                                           // 000000219604: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 000000219608: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 00000021960C: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 000000219614: BE812000
	s_cbranch_execz 5                                          // 000000219618: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x830>
	global_load_b32 v11, v[26:27], off offset:128              // 00000021961C: DC520080 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000219624: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 000000219628: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219630: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219634: BE812000
	s_cbranch_execz 5                                          // 000000219638: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x850>
	global_load_b32 v11, v[26:27], off offset:132              // 00000021963C: DC520084 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000219644: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 000000219648: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219650: 8C7E017E
	.long 0x7f163880                                           // 000000219654: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219658: BF870001
	.long 0x7e16398b                                           // 00000021965C: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 000000219660: BE812000
	s_cbranch_execz 5                                          // 000000219664: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x87c>
	global_load_b32 v12, v[26:27], off offset:136              // 000000219668: DC520088 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000219670: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 000000219674: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021967C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219680: BE812000
	s_cbranch_execz 5                                          // 000000219684: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x89c>
	global_load_b32 v12, v[26:27], off offset:140              // 000000219688: DC52008C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000219690: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 000000219694: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021969C: 8C7E017E
	.long 0x7f183880                                           // 0000002196A0: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002196A4: BF870001
	.long 0x7e18398c                                           // 0000002196A8: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 0000002196AC: BE812000
	s_cbranch_execz 5                                          // 0000002196B0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x8c8>
	global_load_b32 v13, v[26:27], off offset:144              // 0000002196B4: DC520090 0D7C001A
	s_waitcnt vmcnt(0)                                         // 0000002196BC: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 0000002196C0: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002196C8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002196CC: BE812000
	s_cbranch_execz 5                                          // 0000002196D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x8e8>
	global_load_b32 v13, v[26:27], off offset:148              // 0000002196D4: DC520094 0D7C001A
	s_waitcnt vmcnt(0)                                         // 0000002196DC: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 0000002196E0: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002196E8: 8C7E017E
	.long 0x7f1a3880                                           // 0000002196EC: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002196F0: BF870001
	.long 0x7e1a398d                                           // 0000002196F4: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 0000002196F8: BE812000
	s_cbranch_execz 5                                          // 0000002196FC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x914>
	global_load_b32 v14, v[26:27], off offset:152              // 000000219700: DC520098 0E7C001A
	s_waitcnt vmcnt(0)                                         // 000000219708: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 00000021970C: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219714: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219718: BE812000
	s_cbranch_execz 5                                          // 00000021971C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x934>
	global_load_b32 v14, v[26:27], off offset:156              // 000000219720: DC52009C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 000000219728: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 00000021972C: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219734: 8C7E017E
	.long 0x7f1c3880                                           // 000000219738: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021973C: BF870001
	.long 0x7e1c398e                                           // 000000219740: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 000000219744: BE812000
	s_cbranch_execz 5                                          // 000000219748: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x960>
	global_load_b32 v15, v[26:27], off offset:160              // 00000021974C: DC5200A0 0F7C001A
	s_waitcnt vmcnt(0)                                         // 000000219754: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 000000219758: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219760: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219764: BE812000
	s_cbranch_execz 5                                          // 000000219768: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x980>
	global_load_b32 v15, v[26:27], off offset:164              // 00000021976C: DC5200A4 0F7C001A
	s_waitcnt vmcnt(0)                                         // 000000219774: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 000000219778: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219780: 8C7E017E
	.long 0x7f1e3880                                           // 000000219784: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219788: BF870001
	.long 0x7e1e398f                                           // 00000021978C: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 000000219790: BE812000
	s_cbranch_execz 5                                          // 000000219794: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x9ac>
	global_load_b32 v16, v[26:27], off offset:168              // 000000219798: DC5200A8 107C001A
	s_waitcnt vmcnt(0)                                         // 0000002197A0: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 0000002197A4: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002197AC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002197B0: BE812000
	s_cbranch_execz 5                                          // 0000002197B4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x9cc>
	global_load_b32 v16, v[26:27], off offset:172              // 0000002197B8: DC5200AC 107C001A
	s_waitcnt vmcnt(0)                                         // 0000002197C0: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 0000002197C4: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002197CC: 8C7E017E
	.long 0x7f203880                                           // 0000002197D0: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002197D4: BF870001
	.long 0x7e203990                                           // 0000002197D8: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 0000002197DC: BE812000
	s_cbranch_execz 5                                          // 0000002197E0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x9f8>
	global_load_b32 v17, v[26:27], off offset:176              // 0000002197E4: DC5200B0 117C001A
	s_waitcnt vmcnt(0)                                         // 0000002197EC: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 0000002197F0: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002197F8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002197FC: BE812000
	s_cbranch_execz 5                                          // 000000219800: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xa18>
	global_load_b32 v17, v[26:27], off offset:180              // 000000219804: DC5200B4 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021980C: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 000000219810: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219818: 8C7E017E
	.long 0x7f223880                                           // 00000021981C: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219820: BF870001
	.long 0x7e223991                                           // 000000219824: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 000000219828: BE812000
	s_cbranch_execz 5                                          // 00000021982C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xa44>
	global_load_b32 v18, v[26:27], off offset:184              // 000000219830: DC5200B8 127C001A
	s_waitcnt vmcnt(0)                                         // 000000219838: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 00000021983C: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219844: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219848: BE812000
	s_cbranch_execz 5                                          // 00000021984C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xa64>
	global_load_b32 v18, v[26:27], off offset:188              // 000000219850: DC5200BC 127C001A
	s_waitcnt vmcnt(0)                                         // 000000219858: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 00000021985C: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219864: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:64                       // 000000219868: DBFC0040 23000022
	ds_load_b128 v[39:42], v34 offset:80                       // 000000219870: DBFC0050 27000022
	.long 0x7f243880                                           // 000000219878: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021987C: BF870001
	.long 0x7e243992                                           // 000000219880: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 000000219884: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 000000219888: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 000000219890: BE812000
	s_cbranch_execz 5                                          // 000000219894: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xaac>
	global_load_b32 v10, v[26:27], off offset:192              // 000000219898: DC5200C0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002198A0: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 0000002198A4: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002198AC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002198B0: BE812000
	s_cbranch_execz 5                                          // 0000002198B4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xacc>
	global_load_b32 v10, v[26:27], off offset:196              // 0000002198B8: DC5200C4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002198C0: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 0000002198C4: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002198CC: 8C7E017E
	.long 0x7f263880                                           // 0000002198D0: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002198D4: BF870001
	.long 0x7e263993                                           // 0000002198D8: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 0000002198DC: BE812000
	s_cbranch_execz 5                                          // 0000002198E0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xaf8>
	global_load_b32 v10, v[26:27], off offset:200              // 0000002198E4: DC5200C8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002198EC: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 0000002198F0: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002198F8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002198FC: BE812000
	s_cbranch_execz 5                                          // 000000219900: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xb18>
	global_load_b32 v10, v[26:27], off offset:204              // 000000219904: DC5200CC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021990C: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 000000219910: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219918: 8C7E017E
	.long 0x7f283880                                           // 00000021991C: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219920: BF870001
	.long 0x7e283994                                           // 000000219924: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 000000219928: BE812000
	s_cbranch_execz 5                                          // 00000021992C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xb44>
	global_load_b32 v10, v[26:27], off offset:208              // 000000219930: DC5200D0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219938: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 00000021993C: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219944: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219948: BE812000
	s_cbranch_execz 5                                          // 00000021994C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xb64>
	global_load_b32 v10, v[26:27], off offset:212              // 000000219950: DC5200D4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219958: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 00000021995C: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219964: 8C7E017E
	.long 0x7f2a3880                                           // 000000219968: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021996C: BF870001
	.long 0x7e2a3995                                           // 000000219970: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 000000219974: BE812000
	s_cbranch_execz 5                                          // 000000219978: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xb90>
	global_load_b32 v10, v[26:27], off offset:216              // 00000021997C: DC5200D8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219984: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 000000219988: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219990: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219994: BE812000
	s_cbranch_execz 5                                          // 000000219998: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xbb0>
	global_load_b32 v10, v[26:27], off offset:220              // 00000021999C: DC5200DC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002199A4: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 0000002199A8: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002199B0: 8C7E017E
	.long 0x7f2c3880                                           // 0000002199B4: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002199B8: BF870001
	.long 0x7e2c3996                                           // 0000002199BC: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 0000002199C0: BE812000
	s_cbranch_execz 5                                          // 0000002199C4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xbdc>
	global_load_b32 v10, v[26:27], off offset:224              // 0000002199C8: DC5200E0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002199D0: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 0000002199D4: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002199DC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002199E0: BE812000
	s_cbranch_execz 5                                          // 0000002199E4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xbfc>
	global_load_b32 v10, v[26:27], off offset:228              // 0000002199E8: DC5200E4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002199F0: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 0000002199F4: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002199FC: 8C7E017E
	.long 0x7f2e3880                                           // 000000219A00: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219A04: BF870001
	.long 0x7e2e3997                                           // 000000219A08: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 000000219A0C: BE812000
	s_cbranch_execz 5                                          // 000000219A10: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xc28>
	global_load_b32 v10, v[26:27], off offset:232              // 000000219A14: DC5200E8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219A1C: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 000000219A20: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219A28: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219A2C: BE812000
	s_cbranch_execz 5                                          // 000000219A30: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xc48>
	global_load_b32 v10, v[26:27], off offset:236              // 000000219A34: DC5200EC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219A3C: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 000000219A40: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219A48: 8C7E017E
	.long 0x7f303880                                           // 000000219A4C: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219A50: BF870001
	.long 0x7e303998                                           // 000000219A54: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 000000219A58: BE812000
	s_cbranch_execz 5                                          // 000000219A5C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xc74>
	global_load_b32 v10, v[26:27], off offset:240              // 000000219A60: DC5200F0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219A68: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 000000219A6C: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219A74: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219A78: BE812000
	s_cbranch_execz 5                                          // 000000219A7C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xc94>
	global_load_b32 v10, v[26:27], off offset:244              // 000000219A80: DC5200F4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219A88: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 000000219A8C: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219A94: 8C7E017E
	.long 0x7f323880                                           // 000000219A98: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219A9C: BF870001
	.long 0x7e323999                                           // 000000219AA0: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 000000219AA4: BE812000
	s_cbranch_execz 5                                          // 000000219AA8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xcc0>
	global_load_b32 v10, v[26:27], off offset:248              // 000000219AAC: DC5200F8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219AB4: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 000000219AB8: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219AC0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219AC4: BE812000
	s_cbranch_execz 5                                          // 000000219AC8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xce0>
	global_load_b32 v10, v[26:27], off offset:252              // 000000219ACC: DC5200FC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219AD4: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 000000219AD8: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219AE0: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:96                       // 000000219AE4: DBFC0060 23000022
	ds_load_b128 v[39:42], v34 offset:112                      // 000000219AEC: DBFC0070 27000022
	.long 0x7f143880                                           // 000000219AF4: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219AF8: BF870001
	.long 0x7e14398a                                           // 000000219AFC: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 000000219B00: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 000000219B04: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 000000219B0C: BE812000
	s_cbranch_execz 5                                          // 000000219B10: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xd28>
	global_load_b32 v11, v[26:27], off offset:256              // 000000219B14: DC520100 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000219B1C: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 000000219B20: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219B28: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219B2C: BE812000
	s_cbranch_execz 5                                          // 000000219B30: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xd48>
	global_load_b32 v11, v[26:27], off offset:260              // 000000219B34: DC520104 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000219B3C: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 000000219B40: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219B48: 8C7E017E
	.long 0x7f163880                                           // 000000219B4C: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219B50: BF870001
	.long 0x7e16398b                                           // 000000219B54: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 000000219B58: BE812000
	s_cbranch_execz 5                                          // 000000219B5C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xd74>
	global_load_b32 v12, v[26:27], off offset:264              // 000000219B60: DC520108 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000219B68: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 000000219B6C: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219B74: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219B78: BE812000
	s_cbranch_execz 5                                          // 000000219B7C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xd94>
	global_load_b32 v12, v[26:27], off offset:268              // 000000219B80: DC52010C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000219B88: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 000000219B8C: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219B94: 8C7E017E
	.long 0x7f183880                                           // 000000219B98: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219B9C: BF870001
	.long 0x7e18398c                                           // 000000219BA0: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 000000219BA4: BE812000
	s_cbranch_execz 5                                          // 000000219BA8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xdc0>
	global_load_b32 v13, v[26:27], off offset:272              // 000000219BAC: DC520110 0D7C001A
	s_waitcnt vmcnt(0)                                         // 000000219BB4: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 000000219BB8: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219BC0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219BC4: BE812000
	s_cbranch_execz 5                                          // 000000219BC8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xde0>
	global_load_b32 v13, v[26:27], off offset:276              // 000000219BCC: DC520114 0D7C001A
	s_waitcnt vmcnt(0)                                         // 000000219BD4: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 000000219BD8: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219BE0: 8C7E017E
	.long 0x7f1a3880                                           // 000000219BE4: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219BE8: BF870001
	.long 0x7e1a398d                                           // 000000219BEC: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 000000219BF0: BE812000
	s_cbranch_execz 5                                          // 000000219BF4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xe0c>
	global_load_b32 v14, v[26:27], off offset:280              // 000000219BF8: DC520118 0E7C001A
	s_waitcnt vmcnt(0)                                         // 000000219C00: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 000000219C04: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219C0C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219C10: BE812000
	s_cbranch_execz 5                                          // 000000219C14: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xe2c>
	global_load_b32 v14, v[26:27], off offset:284              // 000000219C18: DC52011C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 000000219C20: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 000000219C24: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219C2C: 8C7E017E
	.long 0x7f1c3880                                           // 000000219C30: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219C34: BF870001
	.long 0x7e1c398e                                           // 000000219C38: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 000000219C3C: BE812000
	s_cbranch_execz 5                                          // 000000219C40: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xe58>
	global_load_b32 v15, v[26:27], off offset:288              // 000000219C44: DC520120 0F7C001A
	s_waitcnt vmcnt(0)                                         // 000000219C4C: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 000000219C50: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219C58: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219C5C: BE812000
	s_cbranch_execz 5                                          // 000000219C60: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xe78>
	global_load_b32 v15, v[26:27], off offset:292              // 000000219C64: DC520124 0F7C001A
	s_waitcnt vmcnt(0)                                         // 000000219C6C: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 000000219C70: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219C78: 8C7E017E
	.long 0x7f1e3880                                           // 000000219C7C: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219C80: BF870001
	.long 0x7e1e398f                                           // 000000219C84: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 000000219C88: BE812000
	s_cbranch_execz 5                                          // 000000219C8C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xea4>
	global_load_b32 v16, v[26:27], off offset:296              // 000000219C90: DC520128 107C001A
	s_waitcnt vmcnt(0)                                         // 000000219C98: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 000000219C9C: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219CA4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219CA8: BE812000
	s_cbranch_execz 5                                          // 000000219CAC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xec4>
	global_load_b32 v16, v[26:27], off offset:300              // 000000219CB0: DC52012C 107C001A
	s_waitcnt vmcnt(0)                                         // 000000219CB8: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 000000219CBC: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219CC4: 8C7E017E
	.long 0x7f203880                                           // 000000219CC8: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219CCC: BF870001
	.long 0x7e203990                                           // 000000219CD0: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 000000219CD4: BE812000
	s_cbranch_execz 5                                          // 000000219CD8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xef0>
	global_load_b32 v17, v[26:27], off offset:304              // 000000219CDC: DC520130 117C001A
	s_waitcnt vmcnt(0)                                         // 000000219CE4: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 000000219CE8: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219CF0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219CF4: BE812000
	s_cbranch_execz 5                                          // 000000219CF8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xf10>
	global_load_b32 v17, v[26:27], off offset:308              // 000000219CFC: DC520134 117C001A
	s_waitcnt vmcnt(0)                                         // 000000219D04: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 000000219D08: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219D10: 8C7E017E
	.long 0x7f223880                                           // 000000219D14: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219D18: BF870001
	.long 0x7e223991                                           // 000000219D1C: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 000000219D20: BE812000
	s_cbranch_execz 5                                          // 000000219D24: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xf3c>
	global_load_b32 v18, v[26:27], off offset:312              // 000000219D28: DC520138 127C001A
	s_waitcnt vmcnt(0)                                         // 000000219D30: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 000000219D34: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219D3C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219D40: BE812000
	s_cbranch_execz 5                                          // 000000219D44: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xf5c>
	global_load_b32 v18, v[26:27], off offset:316              // 000000219D48: DC52013C 127C001A
	s_waitcnt vmcnt(0)                                         // 000000219D50: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 000000219D54: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219D5C: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:128                      // 000000219D60: DBFC0080 23000022
	ds_load_b128 v[39:42], v34 offset:144                      // 000000219D68: DBFC0090 27000022
	.long 0x7f243880                                           // 000000219D70: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219D74: BF870001
	.long 0x7e243992                                           // 000000219D78: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 000000219D7C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 000000219D80: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 000000219D88: BE812000
	s_cbranch_execz 5                                          // 000000219D8C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xfa4>
	global_load_b32 v10, v[26:27], off offset:320              // 000000219D90: DC520140 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219D98: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 000000219D9C: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219DA4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219DA8: BE812000
	s_cbranch_execz 5                                          // 000000219DAC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xfc4>
	global_load_b32 v10, v[26:27], off offset:324              // 000000219DB0: DC520144 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219DB8: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 000000219DBC: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219DC4: 8C7E017E
	.long 0x7f263880                                           // 000000219DC8: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219DCC: BF870001
	.long 0x7e263993                                           // 000000219DD0: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 000000219DD4: BE812000
	s_cbranch_execz 5                                          // 000000219DD8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0xff0>
	global_load_b32 v10, v[26:27], off offset:328              // 000000219DDC: DC520148 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219DE4: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 000000219DE8: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219DF0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219DF4: BE812000
	s_cbranch_execz 5                                          // 000000219DF8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1010>
	global_load_b32 v10, v[26:27], off offset:332              // 000000219DFC: DC52014C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219E04: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 000000219E08: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219E10: 8C7E017E
	.long 0x7f283880                                           // 000000219E14: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219E18: BF870001
	.long 0x7e283994                                           // 000000219E1C: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 000000219E20: BE812000
	s_cbranch_execz 5                                          // 000000219E24: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x103c>
	global_load_b32 v10, v[26:27], off offset:336              // 000000219E28: DC520150 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219E30: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 000000219E34: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219E3C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219E40: BE812000
	s_cbranch_execz 5                                          // 000000219E44: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x105c>
	global_load_b32 v10, v[26:27], off offset:340              // 000000219E48: DC520154 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219E50: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 000000219E54: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219E5C: 8C7E017E
	.long 0x7f2a3880                                           // 000000219E60: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219E64: BF870001
	.long 0x7e2a3995                                           // 000000219E68: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 000000219E6C: BE812000
	s_cbranch_execz 5                                          // 000000219E70: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1088>
	global_load_b32 v10, v[26:27], off offset:344              // 000000219E74: DC520158 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219E7C: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 000000219E80: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219E88: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219E8C: BE812000
	s_cbranch_execz 5                                          // 000000219E90: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x10a8>
	global_load_b32 v10, v[26:27], off offset:348              // 000000219E94: DC52015C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219E9C: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 000000219EA0: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219EA8: 8C7E017E
	.long 0x7f2c3880                                           // 000000219EAC: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219EB0: BF870001
	.long 0x7e2c3996                                           // 000000219EB4: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 000000219EB8: BE812000
	s_cbranch_execz 5                                          // 000000219EBC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x10d4>
	global_load_b32 v10, v[26:27], off offset:352              // 000000219EC0: DC520160 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219EC8: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 000000219ECC: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219ED4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219ED8: BE812000
	s_cbranch_execz 5                                          // 000000219EDC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x10f4>
	global_load_b32 v10, v[26:27], off offset:356              // 000000219EE0: DC520164 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219EE8: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 000000219EEC: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219EF4: 8C7E017E
	.long 0x7f2e3880                                           // 000000219EF8: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219EFC: BF870001
	.long 0x7e2e3997                                           // 000000219F00: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 000000219F04: BE812000
	s_cbranch_execz 5                                          // 000000219F08: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1120>
	global_load_b32 v10, v[26:27], off offset:360              // 000000219F0C: DC520168 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219F14: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 000000219F18: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219F20: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219F24: BE812000
	s_cbranch_execz 5                                          // 000000219F28: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1140>
	global_load_b32 v10, v[26:27], off offset:364              // 000000219F2C: DC52016C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219F34: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 000000219F38: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219F40: 8C7E017E
	.long 0x7f303880                                           // 000000219F44: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219F48: BF870001
	.long 0x7e303998                                           // 000000219F4C: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 000000219F50: BE812000
	s_cbranch_execz 5                                          // 000000219F54: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x116c>
	global_load_b32 v10, v[26:27], off offset:368              // 000000219F58: DC520170 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219F60: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 000000219F64: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219F6C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219F70: BE812000
	s_cbranch_execz 5                                          // 000000219F74: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x118c>
	global_load_b32 v10, v[26:27], off offset:372              // 000000219F78: DC520174 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219F80: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 000000219F84: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219F8C: 8C7E017E
	.long 0x7f323880                                           // 000000219F90: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219F94: BF870001
	.long 0x7e323999                                           // 000000219F98: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 000000219F9C: BE812000
	s_cbranch_execz 5                                          // 000000219FA0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x11b8>
	global_load_b32 v10, v[26:27], off offset:376              // 000000219FA4: DC520178 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219FAC: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 000000219FB0: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219FB8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000219FBC: BE812000
	s_cbranch_execz 5                                          // 000000219FC0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x11d8>
	global_load_b32 v10, v[26:27], off offset:380              // 000000219FC4: DC52017C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000219FCC: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 000000219FD0: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000219FD8: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:160                      // 000000219FDC: DBFC00A0 23000022
	ds_load_b128 v[39:42], v34 offset:176                      // 000000219FE4: DBFC00B0 27000022
	.long 0x7f143880                                           // 000000219FEC: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000219FF0: BF870001
	.long 0x7e14398a                                           // 000000219FF4: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 000000219FF8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 000000219FFC: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 00000021A004: BE812000
	s_cbranch_execz 5                                          // 00000021A008: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1220>
	global_load_b32 v11, v[26:27], off offset:384              // 00000021A00C: DC520180 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A014: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 00000021A018: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A020: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A024: BE812000
	s_cbranch_execz 5                                          // 00000021A028: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1240>
	global_load_b32 v11, v[26:27], off offset:388              // 00000021A02C: DC520184 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A034: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 00000021A038: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A040: 8C7E017E
	.long 0x7f163880                                           // 00000021A044: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A048: BF870001
	.long 0x7e16398b                                           // 00000021A04C: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 00000021A050: BE812000
	s_cbranch_execz 5                                          // 00000021A054: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x126c>
	global_load_b32 v12, v[26:27], off offset:392              // 00000021A058: DC520188 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A060: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 00000021A064: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A06C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A070: BE812000
	s_cbranch_execz 5                                          // 00000021A074: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x128c>
	global_load_b32 v12, v[26:27], off offset:396              // 00000021A078: DC52018C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A080: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 00000021A084: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A08C: 8C7E017E
	.long 0x7f183880                                           // 00000021A090: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A094: BF870001
	.long 0x7e18398c                                           // 00000021A098: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000021A09C: BE812000
	s_cbranch_execz 5                                          // 00000021A0A0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x12b8>
	global_load_b32 v13, v[26:27], off offset:400              // 00000021A0A4: DC520190 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A0AC: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 00000021A0B0: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A0B8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A0BC: BE812000
	s_cbranch_execz 5                                          // 00000021A0C0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x12d8>
	global_load_b32 v13, v[26:27], off offset:404              // 00000021A0C4: DC520194 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A0CC: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 00000021A0D0: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A0D8: 8C7E017E
	.long 0x7f1a3880                                           // 00000021A0DC: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A0E0: BF870001
	.long 0x7e1a398d                                           // 00000021A0E4: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 00000021A0E8: BE812000
	s_cbranch_execz 5                                          // 00000021A0EC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1304>
	global_load_b32 v14, v[26:27], off offset:408              // 00000021A0F0: DC520198 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A0F8: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 00000021A0FC: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A104: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A108: BE812000
	s_cbranch_execz 5                                          // 00000021A10C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1324>
	global_load_b32 v14, v[26:27], off offset:412              // 00000021A110: DC52019C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A118: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 00000021A11C: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A124: 8C7E017E
	.long 0x7f1c3880                                           // 00000021A128: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A12C: BF870001
	.long 0x7e1c398e                                           // 00000021A130: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000021A134: BE812000
	s_cbranch_execz 5                                          // 00000021A138: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1350>
	global_load_b32 v15, v[26:27], off offset:416              // 00000021A13C: DC5201A0 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A144: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 00000021A148: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A150: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A154: BE812000
	s_cbranch_execz 5                                          // 00000021A158: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1370>
	global_load_b32 v15, v[26:27], off offset:420              // 00000021A15C: DC5201A4 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A164: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 00000021A168: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A170: 8C7E017E
	.long 0x7f1e3880                                           // 00000021A174: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A178: BF870001
	.long 0x7e1e398f                                           // 00000021A17C: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 00000021A180: BE812000
	s_cbranch_execz 5                                          // 00000021A184: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x139c>
	global_load_b32 v16, v[26:27], off offset:424              // 00000021A188: DC5201A8 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021A190: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 00000021A194: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A19C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A1A0: BE812000
	s_cbranch_execz 5                                          // 00000021A1A4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x13bc>
	global_load_b32 v16, v[26:27], off offset:428              // 00000021A1A8: DC5201AC 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021A1B0: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 00000021A1B4: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A1BC: 8C7E017E
	.long 0x7f203880                                           // 00000021A1C0: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A1C4: BF870001
	.long 0x7e203990                                           // 00000021A1C8: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 00000021A1CC: BE812000
	s_cbranch_execz 5                                          // 00000021A1D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x13e8>
	global_load_b32 v17, v[26:27], off offset:432              // 00000021A1D4: DC5201B0 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021A1DC: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 00000021A1E0: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A1E8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A1EC: BE812000
	s_cbranch_execz 5                                          // 00000021A1F0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1408>
	global_load_b32 v17, v[26:27], off offset:436              // 00000021A1F4: DC5201B4 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021A1FC: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 00000021A200: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A208: 8C7E017E
	.long 0x7f223880                                           // 00000021A20C: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A210: BF870001
	.long 0x7e223991                                           // 00000021A214: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 00000021A218: BE812000
	s_cbranch_execz 5                                          // 00000021A21C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1434>
	global_load_b32 v18, v[26:27], off offset:440              // 00000021A220: DC5201B8 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021A228: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 00000021A22C: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A234: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A238: BE812000
	s_cbranch_execz 5                                          // 00000021A23C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1454>
	global_load_b32 v18, v[26:27], off offset:444              // 00000021A240: DC5201BC 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021A248: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 00000021A24C: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A254: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:192                      // 00000021A258: DBFC00C0 23000022
	ds_load_b128 v[39:42], v34 offset:208                      // 00000021A260: DBFC00D0 27000022
	.long 0x7f243880                                           // 00000021A268: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A26C: BF870001
	.long 0x7e243992                                           // 00000021A270: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 00000021A274: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000021A278: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 00000021A280: BE812000
	s_cbranch_execz 5                                          // 00000021A284: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x149c>
	global_load_b32 v10, v[26:27], off offset:448              // 00000021A288: DC5201C0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A290: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 00000021A294: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A29C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A2A0: BE812000
	s_cbranch_execz 5                                          // 00000021A2A4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x14bc>
	global_load_b32 v10, v[26:27], off offset:452              // 00000021A2A8: DC5201C4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A2B0: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 00000021A2B4: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A2BC: 8C7E017E
	.long 0x7f263880                                           // 00000021A2C0: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A2C4: BF870001
	.long 0x7e263993                                           // 00000021A2C8: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000021A2CC: BE812000
	s_cbranch_execz 5                                          // 00000021A2D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x14e8>
	global_load_b32 v10, v[26:27], off offset:456              // 00000021A2D4: DC5201C8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A2DC: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 00000021A2E0: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A2E8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A2EC: BE812000
	s_cbranch_execz 5                                          // 00000021A2F0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1508>
	global_load_b32 v10, v[26:27], off offset:460              // 00000021A2F4: DC5201CC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A2FC: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 00000021A300: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A308: 8C7E017E
	.long 0x7f283880                                           // 00000021A30C: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A310: BF870001
	.long 0x7e283994                                           // 00000021A314: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000021A318: BE812000
	s_cbranch_execz 5                                          // 00000021A31C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1534>
	global_load_b32 v10, v[26:27], off offset:464              // 00000021A320: DC5201D0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A328: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 00000021A32C: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A334: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A338: BE812000
	s_cbranch_execz 5                                          // 00000021A33C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1554>
	global_load_b32 v10, v[26:27], off offset:468              // 00000021A340: DC5201D4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A348: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 00000021A34C: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A354: 8C7E017E
	.long 0x7f2a3880                                           // 00000021A358: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A35C: BF870001
	.long 0x7e2a3995                                           // 00000021A360: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000021A364: BE812000
	s_cbranch_execz 5                                          // 00000021A368: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1580>
	global_load_b32 v10, v[26:27], off offset:472              // 00000021A36C: DC5201D8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A374: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 00000021A378: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A380: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A384: BE812000
	s_cbranch_execz 5                                          // 00000021A388: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x15a0>
	global_load_b32 v10, v[26:27], off offset:476              // 00000021A38C: DC5201DC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A394: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 00000021A398: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A3A0: 8C7E017E
	.long 0x7f2c3880                                           // 00000021A3A4: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A3A8: BF870001
	.long 0x7e2c3996                                           // 00000021A3AC: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000021A3B0: BE812000
	s_cbranch_execz 5                                          // 00000021A3B4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x15cc>
	global_load_b32 v10, v[26:27], off offset:480              // 00000021A3B8: DC5201E0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A3C0: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 00000021A3C4: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A3CC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A3D0: BE812000
	s_cbranch_execz 5                                          // 00000021A3D4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x15ec>
	global_load_b32 v10, v[26:27], off offset:484              // 00000021A3D8: DC5201E4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A3E0: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 00000021A3E4: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A3EC: 8C7E017E
	.long 0x7f2e3880                                           // 00000021A3F0: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A3F4: BF870001
	.long 0x7e2e3997                                           // 00000021A3F8: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000021A3FC: BE812000
	s_cbranch_execz 5                                          // 00000021A400: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1618>
	global_load_b32 v10, v[26:27], off offset:488              // 00000021A404: DC5201E8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A40C: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 00000021A410: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A418: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A41C: BE812000
	s_cbranch_execz 5                                          // 00000021A420: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1638>
	global_load_b32 v10, v[26:27], off offset:492              // 00000021A424: DC5201EC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A42C: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 00000021A430: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A438: 8C7E017E
	.long 0x7f303880                                           // 00000021A43C: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A440: BF870001
	.long 0x7e303998                                           // 00000021A444: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000021A448: BE812000
	s_cbranch_execz 5                                          // 00000021A44C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1664>
	global_load_b32 v10, v[26:27], off offset:496              // 00000021A450: DC5201F0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A458: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 00000021A45C: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A464: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A468: BE812000
	s_cbranch_execz 5                                          // 00000021A46C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1684>
	global_load_b32 v10, v[26:27], off offset:500              // 00000021A470: DC5201F4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A478: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 00000021A47C: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A484: 8C7E017E
	.long 0x7f323880                                           // 00000021A488: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A48C: BF870001
	.long 0x7e323999                                           // 00000021A490: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000021A494: BE812000
	s_cbranch_execz 5                                          // 00000021A498: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x16b0>
	global_load_b32 v10, v[26:27], off offset:504              // 00000021A49C: DC5201F8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A4A4: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 00000021A4A8: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A4B0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021A4B4: BE812000
	s_cbranch_execz 5                                          // 00000021A4B8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x16d0>
	global_load_b32 v10, v[26:27], off offset:508              // 00000021A4BC: DC5201FC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021A4C4: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 00000021A4C8: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021A4D0: 8C7E017E
	ds_load_b128 v[10:13], v34 offset:224                      // 00000021A4D4: DBFC00E0 0A000022
	ds_load_b128 v[14:17], v34 offset:240                      // 00000021A4DC: DBFC00F0 0E000022
	s_waitcnt lgkmcnt(0)                                       // 00000021A4E4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[10:17], v[2:9] // 00000021A4E8: CC404002 1C0A1512
	s_or_b32 exec_lo, exec_lo, s9                              // 00000021A4F0: 8C7E097E
	v_or_b32_e32 v11, v0, v31                                  // 00000021A4F4: 38163F00
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 00000021A4F8: CA100080 0C0C0080
	s_xor_b32 s1, vcc_lo, -1                                   // 00000021A500: 8D01C16A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000021A504: BF8704B2
	.long 0xd44b0000                                           // 00000021A508: D44B0000
	v_cndmask_b32_e32 v1, v29, v11, vcc_lo                     // 00000021A50C: 0202171D
	v_lshlrev_b32_e32 v10, 2, v11                              // 00000021A510: 30141682
	s_and_b32 s9, s1, s0                                       // 00000021A514: 8B090001
	s_and_saveexec_b32 s0, s9                                  // 00000021A518: BE802009
	s_cbranch_execz 36                                         // 00000021A51C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x17b0>
	ds_load_b32 v0, v10 offset:18432                           // 00000021A520: D8D84800 0000000A
	ds_load_b32 v13, v32                                       // 00000021A528: D8D80000 0D000020
	s_waitcnt lgkmcnt(0)                                       // 00000021A530: BF89FC07
	v_sub_f32_e32 v0, v0, v13                                  // 00000021A534: 08001B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A538: BF870091
	v_mul_f32_e32 v13, 0x3fb8aa3b, v0                          // 00000021A53C: 101A00FF 3FB8AA3B
	v_fma_f32 v14, 0x3fb8aa3b, v0, -v13                        // 00000021A544: D613000E 843600FF 3FB8AA3B
	v_rndne_f32_e32 v15, v13                                   // 00000021A550: 7E1E470D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000021A554: BF870221
	v_sub_f32_e32 v13, v13, v15                                // 00000021A558: 081A1F0D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021A55C: 7C3600FF C2CE8ED0
	v_fmac_f32_e32 v14, 0x32a5705f, v0                         // 00000021A564: 561C00FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021A56C: BF870121
	v_add_f32_e32 v13, v13, v14                                // 00000021A570: 061A1D0D
	v_cvt_i32_f32_e32 v14, v15                                 // 00000021A574: 7E1C110F
	v_exp_f32_e32 v13, v13                                     // 00000021A578: 7E1A4B0D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A57C: BF870095
	.long 0xd71c000d                                           // 00000021A580: D71C000D
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                     // 00000021A584: 02021D0D
	v_cndmask_b32_e32 v13, 0, v13, vcc_lo                      // 00000021A588: 021A1A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021A58C: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A594: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v13, vcc_lo              // 00000021A598: 02001AFF 7F800000
	v_mul_f32_e32 v0, 0x47800000, v0                           // 00000021A5A0: 100000FF 47800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A5A8: BF870001
	v_mul_f32_e32 v13, v2, v0                                  // 00000021A5AC: 101A0102
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021A5B0: 8C7E007E
	v_lshl_or_b32 v0, v11, 6, v29                              // 00000021A5B4: D6560000 04750D0B
	v_or_b32_e32 v2, 2, v11                                    // 00000021A5BC: 38041682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021A5C0: BF870112
	.long 0xd73c000e                                           // 00000021A5C4: D73C000E
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021A5C8: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v2                           // 00000021A5CC: 7C96051D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021A5D0: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A5D4: BF870092
	.long 0xd700000e                                           // 00000021A5D8: D700000E
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 00000021A5DC: 02021C02
	v_add_co_ci_u32_e64 v15, null, s6, v15, s0                 // 00000021A5E0: D5207C0F 00021E06
	global_store_b32 v[14:15], v13, off                        // 00000021A5E8: DC6A0000 007C0D0E
	s_and_saveexec_b32 s0, s9                                  // 00000021A5F0: BE802009
	s_cbranch_execz 35                                         // 00000021A5F4: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1884>
	ds_load_b32 v0, v10 offset:18440                           // 00000021A5F8: D8D84808 0000000A
	ds_load_b32 v12, v32                                       // 00000021A600: D8D80000 0C000020
	s_waitcnt lgkmcnt(0)                                       // 00000021A608: BF89FC07
	v_sub_f32_e32 v0, v0, v12                                  // 00000021A60C: 08001900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021A610: BF870121
	v_mul_f32_e32 v12, 0x3fb8aa3b, v0                          // 00000021A614: 101800FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021A61C: 7C3600FF C2CE8ED0
	v_fma_f32 v13, 0x3fb8aa3b, v0, -v12                        // 00000021A624: D613000D 843200FF 3FB8AA3B
	v_rndne_f32_e32 v14, v12                                   // 00000021A630: 7E1C470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A634: BF870091
	v_dual_fmac_f32 v13, 0x32a5705f, v0 :: v_dual_sub_f32 v12, v12, v14// 00000021A638: C80A00FF 0D0C1D0C 32A5705F
	v_add_f32_e32 v12, v12, v13                                // 00000021A644: 06181B0C
	v_cvt_i32_f32_e32 v13, v14                                 // 00000021A648: 7E1A110E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000021A64C: BF870292
	v_exp_f32_e32 v12, v12                                     // 00000021A650: 7E184B0C
	.long 0xd71c000c                                           // 00000021A654: D71C000C
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                     // 00000021A658: 02021B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021A65C: BF870121
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 00000021A660: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021A664: 7C3C00FF 42B17218
	v_cndmask_b32_e32 v0, 0x7f800000, v12, vcc_lo              // 00000021A66C: 020018FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A674: BF870091
	v_mul_f32_e32 v0, 0x47800000, v0                           // 00000021A678: 100000FF 47800000
	v_mul_f32_e32 v12, v3, v0                                  // 00000021A680: 10180103
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021A684: 8C7E007E
	v_lshl_or_b32 v0, v2, 6, v29                               // 00000021A688: D6560000 04750D02
	v_or_b32_e32 v3, 4, v11                                    // 00000021A690: 38061684
	v_mov_b32_e32 v2, 0                                        // 00000021A694: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000021A698: BF870193
	.long 0xd73c000d                                           // 00000021A69C: D73C000D
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021A6A0: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 00000021A6A4: 7C96071D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021A6A8: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A6AC: BF870092
	.long 0xd700000f                                           // 00000021A6B0: D700000F
	v_cndmask_b32_e32 v1, s2, v13, vcc_lo                      // 00000021A6B4: 02021A02
	v_add_co_ci_u32_e64 v16, null, s6, v14, s0                 // 00000021A6B8: D5207C10 00021C06
	v_mov_b32_e32 v13, 0                                       // 00000021A6C0: 7E1A0280
	global_store_b32 v[15:16], v12, off                        // 00000021A6C4: DC6A0000 007C0C0F
	s_and_saveexec_b32 s0, s9                                  // 00000021A6CC: BE802009
	s_cbranch_execz 35                                         // 00000021A6D0: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1960>
	ds_load_b32 v0, v10 offset:18448                           // 00000021A6D4: D8D84810 0000000A
	ds_load_b32 v12, v32                                       // 00000021A6DC: D8D80000 0C000020
	s_waitcnt lgkmcnt(0)                                       // 00000021A6E4: BF89FC07
	v_sub_f32_e32 v0, v0, v12                                  // 00000021A6E8: 08001900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021A6EC: BF870121
	v_mul_f32_e32 v12, 0x3fb8aa3b, v0                          // 00000021A6F0: 101800FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021A6F8: 7C3600FF C2CE8ED0
	v_fma_f32 v13, 0x3fb8aa3b, v0, -v12                        // 00000021A700: D613000D 843200FF 3FB8AA3B
	v_rndne_f32_e32 v14, v12                                   // 00000021A70C: 7E1C470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A710: BF870091
	v_dual_fmac_f32 v13, 0x32a5705f, v0 :: v_dual_sub_f32 v12, v12, v14// 00000021A714: C80A00FF 0D0C1D0C 32A5705F
	v_add_f32_e32 v12, v12, v13                                // 00000021A720: 06181B0C
	v_cvt_i32_f32_e32 v13, v14                                 // 00000021A724: 7E1A110E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000021A728: BF870292
	v_exp_f32_e32 v12, v12                                     // 00000021A72C: 7E184B0C
	.long 0xd71c000c                                           // 00000021A730: D71C000C
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                     // 00000021A734: 02021B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021A738: BF870121
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 00000021A73C: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021A740: 7C3C00FF 42B17218
	v_cndmask_b32_e32 v0, 0x7f800000, v12, vcc_lo              // 00000021A748: 020018FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A750: BF870091
	v_mul_f32_e32 v0, 0x47800000, v0                           // 00000021A754: 100000FF 47800000
	v_mul_f32_e32 v13, v4, v0                                  // 00000021A75C: 101A0104
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021A760: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 00000021A764: D6560000 04750D03
	v_or_b32_e32 v3, 6, v11                                    // 00000021A76C: 38061686
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021A770: BF870112
	.long 0xd73c000e                                           // 00000021A774: D73C000E
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021A778: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 00000021A77C: 7C96071D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021A780: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A784: BF870092
	.long 0xd700000e                                           // 00000021A788: D700000E
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 00000021A78C: 02021C02
	v_add_co_ci_u32_e64 v15, null, s6, v15, s0                 // 00000021A790: D5207C0F 00021E06
	global_store_b32 v[14:15], v13, off                        // 00000021A798: DC6A0000 007C0D0E
	s_and_saveexec_b32 s0, s9                                  // 00000021A7A0: BE802009
	s_cbranch_execz 36                                         // 00000021A7A4: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1a38>
	ds_load_b32 v0, v10 offset:18456                           // 00000021A7A8: D8D84818 0000000A
	ds_load_b32 v2, v32                                        // 00000021A7B0: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 00000021A7B8: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 00000021A7BC: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021A7C0: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 00000021A7C4: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021A7CC: 7C3600FF C2CE8ED0
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v2                          // 00000021A7D4: D6130004 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v12, v2                                    // 00000021A7E0: 7E184702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021A7E4: BF870112
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 00000021A7E8: 560800FF 32A5705F
	v_sub_f32_e32 v2, v2, v12                                  // 00000021A7F0: 08041902
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021A7F4: BF870121
	v_add_f32_e32 v2, v2, v4                                   // 00000021A7F8: 06040902
	v_cvt_i32_f32_e32 v4, v12                                  // 00000021A7FC: 7E08110C
	v_exp_f32_e32 v2, v2                                       // 00000021A800: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A804: BF870095
	.long 0xd71c0002                                           // 00000021A808: D71C0002
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000021A80C: 02020902
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000021A810: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021A814: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A81C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 00000021A820: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x47800000, v0                           // 00000021A828: 100000FF 47800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A830: BF870001
	v_mul_f32_e32 v2, v5, v0                                   // 00000021A834: 10040105
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021A838: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 00000021A83C: D6560000 04750D03
	v_or_b32_e32 v4, 8, v11                                    // 00000021A844: 38081688
	v_mov_b32_e32 v3, 0                                        // 00000021A848: 7E060280
	v_mov_b32_e32 v5, 0                                        // 00000021A84C: 7E0A0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000021A850: BF870214
	.long 0xd73c000c                                           // 00000021A854: D73C000C
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021A858: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v4                           // 00000021A85C: 7C96091D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021A860: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A864: BF870092
	.long 0xd700000c                                           // 00000021A868: D700000C
	v_cndmask_b32_e32 v1, s2, v12, vcc_lo                      // 00000021A86C: 02021802
	v_add_co_ci_u32_e64 v13, null, s6, v13, s0                 // 00000021A870: D5207C0D 00021A06
	global_store_b32 v[12:13], v2, off                         // 00000021A878: DC6A0000 007C020C
	s_and_saveexec_b32 s0, s9                                  // 00000021A880: BE802009
	s_cbranch_execz 36                                         // 00000021A884: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1b18>
	ds_load_b32 v0, v10 offset:18464                           // 00000021A888: D8D84820 0000000A
	ds_load_b32 v2, v32                                        // 00000021A890: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 00000021A898: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 00000021A89C: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021A8A0: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 00000021A8A4: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021A8AC: 7C3600FF C2CE8ED0
	v_fma_f32 v5, 0x3fb8aa3b, v0, -v2                          // 00000021A8B4: D6130005 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v12, v2                                    // 00000021A8C0: 7E184702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021A8C4: BF870112
	v_fmac_f32_e32 v5, 0x32a5705f, v0                          // 00000021A8C8: 560A00FF 32A5705F
	v_sub_f32_e32 v2, v2, v12                                  // 00000021A8D0: 08041902
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021A8D4: BF870121
	v_add_f32_e32 v2, v2, v5                                   // 00000021A8D8: 06040B02
	v_cvt_i32_f32_e32 v5, v12                                  // 00000021A8DC: 7E0A110C
	v_exp_f32_e32 v2, v2                                       // 00000021A8E0: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A8E4: BF870095
	.long 0xd71c0002                                           // 00000021A8E8: D71C0002
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 00000021A8EC: 02020B02
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000021A8F0: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021A8F4: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A8FC: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 00000021A900: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x47800000, v0                           // 00000021A908: 100000FF 47800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A910: BF870001
	v_mul_f32_e32 v5, v6, v0                                   // 00000021A914: 100A0106
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021A918: 8C7E007E
	v_lshl_or_b32 v0, v4, 6, v29                               // 00000021A91C: D6560000 04750D04
	v_or_b32_e32 v2, 10, v11                                   // 00000021A924: 3804168A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021A928: BF870112
	.long 0xd73c000c                                           // 00000021A92C: D73C000C
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021A930: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v2                           // 00000021A934: 7C96051D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021A938: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A93C: BF870092
	.long 0xd700000c                                           // 00000021A940: D700000C
	v_cndmask_b32_e32 v1, s2, v12, vcc_lo                      // 00000021A944: 02021802
	v_add_co_ci_u32_e64 v13, null, s6, v13, s0                 // 00000021A948: D5207C0D 00021A06
	global_store_b32 v[12:13], v5, off                         // 00000021A950: DC6A0000 007C050C
	s_and_saveexec_b32 s0, s9                                  // 00000021A958: BE802009
	s_cbranch_execz 36                                         // 00000021A95C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1bf0>
	ds_load_b32 v0, v10 offset:18472                           // 00000021A960: D8D84828 0000000A
	ds_load_b32 v3, v32                                        // 00000021A968: D8D80000 03000020
	s_waitcnt lgkmcnt(0)                                       // 00000021A970: BF89FC07
	v_sub_f32_e32 v0, v0, v3                                   // 00000021A974: 08000700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A978: BF870091
	v_mul_f32_e32 v3, 0x3fb8aa3b, v0                           // 00000021A97C: 100600FF 3FB8AA3B
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v3                          // 00000021A984: D6130004 840E00FF 3FB8AA3B
	v_rndne_f32_e32 v5, v3                                     // 00000021A990: 7E0A4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000021A994: BF870221
	v_sub_f32_e32 v3, v3, v5                                   // 00000021A998: 08060B03
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021A99C: 7C3600FF C2CE8ED0
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 00000021A9A4: 560800FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021A9AC: BF870121
	v_add_f32_e32 v3, v3, v4                                   // 00000021A9B0: 06060903
	v_cvt_i32_f32_e32 v4, v5                                   // 00000021A9B4: 7E081105
	v_exp_f32_e32 v3, v3                                       // 00000021A9B8: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A9BC: BF870095
	.long 0xd71c0003                                           // 00000021A9C0: D71C0003
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 00000021A9C4: 02020903
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 00000021A9C8: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021A9CC: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021A9D4: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v3, vcc_lo               // 00000021A9D8: 020006FF 7F800000
	v_mul_f32_e32 v0, 0x47800000, v0                           // 00000021A9E0: 100000FF 47800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021A9E8: BF870001
	v_mul_f32_e32 v3, v7, v0                                   // 00000021A9EC: 10060107
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021A9F0: 8C7E007E
	v_lshl_or_b32 v0, v2, 6, v29                               // 00000021A9F4: D6560000 04750D02
	v_or_b32_e32 v4, 12, v11                                   // 00000021A9FC: 3808168C
	v_mov_b32_e32 v2, 0                                        // 00000021AA00: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000021AA04: BF870193
	.long 0xd73c0005                                           // 00000021AA08: D73C0005
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021AA0C: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v4                           // 00000021AA10: 7C96091D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021AA14: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021AA18: BF870092
	.long 0xd700000c                                           // 00000021AA1C: D700000C
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000021AA20: 02020A02
	v_add_co_ci_u32_e64 v13, null, s6, v6, s0                  // 00000021AA24: D5207C0D 00020C06
	v_mov_b32_e32 v5, 0                                        // 00000021AA2C: 7E0A0280
	global_store_b32 v[12:13], v3, off                         // 00000021AA30: DC6A0000 007C030C
	s_and_saveexec_b32 s0, s9                                  // 00000021AA38: BE802009
	s_cbranch_execz 36                                         // 00000021AA3C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x1cd0>
	ds_load_b32 v0, v10 offset:18480                           // 00000021AA40: D8D84830 0000000A
	ds_load_b32 v3, v32                                        // 00000021AA48: D8D80000 03000020
	s_waitcnt lgkmcnt(0)                                       // 00000021AA50: BF89FC07
	v_sub_f32_e32 v0, v0, v3                                   // 00000021AA54: 08000700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021AA58: BF870091
	v_mul_f32_e32 v3, 0x3fb8aa3b, v0                           // 00000021AA5C: 100600FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v0, -v3                          // 00000021AA64: D6130005 840E00FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 00000021AA70: 7E0C4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000021AA74: BF870191
	v_sub_f32_e32 v3, v3, v6                                   // 00000021AA78: 08060D03
	v_fmac_f32_e32 v5, 0x32a5705f, v0                          // 00000021AA7C: 560A00FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021AA84: 7C3600FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021AA8C: BF870122
	v_add_f32_e32 v3, v3, v5                                   // 00000021AA90: 06060B03
	v_cvt_i32_f32_e32 v5, v6                                   // 00000021AA94: 7E0A1106
	v_exp_f32_e32 v3, v3                                       // 00000021AA98: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021AA9C: BF870095
	.long 0xd71c0003                                           // 00000021AAA0: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000021AAA4: 02020B03
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 00000021AAA8: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021AAAC: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021AAB4: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v3, vcc_lo               // 00000021AAB8: 020006FF 7F800000
	v_mul_f32_e32 v0, 0x47800000, v0                           // 00000021AAC0: 100000FF 47800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021AAC8: BF870001
	v_mul_f32_e32 v5, v8, v0                                   // 00000021AACC: 100A0108
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021AAD0: 8C7E007E
	v_lshl_or_b32 v0, v4, 6, v29                               // 00000021AAD4: D6560000 04750D04
	v_or_b32_e32 v3, 14, v11                                   // 00000021AADC: 3806168E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021AAE0: BF870112
	.long 0xd73c0006                                           // 00000021AAE4: D73C0006
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021AAE8: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 00000021AAEC: 7C96071D
	s_and_b32 s1, s1, vcc_lo                                   // 00000021AAF0: 8B016A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021AAF4: BF870092
	.long 0xd7000006                                           // 00000021AAF8: D7000006
	v_cndmask_b32_e32 v1, s2, v6, vcc_lo                       // 00000021AAFC: 02020C02
	v_add_co_ci_u32_e64 v7, null, s6, v7, s0                   // 00000021AB00: D5207C07 00020E06
	global_store_b32 v[6:7], v5, off                           // 00000021AB08: DC6A0000 007C0506
	s_and_saveexec_b32 s0, s1                                  // 00000021AB10: BE802001
	s_cbranch_execz 63806                                      // 00000021AB14: BFA5F93E <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x210>
	ds_load_b32 v0, v10 offset:18488                           // 00000021AB18: D8D84838 0000000A
	ds_load_b32 v2, v32                                        // 00000021AB20: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 00000021AB28: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 00000021AB2C: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021AB30: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 00000021AB34: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021AB3C: 7C3600FF C2CE8ED0
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v2                          // 00000021AB44: D6130004 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v5, v2                                     // 00000021AB50: 7E0A4702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021AB54: BF870112
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 00000021AB58: 560800FF 32A5705F
	v_sub_f32_e32 v2, v2, v5                                   // 00000021AB60: 08040B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021AB64: BF870121
	v_add_f32_e32 v2, v2, v4                                   // 00000021AB68: 06040902
	v_cvt_i32_f32_e32 v4, v5                                   // 00000021AB6C: 7E081105
	v_exp_f32_e32 v2, v2                                       // 00000021AB70: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021AB74: BF870095
	.long 0xd71c0002                                           // 00000021AB78: D71C0002
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000021AB7C: 02020902
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000021AB80: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021AB84: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021AB8C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 00000021AB90: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x47800000, v0                           // 00000021AB98: 100000FF 47800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021ABA0: BF870001
	v_mul_f32_e32 v2, v9, v0                                   // 00000021ABA4: 10040109
	s_branch 63769                                             // 00000021ABA8: BFA0F919 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin8EEEvPKfS3_S3_Pfi+0x210>
	s_endpgm                                                   // 00000021ABAC: BFB00000
		...

