000000000006e300 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 00000006E300: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 00000006E304: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 00000006E30C: F4080500 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 00000006E314: 3706009F
	v_lshrrev_b32_e32 v156, 5, v0                              // 00000006E318: 33380085
	s_mov_b32 s24, s3                                          // 00000006E31C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006E320: BF870112
	.long 0xd44c0003                                           // 00000006E324: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 00000006E328: 02030690
	v_lshlrev_b32_e32 v132, 6, v156                            // 00000006E32C: 31093886
	s_waitcnt lgkmcnt(0)                                       // 00000006E330: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 00000006E334: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 00000006E33C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006E340: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 00000006E344: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 00000006E34C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:156 offset1:162// 00000006E358: D83CA29C 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006E360: 8C7E047E
	v_mul_u32_u24_e32 v1, 0xab, v0                             // 00000006E364: 160200FF 000000AB
	.long 0x7f043880                                           // 00000006E36C: 7F043880
	v_dual_mov_b32 v141, 0 :: v_dual_and_b32 v154, 15, v0      // 00000006E370: CA240080 8D9A008F
	s_cmp_eq_u64 s[14:15], 0                                   // 00000006E378: BF10800E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000006E37C: BF8704B3
	.long 0x7e043981                                           // 00000006E380: 7E043981
	v_mov_b32_e32 v142, 0                                      // 00000006E384: 7F1C0280
	s_cselect_b32 s25, -1, 0                                   // 00000006E388: 981980C1
	s_and_b32 vcc_lo, exec_lo, s25                             // 00000006E38C: 8B6A197E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E390: BF870092
	v_add_lshl_u32 v155, s2, v2, 4                             // 00000006E394: D647009B 02120402
	v_or_b32_e32 v129, v155, v154                              // 00000006E39C: 3903359B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006E3A0: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 00000006E3A4: 3505029F
	s_cbranch_vccnz 10                                         // 00000006E3A8: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xd4>
	v_mad_i64_i32 v[1:2], null, s23, v129, 0                   // 00000006E3AC: D6FF7C01 02030217
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E3B4: BF870091
	.long 0xd73c0001                                           // 00000006E3B8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000006E3BC: 02020282
	.long 0xd7006a8d                                           // 00000006E3C0: D7006A8D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000006E3C4: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006E3C8: BF870001
	v_add_co_ci_u32_e64 v142, null, s15, v2, vcc_lo            // 00000006E3CC: D5207C8E 01AA040F
	s_clause 0x2                                               // 00000006E3D4: BF850002
	s_load_b64 s[14:15], s[0:1], 0x38                          // 00000006E3D8: F4040380 F8000038
	s_load_b128 s[16:19], s[0:1], 0x20                         // 00000006E3E0: F4080400 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 00000006E3E8: F40C0100 F8000000
	v_mov_b32_e32 v158, 0                                      // 00000006E3F0: 7F3C0280
	s_xor_b32 s0, s25, -1                                      // 00000006E3F4: 8D00C119
	s_waitcnt lgkmcnt(0)                                       // 00000006E3F8: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v129                         // 00000006E3FC: 7C89020E
	s_and_b32 s23, s0, vcc_lo                                  // 00000006E400: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006E404: BF870009
	s_and_saveexec_b32 s0, s23                                 // 00000006E408: BE802017
	s_cbranch_execz 9                                          // 00000006E40C: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x134>
	.long 0xd73c0001                                           // 00000006E410: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 00000006E414: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E418: BF870091
	.long 0xd7006a01                                           // 00000006E41C: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 00000006E420: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 00000006E424: D5207C02 01AA0415
	global_load_b32 v158, v[1:2], off                          // 00000006E42C: DC520000 9E7C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 00000006E434: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 00000006E438: BF10800C
	s_mov_b64 s[20:21], 0                                      // 00000006E43C: BE940180
	s_cbranch_scc1 10                                          // 00000006E440: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c>
	s_ashr_i32 s0, s22, 31                                     // 00000006E444: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 00000006E448: 96810216
	s_mul_i32 s0, s0, s2                                       // 00000006E44C: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000006E450: BF8704A9
	s_add_i32 s1, s1, s0                                       // 00000006E454: 81010001
	s_mul_i32 s0, s22, s2                                      // 00000006E458: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000006E45C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006E460: BF870009
	s_add_u32 s20, s12, s0                                     // 00000006E464: 8014000C
	s_addc_u32 s21, s13, s1                                    // 00000006E468: 8215010D
	.long 0xd7050001                                           // 00000006E46C: D7050001
	v_cndmask_b32_e32 v0, v156, v150, vcc_lo                   // 00000006E470: 02012D9C
	s_lshl_b32 s0, s2, 4                                       // 00000006E474: 84008402
	s_add_i32 s1, s14, -1                                      // 00000006E478: 8101C10E
	s_or_b32 s0, s0, 15                                        // 00000006E47C: 8C008F00
	v_lshrrev_b32_e32 v157, 4, v131                            // 00000006E480: 333B0684
	.long 0xd7390001                                           // 00000006E484: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 00000006E488: 02020288
	s_min_i32 s0, s0, s1                                       // 00000006E48C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000006E490: BF870499
	s_add_i32 s0, s26, s0                                      // 00000006E494: 8100001A
	s_cmp_lt_i32 s0, -15                                       // 00000006E498: BF04CF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E49C: BF870091
	.long 0xd7050001                                           // 00000006E4A0: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 00000006E4A4: 02011901
	.long 0xd7040001                                           // 00000006E4A8: D7040001
	v_cndmask_b32_e32 v1, v156, v1, vcc_lo                     // 00000006E4AC: 0202039C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E4B0: BF870091
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 00000006E4B4: CA240080 480002FF 000000FF
	v_mov_b32_e32 v71, v72                                     // 00000006E4C0: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 00000006E4C4: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 00000006E4C8: 7E880348
	v_mov_b32_e32 v67, v72                                     // 00000006E4CC: 7E860348
	v_mad_u64_u32 v[138:139], null, s24, 12, v[1:2]            // 00000006E4D0: D6FE7C8A 04051818
	v_mov_b32_e32 v70, v72                                     // 00000006E4D8: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 00000006E4DC: 7E840348
	v_mov_b32_e32 v65, v72                                     // 00000006E4E0: 7E820348
	v_mov_b32_e32 v80, v72                                     // 00000006E4E4: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 00000006E4E8: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 00000006E4EC: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 00000006E4F0: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 00000006E4F4: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 00000006E4FC: 7E960348
	v_mov_b32_e32 v74, v72                                     // 00000006E500: 7E940348
	v_mov_b32_e32 v73, v72                                     // 00000006E504: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 00000006E508: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000006E50C: 3404029F
	v_mov_b32_e32 v88, v72                                     // 00000006E510: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 00000006E514: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 00000006E518: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 00000006E51C: 7EAA0348
	.long 0xd73c008b                                           // 00000006E520: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000006E524: 02020281
	v_mov_b32_e32 v84, v72                                     // 00000006E528: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 00000006E52C: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 00000006E530: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 00000006E534: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 00000006E538: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 00000006E53C: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 00000006E540: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 00000006E544: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 00000006E548: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 00000006E54C: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 00000006E550: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 00000006E554: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 00000006E558: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 00000006E55C: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 00000006E560: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 00000006E564: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 00000006E568: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 00000006E56C: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 00000006E570: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 00000006E574: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 00000006E578: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 00000006E57C: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 00000006E580: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 00000006E584: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 00000006E588: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 00000006E58C: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 00000006E590: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 00000006E594: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 00000006E598: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 00000006E59C: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 00000006E5A0: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 00000006E5A4: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 00000006E5A8: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 00000006E5AC: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 00000006E5B0: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 00000006E5B4: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 00000006E5B8: 7F000348
	v_mov_b32_e32 v127, v72                                    // 00000006E5BC: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 00000006E5C0: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 00000006E5C4: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 00000006E5C8: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 00000006E5CC: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 00000006E5D0: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 00000006E5D4: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 00000006E5D8: 7E800348
	v_mov_b32_e32 v63, v72                                     // 00000006E5DC: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 00000006E5E0: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 00000006E5E4: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 00000006E5E8: 7E780348
	v_mov_b32_e32 v59, v72                                     // 00000006E5EC: 7E760348
	v_mov_b32_e32 v58, v72                                     // 00000006E5F0: 7E740348
	v_mov_b32_e32 v57, v72                                     // 00000006E5F4: 7E720348
	v_mov_b32_e32 v56, v72                                     // 00000006E5F8: 7E700348
	v_mov_b32_e32 v55, v72                                     // 00000006E5FC: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 00000006E600: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 00000006E604: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 00000006E608: 7E680348
	v_mov_b32_e32 v51, v72                                     // 00000006E60C: 7E660348
	v_mov_b32_e32 v50, v72                                     // 00000006E610: 7E640348
	v_mov_b32_e32 v49, v72                                     // 00000006E614: 7E620348
	v_mov_b32_e32 v48, v72                                     // 00000006E618: 7E600348
	v_mov_b32_e32 v47, v72                                     // 00000006E61C: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 00000006E620: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 00000006E624: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 00000006E628: 7E580348
	v_mov_b32_e32 v43, v72                                     // 00000006E62C: 7E560348
	v_mov_b32_e32 v42, v72                                     // 00000006E630: 7E540348
	v_mov_b32_e32 v41, v72                                     // 00000006E634: 7E520348
	v_mov_b32_e32 v40, v72                                     // 00000006E638: 7E500348
	v_mov_b32_e32 v39, v72                                     // 00000006E63C: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 00000006E640: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 00000006E644: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 00000006E648: 7E480348
	v_mov_b32_e32 v35, v72                                     // 00000006E64C: 7E460348
	v_mov_b32_e32 v34, v72                                     // 00000006E650: 7E440348
	v_mov_b32_e32 v33, v72                                     // 00000006E654: 7E420348
	v_mov_b32_e32 v32, v72                                     // 00000006E658: 7E400348
	v_mov_b32_e32 v31, v72                                     // 00000006E65C: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 00000006E660: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 00000006E664: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 00000006E668: 7E380348
	v_mov_b32_e32 v27, v72                                     // 00000006E66C: 7E360348
	v_mov_b32_e32 v26, v72                                     // 00000006E670: 7E340348
	v_mov_b32_e32 v25, v72                                     // 00000006E674: 7E320348
	v_mov_b32_e32 v24, v72                                     // 00000006E678: 7E300348
	v_mov_b32_e32 v23, v72                                     // 00000006E67C: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 00000006E680: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 00000006E684: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 00000006E688: 7E280348
	v_mov_b32_e32 v19, v72                                     // 00000006E68C: 7E260348
	v_mov_b32_e32 v18, v72                                     // 00000006E690: 7E240348
	v_mov_b32_e32 v17, v72                                     // 00000006E694: 7E220348
	v_mov_b32_e32 v16, v72                                     // 00000006E698: 7E200348
	v_mov_b32_e32 v15, v72                                     // 00000006E69C: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 00000006E6A0: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 00000006E6A4: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 00000006E6A8: 7E180348
	v_mov_b32_e32 v11, v72                                     // 00000006E6AC: 7E160348
	v_mov_b32_e32 v10, v72                                     // 00000006E6B0: 7E140348
	v_mov_b32_e32 v9, v72                                      // 00000006E6B4: 7E120348
	v_mov_b32_e32 v8, v72                                      // 00000006E6B8: 7E100348
	v_mov_b32_e32 v7, v72                                      // 00000006E6BC: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 00000006E6C0: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 00000006E6C4: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 00000006E6C8: 7E080348
	v_mov_b32_e32 v3, v72                                      // 00000006E6CC: 7E060348
	v_mov_b32_e32 v2, v72                                      // 00000006E6D0: 7E040348
	v_mov_b32_e32 v1, v72                                      // 00000006E6D4: 7E020348
	s_cbranch_scc1 2300                                        // 00000006E6D8: BFA208FC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x27cc>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[4:5]           // 00000006E6DC: D6FF7C01 001302FF 00003000
	v_add3_u32 v3, v129, s26, 1                                // 00000006E6E8: D6550003 02043581
	s_ashr_i32 s1, s0, 31                                      // 00000006E6F0: 86019F00
	v_dual_mov_b32 v129, 0 :: v_dual_lshlrev_b32 v4, 2, v131   // 00000006E6F4: CA220080 81050682
	s_lshr_b32 s1, s1, 28                                      // 00000006E6FC: 85019C01
	s_movk_i32 s2, 0x210                                       // 00000006E700: B0020210
	s_add_i32 s0, s0, s1                                       // 00000006E704: 81000100
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000006E708: BF8701D3
	.long 0xd7006a8f                                           // 00000006E70C: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 00000006E710: 02031701
	v_ashrrev_i32_e32 v1, 31, v3                               // 00000006E714: 3402069F
	s_movk_i32 s1, 0x440                                       // 00000006E718: B0010440
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 00000006E71C: D5207C90 01AB1902
	v_mad_u32_u24 v2, v156, s1, 0x1800                         // 00000006E724: D60B0002 03FC039C 00001800
	v_lshrrev_b32_e32 v1, 30, v1                               // 00000006E730: 3202029E
	s_ashr_i32 s12, s0, 4                                      // 00000006E734: 860C8400
	s_cmp_eq_u64 s[20:21], 0                                   // 00000006E738: BF108014
	v_mov_b32_e32 v176, v156                                   // 00000006E73C: 7F60039C
	v_mad_u32_u24 v5, 0x44, v157, v2                           // 00000006E740: D60B0005 040B3AFF 00000044
	v_add_nc_u32_e32 v1, v3, v1                                // 00000006E74C: 4A020303
	v_mad_u32_u24 v164, 0x44, v131, v2                         // 00000006E750: D60B00A4 040B06FF 00000044
	v_lshlrev_b32_e32 v2, 4, v0                                // 00000006E75C: 30040084
	s_cselect_b32 s13, -1, 0                                   // 00000006E760: 980D80C1
	v_lshl_add_u32 v160, v154, 2, v5                           // 00000006E764: D64600A0 0415059A
	v_ashrrev_i32_e32 v161, 2, v1                              // 00000006E76C: 35420282
	v_lshlrev_b32_e32 v1, 9, v156                              // 00000006E770: 30033889
	v_dual_mov_b32 v8, v129 :: v_dual_add_nc_u32 v5, 0x9f00, v132// 00000006E774: CA200181 080508FF 00009F00
	s_cmp_lg_u64 s[20:21], 0                                   // 00000006E780: BF118014
	v_add_nc_u32_e32 v3, v4, v132                              // 00000006E784: 4A070904
	s_cselect_b32 s22, -1, 0                                   // 00000006E788: 981680C1
	s_ashr_i32 s25, s24, 31                                    // 00000006E78C: 86199F18
	v_add_nc_u32_e32 v167, v5, v4                              // 00000006E790: 4B4E0905
	v_mov_b32_e32 v4, v129                                     // 00000006E794: 7E080381
	v_lshl_add_u32 v165, v131, 5, v1                           // 00000006E798: D64600A5 04050B83
	v_lshl_or_b32 v169, v154, 5, v1                            // 00000006E7A0: D65600A9 04050B9A
	v_dual_mov_b32 v10, v129 :: v_dual_and_b32 v1, 0x1f0, v2   // 00000006E7A8: CA240181 0A0004FF 000001F0
	s_lshl_b64 s[4:5], s[24:25], 9                             // 00000006E7B4: 84848918
	s_add_i32 s15, s15, -1                                     // 00000006E7B8: 810FC10F
	v_mul_u32_u24_e32 v2, 0x210, v156                          // 00000006E7BC: 160538FF 00000210
	s_add_u32 s1, s6, s4                                       // 00000006E7C4: 80010406
	s_addc_u32 s6, s7, s5                                      // 00000006E7C8: 82060507
	.long 0xd70001ab                                           // 00000006E7CC: D70001AB
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 00000006E7D0: 02020201
	.long 0xd44c0000                                           // 00000006E7D4: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 00000006E7D8: 020200FF 00000200
	v_mad_u32_u24 v159, v154, s2, 0x7b00                       // 00000006E7E0: D60B009F 03FC059A 00007B00
	v_add3_u32 v162, v155, v131, s26                           // 00000006E7EC: D65500A2 006B079B
	v_lshl_or_b32 v168, v157, 2, v5                            // 00000006E7F4: D65600A8 0415059D
	v_mad_u32_u24 v170, v154, 48, 0x4b00                       // 00000006E7FC: D60B00AA 03FD619A 00004B00
	v_add_co_ci_u32_e64 v172, null, s6, 0, s1                  // 00000006E808: D5207CAC 00050006
	v_lshl_or_b32 v173, v154, 1, 0x4b00                        // 00000006E810: D65600AD 03FD039A 00004B00
	v_dual_mov_b32 v5, v129 :: v_dual_add_nc_u32 v174, 0xfffffe80, v0// 00000006E81C: CA200181 05AE00FF FFFFFE80
	v_lshl_add_u32 v175, v131, 4, v2                           // 00000006E828: D64600AF 04090983
	v_lshrrev_b32_e32 v0, 1, v0                                // 00000006E830: 32000081
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, v129            // 00000006E834: CA100080 01020181
	v_dual_mov_b32 v6, v129 :: v_dual_add_nc_u32 v163, 0x9c00, v3// 00000006E83C: CA200181 06A206FF 00009C00
	v_dual_mov_b32 v3, v129 :: v_dual_add_nc_u32 v166, 0xa200, v3// 00000006E848: CA200181 03A606FF 0000A200
	v_mov_b32_e32 v7, v129                                     // 00000006E854: 7E0E0381
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v12, v129           // 00000006E858: CA100080 090C0181
	v_mov_b32_e32 v11, v129                                    // 00000006E860: 7E160381
	v_mov_b32_e32 v13, v129                                    // 00000006E864: 7E1A0381
	v_dual_mov_b32 v14, v129 :: v_dual_mov_b32 v17, 0          // 00000006E868: CA100181 0E100080
	v_mov_b32_e32 v15, v129                                    // 00000006E870: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v25, 0          // 00000006E874: CA100181 10180080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v33, 0          // 00000006E87C: CA100181 12200080
	v_mov_b32_e32 v19, v129                                    // 00000006E884: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v41, 0          // 00000006E888: CA100181 14280080
	v_mov_b32_e32 v21, v129                                    // 00000006E890: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v49, 0          // 00000006E894: CA100181 16300080
	v_mov_b32_e32 v23, v129                                    // 00000006E89C: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v57, 0          // 00000006E8A0: CA100181 18380080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v121, 0         // 00000006E8A8: CA100181 1A780080
	v_mov_b32_e32 v27, v129                                    // 00000006E8B0: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v113, 0         // 00000006E8B4: CA100181 1C700080
	v_mov_b32_e32 v29, v129                                    // 00000006E8BC: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v105, 0         // 00000006E8C0: CA100181 1E680080
	v_mov_b32_e32 v31, v129                                    // 00000006E8C8: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v97, 0          // 00000006E8CC: CA100181 20600080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v89, 0          // 00000006E8D4: CA100181 22580080
	v_mov_b32_e32 v35, v129                                    // 00000006E8DC: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v81, 0          // 00000006E8E0: CA100181 24500080
	v_mov_b32_e32 v37, v129                                    // 00000006E8E8: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v73, 0          // 00000006E8EC: CA100181 26480080
	v_mov_b32_e32 v39, v129                                    // 00000006E8F4: 7E4E0381
	v_dual_mov_b32 v40, v129 :: v_dual_mov_b32 v65, 0          // 00000006E8F8: CA100181 28400080
	v_dual_mov_b32 v42, v129 :: v_dual_mov_b32 v145, 0         // 00000006E900: CA100181 2A900080
	v_mov_b32_e32 v43, v129                                    // 00000006E908: 7E560381
	v_mov_b32_e32 v44, v129                                    // 00000006E90C: 7E580381
	v_mov_b32_e32 v45, v129                                    // 00000006E910: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 00000006E914: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 00000006E918: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 00000006E91C: 7E600381
	v_mov_b32_e32 v50, v129                                    // 00000006E920: 7E640381
	v_mov_b32_e32 v51, v129                                    // 00000006E924: 7E660381
	v_mov_b32_e32 v52, v129                                    // 00000006E928: 7E680381
	v_mov_b32_e32 v53, v129                                    // 00000006E92C: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 00000006E930: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 00000006E934: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 00000006E938: 7E700381
	v_mov_b32_e32 v58, v129                                    // 00000006E93C: 7E740381
	v_mov_b32_e32 v59, v129                                    // 00000006E940: 7E760381
	v_mov_b32_e32 v60, v129                                    // 00000006E944: 7E780381
	v_mov_b32_e32 v61, v129                                    // 00000006E948: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 00000006E94C: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 00000006E950: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 00000006E954: 7E800381
	v_mov_b32_e32 v122, v129                                   // 00000006E958: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 00000006E95C: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 00000006E960: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 00000006E964: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 00000006E968: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 00000006E96C: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 00000006E970: 7F000381
	v_mov_b32_e32 v114, v129                                   // 00000006E974: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 00000006E978: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 00000006E97C: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 00000006E980: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 00000006E984: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 00000006E988: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 00000006E98C: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 00000006E990: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 00000006E994: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 00000006E998: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 00000006E99C: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 00000006E9A0: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 00000006E9A4: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 00000006E9A8: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 00000006E9AC: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 00000006E9B0: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 00000006E9B4: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 00000006E9B8: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 00000006E9BC: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 00000006E9C0: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 00000006E9C4: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 00000006E9C8: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 00000006E9CC: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 00000006E9D0: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 00000006E9D4: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 00000006E9D8: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 00000006E9DC: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 00000006E9E0: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 00000006E9E4: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 00000006E9E8: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 00000006E9EC: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 00000006E9F0: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 00000006E9F4: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 00000006E9F8: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 00000006E9FC: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 00000006EA00: 7E940381
	v_mov_b32_e32 v75, v129                                    // 00000006EA04: 7E960381
	v_mov_b32_e32 v76, v129                                    // 00000006EA08: 7E980381
	v_mov_b32_e32 v77, v129                                    // 00000006EA0C: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 00000006EA10: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 00000006EA14: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 00000006EA18: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 00000006EA1C: 7E840381
	v_mov_b32_e32 v67, v129                                    // 00000006EA20: 7E860381
	v_mov_b32_e32 v68, v129                                    // 00000006EA24: 7E880381
	v_mov_b32_e32 v69, v129                                    // 00000006EA28: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 00000006EA2C: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 00000006EA30: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 00000006EA34: 7E900381
	s_add_u32 s6, s8, s4                                       // 00000006EA38: 80060408
	s_addc_u32 s5, s9, s5                                      // 00000006EA3C: 82050509
	s_mov_b32 s7, 0                                            // 00000006EA40: BE870080
	s_branch 117                                               // 00000006EA44: BFA00075 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x91c>
	ds_load_b128 v[146:149], v170                              // 00000006EA48: DBFC0000 920000AA
	ds_load_b128 v[150:153], v170 offset:16                    // 00000006EA50: DBFC0010 960000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EA58: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[146:153], v[121:128]// 00000006EA5C: CC414079 1DE72582
	ds_load_b128 v[150:153], v170 offset:784                   // 00000006EA64: DBFC0310 960000AA
	ds_load_b128 v[146:149], v170 offset:768                   // 00000006EA6C: DBFC0300 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EA74: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[146:153], v[113:120]// 00000006EA78: CC414071 1DC72582
	ds_load_b128 v[150:153], v170 offset:1552                  // 00000006EA80: DBFC0610 960000AA
	ds_load_b128 v[146:149], v170 offset:1536                  // 00000006EA88: DBFC0600 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EA90: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[146:153], v[105:112]// 00000006EA94: CC414069 1DA72582
	ds_load_b128 v[150:153], v170 offset:2320                  // 00000006EA9C: DBFC0910 960000AA
	ds_load_b128 v[146:149], v170 offset:2304                  // 00000006EAA4: DBFC0900 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EAAC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[146:153], v[97:104]// 00000006EAB0: CC414061 1D872582
	ds_load_b128 v[150:153], v170 offset:3088                  // 00000006EAB8: DBFC0C10 960000AA
	ds_load_b128 v[146:149], v170 offset:3072                  // 00000006EAC0: DBFC0C00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EAC8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[146:153], v[89:96]// 00000006EACC: CC414059 1D672582
	ds_load_b128 v[150:153], v170 offset:3856                  // 00000006EAD4: DBFC0F10 960000AA
	ds_load_b128 v[146:149], v170 offset:3840                  // 00000006EADC: DBFC0F00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EAE4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[146:153], v[81:88]// 00000006EAE8: CC414051 1D472582
	ds_load_b128 v[150:153], v170 offset:4624                  // 00000006EAF0: DBFC1210 960000AA
	ds_load_b128 v[146:149], v170 offset:4608                  // 00000006EAF8: DBFC1200 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EB00: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[146:153], v[73:80]// 00000006EB04: CC414049 1D272582
	ds_load_b128 v[150:153], v170 offset:5392                  // 00000006EB0C: DBFC1510 960000AA
	ds_load_b128 v[146:149], v170 offset:5376                  // 00000006EB14: DBFC1500 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EB1C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[146:153], v[65:72]// 00000006EB20: CC414041 1D072582
	ds_load_b128 v[150:153], v170 offset:6160                  // 00000006EB28: DBFC1810 960000AA
	ds_load_b128 v[146:149], v170 offset:6144                  // 00000006EB30: DBFC1800 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EB38: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[146:153], v[57:64]// 00000006EB3C: CC414039 1CE72582
	ds_load_b128 v[150:153], v170 offset:6928                  // 00000006EB44: DBFC1B10 960000AA
	ds_load_b128 v[146:149], v170 offset:6912                  // 00000006EB4C: DBFC1B00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EB54: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[146:153], v[49:56]// 00000006EB58: CC414031 1CC72582
	ds_load_b128 v[150:153], v170 offset:7696                  // 00000006EB60: DBFC1E10 960000AA
	ds_load_b128 v[146:149], v170 offset:7680                  // 00000006EB68: DBFC1E00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EB70: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[146:153], v[41:48]// 00000006EB74: CC414029 1CA72582
	ds_load_b128 v[150:153], v170 offset:8464                  // 00000006EB7C: DBFC2110 960000AA
	ds_load_b128 v[146:149], v170 offset:8448                  // 00000006EB84: DBFC2100 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EB8C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[146:153], v[33:40]// 00000006EB90: CC414021 1C872582
	ds_load_b128 v[150:153], v170 offset:9232                  // 00000006EB98: DBFC2410 960000AA
	ds_load_b128 v[146:149], v170 offset:9216                  // 00000006EBA0: DBFC2400 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EBA8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[146:153], v[25:32]// 00000006EBAC: CC414019 1C672582
	ds_load_b128 v[150:153], v170 offset:10000                 // 00000006EBB4: DBFC2710 960000AA
	ds_load_b128 v[146:149], v170 offset:9984                  // 00000006EBBC: DBFC2700 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EBC4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[146:153], v[17:24]// 00000006EBC8: CC414011 1C472582
	ds_load_b128 v[150:153], v170 offset:10768                 // 00000006EBD0: DBFC2A10 960000AA
	ds_load_b128 v[146:149], v170 offset:10752                 // 00000006EBD8: DBFC2A00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EBE0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[146:153], v[9:16]// 00000006EBE4: CC414009 1C272582
	ds_load_b128 v[150:153], v170 offset:11536                 // 00000006EBEC: DBFC2D10 960000AA
	ds_load_b128 v[146:149], v170 offset:11520                 // 00000006EBF4: DBFC2D00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 00000006EBFC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[146:153], v[1:8]// 00000006EC00: CC414001 1C072582
	v_add_nc_u32_e32 v176, 16, v176                            // 00000006EC08: 4B616090
	s_add_i32 s1, s7, 1                                        // 00000006EC0C: 81018107
	s_cmp_eq_u32 s7, s12                                       // 00000006EC10: BF060C07
	s_mov_b32 s7, s1                                           // 00000006EC14: BE870001
	s_cbranch_scc1 1964                                        // 00000006EC18: BFA207AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x27cc>
	s_and_not1_b32 vcc_lo, exec_lo, s22                        // 00000006EC1C: 916A167E
	s_mov_b32 s1, s13                                          // 00000006EC20: BE81000D
	s_cbranch_vccnz 13                                         // 00000006EC24: BFA4000D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x95c>
	s_lshr_b32 s1, s7, 3                                       // 00000006EC28: 85018307
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000006EC2C: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 00000006EC30: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 00000006EC38: 7F040201
	global_load_b32 v130, v130, s[20:21]                       // 00000006EC3C: DC520000 82140082
	s_waitcnt vmcnt(0)                                         // 00000006EC44: BF8903F7
	v_lshrrev_b32_e32 v130, s7, v130                           // 00000006EC48: 33050407
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006EC4C: BF870091
	v_and_b32_e32 v130, 1, v130                                // 00000006EC50: 37050481
	.long 0xd44a0001                                           // 00000006EC54: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000006EC58: 02030481
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006EC5C: BF870001
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000006EC60: 916A017E
	s_cbranch_vccnz 65512                                      // 00000006EC64: BFA4FFE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x908>
	s_lshl_b32 s2, s7, 4                                       // 00000006EC68: 84028407
	s_waitcnt vmcnt(0)                                         // 00000006EC6C: BF8903F7
	s_barrier                                                  // 00000006EC70: BFBD0000
	buffer_gl0_inv                                             // 00000006EC74: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000006EC7C: BE812000
	s_cbranch_execz 119                                        // 00000006EC80: BFA50077 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb60>
	v_dual_mov_b32 v130, v176 :: v_dual_mov_b32 v131, v175     // 00000006EC84: CA1001B0 828201AF
	v_mov_b32_e32 v132, v174                                   // 00000006EC8C: 7F0803AE
	s_mov_b32 s4, 0                                            // 00000006EC90: BE840080
	s_nop 0                                                    // 00000006EC94: BF800000
	s_nop 0                                                    // 00000006EC98: BF800000
	s_nop 0                                                    // 00000006EC9C: BF800000
	s_nop 0                                                    // 00000006ECA0: BF800000
	s_nop 0                                                    // 00000006ECA4: BF800000
	s_nop 0                                                    // 00000006ECA8: BF800000
	s_nop 0                                                    // 00000006ECAC: BF800000
	s_nop 0                                                    // 00000006ECB0: BF800000
	s_nop 0                                                    // 00000006ECB4: BF800000
	s_nop 0                                                    // 00000006ECB8: BF800000
	s_nop 0                                                    // 00000006ECBC: BF800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006ECC0: BF870112
	v_min_i32_e32 v133, s15, v130                              // 00000006ECC4: 230B040F
	v_add_nc_u32_e32 v132, 0x180, v132                         // 00000006ECC8: 4B0908FF 00000180
	v_add_nc_u32_e32 v130, 12, v130                            // 00000006ECD0: 4B05048C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000006ECD4: BF8701B3
	v_ashrrev_i32_e32 v135, 31, v133                           // 00000006ECD8: 350F0A9F
	.long 0xd72c0088                                           // 00000006ECDC: D72C0088
	v_cndmask_b32_e32 v1, s11, v133, vcc_lo                    // 00000006ECE0: 02030A0B
	v_mad_u64_u32 v[133:134], null, s10, v133, 0               // 00000006ECE4: D6FE7C85 02030A0A
	.long 0xd72c0087                                           // 00000006ECEC: D72C0087
	v_cndmask_b32_e32 v1, s10, v135, vcc_lo                    // 00000006ECF0: 02030E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ECF4: BF870091
	v_add3_u32 v134, v134, v135, v136                          // 00000006ECF8: D6550086 06230F86
	.long 0xd73c0085                                           // 00000006ED00: D73C0085
	v_cndmask_b32_e32 v1, 1, v133, vcc_lo                      // 00000006ED04: 02030A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ED08: BF870091
	.long 0xd7006a85                                           // 00000006ED0C: D7006A85
	v_cndmask_b32_e32 v1, v171, v133, vcc_lo                   // 00000006ED10: 02030BAB
	v_add_co_ci_u32_e64 v134, null, v172, v134, vcc_lo         // 00000006ED14: D5207C86 01AB0DAC
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v132                        // 00000006ED1C: 7C9308FF 0000007F
	global_load_b128 v[133:136], v[133:134], off               // 00000006ED24: DC5E0000 857C0085
	s_or_b32 s4, vcc_lo, s4                                    // 00000006ED2C: 8C04046A
	s_waitcnt vmcnt(0)                                         // 00000006ED30: BF8903F7
	ds_store_b128 v131, v[133:136] offset:31488                // 00000006ED34: DB7C7B00 00008583
	v_add_nc_u32_e32 v131, 0x18c0, v131                        // 00000006ED3C: 4B0706FF 000018C0
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000006ED44: 917E047E
	s_cbranch_execnz 65501                                     // 00000006ED48: BFA6FFDD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006ED4C: 8C7E047E
	v_or_b32_e32 v130, s2, v154                                // 00000006ED50: 39053402
	s_mov_b32 s4, 0                                            // 00000006ED54: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ED58: BF870091
	v_min_i32_e32 v130, s15, v130                              // 00000006ED5C: 2305040F
	v_ashrrev_i32_e32 v132, 31, v130                           // 00000006ED60: 3509049F
	.long 0xd72c0085                                           // 00000006ED64: D72C0085
	v_cndmask_b32_e32 v1, s11, v130, vcc_lo                    // 00000006ED68: 0203040B
	v_mad_u64_u32 v[130:131], null, s10, v130, 0               // 00000006ED6C: D6FE7C82 0203040A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006ED74: BF870093
	.long 0xd72c0084                                           // 00000006ED78: D72C0084
	v_cndmask_b32_e32 v1, s10, v132, vcc_lo                    // 00000006ED7C: 0203080A
	v_add3_u32 v131, v131, v132, v133                          // 00000006ED80: D6550083 06170983
	v_mov_b32_e32 v133, v174                                   // 00000006ED88: 7F0A03AE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006ED8C: BF870122
	.long 0xd73c0083                                           // 00000006ED90: D73C0083
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000006ED94: 02030481
	v_mov_b32_e32 v130, v0                                     // 00000006ED98: 7F040300
	.long 0xd7006a83                                           // 00000006ED9C: D7006A83
	v_cndmask_b32_e32 v1, s6, v131, vcc_lo                     // 00000006EDA0: 02030606
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006EDA4: BF870001
	v_add_co_ci_u32_e64 v132, null, s5, v132, vcc_lo           // 00000006EDA8: D5207C84 01AB0805
	s_set_inst_prefetch_distance 0x1                           // 00000006EDB0: BF840001
	s_nop 0                                                    // 00000006EDB4: BF800000
	s_nop 0                                                    // 00000006EDB8: BF800000
	s_nop 0                                                    // 00000006EDBC: BF800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000006EDC0: BF8701B3
	v_and_b32_e32 v146, 0xf8, v130                             // 00000006EDC4: 372504FF 000000F8
	v_add_nc_u32_e32 v133, 0x180, v133                         // 00000006EDCC: 4B0B0AFF 00000180
	v_add_nc_u32_e32 v130, 0xc0, v130                          // 00000006EDD4: 4B0504FF 000000C0
	v_lshlrev_b32_e32 v134, 1, v146                            // 00000006EDDC: 310D2481
	v_mad_u32_u24 v146, v146, 48, v173                         // 00000006EDE0: D60B0092 06B56192
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006EDE8: BF870092
	.long 0xd7006a86                                           // 00000006EDEC: D7006A86
	v_cndmask_b32_e32 v1, v131, v134, vcc_lo                   // 00000006EDF0: 02030D83
	v_add_co_ci_u32_e64 v135, null, 0, v132, vcc_lo            // 00000006EDF4: D5207C87 01AB0880
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v133                        // 00000006EDFC: 7C930AFF 0000007F
	global_load_b128 v[134:137], v[134:135], off               // 00000006EE04: DC5E0000 867C0086
	s_waitcnt vmcnt(0)                                         // 00000006EE0C: BF8903F7
	ds_store_b16 v146, v134                                    // 00000006EE10: D87C0000 00008692
	ds_store_b16_d16_hi v146, v134 offset:48                   // 00000006EE18: DA840030 00008692
	ds_store_b16 v146, v135 offset:96                          // 00000006EE20: D87C0060 00008792
	ds_store_b16_d16_hi v146, v135 offset:144                  // 00000006EE28: DA840090 00008792
	ds_store_b16 v146, v136 offset:192                         // 00000006EE30: D87C00C0 00008892
	ds_store_b16_d16_hi v146, v136 offset:240                  // 00000006EE38: DA8400F0 00008892
	ds_store_b16 v146, v137 offset:288                         // 00000006EE40: D87C0120 00008992
	ds_store_b16_d16_hi v146, v137 offset:336                  // 00000006EE48: DA840150 00008992
	s_or_b32 s4, vcc_lo, s4                                    // 00000006EE50: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006EE54: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000006EE58: 917E047E
	s_cbranch_execnz 65496                                     // 00000006EE5C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac0>
	s_set_inst_prefetch_distance 0x2                           // 00000006EE60: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006EE64: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 00000006EE68: BF89FC07
	s_barrier                                                  // 00000006EE6C: BFBD0000
	buffer_gl0_inv                                             // 00000006EE70: E0AC0000 00000000
	s_clause 0x3                                               // 00000006EE78: BF850003
	global_load_b128 v[150:153], v[143:144], off offset:16     // 00000006EE7C: DC5E0010 967C008F
	global_load_b128 v[146:149], v[143:144], off               // 00000006EE84: DC5E0000 927C008F
	global_load_b128 v[181:184], v[143:144], off offset:48     // 00000006EE8C: DC5E0030 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:32     // 00000006EE94: DC5E0020 B17C008F
	ds_load_b128 v[185:188], v159                              // 00000006EE9C: DBFC0000 B900009F
	ds_load_b128 v[189:192], v159 offset:16                    // 00000006EEA4: DBFC0010 BD00009F
	v_mov_b32_e32 v136, v129                                   // 00000006EEAC: 7F100381
	v_mov_b32_e32 v130, v129                                   // 00000006EEB0: 7F040381
	v_mov_b32_e32 v131, v129                                   // 00000006EEB4: 7F060381
	v_mov_b32_e32 v132, v129                                   // 00000006EEB8: 7F080381
	v_mov_b32_e32 v133, v129                                   // 00000006EEBC: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 00000006EEC0: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 00000006EEC4: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 00000006EEC8: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000006EECC: BF870212
	v_mov_b32_e32 v136, v135                                   // 00000006EED0: 7F100387
	v_mov_b32_e32 v135, v134                                   // 00000006EED4: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 00000006EED8: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 00000006EEDC: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 00000006EEE0: 7F080383
	v_mov_b32_e32 v131, v130                                   // 00000006EEE4: 7F060382
	v_mov_b32_e32 v130, v129                                   // 00000006EEE8: 7F040381
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006EEEC: BF890807
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006EEF0: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 00000006EEF4: CC414082 1E0B7392
	s_clause 0x1                                               // 00000006EEFC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:80     // 00000006EF00: DC5E0050 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:64     // 00000006EF08: DC5E0040 927C008F
	ds_load_b128 v[185:188], v159 offset:32                    // 00000006EF10: DBFC0020 B900009F
	ds_load_b128 v[189:192], v159 offset:48                    // 00000006EF18: DBFC0030 BD00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006EF20: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 00000006EF24: CC414082 1E0B73B1
	s_clause 0x1                                               // 00000006EF2C: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:112    // 00000006EF30: DC5E0070 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:96     // 00000006EF38: DC5E0060 B17C008F
	ds_load_b128 v[189:192], v159 offset:80                    // 00000006EF40: DBFC0050 BD00009F
	ds_load_b128 v[185:188], v159 offset:64                    // 00000006EF48: DBFC0040 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006EF50: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 00000006EF54: CC414082 1E0B7392
	s_clause 0x1                                               // 00000006EF5C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:144    // 00000006EF60: DC5E0090 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:128    // 00000006EF68: DC5E0080 927C008F
	ds_load_b128 v[189:192], v159 offset:112                   // 00000006EF70: DBFC0070 BD00009F
	ds_load_b128 v[185:188], v159 offset:96                    // 00000006EF78: DBFC0060 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006EF80: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 00000006EF84: CC414082 1E0B73B1
	s_clause 0x1                                               // 00000006EF8C: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:176    // 00000006EF90: DC5E00B0 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:160    // 00000006EF98: DC5E00A0 B17C008F
	ds_load_b128 v[189:192], v159 offset:144                   // 00000006EFA0: DBFC0090 BD00009F
	ds_load_b128 v[185:188], v159 offset:128                   // 00000006EFA8: DBFC0080 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006EFB0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 00000006EFB4: CC414082 1E0B7392
	s_clause 0x1                                               // 00000006EFBC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:208    // 00000006EFC0: DC5E00D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:192    // 00000006EFC8: DC5E00C0 927C008F
	ds_load_b128 v[189:192], v159 offset:176                   // 00000006EFD0: DBFC00B0 BD00009F
	ds_load_b128 v[185:188], v159 offset:160                   // 00000006EFD8: DBFC00A0 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006EFE0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 00000006EFE4: CC414082 1E0B73B1
	s_clause 0x1                                               // 00000006EFEC: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:240    // 00000006EFF0: DC5E00F0 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:224    // 00000006EFF8: DC5E00E0 B17C008F
	ds_load_b128 v[189:192], v159 offset:208                   // 00000006F000: DBFC00D0 BD00009F
	ds_load_b128 v[185:188], v159 offset:192                   // 00000006F008: DBFC00C0 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006F010: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 00000006F014: CC414082 1E0B7392
	s_clause 0x1                                               // 00000006F01C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:272    // 00000006F020: DC5E0110 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:256    // 00000006F028: DC5E0100 927C008F
	ds_load_b128 v[189:192], v159 offset:240                   // 00000006F030: DBFC00F0 BD00009F
	ds_load_b128 v[185:188], v159 offset:224                   // 00000006F038: DBFC00E0 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006F040: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 00000006F044: CC414082 1E0B73B1
	s_clause 0x1                                               // 00000006F04C: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:304    // 00000006F050: DC5E0130 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:288    // 00000006F058: DC5E0120 B17C008F
	ds_load_b128 v[189:192], v159 offset:272                   // 00000006F060: DBFC0110 BD00009F
	ds_load_b128 v[185:188], v159 offset:256                   // 00000006F068: DBFC0100 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006F070: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 00000006F074: CC414082 1E0B7392
	s_clause 0x1                                               // 00000006F07C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:336    // 00000006F080: DC5E0150 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:320    // 00000006F088: DC5E0140 927C008F
	ds_load_b128 v[189:192], v159 offset:304                   // 00000006F090: DBFC0130 BD00009F
	ds_load_b128 v[185:188], v159 offset:288                   // 00000006F098: DBFC0120 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006F0A0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 00000006F0A4: CC414082 1E0B73B1
	s_clause 0x1                                               // 00000006F0AC: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:368    // 00000006F0B0: DC5E0170 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:352    // 00000006F0B8: DC5E0160 B17C008F
	ds_load_b128 v[189:192], v159 offset:336                   // 00000006F0C0: DBFC0150 BD00009F
	ds_load_b128 v[185:188], v159 offset:320                   // 00000006F0C8: DBFC0140 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006F0D0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 00000006F0D4: CC414082 1E0B7392
	s_clause 0x1                                               // 00000006F0DC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:400    // 00000006F0E0: DC5E0190 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:384    // 00000006F0E8: DC5E0180 927C008F
	ds_load_b128 v[189:192], v159 offset:368                   // 00000006F0F0: DBFC0170 BD00009F
	ds_load_b128 v[185:188], v159 offset:352                   // 00000006F0F8: DBFC0160 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006F100: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 00000006F104: CC414082 1E0B73B1
	s_clause 0x1                                               // 00000006F10C: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:432    // 00000006F110: DC5E01B0 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:416    // 00000006F118: DC5E01A0 B17C008F
	ds_load_b128 v[189:192], v159 offset:400                   // 00000006F120: DBFC0190 BD00009F
	ds_load_b128 v[185:188], v159 offset:384                   // 00000006F128: DBFC0180 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006F130: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 00000006F134: CC414082 1E0B7392
	ds_load_b128 v[150:153], v159 offset:432                   // 00000006F13C: DBFC01B0 9600009F
	ds_load_b128 v[146:149], v159 offset:416                   // 00000006F144: DBFC01A0 9200009F
	s_clause 0x1                                               // 00000006F14C: BF850001
	global_load_b128 v[189:192], v[143:144], off offset:464    // 00000006F150: DC5E01D0 BD7C008F
	global_load_b128 v[185:188], v[143:144], off offset:448    // 00000006F158: DC5E01C0 B97C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006F160: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[146:153], v[130:137]// 00000006F164: CC414082 1E0B25B1
	s_clause 0x1                                               // 00000006F16C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:496    // 00000006F170: DC5E01F0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:480    // 00000006F178: DC5E01E0 927C008F
	ds_load_b128 v[181:184], v159 offset:464                   // 00000006F180: DBFC01D0 B500009F
	ds_load_b128 v[177:180], v159 offset:448                   // 00000006F188: DBFC01C0 B100009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000006F190: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[185:192], v[177:184], v[130:137]// 00000006F194: CC414082 1E0B63B9
	ds_load_b128 v[181:184], v159 offset:496                   // 00000006F19C: DBFC01F0 B500009F
	ds_load_b128 v[177:180], v159 offset:480                   // 00000006F1A4: DBFC01E0 B100009F
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000006F1AC: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000006F1B0: CC414082 1E0B6392
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006F1B8: BF870111
	v_dual_mul_f32 v130, 0x3d800000, v130 :: v_dual_mul_f32 v131, 0x3d800000, v131// 00000006F1BC: C8C704FF 828306FF 3D800000
	v_mul_f32_e32 v146, 0x3d800000, v133                       // 00000006F1C8: 11250AFF 3D800000
	v_mov_b32_e32 v133, 0xffff                                 // 00000006F1D0: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000006F1D8: BF870004
	v_mul_f32_e32 v132, 0x3d800000, v132                       // 00000006F1DC: 110908FF 3D800000
	v_dual_mul_f32 v134, 0x3d800000, v134 :: v_dual_mul_f32 v135, 0x3d800000, v135// 00000006F1E4: C8C70CFF 86870EFF 3D800000
	v_dual_mul_f32 v136, 0x3d800000, v136 :: v_dual_mul_f32 v137, 0x3d800000, v137// 00000006F1F0: C8C710FF 888912FF 3D800000
	ds_store_2addr_b32 v160, v130, v131 offset1:34             // 00000006F1FC: D8382200 008382A0
	ds_store_2addr_b32 v160, v132, v146 offset0:68 offset1:102 // 00000006F204: D8386644 009284A0
	ds_store_2addr_b32 v160, v134, v135 offset0:136 offset1:170// 00000006F20C: D838AA88 008786A0
	ds_store_2addr_b32 v160, v136, v137 offset0:204 offset1:238// 00000006F214: D838EECC 008988A0
	s_and_saveexec_b32 s4, s23                                 // 00000006F21C: BE842017
	s_cbranch_execz 363                                        // 00000006F220: BFA5016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14d0>
	s_lshl_b32 s8, s7, 2                                       // 00000006F224: 84088207
	s_mov_b32 s9, exec_lo                                      // 00000006F228: BE89007E
	.long 0xd4c1007e                                           // 00000006F22C: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 00000006F230: 02033D91
	s_cbranch_execz 48                                         // 00000006F234: BFA50030 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff8>
	v_ashrrev_i32_e32 v146, 31, v145                           // 00000006F238: 3525229F
	s_mov_b32 s24, 0                                           // 00000006F23C: BE980080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006F240: BF870091
	.long 0xd73c0082                                           // 00000006F244: D73C0082
	v_cndmask_b32_e32 v1, 2, v145, vcc_lo                      // 00000006F248: 02032282
	.long 0xd7006a82                                           // 00000006F24C: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 00000006F250: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F254: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 00000006F258: D5207C83 01AB078E
	s_branch 15                                                // 00000006F260: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfa0>
	s_nop 0                                                    // 00000006F264: BF800000
	s_nop 0                                                    // 00000006F268: BF800000
	s_nop 0                                                    // 00000006F26C: BF800000
	s_nop 0                                                    // 00000006F270: BF800000
	s_nop 0                                                    // 00000006F274: BF800000
	s_nop 0                                                    // 00000006F278: BF800000
	s_nop 0                                                    // 00000006F27C: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 00000006F280: 8C7E1A7E
	v_mov_b32_e32 v133, v145                                   // 00000006F284: 7F0A0391
	v_mov_b32_e32 v145, v132                                   // 00000006F288: 7F220384
	s_and_b32 s1, exec_lo, s25                                 // 00000006F28C: 8B01197E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000006F290: BF870499
	s_or_b32 s24, s1, s24                                      // 00000006F294: 8C181801
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 00000006F298: 917E187E
	s_cbranch_execz 20                                         // 00000006F29C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff0>
	global_load_b32 v132, v[130:131], off                      // 00000006F2A0: DC520000 847C0082
	s_or_b32 s25, s25, exec_lo                                 // 00000006F2A8: 8C197E19
	s_waitcnt vmcnt(0)                                         // 00000006F2AC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s8, v132                          // 00000006F2B0: 7C890808
	s_and_saveexec_b32 s26, vcc_lo                             // 00000006F2B4: BE9A206A
	s_cbranch_execz 65521                                      // 00000006F2B8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	v_dual_mov_b32 v145, v158 :: v_dual_add_nc_u32 v132, 1, v145// 00000006F2BC: CA20019E 91852281
	.long 0xd7000182                                           // 00000006F2C4: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 00000006F2C8: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006F2CC: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 00000006F2D0: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v158, v132                        // 00000006F2D8: 7C95099E
	s_and_not1_b32 s1, s25, exec_lo                            // 00000006F2DC: 91017E19
	s_and_b32 s25, vcc_lo, exec_lo                             // 00000006F2E0: 8B197E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F2E4: BF870009
	s_or_b32 s25, s1, s25                                      // 00000006F2E8: 8C191901
	s_branch 65508                                             // 00000006F2EC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	s_or_b32 exec_lo, exec_lo, s24                             // 00000006F2F0: 8C7E187E
	v_mov_b32_e32 v145, v133                                   // 00000006F2F4: 7F220385
	s_or_b32 exec_lo, exec_lo, s9                              // 00000006F2F8: 8C7E097E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F2FC: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v145       // 00000006F300: CA10008F 85820191
	s_mov_b32 s1, exec_lo                                      // 00000006F308: BE81007E
	.long 0xd4c1007e                                           // 00000006F30C: D4C1007E
	v_cndmask_b32_e32 v1, s8, v161, vcc_lo                     // 00000006F310: 02034208
	s_cbranch_execz 62                                         // 00000006F314: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1110>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v145        // 00000006F318: CA100080 85820191
	s_mov_b32 s9, exec_lo                                      // 00000006F320: BE89007E
	.long 0xd4c1007e                                           // 00000006F324: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 00000006F328: 02033D91
	s_cbranch_execz 54                                         // 00000006F32C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1108>
	v_mov_b32_e32 v130, v145                                   // 00000006F330: 7F040391
	s_mov_b32 s25, 0                                           // 00000006F334: BE990080
	s_set_inst_prefetch_distance 0x1                           // 00000006F338: BF840001
	s_branch 10                                                // 00000006F33C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1068>
	s_or_b32 exec_lo, exec_lo, s28                             // 00000006F340: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000006F344: BF870499
	s_and_b32 s28, exec_lo, s27                                // 00000006F348: 8B1C1B7E
	s_or_b32 s25, s28, s25                                     // 00000006F34C: 8C19191C
	s_and_not1_b32 s24, s24, exec_lo                           // 00000006F350: 91187E18
	s_and_b32 s28, s26, exec_lo                                // 00000006F354: 8B1C7E1A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F358: BF870009
	s_or_b32 s24, s24, s28                                     // 00000006F35C: 8C181C18
	s_and_not1_b32 exec_lo, exec_lo, s25                       // 00000006F360: 917E197E
	s_cbranch_execz 28                                         // 00000006F364: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000006F368: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 00000006F36C: 7F060382
	s_or_b32 s26, s26, exec_lo                                 // 00000006F370: 8C1A7E1A
	s_or_b32 s27, s27, exec_lo                                 // 00000006F374: 8C1B7E1B
	s_mov_b32 s28, exec_lo                                     // 00000006F378: BE9C007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000006F37C: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006F380: BF870091
	.long 0xd73c0084                                           // 00000006F384: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000006F388: 02030682
	.long 0xd7006a84                                           // 00000006F38C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 00000006F390: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F394: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 00000006F398: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 00000006F3A0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 00000006F3A8: BF8903F7
	.long 0xd4c4007e                                           // 00000006F3AC: D4C4007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 00000006F3B0: 02030808
	s_cbranch_execz 65506                                      // 00000006F3B4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000006F3B8: 4B050681
	s_and_not1_b32 s27, s27, exec_lo                           // 00000006F3BC: 911B7E1B
	s_and_not1_b32 s26, s26, exec_lo                           // 00000006F3C0: 911A7E1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000006F3C4: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000006F3C8: 7C95059E
	s_and_b32 s29, vcc_lo, exec_lo                             // 00000006F3CC: 8B1D7E6A
	s_or_b32 s27, s27, s29                                     // 00000006F3D0: 8C1B1D1B
	s_branch 65498                                             // 00000006F3D4: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	s_set_inst_prefetch_distance 0x2                           // 00000006F3D8: BF840002
	s_or_b32 exec_lo, exec_lo, s25                             // 00000006F3DC: 8C7E197E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v158        // 00000006F3E0: CA100080 8582019E
	s_and_saveexec_b32 s25, s24                                // 00000006F3E8: BE992018
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F3EC: BF870009
	s_xor_b32 s24, exec_lo, s25                                // 00000006F3F0: 8D18197E
	v_cmp_eq_u32_e32 vcc_lo, s8, v132                          // 00000006F3F4: 7C950808
	v_mov_b32_e32 v130, v131                                   // 00000006F3F8: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 00000006F3FC: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s24                             // 00000006F404: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F408: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 00000006F40C: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F410: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006F414: 8C7E017E
	s_or_b32 s9, s8, 1                                         // 00000006F418: 8C098108
	s_mov_b32 s1, exec_lo                                      // 00000006F41C: BE81007E
	.long 0xd4c6007e                                           // 00000006F420: D4C6007E
	v_cndmask_b32_e32 v1, s9, v161, vcc_lo                     // 00000006F424: 02034209
	s_xor_b32 s1, exec_lo, s1                                  // 00000006F428: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 00000006F42C: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 00000006F434: BE813001
	s_cbranch_execz 70                                         // 00000006F438: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1254>
	s_mov_b32 s24, exec_lo                                     // 00000006F43C: BE98007E
	.long 0xd4c1007e                                           // 00000006F440: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000006F444: 02033D82
	s_cbranch_execz 64                                         // 00000006F448: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x124c>
	s_mov_b32 s26, 0                                           // 00000006F44C: BE9A0080
	s_set_inst_prefetch_distance 0x1                           // 00000006F450: BF840001
	s_branch 20                                                // 00000006F454: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11a8>
	s_nop 0                                                    // 00000006F458: BF800000
	s_nop 0                                                    // 00000006F45C: BF800000
	s_nop 0                                                    // 00000006F460: BF800000
	s_nop 0                                                    // 00000006F464: BF800000
	s_nop 0                                                    // 00000006F468: BF800000
	s_nop 0                                                    // 00000006F46C: BF800000
	s_nop 0                                                    // 00000006F470: BF800000
	s_nop 0                                                    // 00000006F474: BF800000
	s_nop 0                                                    // 00000006F478: BF800000
	s_nop 0                                                    // 00000006F47C: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 00000006F480: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000006F484: BF870499
	s_and_b32 s29, exec_lo, s28                                // 00000006F488: 8B1D1C7E
	s_or_b32 s26, s29, s26                                     // 00000006F48C: 8C1A1A1D
	s_and_not1_b32 s25, s25, exec_lo                           // 00000006F490: 91197E19
	s_and_b32 s29, s27, exec_lo                                // 00000006F494: 8B1D7E1B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F498: BF870009
	s_or_b32 s25, s25, s29                                     // 00000006F49C: 8C191D19
	s_and_not1_b32 exec_lo, exec_lo, s26                       // 00000006F4A0: 917E1A7E
	s_cbranch_execz 27                                         // 00000006F4A4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1214>
	v_mov_b32_e32 v131, v130                                   // 00000006F4A8: 7F060382
	s_or_b32 s27, s27, exec_lo                                 // 00000006F4AC: 8C1B7E1B
	s_or_b32 s28, s28, exec_lo                                 // 00000006F4B0: 8C1C7E1C
	s_mov_b32 s29, exec_lo                                     // 00000006F4B4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006F4B8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000006F4BC: 3509069F
	.long 0xd73c0086                                           // 00000006F4C0: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000006F4C4: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006F4C8: BF870091
	.long 0xd7006a86                                           // 00000006F4CC: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 00000006F4D0: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 00000006F4D4: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 00000006F4DC: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 00000006F4E4: BF8903F7
	.long 0xd4c6007e                                           // 00000006F4E8: D4C6007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 00000006F4EC: 02030808
	s_cbranch_execz 65507                                      // 00000006F4F0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000006F4F4: 4B050681
	s_and_not1_b32 s28, s28, exec_lo                           // 00000006F4F8: 911C7E1C
	s_and_not1_b32 s27, s27, exec_lo                           // 00000006F4FC: 911B7E1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000006F500: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000006F504: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 00000006F508: 8B1E7E6A
	s_or_b32 s28, s28, s30                                     // 00000006F50C: 8C1C1E1C
	s_branch 65499                                             // 00000006F510: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	s_set_inst_prefetch_distance 0x2                           // 00000006F514: BF840002
	s_or_b32 exec_lo, exec_lo, s26                             // 00000006F518: 8C7E1A7E
	v_mov_b32_e32 v130, v158                                   // 00000006F51C: 7F04039E
	s_and_saveexec_b32 s26, s25                                // 00000006F520: BE9A2019
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F524: BF870009
	s_xor_b32 s25, exec_lo, s26                                // 00000006F528: 8D191A7E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 00000006F52C: 7C950809
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 00000006F530: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F53C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000006F540: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 00000006F544: 7F040383
	s_or_b32 exec_lo, exec_lo, s25                             // 00000006F548: 8C7E197E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F54C: BF870009
	s_or_b32 exec_lo, exec_lo, s24                             // 00000006F550: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F554: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006F558: 8C7E017E
	s_or_b32 s9, s8, 2                                         // 00000006F55C: 8C098208
	s_mov_b32 s1, exec_lo                                      // 00000006F560: BE81007E
	.long 0xd4c6007e                                           // 00000006F564: D4C6007E
	v_cndmask_b32_e32 v1, s9, v161, vcc_lo                     // 00000006F568: 02034209
	s_xor_b32 s1, exec_lo, s1                                  // 00000006F56C: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 00000006F570: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 00000006F578: BE813001
	s_cbranch_execz 69                                         // 00000006F57C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1394>
	s_mov_b32 s24, exec_lo                                     // 00000006F580: BE98007E
	.long 0xd4c1007e                                           // 00000006F584: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000006F588: 02033D82
	s_cbranch_execz 63                                         // 00000006F58C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x138c>
	s_mov_b32 s26, 0                                           // 00000006F590: BE9A0080
	s_set_inst_prefetch_distance 0x1                           // 00000006F594: BF840001
	s_branch 19                                                // 00000006F598: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12e8>
	s_nop 0                                                    // 00000006F59C: BF800000
	s_nop 0                                                    // 00000006F5A0: BF800000
	s_nop 0                                                    // 00000006F5A4: BF800000
	s_nop 0                                                    // 00000006F5A8: BF800000
	s_nop 0                                                    // 00000006F5AC: BF800000
	s_nop 0                                                    // 00000006F5B0: BF800000
	s_nop 0                                                    // 00000006F5B4: BF800000
	s_nop 0                                                    // 00000006F5B8: BF800000
	s_nop 0                                                    // 00000006F5BC: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 00000006F5C0: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000006F5C4: BF870499
	s_and_b32 s29, exec_lo, s28                                // 00000006F5C8: 8B1D1C7E
	s_or_b32 s26, s29, s26                                     // 00000006F5CC: 8C1A1A1D
	s_and_not1_b32 s25, s25, exec_lo                           // 00000006F5D0: 91197E19
	s_and_b32 s29, s27, exec_lo                                // 00000006F5D4: 8B1D7E1B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F5D8: BF870009
	s_or_b32 s25, s25, s29                                     // 00000006F5DC: 8C191D19
	s_and_not1_b32 exec_lo, exec_lo, s26                       // 00000006F5E0: 917E1A7E
	s_cbranch_execz 27                                         // 00000006F5E4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1354>
	v_mov_b32_e32 v131, v130                                   // 00000006F5E8: 7F060382
	s_or_b32 s27, s27, exec_lo                                 // 00000006F5EC: 8C1B7E1B
	s_or_b32 s28, s28, exec_lo                                 // 00000006F5F0: 8C1C7E1C
	s_mov_b32 s29, exec_lo                                     // 00000006F5F4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006F5F8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000006F5FC: 3509069F
	.long 0xd73c0086                                           // 00000006F600: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000006F604: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006F608: BF870091
	.long 0xd7006a86                                           // 00000006F60C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 00000006F610: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 00000006F614: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 00000006F61C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 00000006F624: BF8903F7
	.long 0xd4c4007e                                           // 00000006F628: D4C4007E
	v_cndmask_b32_e32 v1, s9, v132, vcc_lo                     // 00000006F62C: 02030809
	s_cbranch_execz 65507                                      // 00000006F630: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000006F634: 4B050681
	s_and_not1_b32 s28, s28, exec_lo                           // 00000006F638: 911C7E1C
	s_and_not1_b32 s27, s27, exec_lo                           // 00000006F63C: 911B7E1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000006F640: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000006F644: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 00000006F648: 8B1E7E6A
	s_or_b32 s28, s28, s30                                     // 00000006F64C: 8C1C1E1C
	s_branch 65499                                             // 00000006F650: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	s_set_inst_prefetch_distance 0x2                           // 00000006F654: BF840002
	s_or_b32 exec_lo, exec_lo, s26                             // 00000006F658: 8C7E1A7E
	v_mov_b32_e32 v130, v158                                   // 00000006F65C: 7F04039E
	s_and_saveexec_b32 s26, s25                                // 00000006F660: BE9A2019
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F664: BF870009
	s_xor_b32 s25, exec_lo, s26                                // 00000006F668: 8D191A7E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 00000006F66C: 7C950809
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 00000006F670: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F67C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000006F680: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 00000006F684: 7F040383
	s_or_b32 exec_lo, exec_lo, s25                             // 00000006F688: 8C7E197E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F68C: BF870009
	s_or_b32 exec_lo, exec_lo, s24                             // 00000006F690: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F694: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006F698: 8C7E017E
	s_or_b32 s8, s8, 3                                         // 00000006F69C: 8C088308
	s_mov_b32 s1, exec_lo                                      // 00000006F6A0: BE81007E
	.long 0xd4c6007e                                           // 00000006F6A4: D4C6007E
	v_cndmask_b32_e32 v1, s8, v161, vcc_lo                     // 00000006F6A8: 02034208
	s_xor_b32 s1, exec_lo, s1                                  // 00000006F6AC: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 00000006F6B0: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 00000006F6B8: BE813001
	s_cbranch_execz 66                                         // 00000006F6BC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c8>
	s_mov_b32 s9, exec_lo                                      // 00000006F6C0: BE89007E
	.long 0xd4c1007e                                           // 00000006F6C4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000006F6C8: 02033D82
	s_cbranch_execz 60                                         // 00000006F6CC: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	s_mov_b32 s25, 0                                           // 00000006F6D0: BE990080
	s_set_inst_prefetch_distance 0x1                           // 00000006F6D4: BF840001
	s_branch 19                                                // 00000006F6D8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1428>
	s_nop 0                                                    // 00000006F6DC: BF800000
	s_nop 0                                                    // 00000006F6E0: BF800000
	s_nop 0                                                    // 00000006F6E4: BF800000
	s_nop 0                                                    // 00000006F6E8: BF800000
	s_nop 0                                                    // 00000006F6EC: BF800000
	s_nop 0                                                    // 00000006F6F0: BF800000
	s_nop 0                                                    // 00000006F6F4: BF800000
	s_nop 0                                                    // 00000006F6F8: BF800000
	s_nop 0                                                    // 00000006F6FC: BF800000
	s_or_b32 exec_lo, exec_lo, s28                             // 00000006F700: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000006F704: BF870499
	s_and_b32 s28, exec_lo, s27                                // 00000006F708: 8B1C1B7E
	s_or_b32 s25, s28, s25                                     // 00000006F70C: 8C19191C
	s_and_not1_b32 s24, s24, exec_lo                           // 00000006F710: 91187E18
	s_and_b32 s28, s26, exec_lo                                // 00000006F714: 8B1C7E1A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F718: BF870009
	s_or_b32 s24, s24, s28                                     // 00000006F71C: 8C181C18
	s_and_not1_b32 exec_lo, exec_lo, s25                       // 00000006F720: 917E197E
	s_cbranch_execz 26                                         // 00000006F724: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1490>
	v_ashrrev_i32_e32 v131, 31, v130                           // 00000006F728: 3507049F
	s_or_b32 s26, s26, exec_lo                                 // 00000006F72C: 8C1A7E1A
	s_or_b32 s27, s27, exec_lo                                 // 00000006F730: 8C1B7E1B
	s_mov_b32 s28, exec_lo                                     // 00000006F734: BE9C007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006F738: BF870091
	.long 0xd73c0083                                           // 00000006F73C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 00000006F740: 02030482
	.long 0xd7006a83                                           // 00000006F744: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 00000006F748: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F74C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 00000006F750: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 00000006F758: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 00000006F760: BF8903F7
	.long 0xd4c4007e                                           // 00000006F764: D4C4007E
	v_cndmask_b32_e32 v1, s8, v131, vcc_lo                     // 00000006F768: 02030608
	s_cbranch_execz 65508                                      // 00000006F76C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	v_add_nc_u32_e32 v130, 1, v130                             // 00000006F770: 4B050481
	s_and_not1_b32 s27, s27, exec_lo                           // 00000006F774: 911B7E1B
	s_and_not1_b32 s26, s26, exec_lo                           // 00000006F778: 911A7E1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000006F77C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000006F780: 7C95059E
	s_and_b32 s29, vcc_lo, exec_lo                             // 00000006F784: 8B1D7E6A
	s_or_b32 s27, s27, s29                                     // 00000006F788: 8C1B1D1B
	s_branch 65500                                             // 00000006F78C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	s_set_inst_prefetch_distance 0x2                           // 00000006F790: BF840002
	s_or_b32 exec_lo, exec_lo, s25                             // 00000006F794: 8C7E197E
	s_and_saveexec_b32 s25, s24                                // 00000006F798: BE992018
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F79C: BF870009
	s_xor_b32 s24, exec_lo, s25                                // 00000006F7A0: 8D18197E
	v_cmp_eq_u32_e32 vcc_lo, s8, v131                          // 00000006F7A4: 7C950608
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 00000006F7A8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F7B4: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000006F7B8: 390B0B82
	s_or_b32 exec_lo, exec_lo, s24                             // 00000006F7BC: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F7C0: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 00000006F7C4: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F7C8: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006F7CC: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F7D0: BF870009
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006F7D4: 8C7E047E
	s_and_saveexec_b32 s4, s3                                  // 00000006F7D8: BE842003
	s_cbranch_execz 1029                                       // 00000006F7DC: BFA50405 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x24f4>
	ds_load_b32 v131, v163                                     // 00000006F7E0: D8D80000 830000A3
	v_and_b32_e32 v130, 1, v133                                // 00000006F7E8: 37050A81
	v_cmp_le_i32_e32 vcc_lo, s2, v162                          // 00000006F7EC: 7C874402
	s_delay_alu instid0(VALU_DEP_2)                            // 00000006F7F0: BF870002
	.long 0xd44a0001                                           // 00000006F7F4: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000006F7F8: 02030481
	s_and_b32 s37, vcc_lo, s1                                  // 00000006F7FC: 8B25016A
	s_waitcnt lgkmcnt(0)                                       // 00000006F800: BF89FC07
	v_mov_b32_e32 v130, v131                                   // 00000006F804: 7F040383
	s_and_saveexec_b32 s1, s37                                 // 00000006F808: BE812025
	s_cbranch_execz 7                                          // 00000006F80C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x152c>
	ds_load_b32 v130, v164                                     // 00000006F810: D8D80000 820000A4
	v_max_f32_e32 v132, v131, v131                             // 00000006F818: 21090783
	s_waitcnt lgkmcnt(0)                                       // 00000006F81C: BF89FC07
	v_max_f32_e32 v130, v130, v130                             // 00000006F820: 21050582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F824: BF870001
	v_max_f32_e32 v130, v132, v130                             // 00000006F828: 21050584
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006F82C: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 00000006F830: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s2, v162                          // 00000006F834: 7C834402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000006F838: BF8704A2
	.long 0xd44d0001                                           // 00000006F83C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006F840: 02030880
	s_and_b32 s36, vcc_lo, s1                                  // 00000006F844: 8B24016A
	s_and_saveexec_b32 s1, s36                                 // 00000006F848: BE812024
	s_cbranch_execz 7                                          // 00000006F84C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x156c>
	ds_load_b32 v132, v164 offset:4                            // 00000006F850: D8D80004 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006F858: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006F85C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006F860: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F864: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006F868: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006F86C: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 00000006F870: 37090A84
	s_or_b32 s1, s2, 2                                         // 00000006F874: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006F878: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000006F87C: 7C874401
	.long 0xd44d0001                                           // 00000006F880: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006F884: 02030880
	s_and_b32 s35, vcc_lo, s1                                  // 00000006F888: 8B23016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F88C: BF870009
	s_and_saveexec_b32 s1, s35                                 // 00000006F890: BE812023
	s_cbranch_execz 7                                          // 00000006F894: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15b4>
	ds_load_b32 v132, v164 offset:8                            // 00000006F898: D8D80008 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006F8A0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006F8A4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006F8A8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F8AC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006F8B0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006F8B4: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 00000006F8B8: 37090A88
	s_or_b32 s1, s2, 3                                         // 00000006F8BC: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006F8C0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000006F8C4: 7C874401
	.long 0xd44d0001                                           // 00000006F8C8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006F8CC: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 00000006F8D0: 8B22016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F8D4: BF870009
	s_and_saveexec_b32 s1, s34                                 // 00000006F8D8: BE812022
	s_cbranch_execz 7                                          // 00000006F8DC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15fc>
	ds_load_b32 v132, v164 offset:12                           // 00000006F8E0: D8D8000C 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006F8E8: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006F8EC: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006F8F0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F8F4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006F8F8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006F8FC: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 00000006F900: 37090A90
	s_or_b32 s1, s2, 4                                         // 00000006F904: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006F908: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000006F90C: 7C874401
	.long 0xd44d0001                                           // 00000006F910: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006F914: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 00000006F918: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F91C: BF870009
	s_and_saveexec_b32 s1, s33                                 // 00000006F920: BE812021
	s_cbranch_execz 7                                          // 00000006F924: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1644>
	ds_load_b32 v132, v164 offset:16                           // 00000006F928: D8D80010 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006F930: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006F934: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006F938: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F93C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006F940: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006F944: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 00000006F948: 37090AA0
	s_or_b32 s1, s2, 5                                         // 00000006F94C: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006F950: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000006F954: 7C874401
	.long 0xd44d0001                                           // 00000006F958: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006F95C: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 00000006F960: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F964: BF870009
	s_and_saveexec_b32 s1, s31                                 // 00000006F968: BE81201F
	s_cbranch_execz 7                                          // 00000006F96C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x168c>
	ds_load_b32 v132, v164 offset:20                           // 00000006F970: D8D80014 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006F978: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006F97C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006F980: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F984: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006F988: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006F98C: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 00000006F990: 37090AC0
	s_or_b32 s1, s2, 6                                         // 00000006F994: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006F998: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000006F99C: 7C874401
	.long 0xd44d0001                                           // 00000006F9A0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006F9A4: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 00000006F9A8: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F9AC: BF870009
	s_and_saveexec_b32 s1, s30                                 // 00000006F9B0: BE81201E
	s_cbranch_execz 7                                          // 00000006F9B4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16d4>
	ds_load_b32 v132, v164 offset:24                           // 00000006F9B8: D8D80018 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006F9C0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006F9C4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006F9C8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F9CC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006F9D0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006F9D4: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 00000006F9D8: 37090AFF 00000080
	s_or_b32 s1, s2, 7                                         // 00000006F9E0: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006F9E4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000006F9E8: 7C874401
	.long 0xd44d0001                                           // 00000006F9EC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006F9F0: 02030880
	s_and_b32 s29, vcc_lo, s1                                  // 00000006F9F4: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F9F8: BF870009
	s_and_saveexec_b32 s1, s29                                 // 00000006F9FC: BE81201D
	s_cbranch_execz 7                                          // 00000006FA00: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1720>
	ds_load_b32 v132, v164 offset:28                           // 00000006FA04: D8D8001C 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006FA0C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006FA10: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006FA14: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006FA18: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006FA1C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006FA20: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 00000006FA24: 37090AFF 00000100
	s_or_b32 s1, s2, 8                                         // 00000006FA2C: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006FA30: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000006FA34: 7C874401
	.long 0xd44d0001                                           // 00000006FA38: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006FA3C: 02030880
	s_and_b32 s28, vcc_lo, s1                                  // 00000006FA40: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006FA44: BF870009
	s_and_saveexec_b32 s1, s28                                 // 00000006FA48: BE81201C
	s_cbranch_execz 7                                          // 00000006FA4C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x176c>
	ds_load_b32 v132, v164 offset:32                           // 00000006FA50: D8D80020 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006FA58: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006FA5C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006FA60: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006FA64: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006FA68: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006FA6C: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 00000006FA70: 37090AFF 00000200
	s_or_b32 s1, s2, 9                                         // 00000006FA78: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006FA7C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000006FA80: 7C874401
	.long 0xd44d0001                                           // 00000006FA84: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006FA88: 02030880
	s_and_b32 s27, vcc_lo, s1                                  // 00000006FA8C: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006FA90: BF870009
	s_and_saveexec_b32 s1, s27                                 // 00000006FA94: BE81201B
	s_cbranch_execz 7                                          // 00000006FA98: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17b8>
	ds_load_b32 v132, v164 offset:36                           // 00000006FA9C: D8D80024 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006FAA4: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006FAA8: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006FAAC: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006FAB0: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006FAB4: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006FAB8: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 00000006FABC: 37090AFF 00000400
	s_or_b32 s1, s2, 10                                        // 00000006FAC4: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006FAC8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000006FACC: 7C874401
	.long 0xd44d0001                                           // 00000006FAD0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006FAD4: 02030880
	s_and_b32 s26, vcc_lo, s1                                  // 00000006FAD8: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006FADC: BF870009
	s_and_saveexec_b32 s1, s26                                 // 00000006FAE0: BE81201A
	s_cbranch_execz 7                                          // 00000006FAE4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1804>
	ds_load_b32 v132, v164 offset:40                           // 00000006FAE8: D8D80028 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006FAF0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006FAF4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006FAF8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006FAFC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006FB00: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006FB04: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 00000006FB08: 37090AFF 00000800
	s_or_b32 s1, s2, 11                                        // 00000006FB10: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006FB14: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000006FB18: 7C874401
	.long 0xd44d0001                                           // 00000006FB1C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006FB20: 02030880
	s_and_b32 s25, vcc_lo, s1                                  // 00000006FB24: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006FB28: BF870009
	s_and_saveexec_b32 s1, s25                                 // 00000006FB2C: BE812019
	s_cbranch_execz 7                                          // 00000006FB30: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1850>
	ds_load_b32 v132, v164 offset:44                           // 00000006FB34: D8D8002C 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006FB3C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006FB40: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006FB44: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006FB48: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006FB4C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006FB50: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 00000006FB54: 37090AFF 00001000
	s_or_b32 s1, s2, 12                                        // 00000006FB5C: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006FB60: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000006FB64: 7C874401
	.long 0xd44d0001                                           // 00000006FB68: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006FB6C: 02030880
	s_and_b32 s24, vcc_lo, s1                                  // 00000006FB70: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006FB74: BF870009
	s_and_saveexec_b32 s1, s24                                 // 00000006FB78: BE812018
	s_cbranch_execz 7                                          // 00000006FB7C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x189c>
	ds_load_b32 v132, v164 offset:48                           // 00000006FB80: D8D80030 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006FB88: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006FB8C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006FB90: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006FB94: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006FB98: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006FB9C: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 00000006FBA0: 37090AFF 00002000
	s_or_b32 s1, s2, 13                                        // 00000006FBA8: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006FBAC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000006FBB0: 7C874401
	.long 0xd44d0001                                           // 00000006FBB4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006FBB8: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 00000006FBBC: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006FBC0: BF870009
	s_and_saveexec_b32 s1, s9                                  // 00000006FBC4: BE812009
	s_cbranch_execz 7                                          // 00000006FBC8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18e8>
	ds_load_b32 v132, v164 offset:52                           // 00000006FBCC: D8D80034 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006FBD4: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006FBD8: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006FBDC: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006FBE0: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006FBE4: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006FBE8: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 00000006FBEC: 37090AFF 00004000
	s_or_b32 s1, s2, 14                                        // 00000006FBF4: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006FBF8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000006FBFC: 7C874401
	.long 0xd44d0001                                           // 00000006FC00: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006FC04: 02030880
	s_and_b32 s8, vcc_lo, s1                                   // 00000006FC08: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006FC0C: BF870009
	s_and_saveexec_b32 s1, s8                                  // 00000006FC10: BE812008
	s_cbranch_execz 7                                          // 00000006FC14: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1934>
	ds_load_b32 v132, v164 offset:56                           // 00000006FC18: D8D80038 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006FC20: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006FC24: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006FC28: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006FC2C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006FC30: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000006FC34: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 00000006FC38: 37090AFF 00008000
	s_or_b32 s2, s2, 15                                        // 00000006FC40: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006FC44: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v162                          // 00000006FC48: 7C874402
	.long 0xd44d0001                                           // 00000006FC4C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000006FC50: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 00000006FC54: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006FC58: BF870009
	s_and_saveexec_b32 s2, s1                                  // 00000006FC5C: BE822001
	s_cbranch_execz 7                                          // 00000006FC60: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1980>
	ds_load_b32 v132, v164 offset:60                           // 00000006FC64: D8D8003C 840000A4
	v_max_f32_e32 v130, v130, v130                             // 00000006FC6C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000006FC70: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000006FC74: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006FC78: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000006FC7C: 21050982
	s_or_b32 exec_lo, exec_lo, s2                              // 00000006FC80: 8C7E027E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 00000006FC84: CA100080 84840080
	s_and_saveexec_b32 s2, s37                                 // 00000006FC8C: BE822025
	s_cbranch_execz 30                                         // 00000006FC90: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a0c>
	ds_load_b32 v133, v164                                     // 00000006FC94: D8D80000 850000A4
	s_waitcnt lgkmcnt(0)                                       // 00000006FC9C: BF89FC07
	v_sub_f32_e32 v133, v133, v130                             // 00000006FCA0: 090B0585
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FCA4: BF870091
	v_mul_f32_e32 v134, 0x3fb8aa3b, v133                       // 00000006FCA8: 110D0AFF 3FB8AA3B
	v_fma_f32 v135, 0x3fb8aa3b, v133, -v134                    // 00000006FCB0: D6130087 861B0AFF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 00000006FCBC: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006FCC0: BF870221
	v_sub_f32_e32 v134, v134, v136                             // 00000006FCC4: 090D1186
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 00000006FCC8: 7C370AFF C2CE8ED0
	v_fmac_f32_e32 v135, 0x32a5705f, v133                      // 00000006FCD0: 570F0AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006FCD8: BF870121
	v_add_f32_e32 v134, v134, v135                             // 00000006FCDC: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 00000006FCE0: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 00000006FCE4: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FCE8: BF870095
	.long 0xd71c0086                                           // 00000006FCEC: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 00000006FCF0: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 00000006FCF4: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 00000006FCF8: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000006FD00: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v134, vcc_lo           // 00000006FD04: 030B0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000006FD0C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FD10: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 00000006FD14: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 00000006FD1C: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v165, v134                             // 00000006FD28: DA840000 000086A5
	s_and_saveexec_b32 s2, s36                                 // 00000006FD30: BE822024
	s_cbranch_execz 30                                         // 00000006FD34: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ab0>
	ds_load_b32 v132, v164 offset:4                            // 00000006FD38: D8D80004 840000A4
	s_waitcnt lgkmcnt(0)                                       // 00000006FD40: BF89FC07
	v_sub_f32_e32 v132, v132, v130                             // 00000006FD44: 09090584
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006FD48: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v132                       // 00000006FD4C: 110D08FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v132                 // 00000006FD54: 7C3708FF C2CE8ED0
	v_fma_f32 v135, 0x3fb8aa3b, v132, -v134                    // 00000006FD5C: D6130087 861B08FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 00000006FD68: 7F104786
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006FD6C: BF870112
	v_fmac_f32_e32 v135, 0x32a5705f, v132                      // 00000006FD70: 570F08FF 32A5705F
	v_sub_f32_e32 v134, v134, v136                             // 00000006FD78: 090D1186
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006FD7C: BF870121
	v_add_f32_e32 v134, v134, v135                             // 00000006FD80: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 00000006FD84: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 00000006FD88: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FD8C: BF870095
	.long 0xd71c0086                                           // 00000006FD90: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 00000006FD94: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 00000006FD98: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v132                 // 00000006FD9C: 7C3D08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000006FDA4: BF870002
	v_cndmask_b32_e32 v132, 0x7f800000, v134, vcc_lo           // 00000006FDA8: 03090CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000006FDB0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006FDB4: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 00000006FDB8: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 00000006FDC0: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 00000006FDC4: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 00000006FDD0: 7F0C0280
	ds_store_b16_d16_hi v165, v136 offset:2                    // 00000006FDD4: DA840002 000088A5
	s_and_saveexec_b32 s2, s35                                 // 00000006FDDC: BE822023
	s_cbranch_execz 29                                         // 00000006FDE0: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b58>
	ds_load_b32 v135, v164 offset:8                            // 00000006FDE4: D8D80008 870000A4
	s_waitcnt lgkmcnt(0)                                       // 00000006FDEC: BF89FC07
	v_sub_f32_e32 v135, v135, v130                             // 00000006FDF0: 090F0587
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FDF4: BF870091
	v_mul_f32_e32 v136, 0x3fb8aa3b, v135                       // 00000006FDF8: 11110EFF 3FB8AA3B
	v_fma_f32 v137, 0x3fb8aa3b, v135, -v136                    // 00000006FE00: D6130089 86230EFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 00000006FE0C: 7F244788
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FE10: BF870091
	v_dual_fmac_f32 v137, 0x32a5705f, v135 :: v_dual_sub_f32 v136, v136, v146// 00000006FE14: C80B0EFF 89892588 32A5705F
	v_add_f32_e32 v136, v136, v137                             // 00000006FE20: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 00000006FE24: 7F121192
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 00000006FE28: 7C370EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006FE30: BF870293
	v_exp_f32_e32 v136, v136                                   // 00000006FE34: 7F104B88
	.long 0xd71c0088                                           // 00000006FE38: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 00000006FE3C: 02031388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006FE40: BF870121
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 00000006FE44: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 00000006FE48: 7C3D0EFF 42B17218
	v_cndmask_b32_e32 v135, 0x7f800000, v136, vcc_lo           // 00000006FE50: 030F10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000006FE58: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FE5C: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 00000006FE60: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 00000006FE68: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v165, v136 offset:4                    // 00000006FE74: DA840004 000088A5
	s_and_saveexec_b32 s2, s34                                 // 00000006FE7C: BE822022
	s_cbranch_execz 30                                         // 00000006FE80: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1bfc>
	ds_load_b32 v134, v164 offset:12                           // 00000006FE84: D8D8000C 860000A4
	s_waitcnt lgkmcnt(0)                                       // 00000006FE8C: BF89FC07
	v_sub_f32_e32 v134, v134, v130                             // 00000006FE90: 090D0586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006FE94: BF870121
	v_mul_f32_e32 v136, 0x3fb8aa3b, v134                       // 00000006FE98: 11110CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 00000006FEA0: 7C370CFF C2CE8ED0
	v_fma_f32 v137, 0x3fb8aa3b, v134, -v136                    // 00000006FEA8: D6130089 86230CFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 00000006FEB4: 7F244788
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006FEB8: BF870112
	v_fmac_f32_e32 v137, 0x32a5705f, v134                      // 00000006FEBC: 57130CFF 32A5705F
	v_sub_f32_e32 v136, v136, v146                             // 00000006FEC4: 09112588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006FEC8: BF870121
	v_add_f32_e32 v136, v136, v137                             // 00000006FECC: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 00000006FED0: 7F121192
	v_exp_f32_e32 v136, v136                                   // 00000006FED4: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FED8: BF870095
	.long 0xd71c0088                                           // 00000006FEDC: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 00000006FEE0: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 00000006FEE4: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 00000006FEE8: 7C3D0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000006FEF0: BF870002
	v_cndmask_b32_e32 v134, 0x7f800000, v136, vcc_lo           // 00000006FEF4: 030D10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000006FEFC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006FF00: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 00000006FF04: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 00000006FF0C: 7F120280
	v_add3_u32 v146, v134, v136, 0x7fff                        // 00000006FF10: D6550092 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 00000006FF1C: 7F100280
	ds_store_b16_d16_hi v165, v146 offset:6                    // 00000006FF20: DA840006 000092A5
	s_and_saveexec_b32 s2, s33                                 // 00000006FF28: BE822021
	s_cbranch_execz 30                                         // 00000006FF2C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ca8>
	ds_load_b32 v137, v164 offset:16                           // 00000006FF30: D8D80010 890000A4
	s_waitcnt lgkmcnt(0)                                       // 00000006FF38: BF89FC07
	v_sub_f32_e32 v137, v137, v130                             // 00000006FF3C: 09130589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FF40: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 00000006FF44: 112512FF 3FB8AA3B
	v_fma_f32 v147, 0x3fb8aa3b, v137, -v146                    // 00000006FF4C: D6130093 864B12FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 00000006FF58: 7F284792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000006FF5C: BF870221
	v_sub_f32_e32 v146, v146, v148                             // 00000006FF60: 09252992
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v137                 // 00000006FF64: 7C3712FF C2CE8ED0
	v_fmac_f32_e32 v147, 0x32a5705f, v137                      // 00000006FF6C: 572712FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006FF74: BF870121
	v_add_f32_e32 v146, v146, v147                             // 00000006FF78: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 00000006FF7C: 7F261194
	v_exp_f32_e32 v146, v146                                   // 00000006FF80: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FF84: BF870095
	.long 0xd71c0092                                           // 00000006FF88: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 00000006FF8C: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 00000006FF90: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v137                 // 00000006FF94: 7C3D12FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000006FF9C: BF870002
	v_cndmask_b32_e32 v137, 0x7f800000, v146, vcc_lo           // 00000006FFA0: 031324FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000006FFA8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FFAC: BF870091
	v_bfe_u32 v146, v137, 16, 1                                // 00000006FFB0: D6100092 02052189
	v_add3_u32 v146, v137, v146, 0x7fff                        // 00000006FFB8: D6550092 03FF2589 00007FFF
	ds_store_b16_d16_hi v165, v146 offset:8                    // 00000006FFC4: DA840008 000092A5
	s_and_saveexec_b32 s2, s31                                 // 00000006FFCC: BE82201F
	s_cbranch_execz 30                                         // 00000006FFD0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d4c>
	ds_load_b32 v136, v164 offset:20                           // 00000006FFD4: D8D80014 880000A4
	s_waitcnt lgkmcnt(0)                                       // 00000006FFDC: BF89FC07
	v_sub_f32_e32 v136, v136, v130                             // 00000006FFE0: 09110588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006FFE4: BF870121
	v_mul_f32_e32 v146, 0x3fb8aa3b, v136                       // 00000006FFE8: 112510FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 00000006FFF0: 7C3710FF C2CE8ED0
	v_fma_f32 v147, 0x3fb8aa3b, v136, -v146                    // 00000006FFF8: D6130093 864B10FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 000000070004: 7F284792
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000070008: BF870112
	v_fmac_f32_e32 v147, 0x32a5705f, v136                      // 00000007000C: 572710FF 32A5705F
	v_sub_f32_e32 v146, v146, v148                             // 000000070014: 09252992
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070018: BF870121
	v_add_f32_e32 v146, v146, v147                             // 00000007001C: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 000000070020: 7F261194
	v_exp_f32_e32 v146, v146                                   // 000000070024: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070028: BF870095
	.long 0xd71c0092                                           // 00000007002C: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 000000070030: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 000000070034: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 000000070038: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000070040: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v146, vcc_lo           // 000000070044: 031124FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007004C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070050: BF870121
	v_bfe_u32 v146, v136, 16, 1                                // 000000070054: D6100092 02052188
	v_mov_b32_e32 v147, 0                                      // 00000007005C: 7F260280
	v_add3_u32 v148, v136, v146, 0x7fff                        // 000000070060: D6550094 03FF2588 00007FFF
	v_mov_b32_e32 v146, 0                                      // 00000007006C: 7F240280
	ds_store_b16_d16_hi v165, v148 offset:10                   // 000000070070: DA84000A 000094A5
	s_and_saveexec_b32 s2, s30                                 // 000000070078: BE82201E
	s_cbranch_execz 29                                         // 00000007007C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1df4>
	ds_load_b32 v147, v164 offset:24                           // 000000070080: D8D80018 930000A4
	s_waitcnt lgkmcnt(0)                                       // 000000070088: BF89FC07
	v_sub_f32_e32 v147, v147, v130                             // 00000007008C: 09270593
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070090: BF870091
	v_mul_f32_e32 v148, 0x3fb8aa3b, v147                       // 000000070094: 112926FF 3FB8AA3B
	v_fma_f32 v149, 0x3fb8aa3b, v147, -v148                    // 00000007009C: D6130095 865326FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 0000000700A8: 7F2C4794
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000700AC: BF870091
	v_dual_fmac_f32 v149, 0x32a5705f, v147 :: v_dual_sub_f32 v148, v148, v150// 0000000700B0: C80B26FF 95952D94 32A5705F
	v_add_f32_e32 v148, v148, v149                             // 0000000700BC: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 0000000700C0: 7F2A1196
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 0000000700C4: 7C3726FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000700CC: BF870293
	v_exp_f32_e32 v148, v148                                   // 0000000700D0: 7F284B94
	.long 0xd71c0094                                           // 0000000700D4: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 0000000700D8: 02032B94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000700DC: BF870121
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 0000000700E0: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 0000000700E4: 7C3D26FF 42B17218
	v_cndmask_b32_e32 v147, 0x7f800000, v148, vcc_lo           // 0000000700EC: 032728FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000700F4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000700F8: BF870091
	v_bfe_u32 v148, v147, 16, 1                                // 0000000700FC: D6100094 02052193
	v_add3_u32 v148, v147, v148, 0x7fff                        // 000000070104: D6550094 03FF2993 00007FFF
	ds_store_b16_d16_hi v165, v148 offset:12                   // 000000070110: DA84000C 000094A5
	s_and_saveexec_b32 s2, s29                                 // 000000070118: BE82201D
	s_cbranch_execz 30                                         // 00000007011C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e98>
	ds_load_b32 v146, v164 offset:28                           // 000000070120: D8D8001C 920000A4
	s_waitcnt lgkmcnt(0)                                       // 000000070128: BF89FC07
	v_sub_f32_e32 v146, v146, v130                             // 00000007012C: 09250592
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070130: BF870121
	v_mul_f32_e32 v148, 0x3fb8aa3b, v146                       // 000000070134: 112924FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 00000007013C: 7C3724FF C2CE8ED0
	v_fma_f32 v149, 0x3fb8aa3b, v146, -v148                    // 000000070144: D6130095 865324FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 000000070150: 7F2C4794
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000070154: BF870112
	v_fmac_f32_e32 v149, 0x32a5705f, v146                      // 000000070158: 572B24FF 32A5705F
	v_sub_f32_e32 v148, v148, v150                             // 000000070160: 09292D94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070164: BF870121
	v_add_f32_e32 v148, v148, v149                             // 000000070168: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 00000007016C: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 000000070170: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070174: BF870095
	.long 0xd71c0094                                           // 000000070178: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 00000007017C: 02032B94
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 000000070180: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 000000070184: 7C3D24FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007018C: BF870002
	v_cndmask_b32_e32 v146, 0x7f800000, v148, vcc_lo           // 000000070190: 032528FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000070198: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007019C: BF870121
	v_bfe_u32 v148, v146, 16, 1                                // 0000000701A0: D6100094 02052192
	v_mov_b32_e32 v149, 0                                      // 0000000701A8: 7F2A0280
	v_add3_u32 v150, v146, v148, 0x7fff                        // 0000000701AC: D6550096 03FF2992 00007FFF
	v_mov_b32_e32 v148, 0                                      // 0000000701B8: 7F280280
	ds_store_b16_d16_hi v165, v150 offset:14                   // 0000000701BC: DA84000E 000096A5
	s_and_saveexec_b32 s2, s28                                 // 0000000701C4: BE82201C
	s_cbranch_execz 30                                         // 0000000701C8: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f44>
	ds_load_b32 v149, v164 offset:32                           // 0000000701CC: D8D80020 950000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000701D4: BF89FC07
	v_sub_f32_e32 v149, v149, v130                             // 0000000701D8: 092B0595
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000701DC: BF870091
	v_mul_f32_e32 v150, 0x3fb8aa3b, v149                       // 0000000701E0: 112D2AFF 3FB8AA3B
	v_fma_f32 v151, 0x3fb8aa3b, v149, -v150                    // 0000000701E8: D6130097 865B2AFF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 0000000701F4: 7F304796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000701F8: BF870221
	v_sub_f32_e32 v150, v150, v152                             // 0000000701FC: 092D3196
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 000000070200: 7C372AFF C2CE8ED0
	v_fmac_f32_e32 v151, 0x32a5705f, v149                      // 000000070208: 572F2AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070210: BF870121
	v_add_f32_e32 v150, v150, v151                             // 000000070214: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 000000070218: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 00000007021C: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070220: BF870095
	.long 0xd71c0096                                           // 000000070224: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 000000070228: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 00000007022C: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 000000070230: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000070238: BF870002
	v_cndmask_b32_e32 v149, 0x7f800000, v150, vcc_lo           // 00000007023C: 032B2CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000070244: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070248: BF870091
	v_bfe_u32 v150, v149, 16, 1                                // 00000007024C: D6100096 02052195
	v_add3_u32 v150, v149, v150, 0x7fff                        // 000000070254: D6550096 03FF2D95 00007FFF
	ds_store_b16_d16_hi v165, v150 offset:16                   // 000000070260: DA840010 000096A5
	s_and_saveexec_b32 s2, s27                                 // 000000070268: BE82201B
	s_cbranch_execz 30                                         // 00000007026C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1fe8>
	ds_load_b32 v148, v164 offset:36                           // 000000070270: D8D80024 940000A4
	s_waitcnt lgkmcnt(0)                                       // 000000070278: BF89FC07
	v_sub_f32_e32 v148, v148, v130                             // 00000007027C: 09290594
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070280: BF870121
	v_mul_f32_e32 v150, 0x3fb8aa3b, v148                       // 000000070284: 112D28FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 00000007028C: 7C3728FF C2CE8ED0
	v_fma_f32 v151, 0x3fb8aa3b, v148, -v150                    // 000000070294: D6130097 865B28FF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 0000000702A0: 7F304796
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000702A4: BF870112
	v_fmac_f32_e32 v151, 0x32a5705f, v148                      // 0000000702A8: 572F28FF 32A5705F
	v_sub_f32_e32 v150, v150, v152                             // 0000000702B0: 092D3196
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000702B4: BF870121
	v_add_f32_e32 v150, v150, v151                             // 0000000702B8: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 0000000702BC: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 0000000702C0: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000702C4: BF870095
	.long 0xd71c0096                                           // 0000000702C8: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 0000000702CC: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 0000000702D0: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 0000000702D4: 7C3D28FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000702DC: BF870002
	v_cndmask_b32_e32 v148, 0x7f800000, v150, vcc_lo           // 0000000702E0: 03292CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000702E8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000702EC: BF870121
	v_bfe_u32 v150, v148, 16, 1                                // 0000000702F0: D6100096 02052194
	v_mov_b32_e32 v151, 0                                      // 0000000702F8: 7F2E0280
	v_add3_u32 v152, v148, v150, 0x7fff                        // 0000000702FC: D6550098 03FF2D94 00007FFF
	v_mov_b32_e32 v150, 0                                      // 000000070308: 7F2C0280
	ds_store_b16_d16_hi v165, v152 offset:18                   // 00000007030C: DA840012 000098A5
	s_and_saveexec_b32 s2, s26                                 // 000000070314: BE82201A
	s_cbranch_execz 30                                         // 000000070318: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2094>
	ds_load_b32 v151, v164 offset:40                           // 00000007031C: D8D80028 970000A4
	s_waitcnt lgkmcnt(0)                                       // 000000070324: BF89FC07
	v_sub_f32_e32 v151, v151, v130                             // 000000070328: 092F0597
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007032C: BF870091
	v_mul_f32_e32 v152, 0x3fb8aa3b, v151                       // 000000070330: 11312EFF 3FB8AA3B
	v_fma_f32 v153, 0x3fb8aa3b, v151, -v152                    // 000000070338: D6130099 86632EFF 3FB8AA3B
	v_rndne_f32_e32 v177, v152                                 // 000000070344: 7F624798
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000070348: BF870221
	v_sub_f32_e32 v152, v152, v177                             // 00000007034C: 09316398
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 000000070350: 7C372EFF C2CE8ED0
	v_fmac_f32_e32 v153, 0x32a5705f, v151                      // 000000070358: 57332EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070360: BF870121
	v_add_f32_e32 v152, v152, v153                             // 000000070364: 07313398
	v_cvt_i32_f32_e32 v153, v177                               // 000000070368: 7F3211B1
	v_exp_f32_e32 v152, v152                                   // 00000007036C: 7F304B98
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070370: BF870095
	.long 0xd71c0098                                           // 000000070374: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 000000070378: 02033398
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 00000007037C: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 000000070380: 7C3D2EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000070388: BF870002
	v_cndmask_b32_e32 v151, 0x7f800000, v152, vcc_lo           // 00000007038C: 032F30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000070394: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070398: BF870091
	v_bfe_u32 v152, v151, 16, 1                                // 00000007039C: D6100098 02052197
	v_add3_u32 v152, v151, v152, 0x7fff                        // 0000000703A4: D6550098 03FF3197 00007FFF
	ds_store_b16_d16_hi v165, v152 offset:20                   // 0000000703B0: DA840014 000098A5
	s_and_saveexec_b32 s2, s25                                 // 0000000703B8: BE822019
	s_cbranch_execz 29                                         // 0000000703BC: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2134>
	ds_load_b32 v150, v164 offset:44                           // 0000000703C0: D8D8002C 960000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000703C8: BF89FC07
	v_sub_f32_e32 v150, v150, v130                             // 0000000703CC: 092D0596
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000703D0: BF870121
	v_mul_f32_e32 v152, 0x3fb8aa3b, v150                       // 0000000703D4: 11312CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 0000000703DC: 7C372CFF C2CE8ED0
	v_fma_f32 v153, 0x3fb8aa3b, v150, -v152                    // 0000000703E4: D6130099 86632CFF 3FB8AA3B
	v_rndne_f32_e32 v177, v152                                 // 0000000703F0: 7F624798
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000703F4: BF870091
	v_dual_fmac_f32 v153, 0x32a5705f, v150 :: v_dual_sub_f32 v152, v152, v177// 0000000703F8: C80B2CFF 99996398 32A5705F
	v_add_f32_e32 v152, v152, v153                             // 000000070404: 07313398
	v_cvt_i32_f32_e32 v153, v177                               // 000000070408: 7F3211B1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007040C: BF870292
	v_exp_f32_e32 v152, v152                                   // 000000070410: 7F304B98
	.long 0xd71c0098                                           // 000000070414: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 000000070418: 02033398
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007041C: BF870121
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 000000070420: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 000000070424: 7C3D2CFF 42B17218
	v_cndmask_b32_e32 v150, 0x7f800000, v152, vcc_lo           // 00000007042C: 032D30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000070434: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070438: BF870121
	v_bfe_u32 v152, v150, 16, 1                                // 00000007043C: D6100098 02052196
	v_mov_b32_e32 v153, 0                                      // 000000070444: 7F320280
	v_add3_u32 v177, v150, v152, 0x7fff                        // 000000070448: D65500B1 03FF3196 00007FFF
	v_mov_b32_e32 v152, 0                                      // 000000070454: 7F300280
	ds_store_b16_d16_hi v165, v177 offset:22                   // 000000070458: DA840016 0000B1A5
	s_and_saveexec_b32 s2, s24                                 // 000000070460: BE822018
	s_cbranch_execz 29                                         // 000000070464: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21dc>
	ds_load_b32 v153, v164 offset:48                           // 000000070468: D8D80030 990000A4
	s_waitcnt lgkmcnt(0)                                       // 000000070470: BF89FC07
	v_sub_f32_e32 v153, v153, v130                             // 000000070474: 09330599
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070478: BF870121
	v_mul_f32_e32 v177, 0x3fb8aa3b, v153                       // 00000007047C: 116332FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 000000070484: 7C3732FF C2CE8ED0
	v_fma_f32 v178, 0x3fb8aa3b, v153, -v177                    // 00000007048C: D61300B2 86C732FF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 000000070498: 7F6647B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007049C: BF870091
	v_dual_fmac_f32 v178, 0x32a5705f, v153 :: v_dual_sub_f32 v177, v177, v179// 0000000704A0: C80B32FF B2B167B1 32A5705F
	v_add_f32_e32 v177, v177, v178                             // 0000000704AC: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 0000000704B0: 7F6411B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000704B4: BF870292
	v_exp_f32_e32 v177, v177                                   // 0000000704B8: 7F624BB1
	.long 0xd71c00b1                                           // 0000000704BC: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 0000000704C0: 020365B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000704C4: BF870121
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 0000000704C8: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 0000000704CC: 7C3D32FF 42B17218
	v_cndmask_b32_e32 v153, 0x7f800000, v177, vcc_lo           // 0000000704D4: 033362FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000704DC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000704E0: BF870091
	v_bfe_u32 v177, v153, 16, 1                                // 0000000704E4: D61000B1 02052199
	v_add3_u32 v177, v153, v177, 0x7fff                        // 0000000704EC: D65500B1 03FF6399 00007FFF
	ds_store_b16_d16_hi v165, v177 offset:24                   // 0000000704F8: DA840018 0000B1A5
	s_and_saveexec_b32 s2, s9                                  // 000000070500: BE822009
	s_cbranch_execz 30                                         // 000000070504: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2280>
	ds_load_b32 v152, v164 offset:52                           // 000000070508: D8D80034 980000A4
	s_waitcnt lgkmcnt(0)                                       // 000000070510: BF89FC07
	v_sub_f32_e32 v152, v152, v130                             // 000000070514: 09310598
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070518: BF870091
	v_mul_f32_e32 v177, 0x3fb8aa3b, v152                       // 00000007051C: 116330FF 3FB8AA3B
	v_fma_f32 v178, 0x3fb8aa3b, v152, -v177                    // 000000070524: D61300B2 86C730FF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 000000070530: 7F6647B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000070534: BF870221
	v_sub_f32_e32 v177, v177, v179                             // 000000070538: 096367B1
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 00000007053C: 7C3730FF C2CE8ED0
	v_fmac_f32_e32 v178, 0x32a5705f, v152                      // 000000070544: 576530FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007054C: BF870121
	v_add_f32_e32 v177, v177, v178                             // 000000070550: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 000000070554: 7F6411B3
	v_exp_f32_e32 v177, v177                                   // 000000070558: 7F624BB1
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007055C: BF870095
	.long 0xd71c00b1                                           // 000000070560: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 000000070564: 020365B1
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 000000070568: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 00000007056C: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000070574: BF870002
	v_cndmask_b32_e32 v152, 0x7f800000, v177, vcc_lo           // 000000070578: 033162FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000070580: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070584: BF870121
	v_bfe_u32 v177, v152, 16, 1                                // 000000070588: D61000B1 02052198
	v_mov_b32_e32 v178, 0                                      // 000000070590: 7F640280
	v_add3_u32 v179, v152, v177, 0x7fff                        // 000000070594: D65500B3 03FF6398 00007FFF
	v_mov_b32_e32 v177, 0                                      // 0000000705A0: 7F620280
	ds_store_b16_d16_hi v165, v179 offset:26                   // 0000000705A4: DA84001A 0000B3A5
	s_and_saveexec_b32 s2, s8                                  // 0000000705AC: BE822008
	s_cbranch_execz 30                                         // 0000000705B0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x232c>
	ds_load_b32 v178, v164 offset:56                           // 0000000705B4: D8D80038 B20000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000705BC: BF89FC07
	v_sub_f32_e32 v178, v178, v130                             // 0000000705C0: 096505B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000705C4: BF870091
	v_mul_f32_e32 v179, 0x3fb8aa3b, v178                       // 0000000705C8: 116764FF 3FB8AA3B
	v_fma_f32 v180, 0x3fb8aa3b, v178, -v179                    // 0000000705D0: D61300B4 86CF64FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000705DC: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000705E0: BF870221
	v_sub_f32_e32 v179, v179, v181                             // 0000000705E4: 09676BB3
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 0000000705E8: 7C3764FF C2CE8ED0
	v_fmac_f32_e32 v180, 0x32a5705f, v178                      // 0000000705F0: 576964FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000705F8: BF870121
	v_add_f32_e32 v179, v179, v180                             // 0000000705FC: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 000000070600: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 000000070604: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070608: BF870095
	.long 0xd71c00b3                                           // 00000007060C: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 000000070610: 020369B3
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 000000070614: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 000000070618: 7C3D64FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000070620: BF870002
	v_cndmask_b32_e32 v178, 0x7f800000, v179, vcc_lo           // 000000070624: 036566FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007062C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070630: BF870091
	v_bfe_u32 v179, v178, 16, 1                                // 000000070634: D61000B3 020521B2
	v_add3_u32 v179, v178, v179, 0x7fff                        // 00000007063C: D65500B3 03FF67B2 00007FFF
	ds_store_b16_d16_hi v165, v179 offset:28                   // 000000070648: DA84001C 0000B3A5
	s_and_saveexec_b32 s2, s1                                  // 000000070650: BE822001
	s_cbranch_execz 30                                         // 000000070654: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x23d0>
	ds_load_b32 v177, v164 offset:60                           // 000000070658: D8D8003C B10000A4
	s_waitcnt lgkmcnt(0)                                       // 000000070660: BF89FC07
	v_sub_f32_e32 v177, v177, v130                             // 000000070664: 096305B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070668: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v177                       // 00000007066C: 116762FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v177                 // 000000070674: 7C3762FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v177, -v179                    // 00000007067C: D61300B4 86CF62FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 000000070688: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007068C: BF870112
	v_fmac_f32_e32 v180, 0x32a5705f, v177                      // 000000070690: 576962FF 32A5705F
	v_sub_f32_e32 v179, v179, v181                             // 000000070698: 09676BB3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007069C: BF870121
	v_add_f32_e32 v179, v179, v180                             // 0000000706A0: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000706A4: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 0000000706A8: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000706AC: BF870095
	.long 0xd71c00b3                                           // 0000000706B0: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000706B4: 020369B3
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000706B8: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v177                 // 0000000706BC: 7C3D62FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000706C4: BF870002
	v_cndmask_b32_e32 v177, 0x7f800000, v179, vcc_lo           // 0000000706C8: 036366FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000706D0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000706D4: BF8700A1
	v_bfe_u32 v179, v177, 16, 1                                // 0000000706D8: D61000B3 020521B1
	s_mov_b32 s1, exec_lo                                      // 0000000706E0: BE81007E
	v_add3_u32 v180, v177, v179, 0x7fff                        // 0000000706E4: D65500B4 03FF67B1 00007FFF
	v_mov_b32_e32 v179, 0                                      // 0000000706F0: 7F660280
	ds_store_b16_d16_hi v165, v180 offset:30                   // 0000000706F4: DA84001E 0000B4A5
	v_cmpx_lt_f32_e32 0xefa18f08, v131                         // 0000000706FC: 7D2306FF EFA18F08
	s_cbranch_execz 26                                         // 000000070704: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2470>
	v_sub_f32_e32 v131, v131, v130                             // 000000070708: 09070583
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007070C: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v131                       // 000000070710: 116706FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 000000070718: 7C3706FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v131, -v179                    // 000000070720: D61300B4 86CF06FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 00000007072C: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070730: BF870091
	v_dual_fmac_f32 v180, 0x32a5705f, v131 :: v_dual_sub_f32 v179, v179, v181// 000000070734: C80B06FF B4B36BB3 32A5705F
	v_add_f32_e32 v179, v179, v180                             // 000000070740: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 000000070744: 7F6811B5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000070748: BF870292
	v_exp_f32_e32 v179, v179                                   // 00000007074C: 7F664BB3
	.long 0xd71c00b3                                           // 000000070750: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 000000070754: 020369B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070758: BF870121
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 00000007075C: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 000000070760: 7C3D06FF 42B17218
	v_cndmask_b32_e32 v179, 0x7f800000, v179, vcc_lo           // 000000070768: 036766FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000070770: 8C7E017E
	v_add_f32_e32 v131, v133, v132                             // 000000070774: 07070985
	ds_load_b32 v132, v166                                     // 000000070778: D8D80000 840000A6
	v_add_f32_e32 v131, v131, v135                             // 000000070780: 07070F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070784: BF870091
	v_add_f32_e32 v131, v131, v134                             // 000000070788: 07070D83
	v_add_f32_e32 v131, v131, v137                             // 00000007078C: 07071383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070790: BF870091
	v_add_f32_e32 v131, v131, v136                             // 000000070794: 07071183
	v_add_f32_e32 v131, v131, v147                             // 000000070798: 07072783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007079C: BF870091
	v_add_f32_e32 v131, v131, v146                             // 0000000707A0: 07072583
	v_add_f32_e32 v131, v131, v149                             // 0000000707A4: 07072B83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000707A8: BF870091
	v_add_f32_e32 v131, v131, v148                             // 0000000707AC: 07072983
	v_add_f32_e32 v131, v131, v151                             // 0000000707B0: 07072F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000707B4: BF870091
	v_add_f32_e32 v131, v131, v150                             // 0000000707B8: 07072D83
	v_add_f32_e32 v131, v131, v153                             // 0000000707BC: 07073383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000707C0: BF870091
	v_add_f32_e32 v131, v131, v152                             // 0000000707C4: 07073183
	v_add_f32_e32 v131, v131, v178                             // 0000000707C8: 07076583
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000707CC: BF8700A1
	v_add_f32_e32 v131, v131, v177                             // 0000000707D0: 07076383
	s_waitcnt lgkmcnt(0)                                       // 0000000707D4: BF89FC07
	v_fmac_f32_e32 v131, v179, v132                            // 0000000707D8: 570709B3
	ds_store_b32 v163, v130                                    // 0000000707DC: D8340000 000082A3
	ds_store_b32 v166, v131                                    // 0000000707E4: D8340000 000083A6
	ds_store_b32 v167, v179                                    // 0000000707EC: D8340000 0000B3A7
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000707F4: 8C7E047E
	ds_load_2addr_b32 v[152:153], v168 offset1:2               // 0000000707F8: D8DC0200 980000A8
	ds_load_2addr_b32 v[150:151], v168 offset0:4 offset1:6     // 000000070800: D8DC0604 960000A8
	ds_load_2addr_b32 v[148:149], v168 offset0:8 offset1:10    // 000000070808: D8DC0A08 940000A8
	ds_load_2addr_b32 v[146:147], v168 offset0:12 offset1:14   // 000000070810: D8DC0E0C 920000A8
	s_waitcnt lgkmcnt(3)                                       // 000000070818: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v152                         // 00000007081C: 7C2530F2
	.long 0xd4120001                                           // 000000070820: D4120001
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 000000070824: 020332F2
	s_waitcnt lgkmcnt(2)                                       // 000000070828: BF89FC27
	.long 0xd4120002                                           // 00000007082C: D4120002
	v_cndmask_b32_e32 v1, 1.0, v150, vcc_lo                    // 000000070830: 02032CF2
	.long 0xd4120004                                           // 000000070834: D4120004
	v_cndmask_b32_e32 v1, 1.0, v151, vcc_lo                    // 000000070838: 02032EF2
	s_and_b32 s1, vcc_lo, s1                                   // 00000007083C: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 000000070840: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v148                         // 000000070844: 7C2528F2
	s_and_b32 s2, s1, s2                                       // 000000070848: 8B020201
	.long 0xd4120001                                           // 00000007084C: D4120001
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 000000070850: 02032AF2
	s_and_b32 s4, s2, s4                                       // 000000070854: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 000000070858: BF89FC07
	.long 0xd4120002                                           // 00000007085C: D4120002
	v_cndmask_b32_e32 v1, 1.0, v146, vcc_lo                    // 000000070860: 020324F2
	s_and_b32 s4, s4, vcc_lo                                   // 000000070864: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v147                         // 000000070868: 7C2526F2
	s_and_b32 s1, s4, s1                                       // 00000007086C: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000070870: BF870499
	s_and_b32 s1, s1, s2                                       // 000000070874: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 000000070878: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007087C: BF870099
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 000000070880: D5010082 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v130                           // 000000070888: 7C9B0480
	ds_load_b128 v[130:133], v169                              // 00000007088C: DBFC0000 820000A9
	ds_load_b128 v[134:137], v169 offset:16                    // 000000070894: DBFC0010 860000A9
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 00000007089C: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 0000000708A0: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000708A4: BF870099
	v_cndmask_b32_e64 v177, 0, 1, s1                           // 0000000708A8: D50100B1 00050280
	v_readfirstlane_b32 s1, v177                               // 0000000708B0: 7E0205B1
	s_bitcmp1_b32 s1, 0                                        // 0000000708B4: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 0000000708B8: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000708BC: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 0000000708C0: 8B6A017E
	s_cbranch_vccnz 63584                                      // 0000000708C4: BFA4F860 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x748>
	v_dual_mul_f32 v121, v152, v121 :: v_dual_mul_f32 v122, v153, v122// 0000000708C8: C8C6F398 797AF599
	v_dual_mul_f32 v123, v150, v123 :: v_dual_mul_f32 v124, v151, v124// 0000000708D0: C8C6F796 7B7CF997
	v_dual_mul_f32 v125, v148, v125 :: v_dual_mul_f32 v126, v149, v126// 0000000708D8: C8C6FB94 7D7EFD95
	v_dual_mul_f32 v127, v146, v127 :: v_dual_mul_f32 v128, v147, v128// 0000000708E0: C8C6FF92 7F810193
	v_dual_mul_f32 v113, v152, v113 :: v_dual_mul_f32 v114, v153, v114// 0000000708E8: C8C6E398 7172E599
	v_dual_mul_f32 v115, v150, v115 :: v_dual_mul_f32 v116, v151, v116// 0000000708F0: C8C6E796 7374E997
	v_dual_mul_f32 v117, v148, v117 :: v_dual_mul_f32 v118, v149, v118// 0000000708F8: C8C6EB94 7576ED95
	v_dual_mul_f32 v119, v146, v119 :: v_dual_mul_f32 v120, v147, v120// 000000070900: C8C6EF92 7778F193
	v_dual_mul_f32 v105, v152, v105 :: v_dual_mul_f32 v106, v153, v106// 000000070908: C8C6D398 696AD599
	v_dual_mul_f32 v107, v150, v107 :: v_dual_mul_f32 v108, v151, v108// 000000070910: C8C6D796 6B6CD997
	v_dual_mul_f32 v109, v148, v109 :: v_dual_mul_f32 v110, v149, v110// 000000070918: C8C6DB94 6D6EDD95
	v_dual_mul_f32 v111, v146, v111 :: v_dual_mul_f32 v112, v147, v112// 000000070920: C8C6DF92 6F70E193
	v_dual_mul_f32 v97, v152, v97 :: v_dual_mul_f32 v98, v153, v98// 000000070928: C8C6C398 6162C599
	v_dual_mul_f32 v99, v150, v99 :: v_dual_mul_f32 v100, v151, v100// 000000070930: C8C6C796 6364C997
	v_dual_mul_f32 v101, v148, v101 :: v_dual_mul_f32 v102, v149, v102// 000000070938: C8C6CB94 6566CD95
	v_dual_mul_f32 v103, v146, v103 :: v_dual_mul_f32 v104, v147, v104// 000000070940: C8C6CF92 6768D193
	v_dual_mul_f32 v89, v152, v89 :: v_dual_mul_f32 v90, v153, v90// 000000070948: C8C6B398 595AB599
	v_dual_mul_f32 v91, v150, v91 :: v_dual_mul_f32 v92, v151, v92// 000000070950: C8C6B796 5B5CB997
	v_dual_mul_f32 v93, v148, v93 :: v_dual_mul_f32 v94, v149, v94// 000000070958: C8C6BB94 5D5EBD95
	v_dual_mul_f32 v95, v146, v95 :: v_dual_mul_f32 v96, v147, v96// 000000070960: C8C6BF92 5F60C193
	v_dual_mul_f32 v81, v152, v81 :: v_dual_mul_f32 v82, v153, v82// 000000070968: C8C6A398 5152A599
	v_dual_mul_f32 v83, v150, v83 :: v_dual_mul_f32 v84, v151, v84// 000000070970: C8C6A796 5354A997
	v_dual_mul_f32 v85, v148, v85 :: v_dual_mul_f32 v86, v149, v86// 000000070978: C8C6AB94 5556AD95
	v_dual_mul_f32 v87, v146, v87 :: v_dual_mul_f32 v88, v147, v88// 000000070980: C8C6AF92 5758B193
	v_dual_mul_f32 v73, v152, v73 :: v_dual_mul_f32 v74, v153, v74// 000000070988: C8C69398 494A9599
	v_dual_mul_f32 v75, v150, v75 :: v_dual_mul_f32 v76, v151, v76// 000000070990: C8C69796 4B4C9997
	v_dual_mul_f32 v77, v148, v77 :: v_dual_mul_f32 v78, v149, v78// 000000070998: C8C69B94 4D4E9D95
	v_dual_mul_f32 v79, v146, v79 :: v_dual_mul_f32 v80, v147, v80// 0000000709A0: C8C69F92 4F50A193
	v_dual_mul_f32 v65, v152, v65 :: v_dual_mul_f32 v66, v153, v66// 0000000709A8: C8C68398 41428599
	v_dual_mul_f32 v67, v150, v67 :: v_dual_mul_f32 v68, v151, v68// 0000000709B0: C8C68796 43448997
	v_dual_mul_f32 v69, v148, v69 :: v_dual_mul_f32 v70, v149, v70// 0000000709B8: C8C68B94 45468D95
	v_dual_mul_f32 v71, v146, v71 :: v_dual_mul_f32 v72, v147, v72// 0000000709C0: C8C68F92 47489193
	v_dual_mul_f32 v57, v152, v57 :: v_dual_mul_f32 v58, v153, v58// 0000000709C8: C8C67398 393A7599
	v_dual_mul_f32 v59, v150, v59 :: v_dual_mul_f32 v60, v151, v60// 0000000709D0: C8C67796 3B3C7997
	v_dual_mul_f32 v61, v148, v61 :: v_dual_mul_f32 v62, v149, v62// 0000000709D8: C8C67B94 3D3E7D95
	v_dual_mul_f32 v63, v146, v63 :: v_dual_mul_f32 v64, v147, v64// 0000000709E0: C8C67F92 3F408193
	v_dual_mul_f32 v49, v152, v49 :: v_dual_mul_f32 v50, v153, v50// 0000000709E8: C8C66398 31326599
	v_dual_mul_f32 v51, v150, v51 :: v_dual_mul_f32 v52, v151, v52// 0000000709F0: C8C66796 33346997
	v_dual_mul_f32 v53, v148, v53 :: v_dual_mul_f32 v54, v149, v54// 0000000709F8: C8C66B94 35366D95
	v_dual_mul_f32 v55, v146, v55 :: v_dual_mul_f32 v56, v147, v56// 000000070A00: C8C66F92 37387193
	v_dual_mul_f32 v41, v152, v41 :: v_dual_mul_f32 v42, v153, v42// 000000070A08: C8C65398 292A5599
	v_dual_mul_f32 v43, v150, v43 :: v_dual_mul_f32 v44, v151, v44// 000000070A10: C8C65796 2B2C5997
	v_dual_mul_f32 v45, v148, v45 :: v_dual_mul_f32 v46, v149, v46// 000000070A18: C8C65B94 2D2E5D95
	v_dual_mul_f32 v47, v146, v47 :: v_dual_mul_f32 v48, v147, v48// 000000070A20: C8C65F92 2F306193
	v_dual_mul_f32 v33, v152, v33 :: v_dual_mul_f32 v34, v153, v34// 000000070A28: C8C64398 21224599
	v_dual_mul_f32 v35, v150, v35 :: v_dual_mul_f32 v36, v151, v36// 000000070A30: C8C64796 23244997
	v_dual_mul_f32 v37, v148, v37 :: v_dual_mul_f32 v38, v149, v38// 000000070A38: C8C64B94 25264D95
	v_dual_mul_f32 v39, v146, v39 :: v_dual_mul_f32 v40, v147, v40// 000000070A40: C8C64F92 27285193
	v_dual_mul_f32 v25, v152, v25 :: v_dual_mul_f32 v26, v153, v26// 000000070A48: C8C63398 191A3599
	v_dual_mul_f32 v27, v150, v27 :: v_dual_mul_f32 v28, v151, v28// 000000070A50: C8C63796 1B1C3997
	v_dual_mul_f32 v29, v148, v29 :: v_dual_mul_f32 v30, v149, v30// 000000070A58: C8C63B94 1D1E3D95
	v_dual_mul_f32 v31, v146, v31 :: v_dual_mul_f32 v32, v147, v32// 000000070A60: C8C63F92 1F204193
	v_dual_mul_f32 v17, v152, v17 :: v_dual_mul_f32 v18, v153, v18// 000000070A68: C8C62398 11122599
	v_dual_mul_f32 v19, v150, v19 :: v_dual_mul_f32 v20, v151, v20// 000000070A70: C8C62796 13142997
	v_dual_mul_f32 v21, v148, v21 :: v_dual_mul_f32 v22, v149, v22// 000000070A78: C8C62B94 15162D95
	v_dual_mul_f32 v23, v146, v23 :: v_dual_mul_f32 v24, v147, v24// 000000070A80: C8C62F92 17183193
	v_dual_mul_f32 v9, v152, v9 :: v_dual_mul_f32 v10, v153, v10// 000000070A88: C8C61398 090A1599
	v_dual_mul_f32 v11, v150, v11 :: v_dual_mul_f32 v12, v151, v12// 000000070A90: C8C61796 0B0C1997
	v_dual_mul_f32 v13, v148, v13 :: v_dual_mul_f32 v14, v149, v14// 000000070A98: C8C61B94 0D0E1D95
	v_dual_mul_f32 v15, v146, v15 :: v_dual_mul_f32 v16, v147, v16// 000000070AA0: C8C61F92 0F102193
	v_dual_mul_f32 v1, v152, v1 :: v_dual_mul_f32 v2, v153, v2 // 000000070AA8: C8C60398 01020599
	v_dual_mul_f32 v3, v150, v3 :: v_dual_mul_f32 v4, v151, v4 // 000000070AB0: C8C60796 03040997
	v_dual_mul_f32 v5, v148, v5 :: v_dual_mul_f32 v6, v149, v6 // 000000070AB8: C8C60B94 05060D95
	v_dual_mul_f32 v7, v146, v7 :: v_dual_mul_f32 v8, v147, v8 // 000000070AC0: C8C60F92 07081193
	s_branch 63455                                             // 000000070AC8: BFA0F7DF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x748>
	v_lshlrev_b32_e32 v0, 2, v157                              // 000000070ACC: 30013A82
	.long 0xd700008b                                           // 000000070AD0: D700008B
	v_cndmask_b32_e32 v1, s18, v139, vcc_lo                    // 000000070AD4: 02031612
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000070AD8: BF870191
	v_add_co_ci_u32_e64 v140, null, s19, v140, s0              // 000000070ADC: D5207C8C 00031813
	v_lshl_or_b32 v0, v156, 6, v0                              // 000000070AE4: D6560000 04010D9C
	v_lshlrev_b32_e32 v147, 1, v154                            // 000000070AEC: 31273481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000070AF0: BF870152
	v_add_nc_u32_e32 v133, 0xa000, v0                          // 000000070AF4: 4B0A00FF 0000A000
	ds_load_2addr_b32 v[141:142], v133 offset0:128 offset1:130 // 000000070AFC: D8DC8280 8D000085
	s_waitcnt lgkmcnt(0)                                       // 000000070B04: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 000000070B08: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 000000070B10: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 000000070B18: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000070B1C: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 000000070B20: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 000000070B28: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:132 offset1:134 // 000000070B2C: D8DC8684 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:136 offset1:138 // 000000070B34: D8DC8A88 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:140 offset1:142 // 000000070B3C: D8DC8E8C 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 000000070B44: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 000000070B48: 3505029F
	v_or_b32_e32 v0, v155, v157                                // 000000070B4C: 38013B9B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000070B50: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 000000070B54: 11252191
	.long 0xd73c0083                                           // 000000070B58: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 000000070B5C: 02030281
	.long 0xd7000081                                           // 000000070B60: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 000000070B64: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000070B68: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 000000070B6C: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 000000070B74: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070B7C: BF870094
	.long 0xd7000083                                           // 000000070B80: D7000083
	v_cndmask_b32_e32 v1, s16, v131, vcc_lo                    // 000000070B84: 02030610
	v_add_co_ci_u32_e64 v132, null, s17, v132, s0              // 000000070B88: D5207C84 00030811
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070B90: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 000000070B94: 57252194
	.long 0xd4440000                                           // 000000070B98: D4440000
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 000000070B9C: 0202000E
	v_fma_f32 v139, -v143, v146, v145                          // 000000070BA0: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000070BA8: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 000000070BAC: D637008B 064B218B
	.long 0xd7006a83                                           // 000000070BB4: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 000000070BB8: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 000000070BBC: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 000000070BC4: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 000000070BC8: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 000000070BD0: BE812000
	s_cbranch_execz 70                                         // 000000070BD4: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x29f0>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000070BD8: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 000000070BDC: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 000000070BE8: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 000000070BEC: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 000000070BF4: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 000000070BF8: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070BFC: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 000000070C00: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 000000070C08: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 000000070C14: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000070C18: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 000000070C1C: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 000000070C24: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000070C28: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 000000070C2C: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 000000070C30: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 000000070C34: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 000000070C3C: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070C40: BF870095
	.long 0xd71c008d                                           // 000000070C44: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 000000070C48: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 000000070C4C: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 000000070C50: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070C58: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 000000070C5C: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 000000070C64: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070C68: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 000000070C6C: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 000000070C74: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070C78: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 000000070C7C: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 000000070C84: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 000000070C88: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070C90: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000070C94: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 000000070C98: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070CA0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000070CA4: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 000000070CA8: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070CB0: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 000000070CB4: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 000000070CBC: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 000000070CC4: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070CD0: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 000000070CD4: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 000000070CDC: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 000000070CE8: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000070CF0: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 000000070CF4: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 000000070CFC: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000070D04: BF870292
	v_rcp_f32_e32 v140, v121                                   // 000000070D08: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 000000070D0C: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070D14: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 000000070D18: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 000000070D1C: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070D20: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 000000070D24: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 000000070D2C: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070D30: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 000000070D34: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 000000070D3C: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 000000070D44: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000070D48: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 000000070D4C: D627008C 03CB1D8C
	.long 0xd4440001                                           // 000000070D54: D4440001
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 000000070D58: 0202F20E
	s_and_saveexec_b32 s2, s1                                  // 000000070D5C: BE822001
	s_cbranch_execz 69                                         // 000000070D60: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2b78>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 000000070D64: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 000000070D70: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 000000070D74: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000070D7C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000070D80: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070D84: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000070D88: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000070D90: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000070D9C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000070DA0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000070DA4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000070DA8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000070DB0: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070DB8: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000070DBC: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000070DC0: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000070DC4: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070DC8: BF870095
	.long 0xd71c008e                                           // 000000070DCC: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000070DD0: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000070DD4: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000070DD8: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070DE0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000070DE4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000070DEC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070DF0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 000000070DF4: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000070DFC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070E00: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000070E04: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000070E0C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 000000070E10: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070E18: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000070E1C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000070E20: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070E28: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000070E2C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000070E30: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070E38: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000070E3C: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 000000070E44: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 000000070E4C: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070E58: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 000000070E5C: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 000000070E64: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 000000070E70: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 000000070E78: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 000000070E7C: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 000000070E80: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 000000070E88: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000070E90: BF870292
	v_rcp_f32_e32 v141, v122                                   // 000000070E94: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 000000070E98: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070EA0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000070EA4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000070EA8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070EAC: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 000000070EB0: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 000000070EB8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070EBC: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 000000070EC0: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 000000070EC8: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 000000070ED0: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000070ED4: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 000000070ED8: D6270089 03CB138D
	.long 0xd4440002                                           // 000000070EE0: D4440002
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 000000070EE4: 0202F40E
	s_and_saveexec_b32 s3, s2                                  // 000000070EE8: BE832002
	s_cbranch_execz 69                                         // 000000070EEC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2d04>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 000000070EF0: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 000000070EFC: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 000000070F00: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000070F08: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000070F0C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070F10: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000070F14: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000070F1C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000070F28: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000070F2C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000070F30: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000070F34: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000070F3C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070F44: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000070F48: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000070F4C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000070F50: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070F54: BF870095
	.long 0xd71c008e                                           // 000000070F58: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000070F5C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000070F60: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000070F64: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070F6C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000070F70: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000070F78: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070F7C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 000000070F80: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000070F88: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070F8C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000070F90: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000070F98: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 000000070F9C: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070FA4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000070FA8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000070FAC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070FB4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000070FB8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000070FBC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070FC4: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000070FC8: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 000000070FD0: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 000000070FD8: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070FE4: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 000000070FE8: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 000000070FF0: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 000000070FFC: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 000000071004: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 000000071008: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 000000071010: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000071018: BF870292
	v_rcp_f32_e32 v141, v123                                   // 00000007101C: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 000000071020: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071028: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000007102C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000071030: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071034: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 000000071038: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 000000071040: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071044: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 000000071048: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 000000071050: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 000000071058: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007105C: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 000000071060: D627008A 03CB158D
	.long 0xd4440003                                           // 000000071068: D4440003
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 00000007106C: 0202F60E
	s_and_saveexec_b32 s4, s3                                  // 000000071070: BE842003
	s_cbranch_execz 69                                         // 000000071074: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2e8c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 000000071078: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 000000071084: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 000000071088: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000071090: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000071094: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071098: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000007109C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000710A4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000710B0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000710B4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000710B8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000710BC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000710C4: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000710CC: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000710D0: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000710D4: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000710D8: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000710DC: BF870095
	.long 0xd71c008e                                           // 0000000710E0: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000710E4: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000710E8: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000710EC: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000710F4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000710F8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000071100: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071104: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 000000071108: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 000000071110: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071114: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000071118: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000071120: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 000000071124: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007112C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000071130: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000071134: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007113C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000071140: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000071144: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007114C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000071150: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 000000071158: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 000000071160: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007116C: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 000000071170: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 000000071178: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 000000071184: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007118C: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 000000071190: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 000000071194: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 00000007119C: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000711A4: BF870292
	v_rcp_f32_e32 v141, v124                                   // 0000000711A8: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 0000000711AC: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000711B4: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000711B8: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000711BC: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000711C0: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 0000000711C4: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 0000000711CC: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000711D0: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 0000000711D4: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 0000000711DC: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 0000000711E4: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000711E8: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 0000000711EC: D6270087 03CB0F8D
	.long 0xd4440004                                           // 0000000711F4: D4440004
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 0000000711F8: 0202F80E
	s_and_saveexec_b32 s5, s4                                  // 0000000711FC: BE852004
	s_cbranch_execz 69                                         // 000000071200: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3018>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 000000071204: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 000000071210: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 000000071214: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000007121C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000071220: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071224: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000071228: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000071230: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000007123C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000071240: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000071244: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000071248: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000071250: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000071258: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000007125C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000071260: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000071264: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071268: BF870095
	.long 0xd71c008e                                           // 00000007126C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000071270: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000071274: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000071278: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071280: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000071284: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000007128C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071290: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 000000071294: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 00000007129C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000712A0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000712A4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000712AC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 0000000712B0: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000712B8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000712BC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000712C0: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000712C8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000712CC: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000712D0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000712D8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000712DC: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 0000000712E4: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 0000000712EC: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000712F8: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 0000000712FC: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 000000071304: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 000000071310: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 000000071318: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 00000007131C: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 000000071324: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007132C: BF870292
	v_rcp_f32_e32 v141, v125                                   // 000000071330: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 000000071334: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007133C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000071340: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000071344: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071348: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 00000007134C: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 000000071354: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071358: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 00000007135C: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 000000071364: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 00000007136C: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000071370: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 000000071374: D6270088 03CB118D
	.long 0xd4440005                                           // 00000007137C: D4440005
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 000000071380: 0202FA0E
	s_and_saveexec_b32 s6, s5                                  // 000000071384: BE862005
	s_cbranch_execz 69                                         // 000000071388: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x31a0>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 00000007138C: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 000000071398: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 00000007139C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000713A4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000713A8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000713AC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000713B0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000713B8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000713C4: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000713C8: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000713CC: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000713D0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000713D8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000713E0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000713E4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000713E8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000713EC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000713F0: BF870095
	.long 0xd71c008e                                           // 0000000713F4: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000713F8: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000713FC: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000071400: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071408: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000007140C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000071414: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071418: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 00000007141C: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000071424: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071428: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000007142C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000071434: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 000000071438: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071440: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000071444: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000071448: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071450: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000071454: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000071458: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071460: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000071464: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 00000007146C: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 000000071474: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071480: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 000000071484: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 00000007148C: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 000000071498: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000714A0: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000714A4: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 0000000714A8: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 0000000714B0: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000714B8: BF870292
	v_rcp_f32_e32 v141, v126                                   // 0000000714BC: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 0000000714C0: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000714C8: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000714CC: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000714D0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000714D4: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 0000000714D8: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 0000000714E0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000714E4: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 0000000714E8: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 0000000714F0: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 0000000714F8: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000714FC: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 000000071500: D6270085 03CB0B8D
	.long 0xd4440006                                           // 000000071508: D4440006
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 00000007150C: 0202FC0E
	s_and_saveexec_b32 s7, s6                                  // 000000071510: BE872006
	s_cbranch_execz 69                                         // 000000071514: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x332c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 000000071518: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 000000071524: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 000000071528: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000071530: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000071534: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071538: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000007153C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000071544: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000071550: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000071554: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000071558: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000007155C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000071564: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007156C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000071570: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000071574: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000071578: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007157C: BF870095
	.long 0xd71c008e                                           // 000000071580: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000071584: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000071588: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000007158C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071594: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000071598: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000715A0: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000715A4: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 0000000715A8: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000715B0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000715B4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000715B8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000715C0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 0000000715C4: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000715CC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000715D0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000715D4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000715DC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000715E0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000715E4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000715EC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000715F0: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 0000000715F8: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 000000071600: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007160C: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 000000071610: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 000000071618: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 000000071624: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 00000007162C: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 000000071630: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 000000071638: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000071640: BF870292
	v_rcp_f32_e32 v141, v127                                   // 000000071644: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 000000071648: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071650: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000071654: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000071658: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007165C: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 000000071660: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 000000071668: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007166C: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 000000071670: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 000000071678: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 000000071680: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000071684: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 000000071688: D6270086 03CB0D8D
	.long 0xd4440007                                           // 000000071690: D4440007
	v_cndmask_b32_e32 v1, s14, v127, vcc_lo                    // 000000071694: 0202FE0E
	s_and_saveexec_b32 s8, s7                                  // 000000071698: BE882007
	s_cbranch_execnz 363                                       // 00000007169C: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x394c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000716A0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000716A4: BE882000
	s_cbranch_execnz 432                                       // 0000000716A8: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000716AC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000716B0: BE882001
	s_cbranch_execnz 501                                       // 0000000716B4: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000716B8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000716BC: BE882002
	s_cbranch_execnz 570                                       // 0000000716C0: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cac>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000716C4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000716C8: BE882003
	s_cbranch_execnz 639                                       // 0000000716CC: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dcc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000716D0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000716D4: BE882004
	s_cbranch_execnz 708                                       // 0000000716D8: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eec>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000716DC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000716E0: BE882005
	s_cbranch_execnz 777                                       // 0000000716E4: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x400c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000716E8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000716EC: BE882006
	s_cbranch_execnz 846                                       // 0000000716F0: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x412c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000716F4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000716F8: BE882007
	s_cbranch_execnz 915                                       // 0000000716FC: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x424c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071700: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000071704: BE882000
	s_cbranch_execnz 984                                       // 000000071708: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x436c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007170C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000071710: BE882001
	s_cbranch_execnz 1053                                      // 000000071714: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x448c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071718: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007171C: BE882002
	s_cbranch_execnz 1122                                      // 000000071720: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x45ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071724: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000071728: BE882003
	s_cbranch_execnz 1191                                      // 00000007172C: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x46cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071730: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000071734: BE882004
	s_cbranch_execnz 1260                                      // 000000071738: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x47ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007173C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000071740: BE882005
	s_cbranch_execnz 1329                                      // 000000071744: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x490c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071748: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007174C: BE882006
	s_cbranch_execnz 1398                                      // 000000071750: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4a2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071754: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000071758: BE882007
	s_cbranch_execnz 1467                                      // 00000007175C: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4b4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071760: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000071764: BE882000
	s_cbranch_execnz 1536                                      // 000000071768: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4c6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007176C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000071770: BE882001
	s_cbranch_execnz 1605                                      // 000000071774: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4d8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071778: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007177C: BE882002
	s_cbranch_execnz 1674                                      // 000000071780: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4eac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071784: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000071788: BE882003
	s_cbranch_execnz 1743                                      // 00000007178C: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4fcc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071790: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000071794: BE882004
	s_cbranch_execnz 1812                                      // 000000071798: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x50ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007179C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000717A0: BE882005
	s_cbranch_execnz 1881                                      // 0000000717A4: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x520c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000717A8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000717AC: BE882006
	s_cbranch_execnz 1950                                      // 0000000717B0: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x532c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000717B4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000717B8: BE882007
	s_cbranch_execnz 2019                                      // 0000000717BC: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x544c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000717C0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000717C4: BE882000
	s_cbranch_execnz 2088                                      // 0000000717C8: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x556c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000717CC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000717D0: BE882001
	s_cbranch_execnz 2157                                      // 0000000717D4: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x568c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000717D8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000717DC: BE882002
	s_cbranch_execnz 2226                                      // 0000000717E0: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x57ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000717E4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000717E8: BE882003
	s_cbranch_execnz 2295                                      // 0000000717EC: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x58cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000717F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000717F4: BE882004
	s_cbranch_execnz 2364                                      // 0000000717F8: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x59ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000717FC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000071800: BE882005
	s_cbranch_execnz 2433                                      // 000000071804: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5b0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071808: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007180C: BE882006
	s_cbranch_execnz 2502                                      // 000000071810: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5c2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071814: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000071818: BE882007
	s_cbranch_execnz 2571                                      // 00000007181C: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5d4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071820: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000071824: BE882000
	s_cbranch_execnz 2640                                      // 000000071828: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5e6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007182C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000071830: BE882001
	s_cbranch_execnz 2709                                      // 000000071834: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5f8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071838: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007183C: BE882002
	s_cbranch_execnz 2778                                      // 000000071840: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x60ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071844: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000071848: BE882003
	s_cbranch_execnz 2847                                      // 00000007184C: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x61cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071850: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000071854: BE882004
	s_cbranch_execnz 2916                                      // 000000071858: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x62ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007185C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000071860: BE882005
	s_cbranch_execnz 2985                                      // 000000071864: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x640c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071868: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007186C: BE882006
	s_cbranch_execnz 3054                                      // 000000071870: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x652c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071874: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000071878: BE882007
	s_cbranch_execnz 3123                                      // 00000007187C: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x664c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071880: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000071884: BE882000
	s_cbranch_execnz 3192                                      // 000000071888: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x676c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007188C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000071890: BE882001
	s_cbranch_execnz 3261                                      // 000000071894: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x688c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071898: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007189C: BE882002
	s_cbranch_execnz 3330                                      // 0000000718A0: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x69ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000718A4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000718A8: BE882003
	s_cbranch_execnz 3399                                      // 0000000718AC: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6acc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000718B0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000718B4: BE882004
	s_cbranch_execnz 3468                                      // 0000000718B8: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6bec>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000718BC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000718C0: BE882005
	s_cbranch_execnz 3537                                      // 0000000718C4: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6d0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000718C8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000718CC: BE882006
	s_cbranch_execnz 3606                                      // 0000000718D0: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6e2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000718D4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000718D8: BE882007
	s_cbranch_execnz 3675                                      // 0000000718DC: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6f4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000718E0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000718E4: BE882000
	s_cbranch_execnz 3744                                      // 0000000718E8: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x706c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000718EC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000718F0: BE882001
	s_cbranch_execnz 3813                                      // 0000000718F4: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x718c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000718F8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000718FC: BE882002
	s_cbranch_execnz 3882                                      // 000000071900: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x72ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071904: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000071908: BE882003
	s_cbranch_execnz 3951                                      // 00000007190C: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x73cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071910: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000071914: BE882004
	s_cbranch_execnz 4020                                      // 000000071918: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x74ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007191C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000071920: BE882005
	s_cbranch_execnz 4089                                      // 000000071924: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x760c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071928: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007192C: BE882006
	s_cbranch_execnz 4158                                      // 000000071930: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x772c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071934: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000071938: BE882007
	s_cbranch_execnz 4227                                      // 00000007193C: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x784c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071940: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000071944: BE882000
	s_cbranch_execnz 4296                                      // 000000071948: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x796c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007194C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000071950: BE882001
	s_cbranch_execnz 4365                                      // 000000071954: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7a8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071958: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007195C: BE882002
	s_cbranch_execnz 4434                                      // 000000071960: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7bac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071964: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000071968: BE882003
	s_cbranch_execnz 4503                                      // 00000007196C: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7ccc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071970: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000071974: BE882004
	s_cbranch_execnz 4572                                      // 000000071978: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7dec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007197C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000071980: BE882005
	s_cbranch_execnz 4641                                      // 000000071984: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7f0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071988: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007198C: BE882006
	s_cbranch_execnz 4710                                      // 000000071990: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x802c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071994: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000071998: BE882007
	s_cbranch_execnz 4779                                      // 00000007199C: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x814c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000719A0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000719A4: BE882000
	s_cbranch_execnz 4848                                      // 0000000719A8: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x826c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000719AC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000719B0: BE882001
	s_cbranch_execnz 4917                                      // 0000000719B4: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x838c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000719B8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000719BC: BE882002
	s_cbranch_execnz 4986                                      // 0000000719C0: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x84ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000719C4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000719C8: BE882003
	s_cbranch_execnz 5055                                      // 0000000719CC: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x85cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000719D0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000719D4: BE882004
	s_cbranch_execnz 5124                                      // 0000000719D8: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x86ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000719DC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000719E0: BE882005
	s_cbranch_execnz 5193                                      // 0000000719E4: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x880c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000719E8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000719EC: BE882006
	s_cbranch_execnz 5262                                      // 0000000719F0: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x892c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000719F4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000719F8: BE882007
	s_cbranch_execnz 5331                                      // 0000000719FC: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8a4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071A00: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000071A04: BE882000
	s_cbranch_execnz 5400                                      // 000000071A08: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071A0C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000071A10: BE882001
	s_cbranch_execnz 5469                                      // 000000071A14: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8c8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071A18: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000071A1C: BE882002
	s_cbranch_execnz 5538                                      // 000000071A20: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8dac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071A24: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000071A28: BE882003
	s_cbranch_execnz 5607                                      // 000000071A2C: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8ecc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071A30: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000071A34: BE882004
	s_cbranch_execnz 5676                                      // 000000071A38: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8fec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071A3C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000071A40: BE882005
	s_cbranch_execnz 5745                                      // 000000071A44: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x910c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071A48: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000071A4C: BE882006
	s_cbranch_execnz 5814                                      // 000000071A50: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x922c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071A54: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000071A58: BE882007
	s_cbranch_execnz 5883                                      // 000000071A5C: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x934c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071A60: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000071A64: BE882000
	s_cbranch_execnz 5952                                      // 000000071A68: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x946c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071A6C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000071A70: BE882001
	s_cbranch_execnz 6021                                      // 000000071A74: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x958c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071A78: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000071A7C: BE882002
	s_cbranch_execnz 6090                                      // 000000071A80: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x96ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071A84: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000071A88: BE882003
	s_cbranch_execnz 6159                                      // 000000071A8C: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x97cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071A90: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000071A94: BE882004
	s_cbranch_execnz 6228                                      // 000000071A98: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x98ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071A9C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000071AA0: BE882005
	s_cbranch_execnz 6297                                      // 000000071AA4: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9a0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071AA8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000071AAC: BE882006
	s_cbranch_execnz 6366                                      // 000000071AB0: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9b2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071AB4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000071AB8: BE882007
	s_cbranch_execnz 6435                                      // 000000071ABC: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071AC0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000071AC4: BE882000
	s_cbranch_execnz 6504                                      // 000000071AC8: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9d6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071ACC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000071AD0: BE882001
	s_cbranch_execnz 6573                                      // 000000071AD4: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9e8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071AD8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000071ADC: BE882002
	s_cbranch_execnz 6642                                      // 000000071AE0: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9fac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071AE4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000071AE8: BE882003
	s_cbranch_execnz 6711                                      // 000000071AEC: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa0cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071AF0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000071AF4: BE882004
	s_cbranch_execnz 6780                                      // 000000071AF8: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa1ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071AFC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000071B00: BE882005
	s_cbranch_execnz 6849                                      // 000000071B04: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa30c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071B08: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000071B0C: BE882006
	s_cbranch_execnz 6918                                      // 000000071B10: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa42c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071B14: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000071B18: BE882007
	s_cbranch_execnz 6987                                      // 000000071B1C: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa54c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071B20: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000071B24: BE882000
	s_cbranch_execnz 7056                                      // 000000071B28: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa66c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071B2C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000071B30: BE882001
	s_cbranch_execnz 7125                                      // 000000071B34: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa78c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071B38: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000071B3C: BE882002
	s_cbranch_execnz 7194                                      // 000000071B40: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa8ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071B44: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000071B48: BE882003
	s_cbranch_execnz 7263                                      // 000000071B4C: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa9cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071B50: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000071B54: BE882004
	s_cbranch_execnz 7332                                      // 000000071B58: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaaec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071B5C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000071B60: BE882005
	s_cbranch_execnz 7401                                      // 000000071B64: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071B68: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000071B6C: BE882006
	s_cbranch_execnz 7470                                      // 000000071B70: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xad2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071B74: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000071B78: BE882007
	s_cbranch_execnz 7539                                      // 000000071B7C: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xae4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071B80: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000071B84: BE882000
	s_cbranch_execnz 7608                                      // 000000071B88: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaf6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071B8C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000071B90: BE882001
	s_cbranch_execnz 7677                                      // 000000071B94: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb08c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071B98: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000071B9C: BE882002
	s_cbranch_execnz 7746                                      // 000000071BA0: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb1ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071BA4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000071BA8: BE882003
	s_cbranch_execnz 7815                                      // 000000071BAC: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb2cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071BB0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000071BB4: BE882004
	s_cbranch_execnz 7884                                      // 000000071BB8: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb3ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071BBC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000071BC0: BE882005
	s_cbranch_execnz 7953                                      // 000000071BC4: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb50c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071BC8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000071BCC: BE882006
	s_cbranch_execnz 8022                                      // 000000071BD0: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb62c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071BD4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000071BD8: BE882007
	s_cbranch_execnz 8091                                      // 000000071BDC: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb74c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071BE0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000071BE4: BE882000
	s_cbranch_execnz 8160                                      // 000000071BE8: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb86c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071BEC: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000071BF0: BE802001
	s_cbranch_execnz 8229                                      // 000000071BF4: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb98c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000071BF8: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 000000071BFC: BE802002
	s_cbranch_execnz 8298                                      // 000000071C00: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbaac>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000071C04: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 000000071C08: BE802003
	s_cbranch_execnz 8367                                      // 000000071C0C: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbbcc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000071C10: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000071C14: BE802004
	s_cbranch_execnz 8436                                      // 000000071C18: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbcec>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000071C1C: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000071C20: BE802005
	s_cbranch_execnz 8505                                      // 000000071C24: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbe0c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000071C28: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000071C2C: BE802006
	s_cbranch_execnz 8574                                      // 000000071C30: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbf2c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000071C34: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000071C38: BE802007
	s_cbranch_execnz 8643                                      // 000000071C3C: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc04c>
	s_nop 0                                                    // 000000071C40: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000071C44: BFB60003
	s_endpgm                                                   // 000000071C48: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 000000071C4C: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 000000071C58: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 000000071C5C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000071C64: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000071C68: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071C6C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000071C70: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000071C78: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000071C84: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000071C88: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000071C8C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000071C90: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000071C98: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000071CA0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000071CA4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000071CA8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000071CAC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071CB0: BF870095
	.long 0xd71c008e                                           // 000000071CB4: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000071CB8: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000071CBC: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000071CC0: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071CC8: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000071CCC: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000071CD4: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071CD8: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 000000071CDC: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 000000071CE4: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071CE8: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000071CEC: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000071CF4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 000000071CF8: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071D00: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000071D04: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000071D08: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071D10: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000071D14: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000071D18: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071D20: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000071D24: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 000000071D2C: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 000000071D34: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071D40: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 000000071D44: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 000000071D4C: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 000000071D58: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071D60: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000071D64: BE882000
	s_cbranch_execz 65104                                      // 000000071D68: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33ac>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 000000071D6C: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 000000071D78: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 000000071D7C: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 000000071D84: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 000000071D88: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071D8C: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 000000071D90: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 000000071D98: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 000000071DA4: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000071DA8: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 000000071DAC: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 000000071DB0: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 000000071DB8: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000071DC0: BF870121
	v_add_f32_e32 v141, v141, v142                             // 000000071DC4: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 000000071DC8: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 000000071DCC: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071DD0: BF870095
	.long 0xd71c008d                                           // 000000071DD4: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 000000071DD8: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 000000071DDC: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 000000071DE0: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071DE8: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 000000071DEC: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 000000071DF4: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071DF8: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 000000071DFC: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 000000071E04: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071E08: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 000000071E0C: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 000000071E14: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 000000071E18: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071E20: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 000000071E24: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 000000071E28: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071E30: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 000000071E34: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 000000071E38: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071E40: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 000000071E44: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 000000071E4C: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 000000071E54: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071E60: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 000000071E64: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 000000071E6C: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 000000071E78: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071E80: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000071E84: BE882001
	s_cbranch_execz 65035                                      // 000000071E88: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33b8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 000000071E8C: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 000000071E98: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 000000071E9C: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 000000071EA4: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000071EA8: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071EAC: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 000000071EB0: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 000000071EB8: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 000000071EC4: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000071EC8: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 000000071ECC: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000071ED0: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 000000071ED8: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000071EE0: BF870121
	v_add_f32_e32 v128, v128, v141                             // 000000071EE4: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 000000071EE8: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 000000071EEC: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071EF0: BF870095
	.long 0xd71c0080                                           // 000000071EF4: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 000000071EF8: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 000000071EFC: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000071F00: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071F08: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 000000071F0C: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000071F14: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071F18: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 000000071F1C: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 000000071F24: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071F28: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 000000071F2C: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 000000071F34: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 000000071F38: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071F40: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 000000071F44: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 000000071F48: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071F50: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 000000071F54: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 000000071F58: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071F60: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 000000071F64: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 000000071F6C: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 000000071F74: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071F80: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 000000071F84: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 000000071F8C: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 000000071F98: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 000000071FA0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000071FA4: BE882002
	s_cbranch_execz 64966                                      // 000000071FA8: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33c4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 000000071FAC: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000071FB8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000071FC0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000071FC4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071FC8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000071FCC: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 000000071FD4: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 000000071FE0: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000071FE4: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 000000071FE8: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 000000071FF0: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000071FF4: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 000000071FF8: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 000000071FFC: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000072000: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 000000072008: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007200C: BF870095
	.long 0xd71c0072                                           // 000000072010: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 000000072014: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000072018: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000007201C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072024: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 000000072028: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000072034: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072038: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000007203C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 000000072044: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072048: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 00000007204C: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 000000072054: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 000000072058: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072060: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 000000072064: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 000000072068: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072070: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 000000072074: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 000000072078: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072080: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 000000072084: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000007208C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 000000072094: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000720A0: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 0000000720A4: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 0000000720AC: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000720B8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000720C0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000720C4: BE882003
	s_cbranch_execz 64897                                      // 0000000720C8: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33d0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 0000000720CC: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000720D8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000720E0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000720E4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000720E8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000720EC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000720F4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 000000072100: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000072104: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 000000072108: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000007210C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000072114: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007211C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000072120: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 000000072124: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 000000072128: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007212C: BF870095
	.long 0xd71c0072                                           // 000000072130: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000072134: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000072138: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000007213C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072144: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 000000072148: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000072154: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072158: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000007215C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000072164: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072168: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 00000007216C: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 000000072174: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 000000072178: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072180: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 000000072184: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 000000072188: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072190: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 000000072194: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 000000072198: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000721A0: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 0000000721A4: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000721AC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 0000000721B4: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000721C0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000721C4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000721CC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000721D8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000721E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000721E4: BE882004
	s_cbranch_execz 64828                                      // 0000000721E8: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33dc>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 0000000721EC: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000721F8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000072200: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000072204: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072208: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000007220C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000072214: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000072220: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000072224: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000072228: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000007222C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000072234: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007223C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000072240: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000072244: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000072248: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007224C: BF870095
	.long 0xd71c0072                                           // 000000072250: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000072254: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000072258: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000007225C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072264: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 000000072268: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000072274: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072278: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000007227C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000072284: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072288: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000007228C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 000000072294: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 000000072298: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000722A0: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 0000000722A4: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 0000000722A8: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000722B0: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 0000000722B4: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 0000000722B8: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000722C0: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 0000000722C4: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000722CC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 0000000722D4: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000722E0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000722E4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000722EC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000722F8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000072300: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000072304: BE882005
	s_cbranch_execz 64759                                      // 000000072308: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33e8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 00000007230C: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000072318: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000072320: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000072324: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072328: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000007232C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000072334: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000072340: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000072344: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000072348: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000007234C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000072354: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007235C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000072360: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000072364: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000072368: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007236C: BF870095
	.long 0xd71c0072                                           // 000000072370: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000072374: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000072378: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000007237C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072384: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 000000072388: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 000000072390: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072398: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000007239C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000723A4: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000723A8: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000723AC: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000723B4: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000723B8: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000723C0: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000723C4: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 0000000723C8: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000723D0: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 0000000723D4: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 0000000723D8: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000723E0: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000723E4: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000723EC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 0000000723F4: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072400: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000072404: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000007240C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000072418: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000072420: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000072424: BE882006
	s_cbranch_execz 64690                                      // 000000072428: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33f4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 00000007242C: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000072438: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000072440: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000072444: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072448: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000007244C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000072454: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000072460: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000072464: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000072468: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000007246C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000072474: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007247C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000072480: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000072484: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000072488: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007248C: BF870095
	.long 0xd71c0072                                           // 000000072490: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000072494: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000072498: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000007249C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000724A4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 0000000724A8: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000724B4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000724B8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000724BC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000724C4: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000724C8: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000724CC: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000724D4: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000724D8: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000724E0: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000724E4: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000724E8: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000724F0: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000724F4: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000724F8: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072500: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 000000072504: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000007250C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 000000072514: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072520: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000072524: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000007252C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000072538: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000072540: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000072544: BE882007
	s_cbranch_execz 64621                                      // 000000072548: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3400>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 00000007254C: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000072558: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000072560: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000072564: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072568: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000007256C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000072574: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000072580: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000072584: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000072588: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000007258C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000072594: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007259C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000725A0: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000725A4: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000725A8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000725AC: BF870095
	.long 0xd71c0072                                           // 0000000725B0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000725B4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000725B8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000725BC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000725C4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 0000000725C8: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000725D4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000725D8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000725DC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000725E4: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000725E8: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000725EC: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000725F4: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000725F8: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072600: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 000000072604: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 000000072608: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072610: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 000000072614: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 000000072618: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072620: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 000000072624: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000007262C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 000000072634: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072640: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000072644: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000007264C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000072658: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000072660: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000072664: BE882000
	s_cbranch_execz 64552                                      // 000000072668: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x340c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 00000007266C: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 000000072678: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 00000007267C: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 000000072684: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000072688: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007268C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000072690: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000072698: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000726A4: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000726A8: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000726AC: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000726B0: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000726B8: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000726C0: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000726C4: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000726C8: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000726CC: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000726D0: BF870095
	.long 0xd71c0072                                           // 0000000726D4: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000726D8: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000726DC: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000726E0: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000726E8: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000726EC: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000726F4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000726F8: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 0000000726FC: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 000000072704: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072708: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 00000007270C: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 000000072714: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 000000072718: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072720: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 000000072724: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 000000072728: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072730: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 000000072734: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 000000072738: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072740: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 000000072744: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 00000007274C: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 000000072754: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072760: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 000000072764: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 00000007276C: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 000000072778: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 000000072780: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000072784: BE882001
	s_cbranch_execz 64483                                      // 000000072788: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3418>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 00000007278C: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 000000072798: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 00000007279C: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 0000000727A4: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000727A8: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000727AC: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 0000000727B0: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000727B8: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 0000000727C0: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000000727CC: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000727D0: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 0000000727D4: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 0000000727DC: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000727E0: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000000727E4: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000000727E8: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000000727EC: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000727F0: BF870095
	.long 0xd71c0071                                           // 0000000727F4: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000000727F8: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000727FC: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000072800: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072808: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 00000007280C: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000072814: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072818: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 00000007281C: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 000000072824: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072828: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 00000007282C: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 000000072834: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 000000072838: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072840: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 000000072844: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 000000072848: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072850: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 000000072854: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 000000072858: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072860: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 000000072864: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 00000007286C: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 000000072874: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072880: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 000000072884: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 00000007288C: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 000000072898: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000728A0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000728A4: BE882002
	s_cbranch_execz 64414                                      // 0000000728A8: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3424>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 0000000728AC: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000728B8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000728C0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000728C4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000728C8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000728CC: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 0000000728D4: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 0000000728E0: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000728E4: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 0000000728E8: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000728EC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 0000000728F4: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000728FC: BF870121
	v_add_f32_e32 v106, v106, v113                             // 000000072900: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 000000072904: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 000000072908: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007290C: BF870095
	.long 0xd71c006a                                           // 000000072910: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 000000072914: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000072918: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000007291C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072924: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 000000072928: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000072934: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072938: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000007293C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 000000072944: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072948: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 00000007294C: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 000000072954: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 000000072958: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072960: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 000000072964: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 000000072968: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072970: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 000000072974: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 000000072978: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072980: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 000000072984: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000007298C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 000000072994: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000729A0: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 0000000729A4: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 0000000729AC: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000729B8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000729C0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000729C4: BE882003
	s_cbranch_execz 64345                                      // 0000000729C8: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3430>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 0000000729CC: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000729D8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000729E0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000729E4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000729E8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000729EC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000729F4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 000000072A00: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072A04: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 000000072A08: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 000000072A14: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 000000072A18: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000072A1C: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000072A24: BF870293
	v_exp_f32_e32 v106, v106                                   // 000000072A28: 7ED44B6A
	.long 0xd71c006a                                           // 000000072A2C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000072A30: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000072A34: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000072A38: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000072A3C: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 000000072A44: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072A50: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 000000072A54: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000072A58: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000072A60: BF870291
	v_rcp_f32_e32 v108, v107                                   // 000000072A64: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 000000072A68: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000072A70: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 000000072A74: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 000000072A78: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 000000072A80: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072A84: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 000000072A88: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 000000072A90: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072A94: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 000000072A98: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 000000072AA0: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000072AA8: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000072AAC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 000000072AB4: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 000000072AC0: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000072AC8: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000072ACC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000072AD8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000072AE0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000072AE4: BE882004
	s_cbranch_execz 64276                                      // 000000072AE8: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x343c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 000000072AEC: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000072AF8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000072B00: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000072B04: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072B08: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000072B0C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000072B14: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000072B20: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000072B24: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000072B28: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000072B2C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000072B34: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000072B3C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000072B40: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000072B44: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000072B48: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072B4C: BF870095
	.long 0xd71c006a                                           // 000000072B50: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000072B54: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000072B58: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000072B5C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072B64: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 000000072B68: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000072B74: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072B78: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000072B7C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000072B84: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072B88: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000072B8C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000072B94: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000072B98: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072BA0: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 000000072BA4: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 000000072BA8: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072BB0: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 000000072BB4: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 000000072BB8: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072BC0: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 000000072BC4: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000072BCC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 000000072BD4: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072BE0: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000072BE4: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000072BEC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000072BF8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000072C00: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000072C04: BE882005
	s_cbranch_execz 64207                                      // 000000072C08: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3448>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 000000072C0C: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000072C18: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000072C20: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000072C24: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072C28: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000072C2C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000072C34: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000072C40: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000072C44: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000072C48: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000072C4C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000072C54: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000072C5C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000072C60: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000072C64: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000072C68: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072C6C: BF870095
	.long 0xd71c006a                                           // 000000072C70: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000072C74: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000072C78: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000072C7C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072C84: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 000000072C88: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 000000072C90: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072C98: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000072C9C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000072CA4: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072CA8: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000072CAC: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000072CB4: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000072CB8: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072CC0: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000072CC4: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 000000072CC8: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072CD0: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 000000072CD4: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 000000072CD8: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072CE0: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000072CE4: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000072CEC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 000000072CF4: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072D00: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000072D04: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000072D0C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000072D18: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000072D20: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000072D24: BE882006
	s_cbranch_execz 64138                                      // 000000072D28: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3454>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 000000072D2C: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000072D38: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000072D40: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000072D44: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072D48: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000072D4C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000072D54: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000072D60: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000072D64: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000072D68: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000072D6C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000072D74: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000072D7C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000072D80: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000072D84: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000072D88: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072D8C: BF870095
	.long 0xd71c006a                                           // 000000072D90: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000072D94: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000072D98: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000072D9C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072DA4: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 000000072DA8: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000072DB4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072DB8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000072DBC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000072DC4: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072DC8: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000072DCC: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000072DD4: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000072DD8: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072DE0: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000072DE4: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 000000072DE8: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072DF0: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 000000072DF4: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 000000072DF8: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072E00: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000072E04: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000072E0C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 000000072E14: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072E20: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000072E24: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000072E2C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000072E38: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000072E40: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000072E44: BE882007
	s_cbranch_execz 64069                                      // 000000072E48: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3460>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 000000072E4C: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000072E58: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000072E60: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000072E64: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072E68: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000072E6C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000072E74: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000072E80: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000072E84: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000072E88: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000072E8C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000072E94: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000072E9C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000072EA0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000072EA4: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000072EA8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072EAC: BF870095
	.long 0xd71c006a                                           // 000000072EB0: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000072EB4: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000072EB8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000072EBC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072EC4: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 000000072EC8: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000072ED4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072ED8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000072EDC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000072EE4: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072EE8: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000072EEC: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000072EF4: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000072EF8: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072F00: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000072F04: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 000000072F08: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072F10: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 000000072F14: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 000000072F18: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072F20: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000072F24: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000072F2C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 000000072F34: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072F40: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000072F44: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000072F4C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000072F58: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000072F60: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000072F64: BE882000
	s_cbranch_execz 64000                                      // 000000072F68: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x346c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 000000072F6C: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 000000072F78: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 000000072F7C: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 000000072F84: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000072F88: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072F8C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000072F90: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000072F98: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000072FA4: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000072FA8: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000072FAC: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000072FB0: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000072FB8: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000072FC0: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000072FC4: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000072FC8: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000072FCC: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072FD0: BF870095
	.long 0xd71c006a                                           // 000000072FD4: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000072FD8: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000072FDC: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000072FE0: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072FE8: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 000000072FEC: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000072FF4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000072FF8: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 000000072FFC: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 000000073004: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073008: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 00000007300C: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 000000073014: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 000000073018: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073020: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 000000073024: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 000000073028: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073030: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 000000073034: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 000000073038: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073040: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 000000073044: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 00000007304C: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 000000073054: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073060: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 000000073064: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 00000007306C: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 000000073078: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 000000073080: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000073084: BE882001
	s_cbranch_execz 63931                                      // 000000073088: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3478>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 00000007308C: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 000000073098: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 00000007309C: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 0000000730A4: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000730A8: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000730AC: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 0000000730B0: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000730B8: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 0000000730C0: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000000730CC: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000730D0: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 0000000730D4: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 0000000730DC: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000730E0: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000000730E4: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000000730E8: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000000730EC: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000730F0: BF870095
	.long 0xd71c0069                                           // 0000000730F4: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000000730F8: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000000730FC: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000073100: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073108: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 00000007310C: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000073114: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073118: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 00000007311C: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 000000073124: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073128: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 00000007312C: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 000000073134: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 000000073138: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073140: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 000000073144: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 000000073148: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073150: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 000000073154: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 000000073158: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073160: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 000000073164: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 00000007316C: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 000000073174: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073180: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 000000073184: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 00000007318C: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 000000073198: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000731A0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000731A4: BE882002
	s_cbranch_execz 63862                                      // 0000000731A8: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3484>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 0000000731AC: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000731B8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000731C0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000731C4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000731C8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000731CC: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 0000000731D4: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 0000000731E0: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000731E4: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 0000000731E8: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000731EC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 0000000731F4: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000731FC: BF870121
	v_add_f32_e32 v98, v98, v105                               // 000000073200: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 000000073204: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 000000073208: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007320C: BF870095
	.long 0xd71c0062                                           // 000000073210: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 000000073214: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000073218: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000007321C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073224: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 000000073228: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000073234: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073238: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000007323C: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 000000073244: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073248: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 00000007324C: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 000000073254: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 000000073258: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073260: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 000000073264: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 000000073268: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073270: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 000000073274: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 000000073278: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073280: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 000000073284: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000007328C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 000000073294: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000732A0: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 0000000732A4: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 0000000732AC: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000732B8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000732C0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000732C4: BE882003
	s_cbranch_execz 63793                                      // 0000000732C8: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3490>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 0000000732CC: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000732D8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000732E0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000732E4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000732E8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000732EC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000732F4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 000000073300: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073304: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 000000073308: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 000000073314: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 000000073318: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000007331C: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000073324: BF870293
	v_exp_f32_e32 v98, v98                                     // 000000073328: 7EC44B62
	.long 0xd71c0062                                           // 00000007332C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000073330: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000073334: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000073338: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000007333C: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 000000073344: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073350: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 000000073354: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000073358: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000073360: BF870291
	v_rcp_f32_e32 v100, v99                                    // 000000073364: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 000000073368: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000073370: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 000000073374: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 000000073378: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 000000073380: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073384: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 000000073388: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 000000073390: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073394: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 000000073398: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 0000000733A0: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000733A8: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000733AC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 0000000733B4: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000733C0: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000733C8: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000733CC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000733D8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000733E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000733E4: BE882004
	s_cbranch_execz 63724                                      // 0000000733E8: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x349c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 0000000733EC: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000733F8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000073400: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000073404: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073408: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000007340C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000073414: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000073420: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000073424: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000073428: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000007342C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000073434: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007343C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000073440: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000073444: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000073448: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007344C: BF870095
	.long 0xd71c0062                                           // 000000073450: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000073454: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000073458: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000007345C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073464: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 000000073468: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000073474: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073478: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000007347C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000073484: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073488: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000007348C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000073494: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000073498: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000734A0: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 0000000734A4: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 0000000734A8: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000734B0: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 0000000734B4: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 0000000734B8: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000734C0: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 0000000734C4: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000734CC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 0000000734D4: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000734E0: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000734E4: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000734EC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000734F8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000073500: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000073504: BE882005
	s_cbranch_execz 63655                                      // 000000073508: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34a8>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 00000007350C: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000073518: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000073520: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000073524: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073528: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000007352C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000073534: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000073540: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000073544: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000073548: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000007354C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000073554: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007355C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000073560: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000073564: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000073568: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007356C: BF870095
	.long 0xd71c0062                                           // 000000073570: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000073574: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000073578: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000007357C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073584: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 000000073588: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 000000073590: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073598: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000007359C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000735A4: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000735A8: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000735AC: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000735B4: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000735B8: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000735C0: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000735C4: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 0000000735C8: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000735D0: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 0000000735D4: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 0000000735D8: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000735E0: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000735E4: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000735EC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 0000000735F4: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073600: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000073604: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000007360C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000073618: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000073620: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000073624: BE882006
	s_cbranch_execz 63586                                      // 000000073628: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34b4>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 00000007362C: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000073638: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000073640: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000073644: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073648: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000007364C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000073654: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000073660: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000073664: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000073668: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000007366C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000073674: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007367C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000073680: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000073684: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000073688: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007368C: BF870095
	.long 0xd71c0062                                           // 000000073690: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000073694: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000073698: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000007369C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000736A4: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 0000000736A8: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000736B4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000736B8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000736BC: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000736C4: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000736C8: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000736CC: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000736D4: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000736D8: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000736E0: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000736E4: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000736E8: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000736F0: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000736F4: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000736F8: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073700: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 000000073704: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000007370C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 000000073714: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073720: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000073724: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000007372C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000073738: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000073740: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000073744: BE882007
	s_cbranch_execz 63517                                      // 000000073748: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34c0>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 00000007374C: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000073758: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000073760: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000073764: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073768: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000007376C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000073774: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000073780: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000073784: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000073788: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000007378C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000073794: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007379C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000737A0: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000737A4: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000737A8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000737AC: BF870095
	.long 0xd71c0062                                           // 0000000737B0: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000737B4: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000737B8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000737BC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000737C4: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 0000000737C8: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000737D4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000737D8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000737DC: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000737E4: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000737E8: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000737EC: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000737F4: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000737F8: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073800: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 000000073804: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 000000073808: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073810: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 000000073814: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 000000073818: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073820: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 000000073824: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000007382C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 000000073834: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073840: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000073844: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000007384C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000073858: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000073860: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000073864: BE882000
	s_cbranch_execz 63448                                      // 000000073868: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34cc>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 00000007386C: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 000000073878: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 00000007387C: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 000000073884: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000073888: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007388C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000073890: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000073898: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000738A4: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000738A8: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000738AC: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000738B0: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000738B8: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000738C0: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000738C4: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000738C8: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000738CC: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000738D0: BF870095
	.long 0xd71c0062                                           // 0000000738D4: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000738D8: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000738DC: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000738E0: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000738E8: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000738EC: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000738F4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000738F8: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 0000000738FC: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 000000073904: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073908: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 00000007390C: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 000000073914: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 000000073918: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073920: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 000000073924: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 000000073928: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073930: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 000000073934: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 000000073938: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073940: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 000000073944: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 00000007394C: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 000000073954: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073960: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 000000073964: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 00000007396C: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 000000073978: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 000000073980: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000073984: BE882001
	s_cbranch_execz 63379                                      // 000000073988: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34d8>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 00000007398C: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 000000073998: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 00000007399C: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 0000000739A4: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000739A8: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000739AC: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 0000000739B0: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000739B8: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 0000000739C0: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000000739CC: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000739D0: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 0000000739D4: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 0000000739DC: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000739E0: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000000739E4: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000000739E8: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000000739EC: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000739F0: BF870095
	.long 0xd71c0061                                           // 0000000739F4: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000000739F8: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000739FC: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000073A00: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073A08: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 000000073A0C: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000073A14: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073A18: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 000000073A1C: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 000000073A24: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073A28: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 000000073A2C: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 000000073A34: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 000000073A38: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073A40: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 000000073A44: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 000000073A48: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073A50: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 000000073A54: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 000000073A58: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073A60: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 000000073A64: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 000000073A6C: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 000000073A74: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073A80: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 000000073A84: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 000000073A8C: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 000000073A98: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 000000073AA0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000073AA4: BE882002
	s_cbranch_execz 63310                                      // 000000073AA8: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34e4>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 000000073AAC: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000073AB8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000073AC0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000073AC4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073AC8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000073ACC: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 000000073AD4: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 000000073AE0: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000073AE4: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 000000073AE8: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000073AEC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 000000073AF4: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000073AFC: BF870121
	v_add_f32_e32 v90, v90, v97                                // 000000073B00: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 000000073B04: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 000000073B08: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073B0C: BF870095
	.long 0xd71c005a                                           // 000000073B10: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 000000073B14: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000073B18: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000073B1C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073B24: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 000000073B28: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000073B34: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073B38: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000073B3C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 000000073B44: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073B48: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 000000073B4C: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 000000073B54: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 000000073B58: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073B60: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 000000073B64: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 000000073B68: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073B70: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 000000073B74: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 000000073B78: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073B80: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 000000073B84: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000073B8C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 000000073B94: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073BA0: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 000000073BA4: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 000000073BAC: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000073BB8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000073BC0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000073BC4: BE882003
	s_cbranch_execz 63241                                      // 000000073BC8: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34f0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 000000073BCC: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000073BD8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000073BE0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000073BE4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073BE8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000073BEC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000073BF4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 000000073C00: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073C04: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 000000073C08: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 000000073C14: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 000000073C18: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000073C1C: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000073C24: BF870293
	v_exp_f32_e32 v90, v90                                     // 000000073C28: 7EB44B5A
	.long 0xd71c005a                                           // 000000073C2C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000073C30: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000073C34: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000073C38: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000073C3C: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 000000073C44: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073C50: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 000000073C54: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000073C58: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000073C60: BF870291
	v_rcp_f32_e32 v92, v91                                     // 000000073C64: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 000000073C68: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000073C70: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 000000073C74: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 000000073C78: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 000000073C80: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073C84: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 000000073C88: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 000000073C90: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073C94: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 000000073C98: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 000000073CA0: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000073CA8: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000073CAC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 000000073CB4: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 000000073CC0: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000073CC8: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000073CCC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000073CD8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000073CE0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000073CE4: BE882004
	s_cbranch_execz 63172                                      // 000000073CE8: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34fc>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 000000073CEC: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000073CF8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000073D00: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000073D04: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073D08: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000073D0C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000073D14: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000073D20: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000073D24: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000073D28: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000073D2C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000073D34: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000073D3C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000073D40: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000073D44: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000073D48: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073D4C: BF870095
	.long 0xd71c005a                                           // 000000073D50: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000073D54: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000073D58: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000073D5C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073D64: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 000000073D68: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000073D74: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073D78: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000073D7C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000073D84: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073D88: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000073D8C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000073D94: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000073D98: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073DA0: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 000000073DA4: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 000000073DA8: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073DB0: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 000000073DB4: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 000000073DB8: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073DC0: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 000000073DC4: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000073DCC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 000000073DD4: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073DE0: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000073DE4: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000073DEC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000073DF8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000073E00: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000073E04: BE882005
	s_cbranch_execz 63103                                      // 000000073E08: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3508>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 000000073E0C: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000073E18: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000073E20: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000073E24: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073E28: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000073E2C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000073E34: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000073E40: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000073E44: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000073E48: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000073E4C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000073E54: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000073E5C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000073E60: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000073E64: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000073E68: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073E6C: BF870095
	.long 0xd71c005a                                           // 000000073E70: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000073E74: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000073E78: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000073E7C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073E84: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 000000073E88: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 000000073E90: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073E98: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000073E9C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000073EA4: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073EA8: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000073EAC: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000073EB4: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000073EB8: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073EC0: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000073EC4: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 000000073EC8: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073ED0: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 000000073ED4: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 000000073ED8: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073EE0: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000073EE4: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000073EEC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 000000073EF4: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073F00: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000073F04: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000073F0C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000073F18: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000073F20: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000073F24: BE882006
	s_cbranch_execz 63034                                      // 000000073F28: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3514>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 000000073F2C: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000073F38: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000073F40: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000073F44: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073F48: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000073F4C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000073F54: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000073F60: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000073F64: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000073F68: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000073F6C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000073F74: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000073F7C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000073F80: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000073F84: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000073F88: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073F8C: BF870095
	.long 0xd71c005a                                           // 000000073F90: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000073F94: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000073F98: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000073F9C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073FA4: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 000000073FA8: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000073FB4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073FB8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000073FBC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000073FC4: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073FC8: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000073FCC: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000073FD4: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000073FD8: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073FE0: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000073FE4: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 000000073FE8: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000073FF0: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 000000073FF4: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 000000073FF8: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074000: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000074004: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000007400C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 000000074014: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074020: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000074024: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000007402C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000074038: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000074040: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000074044: BE882007
	s_cbranch_execz 62965                                      // 000000074048: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3520>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 00000007404C: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000074058: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000074060: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000074064: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074068: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000007406C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000074074: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000074080: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000074084: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000074088: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000007408C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000074094: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007409C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000740A0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000740A4: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000740A8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000740AC: BF870095
	.long 0xd71c005a                                           // 0000000740B0: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000740B4: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000740B8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000740BC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000740C4: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 0000000740C8: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000740D4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000740D8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000740DC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000740E4: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000740E8: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000740EC: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000740F4: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000740F8: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074100: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000074104: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 000000074108: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074110: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 000000074114: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 000000074118: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074120: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000074124: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000007412C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 000000074134: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074140: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000074144: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000007414C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000074158: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000074160: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000074164: BE882000
	s_cbranch_execz 62896                                      // 000000074168: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x352c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 00000007416C: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 000000074178: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 00000007417C: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 000000074184: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000074188: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007418C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000074190: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000074198: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000741A4: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000741A8: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000741AC: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000741B0: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000741B8: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000741C0: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000741C4: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000741C8: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000741CC: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000741D0: BF870095
	.long 0xd71c005a                                           // 0000000741D4: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000741D8: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000741DC: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000741E0: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000741E8: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000000741EC: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000741F4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000741F8: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 0000000741FC: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 000000074204: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074208: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 00000007420C: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 000000074214: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 000000074218: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074220: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 000000074224: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 000000074228: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074230: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 000000074234: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 000000074238: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074240: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 000000074244: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 00000007424C: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 000000074254: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074260: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 000000074264: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 00000007426C: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 000000074278: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 000000074280: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000074284: BE882001
	s_cbranch_execz 62827                                      // 000000074288: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3538>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 00000007428C: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 000000074298: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 00000007429C: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 0000000742A4: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000742A8: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000742AC: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 0000000742B0: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000742B8: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 0000000742C0: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000000742CC: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000742D0: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 0000000742D4: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 0000000742DC: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000742E0: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000000742E4: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000000742E8: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000000742EC: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000742F0: BF870095
	.long 0xd71c0059                                           // 0000000742F4: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000000742F8: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000742FC: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000074300: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074308: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 00000007430C: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000074314: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074318: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 00000007431C: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 000000074324: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074328: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 00000007432C: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 000000074334: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 000000074338: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074340: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 000000074344: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 000000074348: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074350: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 000000074354: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 000000074358: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074360: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 000000074364: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 00000007436C: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 000000074374: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074380: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 000000074384: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 00000007438C: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 000000074398: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000743A0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000743A4: BE882002
	s_cbranch_execz 62758                                      // 0000000743A8: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3544>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 0000000743AC: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000743B8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000743C0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000743C4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000743C8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000743CC: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 0000000743D4: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 0000000743E0: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000743E4: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 0000000743E8: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000743EC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 0000000743F4: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000743FC: BF870121
	v_add_f32_e32 v82, v82, v89                                // 000000074400: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 000000074404: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 000000074408: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007440C: BF870095
	.long 0xd71c0052                                           // 000000074410: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 000000074414: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000074418: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000007441C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074424: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 000000074428: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000074434: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074438: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000007443C: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 000000074444: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074448: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 00000007444C: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 000000074454: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 000000074458: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074460: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 000000074464: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 000000074468: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074470: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 000000074474: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 000000074478: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074480: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 000000074484: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000007448C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 000000074494: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000744A0: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 0000000744A4: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 0000000744AC: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000744B8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000744C0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000744C4: BE882003
	s_cbranch_execz 62689                                      // 0000000744C8: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3550>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 0000000744CC: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000744D8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000744E0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000744E4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000744E8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000744EC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000744F4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 000000074500: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074504: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 000000074508: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 000000074514: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 000000074518: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000007451C: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000074524: BF870293
	v_exp_f32_e32 v82, v82                                     // 000000074528: 7EA44B52
	.long 0xd71c0052                                           // 00000007452C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000074530: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000074534: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000074538: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000007453C: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 000000074544: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074550: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 000000074554: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000074558: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000074560: BF870291
	v_rcp_f32_e32 v84, v83                                     // 000000074564: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 000000074568: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000074570: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 000000074574: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 000000074578: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 000000074580: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074584: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 000000074588: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 000000074590: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074594: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 000000074598: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 0000000745A0: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000745A8: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000745AC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 0000000745B4: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000745C0: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000745C8: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000745CC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000745D8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000745E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000745E4: BE882004
	s_cbranch_execz 62620                                      // 0000000745E8: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x355c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 0000000745EC: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000745F8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000074600: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000074604: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074608: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000007460C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000074614: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000074620: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000074624: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000074628: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000007462C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000074634: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007463C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000074640: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000074644: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000074648: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007464C: BF870095
	.long 0xd71c0052                                           // 000000074650: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000074654: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000074658: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000007465C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074664: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 000000074668: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000074674: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074678: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000007467C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000074684: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074688: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000007468C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000074694: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000074698: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000746A0: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 0000000746A4: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 0000000746A8: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000746B0: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 0000000746B4: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 0000000746B8: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000746C0: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 0000000746C4: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000746CC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 0000000746D4: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000746E0: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000746E4: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000746EC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000746F8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000074700: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000074704: BE882005
	s_cbranch_execz 62551                                      // 000000074708: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3568>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 00000007470C: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000074718: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000074720: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000074724: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074728: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000007472C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000074734: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000074740: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000074744: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000074748: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000007474C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000074754: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007475C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000074760: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000074764: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000074768: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007476C: BF870095
	.long 0xd71c0052                                           // 000000074770: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000074774: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000074778: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000007477C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074784: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 000000074788: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 000000074790: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074798: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000007479C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000747A4: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000747A8: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000747AC: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000747B4: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000747B8: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000747C0: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000747C4: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 0000000747C8: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000747D0: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 0000000747D4: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 0000000747D8: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000747E0: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000747E4: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000747EC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 0000000747F4: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074800: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000074804: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000007480C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000074818: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000074820: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000074824: BE882006
	s_cbranch_execz 62482                                      // 000000074828: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3574>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 00000007482C: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000074838: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000074840: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000074844: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074848: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000007484C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000074854: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000074860: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000074864: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000074868: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000007486C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000074874: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007487C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000074880: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000074884: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000074888: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007488C: BF870095
	.long 0xd71c0052                                           // 000000074890: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000074894: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000074898: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000007489C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000748A4: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 0000000748A8: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000748B4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000748B8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000748BC: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000748C4: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000748C8: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000748CC: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000748D4: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000748D8: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000748E0: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000748E4: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000748E8: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000748F0: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000748F4: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000748F8: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074900: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 000000074904: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000007490C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 000000074914: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074920: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000074924: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000007492C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000074938: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000074940: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000074944: BE882007
	s_cbranch_execz 62413                                      // 000000074948: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3580>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 00000007494C: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000074958: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000074960: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000074964: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074968: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000007496C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000074974: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000074980: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000074984: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000074988: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000007498C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000074994: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007499C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000749A0: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000749A4: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000749A8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000749AC: BF870095
	.long 0xd71c0052                                           // 0000000749B0: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000749B4: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000749B8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000749BC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000749C4: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 0000000749C8: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000749D4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000749D8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000749DC: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000749E4: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000749E8: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000749EC: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000749F4: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000749F8: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074A00: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 000000074A04: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 000000074A08: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074A10: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 000000074A14: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 000000074A18: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074A20: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 000000074A24: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000074A2C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 000000074A34: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074A40: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000074A44: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000074A4C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000074A58: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000074A60: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000074A64: BE882000
	s_cbranch_execz 62344                                      // 000000074A68: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x358c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 000000074A6C: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 000000074A78: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 000000074A7C: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000074A84: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000074A88: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074A8C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000074A90: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000074A98: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000074AA4: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000074AA8: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000074AAC: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000074AB0: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000074AB8: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000074AC0: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000074AC4: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000074AC8: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000074ACC: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074AD0: BF870095
	.long 0xd71c0052                                           // 000000074AD4: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000074AD8: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000074ADC: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000074AE0: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074AE8: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 000000074AEC: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000074AF4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074AF8: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 000000074AFC: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 000000074B04: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074B08: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 000000074B0C: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 000000074B14: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 000000074B18: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074B20: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 000000074B24: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 000000074B28: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074B30: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 000000074B34: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 000000074B38: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074B40: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 000000074B44: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 000000074B4C: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 000000074B54: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074B60: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 000000074B64: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 000000074B6C: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 000000074B78: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 000000074B80: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000074B84: BE882001
	s_cbranch_execz 62275                                      // 000000074B88: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3598>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 000000074B8C: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 000000074B98: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 000000074B9C: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 000000074BA4: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000074BA8: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000074BAC: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 000000074BB0: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000074BB8: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 000000074BC0: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 000000074BCC: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000074BD0: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 000000074BD4: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 000000074BDC: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000074BE0: BF870121
	v_add_f32_e32 v81, v81, v82                                // 000000074BE4: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 000000074BE8: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 000000074BEC: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074BF0: BF870095
	.long 0xd71c0051                                           // 000000074BF4: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 000000074BF8: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 000000074BFC: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000074C00: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074C08: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 000000074C0C: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000074C14: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074C18: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 000000074C1C: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 000000074C24: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074C28: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 000000074C2C: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 000000074C34: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 000000074C38: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074C40: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 000000074C44: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 000000074C48: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074C50: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 000000074C54: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 000000074C58: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074C60: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 000000074C64: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 000000074C6C: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 000000074C74: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074C80: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 000000074C84: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 000000074C8C: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 000000074C98: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 000000074CA0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000074CA4: BE882002
	s_cbranch_execz 62206                                      // 000000074CA8: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35a4>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 000000074CAC: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000074CB8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000074CC0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000074CC4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074CC8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000074CCC: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 000000074CD4: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 000000074CE0: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000074CE4: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 000000074CE8: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000074CEC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 000000074CF4: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000074CFC: BF870121
	v_add_f32_e32 v74, v74, v81                                // 000000074D00: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 000000074D04: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 000000074D08: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074D0C: BF870095
	.long 0xd71c004a                                           // 000000074D10: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 000000074D14: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000074D18: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000074D1C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074D24: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 000000074D28: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000074D34: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074D38: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000074D3C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 000000074D44: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074D48: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 000000074D4C: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 000000074D54: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 000000074D58: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074D60: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 000000074D64: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 000000074D68: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074D70: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 000000074D74: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 000000074D78: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074D80: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 000000074D84: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000074D8C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 000000074D94: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074DA0: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 000000074DA4: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 000000074DAC: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000074DB8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000074DC0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000074DC4: BE882003
	s_cbranch_execz 62137                                      // 000000074DC8: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35b0>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 000000074DCC: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000074DD8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000074DE0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000074DE4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074DE8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000074DEC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000074DF4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 000000074E00: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074E04: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 000000074E08: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 000000074E14: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 000000074E18: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000074E1C: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000074E24: BF870293
	v_exp_f32_e32 v74, v74                                     // 000000074E28: 7E944B4A
	.long 0xd71c004a                                           // 000000074E2C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000074E30: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000074E34: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000074E38: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000074E3C: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 000000074E44: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074E50: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 000000074E54: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000074E58: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000074E60: BF870291
	v_rcp_f32_e32 v76, v75                                     // 000000074E64: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 000000074E68: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000074E70: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 000000074E74: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 000000074E78: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 000000074E80: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074E84: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 000000074E88: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 000000074E90: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074E94: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 000000074E98: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 000000074EA0: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000074EA8: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000074EAC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 000000074EB4: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 000000074EC0: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000074EC8: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000074ECC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000074ED8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000074EE0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000074EE4: BE882004
	s_cbranch_execz 62068                                      // 000000074EE8: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35bc>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 000000074EEC: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000074EF8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000074F00: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000074F04: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074F08: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000074F0C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000074F14: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000074F20: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000074F24: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000074F28: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000074F2C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000074F34: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000074F3C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000074F40: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000074F44: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000074F48: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074F4C: BF870095
	.long 0xd71c004a                                           // 000000074F50: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000074F54: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000074F58: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000074F5C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074F64: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 000000074F68: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000074F74: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074F78: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000074F7C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000074F84: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074F88: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000074F8C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000074F94: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000074F98: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074FA0: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 000000074FA4: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 000000074FA8: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074FB0: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 000000074FB4: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 000000074FB8: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074FC0: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 000000074FC4: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000074FCC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 000000074FD4: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000074FE0: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000074FE4: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000074FEC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000074FF8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000075000: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000075004: BE882005
	s_cbranch_execz 61999                                      // 000000075008: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35c8>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 00000007500C: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000075018: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000075020: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000075024: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075028: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000007502C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000075034: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000075040: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000075044: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000075048: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000007504C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000075054: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007505C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000075060: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000075064: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000075068: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007506C: BF870095
	.long 0xd71c004a                                           // 000000075070: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000075074: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000075078: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000007507C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075084: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 000000075088: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 000000075090: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075098: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000007509C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000750A4: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000750A8: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000750AC: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000750B4: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000750B8: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000750C0: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000750C4: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 0000000750C8: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000750D0: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 0000000750D4: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 0000000750D8: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000750E0: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000750E4: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000750EC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 0000000750F4: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075100: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000075104: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000007510C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000075118: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000075120: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000075124: BE882006
	s_cbranch_execz 61930                                      // 000000075128: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35d4>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 00000007512C: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000075138: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000075140: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000075144: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075148: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000007514C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000075154: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000075160: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000075164: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000075168: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000007516C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000075174: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007517C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000075180: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000075184: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000075188: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007518C: BF870095
	.long 0xd71c004a                                           // 000000075190: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000075194: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000075198: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000007519C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000751A4: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 0000000751A8: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000751B4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000751B8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000751BC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000751C4: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000751C8: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000751CC: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000751D4: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000751D8: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000751E0: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000751E4: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000751E8: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000751F0: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000751F4: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000751F8: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075200: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 000000075204: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000007520C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 000000075214: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075220: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000075224: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000007522C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000075238: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000075240: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000075244: BE882007
	s_cbranch_execz 61861                                      // 000000075248: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35e0>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 00000007524C: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000075258: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000075260: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000075264: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075268: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000007526C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000075274: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000075280: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000075284: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000075288: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000007528C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000075294: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007529C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000752A0: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000752A4: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000752A8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000752AC: BF870095
	.long 0xd71c004a                                           // 0000000752B0: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000752B4: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000752B8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000752BC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000752C4: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 0000000752C8: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000752D4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000752D8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000752DC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000752E4: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000752E8: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000752EC: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000752F4: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000752F8: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075300: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 000000075304: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 000000075308: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075310: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 000000075314: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 000000075318: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075320: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 000000075324: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000007532C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 000000075334: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075340: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000075344: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000007534C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000075358: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000075360: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000075364: BE882000
	s_cbranch_execz 61792                                      // 000000075368: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35ec>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 00000007536C: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 000000075378: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 00000007537C: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000075384: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000075388: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007538C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000075390: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000075398: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000753A4: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000753A8: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000753AC: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000753B0: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000753B8: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000753C0: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000753C4: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000753C8: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000753CC: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000753D0: BF870095
	.long 0xd71c004a                                           // 0000000753D4: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000753D8: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000753DC: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000753E0: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000753E8: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000000753EC: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000753F4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000753F8: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 0000000753FC: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 000000075404: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075408: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 00000007540C: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 000000075414: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 000000075418: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075420: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 000000075424: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 000000075428: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075430: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 000000075434: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 000000075438: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075440: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 000000075444: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 00000007544C: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 000000075454: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075460: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 000000075464: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 00000007546C: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 000000075478: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 000000075480: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000075484: BE882001
	s_cbranch_execz 61723                                      // 000000075488: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35f8>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 00000007548C: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 000000075498: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 00000007549C: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 0000000754A4: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000754A8: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000754AC: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 0000000754B0: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000754B8: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 0000000754C0: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000000754CC: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000754D0: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 0000000754D4: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 0000000754DC: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000754E0: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000000754E4: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000000754E8: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000000754EC: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000754F0: BF870095
	.long 0xd71c0049                                           // 0000000754F4: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000754F8: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000754FC: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000075500: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075508: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 00000007550C: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000075514: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075518: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 00000007551C: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 000000075524: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075528: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 00000007552C: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 000000075534: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 000000075538: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075540: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 000000075544: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 000000075548: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075550: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 000000075554: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 000000075558: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075560: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 000000075564: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 00000007556C: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 000000075574: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075580: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 000000075584: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 00000007558C: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 000000075598: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000755A0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000755A4: BE882002
	s_cbranch_execz 61654                                      // 0000000755A8: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3604>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 0000000755AC: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000755B8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000755C0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000755C4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000755C8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000755CC: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 0000000755D4: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 0000000755E0: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000755E4: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 0000000755E8: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000755EC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 0000000755F4: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000755FC: BF870121
	v_add_f32_e32 v66, v66, v73                                // 000000075600: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 000000075604: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 000000075608: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007560C: BF870095
	.long 0xd71c0042                                           // 000000075610: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 000000075614: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000075618: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000007561C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075624: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 000000075628: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000075634: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075638: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000007563C: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 000000075644: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075648: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 00000007564C: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 000000075654: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 000000075658: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075660: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 000000075664: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 000000075668: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075670: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 000000075674: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 000000075678: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075680: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 000000075684: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000007568C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 000000075694: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000756A0: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 0000000756A4: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 0000000756AC: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000756B8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000756C0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000756C4: BE882003
	s_cbranch_execz 61585                                      // 0000000756C8: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3610>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 0000000756CC: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000756D8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000756E0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000756E4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000756E8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000756EC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000756F4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 000000075700: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075704: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 000000075708: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 000000075714: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 000000075718: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000007571C: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000075724: BF870293
	v_exp_f32_e32 v66, v66                                     // 000000075728: 7E844B42
	.long 0xd71c0042                                           // 00000007572C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000075730: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000075734: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000075738: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000007573C: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 000000075744: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075750: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 000000075754: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000075758: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000075760: BF870291
	v_rcp_f32_e32 v68, v67                                     // 000000075764: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 000000075768: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000075770: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 000000075774: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 000000075778: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 000000075780: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075784: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 000000075788: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 000000075790: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075794: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 000000075798: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 0000000757A0: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000757A8: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000757AC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 0000000757B4: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000757C0: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000757C8: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000757CC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000757D8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000757E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000757E4: BE882004
	s_cbranch_execz 61516                                      // 0000000757E8: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x361c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 0000000757EC: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000757F8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000075800: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000075804: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075808: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000007580C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000075814: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000075820: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000075824: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000075828: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000007582C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000075834: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007583C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000075840: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000075844: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000075848: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007584C: BF870095
	.long 0xd71c0042                                           // 000000075850: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000075854: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000075858: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000007585C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075864: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 000000075868: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000075874: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075878: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000007587C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000075884: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075888: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000007588C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000075894: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000075898: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000758A0: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 0000000758A4: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 0000000758A8: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000758B0: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 0000000758B4: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 0000000758B8: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000758C0: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 0000000758C4: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000758CC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 0000000758D4: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000758E0: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000758E4: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000758EC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000758F8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000075900: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000075904: BE882005
	s_cbranch_execz 61447                                      // 000000075908: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3628>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 00000007590C: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000075918: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000075920: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000075924: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075928: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000007592C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000075934: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000075940: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000075944: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000075948: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000007594C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000075954: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007595C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000075960: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000075964: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000075968: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007596C: BF870095
	.long 0xd71c0042                                           // 000000075970: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000075974: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000075978: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000007597C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075984: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000075988: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 000000075990: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075998: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000007599C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000759A4: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000759A8: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000759AC: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000759B4: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000759B8: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000759C0: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000759C4: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 0000000759C8: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000759D0: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 0000000759D4: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 0000000759D8: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000759E0: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000759E4: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000759EC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 0000000759F4: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075A00: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000075A04: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000075A0C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000075A18: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000075A20: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000075A24: BE882006
	s_cbranch_execz 61378                                      // 000000075A28: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3634>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 000000075A2C: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000075A38: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000075A40: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000075A44: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075A48: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000075A4C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000075A54: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000075A60: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000075A64: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000075A68: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000075A6C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000075A74: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000075A7C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000075A80: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000075A84: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000075A88: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075A8C: BF870095
	.long 0xd71c0042                                           // 000000075A90: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000075A94: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000075A98: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000075A9C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075AA4: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 000000075AA8: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000075AB4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075AB8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000075ABC: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000075AC4: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075AC8: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000075ACC: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000075AD4: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000075AD8: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075AE0: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000075AE4: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000075AE8: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075AF0: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 000000075AF4: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000075AF8: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075B00: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000075B04: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000075B0C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 000000075B14: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075B20: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000075B24: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000075B2C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000075B38: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000075B40: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000075B44: BE882007
	s_cbranch_execz 61309                                      // 000000075B48: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3640>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 000000075B4C: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000075B58: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000075B60: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000075B64: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075B68: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000075B6C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000075B74: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000075B80: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000075B84: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000075B88: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000075B8C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000075B94: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000075B9C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000075BA0: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000075BA4: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000075BA8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075BAC: BF870095
	.long 0xd71c0042                                           // 000000075BB0: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000075BB4: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000075BB8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000075BBC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075BC4: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 000000075BC8: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000075BD4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075BD8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000075BDC: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000075BE4: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075BE8: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000075BEC: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000075BF4: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000075BF8: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075C00: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000075C04: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000075C08: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075C10: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 000000075C14: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000075C18: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075C20: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000075C24: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000075C2C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 000000075C34: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075C40: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000075C44: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000075C4C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000075C58: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000075C60: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000075C64: BE882000
	s_cbranch_execz 61240                                      // 000000075C68: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x364c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 000000075C6C: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 000000075C78: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 000000075C7C: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 000000075C84: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000075C88: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075C8C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000075C90: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000075C98: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000075CA4: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000075CA8: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000075CAC: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000075CB0: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000075CB8: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000075CC0: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000075CC4: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000075CC8: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000075CCC: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075CD0: BF870095
	.long 0xd71c0042                                           // 000000075CD4: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000075CD8: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000075CDC: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000075CE0: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075CE8: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000075CEC: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000075CF4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075CF8: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 000000075CFC: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 000000075D04: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075D08: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 000000075D0C: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 000000075D14: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 000000075D18: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075D20: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 000000075D24: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 000000075D28: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075D30: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 000000075D34: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 000000075D38: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075D40: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 000000075D44: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 000000075D4C: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 000000075D54: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075D60: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 000000075D64: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 000000075D6C: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 000000075D78: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000075D80: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000075D84: BE882001
	s_cbranch_execz 61171                                      // 000000075D88: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3658>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 000000075D8C: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 000000075D98: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 000000075D9C: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 000000075DA4: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000075DA8: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000075DAC: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 000000075DB0: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000075DB8: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 000000075DC0: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 000000075DCC: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000075DD0: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 000000075DD4: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 000000075DDC: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000075DE0: BF870121
	v_add_f32_e32 v65, v65, v66                                // 000000075DE4: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000075DE8: 7E841143
	v_exp_f32_e32 v65, v65                                     // 000000075DEC: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075DF0: BF870095
	.long 0xd71c0041                                           // 000000075DF4: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000075DF8: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 000000075DFC: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000075E00: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075E08: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 000000075E0C: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000075E14: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075E18: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 000000075E1C: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 000000075E24: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075E28: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 000000075E2C: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 000000075E34: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 000000075E38: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075E40: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 000000075E44: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 000000075E48: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075E50: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 000000075E54: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 000000075E58: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075E60: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 000000075E64: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 000000075E6C: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 000000075E74: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075E80: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 000000075E84: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 000000075E8C: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 000000075E98: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000075EA0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000075EA4: BE882002
	s_cbranch_execz 61102                                      // 000000075EA8: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3664>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 000000075EAC: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000075EB8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000075EC0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000075EC4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075EC8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000075ECC: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 000000075ED4: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 000000075EE0: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000075EE4: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 000000075EE8: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000075EEC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 000000075EF4: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000075EFC: BF870121
	v_add_f32_e32 v58, v58, v65                                // 000000075F00: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 000000075F04: 7E821142
	v_exp_f32_e32 v58, v58                                     // 000000075F08: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075F0C: BF870095
	.long 0xd71c003a                                           // 000000075F10: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 000000075F14: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000075F18: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000075F1C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075F24: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 000000075F28: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000075F34: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075F38: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000075F3C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 000000075F44: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075F48: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 000000075F4C: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 000000075F54: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 000000075F58: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075F60: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 000000075F64: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 000000075F68: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075F70: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 000000075F74: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 000000075F78: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075F80: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 000000075F84: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000075F8C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 000000075F94: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075FA0: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 000000075FA4: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 000000075FAC: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000075FB8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000075FC0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000075FC4: BE882003
	s_cbranch_execz 61033                                      // 000000075FC8: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3670>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 000000075FCC: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000075FD8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000075FE0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000075FE4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000075FE8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000075FEC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000075FF4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 000000076000: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076004: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 000000076008: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 000000076014: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 000000076018: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000007601C: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000076024: BF870293
	v_exp_f32_e32 v58, v58                                     // 000000076028: 7E744B3A
	.long 0xd71c003a                                           // 00000007602C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000076030: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076034: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000076038: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000007603C: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 000000076044: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076050: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 000000076054: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000076058: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000076060: BF870291
	v_rcp_f32_e32 v60, v59                                     // 000000076064: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 000000076068: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000076070: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 000000076074: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 000000076078: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 000000076080: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076084: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 000000076088: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 000000076090: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076094: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 000000076098: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 0000000760A0: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000760A8: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000760AC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 0000000760B4: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000760C0: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000760C8: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000760CC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000760D8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000760E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000760E4: BE882004
	s_cbranch_execz 60964                                      // 0000000760E8: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x367c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 0000000760EC: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000760F8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000076100: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000076104: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076108: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000007610C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000076114: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000076120: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000076124: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000076128: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000007612C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000076134: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007613C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000076140: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000076144: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000076148: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007614C: BF870095
	.long 0xd71c003a                                           // 000000076150: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000076154: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000076158: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000007615C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076164: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 000000076168: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000076174: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076178: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000007617C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000076184: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076188: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000007618C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000076194: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000076198: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000761A0: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 0000000761A4: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 0000000761A8: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000761B0: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 0000000761B4: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 0000000761B8: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000761C0: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 0000000761C4: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000761CC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 0000000761D4: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000761E0: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000761E4: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000761EC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000761F8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000076200: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000076204: BE882005
	s_cbranch_execz 60895                                      // 000000076208: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3688>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 00000007620C: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000076218: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000076220: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000076224: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076228: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000007622C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000076234: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000076240: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000076244: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000076248: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000007624C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000076254: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007625C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000076260: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000076264: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000076268: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007626C: BF870095
	.long 0xd71c003a                                           // 000000076270: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000076274: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000076278: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000007627C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076284: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 000000076288: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 000000076290: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076298: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000007629C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000762A4: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000762A8: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000762AC: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000762B4: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000762B8: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000762C0: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000762C4: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 0000000762C8: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000762D0: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 0000000762D4: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 0000000762D8: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000762E0: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000762E4: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000762EC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 0000000762F4: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076300: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000076304: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000007630C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000076318: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000076320: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000076324: BE882006
	s_cbranch_execz 60826                                      // 000000076328: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3694>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 00000007632C: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000076338: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000076340: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000076344: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076348: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000007634C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000076354: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000076360: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000076364: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000076368: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000007636C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000076374: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007637C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000076380: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000076384: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000076388: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007638C: BF870095
	.long 0xd71c003a                                           // 000000076390: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000076394: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000076398: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000007639C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000763A4: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 0000000763A8: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000763B4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000763B8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000763BC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000763C4: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000763C8: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000763CC: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000763D4: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000763D8: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000763E0: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000763E4: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000763E8: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000763F0: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000763F4: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000763F8: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076400: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 000000076404: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000007640C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 000000076414: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076420: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000076424: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000007642C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000076438: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000076440: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000076444: BE882007
	s_cbranch_execz 60757                                      // 000000076448: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36a0>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 00000007644C: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000076458: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000076460: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000076464: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076468: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000007646C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000076474: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000076480: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000076484: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000076488: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000007648C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000076494: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007649C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000764A0: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000764A4: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000764A8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000764AC: BF870095
	.long 0xd71c003a                                           // 0000000764B0: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000764B4: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000764B8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000764BC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000764C4: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 0000000764C8: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000764D4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000764D8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000764DC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000764E4: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000764E8: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000764EC: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000764F4: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000764F8: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076500: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 000000076504: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 000000076508: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076510: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 000000076514: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 000000076518: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076520: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 000000076524: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000007652C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 000000076534: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076540: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000076544: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000007654C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000076558: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000076560: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000076564: BE882000
	s_cbranch_execz 60688                                      // 000000076568: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36ac>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 00000007656C: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 000000076578: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 00000007657C: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 000000076584: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000076588: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007658C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000076590: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000076598: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000765A4: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000765A8: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000765AC: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000765B0: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000765B8: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000765C0: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000765C4: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000765C8: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000765CC: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000765D0: BF870095
	.long 0xd71c003a                                           // 0000000765D4: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000765D8: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000765DC: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000765E0: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000765E8: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000765EC: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000765F4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000765F8: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 0000000765FC: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 000000076604: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076608: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000007660C: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 000000076614: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 000000076618: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076620: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 000000076624: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 000000076628: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076630: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 000000076634: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 000000076638: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076640: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 000000076644: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 00000007664C: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 000000076654: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076660: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 000000076664: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 00000007666C: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 000000076678: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000076680: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000076684: BE882001
	s_cbranch_execz 60619                                      // 000000076688: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36b8>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 00000007668C: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 000000076698: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 00000007669C: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 0000000766A4: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000766A8: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000766AC: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 0000000766B0: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000766B8: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 0000000766C0: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 0000000766CC: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000766D0: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 0000000766D4: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 0000000766DC: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000766E0: BF870121
	v_add_f32_e32 v57, v57, v58                                // 0000000766E4: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 0000000766E8: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 0000000766EC: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000766F0: BF870095
	.long 0xd71c0039                                           // 0000000766F4: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000000766F8: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000766FC: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000076700: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076708: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 00000007670C: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000076714: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076718: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 00000007671C: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 000000076724: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076728: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 00000007672C: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 000000076734: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 000000076738: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076740: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 000000076744: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 000000076748: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076750: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 000000076754: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 000000076758: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076760: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 000000076764: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 00000007676C: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 000000076774: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076780: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 000000076784: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 00000007678C: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 000000076798: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000767A0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000767A4: BE882002
	s_cbranch_execz 60550                                      // 0000000767A8: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36c4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 0000000767AC: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000767B8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000767C0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000767C4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000767C8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000767CC: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 0000000767D4: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 0000000767E0: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000767E4: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 0000000767E8: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000767EC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 0000000767F4: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000767FC: BF870121
	v_add_f32_e32 v50, v50, v57                                // 000000076800: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 000000076804: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 000000076808: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007680C: BF870095
	.long 0xd71c0032                                           // 000000076810: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 000000076814: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000076818: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000007681C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076824: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 000000076828: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000076834: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076838: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000007683C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 000000076844: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076848: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 00000007684C: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 000000076854: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 000000076858: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076860: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 000000076864: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 000000076868: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076870: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 000000076874: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 000000076878: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076880: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 000000076884: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000007688C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 000000076894: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000768A0: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 0000000768A4: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 0000000768AC: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000768B8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000768C0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000768C4: BE882003
	s_cbranch_execz 60481                                      // 0000000768C8: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36d0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 0000000768CC: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000768D8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000768E0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000768E4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000768E8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000768EC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000768F4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 000000076900: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076904: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 000000076908: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 000000076914: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 000000076918: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000007691C: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000076924: BF870293
	v_exp_f32_e32 v50, v50                                     // 000000076928: 7E644B32
	.long 0xd71c0032                                           // 00000007692C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000076930: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076934: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000076938: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000007693C: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 000000076944: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076950: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 000000076954: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000076958: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000076960: BF870291
	v_rcp_f32_e32 v52, v51                                     // 000000076964: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 000000076968: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000076970: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 000000076974: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 000000076978: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 000000076980: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076984: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 000000076988: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 000000076990: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076994: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 000000076998: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 0000000769A0: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000769A8: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000769AC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 0000000769B4: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000769C0: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000769C8: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000769CC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000769D8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000769E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000769E4: BE882004
	s_cbranch_execz 60412                                      // 0000000769E8: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36dc>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 0000000769EC: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000769F8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000076A00: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000076A04: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076A08: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000076A0C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000076A14: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000076A20: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000076A24: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000076A28: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000076A2C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000076A34: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076A3C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000076A40: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000076A44: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000076A48: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076A4C: BF870095
	.long 0xd71c0032                                           // 000000076A50: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000076A54: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000076A58: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000076A5C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076A64: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 000000076A68: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000076A74: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076A78: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000076A7C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000076A84: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076A88: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000076A8C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000076A94: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000076A98: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076AA0: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 000000076AA4: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 000000076AA8: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076AB0: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 000000076AB4: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 000000076AB8: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076AC0: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 000000076AC4: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000076ACC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 000000076AD4: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076AE0: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000076AE4: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000076AEC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000076AF8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000076B00: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000076B04: BE882005
	s_cbranch_execz 60343                                      // 000000076B08: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36e8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 000000076B0C: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000076B18: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000076B20: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000076B24: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076B28: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000076B2C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000076B34: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000076B40: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000076B44: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000076B48: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000076B4C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000076B54: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076B5C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000076B60: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000076B64: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000076B68: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076B6C: BF870095
	.long 0xd71c0032                                           // 000000076B70: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000076B74: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000076B78: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000076B7C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076B84: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000076B88: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 000000076B90: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076B98: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000076B9C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000076BA4: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076BA8: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000076BAC: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000076BB4: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000076BB8: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076BC0: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000076BC4: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 000000076BC8: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076BD0: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 000000076BD4: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 000000076BD8: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076BE0: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000076BE4: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000076BEC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 000000076BF4: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076C00: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000076C04: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000076C0C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000076C18: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000076C20: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000076C24: BE882006
	s_cbranch_execz 60274                                      // 000000076C28: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36f4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 000000076C2C: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000076C38: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000076C40: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000076C44: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076C48: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000076C4C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000076C54: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000076C60: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000076C64: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000076C68: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000076C6C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000076C74: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076C7C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000076C80: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000076C84: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000076C88: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076C8C: BF870095
	.long 0xd71c0032                                           // 000000076C90: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000076C94: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000076C98: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000076C9C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076CA4: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 000000076CA8: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000076CB4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076CB8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000076CBC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000076CC4: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076CC8: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000076CCC: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000076CD4: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000076CD8: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076CE0: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000076CE4: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000076CE8: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076CF0: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 000000076CF4: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000076CF8: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076D00: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000076D04: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000076D0C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 000000076D14: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076D20: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000076D24: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000076D2C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000076D38: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000076D40: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000076D44: BE882007
	s_cbranch_execz 60205                                      // 000000076D48: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3700>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 000000076D4C: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000076D58: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000076D60: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000076D64: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076D68: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000076D6C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000076D74: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000076D80: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000076D84: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000076D88: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000076D8C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000076D94: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076D9C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000076DA0: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000076DA4: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000076DA8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076DAC: BF870095
	.long 0xd71c0032                                           // 000000076DB0: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000076DB4: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000076DB8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000076DBC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076DC4: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 000000076DC8: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000076DD4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076DD8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000076DDC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000076DE4: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076DE8: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000076DEC: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000076DF4: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000076DF8: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076E00: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000076E04: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000076E08: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076E10: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 000000076E14: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000076E18: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076E20: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000076E24: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000076E2C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 000000076E34: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076E40: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000076E44: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000076E4C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000076E58: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000076E60: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000076E64: BE882000
	s_cbranch_execz 60136                                      // 000000076E68: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x370c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 000000076E6C: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 000000076E78: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 000000076E7C: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 000000076E84: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000076E88: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076E8C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000076E90: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000076E98: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000076EA4: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000076EA8: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000076EAC: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000076EB0: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000076EB8: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076EC0: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000076EC4: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000076EC8: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000076ECC: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076ED0: BF870095
	.long 0xd71c0032                                           // 000000076ED4: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000076ED8: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000076EDC: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000076EE0: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076EE8: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000076EEC: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000076EF4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076EF8: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 000000076EFC: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 000000076F04: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076F08: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 000000076F0C: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 000000076F14: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 000000076F18: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076F20: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 000000076F24: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 000000076F28: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076F30: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 000000076F34: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 000000076F38: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076F40: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 000000076F44: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 000000076F4C: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 000000076F54: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076F60: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 000000076F64: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 000000076F6C: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 000000076F78: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000076F80: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000076F84: BE882001
	s_cbranch_execz 60067                                      // 000000076F88: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3718>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 000000076F8C: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 000000076F98: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 000000076F9C: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 000000076FA4: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000076FA8: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076FAC: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 000000076FB0: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000076FB8: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 000000076FC0: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 000000076FCC: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000076FD0: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 000000076FD4: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 000000076FDC: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000076FE0: BF870121
	v_add_f32_e32 v49, v49, v50                                // 000000076FE4: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 000000076FE8: 7E641133
	v_exp_f32_e32 v49, v49                                     // 000000076FEC: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000076FF0: BF870095
	.long 0xd71c0031                                           // 000000076FF4: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 000000076FF8: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 000000076FFC: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000077000: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077008: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 00000007700C: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000077014: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077018: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 00000007701C: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 000000077024: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077028: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 00000007702C: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 000000077034: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 000000077038: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077040: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 000000077044: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 000000077048: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077050: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 000000077054: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 000000077058: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077060: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 000000077064: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 00000007706C: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 000000077074: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077080: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 000000077084: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 00000007708C: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 000000077098: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000770A0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000770A4: BE882002
	s_cbranch_execz 59998                                      // 0000000770A8: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3724>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 0000000770AC: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000770B8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000770C0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000770C4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000770C8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000770CC: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 0000000770D4: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 0000000770E0: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000770E4: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 0000000770E8: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000770EC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 0000000770F4: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000770FC: BF870121
	v_add_f32_e32 v42, v42, v49                                // 000000077100: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 000000077104: 7E621132
	v_exp_f32_e32 v42, v42                                     // 000000077108: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007710C: BF870095
	.long 0xd71c002a                                           // 000000077110: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 000000077114: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000077118: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000007711C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077124: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 000000077128: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000077134: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077138: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000007713C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 000000077144: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077148: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 00000007714C: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 000000077154: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 000000077158: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077160: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 000000077164: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 000000077168: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077170: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 000000077174: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 000000077178: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077180: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 000000077184: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000007718C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 000000077194: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000771A0: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 0000000771A4: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 0000000771AC: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000771B8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000771C0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000771C4: BE882003
	s_cbranch_execz 59929                                      // 0000000771C8: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3730>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 0000000771CC: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000771D8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000771E0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000771E4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000771E8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000771EC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000771F4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 000000077200: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077204: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 000000077208: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 000000077214: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 000000077218: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000007721C: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000077224: BF870293
	v_exp_f32_e32 v42, v42                                     // 000000077228: 7E544B2A
	.long 0xd71c002a                                           // 00000007722C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000077230: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000077234: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000077238: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000007723C: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 000000077244: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077250: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 000000077254: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000077258: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000077260: BF870291
	v_rcp_f32_e32 v44, v43                                     // 000000077264: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 000000077268: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000077270: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 000000077274: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 000000077278: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 000000077280: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077284: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 000000077288: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 000000077290: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077294: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 000000077298: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 0000000772A0: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000772A8: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000772AC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 0000000772B4: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000772C0: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000772C8: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000772CC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000772D8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000772E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000772E4: BE882004
	s_cbranch_execz 59860                                      // 0000000772E8: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x373c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 0000000772EC: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000772F8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000077300: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000077304: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077308: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000007730C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000077314: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000077320: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000077324: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000077328: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000007732C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000077334: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007733C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000077340: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000077344: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000077348: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007734C: BF870095
	.long 0xd71c002a                                           // 000000077350: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000077354: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000077358: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000007735C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077364: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 000000077368: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000077374: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077378: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000007737C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000077384: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077388: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000007738C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000077394: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000077398: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000773A0: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 0000000773A4: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 0000000773A8: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000773B0: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 0000000773B4: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 0000000773B8: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000773C0: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 0000000773C4: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000773CC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 0000000773D4: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000773E0: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000773E4: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000773EC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000773F8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000077400: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000077404: BE882005
	s_cbranch_execz 59791                                      // 000000077408: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3748>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 00000007740C: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000077418: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000077420: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000077424: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077428: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000007742C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000077434: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000077440: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000077444: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000077448: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000007744C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000077454: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007745C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000077460: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000077464: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000077468: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007746C: BF870095
	.long 0xd71c002a                                           // 000000077470: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000077474: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000077478: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000007747C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077484: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 000000077488: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 000000077490: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077498: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000007749C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000774A4: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000774A8: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000774AC: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000774B4: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000774B8: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000774C0: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000774C4: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 0000000774C8: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000774D0: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 0000000774D4: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 0000000774D8: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000774E0: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000774E4: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000774EC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 0000000774F4: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077500: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000077504: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000007750C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000077518: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000077520: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000077524: BE882006
	s_cbranch_execz 59722                                      // 000000077528: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3754>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 00000007752C: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000077538: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000077540: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000077544: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077548: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000007754C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000077554: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000077560: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000077564: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000077568: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000007756C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000077574: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007757C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000077580: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000077584: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000077588: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007758C: BF870095
	.long 0xd71c002a                                           // 000000077590: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000077594: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000077598: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000007759C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000775A4: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 0000000775A8: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000775B4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000775B8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000775BC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000775C4: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000775C8: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000775CC: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000775D4: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000775D8: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000775E0: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000775E4: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000775E8: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000775F0: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000775F4: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000775F8: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077600: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 000000077604: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000007760C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 000000077614: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077620: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000077624: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000007762C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000077638: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000077640: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000077644: BE882007
	s_cbranch_execz 59653                                      // 000000077648: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3760>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 00000007764C: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000077658: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000077660: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000077664: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077668: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000007766C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000077674: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000077680: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000077684: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000077688: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000007768C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000077694: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007769C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000776A0: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000776A4: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000776A8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000776AC: BF870095
	.long 0xd71c002a                                           // 0000000776B0: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000776B4: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000776B8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000776BC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000776C4: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 0000000776C8: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000776D4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000776D8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000776DC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000776E4: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000776E8: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000776EC: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000776F4: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000776F8: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077700: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 000000077704: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 000000077708: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077710: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 000000077714: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 000000077718: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077720: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 000000077724: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000007772C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 000000077734: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077740: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000077744: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000007774C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000077758: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000077760: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000077764: BE882000
	s_cbranch_execz 59584                                      // 000000077768: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x376c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 00000007776C: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 000000077778: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 00000007777C: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 000000077784: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000077788: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007778C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000077790: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000077798: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000777A4: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000777A8: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000777AC: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000777B0: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000777B8: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000777C0: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000777C4: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000777C8: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000777CC: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000777D0: BF870095
	.long 0xd71c002a                                           // 0000000777D4: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000777D8: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000777DC: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000777E0: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000777E8: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000777EC: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000777F4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000777F8: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 0000000777FC: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 000000077804: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077808: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 00000007780C: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 000000077814: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 000000077818: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077820: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 000000077824: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 000000077828: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077830: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 000000077834: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 000000077838: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077840: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 000000077844: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 00000007784C: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 000000077854: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077860: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 000000077864: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 00000007786C: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 000000077878: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 000000077880: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000077884: BE882001
	s_cbranch_execz 59515                                      // 000000077888: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3778>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 00000007788C: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 000000077898: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 00000007789C: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 0000000778A4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000778A8: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000778AC: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 0000000778B0: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000778B8: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 0000000778C0: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000000778CC: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000778D0: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 0000000778D4: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 0000000778DC: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000778E0: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000000778E4: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000000778E8: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 0000000778EC: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000778F0: BF870095
	.long 0xd71c0029                                           // 0000000778F4: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000000778F8: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000778FC: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000077900: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077908: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 00000007790C: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000077914: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077918: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 00000007791C: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 000000077924: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077928: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 00000007792C: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 000000077934: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 000000077938: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077940: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 000000077944: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 000000077948: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077950: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 000000077954: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 000000077958: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077960: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 000000077964: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 00000007796C: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 000000077974: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077980: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 000000077984: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 00000007798C: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 000000077998: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000779A0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000779A4: BE882002
	s_cbranch_execz 59446                                      // 0000000779A8: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3784>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 0000000779AC: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000779B8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000779C0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000779C4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000779C8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000779CC: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 0000000779D4: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 0000000779E0: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000779E4: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 0000000779E8: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000779EC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 0000000779F4: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000779FC: BF870121
	v_add_f32_e32 v34, v34, v41                                // 000000077A00: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 000000077A04: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 000000077A08: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077A0C: BF870095
	.long 0xd71c0022                                           // 000000077A10: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 000000077A14: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000077A18: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000077A1C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077A24: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 000000077A28: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000077A34: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077A38: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000077A3C: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 000000077A44: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077A48: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 000000077A4C: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 000000077A54: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 000000077A58: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077A60: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 000000077A64: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 000000077A68: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077A70: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 000000077A74: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 000000077A78: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077A80: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 000000077A84: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000077A8C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 000000077A94: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077AA0: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 000000077AA4: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 000000077AAC: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000077AB8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000077AC0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000077AC4: BE882003
	s_cbranch_execz 59377                                      // 000000077AC8: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3790>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 000000077ACC: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000077AD8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000077AE0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000077AE4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077AE8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000077AEC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000077AF4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 000000077B00: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077B04: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 000000077B08: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 000000077B14: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 000000077B18: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000077B1C: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000077B24: BF870293
	v_exp_f32_e32 v34, v34                                     // 000000077B28: 7E444B22
	.long 0xd71c0022                                           // 000000077B2C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000077B30: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000077B34: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000077B38: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000077B3C: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 000000077B44: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077B50: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 000000077B54: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000077B58: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000077B60: BF870291
	v_rcp_f32_e32 v36, v35                                     // 000000077B64: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 000000077B68: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000077B70: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 000000077B74: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 000000077B78: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 000000077B80: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077B84: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 000000077B88: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 000000077B90: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077B94: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 000000077B98: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 000000077BA0: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000077BA8: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000077BAC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 000000077BB4: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 000000077BC0: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 000000077BC8: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000077BCC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000077BD8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000077BE0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000077BE4: BE882004
	s_cbranch_execz 59308                                      // 000000077BE8: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x379c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 000000077BEC: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000077BF8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000077C00: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000077C04: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077C08: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000077C0C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000077C14: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000077C20: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000077C24: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000077C28: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000077C2C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000077C34: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000077C3C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000077C40: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000077C44: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000077C48: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077C4C: BF870095
	.long 0xd71c0022                                           // 000000077C50: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000077C54: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000077C58: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000077C5C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077C64: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 000000077C68: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000077C74: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077C78: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000077C7C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000077C84: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077C88: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000077C8C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000077C94: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000077C98: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077CA0: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 000000077CA4: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 000000077CA8: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077CB0: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 000000077CB4: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 000000077CB8: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077CC0: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 000000077CC4: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000077CCC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 000000077CD4: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077CE0: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000077CE4: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000077CEC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000077CF8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000077D00: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000077D04: BE882005
	s_cbranch_execz 59239                                      // 000000077D08: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37a8>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 000000077D0C: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000077D18: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000077D20: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000077D24: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077D28: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000077D2C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000077D34: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000077D40: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000077D44: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000077D48: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000077D4C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000077D54: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000077D5C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000077D60: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000077D64: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000077D68: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077D6C: BF870095
	.long 0xd71c0022                                           // 000000077D70: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000077D74: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000077D78: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000077D7C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077D84: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 000000077D88: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 000000077D90: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077D98: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000077D9C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000077DA4: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077DA8: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000077DAC: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000077DB4: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000077DB8: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077DC0: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000077DC4: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 000000077DC8: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077DD0: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 000000077DD4: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 000000077DD8: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077DE0: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000077DE4: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000077DEC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 000000077DF4: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077E00: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000077E04: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000077E0C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000077E18: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000077E20: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000077E24: BE882006
	s_cbranch_execz 59170                                      // 000000077E28: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37b4>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 000000077E2C: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000077E38: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000077E40: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000077E44: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077E48: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000077E4C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000077E54: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000077E60: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000077E64: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000077E68: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000077E6C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000077E74: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000077E7C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000077E80: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000077E84: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000077E88: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077E8C: BF870095
	.long 0xd71c0022                                           // 000000077E90: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000077E94: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000077E98: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000077E9C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077EA4: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 000000077EA8: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000077EB4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077EB8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000077EBC: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000077EC4: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077EC8: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000077ECC: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000077ED4: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000077ED8: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077EE0: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000077EE4: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000077EE8: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077EF0: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 000000077EF4: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000077EF8: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077F00: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000077F04: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000077F0C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 000000077F14: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077F20: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000077F24: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000077F2C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000077F38: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000077F40: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000077F44: BE882007
	s_cbranch_execz 59101                                      // 000000077F48: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37c0>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 000000077F4C: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000077F58: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000077F60: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000077F64: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077F68: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000077F6C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000077F74: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000077F80: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000077F84: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000077F88: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000077F8C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000077F94: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000077F9C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000077FA0: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000077FA4: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000077FA8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077FAC: BF870095
	.long 0xd71c0022                                           // 000000077FB0: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000077FB4: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000077FB8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000077FBC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077FC4: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 000000077FC8: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000077FD4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077FD8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000077FDC: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000077FE4: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077FE8: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000077FEC: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000077FF4: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000077FF8: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078000: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000078004: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000078008: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078010: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 000000078014: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000078018: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078020: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000078024: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000007802C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 000000078034: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078040: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000078044: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000007804C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000078058: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000078060: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000078064: BE882000
	s_cbranch_execz 59032                                      // 000000078068: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37cc>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 00000007806C: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 000000078078: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 00000007807C: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 000000078084: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000078088: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007808C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000078090: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000078098: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000780A4: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000780A8: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000780AC: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000780B0: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000780B8: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000780C0: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000780C4: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000780C8: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000780CC: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000780D0: BF870095
	.long 0xd71c0022                                           // 0000000780D4: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000780D8: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000780DC: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000780E0: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000780E8: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000000780EC: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000780F4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000780F8: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 0000000780FC: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 000000078104: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078108: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 00000007810C: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 000000078114: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 000000078118: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078120: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 000000078124: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 000000078128: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078130: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 000000078134: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 000000078138: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078140: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 000000078144: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 00000007814C: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 000000078154: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078160: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 000000078164: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 00000007816C: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 000000078178: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000078180: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000078184: BE882001
	s_cbranch_execz 58963                                      // 000000078188: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37d8>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 00000007818C: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 000000078198: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 00000007819C: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 0000000781A4: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000781A8: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000781AC: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 0000000781B0: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000781B8: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 0000000781C0: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000000781CC: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000781D0: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 0000000781D4: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 0000000781DC: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000781E0: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000000781E4: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 0000000781E8: 7E441123
	v_exp_f32_e32 v33, v33                                     // 0000000781EC: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000781F0: BF870095
	.long 0xd71c0021                                           // 0000000781F4: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000781F8: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000781FC: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000078200: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078208: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 00000007820C: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000078214: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078218: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 00000007821C: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 000000078224: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078228: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 00000007822C: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 000000078234: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 000000078238: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078240: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 000000078244: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 000000078248: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078250: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 000000078254: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 000000078258: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078260: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 000000078264: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 00000007826C: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 000000078274: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078280: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 000000078284: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 00000007828C: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 000000078298: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000782A0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000782A4: BE882002
	s_cbranch_execz 58894                                      // 0000000782A8: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37e4>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 0000000782AC: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000782B8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000782C0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000782C4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000782C8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000782CC: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 0000000782D4: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 0000000782E0: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000782E4: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 0000000782E8: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000782EC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 0000000782F4: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000782FC: BF870121
	v_add_f32_e32 v26, v26, v33                                // 000000078300: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 000000078304: 7E421122
	v_exp_f32_e32 v26, v26                                     // 000000078308: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007830C: BF870095
	.long 0xd71c001a                                           // 000000078310: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 000000078314: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000078318: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000007831C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078324: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 000000078328: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000078334: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078338: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000007833C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 000000078344: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078348: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 00000007834C: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 000000078354: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 000000078358: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078360: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 000000078364: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 000000078368: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078370: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 000000078374: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 000000078378: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078380: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 000000078384: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000007838C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 000000078394: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000783A0: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 0000000783A4: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 0000000783AC: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000783B8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000783C0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000783C4: BE882003
	s_cbranch_execz 58825                                      // 0000000783C8: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37f0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 0000000783CC: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000783D8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000783E0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000783E4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000783E8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000783EC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000783F4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 000000078400: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078404: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 000000078408: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 000000078414: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 000000078418: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000007841C: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000078424: BF870293
	v_exp_f32_e32 v26, v26                                     // 000000078428: 7E344B1A
	.long 0xd71c001a                                           // 00000007842C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000078430: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000078434: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000078438: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000007843C: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 000000078444: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078450: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 000000078454: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000078458: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000078460: BF870291
	v_rcp_f32_e32 v28, v27                                     // 000000078464: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 000000078468: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000078470: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 000000078474: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 000000078478: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 000000078480: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078484: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 000000078488: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 000000078490: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078494: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 000000078498: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 0000000784A0: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000784A8: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000784AC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 0000000784B4: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000784C0: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000784C8: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000784CC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000784D8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000784E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000784E4: BE882004
	s_cbranch_execz 58756                                      // 0000000784E8: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37fc>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 0000000784EC: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000784F8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000078500: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000078504: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078508: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000007850C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000078514: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000078520: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000078524: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000078528: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000007852C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000078534: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007853C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000078540: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000078544: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000078548: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007854C: BF870095
	.long 0xd71c001a                                           // 000000078550: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000078554: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000078558: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000007855C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078564: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 000000078568: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000078574: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078578: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000007857C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000078584: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078588: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000007858C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000078594: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000078598: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000785A0: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 0000000785A4: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 0000000785A8: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000785B0: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 0000000785B4: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 0000000785B8: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000785C0: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 0000000785C4: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000785CC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 0000000785D4: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000785E0: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000785E4: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000785EC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000785F8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000078600: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000078604: BE882005
	s_cbranch_execz 58687                                      // 000000078608: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3808>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 00000007860C: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000078618: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000078620: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000078624: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078628: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000007862C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000078634: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000078640: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000078644: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000078648: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000007864C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000078654: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007865C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000078660: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000078664: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000078668: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007866C: BF870095
	.long 0xd71c001a                                           // 000000078670: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000078674: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000078678: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000007867C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078684: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 000000078688: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 000000078690: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078698: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000007869C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000786A4: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000786A8: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000786AC: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000786B4: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000786B8: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000786C0: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000786C4: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 0000000786C8: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000786D0: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 0000000786D4: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 0000000786D8: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000786E0: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000786E4: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000786EC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 0000000786F4: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078700: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000078704: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000007870C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000078718: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000078720: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000078724: BE882006
	s_cbranch_execz 58618                                      // 000000078728: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3814>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 00000007872C: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000078738: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000078740: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000078744: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078748: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000007874C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000078754: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000078760: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000078764: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000078768: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000007876C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000078774: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007877C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000078780: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000078784: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000078788: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007878C: BF870095
	.long 0xd71c001a                                           // 000000078790: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000078794: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000078798: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000007879C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000787A4: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 0000000787A8: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000787B4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000787B8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000787BC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000787C4: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000787C8: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000787CC: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000787D4: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000787D8: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000787E0: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000787E4: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000787E8: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000787F0: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000787F4: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000787F8: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078800: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000078804: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000007880C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 000000078814: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078820: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000078824: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000007882C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000078838: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000078840: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000078844: BE882007
	s_cbranch_execz 58549                                      // 000000078848: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3820>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 00000007884C: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000078858: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000078860: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000078864: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078868: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000007886C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000078874: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000078880: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000078884: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000078888: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000007888C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000078894: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007889C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000788A0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000788A4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000788A8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000788AC: BF870095
	.long 0xd71c001a                                           // 0000000788B0: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000788B4: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000788B8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000788BC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000788C4: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 0000000788C8: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000788D4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000788D8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000788DC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000788E4: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000788E8: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000788EC: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000788F4: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000788F8: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078900: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 000000078904: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 000000078908: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078910: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 000000078914: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 000000078918: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078920: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000078924: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000007892C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 000000078934: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078940: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000078944: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000007894C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000078958: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000078960: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000078964: BE882000
	s_cbranch_execz 58480                                      // 000000078968: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x382c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 00000007896C: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 000000078978: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 00000007897C: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 000000078984: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000078988: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007898C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000078990: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000078998: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000789A4: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000789A8: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000789AC: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000789B0: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000789B8: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000789C0: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000789C4: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000789C8: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000789CC: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000789D0: BF870095
	.long 0xd71c001a                                           // 0000000789D4: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000789D8: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000789DC: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000789E0: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000789E8: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 0000000789EC: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000789F4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000789F8: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 0000000789FC: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 000000078A04: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078A08: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 000000078A0C: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 000000078A14: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 000000078A18: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078A20: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 000000078A24: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 000000078A28: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078A30: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 000000078A34: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 000000078A38: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078A40: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 000000078A44: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 000000078A4C: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 000000078A54: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078A60: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 000000078A64: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 000000078A6C: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 000000078A78: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 000000078A80: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000078A84: BE882001
	s_cbranch_execz 58411                                      // 000000078A88: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3838>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 000000078A8C: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 000000078A98: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 000000078A9C: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 000000078AA4: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000078AA8: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000078AAC: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 000000078AB0: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000078AB8: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 000000078AC0: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 000000078ACC: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000078AD0: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 000000078AD4: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 000000078ADC: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000078AE0: BF870121
	v_add_f32_e32 v25, v25, v26                                // 000000078AE4: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 000000078AE8: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 000000078AEC: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078AF0: BF870095
	.long 0xd71c0019                                           // 000000078AF4: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000078AF8: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000078AFC: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000078B00: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078B08: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 000000078B0C: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000078B14: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078B18: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 000000078B1C: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 000000078B24: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078B28: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 000000078B2C: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 000000078B34: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 000000078B38: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078B40: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 000000078B44: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 000000078B48: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078B50: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 000000078B54: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 000000078B58: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078B60: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 000000078B64: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 000000078B6C: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 000000078B74: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078B80: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 000000078B84: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 000000078B8C: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 000000078B98: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 000000078BA0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000078BA4: BE882002
	s_cbranch_execz 58342                                      // 000000078BA8: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3844>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 000000078BAC: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000078BB8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000078BC0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000078BC4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078BC8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000078BCC: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 000000078BD4: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 000000078BE0: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000078BE4: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 000000078BE8: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000078BEC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 000000078BF4: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000078BFC: BF870121
	v_add_f32_e32 v18, v18, v25                                // 000000078C00: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 000000078C04: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 000000078C08: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078C0C: BF870095
	.long 0xd71c0012                                           // 000000078C10: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 000000078C14: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000078C18: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000078C1C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078C24: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 000000078C28: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000078C34: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078C38: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000078C3C: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 000000078C44: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078C48: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 000000078C4C: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 000000078C54: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 000000078C58: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078C60: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 000000078C64: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 000000078C68: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078C70: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 000000078C74: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 000000078C78: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078C80: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 000000078C84: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000078C8C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 000000078C94: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078CA0: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 000000078CA4: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 000000078CAC: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000078CB8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000078CC0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000078CC4: BE882003
	s_cbranch_execz 58273                                      // 000000078CC8: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3850>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 000000078CCC: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000078CD8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000078CE0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000078CE4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078CE8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000078CEC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000078CF4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 000000078D00: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078D04: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 000000078D08: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 000000078D14: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 000000078D18: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000078D1C: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000078D24: BF870293
	v_exp_f32_e32 v18, v18                                     // 000000078D28: 7E244B12
	.long 0xd71c0012                                           // 000000078D2C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000078D30: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000078D34: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000078D38: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000078D3C: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 000000078D44: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078D50: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 000000078D54: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000078D58: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000078D60: BF870291
	v_rcp_f32_e32 v20, v19                                     // 000000078D64: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 000000078D68: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000078D70: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 000000078D74: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 000000078D78: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 000000078D80: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078D84: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 000000078D88: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 000000078D90: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078D94: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 000000078D98: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 000000078DA0: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000078DA8: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000078DAC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 000000078DB4: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 000000078DC0: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000078DC8: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000078DCC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000078DD8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000078DE0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000078DE4: BE882004
	s_cbranch_execz 58204                                      // 000000078DE8: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x385c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 000000078DEC: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000078DF8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000078E00: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000078E04: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078E08: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000078E0C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000078E14: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000078E20: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000078E24: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000078E28: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000078E2C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000078E34: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000078E3C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000078E40: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000078E44: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000078E48: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078E4C: BF870095
	.long 0xd71c0012                                           // 000000078E50: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000078E54: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000078E58: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000078E5C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078E64: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 000000078E68: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000078E74: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078E78: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000078E7C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000078E84: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078E88: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000078E8C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000078E94: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000078E98: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078EA0: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 000000078EA4: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 000000078EA8: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078EB0: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 000000078EB4: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 000000078EB8: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078EC0: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 000000078EC4: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000078ECC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 000000078ED4: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078EE0: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000078EE4: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000078EEC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000078EF8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000078F00: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000078F04: BE882005
	s_cbranch_execz 58135                                      // 000000078F08: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3868>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 000000078F0C: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000078F18: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000078F20: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000078F24: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078F28: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000078F2C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000078F34: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000078F40: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000078F44: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000078F48: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000078F4C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000078F54: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000078F5C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000078F60: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000078F64: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000078F68: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078F6C: BF870095
	.long 0xd71c0012                                           // 000000078F70: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000078F74: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000078F78: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000078F7C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078F84: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 000000078F88: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 000000078F90: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078F98: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000078F9C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000078FA4: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078FA8: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000078FAC: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000078FB4: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000078FB8: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078FC0: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 000000078FC4: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 000000078FC8: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078FD0: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 000000078FD4: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 000000078FD8: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078FE0: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000078FE4: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000078FEC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 000000078FF4: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079000: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000079004: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000007900C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000079018: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000079020: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000079024: BE882006
	s_cbranch_execz 58066                                      // 000000079028: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3874>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 00000007902C: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000079038: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000079040: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000079044: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079048: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000007904C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000079054: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000079060: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000079064: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000079068: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000007906C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000079074: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007907C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000079080: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000079084: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000079088: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007908C: BF870095
	.long 0xd71c0012                                           // 000000079090: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000079094: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000079098: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000007909C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000790A4: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 0000000790A8: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000790B4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000790B8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000790BC: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000790C4: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000790C8: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000790CC: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000790D4: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000790D8: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000790E0: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000790E4: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000790E8: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000790F0: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000790F4: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000790F8: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079100: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000079104: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000007910C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 000000079114: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079120: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000079124: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000007912C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000079138: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000079140: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000079144: BE882007
	s_cbranch_execz 57997                                      // 000000079148: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3880>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 00000007914C: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000079158: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000079160: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000079164: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079168: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000007916C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000079174: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000079180: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000079184: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000079188: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000007918C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000079194: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007919C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000791A0: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000791A4: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000791A8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000791AC: BF870095
	.long 0xd71c0012                                           // 0000000791B0: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000791B4: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000791B8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000791BC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000791C4: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 0000000791C8: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000791D4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000791D8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000791DC: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000791E4: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000791E8: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000791EC: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000791F4: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000791F8: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079200: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 000000079204: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 000000079208: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079210: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 000000079214: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 000000079218: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079220: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000079224: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000007922C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 000000079234: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079240: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000079244: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000007924C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000079258: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000079260: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000079264: BE882000
	s_cbranch_execz 57928                                      // 000000079268: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x388c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 00000007926C: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 000000079278: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 00000007927C: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000079284: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000079288: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007928C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000079290: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000079298: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000792A4: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000792A8: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000792AC: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000792B0: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000792B8: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000792C0: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000792C4: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000792C8: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000792CC: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000792D0: BF870095
	.long 0xd71c0012                                           // 0000000792D4: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000792D8: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000792DC: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000792E0: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000792E8: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000792EC: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000792F4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000792F8: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 0000000792FC: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 000000079304: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079308: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 00000007930C: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 000000079314: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 000000079318: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079320: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 000000079324: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 000000079328: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079330: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 000000079334: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 000000079338: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079340: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 000000079344: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 00000007934C: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 000000079354: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079360: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 000000079364: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 00000007936C: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 000000079378: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 000000079380: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000079384: BE882001
	s_cbranch_execz 57859                                      // 000000079388: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3898>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 00000007938C: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 000000079398: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 00000007939C: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 0000000793A4: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000793A8: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000793AC: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 0000000793B0: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000793B8: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 0000000793C0: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 0000000793CC: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000793D0: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 0000000793D4: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 0000000793DC: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000793E0: BF870121
	v_add_f32_e32 v17, v17, v18                                // 0000000793E4: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 0000000793E8: 7E241113
	v_exp_f32_e32 v17, v17                                     // 0000000793EC: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000793F0: BF870095
	.long 0xd71c0011                                           // 0000000793F4: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000000793F8: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000000793FC: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000079400: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079408: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 00000007940C: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000079414: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079418: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 00000007941C: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 000000079424: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079428: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 00000007942C: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 000000079434: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 000000079438: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079440: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 000000079444: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 000000079448: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079450: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 000000079454: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 000000079458: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079460: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 000000079464: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 00000007946C: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 000000079474: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079480: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 000000079484: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 00000007948C: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 000000079498: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000794A0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000794A4: BE882002
	s_cbranch_execz 57790                                      // 0000000794A8: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38a4>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 0000000794AC: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000794B8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000794C0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000794C4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000794C8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000794CC: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 0000000794D4: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 0000000794E0: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000794E4: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 0000000794E8: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000794EC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 0000000794F4: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000794FC: BF870121
	v_add_f32_e32 v10, v10, v17                                // 000000079500: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 000000079504: 7E221112
	v_exp_f32_e32 v10, v10                                     // 000000079508: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007950C: BF870095
	.long 0xd71c000a                                           // 000000079510: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 000000079514: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000079518: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000007951C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079524: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 000000079528: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000079534: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079538: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000007953C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 000000079544: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079548: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 00000007954C: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 000000079554: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 000000079558: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079560: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 000000079564: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 000000079568: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079570: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 000000079574: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 000000079578: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079580: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 000000079584: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000007958C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 000000079594: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000795A0: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 0000000795A4: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 0000000795AC: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000795B8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000795C0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000795C4: BE882003
	s_cbranch_execz 57721                                      // 0000000795C8: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38b0>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 0000000795CC: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000795D8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000795E0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000795E4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000795E8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000795EC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000795F4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 000000079600: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079604: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 000000079608: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 000000079614: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 000000079618: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000007961C: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000079624: BF870293
	v_exp_f32_e32 v10, v10                                     // 000000079628: 7E144B0A
	.long 0xd71c000a                                           // 00000007962C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000079630: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000079634: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000079638: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000007963C: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 000000079644: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079650: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 000000079654: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000079658: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000079660: BF870291
	v_rcp_f32_e32 v12, v11                                     // 000000079664: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 000000079668: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000079670: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 000000079674: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 000000079678: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 000000079680: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079684: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 000000079688: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 000000079690: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079694: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 000000079698: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 0000000796A0: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000796A8: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000796AC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 0000000796B4: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000796C0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000796C8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000796CC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000796D8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000796E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000796E4: BE882004
	s_cbranch_execz 57652                                      // 0000000796E8: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38bc>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 0000000796EC: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000796F8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000079700: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000079704: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079708: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000007970C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000079714: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000079720: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000079724: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000079728: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000007972C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000079734: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007973C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000079740: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000079744: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000079748: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007974C: BF870095
	.long 0xd71c000a                                           // 000000079750: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000079754: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000079758: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000007975C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079764: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 000000079768: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000079774: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079778: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000007977C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000079784: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079788: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000007978C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000079794: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000079798: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000797A0: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 0000000797A4: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 0000000797A8: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000797B0: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 0000000797B4: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 0000000797B8: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000797C0: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 0000000797C4: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000797CC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 0000000797D4: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000797E0: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000797E4: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000797EC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000797F8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000079800: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000079804: BE882005
	s_cbranch_execz 57583                                      // 000000079808: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38c8>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 00000007980C: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000079818: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000079820: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000079824: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079828: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000007982C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000079834: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000079840: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000079844: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000079848: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000007984C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000079854: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007985C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000079860: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000079864: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000079868: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007986C: BF870095
	.long 0xd71c000a                                           // 000000079870: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000079874: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000079878: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000007987C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079884: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000079888: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 000000079890: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079898: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000007989C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000798A4: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000798A8: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000798AC: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000798B4: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000798B8: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000798C0: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000798C4: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 0000000798C8: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000798D0: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 0000000798D4: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 0000000798D8: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000798E0: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000798E4: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000798EC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 0000000798F4: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079900: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000079904: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000007990C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000079918: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000079920: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000079924: BE882006
	s_cbranch_execz 57514                                      // 000000079928: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38d4>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 00000007992C: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000079938: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000079940: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000079944: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079948: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000007994C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000079954: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000079960: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000079964: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000079968: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000007996C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000079974: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007997C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000079980: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000079984: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000079988: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007998C: BF870095
	.long 0xd71c000a                                           // 000000079990: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000079994: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000079998: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000007999C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000799A4: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 0000000799A8: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000799B4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000799B8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000799BC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000799C4: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000799C8: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000799CC: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000799D4: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000799D8: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000799E0: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000799E4: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000000799E8: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000799F0: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000799F4: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000799F8: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079A00: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000079A04: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000079A0C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 000000079A14: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079A20: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000079A24: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000079A2C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000079A38: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000079A40: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000079A44: BE882007
	s_cbranch_execz 57445                                      // 000000079A48: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38e0>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 000000079A4C: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000079A58: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000079A60: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000079A64: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079A68: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000079A6C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000079A74: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000079A80: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000079A84: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000079A88: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000079A8C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000079A94: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000079A9C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000079AA0: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000079AA4: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000079AA8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079AAC: BF870095
	.long 0xd71c000a                                           // 000000079AB0: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000079AB4: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000079AB8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000079ABC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079AC4: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 000000079AC8: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000079AD4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079AD8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000079ADC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000079AE4: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079AE8: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000079AEC: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000079AF4: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000079AF8: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079B00: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000079B04: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000079B08: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079B10: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000079B14: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000079B18: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079B20: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000079B24: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000079B2C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 000000079B34: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079B40: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000079B44: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000079B4C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000079B58: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000079B60: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000079B64: BE882000
	s_cbranch_execz 57376                                      // 000000079B68: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38ec>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 000000079B6C: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 000000079B78: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 000000079B7C: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000079B84: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000079B88: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079B8C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000079B90: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000079B98: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000079BA4: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000079BA8: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000079BAC: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000079BB0: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000079BB8: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000079BC0: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000079BC4: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000079BC8: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000079BCC: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079BD0: BF870095
	.long 0xd71c000a                                           // 000000079BD4: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000079BD8: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000079BDC: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000079BE0: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079BE8: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000079BEC: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000079BF4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079BF8: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 000000079BFC: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 000000079C04: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079C08: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 000000079C0C: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 000000079C14: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 000000079C18: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079C20: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 000000079C24: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 000000079C28: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079C30: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 000000079C34: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 000000079C38: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079C40: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 000000079C44: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 000000079C4C: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 000000079C54: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079C60: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 000000079C64: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 000000079C6C: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 000000079C78: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 000000079C80: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000079C84: BE802001
	s_cbranch_execz 57307                                      // 000000079C88: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38f8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 000000079C8C: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000079C98: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000079CA0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000079CA4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079CA8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000079CAC: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 000000079CB4: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 000000079CC0: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000079CC4: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 000000079CC8: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 000000079CCC: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000079CD4: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000079CDC: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 000000079CE0: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 000000079CE4: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 000000079CE8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079CEC: BF870095
	.long 0xd71c0001                                           // 000000079CF0: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 000000079CF4: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000079CF8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000079CFC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079D04: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 000000079D08: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000079D14: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079D18: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000079D1C: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 000000079D24: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079D28: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 000000079D2C: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 000000079D34: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 000000079D38: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079D40: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 000000079D44: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 000000079D48: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079D50: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 000000079D54: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 000000079D58: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079D60: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 000000079D64: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000079D6C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 000000079D74: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079D80: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 000000079D84: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 000000079D8C: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000079D98: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000079DA0: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 000000079DA4: BE802002
	s_cbranch_execz 57238                                      // 000000079DA8: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3904>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 000000079DAC: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000079DB8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000079DC0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000079DC4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079DC8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000079DCC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000079DD4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 000000079DE0: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000079DE4: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 000000079DE8: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000079DEC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000079DF4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000079DFC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000079E00: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 000000079E04: 7E041109
	v_exp_f32_e32 v1, v1                                       // 000000079E08: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079E0C: BF870095
	.long 0xd71c0001                                           // 000000079E10: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000079E14: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000079E18: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000079E1C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079E24: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 000000079E28: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000079E34: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079E38: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000079E3C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000079E44: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079E48: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 000000079E4C: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 000000079E54: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 000000079E58: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079E60: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 000000079E64: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 000000079E68: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079E70: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 000000079E74: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 000000079E78: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079E80: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 000000079E84: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000079E8C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 000000079E94: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079EA0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000079EA4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000079EAC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000079EB8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000079EC0: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 000000079EC4: BE802003
	s_cbranch_execz 57169                                      // 000000079EC8: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3910>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 000000079ECC: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000079ED8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000079EE0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000079EE4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079EE8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000079EEC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000079EF4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000079F00: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000079F04: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000079F08: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000079F0C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000079F14: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000079F1C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000079F20: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000079F24: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000079F28: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079F2C: BF870095
	.long 0xd71c0001                                           // 000000079F30: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000079F34: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000079F38: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000079F3C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079F44: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 000000079F48: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000079F54: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079F58: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000079F5C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000079F64: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079F68: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000079F6C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000079F74: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000079F78: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079F80: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 000000079F84: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 000000079F88: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079F90: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 000000079F94: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 000000079F98: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079FA0: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 000000079FA4: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000079FAC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 000000079FB4: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079FC0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000079FC4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000079FCC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000079FD8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000079FE0: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000079FE4: BE802004
	s_cbranch_execz 57100                                      // 000000079FE8: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x391c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 000000079FEC: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000079FF8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000007A000: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000007A004: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A008: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000007A00C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000007A014: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000007A020: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007A024: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000007A028: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000007A02C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000007A034: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007A03C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000007A040: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000007A044: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000007A048: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A04C: BF870095
	.long 0xd71c0001                                           // 00000007A050: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000007A054: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000007A058: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000007A05C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A064: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 00000007A068: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 00000007A070: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A078: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000007A07C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000007A084: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A088: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000007A08C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000007A094: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000007A098: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A0A0: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000007A0A4: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 00000007A0A8: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A0B0: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 00000007A0B4: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 00000007A0B8: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A0C0: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000007A0C4: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000007A0CC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 00000007A0D4: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A0E0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000007A0E4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000007A0EC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000007A0F8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000007A100: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000007A104: BE802005
	s_cbranch_execz 57031                                      // 00000007A108: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3928>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 00000007A10C: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000007A118: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000007A120: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000007A124: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A128: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000007A12C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000007A134: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000007A140: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007A144: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000007A148: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000007A14C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000007A154: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007A15C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000007A160: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000007A164: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000007A168: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A16C: BF870095
	.long 0xd71c0001                                           // 00000007A170: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000007A174: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000007A178: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000007A17C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A184: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 00000007A188: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000007A194: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A198: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000007A19C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000007A1A4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A1A8: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000007A1AC: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000007A1B4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000007A1B8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A1C0: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000007A1C4: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000007A1C8: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A1D0: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000007A1D4: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000007A1D8: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A1E0: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000007A1E4: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000007A1EC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 00000007A1F4: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A200: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000007A204: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000007A20C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000007A218: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000007A220: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000007A224: BE802006
	s_cbranch_execz 56962                                      // 00000007A228: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3934>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 00000007A22C: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000007A238: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000007A240: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000007A244: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A248: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000007A24C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000007A254: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000007A260: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007A264: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000007A268: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000007A26C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000007A274: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007A27C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000007A280: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000007A284: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000007A288: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A28C: BF870095
	.long 0xd71c0001                                           // 00000007A290: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000007A294: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000007A298: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000007A29C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A2A4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 00000007A2A8: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000007A2B4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A2B8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000007A2BC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000007A2C4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A2C8: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000007A2CC: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000007A2D4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000007A2D8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A2E0: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000007A2E4: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000007A2E8: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A2F0: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000007A2F4: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000007A2F8: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A300: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000007A304: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000007A30C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 00000007A314: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A320: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000007A324: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000007A32C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000007A338: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000007A340: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000007A344: BE802007
	s_cbranch_execz 56893                                      // 00000007A348: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3940>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 00000007A34C: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000007A358: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000007A360: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000007A364: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A368: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000007A36C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000007A374: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000007A380: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007A384: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000007A388: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000007A38C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000007A394: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007A39C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000007A3A0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000007A3A4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000007A3A8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A3AC: BF870095
	.long 0xd71c0001                                           // 00000007A3B0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000007A3B4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000007A3B8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000007A3BC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A3C4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 00000007A3C8: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000007A3D4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A3D8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000007A3DC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000007A3E4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A3E8: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000007A3EC: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000007A3F4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000007A3F8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A400: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000007A404: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000007A408: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A410: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000007A414: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000007A418: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A420: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000007A424: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000007A42C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 00000007A434: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A440: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000007A444: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000007A44C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000007A458: DC9601E0 007C0200
	s_nop 0                                                    // 00000007A460: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000007A464: BFB60003
	s_endpgm                                                   // 00000007A468: BFB00000
		...

