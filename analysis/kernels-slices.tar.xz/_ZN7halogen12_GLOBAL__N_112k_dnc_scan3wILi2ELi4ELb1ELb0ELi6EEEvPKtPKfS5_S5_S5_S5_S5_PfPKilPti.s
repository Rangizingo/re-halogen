0000000000160100 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_load_b512 s[12:27], s[0:1], 0x18                         // 000000160100: F4100300 F8000018
	s_lshl_b32 s4, s3, 6                                       // 000000160108: 84048603
	s_ashr_i32 s3, s2, 31                                      // 00000016010C: 86039F02
	s_ashr_i32 s5, s4, 31                                      // 000000160110: 86059F04
	v_and_b32_e32 v75, 63, v0                                  // 000000160114: 369600BF
	s_movk_i32 s7, 0x210                                       // 000000160118: B0070210
	v_mov_b32_e32 v3, v0                                       // 00000016011C: 7E060300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000160120: BF8704D2
	v_lshlrev_b32_e32 v1, 2, v75                               // 000000160124: 30029682
	v_mad_u32_u24 v76, v75, s7, 0x2800                         // 000000160128: D60B004C 03FC0F4B 00002800
	s_waitcnt lgkmcnt(0)                                       // 000000160134: BF89FC07
	s_load_b32 s6, s[22:23], null                              // 000000160138: F400018B F8000000
	s_lshl_b64 s[22:23], s[24:25], 2                           // 000000160140: 84968218
	s_add_u32 s8, s20, s22                                     // 000000160144: 80081614
	s_addc_u32 s9, s21, s23                                    // 000000160148: 82091715
	s_lshl_b64 s[34:35], s[2:3], 16                            // 00000016014C: 84A29002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000160150: BF870009
	s_add_u32 s8, s8, s34                                      // 000000160154: 80082208
	s_addc_u32 s9, s9, s35                                     // 000000160158: 82092309
	s_waitcnt lgkmcnt(0)                                       // 00000016015C: BF89FC07
	s_mul_i32 s40, s6, 0x9000000                               // 000000160160: 9628FF06 09000000
	s_mul_hi_i32 s33, s6, 0x9000000                            // 000000160168: 9721FF06 09000000
	s_add_u32 s6, s8, s40                                      // 000000160170: 80062808
	s_addc_u32 s8, s9, s33                                     // 000000160174: 82082109
	s_lshl_b64 s[36:37], s[4:5], 2                             // 000000160178: 84A48204
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000016017C: BF8700B9
	s_add_u32 s6, s6, s36                                      // 000000160180: 80062406
	s_addc_u32 s7, s8, s37                                     // 000000160184: 82072508
	.long 0xd7000601                                           // 000000160188: D7000601
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 00000016018C: 02020206
	v_add_co_ci_u32_e64 v2, null, s7, 0, s6                    // 000000160190: D5207C02 00190007
	s_mov_b32 s6, 0                                            // 000000160198: BE860080
	s_nop 0                                                    // 00000016019C: BF800000
	s_nop 0                                                    // 0000001601A0: BF800000
	s_nop 0                                                    // 0000001601A4: BF800000
	s_nop 0                                                    // 0000001601A8: BF800000
	s_nop 0                                                    // 0000001601AC: BF800000
	s_nop 0                                                    // 0000001601B0: BF800000
	s_nop 0                                                    // 0000001601B4: BF800000
	s_nop 0                                                    // 0000001601B8: BF800000
	s_nop 0                                                    // 0000001601BC: BF800000
	v_lshrrev_b32_e32 v6, 6, v3                                // 0000001601C0: 320C0686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001601C4: BF870121
	v_lshlrev_b32_e32 v4, 9, v6                                // 0000001601C8: 30080C89
	v_lshl_add_u32 v6, v6, 2, v76                              // 0000001601CC: D6460006 05310506
	.long 0xd7006a04                                           // 0000001601D4: D7006A04
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 0000001601D8: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001601DC: BF8700D1
	v_add_co_ci_u32_e64 v5, null, 0, v2, vcc_lo                // 0000001601E0: D5207C05 01AA0480
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v3                        // 0000001601E8: 7C9206FF 00001F7F
	global_load_b32 v4, v[4:5], off                            // 0000001601F0: DC520000 047C0004
	v_add_nc_u32_e32 v5, 0x80, v3                              // 0000001601F8: 4A0A06FF 00000080
	s_or_b32 s6, vcc_lo, s6                                    // 000000160200: 8C06066A
	v_mov_b32_e32 v3, v5                                       // 000000160204: 7E060305
	s_waitcnt vmcnt(0)                                         // 000000160208: BF8903F7
	ds_store_b32 v6, v4                                        // 00000016020C: D8340000 00000406
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000160214: 917E067E
	s_cbranch_execnz 65513                                     // 000000160218: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000016021C: 8C7E067E
	s_load_b32 s41, s[0:1], 0x58                               // 000000160220: F4000A40 F8000058
	v_lshrrev_b32_e32 v77, 4, v0                               // 000000160228: 329A0084
	s_waitcnt lgkmcnt(0)                                       // 00000016022C: BF89FC07
	s_barrier                                                  // 000000160230: BFBD0000
	buffer_gl0_inv                                             // 000000160234: E0AC0000 00000000
	s_cmp_lt_i32 s41, 1                                        // 00000016023C: BF048129
	s_cbranch_scc1 6004                                        // 000000160240: BFA21774 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f14>
	s_load_b64 s[38:39], s[0:1], 0x8                           // 000000160244: F4040980 F8000008
	s_add_i32 s0, s41, 63                                      // 00000016024C: 8100BF29
	s_add_i32 s42, s2, 0xbd0                                   // 000000160250: 812AFF02 00000BD0
	s_lshr_b32 s43, s0, 6                                      // 000000160258: 852B8600
	s_add_u32 s6, s14, s36                                     // 00000016025C: 8006240E
	s_addc_u32 s7, s15, s37                                    // 000000160260: 8207250F
	s_mov_b32 s15, 0                                           // 000000160264: BE8F0080
	v_lshrrev_b32_e32 v78, 5, v0                               // 000000160268: 329C0085
	s_mov_b32 s24, s15                                         // 00000016026C: BE98000F
	s_mov_b32 s25, s15                                         // 000000160270: BE99000F
	s_mov_b32 s28, s15                                         // 000000160274: BE9C000F
	s_mov_b32 s29, s15                                         // 000000160278: BE9D000F
	s_mov_b32 s30, s15                                         // 00000016027C: BE9E000F
	s_mov_b32 s31, s15                                         // 000000160280: BE9F000F
	v_lshlrev_b32_e32 v2, 8, v0                                // 000000160284: 30040088
	v_and_b32_e32 v3, 15, v0                                   // 000000160288: 3606008F
	s_movk_i32 s0, 0x210                                       // 00000016028C: B0000210
	v_lshl_or_b32 v79, v0, 2, 0xac00                           // 000000160290: D656004F 03FD0500 0000AC00
	s_mov_b32 s44, 0x41800000                                  // 00000016029C: BEAC00FF 41800000
	v_and_b32_e32 v2, 0xf00, v2                                // 0000001602A4: 360404FF 00000F00
	v_mad_u32_u24 v81, v3, s0, 0x2800                          // 0000001602AC: D60B0051 03FC0103 00002800
	s_lshl_b32 s0, s2, 7                                       // 0000001602B8: 84008702
	v_mul_u32_u24_e32 v85, 0xa0, v3                            // 0000001602BC: 16AA06FF 000000A0
	s_ashr_i32 s1, s0, 31                                      // 0000001602C4: 86019F00
	v_lshl_or_b32 v2, v78, 12, v2                              // 0000001602C8: D6560002 0409194E
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000001602D0: 84808100
	s_mov_b32 s45, 0                                           // 0000001602D4: BEAD0080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000001602D8: 7C9800C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001602DC: BF870092
	.long 0xd7000853                                           // 0000001602E0: D7000853
	v_cndmask_b32_e32 v1, s18, v2, vcc_lo                      // 0000001602E4: 02020412
	v_add_co_ci_u32_e64 v84, null, s19, 0, s8                  // 0000001602E8: D5207C54 00210013
	s_add_u32 s8, s26, s0                                      // 0000001602F0: 8008001A
	s_addc_u32 s9, s27, s1                                     // 0000001602F4: 8209011B
	s_mov_b32 s26, s15                                         // 0000001602F8: BE9A000F
	s_mov_b32 s27, s15                                         // 0000001602FC: BE9B000F
	v_lshlrev_b32_e32 v1, 4, v78                               // 000000160300: 30029C84
	v_lshlrev_b32_e32 v2, 1, v3                                // 000000160304: 30040681
	s_lshl_b64 s[0:1], s[4:5], 1                               // 000000160308: 84808104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016030C: BF870119
	s_add_u32 s0, s8, s0                                       // 000000160310: 80000008
	v_or_b32_e32 v80, v1, v3                                   // 000000160314: 38A00701
	v_and_or_b32 v82, v77, 1, v1                               // 000000160318: D6570052 0405034D
	v_lshlrev_b32_e32 v1, 2, v3                                // 000000160320: 30020682
	s_addc_u32 s1, s9, s1                                      // 000000160324: 82010109
	.long 0xd7000049                                           // 000000160328: D7000049
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 00000016032C: 02020400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000160330: BF870193
	v_lshl_add_u32 v88, v82, 1, v85                            // 000000160334: D6460058 05550352
	.long 0xd7000456                                           // 00000016033C: D7000456
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 000000160340: 02020206
	v_mov_b32_e32 v1, s24                                      // 000000160344: 7E020218
	v_add_co_ci_u32_e64 v87, null, s7, 0, s4                   // 000000160348: D5207C57 00110007
	v_add_co_ci_u32_e64 v74, null, s1, 0, s0                   // 000000160350: D5207C4A 00010001
	v_lshl_or_b32 v89, v82, 2, 0xac00                          // 000000160358: D6560059 03FD0552 0000AC00
	v_dual_mov_b32 v2, s25 :: v_dual_mov_b32 v3, s26           // 000000160364: CA100019 0202001A
	v_dual_mov_b32 v4, s27 :: v_dual_mov_b32 v5, s28           // 00000016036C: CA10001B 0404001C
	v_dual_mov_b32 v6, s29 :: v_dual_mov_b32 v7, s30           // 000000160374: CA10001D 0606001E
	v_mov_b32_e32 v8, s31                                      // 00000016037C: 7E10021F
	s_mul_i32 s0, s45, 0xc00                                   // 000000160380: 9600FF2D 00000C00
	s_lshl_b32 s4, s45, 6                                      // 000000160388: 8404862D
	s_add_i32 s0, s42, s0                                      // 00000016038C: 8100002A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000160390: BF870499
	s_ashr_i32 s1, s0, 31                                      // 000000160394: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 000000160398: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000016039C: BF870009
	s_add_u32 s0, s12, s0                                      // 0000001603A0: 8000000C
	s_addc_u32 s1, s13, s1                                     // 0000001603A4: 8201010D
	s_load_b32 s46, s[0:1], null                               // 0000001603A8: F4000B80 F8000000
	s_and_saveexec_b32 s1, vcc_lo                              // 0000001603B0: BE81206A
	s_cbranch_execz 46                                         // 0000001603B4: BFA5002E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x370>
	v_or_b32_e32 v9, s4, v0                                    // 0000001603B8: 38120004
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001603BC: BF870091
	v_mad_u64_u32 v[9:10], null, v9, 48, s[2:3]                // 0000001603C0: D6FE7C09 00096109
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000001603C8: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001603CC: BF870091
	.long 0xd73c0009                                           // 0000001603D0: D73C0009
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 0000001603D4: 02021282
	.long 0xd7000009                                           // 0000001603D8: D7000009
	v_cndmask_b32_e32 v1, s12, v9, vcc_lo                      // 0000001603DC: 0202120C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000001603E0: BF870151
	v_add_co_ci_u32_e64 v10, null, s13, v10, s0                // 0000001603E4: D5207C0A 0002140D
	global_load_b32 v9, v[9:10], off                           // 0000001603EC: DC520000 097C0009
	s_waitcnt vmcnt(0)                                         // 0000001603F4: BF8903F7
	v_mul_f32_e32 v10, 0x3fb8aa3b, v9                          // 0000001603F8: 101412FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000160400: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v9, vcc_lo               // 000000160404: 020212FF C2CE8ED0
	v_fma_f32 v11, 0x3fb8aa3b, v9, -v10                        // 00000016040C: D613000B 842A12FF 3FB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000160418: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016041C: BF870091
	v_dual_fmac_f32 v11, 0x32a5705f, v9 :: v_dual_sub_f32 v10, v10, v12// 000000160420: C80A12FF 0B0A190A 32A5705F
	v_add_f32_e32 v10, v10, v11                                // 00000016042C: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000160430: 7E16110C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000160434: BF870292
	v_exp_f32_e32 v10, v10                                     // 000000160438: 7E144B0A
	.long 0xd71c000a                                           // 00000016043C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000160440: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000160444: BF8700A1
	v_cndmask_b32_e64 v10, 0, v10, s0                          // 000000160448: D501000A 00021480
	.long 0xd41e0000                                           // 000000160450: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v9, vcc_lo               // 000000160454: 020212FF 42B17218
	v_cndmask_b32_e64 v9, 0x7f800000, v10, s0                  // 00000016045C: D5010009 000214FF 7F800000
	ds_store_b32 v79, v9                                       // 000000160468: D8340000 0000094F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000160470: 8C7E017E
	v_add_nc_u32_e32 v11, s4, v80                              // 000000160474: 4A16A004
	.long 0x7f683880                                           // 000000160478: 7F683880
	s_waitcnt lgkmcnt(0)                                       // 00000016047C: BF89FC07
	s_barrier                                                  // 000000160480: BFBD0000
	buffer_gl0_inv                                             // 000000160484: E0AC0000 00000000
	v_mad_u64_u32 v[9:10], null, v11, 48, s[2:3]               // 00000016048C: D6FE7C09 0009610B
	.long 0xd4440000                                           // 000000160494: D4440000
	v_cndmask_b32_e32 v1, s41, v11, vcc_lo                     // 000000160498: 02021629
	.long 0x7f6439b4                                           // 00000016049C: 7F6439B4
	.long 0x7e6439b4                                           // 0000001604A0: 7E6439B4
	.long 0x7f6239b4                                           // 0000001604A4: 7F6239B4
	.long 0x7e6239b4                                           // 0000001604A8: 7E6239B4
	.long 0xd73c003b                                           // 0000001604AC: D73C003B
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 0000001604B0: 02021289
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001604B4: BF870091
	.long 0xd700013d                                           // 0000001604B8: D700013D
	v_cndmask_b32_e32 v1, s16, v59, vcc_lo                     // 0000001604BC: 02027610
	v_add_co_ci_u32_e64 v62, null, s17, v60, s1                // 0000001604C0: D5207C3E 00067811
	s_and_saveexec_b32 s1, s0                                  // 0000001604C8: BE812000
	s_cbranch_execz 11                                         // 0000001604CC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3fc>
	global_load_b128 v[9:12], v[61:62], off                    // 0000001604D0: DC5E0000 097C003D
	s_waitcnt vmcnt(0)                                         // 0000001604D8: BF8903F7
	v_fma_mixlo_f16 v49, v9, s44, 0                            // 0000001604DC: CC210031 02005909
	v_fma_mixhi_f16 v49, v10, s44, 0                           // 0000001604E4: CC220031 0200590A
	v_fma_mixlo_f16 v50, v11, s44, 0                           // 0000001604EC: CC210032 0200590B
	v_fma_mixhi_f16 v50, v12, s44, 0                           // 0000001604F4: CC220032 0200590C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001604FC: 8C7E017E
	.long 0x7e6839b4                                           // 000000160500: 7E6839B4
	.long 0x7f6639b4                                           // 000000160504: 7F6639B4
	.long 0x7e6639b4                                           // 000000160508: 7E6639B4
	s_and_saveexec_b32 s1, s0                                  // 00000016050C: BE812000
	s_cbranch_execz 11                                         // 000000160510: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x440>
	global_load_b128 v[9:12], v[61:62], off offset:16          // 000000160514: DC5E0010 097C003D
	s_waitcnt vmcnt(0)                                         // 00000016051C: BF8903F7
	v_fma_mixlo_f16 v51, v9, s44, 0                            // 000000160520: CC210033 02005909
	v_fma_mixhi_f16 v51, v10, s44, 0                           // 000000160528: CC220033 0200590A
	v_fma_mixlo_f16 v52, v11, s44, 0                           // 000000160530: CC210034 0200590B
	v_fma_mixhi_f16 v52, v12, s44, 0                           // 000000160538: CC220034 0200590C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000160540: 8C7E017E
	.long 0x7f703880                                           // 000000160544: 7F703880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000160548: BF870001
	.long 0x7f6c39b8                                           // 00000016054C: 7F6C39B8
	.long 0x7e6c39b8                                           // 000000160550: 7E6C39B8
	.long 0x7f6a39b8                                           // 000000160554: 7F6A39B8
	.long 0x7e6a39b8                                           // 000000160558: 7E6A39B8
	s_and_saveexec_b32 s1, s0                                  // 00000016055C: BE812000
	s_cbranch_execz 11                                         // 000000160560: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x490>
	global_load_b128 v[9:12], v[61:62], off offset:32          // 000000160564: DC5E0020 097C003D
	s_waitcnt vmcnt(0)                                         // 00000016056C: BF8903F7
	v_fma_mixlo_f16 v53, v9, s44, 0                            // 000000160570: CC210035 02005909
	v_fma_mixhi_f16 v53, v10, s44, 0                           // 000000160578: CC220035 0200590A
	v_fma_mixlo_f16 v54, v11, s44, 0                           // 000000160580: CC210036 0200590B
	v_fma_mixhi_f16 v54, v12, s44, 0                           // 000000160588: CC220036 0200590C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000160590: 8C7E017E
	.long 0x7e7039b8                                           // 000000160594: 7E7039B8
	.long 0x7f6e39b8                                           // 000000160598: 7F6E39B8
	.long 0x7e6e39b8                                           // 00000016059C: 7E6E39B8
	s_and_saveexec_b32 s1, s0                                  // 0000001605A0: BE812000
	s_cbranch_execz 11                                         // 0000001605A4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4d4>
	global_load_b128 v[9:12], v[61:62], off offset:48          // 0000001605A8: DC5E0030 097C003D
	s_waitcnt vmcnt(0)                                         // 0000001605B0: BF8903F7
	v_fma_mixlo_f16 v55, v9, s44, 0                            // 0000001605B4: CC210037 02005909
	v_fma_mixhi_f16 v55, v10, s44, 0                           // 0000001605BC: CC220037 0200590A
	v_fma_mixlo_f16 v56, v11, s44, 0                           // 0000001605C4: CC210038 0200590B
	v_fma_mixhi_f16 v56, v12, s44, 0                           // 0000001605CC: CC220038 0200590C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001605D4: 8C7E017E
	ds_load_b128 v[9:12], v81                                  // 0000001605D8: DBFC0000 09000051
	ds_load_b128 v[13:16], v81 offset:16                       // 0000001605E0: DBFC0010 0D000051
	ds_load_b128 v[17:20], v81 offset:32                       // 0000001605E8: DBFC0020 11000051
	ds_load_b128 v[21:24], v81 offset:48                       // 0000001605F0: DBFC0030 15000051
	ds_load_b128 v[25:28], v81 offset:8448                     // 0000001605F8: DBFC2100 19000051
	ds_load_b128 v[29:32], v81 offset:8464                     // 000000160600: DBFC2110 1D000051
	ds_load_b128 v[33:36], v81 offset:8480                     // 000000160608: DBFC2120 21000051
	ds_load_b128 v[37:40], v81 offset:8496                     // 000000160610: DBFC2130 25000051
	ds_load_b128 v[41:44], v81 offset:16896                    // 000000160618: DBFC4200 29000051
	ds_load_b128 v[45:48], v81 offset:16912                    // 000000160620: DBFC4210 2D000051
	ds_load_b128 v[63:66], v81 offset:16928                    // 000000160628: DBFC4220 3F000051
	ds_load_b128 v[67:70], v81 offset:16944                    // 000000160630: DBFC4230 43000051
	s_waitcnt lgkmcnt(11)                                      // 000000160638: BF89FCB7
	v_fma_mixlo_f16 v9, v9, s44, 0                             // 00000016063C: CC210009 02005909
	v_fma_mixhi_f16 v9, v10, s44, 0                            // 000000160644: CC220009 0200590A
	v_fma_mixlo_f16 v10, v11, s44, 0                           // 00000016064C: CC21000A 0200590B
	v_fma_mixhi_f16 v10, v12, s44, 0                           // 000000160654: CC22000A 0200590C
	s_waitcnt lgkmcnt(10)                                      // 00000016065C: BF89FCA7
	v_fma_mixlo_f16 v11, v13, s44, 0                           // 000000160660: CC21000B 0200590D
	v_fma_mixhi_f16 v11, v14, s44, 0                           // 000000160668: CC22000B 0200590E
	v_fma_mixlo_f16 v12, v15, s44, 0                           // 000000160670: CC21000C 0200590F
	v_fma_mixhi_f16 v12, v16, s44, 0                           // 000000160678: CC22000C 02005910
	s_waitcnt lgkmcnt(9)                                       // 000000160680: BF89FC97
	v_fma_mixlo_f16 v13, v17, s44, 0                           // 000000160684: CC21000D 02005911
	v_fma_mixhi_f16 v13, v18, s44, 0                           // 00000016068C: CC22000D 02005912
	v_fma_mixlo_f16 v14, v19, s44, 0                           // 000000160694: CC21000E 02005913
	v_fma_mixhi_f16 v14, v20, s44, 0                           // 00000016069C: CC22000E 02005914
	s_waitcnt lgkmcnt(8)                                       // 0000001606A4: BF89FC87
	v_fma_mixlo_f16 v15, v21, s44, 0                           // 0000001606A8: CC21000F 02005915
	v_fma_mixhi_f16 v15, v22, s44, 0                           // 0000001606B0: CC22000F 02005916
	v_fma_mixlo_f16 v16, v23, s44, 0                           // 0000001606B8: CC210010 02005917
	v_fma_mixhi_f16 v16, v24, s44, 0                           // 0000001606C0: CC220010 02005918
	s_waitcnt lgkmcnt(7)                                       // 0000001606C8: BF89FC77
	v_fma_mixlo_f16 v17, v25, s44, 0                           // 0000001606CC: CC210011 02005919
	v_fma_mixhi_f16 v17, v26, s44, 0                           // 0000001606D4: CC220011 0200591A
	v_fma_mixlo_f16 v18, v27, s44, 0                           // 0000001606DC: CC210012 0200591B
	v_fma_mixhi_f16 v18, v28, s44, 0                           // 0000001606E4: CC220012 0200591C
	s_waitcnt lgkmcnt(6)                                       // 0000001606EC: BF89FC67
	v_fma_mixlo_f16 v19, v29, s44, 0                           // 0000001606F0: CC210013 0200591D
	v_fma_mixhi_f16 v19, v30, s44, 0                           // 0000001606F8: CC220013 0200591E
	v_fma_mixlo_f16 v20, v31, s44, 0                           // 000000160700: CC210014 0200591F
	v_fma_mixhi_f16 v20, v32, s44, 0                           // 000000160708: CC220014 02005920
	s_waitcnt lgkmcnt(5)                                       // 000000160710: BF89FC57
	v_fma_mixlo_f16 v21, v33, s44, 0                           // 000000160714: CC210015 02005921
	v_fma_mixhi_f16 v21, v34, s44, 0                           // 00000016071C: CC220015 02005922
	v_fma_mixlo_f16 v22, v35, s44, 0                           // 000000160724: CC210016 02005923
	v_fma_mixhi_f16 v22, v36, s44, 0                           // 00000016072C: CC220016 02005924
	s_waitcnt lgkmcnt(4)                                       // 000000160734: BF89FC47
	v_fma_mixlo_f16 v23, v37, s44, 0                           // 000000160738: CC210017 02005925
	v_fma_mixhi_f16 v23, v38, s44, 0                           // 000000160740: CC220017 02005926
	v_fma_mixlo_f16 v24, v39, s44, 0                           // 000000160748: CC210018 02005927
	v_fma_mixhi_f16 v24, v40, s44, 0                           // 000000160750: CC220018 02005928
	v_wmma_f32_16x16x16_f16 v[33:40], v[49:56], v[9:16], v[1:8]// 000000160758: CC404021 1C061331
	s_waitcnt lgkmcnt(3)                                       // 000000160760: BF89FC37
	v_fma_mixlo_f16 v9, v41, s44, 0                            // 000000160764: CC210009 02005929
	v_fma_mixhi_f16 v9, v42, s44, 0                            // 00000016076C: CC220009 0200592A
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[17:24], v[1:8]// 000000160774: CC404019 1C062331
	ds_load_b128 v[17:20], v81 offset:25344                    // 00000016077C: DBFC6300 11000051
	ds_load_b128 v[21:24], v81 offset:25360                    // 000000160784: DBFC6310 15000051
	v_fma_mixlo_f16 v10, v43, s44, 0                           // 00000016078C: CC21000A 0200592B
	v_fma_mixhi_f16 v10, v44, s44, 0                           // 000000160794: CC22000A 0200592C
	s_waitcnt lgkmcnt(4)                                       // 00000016079C: BF89FC47
	v_fma_mixlo_f16 v11, v45, s44, 0                           // 0000001607A0: CC21000B 0200592D
	v_fma_mixhi_f16 v11, v46, s44, 0                           // 0000001607A8: CC22000B 0200592E
	ds_load_b128 v[41:44], v81 offset:25376                    // 0000001607B0: DBFC6320 29000051
	v_fma_mixlo_f16 v12, v47, s44, 0                           // 0000001607B8: CC21000C 0200592F
	v_fma_mixhi_f16 v12, v48, s44, 0                           // 0000001607C0: CC22000C 02005930
	ds_load_b128 v[45:48], v81 offset:25392                    // 0000001607C8: DBFC6330 2D000051
	s_waitcnt lgkmcnt(5)                                       // 0000001607D0: BF89FC57
	v_fma_mixlo_f16 v13, v63, s44, 0                           // 0000001607D4: CC21000D 0200593F
	v_fma_mixhi_f16 v13, v64, s44, 0                           // 0000001607DC: CC22000D 02005940
	v_fma_mixlo_f16 v14, v65, s44, 0                           // 0000001607E4: CC21000E 02005941
	v_fma_mixhi_f16 v14, v66, s44, 0                           // 0000001607EC: CC22000E 02005942
	s_waitcnt lgkmcnt(4)                                       // 0000001607F4: BF89FC47
	v_fma_mixlo_f16 v15, v67, s44, 0                           // 0000001607F8: CC21000F 02005943
	v_fma_mixhi_f16 v15, v68, s44, 0                           // 000000160800: CC22000F 02005944
	v_fma_mixlo_f16 v16, v69, s44, 0                           // 000000160808: CC210010 02005945
	v_fma_mixhi_f16 v16, v70, s44, 0                           // 000000160810: CC220010 02005946
	s_waitcnt lgkmcnt(3)                                       // 000000160818: BF89FC37
	v_fma_mixlo_f16 v63, v17, s44, 0                           // 00000016081C: CC21003F 02005911
	v_fma_mixhi_f16 v63, v18, s44, 0                           // 000000160824: CC22003F 02005912
	v_fma_mixlo_f16 v64, v19, s44, 0                           // 00000016082C: CC210040 02005913
	v_fma_mixhi_f16 v64, v20, s44, 0                           // 000000160834: CC220040 02005914
	s_waitcnt lgkmcnt(2)                                       // 00000016083C: BF89FC27
	v_fma_mixlo_f16 v65, v21, s44, 0                           // 000000160840: CC210041 02005915
	v_fma_mixhi_f16 v65, v22, s44, 0                           // 000000160848: CC220041 02005916
	v_fma_mixlo_f16 v66, v23, s44, 0                           // 000000160850: CC210042 02005917
	v_fma_mixhi_f16 v66, v24, s44, 0                           // 000000160858: CC220042 02005918
	s_waitcnt lgkmcnt(1)                                       // 000000160860: BF89FC17
	v_fma_mixlo_f16 v67, v41, s44, 0                           // 000000160864: CC210043 02005929
	v_fma_mixhi_f16 v67, v42, s44, 0                           // 00000016086C: CC220043 0200592A
	v_fma_mixlo_f16 v68, v43, s44, 0                           // 000000160874: CC210044 0200592B
	v_fma_mixhi_f16 v68, v44, s44, 0                           // 00000016087C: CC220044 0200592C
	s_waitcnt lgkmcnt(0)                                       // 000000160884: BF89FC07
	v_fma_mixlo_f16 v69, v45, s44, 0                           // 000000160888: CC210045 0200592D
	v_fma_mixhi_f16 v69, v46, s44, 0                           // 000000160890: CC220045 0200592E
	v_fma_mixlo_f16 v70, v47, s44, 0                           // 000000160898: CC210046 0200592F
	v_fma_mixhi_f16 v70, v48, s44, 0                           // 0000001608A0: CC220046 02005930
	.long 0x7f603880                                           // 0000001608A8: 7F603880
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[9:16], v[1:8]// 0000001608AC: CC404011 1C061331
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001608B4: BF870193
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[63:70], v[1:8]// 0000001608B8: CC404009 1C067F31
	.long 0x7f5c39b0                                           // 0000001608C0: 7F5C39B0
	.long 0x7e5c39b0                                           // 0000001608C4: 7E5C39B0
	.long 0x7f5a39b0                                           // 0000001608C8: 7F5A39B0
	.long 0x7e5a39b0                                           // 0000001608CC: 7E5A39B0
	s_and_saveexec_b32 s1, s0                                  // 0000001608D0: BE812000
	s_cbranch_execz 11                                         // 0000001608D4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x804>
	global_load_b128 v[41:44], v[61:62], off offset:64         // 0000001608D8: DC5E0040 297C003D
	s_waitcnt vmcnt(0)                                         // 0000001608E0: BF8903F7
	v_fma_mixlo_f16 v45, v41, s44, 0                           // 0000001608E4: CC21002D 02005929
	v_fma_mixhi_f16 v45, v42, s44, 0                           // 0000001608EC: CC22002D 0200592A
	v_fma_mixlo_f16 v46, v43, s44, 0                           // 0000001608F4: CC21002E 0200592B
	v_fma_mixhi_f16 v46, v44, s44, 0                           // 0000001608FC: CC22002E 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000160904: 8C7E017E
	.long 0x7e6039b0                                           // 000000160908: 7E6039B0
	.long 0x7f5e39b0                                           // 00000016090C: 7F5E39B0
	.long 0x7e5e39b0                                           // 000000160910: 7E5E39B0
	s_and_saveexec_b32 s1, s0                                  // 000000160914: BE812000
	s_cbranch_execz 11                                         // 000000160918: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x848>
	global_load_b128 v[41:44], v[61:62], off offset:80         // 00000016091C: DC5E0050 297C003D
	s_waitcnt vmcnt(0)                                         // 000000160924: BF8903F7
	v_fma_mixlo_f16 v47, v41, s44, 0                           // 000000160928: CC21002F 02005929
	v_fma_mixhi_f16 v47, v42, s44, 0                           // 000000160930: CC22002F 0200592A
	v_fma_mixlo_f16 v48, v43, s44, 0                           // 000000160938: CC210030 0200592B
	v_fma_mixhi_f16 v48, v44, s44, 0                           // 000000160940: CC220030 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000160948: 8C7E017E
	.long 0x7f683880                                           // 00000016094C: 7F683880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000160950: BF870001
	.long 0x7f6439b4                                           // 000000160954: 7F6439B4
	.long 0x7e6439b4                                           // 000000160958: 7E6439B4
	.long 0x7f6239b4                                           // 00000016095C: 7F6239B4
	.long 0x7e6239b4                                           // 000000160960: 7E6239B4
	s_and_saveexec_b32 s1, s0                                  // 000000160964: BE812000
	s_cbranch_execz 11                                         // 000000160968: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x898>
	global_load_b128 v[41:44], v[61:62], off offset:96         // 00000016096C: DC5E0060 297C003D
	s_waitcnt vmcnt(0)                                         // 000000160974: BF8903F7
	v_fma_mixlo_f16 v49, v41, s44, 0                           // 000000160978: CC210031 02005929
	v_fma_mixhi_f16 v49, v42, s44, 0                           // 000000160980: CC220031 0200592A
	v_fma_mixlo_f16 v50, v43, s44, 0                           // 000000160988: CC210032 0200592B
	v_fma_mixhi_f16 v50, v44, s44, 0                           // 000000160990: CC220032 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000160998: 8C7E017E
	.long 0x7e6839b4                                           // 00000016099C: 7E6839B4
	.long 0x7f6639b4                                           // 0000001609A0: 7F6639B4
	.long 0x7e6639b4                                           // 0000001609A4: 7E6639B4
	s_and_saveexec_b32 s1, s0                                  // 0000001609A8: BE812000
	s_cbranch_execz 11                                         // 0000001609AC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8dc>
	global_load_b128 v[41:44], v[61:62], off offset:112        // 0000001609B0: DC5E0070 297C003D
	s_waitcnt vmcnt(0)                                         // 0000001609B8: BF8903F7
	v_fma_mixlo_f16 v51, v41, s44, 0                           // 0000001609BC: CC210033 02005929
	v_fma_mixhi_f16 v51, v42, s44, 0                           // 0000001609C4: CC220033 0200592A
	v_fma_mixlo_f16 v52, v43, s44, 0                           // 0000001609CC: CC210034 0200592B
	v_fma_mixhi_f16 v52, v44, s44, 0                           // 0000001609D4: CC220034 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001609DC: 8C7E017E
	ds_load_b128 v[41:44], v81 offset:64                       // 0000001609E0: DBFC0040 29000051
	ds_load_b128 v[53:56], v81 offset:80                       // 0000001609E8: DBFC0050 35000051
	ds_load_b128 v[67:70], v81 offset:96                       // 0000001609F0: DBFC0060 43000051
	ds_load_b128 v[90:93], v81 offset:112                      // 0000001609F8: DBFC0070 5A000051
	ds_load_b128 v[94:97], v81 offset:8512                     // 000000160A00: DBFC2140 5E000051
	ds_load_b128 v[98:101], v81 offset:8528                    // 000000160A08: DBFC2150 62000051
	ds_load_b128 v[102:105], v81 offset:8544                   // 000000160A10: DBFC2160 66000051
	ds_load_b128 v[106:109], v81 offset:8560                   // 000000160A18: DBFC2170 6A000051
	ds_load_b128 v[110:113], v81 offset:16992                  // 000000160A20: DBFC4260 6E000051
	ds_load_b128 v[114:117], v81 offset:17008                  // 000000160A28: DBFC4270 72000051
	ds_load_b128 v[118:121], v81 offset:25424                  // 000000160A30: DBFC6350 76000051
	s_waitcnt lgkmcnt(10)                                      // 000000160A38: BF89FCA7
	v_fma_mixlo_f16 v63, v41, s44, 0                           // 000000160A3C: CC21003F 02005929
	v_fma_mixhi_f16 v63, v42, s44, 0                           // 000000160A44: CC22003F 0200592A
	v_fma_mixlo_f16 v64, v43, s44, 0                           // 000000160A4C: CC210040 0200592B
	v_fma_mixhi_f16 v64, v44, s44, 0                           // 000000160A54: CC220040 0200592C
	s_waitcnt lgkmcnt(9)                                       // 000000160A5C: BF89FC97
	v_fma_mixlo_f16 v65, v53, s44, 0                           // 000000160A60: CC210041 02005935
	v_fma_mixhi_f16 v65, v54, s44, 0                           // 000000160A68: CC220041 02005936
	v_fma_mixlo_f16 v66, v55, s44, 0                           // 000000160A70: CC210042 02005937
	v_fma_mixhi_f16 v66, v56, s44, 0                           // 000000160A78: CC220042 02005938
	ds_load_b128 v[41:44], v81 offset:16960                    // 000000160A80: DBFC4240 29000051
	ds_load_b128 v[53:56], v81 offset:16976                    // 000000160A88: DBFC4250 35000051
	s_waitcnt lgkmcnt(10)                                      // 000000160A90: BF89FCA7
	v_fma_mixlo_f16 v67, v67, s44, 0                           // 000000160A94: CC210043 02005943
	v_fma_mixhi_f16 v67, v68, s44, 0                           // 000000160A9C: CC220043 02005944
	v_fma_mixlo_f16 v68, v69, s44, 0                           // 000000160AA4: CC210044 02005945
	v_fma_mixhi_f16 v68, v70, s44, 0                           // 000000160AAC: CC220044 02005946
	s_waitcnt lgkmcnt(9)                                       // 000000160AB4: BF89FC97
	v_fma_mixhi_f16 v69, v91, s44, 0                           // 000000160AB8: CC220045 0200595B
	v_fma_mixlo_f16 v70, v92, s44, 0                           // 000000160AC0: CC210046 0200595C
	v_fma_mixhi_f16 v70, v93, s44, 0                           // 000000160AC8: CC220046 0200595D
	s_waitcnt lgkmcnt(8)                                       // 000000160AD0: BF89FC87
	v_fma_mixlo_f16 v91, v96, s44, 0                           // 000000160AD4: CC21005B 02005960
	v_fma_mixhi_f16 v91, v97, s44, 0                           // 000000160ADC: CC22005B 02005961
	s_waitcnt lgkmcnt(7)                                       // 000000160AE4: BF89FC77
	v_fma_mixlo_f16 v92, v98, s44, 0                           // 000000160AE8: CC21005C 02005962
	v_fma_mixhi_f16 v92, v99, s44, 0                           // 000000160AF0: CC22005C 02005963
	v_fma_mixlo_f16 v93, v100, s44, 0                          // 000000160AF8: CC21005D 02005964
	v_fma_mixhi_f16 v93, v101, s44, 0                          // 000000160B00: CC22005D 02005965
	s_waitcnt lgkmcnt(5)                                       // 000000160B08: BF89FC57
	v_fma_mixlo_f16 v96, v106, s44, 0                          // 000000160B0C: CC210060 0200596A
	v_fma_mixhi_f16 v96, v107, s44, 0                          // 000000160B14: CC220060 0200596B
	v_fma_mixlo_f16 v97, v108, s44, 0                          // 000000160B1C: CC210061 0200596C
	v_fma_mixhi_f16 v97, v109, s44, 0                          // 000000160B24: CC220061 0200596D
	ds_load_b128 v[106:109], v81 offset:25408                  // 000000160B2C: DBFC6340 6A000051
	s_waitcnt lgkmcnt(2)                                       // 000000160B34: BF89FC27
	v_fma_mixlo_f16 v98, v41, s44, 0                           // 000000160B38: CC210062 02005929
	v_fma_mixhi_f16 v98, v42, s44, 0                           // 000000160B40: CC220062 0200592A
	v_fma_mixlo_f16 v99, v43, s44, 0                           // 000000160B48: CC210063 0200592B
	v_fma_mixhi_f16 v99, v44, s44, 0                           // 000000160B50: CC220063 0200592C
	s_waitcnt lgkmcnt(1)                                       // 000000160B58: BF89FC17
	v_fma_mixlo_f16 v100, v53, s44, 0                          // 000000160B5C: CC210064 02005935
	v_fma_mixhi_f16 v100, v54, s44, 0                          // 000000160B64: CC220064 02005936
	ds_load_b128 v[41:44], v81 offset:25440                    // 000000160B6C: DBFC6360 29000051
	v_fma_mixlo_f16 v101, v55, s44, 0                          // 000000160B74: CC210065 02005937
	v_fma_mixhi_f16 v101, v56, s44, 0                          // 000000160B7C: CC220065 02005938
	ds_load_b128 v[53:56], v81 offset:25456                    // 000000160B84: DBFC6370 35000051
	v_fma_mixlo_f16 v69, v90, s44, 0                           // 000000160B8C: CC210045 0200595A
	v_fma_mixlo_f16 v90, v94, s44, 0                           // 000000160B94: CC21005A 0200595E
	v_fma_mixhi_f16 v90, v95, s44, 0                           // 000000160B9C: CC22005A 0200595F
	v_fma_mixlo_f16 v94, v102, s44, 0                          // 000000160BA4: CC21005E 02005966
	v_fma_mixhi_f16 v94, v103, s44, 0                          // 000000160BAC: CC22005E 02005967
	v_fma_mixlo_f16 v95, v104, s44, 0                          // 000000160BB4: CC21005F 02005968
	v_fma_mixhi_f16 v95, v105, s44, 0                          // 000000160BBC: CC22005F 02005969
	v_fma_mixlo_f16 v102, v110, s44, 0                         // 000000160BC4: CC210066 0200596E
	v_fma_mixhi_f16 v102, v111, s44, 0                         // 000000160BCC: CC220066 0200596F
	v_fma_mixlo_f16 v103, v112, s44, 0                         // 000000160BD4: CC210067 02005970
	v_fma_mixhi_f16 v103, v113, s44, 0                         // 000000160BDC: CC220067 02005971
	v_fma_mixlo_f16 v104, v114, s44, 0                         // 000000160BE4: CC210068 02005972
	v_fma_mixhi_f16 v104, v115, s44, 0                         // 000000160BEC: CC220068 02005973
	v_fma_mixlo_f16 v105, v116, s44, 0                         // 000000160BF4: CC210069 02005974
	v_fma_mixhi_f16 v105, v117, s44, 0                         // 000000160BFC: CC220069 02005975
	s_waitcnt lgkmcnt(2)                                       // 000000160C04: BF89FC27
	v_fma_mixlo_f16 v106, v106, s44, 0                         // 000000160C08: CC21006A 0200596A
	v_fma_mixhi_f16 v106, v107, s44, 0                         // 000000160C10: CC22006A 0200596B
	v_fma_mixlo_f16 v107, v108, s44, 0                         // 000000160C18: CC21006B 0200596C
	v_fma_mixhi_f16 v107, v109, s44, 0                         // 000000160C20: CC22006B 0200596D
	v_fma_mixlo_f16 v108, v118, s44, 0                         // 000000160C28: CC21006C 02005976
	v_fma_mixhi_f16 v108, v119, s44, 0                         // 000000160C30: CC22006C 02005977
	v_fma_mixlo_f16 v109, v120, s44, 0                         // 000000160C38: CC21006D 02005978
	v_fma_mixhi_f16 v109, v121, s44, 0                         // 000000160C40: CC22006D 02005979
	s_waitcnt lgkmcnt(1)                                       // 000000160C48: BF89FC17
	v_fma_mixlo_f16 v110, v41, s44, 0                          // 000000160C4C: CC21006E 02005929
	v_fma_mixhi_f16 v110, v42, s44, 0                          // 000000160C54: CC22006E 0200592A
	v_fma_mixlo_f16 v111, v43, s44, 0                          // 000000160C5C: CC21006F 0200592B
	v_fma_mixhi_f16 v111, v44, s44, 0                          // 000000160C64: CC22006F 0200592C
	s_waitcnt lgkmcnt(0)                                       // 000000160C6C: BF89FC07
	v_fma_mixlo_f16 v112, v53, s44, 0                          // 000000160C70: CC210070 02005935
	v_fma_mixhi_f16 v112, v54, s44, 0                          // 000000160C78: CC220070 02005936
	v_fma_mixlo_f16 v113, v55, s44, 0                          // 000000160C80: CC210071 02005937
	v_fma_mixhi_f16 v113, v56, s44, 0                          // 000000160C88: CC220071 02005938
	.long 0x7f583880                                           // 000000160C90: 7F583880
	v_wmma_f32_16x16x16_f16 v[33:40], v[45:52], v[63:70], v[33:40]// 000000160C94: CC404021 1C867F2D
	v_wmma_f32_16x16x16_f16 v[25:32], v[45:52], v[90:97], v[25:32]// 000000160C9C: CC404019 1C66B52D
	v_wmma_f32_16x16x16_f16 v[17:24], v[45:52], v[98:105], v[17:24]// 000000160CA4: CC404011 1C46C52D
	v_wmma_f32_16x16x16_f16 v[9:16], v[45:52], v[106:113], v[9:16]// 000000160CAC: CC404009 1C26D52D
	.long 0x7f5439ac                                           // 000000160CB4: 7F5439AC
	.long 0x7e5439ac                                           // 000000160CB8: 7E5439AC
	.long 0x7f5239ac                                           // 000000160CBC: 7F5239AC
	.long 0x7e5239ac                                           // 000000160CC0: 7E5239AC
	s_and_saveexec_b32 s1, s0                                  // 000000160CC4: BE812000
	s_cbranch_execz 11                                         // 000000160CC8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xbf8>
	global_load_b128 v[45:48], v[61:62], off offset:128        // 000000160CCC: DC5E0080 2D7C003D
	s_waitcnt vmcnt(0)                                         // 000000160CD4: BF8903F7
	v_fma_mixlo_f16 v41, v45, s44, 0                           // 000000160CD8: CC210029 0200592D
	v_fma_mixhi_f16 v41, v46, s44, 0                           // 000000160CE0: CC220029 0200592E
	v_fma_mixlo_f16 v42, v47, s44, 0                           // 000000160CE8: CC21002A 0200592F
	v_fma_mixhi_f16 v42, v48, s44, 0                           // 000000160CF0: CC22002A 02005930
	s_or_b32 exec_lo, exec_lo, s1                              // 000000160CF8: 8C7E017E
	.long 0x7e5839ac                                           // 000000160CFC: 7E5839AC
	.long 0x7f5639ac                                           // 000000160D00: 7F5639AC
	.long 0x7e5639ac                                           // 000000160D04: 7E5639AC
	s_and_saveexec_b32 s1, s0                                  // 000000160D08: BE812000
	s_cbranch_execz 11                                         // 000000160D0C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc3c>
	global_load_b128 v[43:46], v[61:62], off offset:144        // 000000160D10: DC5E0090 2B7C003D
	s_waitcnt vmcnt(0)                                         // 000000160D18: BF8903F7
	v_fma_mixlo_f16 v43, v43, s44, 0                           // 000000160D1C: CC21002B 0200592B
	v_fma_mixhi_f16 v43, v44, s44, 0                           // 000000160D24: CC22002B 0200592C
	v_fma_mixlo_f16 v44, v45, s44, 0                           // 000000160D2C: CC21002C 0200592D
	v_fma_mixhi_f16 v44, v46, s44, 0                           // 000000160D34: CC22002C 0200592E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000160D3C: 8C7E017E
	.long 0x7f603880                                           // 000000160D40: 7F603880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000160D44: BF870001
	.long 0x7f5c39b0                                           // 000000160D48: 7F5C39B0
	.long 0x7e5c39b0                                           // 000000160D4C: 7E5C39B0
	.long 0x7f5a39b0                                           // 000000160D50: 7F5A39B0
	.long 0x7e5a39b0                                           // 000000160D54: 7E5A39B0
	s_and_saveexec_b32 s1, s0                                  // 000000160D58: BE812000
	s_cbranch_execz 11                                         // 000000160D5C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc8c>
	global_load_b128 v[49:52], v[61:62], off offset:160        // 000000160D60: DC5E00A0 317C003D
	s_waitcnt vmcnt(0)                                         // 000000160D68: BF8903F7
	v_fma_mixlo_f16 v45, v49, s44, 0                           // 000000160D6C: CC21002D 02005931
	v_fma_mixhi_f16 v45, v50, s44, 0                           // 000000160D74: CC22002D 02005932
	v_fma_mixlo_f16 v46, v51, s44, 0                           // 000000160D7C: CC21002E 02005933
	v_fma_mixhi_f16 v46, v52, s44, 0                           // 000000160D84: CC22002E 02005934
	s_or_b32 exec_lo, exec_lo, s1                              // 000000160D8C: 8C7E017E
	.long 0x7e6039b0                                           // 000000160D90: 7E6039B0
	.long 0x7f5e39b0                                           // 000000160D94: 7F5E39B0
	.long 0x7e5e39b0                                           // 000000160D98: 7E5E39B0
	s_and_saveexec_b32 s1, s0                                  // 000000160D9C: BE812000
	s_cbranch_execz 11                                         // 000000160DA0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xcd0>
	global_load_b128 v[47:50], v[61:62], off offset:176        // 000000160DA4: DC5E00B0 2F7C003D
	s_waitcnt vmcnt(0)                                         // 000000160DAC: BF8903F7
	v_fma_mixlo_f16 v47, v47, s44, 0                           // 000000160DB0: CC21002F 0200592F
	v_fma_mixhi_f16 v47, v48, s44, 0                           // 000000160DB8: CC22002F 02005930
	v_fma_mixlo_f16 v48, v49, s44, 0                           // 000000160DC0: CC210030 02005931
	v_fma_mixhi_f16 v48, v50, s44, 0                           // 000000160DC8: CC220030 02005932
	s_or_b32 exec_lo, exec_lo, s1                              // 000000160DD0: 8C7E017E
	ds_load_b128 v[50:53], v81 offset:128                      // 000000160DD4: DBFC0080 32000051
	ds_load_b128 v[54:57], v81 offset:144                      // 000000160DDC: DBFC0090 36000051
	ds_load_b128 v[63:66], v81 offset:160                      // 000000160DE4: DBFC00A0 3F000051
	ds_load_b128 v[67:70], v81 offset:176                      // 000000160DEC: DBFC00B0 43000051
	ds_load_b128 v[90:93], v81 offset:8576                     // 000000160DF4: DBFC2180 5A000051
	ds_load_b128 v[94:97], v81 offset:8592                     // 000000160DFC: DBFC2190 5E000051
	ds_load_b128 v[98:101], v81 offset:8608                    // 000000160E04: DBFC21A0 62000051
	ds_load_b128 v[102:105], v81 offset:8624                   // 000000160E0C: DBFC21B0 66000051
	ds_load_b128 v[106:109], v81 offset:17024                  // 000000160E14: DBFC4280 6A000051
	ds_load_b128 v[110:113], v81 offset:17040                  // 000000160E1C: DBFC4290 6E000051
	.long 0x7f623880                                           // 000000160E24: 7F623880
	ds_load_b128 v[114:117], v81 offset:25488                  // 000000160E28: DBFC6390 72000051
	s_waitcnt lgkmcnt(10)                                      // 000000160E30: BF89FCA7
	v_fma_mixlo_f16 v50, v50, s44, 0                           // 000000160E34: CC210032 02005932
	v_fma_mixhi_f16 v50, v51, s44, 0                           // 000000160E3C: CC220032 02005933
	v_fma_mixlo_f16 v51, v52, s44, 0                           // 000000160E44: CC210033 02005934
	v_fma_mixhi_f16 v51, v53, s44, 0                           // 000000160E4C: CC220033 02005935
	s_waitcnt lgkmcnt(9)                                       // 000000160E54: BF89FC97
	v_fma_mixlo_f16 v52, v54, s44, 0                           // 000000160E58: CC210034 02005936
	v_fma_mixhi_f16 v52, v55, s44, 0                           // 000000160E60: CC220034 02005937
	v_fma_mixlo_f16 v53, v56, s44, 0                           // 000000160E68: CC210035 02005938
	v_fma_mixhi_f16 v53, v57, s44, 0                           // 000000160E70: CC220035 02005939
	s_waitcnt lgkmcnt(8)                                       // 000000160E78: BF89FC87
	v_fma_mixlo_f16 v54, v63, s44, 0                           // 000000160E7C: CC210036 0200593F
	v_fma_mixhi_f16 v54, v64, s44, 0                           // 000000160E84: CC220036 02005940
	v_fma_mixlo_f16 v55, v65, s44, 0                           // 000000160E8C: CC210037 02005941
	v_fma_mixhi_f16 v55, v66, s44, 0                           // 000000160E94: CC220037 02005942
	s_waitcnt lgkmcnt(7)                                       // 000000160E9C: BF89FC77
	v_fma_mixlo_f16 v56, v67, s44, 0                           // 000000160EA0: CC210038 02005943
	v_fma_mixhi_f16 v56, v68, s44, 0                           // 000000160EA8: CC220038 02005944
	v_fma_mixlo_f16 v57, v69, s44, 0                           // 000000160EB0: CC210039 02005945
	v_fma_mixhi_f16 v57, v70, s44, 0                           // 000000160EB8: CC220039 02005946
	s_waitcnt lgkmcnt(6)                                       // 000000160EC0: BF89FC67
	v_fma_mixlo_f16 v63, v90, s44, 0                           // 000000160EC4: CC21003F 0200595A
	v_fma_mixhi_f16 v63, v91, s44, 0                           // 000000160ECC: CC22003F 0200595B
	v_fma_mixlo_f16 v64, v92, s44, 0                           // 000000160ED4: CC210040 0200595C
	v_fma_mixhi_f16 v64, v93, s44, 0                           // 000000160EDC: CC220040 0200595D
	s_waitcnt lgkmcnt(5)                                       // 000000160EE4: BF89FC57
	v_fma_mixlo_f16 v65, v94, s44, 0                           // 000000160EE8: CC210041 0200595E
	v_fma_mixhi_f16 v65, v95, s44, 0                           // 000000160EF0: CC220041 0200595F
	v_fma_mixlo_f16 v66, v96, s44, 0                           // 000000160EF8: CC210042 02005960
	v_fma_mixhi_f16 v66, v97, s44, 0                           // 000000160F00: CC220042 02005961
	s_waitcnt lgkmcnt(4)                                       // 000000160F08: BF89FC47
	v_fma_mixlo_f16 v67, v98, s44, 0                           // 000000160F0C: CC210043 02005962
	ds_load_b128 v[94:97], v81 offset:17056                    // 000000160F14: DBFC42A0 5E000051
	v_fma_mixhi_f16 v67, v99, s44, 0                           // 000000160F1C: CC220043 02005963
	v_fma_mixlo_f16 v68, v100, s44, 0                          // 000000160F24: CC210044 02005964
	v_fma_mixhi_f16 v68, v101, s44, 0                          // 000000160F2C: CC220044 02005965
	s_waitcnt lgkmcnt(4)                                       // 000000160F34: BF89FC47
	v_fma_mixlo_f16 v69, v102, s44, 0                          // 000000160F38: CC210045 02005966
	ds_load_b128 v[98:101], v81 offset:17072                   // 000000160F40: DBFC42B0 62000051
	v_fma_mixhi_f16 v69, v103, s44, 0                          // 000000160F48: CC220045 02005967
	v_fma_mixlo_f16 v70, v104, s44, 0                          // 000000160F50: CC210046 02005968
	v_fma_mixhi_f16 v70, v105, s44, 0                          // 000000160F58: CC220046 02005969
	ds_load_b128 v[102:105], v81 offset:25472                  // 000000160F60: DBFC6380 66000051
	s_waitcnt lgkmcnt(5)                                       // 000000160F68: BF89FC57
	v_fma_mixlo_f16 v90, v106, s44, 0                          // 000000160F6C: CC21005A 0200596A
	v_fma_mixhi_f16 v90, v107, s44, 0                          // 000000160F74: CC22005A 0200596B
	v_fma_mixlo_f16 v91, v108, s44, 0                          // 000000160F7C: CC21005B 0200596C
	v_fma_mixhi_f16 v91, v109, s44, 0                          // 000000160F84: CC22005B 0200596D
	s_waitcnt lgkmcnt(4)                                       // 000000160F8C: BF89FC47
	v_fma_mixlo_f16 v92, v110, s44, 0                          // 000000160F90: CC21005C 0200596E
	v_fma_mixhi_f16 v92, v111, s44, 0                          // 000000160F98: CC22005C 0200596F
	ds_load_b128 v[106:109], v81 offset:25504                  // 000000160FA0: DBFC63A0 6A000051
	v_fma_mixlo_f16 v93, v112, s44, 0                          // 000000160FA8: CC21005D 02005970
	v_fma_mixhi_f16 v93, v113, s44, 0                          // 000000160FB0: CC22005D 02005971
	ds_load_b128 v[110:113], v81 offset:25520                  // 000000160FB8: DBFC63B0 6E000051
	s_waitcnt lgkmcnt(4)                                       // 000000160FC0: BF89FC47
	v_fma_mixlo_f16 v94, v94, s44, 0                           // 000000160FC4: CC21005E 0200595E
	v_fma_mixhi_f16 v94, v95, s44, 0                           // 000000160FCC: CC22005E 0200595F
	v_fma_mixlo_f16 v95, v96, s44, 0                           // 000000160FD4: CC21005F 02005960
	v_fma_mixhi_f16 v95, v97, s44, 0                           // 000000160FDC: CC22005F 02005961
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[50:57], v[33:40]// 000000160FE4: CC404021 1C866529
	s_waitcnt lgkmcnt(3)                                       // 000000160FEC: BF89FC37
	v_fma_mixlo_f16 v96, v98, s44, 0                           // 000000160FF0: CC210060 02005962
	v_fma_mixhi_f16 v96, v99, s44, 0                           // 000000160FF8: CC220060 02005963
	v_fma_mixlo_f16 v97, v100, s44, 0                          // 000000161000: CC210061 02005964
	v_fma_mixhi_f16 v97, v101, s44, 0                          // 000000161008: CC220061 02005965
	s_waitcnt lgkmcnt(2)                                       // 000000161010: BF89FC27
	v_fma_mixlo_f16 v98, v102, s44, 0                          // 000000161014: CC210062 02005966
	v_fma_mixhi_f16 v98, v103, s44, 0                          // 00000016101C: CC220062 02005967
	v_fma_mixlo_f16 v99, v104, s44, 0                          // 000000161024: CC210063 02005968
	v_fma_mixhi_f16 v99, v105, s44, 0                          // 00000016102C: CC220063 02005969
	v_fma_mixlo_f16 v100, v114, s44, 0                         // 000000161034: CC210064 02005972
	v_fma_mixhi_f16 v100, v115, s44, 0                         // 00000016103C: CC220064 02005973
	v_fma_mixlo_f16 v101, v116, s44, 0                         // 000000161044: CC210065 02005974
	v_fma_mixhi_f16 v101, v117, s44, 0                         // 00000016104C: CC220065 02005975
	s_waitcnt lgkmcnt(1)                                       // 000000161054: BF89FC17
	v_fma_mixlo_f16 v102, v106, s44, 0                         // 000000161058: CC210066 0200596A
	v_fma_mixhi_f16 v102, v107, s44, 0                         // 000000161060: CC220066 0200596B
	v_fma_mixlo_f16 v103, v108, s44, 0                         // 000000161068: CC210067 0200596C
	v_fma_mixhi_f16 v103, v109, s44, 0                         // 000000161070: CC220067 0200596D
	s_waitcnt lgkmcnt(0)                                       // 000000161078: BF89FC07
	v_fma_mixlo_f16 v104, v110, s44, 0                         // 00000016107C: CC210068 0200596E
	v_fma_mixhi_f16 v104, v111, s44, 0                         // 000000161084: CC220068 0200596F
	v_fma_mixlo_f16 v105, v112, s44, 0                         // 00000016108C: CC210069 02005970
	v_fma_mixhi_f16 v105, v113, s44, 0                         // 000000161094: CC220069 02005971
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[63:70], v[25:32]// 00000016109C: CC404019 1C667F29
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[90:97], v[17:24]// 0000001610A4: CC404011 1C46B529
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001610AC: BF870003
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[98:105], v[9:16]// 0000001610B0: CC404009 1C26C529
	.long 0x7f5e39b1                                           // 0000001610B8: 7F5E39B1
	.long 0x7e5e39b1                                           // 0000001610BC: 7E5E39B1
	.long 0x7f5c39b1                                           // 0000001610C0: 7F5C39B1
	.long 0x7e5c39b1                                           // 0000001610C4: 7E5C39B1
	s_and_saveexec_b32 s1, s0                                  // 0000001610C8: BE812000
	s_cbranch_execz 11                                         // 0000001610CC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xffc>
	global_load_b128 v[41:44], v[61:62], off offset:192        // 0000001610D0: DC5E00C0 297C003D
	s_waitcnt vmcnt(0)                                         // 0000001610D8: BF8903F7
	v_fma_mixlo_f16 v46, v41, s44, 0                           // 0000001610DC: CC21002E 02005929
	v_fma_mixhi_f16 v46, v42, s44, 0                           // 0000001610E4: CC22002E 0200592A
	v_fma_mixlo_f16 v47, v43, s44, 0                           // 0000001610EC: CC21002F 0200592B
	v_fma_mixhi_f16 v47, v44, s44, 0                           // 0000001610F4: CC22002F 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001610FC: 8C7E017E
	.long 0x7e6239b1                                           // 000000161100: 7E6239B1
	.long 0x7f6039b1                                           // 000000161104: 7F6039B1
	.long 0x7e6039b1                                           // 000000161108: 7E6039B1
	s_and_saveexec_b32 s1, s0                                  // 00000016110C: BE812000
	s_cbranch_execz 11                                         // 000000161110: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1040>
	global_load_b128 v[41:44], v[61:62], off offset:208        // 000000161114: DC5E00D0 297C003D
	s_waitcnt vmcnt(0)                                         // 00000016111C: BF8903F7
	v_fma_mixlo_f16 v48, v41, s44, 0                           // 000000161120: CC210030 02005929
	v_fma_mixhi_f16 v48, v42, s44, 0                           // 000000161128: CC220030 0200592A
	v_fma_mixlo_f16 v49, v43, s44, 0                           // 000000161130: CC210031 0200592B
	v_fma_mixhi_f16 v49, v44, s44, 0                           // 000000161138: CC220031 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000161140: 8C7E017E
	.long 0x7f6a3880                                           // 000000161144: 7F6A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000161148: BF870001
	.long 0x7f6639b5                                           // 00000016114C: 7F6639B5
	.long 0x7e6639b5                                           // 000000161150: 7E6639B5
	.long 0x7f6439b5                                           // 000000161154: 7F6439B5
	.long 0x7e6439b5                                           // 000000161158: 7E6439B5
	s_and_saveexec_b32 s1, s0                                  // 00000016115C: BE812000
	s_cbranch_execz 11                                         // 000000161160: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1090>
	global_load_b128 v[41:44], v[61:62], off offset:224        // 000000161164: DC5E00E0 297C003D
	s_waitcnt vmcnt(0)                                         // 00000016116C: BF8903F7
	v_fma_mixlo_f16 v50, v41, s44, 0                           // 000000161170: CC210032 02005929
	v_fma_mixhi_f16 v50, v42, s44, 0                           // 000000161178: CC220032 0200592A
	v_fma_mixlo_f16 v51, v43, s44, 0                           // 000000161180: CC210033 0200592B
	v_fma_mixhi_f16 v51, v44, s44, 0                           // 000000161188: CC220033 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000161190: 8C7E017E
	.long 0x7e6a39b5                                           // 000000161194: 7E6A39B5
	.long 0x7f6839b5                                           // 000000161198: 7F6839B5
	.long 0x7e6839b5                                           // 00000016119C: 7E6839B5
	s_and_saveexec_b32 s1, s0                                  // 0000001611A0: BE812000
	s_cbranch_execz 11                                         // 0000001611A4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10d4>
	global_load_b128 v[41:44], v[61:62], off offset:240        // 0000001611A8: DC5E00F0 297C003D
	s_waitcnt vmcnt(0)                                         // 0000001611B0: BF8903F7
	v_fma_mixlo_f16 v52, v41, s44, 0                           // 0000001611B4: CC210034 02005929
	v_fma_mixhi_f16 v52, v42, s44, 0                           // 0000001611BC: CC220034 0200592A
	v_fma_mixlo_f16 v53, v43, s44, 0                           // 0000001611C4: CC210035 0200592B
	v_fma_mixhi_f16 v53, v44, s44, 0                           // 0000001611CC: CC220035 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001611D4: 8C7E017E
	ds_load_b128 v[41:44], v81 offset:192                      // 0000001611D8: DBFC00C0 29000051
	ds_load_b128 v[54:57], v81 offset:208                      // 0000001611E0: DBFC00D0 36000051
	ds_load_b128 v[67:70], v81 offset:224                      // 0000001611E8: DBFC00E0 43000051
	ds_load_b128 v[90:93], v81 offset:240                      // 0000001611F0: DBFC00F0 5A000051
	ds_load_b128 v[94:97], v81 offset:8640                     // 0000001611F8: DBFC21C0 5E000051
	ds_load_b128 v[98:101], v81 offset:8656                    // 000000161200: DBFC21D0 62000051
	ds_load_b128 v[102:105], v81 offset:8672                   // 000000161208: DBFC21E0 66000051
	ds_load_b128 v[106:109], v81 offset:8688                   // 000000161210: DBFC21F0 6A000051
	ds_load_b128 v[110:113], v81 offset:17120                  // 000000161218: DBFC42E0 6E000051
	ds_load_b128 v[114:117], v81 offset:17136                  // 000000161220: DBFC42F0 72000051
	ds_load_b128 v[118:121], v81 offset:25552                  // 000000161228: DBFC63D0 76000051
	s_waitcnt lgkmcnt(10)                                      // 000000161230: BF89FCA7
	v_fma_mixlo_f16 v63, v41, s44, 0                           // 000000161234: CC21003F 02005929
	v_fma_mixhi_f16 v63, v42, s44, 0                           // 00000016123C: CC22003F 0200592A
	v_fma_mixlo_f16 v64, v43, s44, 0                           // 000000161244: CC210040 0200592B
	v_fma_mixhi_f16 v64, v44, s44, 0                           // 00000016124C: CC220040 0200592C
	s_waitcnt lgkmcnt(9)                                       // 000000161254: BF89FC97
	v_fma_mixlo_f16 v65, v54, s44, 0                           // 000000161258: CC210041 02005936
	v_fma_mixhi_f16 v65, v55, s44, 0                           // 000000161260: CC220041 02005937
	v_fma_mixlo_f16 v66, v56, s44, 0                           // 000000161268: CC210042 02005938
	v_fma_mixhi_f16 v66, v57, s44, 0                           // 000000161270: CC220042 02005939
	ds_load_b128 v[41:44], v81 offset:17088                    // 000000161278: DBFC42C0 29000051
	ds_load_b128 v[54:57], v81 offset:17104                    // 000000161280: DBFC42D0 36000051
	s_waitcnt lgkmcnt(10)                                      // 000000161288: BF89FCA7
	v_fma_mixlo_f16 v67, v67, s44, 0                           // 00000016128C: CC210043 02005943
	v_fma_mixhi_f16 v67, v68, s44, 0                           // 000000161294: CC220043 02005944
	v_fma_mixlo_f16 v68, v69, s44, 0                           // 00000016129C: CC210044 02005945
	v_fma_mixhi_f16 v68, v70, s44, 0                           // 0000001612A4: CC220044 02005946
	s_waitcnt lgkmcnt(9)                                       // 0000001612AC: BF89FC97
	v_fma_mixhi_f16 v69, v91, s44, 0                           // 0000001612B0: CC220045 0200595B
	v_fma_mixlo_f16 v70, v92, s44, 0                           // 0000001612B8: CC210046 0200595C
	v_fma_mixhi_f16 v70, v93, s44, 0                           // 0000001612C0: CC220046 0200595D
	s_waitcnt lgkmcnt(8)                                       // 0000001612C8: BF89FC87
	v_fma_mixlo_f16 v91, v96, s44, 0                           // 0000001612CC: CC21005B 02005960
	v_fma_mixhi_f16 v91, v97, s44, 0                           // 0000001612D4: CC22005B 02005961
	s_waitcnt lgkmcnt(7)                                       // 0000001612DC: BF89FC77
	v_fma_mixlo_f16 v92, v98, s44, 0                           // 0000001612E0: CC21005C 02005962
	v_fma_mixhi_f16 v92, v99, s44, 0                           // 0000001612E8: CC22005C 02005963
	v_fma_mixlo_f16 v93, v100, s44, 0                          // 0000001612F0: CC21005D 02005964
	v_fma_mixhi_f16 v93, v101, s44, 0                          // 0000001612F8: CC22005D 02005965
	s_waitcnt lgkmcnt(5)                                       // 000000161300: BF89FC57
	v_fma_mixlo_f16 v96, v106, s44, 0                          // 000000161304: CC210060 0200596A
	v_fma_mixhi_f16 v96, v107, s44, 0                          // 00000016130C: CC220060 0200596B
	v_fma_mixlo_f16 v97, v108, s44, 0                          // 000000161314: CC210061 0200596C
	v_fma_mixhi_f16 v97, v109, s44, 0                          // 00000016131C: CC220061 0200596D
	ds_load_b128 v[106:109], v81 offset:25536                  // 000000161324: DBFC63C0 6A000051
	s_waitcnt lgkmcnt(2)                                       // 00000016132C: BF89FC27
	v_fma_mixlo_f16 v98, v41, s44, 0                           // 000000161330: CC210062 02005929
	v_fma_mixhi_f16 v98, v42, s44, 0                           // 000000161338: CC220062 0200592A
	v_fma_mixlo_f16 v99, v43, s44, 0                           // 000000161340: CC210063 0200592B
	v_fma_mixhi_f16 v99, v44, s44, 0                           // 000000161348: CC220063 0200592C
	s_waitcnt lgkmcnt(1)                                       // 000000161350: BF89FC17
	v_fma_mixlo_f16 v100, v54, s44, 0                          // 000000161354: CC210064 02005936
	v_fma_mixhi_f16 v100, v55, s44, 0                          // 00000016135C: CC220064 02005937
	ds_load_b128 v[41:44], v81 offset:25568                    // 000000161364: DBFC63E0 29000051
	v_fma_mixlo_f16 v101, v56, s44, 0                          // 00000016136C: CC210065 02005938
	v_fma_mixhi_f16 v101, v57, s44, 0                          // 000000161374: CC220065 02005939
	ds_load_b128 v[54:57], v81 offset:25584                    // 00000016137C: DBFC63F0 36000051
	v_fma_mixlo_f16 v69, v90, s44, 0                           // 000000161384: CC210045 0200595A
	v_fma_mixlo_f16 v90, v94, s44, 0                           // 00000016138C: CC21005A 0200595E
	v_fma_mixhi_f16 v90, v95, s44, 0                           // 000000161394: CC22005A 0200595F
	v_fma_mixlo_f16 v94, v102, s44, 0                          // 00000016139C: CC21005E 02005966
	v_fma_mixhi_f16 v94, v103, s44, 0                          // 0000001613A4: CC22005E 02005967
	v_fma_mixlo_f16 v95, v104, s44, 0                          // 0000001613AC: CC21005F 02005968
	v_fma_mixhi_f16 v95, v105, s44, 0                          // 0000001613B4: CC22005F 02005969
	v_fma_mixlo_f16 v102, v110, s44, 0                         // 0000001613BC: CC210066 0200596E
	v_fma_mixhi_f16 v102, v111, s44, 0                         // 0000001613C4: CC220066 0200596F
	v_fma_mixlo_f16 v103, v112, s44, 0                         // 0000001613CC: CC210067 02005970
	v_fma_mixhi_f16 v103, v113, s44, 0                         // 0000001613D4: CC220067 02005971
	v_fma_mixlo_f16 v104, v114, s44, 0                         // 0000001613DC: CC210068 02005972
	v_fma_mixhi_f16 v104, v115, s44, 0                         // 0000001613E4: CC220068 02005973
	v_fma_mixlo_f16 v105, v116, s44, 0                         // 0000001613EC: CC210069 02005974
	v_fma_mixhi_f16 v105, v117, s44, 0                         // 0000001613F4: CC220069 02005975
	s_waitcnt lgkmcnt(2)                                       // 0000001613FC: BF89FC27
	v_fma_mixlo_f16 v106, v106, s44, 0                         // 000000161400: CC21006A 0200596A
	v_fma_mixhi_f16 v106, v107, s44, 0                         // 000000161408: CC22006A 0200596B
	v_fma_mixlo_f16 v107, v108, s44, 0                         // 000000161410: CC21006B 0200596C
	v_fma_mixhi_f16 v107, v109, s44, 0                         // 000000161418: CC22006B 0200596D
	v_fma_mixlo_f16 v108, v118, s44, 0                         // 000000161420: CC21006C 02005976
	v_fma_mixhi_f16 v108, v119, s44, 0                         // 000000161428: CC22006C 02005977
	v_fma_mixlo_f16 v109, v120, s44, 0                         // 000000161430: CC21006D 02005978
	v_fma_mixhi_f16 v109, v121, s44, 0                         // 000000161438: CC22006D 02005979
	s_waitcnt lgkmcnt(1)                                       // 000000161440: BF89FC17
	v_fma_mixlo_f16 v110, v41, s44, 0                          // 000000161444: CC21006E 02005929
	v_fma_mixhi_f16 v110, v42, s44, 0                          // 00000016144C: CC22006E 0200592A
	v_fma_mixlo_f16 v111, v43, s44, 0                          // 000000161454: CC21006F 0200592B
	v_fma_mixhi_f16 v111, v44, s44, 0                          // 00000016145C: CC22006F 0200592C
	s_waitcnt lgkmcnt(0)                                       // 000000161464: BF89FC07
	v_fma_mixlo_f16 v112, v54, s44, 0                          // 000000161468: CC210070 02005936
	v_fma_mixhi_f16 v112, v55, s44, 0                          // 000000161470: CC220070 02005937
	v_fma_mixlo_f16 v113, v56, s44, 0                          // 000000161478: CC210071 02005938
	v_fma_mixhi_f16 v113, v57, s44, 0                          // 000000161480: CC220071 02005939
	.long 0x7f583880                                           // 000000161488: 7F583880
	v_wmma_f32_16x16x16_f16 v[33:40], v[46:53], v[63:70], v[33:40]// 00000016148C: CC404021 1C867F2E
	v_wmma_f32_16x16x16_f16 v[25:32], v[46:53], v[90:97], v[25:32]// 000000161494: CC404019 1C66B52E
	v_wmma_f32_16x16x16_f16 v[17:24], v[46:53], v[98:105], v[17:24]// 00000016149C: CC404011 1C46C52E
	v_wmma_f32_16x16x16_f16 v[9:16], v[46:53], v[106:113], v[9:16]// 0000001614A4: CC404009 1C26D52E
	.long 0x7f5439ac                                           // 0000001614AC: 7F5439AC
	.long 0x7e5439ac                                           // 0000001614B0: 7E5439AC
	.long 0x7f5239ac                                           // 0000001614B4: 7F5239AC
	.long 0x7e5239ac                                           // 0000001614B8: 7E5239AC
	s_and_saveexec_b32 s1, s0                                  // 0000001614BC: BE812000
	s_cbranch_execz 11                                         // 0000001614C0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13f0>
	global_load_b128 v[45:48], v[61:62], off offset:256        // 0000001614C4: DC5E0100 2D7C003D
	s_waitcnt vmcnt(0)                                         // 0000001614CC: BF8903F7
	v_fma_mixlo_f16 v41, v45, s44, 0                           // 0000001614D0: CC210029 0200592D
	v_fma_mixhi_f16 v41, v46, s44, 0                           // 0000001614D8: CC220029 0200592E
	v_fma_mixlo_f16 v42, v47, s44, 0                           // 0000001614E0: CC21002A 0200592F
	v_fma_mixhi_f16 v42, v48, s44, 0                           // 0000001614E8: CC22002A 02005930
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001614F0: 8C7E017E
	.long 0x7e5839ac                                           // 0000001614F4: 7E5839AC
	.long 0x7f5639ac                                           // 0000001614F8: 7F5639AC
	.long 0x7e5639ac                                           // 0000001614FC: 7E5639AC
	s_and_saveexec_b32 s1, s0                                  // 000000161500: BE812000
	s_cbranch_execz 11                                         // 000000161504: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1434>
	global_load_b128 v[43:46], v[61:62], off offset:272        // 000000161508: DC5E0110 2B7C003D
	s_waitcnt vmcnt(0)                                         // 000000161510: BF8903F7
	v_fma_mixlo_f16 v43, v43, s44, 0                           // 000000161514: CC21002B 0200592B
	v_fma_mixhi_f16 v43, v44, s44, 0                           // 00000016151C: CC22002B 0200592C
	v_fma_mixlo_f16 v44, v45, s44, 0                           // 000000161524: CC21002C 0200592D
	v_fma_mixhi_f16 v44, v46, s44, 0                           // 00000016152C: CC22002C 0200592E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000161534: 8C7E017E
	.long 0x7f603880                                           // 000000161538: 7F603880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016153C: BF870001
	.long 0x7f5c39b0                                           // 000000161540: 7F5C39B0
	.long 0x7e5c39b0                                           // 000000161544: 7E5C39B0
	.long 0x7f5a39b0                                           // 000000161548: 7F5A39B0
	.long 0x7e5a39b0                                           // 00000016154C: 7E5A39B0
	s_and_saveexec_b32 s1, s0                                  // 000000161550: BE812000
	s_cbranch_execz 11                                         // 000000161554: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1484>
	global_load_b128 v[49:52], v[61:62], off offset:288        // 000000161558: DC5E0120 317C003D
	s_waitcnt vmcnt(0)                                         // 000000161560: BF8903F7
	v_fma_mixlo_f16 v45, v49, s44, 0                           // 000000161564: CC21002D 02005931
	v_fma_mixhi_f16 v45, v50, s44, 0                           // 00000016156C: CC22002D 02005932
	v_fma_mixlo_f16 v46, v51, s44, 0                           // 000000161574: CC21002E 02005933
	v_fma_mixhi_f16 v46, v52, s44, 0                           // 00000016157C: CC22002E 02005934
	s_or_b32 exec_lo, exec_lo, s1                              // 000000161584: 8C7E017E
	.long 0x7e6039b0                                           // 000000161588: 7E6039B0
	.long 0x7f5e39b0                                           // 00000016158C: 7F5E39B0
	.long 0x7e5e39b0                                           // 000000161590: 7E5E39B0
	s_and_saveexec_b32 s1, s0                                  // 000000161594: BE812000
	s_cbranch_execz 11                                         // 000000161598: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14c8>
	global_load_b128 v[47:50], v[61:62], off offset:304        // 00000016159C: DC5E0130 2F7C003D
	s_waitcnt vmcnt(0)                                         // 0000001615A4: BF8903F7
	v_fma_mixlo_f16 v47, v47, s44, 0                           // 0000001615A8: CC21002F 0200592F
	v_fma_mixhi_f16 v47, v48, s44, 0                           // 0000001615B0: CC22002F 02005930
	v_fma_mixlo_f16 v48, v49, s44, 0                           // 0000001615B8: CC210030 02005931
	v_fma_mixhi_f16 v48, v50, s44, 0                           // 0000001615C0: CC220030 02005932
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001615C8: 8C7E017E
	ds_load_b128 v[50:53], v81 offset:256                      // 0000001615CC: DBFC0100 32000051
	ds_load_b128 v[54:57], v81 offset:272                      // 0000001615D4: DBFC0110 36000051
	ds_load_b128 v[63:66], v81 offset:288                      // 0000001615DC: DBFC0120 3F000051
	ds_load_b128 v[67:70], v81 offset:304                      // 0000001615E4: DBFC0130 43000051
	ds_load_b128 v[90:93], v81 offset:8704                     // 0000001615EC: DBFC2200 5A000051
	ds_load_b128 v[94:97], v81 offset:8720                     // 0000001615F4: DBFC2210 5E000051
	ds_load_b128 v[98:101], v81 offset:8736                    // 0000001615FC: DBFC2220 62000051
	ds_load_b128 v[102:105], v81 offset:8752                   // 000000161604: DBFC2230 66000051
	ds_load_b128 v[106:109], v81 offset:17152                  // 00000016160C: DBFC4300 6A000051
	ds_load_b128 v[110:113], v81 offset:17168                  // 000000161614: DBFC4310 6E000051
	.long 0x7f623880                                           // 00000016161C: 7F623880
	ds_load_b128 v[114:117], v81 offset:25616                  // 000000161620: DBFC6410 72000051
	s_waitcnt lgkmcnt(10)                                      // 000000161628: BF89FCA7
	v_fma_mixlo_f16 v50, v50, s44, 0                           // 00000016162C: CC210032 02005932
	v_fma_mixhi_f16 v50, v51, s44, 0                           // 000000161634: CC220032 02005933
	v_fma_mixlo_f16 v51, v52, s44, 0                           // 00000016163C: CC210033 02005934
	v_fma_mixhi_f16 v51, v53, s44, 0                           // 000000161644: CC220033 02005935
	s_waitcnt lgkmcnt(9)                                       // 00000016164C: BF89FC97
	v_fma_mixlo_f16 v52, v54, s44, 0                           // 000000161650: CC210034 02005936
	v_fma_mixhi_f16 v52, v55, s44, 0                           // 000000161658: CC220034 02005937
	v_fma_mixlo_f16 v53, v56, s44, 0                           // 000000161660: CC210035 02005938
	v_fma_mixhi_f16 v53, v57, s44, 0                           // 000000161668: CC220035 02005939
	s_waitcnt lgkmcnt(8)                                       // 000000161670: BF89FC87
	v_fma_mixlo_f16 v54, v63, s44, 0                           // 000000161674: CC210036 0200593F
	v_fma_mixhi_f16 v54, v64, s44, 0                           // 00000016167C: CC220036 02005940
	v_fma_mixlo_f16 v55, v65, s44, 0                           // 000000161684: CC210037 02005941
	v_fma_mixhi_f16 v55, v66, s44, 0                           // 00000016168C: CC220037 02005942
	s_waitcnt lgkmcnt(7)                                       // 000000161694: BF89FC77
	v_fma_mixlo_f16 v56, v67, s44, 0                           // 000000161698: CC210038 02005943
	v_fma_mixhi_f16 v56, v68, s44, 0                           // 0000001616A0: CC220038 02005944
	v_fma_mixlo_f16 v57, v69, s44, 0                           // 0000001616A8: CC210039 02005945
	v_fma_mixhi_f16 v57, v70, s44, 0                           // 0000001616B0: CC220039 02005946
	s_waitcnt lgkmcnt(6)                                       // 0000001616B8: BF89FC67
	v_fma_mixlo_f16 v63, v90, s44, 0                           // 0000001616BC: CC21003F 0200595A
	v_fma_mixhi_f16 v63, v91, s44, 0                           // 0000001616C4: CC22003F 0200595B
	v_fma_mixlo_f16 v64, v92, s44, 0                           // 0000001616CC: CC210040 0200595C
	v_fma_mixhi_f16 v64, v93, s44, 0                           // 0000001616D4: CC220040 0200595D
	s_waitcnt lgkmcnt(5)                                       // 0000001616DC: BF89FC57
	v_fma_mixlo_f16 v65, v94, s44, 0                           // 0000001616E0: CC210041 0200595E
	v_fma_mixhi_f16 v65, v95, s44, 0                           // 0000001616E8: CC220041 0200595F
	v_fma_mixlo_f16 v66, v96, s44, 0                           // 0000001616F0: CC210042 02005960
	v_fma_mixhi_f16 v66, v97, s44, 0                           // 0000001616F8: CC220042 02005961
	s_waitcnt lgkmcnt(4)                                       // 000000161700: BF89FC47
	v_fma_mixlo_f16 v67, v98, s44, 0                           // 000000161704: CC210043 02005962
	ds_load_b128 v[94:97], v81 offset:17184                    // 00000016170C: DBFC4320 5E000051
	v_fma_mixhi_f16 v67, v99, s44, 0                           // 000000161714: CC220043 02005963
	v_fma_mixlo_f16 v68, v100, s44, 0                          // 00000016171C: CC210044 02005964
	v_fma_mixhi_f16 v68, v101, s44, 0                          // 000000161724: CC220044 02005965
	s_waitcnt lgkmcnt(4)                                       // 00000016172C: BF89FC47
	v_fma_mixlo_f16 v69, v102, s44, 0                          // 000000161730: CC210045 02005966
	ds_load_b128 v[98:101], v81 offset:17200                   // 000000161738: DBFC4330 62000051
	v_fma_mixhi_f16 v69, v103, s44, 0                          // 000000161740: CC220045 02005967
	v_fma_mixlo_f16 v70, v104, s44, 0                          // 000000161748: CC210046 02005968
	v_fma_mixhi_f16 v70, v105, s44, 0                          // 000000161750: CC220046 02005969
	ds_load_b128 v[102:105], v81 offset:25600                  // 000000161758: DBFC6400 66000051
	s_waitcnt lgkmcnt(5)                                       // 000000161760: BF89FC57
	v_fma_mixlo_f16 v90, v106, s44, 0                          // 000000161764: CC21005A 0200596A
	v_fma_mixhi_f16 v90, v107, s44, 0                          // 00000016176C: CC22005A 0200596B
	v_fma_mixlo_f16 v91, v108, s44, 0                          // 000000161774: CC21005B 0200596C
	v_fma_mixhi_f16 v91, v109, s44, 0                          // 00000016177C: CC22005B 0200596D
	s_waitcnt lgkmcnt(4)                                       // 000000161784: BF89FC47
	v_fma_mixlo_f16 v92, v110, s44, 0                          // 000000161788: CC21005C 0200596E
	v_fma_mixhi_f16 v92, v111, s44, 0                          // 000000161790: CC22005C 0200596F
	ds_load_b128 v[106:109], v81 offset:25632                  // 000000161798: DBFC6420 6A000051
	v_fma_mixlo_f16 v93, v112, s44, 0                          // 0000001617A0: CC21005D 02005970
	v_fma_mixhi_f16 v93, v113, s44, 0                          // 0000001617A8: CC22005D 02005971
	ds_load_b128 v[110:113], v81 offset:25648                  // 0000001617B0: DBFC6430 6E000051
	s_waitcnt lgkmcnt(4)                                       // 0000001617B8: BF89FC47
	v_fma_mixlo_f16 v94, v94, s44, 0                           // 0000001617BC: CC21005E 0200595E
	v_fma_mixhi_f16 v94, v95, s44, 0                           // 0000001617C4: CC22005E 0200595F
	v_fma_mixlo_f16 v95, v96, s44, 0                           // 0000001617CC: CC21005F 02005960
	v_fma_mixhi_f16 v95, v97, s44, 0                           // 0000001617D4: CC22005F 02005961
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[50:57], v[33:40]// 0000001617DC: CC404021 1C866529
	s_waitcnt lgkmcnt(3)                                       // 0000001617E4: BF89FC37
	v_fma_mixlo_f16 v96, v98, s44, 0                           // 0000001617E8: CC210060 02005962
	v_fma_mixhi_f16 v96, v99, s44, 0                           // 0000001617F0: CC220060 02005963
	v_fma_mixlo_f16 v97, v100, s44, 0                          // 0000001617F8: CC210061 02005964
	v_fma_mixhi_f16 v97, v101, s44, 0                          // 000000161800: CC220061 02005965
	s_waitcnt lgkmcnt(2)                                       // 000000161808: BF89FC27
	v_fma_mixlo_f16 v98, v102, s44, 0                          // 00000016180C: CC210062 02005966
	v_fma_mixhi_f16 v98, v103, s44, 0                          // 000000161814: CC220062 02005967
	v_fma_mixlo_f16 v99, v104, s44, 0                          // 00000016181C: CC210063 02005968
	v_fma_mixhi_f16 v99, v105, s44, 0                          // 000000161824: CC220063 02005969
	v_fma_mixlo_f16 v100, v114, s44, 0                         // 00000016182C: CC210064 02005972
	v_fma_mixhi_f16 v100, v115, s44, 0                         // 000000161834: CC220064 02005973
	v_fma_mixlo_f16 v101, v116, s44, 0                         // 00000016183C: CC210065 02005974
	v_fma_mixhi_f16 v101, v117, s44, 0                         // 000000161844: CC220065 02005975
	s_waitcnt lgkmcnt(1)                                       // 00000016184C: BF89FC17
	v_fma_mixlo_f16 v102, v106, s44, 0                         // 000000161850: CC210066 0200596A
	v_fma_mixhi_f16 v102, v107, s44, 0                         // 000000161858: CC220066 0200596B
	v_fma_mixlo_f16 v103, v108, s44, 0                         // 000000161860: CC210067 0200596C
	v_fma_mixhi_f16 v103, v109, s44, 0                         // 000000161868: CC220067 0200596D
	s_waitcnt lgkmcnt(0)                                       // 000000161870: BF89FC07
	v_fma_mixlo_f16 v104, v110, s44, 0                         // 000000161874: CC210068 0200596E
	v_fma_mixhi_f16 v104, v111, s44, 0                         // 00000016187C: CC220068 0200596F
	v_fma_mixlo_f16 v105, v112, s44, 0                         // 000000161884: CC210069 02005970
	v_fma_mixhi_f16 v105, v113, s44, 0                         // 00000016188C: CC220069 02005971
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[63:70], v[25:32]// 000000161894: CC404019 1C667F29
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[90:97], v[17:24]// 00000016189C: CC404011 1C46B529
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001618A4: BF870003
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[98:105], v[9:16]// 0000001618A8: CC404009 1C26C529
	.long 0x7f5e39b1                                           // 0000001618B0: 7F5E39B1
	.long 0x7e5e39b1                                           // 0000001618B4: 7E5E39B1
	.long 0x7f5c39b1                                           // 0000001618B8: 7F5C39B1
	.long 0x7e5c39b1                                           // 0000001618BC: 7E5C39B1
	s_and_saveexec_b32 s1, s0                                  // 0000001618C0: BE812000
	s_cbranch_execz 11                                         // 0000001618C4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17f4>
	global_load_b128 v[41:44], v[61:62], off offset:320        // 0000001618C8: DC5E0140 297C003D
	s_waitcnt vmcnt(0)                                         // 0000001618D0: BF8903F7
	v_fma_mixlo_f16 v46, v41, s44, 0                           // 0000001618D4: CC21002E 02005929
	v_fma_mixhi_f16 v46, v42, s44, 0                           // 0000001618DC: CC22002E 0200592A
	v_fma_mixlo_f16 v47, v43, s44, 0                           // 0000001618E4: CC21002F 0200592B
	v_fma_mixhi_f16 v47, v44, s44, 0                           // 0000001618EC: CC22002F 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001618F4: 8C7E017E
	.long 0x7e6239b1                                           // 0000001618F8: 7E6239B1
	.long 0x7f6039b1                                           // 0000001618FC: 7F6039B1
	.long 0x7e6039b1                                           // 000000161900: 7E6039B1
	s_and_saveexec_b32 s1, s0                                  // 000000161904: BE812000
	s_cbranch_execz 11                                         // 000000161908: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1838>
	global_load_b128 v[41:44], v[61:62], off offset:336        // 00000016190C: DC5E0150 297C003D
	s_waitcnt vmcnt(0)                                         // 000000161914: BF8903F7
	v_fma_mixlo_f16 v48, v41, s44, 0                           // 000000161918: CC210030 02005929
	v_fma_mixhi_f16 v48, v42, s44, 0                           // 000000161920: CC220030 0200592A
	v_fma_mixlo_f16 v49, v43, s44, 0                           // 000000161928: CC210031 0200592B
	v_fma_mixhi_f16 v49, v44, s44, 0                           // 000000161930: CC220031 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000161938: 8C7E017E
	.long 0x7f6a3880                                           // 00000016193C: 7F6A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000161940: BF870001
	.long 0x7f6639b5                                           // 000000161944: 7F6639B5
	.long 0x7e6639b5                                           // 000000161948: 7E6639B5
	.long 0x7f6439b5                                           // 00000016194C: 7F6439B5
	.long 0x7e6439b5                                           // 000000161950: 7E6439B5
	s_and_saveexec_b32 s1, s0                                  // 000000161954: BE812000
	s_cbranch_execz 11                                         // 000000161958: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1888>
	global_load_b128 v[41:44], v[61:62], off offset:352        // 00000016195C: DC5E0160 297C003D
	s_waitcnt vmcnt(0)                                         // 000000161964: BF8903F7
	v_fma_mixlo_f16 v50, v41, s44, 0                           // 000000161968: CC210032 02005929
	v_fma_mixhi_f16 v50, v42, s44, 0                           // 000000161970: CC220032 0200592A
	v_fma_mixlo_f16 v51, v43, s44, 0                           // 000000161978: CC210033 0200592B
	v_fma_mixhi_f16 v51, v44, s44, 0                           // 000000161980: CC220033 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000161988: 8C7E017E
	.long 0x7e6a39b5                                           // 00000016198C: 7E6A39B5
	.long 0x7f6839b5                                           // 000000161990: 7F6839B5
	.long 0x7e6839b5                                           // 000000161994: 7E6839B5
	s_and_saveexec_b32 s1, s0                                  // 000000161998: BE812000
	s_cbranch_execz 11                                         // 00000016199C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18cc>
	global_load_b128 v[41:44], v[61:62], off offset:368        // 0000001619A0: DC5E0170 297C003D
	s_waitcnt vmcnt(0)                                         // 0000001619A8: BF8903F7
	v_fma_mixlo_f16 v52, v41, s44, 0                           // 0000001619AC: CC210034 02005929
	v_fma_mixhi_f16 v52, v42, s44, 0                           // 0000001619B4: CC220034 0200592A
	v_fma_mixlo_f16 v53, v43, s44, 0                           // 0000001619BC: CC210035 0200592B
	v_fma_mixhi_f16 v53, v44, s44, 0                           // 0000001619C4: CC220035 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001619CC: 8C7E017E
	ds_load_b128 v[41:44], v81 offset:320                      // 0000001619D0: DBFC0140 29000051
	ds_load_b128 v[54:57], v81 offset:336                      // 0000001619D8: DBFC0150 36000051
	ds_load_b128 v[67:70], v81 offset:352                      // 0000001619E0: DBFC0160 43000051
	ds_load_b128 v[90:93], v81 offset:368                      // 0000001619E8: DBFC0170 5A000051
	ds_load_b128 v[94:97], v81 offset:8768                     // 0000001619F0: DBFC2240 5E000051
	ds_load_b128 v[98:101], v81 offset:8784                    // 0000001619F8: DBFC2250 62000051
	ds_load_b128 v[102:105], v81 offset:8800                   // 000000161A00: DBFC2260 66000051
	ds_load_b128 v[106:109], v81 offset:8816                   // 000000161A08: DBFC2270 6A000051
	ds_load_b128 v[110:113], v81 offset:17248                  // 000000161A10: DBFC4360 6E000051
	ds_load_b128 v[114:117], v81 offset:17264                  // 000000161A18: DBFC4370 72000051
	ds_load_b128 v[118:121], v81 offset:25680                  // 000000161A20: DBFC6450 76000051
	s_waitcnt lgkmcnt(10)                                      // 000000161A28: BF89FCA7
	v_fma_mixlo_f16 v63, v41, s44, 0                           // 000000161A2C: CC21003F 02005929
	v_fma_mixhi_f16 v63, v42, s44, 0                           // 000000161A34: CC22003F 0200592A
	v_fma_mixlo_f16 v64, v43, s44, 0                           // 000000161A3C: CC210040 0200592B
	v_fma_mixhi_f16 v64, v44, s44, 0                           // 000000161A44: CC220040 0200592C
	s_waitcnt lgkmcnt(9)                                       // 000000161A4C: BF89FC97
	v_fma_mixlo_f16 v65, v54, s44, 0                           // 000000161A50: CC210041 02005936
	v_fma_mixhi_f16 v65, v55, s44, 0                           // 000000161A58: CC220041 02005937
	v_fma_mixlo_f16 v66, v56, s44, 0                           // 000000161A60: CC210042 02005938
	v_fma_mixhi_f16 v66, v57, s44, 0                           // 000000161A68: CC220042 02005939
	ds_load_b128 v[41:44], v81 offset:17216                    // 000000161A70: DBFC4340 29000051
	ds_load_b128 v[54:57], v81 offset:17232                    // 000000161A78: DBFC4350 36000051
	s_waitcnt lgkmcnt(10)                                      // 000000161A80: BF89FCA7
	v_fma_mixlo_f16 v67, v67, s44, 0                           // 000000161A84: CC210043 02005943
	v_fma_mixhi_f16 v67, v68, s44, 0                           // 000000161A8C: CC220043 02005944
	v_fma_mixlo_f16 v68, v69, s44, 0                           // 000000161A94: CC210044 02005945
	v_fma_mixhi_f16 v68, v70, s44, 0                           // 000000161A9C: CC220044 02005946
	s_waitcnt lgkmcnt(9)                                       // 000000161AA4: BF89FC97
	v_fma_mixhi_f16 v69, v91, s44, 0                           // 000000161AA8: CC220045 0200595B
	v_fma_mixlo_f16 v70, v92, s44, 0                           // 000000161AB0: CC210046 0200595C
	v_fma_mixhi_f16 v70, v93, s44, 0                           // 000000161AB8: CC220046 0200595D
	s_waitcnt lgkmcnt(8)                                       // 000000161AC0: BF89FC87
	v_fma_mixlo_f16 v91, v96, s44, 0                           // 000000161AC4: CC21005B 02005960
	v_fma_mixhi_f16 v91, v97, s44, 0                           // 000000161ACC: CC22005B 02005961
	s_waitcnt lgkmcnt(7)                                       // 000000161AD4: BF89FC77
	v_fma_mixlo_f16 v92, v98, s44, 0                           // 000000161AD8: CC21005C 02005962
	v_fma_mixhi_f16 v92, v99, s44, 0                           // 000000161AE0: CC22005C 02005963
	v_fma_mixlo_f16 v93, v100, s44, 0                          // 000000161AE8: CC21005D 02005964
	v_fma_mixhi_f16 v93, v101, s44, 0                          // 000000161AF0: CC22005D 02005965
	s_waitcnt lgkmcnt(5)                                       // 000000161AF8: BF89FC57
	v_fma_mixlo_f16 v96, v106, s44, 0                          // 000000161AFC: CC210060 0200596A
	v_fma_mixhi_f16 v96, v107, s44, 0                          // 000000161B04: CC220060 0200596B
	v_fma_mixlo_f16 v97, v108, s44, 0                          // 000000161B0C: CC210061 0200596C
	v_fma_mixhi_f16 v97, v109, s44, 0                          // 000000161B14: CC220061 0200596D
	ds_load_b128 v[106:109], v81 offset:25664                  // 000000161B1C: DBFC6440 6A000051
	s_waitcnt lgkmcnt(2)                                       // 000000161B24: BF89FC27
	v_fma_mixlo_f16 v98, v41, s44, 0                           // 000000161B28: CC210062 02005929
	v_fma_mixhi_f16 v98, v42, s44, 0                           // 000000161B30: CC220062 0200592A
	v_fma_mixlo_f16 v99, v43, s44, 0                           // 000000161B38: CC210063 0200592B
	v_fma_mixhi_f16 v99, v44, s44, 0                           // 000000161B40: CC220063 0200592C
	s_waitcnt lgkmcnt(1)                                       // 000000161B48: BF89FC17
	v_fma_mixlo_f16 v100, v54, s44, 0                          // 000000161B4C: CC210064 02005936
	v_fma_mixhi_f16 v100, v55, s44, 0                          // 000000161B54: CC220064 02005937
	ds_load_b128 v[41:44], v81 offset:25696                    // 000000161B5C: DBFC6460 29000051
	v_fma_mixlo_f16 v101, v56, s44, 0                          // 000000161B64: CC210065 02005938
	v_fma_mixhi_f16 v101, v57, s44, 0                          // 000000161B6C: CC220065 02005939
	ds_load_b128 v[54:57], v81 offset:25712                    // 000000161B74: DBFC6470 36000051
	v_fma_mixlo_f16 v69, v90, s44, 0                           // 000000161B7C: CC210045 0200595A
	v_fma_mixlo_f16 v90, v94, s44, 0                           // 000000161B84: CC21005A 0200595E
	v_fma_mixhi_f16 v90, v95, s44, 0                           // 000000161B8C: CC22005A 0200595F
	v_fma_mixlo_f16 v94, v102, s44, 0                          // 000000161B94: CC21005E 02005966
	v_fma_mixhi_f16 v94, v103, s44, 0                          // 000000161B9C: CC22005E 02005967
	v_fma_mixlo_f16 v95, v104, s44, 0                          // 000000161BA4: CC21005F 02005968
	v_fma_mixhi_f16 v95, v105, s44, 0                          // 000000161BAC: CC22005F 02005969
	v_fma_mixlo_f16 v102, v110, s44, 0                         // 000000161BB4: CC210066 0200596E
	v_fma_mixhi_f16 v102, v111, s44, 0                         // 000000161BBC: CC220066 0200596F
	v_fma_mixlo_f16 v103, v112, s44, 0                         // 000000161BC4: CC210067 02005970
	v_fma_mixhi_f16 v103, v113, s44, 0                         // 000000161BCC: CC220067 02005971
	v_fma_mixlo_f16 v104, v114, s44, 0                         // 000000161BD4: CC210068 02005972
	v_fma_mixhi_f16 v104, v115, s44, 0                         // 000000161BDC: CC220068 02005973
	v_fma_mixlo_f16 v105, v116, s44, 0                         // 000000161BE4: CC210069 02005974
	v_fma_mixhi_f16 v105, v117, s44, 0                         // 000000161BEC: CC220069 02005975
	s_waitcnt lgkmcnt(2)                                       // 000000161BF4: BF89FC27
	v_fma_mixlo_f16 v106, v106, s44, 0                         // 000000161BF8: CC21006A 0200596A
	v_fma_mixhi_f16 v106, v107, s44, 0                         // 000000161C00: CC22006A 0200596B
	v_fma_mixlo_f16 v107, v108, s44, 0                         // 000000161C08: CC21006B 0200596C
	v_fma_mixhi_f16 v107, v109, s44, 0                         // 000000161C10: CC22006B 0200596D
	v_fma_mixlo_f16 v108, v118, s44, 0                         // 000000161C18: CC21006C 02005976
	v_fma_mixhi_f16 v108, v119, s44, 0                         // 000000161C20: CC22006C 02005977
	v_fma_mixlo_f16 v109, v120, s44, 0                         // 000000161C28: CC21006D 02005978
	v_fma_mixhi_f16 v109, v121, s44, 0                         // 000000161C30: CC22006D 02005979
	s_waitcnt lgkmcnt(1)                                       // 000000161C38: BF89FC17
	v_fma_mixlo_f16 v110, v41, s44, 0                          // 000000161C3C: CC21006E 02005929
	v_fma_mixhi_f16 v110, v42, s44, 0                          // 000000161C44: CC22006E 0200592A
	v_fma_mixlo_f16 v111, v43, s44, 0                          // 000000161C4C: CC21006F 0200592B
	v_fma_mixhi_f16 v111, v44, s44, 0                          // 000000161C54: CC22006F 0200592C
	s_waitcnt lgkmcnt(0)                                       // 000000161C5C: BF89FC07
	v_fma_mixlo_f16 v112, v54, s44, 0                          // 000000161C60: CC210070 02005936
	v_fma_mixhi_f16 v112, v55, s44, 0                          // 000000161C68: CC220070 02005937
	v_fma_mixlo_f16 v113, v56, s44, 0                          // 000000161C70: CC210071 02005938
	v_fma_mixhi_f16 v113, v57, s44, 0                          // 000000161C78: CC220071 02005939
	.long 0x7f6c3880                                           // 000000161C80: 7F6C3880
	v_wmma_f32_16x16x16_f16 v[33:40], v[46:53], v[63:70], v[33:40]// 000000161C84: CC404021 1C867F2E
	v_wmma_f32_16x16x16_f16 v[25:32], v[46:53], v[90:97], v[25:32]// 000000161C8C: CC404019 1C66B52E
	v_wmma_f32_16x16x16_f16 v[17:24], v[46:53], v[98:105], v[17:24]// 000000161C94: CC404011 1C46C52E
	v_wmma_f32_16x16x16_f16 v[9:16], v[46:53], v[106:113], v[9:16]// 000000161C9C: CC404009 1C26D52E
	.long 0x7f6839b6                                           // 000000161CA4: 7F6839B6
	.long 0x7e6839b6                                           // 000000161CA8: 7E6839B6
	.long 0x7f6639b6                                           // 000000161CAC: 7F6639B6
	.long 0x7e6639b6                                           // 000000161CB0: 7E6639B6
	s_and_saveexec_b32 s1, s0                                  // 000000161CB4: BE812000
	s_cbranch_execz 11                                         // 000000161CB8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1be8>
	global_load_b128 v[41:44], v[61:62], off offset:384        // 000000161CBC: DC5E0180 297C003D
	s_waitcnt vmcnt(0)                                         // 000000161CC4: BF8903F7
	v_fma_mixlo_f16 v51, v41, s44, 0                           // 000000161CC8: CC210033 02005929
	v_fma_mixhi_f16 v51, v42, s44, 0                           // 000000161CD0: CC220033 0200592A
	v_fma_mixlo_f16 v52, v43, s44, 0                           // 000000161CD8: CC210034 0200592B
	v_fma_mixhi_f16 v52, v44, s44, 0                           // 000000161CE0: CC220034 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000161CE8: 8C7E017E
	.long 0x7e6c39b6                                           // 000000161CEC: 7E6C39B6
	.long 0x7f6a39b6                                           // 000000161CF0: 7F6A39B6
	.long 0x7e6a39b6                                           // 000000161CF4: 7E6A39B6
	s_and_saveexec_b32 s1, s0                                  // 000000161CF8: BE812000
	s_cbranch_execz 11                                         // 000000161CFC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c2c>
	global_load_b128 v[41:44], v[61:62], off offset:400        // 000000161D00: DC5E0190 297C003D
	s_waitcnt vmcnt(0)                                         // 000000161D08: BF8903F7
	v_fma_mixlo_f16 v53, v41, s44, 0                           // 000000161D0C: CC210035 02005929
	v_fma_mixhi_f16 v53, v42, s44, 0                           // 000000161D14: CC220035 0200592A
	v_fma_mixlo_f16 v54, v43, s44, 0                           // 000000161D1C: CC210036 0200592B
	v_fma_mixhi_f16 v54, v44, s44, 0                           // 000000161D24: CC220036 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000161D2C: 8C7E017E
	.long 0x7f743880                                           // 000000161D30: 7F743880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000161D34: BF870001
	.long 0x7f7039ba                                           // 000000161D38: 7F7039BA
	.long 0x7e7039ba                                           // 000000161D3C: 7E7039BA
	.long 0x7f6e39ba                                           // 000000161D40: 7F6E39BA
	.long 0x7e6e39ba                                           // 000000161D44: 7E6E39BA
	s_and_saveexec_b32 s1, s0                                  // 000000161D48: BE812000
	s_cbranch_execz 11                                         // 000000161D4C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c7c>
	global_load_b128 v[41:44], v[61:62], off offset:416        // 000000161D50: DC5E01A0 297C003D
	s_waitcnt vmcnt(0)                                         // 000000161D58: BF8903F7
	v_fma_mixlo_f16 v55, v41, s44, 0                           // 000000161D5C: CC210037 02005929
	v_fma_mixhi_f16 v55, v42, s44, 0                           // 000000161D64: CC220037 0200592A
	v_fma_mixlo_f16 v56, v43, s44, 0                           // 000000161D6C: CC210038 0200592B
	v_fma_mixhi_f16 v56, v44, s44, 0                           // 000000161D74: CC220038 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000161D7C: 8C7E017E
	.long 0x7e7439ba                                           // 000000161D80: 7E7439BA
	.long 0x7f7239ba                                           // 000000161D84: 7F7239BA
	.long 0x7e7239ba                                           // 000000161D88: 7E7239BA
	s_and_saveexec_b32 s1, s0                                  // 000000161D8C: BE812000
	s_cbranch_execz 11                                         // 000000161D90: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	global_load_b128 v[41:44], v[61:62], off offset:432        // 000000161D94: DC5E01B0 297C003D
	s_waitcnt vmcnt(0)                                         // 000000161D9C: BF8903F7
	v_fma_mixlo_f16 v57, v41, s44, 0                           // 000000161DA0: CC210039 02005929
	v_fma_mixhi_f16 v57, v42, s44, 0                           // 000000161DA8: CC220039 0200592A
	v_fma_mixlo_f16 v58, v43, s44, 0                           // 000000161DB0: CC21003A 0200592B
	v_fma_mixhi_f16 v58, v44, s44, 0                           // 000000161DB8: CC22003A 0200592C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000161DC0: 8C7E017E
	ds_load_b128 v[41:44], v81 offset:384                      // 000000161DC4: DBFC0180 29000051
	ds_load_b128 v[45:48], v81 offset:400                      // 000000161DCC: DBFC0190 2D000051
	ds_load_b128 v[67:70], v81 offset:416                      // 000000161DD4: DBFC01A0 43000051
	ds_load_b128 v[90:93], v81 offset:432                      // 000000161DDC: DBFC01B0 5A000051
	ds_load_b128 v[94:97], v81 offset:8832                     // 000000161DE4: DBFC2280 5E000051
	ds_load_b128 v[98:101], v81 offset:8848                    // 000000161DEC: DBFC2290 62000051
	ds_load_b128 v[102:105], v81 offset:8864                   // 000000161DF4: DBFC22A0 66000051
	ds_load_b128 v[106:109], v81 offset:8880                   // 000000161DFC: DBFC22B0 6A000051
	ds_load_b128 v[110:113], v81 offset:17312                  // 000000161E04: DBFC43A0 6E000051
	ds_load_b128 v[114:117], v81 offset:17328                  // 000000161E0C: DBFC43B0 72000051
	ds_load_b128 v[118:121], v81 offset:25744                  // 000000161E14: DBFC6490 76000051
	s_waitcnt lgkmcnt(10)                                      // 000000161E1C: BF89FCA7
	v_fma_mixlo_f16 v63, v41, s44, 0                           // 000000161E20: CC21003F 02005929
	v_fma_mixhi_f16 v63, v42, s44, 0                           // 000000161E28: CC22003F 0200592A
	v_fma_mixlo_f16 v64, v43, s44, 0                           // 000000161E30: CC210040 0200592B
	v_fma_mixhi_f16 v64, v44, s44, 0                           // 000000161E38: CC220040 0200592C
	s_waitcnt lgkmcnt(9)                                       // 000000161E40: BF89FC97
	v_fma_mixlo_f16 v65, v45, s44, 0                           // 000000161E44: CC210041 0200592D
	v_fma_mixhi_f16 v65, v46, s44, 0                           // 000000161E4C: CC220041 0200592E
	v_fma_mixlo_f16 v66, v47, s44, 0                           // 000000161E54: CC210042 0200592F
	v_fma_mixhi_f16 v66, v48, s44, 0                           // 000000161E5C: CC220042 02005930
	ds_load_b128 v[41:44], v81 offset:17280                    // 000000161E64: DBFC4380 29000051
	ds_load_b128 v[45:48], v81 offset:17296                    // 000000161E6C: DBFC4390 2D000051
	s_waitcnt lgkmcnt(10)                                      // 000000161E74: BF89FCA7
	v_fma_mixlo_f16 v67, v67, s44, 0                           // 000000161E78: CC210043 02005943
	v_fma_mixhi_f16 v67, v68, s44, 0                           // 000000161E80: CC220043 02005944
	v_fma_mixlo_f16 v68, v69, s44, 0                           // 000000161E88: CC210044 02005945
	v_fma_mixhi_f16 v68, v70, s44, 0                           // 000000161E90: CC220044 02005946
	s_waitcnt lgkmcnt(9)                                       // 000000161E98: BF89FC97
	v_fma_mixhi_f16 v69, v91, s44, 0                           // 000000161E9C: CC220045 0200595B
	v_fma_mixlo_f16 v70, v92, s44, 0                           // 000000161EA4: CC210046 0200595C
	v_fma_mixhi_f16 v70, v93, s44, 0                           // 000000161EAC: CC220046 0200595D
	s_waitcnt lgkmcnt(8)                                       // 000000161EB4: BF89FC87
	v_fma_mixlo_f16 v91, v96, s44, 0                           // 000000161EB8: CC21005B 02005960
	v_fma_mixhi_f16 v91, v97, s44, 0                           // 000000161EC0: CC22005B 02005961
	s_waitcnt lgkmcnt(7)                                       // 000000161EC8: BF89FC77
	v_fma_mixlo_f16 v92, v98, s44, 0                           // 000000161ECC: CC21005C 02005962
	v_fma_mixhi_f16 v92, v99, s44, 0                           // 000000161ED4: CC22005C 02005963
	v_fma_mixlo_f16 v93, v100, s44, 0                          // 000000161EDC: CC21005D 02005964
	v_fma_mixhi_f16 v93, v101, s44, 0                          // 000000161EE4: CC22005D 02005965
	s_waitcnt lgkmcnt(5)                                       // 000000161EEC: BF89FC57
	v_fma_mixlo_f16 v96, v106, s44, 0                          // 000000161EF0: CC210060 0200596A
	v_fma_mixhi_f16 v96, v107, s44, 0                          // 000000161EF8: CC220060 0200596B
	v_fma_mixlo_f16 v97, v108, s44, 0                          // 000000161F00: CC210061 0200596C
	v_fma_mixhi_f16 v97, v109, s44, 0                          // 000000161F08: CC220061 0200596D
	ds_load_b128 v[106:109], v81 offset:25728                  // 000000161F10: DBFC6480 6A000051
	s_waitcnt lgkmcnt(2)                                       // 000000161F18: BF89FC27
	v_fma_mixlo_f16 v98, v41, s44, 0                           // 000000161F1C: CC210062 02005929
	v_fma_mixhi_f16 v98, v42, s44, 0                           // 000000161F24: CC220062 0200592A
	v_fma_mixlo_f16 v99, v43, s44, 0                           // 000000161F2C: CC210063 0200592B
	v_fma_mixhi_f16 v99, v44, s44, 0                           // 000000161F34: CC220063 0200592C
	s_waitcnt lgkmcnt(1)                                       // 000000161F3C: BF89FC17
	v_fma_mixlo_f16 v100, v45, s44, 0                          // 000000161F40: CC210064 0200592D
	v_fma_mixhi_f16 v100, v46, s44, 0                          // 000000161F48: CC220064 0200592E
	ds_load_b128 v[41:44], v81 offset:25760                    // 000000161F50: DBFC64A0 29000051
	v_fma_mixlo_f16 v101, v47, s44, 0                          // 000000161F58: CC210065 0200592F
	v_fma_mixhi_f16 v101, v48, s44, 0                          // 000000161F60: CC220065 02005930
	ds_load_b128 v[45:48], v81 offset:25776                    // 000000161F68: DBFC64B0 2D000051
	v_fma_mixlo_f16 v69, v90, s44, 0                           // 000000161F70: CC210045 0200595A
	v_fma_mixlo_f16 v90, v94, s44, 0                           // 000000161F78: CC21005A 0200595E
	v_fma_mixhi_f16 v90, v95, s44, 0                           // 000000161F80: CC22005A 0200595F
	v_fma_mixlo_f16 v94, v102, s44, 0                          // 000000161F88: CC21005E 02005966
	v_fma_mixhi_f16 v94, v103, s44, 0                          // 000000161F90: CC22005E 02005967
	v_fma_mixlo_f16 v95, v104, s44, 0                          // 000000161F98: CC21005F 02005968
	v_fma_mixhi_f16 v95, v105, s44, 0                          // 000000161FA0: CC22005F 02005969
	v_fma_mixlo_f16 v102, v110, s44, 0                         // 000000161FA8: CC210066 0200596E
	v_fma_mixhi_f16 v102, v111, s44, 0                         // 000000161FB0: CC220066 0200596F
	v_fma_mixlo_f16 v103, v112, s44, 0                         // 000000161FB8: CC210067 02005970
	v_fma_mixhi_f16 v103, v113, s44, 0                         // 000000161FC0: CC220067 02005971
	v_fma_mixlo_f16 v104, v114, s44, 0                         // 000000161FC8: CC210068 02005972
	v_fma_mixhi_f16 v104, v115, s44, 0                         // 000000161FD0: CC220068 02005973
	v_fma_mixlo_f16 v105, v116, s44, 0                         // 000000161FD8: CC210069 02005974
	v_fma_mixhi_f16 v105, v117, s44, 0                         // 000000161FE0: CC220069 02005975
	s_waitcnt lgkmcnt(2)                                       // 000000161FE8: BF89FC27
	v_fma_mixlo_f16 v106, v106, s44, 0                         // 000000161FEC: CC21006A 0200596A
	v_fma_mixhi_f16 v106, v107, s44, 0                         // 000000161FF4: CC22006A 0200596B
	v_fma_mixlo_f16 v107, v108, s44, 0                         // 000000161FFC: CC21006B 0200596C
	v_fma_mixhi_f16 v107, v109, s44, 0                         // 000000162004: CC22006B 0200596D
	v_fma_mixlo_f16 v108, v118, s44, 0                         // 00000016200C: CC21006C 02005976
	v_fma_mixhi_f16 v108, v119, s44, 0                         // 000000162014: CC22006C 02005977
	v_fma_mixlo_f16 v109, v120, s44, 0                         // 00000016201C: CC21006D 02005978
	v_fma_mixhi_f16 v109, v121, s44, 0                         // 000000162024: CC22006D 02005979
	s_waitcnt lgkmcnt(1)                                       // 00000016202C: BF89FC17
	v_fma_mixlo_f16 v110, v41, s44, 0                          // 000000162030: CC21006E 02005929
	v_fma_mixhi_f16 v110, v42, s44, 0                          // 000000162038: CC22006E 0200592A
	v_fma_mixlo_f16 v111, v43, s44, 0                          // 000000162040: CC21006F 0200592B
	v_fma_mixhi_f16 v111, v44, s44, 0                          // 000000162048: CC22006F 0200592C
	s_waitcnt lgkmcnt(0)                                       // 000000162050: BF89FC07
	v_fma_mixlo_f16 v112, v45, s44, 0                          // 000000162054: CC210070 0200592D
	v_fma_mixhi_f16 v112, v46, s44, 0                          // 00000016205C: CC220070 0200592E
	v_fma_mixlo_f16 v113, v47, s44, 0                          // 000000162064: CC210071 0200592F
	v_fma_mixhi_f16 v113, v48, s44, 0                          // 00000016206C: CC220071 02005930
	.long 0x7f583880                                           // 000000162074: 7F583880
	v_wmma_f32_16x16x16_f16 v[33:40], v[51:58], v[63:70], v[33:40]// 000000162078: CC404021 1C867F33
	v_wmma_f32_16x16x16_f16 v[25:32], v[51:58], v[90:97], v[25:32]// 000000162080: CC404019 1C66B533
	v_wmma_f32_16x16x16_f16 v[17:24], v[51:58], v[98:105], v[17:24]// 000000162088: CC404011 1C46C533
	v_wmma_f32_16x16x16_f16 v[9:16], v[51:58], v[106:113], v[9:16]// 000000162090: CC404009 1C26D533
	.long 0x7f5439ac                                           // 000000162098: 7F5439AC
	.long 0x7e5439ac                                           // 00000016209C: 7E5439AC
	.long 0x7f5239ac                                           // 0000001620A0: 7F5239AC
	.long 0x7e5239ac                                           // 0000001620A4: 7E5239AC
	s_and_saveexec_b32 s1, s0                                  // 0000001620A8: BE812000
	s_cbranch_execz 11                                         // 0000001620AC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fdc>
	global_load_b128 v[45:48], v[61:62], off offset:448        // 0000001620B0: DC5E01C0 2D7C003D
	s_waitcnt vmcnt(0)                                         // 0000001620B8: BF8903F7
	v_fma_mixlo_f16 v41, v45, s44, 0                           // 0000001620BC: CC210029 0200592D
	v_fma_mixhi_f16 v41, v46, s44, 0                           // 0000001620C4: CC220029 0200592E
	v_fma_mixlo_f16 v42, v47, s44, 0                           // 0000001620CC: CC21002A 0200592F
	v_fma_mixhi_f16 v42, v48, s44, 0                           // 0000001620D4: CC22002A 02005930
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001620DC: 8C7E017E
	.long 0x7e5839ac                                           // 0000001620E0: 7E5839AC
	.long 0x7f5639ac                                           // 0000001620E4: 7F5639AC
	.long 0x7e5639ac                                           // 0000001620E8: 7E5639AC
	s_and_saveexec_b32 s1, s0                                  // 0000001620EC: BE812000
	s_cbranch_execz 11                                         // 0000001620F0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2020>
	global_load_b128 v[43:46], v[61:62], off offset:464        // 0000001620F4: DC5E01D0 2B7C003D
	s_waitcnt vmcnt(0)                                         // 0000001620FC: BF8903F7
	v_fma_mixlo_f16 v43, v43, s44, 0                           // 000000162100: CC21002B 0200592B
	v_fma_mixhi_f16 v43, v44, s44, 0                           // 000000162108: CC22002B 0200592C
	v_fma_mixlo_f16 v44, v45, s44, 0                           // 000000162110: CC21002C 0200592D
	v_fma_mixhi_f16 v44, v46, s44, 0                           // 000000162118: CC22002C 0200592E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000162120: 8C7E017E
	.long 0x7f603880                                           // 000000162124: 7F603880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000162128: BF870001
	.long 0x7f5c39b0                                           // 00000016212C: 7F5C39B0
	.long 0x7e5c39b0                                           // 000000162130: 7E5C39B0
	.long 0x7f5a39b0                                           // 000000162134: 7F5A39B0
	.long 0x7e5a39b0                                           // 000000162138: 7E5A39B0
	s_and_saveexec_b32 s1, s0                                  // 00000016213C: BE812000
	s_cbranch_execz 11                                         // 000000162140: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2070>
	global_load_b128 v[49:52], v[61:62], off offset:480        // 000000162144: DC5E01E0 317C003D
	s_waitcnt vmcnt(0)                                         // 00000016214C: BF8903F7
	v_fma_mixlo_f16 v45, v49, s44, 0                           // 000000162150: CC21002D 02005931
	v_fma_mixhi_f16 v45, v50, s44, 0                           // 000000162158: CC22002D 02005932
	v_fma_mixlo_f16 v46, v51, s44, 0                           // 000000162160: CC21002E 02005933
	v_fma_mixhi_f16 v46, v52, s44, 0                           // 000000162168: CC22002E 02005934
	s_or_b32 exec_lo, exec_lo, s1                              // 000000162170: 8C7E017E
	.long 0x7e6039b0                                           // 000000162174: 7E6039B0
	.long 0x7f5e39b0                                           // 000000162178: 7F5E39B0
	.long 0x7e5e39b0                                           // 00000016217C: 7E5E39B0
	s_and_saveexec_b32 s1, s0                                  // 000000162180: BE812000
	s_cbranch_execz 11                                         // 000000162184: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x20b4>
	global_load_b128 v[47:50], v[61:62], off offset:496        // 000000162188: DC5E01F0 2F7C003D
	s_waitcnt vmcnt(0)                                         // 000000162190: BF8903F7
	v_fma_mixlo_f16 v47, v47, s44, 0                           // 000000162194: CC21002F 0200592F
	v_fma_mixhi_f16 v47, v48, s44, 0                           // 00000016219C: CC22002F 02005930
	v_fma_mixlo_f16 v48, v49, s44, 0                           // 0000001621A4: CC210030 02005931
	v_fma_mixhi_f16 v48, v50, s44, 0                           // 0000001621AC: CC220030 02005932
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001621B4: 8C7E017E
	ds_load_b128 v[49:52], v81 offset:448                      // 0000001621B8: DBFC01C0 31000051
	ds_load_b128 v[53:56], v81 offset:464                      // 0000001621C0: DBFC01D0 35000051
	ds_load_b128 v[61:64], v81 offset:480                      // 0000001621C8: DBFC01E0 3D000051
	ds_load_b128 v[65:68], v81 offset:496                      // 0000001621D0: DBFC01F0 41000051
	ds_load_b128 v[69:72], v81 offset:8896                     // 0000001621D8: DBFC22C0 45000051
	ds_load_b128 v[90:93], v81 offset:8912                     // 0000001621E0: DBFC22D0 5A000051
	ds_load_b128 v[94:97], v81 offset:8928                     // 0000001621E8: DBFC22E0 5E000051
	ds_load_b128 v[98:101], v81 offset:8944                    // 0000001621F0: DBFC22F0 62000051
	ds_load_b128 v[106:109], v81 offset:25840                  // 0000001621F8: DBFC64F0 6A000051
	ds_load_b128 v[102:105], v81 offset:25824                  // 000000162200: DBFC64E0 66000051
	s_waitcnt lgkmcnt(9)                                       // 000000162208: BF89FC97
	v_fma_mixlo_f16 v49, v49, s44, 0                           // 00000016220C: CC210031 02005931
	v_fma_mixhi_f16 v49, v50, s44, 0                           // 000000162214: CC220031 02005932
	v_fma_mixlo_f16 v50, v51, s44, 0                           // 00000016221C: CC210032 02005933
	v_fma_mixhi_f16 v50, v52, s44, 0                           // 000000162224: CC220032 02005934
	s_waitcnt lgkmcnt(8)                                       // 00000016222C: BF89FC87
	v_fma_mixlo_f16 v51, v53, s44, 0                           // 000000162230: CC210033 02005935
	v_fma_mixhi_f16 v51, v54, s44, 0                           // 000000162238: CC220033 02005936
	v_fma_mixlo_f16 v52, v55, s44, 0                           // 000000162240: CC210034 02005937
	v_fma_mixhi_f16 v52, v56, s44, 0                           // 000000162248: CC220034 02005938
	s_waitcnt lgkmcnt(7)                                       // 000000162250: BF89FC77
	v_fma_mixlo_f16 v53, v61, s44, 0                           // 000000162254: CC210035 0200593D
	v_fma_mixhi_f16 v53, v62, s44, 0                           // 00000016225C: CC220035 0200593E
	v_fma_mixlo_f16 v54, v63, s44, 0                           // 000000162264: CC210036 0200593F
	v_fma_mixhi_f16 v54, v64, s44, 0                           // 00000016226C: CC220036 02005940
	s_waitcnt lgkmcnt(6)                                       // 000000162274: BF89FC67
	v_fma_mixlo_f16 v55, v65, s44, 0                           // 000000162278: CC210037 02005941
	v_fma_mixhi_f16 v55, v66, s44, 0                           // 000000162280: CC220037 02005942
	v_fma_mixlo_f16 v56, v67, s44, 0                           // 000000162288: CC210038 02005943
	v_fma_mixhi_f16 v56, v68, s44, 0                           // 000000162290: CC220038 02005944
	s_waitcnt lgkmcnt(5)                                       // 000000162298: BF89FC57
	v_fma_mixlo_f16 v61, v69, s44, 0                           // 00000016229C: CC21003D 02005945
	v_fma_mixhi_f16 v61, v70, s44, 0                           // 0000001622A4: CC22003D 02005946
	v_fma_mixlo_f16 v62, v71, s44, 0                           // 0000001622AC: CC21003E 02005947
	v_fma_mixhi_f16 v62, v72, s44, 0                           // 0000001622B4: CC22003E 02005948
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[49:56], v[33:40]// 0000001622BC: CC404021 1C866329
	ds_load_b128 v[50:53], v81 offset:17344                    // 0000001622C4: DBFC43C0 32000051
	s_waitcnt lgkmcnt(5)                                       // 0000001622CC: BF89FC57
	v_fma_mixlo_f16 v63, v90, s44, 0                           // 0000001622D0: CC21003F 0200595A
	ds_load_b128 v[54:57], v81 offset:17360                    // 0000001622D8: DBFC43D0 36000051
	ds_load_b128 v[69:72], v81 offset:17376                    // 0000001622E0: DBFC43E0 45000051
	v_fma_mixhi_f16 v63, v91, s44, 0                           // 0000001622E8: CC22003F 0200595B
	v_fma_mixlo_f16 v64, v92, s44, 0                           // 0000001622F0: CC210040 0200595C
	v_fma_mixhi_f16 v64, v93, s44, 0                           // 0000001622F8: CC220040 0200595D
	s_waitcnt lgkmcnt(6)                                       // 000000162300: BF89FC67
	v_fma_mixlo_f16 v65, v94, s44, 0                           // 000000162304: CC210041 0200595E
	v_fma_mixhi_f16 v65, v95, s44, 0                           // 00000016230C: CC220041 0200595F
	v_fma_mixlo_f16 v66, v96, s44, 0                           // 000000162314: CC210042 02005960
	v_fma_mixhi_f16 v66, v97, s44, 0                           // 00000016231C: CC220042 02005961
	s_waitcnt lgkmcnt(5)                                       // 000000162324: BF89FC57
	v_fma_mixlo_f16 v67, v98, s44, 0                           // 000000162328: CC210043 02005962
	ds_load_b128 v[90:93], v81 offset:17392                    // 000000162330: DBFC43F0 5A000051
	ds_load_b128 v[94:97], v81 offset:25792                    // 000000162338: DBFC64C0 5E000051
	v_fma_mixhi_f16 v67, v99, s44, 0                           // 000000162340: CC220043 02005963
	v_fma_mixlo_f16 v68, v100, s44, 0                          // 000000162348: CC210044 02005964
	v_fma_mixhi_f16 v68, v101, s44, 0                          // 000000162350: CC220044 02005965
	ds_load_b128 v[98:101], v81 offset:25808                   // 000000162358: DBFC64D0 62000051
	.long 0x7e623880                                           // 000000162360: 7E623880
	s_waitcnt lgkmcnt(5)                                       // 000000162364: BF89FC57
	v_fma_mixlo_f16 v50, v50, s44, 0                           // 000000162368: CC210032 02005932
	v_fma_mixhi_f16 v50, v51, s44, 0                           // 000000162370: CC220032 02005933
	v_fma_mixlo_f16 v51, v52, s44, 0                           // 000000162378: CC210033 02005934
	v_fma_mixhi_f16 v51, v53, s44, 0                           // 000000162380: CC220033 02005935
	s_waitcnt lgkmcnt(4)                                       // 000000162388: BF89FC47
	v_fma_mixlo_f16 v52, v54, s44, 0                           // 00000016238C: CC210034 02005936
	v_fma_mixhi_f16 v52, v55, s44, 0                           // 000000162394: CC220034 02005937
	v_fma_mixlo_f16 v53, v56, s44, 0                           // 00000016239C: CC210035 02005938
	v_fma_mixhi_f16 v53, v57, s44, 0                           // 0000001623A4: CC220035 02005939
	s_waitcnt lgkmcnt(3)                                       // 0000001623AC: BF89FC37
	v_fma_mixlo_f16 v54, v69, s44, 0                           // 0000001623B0: CC210036 02005945
	v_fma_mixhi_f16 v54, v70, s44, 0                           // 0000001623B8: CC220036 02005946
	v_fma_mixlo_f16 v55, v71, s44, 0                           // 0000001623C0: CC210037 02005947
	v_fma_mixhi_f16 v55, v72, s44, 0                           // 0000001623C8: CC220037 02005948
	s_waitcnt lgkmcnt(2)                                       // 0000001623D0: BF89FC27
	v_fma_mixlo_f16 v56, v90, s44, 0                           // 0000001623D4: CC210038 0200595A
	v_fma_mixhi_f16 v56, v91, s44, 0                           // 0000001623DC: CC220038 0200595B
	v_fma_mixlo_f16 v57, v92, s44, 0                           // 0000001623E4: CC210039 0200595C
	v_fma_mixhi_f16 v57, v93, s44, 0                           // 0000001623EC: CC220039 0200595D
	s_waitcnt lgkmcnt(1)                                       // 0000001623F4: BF89FC17
	v_fma_mixlo_f16 v91, v94, s44, 0                           // 0000001623F8: CC21005B 0200595E
	v_fma_mixhi_f16 v91, v95, s44, 0                           // 000000162400: CC22005B 0200595F
	v_fma_mixlo_f16 v92, v96, s44, 0                           // 000000162408: CC21005C 02005960
	v_fma_mixhi_f16 v92, v97, s44, 0                           // 000000162410: CC22005C 02005961
	s_waitcnt lgkmcnt(0)                                       // 000000162418: BF89FC07
	v_fma_mixlo_f16 v93, v98, s44, 0                           // 00000016241C: CC21005D 02005962
	v_fma_mixhi_f16 v93, v99, s44, 0                           // 000000162424: CC22005D 02005963
	v_fma_mixlo_f16 v94, v100, s44, 0                          // 00000016242C: CC21005E 02005964
	v_fma_mixhi_f16 v94, v101, s44, 0                          // 000000162434: CC22005E 02005965
	v_fma_mixlo_f16 v95, v102, s44, 0                          // 00000016243C: CC21005F 02005966
	v_fma_mixhi_f16 v95, v103, s44, 0                          // 000000162444: CC22005F 02005967
	v_fma_mixlo_f16 v96, v104, s44, 0                          // 00000016244C: CC210060 02005968
	v_fma_mixhi_f16 v96, v105, s44, 0                          // 000000162454: CC220060 02005969
	v_fma_mixlo_f16 v97, v106, s44, 0                          // 00000016245C: CC210061 0200596A
	v_fma_mixhi_f16 v97, v107, s44, 0                          // 000000162464: CC220061 0200596B
	v_fma_mixlo_f16 v98, v108, s44, 0                          // 00000016246C: CC210062 0200596C
	v_fma_mixhi_f16 v98, v109, s44, 0                          // 000000162474: CC220062 0200596D
	v_add_nc_u32_e32 v90, s4, v82                              // 00000016247C: 4AB4A404
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[61:68], v[25:32]// 000000162480: CC404019 1C667B29
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[50:57], v[17:24]// 000000162488: CC404011 1C466529
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000162490: BF870214
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[91:98], v[9:16]// 000000162494: CC404009 1C26B729
	.long 0xd4440001                                           // 00000016249C: D4440001
	v_cndmask_b32_e32 v1, s41, v90, vcc_lo                     // 0000001624A0: 0202B429
	.long 0x7e523931                                           // 0000001624A4: 7E523931
	s_and_saveexec_b32 s5, s1                                  // 0000001624A8: BE852001
	s_cbranch_execz 17                                         // 0000001624AC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23f4>
	v_mad_u64_u32 v[41:42], null, v90, 48, s[2:3]              // 0000001624B0: D6FE7C29 0009615A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001624B8: BF870091
	.long 0xd73c0029                                           // 0000001624BC: D73C0029
	v_cndmask_b32_e32 v1, 9, v41, vcc_lo                       // 0000001624C0: 02025289
	.long 0xd7000429                                           // 0000001624C4: D7000429
	v_cndmask_b32_e32 v1, v86, v41, vcc_lo                     // 0000001624C8: 02025356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001624CC: BF8700C1
	v_add_co_ci_u32_e64 v42, null, v87, v42, s4                // 0000001624D0: D5207C2A 00125557
	global_load_b32 v41, v[41:42], off                         // 0000001624D8: DC520000 297C0029
	s_waitcnt vmcnt(0)                                         // 0000001624E0: BF8903F7
	v_fmac_f32_e32 v41, 0xbb800000, v33                        // 0000001624E4: 565242FF BB800000
	v_fma_mixlo_f16 v41, v41, s44, 0                           // 0000001624EC: CC210029 02005929
	s_or_b32 exec_lo, exec_lo, s5                              // 0000001624F4: 8C7E057E
	v_add_nc_u32_e32 v91, 2, v90                               // 0000001624F8: 4AB6B482
	ds_store_b16 v88, v41                                      // 0000001624FC: D87C0000 00002958
	.long 0xd4440004                                           // 000000162504: D4440004
	v_cndmask_b32_e32 v1, s41, v91, vcc_lo                     // 000000162508: 0202B629
	s_and_saveexec_b32 s6, s4                                  // 00000016250C: BE862004
	s_cbranch_execz 17                                         // 000000162510: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2458>
	v_mad_u64_u32 v[41:42], null, v91, 48, s[2:3]              // 000000162514: D6FE7C29 0009615B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016251C: BF870091
	.long 0xd73c0029                                           // 000000162520: D73C0029
	v_cndmask_b32_e32 v1, 9, v41, vcc_lo                       // 000000162524: 02025289
	.long 0xd7000529                                           // 000000162528: D7000529
	v_cndmask_b32_e32 v1, v86, v41, vcc_lo                     // 00000016252C: 02025356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162530: BF8700C1
	v_add_co_ci_u32_e64 v42, null, v87, v42, s5                // 000000162534: D5207C2A 00165557
	global_load_b32 v33, v[41:42], off                         // 00000016253C: DC520000 217C0029
	s_waitcnt vmcnt(0)                                         // 000000162544: BF8903F7
	v_fmac_f32_e32 v33, 0xbb800000, v34                        // 000000162548: 564244FF BB800000
	v_fma_mixlo_f16 v49, v33, s44, 0                           // 000000162550: CC210031 02005921
	s_or_b32 exec_lo, exec_lo, s6                              // 000000162558: 8C7E067E
	v_add_nc_u32_e32 v92, 4, v90                               // 00000016255C: 4AB8B484
	.long 0x7e423880                                           // 000000162560: 7E423880
	ds_store_b16 v88, v49 offset:4                             // 000000162564: D87C0004 00003158
	.long 0xd4440005                                           // 00000016256C: D4440005
	v_cndmask_b32_e32 v1, s41, v92, vcc_lo                     // 000000162570: 0202B829
	.long 0x7f423921                                           // 000000162574: 7F423921
	s_and_saveexec_b32 s7, s5                                  // 000000162578: BE872005
	s_cbranch_execz 17                                         // 00000016257C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x24c4>
	v_mad_u64_u32 v[41:42], null, v92, 48, s[2:3]              // 000000162580: D6FE7C29 0009615C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162588: BF870091
	.long 0xd73c0029                                           // 00000016258C: D73C0029
	v_cndmask_b32_e32 v1, 9, v41, vcc_lo                       // 000000162590: 02025289
	.long 0xd7000629                                           // 000000162594: D7000629
	v_cndmask_b32_e32 v1, v86, v41, vcc_lo                     // 000000162598: 02025356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016259C: BF8700C1
	v_add_co_ci_u32_e64 v42, null, v87, v42, s6                // 0000001625A0: D5207C2A 001A5557
	global_load_b32 v34, v[41:42], off                         // 0000001625A8: DC520000 227C0029
	s_waitcnt vmcnt(0)                                         // 0000001625B0: BF8903F7
	v_fmac_f32_e32 v34, 0xbb800000, v35                        // 0000001625B4: 564446FF BB800000
	v_fma_mixhi_f16 v33, v34, s44, 0                           // 0000001625BC: CC220021 02005922
	s_or_b32 exec_lo, exec_lo, s7                              // 0000001625C4: 8C7E077E
	v_add_nc_u32_e32 v93, 6, v90                               // 0000001625C8: 4ABAB486
	ds_store_b16_d16_hi v88, v33 offset:8                      // 0000001625CC: DA840008 00002158
	.long 0xd4440006                                           // 0000001625D4: D4440006
	v_cndmask_b32_e32 v1, s41, v93, vcc_lo                     // 0000001625D8: 0202BA29
	s_and_saveexec_b32 s8, s6                                  // 0000001625DC: BE882006
	s_cbranch_execz 17                                         // 0000001625E0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2528>
	v_mad_u64_u32 v[33:34], null, v93, 48, s[2:3]              // 0000001625E4: D6FE7C21 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001625EC: BF870091
	.long 0xd73c0021                                           // 0000001625F0: D73C0021
	v_cndmask_b32_e32 v1, 9, v33, vcc_lo                       // 0000001625F4: 02024289
	.long 0xd7000721                                           // 0000001625F8: D7000721
	v_cndmask_b32_e32 v1, v86, v33, vcc_lo                     // 0000001625FC: 02024356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162600: BF8700C1
	v_add_co_ci_u32_e64 v34, null, v87, v34, s7                // 000000162604: D5207C22 001E4557
	global_load_b32 v33, v[33:34], off                         // 00000016260C: DC520000 217C0021
	s_waitcnt vmcnt(0)                                         // 000000162614: BF8903F7
	v_fmac_f32_e32 v33, 0xbb800000, v36                        // 000000162618: 564248FF BB800000
	v_fma_mixlo_f16 v33, v33, s44, 0                           // 000000162620: CC210021 02005921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000162628: 8C7E087E
	v_add_nc_u32_e32 v94, 8, v90                               // 00000016262C: 4ABCB488
	.long 0x7f423880                                           // 000000162630: 7F423880
	ds_store_b16 v88, v33 offset:12                            // 000000162634: D87C000C 00002158
	.long 0xd4440007                                           // 00000016263C: D4440007
	v_cndmask_b32_e32 v1, s41, v94, vcc_lo                     // 000000162640: 0202BC29
	.long 0x7e4439a1                                           // 000000162644: 7E4439A1
	s_and_saveexec_b32 s9, s7                                  // 000000162648: BE892007
	s_cbranch_execz 17                                         // 00000016264C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2594>
	v_mad_u64_u32 v[34:35], null, v94, 48, s[2:3]              // 000000162650: D6FE7C22 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162658: BF870091
	.long 0xd73c0022                                           // 00000016265C: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 000000162660: 02024489
	.long 0xd7000822                                           // 000000162664: D7000822
	v_cndmask_b32_e32 v1, v86, v34, vcc_lo                     // 000000162668: 02024556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016266C: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v87, v35, s8                // 000000162670: D5207C23 00224757
	global_load_b32 v34, v[34:35], off                         // 000000162678: DC520000 227C0022
	s_waitcnt vmcnt(0)                                         // 000000162680: BF8903F7
	v_fmac_f32_e32 v34, 0xbb800000, v37                        // 000000162684: 56444AFF BB800000
	v_fma_mixlo_f16 v34, v34, s44, 0                           // 00000016268C: CC210022 02005922
	s_or_b32 exec_lo, exec_lo, s9                              // 000000162694: 8C7E097E
	v_add_nc_u32_e32 v95, 10, v90                              // 000000162698: 4ABEB48A
	ds_store_b16 v88, v34 offset:16                            // 00000016269C: D87C0010 00002258
	.long 0xd4440008                                           // 0000001626A4: D4440008
	v_cndmask_b32_e32 v1, s41, v95, vcc_lo                     // 0000001626A8: 0202BE29
	s_and_saveexec_b32 s10, s8                                 // 0000001626AC: BE8A2008
	s_cbranch_execz 17                                         // 0000001626B0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25f8>
	v_mad_u64_u32 v[33:34], null, v95, 48, s[2:3]              // 0000001626B4: D6FE7C21 0009615F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001626BC: BF870091
	.long 0xd73c0021                                           // 0000001626C0: D73C0021
	v_cndmask_b32_e32 v1, 9, v33, vcc_lo                       // 0000001626C4: 02024289
	.long 0xd7000921                                           // 0000001626C8: D7000921
	v_cndmask_b32_e32 v1, v86, v33, vcc_lo                     // 0000001626CC: 02024356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001626D0: BF8700C1
	v_add_co_ci_u32_e64 v34, null, v87, v34, s9                // 0000001626D4: D5207C22 00264557
	global_load_b32 v33, v[33:34], off                         // 0000001626DC: DC520000 217C0021
	s_waitcnt vmcnt(0)                                         // 0000001626E4: BF8903F7
	v_fmac_f32_e32 v33, 0xbb800000, v38                        // 0000001626E8: 56424CFF BB800000
	v_fma_mixhi_f16 v33, v33, s44, 0                           // 0000001626F0: CC220021 02005921
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001626F8: 8C7E0A7E
	v_add_nc_u32_e32 v96, 12, v90                              // 0000001626FC: 4AC0B48C
	.long 0x7e423880                                           // 000000162700: 7E423880
	ds_store_b16_d16_hi v88, v33 offset:20                     // 000000162704: DA840014 00002158
	.long 0xd4440009                                           // 00000016270C: D4440009
	v_cndmask_b32_e32 v1, s41, v96, vcc_lo                     // 000000162710: 0202C029
	.long 0x7e443921                                           // 000000162714: 7E443921
	s_and_saveexec_b32 s11, s9                                 // 000000162718: BE8B2009
	s_cbranch_execz 17                                         // 00000016271C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2664>
	v_mad_u64_u32 v[34:35], null, v96, 48, s[2:3]              // 000000162720: D6FE7C22 00096160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162728: BF870091
	.long 0xd73c0022                                           // 00000016272C: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 000000162730: 02024489
	.long 0xd7000a22                                           // 000000162734: D7000A22
	v_cndmask_b32_e32 v1, v86, v34, vcc_lo                     // 000000162738: 02024556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000016273C: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v87, v35, s10               // 000000162740: D5207C23 002A4757
	global_load_b32 v34, v[34:35], off                         // 000000162748: DC520000 227C0022
	s_waitcnt vmcnt(0)                                         // 000000162750: BF8903F7
	v_fmac_f32_e32 v34, 0xbb800000, v39                        // 000000162754: 56444EFF BB800000
	v_fma_mixlo_f16 v34, v34, s44, 0                           // 00000016275C: CC210022 02005922
	s_or_b32 exec_lo, exec_lo, s11                             // 000000162764: 8C7E0B7E
	v_add_nc_u32_e32 v97, 14, v90                              // 000000162768: 4AC2B48E
	ds_store_b16 v88, v34 offset:24                            // 00000016276C: D87C0018 00002258
	.long 0xd444000a                                           // 000000162774: D444000A
	v_cndmask_b32_e32 v1, s41, v97, vcc_lo                     // 000000162778: 0202C229
	s_and_saveexec_b32 s14, s10                                // 00000016277C: BE8E200A
	s_cbranch_execz 17                                         // 000000162780: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26c8>
	v_mad_u64_u32 v[33:34], null, v97, 48, s[2:3]              // 000000162784: D6FE7C21 00096161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016278C: BF870091
	.long 0xd73c0021                                           // 000000162790: D73C0021
	v_cndmask_b32_e32 v1, 9, v33, vcc_lo                       // 000000162794: 02024289
	.long 0xd7000b21                                           // 000000162798: D7000B21
	v_cndmask_b32_e32 v1, v86, v33, vcc_lo                     // 00000016279C: 02024356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001627A0: BF8700C1
	v_add_co_ci_u32_e64 v34, null, v87, v34, s11               // 0000001627A4: D5207C22 002E4557
	global_load_b32 v33, v[33:34], off                         // 0000001627AC: DC520000 217C0021
	s_waitcnt vmcnt(0)                                         // 0000001627B4: BF8903F7
	v_fmac_f32_e32 v33, 0xbb800000, v40                        // 0000001627B8: 564250FF BB800000
	v_fma_mixlo_f16 v33, v33, s44, 0                           // 0000001627C0: CC210021 02005921
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001627C8: 8C7E0E7E
	.long 0x7f423880                                           // 0000001627CC: 7F423880
	ds_store_b16 v88, v33 offset:28                            // 0000001627D0: D87C001C 00002158
	.long 0x7e4439a1                                           // 0000001627D8: 7E4439A1
	s_and_saveexec_b32 s14, s1                                 // 0000001627DC: BE8E2001
	s_cbranch_execz 17                                         // 0000001627E0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2728>
	v_mad_u64_u32 v[34:35], null, v90, 48, s[2:3]              // 0000001627E4: D6FE7C22 0009615A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001627EC: BF870091
	.long 0xd73c0022                                           // 0000001627F0: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 0000001627F4: 02024489
	.long 0xd7000b22                                           // 0000001627F8: D7000B22
	v_cndmask_b32_e32 v1, v86, v34, vcc_lo                     // 0000001627FC: 02024556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162800: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v87, v35, s11               // 000000162804: D5207C23 002E4757
	global_load_b32 v34, v[34:35], off offset:64               // 00000016280C: DC520040 227C0022
	s_waitcnt vmcnt(0)                                         // 000000162814: BF8903F7
	v_fmac_f32_e32 v34, 0xbb800000, v25                        // 000000162818: 564432FF BB800000
	v_fma_mixlo_f16 v34, v34, s44, 0                           // 000000162820: CC210022 02005922
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162828: 8C7E0E7E
	ds_store_b16 v88, v34 offset:2560                          // 00000016282C: D87C0A00 00002258
	s_and_saveexec_b32 s14, s4                                 // 000000162834: BE8E2004
	s_cbranch_execz 17                                         // 000000162838: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2780>
	v_mad_u64_u32 v[33:34], null, v91, 48, s[2:3]              // 00000016283C: D6FE7C21 0009615B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162844: BF870091
	.long 0xd73c0021                                           // 000000162848: D73C0021
	v_cndmask_b32_e32 v1, 9, v33, vcc_lo                       // 00000016284C: 02024289
	.long 0xd7000b21                                           // 000000162850: D7000B21
	v_cndmask_b32_e32 v1, v86, v33, vcc_lo                     // 000000162854: 02024356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162858: BF8700C1
	v_add_co_ci_u32_e64 v34, null, v87, v34, s11               // 00000016285C: D5207C22 002E4557
	global_load_b32 v25, v[33:34], off offset:64               // 000000162864: DC520040 197C0021
	s_waitcnt vmcnt(0)                                         // 00000016286C: BF8903F7
	v_fmac_f32_e32 v25, 0xbb800000, v26                        // 000000162870: 563234FF BB800000
	v_fma_mixhi_f16 v33, v25, s44, 0                           // 000000162878: CC220021 02005919
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162880: 8C7E0E7E
	.long 0x7e323880                                           // 000000162884: 7E323880
	ds_store_b16_d16_hi v88, v33 offset:2564                   // 000000162888: DA840A04 00002158
	.long 0x7f323919                                           // 000000162890: 7F323919
	s_and_saveexec_b32 s14, s5                                 // 000000162894: BE8E2005
	s_cbranch_execz 17                                         // 000000162898: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27e0>
	v_mad_u64_u32 v[33:34], null, v92, 48, s[2:3]              // 00000016289C: D6FE7C21 0009615C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001628A4: BF870091
	.long 0xd73c0021                                           // 0000001628A8: D73C0021
	v_cndmask_b32_e32 v1, 9, v33, vcc_lo                       // 0000001628AC: 02024289
	.long 0xd7000b21                                           // 0000001628B0: D7000B21
	v_cndmask_b32_e32 v1, v86, v33, vcc_lo                     // 0000001628B4: 02024356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001628B8: BF8700C1
	v_add_co_ci_u32_e64 v34, null, v87, v34, s11               // 0000001628BC: D5207C22 002E4557
	global_load_b32 v26, v[33:34], off offset:64               // 0000001628C4: DC520040 1A7C0021
	s_waitcnt vmcnt(0)                                         // 0000001628CC: BF8903F7
	v_fmac_f32_e32 v26, 0xbb800000, v27                        // 0000001628D0: 563436FF BB800000
	v_fma_mixhi_f16 v25, v26, s44, 0                           // 0000001628D8: CC220019 0200591A
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001628E0: 8C7E0E7E
	ds_store_b16_d16_hi v88, v25 offset:2568                   // 0000001628E4: DA840A08 00001958
	s_and_saveexec_b32 s14, s6                                 // 0000001628EC: BE8E2006
	s_cbranch_execz 17                                         // 0000001628F0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2838>
	v_mad_u64_u32 v[25:26], null, v93, 48, s[2:3]              // 0000001628F4: D6FE7C19 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001628FC: BF870091
	.long 0xd73c0019                                           // 000000162900: D73C0019
	v_cndmask_b32_e32 v1, 9, v25, vcc_lo                       // 000000162904: 02023289
	.long 0xd7000b19                                           // 000000162908: D7000B19
	v_cndmask_b32_e32 v1, v86, v25, vcc_lo                     // 00000016290C: 02023356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162910: BF8700C1
	v_add_co_ci_u32_e64 v26, null, v87, v26, s11               // 000000162914: D5207C1A 002E3557
	global_load_b32 v25, v[25:26], off offset:64               // 00000016291C: DC520040 197C0019
	s_waitcnt vmcnt(0)                                         // 000000162924: BF8903F7
	v_fmac_f32_e32 v25, 0xbb800000, v28                        // 000000162928: 563238FF BB800000
	v_fma_mixlo_f16 v25, v25, s44, 0                           // 000000162930: CC210019 02005919
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162938: 8C7E0E7E
	.long 0x7f323880                                           // 00000016293C: 7F323880
	ds_store_b16 v88, v25 offset:2572                          // 000000162940: D87C0A0C 00001958
	.long 0x7e343999                                           // 000000162948: 7E343999
	s_and_saveexec_b32 s14, s7                                 // 00000016294C: BE8E2007
	s_cbranch_execz 17                                         // 000000162950: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2898>
	v_mad_u64_u32 v[26:27], null, v94, 48, s[2:3]              // 000000162954: D6FE7C1A 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016295C: BF870091
	.long 0xd73c001a                                           // 000000162960: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 000000162964: 02023489
	.long 0xd7000b1a                                           // 000000162968: D7000B1A
	v_cndmask_b32_e32 v1, v86, v26, vcc_lo                     // 00000016296C: 02023556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162970: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v87, v27, s11               // 000000162974: D5207C1B 002E3757
	global_load_b32 v26, v[26:27], off offset:64               // 00000016297C: DC520040 1A7C001A
	s_waitcnt vmcnt(0)                                         // 000000162984: BF8903F7
	v_fmac_f32_e32 v26, 0xbb800000, v29                        // 000000162988: 56343AFF BB800000
	v_fma_mixlo_f16 v26, v26, s44, 0                           // 000000162990: CC21001A 0200591A
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162998: 8C7E0E7E
	ds_store_b16 v88, v26 offset:2576                          // 00000016299C: D87C0A10 00001A58
	s_and_saveexec_b32 s14, s8                                 // 0000001629A4: BE8E2008
	s_cbranch_execz 17                                         // 0000001629A8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x28f0>
	v_mad_u64_u32 v[25:26], null, v95, 48, s[2:3]              // 0000001629AC: D6FE7C19 0009615F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001629B4: BF870091
	.long 0xd73c0019                                           // 0000001629B8: D73C0019
	v_cndmask_b32_e32 v1, 9, v25, vcc_lo                       // 0000001629BC: 02023289
	.long 0xd7000b19                                           // 0000001629C0: D7000B19
	v_cndmask_b32_e32 v1, v86, v25, vcc_lo                     // 0000001629C4: 02023356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001629C8: BF8700C1
	v_add_co_ci_u32_e64 v26, null, v87, v26, s11               // 0000001629CC: D5207C1A 002E3557
	global_load_b32 v25, v[25:26], off offset:64               // 0000001629D4: DC520040 197C0019
	s_waitcnt vmcnt(0)                                         // 0000001629DC: BF8903F7
	v_fmac_f32_e32 v25, 0xbb800000, v30                        // 0000001629E0: 56323CFF BB800000
	v_fma_mixhi_f16 v25, v25, s44, 0                           // 0000001629E8: CC220019 02005919
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001629F0: 8C7E0E7E
	.long 0x7e323880                                           // 0000001629F4: 7E323880
	ds_store_b16_d16_hi v88, v25 offset:2580                   // 0000001629F8: DA840A14 00001958
	.long 0x7e343919                                           // 000000162A00: 7E343919
	s_and_saveexec_b32 s14, s9                                 // 000000162A04: BE8E2009
	s_cbranch_execz 17                                         // 000000162A08: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2950>
	v_mad_u64_u32 v[26:27], null, v96, 48, s[2:3]              // 000000162A0C: D6FE7C1A 00096160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162A14: BF870091
	.long 0xd73c001a                                           // 000000162A18: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 000000162A1C: 02023489
	.long 0xd7000b1a                                           // 000000162A20: D7000B1A
	v_cndmask_b32_e32 v1, v86, v26, vcc_lo                     // 000000162A24: 02023556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162A28: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v87, v27, s11               // 000000162A2C: D5207C1B 002E3757
	global_load_b32 v26, v[26:27], off offset:64               // 000000162A34: DC520040 1A7C001A
	s_waitcnt vmcnt(0)                                         // 000000162A3C: BF8903F7
	v_fmac_f32_e32 v26, 0xbb800000, v31                        // 000000162A40: 56343EFF BB800000
	v_fma_mixlo_f16 v26, v26, s44, 0                           // 000000162A48: CC21001A 0200591A
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162A50: 8C7E0E7E
	ds_store_b16 v88, v26 offset:2584                          // 000000162A54: D87C0A18 00001A58
	s_and_saveexec_b32 s14, s10                                // 000000162A5C: BE8E200A
	s_cbranch_execz 17                                         // 000000162A60: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29a8>
	v_mad_u64_u32 v[25:26], null, v97, 48, s[2:3]              // 000000162A64: D6FE7C19 00096161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162A6C: BF870091
	.long 0xd73c0019                                           // 000000162A70: D73C0019
	v_cndmask_b32_e32 v1, 9, v25, vcc_lo                       // 000000162A74: 02023289
	.long 0xd7000b19                                           // 000000162A78: D7000B19
	v_cndmask_b32_e32 v1, v86, v25, vcc_lo                     // 000000162A7C: 02023356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162A80: BF8700C1
	v_add_co_ci_u32_e64 v26, null, v87, v26, s11               // 000000162A84: D5207C1A 002E3557
	global_load_b32 v25, v[25:26], off offset:64               // 000000162A8C: DC520040 197C0019
	s_waitcnt vmcnt(0)                                         // 000000162A94: BF8903F7
	v_fmac_f32_e32 v25, 0xbb800000, v32                        // 000000162A98: 563240FF BB800000
	v_fma_mixlo_f16 v25, v25, s44, 0                           // 000000162AA0: CC210019 02005919
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162AA8: 8C7E0E7E
	.long 0x7f323880                                           // 000000162AAC: 7F323880
	ds_store_b16 v88, v25 offset:2588                          // 000000162AB0: D87C0A1C 00001958
	.long 0x7e343999                                           // 000000162AB8: 7E343999
	s_and_saveexec_b32 s14, s1                                 // 000000162ABC: BE8E2001
	s_cbranch_execz 17                                         // 000000162AC0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a08>
	v_mad_u64_u32 v[26:27], null, v90, 48, s[2:3]              // 000000162AC4: D6FE7C1A 0009615A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162ACC: BF870091
	.long 0xd73c001a                                           // 000000162AD0: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 000000162AD4: 02023489
	.long 0xd7000b1a                                           // 000000162AD8: D7000B1A
	v_cndmask_b32_e32 v1, v86, v26, vcc_lo                     // 000000162ADC: 02023556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162AE0: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v87, v27, s11               // 000000162AE4: D5207C1B 002E3757
	global_load_b32 v26, v[26:27], off offset:128              // 000000162AEC: DC520080 1A7C001A
	s_waitcnt vmcnt(0)                                         // 000000162AF4: BF8903F7
	v_fmac_f32_e32 v26, 0xbb800000, v17                        // 000000162AF8: 563422FF BB800000
	v_fma_mixlo_f16 v26, v26, s44, 0                           // 000000162B00: CC21001A 0200591A
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162B08: 8C7E0E7E
	ds_store_b16 v88, v26 offset:5120                          // 000000162B0C: D87C1400 00001A58
	s_and_saveexec_b32 s14, s4                                 // 000000162B14: BE8E2004
	s_cbranch_execz 17                                         // 000000162B18: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a60>
	v_mad_u64_u32 v[25:26], null, v91, 48, s[2:3]              // 000000162B1C: D6FE7C19 0009615B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162B24: BF870091
	.long 0xd73c0019                                           // 000000162B28: D73C0019
	v_cndmask_b32_e32 v1, 9, v25, vcc_lo                       // 000000162B2C: 02023289
	.long 0xd7000b19                                           // 000000162B30: D7000B19
	v_cndmask_b32_e32 v1, v86, v25, vcc_lo                     // 000000162B34: 02023356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162B38: BF8700C1
	v_add_co_ci_u32_e64 v26, null, v87, v26, s11               // 000000162B3C: D5207C1A 002E3557
	global_load_b32 v17, v[25:26], off offset:128              // 000000162B44: DC520080 117C0019
	s_waitcnt vmcnt(0)                                         // 000000162B4C: BF8903F7
	v_fmac_f32_e32 v17, 0xbb800000, v18                        // 000000162B50: 562224FF BB800000
	v_fma_mixhi_f16 v25, v17, s44, 0                           // 000000162B58: CC220019 02005911
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162B60: 8C7E0E7E
	.long 0x7e223880                                           // 000000162B64: 7E223880
	ds_store_b16_d16_hi v88, v25 offset:5124                   // 000000162B68: DA841404 00001958
	.long 0x7f223911                                           // 000000162B70: 7F223911
	s_and_saveexec_b32 s14, s5                                 // 000000162B74: BE8E2005
	s_cbranch_execz 17                                         // 000000162B78: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ac0>
	v_mad_u64_u32 v[25:26], null, v92, 48, s[2:3]              // 000000162B7C: D6FE7C19 0009615C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162B84: BF870091
	.long 0xd73c0019                                           // 000000162B88: D73C0019
	v_cndmask_b32_e32 v1, 9, v25, vcc_lo                       // 000000162B8C: 02023289
	.long 0xd7000b19                                           // 000000162B90: D7000B19
	v_cndmask_b32_e32 v1, v86, v25, vcc_lo                     // 000000162B94: 02023356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162B98: BF8700C1
	v_add_co_ci_u32_e64 v26, null, v87, v26, s11               // 000000162B9C: D5207C1A 002E3557
	global_load_b32 v18, v[25:26], off offset:128              // 000000162BA4: DC520080 127C0019
	s_waitcnt vmcnt(0)                                         // 000000162BAC: BF8903F7
	v_fmac_f32_e32 v18, 0xbb800000, v19                        // 000000162BB0: 562426FF BB800000
	v_fma_mixhi_f16 v17, v18, s44, 0                           // 000000162BB8: CC220011 02005912
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162BC0: 8C7E0E7E
	ds_store_b16_d16_hi v88, v17 offset:5128                   // 000000162BC4: DA841408 00001158
	s_and_saveexec_b32 s14, s6                                 // 000000162BCC: BE8E2006
	s_cbranch_execz 17                                         // 000000162BD0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b18>
	v_mad_u64_u32 v[17:18], null, v93, 48, s[2:3]              // 000000162BD4: D6FE7C11 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162BDC: BF870091
	.long 0xd73c0011                                           // 000000162BE0: D73C0011
	v_cndmask_b32_e32 v1, 9, v17, vcc_lo                       // 000000162BE4: 02022289
	.long 0xd7000b11                                           // 000000162BE8: D7000B11
	v_cndmask_b32_e32 v1, v86, v17, vcc_lo                     // 000000162BEC: 02022356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162BF0: BF8700C1
	v_add_co_ci_u32_e64 v18, null, v87, v18, s11               // 000000162BF4: D5207C12 002E2557
	global_load_b32 v17, v[17:18], off offset:128              // 000000162BFC: DC520080 117C0011
	s_waitcnt vmcnt(0)                                         // 000000162C04: BF8903F7
	v_fmac_f32_e32 v17, 0xbb800000, v20                        // 000000162C08: 562228FF BB800000
	v_fma_mixlo_f16 v17, v17, s44, 0                           // 000000162C10: CC210011 02005911
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162C18: 8C7E0E7E
	.long 0x7f223880                                           // 000000162C1C: 7F223880
	ds_store_b16 v88, v17 offset:5132                          // 000000162C20: D87C140C 00001158
	.long 0x7e243991                                           // 000000162C28: 7E243991
	s_and_saveexec_b32 s14, s7                                 // 000000162C2C: BE8E2007
	s_cbranch_execz 17                                         // 000000162C30: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b78>
	v_mad_u64_u32 v[18:19], null, v94, 48, s[2:3]              // 000000162C34: D6FE7C12 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162C3C: BF870091
	.long 0xd73c0012                                           // 000000162C40: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 000000162C44: 02022489
	.long 0xd7000b12                                           // 000000162C48: D7000B12
	v_cndmask_b32_e32 v1, v86, v18, vcc_lo                     // 000000162C4C: 02022556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162C50: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v87, v19, s11               // 000000162C54: D5207C13 002E2757
	global_load_b32 v18, v[18:19], off offset:128              // 000000162C5C: DC520080 127C0012
	s_waitcnt vmcnt(0)                                         // 000000162C64: BF8903F7
	v_fmac_f32_e32 v18, 0xbb800000, v21                        // 000000162C68: 56242AFF BB800000
	v_fma_mixlo_f16 v18, v18, s44, 0                           // 000000162C70: CC210012 02005912
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162C78: 8C7E0E7E
	ds_store_b16 v88, v18 offset:5136                          // 000000162C7C: D87C1410 00001258
	s_and_saveexec_b32 s14, s8                                 // 000000162C84: BE8E2008
	s_cbranch_execz 17                                         // 000000162C88: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2bd0>
	v_mad_u64_u32 v[17:18], null, v95, 48, s[2:3]              // 000000162C8C: D6FE7C11 0009615F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162C94: BF870091
	.long 0xd73c0011                                           // 000000162C98: D73C0011
	v_cndmask_b32_e32 v1, 9, v17, vcc_lo                       // 000000162C9C: 02022289
	.long 0xd7000b11                                           // 000000162CA0: D7000B11
	v_cndmask_b32_e32 v1, v86, v17, vcc_lo                     // 000000162CA4: 02022356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162CA8: BF8700C1
	v_add_co_ci_u32_e64 v18, null, v87, v18, s11               // 000000162CAC: D5207C12 002E2557
	global_load_b32 v17, v[17:18], off offset:128              // 000000162CB4: DC520080 117C0011
	s_waitcnt vmcnt(0)                                         // 000000162CBC: BF8903F7
	v_fmac_f32_e32 v17, 0xbb800000, v22                        // 000000162CC0: 56222CFF BB800000
	v_fma_mixhi_f16 v17, v17, s44, 0                           // 000000162CC8: CC220011 02005911
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162CD0: 8C7E0E7E
	.long 0x7e223880                                           // 000000162CD4: 7E223880
	ds_store_b16_d16_hi v88, v17 offset:5140                   // 000000162CD8: DA841414 00001158
	.long 0x7e243911                                           // 000000162CE0: 7E243911
	s_and_saveexec_b32 s14, s9                                 // 000000162CE4: BE8E2009
	s_cbranch_execz 17                                         // 000000162CE8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c30>
	v_mad_u64_u32 v[18:19], null, v96, 48, s[2:3]              // 000000162CEC: D6FE7C12 00096160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162CF4: BF870091
	.long 0xd73c0012                                           // 000000162CF8: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 000000162CFC: 02022489
	.long 0xd7000b12                                           // 000000162D00: D7000B12
	v_cndmask_b32_e32 v1, v86, v18, vcc_lo                     // 000000162D04: 02022556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162D08: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v87, v19, s11               // 000000162D0C: D5207C13 002E2757
	global_load_b32 v18, v[18:19], off offset:128              // 000000162D14: DC520080 127C0012
	s_waitcnt vmcnt(0)                                         // 000000162D1C: BF8903F7
	v_fmac_f32_e32 v18, 0xbb800000, v23                        // 000000162D20: 56242EFF BB800000
	v_fma_mixlo_f16 v18, v18, s44, 0                           // 000000162D28: CC210012 02005912
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162D30: 8C7E0E7E
	ds_store_b16 v88, v18 offset:5144                          // 000000162D34: D87C1418 00001258
	s_and_saveexec_b32 s14, s10                                // 000000162D3C: BE8E200A
	s_cbranch_execz 17                                         // 000000162D40: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c88>
	v_mad_u64_u32 v[17:18], null, v97, 48, s[2:3]              // 000000162D44: D6FE7C11 00096161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162D4C: BF870091
	.long 0xd73c0011                                           // 000000162D50: D73C0011
	v_cndmask_b32_e32 v1, 9, v17, vcc_lo                       // 000000162D54: 02022289
	.long 0xd7000b11                                           // 000000162D58: D7000B11
	v_cndmask_b32_e32 v1, v86, v17, vcc_lo                     // 000000162D5C: 02022356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162D60: BF8700C1
	v_add_co_ci_u32_e64 v18, null, v87, v18, s11               // 000000162D64: D5207C12 002E2557
	global_load_b32 v17, v[17:18], off offset:128              // 000000162D6C: DC520080 117C0011
	s_waitcnt vmcnt(0)                                         // 000000162D74: BF8903F7
	v_fmac_f32_e32 v17, 0xbb800000, v24                        // 000000162D78: 562230FF BB800000
	v_fma_mixlo_f16 v17, v17, s44, 0                           // 000000162D80: CC210011 02005911
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162D88: 8C7E0E7E
	.long 0x7f223880                                           // 000000162D8C: 7F223880
	ds_store_b16 v88, v17 offset:5148                          // 000000162D90: D87C141C 00001158
	.long 0x7e243991                                           // 000000162D98: 7E243991
	s_and_saveexec_b32 s14, s1                                 // 000000162D9C: BE8E2001
	s_cbranch_execz 17                                         // 000000162DA0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ce8>
	v_mad_u64_u32 v[18:19], null, v90, 48, s[2:3]              // 000000162DA4: D6FE7C12 0009615A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162DAC: BF870091
	.long 0xd73c0012                                           // 000000162DB0: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 000000162DB4: 02022489
	.long 0xd7000b12                                           // 000000162DB8: D7000B12
	v_cndmask_b32_e32 v1, v86, v18, vcc_lo                     // 000000162DBC: 02022556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162DC0: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v87, v19, s11               // 000000162DC4: D5207C13 002E2757
	global_load_b32 v18, v[18:19], off offset:192              // 000000162DCC: DC5200C0 127C0012
	s_waitcnt vmcnt(0)                                         // 000000162DD4: BF8903F7
	v_fmac_f32_e32 v18, 0xbb800000, v9                         // 000000162DD8: 562412FF BB800000
	v_fma_mixlo_f16 v18, v18, s44, 0                           // 000000162DE0: CC210012 02005912
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162DE8: 8C7E0E7E
	ds_store_b16 v88, v18 offset:7680                          // 000000162DEC: D87C1E00 00001258
	s_and_saveexec_b32 s14, s4                                 // 000000162DF4: BE8E2004
	s_cbranch_execz 17                                         // 000000162DF8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d40>
	v_mad_u64_u32 v[17:18], null, v91, 48, s[2:3]              // 000000162DFC: D6FE7C11 0009615B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162E04: BF870091
	.long 0xd73c0011                                           // 000000162E08: D73C0011
	v_cndmask_b32_e32 v1, 9, v17, vcc_lo                       // 000000162E0C: 02022289
	.long 0xd7000b11                                           // 000000162E10: D7000B11
	v_cndmask_b32_e32 v1, v86, v17, vcc_lo                     // 000000162E14: 02022356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162E18: BF8700C1
	v_add_co_ci_u32_e64 v18, null, v87, v18, s11               // 000000162E1C: D5207C12 002E2557
	global_load_b32 v9, v[17:18], off offset:192               // 000000162E24: DC5200C0 097C0011
	s_waitcnt vmcnt(0)                                         // 000000162E2C: BF8903F7
	v_fmac_f32_e32 v9, 0xbb800000, v10                         // 000000162E30: 561214FF BB800000
	v_fma_mixhi_f16 v17, v9, s44, 0                            // 000000162E38: CC220011 02005909
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162E40: 8C7E0E7E
	.long 0x7e123880                                           // 000000162E44: 7E123880
	ds_store_b16_d16_hi v88, v17 offset:7684                   // 000000162E48: DA841E04 00001158
	.long 0x7f123909                                           // 000000162E50: 7F123909
	s_and_saveexec_b32 s14, s5                                 // 000000162E54: BE8E2005
	s_cbranch_execz 17                                         // 000000162E58: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2da0>
	v_mad_u64_u32 v[17:18], null, v92, 48, s[2:3]              // 000000162E5C: D6FE7C11 0009615C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162E64: BF870091
	.long 0xd73c0011                                           // 000000162E68: D73C0011
	v_cndmask_b32_e32 v1, 9, v17, vcc_lo                       // 000000162E6C: 02022289
	.long 0xd7000b11                                           // 000000162E70: D7000B11
	v_cndmask_b32_e32 v1, v86, v17, vcc_lo                     // 000000162E74: 02022356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162E78: BF8700C1
	v_add_co_ci_u32_e64 v18, null, v87, v18, s11               // 000000162E7C: D5207C12 002E2557
	global_load_b32 v10, v[17:18], off offset:192              // 000000162E84: DC5200C0 0A7C0011
	s_waitcnt vmcnt(0)                                         // 000000162E8C: BF8903F7
	v_fmac_f32_e32 v10, 0xbb800000, v11                        // 000000162E90: 561416FF BB800000
	v_fma_mixhi_f16 v9, v10, s44, 0                            // 000000162E98: CC220009 0200590A
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162EA0: 8C7E0E7E
	ds_store_b16_d16_hi v88, v9 offset:7688                    // 000000162EA4: DA841E08 00000958
	s_and_saveexec_b32 s14, s6                                 // 000000162EAC: BE8E2006
	s_cbranch_execz 17                                         // 000000162EB0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2df8>
	v_mad_u64_u32 v[9:10], null, v93, 48, s[2:3]               // 000000162EB4: D6FE7C09 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162EBC: BF870091
	.long 0xd73c0009                                           // 000000162EC0: D73C0009
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 000000162EC4: 02021289
	.long 0xd7000b09                                           // 000000162EC8: D7000B09
	v_cndmask_b32_e32 v1, v86, v9, vcc_lo                      // 000000162ECC: 02021356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162ED0: BF8700C1
	v_add_co_ci_u32_e64 v10, null, v87, v10, s11               // 000000162ED4: D5207C0A 002E1557
	global_load_b32 v9, v[9:10], off offset:192                // 000000162EDC: DC5200C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000162EE4: BF8903F7
	v_fmac_f32_e32 v9, 0xbb800000, v12                         // 000000162EE8: 561218FF BB800000
	v_fma_mixlo_f16 v9, v9, s44, 0                             // 000000162EF0: CC210009 02005909
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162EF8: 8C7E0E7E
	.long 0x7f123880                                           // 000000162EFC: 7F123880
	ds_store_b16 v88, v9 offset:7692                           // 000000162F00: D87C1E0C 00000958
	.long 0x7e143989                                           // 000000162F08: 7E143989
	s_and_saveexec_b32 s14, s7                                 // 000000162F0C: BE8E2007
	s_cbranch_execz 17                                         // 000000162F10: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e58>
	v_mad_u64_u32 v[10:11], null, v94, 48, s[2:3]              // 000000162F14: D6FE7C0A 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162F1C: BF870091
	.long 0xd73c000a                                           // 000000162F20: D73C000A
	v_cndmask_b32_e32 v1, 9, v10, vcc_lo                       // 000000162F24: 02021489
	.long 0xd7000b0a                                           // 000000162F28: D7000B0A
	v_cndmask_b32_e32 v1, v86, v10, vcc_lo                     // 000000162F2C: 02021556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162F30: BF8700C1
	v_add_co_ci_u32_e64 v11, null, v87, v11, s11               // 000000162F34: D5207C0B 002E1757
	global_load_b32 v10, v[10:11], off offset:192              // 000000162F3C: DC5200C0 0A7C000A
	s_waitcnt vmcnt(0)                                         // 000000162F44: BF8903F7
	v_fmac_f32_e32 v10, 0xbb800000, v13                        // 000000162F48: 56141AFF BB800000
	v_fma_mixlo_f16 v10, v10, s44, 0                           // 000000162F50: CC21000A 0200590A
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162F58: 8C7E0E7E
	ds_store_b16 v88, v10 offset:7696                          // 000000162F5C: D87C1E10 00000A58
	s_and_saveexec_b32 s14, s8                                 // 000000162F64: BE8E2008
	s_cbranch_execz 17                                         // 000000162F68: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2eb0>
	v_mad_u64_u32 v[9:10], null, v95, 48, s[2:3]               // 000000162F6C: D6FE7C09 0009615F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162F74: BF870091
	.long 0xd73c0009                                           // 000000162F78: D73C0009
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 000000162F7C: 02021289
	.long 0xd7000b09                                           // 000000162F80: D7000B09
	v_cndmask_b32_e32 v1, v86, v9, vcc_lo                      // 000000162F84: 02021356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162F88: BF8700C1
	v_add_co_ci_u32_e64 v10, null, v87, v10, s11               // 000000162F8C: D5207C0A 002E1557
	global_load_b32 v9, v[9:10], off offset:192                // 000000162F94: DC5200C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000162F9C: BF8903F7
	v_fmac_f32_e32 v9, 0xbb800000, v14                         // 000000162FA0: 56121CFF BB800000
	v_fma_mixhi_f16 v9, v9, s44, 0                             // 000000162FA8: CC220009 02005909
	s_or_b32 exec_lo, exec_lo, s14                             // 000000162FB0: 8C7E0E7E
	.long 0x7e123880                                           // 000000162FB4: 7E123880
	ds_store_b16_d16_hi v88, v9 offset:7700                    // 000000162FB8: DA841E14 00000958
	.long 0x7e143909                                           // 000000162FC0: 7E143909
	s_and_saveexec_b32 s14, s9                                 // 000000162FC4: BE8E2009
	s_cbranch_execz 17                                         // 000000162FC8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2f10>
	v_mad_u64_u32 v[10:11], null, v96, 48, s[2:3]              // 000000162FCC: D6FE7C0A 00096160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000162FD4: BF870091
	.long 0xd73c000a                                           // 000000162FD8: D73C000A
	v_cndmask_b32_e32 v1, 9, v10, vcc_lo                       // 000000162FDC: 02021489
	.long 0xd7000b0a                                           // 000000162FE0: D7000B0A
	v_cndmask_b32_e32 v1, v86, v10, vcc_lo                     // 000000162FE4: 02021556
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000162FE8: BF8700C1
	v_add_co_ci_u32_e64 v11, null, v87, v11, s11               // 000000162FEC: D5207C0B 002E1757
	global_load_b32 v10, v[10:11], off offset:192              // 000000162FF4: DC5200C0 0A7C000A
	s_waitcnt vmcnt(0)                                         // 000000162FFC: BF8903F7
	v_fmac_f32_e32 v10, 0xbb800000, v15                        // 000000163000: 56141EFF BB800000
	v_fma_mixlo_f16 v10, v10, s44, 0                           // 000000163008: CC21000A 0200590A
	s_or_b32 exec_lo, exec_lo, s14                             // 000000163010: 8C7E0E7E
	ds_store_b16 v88, v10 offset:7704                          // 000000163014: D87C1E18 00000A58
	s_and_saveexec_b32 s14, s10                                // 00000016301C: BE8E200A
	s_cbranch_execz 17                                         // 000000163020: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2f68>
	v_mad_u64_u32 v[9:10], null, v97, 48, s[2:3]               // 000000163024: D6FE7C09 00096161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016302C: BF870091
	.long 0xd73c0009                                           // 000000163030: D73C0009
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 000000163034: 02021289
	.long 0xd7000b09                                           // 000000163038: D7000B09
	v_cndmask_b32_e32 v1, v86, v9, vcc_lo                      // 00000016303C: 02021356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000163040: BF8700C1
	v_add_co_ci_u32_e64 v10, null, v87, v10, s11               // 000000163044: D5207C0A 002E1557
	global_load_b32 v9, v[9:10], off offset:192                // 00000016304C: DC5200C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000163054: BF8903F7
	v_fmac_f32_e32 v9, 0xbb800000, v16                         // 000000163058: 561220FF BB800000
	v_fma_mixlo_f16 v9, v9, s44, 0                             // 000000163060: CC210009 02005909
	s_or_b32 exec_lo, exec_lo, s14                             // 000000163068: 8C7E0E7E
	.long 0x7f683880                                           // 00000016306C: 7F683880
	.long 0xd7000b3b                                           // 000000163070: D7000B3B
	v_cndmask_b32_e32 v1, s38, v59, vcc_lo                     // 000000163074: 02027626
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000163078: BF870191
	v_add_co_ci_u32_e64 v60, null, s39, v60, s11               // 00000016307C: D5207C3C 002E7827
	.long 0x7f6439b4                                           // 000000163084: 7F6439B4
	.long 0x7e6439b4                                           // 000000163088: 7E6439B4
	.long 0x7f6239b4                                           // 00000016308C: 7F6239B4
	.long 0x7e6239b4                                           // 000000163090: 7E6239B4
	ds_store_b16 v88, v9 offset:7708                           // 000000163094: D87C1E1C 00000958
	s_waitcnt lgkmcnt(0)                                       // 00000016309C: BF89FC07
	s_barrier                                                  // 0000001630A0: BFBD0000
	buffer_gl0_inv                                             // 0000001630A4: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 0000001630AC: BE8B2000
	s_cbranch_execz 11                                         // 0000001630B0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2fe0>
	global_load_b128 v[9:12], v[59:60], off                    // 0000001630B4: DC5E0000 097C003B
	s_waitcnt vmcnt(0)                                         // 0000001630BC: BF8903F7
	v_fma_mixlo_f16 v49, v9, s44, 0                            // 0000001630C0: CC210031 02005909
	v_fma_mixhi_f16 v49, v10, s44, 0                           // 0000001630C8: CC220031 0200590A
	v_fma_mixlo_f16 v50, v11, s44, 0                           // 0000001630D0: CC210032 0200590B
	v_fma_mixhi_f16 v50, v12, s44, 0                           // 0000001630D8: CC220032 0200590C
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001630E0: 8C7E0B7E
	.long 0x7e6839b4                                           // 0000001630E4: 7E6839B4
	.long 0x7f6639b4                                           // 0000001630E8: 7F6639B4
	.long 0x7e6639b4                                           // 0000001630EC: 7E6639B4
	s_and_saveexec_b32 s11, s0                                 // 0000001630F0: BE8B2000
	s_cbranch_execz 11                                         // 0000001630F4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3024>
	global_load_b128 v[9:12], v[59:60], off offset:16          // 0000001630F8: DC5E0010 097C003B
	s_waitcnt vmcnt(0)                                         // 000000163100: BF8903F7
	v_fma_mixlo_f16 v51, v9, s44, 0                            // 000000163104: CC210033 02005909
	v_fma_mixhi_f16 v51, v10, s44, 0                           // 00000016310C: CC220033 0200590A
	v_fma_mixlo_f16 v52, v11, s44, 0                           // 000000163114: CC210034 0200590B
	v_fma_mixhi_f16 v52, v12, s44, 0                           // 00000016311C: CC220034 0200590C
	s_or_b32 exec_lo, exec_lo, s11                             // 000000163124: 8C7E0B7E
	.long 0x7f703880                                           // 000000163128: 7F703880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016312C: BF870001
	.long 0x7f6c39b8                                           // 000000163130: 7F6C39B8
	.long 0x7e6c39b8                                           // 000000163134: 7E6C39B8
	.long 0x7f6a39b8                                           // 000000163138: 7F6A39B8
	.long 0x7e6a39b8                                           // 00000016313C: 7E6A39B8
	s_and_saveexec_b32 s11, s0                                 // 000000163140: BE8B2000
	s_cbranch_execz 11                                         // 000000163144: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3074>
	global_load_b128 v[9:12], v[59:60], off offset:32          // 000000163148: DC5E0020 097C003B
	s_waitcnt vmcnt(0)                                         // 000000163150: BF8903F7
	v_fma_mixlo_f16 v53, v9, s44, 0                            // 000000163154: CC210035 02005909
	v_fma_mixhi_f16 v53, v10, s44, 0                           // 00000016315C: CC220035 0200590A
	v_fma_mixlo_f16 v54, v11, s44, 0                           // 000000163164: CC210036 0200590B
	v_fma_mixhi_f16 v54, v12, s44, 0                           // 00000016316C: CC220036 0200590C
	s_or_b32 exec_lo, exec_lo, s11                             // 000000163174: 8C7E0B7E
	.long 0x7e7039b8                                           // 000000163178: 7E7039B8
	.long 0x7f6e39b8                                           // 00000016317C: 7F6E39B8
	.long 0x7e6e39b8                                           // 000000163180: 7E6E39B8
	s_and_saveexec_b32 s11, s0                                 // 000000163184: BE8B2000
	s_cbranch_execz 11                                         // 000000163188: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x30b8>
	global_load_b128 v[9:12], v[59:60], off offset:48          // 00000016318C: DC5E0030 097C003B
	s_waitcnt vmcnt(0)                                         // 000000163194: BF8903F7
	v_fma_mixlo_f16 v55, v9, s44, 0                            // 000000163198: CC210037 02005909
	v_fma_mixhi_f16 v55, v10, s44, 0                           // 0000001631A0: CC220037 0200590A
	v_fma_mixlo_f16 v56, v11, s44, 0                           // 0000001631A8: CC210038 0200590B
	v_fma_mixhi_f16 v56, v12, s44, 0                           // 0000001631B0: CC220038 0200590C
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001631B8: 8C7E0B7E
	ds_load_b128 v[9:12], v81                                  // 0000001631BC: DBFC0000 09000051
	ds_load_b128 v[13:16], v81 offset:16                       // 0000001631C4: DBFC0010 0D000051
	ds_load_b128 v[17:20], v81 offset:32                       // 0000001631CC: DBFC0020 11000051
	ds_load_b128 v[21:24], v81 offset:48                       // 0000001631D4: DBFC0030 15000051
	ds_load_b128 v[25:28], v81 offset:8448                     // 0000001631DC: DBFC2100 19000051
	ds_load_b128 v[29:32], v81 offset:8464                     // 0000001631E4: DBFC2110 1D000051
	ds_load_b128 v[33:36], v81 offset:8480                     // 0000001631EC: DBFC2120 21000051
	ds_load_b128 v[37:40], v81 offset:8496                     // 0000001631F4: DBFC2130 25000051
	ds_load_b128 v[41:44], v81 offset:16896                    // 0000001631FC: DBFC4200 29000051
	ds_load_b128 v[45:48], v81 offset:16912                    // 000000163204: DBFC4210 2D000051
	v_dual_mov_b32 v68, s31 :: v_dual_mov_b32 v67, s30         // 00000016320C: CA10001F 4442001E
	v_dual_mov_b32 v66, s29 :: v_dual_mov_b32 v65, s28         // 000000163214: CA10001D 4240001C
	v_dual_mov_b32 v64, s27 :: v_dual_mov_b32 v63, s26         // 00000016321C: CA10001B 403E001A
	v_dual_mov_b32 v62, s25 :: v_dual_mov_b32 v61, s24         // 000000163224: CA100019 3E3C0018
	ds_load_b128 v[69:72], v81 offset:16928                    // 00000016322C: DBFC4220 45000051
	ds_load_b128 v[98:101], v81 offset:16944                   // 000000163234: DBFC4230 62000051
	s_waitcnt lgkmcnt(11)                                      // 00000016323C: BF89FCB7
	v_fma_mixlo_f16 v9, v9, s44, 0                             // 000000163240: CC210009 02005909
	v_fma_mixhi_f16 v9, v10, s44, 0                            // 000000163248: CC220009 0200590A
	v_fma_mixlo_f16 v10, v11, s44, 0                           // 000000163250: CC21000A 0200590B
	v_fma_mixhi_f16 v10, v12, s44, 0                           // 000000163258: CC22000A 0200590C
	s_waitcnt lgkmcnt(10)                                      // 000000163260: BF89FCA7
	v_fma_mixlo_f16 v11, v13, s44, 0                           // 000000163264: CC21000B 0200590D
	v_fma_mixhi_f16 v11, v14, s44, 0                           // 00000016326C: CC22000B 0200590E
	v_fma_mixlo_f16 v12, v15, s44, 0                           // 000000163274: CC21000C 0200590F
	v_fma_mixhi_f16 v12, v16, s44, 0                           // 00000016327C: CC22000C 02005910
	s_waitcnt lgkmcnt(9)                                       // 000000163284: BF89FC97
	v_fma_mixlo_f16 v13, v17, s44, 0                           // 000000163288: CC21000D 02005911
	v_fma_mixhi_f16 v13, v18, s44, 0                           // 000000163290: CC22000D 02005912
	v_fma_mixlo_f16 v14, v19, s44, 0                           // 000000163298: CC21000E 02005913
	v_fma_mixhi_f16 v14, v20, s44, 0                           // 0000001632A0: CC22000E 02005914
	s_waitcnt lgkmcnt(8)                                       // 0000001632A8: BF89FC87
	v_fma_mixlo_f16 v15, v21, s44, 0                           // 0000001632AC: CC21000F 02005915
	v_fma_mixhi_f16 v15, v22, s44, 0                           // 0000001632B4: CC22000F 02005916
	v_fma_mixlo_f16 v16, v23, s44, 0                           // 0000001632BC: CC210010 02005917
	v_fma_mixhi_f16 v16, v24, s44, 0                           // 0000001632C4: CC220010 02005918
	s_waitcnt lgkmcnt(7)                                       // 0000001632CC: BF89FC77
	v_fma_mixlo_f16 v17, v25, s44, 0                           // 0000001632D0: CC210011 02005919
	v_fma_mixhi_f16 v17, v26, s44, 0                           // 0000001632D8: CC220011 0200591A
	v_fma_mixlo_f16 v18, v27, s44, 0                           // 0000001632E0: CC210012 0200591B
	v_fma_mixhi_f16 v18, v28, s44, 0                           // 0000001632E8: CC220012 0200591C
	s_waitcnt lgkmcnt(6)                                       // 0000001632F0: BF89FC67
	v_fma_mixlo_f16 v19, v29, s44, 0                           // 0000001632F4: CC210013 0200591D
	v_fma_mixhi_f16 v19, v30, s44, 0                           // 0000001632FC: CC220013 0200591E
	v_fma_mixlo_f16 v20, v31, s44, 0                           // 000000163304: CC210014 0200591F
	v_fma_mixhi_f16 v20, v32, s44, 0                           // 00000016330C: CC220014 02005920
	s_waitcnt lgkmcnt(5)                                       // 000000163314: BF89FC57
	v_fma_mixlo_f16 v21, v33, s44, 0                           // 000000163318: CC210015 02005921
	v_fma_mixhi_f16 v21, v34, s44, 0                           // 000000163320: CC220015 02005922
	v_fma_mixlo_f16 v22, v35, s44, 0                           // 000000163328: CC210016 02005923
	v_fma_mixhi_f16 v22, v36, s44, 0                           // 000000163330: CC220016 02005924
	s_waitcnt lgkmcnt(4)                                       // 000000163338: BF89FC47
	v_fma_mixlo_f16 v23, v37, s44, 0                           // 00000016333C: CC210017 02005925
	v_fma_mixhi_f16 v23, v38, s44, 0                           // 000000163344: CC220017 02005926
	v_fma_mixlo_f16 v24, v39, s44, 0                           // 00000016334C: CC210018 02005927
	v_fma_mixhi_f16 v24, v40, s44, 0                           // 000000163354: CC220018 02005928
	v_wmma_f32_16x16x16_f16 v[33:40], v[49:56], v[9:16], v[61:68]// 00000016335C: CC404021 1CF61331
	s_waitcnt lgkmcnt(3)                                       // 000000163364: BF89FC37
	v_fma_mixlo_f16 v9, v41, s44, 0                            // 000000163368: CC210009 02005929
	v_fma_mixhi_f16 v9, v42, s44, 0                            // 000000163370: CC220009 0200592A
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[17:24], v[61:68]// 000000163378: CC404019 1CF62331
	ds_load_b128 v[17:20], v81 offset:25344                    // 000000163380: DBFC6300 11000051
	ds_load_b128 v[21:24], v81 offset:25360                    // 000000163388: DBFC6310 15000051
	v_fma_mixlo_f16 v10, v43, s44, 0                           // 000000163390: CC21000A 0200592B
	v_fma_mixhi_f16 v10, v44, s44, 0                           // 000000163398: CC22000A 0200592C
	s_waitcnt lgkmcnt(4)                                       // 0000001633A0: BF89FC47
	v_fma_mixlo_f16 v11, v45, s44, 0                           // 0000001633A4: CC21000B 0200592D
	v_fma_mixhi_f16 v11, v46, s44, 0                           // 0000001633AC: CC22000B 0200592E
	ds_load_b128 v[41:44], v81 offset:25376                    // 0000001633B4: DBFC6320 29000051
	v_fma_mixlo_f16 v12, v47, s44, 0                           // 0000001633BC: CC21000C 0200592F
	v_fma_mixhi_f16 v12, v48, s44, 0                           // 0000001633C4: CC22000C 02005930
	ds_load_b128 v[45:48], v81 offset:25392                    // 0000001633CC: DBFC6330 2D000051
	s_waitcnt lgkmcnt(5)                                       // 0000001633D4: BF89FC57
	v_fma_mixlo_f16 v13, v69, s44, 0                           // 0000001633D8: CC21000D 02005945
	v_fma_mixhi_f16 v13, v70, s44, 0                           // 0000001633E0: CC22000D 02005946
	v_fma_mixlo_f16 v14, v71, s44, 0                           // 0000001633E8: CC21000E 02005947
	v_fma_mixhi_f16 v14, v72, s44, 0                           // 0000001633F0: CC22000E 02005948
	s_waitcnt lgkmcnt(4)                                       // 0000001633F8: BF89FC47
	v_fma_mixlo_f16 v15, v98, s44, 0                           // 0000001633FC: CC21000F 02005962
	v_fma_mixhi_f16 v15, v99, s44, 0                           // 000000163404: CC22000F 02005963
	v_fma_mixlo_f16 v16, v100, s44, 0                          // 00000016340C: CC210010 02005964
	v_fma_mixhi_f16 v16, v101, s44, 0                          // 000000163414: CC220010 02005965
	s_waitcnt lgkmcnt(3)                                       // 00000016341C: BF89FC37
	v_fma_mixlo_f16 v98, v17, s44, 0                           // 000000163420: CC210062 02005911
	v_fma_mixhi_f16 v98, v18, s44, 0                           // 000000163428: CC220062 02005912
	v_fma_mixlo_f16 v99, v19, s44, 0                           // 000000163430: CC210063 02005913
	v_fma_mixhi_f16 v99, v20, s44, 0                           // 000000163438: CC220063 02005914
	s_waitcnt lgkmcnt(2)                                       // 000000163440: BF89FC27
	v_fma_mixlo_f16 v100, v21, s44, 0                          // 000000163444: CC210064 02005915
	v_fma_mixhi_f16 v100, v22, s44, 0                          // 00000016344C: CC220064 02005916
	v_fma_mixlo_f16 v101, v23, s44, 0                          // 000000163454: CC210065 02005917
	v_fma_mixhi_f16 v101, v24, s44, 0                          // 00000016345C: CC220065 02005918
	s_waitcnt lgkmcnt(1)                                       // 000000163464: BF89FC17
	v_fma_mixlo_f16 v102, v41, s44, 0                          // 000000163468: CC210066 02005929
	v_fma_mixhi_f16 v102, v42, s44, 0                          // 000000163470: CC220066 0200592A
	v_fma_mixlo_f16 v103, v43, s44, 0                          // 000000163478: CC210067 0200592B
	v_fma_mixhi_f16 v103, v44, s44, 0                          // 000000163480: CC220067 0200592C
	s_waitcnt lgkmcnt(0)                                       // 000000163488: BF89FC07
	v_fma_mixlo_f16 v104, v45, s44, 0                          // 00000016348C: CC210068 0200592D
	v_fma_mixhi_f16 v104, v46, s44, 0                          // 000000163494: CC220068 0200592E
	v_fma_mixlo_f16 v105, v47, s44, 0                          // 00000016349C: CC210069 0200592F
	v_fma_mixhi_f16 v105, v48, s44, 0                          // 0000001634A4: CC220069 02005930
	.long 0x7f603880                                           // 0000001634AC: 7F603880
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[9:16], v[61:68]// 0000001634B0: CC404011 1CF61331
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001634B8: BF870193
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[98:105], v[61:68]// 0000001634BC: CC404009 1CF6C531
	.long 0x7f5c39b0                                           // 0000001634C4: 7F5C39B0
	.long 0x7e5c39b0                                           // 0000001634C8: 7E5C39B0
	.long 0x7f5a39b0                                           // 0000001634CC: 7F5A39B0
	.long 0x7e5a39b0                                           // 0000001634D0: 7E5A39B0
	s_and_saveexec_b32 s11, s0                                 // 0000001634D4: BE8B2000
	s_cbranch_execz 11                                         // 0000001634D8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3408>
	global_load_b128 v[41:44], v[59:60], off offset:64         // 0000001634DC: DC5E0040 297C003B
	s_waitcnt vmcnt(0)                                         // 0000001634E4: BF8903F7
	v_fma_mixlo_f16 v45, v41, s44, 0                           // 0000001634E8: CC21002D 02005929
	v_fma_mixhi_f16 v45, v42, s44, 0                           // 0000001634F0: CC22002D 0200592A
	v_fma_mixlo_f16 v46, v43, s44, 0                           // 0000001634F8: CC21002E 0200592B
	v_fma_mixhi_f16 v46, v44, s44, 0                           // 000000163500: CC22002E 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 000000163508: 8C7E0B7E
	.long 0x7e6039b0                                           // 00000016350C: 7E6039B0
	.long 0x7f5e39b0                                           // 000000163510: 7F5E39B0
	.long 0x7e5e39b0                                           // 000000163514: 7E5E39B0
	s_and_saveexec_b32 s11, s0                                 // 000000163518: BE8B2000
	s_cbranch_execz 11                                         // 00000016351C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x344c>
	global_load_b128 v[41:44], v[59:60], off offset:80         // 000000163520: DC5E0050 297C003B
	s_waitcnt vmcnt(0)                                         // 000000163528: BF8903F7
	v_fma_mixlo_f16 v47, v41, s44, 0                           // 00000016352C: CC21002F 02005929
	v_fma_mixhi_f16 v47, v42, s44, 0                           // 000000163534: CC22002F 0200592A
	v_fma_mixlo_f16 v48, v43, s44, 0                           // 00000016353C: CC210030 0200592B
	v_fma_mixhi_f16 v48, v44, s44, 0                           // 000000163544: CC220030 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016354C: 8C7E0B7E
	.long 0x7f683880                                           // 000000163550: 7F683880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000163554: BF870001
	.long 0x7f6439b4                                           // 000000163558: 7F6439B4
	.long 0x7e6439b4                                           // 00000016355C: 7E6439B4
	.long 0x7f6239b4                                           // 000000163560: 7F6239B4
	.long 0x7e6239b4                                           // 000000163564: 7E6239B4
	s_and_saveexec_b32 s11, s0                                 // 000000163568: BE8B2000
	s_cbranch_execz 11                                         // 00000016356C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x349c>
	global_load_b128 v[41:44], v[59:60], off offset:96         // 000000163570: DC5E0060 297C003B
	s_waitcnt vmcnt(0)                                         // 000000163578: BF8903F7
	v_fma_mixlo_f16 v49, v41, s44, 0                           // 00000016357C: CC210031 02005929
	v_fma_mixhi_f16 v49, v42, s44, 0                           // 000000163584: CC220031 0200592A
	v_fma_mixlo_f16 v50, v43, s44, 0                           // 00000016358C: CC210032 0200592B
	v_fma_mixhi_f16 v50, v44, s44, 0                           // 000000163594: CC220032 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016359C: 8C7E0B7E
	.long 0x7e6839b4                                           // 0000001635A0: 7E6839B4
	.long 0x7f6639b4                                           // 0000001635A4: 7F6639B4
	.long 0x7e6639b4                                           // 0000001635A8: 7E6639B4
	s_and_saveexec_b32 s11, s0                                 // 0000001635AC: BE8B2000
	s_cbranch_execz 11                                         // 0000001635B0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x34e0>
	global_load_b128 v[41:44], v[59:60], off offset:112        // 0000001635B4: DC5E0070 297C003B
	s_waitcnt vmcnt(0)                                         // 0000001635BC: BF8903F7
	v_fma_mixlo_f16 v51, v41, s44, 0                           // 0000001635C0: CC210033 02005929
	v_fma_mixhi_f16 v51, v42, s44, 0                           // 0000001635C8: CC220033 0200592A
	v_fma_mixlo_f16 v52, v43, s44, 0                           // 0000001635D0: CC210034 0200592B
	v_fma_mixhi_f16 v52, v44, s44, 0                           // 0000001635D8: CC220034 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001635E0: 8C7E0B7E
	ds_load_b128 v[41:44], v81 offset:64                       // 0000001635E4: DBFC0040 29000051
	ds_load_b128 v[53:56], v81 offset:80                       // 0000001635EC: DBFC0050 35000051
	ds_load_b128 v[65:68], v81 offset:96                       // 0000001635F4: DBFC0060 41000051
	ds_load_b128 v[69:72], v81 offset:112                      // 0000001635FC: DBFC0070 45000051
	ds_load_b128 v[98:101], v81 offset:8512                    // 000000163604: DBFC2140 62000051
	ds_load_b128 v[102:105], v81 offset:8528                   // 00000016360C: DBFC2150 66000051
	ds_load_b128 v[106:109], v81 offset:8544                   // 000000163614: DBFC2160 6A000051
	ds_load_b128 v[110:113], v81 offset:8560                   // 00000016361C: DBFC2170 6E000051
	ds_load_b128 v[118:121], v81 offset:25408                  // 000000163624: DBFC6340 76000051
	ds_load_b128 v[122:125], v81 offset:25424                  // 00000016362C: DBFC6350 7A000051
	ds_load_b128 v[114:117], v81 offset:17008                  // 000000163634: DBFC4270 72000051
	s_waitcnt lgkmcnt(10)                                      // 00000016363C: BF89FCA7
	v_fma_mixlo_f16 v61, v41, s44, 0                           // 000000163640: CC21003D 02005929
	v_fma_mixhi_f16 v61, v42, s44, 0                           // 000000163648: CC22003D 0200592A
	v_fma_mixlo_f16 v62, v43, s44, 0                           // 000000163650: CC21003E 0200592B
	v_fma_mixhi_f16 v62, v44, s44, 0                           // 000000163658: CC22003E 0200592C
	s_waitcnt lgkmcnt(9)                                       // 000000163660: BF89FC97
	v_fma_mixlo_f16 v63, v53, s44, 0                           // 000000163664: CC21003F 02005935
	v_fma_mixhi_f16 v63, v54, s44, 0                           // 00000016366C: CC22003F 02005936
	v_fma_mixlo_f16 v64, v55, s44, 0                           // 000000163674: CC210040 02005937
	v_fma_mixhi_f16 v64, v56, s44, 0                           // 00000016367C: CC220040 02005938
	ds_load_b128 v[41:44], v81 offset:16960                    // 000000163684: DBFC4240 29000051
	ds_load_b128 v[53:56], v81 offset:16976                    // 00000016368C: DBFC4250 35000051
	s_waitcnt lgkmcnt(10)                                      // 000000163694: BF89FCA7
	v_fma_mixlo_f16 v65, v65, s44, 0                           // 000000163698: CC210041 02005941
	v_fma_mixhi_f16 v65, v66, s44, 0                           // 0000001636A0: CC220041 02005942
	v_fma_mixlo_f16 v66, v67, s44, 0                           // 0000001636A8: CC210042 02005943
	v_fma_mixhi_f16 v66, v68, s44, 0                           // 0000001636B0: CC220042 02005944
	s_waitcnt lgkmcnt(9)                                       // 0000001636B8: BF89FC97
	v_fma_mixlo_f16 v67, v69, s44, 0                           // 0000001636BC: CC210043 02005945
	v_fma_mixhi_f16 v67, v70, s44, 0                           // 0000001636C4: CC220043 02005946
	v_fma_mixlo_f16 v68, v71, s44, 0                           // 0000001636CC: CC210044 02005947
	v_fma_mixhi_f16 v68, v72, s44, 0                           // 0000001636D4: CC220044 02005948
	s_waitcnt lgkmcnt(8)                                       // 0000001636DC: BF89FC87
	v_fma_mixlo_f16 v98, v98, s44, 0                           // 0000001636E0: CC210062 02005962
	v_fma_mixhi_f16 v98, v99, s44, 0                           // 0000001636E8: CC220062 02005963
	v_fma_mixlo_f16 v99, v100, s44, 0                          // 0000001636F0: CC210063 02005964
	s_waitcnt lgkmcnt(7)                                       // 0000001636F8: BF89FC77
	v_fma_mixlo_f16 v100, v102, s44, 0                         // 0000001636FC: CC210064 02005966
	v_fma_mixhi_f16 v100, v103, s44, 0                         // 000000163704: CC220064 02005967
	s_waitcnt lgkmcnt(6)                                       // 00000016370C: BF89FC67
	v_fma_mixlo_f16 v102, v106, s44, 0                         // 000000163710: CC210066 0200596A
	ds_load_b128 v[69:72], v81 offset:16992                    // 000000163718: DBFC4260 45000051
	v_fma_mixhi_f16 v102, v107, s44, 0                         // 000000163720: CC220066 0200596B
	v_fma_mixlo_f16 v103, v108, s44, 0                         // 000000163728: CC210067 0200596C
	v_fma_mixhi_f16 v103, v109, s44, 0                         // 000000163730: CC220067 0200596D
	s_waitcnt lgkmcnt(2)                                       // 000000163738: BF89FC27
	v_fma_mixlo_f16 v106, v41, s44, 0                          // 00000016373C: CC21006A 02005929
	v_fma_mixhi_f16 v106, v42, s44, 0                          // 000000163744: CC22006A 0200592A
	v_fma_mixlo_f16 v107, v43, s44, 0                          // 00000016374C: CC21006B 0200592B
	v_fma_mixhi_f16 v107, v44, s44, 0                          // 000000163754: CC22006B 0200592C
	s_waitcnt lgkmcnt(1)                                       // 00000016375C: BF89FC17
	v_fma_mixlo_f16 v108, v53, s44, 0                          // 000000163760: CC21006C 02005935
	v_fma_mixhi_f16 v108, v54, s44, 0                          // 000000163768: CC22006C 02005936
	ds_load_b128 v[41:44], v81 offset:25440                    // 000000163770: DBFC6360 29000051
	v_fma_mixlo_f16 v109, v55, s44, 0                          // 000000163778: CC21006D 02005937
	v_fma_mixhi_f16 v109, v56, s44, 0                          // 000000163780: CC22006D 02005938
	ds_load_b128 v[53:56], v81 offset:25456                    // 000000163788: DBFC6370 35000051
	v_fma_mixhi_f16 v99, v101, s44, 0                          // 000000163790: CC220063 02005965
	v_fma_mixlo_f16 v101, v104, s44, 0                         // 000000163798: CC210065 02005968
	v_fma_mixhi_f16 v101, v105, s44, 0                         // 0000001637A0: CC220065 02005969
	v_fma_mixlo_f16 v104, v110, s44, 0                         // 0000001637A8: CC210068 0200596E
	v_fma_mixhi_f16 v104, v111, s44, 0                         // 0000001637B0: CC220068 0200596F
	v_fma_mixlo_f16 v105, v112, s44, 0                         // 0000001637B8: CC210069 02005970
	v_fma_mixhi_f16 v105, v113, s44, 0                         // 0000001637C0: CC220069 02005971
	s_waitcnt lgkmcnt(2)                                       // 0000001637C8: BF89FC27
	v_fma_mixlo_f16 v110, v69, s44, 0                          // 0000001637CC: CC21006E 02005945
	v_fma_mixhi_f16 v110, v70, s44, 0                          // 0000001637D4: CC22006E 02005946
	v_fma_mixlo_f16 v111, v71, s44, 0                          // 0000001637DC: CC21006F 02005947
	v_fma_mixhi_f16 v111, v72, s44, 0                          // 0000001637E4: CC22006F 02005948
	v_fma_mixlo_f16 v112, v114, s44, 0                         // 0000001637EC: CC210070 02005972
	v_fma_mixhi_f16 v112, v115, s44, 0                         // 0000001637F4: CC220070 02005973
	v_fma_mixlo_f16 v113, v116, s44, 0                         // 0000001637FC: CC210071 02005974
	v_fma_mixhi_f16 v113, v117, s44, 0                         // 000000163804: CC220071 02005975
	v_fma_mixlo_f16 v114, v118, s44, 0                         // 00000016380C: CC210072 02005976
	v_fma_mixhi_f16 v114, v119, s44, 0                         // 000000163814: CC220072 02005977
	v_fma_mixlo_f16 v115, v120, s44, 0                         // 00000016381C: CC210073 02005978
	v_fma_mixhi_f16 v115, v121, s44, 0                         // 000000163824: CC220073 02005979
	v_fma_mixlo_f16 v116, v122, s44, 0                         // 00000016382C: CC210074 0200597A
	v_fma_mixhi_f16 v116, v123, s44, 0                         // 000000163834: CC220074 0200597B
	v_fma_mixlo_f16 v117, v124, s44, 0                         // 00000016383C: CC210075 0200597C
	v_fma_mixhi_f16 v117, v125, s44, 0                         // 000000163844: CC220075 0200597D
	s_waitcnt lgkmcnt(1)                                       // 00000016384C: BF89FC17
	v_fma_mixlo_f16 v118, v41, s44, 0                          // 000000163850: CC210076 02005929
	v_fma_mixhi_f16 v118, v42, s44, 0                          // 000000163858: CC220076 0200592A
	v_fma_mixlo_f16 v119, v43, s44, 0                          // 000000163860: CC210077 0200592B
	v_fma_mixhi_f16 v119, v44, s44, 0                          // 000000163868: CC220077 0200592C
	s_waitcnt lgkmcnt(0)                                       // 000000163870: BF89FC07
	v_fma_mixlo_f16 v120, v53, s44, 0                          // 000000163874: CC210078 02005935
	v_fma_mixhi_f16 v120, v54, s44, 0                          // 00000016387C: CC220078 02005936
	v_fma_mixlo_f16 v121, v55, s44, 0                          // 000000163884: CC210079 02005937
	v_fma_mixhi_f16 v121, v56, s44, 0                          // 00000016388C: CC220079 02005938
	.long 0x7f583880                                           // 000000163894: 7F583880
	v_wmma_f32_16x16x16_f16 v[33:40], v[45:52], v[61:68], v[33:40]// 000000163898: CC404021 1C867B2D
	v_wmma_f32_16x16x16_f16 v[25:32], v[45:52], v[98:105], v[25:32]// 0000001638A0: CC404019 1C66C52D
	v_wmma_f32_16x16x16_f16 v[17:24], v[45:52], v[106:113], v[17:24]// 0000001638A8: CC404011 1C46D52D
	v_wmma_f32_16x16x16_f16 v[9:16], v[45:52], v[114:121], v[9:16]// 0000001638B0: CC404009 1C26E52D
	.long 0x7f5439ac                                           // 0000001638B8: 7F5439AC
	.long 0x7e5439ac                                           // 0000001638BC: 7E5439AC
	.long 0x7f5239ac                                           // 0000001638C0: 7F5239AC
	.long 0x7e5239ac                                           // 0000001638C4: 7E5239AC
	s_and_saveexec_b32 s11, s0                                 // 0000001638C8: BE8B2000
	s_cbranch_execz 11                                         // 0000001638CC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x37fc>
	global_load_b128 v[45:48], v[59:60], off offset:128        // 0000001638D0: DC5E0080 2D7C003B
	s_waitcnt vmcnt(0)                                         // 0000001638D8: BF8903F7
	v_fma_mixlo_f16 v41, v45, s44, 0                           // 0000001638DC: CC210029 0200592D
	v_fma_mixhi_f16 v41, v46, s44, 0                           // 0000001638E4: CC220029 0200592E
	v_fma_mixlo_f16 v42, v47, s44, 0                           // 0000001638EC: CC21002A 0200592F
	v_fma_mixhi_f16 v42, v48, s44, 0                           // 0000001638F4: CC22002A 02005930
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001638FC: 8C7E0B7E
	.long 0x7e5839ac                                           // 000000163900: 7E5839AC
	.long 0x7f5639ac                                           // 000000163904: 7F5639AC
	.long 0x7e5639ac                                           // 000000163908: 7E5639AC
	s_and_saveexec_b32 s11, s0                                 // 00000016390C: BE8B2000
	s_cbranch_execz 11                                         // 000000163910: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3840>
	global_load_b128 v[43:46], v[59:60], off offset:144        // 000000163914: DC5E0090 2B7C003B
	s_waitcnt vmcnt(0)                                         // 00000016391C: BF8903F7
	v_fma_mixlo_f16 v43, v43, s44, 0                           // 000000163920: CC21002B 0200592B
	v_fma_mixhi_f16 v43, v44, s44, 0                           // 000000163928: CC22002B 0200592C
	v_fma_mixlo_f16 v44, v45, s44, 0                           // 000000163930: CC21002C 0200592D
	v_fma_mixhi_f16 v44, v46, s44, 0                           // 000000163938: CC22002C 0200592E
	s_or_b32 exec_lo, exec_lo, s11                             // 000000163940: 8C7E0B7E
	.long 0x7f603880                                           // 000000163944: 7F603880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000163948: BF870001
	.long 0x7f5c39b0                                           // 00000016394C: 7F5C39B0
	.long 0x7e5c39b0                                           // 000000163950: 7E5C39B0
	.long 0x7f5a39b0                                           // 000000163954: 7F5A39B0
	.long 0x7e5a39b0                                           // 000000163958: 7E5A39B0
	s_and_saveexec_b32 s11, s0                                 // 00000016395C: BE8B2000
	s_cbranch_execz 11                                         // 000000163960: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3890>
	global_load_b128 v[49:52], v[59:60], off offset:160        // 000000163964: DC5E00A0 317C003B
	s_waitcnt vmcnt(0)                                         // 00000016396C: BF8903F7
	v_fma_mixlo_f16 v45, v49, s44, 0                           // 000000163970: CC21002D 02005931
	v_fma_mixhi_f16 v45, v50, s44, 0                           // 000000163978: CC22002D 02005932
	v_fma_mixlo_f16 v46, v51, s44, 0                           // 000000163980: CC21002E 02005933
	v_fma_mixhi_f16 v46, v52, s44, 0                           // 000000163988: CC22002E 02005934
	s_or_b32 exec_lo, exec_lo, s11                             // 000000163990: 8C7E0B7E
	.long 0x7e6039b0                                           // 000000163994: 7E6039B0
	.long 0x7f5e39b0                                           // 000000163998: 7F5E39B0
	.long 0x7e5e39b0                                           // 00000016399C: 7E5E39B0
	s_and_saveexec_b32 s11, s0                                 // 0000001639A0: BE8B2000
	s_cbranch_execz 11                                         // 0000001639A4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x38d4>
	global_load_b128 v[47:50], v[59:60], off offset:176        // 0000001639A8: DC5E00B0 2F7C003B
	s_waitcnt vmcnt(0)                                         // 0000001639B0: BF8903F7
	v_fma_mixlo_f16 v47, v47, s44, 0                           // 0000001639B4: CC21002F 0200592F
	v_fma_mixhi_f16 v47, v48, s44, 0                           // 0000001639BC: CC22002F 02005930
	v_fma_mixlo_f16 v48, v49, s44, 0                           // 0000001639C4: CC210030 02005931
	v_fma_mixhi_f16 v48, v50, s44, 0                           // 0000001639CC: CC220030 02005932
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001639D4: 8C7E0B7E
	ds_load_b128 v[50:53], v81 offset:128                      // 0000001639D8: DBFC0080 32000051
	ds_load_b128 v[54:57], v81 offset:144                      // 0000001639E0: DBFC0090 36000051
	ds_load_b128 v[61:64], v81 offset:160                      // 0000001639E8: DBFC00A0 3D000051
	ds_load_b128 v[65:68], v81 offset:176                      // 0000001639F0: DBFC00B0 41000051
	ds_load_b128 v[69:72], v81 offset:8576                     // 0000001639F8: DBFC2180 45000051
	ds_load_b128 v[98:101], v81 offset:8592                    // 000000163A00: DBFC2190 62000051
	ds_load_b128 v[102:105], v81 offset:8608                   // 000000163A08: DBFC21A0 66000051
	ds_load_b128 v[106:109], v81 offset:8624                   // 000000163A10: DBFC21B0 6A000051
	ds_load_b128 v[110:113], v81 offset:17024                  // 000000163A18: DBFC4280 6E000051
	ds_load_b128 v[114:117], v81 offset:17056                  // 000000163A20: DBFC42A0 72000051
	ds_load_b128 v[118:121], v81 offset:17072                  // 000000163A28: DBFC42B0 76000051
	.long 0x7f623880                                           // 000000163A30: 7F623880
	ds_load_b128 v[122:125], v81 offset:25488                  // 000000163A34: DBFC6390 7A000051
	s_waitcnt lgkmcnt(11)                                      // 000000163A3C: BF89FCB7
	v_fma_mixlo_f16 v50, v50, s44, 0                           // 000000163A40: CC210032 02005932
	v_fma_mixhi_f16 v50, v51, s44, 0                           // 000000163A48: CC220032 02005933
	v_fma_mixlo_f16 v51, v52, s44, 0                           // 000000163A50: CC210033 02005934
	s_waitcnt lgkmcnt(10)                                      // 000000163A58: BF89FCA7
	v_fma_mixlo_f16 v52, v54, s44, 0                           // 000000163A5C: CC210034 02005936
	s_waitcnt lgkmcnt(9)                                       // 000000163A64: BF89FC97
	v_fma_mixlo_f16 v54, v61, s44, 0                           // 000000163A68: CC210036 0200593D
	v_fma_mixhi_f16 v54, v62, s44, 0                           // 000000163A70: CC220036 0200593E
	s_waitcnt lgkmcnt(7)                                       // 000000163A78: BF89FC77
	v_fma_mixlo_f16 v61, v69, s44, 0                           // 000000163A7C: CC21003D 02005945
	v_fma_mixhi_f16 v61, v70, s44, 0                           // 000000163A84: CC22003D 02005946
	v_fma_mixlo_f16 v62, v71, s44, 0                           // 000000163A8C: CC21003E 02005947
	v_fma_mixhi_f16 v62, v72, s44, 0                           // 000000163A94: CC22003E 02005948
	ds_load_b128 v[69:72], v81 offset:17040                    // 000000163A9C: DBFC4290 45000051
	v_fma_mixhi_f16 v51, v53, s44, 0                           // 000000163AA4: CC220033 02005935
	v_fma_mixhi_f16 v52, v55, s44, 0                           // 000000163AAC: CC220034 02005937
	v_fma_mixhi_f16 v53, v57, s44, 0                           // 000000163AB4: CC220035 02005939
	v_fma_mixlo_f16 v55, v63, s44, 0                           // 000000163ABC: CC210037 0200593F
	v_fma_mixhi_f16 v55, v64, s44, 0                           // 000000163AC4: CC220037 02005940
	v_fma_mixlo_f16 v57, v67, s44, 0                           // 000000163ACC: CC210039 02005943
	v_fma_mixhi_f16 v57, v68, s44, 0                           // 000000163AD4: CC220039 02005944
	s_waitcnt lgkmcnt(7)                                       // 000000163ADC: BF89FC77
	v_fma_mixlo_f16 v63, v98, s44, 0                           // 000000163AE0: CC21003F 02005962
	v_fma_mixhi_f16 v63, v99, s44, 0                           // 000000163AE8: CC22003F 02005963
	v_fma_mixlo_f16 v64, v100, s44, 0                          // 000000163AF0: CC210040 02005964
	v_fma_mixhi_f16 v64, v101, s44, 0                          // 000000163AF8: CC220040 02005965
	s_waitcnt lgkmcnt(5)                                       // 000000163B00: BF89FC57
	v_fma_mixlo_f16 v67, v106, s44, 0                          // 000000163B04: CC210043 0200596A
	v_fma_mixhi_f16 v67, v107, s44, 0                          // 000000163B0C: CC220043 0200596B
	v_fma_mixlo_f16 v68, v108, s44, 0                          // 000000163B14: CC210044 0200596C
	v_fma_mixhi_f16 v68, v109, s44, 0                          // 000000163B1C: CC220044 0200596D
	ds_load_b128 v[106:109], v81 offset:25472                  // 000000163B24: DBFC6380 6A000051
	s_waitcnt lgkmcnt(5)                                       // 000000163B2C: BF89FC57
	v_fma_mixlo_f16 v98, v110, s44, 0                          // 000000163B30: CC210062 0200596E
	v_fma_mixhi_f16 v98, v111, s44, 0                          // 000000163B38: CC220062 0200596F
	v_fma_mixlo_f16 v99, v112, s44, 0                          // 000000163B40: CC210063 02005970
	v_fma_mixhi_f16 v99, v113, s44, 0                          // 000000163B48: CC220063 02005971
	s_waitcnt lgkmcnt(1)                                       // 000000163B50: BF89FC17
	v_fma_mixlo_f16 v100, v69, s44, 0                          // 000000163B54: CC210064 02005945
	v_fma_mixhi_f16 v100, v70, s44, 0                          // 000000163B5C: CC220064 02005946
	ds_load_b128 v[110:113], v81 offset:25504                  // 000000163B64: DBFC63A0 6E000051
	v_fma_mixlo_f16 v101, v71, s44, 0                          // 000000163B6C: CC210065 02005947
	v_fma_mixhi_f16 v101, v72, s44, 0                          // 000000163B74: CC220065 02005948
	ds_load_b128 v[69:72], v81 offset:25520                    // 000000163B7C: DBFC63B0 45000051
	v_fma_mixlo_f16 v53, v56, s44, 0                           // 000000163B84: CC210035 02005938
	v_fma_mixlo_f16 v56, v65, s44, 0                           // 000000163B8C: CC210038 02005941
	v_fma_mixhi_f16 v56, v66, s44, 0                           // 000000163B94: CC220038 02005942
	v_fma_mixlo_f16 v65, v102, s44, 0                          // 000000163B9C: CC210041 02005966
	v_fma_mixhi_f16 v65, v103, s44, 0                          // 000000163BA4: CC220041 02005967
	v_fma_mixlo_f16 v66, v104, s44, 0                          // 000000163BAC: CC210042 02005968
	v_fma_mixhi_f16 v66, v105, s44, 0                          // 000000163BB4: CC220042 02005969
	v_fma_mixlo_f16 v102, v114, s44, 0                         // 000000163BBC: CC210066 02005972
	v_fma_mixhi_f16 v102, v115, s44, 0                         // 000000163BC4: CC220066 02005973
	v_fma_mixlo_f16 v103, v116, s44, 0                         // 000000163BCC: CC210067 02005974
	v_fma_mixhi_f16 v103, v117, s44, 0                         // 000000163BD4: CC220067 02005975
	v_fma_mixlo_f16 v104, v118, s44, 0                         // 000000163BDC: CC210068 02005976
	v_fma_mixhi_f16 v104, v119, s44, 0                         // 000000163BE4: CC220068 02005977
	v_fma_mixlo_f16 v105, v120, s44, 0                         // 000000163BEC: CC210069 02005978
	v_fma_mixhi_f16 v105, v121, s44, 0                         // 000000163BF4: CC220069 02005979
	s_waitcnt lgkmcnt(2)                                       // 000000163BFC: BF89FC27
	v_fma_mixlo_f16 v106, v106, s44, 0                         // 000000163C00: CC21006A 0200596A
	v_fma_mixhi_f16 v106, v107, s44, 0                         // 000000163C08: CC22006A 0200596B
	v_fma_mixlo_f16 v107, v108, s44, 0                         // 000000163C10: CC21006B 0200596C
	v_fma_mixhi_f16 v107, v109, s44, 0                         // 000000163C18: CC22006B 0200596D
	v_fma_mixlo_f16 v108, v122, s44, 0                         // 000000163C20: CC21006C 0200597A
	v_fma_mixhi_f16 v108, v123, s44, 0                         // 000000163C28: CC22006C 0200597B
	v_fma_mixlo_f16 v109, v124, s44, 0                         // 000000163C30: CC21006D 0200597C
	v_fma_mixhi_f16 v109, v125, s44, 0                         // 000000163C38: CC22006D 0200597D
	s_waitcnt lgkmcnt(1)                                       // 000000163C40: BF89FC17
	v_fma_mixlo_f16 v110, v110, s44, 0                         // 000000163C44: CC21006E 0200596E
	v_fma_mixhi_f16 v110, v111, s44, 0                         // 000000163C4C: CC22006E 0200596F
	v_fma_mixlo_f16 v111, v112, s44, 0                         // 000000163C54: CC21006F 02005970
	v_fma_mixhi_f16 v111, v113, s44, 0                         // 000000163C5C: CC22006F 02005971
	s_waitcnt lgkmcnt(0)                                       // 000000163C64: BF89FC07
	v_fma_mixlo_f16 v112, v69, s44, 0                          // 000000163C68: CC210070 02005945
	v_fma_mixhi_f16 v112, v70, s44, 0                          // 000000163C70: CC220070 02005946
	v_fma_mixlo_f16 v113, v71, s44, 0                          // 000000163C78: CC210071 02005947
	v_fma_mixhi_f16 v113, v72, s44, 0                          // 000000163C80: CC220071 02005948
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[50:57], v[33:40]// 000000163C88: CC404021 1C866529
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[61:68], v[25:32]// 000000163C90: CC404019 1C667B29
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[98:105], v[17:24]// 000000163C98: CC404011 1C46C529
	s_delay_alu instid0(VALU_DEP_4)                            // 000000163CA0: BF870004
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[106:113], v[9:16]// 000000163CA4: CC404009 1C26D529
	.long 0x7f5e39b1                                           // 000000163CAC: 7F5E39B1
	.long 0x7e5e39b1                                           // 000000163CB0: 7E5E39B1
	.long 0x7f5c39b1                                           // 000000163CB4: 7F5C39B1
	.long 0x7e5c39b1                                           // 000000163CB8: 7E5C39B1
	s_and_saveexec_b32 s11, s0                                 // 000000163CBC: BE8B2000
	s_cbranch_execz 11                                         // 000000163CC0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3bf0>
	global_load_b128 v[41:44], v[59:60], off offset:192        // 000000163CC4: DC5E00C0 297C003B
	s_waitcnt vmcnt(0)                                         // 000000163CCC: BF8903F7
	v_fma_mixlo_f16 v46, v41, s44, 0                           // 000000163CD0: CC21002E 02005929
	v_fma_mixhi_f16 v46, v42, s44, 0                           // 000000163CD8: CC22002E 0200592A
	v_fma_mixlo_f16 v47, v43, s44, 0                           // 000000163CE0: CC21002F 0200592B
	v_fma_mixhi_f16 v47, v44, s44, 0                           // 000000163CE8: CC22002F 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 000000163CF0: 8C7E0B7E
	.long 0x7e6239b1                                           // 000000163CF4: 7E6239B1
	.long 0x7f6039b1                                           // 000000163CF8: 7F6039B1
	.long 0x7e6039b1                                           // 000000163CFC: 7E6039B1
	s_and_saveexec_b32 s11, s0                                 // 000000163D00: BE8B2000
	s_cbranch_execz 11                                         // 000000163D04: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3c34>
	global_load_b128 v[41:44], v[59:60], off offset:208        // 000000163D08: DC5E00D0 297C003B
	s_waitcnt vmcnt(0)                                         // 000000163D10: BF8903F7
	v_fma_mixlo_f16 v48, v41, s44, 0                           // 000000163D14: CC210030 02005929
	v_fma_mixhi_f16 v48, v42, s44, 0                           // 000000163D1C: CC220030 0200592A
	v_fma_mixlo_f16 v49, v43, s44, 0                           // 000000163D24: CC210031 0200592B
	v_fma_mixhi_f16 v49, v44, s44, 0                           // 000000163D2C: CC220031 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 000000163D34: 8C7E0B7E
	.long 0x7f6a3880                                           // 000000163D38: 7F6A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000163D3C: BF870001
	.long 0x7f6639b5                                           // 000000163D40: 7F6639B5
	.long 0x7e6639b5                                           // 000000163D44: 7E6639B5
	.long 0x7f6439b5                                           // 000000163D48: 7F6439B5
	.long 0x7e6439b5                                           // 000000163D4C: 7E6439B5
	s_and_saveexec_b32 s11, s0                                 // 000000163D50: BE8B2000
	s_cbranch_execz 11                                         // 000000163D54: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3c84>
	global_load_b128 v[41:44], v[59:60], off offset:224        // 000000163D58: DC5E00E0 297C003B
	s_waitcnt vmcnt(0)                                         // 000000163D60: BF8903F7
	v_fma_mixlo_f16 v50, v41, s44, 0                           // 000000163D64: CC210032 02005929
	v_fma_mixhi_f16 v50, v42, s44, 0                           // 000000163D6C: CC220032 0200592A
	v_fma_mixlo_f16 v51, v43, s44, 0                           // 000000163D74: CC210033 0200592B
	v_fma_mixhi_f16 v51, v44, s44, 0                           // 000000163D7C: CC220033 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 000000163D84: 8C7E0B7E
	.long 0x7e6a39b5                                           // 000000163D88: 7E6A39B5
	.long 0x7f6839b5                                           // 000000163D8C: 7F6839B5
	.long 0x7e6839b5                                           // 000000163D90: 7E6839B5
	s_and_saveexec_b32 s11, s0                                 // 000000163D94: BE8B2000
	s_cbranch_execz 11                                         // 000000163D98: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3cc8>
	global_load_b128 v[41:44], v[59:60], off offset:240        // 000000163D9C: DC5E00F0 297C003B
	s_waitcnt vmcnt(0)                                         // 000000163DA4: BF8903F7
	v_fma_mixlo_f16 v52, v41, s44, 0                           // 000000163DA8: CC210034 02005929
	v_fma_mixhi_f16 v52, v42, s44, 0                           // 000000163DB0: CC220034 0200592A
	v_fma_mixlo_f16 v53, v43, s44, 0                           // 000000163DB8: CC210035 0200592B
	v_fma_mixhi_f16 v53, v44, s44, 0                           // 000000163DC0: CC220035 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 000000163DC8: 8C7E0B7E
	ds_load_b128 v[41:44], v81 offset:192                      // 000000163DCC: DBFC00C0 29000051
	ds_load_b128 v[54:57], v81 offset:208                      // 000000163DD4: DBFC00D0 36000051
	ds_load_b128 v[65:68], v81 offset:224                      // 000000163DDC: DBFC00E0 41000051
	ds_load_b128 v[69:72], v81 offset:240                      // 000000163DE4: DBFC00F0 45000051
	ds_load_b128 v[98:101], v81 offset:8640                    // 000000163DEC: DBFC21C0 62000051
	ds_load_b128 v[102:105], v81 offset:8656                   // 000000163DF4: DBFC21D0 66000051
	ds_load_b128 v[106:109], v81 offset:8672                   // 000000163DFC: DBFC21E0 6A000051
	ds_load_b128 v[110:113], v81 offset:8688                   // 000000163E04: DBFC21F0 6E000051
	ds_load_b128 v[118:121], v81 offset:25536                  // 000000163E0C: DBFC63C0 76000051
	ds_load_b128 v[122:125], v81 offset:25552                  // 000000163E14: DBFC63D0 7A000051
	ds_load_b128 v[114:117], v81 offset:17136                  // 000000163E1C: DBFC42F0 72000051
	s_waitcnt lgkmcnt(10)                                      // 000000163E24: BF89FCA7
	v_fma_mixlo_f16 v61, v41, s44, 0                           // 000000163E28: CC21003D 02005929
	v_fma_mixhi_f16 v61, v42, s44, 0                           // 000000163E30: CC22003D 0200592A
	v_fma_mixlo_f16 v62, v43, s44, 0                           // 000000163E38: CC21003E 0200592B
	v_fma_mixhi_f16 v62, v44, s44, 0                           // 000000163E40: CC22003E 0200592C
	s_waitcnt lgkmcnt(9)                                       // 000000163E48: BF89FC97
	v_fma_mixlo_f16 v63, v54, s44, 0                           // 000000163E4C: CC21003F 02005936
	v_fma_mixhi_f16 v63, v55, s44, 0                           // 000000163E54: CC22003F 02005937
	v_fma_mixlo_f16 v64, v56, s44, 0                           // 000000163E5C: CC210040 02005938
	v_fma_mixhi_f16 v64, v57, s44, 0                           // 000000163E64: CC220040 02005939
	ds_load_b128 v[41:44], v81 offset:17088                    // 000000163E6C: DBFC42C0 29000051
	ds_load_b128 v[54:57], v81 offset:17104                    // 000000163E74: DBFC42D0 36000051
	s_waitcnt lgkmcnt(10)                                      // 000000163E7C: BF89FCA7
	v_fma_mixlo_f16 v65, v65, s44, 0                           // 000000163E80: CC210041 02005941
	v_fma_mixhi_f16 v65, v66, s44, 0                           // 000000163E88: CC220041 02005942
	v_fma_mixlo_f16 v66, v67, s44, 0                           // 000000163E90: CC210042 02005943
	v_fma_mixhi_f16 v66, v68, s44, 0                           // 000000163E98: CC220042 02005944
	s_waitcnt lgkmcnt(9)                                       // 000000163EA0: BF89FC97
	v_fma_mixlo_f16 v67, v69, s44, 0                           // 000000163EA4: CC210043 02005945
	v_fma_mixhi_f16 v67, v70, s44, 0                           // 000000163EAC: CC220043 02005946
	v_fma_mixlo_f16 v68, v71, s44, 0                           // 000000163EB4: CC210044 02005947
	v_fma_mixhi_f16 v68, v72, s44, 0                           // 000000163EBC: CC220044 02005948
	s_waitcnt lgkmcnt(8)                                       // 000000163EC4: BF89FC87
	v_fma_mixlo_f16 v98, v98, s44, 0                           // 000000163EC8: CC210062 02005962
	v_fma_mixhi_f16 v98, v99, s44, 0                           // 000000163ED0: CC220062 02005963
	v_fma_mixlo_f16 v99, v100, s44, 0                          // 000000163ED8: CC210063 02005964
	s_waitcnt lgkmcnt(7)                                       // 000000163EE0: BF89FC77
	v_fma_mixlo_f16 v100, v102, s44, 0                         // 000000163EE4: CC210064 02005966
	v_fma_mixhi_f16 v100, v103, s44, 0                         // 000000163EEC: CC220064 02005967
	s_waitcnt lgkmcnt(6)                                       // 000000163EF4: BF89FC67
	v_fma_mixlo_f16 v102, v106, s44, 0                         // 000000163EF8: CC210066 0200596A
	ds_load_b128 v[69:72], v81 offset:17120                    // 000000163F00: DBFC42E0 45000051
	v_fma_mixhi_f16 v102, v107, s44, 0                         // 000000163F08: CC220066 0200596B
	v_fma_mixlo_f16 v103, v108, s44, 0                         // 000000163F10: CC210067 0200596C
	v_fma_mixhi_f16 v103, v109, s44, 0                         // 000000163F18: CC220067 0200596D
	s_waitcnt lgkmcnt(2)                                       // 000000163F20: BF89FC27
	v_fma_mixlo_f16 v106, v41, s44, 0                          // 000000163F24: CC21006A 02005929
	v_fma_mixhi_f16 v106, v42, s44, 0                          // 000000163F2C: CC22006A 0200592A
	v_fma_mixlo_f16 v107, v43, s44, 0                          // 000000163F34: CC21006B 0200592B
	v_fma_mixhi_f16 v107, v44, s44, 0                          // 000000163F3C: CC22006B 0200592C
	s_waitcnt lgkmcnt(1)                                       // 000000163F44: BF89FC17
	v_fma_mixlo_f16 v108, v54, s44, 0                          // 000000163F48: CC21006C 02005936
	v_fma_mixhi_f16 v108, v55, s44, 0                          // 000000163F50: CC22006C 02005937
	ds_load_b128 v[41:44], v81 offset:25568                    // 000000163F58: DBFC63E0 29000051
	v_fma_mixlo_f16 v109, v56, s44, 0                          // 000000163F60: CC21006D 02005938
	v_fma_mixhi_f16 v109, v57, s44, 0                          // 000000163F68: CC22006D 02005939
	ds_load_b128 v[54:57], v81 offset:25584                    // 000000163F70: DBFC63F0 36000051
	v_fma_mixhi_f16 v99, v101, s44, 0                          // 000000163F78: CC220063 02005965
	v_fma_mixlo_f16 v101, v104, s44, 0                         // 000000163F80: CC210065 02005968
	v_fma_mixhi_f16 v101, v105, s44, 0                         // 000000163F88: CC220065 02005969
	v_fma_mixlo_f16 v104, v110, s44, 0                         // 000000163F90: CC210068 0200596E
	v_fma_mixhi_f16 v104, v111, s44, 0                         // 000000163F98: CC220068 0200596F
	v_fma_mixlo_f16 v105, v112, s44, 0                         // 000000163FA0: CC210069 02005970
	v_fma_mixhi_f16 v105, v113, s44, 0                         // 000000163FA8: CC220069 02005971
	s_waitcnt lgkmcnt(2)                                       // 000000163FB0: BF89FC27
	v_fma_mixlo_f16 v110, v69, s44, 0                          // 000000163FB4: CC21006E 02005945
	v_fma_mixhi_f16 v110, v70, s44, 0                          // 000000163FBC: CC22006E 02005946
	v_fma_mixlo_f16 v111, v71, s44, 0                          // 000000163FC4: CC21006F 02005947
	v_fma_mixhi_f16 v111, v72, s44, 0                          // 000000163FCC: CC22006F 02005948
	v_fma_mixlo_f16 v112, v114, s44, 0                         // 000000163FD4: CC210070 02005972
	v_fma_mixhi_f16 v112, v115, s44, 0                         // 000000163FDC: CC220070 02005973
	v_fma_mixlo_f16 v113, v116, s44, 0                         // 000000163FE4: CC210071 02005974
	v_fma_mixhi_f16 v113, v117, s44, 0                         // 000000163FEC: CC220071 02005975
	v_fma_mixlo_f16 v114, v118, s44, 0                         // 000000163FF4: CC210072 02005976
	v_fma_mixhi_f16 v114, v119, s44, 0                         // 000000163FFC: CC220072 02005977
	v_fma_mixlo_f16 v115, v120, s44, 0                         // 000000164004: CC210073 02005978
	v_fma_mixhi_f16 v115, v121, s44, 0                         // 00000016400C: CC220073 02005979
	v_fma_mixlo_f16 v116, v122, s44, 0                         // 000000164014: CC210074 0200597A
	v_fma_mixhi_f16 v116, v123, s44, 0                         // 00000016401C: CC220074 0200597B
	v_fma_mixlo_f16 v117, v124, s44, 0                         // 000000164024: CC210075 0200597C
	v_fma_mixhi_f16 v117, v125, s44, 0                         // 00000016402C: CC220075 0200597D
	s_waitcnt lgkmcnt(1)                                       // 000000164034: BF89FC17
	v_fma_mixlo_f16 v118, v41, s44, 0                          // 000000164038: CC210076 02005929
	v_fma_mixhi_f16 v118, v42, s44, 0                          // 000000164040: CC220076 0200592A
	v_fma_mixlo_f16 v119, v43, s44, 0                          // 000000164048: CC210077 0200592B
	v_fma_mixhi_f16 v119, v44, s44, 0                          // 000000164050: CC220077 0200592C
	s_waitcnt lgkmcnt(0)                                       // 000000164058: BF89FC07
	v_fma_mixlo_f16 v120, v54, s44, 0                          // 00000016405C: CC210078 02005936
	v_fma_mixhi_f16 v120, v55, s44, 0                          // 000000164064: CC220078 02005937
	v_fma_mixlo_f16 v121, v56, s44, 0                          // 00000016406C: CC210079 02005938
	v_fma_mixhi_f16 v121, v57, s44, 0                          // 000000164074: CC220079 02005939
	.long 0x7f583880                                           // 00000016407C: 7F583880
	v_wmma_f32_16x16x16_f16 v[33:40], v[46:53], v[61:68], v[33:40]// 000000164080: CC404021 1C867B2E
	v_wmma_f32_16x16x16_f16 v[25:32], v[46:53], v[98:105], v[25:32]// 000000164088: CC404019 1C66C52E
	v_wmma_f32_16x16x16_f16 v[17:24], v[46:53], v[106:113], v[17:24]// 000000164090: CC404011 1C46D52E
	v_wmma_f32_16x16x16_f16 v[9:16], v[46:53], v[114:121], v[9:16]// 000000164098: CC404009 1C26E52E
	.long 0x7f5439ac                                           // 0000001640A0: 7F5439AC
	.long 0x7e5439ac                                           // 0000001640A4: 7E5439AC
	.long 0x7f5239ac                                           // 0000001640A8: 7F5239AC
	.long 0x7e5239ac                                           // 0000001640AC: 7E5239AC
	s_and_saveexec_b32 s11, s0                                 // 0000001640B0: BE8B2000
	s_cbranch_execz 11                                         // 0000001640B4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3fe4>
	global_load_b128 v[45:48], v[59:60], off offset:256        // 0000001640B8: DC5E0100 2D7C003B
	s_waitcnt vmcnt(0)                                         // 0000001640C0: BF8903F7
	v_fma_mixlo_f16 v41, v45, s44, 0                           // 0000001640C4: CC210029 0200592D
	v_fma_mixhi_f16 v41, v46, s44, 0                           // 0000001640CC: CC220029 0200592E
	v_fma_mixlo_f16 v42, v47, s44, 0                           // 0000001640D4: CC21002A 0200592F
	v_fma_mixhi_f16 v42, v48, s44, 0                           // 0000001640DC: CC22002A 02005930
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001640E4: 8C7E0B7E
	.long 0x7e5839ac                                           // 0000001640E8: 7E5839AC
	.long 0x7f5639ac                                           // 0000001640EC: 7F5639AC
	.long 0x7e5639ac                                           // 0000001640F0: 7E5639AC
	s_and_saveexec_b32 s11, s0                                 // 0000001640F4: BE8B2000
	s_cbranch_execz 11                                         // 0000001640F8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4028>
	global_load_b128 v[43:46], v[59:60], off offset:272        // 0000001640FC: DC5E0110 2B7C003B
	s_waitcnt vmcnt(0)                                         // 000000164104: BF8903F7
	v_fma_mixlo_f16 v43, v43, s44, 0                           // 000000164108: CC21002B 0200592B
	v_fma_mixhi_f16 v43, v44, s44, 0                           // 000000164110: CC22002B 0200592C
	v_fma_mixlo_f16 v44, v45, s44, 0                           // 000000164118: CC21002C 0200592D
	v_fma_mixhi_f16 v44, v46, s44, 0                           // 000000164120: CC22002C 0200592E
	s_or_b32 exec_lo, exec_lo, s11                             // 000000164128: 8C7E0B7E
	.long 0x7f603880                                           // 00000016412C: 7F603880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000164130: BF870001
	.long 0x7f5c39b0                                           // 000000164134: 7F5C39B0
	.long 0x7e5c39b0                                           // 000000164138: 7E5C39B0
	.long 0x7f5a39b0                                           // 00000016413C: 7F5A39B0
	.long 0x7e5a39b0                                           // 000000164140: 7E5A39B0
	s_and_saveexec_b32 s11, s0                                 // 000000164144: BE8B2000
	s_cbranch_execz 11                                         // 000000164148: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4078>
	global_load_b128 v[49:52], v[59:60], off offset:288        // 00000016414C: DC5E0120 317C003B
	s_waitcnt vmcnt(0)                                         // 000000164154: BF8903F7
	v_fma_mixlo_f16 v45, v49, s44, 0                           // 000000164158: CC21002D 02005931
	v_fma_mixhi_f16 v45, v50, s44, 0                           // 000000164160: CC22002D 02005932
	v_fma_mixlo_f16 v46, v51, s44, 0                           // 000000164168: CC21002E 02005933
	v_fma_mixhi_f16 v46, v52, s44, 0                           // 000000164170: CC22002E 02005934
	s_or_b32 exec_lo, exec_lo, s11                             // 000000164178: 8C7E0B7E
	.long 0x7e6039b0                                           // 00000016417C: 7E6039B0
	.long 0x7f5e39b0                                           // 000000164180: 7F5E39B0
	.long 0x7e5e39b0                                           // 000000164184: 7E5E39B0
	s_and_saveexec_b32 s11, s0                                 // 000000164188: BE8B2000
	s_cbranch_execz 11                                         // 00000016418C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x40bc>
	global_load_b128 v[47:50], v[59:60], off offset:304        // 000000164190: DC5E0130 2F7C003B
	s_waitcnt vmcnt(0)                                         // 000000164198: BF8903F7
	v_fma_mixlo_f16 v47, v47, s44, 0                           // 00000016419C: CC21002F 0200592F
	v_fma_mixhi_f16 v47, v48, s44, 0                           // 0000001641A4: CC22002F 02005930
	v_fma_mixlo_f16 v48, v49, s44, 0                           // 0000001641AC: CC210030 02005931
	v_fma_mixhi_f16 v48, v50, s44, 0                           // 0000001641B4: CC220030 02005932
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001641BC: 8C7E0B7E
	ds_load_b128 v[50:53], v81 offset:256                      // 0000001641C0: DBFC0100 32000051
	ds_load_b128 v[54:57], v81 offset:272                      // 0000001641C8: DBFC0110 36000051
	ds_load_b128 v[61:64], v81 offset:288                      // 0000001641D0: DBFC0120 3D000051
	ds_load_b128 v[65:68], v81 offset:304                      // 0000001641D8: DBFC0130 41000051
	ds_load_b128 v[69:72], v81 offset:8704                     // 0000001641E0: DBFC2200 45000051
	ds_load_b128 v[98:101], v81 offset:8720                    // 0000001641E8: DBFC2210 62000051
	ds_load_b128 v[102:105], v81 offset:8736                   // 0000001641F0: DBFC2220 66000051
	ds_load_b128 v[106:109], v81 offset:8752                   // 0000001641F8: DBFC2230 6A000051
	ds_load_b128 v[110:113], v81 offset:17152                  // 000000164200: DBFC4300 6E000051
	ds_load_b128 v[114:117], v81 offset:17184                  // 000000164208: DBFC4320 72000051
	ds_load_b128 v[118:121], v81 offset:17200                  // 000000164210: DBFC4330 76000051
	.long 0x7f623880                                           // 000000164218: 7F623880
	ds_load_b128 v[122:125], v81 offset:25616                  // 00000016421C: DBFC6410 7A000051
	s_waitcnt lgkmcnt(11)                                      // 000000164224: BF89FCB7
	v_fma_mixlo_f16 v50, v50, s44, 0                           // 000000164228: CC210032 02005932
	v_fma_mixhi_f16 v50, v51, s44, 0                           // 000000164230: CC220032 02005933
	v_fma_mixlo_f16 v51, v52, s44, 0                           // 000000164238: CC210033 02005934
	s_waitcnt lgkmcnt(10)                                      // 000000164240: BF89FCA7
	v_fma_mixlo_f16 v52, v54, s44, 0                           // 000000164244: CC210034 02005936
	s_waitcnt lgkmcnt(9)                                       // 00000016424C: BF89FC97
	v_fma_mixlo_f16 v54, v61, s44, 0                           // 000000164250: CC210036 0200593D
	v_fma_mixhi_f16 v54, v62, s44, 0                           // 000000164258: CC220036 0200593E
	s_waitcnt lgkmcnt(7)                                       // 000000164260: BF89FC77
	v_fma_mixlo_f16 v61, v69, s44, 0                           // 000000164264: CC21003D 02005945
	v_fma_mixhi_f16 v61, v70, s44, 0                           // 00000016426C: CC22003D 02005946
	v_fma_mixlo_f16 v62, v71, s44, 0                           // 000000164274: CC21003E 02005947
	v_fma_mixhi_f16 v62, v72, s44, 0                           // 00000016427C: CC22003E 02005948
	ds_load_b128 v[69:72], v81 offset:17168                    // 000000164284: DBFC4310 45000051
	v_fma_mixhi_f16 v51, v53, s44, 0                           // 00000016428C: CC220033 02005935
	v_fma_mixhi_f16 v52, v55, s44, 0                           // 000000164294: CC220034 02005937
	v_fma_mixhi_f16 v53, v57, s44, 0                           // 00000016429C: CC220035 02005939
	v_fma_mixlo_f16 v55, v63, s44, 0                           // 0000001642A4: CC210037 0200593F
	v_fma_mixhi_f16 v55, v64, s44, 0                           // 0000001642AC: CC220037 02005940
	v_fma_mixlo_f16 v57, v67, s44, 0                           // 0000001642B4: CC210039 02005943
	v_fma_mixhi_f16 v57, v68, s44, 0                           // 0000001642BC: CC220039 02005944
	s_waitcnt lgkmcnt(7)                                       // 0000001642C4: BF89FC77
	v_fma_mixlo_f16 v63, v98, s44, 0                           // 0000001642C8: CC21003F 02005962
	v_fma_mixhi_f16 v63, v99, s44, 0                           // 0000001642D0: CC22003F 02005963
	v_fma_mixlo_f16 v64, v100, s44, 0                          // 0000001642D8: CC210040 02005964
	v_fma_mixhi_f16 v64, v101, s44, 0                          // 0000001642E0: CC220040 02005965
	s_waitcnt lgkmcnt(5)                                       // 0000001642E8: BF89FC57
	v_fma_mixlo_f16 v67, v106, s44, 0                          // 0000001642EC: CC210043 0200596A
	v_fma_mixhi_f16 v67, v107, s44, 0                          // 0000001642F4: CC220043 0200596B
	v_fma_mixlo_f16 v68, v108, s44, 0                          // 0000001642FC: CC210044 0200596C
	v_fma_mixhi_f16 v68, v109, s44, 0                          // 000000164304: CC220044 0200596D
	ds_load_b128 v[106:109], v81 offset:25600                  // 00000016430C: DBFC6400 6A000051
	s_waitcnt lgkmcnt(5)                                       // 000000164314: BF89FC57
	v_fma_mixlo_f16 v98, v110, s44, 0                          // 000000164318: CC210062 0200596E
	v_fma_mixhi_f16 v98, v111, s44, 0                          // 000000164320: CC220062 0200596F
	v_fma_mixlo_f16 v99, v112, s44, 0                          // 000000164328: CC210063 02005970
	v_fma_mixhi_f16 v99, v113, s44, 0                          // 000000164330: CC220063 02005971
	s_waitcnt lgkmcnt(1)                                       // 000000164338: BF89FC17
	v_fma_mixlo_f16 v100, v69, s44, 0                          // 00000016433C: CC210064 02005945
	v_fma_mixhi_f16 v100, v70, s44, 0                          // 000000164344: CC220064 02005946
	ds_load_b128 v[110:113], v81 offset:25632                  // 00000016434C: DBFC6420 6E000051
	v_fma_mixlo_f16 v101, v71, s44, 0                          // 000000164354: CC210065 02005947
	v_fma_mixhi_f16 v101, v72, s44, 0                          // 00000016435C: CC220065 02005948
	ds_load_b128 v[69:72], v81 offset:25648                    // 000000164364: DBFC6430 45000051
	v_fma_mixlo_f16 v53, v56, s44, 0                           // 00000016436C: CC210035 02005938
	v_fma_mixlo_f16 v56, v65, s44, 0                           // 000000164374: CC210038 02005941
	v_fma_mixhi_f16 v56, v66, s44, 0                           // 00000016437C: CC220038 02005942
	v_fma_mixlo_f16 v65, v102, s44, 0                          // 000000164384: CC210041 02005966
	v_fma_mixhi_f16 v65, v103, s44, 0                          // 00000016438C: CC220041 02005967
	v_fma_mixlo_f16 v66, v104, s44, 0                          // 000000164394: CC210042 02005968
	v_fma_mixhi_f16 v66, v105, s44, 0                          // 00000016439C: CC220042 02005969
	v_fma_mixlo_f16 v102, v114, s44, 0                         // 0000001643A4: CC210066 02005972
	v_fma_mixhi_f16 v102, v115, s44, 0                         // 0000001643AC: CC220066 02005973
	v_fma_mixlo_f16 v103, v116, s44, 0                         // 0000001643B4: CC210067 02005974
	v_fma_mixhi_f16 v103, v117, s44, 0                         // 0000001643BC: CC220067 02005975
	v_fma_mixlo_f16 v104, v118, s44, 0                         // 0000001643C4: CC210068 02005976
	v_fma_mixhi_f16 v104, v119, s44, 0                         // 0000001643CC: CC220068 02005977
	v_fma_mixlo_f16 v105, v120, s44, 0                         // 0000001643D4: CC210069 02005978
	v_fma_mixhi_f16 v105, v121, s44, 0                         // 0000001643DC: CC220069 02005979
	s_waitcnt lgkmcnt(2)                                       // 0000001643E4: BF89FC27
	v_fma_mixlo_f16 v106, v106, s44, 0                         // 0000001643E8: CC21006A 0200596A
	v_fma_mixhi_f16 v106, v107, s44, 0                         // 0000001643F0: CC22006A 0200596B
	v_fma_mixlo_f16 v107, v108, s44, 0                         // 0000001643F8: CC21006B 0200596C
	v_fma_mixhi_f16 v107, v109, s44, 0                         // 000000164400: CC22006B 0200596D
	v_fma_mixlo_f16 v108, v122, s44, 0                         // 000000164408: CC21006C 0200597A
	v_fma_mixhi_f16 v108, v123, s44, 0                         // 000000164410: CC22006C 0200597B
	v_fma_mixlo_f16 v109, v124, s44, 0                         // 000000164418: CC21006D 0200597C
	v_fma_mixhi_f16 v109, v125, s44, 0                         // 000000164420: CC22006D 0200597D
	s_waitcnt lgkmcnt(1)                                       // 000000164428: BF89FC17
	v_fma_mixlo_f16 v110, v110, s44, 0                         // 00000016442C: CC21006E 0200596E
	v_fma_mixhi_f16 v110, v111, s44, 0                         // 000000164434: CC22006E 0200596F
	v_fma_mixlo_f16 v111, v112, s44, 0                         // 00000016443C: CC21006F 02005970
	v_fma_mixhi_f16 v111, v113, s44, 0                         // 000000164444: CC22006F 02005971
	s_waitcnt lgkmcnt(0)                                       // 00000016444C: BF89FC07
	v_fma_mixlo_f16 v112, v69, s44, 0                          // 000000164450: CC210070 02005945
	v_fma_mixhi_f16 v112, v70, s44, 0                          // 000000164458: CC220070 02005946
	v_fma_mixlo_f16 v113, v71, s44, 0                          // 000000164460: CC210071 02005947
	v_fma_mixhi_f16 v113, v72, s44, 0                          // 000000164468: CC220071 02005948
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[50:57], v[33:40]// 000000164470: CC404021 1C866529
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[61:68], v[25:32]// 000000164478: CC404019 1C667B29
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[98:105], v[17:24]// 000000164480: CC404011 1C46C529
	s_delay_alu instid0(VALU_DEP_4)                            // 000000164488: BF870004
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[106:113], v[9:16]// 00000016448C: CC404009 1C26D529
	.long 0x7f5e39b1                                           // 000000164494: 7F5E39B1
	.long 0x7e5e39b1                                           // 000000164498: 7E5E39B1
	.long 0x7f5c39b1                                           // 00000016449C: 7F5C39B1
	.long 0x7e5c39b1                                           // 0000001644A0: 7E5C39B1
	s_and_saveexec_b32 s11, s0                                 // 0000001644A4: BE8B2000
	s_cbranch_execz 11                                         // 0000001644A8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x43d8>
	global_load_b128 v[41:44], v[59:60], off offset:320        // 0000001644AC: DC5E0140 297C003B
	s_waitcnt vmcnt(0)                                         // 0000001644B4: BF8903F7
	v_fma_mixlo_f16 v46, v41, s44, 0                           // 0000001644B8: CC21002E 02005929
	v_fma_mixhi_f16 v46, v42, s44, 0                           // 0000001644C0: CC22002E 0200592A
	v_fma_mixlo_f16 v47, v43, s44, 0                           // 0000001644C8: CC21002F 0200592B
	v_fma_mixhi_f16 v47, v44, s44, 0                           // 0000001644D0: CC22002F 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001644D8: 8C7E0B7E
	.long 0x7e6239b1                                           // 0000001644DC: 7E6239B1
	.long 0x7f6039b1                                           // 0000001644E0: 7F6039B1
	.long 0x7e6039b1                                           // 0000001644E4: 7E6039B1
	s_and_saveexec_b32 s11, s0                                 // 0000001644E8: BE8B2000
	s_cbranch_execz 11                                         // 0000001644EC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x441c>
	global_load_b128 v[41:44], v[59:60], off offset:336        // 0000001644F0: DC5E0150 297C003B
	s_waitcnt vmcnt(0)                                         // 0000001644F8: BF8903F7
	v_fma_mixlo_f16 v48, v41, s44, 0                           // 0000001644FC: CC210030 02005929
	v_fma_mixhi_f16 v48, v42, s44, 0                           // 000000164504: CC220030 0200592A
	v_fma_mixlo_f16 v49, v43, s44, 0                           // 00000016450C: CC210031 0200592B
	v_fma_mixhi_f16 v49, v44, s44, 0                           // 000000164514: CC220031 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016451C: 8C7E0B7E
	.long 0x7f6a3880                                           // 000000164520: 7F6A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000164524: BF870001
	.long 0x7f6639b5                                           // 000000164528: 7F6639B5
	.long 0x7e6639b5                                           // 00000016452C: 7E6639B5
	.long 0x7f6439b5                                           // 000000164530: 7F6439B5
	.long 0x7e6439b5                                           // 000000164534: 7E6439B5
	s_and_saveexec_b32 s11, s0                                 // 000000164538: BE8B2000
	s_cbranch_execz 11                                         // 00000016453C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x446c>
	global_load_b128 v[41:44], v[59:60], off offset:352        // 000000164540: DC5E0160 297C003B
	s_waitcnt vmcnt(0)                                         // 000000164548: BF8903F7
	v_fma_mixlo_f16 v50, v41, s44, 0                           // 00000016454C: CC210032 02005929
	v_fma_mixhi_f16 v50, v42, s44, 0                           // 000000164554: CC220032 0200592A
	v_fma_mixlo_f16 v51, v43, s44, 0                           // 00000016455C: CC210033 0200592B
	v_fma_mixhi_f16 v51, v44, s44, 0                           // 000000164564: CC220033 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016456C: 8C7E0B7E
	.long 0x7e6a39b5                                           // 000000164570: 7E6A39B5
	.long 0x7f6839b5                                           // 000000164574: 7F6839B5
	.long 0x7e6839b5                                           // 000000164578: 7E6839B5
	s_and_saveexec_b32 s11, s0                                 // 00000016457C: BE8B2000
	s_cbranch_execz 11                                         // 000000164580: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x44b0>
	global_load_b128 v[41:44], v[59:60], off offset:368        // 000000164584: DC5E0170 297C003B
	s_waitcnt vmcnt(0)                                         // 00000016458C: BF8903F7
	v_fma_mixlo_f16 v52, v41, s44, 0                           // 000000164590: CC210034 02005929
	v_fma_mixhi_f16 v52, v42, s44, 0                           // 000000164598: CC220034 0200592A
	v_fma_mixlo_f16 v53, v43, s44, 0                           // 0000001645A0: CC210035 0200592B
	v_fma_mixhi_f16 v53, v44, s44, 0                           // 0000001645A8: CC220035 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001645B0: 8C7E0B7E
	ds_load_b128 v[41:44], v81 offset:320                      // 0000001645B4: DBFC0140 29000051
	ds_load_b128 v[54:57], v81 offset:336                      // 0000001645BC: DBFC0150 36000051
	ds_load_b128 v[65:68], v81 offset:352                      // 0000001645C4: DBFC0160 41000051
	ds_load_b128 v[69:72], v81 offset:368                      // 0000001645CC: DBFC0170 45000051
	ds_load_b128 v[98:101], v81 offset:8768                    // 0000001645D4: DBFC2240 62000051
	ds_load_b128 v[102:105], v81 offset:8784                   // 0000001645DC: DBFC2250 66000051
	ds_load_b128 v[106:109], v81 offset:8800                   // 0000001645E4: DBFC2260 6A000051
	ds_load_b128 v[110:113], v81 offset:8816                   // 0000001645EC: DBFC2270 6E000051
	ds_load_b128 v[118:121], v81 offset:25664                  // 0000001645F4: DBFC6440 76000051
	ds_load_b128 v[122:125], v81 offset:25680                  // 0000001645FC: DBFC6450 7A000051
	ds_load_b128 v[114:117], v81 offset:17264                  // 000000164604: DBFC4370 72000051
	s_waitcnt lgkmcnt(10)                                      // 00000016460C: BF89FCA7
	v_fma_mixlo_f16 v61, v41, s44, 0                           // 000000164610: CC21003D 02005929
	v_fma_mixhi_f16 v61, v42, s44, 0                           // 000000164618: CC22003D 0200592A
	v_fma_mixlo_f16 v62, v43, s44, 0                           // 000000164620: CC21003E 0200592B
	v_fma_mixhi_f16 v62, v44, s44, 0                           // 000000164628: CC22003E 0200592C
	s_waitcnt lgkmcnt(9)                                       // 000000164630: BF89FC97
	v_fma_mixlo_f16 v63, v54, s44, 0                           // 000000164634: CC21003F 02005936
	v_fma_mixhi_f16 v63, v55, s44, 0                           // 00000016463C: CC22003F 02005937
	v_fma_mixlo_f16 v64, v56, s44, 0                           // 000000164644: CC210040 02005938
	v_fma_mixhi_f16 v64, v57, s44, 0                           // 00000016464C: CC220040 02005939
	ds_load_b128 v[41:44], v81 offset:17216                    // 000000164654: DBFC4340 29000051
	ds_load_b128 v[54:57], v81 offset:17232                    // 00000016465C: DBFC4350 36000051
	s_waitcnt lgkmcnt(10)                                      // 000000164664: BF89FCA7
	v_fma_mixlo_f16 v65, v65, s44, 0                           // 000000164668: CC210041 02005941
	v_fma_mixhi_f16 v65, v66, s44, 0                           // 000000164670: CC220041 02005942
	v_fma_mixlo_f16 v66, v67, s44, 0                           // 000000164678: CC210042 02005943
	v_fma_mixhi_f16 v66, v68, s44, 0                           // 000000164680: CC220042 02005944
	s_waitcnt lgkmcnt(9)                                       // 000000164688: BF89FC97
	v_fma_mixlo_f16 v67, v69, s44, 0                           // 00000016468C: CC210043 02005945
	v_fma_mixhi_f16 v67, v70, s44, 0                           // 000000164694: CC220043 02005946
	v_fma_mixlo_f16 v68, v71, s44, 0                           // 00000016469C: CC210044 02005947
	v_fma_mixhi_f16 v68, v72, s44, 0                           // 0000001646A4: CC220044 02005948
	s_waitcnt lgkmcnt(8)                                       // 0000001646AC: BF89FC87
	v_fma_mixlo_f16 v98, v98, s44, 0                           // 0000001646B0: CC210062 02005962
	v_fma_mixhi_f16 v98, v99, s44, 0                           // 0000001646B8: CC220062 02005963
	v_fma_mixlo_f16 v99, v100, s44, 0                          // 0000001646C0: CC210063 02005964
	s_waitcnt lgkmcnt(7)                                       // 0000001646C8: BF89FC77
	v_fma_mixlo_f16 v100, v102, s44, 0                         // 0000001646CC: CC210064 02005966
	v_fma_mixhi_f16 v100, v103, s44, 0                         // 0000001646D4: CC220064 02005967
	s_waitcnt lgkmcnt(6)                                       // 0000001646DC: BF89FC67
	v_fma_mixlo_f16 v102, v106, s44, 0                         // 0000001646E0: CC210066 0200596A
	ds_load_b128 v[69:72], v81 offset:17248                    // 0000001646E8: DBFC4360 45000051
	v_fma_mixhi_f16 v102, v107, s44, 0                         // 0000001646F0: CC220066 0200596B
	v_fma_mixlo_f16 v103, v108, s44, 0                         // 0000001646F8: CC210067 0200596C
	v_fma_mixhi_f16 v103, v109, s44, 0                         // 000000164700: CC220067 0200596D
	s_waitcnt lgkmcnt(2)                                       // 000000164708: BF89FC27
	v_fma_mixlo_f16 v106, v41, s44, 0                          // 00000016470C: CC21006A 02005929
	v_fma_mixhi_f16 v106, v42, s44, 0                          // 000000164714: CC22006A 0200592A
	v_fma_mixlo_f16 v107, v43, s44, 0                          // 00000016471C: CC21006B 0200592B
	v_fma_mixhi_f16 v107, v44, s44, 0                          // 000000164724: CC22006B 0200592C
	s_waitcnt lgkmcnt(1)                                       // 00000016472C: BF89FC17
	v_fma_mixlo_f16 v108, v54, s44, 0                          // 000000164730: CC21006C 02005936
	v_fma_mixhi_f16 v108, v55, s44, 0                          // 000000164738: CC22006C 02005937
	ds_load_b128 v[41:44], v81 offset:25696                    // 000000164740: DBFC6460 29000051
	v_fma_mixlo_f16 v109, v56, s44, 0                          // 000000164748: CC21006D 02005938
	v_fma_mixhi_f16 v109, v57, s44, 0                          // 000000164750: CC22006D 02005939
	ds_load_b128 v[54:57], v81 offset:25712                    // 000000164758: DBFC6470 36000051
	v_fma_mixhi_f16 v99, v101, s44, 0                          // 000000164760: CC220063 02005965
	v_fma_mixlo_f16 v101, v104, s44, 0                         // 000000164768: CC210065 02005968
	v_fma_mixhi_f16 v101, v105, s44, 0                         // 000000164770: CC220065 02005969
	v_fma_mixlo_f16 v104, v110, s44, 0                         // 000000164778: CC210068 0200596E
	v_fma_mixhi_f16 v104, v111, s44, 0                         // 000000164780: CC220068 0200596F
	v_fma_mixlo_f16 v105, v112, s44, 0                         // 000000164788: CC210069 02005970
	v_fma_mixhi_f16 v105, v113, s44, 0                         // 000000164790: CC220069 02005971
	s_waitcnt lgkmcnt(2)                                       // 000000164798: BF89FC27
	v_fma_mixlo_f16 v110, v69, s44, 0                          // 00000016479C: CC21006E 02005945
	v_fma_mixhi_f16 v110, v70, s44, 0                          // 0000001647A4: CC22006E 02005946
	v_fma_mixlo_f16 v111, v71, s44, 0                          // 0000001647AC: CC21006F 02005947
	v_fma_mixhi_f16 v111, v72, s44, 0                          // 0000001647B4: CC22006F 02005948
	v_fma_mixlo_f16 v112, v114, s44, 0                         // 0000001647BC: CC210070 02005972
	v_fma_mixhi_f16 v112, v115, s44, 0                         // 0000001647C4: CC220070 02005973
	v_fma_mixlo_f16 v113, v116, s44, 0                         // 0000001647CC: CC210071 02005974
	v_fma_mixhi_f16 v113, v117, s44, 0                         // 0000001647D4: CC220071 02005975
	v_fma_mixlo_f16 v114, v118, s44, 0                         // 0000001647DC: CC210072 02005976
	v_fma_mixhi_f16 v114, v119, s44, 0                         // 0000001647E4: CC220072 02005977
	v_fma_mixlo_f16 v115, v120, s44, 0                         // 0000001647EC: CC210073 02005978
	v_fma_mixhi_f16 v115, v121, s44, 0                         // 0000001647F4: CC220073 02005979
	v_fma_mixlo_f16 v116, v122, s44, 0                         // 0000001647FC: CC210074 0200597A
	v_fma_mixhi_f16 v116, v123, s44, 0                         // 000000164804: CC220074 0200597B
	v_fma_mixlo_f16 v117, v124, s44, 0                         // 00000016480C: CC210075 0200597C
	v_fma_mixhi_f16 v117, v125, s44, 0                         // 000000164814: CC220075 0200597D
	s_waitcnt lgkmcnt(1)                                       // 00000016481C: BF89FC17
	v_fma_mixlo_f16 v118, v41, s44, 0                          // 000000164820: CC210076 02005929
	v_fma_mixhi_f16 v118, v42, s44, 0                          // 000000164828: CC220076 0200592A
	v_fma_mixlo_f16 v119, v43, s44, 0                          // 000000164830: CC210077 0200592B
	v_fma_mixhi_f16 v119, v44, s44, 0                          // 000000164838: CC220077 0200592C
	s_waitcnt lgkmcnt(0)                                       // 000000164840: BF89FC07
	v_fma_mixlo_f16 v120, v54, s44, 0                          // 000000164844: CC210078 02005936
	v_fma_mixhi_f16 v120, v55, s44, 0                          // 00000016484C: CC220078 02005937
	v_fma_mixlo_f16 v121, v56, s44, 0                          // 000000164854: CC210079 02005938
	v_fma_mixhi_f16 v121, v57, s44, 0                          // 00000016485C: CC220079 02005939
	.long 0x7f6c3880                                           // 000000164864: 7F6C3880
	v_wmma_f32_16x16x16_f16 v[33:40], v[46:53], v[61:68], v[33:40]// 000000164868: CC404021 1C867B2E
	v_wmma_f32_16x16x16_f16 v[25:32], v[46:53], v[98:105], v[25:32]// 000000164870: CC404019 1C66C52E
	v_wmma_f32_16x16x16_f16 v[17:24], v[46:53], v[106:113], v[17:24]// 000000164878: CC404011 1C46D52E
	v_wmma_f32_16x16x16_f16 v[9:16], v[46:53], v[114:121], v[9:16]// 000000164880: CC404009 1C26E52E
	.long 0x7f6839b6                                           // 000000164888: 7F6839B6
	.long 0x7e6839b6                                           // 00000016488C: 7E6839B6
	.long 0x7f6639b6                                           // 000000164890: 7F6639B6
	.long 0x7e6639b6                                           // 000000164894: 7E6639B6
	s_and_saveexec_b32 s11, s0                                 // 000000164898: BE8B2000
	s_cbranch_execz 11                                         // 00000016489C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x47cc>
	global_load_b128 v[41:44], v[59:60], off offset:384        // 0000001648A0: DC5E0180 297C003B
	s_waitcnt vmcnt(0)                                         // 0000001648A8: BF8903F7
	v_fma_mixlo_f16 v51, v41, s44, 0                           // 0000001648AC: CC210033 02005929
	v_fma_mixhi_f16 v51, v42, s44, 0                           // 0000001648B4: CC220033 0200592A
	v_fma_mixlo_f16 v52, v43, s44, 0                           // 0000001648BC: CC210034 0200592B
	v_fma_mixhi_f16 v52, v44, s44, 0                           // 0000001648C4: CC220034 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001648CC: 8C7E0B7E
	.long 0x7e6c39b6                                           // 0000001648D0: 7E6C39B6
	.long 0x7f6a39b6                                           // 0000001648D4: 7F6A39B6
	.long 0x7e6a39b6                                           // 0000001648D8: 7E6A39B6
	s_and_saveexec_b32 s11, s0                                 // 0000001648DC: BE8B2000
	s_cbranch_execz 11                                         // 0000001648E0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4810>
	global_load_b128 v[41:44], v[59:60], off offset:400        // 0000001648E4: DC5E0190 297C003B
	s_waitcnt vmcnt(0)                                         // 0000001648EC: BF8903F7
	v_fma_mixlo_f16 v53, v41, s44, 0                           // 0000001648F0: CC210035 02005929
	v_fma_mixhi_f16 v53, v42, s44, 0                           // 0000001648F8: CC220035 0200592A
	v_fma_mixlo_f16 v54, v43, s44, 0                           // 000000164900: CC210036 0200592B
	v_fma_mixhi_f16 v54, v44, s44, 0                           // 000000164908: CC220036 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 000000164910: 8C7E0B7E
	.long 0x7f743880                                           // 000000164914: 7F743880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000164918: BF870001
	.long 0x7f7039ba                                           // 00000016491C: 7F7039BA
	.long 0x7e7039ba                                           // 000000164920: 7E7039BA
	.long 0x7f6e39ba                                           // 000000164924: 7F6E39BA
	.long 0x7e6e39ba                                           // 000000164928: 7E6E39BA
	s_and_saveexec_b32 s11, s0                                 // 00000016492C: BE8B2000
	s_cbranch_execz 11                                         // 000000164930: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4860>
	global_load_b128 v[41:44], v[59:60], off offset:416        // 000000164934: DC5E01A0 297C003B
	s_waitcnt vmcnt(0)                                         // 00000016493C: BF8903F7
	v_fma_mixlo_f16 v55, v41, s44, 0                           // 000000164940: CC210037 02005929
	v_fma_mixhi_f16 v55, v42, s44, 0                           // 000000164948: CC220037 0200592A
	v_fma_mixlo_f16 v56, v43, s44, 0                           // 000000164950: CC210038 0200592B
	v_fma_mixhi_f16 v56, v44, s44, 0                           // 000000164958: CC220038 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 000000164960: 8C7E0B7E
	.long 0x7e7439ba                                           // 000000164964: 7E7439BA
	.long 0x7f7239ba                                           // 000000164968: 7F7239BA
	.long 0x7e7239ba                                           // 00000016496C: 7E7239BA
	s_and_saveexec_b32 s11, s0                                 // 000000164970: BE8B2000
	s_cbranch_execz 11                                         // 000000164974: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x48a4>
	global_load_b128 v[41:44], v[59:60], off offset:432        // 000000164978: DC5E01B0 297C003B
	s_waitcnt vmcnt(0)                                         // 000000164980: BF8903F7
	v_fma_mixlo_f16 v57, v41, s44, 0                           // 000000164984: CC210039 02005929
	v_fma_mixhi_f16 v57, v42, s44, 0                           // 00000016498C: CC220039 0200592A
	v_fma_mixlo_f16 v58, v43, s44, 0                           // 000000164994: CC21003A 0200592B
	v_fma_mixhi_f16 v58, v44, s44, 0                           // 00000016499C: CC22003A 0200592C
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001649A4: 8C7E0B7E
	ds_load_b128 v[41:44], v81 offset:384                      // 0000001649A8: DBFC0180 29000051
	ds_load_b128 v[45:48], v81 offset:400                      // 0000001649B0: DBFC0190 2D000051
	ds_load_b128 v[65:68], v81 offset:416                      // 0000001649B8: DBFC01A0 41000051
	ds_load_b128 v[69:72], v81 offset:432                      // 0000001649C0: DBFC01B0 45000051
	ds_load_b128 v[98:101], v81 offset:8832                    // 0000001649C8: DBFC2280 62000051
	ds_load_b128 v[102:105], v81 offset:8848                   // 0000001649D0: DBFC2290 66000051
	ds_load_b128 v[106:109], v81 offset:8864                   // 0000001649D8: DBFC22A0 6A000051
	ds_load_b128 v[110:113], v81 offset:8880                   // 0000001649E0: DBFC22B0 6E000051
	ds_load_b128 v[118:121], v81 offset:25728                  // 0000001649E8: DBFC6480 76000051
	ds_load_b128 v[122:125], v81 offset:25744                  // 0000001649F0: DBFC6490 7A000051
	ds_load_b128 v[114:117], v81 offset:17328                  // 0000001649F8: DBFC43B0 72000051
	s_waitcnt lgkmcnt(10)                                      // 000000164A00: BF89FCA7
	v_fma_mixlo_f16 v61, v41, s44, 0                           // 000000164A04: CC21003D 02005929
	v_fma_mixhi_f16 v61, v42, s44, 0                           // 000000164A0C: CC22003D 0200592A
	v_fma_mixlo_f16 v62, v43, s44, 0                           // 000000164A14: CC21003E 0200592B
	v_fma_mixhi_f16 v62, v44, s44, 0                           // 000000164A1C: CC22003E 0200592C
	s_waitcnt lgkmcnt(9)                                       // 000000164A24: BF89FC97
	v_fma_mixlo_f16 v63, v45, s44, 0                           // 000000164A28: CC21003F 0200592D
	v_fma_mixhi_f16 v63, v46, s44, 0                           // 000000164A30: CC22003F 0200592E
	v_fma_mixlo_f16 v64, v47, s44, 0                           // 000000164A38: CC210040 0200592F
	v_fma_mixhi_f16 v64, v48, s44, 0                           // 000000164A40: CC220040 02005930
	ds_load_b128 v[41:44], v81 offset:17280                    // 000000164A48: DBFC4380 29000051
	ds_load_b128 v[45:48], v81 offset:17296                    // 000000164A50: DBFC4390 2D000051
	s_waitcnt lgkmcnt(10)                                      // 000000164A58: BF89FCA7
	v_fma_mixlo_f16 v65, v65, s44, 0                           // 000000164A5C: CC210041 02005941
	v_fma_mixhi_f16 v65, v66, s44, 0                           // 000000164A64: CC220041 02005942
	v_fma_mixlo_f16 v66, v67, s44, 0                           // 000000164A6C: CC210042 02005943
	v_fma_mixhi_f16 v66, v68, s44, 0                           // 000000164A74: CC220042 02005944
	s_waitcnt lgkmcnt(9)                                       // 000000164A7C: BF89FC97
	v_fma_mixlo_f16 v67, v69, s44, 0                           // 000000164A80: CC210043 02005945
	v_fma_mixhi_f16 v67, v70, s44, 0                           // 000000164A88: CC220043 02005946
	v_fma_mixlo_f16 v68, v71, s44, 0                           // 000000164A90: CC210044 02005947
	v_fma_mixhi_f16 v68, v72, s44, 0                           // 000000164A98: CC220044 02005948
	s_waitcnt lgkmcnt(8)                                       // 000000164AA0: BF89FC87
	v_fma_mixlo_f16 v98, v98, s44, 0                           // 000000164AA4: CC210062 02005962
	v_fma_mixhi_f16 v98, v99, s44, 0                           // 000000164AAC: CC220062 02005963
	v_fma_mixlo_f16 v99, v100, s44, 0                          // 000000164AB4: CC210063 02005964
	s_waitcnt lgkmcnt(7)                                       // 000000164ABC: BF89FC77
	v_fma_mixlo_f16 v100, v102, s44, 0                         // 000000164AC0: CC210064 02005966
	v_fma_mixhi_f16 v100, v103, s44, 0                         // 000000164AC8: CC220064 02005967
	s_waitcnt lgkmcnt(6)                                       // 000000164AD0: BF89FC67
	v_fma_mixlo_f16 v102, v106, s44, 0                         // 000000164AD4: CC210066 0200596A
	ds_load_b128 v[69:72], v81 offset:17312                    // 000000164ADC: DBFC43A0 45000051
	v_fma_mixhi_f16 v102, v107, s44, 0                         // 000000164AE4: CC220066 0200596B
	v_fma_mixlo_f16 v103, v108, s44, 0                         // 000000164AEC: CC210067 0200596C
	v_fma_mixhi_f16 v103, v109, s44, 0                         // 000000164AF4: CC220067 0200596D
	s_waitcnt lgkmcnt(2)                                       // 000000164AFC: BF89FC27
	v_fma_mixlo_f16 v106, v41, s44, 0                          // 000000164B00: CC21006A 02005929
	v_fma_mixhi_f16 v106, v42, s44, 0                          // 000000164B08: CC22006A 0200592A
	v_fma_mixlo_f16 v107, v43, s44, 0                          // 000000164B10: CC21006B 0200592B
	v_fma_mixhi_f16 v107, v44, s44, 0                          // 000000164B18: CC22006B 0200592C
	s_waitcnt lgkmcnt(1)                                       // 000000164B20: BF89FC17
	v_fma_mixlo_f16 v108, v45, s44, 0                          // 000000164B24: CC21006C 0200592D
	v_fma_mixhi_f16 v108, v46, s44, 0                          // 000000164B2C: CC22006C 0200592E
	ds_load_b128 v[41:44], v81 offset:25760                    // 000000164B34: DBFC64A0 29000051
	v_fma_mixlo_f16 v109, v47, s44, 0                          // 000000164B3C: CC21006D 0200592F
	v_fma_mixhi_f16 v109, v48, s44, 0                          // 000000164B44: CC22006D 02005930
	ds_load_b128 v[45:48], v81 offset:25776                    // 000000164B4C: DBFC64B0 2D000051
	v_fma_mixhi_f16 v99, v101, s44, 0                          // 000000164B54: CC220063 02005965
	v_fma_mixlo_f16 v101, v104, s44, 0                         // 000000164B5C: CC210065 02005968
	v_fma_mixhi_f16 v101, v105, s44, 0                         // 000000164B64: CC220065 02005969
	v_fma_mixlo_f16 v104, v110, s44, 0                         // 000000164B6C: CC210068 0200596E
	v_fma_mixhi_f16 v104, v111, s44, 0                         // 000000164B74: CC220068 0200596F
	v_fma_mixlo_f16 v105, v112, s44, 0                         // 000000164B7C: CC210069 02005970
	v_fma_mixhi_f16 v105, v113, s44, 0                         // 000000164B84: CC220069 02005971
	s_waitcnt lgkmcnt(2)                                       // 000000164B8C: BF89FC27
	v_fma_mixlo_f16 v110, v69, s44, 0                          // 000000164B90: CC21006E 02005945
	v_fma_mixhi_f16 v110, v70, s44, 0                          // 000000164B98: CC22006E 02005946
	v_fma_mixlo_f16 v111, v71, s44, 0                          // 000000164BA0: CC21006F 02005947
	v_fma_mixhi_f16 v111, v72, s44, 0                          // 000000164BA8: CC22006F 02005948
	v_fma_mixlo_f16 v112, v114, s44, 0                         // 000000164BB0: CC210070 02005972
	v_fma_mixhi_f16 v112, v115, s44, 0                         // 000000164BB8: CC220070 02005973
	v_fma_mixlo_f16 v113, v116, s44, 0                         // 000000164BC0: CC210071 02005974
	v_fma_mixhi_f16 v113, v117, s44, 0                         // 000000164BC8: CC220071 02005975
	v_fma_mixlo_f16 v114, v118, s44, 0                         // 000000164BD0: CC210072 02005976
	v_fma_mixhi_f16 v114, v119, s44, 0                         // 000000164BD8: CC220072 02005977
	v_fma_mixlo_f16 v115, v120, s44, 0                         // 000000164BE0: CC210073 02005978
	v_fma_mixhi_f16 v115, v121, s44, 0                         // 000000164BE8: CC220073 02005979
	v_fma_mixlo_f16 v116, v122, s44, 0                         // 000000164BF0: CC210074 0200597A
	v_fma_mixhi_f16 v116, v123, s44, 0                         // 000000164BF8: CC220074 0200597B
	v_fma_mixlo_f16 v117, v124, s44, 0                         // 000000164C00: CC210075 0200597C
	v_fma_mixhi_f16 v117, v125, s44, 0                         // 000000164C08: CC220075 0200597D
	s_waitcnt lgkmcnt(1)                                       // 000000164C10: BF89FC17
	v_fma_mixlo_f16 v118, v41, s44, 0                          // 000000164C14: CC210076 02005929
	v_fma_mixhi_f16 v118, v42, s44, 0                          // 000000164C1C: CC220076 0200592A
	v_fma_mixlo_f16 v119, v43, s44, 0                          // 000000164C24: CC210077 0200592B
	v_fma_mixhi_f16 v119, v44, s44, 0                          // 000000164C2C: CC220077 0200592C
	s_waitcnt lgkmcnt(0)                                       // 000000164C34: BF89FC07
	v_fma_mixlo_f16 v120, v45, s44, 0                          // 000000164C38: CC210078 0200592D
	v_fma_mixhi_f16 v120, v46, s44, 0                          // 000000164C40: CC220078 0200592E
	v_fma_mixlo_f16 v121, v47, s44, 0                          // 000000164C48: CC210079 0200592F
	v_fma_mixhi_f16 v121, v48, s44, 0                          // 000000164C50: CC220079 02005930
	.long 0x7f583880                                           // 000000164C58: 7F583880
	v_wmma_f32_16x16x16_f16 v[33:40], v[51:58], v[61:68], v[33:40]// 000000164C5C: CC404021 1C867B33
	v_wmma_f32_16x16x16_f16 v[25:32], v[51:58], v[98:105], v[25:32]// 000000164C64: CC404019 1C66C533
	v_wmma_f32_16x16x16_f16 v[17:24], v[51:58], v[106:113], v[17:24]// 000000164C6C: CC404011 1C46D533
	v_wmma_f32_16x16x16_f16 v[9:16], v[51:58], v[114:121], v[9:16]// 000000164C74: CC404009 1C26E533
	.long 0x7f5439ac                                           // 000000164C7C: 7F5439AC
	.long 0x7e5439ac                                           // 000000164C80: 7E5439AC
	.long 0x7f5239ac                                           // 000000164C84: 7F5239AC
	.long 0x7e5239ac                                           // 000000164C88: 7E5239AC
	s_and_saveexec_b32 s11, s0                                 // 000000164C8C: BE8B2000
	s_cbranch_execz 11                                         // 000000164C90: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4bc0>
	global_load_b128 v[45:48], v[59:60], off offset:448        // 000000164C94: DC5E01C0 2D7C003B
	s_waitcnt vmcnt(0)                                         // 000000164C9C: BF8903F7
	v_fma_mixlo_f16 v41, v45, s44, 0                           // 000000164CA0: CC210029 0200592D
	v_fma_mixhi_f16 v41, v46, s44, 0                           // 000000164CA8: CC220029 0200592E
	v_fma_mixlo_f16 v42, v47, s44, 0                           // 000000164CB0: CC21002A 0200592F
	v_fma_mixhi_f16 v42, v48, s44, 0                           // 000000164CB8: CC22002A 02005930
	s_or_b32 exec_lo, exec_lo, s11                             // 000000164CC0: 8C7E0B7E
	.long 0x7e5839ac                                           // 000000164CC4: 7E5839AC
	.long 0x7f5639ac                                           // 000000164CC8: 7F5639AC
	.long 0x7e5639ac                                           // 000000164CCC: 7E5639AC
	s_and_saveexec_b32 s11, s0                                 // 000000164CD0: BE8B2000
	s_cbranch_execz 11                                         // 000000164CD4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4c04>
	global_load_b128 v[43:46], v[59:60], off offset:464        // 000000164CD8: DC5E01D0 2B7C003B
	s_waitcnt vmcnt(0)                                         // 000000164CE0: BF8903F7
	v_fma_mixlo_f16 v43, v43, s44, 0                           // 000000164CE4: CC21002B 0200592B
	v_fma_mixhi_f16 v43, v44, s44, 0                           // 000000164CEC: CC22002B 0200592C
	v_fma_mixlo_f16 v44, v45, s44, 0                           // 000000164CF4: CC21002C 0200592D
	v_fma_mixhi_f16 v44, v46, s44, 0                           // 000000164CFC: CC22002C 0200592E
	s_or_b32 exec_lo, exec_lo, s11                             // 000000164D04: 8C7E0B7E
	.long 0x7f603880                                           // 000000164D08: 7F603880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000164D0C: BF870001
	.long 0x7f5c39b0                                           // 000000164D10: 7F5C39B0
	.long 0x7e5c39b0                                           // 000000164D14: 7E5C39B0
	.long 0x7f5a39b0                                           // 000000164D18: 7F5A39B0
	.long 0x7e5a39b0                                           // 000000164D1C: 7E5A39B0
	s_and_saveexec_b32 s11, s0                                 // 000000164D20: BE8B2000
	s_cbranch_execz 11                                         // 000000164D24: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4c54>
	global_load_b128 v[49:52], v[59:60], off offset:480        // 000000164D28: DC5E01E0 317C003B
	s_waitcnt vmcnt(0)                                         // 000000164D30: BF8903F7
	v_fma_mixlo_f16 v45, v49, s44, 0                           // 000000164D34: CC21002D 02005931
	v_fma_mixhi_f16 v45, v50, s44, 0                           // 000000164D3C: CC22002D 02005932
	v_fma_mixlo_f16 v46, v51, s44, 0                           // 000000164D44: CC21002E 02005933
	v_fma_mixhi_f16 v46, v52, s44, 0                           // 000000164D4C: CC22002E 02005934
	s_or_b32 exec_lo, exec_lo, s11                             // 000000164D54: 8C7E0B7E
	.long 0x7e6039b0                                           // 000000164D58: 7E6039B0
	.long 0x7f5e39b0                                           // 000000164D5C: 7F5E39B0
	.long 0x7e5e39b0                                           // 000000164D60: 7E5E39B0
	s_and_saveexec_b32 s11, s0                                 // 000000164D64: BE8B2000
	s_cbranch_execz 11                                         // 000000164D68: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4c98>
	global_load_b128 v[47:50], v[59:60], off offset:496        // 000000164D6C: DC5E01F0 2F7C003B
	s_waitcnt vmcnt(0)                                         // 000000164D74: BF8903F7
	v_fma_mixlo_f16 v47, v47, s44, 0                           // 000000164D78: CC21002F 0200592F
	v_fma_mixhi_f16 v47, v48, s44, 0                           // 000000164D80: CC22002F 02005930
	v_fma_mixlo_f16 v48, v49, s44, 0                           // 000000164D88: CC210030 02005931
	v_fma_mixhi_f16 v48, v50, s44, 0                           // 000000164D90: CC220030 02005932
	s_or_b32 exec_lo, exec_lo, s11                             // 000000164D98: 8C7E0B7E
	ds_load_b128 v[49:52], v81 offset:448                      // 000000164D9C: DBFC01C0 31000051
	ds_load_b128 v[53:56], v81 offset:464                      // 000000164DA4: DBFC01D0 35000051
	ds_load_b128 v[57:60], v81 offset:480                      // 000000164DAC: DBFC01E0 39000051
	ds_load_b128 v[61:64], v81 offset:496                      // 000000164DB4: DBFC01F0 3D000051
	ds_load_b128 v[65:68], v81 offset:8896                     // 000000164DBC: DBFC22C0 41000051
	ds_load_b128 v[69:72], v81 offset:8912                     // 000000164DC4: DBFC22D0 45000051
	ds_load_b128 v[98:101], v81 offset:8928                    // 000000164DCC: DBFC22E0 62000051
	ds_load_b128 v[102:105], v81 offset:8944                   // 000000164DD4: DBFC22F0 66000051
	ds_load_b128 v[106:109], v81 offset:17344                  // 000000164DDC: DBFC43C0 6A000051
	ds_load_b128 v[110:113], v81 offset:17360                  // 000000164DE4: DBFC43D0 6E000051
	ds_load_b128 v[114:117], v81 offset:25808                  // 000000164DEC: DBFC64D0 72000051
	s_mul_i32 s11, s45, 48                                     // 000000164DF4: 960BB02D
	s_mul_hi_u32 s0, s45, 48                                   // 000000164DF8: 9680B02D
	s_add_u32 s18, s11, s2                                     // 000000164DFC: 8012020B
	s_addc_u32 s19, s0, s3                                     // 000000164E00: 82130300
	s_mov_b32 s11, 0                                           // 000000164E04: BE8B0080
	s_lshl_b64 s[18:19], s[18:19], 14                          // 000000164E08: 84928E12
	s_waitcnt lgkmcnt(10)                                      // 000000164E0C: BF89FCA7
	v_fma_mixlo_f16 v49, v49, s44, 0                           // 000000164E10: CC210031 02005931
	v_fma_mixhi_f16 v49, v50, s44, 0                           // 000000164E18: CC220031 02005932
	v_fma_mixlo_f16 v50, v51, s44, 0                           // 000000164E20: CC210032 02005933
	v_fma_mixhi_f16 v50, v52, s44, 0                           // 000000164E28: CC220032 02005934
	s_waitcnt lgkmcnt(9)                                       // 000000164E30: BF89FC97
	v_fma_mixhi_f16 v51, v54, s44, 0                           // 000000164E34: CC220033 02005936
	v_fma_mixlo_f16 v52, v55, s44, 0                           // 000000164E3C: CC210034 02005937
	s_waitcnt lgkmcnt(8)                                       // 000000164E44: BF89FC87
	v_fma_mixlo_f16 v54, v59, s44, 0                           // 000000164E48: CC210036 0200593B
	v_fma_mixhi_f16 v54, v60, s44, 0                           // 000000164E50: CC220036 0200593C
	s_waitcnt lgkmcnt(7)                                       // 000000164E58: BF89FC77
	v_fma_mixlo_f16 v55, v61, s44, 0                           // 000000164E5C: CC210037 0200593D
	v_fma_mixhi_f16 v55, v62, s44, 0                           // 000000164E64: CC220037 0200593E
	s_waitcnt lgkmcnt(5)                                       // 000000164E6C: BF89FC57
	v_fma_mixlo_f16 v59, v69, s44, 0                           // 000000164E70: CC21003B 02005945
	v_fma_mixhi_f16 v59, v70, s44, 0                           // 000000164E78: CC22003B 02005946
	v_fma_mixlo_f16 v60, v71, s44, 0                           // 000000164E80: CC21003C 02005947
	v_fma_mixhi_f16 v60, v72, s44, 0                           // 000000164E88: CC22003C 02005948
	s_waitcnt lgkmcnt(4)                                       // 000000164E90: BF89FC47
	v_fma_mixlo_f16 v61, v98, s44, 0                           // 000000164E94: CC21003D 02005962
	ds_load_b128 v[69:72], v81 offset:17376                    // 000000164E9C: DBFC43E0 45000051
	v_fma_mixhi_f16 v61, v99, s44, 0                           // 000000164EA4: CC22003D 02005963
	v_fma_mixlo_f16 v62, v100, s44, 0                          // 000000164EAC: CC21003E 02005964
	v_fma_mixhi_f16 v62, v101, s44, 0                          // 000000164EB4: CC22003E 02005965
	ds_load_b128 v[98:101], v81 offset:17392                   // 000000164EBC: DBFC43F0 62000051
	v_fma_mixlo_f16 v51, v53, s44, 0                           // 000000164EC4: CC210033 02005935
	v_fma_mixhi_f16 v52, v56, s44, 0                           // 000000164ECC: CC220034 02005938
	v_fma_mixlo_f16 v53, v57, s44, 0                           // 000000164ED4: CC210035 02005939
	v_fma_mixhi_f16 v53, v58, s44, 0                           // 000000164EDC: CC220035 0200593A
	v_fma_mixlo_f16 v56, v63, s44, 0                           // 000000164EE4: CC210038 0200593F
	v_fma_mixhi_f16 v56, v64, s44, 0                           // 000000164EEC: CC220038 02005940
	v_fma_mixlo_f16 v57, v65, s44, 0                           // 000000164EF4: CC210039 02005941
	v_fma_mixhi_f16 v57, v66, s44, 0                           // 000000164EFC: CC220039 02005942
	v_fma_mixlo_f16 v58, v67, s44, 0                           // 000000164F04: CC21003A 02005943
	v_fma_mixhi_f16 v58, v68, s44, 0                           // 000000164F0C: CC22003A 02005944
	s_waitcnt lgkmcnt(5)                                       // 000000164F14: BF89FC57
	v_fma_mixlo_f16 v63, v102, s44, 0                          // 000000164F18: CC21003F 02005966
	v_fma_mixhi_f16 v63, v103, s44, 0                          // 000000164F20: CC22003F 02005967
	v_fma_mixlo_f16 v64, v104, s44, 0                          // 000000164F28: CC210040 02005968
	v_fma_mixhi_f16 v64, v105, s44, 0                          // 000000164F30: CC220040 02005969
	ds_load_b128 v[102:105], v81 offset:25792                  // 000000164F38: DBFC64C0 66000051
	s_waitcnt lgkmcnt(5)                                       // 000000164F40: BF89FC57
	v_fma_mixlo_f16 v65, v106, s44, 0                          // 000000164F44: CC210041 0200596A
	v_fma_mixhi_f16 v65, v107, s44, 0                          // 000000164F4C: CC220041 0200596B
	v_fma_mixlo_f16 v66, v108, s44, 0                          // 000000164F54: CC210042 0200596C
	v_fma_mixhi_f16 v66, v109, s44, 0                          // 000000164F5C: CC220042 0200596D
	s_waitcnt lgkmcnt(4)                                       // 000000164F64: BF89FC47
	v_fma_mixlo_f16 v67, v110, s44, 0                          // 000000164F68: CC210043 0200596E
	v_fma_mixhi_f16 v67, v111, s44, 0                          // 000000164F70: CC220043 0200596F
	ds_load_b128 v[106:109], v81 offset:25824                  // 000000164F78: DBFC64E0 6A000051
	v_fma_mixlo_f16 v68, v112, s44, 0                          // 000000164F80: CC210044 02005970
	v_fma_mixhi_f16 v68, v113, s44, 0                          // 000000164F88: CC220044 02005971
	ds_load_b128 v[110:113], v81 offset:25840                  // 000000164F90: DBFC64F0 6E000051
	s_waitcnt lgkmcnt(4)                                       // 000000164F98: BF89FC47
	v_fma_mixlo_f16 v69, v69, s44, 0                           // 000000164F9C: CC210045 02005945
	v_fma_mixhi_f16 v69, v70, s44, 0                           // 000000164FA4: CC220045 02005946
	v_fma_mixlo_f16 v70, v71, s44, 0                           // 000000164FAC: CC210046 02005947
	v_fma_mixhi_f16 v70, v72, s44, 0                           // 000000164FB4: CC220046 02005948
	s_waitcnt lgkmcnt(3)                                       // 000000164FBC: BF89FC37
	v_fma_mixlo_f16 v71, v98, s44, 0                           // 000000164FC0: CC210047 02005962
	v_fma_mixhi_f16 v71, v99, s44, 0                           // 000000164FC8: CC220047 02005963
	v_fma_mixlo_f16 v72, v100, s44, 0                          // 000000164FD0: CC210048 02005964
	v_fma_mixhi_f16 v72, v101, s44, 0                          // 000000164FD8: CC220048 02005965
	v_fma_mixlo_f16 v100, v114, s44, 0                         // 000000164FE0: CC210064 02005972
	s_waitcnt lgkmcnt(2)                                       // 000000164FE8: BF89FC27
	v_fma_mixlo_f16 v98, v102, s44, 0                          // 000000164FEC: CC210062 02005966
	v_fma_mixhi_f16 v98, v103, s44, 0                          // 000000164FF4: CC220062 02005967
	v_fma_mixlo_f16 v99, v104, s44, 0                          // 000000164FFC: CC210063 02005968
	v_fma_mixhi_f16 v99, v105, s44, 0                          // 000000165004: CC220063 02005969
	v_fma_mixhi_f16 v100, v115, s44, 0                         // 00000016500C: CC220064 02005973
	v_fma_mixlo_f16 v101, v116, s44, 0                         // 000000165014: CC210065 02005974
	v_fma_mixhi_f16 v101, v117, s44, 0                         // 00000016501C: CC220065 02005975
	s_waitcnt lgkmcnt(1)                                       // 000000165024: BF89FC17
	v_fma_mixlo_f16 v102, v106, s44, 0                         // 000000165028: CC210066 0200596A
	v_fma_mixhi_f16 v102, v107, s44, 0                         // 000000165030: CC220066 0200596B
	v_fma_mixlo_f16 v103, v108, s44, 0                         // 000000165038: CC210067 0200596C
	v_fma_mixhi_f16 v103, v109, s44, 0                         // 000000165040: CC220067 0200596D
	s_waitcnt lgkmcnt(0)                                       // 000000165048: BF89FC07
	v_fma_mixlo_f16 v104, v110, s44, 0                         // 00000016504C: CC210068 0200596E
	v_fma_mixhi_f16 v104, v111, s44, 0                         // 000000165054: CC220068 0200596F
	v_fma_mixlo_f16 v105, v112, s44, 0                         // 00000016505C: CC210069 02005970
	v_fma_mixhi_f16 v105, v113, s44, 0                         // 000000165064: CC220069 02005971
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[65:72], v[17:24]// 00000016506C: CC404011 1C468329
	v_mov_b32_e32 v65, 0                                       // 000000165074: 7E820280
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[49:56], v[33:40]// 000000165078: CC404021 1C866329
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[57:64], v[25:32]// 000000165080: CC404019 1C667329
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[98:105], v[9:16]// 000000165088: CC404009 1C26C529
	.long 0xd7000062                                           // 000000165090: D7000062
	v_cndmask_b32_e32 v0, v83, v18, vcc_lo                     // 000000165094: 02002553
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165098: BF870001
	v_add_co_ci_u32_e64 v99, null, s19, v84, s0                // 00000016509C: D5207C63 0002A813
	v_mov_b32_e32 v66, v65                                     // 0000001650A4: 7E840341
	v_mov_b32_e32 v67, v65                                     // 0000001650A8: 7E860341
	v_mov_b32_e32 v68, v65                                     // 0000001650AC: 7E880341
	v_mov_b32_e32 v69, v65                                     // 0000001650B0: 7E8A0341
	v_mov_b32_e32 v70, v65                                     // 0000001650B4: 7E8C0341
	v_mov_b32_e32 v71, v65                                     // 0000001650B8: 7E8E0341
	v_mov_b32_e32 v72, v65                                     // 0000001650BC: 7E900341
	v_mov_b32_e32 v57, v65                                     // 0000001650C0: 7E720341
	v_mov_b32_e32 v58, v65                                     // 0000001650C4: 7E740341
	v_mov_b32_e32 v59, v65                                     // 0000001650C8: 7E760341
	v_mov_b32_e32 v60, v65                                     // 0000001650CC: 7E780341
	v_mov_b32_e32 v61, v65                                     // 0000001650D0: 7E7A0341
	v_mov_b32_e32 v62, v65                                     // 0000001650D4: 7E7C0341
	v_mov_b32_e32 v63, v65                                     // 0000001650D8: 7E7E0341
	v_mov_b32_e32 v64, v65                                     // 0000001650DC: 7E800341
	v_mov_b32_e32 v49, v65                                     // 0000001650E0: 7E620341
	v_mov_b32_e32 v50, v65                                     // 0000001650E4: 7E640341
	v_mov_b32_e32 v51, v65                                     // 0000001650E8: 7E660341
	v_mov_b32_e32 v52, v65                                     // 0000001650EC: 7E680341
	v_mov_b32_e32 v53, v65                                     // 0000001650F0: 7E6A0341
	v_mov_b32_e32 v54, v65                                     // 0000001650F4: 7E6C0341
	v_mov_b32_e32 v55, v65                                     // 0000001650F8: 7E6E0341
	v_mov_b32_e32 v56, v65                                     // 0000001650FC: 7E700341
	v_mov_b32_e32 v41, v65                                     // 000000165100: 7E520341
	v_mov_b32_e32 v42, v65                                     // 000000165104: 7E540341
	v_mov_b32_e32 v43, v65                                     // 000000165108: 7E560341
	v_mov_b32_e32 v44, v65                                     // 00000016510C: 7E580341
	v_mov_b32_e32 v45, v65                                     // 000000165110: 7E5A0341
	v_mov_b32_e32 v46, v65                                     // 000000165114: 7E5C0341
	v_mov_b32_e32 v47, v65                                     // 000000165118: 7E5E0341
	v_mov_b32_e32 v48, v65                                     // 00000016511C: 7E600341
	s_mov_b32 s18, 0                                           // 000000165120: BE920080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000165124: BF8704B9
	s_lshl_b32 s14, s18, 4                                     // 000000165128: 840E8412
	v_lshl_add_u32 v124, s18, 5, v85                           // 00000016512C: D646007C 05550A12
	s_lshl_b64 s[48:49], s[14:15], 2                           // 000000165134: 84B0820E
	.long 0xd7000064                                           // 000000165138: D7000064
	v_cndmask_b32_e32 v0, v98, v48, vcc_lo                     // 00000016513C: 02006162
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165140: BF870001
	v_add_co_ci_u32_e64 v101, null, s49, v99, s0               // 000000165144: D5207C65 0002C631
	.long 0xd44a0000                                           // 00000016514C: D44A0000
	v_cndmask_b32_e32 v1, s18, v78, vcc_lo                     // 000000165150: 02029C12
	s_add_i32 s18, s18, 1                                      // 000000165154: 81128112
	s_clause 0x3                                               // 000000165158: BF850003
	global_load_b128 v[132:135], v[100:101], off               // 00000016515C: DC5E0000 847C0064
	global_load_b128 v[136:139], v[100:101], off offset:16     // 000000165164: DC5E0010 887C0064
	global_load_b128 v[140:143], v[100:101], off offset:32     // 00000016516C: DC5E0020 8C7C0064
	global_load_b128 v[144:147], v[100:101], off offset:48     // 000000165174: DC5E0030 907C0064
	ds_load_b128 v[100:103], v124                              // 00000016517C: DBFC0000 6400007C
	ds_load_b128 v[104:107], v124 offset:16                    // 000000165184: DBFC0010 6800007C
	ds_load_b128 v[112:115], v124 offset:2576                  // 00000016518C: DBFC0A10 7000007C
	ds_load_b128 v[108:111], v124 offset:2560                  // 000000165194: DBFC0A00 6C00007C
	ds_load_b128 v[120:123], v124 offset:5136                  // 00000016519C: DBFC1410 7800007C
	ds_load_b128 v[116:119], v124 offset:5120                  // 0000001651A4: DBFC1400 7400007C
	ds_load_b128 v[128:131], v124 offset:7696                  // 0000001651AC: DBFC1E10 8000007C
	ds_load_b128 v[124:127], v124 offset:7680                  // 0000001651B4: DBFC1E00 7C00007C
	s_or_b32 s11, s0, s11                                      // 0000001651BC: 8C0B0B00
	s_waitcnt vmcnt(3)                                         // 0000001651C0: BF890FF7
	v_fma_mixlo_f16 v132, v132, s44, 0                         // 0000001651C4: CC210084 02005984
	v_fma_mixhi_f16 v132, v133, s44, 0                         // 0000001651CC: CC220084 02005985
	v_fma_mixlo_f16 v133, v134, s44, 0                         // 0000001651D4: CC210085 02005986
	v_fma_mixhi_f16 v133, v135, s44, 0                         // 0000001651DC: CC220085 02005987
	s_waitcnt vmcnt(2)                                         // 0000001651E4: BF890BF7
	v_fma_mixlo_f16 v134, v136, s44, 0                         // 0000001651E8: CC210086 02005988
	v_fma_mixhi_f16 v134, v137, s44, 0                         // 0000001651F0: CC220086 02005989
	v_fma_mixlo_f16 v135, v138, s44, 0                         // 0000001651F8: CC210087 0200598A
	v_fma_mixhi_f16 v135, v139, s44, 0                         // 000000165200: CC220087 0200598B
	s_waitcnt vmcnt(1)                                         // 000000165208: BF8907F7
	v_fma_mixlo_f16 v136, v140, s44, 0                         // 00000016520C: CC210088 0200598C
	v_fma_mixhi_f16 v136, v141, s44, 0                         // 000000165214: CC220088 0200598D
	v_fma_mixlo_f16 v137, v142, s44, 0                         // 00000016521C: CC210089 0200598E
	v_fma_mixhi_f16 v137, v143, s44, 0                         // 000000165224: CC220089 0200598F
	s_waitcnt vmcnt(0)                                         // 00000016522C: BF8903F7
	v_fma_mixlo_f16 v138, v144, s44, 0                         // 000000165230: CC21008A 02005990
	v_fma_mixhi_f16 v138, v145, s44, 0                         // 000000165238: CC22008A 02005991
	v_fma_mixlo_f16 v139, v146, s44, 0                         // 000000165240: CC21008B 02005992
	v_fma_mixhi_f16 v139, v147, s44, 0                         // 000000165248: CC22008B 02005993
	s_waitcnt lgkmcnt(6)                                       // 000000165250: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165254: BF870001
	v_wmma_f32_16x16x16_f16 v[65:72], v[132:139], v[100:107], v[65:72]// 000000165258: CC404041 1D06C984
	s_waitcnt lgkmcnt(4)                                       // 000000165260: BF89FC47
	v_wmma_f32_16x16x16_f16 v[57:64], v[132:139], v[108:115], v[57:64]// 000000165264: CC404039 1CE6D984
	s_waitcnt lgkmcnt(2)                                       // 00000016526C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[49:56], v[132:139], v[116:123], v[49:56]// 000000165270: CC404031 1CC6E984
	s_waitcnt lgkmcnt(0)                                       // 000000165278: BF89FC07
	v_wmma_f32_16x16x16_f16 v[41:48], v[132:139], v[124:131], v[41:48]// 00000016527C: CC404029 1CA6F984
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 000000165284: 917E0B7E
	s_cbranch_execnz 65446                                     // 000000165288: BFA6FFA6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5024>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016528C: 8C7E0B7E
	s_and_saveexec_b32 s0, s1                                  // 000000165290: BE802001
	s_cbranch_execnz 183                                       // 000000165294: BFA600B7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5474>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165298: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000016529C: BE802004
	s_cbranch_execnz 202                                       // 0000001652A0: BFA600CA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x54cc>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001652A4: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000001652A8: BE802005
	s_cbranch_execnz 221                                       // 0000001652AC: BFA600DD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5524>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001652B0: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000001652B4: BE802006
	s_cbranch_execnz 240                                       // 0000001652B8: BFA600F0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x557c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001652BC: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001652C0: BE802007
	s_cbranch_execnz 259                                       // 0000001652C4: BFA60103 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x55d4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001652C8: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001652CC: BE802008
	s_cbranch_execnz 278                                       // 0000001652D0: BFA60116 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x562c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001652D4: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001652D8: BE802009
	s_cbranch_execnz 297                                       // 0000001652DC: BFA60129 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5684>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001652E0: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001652E4: BE80200A
	s_cbranch_execnz 316                                       // 0000001652E8: BFA6013C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x56dc>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001652EC: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001652F0: BE802001
	s_cbranch_execnz 334                                       // 0000001652F4: BFA6014E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5730>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001652F8: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000001652FC: BE802004
	s_cbranch_execnz 353                                       // 000000165300: BFA60161 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5788>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165304: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000165308: BE802005
	s_cbranch_execnz 372                                       // 00000016530C: BFA60174 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x57e0>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165310: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000165314: BE802006
	s_cbranch_execnz 391                                       // 000000165318: BFA60187 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5838>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016531C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000165320: BE802007
	s_cbranch_execnz 410                                       // 000000165324: BFA6019A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5890>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165328: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000016532C: BE802008
	s_cbranch_execnz 429                                       // 000000165330: BFA601AD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x58e8>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165334: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000165338: BE802009
	s_cbranch_execnz 448                                       // 00000016533C: BFA601C0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5940>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165340: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 000000165344: BE80200A
	s_cbranch_execnz 467                                       // 000000165348: BFA601D3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5998>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016534C: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 000000165350: BE802001
	s_cbranch_execnz 485                                       // 000000165354: BFA601E5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x59ec>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165358: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000016535C: BE802004
	s_cbranch_execnz 504                                       // 000000165360: BFA601F8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a44>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165364: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000165368: BE802005
	s_cbranch_execnz 523                                       // 00000016536C: BFA6020B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a9c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165370: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000165374: BE802006
	s_cbranch_execnz 542                                       // 000000165378: BFA6021E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5af4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016537C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000165380: BE802007
	s_cbranch_execnz 561                                       // 000000165384: BFA60231 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5b4c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165388: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000016538C: BE802008
	s_cbranch_execnz 580                                       // 000000165390: BFA60244 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5ba4>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165394: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000165398: BE802009
	s_cbranch_execnz 599                                       // 00000016539C: BFA60257 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5bfc>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001653A0: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001653A4: BE80200A
	s_cbranch_execnz 618                                       // 0000001653A8: BFA6026A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c54>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001653AC: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001653B0: BE802001
	s_cbranch_execnz 636                                       // 0000001653B4: BFA6027C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5ca8>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001653B8: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000001653BC: BE802004
	s_cbranch_execnz 655                                       // 0000001653C0: BFA6028F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5d00>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001653C4: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000001653C8: BE802005
	s_cbranch_execnz 674                                       // 0000001653CC: BFA602A2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5d58>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001653D0: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000001653D4: BE802006
	s_cbranch_execnz 693                                       // 0000001653D8: BFA602B5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5db0>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001653DC: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001653E0: BE802007
	s_cbranch_execnz 712                                       // 0000001653E4: BFA602C8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5e08>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001653E8: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001653EC: BE802008
	s_cbranch_execnz 731                                       // 0000001653F0: BFA602DB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5e60>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001653F4: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001653F8: BE802009
	s_cbranch_execnz 750                                       // 0000001653FC: BFA602EE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5eb8>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165400: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 000000165404: BE80200A
	s_cbranch_execz 18                                         // 000000165408: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5354>
	ds_load_b32 v9, v89 offset:56                              // 00000016540C: D8D80038 09000059
	s_waitcnt lgkmcnt(0)                                       // 000000165414: BF89FC07
	v_fmac_f32_e32 v48, v16, v9                                // 000000165418: 56601310
	v_mad_u64_u32 v[9:10], null, 0x3000, v97, v[73:74]         // 00000016541C: D6FE7C09 0526C2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165428: BF870092
	v_mul_f32_e32 v11, 0x3b800000, v48                         // 00000016542C: 101660FF 3B800000
	v_bfe_u32 v12, v11, 16, 1                                  // 000000165434: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016543C: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000165440: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 00000016544C: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165454: 8C7E007E
	s_mul_f32 s0, s46, 0x3fb8aa3b                              // 000000165458: A200FF2E 3FB8AA3B
	v_mov_b32_e32 v10, v0                                      // 000000165460: 7E140300
	s_waitcnt_vscnt null, 0x0                                  // 000000165464: BC7C0000
	s_barrier                                                  // 000000165468: BFBD0000
	s_xor_b32 s1, s0, 0x80000000                               // 00000016546C: 8D01FF00 80000000
	s_rndne_f32 s4, s0                                         // 000000165474: BE846300
	s_fmamk_f32 s1, s46, 0x3fb8aa3b, s1                        // 000000165478: A301012E 3FB8AA3B
	s_cmp_nlt_f32 s46, 0xc2ce8ed0                              // 000000165480: BF4EFF2E C2CE8ED0
	buffer_gl0_inv                                             // 000000165488: E0AC0000 00000000
	s_sub_f32 s0, s0, s4                                       // 000000165490: A0800400
	s_fmamk_f32 s1, s46, 0x32a5705f, s1                        // 000000165494: A301012E 32A5705F
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 00000016549C: BF87052B
	s_add_f32 s0, s0, s1                                       // 0000001654A0: A0000100
	s_mov_b32 s1, 0                                            // 0000001654A4: BE810080
	v_exp_f32_e32 v9, s0                                       // 0000001654A8: 7E124A00
	s_cvt_i32_f32 s0, s4                                       // 0000001654AC: BE806604
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000001654B0: BF870585
	.long 0xd71c0009                                           // 0000001654B4: D71C0009
	v_cndmask_b32_e32 v0, v9, v0, vcc_lo                       // 0000001654B8: 02000109
	s_cselect_b32 s0, -1, 0                                    // 0000001654BC: 980080C1
	s_cmp_ngt_f32 s46, 0x42b17218                              // 0000001654C0: BF4BFF2E 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001654C8: BF870001
	v_cndmask_b32_e64 v9, 0, v9, s0                            // 0000001654CC: D5010009 00021280
	s_cselect_b32 s0, -1, 0                                    // 0000001654D4: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000001654D8: BF870481
	v_cndmask_b32_e64 v9, 0x7f800000, v9, s0                   // 0000001654DC: D5010009 000212FF 7F800000
	s_nop 0                                                    // 0000001654E8: BF800000
	s_nop 0                                                    // 0000001654EC: BF800000
	s_nop 0                                                    // 0000001654F0: BF800000
	s_nop 0                                                    // 0000001654F4: BF800000
	s_nop 0                                                    // 0000001654F8: BF800000
	s_nop 0                                                    // 0000001654FC: BF800000
	v_lshrrev_b32_e32 v11, 4, v10                              // 000000165500: 32161484
	v_add_nc_u32_e32 v13, 0x80, v10                            // 000000165504: 4A1A14FF 00000080
	.long 0xd4490000                                           // 00000016550C: D4490000
	v_cndmask_b32_e32 v1, 0x1f7f, v10, vcc_lo                  // 000000165510: 020214FF 00001F7F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000165518: BF8700A2
	v_dual_mov_b32 v10, v13 :: v_dual_and_b32 v11, 0xffffffc, v11// 00000016551C: CA24010D 0A0A16FF 0FFFFFFC
	s_or_b32 s1, s0, s1                                        // 000000165528: 8C010100
	v_add_nc_u32_e32 v11, v76, v11                             // 00000016552C: 4A16174C
	ds_load_b32 v12, v11                                       // 000000165530: D8D80000 0C00000B
	s_waitcnt lgkmcnt(0)                                       // 000000165538: BF89FC07
	v_mul_f32_e32 v12, v9, v12                                 // 00000016553C: 10181909
	ds_store_b32 v11, v12                                      // 000000165540: D8340000 00000C0B
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000165548: 917E017E
	s_cbranch_execnz 65516                                     // 00000016554C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5400>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000165550: 8C7E017E
	s_add_i32 s45, s45, 1                                      // 000000165554: 812D812D
	s_waitcnt lgkmcnt(0)                                       // 000000165558: BF89FC07
	s_cmp_eq_u32 s45, s43                                      // 00000016555C: BF062B2D
	s_barrier                                                  // 000000165560: BFBD0000
	buffer_gl0_inv                                             // 000000165564: E0AC0000 00000000
	s_cbranch_scc0 60292                                       // 00000016556C: BFA1EB84 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x280>
	s_branch 680                                               // 000000165570: BFA002A8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5f14>
	ds_load_b32 v98, v89                                       // 000000165574: D8D80000 62000059
	s_waitcnt lgkmcnt(0)                                       // 00000016557C: BF89FC07
	v_fma_f32 v33, v33, v98, v65                               // 000000165580: D6130021 0506C521
	v_mad_u64_u32 v[98:99], null, 0x3000, v90, v[73:74]        // 000000165588: D6FE7C62 0526B4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165594: BF870092
	v_mul_f32_e32 v33, 0x3b800000, v33                         // 000000165598: 104242FF 3B800000
	v_bfe_u32 v65, v33, 16, 1                                  // 0000001655A0: D6100041 02052121
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001655A8: BF870001
	v_add3_u32 v33, v33, v65, 0x7fff                           // 0000001655AC: D6550021 03FE8321 00007FFF
	global_store_d16_hi_b16 v[98:99], v33, off                 // 0000001655B8: DC960000 007C2162
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001655C0: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000001655C4: BE802004
	s_cbranch_execz 65334                                      // 0000001655C8: BFA5FF36 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51a4>
	ds_load_b32 v33, v89 offset:8                              // 0000001655CC: D8D80008 21000059
	s_waitcnt lgkmcnt(0)                                       // 0000001655D4: BF89FC07
	v_fma_f32 v33, v34, v33, v66                               // 0000001655D8: D6130021 050A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001655E0: BF870121
	v_mul_f32_e32 v65, 0x3b800000, v33                         // 0000001655E4: 108242FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v91, v[73:74]        // 0000001655EC: D6FE7C21 0526B6FF 00003000
	v_bfe_u32 v66, v65, 16, 1                                  // 0000001655F8: D6100042 02052141
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165600: BF870001
	v_add3_u32 v65, v65, v66, 0x7fff                           // 000000165604: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[33:34], v65, off                 // 000000165610: DC960000 007C4121
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165618: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000016561C: BE802005
	s_cbranch_execz 65315                                      // 000000165620: BFA5FF23 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51b0>
	ds_load_b32 v33, v89 offset:16                             // 000000165624: D8D80010 21000059
	s_waitcnt lgkmcnt(0)                                       // 00000016562C: BF89FC07
	v_fma_f32 v33, v35, v33, v67                               // 000000165630: D6130021 050E4323
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165638: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 00000016563C: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v92, v[73:74]        // 000000165644: D6FE7C21 0526B8FF 00003000
	v_bfe_u32 v65, v35, 16, 1                                  // 000000165650: D6100041 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165658: BF870001
	v_add3_u32 v35, v35, v65, 0x7fff                           // 00000016565C: D6550023 03FE8323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 000000165668: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165670: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000165674: BE802006
	s_cbranch_execz 65296                                      // 000000165678: BFA5FF10 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51bc>
	ds_load_b32 v33, v89 offset:24                             // 00000016567C: D8D80018 21000059
	s_waitcnt lgkmcnt(0)                                       // 000000165684: BF89FC07
	v_fma_f32 v33, v36, v33, v68                               // 000000165688: D6130021 05124324
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165690: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 000000165694: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v93, v[73:74]        // 00000016569C: D6FE7C21 0526BAFF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 0000001656A8: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001656B0: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000001656B4: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 0000001656C0: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001656C8: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001656CC: BE802007
	s_cbranch_execz 65277                                      // 0000001656D0: BFA5FEFD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51c8>
	ds_load_b32 v33, v89 offset:32                             // 0000001656D4: D8D80020 21000059
	s_waitcnt lgkmcnt(0)                                       // 0000001656DC: BF89FC07
	v_fma_f32 v33, v37, v33, v69                               // 0000001656E0: D6130021 05164325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001656E8: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 0000001656EC: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v94, v[73:74]        // 0000001656F4: D6FE7C21 0526BCFF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 000000165700: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165708: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000016570C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 000000165718: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165720: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 000000165724: BE802008
	s_cbranch_execz 65258                                      // 000000165728: BFA5FEEA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51d4>
	ds_load_b32 v33, v89 offset:40                             // 00000016572C: D8D80028 21000059
	s_waitcnt lgkmcnt(0)                                       // 000000165734: BF89FC07
	v_fma_f32 v33, v38, v33, v70                               // 000000165738: D6130021 051A4326
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165740: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 000000165744: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v95, v[73:74]        // 00000016574C: D6FE7C21 0526BEFF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 000000165758: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165760: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000165764: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 000000165770: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165778: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000016577C: BE802009
	s_cbranch_execz 65239                                      // 000000165780: BFA5FED7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51e0>
	ds_load_b32 v33, v89 offset:48                             // 000000165784: D8D80030 21000059
	s_waitcnt lgkmcnt(0)                                       // 00000016578C: BF89FC07
	v_fma_f32 v33, v39, v33, v71                               // 000000165790: D6130021 051E4327
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165798: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 00000016579C: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v96, v[73:74]        // 0000001657A4: D6FE7C21 0526C0FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 0000001657B0: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001657B8: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000001657BC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 0000001657C8: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001657D0: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001657D4: BE80200A
	s_cbranch_execz 65220                                      // 0000001657D8: BFA5FEC4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51ec>
	ds_load_b32 v33, v89 offset:56                             // 0000001657DC: D8D80038 21000059
	s_waitcnt lgkmcnt(0)                                       // 0000001657E4: BF89FC07
	v_fmac_f32_e32 v72, v40, v33                               // 0000001657E8: 56904328
	v_mad_u64_u32 v[33:34], null, 0x3000, v97, v[73:74]        // 0000001657EC: D6FE7C21 0526C2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001657F8: BF870092
	v_mul_f32_e32 v35, 0x3b800000, v72                         // 0000001657FC: 104690FF 3B800000
	v_bfe_u32 v36, v35, 16, 1                                  // 000000165804: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016580C: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000165810: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 00000016581C: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165824: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 000000165828: BE802001
	s_cbranch_execz 65202                                      // 00000016582C: BFA5FEB2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51f8>
	ds_load_b32 v33, v89                                       // 000000165830: D8D80000 21000059
	s_waitcnt lgkmcnt(0)                                       // 000000165838: BF89FC07
	v_fma_f32 v25, v25, v33, v57                               // 00000016583C: D6130019 04E64319
	v_mad_u64_u32 v[33:34], null, 0x3000, v90, v[73:74]        // 000000165844: D6FE7C21 0526B4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165850: BF870092
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 000000165854: 103232FF 3B800000
	v_bfe_u32 v35, v25, 16, 1                                  // 00000016585C: D6100023 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165864: BF870001
	v_add3_u32 v25, v25, v35, 0x7fff                           // 000000165868: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:32       // 000000165874: DC960020 007C1921
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016587C: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000165880: BE802004
	s_cbranch_execz 65183                                      // 000000165884: BFA5FE9F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5204>
	ds_load_b32 v25, v89 offset:8                              // 000000165888: D8D80008 19000059
	s_waitcnt lgkmcnt(0)                                       // 000000165890: BF89FC07
	v_fma_f32 v25, v26, v25, v58                               // 000000165894: D6130019 04EA331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016589C: BF870121
	v_mul_f32_e32 v33, 0x3b800000, v25                         // 0000001658A0: 104232FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v91, v[73:74]        // 0000001658A8: D6FE7C19 0526B6FF 00003000
	v_bfe_u32 v34, v33, 16, 1                                  // 0000001658B4: D6100022 02052121
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001658BC: BF870001
	v_add3_u32 v33, v33, v34, 0x7fff                           // 0000001658C0: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:32       // 0000001658CC: DC960020 007C2119
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001658D4: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000001658D8: BE802005
	s_cbranch_execz 65164                                      // 0000001658DC: BFA5FE8C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5210>
	ds_load_b32 v25, v89 offset:16                             // 0000001658E0: D8D80010 19000059
	s_waitcnt lgkmcnt(0)                                       // 0000001658E8: BF89FC07
	v_fma_f32 v25, v27, v25, v59                               // 0000001658EC: D6130019 04EE331B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001658F4: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001658F8: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v92, v[73:74]        // 000000165900: D6FE7C19 0526B8FF 00003000
	v_bfe_u32 v33, v27, 16, 1                                  // 00000016590C: D6100021 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165914: BF870001
	v_add3_u32 v27, v27, v33, 0x7fff                           // 000000165918: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:32       // 000000165924: DC960020 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016592C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000165930: BE802006
	s_cbranch_execz 65145                                      // 000000165934: BFA5FE79 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x521c>
	ds_load_b32 v25, v89 offset:24                             // 000000165938: D8D80018 19000059
	s_waitcnt lgkmcnt(0)                                       // 000000165940: BF89FC07
	v_fma_f32 v25, v28, v25, v60                               // 000000165944: D6130019 04F2331C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016594C: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 000000165950: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v93, v[73:74]        // 000000165958: D6FE7C19 0526BAFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 000000165964: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016596C: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000165970: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:32       // 00000016597C: DC960020 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165984: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000165988: BE802007
	s_cbranch_execz 65126                                      // 00000016598C: BFA5FE66 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5228>
	ds_load_b32 v25, v89 offset:32                             // 000000165990: D8D80020 19000059
	s_waitcnt lgkmcnt(0)                                       // 000000165998: BF89FC07
	v_fma_f32 v25, v29, v25, v61                               // 00000016599C: D6130019 04F6331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001659A4: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001659A8: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v94, v[73:74]        // 0000001659B0: D6FE7C19 0526BCFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001659BC: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001659C4: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001659C8: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:32       // 0000001659D4: DC960020 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001659DC: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001659E0: BE802008
	s_cbranch_execz 65107                                      // 0000001659E4: BFA5FE53 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5234>
	ds_load_b32 v25, v89 offset:40                             // 0000001659E8: D8D80028 19000059
	s_waitcnt lgkmcnt(0)                                       // 0000001659F0: BF89FC07
	v_fma_f32 v25, v30, v25, v62                               // 0000001659F4: D6130019 04FA331E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001659FC: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 000000165A00: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v95, v[73:74]        // 000000165A08: D6FE7C19 0526BEFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 000000165A14: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165A1C: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000165A20: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:32       // 000000165A2C: DC960020 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165A34: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000165A38: BE802009
	s_cbranch_execz 65088                                      // 000000165A3C: BFA5FE40 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5240>
	ds_load_b32 v25, v89 offset:48                             // 000000165A40: D8D80030 19000059
	s_waitcnt lgkmcnt(0)                                       // 000000165A48: BF89FC07
	v_fma_f32 v25, v31, v25, v63                               // 000000165A4C: D6130019 04FE331F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165A54: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 000000165A58: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v96, v[73:74]        // 000000165A60: D6FE7C19 0526C0FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 000000165A6C: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165A74: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000165A78: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:32       // 000000165A84: DC960020 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165A8C: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 000000165A90: BE80200A
	s_cbranch_execz 65069                                      // 000000165A94: BFA5FE2D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x524c>
	ds_load_b32 v25, v89 offset:56                             // 000000165A98: D8D80038 19000059
	s_waitcnt lgkmcnt(0)                                       // 000000165AA0: BF89FC07
	v_fmac_f32_e32 v64, v32, v25                               // 000000165AA4: 56803320
	v_mad_u64_u32 v[25:26], null, 0x3000, v97, v[73:74]        // 000000165AA8: D6FE7C19 0526C2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165AB4: BF870092
	v_mul_f32_e32 v27, 0x3b800000, v64                         // 000000165AB8: 103680FF 3B800000
	v_bfe_u32 v28, v27, 16, 1                                  // 000000165AC0: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165AC8: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000165ACC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:32       // 000000165AD8: DC960020 007C1B19
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165AE0: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 000000165AE4: BE802001
	s_cbranch_execz 65051                                      // 000000165AE8: BFA5FE1B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5258>
	ds_load_b32 v25, v89                                       // 000000165AEC: D8D80000 19000059
	s_waitcnt lgkmcnt(0)                                       // 000000165AF4: BF89FC07
	v_fma_f32 v17, v17, v25, v49                               // 000000165AF8: D6130011 04C63311
	v_mad_u64_u32 v[25:26], null, 0x3000, v90, v[73:74]        // 000000165B00: D6FE7C19 0526B4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165B0C: BF870092
	v_mul_f32_e32 v17, 0x3b800000, v17                         // 000000165B10: 102222FF 3B800000
	v_bfe_u32 v27, v17, 16, 1                                  // 000000165B18: D610001B 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165B20: BF870001
	v_add3_u32 v17, v17, v27, 0x7fff                           // 000000165B24: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:64       // 000000165B30: DC960040 007C1119
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165B38: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000165B3C: BE802004
	s_cbranch_execz 65032                                      // 000000165B40: BFA5FE08 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5264>
	ds_load_b32 v17, v89 offset:8                              // 000000165B44: D8D80008 11000059
	s_waitcnt lgkmcnt(0)                                       // 000000165B4C: BF89FC07
	v_fma_f32 v17, v18, v17, v50                               // 000000165B50: D6130011 04CA2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165B58: BF870121
	v_mul_f32_e32 v25, 0x3b800000, v17                         // 000000165B5C: 103222FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v91, v[73:74]        // 000000165B64: D6FE7C11 0526B6FF 00003000
	v_bfe_u32 v26, v25, 16, 1                                  // 000000165B70: D610001A 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165B78: BF870001
	v_add3_u32 v25, v25, v26, 0x7fff                           // 000000165B7C: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:64       // 000000165B88: DC960040 007C1911
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165B90: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000165B94: BE802005
	s_cbranch_execz 65013                                      // 000000165B98: BFA5FDF5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5270>
	ds_load_b32 v17, v89 offset:16                             // 000000165B9C: D8D80010 11000059
	s_waitcnt lgkmcnt(0)                                       // 000000165BA4: BF89FC07
	v_fma_f32 v17, v19, v17, v51                               // 000000165BA8: D6130011 04CE2313
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165BB0: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 000000165BB4: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v92, v[73:74]        // 000000165BBC: D6FE7C11 0526B8FF 00003000
	v_bfe_u32 v25, v19, 16, 1                                  // 000000165BC8: D6100019 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165BD0: BF870001
	v_add3_u32 v19, v19, v25, 0x7fff                           // 000000165BD4: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 000000165BE0: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165BE8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000165BEC: BE802006
	s_cbranch_execz 64994                                      // 000000165BF0: BFA5FDE2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x527c>
	ds_load_b32 v17, v89 offset:24                             // 000000165BF4: D8D80018 11000059
	s_waitcnt lgkmcnt(0)                                       // 000000165BFC: BF89FC07
	v_fma_f32 v17, v20, v17, v52                               // 000000165C00: D6130011 04D22314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165C08: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 000000165C0C: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v93, v[73:74]        // 000000165C14: D6FE7C11 0526BAFF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 000000165C20: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165C28: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000165C2C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 000000165C38: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165C40: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000165C44: BE802007
	s_cbranch_execz 64975                                      // 000000165C48: BFA5FDCF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5288>
	ds_load_b32 v17, v89 offset:32                             // 000000165C4C: D8D80020 11000059
	s_waitcnt lgkmcnt(0)                                       // 000000165C54: BF89FC07
	v_fma_f32 v17, v21, v17, v53                               // 000000165C58: D6130011 04D62315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165C60: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 000000165C64: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v94, v[73:74]        // 000000165C6C: D6FE7C11 0526BCFF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 000000165C78: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165C80: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000165C84: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 000000165C90: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165C98: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 000000165C9C: BE802008
	s_cbranch_execz 64956                                      // 000000165CA0: BFA5FDBC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5294>
	ds_load_b32 v17, v89 offset:40                             // 000000165CA4: D8D80028 11000059
	s_waitcnt lgkmcnt(0)                                       // 000000165CAC: BF89FC07
	v_fma_f32 v17, v22, v17, v54                               // 000000165CB0: D6130011 04DA2316
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165CB8: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 000000165CBC: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v95, v[73:74]        // 000000165CC4: D6FE7C11 0526BEFF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 000000165CD0: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165CD8: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000165CDC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 000000165CE8: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165CF0: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000165CF4: BE802009
	s_cbranch_execz 64937                                      // 000000165CF8: BFA5FDA9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x52a0>
	ds_load_b32 v17, v89 offset:48                             // 000000165CFC: D8D80030 11000059
	s_waitcnt lgkmcnt(0)                                       // 000000165D04: BF89FC07
	v_fma_f32 v17, v23, v17, v55                               // 000000165D08: D6130011 04DE2317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165D10: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 000000165D14: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v96, v[73:74]        // 000000165D1C: D6FE7C11 0526C0FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 000000165D28: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165D30: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000165D34: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 000000165D40: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165D48: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 000000165D4C: BE80200A
	s_cbranch_execz 64918                                      // 000000165D50: BFA5FD96 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x52ac>
	ds_load_b32 v17, v89 offset:56                             // 000000165D54: D8D80038 11000059
	s_waitcnt lgkmcnt(0)                                       // 000000165D5C: BF89FC07
	v_fmac_f32_e32 v56, v24, v17                               // 000000165D60: 56702318
	v_mad_u64_u32 v[17:18], null, 0x3000, v97, v[73:74]        // 000000165D64: D6FE7C11 0526C2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165D70: BF870092
	v_mul_f32_e32 v19, 0x3b800000, v56                         // 000000165D74: 102670FF 3B800000
	v_bfe_u32 v20, v19, 16, 1                                  // 000000165D7C: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165D84: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000165D88: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 000000165D94: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165D9C: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 000000165DA0: BE802001
	s_cbranch_execz 64900                                      // 000000165DA4: BFA5FD84 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x52b8>
	ds_load_b32 v17, v89                                       // 000000165DA8: D8D80000 11000059
	s_waitcnt lgkmcnt(0)                                       // 000000165DB0: BF89FC07
	v_fma_f32 v9, v9, v17, v41                                 // 000000165DB4: D6130009 04A62309
	v_mad_u64_u32 v[17:18], null, 0x3000, v90, v[73:74]        // 000000165DBC: D6FE7C11 0526B4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000165DC8: BF870092
	v_mul_f32_e32 v9, 0x3b800000, v9                           // 000000165DCC: 101212FF 3B800000
	v_bfe_u32 v19, v9, 16, 1                                   // 000000165DD4: D6100013 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165DDC: BF870001
	v_add3_u32 v9, v9, v19, 0x7fff                             // 000000165DE0: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:96        // 000000165DEC: DC960060 007C0911
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165DF4: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000165DF8: BE802004
	s_cbranch_execz 64881                                      // 000000165DFC: BFA5FD71 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x52c4>
	ds_load_b32 v9, v89 offset:8                               // 000000165E00: D8D80008 09000059
	s_waitcnt lgkmcnt(0)                                       // 000000165E08: BF89FC07
	v_fma_f32 v9, v10, v9, v42                                 // 000000165E0C: D6130009 04AA130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165E14: BF870121
	v_mul_f32_e32 v17, 0x3b800000, v9                          // 000000165E18: 102212FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v91, v[73:74]         // 000000165E20: D6FE7C09 0526B6FF 00003000
	v_bfe_u32 v18, v17, 16, 1                                  // 000000165E2C: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165E34: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 000000165E38: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:96        // 000000165E44: DC960060 007C1109
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165E4C: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000165E50: BE802005
	s_cbranch_execz 64862                                      // 000000165E54: BFA5FD5E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x52d0>
	ds_load_b32 v9, v89 offset:16                              // 000000165E58: D8D80010 09000059
	s_waitcnt lgkmcnt(0)                                       // 000000165E60: BF89FC07
	v_fma_f32 v9, v11, v9, v43                                 // 000000165E64: D6130009 04AE130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165E6C: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 000000165E70: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v92, v[73:74]         // 000000165E78: D6FE7C09 0526B8FF 00003000
	v_bfe_u32 v17, v11, 16, 1                                  // 000000165E84: D6100011 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165E8C: BF870001
	v_add3_u32 v11, v11, v17, 0x7fff                           // 000000165E90: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 000000165E9C: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165EA4: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000165EA8: BE802006
	s_cbranch_execz 64843                                      // 000000165EAC: BFA5FD4B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x52dc>
	ds_load_b32 v9, v89 offset:24                              // 000000165EB0: D8D80018 09000059
	s_waitcnt lgkmcnt(0)                                       // 000000165EB8: BF89FC07
	v_fma_f32 v9, v12, v9, v44                                 // 000000165EBC: D6130009 04B2130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165EC4: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 000000165EC8: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v93, v[73:74]         // 000000165ED0: D6FE7C09 0526BAFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 000000165EDC: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165EE4: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000165EE8: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 000000165EF4: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165EFC: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000165F00: BE802007
	s_cbranch_execz 64824                                      // 000000165F04: BFA5FD38 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x52e8>
	ds_load_b32 v9, v89 offset:32                              // 000000165F08: D8D80020 09000059
	s_waitcnt lgkmcnt(0)                                       // 000000165F10: BF89FC07
	v_fma_f32 v9, v13, v9, v45                                 // 000000165F14: D6130009 04B6130D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165F1C: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 000000165F20: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v94, v[73:74]         // 000000165F28: D6FE7C09 0526BCFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 000000165F34: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165F3C: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000165F40: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 000000165F4C: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165F54: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 000000165F58: BE802008
	s_cbranch_execz 64805                                      // 000000165F5C: BFA5FD25 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x52f4>
	ds_load_b32 v9, v89 offset:40                              // 000000165F60: D8D80028 09000059
	s_waitcnt lgkmcnt(0)                                       // 000000165F68: BF89FC07
	v_fma_f32 v9, v14, v9, v46                                 // 000000165F6C: D6130009 04BA130E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165F74: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 000000165F78: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v95, v[73:74]         // 000000165F80: D6FE7C09 0526BEFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 000000165F8C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165F94: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000165F98: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 000000165FA4: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 000000165FAC: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000165FB0: BE802009
	s_cbranch_execz 64786                                      // 000000165FB4: BFA5FD12 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5300>
	ds_load_b32 v9, v89 offset:48                              // 000000165FB8: D8D80030 09000059
	s_waitcnt lgkmcnt(0)                                       // 000000165FC0: BF89FC07
	v_fma_f32 v9, v15, v9, v47                                 // 000000165FC4: D6130009 04BE130F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000165FCC: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 000000165FD0: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v96, v[73:74]         // 000000165FD8: D6FE7C09 0526C0FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 000000165FE4: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000165FEC: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000165FF0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 000000165FFC: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s0                              // 000000166004: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 000000166008: BE80200A
	s_cbranch_execnz 64767                                     // 00000016600C: BFA6FCFF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x530c>
	s_branch 64784                                             // 000000166010: BFA0FD10 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5354>
	v_lshlrev_b32_e32 v1, 3, v0                                // 000000166014: 30020083
	s_add_u32 s0, s40, s34                                     // 000000166018: 80002228
	s_addc_u32 s1, s33, s35                                    // 00000016601C: 82012321
	s_add_u32 s2, s36, s22                                     // 000000166020: 80021624
	s_addc_u32 s3, s37, s23                                    // 000000166024: 82031725
	v_and_b32_e32 v1, 0x200, v1                                // 000000166028: 360202FF 00000200
	s_add_u32 s0, s2, s0                                       // 000000166030: 80000002
	v_lshlrev_b32_e32 v3, 2, v75                               // 000000166034: 30069682
	s_addc_u32 s1, s3, s1                                      // 000000166038: 82010103
	v_or_b32_e32 v2, 0xffffff80, v0                            // 00000016603C: 380400FF FFFFFF80
	.long 0xd7000001                                           // 000000166044: D7000001
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 000000166048: 02020200
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000016604C: BF8700B1
	v_add_co_ci_u32_e64 v4, null, s1, 0, s0                    // 000000166050: D5207C04 00010001
	s_mov_b32 s1, 0                                            // 000000166058: BE810080
	.long 0xd7006a00                                           // 00000016605C: D7006A00
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000166060: 02020701
	v_add_co_ci_u32_e64 v1, null, 0, v4, vcc_lo                // 000000166064: D5207C01 01AA0880
	v_mul_u32_u24_e32 v3, 0x210, v75                           // 00000016606C: 160696FF 00000210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166074: BF870093
	.long 0xd7006a00                                           // 000000166078: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 00000016607C: 02020014
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 000000166080: D5207C01 01AA0215
	s_delay_alu instid0(VALU_DEP_3)                            // 000000166088: BF870003
	v_and_or_b32 v3, v77, 4, v3                                // 00000016608C: D6570003 040D094D
	s_nop 0                                                    // 000000166094: BF800000
	s_nop 0                                                    // 000000166098: BF800000
	s_nop 0                                                    // 00000016609C: BF800000
	s_nop 0                                                    // 0000001660A0: BF800000
	s_nop 0                                                    // 0000001660A4: BF800000
	s_nop 0                                                    // 0000001660A8: BF800000
	s_nop 0                                                    // 0000001660AC: BF800000
	s_nop 0                                                    // 0000001660B0: BF800000
	s_nop 0                                                    // 0000001660B4: BF800000
	s_nop 0                                                    // 0000001660B8: BF800000
	s_nop 0                                                    // 0000001660BC: BF800000
	ds_load_b32 v4, v3 offset:10240                            // 0000001660C0: D8D82800 04000003
	v_add_nc_u32_e32 v2, 0x80, v2                              // 0000001660C8: 4A0404FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001660D0: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001660D4: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v2                        // 0000001660D8: 7C9204FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001660E0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001660E4: BF89FC07
	global_store_b32 v[0:1], v4, off                           // 0000001660E8: DC6A0000 007C0400
	.long 0xd7000000                                           // 0000001660F0: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 0000001660F4: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000001660FC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000166104: 917E017E
	s_cbranch_execnz 65517                                     // 000000166108: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi6EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5fc0>
	s_nop 0                                                    // 00000016610C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000166110: BFB60003
	s_endpgm                                                   // 000000166114: BFB00000
		...

