0000000000148200 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_load_b512 s[12:27], s[0:1], 0x10                         // 000000148200: F4100300 F8000010
	s_lshl_b32 s4, s3, 6                                       // 000000148208: 84048603
	s_ashr_i32 s3, s2, 31                                      // 00000014820C: 86039F02
	s_ashr_i32 s5, s4, 31                                      // 000000148210: 86059F04
	v_and_b32_e32 v74, 63, v0                                  // 000000148214: 369400BF
	s_movk_i32 s7, 0x210                                       // 000000148218: B0070210
	v_mov_b32_e32 v4, v0                                       // 00000014821C: 7E080300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000148220: BF8704D2
	v_lshlrev_b32_e32 v2, 2, v74                               // 000000148224: 30049482
	v_mad_u32_u24 v1, v74, s7, 0x3200                          // 000000148228: D60B0001 03FC0F4A 00003200
	s_waitcnt lgkmcnt(0)                                       // 000000148234: BF89FC07
	s_load_b32 s6, s[24:25], null                              // 000000148238: F400018C F8000000
	s_lshl_b64 s[34:35], s[26:27], 2                           // 000000148240: 84A2821A
	s_add_u32 s8, s22, s34                                     // 000000148244: 80082216
	s_addc_u32 s9, s23, s35                                    // 000000148248: 82092317
	s_lshl_b64 s[36:37], s[2:3], 16                            // 00000014824C: 84A49002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000148250: BF870009
	s_add_u32 s8, s8, s36                                      // 000000148254: 80082408
	s_addc_u32 s9, s9, s37                                     // 000000148258: 82092509
	s_waitcnt lgkmcnt(0)                                       // 00000014825C: BF89FC07
	s_mul_i32 s11, s6, 0x9000000                               // 000000148260: 960BFF06 09000000
	s_mul_hi_i32 s33, s6, 0x9000000                            // 000000148268: 9721FF06 09000000
	s_add_u32 s6, s8, s11                                      // 000000148270: 80060B08
	s_addc_u32 s8, s9, s33                                     // 000000148274: 82082109
	s_lshl_b64 s[38:39], s[4:5], 2                             // 000000148278: 84A68204
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000014827C: BF8700B9
	s_add_u32 s6, s6, s38                                      // 000000148280: 80062606
	s_addc_u32 s7, s8, s39                                     // 000000148284: 82072708
	.long 0xd7000602                                           // 000000148288: D7000602
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 00000014828C: 02020406
	v_add_co_ci_u32_e64 v3, null, s7, 0, s6                    // 000000148290: D5207C03 00190007
	s_mov_b32 s6, 0                                            // 000000148298: BE860080
	s_nop 0                                                    // 00000014829C: BF800000
	s_nop 0                                                    // 0000001482A0: BF800000
	s_nop 0                                                    // 0000001482A4: BF800000
	s_nop 0                                                    // 0000001482A8: BF800000
	s_nop 0                                                    // 0000001482AC: BF800000
	s_nop 0                                                    // 0000001482B0: BF800000
	s_nop 0                                                    // 0000001482B4: BF800000
	s_nop 0                                                    // 0000001482B8: BF800000
	s_nop 0                                                    // 0000001482BC: BF800000
	v_lshrrev_b32_e32 v7, 6, v4                                // 0000001482C0: 320E0886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001482C4: BF870121
	v_lshlrev_b32_e32 v5, 9, v7                                // 0000001482C8: 300A0E89
	v_lshl_add_u32 v7, v7, 2, v1                               // 0000001482CC: D6460007 04050507
	.long 0xd7006a05                                           // 0000001482D4: D7006A05
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 0000001482D8: 02020B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001482DC: BF8700D1
	v_add_co_ci_u32_e64 v6, null, 0, v3, vcc_lo                // 0000001482E0: D5207C06 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001482E8: 7C9208FF 00001F7F
	global_load_b32 v5, v[5:6], off                            // 0000001482F0: DC520000 057C0005
	v_add_nc_u32_e32 v6, 0x80, v4                              // 0000001482F8: 4A0C08FF 00000080
	s_or_b32 s6, vcc_lo, s6                                    // 000000148300: 8C06066A
	v_mov_b32_e32 v4, v6                                       // 000000148304: 7E080306
	s_waitcnt vmcnt(0)                                         // 000000148308: BF8903F7
	ds_store_b32 v7, v5                                        // 00000014830C: D8340000 00000507
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000148314: 917E067E
	s_cbranch_execnz 65513                                     // 000000148318: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000014831C: 8C7E067E
	s_load_b32 s40, s[0:1], 0x58                               // 000000148320: F4000A00 F8000058
	v_or_b32_e32 v75, 0xffffff80, v0                           // 000000148328: 389600FF FFFFFF80
	v_lshrrev_b32_e32 v1, 6, v0                                // 000000148330: 32020086
	s_mov_b32 s6, 0                                            // 000000148334: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000148338: BF89FC07
	s_barrier                                                  // 00000014833C: BFBD0000
	buffer_gl0_inv                                             // 000000148340: E0AC0000 00000000
	s_cmp_gt_i32 s40, 0                                        // 000000148348: BF028028
	s_cbranch_scc1 9                                           // 00000014834C: BFA20009 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x174>
	v_lshrrev_b32_e32 v68, 6, v0                               // 000000148350: 32880086
	v_or_b32_e32 v2, 0xffffff80, v0                            // 000000148354: 380400FF FFFFFF80
	v_mov_b32_e32 v69, 0                                       // 00000014835C: 7E8A0280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000148360: BF870003
	v_mov_b32_e32 v3, v68                                      // 000000148364: 7E060344
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000148368: 916A067E
	s_cbranch_vccz 1                                           // 00000014836C: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x174>
	s_branch 4332                                              // 000000148370: BFA010EC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4524>
	s_mov_b32 s25, 0                                           // 000000148374: BE990080
	v_lshrrev_b32_e32 v76, 5, v0                               // 000000148378: 32980085
	s_mov_b32 s24, s25                                         // 00000014837C: BE980019
	s_mov_b32 s26, s25                                         // 000000148380: BE9A0019
	s_mov_b32 s27, s25                                         // 000000148384: BE9B0019
	s_mov_b32 s28, s25                                         // 000000148388: BE9C0019
	s_mov_b32 s29, s25                                         // 00000014838C: BE9D0019
	s_mov_b32 s30, s25                                         // 000000148390: BE9E0019
	s_mov_b32 s31, s25                                         // 000000148394: BE9F0019
	v_lshlrev_b32_e32 v2, 2, v0                                // 000000148398: 30040082
	v_mul_u32_u24_e32 v7, 0xa00, v76                           // 00000014839C: 160E98FF 00000A00
	v_dual_mov_b32 v10, s24 :: v_dual_mov_b32 v11, s25         // 0000001483A4: CA100018 0A0A0019
	s_load_b64 s[0:1], s[0:1], 0x50                            // 0000001483AC: F4040000 F8000050
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001483B4: BF870003
	v_or_b32_e32 v77, 0xb600, v2                               // 0000001483B8: 389A04FF 0000B600
	v_dual_mov_b32 v13, s27 :: v_dual_add_nc_u32 v78, 0xb700, v2// 0000001483C0: CA20001B 0D4E04FF 0000B700
	v_dual_mov_b32 v15, s29 :: v_dual_lshlrev_b32 v2, 8, v0    // 0000001483CC: CA22001D 0F020088
	v_lshlrev_b32_e32 v3, 4, v76                               // 0000001483D4: 30069884
	v_and_b32_e32 v4, 15, v0                                   // 0000001483D8: 3608008F
	v_bfe_u32 v5, v0, 4, 1                                     // 0000001483DC: D6100005 02050900
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001483E4: BF8701A4
	v_dual_mov_b32 v17, s31 :: v_dual_and_b32 v2, 0xf00, v2    // 0000001483E8: CA24001F 110204FF 00000F00
	s_add_i32 s6, s40, 63                                      // 0000001483F4: 8106BF28
	v_or_b32_e32 v79, v3, v4                                   // 0000001483F8: 389E0903
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001483FC: BF870193
	v_or_b32_e32 v81, v3, v5                                   // 000000148400: 38A20B03
	v_lshl_or_b32 v3, v76, 12, v2                              // 000000148404: D6560003 0409194C
	v_mov_b32_e32 v2, 0                                        // 00000014840C: 7E040280
	s_lshr_b32 s41, s6, 6                                      // 000000148410: 85298606
	s_add_i32 s42, s2, 0xbd0                                   // 000000148414: 812AFF02 00000BD0
	s_movk_i32 s6, 0x210                                       // 00000014841C: B0060210
	s_add_u32 s8, s16, s38                                     // 000000148420: 80082610
	s_addc_u32 s9, s17, s39                                    // 000000148424: 82092711
	v_mov_b32_e32 v69, v2                                      // 000000148428: 7E8A0302
	v_mad_u32_u24 v80, v4, s6, 0x3200                          // 00000014842C: D60B0050 03FC0D04 00003200
	s_lshl_b32 s6, s2, 7                                       // 000000148438: 84068702
	v_lshlrev_b32_e32 v6, 2, v4                                // 00000014843C: 300C0882
	s_ashr_i32 s7, s6, 31                                      // 000000148440: 86079F06
	.long 0xd7000a52                                           // 000000148444: D7000A52
	v_cndmask_b32_e32 v1, s20, v3, vcc_lo                      // 000000148448: 02020614
	s_lshl_b64 s[6:7], s[6:7], 1                               // 00000014844C: 84868106
	v_mad_u32_u24 v3, 0x2100, v76, v80                         // 000000148450: D60B0003 054298FF 00002100
	s_waitcnt lgkmcnt(0)                                       // 00000014845C: BF89FC07
	s_add_u32 s6, s0, s6                                       // 000000148460: 80060600
	s_addc_u32 s7, s1, s7                                      // 000000148464: 82070701
	s_lshl_b64 s[0:1], s[4:5], 1                               // 000000148468: 84808104
	v_mul_u32_u24_e32 v84, 0xa0, v4                            // 00000014846C: 16A808FF 000000A0
	s_add_u32 s4, s6, s0                                       // 000000148474: 80040006
	s_movk_i32 s0, 0x2800                                      // 000000148478: B0002800
	s_addc_u32 s5, s7, s1                                      // 00000014847C: 82050107
	v_mad_u32_u24 v85, 0xa0, v4, s0                            // 000000148480: D60B0055 000208FF 000000A0
	.long 0xd7000057                                           // 00000014848C: D7000057
	v_cndmask_b32_e32 v1, s8, v6, vcc_lo                       // 000000148490: 02020C08
	s_delay_alu instid0(VALU_DEP_1)                            // 000000148494: BF870001
	v_add_co_ci_u32_e64 v88, null, s9, 0, s0                   // 000000148498: D5207C58 00010009
	s_lshl_b64 s[0:1], s[2:3], 9                               // 0000001484A0: 84808902
	v_lshl_or_b32 v86, v5, 2, v3                               // 0000001484A4: D6560056 040D0505
	v_dual_mov_b32 v68, v1 :: v_dual_lshlrev_b32 v5, 1, v4     // 0000001484AC: CA220101 44040881
	v_mad_u64_u32 v[3:4], null, 0x6000, v74, s[0:1]            // 0000001484B4: D6FE7C03 000294FF 00006000
	v_mul_u32_u24_e32 v6, 0xa0, v1                             // 0000001484C0: 160C02FF 000000A0
	v_add_co_ci_u32_e64 v83, null, s21, 0, s10                 // 0000001484C8: D5207C53 00290015
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001484D0: BF870094
	.long 0xd7000046                                           // 0000001484D4: D7000046
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000001484D8: 02020A04
	v_add_co_ci_u32_e64 v71, null, s5, 0, s0                   // 0000001484DC: D5207C47 00010005
	v_lshl_or_b32 v3, v1, 2, v3                                // 0000001484E4: D6560003 040D0501
	v_lshl_add_u32 v89, v81, 1, v84                            // 0000001484EC: D6460059 05510351
	v_lshl_or_b32 v90, v81, 2, 0xb700                          // 0000001484F4: D656005A 03FD0551 0000B700
	v_lshl_or_b32 v91, v74, 2, 0xb600                          // 000000148500: D656005B 03FD054A 0000B600
	v_lshl_add_u32 v92, v74, 1, v6                             // 00000014850C: D646005C 0419034A
	.long 0xd7000048                                           // 000000148514: D7000048
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                      // 000000148518: 0202060C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014851C: BF870001
	v_add_co_ci_u32_e64 v73, null, s13, v4, s0                 // 000000148520: D5207C49 0002080D
	v_mov_b32_e32 v12, s26                                     // 000000148528: 7E18021A
	v_mov_b32_e32 v14, s28                                     // 00000014852C: 7E1C021C
	v_dual_mov_b32 v16, s30 :: v_dual_add_nc_u32 v93, v84, v7  // 000000148530: CA20001E 105C0F54
	s_mov_b32 s12, 0x41800000                                  // 000000148538: BE8C00FF 41800000
	s_mov_b32 s13, 0                                           // 000000148540: BE8D0080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 000000148544: 7C9800C0
	s_branch 13                                                // 000000148548: BFA0000D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x380>
	.long 0xd7000048                                           // 00000014854C: D7000048
	v_cndmask_b32_e32 v1, 0x180000, v72, vcc_lo                // 000000148550: 020290FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000148558: BF870001
	v_add_co_ci_u32_e64 v73, null, 0, v73, s0                  // 00000014855C: D5207C49 00029280
	s_add_i32 s13, s13, 1                                      // 000000148564: 810D810D
	s_waitcnt lgkmcnt(0)                                       // 000000148568: BF89FC07
	s_cmp_eq_u32 s13, s41                                      // 00000014856C: BF06290D
	s_barrier                                                  // 000000148570: BFBD0000
	buffer_gl0_inv                                             // 000000148574: E0AC0000 00000000
	s_cbranch_scc1 4199                                        // 00000014857C: BFA21067 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x451c>
	s_mul_i32 s0, s13, 0xc00                                   // 000000148580: 9600FF0D 00000C00
	s_lshl_b32 s16, s13, 6                                     // 000000148588: 8410860D
	s_add_i32 s0, s42, s0                                      // 00000014858C: 8100002A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000148590: BF870499
	s_ashr_i32 s1, s0, 31                                      // 000000148594: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 000000148598: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014859C: BF870009
	s_add_u32 s0, s14, s0                                      // 0000001485A0: 8000000E
	s_addc_u32 s1, s15, s1                                     // 0000001485A4: 8201010F
	global_load_b32 v3, v2, s[0:1]                             // 0000001485A8: DC520000 03000002
	s_waitcnt vmcnt(0)                                         // 0000001485B0: BF8903F7
	v_readfirstlane_b32 s17, v3                                // 0000001485B4: 7E220503
	s_and_saveexec_b32 s1, vcc_lo                              // 0000001485B8: BE81206A
	s_cbranch_execz 77                                         // 0000001485BC: BFA5004D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f4>
	v_or_b32_e32 v3, s16, v0                                   // 0000001485C0: 38060010
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001485C4: BF870091
	v_mad_u64_u32 v[3:4], null, v3, 48, s[2:3]                 // 0000001485C8: D6FE7C03 00096103
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000001485D0: 3408069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001485D4: BF870091
	.long 0xd73c0003                                           // 0000001485D8: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 0000001485DC: 02020682
	.long 0xd7000003                                           // 0000001485E0: D7000003
	v_cndmask_b32_e32 v1, s14, v3, vcc_lo                      // 0000001485E4: 0202060E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001485E8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, s15, v4, s0                  // 0000001485EC: D5207C04 0002080F
	global_load_b32 v3, v[3:4], off                            // 0000001485F4: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000001485FC: BF8903F7
	v_sub_f32_e32 v4, s17, v3                                  // 000000148600: 08080611
	v_dual_mul_f32 v6, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, 0x3fb8aa3b, v4// 000000148604: C8C606FF 060408FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000148610: BF8701A1
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v6                          // 000000148614: D6130009 841A06FF 3FB8AA3B
	v_rndne_f32_e32 v18, v6                                    // 000000148620: 7E244706
	v_fma_f32 v7, 0x3fb8aa3b, v4, -v5                          // 000000148624: D6130007 841608FF 3FB8AA3B
	v_rndne_f32_e32 v8, v5                                     // 000000148630: 7E104705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000148634: BF870113
	v_dual_fmac_f32 v9, 0x32a5705f, v3 :: v_dual_sub_f32 v6, v6, v18// 000000148638: C80A06FF 09062506 32A5705F
	v_sub_f32_e32 v5, v5, v8                                   // 000000148644: 080A1105
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000148648: BF870124
	v_fmac_f32_e32 v7, 0x32a5705f, v4                          // 00000014864C: 560E08FF 32A5705F
	.long 0xd41b0000                                           // 000000148654: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v4, vcc_lo               // 000000148658: 020208FF C2CE8ED0
	v_dual_add_f32 v6, v6, v9 :: v_dual_add_f32 v5, v5, v7     // 000000148660: C9081306 06040F05
	v_cvt_i32_f32_e32 v7, v8                                   // 000000148668: 7E0E1108
	v_cvt_i32_f32_e32 v8, v18                                  // 00000014866C: 7E101112
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000148670: BF870193
	v_exp_f32_e32 v6, v6                                       // 000000148674: 7E0C4B06
	v_exp_f32_e32 v5, v5                                       // 000000148678: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014867C: BF870296
	.long 0xd71c0006                                           // 000000148680: D71C0006
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 000000148684: 02021106
	.long 0xd71c0005                                           // 000000148688: D71C0005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000014868C: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000148690: BF8700A1
	v_cndmask_b32_e64 v5, 0, v5, s0                            // 000000148694: D5010005 00020A80
	.long 0xd41b0000                                           // 00000014869C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v3, vcc_lo               // 0000001486A0: 020206FF C2CE8ED0
	v_cndmask_b32_e64 v6, 0, v6, s0                            // 0000001486A8: D5010006 00020C80
	.long 0xd41e0000                                           // 0000001486B0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v4, vcc_lo               // 0000001486B4: 020208FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001486BC: BF8700A1
	v_cndmask_b32_e64 v4, 0x7f800000, v5, s0                   // 0000001486C0: D5010004 00020AFF 7F800000
	.long 0xd41e0000                                           // 0000001486CC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v3, vcc_lo               // 0000001486D0: 020206FF 42B17218
	v_cndmask_b32_e64 v3, 0x7f800000, v6, s0                   // 0000001486D8: D5010003 00020CFF 7F800000
	ds_store_b32 v77, v4                                       // 0000001486E4: D8340000 0000044D
	ds_store_b32 v78, v3                                       // 0000001486EC: D8340000 0000034E
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001486F4: 8C7E017E
	v_add_nc_u32_e32 v5, s16, v79                              // 0000001486F8: 4A0A9E10
	.long 0x7f7a3880                                           // 0000001486FC: 7F7A3880
	s_waitcnt lgkmcnt(0)                                       // 000000148700: BF89FC07
	s_barrier                                                  // 000000148704: BFBD0000
	buffer_gl0_inv                                             // 000000148708: E0AC0000 00000000
	v_mad_u64_u32 v[3:4], null, v5, 48, s[2:3]                 // 000000148710: D6FE7C03 00096105
	.long 0xd4440000                                           // 000000148718: D4440000
	v_cndmask_b32_e32 v1, s40, v5, vcc_lo                      // 00000014871C: 02020A28
	.long 0x7f7639bd                                           // 000000148720: 7F7639BD
	.long 0x7e7639bd                                           // 000000148724: 7E7639BD
	.long 0x7f7439bd                                           // 000000148728: 7F7439BD
	.long 0x7e7439bd                                           // 00000014872C: 7E7439BD
	.long 0xd73c0003                                           // 000000148730: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000148734: 02020689
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000148738: BF870091
	.long 0xd7000103                                           // 00000014873C: D7000103
	v_cndmask_b32_e32 v1, s18, v3, vcc_lo                      // 000000148740: 02020612
	v_add_co_ci_u32_e64 v4, null, s19, v4, s1                  // 000000148744: D5207C04 00060813
	s_and_saveexec_b32 s1, s0                                  // 00000014874C: BE812000
	s_cbranch_execz 11                                         // 000000148750: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	global_load_b128 v[5:8], v[3:4], off                       // 000000148754: DC5E0000 057C0003
	s_waitcnt vmcnt(0)                                         // 00000014875C: BF8903F7
	v_fma_mixlo_f16 v58, v5, s12, 0                            // 000000148760: CC21003A 02001905
	v_fma_mixhi_f16 v58, v6, s12, 0                            // 000000148768: CC22003A 02001906
	v_fma_mixlo_f16 v59, v7, s12, 0                            // 000000148770: CC21003B 02001907
	v_fma_mixhi_f16 v59, v8, s12, 0                            // 000000148778: CC22003B 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000148780: 8C7E017E
	.long 0x7e7a39bd                                           // 000000148784: 7E7A39BD
	.long 0x7f7839bd                                           // 000000148788: 7F7839BD
	.long 0x7e7839bd                                           // 00000014878C: 7E7839BD
	s_and_saveexec_b32 s1, s0                                  // 000000148790: BE812000
	s_cbranch_execz 11                                         // 000000148794: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c4>
	global_load_b128 v[5:8], v[3:4], off offset:16             // 000000148798: DC5E0010 057C0003
	s_waitcnt vmcnt(0)                                         // 0000001487A0: BF8903F7
	v_fma_mixlo_f16 v60, v5, s12, 0                            // 0000001487A4: CC21003C 02001905
	v_fma_mixhi_f16 v60, v6, s12, 0                            // 0000001487AC: CC22003C 02001906
	v_fma_mixlo_f16 v61, v7, s12, 0                            // 0000001487B4: CC21003D 02001907
	v_fma_mixhi_f16 v61, v8, s12, 0                            // 0000001487BC: CC22003D 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001487C4: 8C7E017E
	.long 0x7f823880                                           // 0000001487C8: 7F823880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001487CC: BF870001
	.long 0x7f7e39c1                                           // 0000001487D0: 7F7E39C1
	.long 0x7e7e39c1                                           // 0000001487D4: 7E7E39C1
	.long 0x7f7c39c1                                           // 0000001487D8: 7F7C39C1
	.long 0x7e7c39c1                                           // 0000001487DC: 7E7C39C1
	s_and_saveexec_b32 s1, s0                                  // 0000001487E0: BE812000
	s_cbranch_execz 11                                         // 0000001487E4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x614>
	global_load_b128 v[5:8], v[3:4], off offset:32             // 0000001487E8: DC5E0020 057C0003
	s_waitcnt vmcnt(0)                                         // 0000001487F0: BF8903F7
	v_fma_mixlo_f16 v62, v5, s12, 0                            // 0000001487F4: CC21003E 02001905
	v_fma_mixhi_f16 v62, v6, s12, 0                            // 0000001487FC: CC22003E 02001906
	v_fma_mixlo_f16 v63, v7, s12, 0                            // 000000148804: CC21003F 02001907
	v_fma_mixhi_f16 v63, v8, s12, 0                            // 00000014880C: CC22003F 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000148814: 8C7E017E
	.long 0x7e8239c1                                           // 000000148818: 7E8239C1
	.long 0x7f8039c1                                           // 00000014881C: 7F8039C1
	.long 0x7e8039c1                                           // 000000148820: 7E8039C1
	s_and_saveexec_b32 s1, s0                                  // 000000148824: BE812000
	s_cbranch_execz 11                                         // 000000148828: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x658>
	global_load_b128 v[5:8], v[3:4], off offset:48             // 00000014882C: DC5E0030 057C0003
	s_waitcnt vmcnt(0)                                         // 000000148834: BF8903F7
	v_fma_mixlo_f16 v64, v5, s12, 0                            // 000000148838: CC210040 02001905
	v_fma_mixhi_f16 v64, v6, s12, 0                            // 000000148840: CC220040 02001906
	v_fma_mixlo_f16 v65, v7, s12, 0                            // 000000148848: CC210041 02001907
	v_fma_mixhi_f16 v65, v8, s12, 0                            // 000000148850: CC220041 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000148858: 8C7E017E
	ds_load_b128 v[5:8], v80                                   // 00000014885C: DBFC0000 05000050
	ds_load_b128 v[20:23], v80 offset:16                       // 000000148864: DBFC0010 14000050
	ds_load_b128 v[24:27], v80 offset:32                       // 00000014886C: DBFC0020 18000050
	ds_load_b128 v[28:31], v80 offset:48                       // 000000148874: DBFC0030 1C000050
	ds_load_b128 v[32:35], v80 offset:8448                     // 00000014887C: DBFC2100 20000050
	ds_load_b128 v[36:39], v80 offset:8464                     // 000000148884: DBFC2110 24000050
	ds_load_b128 v[40:43], v80 offset:8480                     // 00000014888C: DBFC2120 28000050
	ds_load_b128 v[44:47], v80 offset:8496                     // 000000148894: DBFC2130 2C000050
	ds_load_b128 v[54:57], v80 offset:16928                    // 00000014889C: DBFC4220 36000050
	ds_load_b128 v[94:97], v80 offset:16944                    // 0000001488A4: DBFC4230 5E000050
	ds_load_b128 v[50:53], v80 offset:16912                    // 0000001488AC: DBFC4210 32000050
	s_waitcnt lgkmcnt(10)                                      // 0000001488B4: BF89FCA7
	v_fma_mixlo_f16 v18, v5, s12, 0                            // 0000001488B8: CC210012 02001905
	v_fma_mixhi_f16 v18, v6, s12, 0                            // 0000001488C0: CC220012 02001906
	v_fma_mixlo_f16 v19, v7, s12, 0                            // 0000001488C8: CC210013 02001907
	v_fma_mixhi_f16 v19, v8, s12, 0                            // 0000001488D0: CC220013 02001908
	ds_load_b128 v[5:8], v80 offset:16896                      // 0000001488D8: DBFC4200 05000050
	s_waitcnt lgkmcnt(10)                                      // 0000001488E0: BF89FCA7
	v_fma_mixlo_f16 v20, v20, s12, 0                           // 0000001488E4: CC210014 02001914
	v_fma_mixhi_f16 v20, v21, s12, 0                           // 0000001488EC: CC220014 02001915
	v_fma_mixlo_f16 v21, v22, s12, 0                           // 0000001488F4: CC210015 02001916
	v_fma_mixhi_f16 v21, v23, s12, 0                           // 0000001488FC: CC220015 02001917
	s_waitcnt lgkmcnt(9)                                       // 000000148904: BF89FC97
	v_fma_mixlo_f16 v22, v24, s12, 0                           // 000000148908: CC210016 02001918
	v_fma_mixhi_f16 v22, v25, s12, 0                           // 000000148910: CC220016 02001919
	v_fma_mixlo_f16 v23, v26, s12, 0                           // 000000148918: CC210017 0200191A
	v_fma_mixhi_f16 v23, v27, s12, 0                           // 000000148920: CC220017 0200191B
	s_waitcnt lgkmcnt(8)                                       // 000000148928: BF89FC87
	v_fma_mixlo_f16 v24, v28, s12, 0                           // 00000014892C: CC210018 0200191C
	v_fma_mixhi_f16 v24, v29, s12, 0                           // 000000148934: CC220018 0200191D
	v_fma_mixlo_f16 v25, v30, s12, 0                           // 00000014893C: CC210019 0200191E
	v_fma_mixhi_f16 v25, v31, s12, 0                           // 000000148944: CC220019 0200191F
	s_waitcnt lgkmcnt(7)                                       // 00000014894C: BF89FC77
	v_fma_mixlo_f16 v26, v32, s12, 0                           // 000000148950: CC21001A 02001920
	v_fma_mixhi_f16 v26, v33, s12, 0                           // 000000148958: CC22001A 02001921
	v_fma_mixlo_f16 v27, v34, s12, 0                           // 000000148960: CC21001B 02001922
	v_fma_mixhi_f16 v27, v35, s12, 0                           // 000000148968: CC22001B 02001923
	s_waitcnt lgkmcnt(6)                                       // 000000148970: BF89FC67
	v_fma_mixlo_f16 v28, v36, s12, 0                           // 000000148974: CC21001C 02001924
	v_fma_mixhi_f16 v28, v37, s12, 0                           // 00000014897C: CC22001C 02001925
	v_fma_mixlo_f16 v29, v38, s12, 0                           // 000000148984: CC21001D 02001926
	v_fma_mixhi_f16 v29, v39, s12, 0                           // 00000014898C: CC22001D 02001927
	s_waitcnt lgkmcnt(5)                                       // 000000148994: BF89FC57
	v_fma_mixlo_f16 v30, v40, s12, 0                           // 000000148998: CC21001E 02001928
	v_fma_mixhi_f16 v30, v41, s12, 0                           // 0000001489A0: CC22001E 02001929
	v_fma_mixlo_f16 v31, v42, s12, 0                           // 0000001489A8: CC21001F 0200192A
	v_fma_mixhi_f16 v31, v43, s12, 0                           // 0000001489B0: CC22001F 0200192B
	s_waitcnt lgkmcnt(4)                                       // 0000001489B8: BF89FC47
	v_fma_mixlo_f16 v32, v44, s12, 0                           // 0000001489BC: CC210020 0200192C
	v_fma_mixhi_f16 v32, v45, s12, 0                           // 0000001489C4: CC220020 0200192D
	v_fma_mixlo_f16 v33, v46, s12, 0                           // 0000001489CC: CC210021 0200192E
	v_fma_mixhi_f16 v33, v47, s12, 0                           // 0000001489D4: CC220021 0200192F
	v_wmma_f32_16x16x16_f16 v[42:49], v[58:65], v[18:25], v[10:17]// 0000001489DC: CC40402A 1C2A253A
	s_waitcnt lgkmcnt(0)                                       // 0000001489E4: BF89FC07
	v_fma_mixlo_f16 v18, v5, s12, 0                            // 0000001489E8: CC210012 02001905
	v_fma_mixhi_f16 v18, v6, s12, 0                            // 0000001489F0: CC220012 02001906
	v_wmma_f32_16x16x16_f16 v[34:41], v[58:65], v[26:33], v[10:17]// 0000001489F8: CC404022 1C2A353A
	ds_load_b128 v[26:29], v80 offset:25344                    // 000000148A00: DBFC6300 1A000050
	ds_load_b128 v[30:33], v80 offset:25360                    // 000000148A08: DBFC6310 1E000050
	v_fma_mixlo_f16 v19, v7, s12, 0                            // 000000148A10: CC210013 02001907
	v_fma_mixhi_f16 v19, v8, s12, 0                            // 000000148A18: CC220013 02001908
	v_fma_mixlo_f16 v20, v50, s12, 0                           // 000000148A20: CC210014 02001932
	v_fma_mixhi_f16 v20, v51, s12, 0                           // 000000148A28: CC220014 02001933
	ds_load_b128 v[5:8], v80 offset:25376                      // 000000148A30: DBFC6320 05000050
	v_fma_mixlo_f16 v21, v52, s12, 0                           // 000000148A38: CC210015 02001934
	v_fma_mixhi_f16 v21, v53, s12, 0                           // 000000148A40: CC220015 02001935
	ds_load_b128 v[50:53], v80 offset:25392                    // 000000148A48: DBFC6330 32000050
	v_fma_mixlo_f16 v22, v54, s12, 0                           // 000000148A50: CC210016 02001936
	v_fma_mixhi_f16 v22, v55, s12, 0                           // 000000148A58: CC220016 02001937
	v_fma_mixlo_f16 v23, v56, s12, 0                           // 000000148A60: CC210017 02001938
	v_fma_mixhi_f16 v23, v57, s12, 0                           // 000000148A68: CC220017 02001939
	v_fma_mixlo_f16 v24, v94, s12, 0                           // 000000148A70: CC210018 0200195E
	v_fma_mixhi_f16 v24, v95, s12, 0                           // 000000148A78: CC220018 0200195F
	v_fma_mixlo_f16 v25, v96, s12, 0                           // 000000148A80: CC210019 02001960
	v_fma_mixhi_f16 v25, v97, s12, 0                           // 000000148A88: CC220019 02001961
	.long 0x7f723880                                           // 000000148A90: 7F723880
	s_waitcnt lgkmcnt(3)                                       // 000000148A94: BF89FC37
	v_fma_mixlo_f16 v94, v26, s12, 0                           // 000000148A98: CC21005E 0200191A
	v_fma_mixhi_f16 v94, v27, s12, 0                           // 000000148AA0: CC22005E 0200191B
	v_fma_mixlo_f16 v95, v28, s12, 0                           // 000000148AA8: CC21005F 0200191C
	v_fma_mixhi_f16 v95, v29, s12, 0                           // 000000148AB0: CC22005F 0200191D
	s_waitcnt lgkmcnt(2)                                       // 000000148AB8: BF89FC27
	v_fma_mixlo_f16 v96, v30, s12, 0                           // 000000148ABC: CC210060 0200191E
	v_fma_mixhi_f16 v96, v31, s12, 0                           // 000000148AC4: CC220060 0200191F
	v_fma_mixlo_f16 v97, v32, s12, 0                           // 000000148ACC: CC210061 02001920
	v_fma_mixhi_f16 v97, v33, s12, 0                           // 000000148AD4: CC220061 02001921
	s_waitcnt lgkmcnt(1)                                       // 000000148ADC: BF89FC17
	v_fma_mixlo_f16 v98, v5, s12, 0                            // 000000148AE0: CC210062 02001905
	v_fma_mixhi_f16 v98, v6, s12, 0                            // 000000148AE8: CC220062 02001906
	v_fma_mixlo_f16 v99, v7, s12, 0                            // 000000148AF0: CC210063 02001907
	v_fma_mixhi_f16 v99, v8, s12, 0                            // 000000148AF8: CC220063 02001908
	s_waitcnt lgkmcnt(0)                                       // 000000148B00: BF89FC07
	v_fma_mixlo_f16 v100, v50, s12, 0                          // 000000148B04: CC210064 02001932
	v_fma_mixhi_f16 v100, v51, s12, 0                          // 000000148B0C: CC220064 02001933
	v_fma_mixlo_f16 v101, v52, s12, 0                          // 000000148B14: CC210065 02001934
	v_fma_mixhi_f16 v101, v53, s12, 0                          // 000000148B1C: CC220065 02001935
	v_wmma_f32_16x16x16_f16 v[26:33], v[58:65], v[18:25], v[10:17]// 000000148B24: CC40401A 1C2A253A
	.long 0x7f6e39b9                                           // 000000148B2C: 7F6E39B9
	.long 0x7e6e39b9                                           // 000000148B30: 7E6E39B9
	s_delay_alu instid0(VALU_DEP_4)                            // 000000148B34: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[58:65], v[94:101], v[10:17]// 000000148B38: CC404012 1C2ABD3A
	.long 0x7f6c39b9                                           // 000000148B40: 7F6C39B9
	.long 0x7e6c39b9                                           // 000000148B44: 7E6C39B9
	s_and_saveexec_b32 s1, s0                                  // 000000148B48: BE812000
	s_cbranch_execz 11                                         // 000000148B4C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x97c>
	global_load_b128 v[5:8], v[3:4], off offset:64             // 000000148B50: DC5E0040 057C0003
	s_waitcnt vmcnt(0)                                         // 000000148B58: BF8903F7
	v_fma_mixlo_f16 v54, v5, s12, 0                            // 000000148B5C: CC210036 02001905
	v_fma_mixhi_f16 v54, v6, s12, 0                            // 000000148B64: CC220036 02001906
	v_fma_mixlo_f16 v55, v7, s12, 0                            // 000000148B6C: CC210037 02001907
	v_fma_mixhi_f16 v55, v8, s12, 0                            // 000000148B74: CC220037 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000148B7C: 8C7E017E
	.long 0x7e7239b9                                           // 000000148B80: 7E7239B9
	.long 0x7f7039b9                                           // 000000148B84: 7F7039B9
	.long 0x7e7039b9                                           // 000000148B88: 7E7039B9
	s_and_saveexec_b32 s1, s0                                  // 000000148B8C: BE812000
	s_cbranch_execz 11                                         // 000000148B90: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x9c0>
	global_load_b128 v[5:8], v[3:4], off offset:80             // 000000148B94: DC5E0050 057C0003
	s_waitcnt vmcnt(0)                                         // 000000148B9C: BF8903F7
	v_fma_mixlo_f16 v56, v5, s12, 0                            // 000000148BA0: CC210038 02001905
	v_fma_mixhi_f16 v56, v6, s12, 0                            // 000000148BA8: CC220038 02001906
	v_fma_mixlo_f16 v57, v7, s12, 0                            // 000000148BB0: CC210039 02001907
	v_fma_mixhi_f16 v57, v8, s12, 0                            // 000000148BB8: CC220039 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000148BC0: 8C7E017E
	.long 0x7f7a3880                                           // 000000148BC4: 7F7A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000148BC8: BF870001
	.long 0x7f7639bd                                           // 000000148BCC: 7F7639BD
	.long 0x7e7639bd                                           // 000000148BD0: 7E7639BD
	.long 0x7f7439bd                                           // 000000148BD4: 7F7439BD
	.long 0x7e7439bd                                           // 000000148BD8: 7E7439BD
	s_and_saveexec_b32 s1, s0                                  // 000000148BDC: BE812000
	s_cbranch_execz 11                                         // 000000148BE0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa10>
	global_load_b128 v[5:8], v[3:4], off offset:96             // 000000148BE4: DC5E0060 057C0003
	s_waitcnt vmcnt(0)                                         // 000000148BEC: BF8903F7
	v_fma_mixlo_f16 v58, v5, s12, 0                            // 000000148BF0: CC21003A 02001905
	v_fma_mixhi_f16 v58, v6, s12, 0                            // 000000148BF8: CC22003A 02001906
	v_fma_mixlo_f16 v59, v7, s12, 0                            // 000000148C00: CC21003B 02001907
	v_fma_mixhi_f16 v59, v8, s12, 0                            // 000000148C08: CC22003B 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000148C10: 8C7E017E
	.long 0x7e7a39bd                                           // 000000148C14: 7E7A39BD
	.long 0x7f7839bd                                           // 000000148C18: 7F7839BD
	.long 0x7e7839bd                                           // 000000148C1C: 7E7839BD
	s_and_saveexec_b32 s1, s0                                  // 000000148C20: BE812000
	s_cbranch_execz 11                                         // 000000148C24: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa54>
	global_load_b128 v[5:8], v[3:4], off offset:112            // 000000148C28: DC5E0070 057C0003
	s_waitcnt vmcnt(0)                                         // 000000148C30: BF8903F7
	v_fma_mixlo_f16 v60, v5, s12, 0                            // 000000148C34: CC21003C 02001905
	v_fma_mixhi_f16 v60, v6, s12, 0                            // 000000148C3C: CC22003C 02001906
	v_fma_mixlo_f16 v61, v7, s12, 0                            // 000000148C44: CC21003D 02001907
	v_fma_mixhi_f16 v61, v8, s12, 0                            // 000000148C4C: CC22003D 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000148C54: 8C7E017E
	ds_load_b128 v[5:8], v80 offset:64                         // 000000148C58: DBFC0040 05000050
	ds_load_b128 v[50:53], v80 offset:80                       // 000000148C60: DBFC0050 32000050
	ds_load_b128 v[62:65], v80 offset:96                       // 000000148C68: DBFC0060 3E000050
	ds_load_b128 v[100:103], v80 offset:112                    // 000000148C70: DBFC0070 64000050
	ds_load_b128 v[104:107], v80 offset:8512                   // 000000148C78: DBFC2140 68000050
	ds_load_b128 v[108:111], v80 offset:8528                   // 000000148C80: DBFC2150 6C000050
	ds_load_b128 v[112:115], v80 offset:8544                   // 000000148C88: DBFC2160 70000050
	ds_load_b128 v[116:119], v80 offset:8560                   // 000000148C90: DBFC2170 74000050
	ds_load_b128 v[124:127], v80 offset:25408                  // 000000148C98: DBFC6340 7C000050
	ds_load_b128 v[128:131], v80 offset:25424                  // 000000148CA0: DBFC6350 80000050
	ds_load_b128 v[120:123], v80 offset:17008                  // 000000148CA8: DBFC4270 78000050
	s_waitcnt lgkmcnt(10)                                      // 000000148CB0: BF89FCA7
	v_fma_mixlo_f16 v94, v5, s12, 0                            // 000000148CB4: CC21005E 02001905
	v_fma_mixhi_f16 v94, v6, s12, 0                            // 000000148CBC: CC22005E 02001906
	v_fma_mixlo_f16 v95, v7, s12, 0                            // 000000148CC4: CC21005F 02001907
	v_fma_mixhi_f16 v95, v8, s12, 0                            // 000000148CCC: CC22005F 02001908
	s_waitcnt lgkmcnt(9)                                       // 000000148CD4: BF89FC97
	v_fma_mixlo_f16 v96, v50, s12, 0                           // 000000148CD8: CC210060 02001932
	v_fma_mixhi_f16 v96, v51, s12, 0                           // 000000148CE0: CC220060 02001933
	v_fma_mixlo_f16 v97, v52, s12, 0                           // 000000148CE8: CC210061 02001934
	v_fma_mixhi_f16 v97, v53, s12, 0                           // 000000148CF0: CC220061 02001935
	ds_load_b128 v[5:8], v80 offset:16960                      // 000000148CF8: DBFC4240 05000050
	ds_load_b128 v[50:53], v80 offset:16976                    // 000000148D00: DBFC4250 32000050
	s_waitcnt lgkmcnt(10)                                      // 000000148D08: BF89FCA7
	v_fma_mixlo_f16 v98, v62, s12, 0                           // 000000148D0C: CC210062 0200193E
	v_fma_mixhi_f16 v98, v63, s12, 0                           // 000000148D14: CC220062 0200193F
	v_fma_mixlo_f16 v99, v64, s12, 0                           // 000000148D1C: CC210063 02001940
	v_fma_mixhi_f16 v99, v65, s12, 0                           // 000000148D24: CC220063 02001941
	s_waitcnt lgkmcnt(9)                                       // 000000148D2C: BF89FC97
	v_fma_mixlo_f16 v100, v100, s12, 0                         // 000000148D30: CC210064 02001964
	v_fma_mixhi_f16 v100, v101, s12, 0                         // 000000148D38: CC220064 02001965
	v_fma_mixlo_f16 v101, v102, s12, 0                         // 000000148D40: CC210065 02001966
	v_fma_mixhi_f16 v101, v103, s12, 0                         // 000000148D48: CC220065 02001967
	s_waitcnt lgkmcnt(8)                                       // 000000148D50: BF89FC87
	v_fma_mixhi_f16 v102, v105, s12, 0                         // 000000148D54: CC220066 02001969
	v_fma_mixlo_f16 v103, v106, s12, 0                         // 000000148D5C: CC210067 0200196A
	s_waitcnt lgkmcnt(7)                                       // 000000148D64: BF89FC77
	v_fma_mixlo_f16 v105, v110, s12, 0                         // 000000148D68: CC210069 0200196E
	v_fma_mixhi_f16 v105, v111, s12, 0                         // 000000148D70: CC220069 0200196F
	s_waitcnt lgkmcnt(6)                                       // 000000148D78: BF89FC67
	v_fma_mixlo_f16 v106, v112, s12, 0                         // 000000148D7C: CC21006A 02001970
	ds_load_b128 v[62:65], v80 offset:16992                    // 000000148D84: DBFC4260 3E000050
	v_fma_mixhi_f16 v106, v113, s12, 0                         // 000000148D8C: CC22006A 02001971
	v_fma_mixlo_f16 v102, v104, s12, 0                         // 000000148D94: CC210066 02001968
	v_fma_mixhi_f16 v103, v107, s12, 0                         // 000000148D9C: CC220067 0200196B
	v_fma_mixlo_f16 v104, v108, s12, 0                         // 000000148DA4: CC210068 0200196C
	s_waitcnt lgkmcnt(2)                                       // 000000148DAC: BF89FC27
	v_fma_mixlo_f16 v110, v5, s12, 0                           // 000000148DB0: CC21006E 02001905
	v_fma_mixhi_f16 v110, v6, s12, 0                           // 000000148DB8: CC22006E 02001906
	v_fma_mixlo_f16 v111, v7, s12, 0                           // 000000148DC0: CC21006F 02001907
	v_fma_mixhi_f16 v111, v8, s12, 0                           // 000000148DC8: CC22006F 02001908
	s_waitcnt lgkmcnt(1)                                       // 000000148DD0: BF89FC17
	v_fma_mixlo_f16 v112, v50, s12, 0                          // 000000148DD4: CC210070 02001932
	v_fma_mixhi_f16 v112, v51, s12, 0                          // 000000148DDC: CC220070 02001933
	ds_load_b128 v[5:8], v80 offset:25440                      // 000000148DE4: DBFC6360 05000050
	v_fma_mixlo_f16 v113, v52, s12, 0                          // 000000148DEC: CC210071 02001934
	v_fma_mixhi_f16 v113, v53, s12, 0                          // 000000148DF4: CC220071 02001935
	ds_load_b128 v[50:53], v80 offset:25456                    // 000000148DFC: DBFC6370 32000050
	v_fma_mixhi_f16 v104, v109, s12, 0                         // 000000148E04: CC220068 0200196D
	v_fma_mixlo_f16 v107, v114, s12, 0                         // 000000148E0C: CC21006B 02001972
	v_fma_mixhi_f16 v107, v115, s12, 0                         // 000000148E14: CC22006B 02001973
	v_fma_mixlo_f16 v108, v116, s12, 0                         // 000000148E1C: CC21006C 02001974
	v_fma_mixhi_f16 v108, v117, s12, 0                         // 000000148E24: CC22006C 02001975
	v_fma_mixlo_f16 v109, v118, s12, 0                         // 000000148E2C: CC21006D 02001976
	v_fma_mixhi_f16 v109, v119, s12, 0                         // 000000148E34: CC22006D 02001977
	s_waitcnt lgkmcnt(2)                                       // 000000148E3C: BF89FC27
	v_fma_mixlo_f16 v114, v62, s12, 0                          // 000000148E40: CC210072 0200193E
	v_fma_mixhi_f16 v114, v63, s12, 0                          // 000000148E48: CC220072 0200193F
	v_fma_mixlo_f16 v115, v64, s12, 0                          // 000000148E50: CC210073 02001940
	v_fma_mixhi_f16 v115, v65, s12, 0                          // 000000148E58: CC220073 02001941
	v_fma_mixlo_f16 v116, v120, s12, 0                         // 000000148E60: CC210074 02001978
	v_fma_mixhi_f16 v116, v121, s12, 0                         // 000000148E68: CC220074 02001979
	v_fma_mixlo_f16 v117, v122, s12, 0                         // 000000148E70: CC210075 0200197A
	v_fma_mixhi_f16 v117, v123, s12, 0                         // 000000148E78: CC220075 0200197B
	v_fma_mixlo_f16 v118, v124, s12, 0                         // 000000148E80: CC210076 0200197C
	v_fma_mixhi_f16 v118, v125, s12, 0                         // 000000148E88: CC220076 0200197D
	v_fma_mixlo_f16 v119, v126, s12, 0                         // 000000148E90: CC210077 0200197E
	v_fma_mixhi_f16 v119, v127, s12, 0                         // 000000148E98: CC220077 0200197F
	v_fma_mixlo_f16 v120, v128, s12, 0                         // 000000148EA0: CC210078 02001980
	v_fma_mixhi_f16 v120, v129, s12, 0                         // 000000148EA8: CC220078 02001981
	v_fma_mixlo_f16 v121, v130, s12, 0                         // 000000148EB0: CC210079 02001982
	v_fma_mixhi_f16 v121, v131, s12, 0                         // 000000148EB8: CC220079 02001983
	s_waitcnt lgkmcnt(1)                                       // 000000148EC0: BF89FC17
	v_fma_mixlo_f16 v122, v5, s12, 0                           // 000000148EC4: CC21007A 02001905
	v_fma_mixhi_f16 v122, v6, s12, 0                           // 000000148ECC: CC22007A 02001906
	v_fma_mixlo_f16 v123, v7, s12, 0                           // 000000148ED4: CC21007B 02001907
	v_fma_mixhi_f16 v123, v8, s12, 0                           // 000000148EDC: CC22007B 02001908
	s_waitcnt lgkmcnt(0)                                       // 000000148EE4: BF89FC07
	v_fma_mixlo_f16 v124, v50, s12, 0                          // 000000148EE8: CC21007C 02001932
	v_fma_mixhi_f16 v124, v51, s12, 0                          // 000000148EF0: CC22007C 02001933
	v_fma_mixlo_f16 v125, v52, s12, 0                          // 000000148EF8: CC21007D 02001934
	v_fma_mixhi_f16 v125, v53, s12, 0                          // 000000148F00: CC22007D 02001935
	.long 0x7f6a3880                                           // 000000148F08: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[54:61], v[94:101], v[42:49]// 000000148F0C: CC40402A 1CAABD36
	v_wmma_f32_16x16x16_f16 v[34:41], v[54:61], v[102:109], v[34:41]// 000000148F14: CC404022 1C8ACD36
	v_wmma_f32_16x16x16_f16 v[26:33], v[54:61], v[110:117], v[26:33]// 000000148F1C: CC40401A 1C6ADD36
	v_wmma_f32_16x16x16_f16 v[18:25], v[54:61], v[118:125], v[18:25]// 000000148F24: CC404012 1C4AED36
	.long 0x7f6639b5                                           // 000000148F2C: 7F6639B5
	.long 0x7e6639b5                                           // 000000148F30: 7E6639B5
	.long 0x7f6439b5                                           // 000000148F34: 7F6439B5
	.long 0x7e6439b5                                           // 000000148F38: 7E6439B5
	s_and_saveexec_b32 s1, s0                                  // 000000148F3C: BE812000
	s_cbranch_execz 11                                         // 000000148F40: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd70>
	global_load_b128 v[5:8], v[3:4], off offset:128            // 000000148F44: DC5E0080 057C0003
	s_waitcnt vmcnt(0)                                         // 000000148F4C: BF8903F7
	v_fma_mixlo_f16 v50, v5, s12, 0                            // 000000148F50: CC210032 02001905
	v_fma_mixhi_f16 v50, v6, s12, 0                            // 000000148F58: CC220032 02001906
	v_fma_mixlo_f16 v51, v7, s12, 0                            // 000000148F60: CC210033 02001907
	v_fma_mixhi_f16 v51, v8, s12, 0                            // 000000148F68: CC220033 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000148F70: 8C7E017E
	.long 0x7e6a39b5                                           // 000000148F74: 7E6A39B5
	.long 0x7f6839b5                                           // 000000148F78: 7F6839B5
	.long 0x7e6839b5                                           // 000000148F7C: 7E6839B5
	s_and_saveexec_b32 s1, s0                                  // 000000148F80: BE812000
	s_cbranch_execz 11                                         // 000000148F84: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xdb4>
	global_load_b128 v[5:8], v[3:4], off offset:144            // 000000148F88: DC5E0090 057C0003
	s_waitcnt vmcnt(0)                                         // 000000148F90: BF8903F7
	v_fma_mixlo_f16 v52, v5, s12, 0                            // 000000148F94: CC210034 02001905
	v_fma_mixhi_f16 v52, v6, s12, 0                            // 000000148F9C: CC220034 02001906
	v_fma_mixlo_f16 v53, v7, s12, 0                            // 000000148FA4: CC210035 02001907
	v_fma_mixhi_f16 v53, v8, s12, 0                            // 000000148FAC: CC220035 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000148FB4: 8C7E017E
	.long 0x7f723880                                           // 000000148FB8: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000148FBC: BF870001
	.long 0x7f6e39b9                                           // 000000148FC0: 7F6E39B9
	.long 0x7e6e39b9                                           // 000000148FC4: 7E6E39B9
	.long 0x7f6c39b9                                           // 000000148FC8: 7F6C39B9
	.long 0x7e6c39b9                                           // 000000148FCC: 7E6C39B9
	s_and_saveexec_b32 s1, s0                                  // 000000148FD0: BE812000
	s_cbranch_execz 11                                         // 000000148FD4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe04>
	global_load_b128 v[5:8], v[3:4], off offset:160            // 000000148FD8: DC5E00A0 057C0003
	s_waitcnt vmcnt(0)                                         // 000000148FE0: BF8903F7
	v_fma_mixlo_f16 v54, v5, s12, 0                            // 000000148FE4: CC210036 02001905
	v_fma_mixhi_f16 v54, v6, s12, 0                            // 000000148FEC: CC220036 02001906
	v_fma_mixlo_f16 v55, v7, s12, 0                            // 000000148FF4: CC210037 02001907
	v_fma_mixhi_f16 v55, v8, s12, 0                            // 000000148FFC: CC220037 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000149004: 8C7E017E
	.long 0x7e7239b9                                           // 000000149008: 7E7239B9
	.long 0x7f7039b9                                           // 00000014900C: 7F7039B9
	.long 0x7e7039b9                                           // 000000149010: 7E7039B9
	s_and_saveexec_b32 s1, s0                                  // 000000149014: BE812000
	s_cbranch_execz 11                                         // 000000149018: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe48>
	global_load_b128 v[5:8], v[3:4], off offset:176            // 00000014901C: DC5E00B0 057C0003
	s_waitcnt vmcnt(0)                                         // 000000149024: BF8903F7
	v_fma_mixlo_f16 v56, v5, s12, 0                            // 000000149028: CC210038 02001905
	v_fma_mixhi_f16 v56, v6, s12, 0                            // 000000149030: CC220038 02001906
	v_fma_mixlo_f16 v57, v7, s12, 0                            // 000000149038: CC210039 02001907
	v_fma_mixhi_f16 v57, v8, s12, 0                            // 000000149040: CC220039 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000149048: 8C7E017E
	ds_load_b128 v[5:8], v80 offset:128                        // 00000014904C: DBFC0080 05000050
	ds_load_b128 v[61:64], v80 offset:144                      // 000000149054: DBFC0090 3D000050
	ds_load_b128 v[94:97], v80 offset:160                      // 00000014905C: DBFC00A0 5E000050
	ds_load_b128 v[98:101], v80 offset:176                     // 000000149064: DBFC00B0 62000050
	ds_load_b128 v[102:105], v80 offset:8576                   // 00000014906C: DBFC2180 66000050
	ds_load_b128 v[106:109], v80 offset:8592                   // 000000149074: DBFC2190 6A000050
	ds_load_b128 v[110:113], v80 offset:8608                   // 00000014907C: DBFC21A0 6E000050
	ds_load_b128 v[114:117], v80 offset:8624                   // 000000149084: DBFC21B0 72000050
	.long 0x7f743880                                           // 00000014908C: 7F743880
	ds_load_b128 v[118:121], v80 offset:17040                  // 000000149090: DBFC4290 76000050
	ds_load_b128 v[122:125], v80 offset:25488                  // 000000149098: DBFC6390 7A000050
	s_waitcnt lgkmcnt(9)                                       // 0000001490A0: BF89FC97
	v_fma_mixlo_f16 v59, v5, s12, 0                            // 0000001490A4: CC21003B 02001905
	v_fma_mixhi_f16 v59, v6, s12, 0                            // 0000001490AC: CC22003B 02001906
	v_fma_mixlo_f16 v60, v7, s12, 0                            // 0000001490B4: CC21003C 02001907
	v_fma_mixhi_f16 v60, v8, s12, 0                            // 0000001490BC: CC22003C 02001908
	ds_load_b128 v[5:8], v80 offset:17024                      // 0000001490C4: DBFC4280 05000050
	s_waitcnt lgkmcnt(9)                                       // 0000001490CC: BF89FC97
	v_fma_mixlo_f16 v61, v61, s12, 0                           // 0000001490D0: CC21003D 0200193D
	v_fma_mixhi_f16 v61, v62, s12, 0                           // 0000001490D8: CC22003D 0200193E
	v_fma_mixlo_f16 v62, v63, s12, 0                           // 0000001490E0: CC21003E 0200193F
	v_fma_mixhi_f16 v62, v64, s12, 0                           // 0000001490E8: CC22003E 02001940
	s_waitcnt lgkmcnt(8)                                       // 0000001490F0: BF89FC87
	v_fma_mixlo_f16 v63, v94, s12, 0                           // 0000001490F4: CC21003F 0200195E
	v_fma_mixhi_f16 v63, v95, s12, 0                           // 0000001490FC: CC22003F 0200195F
	v_fma_mixlo_f16 v64, v96, s12, 0                           // 000000149104: CC210040 02001960
	v_fma_mixhi_f16 v64, v97, s12, 0                           // 00000014910C: CC220040 02001961
	s_waitcnt lgkmcnt(7)                                       // 000000149114: BF89FC77
	v_fma_mixlo_f16 v65, v98, s12, 0                           // 000000149118: CC210041 02001962
	v_fma_mixhi_f16 v65, v99, s12, 0                           // 000000149120: CC220041 02001963
	v_fma_mixlo_f16 v66, v100, s12, 0                          // 000000149128: CC210042 02001964
	v_fma_mixhi_f16 v66, v101, s12, 0                          // 000000149130: CC220042 02001965
	s_waitcnt lgkmcnt(6)                                       // 000000149138: BF89FC67
	v_fma_mixlo_f16 v94, v102, s12, 0                          // 00000014913C: CC21005E 02001966
	v_fma_mixhi_f16 v94, v103, s12, 0                          // 000000149144: CC22005E 02001967
	v_fma_mixlo_f16 v95, v104, s12, 0                          // 00000014914C: CC21005F 02001968
	v_fma_mixhi_f16 v95, v105, s12, 0                          // 000000149154: CC22005F 02001969
	s_waitcnt lgkmcnt(5)                                       // 00000014915C: BF89FC57
	v_fma_mixlo_f16 v96, v106, s12, 0                          // 000000149160: CC210060 0200196A
	v_fma_mixhi_f16 v96, v107, s12, 0                          // 000000149168: CC220060 0200196B
	v_fma_mixlo_f16 v97, v108, s12, 0                          // 000000149170: CC210061 0200196C
	v_fma_mixhi_f16 v97, v109, s12, 0                          // 000000149178: CC220061 0200196D
	s_waitcnt lgkmcnt(4)                                       // 000000149180: BF89FC47
	v_fma_mixlo_f16 v98, v110, s12, 0                          // 000000149184: CC210062 0200196E
	ds_load_b128 v[106:109], v80 offset:17056                  // 00000014918C: DBFC42A0 6A000050
	v_fma_mixhi_f16 v98, v111, s12, 0                          // 000000149194: CC220062 0200196F
	v_fma_mixlo_f16 v99, v112, s12, 0                          // 00000014919C: CC210063 02001970
	v_fma_mixhi_f16 v99, v113, s12, 0                          // 0000001491A4: CC220063 02001971
	s_waitcnt lgkmcnt(4)                                       // 0000001491AC: BF89FC47
	v_fma_mixlo_f16 v100, v114, s12, 0                         // 0000001491B0: CC210064 02001972
	ds_load_b128 v[110:113], v80 offset:17072                  // 0000001491B8: DBFC42B0 6E000050
	v_fma_mixhi_f16 v100, v115, s12, 0                         // 0000001491C0: CC220064 02001973
	v_fma_mixlo_f16 v101, v116, s12, 0                         // 0000001491C8: CC210065 02001974
	v_fma_mixhi_f16 v101, v117, s12, 0                         // 0000001491D0: CC220065 02001975
	ds_load_b128 v[114:117], v80 offset:25472                  // 0000001491D8: DBFC6380 72000050
	s_waitcnt lgkmcnt(3)                                       // 0000001491E0: BF89FC37
	v_fma_mixlo_f16 v102, v5, s12, 0                           // 0000001491E4: CC210066 02001905
	v_fma_mixhi_f16 v102, v6, s12, 0                           // 0000001491EC: CC220066 02001906
	v_fma_mixlo_f16 v103, v7, s12, 0                           // 0000001491F4: CC210067 02001907
	v_fma_mixhi_f16 v103, v8, s12, 0                           // 0000001491FC: CC220067 02001908
	v_fma_mixlo_f16 v104, v118, s12, 0                         // 000000149204: CC210068 02001976
	v_fma_mixhi_f16 v104, v119, s12, 0                         // 00000014920C: CC220068 02001977
	ds_load_b128 v[5:8], v80 offset:25504                      // 000000149214: DBFC63A0 05000050
	v_fma_mixlo_f16 v105, v120, s12, 0                         // 00000014921C: CC210069 02001978
	v_fma_mixhi_f16 v105, v121, s12, 0                         // 000000149224: CC220069 02001979
	ds_load_b128 v[118:121], v80 offset:25520                  // 00000014922C: DBFC63B0 76000050
	s_waitcnt lgkmcnt(4)                                       // 000000149234: BF89FC47
	v_fma_mixlo_f16 v106, v106, s12, 0                         // 000000149238: CC21006A 0200196A
	v_fma_mixhi_f16 v106, v107, s12, 0                         // 000000149240: CC22006A 0200196B
	v_fma_mixlo_f16 v107, v108, s12, 0                         // 000000149248: CC21006B 0200196C
	v_fma_mixhi_f16 v107, v109, s12, 0                         // 000000149250: CC22006B 0200196D
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[59:66], v[42:49]// 000000149258: CC40402A 1CAA7732
	s_waitcnt lgkmcnt(3)                                       // 000000149260: BF89FC37
	v_fma_mixlo_f16 v108, v110, s12, 0                         // 000000149264: CC21006C 0200196E
	v_fma_mixhi_f16 v108, v111, s12, 0                         // 00000014926C: CC22006C 0200196F
	v_fma_mixlo_f16 v109, v112, s12, 0                         // 000000149274: CC21006D 02001970
	v_fma_mixhi_f16 v109, v113, s12, 0                         // 00000014927C: CC22006D 02001971
	s_waitcnt lgkmcnt(2)                                       // 000000149284: BF89FC27
	v_fma_mixlo_f16 v110, v114, s12, 0                         // 000000149288: CC21006E 02001972
	v_fma_mixhi_f16 v110, v115, s12, 0                         // 000000149290: CC22006E 02001973
	v_fma_mixlo_f16 v111, v116, s12, 0                         // 000000149298: CC21006F 02001974
	v_fma_mixhi_f16 v111, v117, s12, 0                         // 0000001492A0: CC22006F 02001975
	v_fma_mixlo_f16 v112, v122, s12, 0                         // 0000001492A8: CC210070 0200197A
	v_fma_mixhi_f16 v112, v123, s12, 0                         // 0000001492B0: CC220070 0200197B
	v_fma_mixlo_f16 v113, v124, s12, 0                         // 0000001492B8: CC210071 0200197C
	v_fma_mixhi_f16 v113, v125, s12, 0                         // 0000001492C0: CC220071 0200197D
	s_waitcnt lgkmcnt(1)                                       // 0000001492C8: BF89FC17
	v_fma_mixlo_f16 v114, v5, s12, 0                           // 0000001492CC: CC210072 02001905
	v_fma_mixhi_f16 v114, v6, s12, 0                           // 0000001492D4: CC220072 02001906
	v_fma_mixlo_f16 v115, v7, s12, 0                           // 0000001492DC: CC210073 02001907
	v_fma_mixhi_f16 v115, v8, s12, 0                           // 0000001492E4: CC220073 02001908
	s_waitcnt lgkmcnt(0)                                       // 0000001492EC: BF89FC07
	v_fma_mixlo_f16 v116, v118, s12, 0                         // 0000001492F0: CC210074 02001976
	v_fma_mixhi_f16 v116, v119, s12, 0                         // 0000001492F8: CC220074 02001977
	v_fma_mixlo_f16 v117, v120, s12, 0                         // 000000149300: CC210075 02001978
	v_fma_mixhi_f16 v117, v121, s12, 0                         // 000000149308: CC220075 02001979
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[94:101], v[34:41]// 000000149310: CC404022 1C8ABD32
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[102:109], v[26:33]// 000000149318: CC40401A 1C6ACD32
	s_delay_alu instid0(VALU_DEP_3)                            // 000000149320: BF870003
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[110:117], v[18:25]// 000000149324: CC404012 1C4ADD32
	.long 0x7f7039ba                                           // 00000014932C: 7F7039BA
	.long 0x7e7039ba                                           // 000000149330: 7E7039BA
	.long 0x7f6e39ba                                           // 000000149334: 7F6E39BA
	.long 0x7e6e39ba                                           // 000000149338: 7E6E39BA
	s_and_saveexec_b32 s1, s0                                  // 00000014933C: BE812000
	s_cbranch_execz 11                                         // 000000149340: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1170>
	global_load_b128 v[5:8], v[3:4], off offset:192            // 000000149344: DC5E00C0 057C0003
	s_waitcnt vmcnt(0)                                         // 00000014934C: BF8903F7
	v_fma_mixlo_f16 v55, v5, s12, 0                            // 000000149350: CC210037 02001905
	v_fma_mixhi_f16 v55, v6, s12, 0                            // 000000149358: CC220037 02001906
	v_fma_mixlo_f16 v56, v7, s12, 0                            // 000000149360: CC210038 02001907
	v_fma_mixhi_f16 v56, v8, s12, 0                            // 000000149368: CC220038 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000149370: 8C7E017E
	.long 0x7e7439ba                                           // 000000149374: 7E7439BA
	.long 0x7f7239ba                                           // 000000149378: 7F7239BA
	.long 0x7e7239ba                                           // 00000014937C: 7E7239BA
	s_and_saveexec_b32 s1, s0                                  // 000000149380: BE812000
	s_cbranch_execz 11                                         // 000000149384: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11b4>
	global_load_b128 v[5:8], v[3:4], off offset:208            // 000000149388: DC5E00D0 057C0003
	s_waitcnt vmcnt(0)                                         // 000000149390: BF8903F7
	v_fma_mixlo_f16 v57, v5, s12, 0                            // 000000149394: CC210039 02001905
	v_fma_mixhi_f16 v57, v6, s12, 0                            // 00000014939C: CC220039 02001906
	v_fma_mixlo_f16 v58, v7, s12, 0                            // 0000001493A4: CC21003A 02001907
	v_fma_mixhi_f16 v58, v8, s12, 0                            // 0000001493AC: CC22003A 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001493B4: 8C7E017E
	.long 0x7f7c3880                                           // 0000001493B8: 7F7C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001493BC: BF870001
	.long 0x7f7839be                                           // 0000001493C0: 7F7839BE
	.long 0x7e7839be                                           // 0000001493C4: 7E7839BE
	.long 0x7f7639be                                           // 0000001493C8: 7F7639BE
	.long 0x7e7639be                                           // 0000001493CC: 7E7639BE
	s_and_saveexec_b32 s1, s0                                  // 0000001493D0: BE812000
	s_cbranch_execz 11                                         // 0000001493D4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1204>
	global_load_b128 v[5:8], v[3:4], off offset:224            // 0000001493D8: DC5E00E0 057C0003
	s_waitcnt vmcnt(0)                                         // 0000001493E0: BF8903F7
	v_fma_mixlo_f16 v59, v5, s12, 0                            // 0000001493E4: CC21003B 02001905
	v_fma_mixhi_f16 v59, v6, s12, 0                            // 0000001493EC: CC22003B 02001906
	v_fma_mixlo_f16 v60, v7, s12, 0                            // 0000001493F4: CC21003C 02001907
	v_fma_mixhi_f16 v60, v8, s12, 0                            // 0000001493FC: CC22003C 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000149404: 8C7E017E
	.long 0x7e7c39be                                           // 000000149408: 7E7C39BE
	.long 0x7f7a39be                                           // 00000014940C: 7F7A39BE
	.long 0x7e7a39be                                           // 000000149410: 7E7A39BE
	s_and_saveexec_b32 s1, s0                                  // 000000149414: BE812000
	s_cbranch_execz 11                                         // 000000149418: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1248>
	global_load_b128 v[5:8], v[3:4], off offset:240            // 00000014941C: DC5E00F0 057C0003
	s_waitcnt vmcnt(0)                                         // 000000149424: BF8903F7
	v_fma_mixlo_f16 v61, v5, s12, 0                            // 000000149428: CC21003D 02001905
	v_fma_mixhi_f16 v61, v6, s12, 0                            // 000000149430: CC22003D 02001906
	v_fma_mixlo_f16 v62, v7, s12, 0                            // 000000149438: CC21003E 02001907
	v_fma_mixhi_f16 v62, v8, s12, 0                            // 000000149440: CC22003E 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000149448: 8C7E017E
	ds_load_b128 v[5:8], v80 offset:192                        // 00000014944C: DBFC00C0 05000050
	ds_load_b128 v[50:53], v80 offset:208                      // 000000149454: DBFC00D0 32000050
	ds_load_b128 v[63:66], v80 offset:224                      // 00000014945C: DBFC00E0 3F000050
	ds_load_b128 v[100:103], v80 offset:240                    // 000000149464: DBFC00F0 64000050
	ds_load_b128 v[104:107], v80 offset:8640                   // 00000014946C: DBFC21C0 68000050
	ds_load_b128 v[108:111], v80 offset:8656                   // 000000149474: DBFC21D0 6C000050
	ds_load_b128 v[112:115], v80 offset:8672                   // 00000014947C: DBFC21E0 70000050
	ds_load_b128 v[116:119], v80 offset:8688                   // 000000149484: DBFC21F0 74000050
	ds_load_b128 v[124:127], v80 offset:25536                  // 00000014948C: DBFC63C0 7C000050
	ds_load_b128 v[128:131], v80 offset:25552                  // 000000149494: DBFC63D0 80000050
	ds_load_b128 v[120:123], v80 offset:17136                  // 00000014949C: DBFC42F0 78000050
	s_waitcnt lgkmcnt(10)                                      // 0000001494A4: BF89FCA7
	v_fma_mixlo_f16 v94, v5, s12, 0                            // 0000001494A8: CC21005E 02001905
	v_fma_mixhi_f16 v94, v6, s12, 0                            // 0000001494B0: CC22005E 02001906
	v_fma_mixlo_f16 v95, v7, s12, 0                            // 0000001494B8: CC21005F 02001907
	v_fma_mixhi_f16 v95, v8, s12, 0                            // 0000001494C0: CC22005F 02001908
	s_waitcnt lgkmcnt(9)                                       // 0000001494C8: BF89FC97
	v_fma_mixlo_f16 v96, v50, s12, 0                           // 0000001494CC: CC210060 02001932
	v_fma_mixhi_f16 v96, v51, s12, 0                           // 0000001494D4: CC220060 02001933
	v_fma_mixlo_f16 v97, v52, s12, 0                           // 0000001494DC: CC210061 02001934
	v_fma_mixhi_f16 v97, v53, s12, 0                           // 0000001494E4: CC220061 02001935
	ds_load_b128 v[5:8], v80 offset:17088                      // 0000001494EC: DBFC42C0 05000050
	ds_load_b128 v[50:53], v80 offset:17104                    // 0000001494F4: DBFC42D0 32000050
	s_waitcnt lgkmcnt(10)                                      // 0000001494FC: BF89FCA7
	v_fma_mixlo_f16 v98, v63, s12, 0                           // 000000149500: CC210062 0200193F
	v_fma_mixhi_f16 v98, v64, s12, 0                           // 000000149508: CC220062 02001940
	v_fma_mixlo_f16 v99, v65, s12, 0                           // 000000149510: CC210063 02001941
	v_fma_mixhi_f16 v99, v66, s12, 0                           // 000000149518: CC220063 02001942
	s_waitcnt lgkmcnt(9)                                       // 000000149520: BF89FC97
	v_fma_mixlo_f16 v100, v100, s12, 0                         // 000000149524: CC210064 02001964
	v_fma_mixhi_f16 v100, v101, s12, 0                         // 00000014952C: CC220064 02001965
	v_fma_mixlo_f16 v101, v102, s12, 0                         // 000000149534: CC210065 02001966
	v_fma_mixhi_f16 v101, v103, s12, 0                         // 00000014953C: CC220065 02001967
	s_waitcnt lgkmcnt(8)                                       // 000000149544: BF89FC87
	v_fma_mixhi_f16 v102, v105, s12, 0                         // 000000149548: CC220066 02001969
	v_fma_mixlo_f16 v103, v106, s12, 0                         // 000000149550: CC210067 0200196A
	s_waitcnt lgkmcnt(7)                                       // 000000149558: BF89FC77
	v_fma_mixlo_f16 v105, v110, s12, 0                         // 00000014955C: CC210069 0200196E
	v_fma_mixhi_f16 v105, v111, s12, 0                         // 000000149564: CC220069 0200196F
	s_waitcnt lgkmcnt(6)                                       // 00000014956C: BF89FC67
	v_fma_mixlo_f16 v106, v112, s12, 0                         // 000000149570: CC21006A 02001970
	ds_load_b128 v[63:66], v80 offset:17120                    // 000000149578: DBFC42E0 3F000050
	v_fma_mixhi_f16 v106, v113, s12, 0                         // 000000149580: CC22006A 02001971
	v_fma_mixlo_f16 v102, v104, s12, 0                         // 000000149588: CC210066 02001968
	v_fma_mixhi_f16 v103, v107, s12, 0                         // 000000149590: CC220067 0200196B
	v_fma_mixlo_f16 v104, v108, s12, 0                         // 000000149598: CC210068 0200196C
	s_waitcnt lgkmcnt(2)                                       // 0000001495A0: BF89FC27
	v_fma_mixlo_f16 v110, v5, s12, 0                           // 0000001495A4: CC21006E 02001905
	v_fma_mixhi_f16 v110, v6, s12, 0                           // 0000001495AC: CC22006E 02001906
	v_fma_mixlo_f16 v111, v7, s12, 0                           // 0000001495B4: CC21006F 02001907
	v_fma_mixhi_f16 v111, v8, s12, 0                           // 0000001495BC: CC22006F 02001908
	s_waitcnt lgkmcnt(1)                                       // 0000001495C4: BF89FC17
	v_fma_mixlo_f16 v112, v50, s12, 0                          // 0000001495C8: CC210070 02001932
	v_fma_mixhi_f16 v112, v51, s12, 0                          // 0000001495D0: CC220070 02001933
	ds_load_b128 v[5:8], v80 offset:25568                      // 0000001495D8: DBFC63E0 05000050
	v_fma_mixlo_f16 v113, v52, s12, 0                          // 0000001495E0: CC210071 02001934
	v_fma_mixhi_f16 v113, v53, s12, 0                          // 0000001495E8: CC220071 02001935
	ds_load_b128 v[50:53], v80 offset:25584                    // 0000001495F0: DBFC63F0 32000050
	v_fma_mixhi_f16 v104, v109, s12, 0                         // 0000001495F8: CC220068 0200196D
	v_fma_mixlo_f16 v107, v114, s12, 0                         // 000000149600: CC21006B 02001972
	v_fma_mixhi_f16 v107, v115, s12, 0                         // 000000149608: CC22006B 02001973
	v_fma_mixlo_f16 v108, v116, s12, 0                         // 000000149610: CC21006C 02001974
	v_fma_mixhi_f16 v108, v117, s12, 0                         // 000000149618: CC22006C 02001975
	v_fma_mixlo_f16 v109, v118, s12, 0                         // 000000149620: CC21006D 02001976
	v_fma_mixhi_f16 v109, v119, s12, 0                         // 000000149628: CC22006D 02001977
	s_waitcnt lgkmcnt(2)                                       // 000000149630: BF89FC27
	v_fma_mixlo_f16 v114, v63, s12, 0                          // 000000149634: CC210072 0200193F
	v_fma_mixhi_f16 v114, v64, s12, 0                          // 00000014963C: CC220072 02001940
	v_fma_mixlo_f16 v115, v65, s12, 0                          // 000000149644: CC210073 02001941
	v_fma_mixhi_f16 v115, v66, s12, 0                          // 00000014964C: CC220073 02001942
	v_fma_mixlo_f16 v116, v120, s12, 0                         // 000000149654: CC210074 02001978
	v_fma_mixhi_f16 v116, v121, s12, 0                         // 00000014965C: CC220074 02001979
	v_fma_mixlo_f16 v117, v122, s12, 0                         // 000000149664: CC210075 0200197A
	v_fma_mixhi_f16 v117, v123, s12, 0                         // 00000014966C: CC220075 0200197B
	v_fma_mixlo_f16 v118, v124, s12, 0                         // 000000149674: CC210076 0200197C
	v_fma_mixhi_f16 v118, v125, s12, 0                         // 00000014967C: CC220076 0200197D
	v_fma_mixlo_f16 v119, v126, s12, 0                         // 000000149684: CC210077 0200197E
	v_fma_mixhi_f16 v119, v127, s12, 0                         // 00000014968C: CC220077 0200197F
	v_fma_mixlo_f16 v120, v128, s12, 0                         // 000000149694: CC210078 02001980
	v_fma_mixhi_f16 v120, v129, s12, 0                         // 00000014969C: CC220078 02001981
	v_fma_mixlo_f16 v121, v130, s12, 0                         // 0000001496A4: CC210079 02001982
	v_fma_mixhi_f16 v121, v131, s12, 0                         // 0000001496AC: CC220079 02001983
	s_waitcnt lgkmcnt(1)                                       // 0000001496B4: BF89FC17
	v_fma_mixlo_f16 v122, v5, s12, 0                           // 0000001496B8: CC21007A 02001905
	v_fma_mixhi_f16 v122, v6, s12, 0                           // 0000001496C0: CC22007A 02001906
	v_fma_mixlo_f16 v123, v7, s12, 0                           // 0000001496C8: CC21007B 02001907
	v_fma_mixhi_f16 v123, v8, s12, 0                           // 0000001496D0: CC22007B 02001908
	s_waitcnt lgkmcnt(0)                                       // 0000001496D8: BF89FC07
	v_fma_mixlo_f16 v124, v50, s12, 0                          // 0000001496DC: CC21007C 02001932
	v_fma_mixhi_f16 v124, v51, s12, 0                          // 0000001496E4: CC22007C 02001933
	v_fma_mixlo_f16 v125, v52, s12, 0                          // 0000001496EC: CC21007D 02001934
	v_fma_mixhi_f16 v125, v53, s12, 0                          // 0000001496F4: CC22007D 02001935
	.long 0x7f6a3880                                           // 0000001496FC: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[55:62], v[94:101], v[42:49]// 000000149700: CC40402A 1CAABD37
	v_wmma_f32_16x16x16_f16 v[34:41], v[55:62], v[102:109], v[34:41]// 000000149708: CC404022 1C8ACD37
	v_wmma_f32_16x16x16_f16 v[26:33], v[55:62], v[110:117], v[26:33]// 000000149710: CC40401A 1C6ADD37
	v_wmma_f32_16x16x16_f16 v[18:25], v[55:62], v[118:125], v[18:25]// 000000149718: CC404012 1C4AED37
	.long 0x7f6639b5                                           // 000000149720: 7F6639B5
	.long 0x7e6639b5                                           // 000000149724: 7E6639B5
	.long 0x7f6439b5                                           // 000000149728: 7F6439B5
	.long 0x7e6439b5                                           // 00000014972C: 7E6439B5
	s_and_saveexec_b32 s1, s0                                  // 000000149730: BE812000
	s_cbranch_execz 11                                         // 000000149734: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1564>
	global_load_b128 v[5:8], v[3:4], off offset:256            // 000000149738: DC5E0100 057C0003
	s_waitcnt vmcnt(0)                                         // 000000149740: BF8903F7
	v_fma_mixlo_f16 v50, v5, s12, 0                            // 000000149744: CC210032 02001905
	v_fma_mixhi_f16 v50, v6, s12, 0                            // 00000014974C: CC220032 02001906
	v_fma_mixlo_f16 v51, v7, s12, 0                            // 000000149754: CC210033 02001907
	v_fma_mixhi_f16 v51, v8, s12, 0                            // 00000014975C: CC220033 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000149764: 8C7E017E
	.long 0x7e6a39b5                                           // 000000149768: 7E6A39B5
	.long 0x7f6839b5                                           // 00000014976C: 7F6839B5
	.long 0x7e6839b5                                           // 000000149770: 7E6839B5
	s_and_saveexec_b32 s1, s0                                  // 000000149774: BE812000
	s_cbranch_execz 11                                         // 000000149778: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15a8>
	global_load_b128 v[5:8], v[3:4], off offset:272            // 00000014977C: DC5E0110 057C0003
	s_waitcnt vmcnt(0)                                         // 000000149784: BF8903F7
	v_fma_mixlo_f16 v52, v5, s12, 0                            // 000000149788: CC210034 02001905
	v_fma_mixhi_f16 v52, v6, s12, 0                            // 000000149790: CC220034 02001906
	v_fma_mixlo_f16 v53, v7, s12, 0                            // 000000149798: CC210035 02001907
	v_fma_mixhi_f16 v53, v8, s12, 0                            // 0000001497A0: CC220035 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001497A8: 8C7E017E
	.long 0x7f723880                                           // 0000001497AC: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001497B0: BF870001
	.long 0x7f6e39b9                                           // 0000001497B4: 7F6E39B9
	.long 0x7e6e39b9                                           // 0000001497B8: 7E6E39B9
	.long 0x7f6c39b9                                           // 0000001497BC: 7F6C39B9
	.long 0x7e6c39b9                                           // 0000001497C0: 7E6C39B9
	s_and_saveexec_b32 s1, s0                                  // 0000001497C4: BE812000
	s_cbranch_execz 11                                         // 0000001497C8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15f8>
	global_load_b128 v[5:8], v[3:4], off offset:288            // 0000001497CC: DC5E0120 057C0003
	s_waitcnt vmcnt(0)                                         // 0000001497D4: BF8903F7
	v_fma_mixlo_f16 v54, v5, s12, 0                            // 0000001497D8: CC210036 02001905
	v_fma_mixhi_f16 v54, v6, s12, 0                            // 0000001497E0: CC220036 02001906
	v_fma_mixlo_f16 v55, v7, s12, 0                            // 0000001497E8: CC210037 02001907
	v_fma_mixhi_f16 v55, v8, s12, 0                            // 0000001497F0: CC220037 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001497F8: 8C7E017E
	.long 0x7e7239b9                                           // 0000001497FC: 7E7239B9
	.long 0x7f7039b9                                           // 000000149800: 7F7039B9
	.long 0x7e7039b9                                           // 000000149804: 7E7039B9
	s_and_saveexec_b32 s1, s0                                  // 000000149808: BE812000
	s_cbranch_execz 11                                         // 00000014980C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x163c>
	global_load_b128 v[5:8], v[3:4], off offset:304            // 000000149810: DC5E0130 057C0003
	s_waitcnt vmcnt(0)                                         // 000000149818: BF8903F7
	v_fma_mixlo_f16 v56, v5, s12, 0                            // 00000014981C: CC210038 02001905
	v_fma_mixhi_f16 v56, v6, s12, 0                            // 000000149824: CC220038 02001906
	v_fma_mixlo_f16 v57, v7, s12, 0                            // 00000014982C: CC210039 02001907
	v_fma_mixhi_f16 v57, v8, s12, 0                            // 000000149834: CC220039 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014983C: 8C7E017E
	ds_load_b128 v[5:8], v80 offset:256                        // 000000149840: DBFC0100 05000050
	ds_load_b128 v[61:64], v80 offset:272                      // 000000149848: DBFC0110 3D000050
	ds_load_b128 v[94:97], v80 offset:288                      // 000000149850: DBFC0120 5E000050
	ds_load_b128 v[98:101], v80 offset:304                     // 000000149858: DBFC0130 62000050
	ds_load_b128 v[102:105], v80 offset:8704                   // 000000149860: DBFC2200 66000050
	ds_load_b128 v[106:109], v80 offset:8720                   // 000000149868: DBFC2210 6A000050
	ds_load_b128 v[110:113], v80 offset:8736                   // 000000149870: DBFC2220 6E000050
	ds_load_b128 v[114:117], v80 offset:8752                   // 000000149878: DBFC2230 72000050
	.long 0x7f743880                                           // 000000149880: 7F743880
	ds_load_b128 v[118:121], v80 offset:17168                  // 000000149884: DBFC4310 76000050
	ds_load_b128 v[122:125], v80 offset:25616                  // 00000014988C: DBFC6410 7A000050
	s_waitcnt lgkmcnt(9)                                       // 000000149894: BF89FC97
	v_fma_mixlo_f16 v59, v5, s12, 0                            // 000000149898: CC21003B 02001905
	v_fma_mixhi_f16 v59, v6, s12, 0                            // 0000001498A0: CC22003B 02001906
	v_fma_mixlo_f16 v60, v7, s12, 0                            // 0000001498A8: CC21003C 02001907
	v_fma_mixhi_f16 v60, v8, s12, 0                            // 0000001498B0: CC22003C 02001908
	ds_load_b128 v[5:8], v80 offset:17152                      // 0000001498B8: DBFC4300 05000050
	s_waitcnt lgkmcnt(9)                                       // 0000001498C0: BF89FC97
	v_fma_mixlo_f16 v61, v61, s12, 0                           // 0000001498C4: CC21003D 0200193D
	v_fma_mixhi_f16 v61, v62, s12, 0                           // 0000001498CC: CC22003D 0200193E
	v_fma_mixlo_f16 v62, v63, s12, 0                           // 0000001498D4: CC21003E 0200193F
	v_fma_mixhi_f16 v62, v64, s12, 0                           // 0000001498DC: CC22003E 02001940
	s_waitcnt lgkmcnt(8)                                       // 0000001498E4: BF89FC87
	v_fma_mixlo_f16 v63, v94, s12, 0                           // 0000001498E8: CC21003F 0200195E
	v_fma_mixhi_f16 v63, v95, s12, 0                           // 0000001498F0: CC22003F 0200195F
	v_fma_mixlo_f16 v64, v96, s12, 0                           // 0000001498F8: CC210040 02001960
	v_fma_mixhi_f16 v64, v97, s12, 0                           // 000000149900: CC220040 02001961
	s_waitcnt lgkmcnt(7)                                       // 000000149908: BF89FC77
	v_fma_mixlo_f16 v65, v98, s12, 0                           // 00000014990C: CC210041 02001962
	v_fma_mixhi_f16 v65, v99, s12, 0                           // 000000149914: CC220041 02001963
	v_fma_mixlo_f16 v66, v100, s12, 0                          // 00000014991C: CC210042 02001964
	v_fma_mixhi_f16 v66, v101, s12, 0                          // 000000149924: CC220042 02001965
	s_waitcnt lgkmcnt(6)                                       // 00000014992C: BF89FC67
	v_fma_mixlo_f16 v94, v102, s12, 0                          // 000000149930: CC21005E 02001966
	v_fma_mixhi_f16 v94, v103, s12, 0                          // 000000149938: CC22005E 02001967
	v_fma_mixlo_f16 v95, v104, s12, 0                          // 000000149940: CC21005F 02001968
	v_fma_mixhi_f16 v95, v105, s12, 0                          // 000000149948: CC22005F 02001969
	s_waitcnt lgkmcnt(5)                                       // 000000149950: BF89FC57
	v_fma_mixlo_f16 v96, v106, s12, 0                          // 000000149954: CC210060 0200196A
	v_fma_mixhi_f16 v96, v107, s12, 0                          // 00000014995C: CC220060 0200196B
	v_fma_mixlo_f16 v97, v108, s12, 0                          // 000000149964: CC210061 0200196C
	v_fma_mixhi_f16 v97, v109, s12, 0                          // 00000014996C: CC220061 0200196D
	s_waitcnt lgkmcnt(4)                                       // 000000149974: BF89FC47
	v_fma_mixlo_f16 v98, v110, s12, 0                          // 000000149978: CC210062 0200196E
	ds_load_b128 v[106:109], v80 offset:17184                  // 000000149980: DBFC4320 6A000050
	v_fma_mixhi_f16 v98, v111, s12, 0                          // 000000149988: CC220062 0200196F
	v_fma_mixlo_f16 v99, v112, s12, 0                          // 000000149990: CC210063 02001970
	v_fma_mixhi_f16 v99, v113, s12, 0                          // 000000149998: CC220063 02001971
	s_waitcnt lgkmcnt(4)                                       // 0000001499A0: BF89FC47
	v_fma_mixlo_f16 v100, v114, s12, 0                         // 0000001499A4: CC210064 02001972
	ds_load_b128 v[110:113], v80 offset:17200                  // 0000001499AC: DBFC4330 6E000050
	v_fma_mixhi_f16 v100, v115, s12, 0                         // 0000001499B4: CC220064 02001973
	v_fma_mixlo_f16 v101, v116, s12, 0                         // 0000001499BC: CC210065 02001974
	v_fma_mixhi_f16 v101, v117, s12, 0                         // 0000001499C4: CC220065 02001975
	ds_load_b128 v[114:117], v80 offset:25600                  // 0000001499CC: DBFC6400 72000050
	s_waitcnt lgkmcnt(3)                                       // 0000001499D4: BF89FC37
	v_fma_mixlo_f16 v102, v5, s12, 0                           // 0000001499D8: CC210066 02001905
	v_fma_mixhi_f16 v102, v6, s12, 0                           // 0000001499E0: CC220066 02001906
	v_fma_mixlo_f16 v103, v7, s12, 0                           // 0000001499E8: CC210067 02001907
	v_fma_mixhi_f16 v103, v8, s12, 0                           // 0000001499F0: CC220067 02001908
	v_fma_mixlo_f16 v104, v118, s12, 0                         // 0000001499F8: CC210068 02001976
	v_fma_mixhi_f16 v104, v119, s12, 0                         // 000000149A00: CC220068 02001977
	ds_load_b128 v[5:8], v80 offset:25632                      // 000000149A08: DBFC6420 05000050
	v_fma_mixlo_f16 v105, v120, s12, 0                         // 000000149A10: CC210069 02001978
	v_fma_mixhi_f16 v105, v121, s12, 0                         // 000000149A18: CC220069 02001979
	ds_load_b128 v[118:121], v80 offset:25648                  // 000000149A20: DBFC6430 76000050
	s_waitcnt lgkmcnt(4)                                       // 000000149A28: BF89FC47
	v_fma_mixlo_f16 v106, v106, s12, 0                         // 000000149A2C: CC21006A 0200196A
	v_fma_mixhi_f16 v106, v107, s12, 0                         // 000000149A34: CC22006A 0200196B
	v_fma_mixlo_f16 v107, v108, s12, 0                         // 000000149A3C: CC21006B 0200196C
	v_fma_mixhi_f16 v107, v109, s12, 0                         // 000000149A44: CC22006B 0200196D
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[59:66], v[42:49]// 000000149A4C: CC40402A 1CAA7732
	s_waitcnt lgkmcnt(3)                                       // 000000149A54: BF89FC37
	v_fma_mixlo_f16 v108, v110, s12, 0                         // 000000149A58: CC21006C 0200196E
	v_fma_mixhi_f16 v108, v111, s12, 0                         // 000000149A60: CC22006C 0200196F
	v_fma_mixlo_f16 v109, v112, s12, 0                         // 000000149A68: CC21006D 02001970
	v_fma_mixhi_f16 v109, v113, s12, 0                         // 000000149A70: CC22006D 02001971
	s_waitcnt lgkmcnt(2)                                       // 000000149A78: BF89FC27
	v_fma_mixlo_f16 v110, v114, s12, 0                         // 000000149A7C: CC21006E 02001972
	v_fma_mixhi_f16 v110, v115, s12, 0                         // 000000149A84: CC22006E 02001973
	v_fma_mixlo_f16 v111, v116, s12, 0                         // 000000149A8C: CC21006F 02001974
	v_fma_mixhi_f16 v111, v117, s12, 0                         // 000000149A94: CC22006F 02001975
	v_fma_mixlo_f16 v112, v122, s12, 0                         // 000000149A9C: CC210070 0200197A
	v_fma_mixhi_f16 v112, v123, s12, 0                         // 000000149AA4: CC220070 0200197B
	v_fma_mixlo_f16 v113, v124, s12, 0                         // 000000149AAC: CC210071 0200197C
	v_fma_mixhi_f16 v113, v125, s12, 0                         // 000000149AB4: CC220071 0200197D
	s_waitcnt lgkmcnt(1)                                       // 000000149ABC: BF89FC17
	v_fma_mixlo_f16 v114, v5, s12, 0                           // 000000149AC0: CC210072 02001905
	v_fma_mixhi_f16 v114, v6, s12, 0                           // 000000149AC8: CC220072 02001906
	v_fma_mixlo_f16 v115, v7, s12, 0                           // 000000149AD0: CC210073 02001907
	v_fma_mixhi_f16 v115, v8, s12, 0                           // 000000149AD8: CC220073 02001908
	s_waitcnt lgkmcnt(0)                                       // 000000149AE0: BF89FC07
	v_fma_mixlo_f16 v116, v118, s12, 0                         // 000000149AE4: CC210074 02001976
	v_fma_mixhi_f16 v116, v119, s12, 0                         // 000000149AEC: CC220074 02001977
	v_fma_mixlo_f16 v117, v120, s12, 0                         // 000000149AF4: CC210075 02001978
	v_fma_mixhi_f16 v117, v121, s12, 0                         // 000000149AFC: CC220075 02001979
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[94:101], v[34:41]// 000000149B04: CC404022 1C8ABD32
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[102:109], v[26:33]// 000000149B0C: CC40401A 1C6ACD32
	s_delay_alu instid0(VALU_DEP_3)                            // 000000149B14: BF870003
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[110:117], v[18:25]// 000000149B18: CC404012 1C4ADD32
	.long 0x7f7039ba                                           // 000000149B20: 7F7039BA
	.long 0x7e7039ba                                           // 000000149B24: 7E7039BA
	.long 0x7f6e39ba                                           // 000000149B28: 7F6E39BA
	.long 0x7e6e39ba                                           // 000000149B2C: 7E6E39BA
	s_and_saveexec_b32 s1, s0                                  // 000000149B30: BE812000
	s_cbranch_execz 11                                         // 000000149B34: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1964>
	global_load_b128 v[5:8], v[3:4], off offset:320            // 000000149B38: DC5E0140 057C0003
	s_waitcnt vmcnt(0)                                         // 000000149B40: BF8903F7
	v_fma_mixlo_f16 v55, v5, s12, 0                            // 000000149B44: CC210037 02001905
	v_fma_mixhi_f16 v55, v6, s12, 0                            // 000000149B4C: CC220037 02001906
	v_fma_mixlo_f16 v56, v7, s12, 0                            // 000000149B54: CC210038 02001907
	v_fma_mixhi_f16 v56, v8, s12, 0                            // 000000149B5C: CC220038 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000149B64: 8C7E017E
	.long 0x7e7439ba                                           // 000000149B68: 7E7439BA
	.long 0x7f7239ba                                           // 000000149B6C: 7F7239BA
	.long 0x7e7239ba                                           // 000000149B70: 7E7239BA
	s_and_saveexec_b32 s1, s0                                  // 000000149B74: BE812000
	s_cbranch_execz 11                                         // 000000149B78: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19a8>
	global_load_b128 v[5:8], v[3:4], off offset:336            // 000000149B7C: DC5E0150 057C0003
	s_waitcnt vmcnt(0)                                         // 000000149B84: BF8903F7
	v_fma_mixlo_f16 v57, v5, s12, 0                            // 000000149B88: CC210039 02001905
	v_fma_mixhi_f16 v57, v6, s12, 0                            // 000000149B90: CC220039 02001906
	v_fma_mixlo_f16 v58, v7, s12, 0                            // 000000149B98: CC21003A 02001907
	v_fma_mixhi_f16 v58, v8, s12, 0                            // 000000149BA0: CC22003A 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000149BA8: 8C7E017E
	.long 0x7f7c3880                                           // 000000149BAC: 7F7C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000149BB0: BF870001
	.long 0x7f7839be                                           // 000000149BB4: 7F7839BE
	.long 0x7e7839be                                           // 000000149BB8: 7E7839BE
	.long 0x7f7639be                                           // 000000149BBC: 7F7639BE
	.long 0x7e7639be                                           // 000000149BC0: 7E7639BE
	s_and_saveexec_b32 s1, s0                                  // 000000149BC4: BE812000
	s_cbranch_execz 11                                         // 000000149BC8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19f8>
	global_load_b128 v[5:8], v[3:4], off offset:352            // 000000149BCC: DC5E0160 057C0003
	s_waitcnt vmcnt(0)                                         // 000000149BD4: BF8903F7
	v_fma_mixlo_f16 v59, v5, s12, 0                            // 000000149BD8: CC21003B 02001905
	v_fma_mixhi_f16 v59, v6, s12, 0                            // 000000149BE0: CC22003B 02001906
	v_fma_mixlo_f16 v60, v7, s12, 0                            // 000000149BE8: CC21003C 02001907
	v_fma_mixhi_f16 v60, v8, s12, 0                            // 000000149BF0: CC22003C 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000149BF8: 8C7E017E
	.long 0x7e7c39be                                           // 000000149BFC: 7E7C39BE
	.long 0x7f7a39be                                           // 000000149C00: 7F7A39BE
	.long 0x7e7a39be                                           // 000000149C04: 7E7A39BE
	s_and_saveexec_b32 s1, s0                                  // 000000149C08: BE812000
	s_cbranch_execz 11                                         // 000000149C0C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a3c>
	global_load_b128 v[5:8], v[3:4], off offset:368            // 000000149C10: DC5E0170 057C0003
	s_waitcnt vmcnt(0)                                         // 000000149C18: BF8903F7
	v_fma_mixlo_f16 v61, v5, s12, 0                            // 000000149C1C: CC21003D 02001905
	v_fma_mixhi_f16 v61, v6, s12, 0                            // 000000149C24: CC22003D 02001906
	v_fma_mixlo_f16 v62, v7, s12, 0                            // 000000149C2C: CC21003E 02001907
	v_fma_mixhi_f16 v62, v8, s12, 0                            // 000000149C34: CC22003E 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000149C3C: 8C7E017E
	ds_load_b128 v[5:8], v80 offset:320                        // 000000149C40: DBFC0140 05000050
	ds_load_b128 v[50:53], v80 offset:336                      // 000000149C48: DBFC0150 32000050
	ds_load_b128 v[63:66], v80 offset:352                      // 000000149C50: DBFC0160 3F000050
	ds_load_b128 v[100:103], v80 offset:368                    // 000000149C58: DBFC0170 64000050
	ds_load_b128 v[104:107], v80 offset:8768                   // 000000149C60: DBFC2240 68000050
	ds_load_b128 v[108:111], v80 offset:8784                   // 000000149C68: DBFC2250 6C000050
	ds_load_b128 v[112:115], v80 offset:8800                   // 000000149C70: DBFC2260 70000050
	ds_load_b128 v[116:119], v80 offset:8816                   // 000000149C78: DBFC2270 74000050
	ds_load_b128 v[124:127], v80 offset:25664                  // 000000149C80: DBFC6440 7C000050
	ds_load_b128 v[128:131], v80 offset:25680                  // 000000149C88: DBFC6450 80000050
	ds_load_b128 v[120:123], v80 offset:17264                  // 000000149C90: DBFC4370 78000050
	s_waitcnt lgkmcnt(10)                                      // 000000149C98: BF89FCA7
	v_fma_mixlo_f16 v94, v5, s12, 0                            // 000000149C9C: CC21005E 02001905
	v_fma_mixhi_f16 v94, v6, s12, 0                            // 000000149CA4: CC22005E 02001906
	v_fma_mixlo_f16 v95, v7, s12, 0                            // 000000149CAC: CC21005F 02001907
	v_fma_mixhi_f16 v95, v8, s12, 0                            // 000000149CB4: CC22005F 02001908
	s_waitcnt lgkmcnt(9)                                       // 000000149CBC: BF89FC97
	v_fma_mixlo_f16 v96, v50, s12, 0                           // 000000149CC0: CC210060 02001932
	v_fma_mixhi_f16 v96, v51, s12, 0                           // 000000149CC8: CC220060 02001933
	v_fma_mixlo_f16 v97, v52, s12, 0                           // 000000149CD0: CC210061 02001934
	v_fma_mixhi_f16 v97, v53, s12, 0                           // 000000149CD8: CC220061 02001935
	ds_load_b128 v[5:8], v80 offset:17216                      // 000000149CE0: DBFC4340 05000050
	ds_load_b128 v[50:53], v80 offset:17232                    // 000000149CE8: DBFC4350 32000050
	s_waitcnt lgkmcnt(10)                                      // 000000149CF0: BF89FCA7
	v_fma_mixlo_f16 v98, v63, s12, 0                           // 000000149CF4: CC210062 0200193F
	v_fma_mixhi_f16 v98, v64, s12, 0                           // 000000149CFC: CC220062 02001940
	v_fma_mixlo_f16 v99, v65, s12, 0                           // 000000149D04: CC210063 02001941
	v_fma_mixhi_f16 v99, v66, s12, 0                           // 000000149D0C: CC220063 02001942
	s_waitcnt lgkmcnt(9)                                       // 000000149D14: BF89FC97
	v_fma_mixlo_f16 v100, v100, s12, 0                         // 000000149D18: CC210064 02001964
	v_fma_mixhi_f16 v100, v101, s12, 0                         // 000000149D20: CC220064 02001965
	v_fma_mixlo_f16 v101, v102, s12, 0                         // 000000149D28: CC210065 02001966
	v_fma_mixhi_f16 v101, v103, s12, 0                         // 000000149D30: CC220065 02001967
	s_waitcnt lgkmcnt(8)                                       // 000000149D38: BF89FC87
	v_fma_mixhi_f16 v102, v105, s12, 0                         // 000000149D3C: CC220066 02001969
	v_fma_mixlo_f16 v103, v106, s12, 0                         // 000000149D44: CC210067 0200196A
	s_waitcnt lgkmcnt(7)                                       // 000000149D4C: BF89FC77
	v_fma_mixlo_f16 v105, v110, s12, 0                         // 000000149D50: CC210069 0200196E
	v_fma_mixhi_f16 v105, v111, s12, 0                         // 000000149D58: CC220069 0200196F
	s_waitcnt lgkmcnt(6)                                       // 000000149D60: BF89FC67
	v_fma_mixlo_f16 v106, v112, s12, 0                         // 000000149D64: CC21006A 02001970
	ds_load_b128 v[63:66], v80 offset:17248                    // 000000149D6C: DBFC4360 3F000050
	v_fma_mixhi_f16 v106, v113, s12, 0                         // 000000149D74: CC22006A 02001971
	v_fma_mixlo_f16 v102, v104, s12, 0                         // 000000149D7C: CC210066 02001968
	v_fma_mixhi_f16 v103, v107, s12, 0                         // 000000149D84: CC220067 0200196B
	v_fma_mixlo_f16 v104, v108, s12, 0                         // 000000149D8C: CC210068 0200196C
	s_waitcnt lgkmcnt(2)                                       // 000000149D94: BF89FC27
	v_fma_mixlo_f16 v110, v5, s12, 0                           // 000000149D98: CC21006E 02001905
	v_fma_mixhi_f16 v110, v6, s12, 0                           // 000000149DA0: CC22006E 02001906
	v_fma_mixlo_f16 v111, v7, s12, 0                           // 000000149DA8: CC21006F 02001907
	v_fma_mixhi_f16 v111, v8, s12, 0                           // 000000149DB0: CC22006F 02001908
	s_waitcnt lgkmcnt(1)                                       // 000000149DB8: BF89FC17
	v_fma_mixlo_f16 v112, v50, s12, 0                          // 000000149DBC: CC210070 02001932
	v_fma_mixhi_f16 v112, v51, s12, 0                          // 000000149DC4: CC220070 02001933
	ds_load_b128 v[5:8], v80 offset:25696                      // 000000149DCC: DBFC6460 05000050
	v_fma_mixlo_f16 v113, v52, s12, 0                          // 000000149DD4: CC210071 02001934
	v_fma_mixhi_f16 v113, v53, s12, 0                          // 000000149DDC: CC220071 02001935
	ds_load_b128 v[50:53], v80 offset:25712                    // 000000149DE4: DBFC6470 32000050
	v_fma_mixhi_f16 v104, v109, s12, 0                         // 000000149DEC: CC220068 0200196D
	v_fma_mixlo_f16 v107, v114, s12, 0                         // 000000149DF4: CC21006B 02001972
	v_fma_mixhi_f16 v107, v115, s12, 0                         // 000000149DFC: CC22006B 02001973
	v_fma_mixlo_f16 v108, v116, s12, 0                         // 000000149E04: CC21006C 02001974
	v_fma_mixhi_f16 v108, v117, s12, 0                         // 000000149E0C: CC22006C 02001975
	v_fma_mixlo_f16 v109, v118, s12, 0                         // 000000149E14: CC21006D 02001976
	v_fma_mixhi_f16 v109, v119, s12, 0                         // 000000149E1C: CC22006D 02001977
	s_waitcnt lgkmcnt(2)                                       // 000000149E24: BF89FC27
	v_fma_mixlo_f16 v114, v63, s12, 0                          // 000000149E28: CC210072 0200193F
	v_fma_mixhi_f16 v114, v64, s12, 0                          // 000000149E30: CC220072 02001940
	v_fma_mixlo_f16 v115, v65, s12, 0                          // 000000149E38: CC210073 02001941
	v_fma_mixhi_f16 v115, v66, s12, 0                          // 000000149E40: CC220073 02001942
	v_fma_mixlo_f16 v116, v120, s12, 0                         // 000000149E48: CC210074 02001978
	v_fma_mixhi_f16 v116, v121, s12, 0                         // 000000149E50: CC220074 02001979
	v_fma_mixlo_f16 v117, v122, s12, 0                         // 000000149E58: CC210075 0200197A
	v_fma_mixhi_f16 v117, v123, s12, 0                         // 000000149E60: CC220075 0200197B
	v_fma_mixlo_f16 v118, v124, s12, 0                         // 000000149E68: CC210076 0200197C
	v_fma_mixhi_f16 v118, v125, s12, 0                         // 000000149E70: CC220076 0200197D
	v_fma_mixlo_f16 v119, v126, s12, 0                         // 000000149E78: CC210077 0200197E
	v_fma_mixhi_f16 v119, v127, s12, 0                         // 000000149E80: CC220077 0200197F
	v_fma_mixlo_f16 v120, v128, s12, 0                         // 000000149E88: CC210078 02001980
	v_fma_mixhi_f16 v120, v129, s12, 0                         // 000000149E90: CC220078 02001981
	v_fma_mixlo_f16 v121, v130, s12, 0                         // 000000149E98: CC210079 02001982
	v_fma_mixhi_f16 v121, v131, s12, 0                         // 000000149EA0: CC220079 02001983
	s_waitcnt lgkmcnt(1)                                       // 000000149EA8: BF89FC17
	v_fma_mixlo_f16 v122, v5, s12, 0                           // 000000149EAC: CC21007A 02001905
	v_fma_mixhi_f16 v122, v6, s12, 0                           // 000000149EB4: CC22007A 02001906
	v_fma_mixlo_f16 v123, v7, s12, 0                           // 000000149EBC: CC21007B 02001907
	v_fma_mixhi_f16 v123, v8, s12, 0                           // 000000149EC4: CC22007B 02001908
	s_waitcnt lgkmcnt(0)                                       // 000000149ECC: BF89FC07
	v_fma_mixlo_f16 v124, v50, s12, 0                          // 000000149ED0: CC21007C 02001932
	v_fma_mixhi_f16 v124, v51, s12, 0                          // 000000149ED8: CC22007C 02001933
	v_fma_mixlo_f16 v125, v52, s12, 0                          // 000000149EE0: CC21007D 02001934
	v_fma_mixhi_f16 v125, v53, s12, 0                          // 000000149EE8: CC22007D 02001935
	.long 0x7f7e3880                                           // 000000149EF0: 7F7E3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[55:62], v[94:101], v[42:49]// 000000149EF4: CC40402A 1CAABD37
	v_wmma_f32_16x16x16_f16 v[34:41], v[55:62], v[102:109], v[34:41]// 000000149EFC: CC404022 1C8ACD37
	v_wmma_f32_16x16x16_f16 v[26:33], v[55:62], v[110:117], v[26:33]// 000000149F04: CC40401A 1C6ADD37
	v_wmma_f32_16x16x16_f16 v[18:25], v[55:62], v[118:125], v[18:25]// 000000149F0C: CC404012 1C4AED37
	.long 0x7f7a39bf                                           // 000000149F14: 7F7A39BF
	.long 0x7e7a39bf                                           // 000000149F18: 7E7A39BF
	.long 0x7f7839bf                                           // 000000149F1C: 7F7839BF
	.long 0x7e7839bf                                           // 000000149F20: 7E7839BF
	s_and_saveexec_b32 s1, s0                                  // 000000149F24: BE812000
	s_cbranch_execz 11                                         // 000000149F28: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d58>
	global_load_b128 v[5:8], v[3:4], off offset:384            // 000000149F2C: DC5E0180 057C0003
	s_waitcnt vmcnt(0)                                         // 000000149F34: BF8903F7
	v_fma_mixlo_f16 v60, v5, s12, 0                            // 000000149F38: CC21003C 02001905
	v_fma_mixhi_f16 v60, v6, s12, 0                            // 000000149F40: CC22003C 02001906
	v_fma_mixlo_f16 v61, v7, s12, 0                            // 000000149F48: CC21003D 02001907
	v_fma_mixhi_f16 v61, v8, s12, 0                            // 000000149F50: CC22003D 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000149F58: 8C7E017E
	.long 0x7e7e39bf                                           // 000000149F5C: 7E7E39BF
	.long 0x7f7c39bf                                           // 000000149F60: 7F7C39BF
	.long 0x7e7c39bf                                           // 000000149F64: 7E7C39BF
	s_and_saveexec_b32 s1, s0                                  // 000000149F68: BE812000
	s_cbranch_execz 11                                         // 000000149F6C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d9c>
	global_load_b128 v[5:8], v[3:4], off offset:400            // 000000149F70: DC5E0190 057C0003
	s_waitcnt vmcnt(0)                                         // 000000149F78: BF8903F7
	v_fma_mixlo_f16 v62, v5, s12, 0                            // 000000149F7C: CC21003E 02001905
	v_fma_mixhi_f16 v62, v6, s12, 0                            // 000000149F84: CC22003E 02001906
	v_fma_mixlo_f16 v63, v7, s12, 0                            // 000000149F8C: CC21003F 02001907
	v_fma_mixhi_f16 v63, v8, s12, 0                            // 000000149F94: CC22003F 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000149F9C: 8C7E017E
	.long 0x7f863880                                           // 000000149FA0: 7F863880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000149FA4: BF870001
	.long 0x7f8239c3                                           // 000000149FA8: 7F8239C3
	.long 0x7e8239c3                                           // 000000149FAC: 7E8239C3
	.long 0x7f8039c3                                           // 000000149FB0: 7F8039C3
	.long 0x7e8039c3                                           // 000000149FB4: 7E8039C3
	s_and_saveexec_b32 s1, s0                                  // 000000149FB8: BE812000
	s_cbranch_execz 11                                         // 000000149FBC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dec>
	global_load_b128 v[5:8], v[3:4], off offset:416            // 000000149FC0: DC5E01A0 057C0003
	s_waitcnt vmcnt(0)                                         // 000000149FC8: BF8903F7
	v_fma_mixlo_f16 v64, v5, s12, 0                            // 000000149FCC: CC210040 02001905
	v_fma_mixhi_f16 v64, v6, s12, 0                            // 000000149FD4: CC220040 02001906
	v_fma_mixlo_f16 v65, v7, s12, 0                            // 000000149FDC: CC210041 02001907
	v_fma_mixhi_f16 v65, v8, s12, 0                            // 000000149FE4: CC220041 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 000000149FEC: 8C7E017E
	.long 0x7e8639c3                                           // 000000149FF0: 7E8639C3
	.long 0x7f8439c3                                           // 000000149FF4: 7F8439C3
	.long 0x7e8439c3                                           // 000000149FF8: 7E8439C3
	s_and_saveexec_b32 s1, s0                                  // 000000149FFC: BE812000
	s_cbranch_execz 11                                         // 00000014A000: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e30>
	global_load_b128 v[5:8], v[3:4], off offset:432            // 00000014A004: DC5E01B0 057C0003
	s_waitcnt vmcnt(0)                                         // 00000014A00C: BF8903F7
	v_fma_mixlo_f16 v66, v5, s12, 0                            // 00000014A010: CC210042 02001905
	v_fma_mixhi_f16 v66, v6, s12, 0                            // 00000014A018: CC220042 02001906
	v_fma_mixlo_f16 v67, v7, s12, 0                            // 00000014A020: CC210043 02001907
	v_fma_mixhi_f16 v67, v8, s12, 0                            // 00000014A028: CC220043 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014A030: 8C7E017E
	ds_load_b128 v[5:8], v80 offset:384                        // 00000014A034: DBFC0180 05000050
	ds_load_b128 v[50:53], v80 offset:400                      // 00000014A03C: DBFC0190 32000050
	ds_load_b128 v[54:57], v80 offset:416                      // 00000014A044: DBFC01A0 36000050
	ds_load_b128 v[100:103], v80 offset:432                    // 00000014A04C: DBFC01B0 64000050
	ds_load_b128 v[104:107], v80 offset:8832                   // 00000014A054: DBFC2280 68000050
	ds_load_b128 v[108:111], v80 offset:8848                   // 00000014A05C: DBFC2290 6C000050
	ds_load_b128 v[112:115], v80 offset:8864                   // 00000014A064: DBFC22A0 70000050
	ds_load_b128 v[116:119], v80 offset:8880                   // 00000014A06C: DBFC22B0 74000050
	ds_load_b128 v[124:127], v80 offset:25728                  // 00000014A074: DBFC6480 7C000050
	ds_load_b128 v[128:131], v80 offset:25744                  // 00000014A07C: DBFC6490 80000050
	ds_load_b128 v[120:123], v80 offset:17328                  // 00000014A084: DBFC43B0 78000050
	s_waitcnt lgkmcnt(10)                                      // 00000014A08C: BF89FCA7
	v_fma_mixlo_f16 v94, v5, s12, 0                            // 00000014A090: CC21005E 02001905
	v_fma_mixhi_f16 v94, v6, s12, 0                            // 00000014A098: CC22005E 02001906
	v_fma_mixlo_f16 v95, v7, s12, 0                            // 00000014A0A0: CC21005F 02001907
	v_fma_mixhi_f16 v95, v8, s12, 0                            // 00000014A0A8: CC22005F 02001908
	s_waitcnt lgkmcnt(9)                                       // 00000014A0B0: BF89FC97
	v_fma_mixlo_f16 v96, v50, s12, 0                           // 00000014A0B4: CC210060 02001932
	v_fma_mixhi_f16 v96, v51, s12, 0                           // 00000014A0BC: CC220060 02001933
	v_fma_mixlo_f16 v97, v52, s12, 0                           // 00000014A0C4: CC210061 02001934
	v_fma_mixhi_f16 v97, v53, s12, 0                           // 00000014A0CC: CC220061 02001935
	ds_load_b128 v[5:8], v80 offset:17280                      // 00000014A0D4: DBFC4380 05000050
	ds_load_b128 v[50:53], v80 offset:17296                    // 00000014A0DC: DBFC4390 32000050
	s_waitcnt lgkmcnt(10)                                      // 00000014A0E4: BF89FCA7
	v_fma_mixlo_f16 v98, v54, s12, 0                           // 00000014A0E8: CC210062 02001936
	v_fma_mixhi_f16 v98, v55, s12, 0                           // 00000014A0F0: CC220062 02001937
	v_fma_mixlo_f16 v99, v56, s12, 0                           // 00000014A0F8: CC210063 02001938
	v_fma_mixhi_f16 v99, v57, s12, 0                           // 00000014A100: CC220063 02001939
	s_waitcnt lgkmcnt(9)                                       // 00000014A108: BF89FC97
	v_fma_mixlo_f16 v100, v100, s12, 0                         // 00000014A10C: CC210064 02001964
	v_fma_mixhi_f16 v100, v101, s12, 0                         // 00000014A114: CC220064 02001965
	v_fma_mixlo_f16 v101, v102, s12, 0                         // 00000014A11C: CC210065 02001966
	v_fma_mixhi_f16 v101, v103, s12, 0                         // 00000014A124: CC220065 02001967
	s_waitcnt lgkmcnt(8)                                       // 00000014A12C: BF89FC87
	v_fma_mixhi_f16 v102, v105, s12, 0                         // 00000014A130: CC220066 02001969
	v_fma_mixlo_f16 v103, v106, s12, 0                         // 00000014A138: CC210067 0200196A
	s_waitcnt lgkmcnt(7)                                       // 00000014A140: BF89FC77
	v_fma_mixlo_f16 v105, v110, s12, 0                         // 00000014A144: CC210069 0200196E
	v_fma_mixhi_f16 v105, v111, s12, 0                         // 00000014A14C: CC220069 0200196F
	s_waitcnt lgkmcnt(6)                                       // 00000014A154: BF89FC67
	v_fma_mixlo_f16 v106, v112, s12, 0                         // 00000014A158: CC21006A 02001970
	ds_load_b128 v[54:57], v80 offset:17312                    // 00000014A160: DBFC43A0 36000050
	v_fma_mixhi_f16 v106, v113, s12, 0                         // 00000014A168: CC22006A 02001971
	v_fma_mixlo_f16 v102, v104, s12, 0                         // 00000014A170: CC210066 02001968
	v_fma_mixhi_f16 v103, v107, s12, 0                         // 00000014A178: CC220067 0200196B
	v_fma_mixlo_f16 v104, v108, s12, 0                         // 00000014A180: CC210068 0200196C
	s_waitcnt lgkmcnt(2)                                       // 00000014A188: BF89FC27
	v_fma_mixlo_f16 v110, v5, s12, 0                           // 00000014A18C: CC21006E 02001905
	v_fma_mixhi_f16 v110, v6, s12, 0                           // 00000014A194: CC22006E 02001906
	v_fma_mixlo_f16 v111, v7, s12, 0                           // 00000014A19C: CC21006F 02001907
	v_fma_mixhi_f16 v111, v8, s12, 0                           // 00000014A1A4: CC22006F 02001908
	s_waitcnt lgkmcnt(1)                                       // 00000014A1AC: BF89FC17
	v_fma_mixlo_f16 v112, v50, s12, 0                          // 00000014A1B0: CC210070 02001932
	v_fma_mixhi_f16 v112, v51, s12, 0                          // 00000014A1B8: CC220070 02001933
	ds_load_b128 v[5:8], v80 offset:25760                      // 00000014A1C0: DBFC64A0 05000050
	v_fma_mixlo_f16 v113, v52, s12, 0                          // 00000014A1C8: CC210071 02001934
	v_fma_mixhi_f16 v113, v53, s12, 0                          // 00000014A1D0: CC220071 02001935
	ds_load_b128 v[50:53], v80 offset:25776                    // 00000014A1D8: DBFC64B0 32000050
	v_fma_mixhi_f16 v104, v109, s12, 0                         // 00000014A1E0: CC220068 0200196D
	v_fma_mixlo_f16 v107, v114, s12, 0                         // 00000014A1E8: CC21006B 02001972
	v_fma_mixhi_f16 v107, v115, s12, 0                         // 00000014A1F0: CC22006B 02001973
	v_fma_mixlo_f16 v108, v116, s12, 0                         // 00000014A1F8: CC21006C 02001974
	v_fma_mixhi_f16 v108, v117, s12, 0                         // 00000014A200: CC22006C 02001975
	v_fma_mixlo_f16 v109, v118, s12, 0                         // 00000014A208: CC21006D 02001976
	v_fma_mixhi_f16 v109, v119, s12, 0                         // 00000014A210: CC22006D 02001977
	s_waitcnt lgkmcnt(2)                                       // 00000014A218: BF89FC27
	v_fma_mixlo_f16 v114, v54, s12, 0                          // 00000014A21C: CC210072 02001936
	v_fma_mixhi_f16 v114, v55, s12, 0                          // 00000014A224: CC220072 02001937
	v_fma_mixlo_f16 v115, v56, s12, 0                          // 00000014A22C: CC210073 02001938
	v_fma_mixhi_f16 v115, v57, s12, 0                          // 00000014A234: CC220073 02001939
	v_fma_mixlo_f16 v116, v120, s12, 0                         // 00000014A23C: CC210074 02001978
	v_fma_mixhi_f16 v116, v121, s12, 0                         // 00000014A244: CC220074 02001979
	v_fma_mixlo_f16 v117, v122, s12, 0                         // 00000014A24C: CC210075 0200197A
	v_fma_mixhi_f16 v117, v123, s12, 0                         // 00000014A254: CC220075 0200197B
	v_fma_mixlo_f16 v118, v124, s12, 0                         // 00000014A25C: CC210076 0200197C
	v_fma_mixhi_f16 v118, v125, s12, 0                         // 00000014A264: CC220076 0200197D
	v_fma_mixlo_f16 v119, v126, s12, 0                         // 00000014A26C: CC210077 0200197E
	v_fma_mixhi_f16 v119, v127, s12, 0                         // 00000014A274: CC220077 0200197F
	v_fma_mixlo_f16 v120, v128, s12, 0                         // 00000014A27C: CC210078 02001980
	v_fma_mixhi_f16 v120, v129, s12, 0                         // 00000014A284: CC220078 02001981
	v_fma_mixlo_f16 v121, v130, s12, 0                         // 00000014A28C: CC210079 02001982
	v_fma_mixhi_f16 v121, v131, s12, 0                         // 00000014A294: CC220079 02001983
	s_waitcnt lgkmcnt(1)                                       // 00000014A29C: BF89FC17
	v_fma_mixlo_f16 v122, v5, s12, 0                           // 00000014A2A0: CC21007A 02001905
	v_fma_mixhi_f16 v122, v6, s12, 0                           // 00000014A2A8: CC22007A 02001906
	v_fma_mixlo_f16 v123, v7, s12, 0                           // 00000014A2B0: CC21007B 02001907
	v_fma_mixhi_f16 v123, v8, s12, 0                           // 00000014A2B8: CC22007B 02001908
	s_waitcnt lgkmcnt(0)                                       // 00000014A2C0: BF89FC07
	v_fma_mixlo_f16 v124, v50, s12, 0                          // 00000014A2C4: CC21007C 02001932
	v_fma_mixhi_f16 v124, v51, s12, 0                          // 00000014A2CC: CC22007C 02001933
	v_fma_mixlo_f16 v125, v52, s12, 0                          // 00000014A2D4: CC21007D 02001934
	v_fma_mixhi_f16 v125, v53, s12, 0                          // 00000014A2DC: CC22007D 02001935
	.long 0x7f6a3880                                           // 00000014A2E4: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[60:67], v[94:101], v[42:49]// 00000014A2E8: CC40402A 1CAABD3C
	v_wmma_f32_16x16x16_f16 v[34:41], v[60:67], v[102:109], v[34:41]// 00000014A2F0: CC404022 1C8ACD3C
	v_wmma_f32_16x16x16_f16 v[26:33], v[60:67], v[110:117], v[26:33]// 00000014A2F8: CC40401A 1C6ADD3C
	v_wmma_f32_16x16x16_f16 v[18:25], v[60:67], v[118:125], v[18:25]// 00000014A300: CC404012 1C4AED3C
	.long 0x7f6639b5                                           // 00000014A308: 7F6639B5
	.long 0x7e6639b5                                           // 00000014A30C: 7E6639B5
	.long 0x7f6439b5                                           // 00000014A310: 7F6439B5
	.long 0x7e6439b5                                           // 00000014A314: 7E6439B5
	s_and_saveexec_b32 s1, s0                                  // 00000014A318: BE812000
	s_cbranch_execz 11                                         // 00000014A31C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x214c>
	global_load_b128 v[5:8], v[3:4], off offset:448            // 00000014A320: DC5E01C0 057C0003
	s_waitcnt vmcnt(0)                                         // 00000014A328: BF8903F7
	v_fma_mixlo_f16 v50, v5, s12, 0                            // 00000014A32C: CC210032 02001905
	v_fma_mixhi_f16 v50, v6, s12, 0                            // 00000014A334: CC220032 02001906
	v_fma_mixlo_f16 v51, v7, s12, 0                            // 00000014A33C: CC210033 02001907
	v_fma_mixhi_f16 v51, v8, s12, 0                            // 00000014A344: CC220033 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014A34C: 8C7E017E
	.long 0x7e6a39b5                                           // 00000014A350: 7E6A39B5
	.long 0x7f6839b5                                           // 00000014A354: 7F6839B5
	.long 0x7e6839b5                                           // 00000014A358: 7E6839B5
	s_and_saveexec_b32 s1, s0                                  // 00000014A35C: BE812000
	s_cbranch_execz 11                                         // 00000014A360: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2190>
	global_load_b128 v[5:8], v[3:4], off offset:464            // 00000014A364: DC5E01D0 057C0003
	s_waitcnt vmcnt(0)                                         // 00000014A36C: BF8903F7
	v_fma_mixlo_f16 v52, v5, s12, 0                            // 00000014A370: CC210034 02001905
	v_fma_mixhi_f16 v52, v6, s12, 0                            // 00000014A378: CC220034 02001906
	v_fma_mixlo_f16 v53, v7, s12, 0                            // 00000014A380: CC210035 02001907
	v_fma_mixhi_f16 v53, v8, s12, 0                            // 00000014A388: CC220035 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014A390: 8C7E017E
	.long 0x7f723880                                           // 00000014A394: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014A398: BF870001
	.long 0x7f6e39b9                                           // 00000014A39C: 7F6E39B9
	.long 0x7e6e39b9                                           // 00000014A3A0: 7E6E39B9
	.long 0x7f6c39b9                                           // 00000014A3A4: 7F6C39B9
	.long 0x7e6c39b9                                           // 00000014A3A8: 7E6C39B9
	s_and_saveexec_b32 s1, s0                                  // 00000014A3AC: BE812000
	s_cbranch_execz 11                                         // 00000014A3B0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x21e0>
	global_load_b128 v[5:8], v[3:4], off offset:480            // 00000014A3B4: DC5E01E0 057C0003
	s_waitcnt vmcnt(0)                                         // 00000014A3BC: BF8903F7
	v_fma_mixlo_f16 v54, v5, s12, 0                            // 00000014A3C0: CC210036 02001905
	v_fma_mixhi_f16 v54, v6, s12, 0                            // 00000014A3C8: CC220036 02001906
	v_fma_mixlo_f16 v55, v7, s12, 0                            // 00000014A3D0: CC210037 02001907
	v_fma_mixhi_f16 v55, v8, s12, 0                            // 00000014A3D8: CC220037 02001908
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014A3E0: 8C7E017E
	.long 0x7e7239b9                                           // 00000014A3E4: 7E7239B9
	.long 0x7f7039b9                                           // 00000014A3E8: 7F7039B9
	.long 0x7e7039b9                                           // 00000014A3EC: 7E7039B9
	s_and_saveexec_b32 s1, s0                                  // 00000014A3F0: BE812000
	s_cbranch_execz 11                                         // 00000014A3F4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2224>
	global_load_b128 v[3:6], v[3:4], off offset:496            // 00000014A3F8: DC5E01F0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014A400: BF8903F7
	v_fma_mixlo_f16 v56, v3, s12, 0                            // 00000014A404: CC210038 02001903
	v_fma_mixhi_f16 v56, v4, s12, 0                            // 00000014A40C: CC220038 02001904
	v_fma_mixlo_f16 v57, v5, s12, 0                            // 00000014A414: CC210039 02001905
	v_fma_mixhi_f16 v57, v6, s12, 0                            // 00000014A41C: CC220039 02001906
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014A424: 8C7E017E
	ds_load_b128 v[3:6], v80 offset:448                        // 00000014A428: DBFC01C0 03000050
	ds_load_b128 v[60:63], v80 offset:464                      // 00000014A430: DBFC01D0 3C000050
	ds_load_b128 v[64:67], v80 offset:480                      // 00000014A438: DBFC01E0 40000050
	ds_load_b128 v[94:97], v80 offset:496                      // 00000014A440: DBFC01F0 5E000050
	ds_load_b128 v[98:101], v80 offset:8896                    // 00000014A448: DBFC22C0 62000050
	ds_load_b128 v[102:105], v80 offset:8912                   // 00000014A450: DBFC22D0 66000050
	ds_load_b128 v[106:109], v80 offset:8928                   // 00000014A458: DBFC22E0 6A000050
	ds_load_b128 v[110:113], v80 offset:25808                  // 00000014A460: DBFC64D0 6E000050
	ds_load_b128 v[114:117], v80 offset:25824                  // 00000014A468: DBFC64E0 72000050
	ds_load_b128 v[118:121], v80 offset:25840                  // 00000014A470: DBFC64F0 76000050
	s_waitcnt lgkmcnt(9)                                       // 00000014A478: BF89FC97
	v_fma_mixlo_f16 v58, v3, s12, 0                            // 00000014A47C: CC21003A 02001903
	v_fma_mixhi_f16 v58, v4, s12, 0                            // 00000014A484: CC22003A 02001904
	v_fma_mixlo_f16 v59, v5, s12, 0                            // 00000014A48C: CC21003B 02001905
	v_fma_mixhi_f16 v59, v6, s12, 0                            // 00000014A494: CC22003B 02001906
	ds_load_b128 v[3:6], v80 offset:8944                       // 00000014A49C: DBFC22F0 03000050
	s_waitcnt lgkmcnt(9)                                       // 00000014A4A4: BF89FC97
	v_fma_mixlo_f16 v60, v60, s12, 0                           // 00000014A4A8: CC21003C 0200193C
	v_fma_mixhi_f16 v60, v61, s12, 0                           // 00000014A4B0: CC22003C 0200193D
	v_fma_mixlo_f16 v61, v62, s12, 0                           // 00000014A4B8: CC21003D 0200193E
	v_fma_mixhi_f16 v61, v63, s12, 0                           // 00000014A4C0: CC22003D 0200193F
	s_waitcnt lgkmcnt(8)                                       // 00000014A4C8: BF89FC87
	v_fma_mixlo_f16 v62, v64, s12, 0                           // 00000014A4CC: CC21003E 02001940
	v_fma_mixhi_f16 v62, v65, s12, 0                           // 00000014A4D4: CC22003E 02001941
	v_fma_mixlo_f16 v63, v66, s12, 0                           // 00000014A4DC: CC21003F 02001942
	v_fma_mixhi_f16 v63, v67, s12, 0                           // 00000014A4E4: CC22003F 02001943
	s_waitcnt lgkmcnt(7)                                       // 00000014A4EC: BF89FC77
	v_fma_mixlo_f16 v64, v94, s12, 0                           // 00000014A4F0: CC210040 0200195E
	v_fma_mixhi_f16 v64, v95, s12, 0                           // 00000014A4F8: CC220040 0200195F
	v_fma_mixlo_f16 v65, v96, s12, 0                           // 00000014A500: CC210041 02001960
	v_fma_mixhi_f16 v65, v97, s12, 0                           // 00000014A508: CC220041 02001961
	s_waitcnt lgkmcnt(6)                                       // 00000014A510: BF89FC67
	v_fma_mixlo_f16 v94, v98, s12, 0                           // 00000014A514: CC21005E 02001962
	v_fma_mixhi_f16 v94, v99, s12, 0                           // 00000014A51C: CC22005E 02001963
	v_fma_mixlo_f16 v95, v100, s12, 0                          // 00000014A524: CC21005F 02001964
	v_fma_mixhi_f16 v95, v101, s12, 0                          // 00000014A52C: CC22005F 02001965
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[58:65], v[42:49]// 00000014A534: CC40402A 1CAA7532
	ds_load_b128 v[58:61], v80 offset:17344                    // 00000014A53C: DBFC43C0 3A000050
	s_waitcnt lgkmcnt(6)                                       // 00000014A544: BF89FC67
	v_fma_mixlo_f16 v96, v102, s12, 0                          // 00000014A548: CC210060 02001966
	ds_load_b128 v[62:65], v80 offset:17360                    // 00000014A550: DBFC43D0 3E000050
	v_fma_mixhi_f16 v96, v103, s12, 0                          // 00000014A558: CC220060 02001967
	v_fma_mixlo_f16 v97, v104, s12, 0                          // 00000014A560: CC210061 02001968
	v_fma_mixhi_f16 v97, v105, s12, 0                          // 00000014A568: CC220061 02001969
	s_waitcnt lgkmcnt(6)                                       // 00000014A570: BF89FC67
	v_fma_mixlo_f16 v98, v106, s12, 0                          // 00000014A574: CC210062 0200196A
	ds_load_b128 v[102:105], v80 offset:17376                  // 00000014A57C: DBFC43E0 66000050
	v_fma_mixhi_f16 v98, v107, s12, 0                          // 00000014A584: CC220062 0200196B
	v_fma_mixlo_f16 v99, v108, s12, 0                          // 00000014A58C: CC210063 0200196C
	v_fma_mixhi_f16 v99, v109, s12, 0                          // 00000014A594: CC220063 0200196D
	s_waitcnt lgkmcnt(3)                                       // 00000014A59C: BF89FC37
	v_fma_mixlo_f16 v100, v3, s12, 0                           // 00000014A5A0: CC210064 02001903
	ds_load_b128 v[106:109], v80 offset:17392                  // 00000014A5A8: DBFC43F0 6A000050
	v_fma_mixhi_f16 v100, v4, s12, 0                           // 00000014A5B0: CC220064 02001904
	v_fma_mixlo_f16 v101, v5, s12, 0                           // 00000014A5B8: CC210065 02001905
	v_fma_mixhi_f16 v101, v6, s12, 0                           // 00000014A5C0: CC220065 02001906
	ds_load_b128 v[3:6], v80 offset:25792                      // 00000014A5C8: DBFC64C0 03000050
	s_waitcnt lgkmcnt(4)                                       // 00000014A5D0: BF89FC47
	v_fma_mixlo_f16 v58, v58, s12, 0                           // 00000014A5D4: CC21003A 0200193A
	v_fma_mixhi_f16 v58, v59, s12, 0                           // 00000014A5DC: CC22003A 0200193B
	v_fma_mixlo_f16 v59, v60, s12, 0                           // 00000014A5E4: CC21003B 0200193C
	v_fma_mixhi_f16 v59, v61, s12, 0                           // 00000014A5EC: CC22003B 0200193D
	s_waitcnt lgkmcnt(3)                                       // 00000014A5F4: BF89FC37
	v_fma_mixlo_f16 v60, v62, s12, 0                           // 00000014A5F8: CC21003C 0200193E
	v_fma_mixhi_f16 v60, v63, s12, 0                           // 00000014A600: CC22003C 0200193F
	v_fma_mixlo_f16 v61, v64, s12, 0                           // 00000014A608: CC21003D 02001940
	v_fma_mixhi_f16 v61, v65, s12, 0                           // 00000014A610: CC22003D 02001941
	s_waitcnt lgkmcnt(2)                                       // 00000014A618: BF89FC27
	v_fma_mixlo_f16 v62, v102, s12, 0                          // 00000014A61C: CC21003E 02001966
	v_fma_mixhi_f16 v62, v103, s12, 0                          // 00000014A624: CC22003E 02001967
	v_fma_mixlo_f16 v63, v104, s12, 0                          // 00000014A62C: CC21003F 02001968
	v_fma_mixhi_f16 v63, v105, s12, 0                          // 00000014A634: CC22003F 02001969
	s_waitcnt lgkmcnt(1)                                       // 00000014A63C: BF89FC17
	v_fma_mixlo_f16 v64, v106, s12, 0                          // 00000014A640: CC210040 0200196A
	v_fma_mixhi_f16 v64, v107, s12, 0                          // 00000014A648: CC220040 0200196B
	v_fma_mixlo_f16 v65, v108, s12, 0                          // 00000014A650: CC210041 0200196C
	v_fma_mixhi_f16 v65, v109, s12, 0                          // 00000014A658: CC220041 0200196D
	s_waitcnt lgkmcnt(0)                                       // 00000014A660: BF89FC07
	v_fma_mixlo_f16 v102, v3, s12, 0                           // 00000014A664: CC210066 02001903
	v_fma_mixhi_f16 v102, v4, s12, 0                           // 00000014A66C: CC220066 02001904
	v_fma_mixlo_f16 v103, v5, s12, 0                           // 00000014A674: CC210067 02001905
	v_fma_mixhi_f16 v103, v6, s12, 0                           // 00000014A67C: CC220067 02001906
	v_fma_mixlo_f16 v104, v110, s12, 0                         // 00000014A684: CC210068 0200196E
	v_fma_mixhi_f16 v104, v111, s12, 0                         // 00000014A68C: CC220068 0200196F
	v_fma_mixlo_f16 v105, v112, s12, 0                         // 00000014A694: CC210069 02001970
	v_fma_mixhi_f16 v105, v113, s12, 0                         // 00000014A69C: CC220069 02001971
	v_fma_mixlo_f16 v106, v114, s12, 0                         // 00000014A6A4: CC21006A 02001972
	v_fma_mixhi_f16 v106, v115, s12, 0                         // 00000014A6AC: CC22006A 02001973
	v_fma_mixlo_f16 v107, v116, s12, 0                         // 00000014A6B4: CC21006B 02001974
	v_fma_mixhi_f16 v107, v117, s12, 0                         // 00000014A6BC: CC22006B 02001975
	v_fma_mixlo_f16 v108, v118, s12, 0                         // 00000014A6C4: CC21006C 02001976
	v_fma_mixhi_f16 v108, v119, s12, 0                         // 00000014A6CC: CC22006C 02001977
	v_fma_mixlo_f16 v109, v120, s12, 0                         // 00000014A6D4: CC21006D 02001978
	v_fma_mixhi_f16 v109, v121, s12, 0                         // 00000014A6DC: CC22006D 02001979
	v_add_nc_u32_e32 v5, s16, v81                              // 00000014A6E4: 4A0AA210
	.long 0x7e063880                                           // 00000014A6E8: 7E063880
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[94:101], v[34:41]// 00000014A6EC: CC404022 1C8ABD32
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[58:65], v[26:33]// 00000014A6F4: CC40401A 1C6A7532
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[102:109], v[18:25]// 00000014A6FC: CC404012 1C4ACD32
	.long 0xd4440000                                           // 00000014A704: D4440000
	v_cndmask_b32_e32 v1, s40, v5, vcc_lo                      // 00000014A708: 02020A28
	.long 0x7f063903                                           // 00000014A70C: 7F063903
	s_and_saveexec_b32 s4, s0                                  // 00000014A710: BE842000
	s_cbranch_execz 17                                         // 00000014A714: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x255c>
	v_mad_u64_u32 v[6:7], null, v5, 48, s[2:3]                 // 00000014A718: D6FE7C06 00096105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014A720: BF870091
	.long 0xd73c0006                                           // 00000014A724: D73C0006
	v_cndmask_b32_e32 v1, 9, v6, vcc_lo                        // 00000014A728: 02020C89
	.long 0xd7000106                                           // 00000014A72C: D7000106
	v_cndmask_b32_e32 v1, v87, v6, vcc_lo                      // 00000014A730: 02020D57
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014A734: BF8700C1
	v_add_co_ci_u32_e64 v7, null, v88, v7, s1                  // 00000014A738: D5207C07 00060F58
	global_load_b32 v4, v[6:7], off                            // 00000014A740: DC520000 047C0006
	s_waitcnt vmcnt(0)                                         // 00000014A748: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v42                         // 00000014A74C: 560854FF BB800000
	v_fma_mixhi_f16 v3, v4, s12, 0                             // 00000014A754: CC220003 02001904
	s_or_b32 exec_lo, exec_lo, s4                              // 00000014A75C: 8C7E047E
	v_add_nc_u32_e32 v6, 2, v5                                 // 00000014A760: 4A0C0A82
	ds_store_b16_d16_hi v89, v3                                // 00000014A764: DA840000 00000359
	.long 0xd4440001                                           // 00000014A76C: D4440001
	v_cndmask_b32_e32 v1, s40, v6, vcc_lo                      // 00000014A770: 02020C28
	s_and_saveexec_b32 s5, s1                                  // 00000014A774: BE852001
	s_cbranch_execz 17                                         // 00000014A778: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25c0>
	v_mad_u64_u32 v[3:4], null, v6, 48, s[2:3]                 // 00000014A77C: D6FE7C03 00096106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014A784: BF870091
	.long 0xd73c0003                                           // 00000014A788: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014A78C: 02020689
	.long 0xd7000403                                           // 00000014A790: D7000403
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014A794: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014A798: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s4                  // 00000014A79C: D5207C04 00120958
	global_load_b32 v3, v[3:4], off                            // 00000014A7A4: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014A7AC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v43                         // 00000014A7B0: 560656FF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000014A7B8: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s5                              // 00000014A7C0: 8C7E057E
	v_add_nc_u32_e32 v7, 4, v5                                 // 00000014A7C4: 4A0E0A84
	.long 0x7f063880                                           // 00000014A7C8: 7F063880
	ds_store_b16 v89, v3 offset:4                              // 00000014A7CC: D87C0004 00000359
	.long 0xd4440004                                           // 00000014A7D4: D4440004
	v_cndmask_b32_e32 v1, s40, v7, vcc_lo                      // 00000014A7D8: 02020E28
	.long 0x7e083983                                           // 00000014A7DC: 7E083983
	s_and_saveexec_b32 s6, s4                                  // 00000014A7E0: BE862004
	s_cbranch_execz 17                                         // 00000014A7E4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x262c>
	v_mad_u64_u32 v[8:9], null, v7, 48, s[2:3]                 // 00000014A7E8: D6FE7C08 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014A7F0: BF870091
	.long 0xd73c0008                                           // 00000014A7F4: D73C0008
	v_cndmask_b32_e32 v1, 9, v8, vcc_lo                        // 00000014A7F8: 02021089
	.long 0xd7000508                                           // 00000014A7FC: D7000508
	v_cndmask_b32_e32 v1, v87, v8, vcc_lo                      // 00000014A800: 02021157
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014A804: BF8700C1
	v_add_co_ci_u32_e64 v9, null, v88, v9, s5                  // 00000014A808: D5207C09 00161358
	global_load_b32 v4, v[8:9], off                            // 00000014A810: DC520000 047C0008
	s_waitcnt vmcnt(0)                                         // 00000014A818: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v44                         // 00000014A81C: 560858FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000014A824: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s6                              // 00000014A82C: 8C7E067E
	v_add_nc_u32_e32 v8, 6, v5                                 // 00000014A830: 4A100A86
	ds_store_b16 v89, v4 offset:8                              // 00000014A834: D87C0008 00000459
	.long 0xd4440005                                           // 00000014A83C: D4440005
	v_cndmask_b32_e32 v1, s40, v8, vcc_lo                      // 00000014A840: 02021028
	s_and_saveexec_b32 s7, s5                                  // 00000014A844: BE872005
	s_cbranch_execz 17                                         // 00000014A848: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2690>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 00000014A84C: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014A854: BF870091
	.long 0xd73c0003                                           // 00000014A858: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014A85C: 02020689
	.long 0xd7000603                                           // 00000014A860: D7000603
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014A864: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014A868: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s6                  // 00000014A86C: D5207C04 001A0958
	global_load_b32 v3, v[3:4], off                            // 00000014A874: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014A87C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v45                         // 00000014A880: 56065AFF BB800000
	v_fma_mixhi_f16 v3, v3, s12, 0                             // 00000014A888: CC220003 02001903
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014A890: 8C7E077E
	v_add_nc_u32_e32 v9, 8, v5                                 // 00000014A894: 4A120A88
	.long 0x7e083880                                           // 00000014A898: 7E083880
	ds_store_b16_d16_hi v89, v3 offset:12                      // 00000014A89C: DA84000C 00000359
	.long 0xd4440006                                           // 00000014A8A4: D4440006
	v_cndmask_b32_e32 v1, s40, v9, vcc_lo                      // 00000014A8A8: 02021228
	.long 0x7e063904                                           // 00000014A8AC: 7E063904
	s_and_saveexec_b32 s8, s6                                  // 00000014A8B0: BE882006
	s_cbranch_execz 17                                         // 00000014A8B4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26fc>
	v_mad_u64_u32 v[42:43], null, v9, 48, s[2:3]               // 00000014A8B8: D6FE7C2A 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014A8C0: BF870091
	.long 0xd73c002a                                           // 00000014A8C4: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000014A8C8: 02025489
	.long 0xd700072a                                           // 00000014A8CC: D700072A
	v_cndmask_b32_e32 v1, v87, v42, vcc_lo                     // 00000014A8D0: 02025557
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014A8D4: BF8700C1
	v_add_co_ci_u32_e64 v43, null, v88, v43, s7                // 00000014A8D8: D5207C2B 001E5758
	global_load_b32 v3, v[42:43], off                          // 00000014A8E0: DC520000 037C002A
	s_waitcnt vmcnt(0)                                         // 00000014A8E8: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v46                         // 00000014A8EC: 56065CFF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000014A8F4: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014A8FC: 8C7E087E
	v_add_nc_u32_e32 v50, 10, v5                               // 00000014A900: 4A640A8A
	ds_store_b16 v89, v3 offset:16                             // 00000014A904: D87C0010 00000359
	.long 0xd4440007                                           // 00000014A90C: D4440007
	v_cndmask_b32_e32 v1, s40, v50, vcc_lo                     // 00000014A910: 02026428
	s_and_saveexec_b32 s9, s7                                  // 00000014A914: BE892007
	s_cbranch_execz 17                                         // 00000014A918: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2760>
	v_mad_u64_u32 v[3:4], null, v50, 48, s[2:3]                // 00000014A91C: D6FE7C03 00096132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014A924: BF870091
	.long 0xd73c0003                                           // 00000014A928: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014A92C: 02020689
	.long 0xd7000803                                           // 00000014A930: D7000803
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014A934: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014A938: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s8                  // 00000014A93C: D5207C04 00220958
	global_load_b32 v3, v[3:4], off                            // 00000014A944: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014A94C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v47                         // 00000014A950: 56065EFF BB800000
	v_fma_mixlo_f16 v4, v3, s12, 0                             // 00000014A958: CC210004 02001903
	s_or_b32 exec_lo, exec_lo, s9                              // 00000014A960: 8C7E097E
	v_add_nc_u32_e32 v51, 12, v5                               // 00000014A964: 4A660A8C
	.long 0x7e063880                                           // 00000014A968: 7E063880
	ds_store_b16 v89, v4 offset:20                             // 00000014A96C: D87C0014 00000459
	.long 0xd4440008                                           // 00000014A974: D4440008
	v_cndmask_b32_e32 v1, s40, v51, vcc_lo                     // 00000014A978: 02026628
	.long 0x7f063903                                           // 00000014A97C: 7F063903
	s_and_saveexec_b32 s10, s8                                 // 00000014A980: BE8A2008
	s_cbranch_execz 17                                         // 00000014A984: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27cc>
	v_mad_u64_u32 v[42:43], null, v51, 48, s[2:3]              // 00000014A988: D6FE7C2A 00096133
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014A990: BF870091
	.long 0xd73c002a                                           // 00000014A994: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000014A998: 02025489
	.long 0xd700092a                                           // 00000014A99C: D700092A
	v_cndmask_b32_e32 v1, v87, v42, vcc_lo                     // 00000014A9A0: 02025557
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014A9A4: BF8700C1
	v_add_co_ci_u32_e64 v43, null, v88, v43, s9                // 00000014A9A8: D5207C2B 00265758
	global_load_b32 v4, v[42:43], off                          // 00000014A9B0: DC520000 047C002A
	s_waitcnt vmcnt(0)                                         // 00000014A9B8: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v48                         // 00000014A9BC: 560860FF BB800000
	v_fma_mixhi_f16 v3, v4, s12, 0                             // 00000014A9C4: CC220003 02001904
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014A9CC: 8C7E0A7E
	v_add_nc_u32_e32 v52, 14, v5                               // 00000014A9D0: 4A680A8E
	ds_store_b16_d16_hi v89, v3 offset:24                      // 00000014A9D4: DA840018 00000359
	.long 0xd4440009                                           // 00000014A9DC: D4440009
	v_cndmask_b32_e32 v1, s40, v52, vcc_lo                     // 00000014A9E0: 02026828
	s_and_saveexec_b32 s20, s9                                 // 00000014A9E4: BE942009
	s_cbranch_execz 17                                         // 00000014A9E8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2830>
	v_mad_u64_u32 v[3:4], null, v52, 48, s[2:3]                // 00000014A9EC: D6FE7C03 00096134
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014A9F4: BF870091
	.long 0xd73c0003                                           // 00000014A9F8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014A9FC: 02020689
	.long 0xd7000a03                                           // 00000014AA00: D7000A03
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014AA04: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014AA08: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s10                 // 00000014AA0C: D5207C04 002A0958
	global_load_b32 v3, v[3:4], off                            // 00000014AA14: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014AA1C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v49                         // 00000014AA20: 560662FF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000014AA28: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014AA30: 8C7E147E
	.long 0x7f063880                                           // 00000014AA34: 7F063880
	ds_store_b16 v89, v3 offset:28                             // 00000014AA38: D87C001C 00000359
	.long 0x7e083983                                           // 00000014AA40: 7E083983
	s_and_saveexec_b32 s20, s0                                 // 00000014AA44: BE942000
	s_cbranch_execz 17                                         // 00000014AA48: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2890>
	v_mad_u64_u32 v[42:43], null, v5, 48, s[2:3]               // 00000014AA4C: D6FE7C2A 00096105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014AA54: BF870091
	.long 0xd73c002a                                           // 00000014AA58: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000014AA5C: 02025489
	.long 0xd7000a2a                                           // 00000014AA60: D7000A2A
	v_cndmask_b32_e32 v1, v87, v42, vcc_lo                     // 00000014AA64: 02025557
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014AA68: BF8700C1
	v_add_co_ci_u32_e64 v43, null, v88, v43, s10               // 00000014AA6C: D5207C2B 002A5758
	global_load_b32 v4, v[42:43], off offset:64                // 00000014AA74: DC520040 047C002A
	s_waitcnt vmcnt(0)                                         // 00000014AA7C: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v34                         // 00000014AA80: 560844FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000014AA88: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014AA90: 8C7E147E
	ds_store_b16 v89, v4 offset:2560                           // 00000014AA94: D87C0A00 00000459
	s_and_saveexec_b32 s20, s1                                 // 00000014AA9C: BE942001
	s_cbranch_execz 17                                         // 00000014AAA0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x28e8>
	v_mad_u64_u32 v[3:4], null, v6, 48, s[2:3]                 // 00000014AAA4: D6FE7C03 00096106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014AAAC: BF870091
	.long 0xd73c0003                                           // 00000014AAB0: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014AAB4: 02020689
	.long 0xd7000a03                                           // 00000014AAB8: D7000A03
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014AABC: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014AAC0: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s10                 // 00000014AAC4: D5207C04 002A0958
	global_load_b32 v3, v[3:4], off offset:64                  // 00000014AACC: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014AAD4: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v35                         // 00000014AAD8: 560646FF BB800000
	v_fma_mixhi_f16 v3, v3, s12, 0                             // 00000014AAE0: CC220003 02001903
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014AAE8: 8C7E147E
	.long 0x7e063880                                           // 00000014AAEC: 7E063880
	ds_store_b16_d16_hi v89, v3 offset:2564                    // 00000014AAF0: DA840A04 00000359
	.long 0x7e083903                                           // 00000014AAF8: 7E083903
	s_and_saveexec_b32 s20, s4                                 // 00000014AAFC: BE942004
	s_cbranch_execz 17                                         // 00000014AB00: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2948>
	v_mad_u64_u32 v[34:35], null, v7, 48, s[2:3]               // 00000014AB04: D6FE7C22 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014AB0C: BF870091
	.long 0xd73c0022                                           // 00000014AB10: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000014AB14: 02024489
	.long 0xd7000a22                                           // 00000014AB18: D7000A22
	v_cndmask_b32_e32 v1, v87, v34, vcc_lo                     // 00000014AB1C: 02024557
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014AB20: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v88, v35, s10               // 00000014AB24: D5207C23 002A4758
	global_load_b32 v4, v[34:35], off offset:64                // 00000014AB2C: DC520040 047C0022
	s_waitcnt vmcnt(0)                                         // 00000014AB34: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v36                         // 00000014AB38: 560848FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000014AB40: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014AB48: 8C7E147E
	ds_store_b16 v89, v4 offset:2568                           // 00000014AB4C: D87C0A08 00000459
	s_and_saveexec_b32 s20, s5                                 // 00000014AB54: BE942005
	s_cbranch_execz 17                                         // 00000014AB58: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29a0>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 00000014AB5C: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014AB64: BF870091
	.long 0xd73c0003                                           // 00000014AB68: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014AB6C: 02020689
	.long 0xd7000a03                                           // 00000014AB70: D7000A03
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014AB74: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014AB78: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s10                 // 00000014AB7C: D5207C04 002A0958
	global_load_b32 v3, v[3:4], off offset:64                  // 00000014AB84: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014AB8C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v37                         // 00000014AB90: 56064AFF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000014AB98: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014ABA0: 8C7E147E
	.long 0x7f063880                                           // 00000014ABA4: 7F063880
	ds_store_b16 v89, v3 offset:2572                           // 00000014ABA8: D87C0A0C 00000359
	.long 0x7e083983                                           // 00000014ABB0: 7E083983
	s_and_saveexec_b32 s20, s6                                 // 00000014ABB4: BE942006
	s_cbranch_execz 17                                         // 00000014ABB8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a00>
	v_mad_u64_u32 v[34:35], null, v9, 48, s[2:3]               // 00000014ABBC: D6FE7C22 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014ABC4: BF870091
	.long 0xd73c0022                                           // 00000014ABC8: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000014ABCC: 02024489
	.long 0xd7000a22                                           // 00000014ABD0: D7000A22
	v_cndmask_b32_e32 v1, v87, v34, vcc_lo                     // 00000014ABD4: 02024557
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014ABD8: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v88, v35, s10               // 00000014ABDC: D5207C23 002A4758
	global_load_b32 v4, v[34:35], off offset:64                // 00000014ABE4: DC520040 047C0022
	s_waitcnt vmcnt(0)                                         // 00000014ABEC: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v38                         // 00000014ABF0: 56084CFF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000014ABF8: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014AC00: 8C7E147E
	ds_store_b16 v89, v4 offset:2576                           // 00000014AC04: D87C0A10 00000459
	s_and_saveexec_b32 s20, s7                                 // 00000014AC0C: BE942007
	s_cbranch_execz 17                                         // 00000014AC10: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a58>
	v_mad_u64_u32 v[3:4], null, v50, 48, s[2:3]                // 00000014AC14: D6FE7C03 00096132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014AC1C: BF870091
	.long 0xd73c0003                                           // 00000014AC20: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014AC24: 02020689
	.long 0xd7000a03                                           // 00000014AC28: D7000A03
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014AC2C: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014AC30: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s10                 // 00000014AC34: D5207C04 002A0958
	global_load_b32 v3, v[3:4], off offset:64                  // 00000014AC3C: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014AC44: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v39                         // 00000014AC48: 56064EFF BB800000
	v_fma_mixhi_f16 v3, v3, s12, 0                             // 00000014AC50: CC220003 02001903
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014AC58: 8C7E147E
	.long 0x7e063880                                           // 00000014AC5C: 7E063880
	ds_store_b16_d16_hi v89, v3 offset:2580                    // 00000014AC60: DA840A14 00000359
	.long 0x7e083903                                           // 00000014AC68: 7E083903
	s_and_saveexec_b32 s20, s8                                 // 00000014AC6C: BE942008
	s_cbranch_execz 17                                         // 00000014AC70: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ab8>
	v_mad_u64_u32 v[34:35], null, v51, 48, s[2:3]              // 00000014AC74: D6FE7C22 00096133
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014AC7C: BF870091
	.long 0xd73c0022                                           // 00000014AC80: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000014AC84: 02024489
	.long 0xd7000a22                                           // 00000014AC88: D7000A22
	v_cndmask_b32_e32 v1, v87, v34, vcc_lo                     // 00000014AC8C: 02024557
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014AC90: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v88, v35, s10               // 00000014AC94: D5207C23 002A4758
	global_load_b32 v4, v[34:35], off offset:64                // 00000014AC9C: DC520040 047C0022
	s_waitcnt vmcnt(0)                                         // 00000014ACA4: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v40                         // 00000014ACA8: 560850FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000014ACB0: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014ACB8: 8C7E147E
	ds_store_b16 v89, v4 offset:2584                           // 00000014ACBC: D87C0A18 00000459
	s_and_saveexec_b32 s20, s9                                 // 00000014ACC4: BE942009
	s_cbranch_execz 17                                         // 00000014ACC8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b10>
	v_mad_u64_u32 v[3:4], null, v52, 48, s[2:3]                // 00000014ACCC: D6FE7C03 00096134
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014ACD4: BF870091
	.long 0xd73c0003                                           // 00000014ACD8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014ACDC: 02020689
	.long 0xd7000a03                                           // 00000014ACE0: D7000A03
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014ACE4: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014ACE8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s10                 // 00000014ACEC: D5207C04 002A0958
	global_load_b32 v3, v[3:4], off offset:64                  // 00000014ACF4: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014ACFC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v41                         // 00000014AD00: 560652FF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000014AD08: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014AD10: 8C7E147E
	.long 0x7f063880                                           // 00000014AD14: 7F063880
	ds_store_b16 v89, v3 offset:2588                           // 00000014AD18: D87C0A1C 00000359
	.long 0x7e083983                                           // 00000014AD20: 7E083983
	s_and_saveexec_b32 s20, s0                                 // 00000014AD24: BE942000
	s_cbranch_execz 17                                         // 00000014AD28: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b70>
	v_mad_u64_u32 v[34:35], null, v5, 48, s[2:3]               // 00000014AD2C: D6FE7C22 00096105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014AD34: BF870091
	.long 0xd73c0022                                           // 00000014AD38: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000014AD3C: 02024489
	.long 0xd7000a22                                           // 00000014AD40: D7000A22
	v_cndmask_b32_e32 v1, v87, v34, vcc_lo                     // 00000014AD44: 02024557
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014AD48: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v88, v35, s10               // 00000014AD4C: D5207C23 002A4758
	global_load_b32 v4, v[34:35], off offset:128               // 00000014AD54: DC520080 047C0022
	s_waitcnt vmcnt(0)                                         // 00000014AD5C: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v26                         // 00000014AD60: 560834FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000014AD68: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014AD70: 8C7E147E
	ds_store_b16 v89, v4 offset:5120                           // 00000014AD74: D87C1400 00000459
	s_and_saveexec_b32 s20, s1                                 // 00000014AD7C: BE942001
	s_cbranch_execz 17                                         // 00000014AD80: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2bc8>
	v_mad_u64_u32 v[3:4], null, v6, 48, s[2:3]                 // 00000014AD84: D6FE7C03 00096106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014AD8C: BF870091
	.long 0xd73c0003                                           // 00000014AD90: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014AD94: 02020689
	.long 0xd7000a03                                           // 00000014AD98: D7000A03
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014AD9C: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014ADA0: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s10                 // 00000014ADA4: D5207C04 002A0958
	global_load_b32 v3, v[3:4], off offset:128                 // 00000014ADAC: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014ADB4: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v27                         // 00000014ADB8: 560636FF BB800000
	v_fma_mixhi_f16 v3, v3, s12, 0                             // 00000014ADC0: CC220003 02001903
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014ADC8: 8C7E147E
	.long 0x7e063880                                           // 00000014ADCC: 7E063880
	ds_store_b16_d16_hi v89, v3 offset:5124                    // 00000014ADD0: DA841404 00000359
	.long 0x7e083903                                           // 00000014ADD8: 7E083903
	s_and_saveexec_b32 s20, s4                                 // 00000014ADDC: BE942004
	s_cbranch_execz 17                                         // 00000014ADE0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c28>
	v_mad_u64_u32 v[26:27], null, v7, 48, s[2:3]               // 00000014ADE4: D6FE7C1A 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014ADEC: BF870091
	.long 0xd73c001a                                           // 00000014ADF0: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000014ADF4: 02023489
	.long 0xd7000a1a                                           // 00000014ADF8: D7000A1A
	v_cndmask_b32_e32 v1, v87, v26, vcc_lo                     // 00000014ADFC: 02023557
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014AE00: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v88, v27, s10               // 00000014AE04: D5207C1B 002A3758
	global_load_b32 v4, v[26:27], off offset:128               // 00000014AE0C: DC520080 047C001A
	s_waitcnt vmcnt(0)                                         // 00000014AE14: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v28                         // 00000014AE18: 560838FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000014AE20: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014AE28: 8C7E147E
	ds_store_b16 v89, v4 offset:5128                           // 00000014AE2C: D87C1408 00000459
	s_and_saveexec_b32 s20, s5                                 // 00000014AE34: BE942005
	s_cbranch_execz 17                                         // 00000014AE38: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c80>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 00000014AE3C: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014AE44: BF870091
	.long 0xd73c0003                                           // 00000014AE48: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014AE4C: 02020689
	.long 0xd7000a03                                           // 00000014AE50: D7000A03
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014AE54: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014AE58: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s10                 // 00000014AE5C: D5207C04 002A0958
	global_load_b32 v3, v[3:4], off offset:128                 // 00000014AE64: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014AE6C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v29                         // 00000014AE70: 56063AFF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000014AE78: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014AE80: 8C7E147E
	.long 0x7f063880                                           // 00000014AE84: 7F063880
	ds_store_b16 v89, v3 offset:5132                           // 00000014AE88: D87C140C 00000359
	.long 0x7e083983                                           // 00000014AE90: 7E083983
	s_and_saveexec_b32 s20, s6                                 // 00000014AE94: BE942006
	s_cbranch_execz 17                                         // 00000014AE98: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ce0>
	v_mad_u64_u32 v[26:27], null, v9, 48, s[2:3]               // 00000014AE9C: D6FE7C1A 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014AEA4: BF870091
	.long 0xd73c001a                                           // 00000014AEA8: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000014AEAC: 02023489
	.long 0xd7000a1a                                           // 00000014AEB0: D7000A1A
	v_cndmask_b32_e32 v1, v87, v26, vcc_lo                     // 00000014AEB4: 02023557
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014AEB8: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v88, v27, s10               // 00000014AEBC: D5207C1B 002A3758
	global_load_b32 v4, v[26:27], off offset:128               // 00000014AEC4: DC520080 047C001A
	s_waitcnt vmcnt(0)                                         // 00000014AECC: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v30                         // 00000014AED0: 56083CFF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000014AED8: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014AEE0: 8C7E147E
	ds_store_b16 v89, v4 offset:5136                           // 00000014AEE4: D87C1410 00000459
	s_and_saveexec_b32 s20, s7                                 // 00000014AEEC: BE942007
	s_cbranch_execz 17                                         // 00000014AEF0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d38>
	v_mad_u64_u32 v[3:4], null, v50, 48, s[2:3]                // 00000014AEF4: D6FE7C03 00096132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014AEFC: BF870091
	.long 0xd73c0003                                           // 00000014AF00: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014AF04: 02020689
	.long 0xd7000a03                                           // 00000014AF08: D7000A03
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014AF0C: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014AF10: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s10                 // 00000014AF14: D5207C04 002A0958
	global_load_b32 v3, v[3:4], off offset:128                 // 00000014AF1C: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014AF24: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v31                         // 00000014AF28: 56063EFF BB800000
	v_fma_mixhi_f16 v3, v3, s12, 0                             // 00000014AF30: CC220003 02001903
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014AF38: 8C7E147E
	.long 0x7e063880                                           // 00000014AF3C: 7E063880
	ds_store_b16_d16_hi v89, v3 offset:5140                    // 00000014AF40: DA841414 00000359
	.long 0x7e083903                                           // 00000014AF48: 7E083903
	s_and_saveexec_b32 s20, s8                                 // 00000014AF4C: BE942008
	s_cbranch_execz 17                                         // 00000014AF50: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d98>
	v_mad_u64_u32 v[26:27], null, v51, 48, s[2:3]              // 00000014AF54: D6FE7C1A 00096133
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014AF5C: BF870091
	.long 0xd73c001a                                           // 00000014AF60: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000014AF64: 02023489
	.long 0xd7000a1a                                           // 00000014AF68: D7000A1A
	v_cndmask_b32_e32 v1, v87, v26, vcc_lo                     // 00000014AF6C: 02023557
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014AF70: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v88, v27, s10               // 00000014AF74: D5207C1B 002A3758
	global_load_b32 v4, v[26:27], off offset:128               // 00000014AF7C: DC520080 047C001A
	s_waitcnt vmcnt(0)                                         // 00000014AF84: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v32                         // 00000014AF88: 560840FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000014AF90: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014AF98: 8C7E147E
	ds_store_b16 v89, v4 offset:5144                           // 00000014AF9C: D87C1418 00000459
	s_and_saveexec_b32 s20, s9                                 // 00000014AFA4: BE942009
	s_cbranch_execz 17                                         // 00000014AFA8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2df0>
	v_mad_u64_u32 v[3:4], null, v52, 48, s[2:3]                // 00000014AFAC: D6FE7C03 00096134
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014AFB4: BF870091
	.long 0xd73c0003                                           // 00000014AFB8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014AFBC: 02020689
	.long 0xd7000a03                                           // 00000014AFC0: D7000A03
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014AFC4: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014AFC8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s10                 // 00000014AFCC: D5207C04 002A0958
	global_load_b32 v3, v[3:4], off offset:128                 // 00000014AFD4: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014AFDC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v33                         // 00000014AFE0: 560642FF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000014AFE8: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014AFF0: 8C7E147E
	.long 0x7f063880                                           // 00000014AFF4: 7F063880
	ds_store_b16 v89, v3 offset:5148                           // 00000014AFF8: D87C141C 00000359
	.long 0x7e083983                                           // 00000014B000: 7E083983
	s_and_saveexec_b32 s20, s0                                 // 00000014B004: BE942000
	s_cbranch_execz 17                                         // 00000014B008: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e50>
	v_mad_u64_u32 v[26:27], null, v5, 48, s[2:3]               // 00000014B00C: D6FE7C1A 00096105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014B014: BF870091
	.long 0xd73c001a                                           // 00000014B018: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000014B01C: 02023489
	.long 0xd7000a1a                                           // 00000014B020: D7000A1A
	v_cndmask_b32_e32 v1, v87, v26, vcc_lo                     // 00000014B024: 02023557
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014B028: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v88, v27, s10               // 00000014B02C: D5207C1B 002A3758
	global_load_b32 v4, v[26:27], off offset:192               // 00000014B034: DC5200C0 047C001A
	s_waitcnt vmcnt(0)                                         // 00000014B03C: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v18                         // 00000014B040: 560824FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000014B048: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014B050: 8C7E147E
	ds_store_b16 v89, v4 offset:7680                           // 00000014B054: D87C1E00 00000459
	s_and_saveexec_b32 s20, s1                                 // 00000014B05C: BE942001
	s_cbranch_execz 17                                         // 00000014B060: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ea8>
	v_mad_u64_u32 v[3:4], null, v6, 48, s[2:3]                 // 00000014B064: D6FE7C03 00096106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014B06C: BF870091
	.long 0xd73c0003                                           // 00000014B070: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014B074: 02020689
	.long 0xd7000a03                                           // 00000014B078: D7000A03
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014B07C: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014B080: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s10                 // 00000014B084: D5207C04 002A0958
	global_load_b32 v3, v[3:4], off offset:192                 // 00000014B08C: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014B094: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v19                         // 00000014B098: 560626FF BB800000
	v_fma_mixhi_f16 v3, v3, s12, 0                             // 00000014B0A0: CC220003 02001903
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014B0A8: 8C7E147E
	.long 0x7e063880                                           // 00000014B0AC: 7E063880
	ds_store_b16_d16_hi v89, v3 offset:7684                    // 00000014B0B0: DA841E04 00000359
	.long 0x7e083903                                           // 00000014B0B8: 7E083903
	s_and_saveexec_b32 s20, s4                                 // 00000014B0BC: BE942004
	s_cbranch_execz 17                                         // 00000014B0C0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2f08>
	v_mad_u64_u32 v[18:19], null, v7, 48, s[2:3]               // 00000014B0C4: D6FE7C12 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014B0CC: BF870091
	.long 0xd73c0012                                           // 00000014B0D0: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 00000014B0D4: 02022489
	.long 0xd7000a12                                           // 00000014B0D8: D7000A12
	v_cndmask_b32_e32 v1, v87, v18, vcc_lo                     // 00000014B0DC: 02022557
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014B0E0: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v88, v19, s10               // 00000014B0E4: D5207C13 002A2758
	global_load_b32 v4, v[18:19], off offset:192               // 00000014B0EC: DC5200C0 047C0012
	s_waitcnt vmcnt(0)                                         // 00000014B0F4: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v20                         // 00000014B0F8: 560828FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000014B100: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014B108: 8C7E147E
	ds_store_b16 v89, v4 offset:7688                           // 00000014B10C: D87C1E08 00000459
	s_and_saveexec_b32 s20, s5                                 // 00000014B114: BE942005
	s_cbranch_execz 17                                         // 00000014B118: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2f60>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 00000014B11C: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014B124: BF870091
	.long 0xd73c0003                                           // 00000014B128: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014B12C: 02020689
	.long 0xd7000a03                                           // 00000014B130: D7000A03
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014B134: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014B138: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s10                 // 00000014B13C: D5207C04 002A0958
	global_load_b32 v3, v[3:4], off offset:192                 // 00000014B144: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014B14C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v21                         // 00000014B150: 56062AFF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000014B158: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014B160: 8C7E147E
	.long 0x7f063880                                           // 00000014B164: 7F063880
	ds_store_b16 v89, v3 offset:7692                           // 00000014B168: D87C1E0C 00000359
	.long 0x7e083983                                           // 00000014B170: 7E083983
	s_and_saveexec_b32 s20, s6                                 // 00000014B174: BE942006
	s_cbranch_execz 17                                         // 00000014B178: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2fc0>
	v_mad_u64_u32 v[18:19], null, v9, 48, s[2:3]               // 00000014B17C: D6FE7C12 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014B184: BF870091
	.long 0xd73c0012                                           // 00000014B188: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 00000014B18C: 02022489
	.long 0xd7000a12                                           // 00000014B190: D7000A12
	v_cndmask_b32_e32 v1, v87, v18, vcc_lo                     // 00000014B194: 02022557
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014B198: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v88, v19, s10               // 00000014B19C: D5207C13 002A2758
	global_load_b32 v4, v[18:19], off offset:192               // 00000014B1A4: DC5200C0 047C0012
	s_waitcnt vmcnt(0)                                         // 00000014B1AC: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v22                         // 00000014B1B0: 56082CFF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000014B1B8: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014B1C0: 8C7E147E
	ds_store_b16 v89, v4 offset:7696                           // 00000014B1C4: D87C1E10 00000459
	s_and_saveexec_b32 s20, s7                                 // 00000014B1CC: BE942007
	s_cbranch_execz 17                                         // 00000014B1D0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3018>
	v_mad_u64_u32 v[3:4], null, v50, 48, s[2:3]                // 00000014B1D4: D6FE7C03 00096132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014B1DC: BF870091
	.long 0xd73c0003                                           // 00000014B1E0: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014B1E4: 02020689
	.long 0xd7000a03                                           // 00000014B1E8: D7000A03
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014B1EC: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014B1F0: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s10                 // 00000014B1F4: D5207C04 002A0958
	global_load_b32 v3, v[3:4], off offset:192                 // 00000014B1FC: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014B204: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v23                         // 00000014B208: 56062EFF BB800000
	v_fma_mixhi_f16 v3, v3, s12, 0                             // 00000014B210: CC220003 02001903
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014B218: 8C7E147E
	.long 0x7e063880                                           // 00000014B21C: 7E063880
	ds_store_b16_d16_hi v89, v3 offset:7700                    // 00000014B220: DA841E14 00000359
	.long 0x7e083903                                           // 00000014B228: 7E083903
	s_and_saveexec_b32 s20, s8                                 // 00000014B22C: BE942008
	s_cbranch_execz 17                                         // 00000014B230: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3078>
	v_mad_u64_u32 v[18:19], null, v51, 48, s[2:3]              // 00000014B234: D6FE7C12 00096133
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014B23C: BF870091
	.long 0xd73c0012                                           // 00000014B240: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 00000014B244: 02022489
	.long 0xd7000a12                                           // 00000014B248: D7000A12
	v_cndmask_b32_e32 v1, v87, v18, vcc_lo                     // 00000014B24C: 02022557
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014B250: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v88, v19, s10               // 00000014B254: D5207C13 002A2758
	global_load_b32 v4, v[18:19], off offset:192               // 00000014B25C: DC5200C0 047C0012
	s_waitcnt vmcnt(0)                                         // 00000014B264: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v24                         // 00000014B268: 560830FF BB800000
	v_fma_mixlo_f16 v4, v4, s12, 0                             // 00000014B270: CC210004 02001904
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014B278: 8C7E147E
	ds_store_b16 v89, v4 offset:7704                           // 00000014B27C: D87C1E18 00000459
	s_and_saveexec_b32 s20, s9                                 // 00000014B284: BE942009
	s_cbranch_execz 17                                         // 00000014B288: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x30d0>
	v_mad_u64_u32 v[3:4], null, v52, 48, s[2:3]                // 00000014B28C: D6FE7C03 00096134
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014B294: BF870091
	.long 0xd73c0003                                           // 00000014B298: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014B29C: 02020689
	.long 0xd7000a03                                           // 00000014B2A0: D7000A03
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000014B2A4: 02020757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014B2A8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v88, v4, s10                 // 00000014B2AC: D5207C04 002A0958
	global_load_b32 v3, v[3:4], off offset:192                 // 00000014B2B4: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014B2BC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v25                         // 00000014B2C0: 560632FF BB800000
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000014B2C8: CC210003 02001903
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014B2D0: 8C7E147E
	s_mul_i32 s10, s13, 48                                     // 00000014B2D4: 960AB00D
	s_mul_hi_u32 s21, s13, 48                                  // 00000014B2D8: 9695B00D
	s_add_u32 s20, s10, s2                                     // 00000014B2DC: 8014020A
	s_addc_u32 s21, s21, s3                                    // 00000014B2E0: 82150315
	v_mov_b32_e32 v42, 0                                       // 00000014B2E4: 7E540280
	s_lshl_b64 s[20:21], s[20:21], 14                          // 00000014B2E8: 84948E14
	ds_store_b16 v89, v3 offset:7708                           // 00000014B2EC: D87C1E1C 00000359
	.long 0xd7000a03                                           // 00000014B2F4: D7000A03
	v_cndmask_b32_e32 v0, v82, v20, vcc_lo                     // 00000014B2F8: 02002952
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014B2FC: BF870001
	v_add_co_ci_u32_e64 v4, null, s21, v83, s10                // 00000014B300: D5207C04 002AA615
	v_mov_b32_e32 v43, v42                                     // 00000014B308: 7E56032A
	v_mov_b32_e32 v44, v42                                     // 00000014B30C: 7E58032A
	v_mov_b32_e32 v45, v42                                     // 00000014B310: 7E5A032A
	v_mov_b32_e32 v46, v42                                     // 00000014B314: 7E5C032A
	v_mov_b32_e32 v47, v42                                     // 00000014B318: 7E5E032A
	v_mov_b32_e32 v48, v42                                     // 00000014B31C: 7E60032A
	v_mov_b32_e32 v49, v42                                     // 00000014B320: 7E62032A
	v_mov_b32_e32 v34, v42                                     // 00000014B324: 7E44032A
	v_mov_b32_e32 v35, v42                                     // 00000014B328: 7E46032A
	v_mov_b32_e32 v36, v42                                     // 00000014B32C: 7E48032A
	v_mov_b32_e32 v37, v42                                     // 00000014B330: 7E4A032A
	v_mov_b32_e32 v38, v42                                     // 00000014B334: 7E4C032A
	v_mov_b32_e32 v39, v42                                     // 00000014B338: 7E4E032A
	v_mov_b32_e32 v40, v42                                     // 00000014B33C: 7E50032A
	v_mov_b32_e32 v41, v42                                     // 00000014B340: 7E52032A
	v_mov_b32_e32 v26, v42                                     // 00000014B344: 7E34032A
	v_mov_b32_e32 v27, v42                                     // 00000014B348: 7E36032A
	v_mov_b32_e32 v28, v42                                     // 00000014B34C: 7E38032A
	v_mov_b32_e32 v29, v42                                     // 00000014B350: 7E3A032A
	v_mov_b32_e32 v30, v42                                     // 00000014B354: 7E3C032A
	v_mov_b32_e32 v31, v42                                     // 00000014B358: 7E3E032A
	v_mov_b32_e32 v32, v42                                     // 00000014B35C: 7E40032A
	v_mov_b32_e32 v33, v42                                     // 00000014B360: 7E42032A
	v_mov_b32_e32 v18, v42                                     // 00000014B364: 7E24032A
	v_mov_b32_e32 v19, v42                                     // 00000014B368: 7E26032A
	v_mov_b32_e32 v20, v42                                     // 00000014B36C: 7E28032A
	v_mov_b32_e32 v21, v42                                     // 00000014B370: 7E2A032A
	v_mov_b32_e32 v22, v42                                     // 00000014B374: 7E2C032A
	v_mov_b32_e32 v23, v42                                     // 00000014B378: 7E2E032A
	v_mov_b32_e32 v24, v42                                     // 00000014B37C: 7E30032A
	v_mov_b32_e32 v25, v42                                     // 00000014B380: 7E32032A
	s_mov_b32 s21, 0                                           // 00000014B384: BE950080
	s_mov_b32 s20, 0                                           // 00000014B388: BE940080
	s_waitcnt lgkmcnt(0)                                       // 00000014B38C: BF89FC07
	s_barrier                                                  // 00000014B390: BFBD0000
	buffer_gl0_inv                                             // 00000014B394: E0AC0000 00000000
	s_lshl_b32 s24, s21, 4                                     // 00000014B39C: 84188415
	v_lshl_add_u32 v65, s21, 5, v84                            // 00000014B3A0: D6460041 05510A15
	s_lshl_b64 s[26:27], s[24:25], 2                           // 00000014B3A8: 849A8218
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014B3AC: BF870099
	.long 0xd7000a35                                           // 00000014B3B0: D7000A35
	v_cndmask_b32_e32 v0, v3, v26, vcc_lo                      // 00000014B3B4: 02003503
	v_add_co_ci_u32_e64 v54, null, s27, v4, s10                // 00000014B3B8: D5207C36 002A081B
	.long 0xd44a000a                                           // 00000014B3C0: D44A000A
	v_cndmask_b32_e32 v1, s21, v76, vcc_lo                     // 00000014B3C4: 02029815
	s_add_i32 s21, s21, 1                                      // 00000014B3C8: 81158115
	s_clause 0x3                                               // 00000014B3CC: BF850003
	global_load_b128 v[61:64], v[53:54], off                   // 00000014B3D0: DC5E0000 3D7C0035
	global_load_b128 v[120:123], v[53:54], off offset:16       // 00000014B3D8: DC5E0010 787C0035
	global_load_b128 v[124:127], v[53:54], off offset:32       // 00000014B3E0: DC5E0020 7C7C0035
	global_load_b128 v[128:131], v[53:54], off offset:48       // 00000014B3E8: DC5E0030 807C0035
	ds_load_b128 v[53:56], v65                                 // 00000014B3F0: DBFC0000 35000041
	ds_load_b128 v[57:60], v65 offset:16                       // 00000014B3F8: DBFC0010 39000041
	ds_load_b128 v[98:101], v65 offset:2576                    // 00000014B400: DBFC0A10 62000041
	ds_load_b128 v[94:97], v65 offset:2560                     // 00000014B408: DBFC0A00 5E000041
	ds_load_b128 v[106:109], v65 offset:5136                   // 00000014B410: DBFC1410 6A000041
	ds_load_b128 v[102:105], v65 offset:5120                   // 00000014B418: DBFC1400 66000041
	ds_load_b128 v[114:117], v65 offset:7696                   // 00000014B420: DBFC1E10 72000041
	ds_load_b128 v[110:113], v65 offset:7680                   // 00000014B428: DBFC1E00 6E000041
	s_or_b32 s20, s10, s20                                     // 00000014B430: 8C14140A
	s_waitcnt vmcnt(3)                                         // 00000014B434: BF890FF7
	v_fma_mixlo_f16 v118, v61, s12, 0                          // 00000014B438: CC210076 0200193D
	v_fma_mixhi_f16 v118, v62, s12, 0                          // 00000014B440: CC220076 0200193E
	v_fma_mixlo_f16 v119, v63, s12, 0                          // 00000014B448: CC210077 0200193F
	v_fma_mixhi_f16 v119, v64, s12, 0                          // 00000014B450: CC220077 02001940
	s_waitcnt vmcnt(2)                                         // 00000014B458: BF890BF7
	v_fma_mixlo_f16 v120, v120, s12, 0                         // 00000014B45C: CC210078 02001978
	v_fma_mixhi_f16 v120, v121, s12, 0                         // 00000014B464: CC220078 02001979
	v_fma_mixlo_f16 v121, v122, s12, 0                         // 00000014B46C: CC210079 0200197A
	v_fma_mixhi_f16 v121, v123, s12, 0                         // 00000014B474: CC220079 0200197B
	s_waitcnt vmcnt(1)                                         // 00000014B47C: BF8907F7
	v_fma_mixlo_f16 v122, v124, s12, 0                         // 00000014B480: CC21007A 0200197C
	v_fma_mixhi_f16 v122, v125, s12, 0                         // 00000014B488: CC22007A 0200197D
	v_fma_mixlo_f16 v123, v126, s12, 0                         // 00000014B490: CC21007B 0200197E
	v_fma_mixhi_f16 v123, v127, s12, 0                         // 00000014B498: CC22007B 0200197F
	s_waitcnt vmcnt(0)                                         // 00000014B4A0: BF8903F7
	v_fma_mixlo_f16 v124, v128, s12, 0                         // 00000014B4A4: CC21007C 02001980
	v_fma_mixhi_f16 v124, v129, s12, 0                         // 00000014B4AC: CC22007C 02001981
	v_fma_mixlo_f16 v125, v130, s12, 0                         // 00000014B4B4: CC21007D 02001982
	v_fma_mixhi_f16 v125, v131, s12, 0                         // 00000014B4BC: CC22007D 02001983
	s_waitcnt lgkmcnt(6)                                       // 00000014B4C4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014B4C8: BF870001
	v_wmma_f32_16x16x16_f16 v[42:49], v[118:125], v[53:60], v[42:49]// 00000014B4CC: CC40402A 1CAA6B76
	s_waitcnt lgkmcnt(4)                                       // 00000014B4D4: BF89FC47
	v_wmma_f32_16x16x16_f16 v[34:41], v[118:125], v[94:101], v[34:41]// 00000014B4D8: CC404022 1C8ABD76
	s_waitcnt lgkmcnt(2)                                       // 00000014B4E0: BF89FC27
	v_wmma_f32_16x16x16_f16 v[26:33], v[118:125], v[102:109], v[26:33]// 00000014B4E4: CC40401A 1C6ACD76
	s_waitcnt lgkmcnt(0)                                       // 00000014B4EC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[118:125], v[110:117], v[18:25]// 00000014B4F0: CC404012 1C4ADD76
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 00000014B4F8: 917E147E
	s_cbranch_execnz 65447                                     // 00000014B4FC: BFA6FFA7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x319c>
	s_or_b32 exec_lo, exec_lo, s20                             // 00000014B500: 8C7E147E
	s_and_saveexec_b32 s10, s0                                 // 00000014B504: BE8A2000
	s_cbranch_execnz 476                                       // 00000014B508: BFA601DC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a7c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B50C: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 00000014B510: BE8A2001
	s_cbranch_execnz 495                                       // 00000014B514: BFA601EF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ad4>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B518: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 00000014B51C: BE8A2004
	s_cbranch_execnz 514                                       // 00000014B520: BFA60202 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b2c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B524: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 00000014B528: BE8A2005
	s_cbranch_execnz 533                                       // 00000014B52C: BFA60215 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b84>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B530: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 00000014B534: BE8A2006
	s_cbranch_execnz 552                                       // 00000014B538: BFA60228 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3bdc>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B53C: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 00000014B540: BE8A2007
	s_cbranch_execnz 571                                       // 00000014B544: BFA6023B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3c34>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B548: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 00000014B54C: BE8A2008
	s_cbranch_execnz 590                                       // 00000014B550: BFA6024E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3c8c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B554: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 00000014B558: BE8A2009
	s_cbranch_execnz 609                                       // 00000014B55C: BFA60261 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ce4>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B560: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 00000014B564: BE8A2000
	s_cbranch_execnz 627                                       // 00000014B568: BFA60273 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d38>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B56C: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 00000014B570: BE8A2001
	s_cbranch_execnz 646                                       // 00000014B574: BFA60286 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d90>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B578: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 00000014B57C: BE8A2004
	s_cbranch_execnz 665                                       // 00000014B580: BFA60299 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3de8>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B584: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 00000014B588: BE8A2005
	s_cbranch_execnz 684                                       // 00000014B58C: BFA602AC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3e40>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B590: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 00000014B594: BE8A2006
	s_cbranch_execnz 703                                       // 00000014B598: BFA602BF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3e98>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B59C: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 00000014B5A0: BE8A2007
	s_cbranch_execnz 722                                       // 00000014B5A4: BFA602D2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ef0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B5A8: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 00000014B5AC: BE8A2008
	s_cbranch_execnz 741                                       // 00000014B5B0: BFA602E5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3f48>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B5B4: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 00000014B5B8: BE8A2009
	s_cbranch_execnz 760                                       // 00000014B5BC: BFA602F8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3fa0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B5C0: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 00000014B5C4: BE8A2000
	s_cbranch_execnz 778                                       // 00000014B5C8: BFA6030A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ff4>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B5CC: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 00000014B5D0: BE8A2001
	s_cbranch_execnz 797                                       // 00000014B5D4: BFA6031D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x404c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B5D8: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 00000014B5DC: BE8A2004
	s_cbranch_execnz 816                                       // 00000014B5E0: BFA60330 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x40a4>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B5E4: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 00000014B5E8: BE8A2005
	s_cbranch_execnz 835                                       // 00000014B5EC: BFA60343 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x40fc>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B5F0: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 00000014B5F4: BE8A2006
	s_cbranch_execnz 854                                       // 00000014B5F8: BFA60356 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4154>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B5FC: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 00000014B600: BE8A2007
	s_cbranch_execnz 873                                       // 00000014B604: BFA60369 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41ac>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B608: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 00000014B60C: BE8A2008
	s_cbranch_execnz 892                                       // 00000014B610: BFA6037C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4204>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B614: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 00000014B618: BE8A2009
	s_cbranch_execnz 911                                       // 00000014B61C: BFA6038F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x425c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B620: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 00000014B624: BE8A2000
	s_cbranch_execnz 929                                       // 00000014B628: BFA603A1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42b0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014B62C: 8C7E0A7E
	s_and_saveexec_b32 s0, s1                                  // 00000014B630: BE802001
	s_cbranch_execnz 948                                       // 00000014B634: BFA603B4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4308>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014B638: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000014B63C: BE802004
	s_cbranch_execnz 967                                       // 00000014B640: BFA603C7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4360>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014B644: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000014B648: BE802005
	s_cbranch_execnz 986                                       // 00000014B64C: BFA603DA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x43b8>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014B650: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000014B654: BE802006
	s_cbranch_execnz 1005                                      // 00000014B658: BFA603ED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4410>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014B65C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000014B660: BE802007
	s_cbranch_execnz 1024                                      // 00000014B664: BFA60400 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4468>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014B668: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000014B66C: BE802008
	s_cbranch_execnz 1043                                      // 00000014B670: BFA60413 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x44c0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014B674: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000014B678: BE802009
	s_cbranch_execz 18                                         // 00000014B67C: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x34c8>
	ds_load_b32 v3, v90 offset:56                              // 00000014B680: D8D80038 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014B688: BF89FC07
	v_fmac_f32_e32 v25, 0, v3                                  // 00000014B68C: 56320680
	v_mad_u64_u32 v[3:4], null, 0x3000, v52, v[70:71]          // 00000014B690: D6FE7C03 051A68FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014B69C: BF870092
	v_mul_f32_e32 v5, 0x3b800000, v25                          // 00000014B6A0: 100A32FF 3B800000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000014B6A8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014B6B0: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000014B6B4: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000014B6C0: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014B6C8: 8C7E007E
	s_mul_f32 s0, s17, 0x3fb8aa3b                              // 00000014B6CC: A200FF11 3FB8AA3B
	v_or_b32_e32 v4, s16, v74                                  // 00000014B6D4: 38089410
	v_dual_mov_b32 v18, v72 :: v_dual_mov_b32 v19, v73         // 00000014B6D8: CA100148 12120149
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014B6E0: BF870009
	s_xor_b32 s1, s0, 0x80000000                               // 00000014B6E4: 8D01FF00 80000000
	s_rndne_f32 s4, s0                                         // 00000014B6EC: BE846300
	s_fmamk_f32 s1, s17, 0x3fb8aa3b, s1                        // 00000014B6F0: A3010111 3FB8AA3B
	s_cmp_nlt_f32 s17, 0xc2ce8ed0                              // 00000014B6F8: BF4EFF11 C2CE8ED0
	s_mov_b32 s5, 0                                            // 00000014B700: BE850080
	s_sub_f32 s0, s0, s4                                       // 00000014B704: A0800400
	s_fmamk_f32 s1, s17, 0x32a5705f, s1                        // 00000014B708: A3010111 32A5705F
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000014B710: BF87059B
	s_add_f32 s0, s0, s1                                       // 00000014B714: A0000100
	v_exp_f32_e32 v3, s0                                       // 00000014B718: 7E064A00
	s_cvt_i32_f32 s0, s4                                       // 00000014B71C: BE806604
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000014B720: BF870585
	.long 0xd71c0003                                           // 00000014B724: D71C0003
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 00000014B728: 02000103
	s_cselect_b32 s0, -1, 0                                    // 00000014B72C: 980080C1
	s_cmp_ngt_f32 s17, 0x42b17218                              // 00000014B730: BF4BFF11 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000014B738: BF870131
	v_cndmask_b32_e64 v3, 0, v3, s0                            // 00000014B73C: D5010003 00020680
	s_cselect_b32 s1, -1, 0                                    // 00000014B744: 980180C1
	.long 0xd4440000                                           // 00000014B748: D4440000
	v_cndmask_b32_e32 v1, s40, v4, vcc_lo                      // 00000014B74C: 02020828
	v_cndmask_b32_e64 v20, 0x7f800000, v3, s1                  // 00000014B750: D5010014 000606FF 7F800000
	s_branch 120                                               // 00000014B75C: BFA00078 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3740>
	s_set_inst_prefetch_distance 0x2                           // 00000014B760: BF840002
	s_or_b32 exec_lo, exec_lo, s6                              // 00000014B764: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000014B768: BF89FC07
	s_barrier                                                  // 00000014B76C: BFBD0000
	buffer_gl0_inv                                             // 00000014B770: E0AC0000 00000000
	ds_load_b128 v[22:25], v85                                 // 00000014B778: DBFC0000 16000055
	ds_load_b128 v[26:29], v85 offset:16                       // 00000014B780: DBFC0010 1A000055
	ds_load_b128 v[30:33], v93                                 // 00000014B788: DBFC0000 1E00005D
	ds_load_b128 v[34:37], v93 offset:16                       // 00000014B790: DBFC0010 2200005D
	ds_load_b128 v[38:41], v85 offset:32                       // 00000014B798: DBFC0020 26000055
	ds_load_b128 v[42:45], v85 offset:48                       // 00000014B7A0: DBFC0030 2A000055
	ds_load_b128 v[46:49], v93 offset:32                       // 00000014B7A8: DBFC0020 2E00005D
	ds_load_b128 v[50:53], v93 offset:48                       // 00000014B7B0: DBFC0030 3200005D
	v_mov_b32_e32 v9, v2                                       // 00000014B7B8: 7E120302
	v_mov_b32_e32 v3, v2                                       // 00000014B7BC: 7E060302
	v_mov_b32_e32 v4, v2                                       // 00000014B7C0: 7E080302
	v_mov_b32_e32 v5, v2                                       // 00000014B7C4: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 00000014B7C8: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 00000014B7CC: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 00000014B7D0: 7E100302
	v_mov_b32_e32 v61, v9                                      // 00000014B7D4: 7E7A0309
	v_dual_mov_b32 v57, v5 :: v_dual_mov_b32 v56, v4           // 00000014B7D8: CA100105 39380104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000014B7E0: BF870214
	v_dual_mov_b32 v59, v7 :: v_dual_mov_b32 v58, v6           // 00000014B7E4: CA100107 3B3A0106
	v_dual_mov_b32 v60, v8 :: v_dual_mov_b32 v55, v3           // 00000014B7EC: CA100108 3C360103
	v_mov_b32_e32 v54, v2                                      // 00000014B7F4: 7E6C0302
	ds_load_b128 v[98:101], v85 offset:80                      // 00000014B7F8: DBFC0050 62000055
	ds_load_b128 v[94:97], v85 offset:64                       // 00000014B800: DBFC0040 5E000055
	ds_load_b128 v[106:109], v93 offset:80                     // 00000014B808: DBFC0050 6A00005D
	ds_load_b128 v[102:105], v93 offset:64                     // 00000014B810: DBFC0040 6600005D
	ds_load_b128 v[114:117], v85 offset:112                    // 00000014B818: DBFC0070 72000055
	ds_load_b128 v[110:113], v85 offset:96                     // 00000014B820: DBFC0060 6E000055
	ds_load_2addr_b32 v[3:4], v21 offset0:16 offset1:18        // 00000014B828: D8DC1210 03000015
	ds_load_b128 v[122:125], v93 offset:112                    // 00000014B830: DBFC0070 7A00005D
	ds_load_b128 v[118:121], v93 offset:96                     // 00000014B838: DBFC0060 7600005D
	ds_load_2addr_b32 v[5:6], v21 offset0:20 offset1:22        // 00000014B840: D8DC1614 05000015
	ds_load_2addr_b32 v[7:8], v21 offset0:24 offset1:26        // 00000014B848: D8DC1A18 07000015
	.long 0xd7000112                                           // 00000014B850: D7000112
	v_cndmask_b32_e32 v1, 0x80, v18, vcc_lo                    // 00000014B854: 020224FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014B85C: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 00000014B860: D5207C13 00062680
	s_waitcnt lgkmcnt(15)                                      // 00000014B868: BF89FCF7
	v_wmma_f32_16x16x16_f16 v[54:61], v[22:29], v[30:37], v[54:61]// 00000014B86C: CC404036 1CDA3D16
	ds_load_2addr_b32 v[22:23], v21 offset0:28 offset1:30      // 00000014B874: D8DC1E1C 16000015
	s_add_i32 s1, s5, 32                                       // 00000014B87C: 8101A005
	s_cmpk_gt_u32 s5, 0x5f                                     // 00000014B880: B585005F
	s_mov_b32 s5, s1                                           // 00000014B884: BE850001
	s_waitcnt lgkmcnt(12)                                      // 00000014B888: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[54:61], v[38:45], v[46:53], v[54:61]// 00000014B88C: CC404036 1CDA5D26
	s_waitcnt lgkmcnt(8)                                       // 00000014B894: BF89FC87
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014B898: BF870001
	v_wmma_f32_16x16x16_f16 v[54:61], v[94:101], v[102:109], v[54:61]// 00000014B89C: CC404036 1CDACD5E
	s_waitcnt lgkmcnt(5)                                       // 00000014B8A4: BF89FC57
	v_mul_f32_e32 v3, v20, v3                                  // 00000014B8A8: 10060714
	v_mul_f32_e32 v4, v20, v4                                  // 00000014B8AC: 10080914
	s_waitcnt lgkmcnt(2)                                       // 00000014B8B0: BF89FC27
	v_mul_f32_e32 v5, v20, v5                                  // 00000014B8B4: 100A0B14
	v_wmma_f32_16x16x16_f16 v[54:61], v[110:117], v[118:125], v[54:61]// 00000014B8B8: CC404036 1CDAED6E
	s_waitcnt lgkmcnt(1)                                       // 00000014B8C0: BF89FC17
	v_mul_f32_e32 v7, v20, v7                                  // 00000014B8C4: 100E0F14
	v_mul_f32_e32 v6, v20, v6                                  // 00000014B8C8: 100C0D14
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000014B8CC: BF870193
	v_dual_mul_f32 v8, v20, v8 :: v_dual_fmac_f32 v3, 0x3b800000, v54// 00000014B8D0: C8C01114 08026CFF 3B800000
	v_fmac_f32_e32 v7, 0x3b800000, v58                         // 00000014B8DC: 560E74FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 00000014B8E4: BF89FC07
	v_mul_f32_e32 v9, v20, v22                                 // 00000014B8E8: 10122D14
	v_mul_f32_e32 v22, v20, v23                                // 00000014B8EC: 102C2F14
	v_dual_fmac_f32 v4, 0x3b800000, v55 :: v_dual_fmac_f32 v5, 0x3b800000, v56// 00000014B8F0: C8006EFF 040470FF 3B800000
	v_fmac_f32_e32 v8, 0x3b800000, v59                         // 00000014B8FC: 561076FF 3B800000
	v_fmac_f32_e32 v6, 0x3b800000, v57                         // 00000014B904: 560C72FF 3B800000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000014B90C: BF870004
	v_dual_fmac_f32 v22, 0x3b800000, v61 :: v_dual_fmac_f32 v9, 0x3b800000, v60// 00000014B910: C8007AFF 160878FF 3B800000
	ds_store_2addr_b32 v21, v3, v4 offset0:16 offset1:18       // 00000014B91C: D8381210 00040315
	ds_store_2addr_b32 v21, v5, v6 offset0:20 offset1:22       // 00000014B924: D8381614 00060515
	ds_store_2addr_b32 v21, v7, v8 offset0:24 offset1:26       // 00000014B92C: D8381A18 00080715
	ds_store_2addr_b32 v21, v9, v22 offset0:28 offset1:30      // 00000014B934: D8381E1C 00160915
	s_cbranch_scc1 62211                                       // 00000014B93C: BFA2F303 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x34c>
	v_dual_mov_b32 v4, v18 :: v_dual_mov_b32 v5, v19           // 00000014B940: CA100112 04040113
	v_dual_mov_b32 v6, v92 :: v_dual_mov_b32 v7, v75           // 00000014B948: CA10015C 0606014B
	s_mov_b32 s6, 0                                            // 00000014B950: BE860080
	s_waitcnt_vscnt null, 0x0                                  // 00000014B954: BC7C0000
	s_barrier                                                  // 00000014B958: BFBD0000
	buffer_gl0_inv                                             // 00000014B95C: E0AC0000 00000000
	s_set_inst_prefetch_distance 0x1                           // 00000014B964: BF840001
	s_branch 23                                                // 00000014B968: BFA00017 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x37c8>
	s_nop 0                                                    // 00000014B96C: BF800000
	s_nop 0                                                    // 00000014B970: BF800000
	s_nop 0                                                    // 00000014B974: BF800000
	s_nop 0                                                    // 00000014B978: BF800000
	s_nop 0                                                    // 00000014B97C: BF800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014B980: 8C7E017E
	v_add_nc_u32_e32 v7, 0x80, v7                              // 00000014B984: 4A0E0EFF 00000080
	.long 0xd7000404                                           // 00000014B98C: D7000404
	v_cndmask_b32_e32 v0, v4, v136, vcc_lo                     // 00000014B990: 02011104
	ds_store_b16 v6, v3 offset:10240                           // 00000014B994: D87C2800 00000306
	v_add_nc_u32_e32 v6, 0x140, v6                             // 00000014B99C: 4A0C0CFF 00000140
	.long 0xd4490001                                           // 00000014B9A4: D4490001
	v_cndmask_b32_e32 v1, 0x37f, v7, vcc_lo                    // 00000014B9A8: 02020EFF 0000037F
	v_add_co_ci_u32_e64 v5, null, 0, v5, s4                    // 00000014B9B0: D5207C05 00120A80
	s_or_b32 s6, s1, s6                                        // 00000014B9B8: 8C060601
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014B9BC: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000014B9C0: 917E067E
	s_cbranch_execz 13                                         // 00000014B9C4: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x37fc>
	.long 0x7e063880                                           // 00000014B9C8: 7E063880
	s_and_saveexec_b32 s1, s0                                  // 00000014B9CC: BE812000
	s_cbranch_execz 65515                                      // 00000014B9D0: BFA5FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3780>
	global_load_b32 v3, v[4:5], off                            // 00000014B9D4: DC520000 037C0004
	ds_load_b32 v8, v91                                        // 00000014B9DC: D8D80000 0800005B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014B9E4: BF890007
	v_mul_f32_e32 v3, v3, v8                                   // 00000014B9E8: 10061103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014B9EC: BF870001
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000014B9F0: CC210003 02001903
	s_branch 65505                                             // 00000014B9F8: BFA0FFE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3780>
	s_set_inst_prefetch_distance 0x2                           // 00000014B9FC: BF840002
	s_or_b32 exec_lo, exec_lo, s6                              // 00000014BA00: 8C7E067E
	v_lshl_add_u32 v21, s5, 2, v86                             // 00000014BA04: D6460015 05590405
	s_waitcnt lgkmcnt(0)                                       // 00000014BA0C: BF89FC07
	s_barrier                                                  // 00000014BA10: BFBD0000
	buffer_gl0_inv                                             // 00000014BA14: E0AC0000 00000000
	ds_load_b128 v[22:25], v85                                 // 00000014BA1C: DBFC0000 16000055
	ds_load_b128 v[26:29], v85 offset:16                       // 00000014BA24: DBFC0010 1A000055
	ds_load_b128 v[30:33], v85 offset:32                       // 00000014BA2C: DBFC0020 1E000055
	ds_load_b128 v[34:37], v85 offset:48                       // 00000014BA34: DBFC0030 22000055
	ds_load_b128 v[38:41], v93                                 // 00000014BA3C: DBFC0000 2600005D
	ds_load_b128 v[42:45], v93 offset:16                       // 00000014BA44: DBFC0010 2A00005D
	ds_load_b128 v[46:49], v93 offset:32                       // 00000014BA4C: DBFC0020 2E00005D
	ds_load_b128 v[50:53], v93 offset:48                       // 00000014BA54: DBFC0030 3200005D
	ds_load_b128 v[58:61], v85 offset:80                       // 00000014BA5C: DBFC0050 3A000055
	ds_load_b128 v[54:57], v85 offset:64                       // 00000014BA64: DBFC0040 36000055
	ds_load_b128 v[98:101], v93 offset:80                      // 00000014BA6C: DBFC0050 6200005D
	ds_load_b128 v[94:97], v93 offset:64                       // 00000014BA74: DBFC0040 5E00005D
	ds_load_b128 v[106:109], v85 offset:112                    // 00000014BA7C: DBFC0070 6A000055
	ds_load_b128 v[102:105], v85 offset:96                     // 00000014BA84: DBFC0060 66000055
	ds_load_b128 v[114:117], v93 offset:112                    // 00000014BA8C: DBFC0070 7200005D
	ds_load_b128 v[110:113], v93 offset:96                     // 00000014BA94: DBFC0060 6E00005D
	ds_load_2addr_b32 v[62:63], v21 offset1:2                  // 00000014BA9C: D8DC0200 3E000015
	ds_load_2addr_b32 v[64:65], v21 offset0:4 offset1:6        // 00000014BAA4: D8DC0604 40000015
	ds_load_2addr_b32 v[66:67], v21 offset0:8 offset1:10       // 00000014BAAC: D8DC0A08 42000015
	ds_load_2addr_b32 v[126:127], v21 offset0:12 offset1:14    // 00000014BAB4: D8DC0E0C 7E000015
	v_mov_b32_e32 v9, v2                                       // 00000014BABC: 7E120302
	v_mov_b32_e32 v3, v2                                       // 00000014BAC0: 7E060302
	v_mov_b32_e32 v4, v2                                       // 00000014BAC4: 7E080302
	v_mov_b32_e32 v5, v2                                       // 00000014BAC8: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 00000014BACC: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 00000014BAD0: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 00000014BAD4: 7E100302
	v_mov_b32_e32 v125, v9                                     // 00000014BAD8: 7EFA0309
	v_dual_mov_b32 v121, v5 :: v_dual_mov_b32 v120, v4         // 00000014BADC: CA100105 79780104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000014BAE4: BF870214
	v_dual_mov_b32 v123, v7 :: v_dual_mov_b32 v122, v6         // 00000014BAE8: CA100107 7B7A0106
	v_dual_mov_b32 v124, v8 :: v_dual_mov_b32 v119, v3         // 00000014BAF0: CA100108 7C760103
	v_mov_b32_e32 v118, v2                                     // 00000014BAF8: 7EEC0302
	s_waitcnt lgkmcnt(3)                                       // 00000014BAFC: BF89FC37
	v_dual_mov_b32 v4, v18 :: v_dual_mul_f32 v3, v20, v62      // 00000014BB00: CA060112 04027D14
	v_mul_f32_e32 v8, v20, v63                                 // 00000014BB08: 10107F14
	s_waitcnt lgkmcnt(2)                                       // 00000014BB0C: BF89FC27
	v_mul_f32_e32 v9, v20, v64                                 // 00000014BB10: 10128114
	v_wmma_f32_16x16x16_f16 v[118:125], v[22:29], v[38:45], v[118:125]// 00000014BB14: CC404076 1DDA4D16
	v_mul_f32_e32 v22, v20, v65                                // 00000014BB1C: 102C8314
	s_waitcnt lgkmcnt(1)                                       // 00000014BB20: BF89FC17
	v_mul_f32_e32 v23, v20, v66                                // 00000014BB24: 102E8514
	v_dual_mul_f32 v24, v20, v67 :: v_dual_mov_b32 v5, v19     // 00000014BB28: C8D08714 18040113
	v_wmma_f32_16x16x16_f16 v[118:125], v[30:37], v[46:53], v[118:125]// 00000014BB30: CC404076 1DDA5D1E
	v_dual_mov_b32 v6, v92 :: v_dual_mov_b32 v7, v75           // 00000014BB38: CA10015C 0606014B
	s_mov_b32 s6, 0                                            // 00000014BB40: BE860080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014BB44: BF870092
	v_wmma_f32_16x16x16_f16 v[118:125], v[54:61], v[94:101], v[118:125]// 00000014BB48: CC404076 1DDABD36
	v_wmma_f32_16x16x16_f16 v[118:125], v[102:109], v[110:117], v[118:125]// 00000014BB50: CC404076 1DDADD66
	s_waitcnt lgkmcnt(0)                                       // 00000014BB58: BF89FC07
	v_mul_f32_e32 v25, v20, v126                               // 00000014BB5C: 1032FD14
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000014BB60: BF870192
	v_dual_mul_f32 v26, v20, v127 :: v_dual_fmac_f32 v3, 0x3b800000, v118// 00000014BB64: C8C0FF14 1A02ECFF 3B800000
	v_dual_fmac_f32 v8, 0x3b800000, v119 :: v_dual_fmac_f32 v9, 0x3b800000, v120// 00000014BB70: C800EEFF 0808F0FF 3B800000
	v_dual_fmac_f32 v22, 0x3b800000, v121 :: v_dual_fmac_f32 v23, 0x3b800000, v122// 00000014BB7C: C800F2FF 1616F4FF 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000014BB88: BF870214
	v_dual_fmac_f32 v24, 0x3b800000, v123 :: v_dual_fmac_f32 v25, 0x3b800000, v124// 00000014BB8C: C800F6FF 1818F8FF 3B800000
	v_fmac_f32_e32 v26, 0x3b800000, v125                       // 00000014BB98: 5634FAFF 3B800000
	ds_store_2addr_b32 v21, v3, v8 offset1:2                   // 00000014BBA0: D8380200 00080315
	ds_store_2addr_b32 v21, v9, v22 offset0:4 offset1:6        // 00000014BBA8: D8380604 00160915
	ds_store_2addr_b32 v21, v23, v24 offset0:8 offset1:10      // 00000014BBB0: D8380A08 00181715
	ds_store_2addr_b32 v21, v25, v26 offset0:12 offset1:14     // 00000014BBB8: D8380E0C 001A1915
	s_waitcnt lgkmcnt(0)                                       // 00000014BBC0: BF89FC07
	s_barrier                                                  // 00000014BBC4: BFBD0000
	buffer_gl0_inv                                             // 00000014BBC8: E0AC0000 00000000
	s_set_inst_prefetch_distance 0x1                           // 00000014BBD0: BF840001
	s_branch 28                                                // 00000014BBD4: BFA0001C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a48>
	s_nop 0                                                    // 00000014BBD8: BF800000
	s_nop 0                                                    // 00000014BBDC: BF800000
	s_nop 0                                                    // 00000014BBE0: BF800000
	s_nop 0                                                    // 00000014BBE4: BF800000
	s_nop 0                                                    // 00000014BBE8: BF800000
	s_nop 0                                                    // 00000014BBEC: BF800000
	s_nop 0                                                    // 00000014BBF0: BF800000
	s_nop 0                                                    // 00000014BBF4: BF800000
	s_nop 0                                                    // 00000014BBF8: BF800000
	s_nop 0                                                    // 00000014BBFC: BF800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014BC00: 8C7E017E
	v_add_nc_u32_e32 v7, 0x80, v7                              // 00000014BC04: 4A0E0EFF 00000080
	.long 0xd7000404                                           // 00000014BC0C: D7000404
	v_cndmask_b32_e32 v0, v4, v136, vcc_lo                     // 00000014BC10: 02011104
	ds_store_b16 v6, v3 offset:10240                           // 00000014BC14: D87C2800 00000306
	v_add_nc_u32_e32 v6, 0x140, v6                             // 00000014BC1C: 4A0C0CFF 00000140
	.long 0xd4490001                                           // 00000014BC24: D4490001
	v_cndmask_b32_e32 v1, 0x37f, v7, vcc_lo                    // 00000014BC28: 02020EFF 0000037F
	v_add_co_ci_u32_e64 v5, null, 0, v5, s4                    // 00000014BC30: D5207C05 00120A80
	s_or_b32 s6, s1, s6                                        // 00000014BC38: 8C060601
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014BC3C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000014BC40: 917E067E
	s_cbranch_execz 65222                                      // 00000014BC44: BFA5FEC6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3560>
	.long 0x7e063880                                           // 00000014BC48: 7E063880
	s_and_saveexec_b32 s1, s0                                  // 00000014BC4C: BE812000
	s_cbranch_execz 65515                                      // 00000014BC50: BFA5FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a00>
	global_load_b32 v3, v[4:5], off offset:64                  // 00000014BC54: DC520040 037C0004
	ds_load_b32 v8, v91                                        // 00000014BC5C: D8D80000 0800005B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014BC64: BF890007
	v_mul_f32_e32 v3, v3, v8                                   // 00000014BC68: 10061103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014BC6C: BF870001
	v_fma_mixlo_f16 v3, v3, s12, 0                             // 00000014BC70: CC210003 02001903
	s_branch 65505                                             // 00000014BC78: BFA0FFE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a00>
	ds_load_b32 v3, v90                                        // 00000014BC7C: D8D80000 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014BC84: BF89FC07
	v_fma_f32 v3, 0, v3, v42                                   // 00000014BC88: D6130003 04AA0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014BC90: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 00000014BC94: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v5, v[70:71]           // 00000014BC9C: D6FE7C03 051A0AFF 00003000
	v_bfe_u32 v53, v42, 16, 1                                  // 00000014BCA8: D6100035 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014BCB0: BF870001
	v_add3_u32 v42, v42, v53, 0x7fff                           // 00000014BCB4: D655002A 03FE6B2A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 00000014BCC0: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014BCC8: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 00000014BCCC: BE8A2001
	s_cbranch_execz 65041                                      // 00000014BCD0: BFA5FE11 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3318>
	ds_load_b32 v3, v90 offset:8                               // 00000014BCD4: D8D80008 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014BCDC: BF89FC07
	v_fma_f32 v3, 0, v3, v43                                   // 00000014BCE0: D6130003 04AE0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014BCE8: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 00000014BCEC: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v6, v[70:71]           // 00000014BCF4: D6FE7C03 051A0CFF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 00000014BD00: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014BD08: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000014BD0C: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 00000014BD18: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014BD20: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 00000014BD24: BE8A2004
	s_cbranch_execz 65022                                      // 00000014BD28: BFA5FDFE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3324>
	ds_load_b32 v3, v90 offset:16                              // 00000014BD2C: D8D80010 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014BD34: BF89FC07
	v_fma_f32 v3, 0, v3, v44                                   // 00000014BD38: D6130003 04B20680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014BD40: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 00000014BD44: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[70:71]           // 00000014BD4C: D6FE7C03 051A0EFF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 00000014BD58: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014BD60: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000014BD64: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 00000014BD70: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014BD78: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 00000014BD7C: BE8A2005
	s_cbranch_execz 65003                                      // 00000014BD80: BFA5FDEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3330>
	ds_load_b32 v3, v90 offset:24                              // 00000014BD84: D8D80018 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014BD8C: BF89FC07
	v_fma_f32 v3, 0, v3, v45                                   // 00000014BD90: D6130003 04B60680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014BD98: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 00000014BD9C: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[70:71]           // 00000014BDA4: D6FE7C03 051A10FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 00000014BDB0: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014BDB8: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000014BDBC: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 00000014BDC8: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014BDD0: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 00000014BDD4: BE8A2006
	s_cbranch_execz 64984                                      // 00000014BDD8: BFA5FDD8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x333c>
	ds_load_b32 v3, v90 offset:32                              // 00000014BDDC: D8D80020 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014BDE4: BF89FC07
	v_fma_f32 v3, 0, v3, v46                                   // 00000014BDE8: D6130003 04BA0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014BDF0: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 00000014BDF4: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[70:71]           // 00000014BDFC: D6FE7C03 051A12FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 00000014BE08: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014BE10: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000014BE14: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 00000014BE20: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014BE28: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 00000014BE2C: BE8A2007
	s_cbranch_execz 64965                                      // 00000014BE30: BFA5FDC5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3348>
	ds_load_b32 v3, v90 offset:40                              // 00000014BE34: D8D80028 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014BE3C: BF89FC07
	v_fma_f32 v3, 0, v3, v47                                   // 00000014BE40: D6130003 04BE0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014BE48: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 00000014BE4C: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v50, v[70:71]          // 00000014BE54: D6FE7C03 051A64FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 00000014BE60: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014BE68: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000014BE6C: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 00000014BE78: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014BE80: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 00000014BE84: BE8A2008
	s_cbranch_execz 64946                                      // 00000014BE88: BFA5FDB2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3354>
	ds_load_b32 v3, v90 offset:48                              // 00000014BE8C: D8D80030 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014BE94: BF89FC07
	v_fma_f32 v3, 0, v3, v48                                   // 00000014BE98: D6130003 04C20680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014BEA0: BF870121
	v_mul_f32_e32 v42, 0x3b800000, v3                          // 00000014BEA4: 105406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v51, v[70:71]          // 00000014BEAC: D6FE7C03 051A66FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 00000014BEB8: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014BEC0: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000014BEC4: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 00000014BED0: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014BED8: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 00000014BEDC: BE8A2009
	s_cbranch_execz 64927                                      // 00000014BEE0: BFA5FD9F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3360>
	ds_load_b32 v3, v90 offset:56                              // 00000014BEE4: D8D80038 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014BEEC: BF89FC07
	v_fmac_f32_e32 v49, 0, v3                                  // 00000014BEF0: 56620680
	v_mad_u64_u32 v[3:4], null, 0x3000, v52, v[70:71]          // 00000014BEF4: D6FE7C03 051A68FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014BF00: BF870092
	v_mul_f32_e32 v42, 0x3b800000, v49                         // 00000014BF04: 105462FF 3B800000
	v_bfe_u32 v43, v42, 16, 1                                  // 00000014BF0C: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014BF14: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000014BF18: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[3:4], v42, off                   // 00000014BF24: DC960000 007C2A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014BF2C: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 00000014BF30: BE8A2000
	s_cbranch_execz 64909                                      // 00000014BF34: BFA5FD8D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x336c>
	ds_load_b32 v3, v90                                        // 00000014BF38: D8D80000 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014BF40: BF89FC07
	v_fma_f32 v3, 0, v3, v34                                   // 00000014BF44: D6130003 048A0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014BF4C: BF870121
	v_mul_f32_e32 v34, 0x3b800000, v3                          // 00000014BF50: 104406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v5, v[70:71]           // 00000014BF58: D6FE7C03 051A0AFF 00003000
	v_bfe_u32 v42, v34, 16, 1                                  // 00000014BF64: D610002A 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014BF6C: BF870001
	v_add3_u32 v34, v34, v42, 0x7fff                           // 00000014BF70: D6550022 03FE5522 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:32         // 00000014BF7C: DC960020 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014BF84: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 00000014BF88: BE8A2001
	s_cbranch_execz 64890                                      // 00000014BF8C: BFA5FD7A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3378>
	ds_load_b32 v3, v90 offset:8                               // 00000014BF90: D8D80008 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014BF98: BF89FC07
	v_fma_f32 v3, 0, v3, v35                                   // 00000014BF9C: D6130003 048E0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014BFA4: BF870121
	v_mul_f32_e32 v34, 0x3b800000, v3                          // 00000014BFA8: 104406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v6, v[70:71]           // 00000014BFB0: D6FE7C03 051A0CFF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 00000014BFBC: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014BFC4: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000014BFC8: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:32         // 00000014BFD4: DC960020 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014BFDC: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 00000014BFE0: BE8A2004
	s_cbranch_execz 64871                                      // 00000014BFE4: BFA5FD67 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3384>
	ds_load_b32 v3, v90 offset:16                              // 00000014BFE8: D8D80010 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014BFF0: BF89FC07
	v_fma_f32 v3, 0, v3, v36                                   // 00000014BFF4: D6130003 04920680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014BFFC: BF870121
	v_mul_f32_e32 v34, 0x3b800000, v3                          // 00000014C000: 104406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[70:71]           // 00000014C008: D6FE7C03 051A0EFF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 00000014C014: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C01C: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000014C020: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:32         // 00000014C02C: DC960020 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C034: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 00000014C038: BE8A2005
	s_cbranch_execz 64852                                      // 00000014C03C: BFA5FD54 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3390>
	ds_load_b32 v3, v90 offset:24                              // 00000014C040: D8D80018 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C048: BF89FC07
	v_fma_f32 v3, 0, v3, v37                                   // 00000014C04C: D6130003 04960680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C054: BF870121
	v_mul_f32_e32 v34, 0x3b800000, v3                          // 00000014C058: 104406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[70:71]           // 00000014C060: D6FE7C03 051A10FF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 00000014C06C: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C074: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000014C078: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:32         // 00000014C084: DC960020 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C08C: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 00000014C090: BE8A2006
	s_cbranch_execz 64833                                      // 00000014C094: BFA5FD41 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x339c>
	ds_load_b32 v3, v90 offset:32                              // 00000014C098: D8D80020 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C0A0: BF89FC07
	v_fma_f32 v3, 0, v3, v38                                   // 00000014C0A4: D6130003 049A0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C0AC: BF870121
	v_mul_f32_e32 v34, 0x3b800000, v3                          // 00000014C0B0: 104406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[70:71]           // 00000014C0B8: D6FE7C03 051A12FF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 00000014C0C4: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C0CC: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000014C0D0: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:32         // 00000014C0DC: DC960020 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C0E4: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 00000014C0E8: BE8A2007
	s_cbranch_execz 64814                                      // 00000014C0EC: BFA5FD2E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33a8>
	ds_load_b32 v3, v90 offset:40                              // 00000014C0F0: D8D80028 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C0F8: BF89FC07
	v_fma_f32 v3, 0, v3, v39                                   // 00000014C0FC: D6130003 049E0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C104: BF870121
	v_mul_f32_e32 v34, 0x3b800000, v3                          // 00000014C108: 104406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v50, v[70:71]          // 00000014C110: D6FE7C03 051A64FF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 00000014C11C: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C124: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000014C128: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:32         // 00000014C134: DC960020 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C13C: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 00000014C140: BE8A2008
	s_cbranch_execz 64795                                      // 00000014C144: BFA5FD1B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33b4>
	ds_load_b32 v3, v90 offset:48                              // 00000014C148: D8D80030 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C150: BF89FC07
	v_fma_f32 v3, 0, v3, v40                                   // 00000014C154: D6130003 04A20680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C15C: BF870121
	v_mul_f32_e32 v34, 0x3b800000, v3                          // 00000014C160: 104406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v51, v[70:71]          // 00000014C168: D6FE7C03 051A66FF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 00000014C174: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C17C: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000014C180: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:32         // 00000014C18C: DC960020 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C194: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 00000014C198: BE8A2009
	s_cbranch_execz 64776                                      // 00000014C19C: BFA5FD08 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33c0>
	ds_load_b32 v3, v90 offset:56                              // 00000014C1A0: D8D80038 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C1A8: BF89FC07
	v_fmac_f32_e32 v41, 0, v3                                  // 00000014C1AC: 56520680
	v_mad_u64_u32 v[3:4], null, 0x3000, v52, v[70:71]          // 00000014C1B0: D6FE7C03 051A68FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014C1BC: BF870092
	v_mul_f32_e32 v34, 0x3b800000, v41                         // 00000014C1C0: 104452FF 3B800000
	v_bfe_u32 v35, v34, 16, 1                                  // 00000014C1C8: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C1D0: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000014C1D4: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[3:4], v34, off offset:32         // 00000014C1E0: DC960020 007C2203
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C1E8: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 00000014C1EC: BE8A2000
	s_cbranch_execz 64758                                      // 00000014C1F0: BFA5FCF6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33cc>
	ds_load_b32 v3, v90                                        // 00000014C1F4: D8D80000 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C1FC: BF89FC07
	v_fma_f32 v3, 0, v3, v26                                   // 00000014C200: D6130003 046A0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C208: BF870121
	v_mul_f32_e32 v26, 0x3b800000, v3                          // 00000014C20C: 103406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v5, v[70:71]           // 00000014C214: D6FE7C03 051A0AFF 00003000
	v_bfe_u32 v34, v26, 16, 1                                  // 00000014C220: D6100022 0205211A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C228: BF870001
	v_add3_u32 v26, v26, v34, 0x7fff                           // 00000014C22C: D655001A 03FE451A 00007FFF
	global_store_d16_hi_b16 v[3:4], v26, off offset:64         // 00000014C238: DC960040 007C1A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C240: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 00000014C244: BE8A2001
	s_cbranch_execz 64739                                      // 00000014C248: BFA5FCE3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33d8>
	ds_load_b32 v3, v90 offset:8                               // 00000014C24C: D8D80008 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C254: BF89FC07
	v_fma_f32 v3, 0, v3, v27                                   // 00000014C258: D6130003 046E0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C260: BF870121
	v_mul_f32_e32 v26, 0x3b800000, v3                          // 00000014C264: 103406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v6, v[70:71]           // 00000014C26C: D6FE7C03 051A0CFF 00003000
	v_bfe_u32 v27, v26, 16, 1                                  // 00000014C278: D610001B 0205211A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C280: BF870001
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000014C284: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[3:4], v26, off offset:64         // 00000014C290: DC960040 007C1A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C298: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 00000014C29C: BE8A2004
	s_cbranch_execz 64720                                      // 00000014C2A0: BFA5FCD0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33e4>
	ds_load_b32 v3, v90 offset:16                              // 00000014C2A4: D8D80010 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C2AC: BF89FC07
	v_fma_f32 v3, 0, v3, v28                                   // 00000014C2B0: D6130003 04720680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C2B8: BF870121
	v_mul_f32_e32 v26, 0x3b800000, v3                          // 00000014C2BC: 103406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[70:71]           // 00000014C2C4: D6FE7C03 051A0EFF 00003000
	v_bfe_u32 v27, v26, 16, 1                                  // 00000014C2D0: D610001B 0205211A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C2D8: BF870001
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000014C2DC: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[3:4], v26, off offset:64         // 00000014C2E8: DC960040 007C1A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C2F0: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 00000014C2F4: BE8A2005
	s_cbranch_execz 64701                                      // 00000014C2F8: BFA5FCBD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33f0>
	ds_load_b32 v3, v90 offset:24                              // 00000014C2FC: D8D80018 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C304: BF89FC07
	v_fma_f32 v3, 0, v3, v29                                   // 00000014C308: D6130003 04760680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C310: BF870121
	v_mul_f32_e32 v26, 0x3b800000, v3                          // 00000014C314: 103406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[70:71]           // 00000014C31C: D6FE7C03 051A10FF 00003000
	v_bfe_u32 v27, v26, 16, 1                                  // 00000014C328: D610001B 0205211A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C330: BF870001
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000014C334: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[3:4], v26, off offset:64         // 00000014C340: DC960040 007C1A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C348: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 00000014C34C: BE8A2006
	s_cbranch_execz 64682                                      // 00000014C350: BFA5FCAA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33fc>
	ds_load_b32 v3, v90 offset:32                              // 00000014C354: D8D80020 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C35C: BF89FC07
	v_fma_f32 v3, 0, v3, v30                                   // 00000014C360: D6130003 047A0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C368: BF870121
	v_mul_f32_e32 v26, 0x3b800000, v3                          // 00000014C36C: 103406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[70:71]           // 00000014C374: D6FE7C03 051A12FF 00003000
	v_bfe_u32 v27, v26, 16, 1                                  // 00000014C380: D610001B 0205211A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C388: BF870001
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000014C38C: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[3:4], v26, off offset:64         // 00000014C398: DC960040 007C1A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C3A0: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 00000014C3A4: BE8A2007
	s_cbranch_execz 64663                                      // 00000014C3A8: BFA5FC97 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3408>
	ds_load_b32 v3, v90 offset:40                              // 00000014C3AC: D8D80028 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C3B4: BF89FC07
	v_fma_f32 v3, 0, v3, v31                                   // 00000014C3B8: D6130003 047E0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C3C0: BF870121
	v_mul_f32_e32 v26, 0x3b800000, v3                          // 00000014C3C4: 103406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v50, v[70:71]          // 00000014C3CC: D6FE7C03 051A64FF 00003000
	v_bfe_u32 v27, v26, 16, 1                                  // 00000014C3D8: D610001B 0205211A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C3E0: BF870001
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000014C3E4: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[3:4], v26, off offset:64         // 00000014C3F0: DC960040 007C1A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C3F8: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 00000014C3FC: BE8A2008
	s_cbranch_execz 64644                                      // 00000014C400: BFA5FC84 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3414>
	ds_load_b32 v3, v90 offset:48                              // 00000014C404: D8D80030 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C40C: BF89FC07
	v_fma_f32 v3, 0, v3, v32                                   // 00000014C410: D6130003 04820680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C418: BF870121
	v_mul_f32_e32 v26, 0x3b800000, v3                          // 00000014C41C: 103406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v51, v[70:71]          // 00000014C424: D6FE7C03 051A66FF 00003000
	v_bfe_u32 v27, v26, 16, 1                                  // 00000014C430: D610001B 0205211A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C438: BF870001
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000014C43C: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[3:4], v26, off offset:64         // 00000014C448: DC960040 007C1A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C450: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 00000014C454: BE8A2009
	s_cbranch_execz 64625                                      // 00000014C458: BFA5FC71 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3420>
	ds_load_b32 v3, v90 offset:56                              // 00000014C45C: D8D80038 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C464: BF89FC07
	v_fmac_f32_e32 v33, 0, v3                                  // 00000014C468: 56420680
	v_mad_u64_u32 v[3:4], null, 0x3000, v52, v[70:71]          // 00000014C46C: D6FE7C03 051A68FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014C478: BF870092
	v_mul_f32_e32 v26, 0x3b800000, v33                         // 00000014C47C: 103442FF 3B800000
	v_bfe_u32 v27, v26, 16, 1                                  // 00000014C484: D610001B 0205211A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C48C: BF870001
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000014C490: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[3:4], v26, off offset:64         // 00000014C49C: DC960040 007C1A03
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C4A4: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 00000014C4A8: BE8A2000
	s_cbranch_execz 64607                                      // 00000014C4AC: BFA5FC5F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x342c>
	ds_load_b32 v3, v90                                        // 00000014C4B0: D8D80000 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C4B8: BF89FC07
	v_fma_f32 v3, 0, v3, v18                                   // 00000014C4BC: D6130003 044A0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C4C4: BF870121
	v_mul_f32_e32 v18, 0x3b800000, v3                          // 00000014C4C8: 102406FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v5, v[70:71]           // 00000014C4D0: D6FE7C03 051A0AFF 00003000
	v_bfe_u32 v26, v18, 16, 1                                  // 00000014C4DC: D610001A 02052112
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C4E4: BF870001
	v_add3_u32 v5, v18, v26, 0x7fff                            // 00000014C4E8: D6550005 03FE3512 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000014C4F4: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014C4FC: 8C7E0A7E
	s_and_saveexec_b32 s0, s1                                  // 00000014C500: BE802001
	s_cbranch_execz 64588                                      // 00000014C504: BFA5FC4C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3438>
	ds_load_b32 v3, v90 offset:8                               // 00000014C508: D8D80008 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C510: BF89FC07
	v_fma_f32 v3, 0, v3, v19                                   // 00000014C514: D6130003 044E0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C51C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000014C520: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v6, v[70:71]           // 00000014C528: D6FE7C03 051A0CFF 00003000
	v_bfe_u32 v18, v5, 16, 1                                   // 00000014C534: D6100012 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C53C: BF870001
	v_add3_u32 v5, v5, v18, 0x7fff                             // 00000014C540: D6550005 03FE2505 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000014C54C: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014C554: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000014C558: BE802004
	s_cbranch_execz 64569                                      // 00000014C55C: BFA5FC39 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3444>
	ds_load_b32 v3, v90 offset:16                              // 00000014C560: D8D80010 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C568: BF89FC07
	v_fma_f32 v3, 0, v3, v20                                   // 00000014C56C: D6130003 04520680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C574: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000014C578: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[70:71]           // 00000014C580: D6FE7C03 051A0EFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000014C58C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C594: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000014C598: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000014C5A4: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014C5AC: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000014C5B0: BE802005
	s_cbranch_execz 64550                                      // 00000014C5B4: BFA5FC26 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3450>
	ds_load_b32 v3, v90 offset:24                              // 00000014C5B8: D8D80018 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C5C0: BF89FC07
	v_fma_f32 v3, 0, v3, v21                                   // 00000014C5C4: D6130003 04560680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C5CC: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000014C5D0: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[70:71]           // 00000014C5D8: D6FE7C03 051A10FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000014C5E4: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C5EC: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000014C5F0: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000014C5FC: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014C604: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000014C608: BE802006
	s_cbranch_execz 64531                                      // 00000014C60C: BFA5FC13 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x345c>
	ds_load_b32 v3, v90 offset:32                              // 00000014C610: D8D80020 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C618: BF89FC07
	v_fma_f32 v3, 0, v3, v22                                   // 00000014C61C: D6130003 045A0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C624: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000014C628: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[70:71]           // 00000014C630: D6FE7C03 051A12FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000014C63C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C644: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000014C648: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000014C654: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014C65C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000014C660: BE802007
	s_cbranch_execz 64512                                      // 00000014C664: BFA5FC00 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3468>
	ds_load_b32 v3, v90 offset:40                              // 00000014C668: D8D80028 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C670: BF89FC07
	v_fma_f32 v3, 0, v3, v23                                   // 00000014C674: D6130003 045E0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C67C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000014C680: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v50, v[70:71]          // 00000014C688: D6FE7C03 051A64FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000014C694: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C69C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000014C6A0: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000014C6AC: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014C6B4: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000014C6B8: BE802008
	s_cbranch_execz 64493                                      // 00000014C6BC: BFA5FBED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3474>
	ds_load_b32 v3, v90 offset:48                              // 00000014C6C0: D8D80030 0300005A
	s_waitcnt lgkmcnt(0)                                       // 00000014C6C8: BF89FC07
	v_fma_f32 v3, 0, v3, v24                                   // 00000014C6CC: D6130003 04620680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014C6D4: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000014C6D8: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v51, v[70:71]          // 00000014C6E0: D6FE7C03 051A66FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000014C6EC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C6F4: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000014C6F8: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000014C704: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014C70C: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000014C710: BE802009
	s_cbranch_execnz 64474                                     // 00000014C714: BFA6FBDA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3480>
	s_branch 64491                                             // 00000014C718: BFA0FBEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x34c8>
	v_dual_mov_b32 v2, v75 :: v_dual_mov_b32 v3, v1            // 00000014C71C: CA10014B 02020101
	s_add_u32 s0, s11, s36                                     // 00000014C724: 8000240B
	.long 0xd73c0000                                           // 00000014C728: D73C0000
	v_cndmask_b32_e32 v1, 9, v68, vcc_lo                       // 00000014C72C: 02028889
	s_addc_u32 s1, s33, s37                                    // 00000014C730: 82012521
	s_add_u32 s2, s38, s34                                     // 00000014C734: 80022226
	s_addc_u32 s3, s39, s35                                    // 00000014C738: 82032327
	s_add_u32 s0, s2, s0                                       // 00000014C73C: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000014C740: 82010103
	v_lshlrev_b32_e32 v4, 2, v74                               // 00000014C744: 30089482
	.long 0xd7006a00                                           // 00000014C748: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000014C74C: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000014C750: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000014C754: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000014C75C: BE810080
	.long 0xd7006a00                                           // 00000014C760: D7006A00
	v_cndmask_b32_e32 v1, v0, v4, vcc_lo                       // 00000014C764: 02020900
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000014C768: D5207C01 01AA0280
	v_mul_u32_u24_e32 v4, 0x210, v74                           // 00000014C770: 160894FF 00000210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014C778: BF870093
	.long 0xd7006a00                                           // 00000014C77C: D7006A00
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 00000014C780: 02020016
	v_add_co_ci_u32_e64 v1, null, s23, v1, vcc_lo              // 00000014C784: D5207C01 01AA0217
	s_delay_alu instid0(VALU_DEP_3)                            // 00000014C78C: BF870003
	v_lshl_add_u32 v3, v3, 2, v4                               // 00000014C790: D6460003 04110503
	s_nop 0                                                    // 00000014C798: BF800000
	s_nop 0                                                    // 00000014C79C: BF800000
	s_nop 0                                                    // 00000014C7A0: BF800000
	s_nop 0                                                    // 00000014C7A4: BF800000
	s_nop 0                                                    // 00000014C7A8: BF800000
	s_nop 0                                                    // 00000014C7AC: BF800000
	s_nop 0                                                    // 00000014C7B0: BF800000
	s_nop 0                                                    // 00000014C7B4: BF800000
	s_nop 0                                                    // 00000014C7B8: BF800000
	s_nop 0                                                    // 00000014C7BC: BF800000
	ds_load_b32 v4, v3 offset:12800                            // 00000014C7C0: D8D83200 04000003
	v_add_nc_u32_e32 v2, 0x80, v2                              // 00000014C7C8: 4A0404FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 00000014C7D0: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000014C7D4: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v2                        // 00000014C7D8: 7C9204FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 00000014C7E0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000014C7E4: BF89FC07
	global_store_b32 v[0:1], v4, off                           // 00000014C7E8: DC6A0000 007C0400
	.long 0xd7000000                                           // 00000014C7F0: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 00000014C7F4: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000014C7FC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000014C804: 917E017E
	s_cbranch_execnz 65517                                     // 00000014C808: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi2EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x45c0>
	s_nop 0                                                    // 00000014C80C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000014C810: BFB60003
	s_endpgm                                                   // 00000014C814: BFB00000
		...

