000000000007d300 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 00000007D300: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 00000007D304: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000007D30C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 00000007D314: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 00000007D318: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000007D31C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 00000007D320: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000007D328: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000007D32C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 00000007D330: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 00000007D334: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000007D33C: 84928214
	s_add_u32 s25, s16, s18                                    // 00000007D340: 80191210
	s_addc_u32 s28, s17, s19                                   // 00000007D344: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 00000007D348: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007D34C: BF870009
	s_add_u32 s25, s25, s20                                    // 00000007D350: 80191419
	s_addc_u32 s30, s28, s21                                   // 00000007D354: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 00000007D358: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000007D35C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 00000007D364: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000007D36C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 00000007D370: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 00000007D374: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000007D378: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000007D37C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 00000007D380: 821E191E
	.long 0xd7001f02                                           // 00000007D384: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 00000007D388: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000007D38C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 00000007D394: BE9E0080
	s_nop 0                                                    // 00000007D398: BF800000
	s_nop 0                                                    // 00000007D39C: BF800000
	s_nop 0                                                    // 00000007D3A0: BF800000
	s_nop 0                                                    // 00000007D3A4: BF800000
	s_nop 0                                                    // 00000007D3A8: BF800000
	s_nop 0                                                    // 00000007D3AC: BF800000
	s_nop 0                                                    // 00000007D3B0: BF800000
	s_nop 0                                                    // 00000007D3B4: BF800000
	s_nop 0                                                    // 00000007D3B8: BF800000
	s_nop 0                                                    // 00000007D3BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 00000007D3C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 00000007D3C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D3CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 00000007D3D0: 300C1089
	.long 0xd7006a06                                           // 00000007D3D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000007D3D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007D3DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 00000007D3E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000007D3E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 00000007D3F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 00000007D3F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 00000007D3FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 00000007D408: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000007D40C: BF8903F7
	ds_store_b32 v6, v9                                        // 00000007D410: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 00000007D418: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000007D41C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 00000007D420: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 00000007D424: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 00000007D42C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 00000007D434: 32040084
	s_mov_b32 s0, 0                                            // 00000007D438: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000007D43C: BF89FC07
	s_barrier                                                  // 00000007D440: BFBD0000
	buffer_gl0_inv                                             // 00000007D444: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000007D44C: BF02801E
	s_cbranch_scc1 12                                          // 00000007D450: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 00000007D454: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000007D45C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007D464: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 00000007D468: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 00000007D470: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000007D474: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000007D478: 916A007E
	s_cbranch_vccz 2                                           // 00000007D47C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2248                                              // 00000007D480: BFA008C8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x24a4>
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000007D484: 304E0A82
	s_add_i32 s0, s30, 63                                      // 00000007D488: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000007D48C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 00000007D494: 85218600
	s_add_u32 s34, s10, s24                                    // 00000007D498: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000007D49C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 00000007D4A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 00000007D4A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 00000007D4AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 00000007D4B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000007D4B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 00000007D4B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 00000007D4BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 00000007D4C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 00000007D4C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 00000007D4C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 00000007D4D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 00000007D4D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 00000007D4DC: B00A0204
	.long 0xd7000b2c                                           // 00000007D4E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 00000007D4E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000007D4E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 00000007D4EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 00000007D4F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 00000007D500: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 00000007D504: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 00000007D510: 3816500A
	.long 0xd7000a05                                           // 00000007D514: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 00000007D518: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007D51C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 00000007D520: D5207C06 00290001
	.long 0xd7000107                                           // 00000007D528: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 00000007D52C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007D530: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 00000007D534: D5207C08 0006180D
	.long 0xd7000109                                           // 00000007D53C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 00000007D540: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 00000007D544: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 00000007D54C: 84848E02
	.long 0xd700010b                                           // 00000007D550: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 00000007D554: 02021606
	s_add_u32 s4, s14, s4                                      // 00000007D558: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 00000007D55C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 00000007D564: 8205050F
	.long 0xd700010d                                           // 00000007D568: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 00000007D56C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007D570: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 00000007D574: D5207C0E 00050005
	.long 0xd700010f                                           // 00000007D57C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 00000007D580: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 00000007D588: D5207C10 00061880
	.long 0xd7000111                                           // 00000007D590: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 00000007D594: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007D59C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 00000007D5A0: D5207C12 00061880
	.long 0xd7000113                                           // 00000007D5A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 00000007D5AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 00000007D5B4: D5207C14 00061880
	.long 0xd7000115                                           // 00000007D5BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 00000007D5C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007D5C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 00000007D5CC: D5207C16 00061880
	.long 0xd7000117                                           // 00000007D5D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 00000007D5D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 00000007D5E0: D5207C18 00061880
	.long 0xd7000119                                           // 00000007D5E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 00000007D5EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007D5F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 00000007D5F8: D5207C1A 00061880
	.long 0xd700011b                                           // 00000007D600: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 00000007D604: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 00000007D60C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 00000007D614: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000007D618: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 00000007D620: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 00000007D624: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 00000007D62C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 00000007D634: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 00000007D63C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 00000007D644: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 00000007D64C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 00000007D654: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 00000007D65C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 00000007D664: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 00000007D66C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 00000007D674: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 00000007D67C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 00000007D684: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 00000007D68C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 00000007D694: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 00000007D69C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000007D6A0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 00000007D6A4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000007D6AC: BF870499
	s_add_i32 s6, s31, s1                                      // 00000007D6B0: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 00000007D6B4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007D6B8: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 00000007D6BC: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 00000007D6C0: 84078605
	s_add_u32 s10, s8, s10                                     // 00000007D6C4: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 00000007D6C8: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 00000007D6CC: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 00000007D6D4: BE84206A
	s_cbranch_execz 77                                         // 00000007D6D8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s7, v0                                   // 00000007D6DC: 383A0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D6E0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 00000007D6E4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 00000007D6EC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D6F0: BF870091
	.long 0xd73c001d                                           // 00000007D6F4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 00000007D6F8: 02023A82
	.long 0xd700011d                                           // 00000007D6FC: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 00000007D700: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007D704: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 00000007D708: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 00000007D710: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007D718: BF890007
	v_sub_f32_e32 v30, s6, v29                                 // 00000007D71C: 083C3A06
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 00000007D720: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000007D72C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 00000007D730: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 00000007D73C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 00000007D740: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 00000007D74C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007D750: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 00000007D754: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 00000007D760: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007D764: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 00000007D768: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 00000007D770: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 00000007D774: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 00000007D77C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 00000007D784: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 00000007D788: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007D78C: BF870193
	v_exp_f32_e32 v32, v32                                     // 00000007D790: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 00000007D794: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007D798: BF870296
	.long 0xd71c0020                                           // 00000007D79C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 00000007D7A0: 02024520
	.long 0xd71c001f                                           // 00000007D7A4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 00000007D7A8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007D7AC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 00000007D7B0: D501001F 00063E80
	.long 0xd41b0001                                           // 00000007D7B8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 00000007D7BC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 00000007D7C4: D5010020 00064080
	.long 0xd41e0001                                           // 00000007D7CC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 00000007D7D0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007D7D8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 00000007D7DC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 00000007D7E8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 00000007D7EC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 00000007D7F4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 00000007D800: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 00000007D808: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007D810: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 00000007D814: CA100108 1E1C0107
	s_mov_b32 s10, 0                                           // 00000007D81C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000007D820: BF89FC07
	s_barrier                                                  // 00000007D824: BFBD0000
	buffer_gl0_inv                                             // 00000007D828: E0AC0000 00000000
	s_branch 15                                                // 00000007D830: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007D834: 8C7E047E
	.long 0xd700011d                                           // 00000007D838: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 00000007D83C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007D844: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007D848: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000007D850: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000007D854: BF08B70A
	s_mov_b32 s10, s1                                          // 00000007D858: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 00000007D85C: BF89FC07
	s_barrier                                                  // 00000007D860: BFBD0000
	buffer_gl0_inv                                             // 00000007D864: E0AC0000 00000000
	s_cbranch_scc1 706                                         // 00000007D86C: BFA202C2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 00000007D870: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 00000007D878: CA100128 21220126
	s_mov_b32 s11, 0                                           // 00000007D880: BE8B0080
	s_nop 0                                                    // 00000007D884: BF800000
	s_nop 0                                                    // 00000007D888: BF800000
	s_nop 0                                                    // 00000007D88C: BF800000
	s_nop 0                                                    // 00000007D890: BF800000
	s_nop 0                                                    // 00000007D894: BF800000
	s_nop 0                                                    // 00000007D898: BF800000
	s_nop 0                                                    // 00000007D89C: BF800000
	s_nop 0                                                    // 00000007D8A0: BF800000
	s_nop 0                                                    // 00000007D8A4: BF800000
	s_nop 0                                                    // 00000007D8A8: BF800000
	s_nop 0                                                    // 00000007D8AC: BF800000
	s_nop 0                                                    // 00000007D8B0: BF800000
	s_nop 0                                                    // 00000007D8B4: BF800000
	s_nop 0                                                    // 00000007D8B8: BF800000
	s_nop 0                                                    // 00000007D8BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 00000007D8C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 00000007D8C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 00000007D8D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 00000007D8D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007D8DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000007D8E0: D5207C20 00064080
	.long 0xd4490004                                           // 00000007D8E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 00000007D8EC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000007D8F4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000007D8F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 00000007D8FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 00000007D904: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000007D90C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000007D910: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000007D914: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000007D918: BF89FC07
	s_barrier                                                  // 00000007D91C: BFBD0000
	buffer_gl0_inv                                             // 00000007D920: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000007D928: BE842000
	s_cbranch_execz 65473                                      // 00000007D92C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 00000007D930: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 00000007D938: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 00000007D940: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 00000007D948: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 00000007D950: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 00000007D958: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 00000007D960: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 00000007D968: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 00000007D970: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 00000007D978: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 00000007D980: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 00000007D988: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 00000007D990: D8DCFFEE 50000001
	v_or3_b32 v70, s10, s7, v2                                 // 00000007D998: D6580046 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D9A0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 00000007D9A4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 00000007D9AC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 00000007D9B0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D9B4: BF870091
	.long 0xd7000146                                           // 00000007D9B8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 00000007D9BC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 00000007D9C0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 00000007D9C8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 00000007D9D0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 00000007D9D4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007D9DC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 00000007D9E0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 00000007D9E8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 00000007D9EC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 00000007D9F4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 00000007D9FC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 00000007DA04: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 00000007DA0C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 00000007DA14: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DA18: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 00000007DA1C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 00000007DA24: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 00000007DA2C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DA30: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 00000007DA34: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 00000007DA3C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 00000007DA44: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DA48: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 00000007DA4C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 00000007DA54: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 00000007DA5C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007DA60: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000007DA64: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 00000007DA6C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 00000007DA74: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 00000007DA7C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 00000007DA84: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 00000007DA8C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 00000007DA94: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 00000007DA9C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 00000007DAA4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 00000007DAAC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 00000007DAB4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DAB8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 00000007DABC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 00000007DAC4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DACC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 00000007DAD0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 00000007DAD8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 00000007DAE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DAE4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 00000007DAE8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 00000007DAF0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 00000007DAF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007DAFC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 00000007DB00: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 00000007DB08: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 00000007DB10: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 00000007DB18: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 00000007DB20: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 00000007DB28: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 00000007DB30: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 00000007DB38: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 00000007DB40: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 00000007DB48: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 00000007DB50: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DB54: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 00000007DB58: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 00000007DB60: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 00000007DB68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DB6C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000007DB70: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000007DB78: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000007DB80: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DB84: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 00000007DB88: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 00000007DB90: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 00000007DB98: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007DB9C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000007DBA0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 00000007DBA8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 00000007DBB0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 00000007DBB8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 00000007DBC0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 00000007DBC8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 00000007DBD0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 00000007DBD8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 00000007DBE0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 00000007DBE8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000007DBF0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DBF4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000007DBF8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000007DC00: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000007DC08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DC0C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 00000007DC10: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 00000007DC18: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 00000007DC20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DC24: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 00000007DC28: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 00000007DC30: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 00000007DC38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007DC3C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 00000007DC40: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 00000007DC48: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 00000007DC50: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 00000007DC58: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 00000007DC60: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 00000007DC68: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 00000007DC70: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 00000007DC78: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 00000007DC80: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 00000007DC88: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 00000007DC90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DC94: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000007DC98: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000007DCA0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000007DCA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DCAC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000007DCB0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000007DCB8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000007DCC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DCC4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 00000007DCC8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 00000007DCD0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 00000007DCD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007DCDC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000007DCE0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 00000007DCE8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 00000007DCF0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 00000007DCF8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 00000007DD00: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 00000007DD08: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 00000007DD10: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 00000007DD18: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 00000007DD20: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 00000007DD28: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000007DD30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DD34: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000007DD38: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000007DD40: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000007DD48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DD4C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000007DD50: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000007DD58: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000007DD60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DD64: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000007DD68: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000007DD70: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000007DD78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007DD7C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000007DD80: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 00000007DD88: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 00000007DD90: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 00000007DD98: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 00000007DDA0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 00000007DDA8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 00000007DDB0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 00000007DDB8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 00000007DDC0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 00000007DDC8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000007DDD0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DDD4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000007DDD8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000007DDE0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000007DDE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DDEC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000007DDF0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000007DDF8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000007DE00: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DE04: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000007DE08: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000007DE10: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000007DE18: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007DE1C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000007DE20: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 00000007DE28: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 00000007DE30: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 00000007DE38: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 00000007DE40: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 00000007DE48: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 00000007DE50: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 00000007DE58: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 00000007DE60: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 00000007DE68: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000007DE70: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DE74: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000007DE78: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000007DE80: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000007DE88: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DE8C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000007DE90: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000007DE98: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000007DEA0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DEA4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000007DEA8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000007DEB0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000007DEB8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007DEBC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000007DEC0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 00000007DEC8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 00000007DED0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 00000007DED8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 00000007DEE0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 00000007DEE8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 00000007DEF0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 00000007DEF8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 00000007DF00: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 00000007DF08: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000007DF10: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DF14: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000007DF18: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000007DF20: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000007DF28: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DF2C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000007DF30: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000007DF38: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000007DF40: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DF44: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000007DF48: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000007DF50: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000007DF58: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007DF5C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000007DF60: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 00000007DF68: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 00000007DF70: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 00000007DF78: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 00000007DF80: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 00000007DF88: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 00000007DF90: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 00000007DF98: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 00000007DFA0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 00000007DFA8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000007DFB0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DFB4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000007DFB8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000007DFC0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000007DFC8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DFCC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000007DFD0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000007DFD8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000007DFE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DFE4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000007DFE8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000007DFF0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000007DFF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007DFFC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000007E000: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 00000007E008: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 00000007E010: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 00000007E018: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 00000007E020: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 00000007E028: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 00000007E030: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 00000007E038: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 00000007E040: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 00000007E048: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000007E050: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E054: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000007E058: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000007E060: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000007E068: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E06C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000007E070: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000007E078: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000007E080: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E084: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000007E088: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000007E090: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000007E098: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007E09C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000007E0A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 00000007E0A8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 00000007E0B0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 00000007E0B8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 00000007E0C0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 00000007E0C8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 00000007E0D0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 00000007E0D8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 00000007E0E0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 00000007E0E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000007E0F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E0F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000007E0F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000007E100: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000007E108: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E10C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000007E110: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000007E118: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000007E120: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E124: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000007E128: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000007E130: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000007E138: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007E13C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000007E140: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 00000007E148: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 00000007E150: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 00000007E158: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 00000007E160: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 00000007E168: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 00000007E170: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 00000007E178: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 00000007E180: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 00000007E188: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000007E190: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E194: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000007E198: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000007E1A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000007E1A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E1AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000007E1B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000007E1B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000007E1C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E1C4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000007E1C8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000007E1D0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000007E1D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007E1DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000007E1E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 00000007E1E8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 00000007E1F0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 00000007E1F8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 00000007E200: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 00000007E208: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 00000007E210: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 00000007E218: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 00000007E220: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 00000007E228: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000007E230: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E234: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000007E238: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000007E240: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000007E248: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E24C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000007E250: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000007E258: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000007E260: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E264: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000007E268: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000007E270: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000007E278: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007E27C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000007E280: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 00000007E288: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 00000007E290: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 00000007E298: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 00000007E2A0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 00000007E2A8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 00000007E2B0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 00000007E2B8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 00000007E2C0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 00000007E2C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000007E2D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E2D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000007E2D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000007E2E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000007E2E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E2EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000007E2F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000007E2F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000007E300: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E304: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000007E308: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000007E310: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000007E318: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E31C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 00000007E320: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 00000007E328: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 00000007E330: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E334: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 00000007E338: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 00000007E340: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 00000007E348: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007E34C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 00000007E350: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s10, v[4:5]            // 00000007E358: D6FE7C1F 041014FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 00000007E364: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 00000007E36C: D8340000 0000201F
	s_branch 64815                                             // 00000007E374: BFA0FD2F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_mov_b32_e32 v30, v14                                     // 00000007E378: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 00000007E37C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 00000007E384: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 00000007E388: 7E46032B
	s_mov_b32 s10, 0                                           // 00000007E38C: BE8A0080
	s_branch 21                                                // 00000007E390: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000007E394: 8C7E0B7E
	.long 0xd700011f                                           // 00000007E398: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 00000007E39C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007E3A4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000007E3A8: D5207C20 00064080
	.long 0xd700011d                                           // 00000007E3B0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 00000007E3B4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 00000007E3BC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007E3C0: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000007E3C8: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000007E3CC: BF08B70A
	s_mov_b32 s10, s1                                          // 00000007E3D0: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 00000007E3D4: BC7C0000
	s_barrier                                                  // 00000007E3D8: BFBD0000
	buffer_gl0_inv                                             // 00000007E3DC: E0AC0000 00000000
	s_cbranch_scc1 246                                         // 00000007E3E4: BFA200F6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14c0>
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007E3E8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 00000007E3EC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 00000007E3F4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 00000007E3F8: 7E780326
	s_mov_b32 s11, 0                                           // 00000007E3FC: BE8B0080
	global_load_b32 v61, v[33:34], off                         // 00000007E400: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 00000007E408: 4A7878FF 00000080
	.long 0xd7000121                                           // 00000007E410: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 00000007E414: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007E41C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 00000007E420: D5207C22 00064480
	.long 0xd4490004                                           // 00000007E428: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 00000007E42C: 020278FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000007E434: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000007E438: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 00000007E43C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 00000007E444: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000007E44C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000007E450: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000007E454: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000007E458: BF89FC07
	s_barrier                                                  // 00000007E45C: BFBD0000
	buffer_gl0_inv                                             // 00000007E460: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 00000007E468: BE8B2000
	s_cbranch_execz 65481                                      // 00000007E46C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s10, v2                                  // 00000007E470: 3842040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E474: BF870091
	v_or_b32_e32 v36, s7, v33                                  // 00000007E478: 38484207
	.long 0xd4440001                                           // 00000007E47C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 00000007E480: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 00000007E484: 8B7E017E
	s_cbranch_execz 65474                                      // 00000007E488: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_mov_b32_e32 v60, 0                                       // 00000007E48C: 7E780280
	s_mov_b32 s1, 0                                            // 00000007E490: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007E494: BF870009
	v_lshl_add_u32 v34, s1, 2, v46                             // 00000007E498: D6460022 04B90401
	s_add_i32 s4, s1, 8                                        // 00000007E4A0: 81048801
	s_cmpk_lt_u32 s1, 0x78                                     // 00000007E4A4: B6810078
	ds_load_2addr_b32 v[70:71], v34 offset0:6 offset1:7        // 00000007E4A8: D8DC0706 46000022
	ds_load_2addr_b32 v[72:73], v34 offset1:1                  // 00000007E4B0: D8DC0100 48000022
	ds_load_2addr_b32 v[74:75], v34 offset0:4 offset1:5        // 00000007E4B8: D8DC0504 4A000022
	ds_load_2addr_b32 v[76:77], v34 offset0:2 offset1:3        // 00000007E4C0: D8DC0302 4C000022
	v_mad_u64_u32 v[61:62], null, 0x44, s1, v[1:2]             // 00000007E4C8: D6FE7C3D 040402FF 00000044
	s_mov_b32 s1, s4                                           // 00000007E4D4: BE810004
	ds_load_2addr_b32 v[62:63], v61 offset1:17                 // 00000007E4D8: D8DC1100 3E00003D
	ds_load_2addr_b32 v[66:67], v61 offset0:34 offset1:51      // 00000007E4E0: D8DC3322 4200003D
	ds_load_2addr_b32 v[68:69], v61 offset0:68 offset1:85      // 00000007E4E8: D8DC5544 4400003D
	ds_load_2addr_b32 v[64:65], v61 offset0:102 offset1:119    // 00000007E4F0: D8DC7766 4000003D
	s_waitcnt lgkmcnt(7)                                       // 00000007E4F8: BF89FC77
	v_bfe_u32 v85, v70, 16, 1                                  // 00000007E4FC: D6100055 02052146
	s_waitcnt lgkmcnt(6)                                       // 00000007E504: BF89FC67
	v_bfe_u32 v87, v72, 16, 1                                  // 00000007E508: D6100057 02052148
	v_bfe_u32 v90, v73, 16, 1                                  // 00000007E510: D610005A 02052149
	s_waitcnt lgkmcnt(4)                                       // 00000007E518: BF89FC47
	v_bfe_u32 v89, v77, 16, 1                                  // 00000007E51C: D6100059 0205214D
	v_bfe_u32 v88, v74, 16, 1                                  // 00000007E524: D6100058 0205214A
	v_bfe_u32 v86, v75, 16, 1                                  // 00000007E52C: D6100056 0205214B
	v_add3_u32 v72, v72, v87, 0x7fff                           // 00000007E534: D6550048 03FEAF48 00007FFF
	v_add3_u32 v73, v73, v90, 0x7fff                           // 00000007E540: D6550049 03FEB549 00007FFF
	v_bfe_u32 v84, v71, 16, 1                                  // 00000007E54C: D6100054 02052147
	s_delay_alu instid0(VALU_DEP_3)                            // 00000007E554: BF870003
	v_and_b32_e32 v72, 0xffff0000, v72                         // 00000007E558: 369090FF FFFF0000
	s_waitcnt lgkmcnt(3)                                       // 00000007E560: BF89FC37
	v_bfe_u32 v83, v62, 16, 1                                  // 00000007E564: D6100053 0205213E
	v_bfe_u32 v82, v63, 16, 1                                  // 00000007E56C: D6100052 0205213F
	s_waitcnt lgkmcnt(2)                                       // 00000007E574: BF89FC27
	v_bfe_u32 v81, v66, 16, 1                                  // 00000007E578: D6100051 02052142
	v_bfe_u32 v80, v67, 16, 1                                  // 00000007E580: D6100050 02052143
	v_and_b32_e32 v73, 0xffff0000, v73                         // 00000007E588: 369292FF FFFF0000
	v_add3_u32 v62, v62, v83, 0x7fff                           // 00000007E590: D655003E 03FEA73E 00007FFF
	v_bfe_u32 v83, v76, 16, 1                                  // 00000007E59C: D6100053 0205214C
	v_add3_u32 v63, v63, v82, 0x7fff                           // 00000007E5A4: D655003F 03FEA53F 00007FFF
	v_add3_u32 v66, v66, v81, 0x7fff                           // 00000007E5B0: D6550042 03FEA342 00007FFF
	s_waitcnt lgkmcnt(1)                                       // 00000007E5BC: BF89FC17
	v_bfe_u32 v79, v68, 16, 1                                  // 00000007E5C0: D610004F 02052144
	v_and_b32_e32 v62, 0xffff0000, v62                         // 00000007E5C8: 367C7CFF FFFF0000
	v_add3_u32 v76, v76, v83, 0x7fff                           // 00000007E5D0: D655004C 03FEA74C 00007FFF
	v_and_b32_e32 v63, 0xffff0000, v63                         // 00000007E5DC: 367E7EFF FFFF0000
	v_and_b32_e32 v66, 0xffff0000, v66                         // 00000007E5E4: 368484FF FFFF0000
	v_bfe_u32 v78, v69, 16, 1                                  // 00000007E5EC: D610004E 02052145
	v_fmac_f32_e32 v60, v72, v62                               // 00000007E5F4: 56787D48
	v_add3_u32 v62, v67, v80, 0x7fff                           // 00000007E5F8: D655003E 03FEA143 00007FFF
	v_add3_u32 v67, v77, v89, 0x7fff                           // 00000007E604: D6550043 03FEB34D 00007FFF
	v_and_b32_e32 v72, 0xffff0000, v76                         // 00000007E610: 369098FF FFFF0000
	s_waitcnt lgkmcnt(0)                                       // 00000007E618: BF89FC07
	v_bfe_u32 v61, v64, 16, 1                                  // 00000007E61C: D610003D 02052140
	v_fmac_f32_e32 v60, v73, v63                               // 00000007E624: 56787F49
	v_add3_u32 v63, v68, v79, 0x7fff                           // 00000007E628: D655003F 03FE9F44 00007FFF
	v_add3_u32 v68, v74, v88, 0x7fff                           // 00000007E634: D6550044 03FEB14A 00007FFF
	v_and_b32_e32 v62, 0xffff0000, v62                         // 00000007E640: 367C7CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007E648: BF870004
	v_dual_fmac_f32 v60, v72, v66 :: v_dual_and_b32 v67, 0xffff0000, v67// 00000007E64C: C8248548 3C4286FF FFFF0000
	v_add3_u32 v66, v69, v78, 0x7fff                           // 00000007E658: D6550042 03FE9D45 00007FFF
	v_add3_u32 v69, v75, v86, 0x7fff                           // 00000007E664: D6550045 03FEAD4B 00007FFF
	v_and_b32_e32 v63, 0xffff0000, v63                         // 00000007E670: 367E7EFF FFFF0000
	v_and_b32_e32 v68, 0xffff0000, v68                         // 00000007E678: 368888FF FFFF0000
	v_fmac_f32_e32 v60, v67, v62                               // 00000007E680: 56787D43
	v_bfe_u32 v34, v65, 16, 1                                  // 00000007E684: D6100022 02052141
	v_add3_u32 v61, v64, v61, 0x7fff                           // 00000007E68C: D655003D 03FE7B40 00007FFF
	v_add3_u32 v62, v70, v85, 0x7fff                           // 00000007E698: D655003E 03FEAB46 00007FFF
	v_and_b32_e32 v64, 0xffff0000, v66                         // 00000007E6A4: 368084FF FFFF0000
	v_and_b32_e32 v66, 0xffff0000, v69                         // 00000007E6AC: 36848AFF FFFF0000
	v_fmac_f32_e32 v60, v68, v63                               // 00000007E6B4: 56787F44
	v_add3_u32 v34, v65, v34, 0x7fff                           // 00000007E6B8: D6550022 03FE4541 00007FFF
	v_add3_u32 v63, v71, v84, 0x7fff                           // 00000007E6C4: D655003F 03FEA947 00007FFF
	v_and_b32_e32 v61, 0xffff0000, v61                         // 00000007E6D0: 367A7AFF FFFF0000
	v_and_b32_e32 v62, 0xffff0000, v62                         // 00000007E6D8: 367C7CFF FFFF0000
	v_fmac_f32_e32 v60, v66, v64                               // 00000007E6E0: 56788142
	v_and_b32_e32 v34, 0xffff0000, v34                         // 00000007E6E4: 364444FF FFFF0000
	v_and_b32_e32 v63, 0xffff0000, v63                         // 00000007E6EC: 367E7EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E6F4: BF870093
	v_fmac_f32_e32 v60, v62, v61                               // 00000007E6F8: 56787B3E
	v_fmac_f32_e32 v60, v63, v34                               // 00000007E6FC: 5678453F
	s_cbranch_scc1 65380                                       // 00000007E700: BFA2FF64 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1194>
	v_lshlrev_b32_e32 v33, 2, v33                              // 00000007E704: 30424282
	v_mov_b32_e32 v61, v1                                      // 00000007E708: 7E7A0301
	s_mov_b32 s12, 0                                           // 00000007E70C: BE8C0080
	ds_load_b32 v62, v33 offset:17440                          // 00000007E710: D8D84420 3E000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 00000007E718: CA10011E 2220011D
	s_waitcnt lgkmcnt(0)                                       // 00000007E720: BF89FC07
	v_mul_f32_e32 v60, v60, v62                                // 00000007E724: 10787D3C
	v_mov_b32_e32 v62, v35                                     // 00000007E728: 7E7C0323
	s_nop 0                                                    // 00000007E72C: BF800000
	s_nop 0                                                    // 00000007E730: BF800000
	s_nop 0                                                    // 00000007E734: BF800000
	s_nop 0                                                    // 00000007E738: BF800000
	s_nop 0                                                    // 00000007E73C: BF800000
	global_load_b32 v63, v[33:34], off                         // 00000007E740: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 00000007E748: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 00000007E750: 4A7C7CC1
	.long 0xd7000121                                           // 00000007E754: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 00000007E758: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007E75C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 00000007E760: D5207C22 00064480
	.long 0xd44a0004                                           // 00000007E768: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 00000007E76C: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 00000007E770: 4A7A7AFF 00000044
	s_or_b32 s12, s4, s12                                      // 00000007E778: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007E77C: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 00000007E780: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 00000007E784: 917E0C7E
	s_cbranch_execnz 65517                                     // 00000007E788: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1440>
	s_or_b32 exec_lo, exec_lo, s12                             // 00000007E78C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007E790: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 00000007E794: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 00000007E79C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 00000007E7A8: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 00000007E7B4: DC960000 007C2421
	s_branch 65269                                             // 00000007E7BC: BFA0FEF5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 00000007E7C0: A201FF06 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 00000007E7C8: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000007E7CC: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 00000007E7D0: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 00000007E7D8: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 00000007E7DC: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 00000007E7E4: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 00000007E7EC: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000007E7F0: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 00000007E7F4: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 00000007E7FC: A0010401
	s_mov_b32 s4, 0                                            // 00000007E800: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 00000007E804: BF87000A
	v_exp_f32_e32 v29, s1                                      // 00000007E808: 7E3A4A01
	s_cvt_i32_f32 s1, s7                                       // 00000007E80C: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000007E810: BF870585
	.long 0xd71c001d                                           // 00000007E814: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 00000007E818: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 00000007E81C: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 00000007E820: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000007E828: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 00000007E82C: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 00000007E834: 980180C1
	v_mov_b32_e32 v29, v37                                     // 00000007E838: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 00000007E83C: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 00000007E848: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 00000007E850: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007E858: BF870001
	.long 0xd4490001                                           // 00000007E85C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 00000007E860: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 00000007E868: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 00000007E86C: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 00000007E870: 1040411E
	ds_store_b32 v29, v32                                      // 00000007E874: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 00000007E87C: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007E884: 917E047E
	s_cbranch_execnz 65519                                     // 00000007E888: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1548>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007E88C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 00000007E890: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 00000007E898: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 00000007E8A0: 7E420326
	s_mov_b32 s6, 0                                            // 00000007E8A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007E8A8: BF89FC07
	s_barrier                                                  // 00000007E8AC: BFBD0000
	buffer_gl0_inv                                             // 00000007E8B0: E0AC0000 00000000
	s_nop 0                                                    // 00000007E8B8: BF800000
	s_nop 0                                                    // 00000007E8BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007E8C0: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 00000007E8C8: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007E8D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007E8D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007E8DC: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 00000007E8E4: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007E8E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007E8F0: BF870004
	.long 0xd4490004                                           // 00000007E8F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007E8F8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007E900: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007E904: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007E908: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 00000007E90C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 00000007E914: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007E91C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007E920: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007E924: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000007E928: BF89FC07
	s_barrier                                                  // 00000007E92C: BFBD0000
	buffer_gl0_inv                                             // 00000007E930: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 00000007E938: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 00000007E940: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 00000007E948: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 00000007E950: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 00000007E958: 7E780300
	s_mov_b32 s4, 0                                            // 00000007E95C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007E960: BF840001
	s_nop 0                                                    // 00000007E964: BF800000
	s_nop 0                                                    // 00000007E968: BF800000
	s_nop 0                                                    // 00000007E96C: BF800000
	s_nop 0                                                    // 00000007E970: BF800000
	s_nop 0                                                    // 00000007E974: BF800000
	s_nop 0                                                    // 00000007E978: BF800000
	s_nop 0                                                    // 00000007E97C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007E980: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000007E984: 327A7884
	.long 0xd4490001                                           // 00000007E988: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000007E98C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000007E994: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000007E998: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007E9A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000007E9A8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000007E9B0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000007E9B8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000007E9C0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000007E9C8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000007E9D0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000007E9D8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000007E9E0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000007E9E4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007E9F0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000007E9F4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000007E9F8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000007EA00: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000007EA04: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000007EA08: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000007EA0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EA10: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000007EA14: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000007EA18: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000007EA1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EA20: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000007EA24: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000007EA30: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000007EA38: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007EA40: 917E047E
	s_cbranch_execnz 65486                                     // 00000007EA44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1680>
	s_set_inst_prefetch_distance 0x2                           // 00000007EA48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007EA4C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 00000007EA50: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000007EA58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000007EA60: 7E420326
	s_mov_b32 s6, 0                                            // 00000007EA64: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007EA68: BF89FC07
	s_barrier                                                  // 00000007EA6C: BFBD0000
	buffer_gl0_inv                                             // 00000007EA70: E0AC0000 00000000
	s_nop 0                                                    // 00000007EA78: BF800000
	s_nop 0                                                    // 00000007EA7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007EA80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 00000007EA88: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007EA90: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007EA98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007EA9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000007EAA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007EAA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007EAB0: BF870004
	.long 0xd4490004                                           // 00000007EAB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007EAB8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007EAC0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007EAC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007EAC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007EACC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000007EAD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007EADC: 917E067E
	s_cbranch_execnz 65511                                     // 00000007EAE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1780>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007EAE4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000007EAE8: BF89FC07
	s_barrier                                                  // 00000007EAEC: BFBD0000
	buffer_gl0_inv                                             // 00000007EAF0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 00000007EAF8: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 00000007EB00: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 00000007EB08: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 00000007EB10: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 00000007EB18: 7E780300
	s_mov_b32 s4, 0                                            // 00000007EB1C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007EB20: BF840001
	s_nop 0                                                    // 00000007EB24: BF800000
	s_nop 0                                                    // 00000007EB28: BF800000
	s_nop 0                                                    // 00000007EB2C: BF800000
	s_nop 0                                                    // 00000007EB30: BF800000
	s_nop 0                                                    // 00000007EB34: BF800000
	s_nop 0                                                    // 00000007EB38: BF800000
	s_nop 0                                                    // 00000007EB3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007EB40: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000007EB44: 327A7884
	.long 0xd4490001                                           // 00000007EB48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000007EB4C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000007EB54: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000007EB58: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007EB64: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000007EB68: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000007EB70: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000007EB78: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000007EB80: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000007EB88: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000007EB90: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000007EB98: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000007EBA0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000007EBA4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007EBB0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000007EBB4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000007EBB8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000007EBC0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000007EBC4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000007EBC8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000007EBCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EBD0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000007EBD4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000007EBD8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000007EBDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EBE0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000007EBE4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000007EBF0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000007EBF8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007EC00: 917E047E
	s_cbranch_execnz 65486                                     // 00000007EC04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1840>
	s_set_inst_prefetch_distance 0x2                           // 00000007EC08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007EC0C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 00000007EC10: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000007EC18: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000007EC20: 7E420326
	s_mov_b32 s6, 0                                            // 00000007EC24: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007EC28: BF89FC07
	s_barrier                                                  // 00000007EC2C: BFBD0000
	buffer_gl0_inv                                             // 00000007EC30: E0AC0000 00000000
	s_nop 0                                                    // 00000007EC38: BF800000
	s_nop 0                                                    // 00000007EC3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007EC40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 00000007EC48: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007EC50: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007EC58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007EC5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000007EC64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007EC68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007EC70: BF870004
	.long 0xd4490004                                           // 00000007EC74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007EC78: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007EC80: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007EC84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007EC88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007EC8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000007EC94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007EC9C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007ECA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007ECA4: 8C7E067E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 00000007ECA8: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 00000007ECB0: BF89FC07
	s_barrier                                                  // 00000007ECB4: BFBD0000
	buffer_gl0_inv                                             // 00000007ECB8: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 00000007ECC0: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 00000007ECC4: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 00000007ECCC: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 00000007ECD4: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 00000007ECDC: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 00000007ECE4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007ECE8: BF840001
	s_nop 0                                                    // 00000007ECEC: BF800000
	s_nop 0                                                    // 00000007ECF0: BF800000
	s_nop 0                                                    // 00000007ECF4: BF800000
	s_nop 0                                                    // 00000007ECF8: BF800000
	s_nop 0                                                    // 00000007ECFC: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000007ED00: 327C7A84
	.long 0xd4490001                                           // 00000007ED04: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000007ED08: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007ED10: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000007ED14: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000007ED18: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007ED24: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000007ED28: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000007ED30: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000007ED38: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000007ED40: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000007ED48: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000007ED50: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000007ED58: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000007ED60: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000007ED64: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007ED68: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000007ED6C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000007ED78: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000007ED80: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000007ED84: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000007ED88: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000007ED8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007ED90: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000007ED94: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000007ED98: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000007ED9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EDA0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000007EDA4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000007EDB0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000007EDB8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007EDC0: 917E047E
	s_cbranch_execnz 65486                                     // 00000007EDC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a00>
	s_set_inst_prefetch_distance 0x2                           // 00000007EDC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007EDCC: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 00000007EDD0: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000007EDD8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000007EDE0: 7E420326
	s_mov_b32 s6, 0                                            // 00000007EDE4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007EDE8: BF89FC07
	s_barrier                                                  // 00000007EDEC: BFBD0000
	buffer_gl0_inv                                             // 00000007EDF0: E0AC0000 00000000
	s_nop 0                                                    // 00000007EDF8: BF800000
	s_nop 0                                                    // 00000007EDFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007EE00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 00000007EE08: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007EE10: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007EE18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007EE1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000007EE24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007EE28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007EE30: BF870004
	.long 0xd4490004                                           // 00000007EE34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007EE38: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007EE40: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007EE44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007EE48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007EE4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000007EE54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007EE5C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007EE60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007EE64: 8C7E067E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 00000007EE68: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 00000007EE70: BF89FC07
	s_barrier                                                  // 00000007EE74: BFBD0000
	buffer_gl0_inv                                             // 00000007EE78: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 00000007EE80: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 00000007EE88: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 00000007EE90: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 00000007EE98: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 00000007EEA0: 7E780300
	s_mov_b32 s4, 0                                            // 00000007EEA4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007EEA8: BF840001
	s_nop 0                                                    // 00000007EEAC: BF800000
	s_nop 0                                                    // 00000007EEB0: BF800000
	s_nop 0                                                    // 00000007EEB4: BF800000
	s_nop 0                                                    // 00000007EEB8: BF800000
	s_nop 0                                                    // 00000007EEBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007EEC0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000007EEC4: 327A7884
	.long 0xd4490001                                           // 00000007EEC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000007EECC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000007EED4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000007EED8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007EEE4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000007EEE8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000007EEF0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000007EEF8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000007EF00: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000007EF08: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000007EF10: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000007EF18: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000007EF20: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000007EF24: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007EF30: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000007EF34: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000007EF38: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000007EF40: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000007EF44: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000007EF48: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000007EF4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EF50: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000007EF54: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000007EF58: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000007EF5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EF60: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000007EF64: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000007EF70: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000007EF78: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007EF80: 917E047E
	s_cbranch_execnz 65486                                     // 00000007EF84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1bc0>
	s_set_inst_prefetch_distance 0x2                           // 00000007EF88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007EF8C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 00000007EF90: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000007EF98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000007EFA0: 7E420326
	s_mov_b32 s6, 0                                            // 00000007EFA4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007EFA8: BF89FC07
	s_barrier                                                  // 00000007EFAC: BFBD0000
	buffer_gl0_inv                                             // 00000007EFB0: E0AC0000 00000000
	s_nop 0                                                    // 00000007EFB8: BF800000
	s_nop 0                                                    // 00000007EFBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007EFC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 00000007EFC8: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007EFD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007EFD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007EFDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000007EFE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007EFE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007EFF0: BF870004
	.long 0xd4490004                                           // 00000007EFF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007EFF8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007F000: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007F004: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007F008: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007F00C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000007F014: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007F01C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007F020: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007F024: 8C7E067E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 00000007F028: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 00000007F030: BF89FC07
	s_barrier                                                  // 00000007F034: BFBD0000
	buffer_gl0_inv                                             // 00000007F038: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 00000007F040: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 00000007F044: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 00000007F04C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 00000007F054: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 00000007F05C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 00000007F064: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007F068: BF840001
	s_nop 0                                                    // 00000007F06C: BF800000
	s_nop 0                                                    // 00000007F070: BF800000
	s_nop 0                                                    // 00000007F074: BF800000
	s_nop 0                                                    // 00000007F078: BF800000
	s_nop 0                                                    // 00000007F07C: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 00000007F080: 327C7884
	.long 0xd4490001                                           // 00000007F084: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000007F088: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007F090: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000007F094: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000007F098: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007F0A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000007F0A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000007F0B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000007F0B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000007F0C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000007F0C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000007F0D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000007F0D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000007F0E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000007F0E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007F0E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000007F0EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000007F0F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000007F100: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000007F104: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000007F108: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000007F10C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F110: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000007F114: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000007F118: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000007F11C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F120: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 00000007F124: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 00000007F130: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007F134: BF870002
	v_mov_b32_e32 v60, v63                                     // 00000007F138: 7E78033F
	ds_store_b32 v62, v70                                      // 00000007F13C: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007F144: 917E047E
	s_cbranch_execnz 65485                                     // 00000007F148: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d80>
	s_set_inst_prefetch_distance 0x2                           // 00000007F14C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007F150: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 00000007F154: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000007F15C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000007F164: 7E420326
	s_mov_b32 s6, 0                                            // 00000007F168: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007F16C: BF89FC07
	s_barrier                                                  // 00000007F170: BFBD0000
	buffer_gl0_inv                                             // 00000007F174: E0AC0000 00000000
	s_nop 0                                                    // 00000007F17C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007F180: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 00000007F188: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007F190: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007F198: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007F19C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000007F1A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007F1A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007F1B0: BF870004
	.long 0xd4490004                                           // 00000007F1B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007F1B8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007F1C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007F1C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007F1C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007F1CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000007F1D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007F1DC: 917E067E
	s_cbranch_execnz 65511                                     // 00000007F1E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e80>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007F1E4: 8C7E067E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 00000007F1E8: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 00000007F1F0: BF89FC07
	s_barrier                                                  // 00000007F1F4: BFBD0000
	buffer_gl0_inv                                             // 00000007F1F8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 00000007F200: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 00000007F208: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 00000007F210: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 00000007F218: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 00000007F220: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000007F224: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007F228: BF840001
	s_nop 0                                                    // 00000007F22C: BF800000
	s_nop 0                                                    // 00000007F230: BF800000
	s_nop 0                                                    // 00000007F234: BF800000
	s_nop 0                                                    // 00000007F238: BF800000
	s_nop 0                                                    // 00000007F23C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007F240: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000007F244: 327C7A84
	.long 0xd4490001                                           // 00000007F248: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000007F24C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000007F254: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000007F258: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007F264: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000007F268: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000007F270: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000007F278: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000007F280: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000007F288: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000007F290: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000007F298: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000007F2A0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000007F2A4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007F2A8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000007F2AC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000007F2B8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000007F2C0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000007F2C4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000007F2C8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000007F2CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F2D0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000007F2D4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000007F2D8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000007F2DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F2E0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000007F2E4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000007F2F0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000007F2F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007F300: 917E047E
	s_cbranch_execnz 65486                                     // 00000007F304: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f40>
	s_set_inst_prefetch_distance 0x2                           // 00000007F308: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007F30C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 00000007F310: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000007F318: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000007F320: 7E420326
	s_mov_b32 s6, 0                                            // 00000007F324: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007F328: BF89FC07
	s_barrier                                                  // 00000007F32C: BFBD0000
	buffer_gl0_inv                                             // 00000007F330: E0AC0000 00000000
	s_nop 0                                                    // 00000007F338: BF800000
	s_nop 0                                                    // 00000007F33C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007F340: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 00000007F348: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007F350: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007F358: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007F35C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000007F364: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007F368: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007F370: BF870004
	.long 0xd4490004                                           // 00000007F374: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007F378: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007F380: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007F384: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007F388: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007F38C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000007F394: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007F39C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007F3A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007F3A4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000007F3A8: BF89FC07
	s_barrier                                                  // 00000007F3AC: BFBD0000
	buffer_gl0_inv                                             // 00000007F3B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 00000007F3B8: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 00000007F3C0: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 00000007F3C8: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 00000007F3D0: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 00000007F3D8: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000007F3DC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007F3E0: BF840001
	s_nop 0                                                    // 00000007F3E4: BF800000
	s_nop 0                                                    // 00000007F3E8: BF800000
	s_nop 0                                                    // 00000007F3EC: BF800000
	s_nop 0                                                    // 00000007F3F0: BF800000
	s_nop 0                                                    // 00000007F3F4: BF800000
	s_nop 0                                                    // 00000007F3F8: BF800000
	s_nop 0                                                    // 00000007F3FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007F400: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000007F404: 327C7A84
	.long 0xd4490001                                           // 00000007F408: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000007F40C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000007F414: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000007F418: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007F424: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000007F428: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000007F430: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000007F438: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000007F440: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000007F448: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000007F450: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000007F458: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000007F460: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000007F464: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007F468: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000007F46C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000007F478: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000007F480: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000007F484: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000007F488: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000007F48C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F490: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000007F494: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000007F498: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000007F49C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F4A0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000007F4A4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000007F4B0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000007F4B8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007F4C0: 917E047E
	s_cbranch_execnz 65486                                     // 00000007F4C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2100>
	s_set_inst_prefetch_distance 0x2                           // 00000007F4C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007F4CC: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 00000007F4D0: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000007F4D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000007F4E0: 7E420326
	s_mov_b32 s6, 0                                            // 00000007F4E4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007F4E8: BF89FC07
	s_barrier                                                  // 00000007F4EC: BFBD0000
	buffer_gl0_inv                                             // 00000007F4F0: E0AC0000 00000000
	s_nop 0                                                    // 00000007F4F8: BF800000
	s_nop 0                                                    // 00000007F4FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007F500: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 00000007F508: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007F510: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007F518: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007F51C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000007F524: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007F528: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007F530: BF870004
	.long 0xd4490004                                           // 00000007F534: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007F538: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007F540: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007F544: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007F548: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007F54C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000007F554: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007F55C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007F560: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2200>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007F564: 8C7E067E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 00000007F568: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 00000007F570: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 00000007F578: BF89FC07
	s_barrier                                                  // 00000007F57C: BFBD0000
	buffer_gl0_inv                                             // 00000007F580: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 00000007F588: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 00000007F590: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 00000007F598: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 00000007F5A0: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 00000007F5A8: 7E780300
	s_mov_b32 s4, 0                                            // 00000007F5AC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007F5B0: BF840001
	s_nop 0                                                    // 00000007F5B4: BF800000
	s_nop 0                                                    // 00000007F5B8: BF800000
	s_nop 0                                                    // 00000007F5BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007F5C0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000007F5C4: 327A7884
	.long 0xd4490001                                           // 00000007F5C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000007F5CC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000007F5D4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000007F5D8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007F5E4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000007F5E8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000007F5F0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000007F5F8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000007F600: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000007F608: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000007F610: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000007F618: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000007F620: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000007F624: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007F630: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000007F634: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000007F638: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000007F640: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000007F644: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000007F648: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000007F64C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F650: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000007F654: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000007F658: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000007F65C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F660: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000007F664: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000007F670: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000007F678: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007F680: 917E047E
	s_cbranch_execnz 65486                                     // 00000007F684: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x22c0>
	s_set_inst_prefetch_distance 0x2                           // 00000007F688: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007F68C: 8C7E047E
	.long 0xd7000107                                           // 00000007F690: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 00000007F694: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007F69C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 00000007F6A0: D5207C08 00061080
	.long 0xd7000109                                           // 00000007F6A8: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 00000007F6AC: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 00000007F6B4: D5207C0A 00061480
	.long 0xd700010d                                           // 00000007F6BC: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 00000007F6C0: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007F6C8: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 00000007F6CC: D5207C0E 00061C80
	.long 0xd700010b                                           // 00000007F6D4: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 00000007F6D8: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 00000007F6E0: D5207C0C 00061880
	.long 0xd700010f                                           // 00000007F6E8: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 00000007F6EC: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007F6F4: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 00000007F6F8: D5207C10 00062080
	.long 0xd7000111                                           // 00000007F700: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 00000007F704: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 00000007F70C: D5207C12 00062480
	.long 0xd7000113                                           // 00000007F714: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 00000007F718: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007F720: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 00000007F724: D5207C14 00062880
	.long 0xd7000115                                           // 00000007F72C: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 00000007F730: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 00000007F738: D5207C16 00062C80
	.long 0xd7000117                                           // 00000007F740: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 00000007F744: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007F74C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 00000007F750: D5207C18 00063080
	.long 0xd7000119                                           // 00000007F758: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 00000007F75C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 00000007F764: D5207C1A 00063480
	.long 0xd700011b                                           // 00000007F76C: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 00000007F770: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007F778: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 00000007F77C: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 00000007F784: 81058105
	s_waitcnt lgkmcnt(0)                                       // 00000007F788: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 00000007F78C: BF062105
	s_barrier                                                  // 00000007F790: BFBD0000
	buffer_gl0_inv                                             // 00000007F794: E0AC0000 00000000
	s_cbranch_scc0 63425                                       // 00000007F79C: BFA1F7C1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 00000007F7A0: 7E080326
	s_add_u32 s0, s28, s20                                     // 00000007F7A4: 8000141C
	.long 0xd73c0000                                           // 00000007F7A8: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000007F7AC: 02020489
	s_addc_u32 s1, s29, s21                                    // 00000007F7B0: 8201151D
	s_add_u32 s2, s24, s18                                     // 00000007F7B4: 80021218
	s_addc_u32 s3, s25, s19                                    // 00000007F7B8: 82031319
	s_add_u32 s0, s2, s0                                       // 00000007F7BC: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000007F7C0: 82010103
	.long 0xd7006a00                                           // 00000007F7C4: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000007F7C8: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000007F7CC: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000007F7D0: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000007F7D8: BE810080
	.long 0xd7006a00                                           // 00000007F7DC: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 00000007F7E0: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000007F7E4: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F7EC: BF870092
	.long 0xd7006a00                                           // 00000007F7F0: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000007F7F4: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000007F7F8: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 00000007F800: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 00000007F808: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 00000007F810: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000007F818: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000007F81C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 00000007F824: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000007F828: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 00000007F82C: DC6A0000 007C0200
	.long 0xd7000000                                           // 00000007F834: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000007F838: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000007F840: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000007F848: 917E017E
	s_cbranch_execnz 65516                                     // 00000007F84C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2500>
	s_endpgm                                                   // 00000007F850: BFB00000
		...

