00000000000f5a00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 0000000F5A00: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 0000000F5A04: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 0000000F5A0C: F4080500 F8000050
	v_and_b32_e32 v130, 31, v0                                 // 0000000F5A14: 3704009F
	v_lshrrev_b32_e32 v157, 5, v0                              // 0000000F5A18: 333A0085
	s_mov_b32 s24, s3                                          // 0000000F5A1C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F5A20: BF870112
	.long 0xd44c0003                                           // 0000000F5A24: D44C0003
	v_cndmask_b32_e32 v1, 16, v130, vcc_lo                     // 0000000F5A28: 02030490
	v_lshlrev_b32_e32 v131, 6, v157                            // 0000000F5A2C: 31073A86
	s_waitcnt lgkmcnt(0)                                       // 0000000F5A30: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 0000000F5A34: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 0000000F5A3C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F5A40: BF870001
	v_lshl_add_u32 v1, v130, 2, v131                           // 0000000F5A44: D6460001 060D0582
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 0000000F5A4C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:231 offset1:243// 0000000F5A58: D83CF3E7 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F5A60: 8C7E047E
	v_mul_u32_u24_e32 v1, 0x2ab, v0                            // 0000000F5A64: 160200FF 000002AB
	s_clause 0x1                                               // 0000000F5A6C: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 0000000F5A70: F40C0100 F8000000
	s_load_b128 s[16:19], s[0:1], 0x20                         // 0000000F5A78: F4080400 F8000020
	s_lshl_b32 s27, s2, 5                                      // 0000000F5A80: 841B8502
	v_dual_mov_b32 v144, 0 :: v_dual_and_b32 v159, 15, v0      // 0000000F5A84: CA240080 909E008F
	.long 0xd7381001                                           // 0000000F5A8C: D7381001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000000F5A90: 02020282
	.long 0x7f023880                                           // 0000000F5A94: 7F023880
	s_cmp_eq_u64 s[14:15], 0                                   // 0000000F5A98: BF10800E
	v_mov_b32_e32 v145, 0                                      // 0000000F5A9C: 7F220280
	s_cselect_b32 s25, -1, 0                                   // 0000000F5AA0: 981980C1
	.long 0xd7620001                                           // 0000000F5AA4: D7620001
	v_cndmask_b32_e32 v0, v1, v176, vcc_lo                     // 0000000F5AA8: 02016101
	s_and_b32 vcc_lo, exec_lo, s25                             // 0000000F5AAC: 8B6A197E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5AB0: BF870091
	v_add_nc_u32_e32 v158, s27, v1                             // 0000000F5AB4: 4B3C021B
	v_or_b32_e32 v128, v158, v159                              // 0000000F5AB8: 39013F9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F5ABC: BF870001
	v_ashrrev_i32_e32 v129, 31, v128                           // 0000000F5AC0: 3503009F
	s_cbranch_vccnz 10                                         // 0000000F5AC4: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf0>
	v_mad_i64_i32 v[1:2], null, s23, v128, 0                   // 0000000F5AC8: D6FF7C01 02030017
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5AD0: BF870091
	.long 0xd73c0001                                           // 0000000F5AD4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000000F5AD8: 02020282
	.long 0xd7006a90                                           // 0000000F5ADC: D7006A90
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000000F5AE0: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F5AE4: BF870001
	v_add_co_ci_u32_e64 v145, null, s15, v2, vcc_lo            // 0000000F5AE8: D5207C91 01AA040F
	s_load_b64 s[14:15], s[0:1], 0x38                          // 0000000F5AF0: F4040380 F8000038
	v_mov_b32_e32 v161, 0                                      // 0000000F5AF8: 7F420280
	s_xor_b32 s0, s25, -1                                      // 0000000F5AFC: 8D00C119
	s_waitcnt lgkmcnt(0)                                       // 0000000F5B00: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v128                         // 0000000F5B04: 7C89000E
	s_and_b32 s23, s0, vcc_lo                                  // 0000000F5B08: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F5B0C: BF870009
	s_and_saveexec_b32 s0, s23                                 // 0000000F5B10: BE802017
	s_cbranch_execz 9                                          // 0000000F5B14: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13c>
	.long 0xd73c0001                                           // 0000000F5B18: D73C0001
	v_cndmask_b32_e32 v1, 2, v128, vcc_lo                      // 0000000F5B1C: 02030082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5B20: BF870091
	.long 0xd7006a01                                           // 0000000F5B24: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 0000000F5B28: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 0000000F5B2C: D5207C02 01AA0415
	global_load_b32 v161, v[1:2], off                          // 0000000F5B34: DC520000 A17C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000F5B3C: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 0000000F5B40: BF10800C
	s_mov_b64 s[20:21], 0                                      // 0000000F5B44: BE940180
	s_cbranch_scc1 10                                          // 0000000F5B48: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x174>
	s_ashr_i32 s0, s22, 31                                     // 0000000F5B4C: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 0000000F5B50: 96810216
	s_mul_i32 s0, s0, s2                                       // 0000000F5B54: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000F5B58: BF8704A9
	s_add_i32 s1, s1, s0                                       // 0000000F5B5C: 81010001
	s_mul_i32 s0, s22, s2                                      // 0000000F5B60: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000000F5B64: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F5B68: BF870009
	s_add_u32 s20, s12, s0                                     // 0000000F5B6C: 8014000C
	s_addc_u32 s21, s13, s1                                    // 0000000F5B70: 8215010D
	v_lshrrev_b32_e32 v1, 1, v0                                // 0000000F5B74: 32020081
	v_mov_b32_e32 v7, 0                                        // 0000000F5B78: 7E0E0280
	.long 0xd44c0000                                           // 0000000F5B7C: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000000F5B80: 020200FF 00000200
	v_dual_mov_b32 v137, 0 :: v_dual_lshlrev_b32 v0, 3, v130   // 0000000F5B88: CA220080 89010483
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000F5B90: BF8701A3
	v_dual_mov_b32 v10, v7 :: v_dual_and_b32 v133, 0x1f8, v1   // 0000000F5B94: CA240107 0A8402FF 000001F8
	v_mov_b32_e32 v8, v7                                       // 0000000F5BA0: 7E100307
	v_dual_mov_b32 v9, v7 :: v_dual_lshlrev_b32 v132, 1, v0    // 0000000F5BA4: CA220107 09840081
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000F5BAC: BF870003
	v_dual_mov_b32 v138, 0 :: v_dual_lshlrev_b32 v129, 1, v133 // 0000000F5BB0: CA220080 8A810A81
	v_dual_mov_b32 v139, 0 :: v_dual_mov_b32 v140, 0           // 0000000F5BB8: CA100080 8B8C0080
	scratch_store_b128 off, v[7:10], off                       // 0000000F5BC0: DC750000 007C0700
	s_and_saveexec_b32 s1, s0                                  // 0000000F5BC8: BE812000
	s_cbranch_execz 67                                         // 0000000F5BCC: BFA50043 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2dc>
	s_add_i32 s2, s15, -1                                      // 0000000F5BD0: 8102C10F
	s_ashr_i32 s25, s24, 31                                    // 0000000F5BD4: 86199F18
	v_min_i32_e32 v0, s2, v157                                 // 0000000F5BD8: 22013A02
	v_min_i32_e32 v2, s2, v159                                 // 0000000F5BDC: 22053E02
	s_lshl_b64 s[12:13], s[24:25], 9                           // 0000000F5BE0: 848C8918
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F5BE4: BF870112
	v_ashrrev_i32_e32 v3, 31, v0                               // 0000000F5BE8: 3406009F
	v_ashrrev_i32_e32 v5, 31, v2                               // 0000000F5BEC: 340A049F
	.long 0xd72c0004                                           // 0000000F5BF0: D72C0004
	v_cndmask_b32_e32 v1, s11, v0, vcc_lo                      // 0000000F5BF4: 0202000B
	v_mad_u64_u32 v[0:1], null, s10, v0, 0                     // 0000000F5BF8: D6FE7C00 0202000A
	.long 0xd72c0008                                           // 0000000F5C00: D72C0008
	v_cndmask_b32_e32 v1, s11, v2, vcc_lo                      // 0000000F5C04: 0202040B
	.long 0xd72c0006                                           // 0000000F5C08: D72C0006
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 0000000F5C0C: 0202060A
	v_mad_u64_u32 v[2:3], null, s10, v2, 0                     // 0000000F5C10: D6FE7C02 0202040A
	.long 0xd72c0005                                           // 0000000F5C18: D72C0005
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000000F5C1C: 02020A0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F5C20: BF870113
	v_add3_u32 v1, v1, v6, v4                                  // 0000000F5C24: D6550001 04120D01
	v_add3_u32 v3, v3, v5, v8                                  // 0000000F5C2C: D6550003 04220B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F5C34: BF870112
	.long 0xd73c0000                                           // 0000000F5C38: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000000F5C3C: 02020081
	.long 0xd73c0002                                           // 0000000F5C40: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000000F5C44: 02020481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5C48: BF870092
	.long 0xd7006a00                                           // 0000000F5C4C: D7006A00
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 0000000F5C50: 02020006
	v_add_co_ci_u32_e64 v1, null, s7, v1, vcc_lo               // 0000000F5C54: D5207C01 01AA0207
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5C5C: BF870093
	.long 0xd7006a02                                           // 0000000F5C60: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000000F5C64: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 0000000F5C68: D5207C03 01AA0609
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5C70: BF870094
	.long 0xd7006a00                                           // 0000000F5C74: D7006A00
	v_cndmask_b32_e32 v0, v0, v12, vcc_lo                      // 0000000F5C78: 02001900
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 0000000F5C7C: D5207C01 01AA020D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5C84: BF870094
	.long 0xd7006a02                                           // 0000000F5C88: D7006A02
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 0000000F5C8C: 02001902
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 0000000F5C90: D5207C03 01AA060D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5C98: BF870094
	.long 0xd7006a00                                           // 0000000F5C9C: D7006A00
	v_cndmask_b32_e32 v1, v0, v132, vcc_lo                     // 0000000F5CA0: 02030900
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000F5CA4: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F5CAC: BF870094
	.long 0xd7006a04                                           // 0000000F5CB0: D7006A04
	v_cndmask_b32_e32 v1, v2, v129, vcc_lo                     // 0000000F5CB4: 02030302
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000000F5CB8: D5207C05 01AA0680
	global_load_b128 v[0:3], v[0:1], off                       // 0000000F5CC0: DC5E0000 007C0000
	global_load_b128 v[137:140], v[4:5], off                   // 0000000F5CC8: DC5E0000 897C0004
	s_waitcnt vmcnt(1)                                         // 0000000F5CD0: BF8907F7
	scratch_store_b128 off, v[0:3], off                        // 0000000F5CD4: DC750000 007C0000
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F5CDC: 8C7E017E
	.long 0xd7050000                                           // 0000000F5CE0: D7050000
	v_cndmask_b32_e32 v0, v157, v150, vcc_lo                   // 0000000F5CE4: 02012D9D
	s_or_b32 s27, s27, 31                                      // 0000000F5CE8: 8C1B9F1B
	s_add_i32 s1, s14, -1                                      // 0000000F5CEC: 8101C10E
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v5, 0               // 0000000F5CF0: CA100080 06040080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000F5CF8: BF8701C2
	.long 0xd7390000                                           // 0000000F5CFC: D7390000
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 0000000F5D00: 02020088
	s_min_i32 s1, s27, s1                                      // 0000000F5D04: 8901011B
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 0000000F5D08: CA100080 04020080
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 0000000F5D10: CA100080 02000080
	.long 0xd7050008                                           // 0000000F5D18: D7050008
	v_cndmask_b32_e32 v0, v0, v140, vcc_lo                     // 0000000F5D1C: 02011900
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v15, 0              // 0000000F5D20: CA100080 000E0080
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 0000000F5D28: CA100080 0E0C0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000F5D30: BF8701B3
	.long 0xd7040008                                           // 0000000F5D34: D7040008
	v_cndmask_b32_e32 v1, v157, v8, vcc_lo                     // 0000000F5D38: 0202119D
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 0000000F5D3C: CA100080 0C0A0080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 0000000F5D44: CA100080 0A080080
	v_dual_mov_b32 v23, 0 :: v_dual_and_b32 v16, 0xff, v8      // 0000000F5D4C: CA240080 171010FF 000000FF
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v21, 0              // 0000000F5D58: CA100080 08140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v19, 0             // 0000000F5D60: CA100080 16120080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000F5D68: BF870243
	v_mad_u64_u32 v[141:142], null, s24, 12, v[16:17]          // 0000000F5D6C: D6FE7C8D 04411818
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v17, 0             // 0000000F5D74: CA100080 14100080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v31, 0             // 0000000F5D7C: CA100080 121E0080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v29, 0             // 0000000F5D84: CA100080 101C0080
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v32, 8, v141   // 0000000F5D8C: CA220080 19211A88
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v27, 0             // 0000000F5D94: CA100080 1E1A0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v39, 0             // 0000000F5D9C: CA100080 1C260080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000F5DA4: BF8701B3
	v_ashrrev_i32_e32 v33, 31, v32                             // 0000000F5DA8: 3442409F
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v37, 0             // 0000000F5DAC: CA100080 1A240080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v35, 0             // 0000000F5DB4: CA100080 18220080
	.long 0xd73c008e                                           // 0000000F5DBC: D73C008E
	v_cndmask_b32_e32 v1, 1, v32, vcc_lo                       // 0000000F5DC0: 02024081
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v33, 0             // 0000000F5DC4: CA100080 26200080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v47, 0             // 0000000F5DCC: CA100080 242E0080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v45, 0             // 0000000F5DD4: CA100080 222C0080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v43, 0             // 0000000F5DDC: CA100080 202A0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v41, 0             // 0000000F5DE4: CA100080 2E280080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v55, 0             // 0000000F5DEC: CA100080 2C360080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v53, 0             // 0000000F5DF4: CA100080 2A340080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v51, 0             // 0000000F5DFC: CA100080 28320080
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v49, 0             // 0000000F5E04: CA100080 36300080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v63, 0             // 0000000F5E0C: CA100080 343E0080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v61, 0             // 0000000F5E14: CA100080 323C0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v59, 0             // 0000000F5E1C: CA100080 303A0080
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v57, 0             // 0000000F5E24: CA100080 3E380080
	v_dual_mov_b32 v60, 0 :: v_dual_mov_b32 v71, 0             // 0000000F5E2C: CA100080 3C460080
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v69, 0             // 0000000F5E34: CA100080 3A440080
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v67, 0             // 0000000F5E3C: CA100080 38420080
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v65, 0             // 0000000F5E44: CA100080 46400080
	v_dual_mov_b32 v68, 0 :: v_dual_mov_b32 v79, 0             // 0000000F5E4C: CA100080 444E0080
	v_dual_mov_b32 v66, 0 :: v_dual_mov_b32 v77, 0             // 0000000F5E54: CA100080 424C0080
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v75, 0             // 0000000F5E5C: CA100080 404A0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v73, 0             // 0000000F5E64: CA100080 4E480080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v87, 0             // 0000000F5E6C: CA100080 4C560080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v85, 0             // 0000000F5E74: CA100080 4A540080
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v83, 0             // 0000000F5E7C: CA100080 48520080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v81, 0             // 0000000F5E84: CA100080 56500080
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v95, 0             // 0000000F5E8C: CA100080 545E0080
	v_dual_mov_b32 v82, 0 :: v_dual_mov_b32 v93, 0             // 0000000F5E94: CA100080 525C0080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v91, 0             // 0000000F5E9C: CA100080 505A0080
	v_dual_mov_b32 v94, 0 :: v_dual_mov_b32 v89, 0             // 0000000F5EA4: CA100080 5E580080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v103, 0            // 0000000F5EAC: CA100080 5C660080
	v_dual_mov_b32 v90, 0 :: v_dual_mov_b32 v101, 0            // 0000000F5EB4: CA100080 5A640080
	v_dual_mov_b32 v88, 0 :: v_dual_mov_b32 v99, 0             // 0000000F5EBC: CA100080 58620080
	v_dual_mov_b32 v102, 0 :: v_dual_mov_b32 v97, 0            // 0000000F5EC4: CA100080 66600080
	v_dual_mov_b32 v100, 0 :: v_dual_mov_b32 v111, 0           // 0000000F5ECC: CA100080 646E0080
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v109, 0            // 0000000F5ED4: CA100080 626C0080
	v_dual_mov_b32 v96, 0 :: v_dual_mov_b32 v107, 0            // 0000000F5EDC: CA100080 606A0080
	v_dual_mov_b32 v110, 0 :: v_dual_mov_b32 v105, 0           // 0000000F5EE4: CA100080 6E680080
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v119, 0           // 0000000F5EEC: CA100080 6C760080
	v_dual_mov_b32 v106, 0 :: v_dual_mov_b32 v117, 0           // 0000000F5EF4: CA100080 6A740080
	v_dual_mov_b32 v104, 0 :: v_dual_mov_b32 v115, 0           // 0000000F5EFC: CA100080 68720080
	v_dual_mov_b32 v118, 0 :: v_dual_mov_b32 v113, 0           // 0000000F5F04: CA100080 76700080
	v_dual_mov_b32 v116, 0 :: v_dual_mov_b32 v127, 0           // 0000000F5F0C: CA100080 747E0080
	v_dual_mov_b32 v114, 0 :: v_dual_mov_b32 v125, 0           // 0000000F5F14: CA100080 727C0080
	v_dual_mov_b32 v112, 0 :: v_dual_mov_b32 v123, 0           // 0000000F5F1C: CA100080 707A0080
	v_dual_mov_b32 v126, 0 :: v_dual_mov_b32 v121, 0           // 0000000F5F24: CA100080 7E780080
	v_mov_b32_e32 v124, 0                                      // 0000000F5F2C: 7EF80280
	v_mov_b32_e32 v122, 0                                      // 0000000F5F30: 7EF40280
	v_mov_b32_e32 v120, 0                                      // 0000000F5F34: 7EF00280
	v_lshrrev_b32_e32 v162, 4, v130                            // 0000000F5F38: 33450484
	v_lshlrev_b32_e32 v160, 1, v159                            // 0000000F5F3C: 31413E81
	s_add_i32 s1, s26, s1                                      // 0000000F5F40: 8101011A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F5F44: BF870009
	s_cmp_lt_i32 s1, -15                                       // 0000000F5F48: BF04CF01
	s_cbranch_scc1 2259                                        // 0000000F5F4C: BFA208D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x289c>
	v_mad_i64_i32 v[0:1], null, 0x3000, v128, s[4:5]           // 0000000F5F50: D6FF7C00 001300FF 00003000
	s_ashr_i32 s2, s1, 31                                      // 0000000F5F5C: 86029F01
	v_mul_u32_u24_e32 v2, 0x210, v157                          // 0000000F5F60: 16053AFF 00000210
	s_lshr_b32 s2, s2, 28                                      // 0000000F5F68: 85029C02
	v_add3_u32 v171, v158, v130, s26                           // 0000000F5F6C: D65500AB 006B059E
	s_add_i32 s1, s1, s2                                       // 0000000F5F74: 81010201
	v_mad_u32_u24 v180, v159, 48, 0x9600                       // 0000000F5F78: D60B00B4 03FD619F 00009600
	s_ashr_i32 s5, s1, 4                                       // 0000000F5F84: 86058401
	.long 0xd7006a92                                           // 0000000F5F88: D7006A92
	v_cndmask_b32_e32 v1, v0, v142, vcc_lo                     // 0000000F5F8C: 02031D00
	s_cmp_eq_u64 s[20:21], 0                                   // 0000000F5F90: BF108014
	v_add_co_ci_u32_e64 v147, null, v1, v143, vcc_lo           // 0000000F5F94: D5207C93 01AB1F01
	v_mul_u32_u24_e32 v0, 48, v133                             // 0000000F5F9C: 16010AB0
	v_add3_u32 v1, v128, s26, 1                                // 0000000F5FA0: D6550001 02043580
	s_cselect_b32 s12, -1, 0                                   // 0000000F5FA8: 980C80C1
	s_cmp_lg_u64 s[20:21], 0                                   // 0000000F5FAC: BF118014
	v_add3_u32 v163, v2, v132, 0xc600                          // 0000000F5FB0: D65500A3 03FF0902 0000C600
	s_cselect_b32 s13, -1, 0                                   // 0000000F5FBC: 980D80C1
	s_ashr_i32 s25, s24, 31                                    // 0000000F5FC0: 86199F18
	v_add3_u32 v164, v0, v160, 0x9600                          // 0000000F5FC4: D65500A4 03FF4100 00009600
	v_ashrrev_i32_e32 v0, 31, v1                               // 0000000F5FD0: 3400029F
	s_lshl_b64 s[24:25], s[24:25], 9                           // 0000000F5FD4: 84988918
	s_add_i32 s15, s15, -1                                     // 0000000F5FD8: 810FC10F
	s_add_u32 s2, s6, s24                                      // 0000000F5FDC: 80021806
	s_movk_i32 s6, 0x440                                       // 0000000F5FE0: B0060440
	v_lshrrev_b32_e32 v0, 30, v0                               // 0000000F5FE4: 3200009E
	v_mad_u32_u24 v2, v157, s6, 0x3000                         // 0000000F5FE8: D60B0002 03FC0D9D 00003000
	v_mov_b32_e32 v128, 0                                      // 0000000F5FF4: 7F000280
	s_addc_u32 s4, s7, s25                                     // 0000000F5FF8: 82041907
	.long 0xd70002a5                                           // 0000000F5FFC: D70002A5
	v_cndmask_b32_e32 v1, s2, v132, vcc_lo                     // 0000000F6000: 02030802
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000F6004: BF870243
	v_mad_u32_u24 v3, 0x44, v162, v2                           // 0000000F6008: D60B0003 040B44FF 00000044
	v_add_nc_u32_e32 v0, v1, v0                                // 0000000F6014: 4A000101
	v_lshlrev_b32_e32 v1, 2, v130                              // 0000000F6018: 30030482
	v_dual_mov_b32 v125, v128 :: v_dual_add_nc_u32 v4, 0xed00, v131// 0000000F601C: CA200180 7D0506FF 0000ED00
	v_lshl_add_u32 v169, v159, 2, v3                           // 0000000F6028: D64600A9 040D059F
	v_mov_b32_e32 v121, v128                                   // 0000000F6030: 7EF20380
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000F6034: BF870004
	v_dual_mov_b32 v120, 0 :: v_dual_add_nc_u32 v3, v131, v1   // 0000000F6038: CA200080 78020383
	v_ashrrev_i32_e32 v170, 2, v0                              // 0000000F6040: 35540082
	v_dual_mov_b32 v123, v128 :: v_dual_lshlrev_b32 v0, 9, v157// 0000000F6044: CA220180 7B013A89
	v_add_co_ci_u32_e64 v166, null, s4, 0, s2                  // 0000000F604C: D5207CA6 00090004
	s_add_u32 s2, s8, s24                                      // 0000000F6054: 80021808
	s_mov_b32 s1, 0xc600                                       // 0000000F6058: BE8100FF 0000C600
	s_addc_u32 s4, s9, s25                                     // 0000000F6060: 82041909
	.long 0xd70002a7                                           // 0000000F6064: D70002A7
	v_cndmask_b32_e32 v1, s2, v129, vcc_lo                     // 0000000F6068: 02030202
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F606C: BF870001
	v_add_co_ci_u32_e64 v168, null, s4, 0, s2                  // 0000000F6070: D5207CA8 00090004
	v_dual_mov_b32 v127, v128 :: v_dual_add_nc_u32 v172, 0xe700, v3// 0000000F6078: CA200180 7FAC06FF 0000E700
	v_mad_u32_u24 v173, 0x44, v130, v2                         // 0000000F6084: D60B00AD 040B04FF 00000044
	v_lshl_add_u32 v174, v130, 5, v0                           // 0000000F6090: D64600AE 04010B82
	v_dual_mov_b32 v122, v128 :: v_dual_add_nc_u32 v175, 0xf300, v3// 0000000F6098: CA200180 7AAE06FF 0000F300
	v_add_nc_u32_e32 v176, v4, v1                              // 0000000F60A4: 4B600304
	v_lshl_or_b32 v177, v162, 2, v4                            // 0000000F60A8: D65600B1 041105A2
	v_lshl_or_b32 v178, v159, 5, v0                            // 0000000F60B0: D65600B2 04010B9F
	v_mov_b32_e32 v124, v128                                   // 0000000F60B8: 7EF80380
	v_mov_b32_e32 v126, v128                                   // 0000000F60BC: 7EFC0380
	v_dual_mov_b32 v112, 0 :: v_dual_mov_b32 v113, v128        // 0000000F60C0: CA100080 70700180
	v_mov_b32_e32 v114, v128                                   // 0000000F60C8: 7EE40380
	v_dual_mov_b32 v115, v128 :: v_dual_mov_b32 v104, 0        // 0000000F60CC: CA100180 73680080
	v_mov_b32_e32 v116, v128                                   // 0000000F60D4: 7EE80380
	v_dual_mov_b32 v117, v128 :: v_dual_mov_b32 v96, 0         // 0000000F60D8: CA100180 75600080
	v_mov_b32_e32 v118, v128                                   // 0000000F60E0: 7EEC0380
	v_dual_mov_b32 v119, v128 :: v_dual_mov_b32 v88, 0         // 0000000F60E4: CA100180 77580080
	v_dual_mov_b32 v105, v128 :: v_dual_mov_b32 v80, 0         // 0000000F60EC: CA100180 69500080
	v_mov_b32_e32 v106, v128                                   // 0000000F60F4: 7ED40380
	v_dual_mov_b32 v107, v128 :: v_dual_mov_b32 v72, 0         // 0000000F60F8: CA100180 6B480080
	v_mov_b32_e32 v108, v128                                   // 0000000F6100: 7ED80380
	v_dual_mov_b32 v109, v128 :: v_dual_mov_b32 v64, 0         // 0000000F6104: CA100180 6D400080
	v_mov_b32_e32 v110, v128                                   // 0000000F610C: 7EDC0380
	v_dual_mov_b32 v111, v128 :: v_dual_mov_b32 v56, 0         // 0000000F6110: CA100180 6F380080
	v_dual_mov_b32 v97, v128 :: v_dual_mov_b32 v48, 0          // 0000000F6118: CA100180 61300080
	v_mov_b32_e32 v98, v128                                    // 0000000F6120: 7EC40380
	v_dual_mov_b32 v99, v128 :: v_dual_mov_b32 v40, 0          // 0000000F6124: CA100180 63280080
	v_mov_b32_e32 v100, v128                                   // 0000000F612C: 7EC80380
	v_dual_mov_b32 v101, v128 :: v_dual_mov_b32 v32, 0         // 0000000F6130: CA100180 65200080
	v_mov_b32_e32 v102, v128                                   // 0000000F6138: 7ECC0380
	v_dual_mov_b32 v103, v128 :: v_dual_mov_b32 v24, 0         // 0000000F613C: CA100180 67180080
	v_dual_mov_b32 v89, v128 :: v_dual_mov_b32 v16, 0          // 0000000F6144: CA100180 59100080
	v_mov_b32_e32 v90, v128                                    // 0000000F614C: 7EB40380
	v_dual_mov_b32 v91, v128 :: v_dual_mov_b32 v8, 0           // 0000000F6150: CA100180 5B080080
	v_mov_b32_e32 v92, v128                                    // 0000000F6158: 7EB80380
	v_dual_mov_b32 v93, v128 :: v_dual_mov_b32 v0, 0           // 0000000F615C: CA100180 5D000080
	v_mov_b32_e32 v94, v128                                    // 0000000F6164: 7EBC0380
	v_dual_mov_b32 v95, v128 :: v_dual_mov_b32 v148, 0         // 0000000F6168: CA100180 5F940080
	v_mov_b32_e32 v81, v128                                    // 0000000F6170: 7EA20380
	v_mov_b32_e32 v82, v128                                    // 0000000F6174: 7EA40380
	v_mov_b32_e32 v83, v128                                    // 0000000F6178: 7EA60380
	v_mov_b32_e32 v84, v128                                    // 0000000F617C: 7EA80380
	v_mov_b32_e32 v85, v128                                    // 0000000F6180: 7EAA0380
	v_mov_b32_e32 v86, v128                                    // 0000000F6184: 7EAC0380
	v_mov_b32_e32 v87, v128                                    // 0000000F6188: 7EAE0380
	v_mov_b32_e32 v73, v128                                    // 0000000F618C: 7E920380
	v_mov_b32_e32 v74, v128                                    // 0000000F6190: 7E940380
	v_mov_b32_e32 v75, v128                                    // 0000000F6194: 7E960380
	v_mov_b32_e32 v76, v128                                    // 0000000F6198: 7E980380
	v_mov_b32_e32 v77, v128                                    // 0000000F619C: 7E9A0380
	v_mov_b32_e32 v78, v128                                    // 0000000F61A0: 7E9C0380
	v_mov_b32_e32 v79, v128                                    // 0000000F61A4: 7E9E0380
	v_mov_b32_e32 v65, v128                                    // 0000000F61A8: 7E820380
	v_mov_b32_e32 v66, v128                                    // 0000000F61AC: 7E840380
	v_mov_b32_e32 v67, v128                                    // 0000000F61B0: 7E860380
	v_mov_b32_e32 v68, v128                                    // 0000000F61B4: 7E880380
	v_mov_b32_e32 v69, v128                                    // 0000000F61B8: 7E8A0380
	v_mov_b32_e32 v70, v128                                    // 0000000F61BC: 7E8C0380
	v_mov_b32_e32 v71, v128                                    // 0000000F61C0: 7E8E0380
	v_mov_b32_e32 v57, v128                                    // 0000000F61C4: 7E720380
	v_mov_b32_e32 v58, v128                                    // 0000000F61C8: 7E740380
	v_mov_b32_e32 v59, v128                                    // 0000000F61CC: 7E760380
	v_mov_b32_e32 v60, v128                                    // 0000000F61D0: 7E780380
	v_mov_b32_e32 v61, v128                                    // 0000000F61D4: 7E7A0380
	v_mov_b32_e32 v62, v128                                    // 0000000F61D8: 7E7C0380
	v_mov_b32_e32 v63, v128                                    // 0000000F61DC: 7E7E0380
	v_mov_b32_e32 v49, v128                                    // 0000000F61E0: 7E620380
	v_mov_b32_e32 v50, v128                                    // 0000000F61E4: 7E640380
	v_mov_b32_e32 v51, v128                                    // 0000000F61E8: 7E660380
	v_mov_b32_e32 v52, v128                                    // 0000000F61EC: 7E680380
	v_mov_b32_e32 v53, v128                                    // 0000000F61F0: 7E6A0380
	v_mov_b32_e32 v54, v128                                    // 0000000F61F4: 7E6C0380
	v_mov_b32_e32 v55, v128                                    // 0000000F61F8: 7E6E0380
	v_mov_b32_e32 v41, v128                                    // 0000000F61FC: 7E520380
	v_mov_b32_e32 v42, v128                                    // 0000000F6200: 7E540380
	v_mov_b32_e32 v43, v128                                    // 0000000F6204: 7E560380
	v_mov_b32_e32 v44, v128                                    // 0000000F6208: 7E580380
	v_mov_b32_e32 v45, v128                                    // 0000000F620C: 7E5A0380
	v_mov_b32_e32 v46, v128                                    // 0000000F6210: 7E5C0380
	v_mov_b32_e32 v47, v128                                    // 0000000F6214: 7E5E0380
	v_mov_b32_e32 v33, v128                                    // 0000000F6218: 7E420380
	v_mov_b32_e32 v34, v128                                    // 0000000F621C: 7E440380
	v_mov_b32_e32 v35, v128                                    // 0000000F6220: 7E460380
	v_mov_b32_e32 v36, v128                                    // 0000000F6224: 7E480380
	v_mov_b32_e32 v37, v128                                    // 0000000F6228: 7E4A0380
	v_mov_b32_e32 v38, v128                                    // 0000000F622C: 7E4C0380
	v_mov_b32_e32 v39, v128                                    // 0000000F6230: 7E4E0380
	v_mov_b32_e32 v25, v128                                    // 0000000F6234: 7E320380
	v_mov_b32_e32 v26, v128                                    // 0000000F6238: 7E340380
	v_mov_b32_e32 v27, v128                                    // 0000000F623C: 7E360380
	v_mov_b32_e32 v28, v128                                    // 0000000F6240: 7E380380
	v_mov_b32_e32 v29, v128                                    // 0000000F6244: 7E3A0380
	v_mov_b32_e32 v30, v128                                    // 0000000F6248: 7E3C0380
	v_mov_b32_e32 v31, v128                                    // 0000000F624C: 7E3E0380
	v_mov_b32_e32 v17, v128                                    // 0000000F6250: 7E220380
	v_mov_b32_e32 v18, v128                                    // 0000000F6254: 7E240380
	v_mov_b32_e32 v19, v128                                    // 0000000F6258: 7E260380
	v_mov_b32_e32 v20, v128                                    // 0000000F625C: 7E280380
	v_mov_b32_e32 v21, v128                                    // 0000000F6260: 7E2A0380
	v_mov_b32_e32 v22, v128                                    // 0000000F6264: 7E2C0380
	v_mov_b32_e32 v23, v128                                    // 0000000F6268: 7E2E0380
	v_mov_b32_e32 v9, v128                                     // 0000000F626C: 7E120380
	v_mov_b32_e32 v10, v128                                    // 0000000F6270: 7E140380
	v_mov_b32_e32 v11, v128                                    // 0000000F6274: 7E160380
	v_mov_b32_e32 v12, v128                                    // 0000000F6278: 7E180380
	v_mov_b32_e32 v13, v128                                    // 0000000F627C: 7E1A0380
	v_mov_b32_e32 v14, v128                                    // 0000000F6280: 7E1C0380
	v_mov_b32_e32 v15, v128                                    // 0000000F6284: 7E1E0380
	v_mov_b32_e32 v1, v128                                     // 0000000F6288: 7E020380
	v_mov_b32_e32 v2, v128                                     // 0000000F628C: 7E040380
	v_mov_b32_e32 v3, v128                                     // 0000000F6290: 7E060380
	v_mov_b32_e32 v4, v128                                     // 0000000F6294: 7E080380
	v_mov_b32_e32 v5, v128                                     // 0000000F6298: 7E0A0380
	v_mov_b32_e32 v6, v128                                     // 0000000F629C: 7E0C0380
	v_mov_b32_e32 v7, v128                                     // 0000000F62A0: 7E0E0380
	v_mad_u32_u24 v179, 0x210, v159, s1                        // 0000000F62A4: D60B00B3 00073EFF 00000210
	s_mov_b32 s6, 0                                            // 0000000F62B0: BE860080
	s_branch 116                                               // 0000000F62B4: BFA00074 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa88>
	ds_load_b128 v[149:152], v180                              // 0000000F62B8: DBFC0000 950000B4
	ds_load_b128 v[153:156], v180 offset:16                    // 0000000F62C0: DBFC0010 990000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F62C8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[120:127], v[129:136], v[149:156], v[120:127]// 0000000F62CC: CC414078 1DE32B81
	ds_load_b128 v[153:156], v180 offset:784                   // 0000000F62D4: DBFC0310 990000B4
	ds_load_b128 v[149:152], v180 offset:768                   // 0000000F62DC: DBFC0300 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F62E4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[112:119], v[129:136], v[149:156], v[112:119]// 0000000F62E8: CC414070 1DC32B81
	ds_load_b128 v[153:156], v180 offset:1552                  // 0000000F62F0: DBFC0610 990000B4
	ds_load_b128 v[149:152], v180 offset:1536                  // 0000000F62F8: DBFC0600 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F6300: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[104:111], v[129:136], v[149:156], v[104:111]// 0000000F6304: CC414068 1DA32B81
	ds_load_b128 v[153:156], v180 offset:2320                  // 0000000F630C: DBFC0910 990000B4
	ds_load_b128 v[149:152], v180 offset:2304                  // 0000000F6314: DBFC0900 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F631C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[96:103], v[129:136], v[149:156], v[96:103]// 0000000F6320: CC414060 1D832B81
	ds_load_b128 v[153:156], v180 offset:3088                  // 0000000F6328: DBFC0C10 990000B4
	ds_load_b128 v[149:152], v180 offset:3072                  // 0000000F6330: DBFC0C00 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F6338: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[88:95], v[129:136], v[149:156], v[88:95]// 0000000F633C: CC414058 1D632B81
	ds_load_b128 v[153:156], v180 offset:3856                  // 0000000F6344: DBFC0F10 990000B4
	ds_load_b128 v[149:152], v180 offset:3840                  // 0000000F634C: DBFC0F00 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F6354: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[80:87], v[129:136], v[149:156], v[80:87]// 0000000F6358: CC414050 1D432B81
	ds_load_b128 v[153:156], v180 offset:4624                  // 0000000F6360: DBFC1210 990000B4
	ds_load_b128 v[149:152], v180 offset:4608                  // 0000000F6368: DBFC1200 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F6370: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[72:79], v[129:136], v[149:156], v[72:79]// 0000000F6374: CC414048 1D232B81
	ds_load_b128 v[153:156], v180 offset:5392                  // 0000000F637C: DBFC1510 990000B4
	ds_load_b128 v[149:152], v180 offset:5376                  // 0000000F6384: DBFC1500 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F638C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[64:71], v[129:136], v[149:156], v[64:71]// 0000000F6390: CC414040 1D032B81
	ds_load_b128 v[153:156], v180 offset:6160                  // 0000000F6398: DBFC1810 990000B4
	ds_load_b128 v[149:152], v180 offset:6144                  // 0000000F63A0: DBFC1800 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F63A8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[56:63], v[129:136], v[149:156], v[56:63]// 0000000F63AC: CC414038 1CE32B81
	ds_load_b128 v[153:156], v180 offset:6928                  // 0000000F63B4: DBFC1B10 990000B4
	ds_load_b128 v[149:152], v180 offset:6912                  // 0000000F63BC: DBFC1B00 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F63C4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[48:55], v[129:136], v[149:156], v[48:55]// 0000000F63C8: CC414030 1CC32B81
	ds_load_b128 v[153:156], v180 offset:7696                  // 0000000F63D0: DBFC1E10 990000B4
	ds_load_b128 v[149:152], v180 offset:7680                  // 0000000F63D8: DBFC1E00 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F63E0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[40:47], v[129:136], v[149:156], v[40:47]// 0000000F63E4: CC414028 1CA32B81
	ds_load_b128 v[153:156], v180 offset:8464                  // 0000000F63EC: DBFC2110 990000B4
	ds_load_b128 v[149:152], v180 offset:8448                  // 0000000F63F4: DBFC2100 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F63FC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[32:39], v[129:136], v[149:156], v[32:39]// 0000000F6400: CC414020 1C832B81
	ds_load_b128 v[153:156], v180 offset:9232                  // 0000000F6408: DBFC2410 990000B4
	ds_load_b128 v[149:152], v180 offset:9216                  // 0000000F6410: DBFC2400 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F6418: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[24:31], v[129:136], v[149:156], v[24:31]// 0000000F641C: CC414018 1C632B81
	ds_load_b128 v[153:156], v180 offset:10000                 // 0000000F6424: DBFC2710 990000B4
	ds_load_b128 v[149:152], v180 offset:9984                  // 0000000F642C: DBFC2700 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F6434: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[16:23], v[129:136], v[149:156], v[16:23]// 0000000F6438: CC414010 1C432B81
	ds_load_b128 v[153:156], v180 offset:10768                 // 0000000F6440: DBFC2A10 990000B4
	ds_load_b128 v[149:152], v180 offset:10752                 // 0000000F6448: DBFC2A00 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F6450: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[8:15], v[129:136], v[149:156], v[8:15]// 0000000F6454: CC414008 1C232B81
	ds_load_b128 v[153:156], v180 offset:11536                 // 0000000F645C: DBFC2D10 990000B4
	ds_load_b128 v[149:152], v180 offset:11520                 // 0000000F6464: DBFC2D00 950000B4
	s_waitcnt lgkmcnt(0)                                       // 0000000F646C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[0:7], v[129:136], v[149:156], v[0:7]// 0000000F6470: CC414000 1C032B81
	s_add_i32 s1, s6, 1                                        // 0000000F6478: 81018106
	s_cmp_eq_u32 s6, s5                                        // 0000000F647C: BF060506
	s_mov_b32 s6, s1                                           // 0000000F6480: BE860001
	s_cbranch_scc1 1925                                        // 0000000F6484: BFA20785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x289c>
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 0000000F6488: 916A0D7E
	s_mov_b32 s1, s12                                          // 0000000F648C: BE81000C
	s_cbranch_vccz 3                                           // 0000000F6490: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaa0>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000000F6494: 916A017E
	s_cbranch_vccnz 65527                                      // 0000000F6498: BFA4FFF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa78>
	s_branch 15                                                // 0000000F649C: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xadc>
	s_lshr_b32 s1, s6, 3                                       // 0000000F64A0: 85018306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000F64A4: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 0000000F64A8: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v129, s1                                     // 0000000F64B0: 7F020201
	global_load_b32 v129, v129, s[20:21]                       // 0000000F64B4: DC520000 81140081
	s_waitcnt vmcnt(0)                                         // 0000000F64BC: BF8903F7
	v_lshrrev_b32_e32 v129, s6, v129                           // 0000000F64C0: 33030206
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F64C4: BF870091
	v_and_b32_e32 v129, 1, v129                                // 0000000F64C8: 37030281
	.long 0xd44a0001                                           // 0000000F64CC: D44A0001
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000000F64D0: 02030281
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000000F64D4: 916A017E
	s_cbranch_vccnz 65511                                      // 0000000F64D8: BFA4FFE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa78>
	s_lshl_b32 s2, s6, 4                                       // 0000000F64DC: 84028406
	s_waitcnt vmcnt(0)                                         // 0000000F64E0: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 0000000F64E4: BC7C0000
	s_barrier                                                  // 0000000F64E8: BFBD0000
	buffer_gl0_inv                                             // 0000000F64EC: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000000F64F4: BE812000
	s_cbranch_execz 72                                         // 0000000F64F8: BFA50048 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc1c>
	scratch_load_b128 v[129:132], off, off                     // 0000000F64FC: DC5D0000 817C0000
	s_cmp_ge_i32 s6, s5                                        // 0000000F6504: BF030506
	s_waitcnt vmcnt(0)                                         // 0000000F6508: BF8903F7
	ds_store_b128 v163, v[129:132]                             // 0000000F650C: DB7C0000 000081A3
	ds_store_b16 v164, v137                                    // 0000000F6514: D87C0000 000089A4
	ds_store_b16_d16_hi v164, v137 offset:48                   // 0000000F651C: DA840030 000089A4
	ds_store_b16 v164, v138 offset:96                          // 0000000F6524: D87C0060 00008AA4
	ds_store_b16_d16_hi v164, v138 offset:144                  // 0000000F652C: DA840090 00008AA4
	ds_store_b16 v164, v139 offset:192                         // 0000000F6534: D87C00C0 00008BA4
	ds_store_b16_d16_hi v164, v139 offset:240                  // 0000000F653C: DA8400F0 00008BA4
	ds_store_b16 v164, v140 offset:288                         // 0000000F6544: D87C0120 00008CA4
	ds_store_b16_d16_hi v164, v140 offset:336                  // 0000000F654C: DA840150 00008CA4
	s_cbranch_scc1 49                                          // 0000000F6554: BFA20031 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc1c>
	s_add_i32 s4, s2, 16                                       // 0000000F6558: 81049002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F655C: BF870129
	v_or_b32_e32 v129, s4, v157                                // 0000000F6560: 39033A04
	v_or_b32_e32 v130, s4, v159                                // 0000000F6564: 39053E04
	v_min_i32_e32 v129, s15, v129                              // 0000000F6568: 2303020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F656C: BF870112
	v_min_i32_e32 v131, s15, v130                              // 0000000F6570: 2307040F
	v_ashrrev_i32_e32 v132, 31, v129                           // 0000000F6574: 3509029F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F6578: BF870002
	v_ashrrev_i32_e32 v134, 31, v131                           // 0000000F657C: 350D069F
	.long 0xd72c0085                                           // 0000000F6580: D72C0085
	v_cndmask_b32_e32 v1, s11, v129, vcc_lo                    // 0000000F6584: 0203020B
	v_mad_u64_u32 v[129:130], null, s10, v129, 0               // 0000000F6588: D6FE7C81 0203020A
	.long 0xd72c0088                                           // 0000000F6590: D72C0088
	v_cndmask_b32_e32 v1, s11, v131, vcc_lo                    // 0000000F6594: 0203060B
	.long 0xd72c0087                                           // 0000000F6598: D72C0087
	v_cndmask_b32_e32 v1, s10, v132, vcc_lo                    // 0000000F659C: 0203080A
	v_mad_u64_u32 v[131:132], null, s10, v131, 0               // 0000000F65A0: D6FE7C83 0203060A
	.long 0xd72c0086                                           // 0000000F65A8: D72C0086
	v_cndmask_b32_e32 v1, s10, v134, vcc_lo                    // 0000000F65AC: 02030C0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F65B0: BF870113
	v_add3_u32 v130, v130, v135, v133                          // 0000000F65B4: D6550082 06170F82
	v_add3_u32 v132, v132, v134, v136                          // 0000000F65BC: D6550084 06230D84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F65C4: BF870112
	.long 0xd73c0081                                           // 0000000F65C8: D73C0081
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000000F65CC: 02030281
	.long 0xd73c0083                                           // 0000000F65D0: D73C0083
	v_cndmask_b32_e32 v1, 1, v131, vcc_lo                      // 0000000F65D4: 02030681
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F65D8: BF870092
	.long 0xd7006a81                                           // 0000000F65DC: D7006A81
	v_cndmask_b32_e32 v1, v165, v129, vcc_lo                   // 0000000F65E0: 020303A5
	v_add_co_ci_u32_e64 v130, null, v166, v130, vcc_lo         // 0000000F65E4: D5207C82 01AB05A6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F65EC: BF870093
	.long 0xd7006a85                                           // 0000000F65F0: D7006A85
	v_cndmask_b32_e32 v1, v167, v131, vcc_lo                   // 0000000F65F4: 020307A7
	v_add_co_ci_u32_e64 v134, null, v168, v132, vcc_lo         // 0000000F65F8: D5207C86 01AB09A8
	global_load_b128 v[129:132], v[129:130], off               // 0000000F6600: DC5E0000 817C0081
	global_load_b128 v[137:140], v[133:134], off               // 0000000F6608: DC5E0000 897C0085
	s_waitcnt vmcnt(1)                                         // 0000000F6610: BF8907F7
	scratch_store_b128 off, v[129:132], off                    // 0000000F6614: DC750000 007C8100
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F661C: 8C7E017E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F6620: BF890007
	s_waitcnt_vscnt null, 0x0                                  // 0000000F6624: BC7C0000
	s_barrier                                                  // 0000000F6628: BFBD0000
	buffer_gl0_inv                                             // 0000000F662C: E0AC0000 00000000
	s_clause 0x1                                               // 0000000F6634: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:16     // 0000000F6638: DC5E0010 997C0092
	global_load_b128 v[149:152], v[146:147], off               // 0000000F6640: DC5E0000 957C0092
	ds_load_b128 v[181:184], v179                              // 0000000F6648: DBFC0000 B50000B3
	ds_load_b128 v[185:188], v179 offset:16                    // 0000000F6650: DBFC0010 B90000B3
	v_mov_b32_e32 v135, v128                                   // 0000000F6658: 7F0E0380
	v_mov_b32_e32 v129, v128                                   // 0000000F665C: 7F020380
	v_mov_b32_e32 v130, v128                                   // 0000000F6660: 7F040380
	v_mov_b32_e32 v131, v128                                   // 0000000F6664: 7F060380
	v_mov_b32_e32 v132, v128                                   // 0000000F6668: 7F080380
	v_mov_b32_e32 v133, v128                                   // 0000000F666C: 7F0A0380
	v_mov_b32_e32 v134, v128                                   // 0000000F6670: 7F0C0380
	v_mov_b32_e32 v136, v135                                   // 0000000F6674: 7F100387
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000F6678: BF870212
	v_mov_b32_e32 v135, v134                                   // 0000000F667C: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 0000000F6680: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 0000000F6684: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 0000000F6688: 7F080383
	v_mov_b32_e32 v131, v130                                   // 0000000F668C: 7F060382
	v_mov_b32_e32 v130, v129                                   // 0000000F6690: 7F040381
	v_mov_b32_e32 v129, v128                                   // 0000000F6694: 7F020380
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F6698: BF890007
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F669C: BF870001
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F66A0: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F66A8: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:48     // 0000000F66AC: DC5E0030 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:32     // 0000000F66B4: DC5E0020 957C0092
	ds_load_b128 v[181:184], v179 offset:32                    // 0000000F66BC: DBFC0020 B50000B3
	ds_load_b128 v[185:188], v179 offset:48                    // 0000000F66C4: DBFC0030 B90000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F66CC: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F66D0: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F66D8: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:80     // 0000000F66DC: DC5E0050 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:64     // 0000000F66E4: DC5E0040 957C0092
	ds_load_b128 v[185:188], v179 offset:80                    // 0000000F66EC: DBFC0050 B90000B3
	ds_load_b128 v[181:184], v179 offset:64                    // 0000000F66F4: DBFC0040 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F66FC: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F6700: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F6708: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:112    // 0000000F670C: DC5E0070 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:96     // 0000000F6714: DC5E0060 957C0092
	ds_load_b128 v[185:188], v179 offset:112                   // 0000000F671C: DBFC0070 B90000B3
	ds_load_b128 v[181:184], v179 offset:96                    // 0000000F6724: DBFC0060 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F672C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F6730: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F6738: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:144    // 0000000F673C: DC5E0090 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:128    // 0000000F6744: DC5E0080 957C0092
	ds_load_b128 v[185:188], v179 offset:144                   // 0000000F674C: DBFC0090 B90000B3
	ds_load_b128 v[181:184], v179 offset:128                   // 0000000F6754: DBFC0080 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F675C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F6760: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F6768: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:176    // 0000000F676C: DC5E00B0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:160    // 0000000F6774: DC5E00A0 957C0092
	ds_load_b128 v[185:188], v179 offset:176                   // 0000000F677C: DBFC00B0 B90000B3
	ds_load_b128 v[181:184], v179 offset:160                   // 0000000F6784: DBFC00A0 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F678C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F6790: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F6798: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:208    // 0000000F679C: DC5E00D0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:192    // 0000000F67A4: DC5E00C0 957C0092
	ds_load_b128 v[185:188], v179 offset:208                   // 0000000F67AC: DBFC00D0 B90000B3
	ds_load_b128 v[181:184], v179 offset:192                   // 0000000F67B4: DBFC00C0 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F67BC: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F67C0: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F67C8: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:240    // 0000000F67CC: DC5E00F0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:224    // 0000000F67D4: DC5E00E0 957C0092
	ds_load_b128 v[185:188], v179 offset:240                   // 0000000F67DC: DBFC00F0 B90000B3
	ds_load_b128 v[181:184], v179 offset:224                   // 0000000F67E4: DBFC00E0 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F67EC: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F67F0: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F67F8: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:272    // 0000000F67FC: DC5E0110 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:256    // 0000000F6804: DC5E0100 957C0092
	ds_load_b128 v[185:188], v179 offset:272                   // 0000000F680C: DBFC0110 B90000B3
	ds_load_b128 v[181:184], v179 offset:256                   // 0000000F6814: DBFC0100 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F681C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F6820: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F6828: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:304    // 0000000F682C: DC5E0130 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:288    // 0000000F6834: DC5E0120 957C0092
	ds_load_b128 v[185:188], v179 offset:304                   // 0000000F683C: DBFC0130 B90000B3
	ds_load_b128 v[181:184], v179 offset:288                   // 0000000F6844: DBFC0120 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F684C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F6850: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F6858: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:336    // 0000000F685C: DC5E0150 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:320    // 0000000F6864: DC5E0140 957C0092
	ds_load_b128 v[185:188], v179 offset:336                   // 0000000F686C: DBFC0150 B90000B3
	ds_load_b128 v[181:184], v179 offset:320                   // 0000000F6874: DBFC0140 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F687C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F6880: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F6888: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:368    // 0000000F688C: DC5E0170 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:352    // 0000000F6894: DC5E0160 957C0092
	ds_load_b128 v[185:188], v179 offset:368                   // 0000000F689C: DBFC0170 B90000B3
	ds_load_b128 v[181:184], v179 offset:352                   // 0000000F68A4: DBFC0160 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F68AC: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F68B0: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F68B8: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:400    // 0000000F68BC: DC5E0190 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:384    // 0000000F68C4: DC5E0180 957C0092
	ds_load_b128 v[185:188], v179 offset:400                   // 0000000F68CC: DBFC0190 B90000B3
	ds_load_b128 v[181:184], v179 offset:384                   // 0000000F68D4: DBFC0180 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F68DC: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F68E0: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F68E8: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:432    // 0000000F68EC: DC5E01B0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:416    // 0000000F68F4: DC5E01A0 957C0092
	ds_load_b128 v[185:188], v179 offset:432                   // 0000000F68FC: DBFC01B0 B90000B3
	ds_load_b128 v[181:184], v179 offset:416                   // 0000000F6904: DBFC01A0 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F690C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F6910: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F6918: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:464    // 0000000F691C: DC5E01D0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:448    // 0000000F6924: DC5E01C0 957C0092
	ds_load_b128 v[185:188], v179 offset:464                   // 0000000F692C: DBFC01D0 B90000B3
	ds_load_b128 v[181:184], v179 offset:448                   // 0000000F6934: DBFC01C0 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F693C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F6940: CC414081 1E076B95
	s_clause 0x1                                               // 0000000F6948: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:496    // 0000000F694C: DC5E01F0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:480    // 0000000F6954: DC5E01E0 957C0092
	ds_load_b128 v[185:188], v179 offset:496                   // 0000000F695C: DBFC01F0 B90000B3
	ds_load_b128 v[181:184], v179 offset:480                   // 0000000F6964: DBFC01E0 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F696C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000000F6970: CC414081 1E076B95
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F6978: BF870111
	v_dual_mul_f32 v129, 0x3d800000, v129 :: v_dual_mul_f32 v130, 0x3d800000, v130// 0000000F697C: C8C702FF 818304FF 3D800000
	v_mul_f32_e32 v149, 0x3d800000, v132                       // 0000000F6988: 112B08FF 3D800000
	v_mov_b32_e32 v132, 0xffff                                 // 0000000F6990: 7F0802FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000F6998: BF870004
	v_mul_f32_e32 v131, 0x3d800000, v131                       // 0000000F699C: 110706FF 3D800000
	v_dual_mul_f32 v133, 0x3d800000, v133 :: v_dual_mul_f32 v134, 0x3d800000, v134// 0000000F69A4: C8C70AFF 85870CFF 3D800000
	v_dual_mul_f32 v135, 0x3d800000, v135 :: v_dual_mul_f32 v136, 0x3d800000, v136// 0000000F69B0: C8C70EFF 878910FF 3D800000
	ds_store_2addr_b32 v169, v129, v130 offset1:34             // 0000000F69BC: D8382200 008281A9
	ds_store_2addr_b32 v169, v131, v149 offset0:68 offset1:102 // 0000000F69C4: D8386644 009583A9
	ds_store_2addr_b32 v169, v133, v134 offset0:136 offset1:170// 0000000F69CC: D838AA88 008685A9
	ds_store_2addr_b32 v169, v135, v136 offset0:204 offset1:238// 0000000F69D4: D838EECC 008887A9
	s_waitcnt lgkmcnt(0)                                       // 0000000F69DC: BF89FC07
	s_barrier                                                  // 0000000F69E0: BFBD0000
	buffer_gl0_inv                                             // 0000000F69E4: E0AC0000 00000000
	s_and_saveexec_b32 s4, s23                                 // 0000000F69EC: BE842017
	s_cbranch_execz 359                                        // 0000000F69F0: BFA50167 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1590>
	s_lshl_b32 s7, s6, 2                                       // 0000000F69F4: 84078206
	s_mov_b32 s8, exec_lo                                      // 0000000F69F8: BE88007E
	.long 0xd4c1007e                                           // 0000000F69FC: D4C1007E
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 0000000F6A00: 02034394
	s_cbranch_execz 44                                         // 0000000F6A04: BFA5002C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10b8>
	v_ashrrev_i32_e32 v149, 31, v148                           // 0000000F6A08: 352B289F
	s_mov_b32 s9, 0                                            // 0000000F6A0C: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F6A10: BF870091
	.long 0xd73c0081                                           // 0000000F6A14: D73C0081
	v_cndmask_b32_e32 v1, 2, v148, vcc_lo                      // 0000000F6A18: 02032882
	.long 0xd7006a81                                           // 0000000F6A1C: D7006A81
	v_cndmask_b32_e32 v1, v144, v129, vcc_lo                   // 0000000F6A20: 02030390
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F6A24: BF870001
	v_add_co_ci_u32_e64 v130, null, v145, v130, vcc_lo         // 0000000F6A28: D5207C82 01AB0591
	s_branch 11                                                // 0000000F6A30: BFA0000B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1060>
	s_nop 0                                                    // 0000000F6A34: BF800000
	s_nop 0                                                    // 0000000F6A38: BF800000
	s_nop 0                                                    // 0000000F6A3C: BF800000
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000F6A40: 8C7E187E
	v_mov_b32_e32 v132, v148                                   // 0000000F6A44: 7F080394
	v_mov_b32_e32 v148, v131                                   // 0000000F6A48: 7F280383
	s_and_b32 s1, exec_lo, s22                                 // 0000000F6A4C: 8B01167E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000F6A50: BF870499
	s_or_b32 s9, s1, s9                                        // 0000000F6A54: 8C090901
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000F6A58: 917E097E
	s_cbranch_execz 20                                         // 0000000F6A5C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10b0>
	global_load_b32 v131, v[129:130], off                      // 0000000F6A60: DC520000 837C0081
	s_or_b32 s22, s22, exec_lo                                 // 0000000F6A68: 8C167E16
	s_waitcnt vmcnt(0)                                         // 0000000F6A6C: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s7, v131                          // 0000000F6A70: 7C890607
	s_and_saveexec_b32 s24, vcc_lo                             // 0000000F6A74: BE98206A
	s_cbranch_execz 65521                                      // 0000000F6A78: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	v_dual_mov_b32 v148, v161 :: v_dual_add_nc_u32 v131, 1, v148// 0000000F6A7C: CA2001A1 94832881
	.long 0xd7000181                                           // 0000000F6A84: D7000181
	v_cndmask_b32_e32 v0, v129, v132, vcc_lo                   // 0000000F6A88: 02010981
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F6A8C: BF870191
	v_add_co_ci_u32_e64 v130, null, 0, v130, s1                // 0000000F6A90: D5207C82 00070480
	v_cmp_eq_u32_e32 vcc_lo, v161, v131                        // 0000000F6A98: 7C9507A1
	s_and_not1_b32 s1, s22, exec_lo                            // 0000000F6A9C: 91017E16
	s_and_b32 s22, vcc_lo, exec_lo                             // 0000000F6AA0: 8B167E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6AA4: BF870009
	s_or_b32 s22, s1, s22                                      // 0000000F6AA8: 8C161601
	s_branch 65508                                             // 0000000F6AAC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000F6AB0: 8C7E097E
	v_mov_b32_e32 v148, v132                                   // 0000000F6AB4: 7F280384
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F6AB8: 8C7E087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F6ABC: BF870001
	v_dual_mov_b32 v132, 15 :: v_dual_mov_b32 v129, v148       // 0000000F6AC0: CA10008F 84800194
	s_mov_b32 s1, exec_lo                                      // 0000000F6AC8: BE81007E
	.long 0xd4c1007e                                           // 0000000F6ACC: D4C1007E
	v_cndmask_b32_e32 v1, s7, v170, vcc_lo                     // 0000000F6AD0: 02035407
	s_cbranch_execz 62                                         // 0000000F6AD4: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11d0>
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v129, v148        // 0000000F6AD8: CA100080 84800194
	s_mov_b32 s8, exec_lo                                      // 0000000F6AE0: BE88007E
	.long 0xd4c1007e                                           // 0000000F6AE4: D4C1007E
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 0000000F6AE8: 02034394
	s_cbranch_execz 54                                         // 0000000F6AEC: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11c8>
	v_mov_b32_e32 v129, v148                                   // 0000000F6AF0: 7F020394
	s_mov_b32 s22, 0                                           // 0000000F6AF4: BE960080
	s_set_inst_prefetch_distance 0x1                           // 0000000F6AF8: BF840001
	s_branch 10                                                // 0000000F6AFC: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1128>
	s_or_b32 exec_lo, exec_lo, s26                             // 0000000F6B00: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000F6B04: BF870499
	s_and_b32 s26, exec_lo, s25                                // 0000000F6B08: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 0000000F6B0C: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 0000000F6B10: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 0000000F6B14: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6B18: BF870009
	s_or_b32 s9, s9, s26                                       // 0000000F6B1C: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000000F6B20: 917E167E
	s_cbranch_execz 28                                         // 0000000F6B24: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1198>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F6B28: BF8700C1
	v_mov_b32_e32 v130, v129                                   // 0000000F6B2C: 7F040381
	s_or_b32 s24, s24, exec_lo                                 // 0000000F6B30: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 0000000F6B34: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 0000000F6B38: BE9A007E
	v_ashrrev_i32_e32 v131, 31, v130                           // 0000000F6B3C: 3507049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F6B40: BF870091
	.long 0xd73c0083                                           // 0000000F6B44: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 0000000F6B48: 02030482
	.long 0xd7006a83                                           // 0000000F6B4C: D7006A83
	v_cndmask_b32_e32 v1, v144, v131, vcc_lo                   // 0000000F6B50: 02030790
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F6B54: BF870001
	v_add_co_ci_u32_e64 v132, null, v145, v132, vcc_lo         // 0000000F6B58: D5207C84 01AB0991
	global_load_b32 v131, v[131:132], off                      // 0000000F6B60: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 0000000F6B68: BF8903F7
	.long 0xd4c4007e                                           // 0000000F6B6C: D4C4007E
	v_cndmask_b32_e32 v1, s7, v131, vcc_lo                     // 0000000F6B70: 02030607
	s_cbranch_execz 65506                                      // 0000000F6B74: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1100>
	v_add_nc_u32_e32 v129, 1, v130                             // 0000000F6B78: 4B030481
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000F6B7C: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 0000000F6B80: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000F6B84: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 0000000F6B88: 7C9503A1
	s_and_b32 s27, vcc_lo, exec_lo                             // 0000000F6B8C: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 0000000F6B90: 8C191B19
	s_branch 65498                                             // 0000000F6B94: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1100>
	s_set_inst_prefetch_distance 0x2                           // 0000000F6B98: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000F6B9C: 8C7E167E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v129, v161        // 0000000F6BA0: CA100080 848001A1
	s_and_saveexec_b32 s22, s9                                 // 0000000F6BA8: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6BAC: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 0000000F6BB0: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v131                          // 0000000F6BB4: 7C950607
	v_mov_b32_e32 v129, v130                                   // 0000000F6BB8: 7F020382
	v_cndmask_b32_e64 v132, 0, 15, vcc_lo                      // 0000000F6BBC: D5010084 01A91E80
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000F6BC4: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6BC8: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F6BCC: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6BD0: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F6BD4: 8C7E017E
	s_or_b32 s8, s7, 1                                         // 0000000F6BD8: 8C088107
	s_mov_b32 s1, exec_lo                                      // 0000000F6BDC: BE81007E
	.long 0xd4c6007e                                           // 0000000F6BE0: D4C6007E
	v_cndmask_b32_e32 v1, s8, v170, vcc_lo                     // 0000000F6BE4: 02035408
	s_xor_b32 s1, exec_lo, s1                                  // 0000000F6BE8: 8D01017E
	v_or_b32_e32 v132, 0xf0, v132                              // 0000000F6BEC: 390908FF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 0000000F6BF4: BE813001
	s_cbranch_execz 70                                         // 0000000F6BF8: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1314>
	s_mov_b32 s9, exec_lo                                      // 0000000F6BFC: BE89007E
	.long 0xd4c1007e                                           // 0000000F6C00: D4C1007E
	v_cndmask_b32_e32 v1, v129, v161, vcc_lo                   // 0000000F6C04: 02034381
	s_cbranch_execz 64                                         // 0000000F6C08: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x130c>
	s_mov_b32 s24, 0                                           // 0000000F6C0C: BE980080
	s_set_inst_prefetch_distance 0x1                           // 0000000F6C10: BF840001
	s_branch 20                                                // 0000000F6C14: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1268>
	s_nop 0                                                    // 0000000F6C18: BF800000
	s_nop 0                                                    // 0000000F6C1C: BF800000
	s_nop 0                                                    // 0000000F6C20: BF800000
	s_nop 0                                                    // 0000000F6C24: BF800000
	s_nop 0                                                    // 0000000F6C28: BF800000
	s_nop 0                                                    // 0000000F6C2C: BF800000
	s_nop 0                                                    // 0000000F6C30: BF800000
	s_nop 0                                                    // 0000000F6C34: BF800000
	s_nop 0                                                    // 0000000F6C38: BF800000
	s_nop 0                                                    // 0000000F6C3C: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 0000000F6C40: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000F6C44: BF870499
	s_and_b32 s27, exec_lo, s26                                // 0000000F6C48: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 0000000F6C4C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 0000000F6C50: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 0000000F6C54: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6C58: BF870009
	s_or_b32 s22, s22, s27                                     // 0000000F6C5C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 0000000F6C60: 917E187E
	s_cbranch_execz 27                                         // 0000000F6C64: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12d4>
	v_mov_b32_e32 v130, v129                                   // 0000000F6C68: 7F040381
	s_or_b32 s25, s25, exec_lo                                 // 0000000F6C6C: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 0000000F6C70: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 0000000F6C74: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F6C78: BF870091
	v_ashrrev_i32_e32 v131, 31, v130                           // 0000000F6C7C: 3507049F
	.long 0xd73c0085                                           // 0000000F6C80: D73C0085
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 0000000F6C84: 02030482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F6C88: BF870091
	.long 0xd7006a85                                           // 0000000F6C8C: D7006A85
	v_cndmask_b32_e32 v1, v144, v133, vcc_lo                   // 0000000F6C90: 02030B90
	v_add_co_ci_u32_e64 v134, null, v145, v134, vcc_lo         // 0000000F6C94: D5207C86 01AB0D91
	global_load_b32 v131, v[133:134], off                      // 0000000F6C9C: DC520000 837C0085
	s_waitcnt vmcnt(0)                                         // 0000000F6CA4: BF8903F7
	.long 0xd4c6007e                                           // 0000000F6CA8: D4C6007E
	v_cndmask_b32_e32 v1, s7, v131, vcc_lo                     // 0000000F6CAC: 02030607
	s_cbranch_execz 65507                                      // 0000000F6CB0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	v_add_nc_u32_e32 v129, 1, v130                             // 0000000F6CB4: 4B030481
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000F6CB8: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000F6CBC: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000F6CC0: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 0000000F6CC4: 7C9503A1
	s_and_b32 s28, vcc_lo, exec_lo                             // 0000000F6CC8: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 0000000F6CCC: 8C1A1C1A
	s_branch 65499                                             // 0000000F6CD0: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	s_set_inst_prefetch_distance 0x2                           // 0000000F6CD4: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000F6CD8: 8C7E187E
	v_mov_b32_e32 v129, v161                                   // 0000000F6CDC: 7F0203A1
	s_and_saveexec_b32 s24, s22                                // 0000000F6CE0: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6CE4: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 0000000F6CE8: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v131                          // 0000000F6CEC: 7C950608
	v_cndmask_b32_e64 v129, 0, 0xf0, vcc_lo                    // 0000000F6CF0: D5010081 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F6CFC: BF870001
	v_or_b32_e32 v132, v129, v132                              // 0000000F6D00: 39090981
	v_mov_b32_e32 v129, v130                                   // 0000000F6D04: 7F020382
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000F6D08: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6D0C: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000F6D10: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6D14: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F6D18: 8C7E017E
	s_or_b32 s8, s7, 2                                         // 0000000F6D1C: 8C088207
	s_mov_b32 s1, exec_lo                                      // 0000000F6D20: BE81007E
	.long 0xd4c6007e                                           // 0000000F6D24: D4C6007E
	v_cndmask_b32_e32 v1, s8, v170, vcc_lo                     // 0000000F6D28: 02035408
	s_xor_b32 s1, exec_lo, s1                                  // 0000000F6D2C: 8D01017E
	v_or_b32_e32 v132, 0xf00, v132                             // 0000000F6D30: 390908FF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 0000000F6D38: BE813001
	s_cbranch_execz 69                                         // 0000000F6D3C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1454>
	s_mov_b32 s9, exec_lo                                      // 0000000F6D40: BE89007E
	.long 0xd4c1007e                                           // 0000000F6D44: D4C1007E
	v_cndmask_b32_e32 v1, v129, v161, vcc_lo                   // 0000000F6D48: 02034381
	s_cbranch_execz 63                                         // 0000000F6D4C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x144c>
	s_mov_b32 s24, 0                                           // 0000000F6D50: BE980080
	s_set_inst_prefetch_distance 0x1                           // 0000000F6D54: BF840001
	s_branch 19                                                // 0000000F6D58: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13a8>
	s_nop 0                                                    // 0000000F6D5C: BF800000
	s_nop 0                                                    // 0000000F6D60: BF800000
	s_nop 0                                                    // 0000000F6D64: BF800000
	s_nop 0                                                    // 0000000F6D68: BF800000
	s_nop 0                                                    // 0000000F6D6C: BF800000
	s_nop 0                                                    // 0000000F6D70: BF800000
	s_nop 0                                                    // 0000000F6D74: BF800000
	s_nop 0                                                    // 0000000F6D78: BF800000
	s_nop 0                                                    // 0000000F6D7C: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 0000000F6D80: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000F6D84: BF870499
	s_and_b32 s27, exec_lo, s26                                // 0000000F6D88: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 0000000F6D8C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 0000000F6D90: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 0000000F6D94: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6D98: BF870009
	s_or_b32 s22, s22, s27                                     // 0000000F6D9C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 0000000F6DA0: 917E187E
	s_cbranch_execz 27                                         // 0000000F6DA4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1414>
	v_mov_b32_e32 v130, v129                                   // 0000000F6DA8: 7F040381
	s_or_b32 s25, s25, exec_lo                                 // 0000000F6DAC: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 0000000F6DB0: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 0000000F6DB4: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F6DB8: BF870091
	v_ashrrev_i32_e32 v131, 31, v130                           // 0000000F6DBC: 3507049F
	.long 0xd73c0085                                           // 0000000F6DC0: D73C0085
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 0000000F6DC4: 02030482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F6DC8: BF870091
	.long 0xd7006a85                                           // 0000000F6DCC: D7006A85
	v_cndmask_b32_e32 v1, v144, v133, vcc_lo                   // 0000000F6DD0: 02030B90
	v_add_co_ci_u32_e64 v134, null, v145, v134, vcc_lo         // 0000000F6DD4: D5207C86 01AB0D91
	global_load_b32 v131, v[133:134], off                      // 0000000F6DDC: DC520000 837C0085
	s_waitcnt vmcnt(0)                                         // 0000000F6DE4: BF8903F7
	.long 0xd4c4007e                                           // 0000000F6DE8: D4C4007E
	v_cndmask_b32_e32 v1, s8, v131, vcc_lo                     // 0000000F6DEC: 02030608
	s_cbranch_execz 65507                                      // 0000000F6DF0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1380>
	v_add_nc_u32_e32 v129, 1, v130                             // 0000000F6DF4: 4B030481
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000F6DF8: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000F6DFC: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000F6E00: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 0000000F6E04: 7C9503A1
	s_and_b32 s28, vcc_lo, exec_lo                             // 0000000F6E08: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 0000000F6E0C: 8C1A1C1A
	s_branch 65499                                             // 0000000F6E10: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1380>
	s_set_inst_prefetch_distance 0x2                           // 0000000F6E14: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000F6E18: 8C7E187E
	v_mov_b32_e32 v129, v161                                   // 0000000F6E1C: 7F0203A1
	s_and_saveexec_b32 s24, s22                                // 0000000F6E20: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6E24: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 0000000F6E28: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v131                          // 0000000F6E2C: 7C950608
	v_cndmask_b32_e64 v129, 0, 0xf00, vcc_lo                   // 0000000F6E30: D5010081 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F6E3C: BF870001
	v_or_b32_e32 v132, v129, v132                              // 0000000F6E40: 39090981
	v_mov_b32_e32 v129, v130                                   // 0000000F6E44: 7F020382
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000F6E48: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6E4C: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000F6E50: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6E54: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F6E58: 8C7E017E
	s_or_b32 s7, s7, 3                                         // 0000000F6E5C: 8C078307
	s_mov_b32 s1, exec_lo                                      // 0000000F6E60: BE81007E
	.long 0xd4c6007e                                           // 0000000F6E64: D4C6007E
	v_cndmask_b32_e32 v1, s7, v170, vcc_lo                     // 0000000F6E68: 02035407
	s_xor_b32 s1, exec_lo, s1                                  // 0000000F6E6C: 8D01017E
	v_or_b32_e32 v132, 0xf000, v132                            // 0000000F6E70: 390908FF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 0000000F6E78: BE813001
	s_cbranch_execz 66                                         // 0000000F6E7C: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1588>
	s_mov_b32 s8, exec_lo                                      // 0000000F6E80: BE88007E
	.long 0xd4c1007e                                           // 0000000F6E84: D4C1007E
	v_cndmask_b32_e32 v1, v129, v161, vcc_lo                   // 0000000F6E88: 02034381
	s_cbranch_execz 60                                         // 0000000F6E8C: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1580>
	s_mov_b32 s22, 0                                           // 0000000F6E90: BE960080
	s_set_inst_prefetch_distance 0x1                           // 0000000F6E94: BF840001
	s_branch 19                                                // 0000000F6E98: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14e8>
	s_nop 0                                                    // 0000000F6E9C: BF800000
	s_nop 0                                                    // 0000000F6EA0: BF800000
	s_nop 0                                                    // 0000000F6EA4: BF800000
	s_nop 0                                                    // 0000000F6EA8: BF800000
	s_nop 0                                                    // 0000000F6EAC: BF800000
	s_nop 0                                                    // 0000000F6EB0: BF800000
	s_nop 0                                                    // 0000000F6EB4: BF800000
	s_nop 0                                                    // 0000000F6EB8: BF800000
	s_nop 0                                                    // 0000000F6EBC: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 0000000F6EC0: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000F6EC4: BF870499
	s_and_b32 s26, exec_lo, s25                                // 0000000F6EC8: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 0000000F6ECC: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 0000000F6ED0: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 0000000F6ED4: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6ED8: BF870009
	s_or_b32 s9, s9, s26                                       // 0000000F6EDC: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000000F6EE0: 917E167E
	s_cbranch_execz 26                                         // 0000000F6EE4: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1550>
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000F6EE8: 3505029F
	s_or_b32 s24, s24, exec_lo                                 // 0000000F6EEC: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 0000000F6EF0: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 0000000F6EF4: BE9A007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F6EF8: BF870091
	.long 0xd73c0082                                           // 0000000F6EFC: D73C0082
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 0000000F6F00: 02030282
	.long 0xd7006a82                                           // 0000000F6F04: D7006A82
	v_cndmask_b32_e32 v1, v144, v130, vcc_lo                   // 0000000F6F08: 02030590
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F6F0C: BF870001
	v_add_co_ci_u32_e64 v131, null, v145, v131, vcc_lo         // 0000000F6F10: D5207C83 01AB0791
	global_load_b32 v130, v[130:131], off                      // 0000000F6F18: DC520000 827C0082
	s_waitcnt vmcnt(0)                                         // 0000000F6F20: BF8903F7
	.long 0xd4c4007e                                           // 0000000F6F24: D4C4007E
	v_cndmask_b32_e32 v1, s7, v130, vcc_lo                     // 0000000F6F28: 02030407
	s_cbranch_execz 65508                                      // 0000000F6F2C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	v_add_nc_u32_e32 v129, 1, v129                             // 0000000F6F30: 4B030281
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000F6F34: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 0000000F6F38: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000F6F3C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 0000000F6F40: 7C9503A1
	s_and_b32 s27, vcc_lo, exec_lo                             // 0000000F6F44: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 0000000F6F48: 8C191B19
	s_branch 65500                                             // 0000000F6F4C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000F6F50: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000F6F54: 8C7E167E
	s_and_saveexec_b32 s22, s9                                 // 0000000F6F58: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6F5C: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 0000000F6F60: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v130                          // 0000000F6F64: 7C950407
	v_cndmask_b32_e64 v129, 0, 0xf000, vcc_lo                  // 0000000F6F68: D5010081 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F6F74: BF870001
	v_or_b32_e32 v132, v129, v132                              // 0000000F6F78: 39090981
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000F6F7C: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6F80: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F6F84: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6F88: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F6F8C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F6F90: BF870009
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F6F94: 8C7E047E
	s_and_saveexec_b32 s4, s3                                  // 0000000F6F98: BE842003
	s_cbranch_execz 1029                                       // 0000000F6F9C: BFA50405 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x25b4>
	ds_load_b32 v130, v172                                     // 0000000F6FA0: D8D80000 820000AC
	v_and_b32_e32 v129, 1, v132                                // 0000000F6FA8: 37030881
	v_cmp_le_i32_e32 vcc_lo, s2, v171                          // 0000000F6FAC: 7C875602
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F6FB0: BF870002
	.long 0xd44a0001                                           // 0000000F6FB4: D44A0001
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000000F6FB8: 02030281
	s_and_b32 s35, vcc_lo, s1                                  // 0000000F6FBC: 8B23016A
	s_waitcnt lgkmcnt(0)                                       // 0000000F6FC0: BF89FC07
	v_mov_b32_e32 v129, v130                                   // 0000000F6FC4: 7F020382
	s_and_saveexec_b32 s1, s35                                 // 0000000F6FC8: BE812023
	s_cbranch_execz 7                                          // 0000000F6FCC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15ec>
	ds_load_b32 v129, v173                                     // 0000000F6FD0: D8D80000 810000AD
	v_max_f32_e32 v131, v130, v130                             // 0000000F6FD8: 21070582
	s_waitcnt lgkmcnt(0)                                       // 0000000F6FDC: BF89FC07
	v_max_f32_e32 v129, v129, v129                             // 0000000F6FE0: 21030381
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F6FE4: BF870001
	v_max_f32_e32 v129, v131, v129                             // 0000000F6FE8: 21030383
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F6FEC: 8C7E017E
	v_and_b32_e32 v131, 2, v132                                // 0000000F6FF0: 37070882
	v_cmp_lt_i32_e32 vcc_lo, s2, v171                          // 0000000F6FF4: 7C835602
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000F6FF8: BF8704A2
	.long 0xd44d0001                                           // 0000000F6FFC: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F7000: 02030680
	s_and_b32 s34, vcc_lo, s1                                  // 0000000F7004: 8B22016A
	s_and_saveexec_b32 s1, s34                                 // 0000000F7008: BE812022
	s_cbranch_execz 7                                          // 0000000F700C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x162c>
	ds_load_b32 v131, v173 offset:4                            // 0000000F7010: D8D80004 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F7018: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F701C: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F7020: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F7024: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F7028: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F702C: 8C7E017E
	v_and_b32_e32 v131, 4, v132                                // 0000000F7030: 37070884
	s_or_b32 s1, s2, 2                                         // 0000000F7034: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F7038: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 0000000F703C: 7C875601
	.long 0xd44d0001                                           // 0000000F7040: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F7044: 02030680
	s_and_b32 s33, vcc_lo, s1                                  // 0000000F7048: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F704C: BF870009
	s_and_saveexec_b32 s1, s33                                 // 0000000F7050: BE812021
	s_cbranch_execz 7                                          // 0000000F7054: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1674>
	ds_load_b32 v131, v173 offset:8                            // 0000000F7058: D8D80008 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F7060: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F7064: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F7068: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F706C: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F7070: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F7074: 8C7E017E
	v_and_b32_e32 v131, 8, v132                                // 0000000F7078: 37070888
	s_or_b32 s1, s2, 3                                         // 0000000F707C: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F7080: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 0000000F7084: 7C875601
	.long 0xd44d0001                                           // 0000000F7088: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F708C: 02030680
	s_and_b32 s31, vcc_lo, s1                                  // 0000000F7090: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F7094: BF870009
	s_and_saveexec_b32 s1, s31                                 // 0000000F7098: BE81201F
	s_cbranch_execz 7                                          // 0000000F709C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16bc>
	ds_load_b32 v131, v173 offset:12                           // 0000000F70A0: D8D8000C 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F70A8: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F70AC: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F70B0: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F70B4: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F70B8: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F70BC: 8C7E017E
	v_and_b32_e32 v131, 16, v132                               // 0000000F70C0: 37070890
	s_or_b32 s1, s2, 4                                         // 0000000F70C4: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F70C8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 0000000F70CC: 7C875601
	.long 0xd44d0001                                           // 0000000F70D0: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F70D4: 02030680
	s_and_b32 s30, vcc_lo, s1                                  // 0000000F70D8: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F70DC: BF870009
	s_and_saveexec_b32 s1, s30                                 // 0000000F70E0: BE81201E
	s_cbranch_execz 7                                          // 0000000F70E4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1704>
	ds_load_b32 v131, v173 offset:16                           // 0000000F70E8: D8D80010 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F70F0: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F70F4: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F70F8: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F70FC: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F7100: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F7104: 8C7E017E
	v_and_b32_e32 v131, 32, v132                               // 0000000F7108: 370708A0
	s_or_b32 s1, s2, 5                                         // 0000000F710C: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F7110: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 0000000F7114: 7C875601
	.long 0xd44d0001                                           // 0000000F7118: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F711C: 02030680
	s_and_b32 s29, vcc_lo, s1                                  // 0000000F7120: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F7124: BF870009
	s_and_saveexec_b32 s1, s29                                 // 0000000F7128: BE81201D
	s_cbranch_execz 7                                          // 0000000F712C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x174c>
	ds_load_b32 v131, v173 offset:20                           // 0000000F7130: D8D80014 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F7138: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F713C: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F7140: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F7144: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F7148: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F714C: 8C7E017E
	v_and_b32_e32 v131, 64, v132                               // 0000000F7150: 370708C0
	s_or_b32 s1, s2, 6                                         // 0000000F7154: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F7158: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 0000000F715C: 7C875601
	.long 0xd44d0001                                           // 0000000F7160: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F7164: 02030680
	s_and_b32 s28, vcc_lo, s1                                  // 0000000F7168: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F716C: BF870009
	s_and_saveexec_b32 s1, s28                                 // 0000000F7170: BE81201C
	s_cbranch_execz 7                                          // 0000000F7174: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1794>
	ds_load_b32 v131, v173 offset:24                           // 0000000F7178: D8D80018 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F7180: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F7184: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F7188: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F718C: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F7190: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F7194: 8C7E017E
	v_and_b32_e32 v131, 0x80, v132                             // 0000000F7198: 370708FF 00000080
	s_or_b32 s1, s2, 7                                         // 0000000F71A0: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F71A4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 0000000F71A8: 7C875601
	.long 0xd44d0001                                           // 0000000F71AC: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F71B0: 02030680
	s_and_b32 s27, vcc_lo, s1                                  // 0000000F71B4: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F71B8: BF870009
	s_and_saveexec_b32 s1, s27                                 // 0000000F71BC: BE81201B
	s_cbranch_execz 7                                          // 0000000F71C0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17e0>
	ds_load_b32 v131, v173 offset:28                           // 0000000F71C4: D8D8001C 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F71CC: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F71D0: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F71D4: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F71D8: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F71DC: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F71E0: 8C7E017E
	v_and_b32_e32 v131, 0x100, v132                            // 0000000F71E4: 370708FF 00000100
	s_or_b32 s1, s2, 8                                         // 0000000F71EC: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F71F0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 0000000F71F4: 7C875601
	.long 0xd44d0001                                           // 0000000F71F8: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F71FC: 02030680
	s_and_b32 s26, vcc_lo, s1                                  // 0000000F7200: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F7204: BF870009
	s_and_saveexec_b32 s1, s26                                 // 0000000F7208: BE81201A
	s_cbranch_execz 7                                          // 0000000F720C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x182c>
	ds_load_b32 v131, v173 offset:32                           // 0000000F7210: D8D80020 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F7218: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F721C: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F7220: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F7224: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F7228: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F722C: 8C7E017E
	v_and_b32_e32 v131, 0x200, v132                            // 0000000F7230: 370708FF 00000200
	s_or_b32 s1, s2, 9                                         // 0000000F7238: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F723C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 0000000F7240: 7C875601
	.long 0xd44d0001                                           // 0000000F7244: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F7248: 02030680
	s_and_b32 s25, vcc_lo, s1                                  // 0000000F724C: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F7250: BF870009
	s_and_saveexec_b32 s1, s25                                 // 0000000F7254: BE812019
	s_cbranch_execz 7                                          // 0000000F7258: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1878>
	ds_load_b32 v131, v173 offset:36                           // 0000000F725C: D8D80024 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F7264: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F7268: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F726C: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F7270: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F7274: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F7278: 8C7E017E
	v_and_b32_e32 v131, 0x400, v132                            // 0000000F727C: 370708FF 00000400
	s_or_b32 s1, s2, 10                                        // 0000000F7284: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F7288: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 0000000F728C: 7C875601
	.long 0xd44d0001                                           // 0000000F7290: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F7294: 02030680
	s_and_b32 s24, vcc_lo, s1                                  // 0000000F7298: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F729C: BF870009
	s_and_saveexec_b32 s1, s24                                 // 0000000F72A0: BE812018
	s_cbranch_execz 7                                          // 0000000F72A4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18c4>
	ds_load_b32 v131, v173 offset:40                           // 0000000F72A8: D8D80028 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F72B0: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F72B4: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F72B8: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F72BC: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F72C0: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F72C4: 8C7E017E
	v_and_b32_e32 v131, 0x800, v132                            // 0000000F72C8: 370708FF 00000800
	s_or_b32 s1, s2, 11                                        // 0000000F72D0: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F72D4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 0000000F72D8: 7C875601
	.long 0xd44d0001                                           // 0000000F72DC: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F72E0: 02030680
	s_and_b32 s22, vcc_lo, s1                                  // 0000000F72E4: 8B16016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F72E8: BF870009
	s_and_saveexec_b32 s1, s22                                 // 0000000F72EC: BE812016
	s_cbranch_execz 7                                          // 0000000F72F0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1910>
	ds_load_b32 v131, v173 offset:44                           // 0000000F72F4: D8D8002C 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F72FC: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F7300: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F7304: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F7308: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F730C: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F7310: 8C7E017E
	v_and_b32_e32 v131, 0x1000, v132                           // 0000000F7314: 370708FF 00001000
	s_or_b32 s1, s2, 12                                        // 0000000F731C: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F7320: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 0000000F7324: 7C875601
	.long 0xd44d0001                                           // 0000000F7328: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F732C: 02030680
	s_and_b32 s9, vcc_lo, s1                                   // 0000000F7330: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F7334: BF870009
	s_and_saveexec_b32 s1, s9                                  // 0000000F7338: BE812009
	s_cbranch_execz 7                                          // 0000000F733C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x195c>
	ds_load_b32 v131, v173 offset:48                           // 0000000F7340: D8D80030 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F7348: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F734C: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F7350: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F7354: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F7358: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F735C: 8C7E017E
	v_and_b32_e32 v131, 0x2000, v132                           // 0000000F7360: 370708FF 00002000
	s_or_b32 s1, s2, 13                                        // 0000000F7368: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F736C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 0000000F7370: 7C875601
	.long 0xd44d0001                                           // 0000000F7374: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F7378: 02030680
	s_and_b32 s8, vcc_lo, s1                                   // 0000000F737C: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F7380: BF870009
	s_and_saveexec_b32 s1, s8                                  // 0000000F7384: BE812008
	s_cbranch_execz 7                                          // 0000000F7388: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19a8>
	ds_load_b32 v131, v173 offset:52                           // 0000000F738C: D8D80034 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F7394: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F7398: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F739C: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F73A0: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F73A4: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F73A8: 8C7E017E
	v_and_b32_e32 v131, 0x4000, v132                           // 0000000F73AC: 370708FF 00004000
	s_or_b32 s1, s2, 14                                        // 0000000F73B4: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F73B8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 0000000F73BC: 7C875601
	.long 0xd44d0001                                           // 0000000F73C0: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F73C4: 02030680
	s_and_b32 s7, vcc_lo, s1                                   // 0000000F73C8: 8B07016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F73CC: BF870009
	s_and_saveexec_b32 s1, s7                                  // 0000000F73D0: BE812007
	s_cbranch_execz 7                                          // 0000000F73D4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19f4>
	ds_load_b32 v131, v173 offset:56                           // 0000000F73D8: D8D80038 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F73E0: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F73E4: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F73E8: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F73EC: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F73F0: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F73F4: 8C7E017E
	v_and_b32_e32 v131, 0x8000, v132                           // 0000000F73F8: 370708FF 00008000
	s_or_b32 s2, s2, 15                                        // 0000000F7400: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F7404: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v171                          // 0000000F7408: 7C875602
	.long 0xd44d0001                                           // 0000000F740C: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 0000000F7410: 02030680
	s_and_b32 s1, vcc_lo, s1                                   // 0000000F7414: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F7418: BF870009
	s_and_saveexec_b32 s2, s1                                  // 0000000F741C: BE822001
	s_cbranch_execz 7                                          // 0000000F7420: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a40>
	ds_load_b32 v131, v173 offset:60                           // 0000000F7424: D8D8003C 830000AD
	v_max_f32_e32 v129, v129, v129                             // 0000000F742C: 21030381
	s_waitcnt lgkmcnt(0)                                       // 0000000F7430: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 0000000F7434: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F7438: BF870001
	v_max_f32_e32 v129, v129, v131                             // 0000000F743C: 21030781
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F7440: 8C7E027E
	v_dual_mov_b32 v131, 0 :: v_dual_mov_b32 v132, 0           // 0000000F7444: CA100080 83840080
	s_and_saveexec_b32 s2, s35                                 // 0000000F744C: BE822023
	s_cbranch_execz 30                                         // 0000000F7450: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1acc>
	ds_load_b32 v132, v173                                     // 0000000F7454: D8D80000 840000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F745C: BF89FC07
	v_sub_f32_e32 v132, v132, v129                             // 0000000F7460: 09090384
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7464: BF870091
	v_mul_f32_e32 v133, 0x3fb8aa3b, v132                       // 0000000F7468: 110B08FF 3FB8AA3B
	v_fma_f32 v134, 0x3fb8aa3b, v132, -v133                    // 0000000F7470: D6130086 861708FF 3FB8AA3B
	v_rndne_f32_e32 v135, v133                                 // 0000000F747C: 7F0E4785
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F7480: BF870221
	v_sub_f32_e32 v133, v133, v135                             // 0000000F7484: 090B0F85
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v132                 // 0000000F7488: 7C3708FF C2CE8ED0
	v_fmac_f32_e32 v134, 0x32a5705f, v132                      // 0000000F7490: 570D08FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7498: BF870121
	v_add_f32_e32 v133, v133, v134                             // 0000000F749C: 070B0D85
	v_cvt_i32_f32_e32 v134, v135                               // 0000000F74A0: 7F0C1187
	v_exp_f32_e32 v133, v133                                   // 0000000F74A4: 7F0A4B85
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F74A8: BF870095
	.long 0xd71c0085                                           // 0000000F74AC: D71C0085
	v_cndmask_b32_e32 v1, v133, v134, vcc_lo                   // 0000000F74B0: 02030D85
	v_cndmask_b32_e32 v133, 0, v133, vcc_lo                    // 0000000F74B4: 030B0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v132                 // 0000000F74B8: 7C3D08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F74C0: BF870002
	v_cndmask_b32_e32 v132, 0x7f800000, v133, vcc_lo           // 0000000F74C4: 03090AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F74CC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F74D0: BF870091
	v_bfe_u32 v133, v132, 16, 1                                // 0000000F74D4: D6100085 02052184
	v_add3_u32 v133, v132, v133, 0x7fff                        // 0000000F74DC: D6550085 03FF0B84 00007FFF
	ds_store_b16_d16_hi v174, v133                             // 0000000F74E8: DA840000 000085AE
	s_and_saveexec_b32 s2, s34                                 // 0000000F74F0: BE822022
	s_cbranch_execz 30                                         // 0000000F74F4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b70>
	ds_load_b32 v131, v173 offset:4                            // 0000000F74F8: D8D80004 830000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F7500: BF89FC07
	v_sub_f32_e32 v131, v131, v129                             // 0000000F7504: 09070383
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7508: BF870121
	v_mul_f32_e32 v133, 0x3fb8aa3b, v131                       // 0000000F750C: 110B06FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 0000000F7514: 7C3706FF C2CE8ED0
	v_fma_f32 v134, 0x3fb8aa3b, v131, -v133                    // 0000000F751C: D6130086 861706FF 3FB8AA3B
	v_rndne_f32_e32 v135, v133                                 // 0000000F7528: 7F0E4785
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F752C: BF870112
	v_fmac_f32_e32 v134, 0x32a5705f, v131                      // 0000000F7530: 570D06FF 32A5705F
	v_sub_f32_e32 v133, v133, v135                             // 0000000F7538: 090B0F85
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F753C: BF870121
	v_add_f32_e32 v133, v133, v134                             // 0000000F7540: 070B0D85
	v_cvt_i32_f32_e32 v134, v135                               // 0000000F7544: 7F0C1187
	v_exp_f32_e32 v133, v133                                   // 0000000F7548: 7F0A4B85
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F754C: BF870095
	.long 0xd71c0085                                           // 0000000F7550: D71C0085
	v_cndmask_b32_e32 v1, v133, v134, vcc_lo                   // 0000000F7554: 02030D85
	v_cndmask_b32_e32 v133, 0, v133, vcc_lo                    // 0000000F7558: 030B0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 0000000F755C: 7C3D06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F7564: BF870002
	v_cndmask_b32_e32 v131, 0x7f800000, v133, vcc_lo           // 0000000F7568: 03070AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F7570: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7574: BF870121
	v_bfe_u32 v133, v131, 16, 1                                // 0000000F7578: D6100085 02052183
	v_mov_b32_e32 v134, 0                                      // 0000000F7580: 7F0C0280
	v_add3_u32 v135, v131, v133, 0x7fff                        // 0000000F7584: D6550087 03FF0B83 00007FFF
	v_mov_b32_e32 v133, 0                                      // 0000000F7590: 7F0A0280
	ds_store_b16_d16_hi v174, v135 offset:2                    // 0000000F7594: DA840002 000087AE
	s_and_saveexec_b32 s2, s33                                 // 0000000F759C: BE822021
	s_cbranch_execz 29                                         // 0000000F75A0: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c18>
	ds_load_b32 v134, v173 offset:8                            // 0000000F75A4: D8D80008 860000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F75AC: BF89FC07
	v_sub_f32_e32 v134, v134, v129                             // 0000000F75B0: 090D0386
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F75B4: BF870091
	v_mul_f32_e32 v135, 0x3fb8aa3b, v134                       // 0000000F75B8: 110F0CFF 3FB8AA3B
	v_fma_f32 v136, 0x3fb8aa3b, v134, -v135                    // 0000000F75C0: D6130088 861F0CFF 3FB8AA3B
	v_rndne_f32_e32 v149, v135                                 // 0000000F75CC: 7F2A4787
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F75D0: BF870091
	v_dual_fmac_f32 v136, 0x32a5705f, v134 :: v_dual_sub_f32 v135, v135, v149// 0000000F75D4: C80B0CFF 88872B87 32A5705F
	v_add_f32_e32 v135, v135, v136                             // 0000000F75E0: 070F1187
	v_cvt_i32_f32_e32 v136, v149                               // 0000000F75E4: 7F101195
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 0000000F75E8: 7C370CFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F75F0: BF870293
	v_exp_f32_e32 v135, v135                                   // 0000000F75F4: 7F0E4B87
	.long 0xd71c0087                                           // 0000000F75F8: D71C0087
	v_cndmask_b32_e32 v1, v135, v136, vcc_lo                   // 0000000F75FC: 02031187
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7600: BF870121
	v_cndmask_b32_e32 v135, 0, v135, vcc_lo                    // 0000000F7604: 030F0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 0000000F7608: 7C3D0CFF 42B17218
	v_cndmask_b32_e32 v134, 0x7f800000, v135, vcc_lo           // 0000000F7610: 030D0EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F7618: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F761C: BF870091
	v_bfe_u32 v135, v134, 16, 1                                // 0000000F7620: D6100087 02052186
	v_add3_u32 v135, v134, v135, 0x7fff                        // 0000000F7628: D6550087 03FF0F86 00007FFF
	ds_store_b16_d16_hi v174, v135 offset:4                    // 0000000F7634: DA840004 000087AE
	s_and_saveexec_b32 s2, s31                                 // 0000000F763C: BE82201F
	s_cbranch_execz 30                                         // 0000000F7640: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1cbc>
	ds_load_b32 v133, v173 offset:12                           // 0000000F7644: D8D8000C 850000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F764C: BF89FC07
	v_sub_f32_e32 v133, v133, v129                             // 0000000F7650: 090B0385
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7654: BF870121
	v_mul_f32_e32 v135, 0x3fb8aa3b, v133                       // 0000000F7658: 110F0AFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 0000000F7660: 7C370AFF C2CE8ED0
	v_fma_f32 v136, 0x3fb8aa3b, v133, -v135                    // 0000000F7668: D6130088 861F0AFF 3FB8AA3B
	v_rndne_f32_e32 v149, v135                                 // 0000000F7674: 7F2A4787
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F7678: BF870112
	v_fmac_f32_e32 v136, 0x32a5705f, v133                      // 0000000F767C: 57110AFF 32A5705F
	v_sub_f32_e32 v135, v135, v149                             // 0000000F7684: 090F2B87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7688: BF870121
	v_add_f32_e32 v135, v135, v136                             // 0000000F768C: 070F1187
	v_cvt_i32_f32_e32 v136, v149                               // 0000000F7690: 7F101195
	v_exp_f32_e32 v135, v135                                   // 0000000F7694: 7F0E4B87
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7698: BF870095
	.long 0xd71c0087                                           // 0000000F769C: D71C0087
	v_cndmask_b32_e32 v1, v135, v136, vcc_lo                   // 0000000F76A0: 02031187
	v_cndmask_b32_e32 v135, 0, v135, vcc_lo                    // 0000000F76A4: 030F0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 0000000F76A8: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F76B0: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v135, vcc_lo           // 0000000F76B4: 030B0EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F76BC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F76C0: BF870121
	v_bfe_u32 v135, v133, 16, 1                                // 0000000F76C4: D6100087 02052185
	v_mov_b32_e32 v136, 0                                      // 0000000F76CC: 7F100280
	v_add3_u32 v149, v133, v135, 0x7fff                        // 0000000F76D0: D6550095 03FF0F85 00007FFF
	v_mov_b32_e32 v135, 0                                      // 0000000F76DC: 7F0E0280
	ds_store_b16_d16_hi v174, v149 offset:6                    // 0000000F76E0: DA840006 000095AE
	s_and_saveexec_b32 s2, s30                                 // 0000000F76E8: BE82201E
	s_cbranch_execz 30                                         // 0000000F76EC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d68>
	ds_load_b32 v136, v173 offset:16                           // 0000000F76F0: D8D80010 880000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F76F8: BF89FC07
	v_sub_f32_e32 v136, v136, v129                             // 0000000F76FC: 09110388
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7700: BF870091
	v_mul_f32_e32 v149, 0x3fb8aa3b, v136                       // 0000000F7704: 112B10FF 3FB8AA3B
	v_fma_f32 v150, 0x3fb8aa3b, v136, -v149                    // 0000000F770C: D6130096 865710FF 3FB8AA3B
	v_rndne_f32_e32 v151, v149                                 // 0000000F7718: 7F2E4795
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F771C: BF870221
	v_sub_f32_e32 v149, v149, v151                             // 0000000F7720: 092B2F95
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 0000000F7724: 7C3710FF C2CE8ED0
	v_fmac_f32_e32 v150, 0x32a5705f, v136                      // 0000000F772C: 572D10FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7734: BF870121
	v_add_f32_e32 v149, v149, v150                             // 0000000F7738: 072B2D95
	v_cvt_i32_f32_e32 v150, v151                               // 0000000F773C: 7F2C1197
	v_exp_f32_e32 v149, v149                                   // 0000000F7740: 7F2A4B95
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7744: BF870095
	.long 0xd71c0095                                           // 0000000F7748: D71C0095
	v_cndmask_b32_e32 v1, v149, v150, vcc_lo                   // 0000000F774C: 02032D95
	v_cndmask_b32_e32 v149, 0, v149, vcc_lo                    // 0000000F7750: 032B2A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 0000000F7754: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F775C: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v149, vcc_lo           // 0000000F7760: 03112AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F7768: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F776C: BF870091
	v_bfe_u32 v149, v136, 16, 1                                // 0000000F7770: D6100095 02052188
	v_add3_u32 v149, v136, v149, 0x7fff                        // 0000000F7778: D6550095 03FF2B88 00007FFF
	ds_store_b16_d16_hi v174, v149 offset:8                    // 0000000F7784: DA840008 000095AE
	s_and_saveexec_b32 s2, s29                                 // 0000000F778C: BE82201D
	s_cbranch_execz 30                                         // 0000000F7790: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e0c>
	ds_load_b32 v135, v173 offset:20                           // 0000000F7794: D8D80014 870000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F779C: BF89FC07
	v_sub_f32_e32 v135, v135, v129                             // 0000000F77A0: 090F0387
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F77A4: BF870121
	v_mul_f32_e32 v149, 0x3fb8aa3b, v135                       // 0000000F77A8: 112B0EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 0000000F77B0: 7C370EFF C2CE8ED0
	v_fma_f32 v150, 0x3fb8aa3b, v135, -v149                    // 0000000F77B8: D6130096 86570EFF 3FB8AA3B
	v_rndne_f32_e32 v151, v149                                 // 0000000F77C4: 7F2E4795
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F77C8: BF870112
	v_fmac_f32_e32 v150, 0x32a5705f, v135                      // 0000000F77CC: 572D0EFF 32A5705F
	v_sub_f32_e32 v149, v149, v151                             // 0000000F77D4: 092B2F95
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F77D8: BF870121
	v_add_f32_e32 v149, v149, v150                             // 0000000F77DC: 072B2D95
	v_cvt_i32_f32_e32 v150, v151                               // 0000000F77E0: 7F2C1197
	v_exp_f32_e32 v149, v149                                   // 0000000F77E4: 7F2A4B95
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F77E8: BF870095
	.long 0xd71c0095                                           // 0000000F77EC: D71C0095
	v_cndmask_b32_e32 v1, v149, v150, vcc_lo                   // 0000000F77F0: 02032D95
	v_cndmask_b32_e32 v149, 0, v149, vcc_lo                    // 0000000F77F4: 032B2A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 0000000F77F8: 7C3D0EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F7800: BF870002
	v_cndmask_b32_e32 v135, 0x7f800000, v149, vcc_lo           // 0000000F7804: 030F2AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F780C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7810: BF870121
	v_bfe_u32 v149, v135, 16, 1                                // 0000000F7814: D6100095 02052187
	v_mov_b32_e32 v150, 0                                      // 0000000F781C: 7F2C0280
	v_add3_u32 v151, v135, v149, 0x7fff                        // 0000000F7820: D6550097 03FF2B87 00007FFF
	v_mov_b32_e32 v149, 0                                      // 0000000F782C: 7F2A0280
	ds_store_b16_d16_hi v174, v151 offset:10                   // 0000000F7830: DA84000A 000097AE
	s_and_saveexec_b32 s2, s28                                 // 0000000F7838: BE82201C
	s_cbranch_execz 29                                         // 0000000F783C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1eb4>
	ds_load_b32 v150, v173 offset:24                           // 0000000F7840: D8D80018 960000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F7848: BF89FC07
	v_sub_f32_e32 v150, v150, v129                             // 0000000F784C: 092D0396
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7850: BF870091
	v_mul_f32_e32 v151, 0x3fb8aa3b, v150                       // 0000000F7854: 112F2CFF 3FB8AA3B
	v_fma_f32 v152, 0x3fb8aa3b, v150, -v151                    // 0000000F785C: D6130098 865F2CFF 3FB8AA3B
	v_rndne_f32_e32 v153, v151                                 // 0000000F7868: 7F324797
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F786C: BF870091
	v_dual_fmac_f32 v152, 0x32a5705f, v150 :: v_dual_sub_f32 v151, v151, v153// 0000000F7870: C80B2CFF 98973397 32A5705F
	v_add_f32_e32 v151, v151, v152                             // 0000000F787C: 072F3197
	v_cvt_i32_f32_e32 v152, v153                               // 0000000F7880: 7F301199
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 0000000F7884: 7C372CFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F788C: BF870293
	v_exp_f32_e32 v151, v151                                   // 0000000F7890: 7F2E4B97
	.long 0xd71c0097                                           // 0000000F7894: D71C0097
	v_cndmask_b32_e32 v1, v151, v152, vcc_lo                   // 0000000F7898: 02033197
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F789C: BF870121
	v_cndmask_b32_e32 v151, 0, v151, vcc_lo                    // 0000000F78A0: 032F2E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 0000000F78A4: 7C3D2CFF 42B17218
	v_cndmask_b32_e32 v150, 0x7f800000, v151, vcc_lo           // 0000000F78AC: 032D2EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F78B4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F78B8: BF870091
	v_bfe_u32 v151, v150, 16, 1                                // 0000000F78BC: D6100097 02052196
	v_add3_u32 v151, v150, v151, 0x7fff                        // 0000000F78C4: D6550097 03FF2F96 00007FFF
	ds_store_b16_d16_hi v174, v151 offset:12                   // 0000000F78D0: DA84000C 000097AE
	s_and_saveexec_b32 s2, s27                                 // 0000000F78D8: BE82201B
	s_cbranch_execz 30                                         // 0000000F78DC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f58>
	ds_load_b32 v149, v173 offset:28                           // 0000000F78E0: D8D8001C 950000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F78E8: BF89FC07
	v_sub_f32_e32 v149, v149, v129                             // 0000000F78EC: 092B0395
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F78F0: BF870121
	v_mul_f32_e32 v151, 0x3fb8aa3b, v149                       // 0000000F78F4: 112F2AFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 0000000F78FC: 7C372AFF C2CE8ED0
	v_fma_f32 v152, 0x3fb8aa3b, v149, -v151                    // 0000000F7904: D6130098 865F2AFF 3FB8AA3B
	v_rndne_f32_e32 v153, v151                                 // 0000000F7910: 7F324797
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F7914: BF870112
	v_fmac_f32_e32 v152, 0x32a5705f, v149                      // 0000000F7918: 57312AFF 32A5705F
	v_sub_f32_e32 v151, v151, v153                             // 0000000F7920: 092F3397
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7924: BF870121
	v_add_f32_e32 v151, v151, v152                             // 0000000F7928: 072F3197
	v_cvt_i32_f32_e32 v152, v153                               // 0000000F792C: 7F301199
	v_exp_f32_e32 v151, v151                                   // 0000000F7930: 7F2E4B97
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7934: BF870095
	.long 0xd71c0097                                           // 0000000F7938: D71C0097
	v_cndmask_b32_e32 v1, v151, v152, vcc_lo                   // 0000000F793C: 02033197
	v_cndmask_b32_e32 v151, 0, v151, vcc_lo                    // 0000000F7940: 032F2E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 0000000F7944: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F794C: BF870002
	v_cndmask_b32_e32 v149, 0x7f800000, v151, vcc_lo           // 0000000F7950: 032B2EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F7958: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F795C: BF870121
	v_bfe_u32 v151, v149, 16, 1                                // 0000000F7960: D6100097 02052195
	v_mov_b32_e32 v152, 0                                      // 0000000F7968: 7F300280
	v_add3_u32 v153, v149, v151, 0x7fff                        // 0000000F796C: D6550099 03FF2F95 00007FFF
	v_mov_b32_e32 v151, 0                                      // 0000000F7978: 7F2E0280
	ds_store_b16_d16_hi v174, v153 offset:14                   // 0000000F797C: DA84000E 000099AE
	s_and_saveexec_b32 s2, s26                                 // 0000000F7984: BE82201A
	s_cbranch_execz 30                                         // 0000000F7988: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2004>
	ds_load_b32 v152, v173 offset:32                           // 0000000F798C: D8D80020 980000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F7994: BF89FC07
	v_sub_f32_e32 v152, v152, v129                             // 0000000F7998: 09310398
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F799C: BF870091
	v_mul_f32_e32 v153, 0x3fb8aa3b, v152                       // 0000000F79A0: 113330FF 3FB8AA3B
	v_fma_f32 v154, 0x3fb8aa3b, v152, -v153                    // 0000000F79A8: D613009A 866730FF 3FB8AA3B
	v_rndne_f32_e32 v155, v153                                 // 0000000F79B4: 7F364799
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F79B8: BF870221
	v_sub_f32_e32 v153, v153, v155                             // 0000000F79BC: 09333799
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 0000000F79C0: 7C3730FF C2CE8ED0
	v_fmac_f32_e32 v154, 0x32a5705f, v152                      // 0000000F79C8: 573530FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F79D0: BF870121
	v_add_f32_e32 v153, v153, v154                             // 0000000F79D4: 07333599
	v_cvt_i32_f32_e32 v154, v155                               // 0000000F79D8: 7F34119B
	v_exp_f32_e32 v153, v153                                   // 0000000F79DC: 7F324B99
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F79E0: BF870095
	.long 0xd71c0099                                           // 0000000F79E4: D71C0099
	v_cndmask_b32_e32 v1, v153, v154, vcc_lo                   // 0000000F79E8: 02033599
	v_cndmask_b32_e32 v153, 0, v153, vcc_lo                    // 0000000F79EC: 03333280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 0000000F79F0: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F79F8: BF870002
	v_cndmask_b32_e32 v152, 0x7f800000, v153, vcc_lo           // 0000000F79FC: 033132FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F7A04: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7A08: BF870091
	v_bfe_u32 v153, v152, 16, 1                                // 0000000F7A0C: D6100099 02052198
	v_add3_u32 v153, v152, v153, 0x7fff                        // 0000000F7A14: D6550099 03FF3398 00007FFF
	ds_store_b16_d16_hi v174, v153 offset:16                   // 0000000F7A20: DA840010 000099AE
	s_and_saveexec_b32 s2, s25                                 // 0000000F7A28: BE822019
	s_cbranch_execz 30                                         // 0000000F7A2C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x20a8>
	ds_load_b32 v151, v173 offset:36                           // 0000000F7A30: D8D80024 970000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F7A38: BF89FC07
	v_sub_f32_e32 v151, v151, v129                             // 0000000F7A3C: 092F0397
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7A40: BF870121
	v_mul_f32_e32 v153, 0x3fb8aa3b, v151                       // 0000000F7A44: 11332EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 0000000F7A4C: 7C372EFF C2CE8ED0
	v_fma_f32 v154, 0x3fb8aa3b, v151, -v153                    // 0000000F7A54: D613009A 86672EFF 3FB8AA3B
	v_rndne_f32_e32 v155, v153                                 // 0000000F7A60: 7F364799
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F7A64: BF870112
	v_fmac_f32_e32 v154, 0x32a5705f, v151                      // 0000000F7A68: 57352EFF 32A5705F
	v_sub_f32_e32 v153, v153, v155                             // 0000000F7A70: 09333799
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7A74: BF870121
	v_add_f32_e32 v153, v153, v154                             // 0000000F7A78: 07333599
	v_cvt_i32_f32_e32 v154, v155                               // 0000000F7A7C: 7F34119B
	v_exp_f32_e32 v153, v153                                   // 0000000F7A80: 7F324B99
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7A84: BF870095
	.long 0xd71c0099                                           // 0000000F7A88: D71C0099
	v_cndmask_b32_e32 v1, v153, v154, vcc_lo                   // 0000000F7A8C: 02033599
	v_cndmask_b32_e32 v153, 0, v153, vcc_lo                    // 0000000F7A90: 03333280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 0000000F7A94: 7C3D2EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F7A9C: BF870002
	v_cndmask_b32_e32 v151, 0x7f800000, v153, vcc_lo           // 0000000F7AA0: 032F32FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F7AA8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7AAC: BF870121
	v_bfe_u32 v153, v151, 16, 1                                // 0000000F7AB0: D6100099 02052197
	v_mov_b32_e32 v154, 0                                      // 0000000F7AB8: 7F340280
	v_add3_u32 v155, v151, v153, 0x7fff                        // 0000000F7ABC: D655009B 03FF3397 00007FFF
	v_mov_b32_e32 v153, 0                                      // 0000000F7AC8: 7F320280
	ds_store_b16_d16_hi v174, v155 offset:18                   // 0000000F7ACC: DA840012 00009BAE
	s_and_saveexec_b32 s2, s24                                 // 0000000F7AD4: BE822018
	s_cbranch_execz 29                                         // 0000000F7AD8: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2150>
	ds_load_b32 v154, v173 offset:40                           // 0000000F7ADC: D8D80028 9A0000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F7AE4: BF89FC07
	v_sub_f32_e32 v154, v154, v129                             // 0000000F7AE8: 0935039A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7AEC: BF870091
	v_mul_f32_e32 v155, 0x3fb8aa3b, v154                       // 0000000F7AF0: 113734FF 3FB8AA3B
	v_fma_f32 v156, 0x3fb8aa3b, v154, -v155                    // 0000000F7AF8: D613009C 866F34FF 3FB8AA3B
	v_rndne_f32_e32 v181, v155                                 // 0000000F7B04: 7F6A479B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7B08: BF870091
	v_dual_fmac_f32 v156, 0x32a5705f, v154 :: v_dual_sub_f32 v155, v155, v181// 0000000F7B0C: C80B34FF 9C9B6B9B 32A5705F
	v_add_f32_e32 v155, v155, v156                             // 0000000F7B18: 0737399B
	v_cvt_i32_f32_e32 v156, v181                               // 0000000F7B1C: 7F3811B5
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v154                 // 0000000F7B20: 7C3734FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F7B28: BF870293
	v_exp_f32_e32 v155, v155                                   // 0000000F7B2C: 7F364B9B
	.long 0xd71c009b                                           // 0000000F7B30: D71C009B
	v_cndmask_b32_e32 v1, v155, v156, vcc_lo                   // 0000000F7B34: 0203399B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7B38: BF870121
	v_cndmask_b32_e32 v155, 0, v155, vcc_lo                    // 0000000F7B3C: 03373680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v154                 // 0000000F7B40: 7C3D34FF 42B17218
	v_cndmask_b32_e32 v154, 0x7f800000, v155, vcc_lo           // 0000000F7B48: 033536FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F7B50: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7B54: BF870091
	v_bfe_u32 v155, v154, 16, 1                                // 0000000F7B58: D610009B 0205219A
	v_add3_u32 v155, v154, v155, 0x7fff                        // 0000000F7B60: D655009B 03FF379A 00007FFF
	ds_store_b16_d16_hi v174, v155 offset:20                   // 0000000F7B6C: DA840014 00009BAE
	s_and_saveexec_b32 s2, s22                                 // 0000000F7B74: BE822016
	s_cbranch_execz 30                                         // 0000000F7B78: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21f4>
	ds_load_b32 v153, v173 offset:44                           // 0000000F7B7C: D8D8002C 990000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F7B84: BF89FC07
	v_sub_f32_e32 v153, v153, v129                             // 0000000F7B88: 09330399
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7B8C: BF870121
	v_mul_f32_e32 v155, 0x3fb8aa3b, v153                       // 0000000F7B90: 113732FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 0000000F7B98: 7C3732FF C2CE8ED0
	v_fma_f32 v156, 0x3fb8aa3b, v153, -v155                    // 0000000F7BA0: D613009C 866F32FF 3FB8AA3B
	v_rndne_f32_e32 v181, v155                                 // 0000000F7BAC: 7F6A479B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F7BB0: BF870112
	v_fmac_f32_e32 v156, 0x32a5705f, v153                      // 0000000F7BB4: 573932FF 32A5705F
	v_sub_f32_e32 v155, v155, v181                             // 0000000F7BBC: 09376B9B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7BC0: BF870121
	v_add_f32_e32 v155, v155, v156                             // 0000000F7BC4: 0737399B
	v_cvt_i32_f32_e32 v156, v181                               // 0000000F7BC8: 7F3811B5
	v_exp_f32_e32 v155, v155                                   // 0000000F7BCC: 7F364B9B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7BD0: BF870095
	.long 0xd71c009b                                           // 0000000F7BD4: D71C009B
	v_cndmask_b32_e32 v1, v155, v156, vcc_lo                   // 0000000F7BD8: 0203399B
	v_cndmask_b32_e32 v155, 0, v155, vcc_lo                    // 0000000F7BDC: 03373680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 0000000F7BE0: 7C3D32FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F7BE8: BF870002
	v_cndmask_b32_e32 v153, 0x7f800000, v155, vcc_lo           // 0000000F7BEC: 033336FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F7BF4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7BF8: BF870121
	v_bfe_u32 v155, v153, 16, 1                                // 0000000F7BFC: D610009B 02052199
	v_mov_b32_e32 v156, 0                                      // 0000000F7C04: 7F380280
	v_add3_u32 v181, v153, v155, 0x7fff                        // 0000000F7C08: D65500B5 03FF3799 00007FFF
	v_mov_b32_e32 v155, 0                                      // 0000000F7C14: 7F360280
	ds_store_b16_d16_hi v174, v181 offset:22                   // 0000000F7C18: DA840016 0000B5AE
	s_and_saveexec_b32 s2, s9                                  // 0000000F7C20: BE822009
	s_cbranch_execz 30                                         // 0000000F7C24: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x22a0>
	ds_load_b32 v156, v173 offset:48                           // 0000000F7C28: D8D80030 9C0000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F7C30: BF89FC07
	v_sub_f32_e32 v156, v156, v129                             // 0000000F7C34: 0939039C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7C38: BF870091
	v_mul_f32_e32 v181, 0x3fb8aa3b, v156                       // 0000000F7C3C: 116B38FF 3FB8AA3B
	v_fma_f32 v182, 0x3fb8aa3b, v156, -v181                    // 0000000F7C44: D61300B6 86D738FF 3FB8AA3B
	v_rndne_f32_e32 v183, v181                                 // 0000000F7C50: 7F6E47B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F7C54: BF870221
	v_sub_f32_e32 v181, v181, v183                             // 0000000F7C58: 096B6FB5
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v156                 // 0000000F7C5C: 7C3738FF C2CE8ED0
	v_fmac_f32_e32 v182, 0x32a5705f, v156                      // 0000000F7C64: 576D38FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7C6C: BF870121
	v_add_f32_e32 v181, v181, v182                             // 0000000F7C70: 076B6DB5
	v_cvt_i32_f32_e32 v182, v183                               // 0000000F7C74: 7F6C11B7
	v_exp_f32_e32 v181, v181                                   // 0000000F7C78: 7F6A4BB5
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7C7C: BF870095
	.long 0xd71c00b5                                           // 0000000F7C80: D71C00B5
	v_cndmask_b32_e32 v1, v181, v182, vcc_lo                   // 0000000F7C84: 02036DB5
	v_cndmask_b32_e32 v181, 0, v181, vcc_lo                    // 0000000F7C88: 036B6A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v156                 // 0000000F7C8C: 7C3D38FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F7C94: BF870002
	v_cndmask_b32_e32 v156, 0x7f800000, v181, vcc_lo           // 0000000F7C98: 03396AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F7CA0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7CA4: BF870091
	v_bfe_u32 v181, v156, 16, 1                                // 0000000F7CA8: D61000B5 0205219C
	v_add3_u32 v181, v156, v181, 0x7fff                        // 0000000F7CB0: D65500B5 03FF6B9C 00007FFF
	ds_store_b16_d16_hi v174, v181 offset:24                   // 0000000F7CBC: DA840018 0000B5AE
	s_and_saveexec_b32 s2, s8                                  // 0000000F7CC4: BE822008
	s_cbranch_execz 30                                         // 0000000F7CC8: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2344>
	ds_load_b32 v155, v173 offset:52                           // 0000000F7CCC: D8D80034 9B0000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F7CD4: BF89FC07
	v_sub_f32_e32 v155, v155, v129                             // 0000000F7CD8: 0937039B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7CDC: BF870121
	v_mul_f32_e32 v181, 0x3fb8aa3b, v155                       // 0000000F7CE0: 116B36FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v155                 // 0000000F7CE8: 7C3736FF C2CE8ED0
	v_fma_f32 v182, 0x3fb8aa3b, v155, -v181                    // 0000000F7CF0: D61300B6 86D736FF 3FB8AA3B
	v_rndne_f32_e32 v183, v181                                 // 0000000F7CFC: 7F6E47B5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F7D00: BF870112
	v_fmac_f32_e32 v182, 0x32a5705f, v155                      // 0000000F7D04: 576D36FF 32A5705F
	v_sub_f32_e32 v181, v181, v183                             // 0000000F7D0C: 096B6FB5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7D10: BF870121
	v_add_f32_e32 v181, v181, v182                             // 0000000F7D14: 076B6DB5
	v_cvt_i32_f32_e32 v182, v183                               // 0000000F7D18: 7F6C11B7
	v_exp_f32_e32 v181, v181                                   // 0000000F7D1C: 7F6A4BB5
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7D20: BF870095
	.long 0xd71c00b5                                           // 0000000F7D24: D71C00B5
	v_cndmask_b32_e32 v1, v181, v182, vcc_lo                   // 0000000F7D28: 02036DB5
	v_cndmask_b32_e32 v181, 0, v181, vcc_lo                    // 0000000F7D2C: 036B6A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v155                 // 0000000F7D30: 7C3D36FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F7D38: BF870002
	v_cndmask_b32_e32 v155, 0x7f800000, v181, vcc_lo           // 0000000F7D3C: 03376AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F7D44: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7D48: BF870121
	v_bfe_u32 v181, v155, 16, 1                                // 0000000F7D4C: D61000B5 0205219B
	v_mov_b32_e32 v182, 0                                      // 0000000F7D54: 7F6C0280
	v_add3_u32 v183, v155, v181, 0x7fff                        // 0000000F7D58: D65500B7 03FF6B9B 00007FFF
	v_mov_b32_e32 v181, 0                                      // 0000000F7D64: 7F6A0280
	ds_store_b16_d16_hi v174, v183 offset:26                   // 0000000F7D68: DA84001A 0000B7AE
	s_and_saveexec_b32 s2, s7                                  // 0000000F7D70: BE822007
	s_cbranch_execz 29                                         // 0000000F7D74: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x23ec>
	ds_load_b32 v182, v173 offset:56                           // 0000000F7D78: D8D80038 B60000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F7D80: BF89FC07
	v_sub_f32_e32 v182, v182, v129                             // 0000000F7D84: 096D03B6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7D88: BF870091
	v_mul_f32_e32 v183, 0x3fb8aa3b, v182                       // 0000000F7D8C: 116F6CFF 3FB8AA3B
	v_fma_f32 v184, 0x3fb8aa3b, v182, -v183                    // 0000000F7D94: D61300B8 86DF6CFF 3FB8AA3B
	v_rndne_f32_e32 v185, v183                                 // 0000000F7DA0: 7F7247B7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7DA4: BF870091
	v_dual_fmac_f32 v184, 0x32a5705f, v182 :: v_dual_sub_f32 v183, v183, v185// 0000000F7DA8: C80B6CFF B8B773B7 32A5705F
	v_add_f32_e32 v183, v183, v184                             // 0000000F7DB4: 076F71B7
	v_cvt_i32_f32_e32 v184, v185                               // 0000000F7DB8: 7F7011B9
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v182                 // 0000000F7DBC: 7C376CFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F7DC4: BF870293
	v_exp_f32_e32 v183, v183                                   // 0000000F7DC8: 7F6E4BB7
	.long 0xd71c00b7                                           // 0000000F7DCC: D71C00B7
	v_cndmask_b32_e32 v1, v183, v184, vcc_lo                   // 0000000F7DD0: 020371B7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7DD4: BF870121
	v_cndmask_b32_e32 v183, 0, v183, vcc_lo                    // 0000000F7DD8: 036F6E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v182                 // 0000000F7DDC: 7C3D6CFF 42B17218
	v_cndmask_b32_e32 v182, 0x7f800000, v183, vcc_lo           // 0000000F7DE4: 036D6EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F7DEC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7DF0: BF870091
	v_bfe_u32 v183, v182, 16, 1                                // 0000000F7DF4: D61000B7 020521B6
	v_add3_u32 v183, v182, v183, 0x7fff                        // 0000000F7DFC: D65500B7 03FF6FB6 00007FFF
	ds_store_b16_d16_hi v174, v183 offset:28                   // 0000000F7E08: DA84001C 0000B7AE
	s_and_saveexec_b32 s2, s1                                  // 0000000F7E10: BE822001
	s_cbranch_execz 30                                         // 0000000F7E14: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2490>
	ds_load_b32 v181, v173 offset:60                           // 0000000F7E18: D8D8003C B50000AD
	s_waitcnt lgkmcnt(0)                                       // 0000000F7E20: BF89FC07
	v_sub_f32_e32 v181, v181, v129                             // 0000000F7E24: 096B03B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7E28: BF870121
	v_mul_f32_e32 v183, 0x3fb8aa3b, v181                       // 0000000F7E2C: 116F6AFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v181                 // 0000000F7E34: 7C376AFF C2CE8ED0
	v_fma_f32 v184, 0x3fb8aa3b, v181, -v183                    // 0000000F7E3C: D61300B8 86DF6AFF 3FB8AA3B
	v_rndne_f32_e32 v185, v183                                 // 0000000F7E48: 7F7247B7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F7E4C: BF870112
	v_fmac_f32_e32 v184, 0x32a5705f, v181                      // 0000000F7E50: 57716AFF 32A5705F
	v_sub_f32_e32 v183, v183, v185                             // 0000000F7E58: 096F73B7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7E5C: BF870121
	v_add_f32_e32 v183, v183, v184                             // 0000000F7E60: 076F71B7
	v_cvt_i32_f32_e32 v184, v185                               // 0000000F7E64: 7F7011B9
	v_exp_f32_e32 v183, v183                                   // 0000000F7E68: 7F6E4BB7
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7E6C: BF870095
	.long 0xd71c00b7                                           // 0000000F7E70: D71C00B7
	v_cndmask_b32_e32 v1, v183, v184, vcc_lo                   // 0000000F7E74: 020371B7
	v_cndmask_b32_e32 v183, 0, v183, vcc_lo                    // 0000000F7E78: 036F6E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v181                 // 0000000F7E7C: 7C3D6AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F7E84: BF870002
	v_cndmask_b32_e32 v181, 0x7f800000, v183, vcc_lo           // 0000000F7E88: 036B6EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F7E90: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F7E94: BF8700A1
	v_bfe_u32 v183, v181, 16, 1                                // 0000000F7E98: D61000B7 020521B5
	s_mov_b32 s1, exec_lo                                      // 0000000F7EA0: BE81007E
	v_add3_u32 v184, v181, v183, 0x7fff                        // 0000000F7EA4: D65500B8 03FF6FB5 00007FFF
	v_mov_b32_e32 v183, 0                                      // 0000000F7EB0: 7F6E0280
	ds_store_b16_d16_hi v174, v184 offset:30                   // 0000000F7EB4: DA84001E 0000B8AE
	v_cmpx_lt_f32_e32 0xefa18f08, v130                         // 0000000F7EBC: 7D2304FF EFA18F08
	s_cbranch_execz 26                                         // 0000000F7EC4: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2530>
	v_sub_f32_e32 v130, v130, v129                             // 0000000F7EC8: 09050382
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7ECC: BF870091
	v_mul_f32_e32 v183, 0x3fb8aa3b, v130                       // 0000000F7ED0: 116F04FF 3FB8AA3B
	v_fma_f32 v184, 0x3fb8aa3b, v130, -v183                    // 0000000F7ED8: D61300B8 86DF04FF 3FB8AA3B
	v_rndne_f32_e32 v185, v183                                 // 0000000F7EE4: 7F7247B7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7EE8: BF870091
	v_dual_fmac_f32 v184, 0x32a5705f, v130 :: v_dual_sub_f32 v183, v183, v185// 0000000F7EEC: C80B04FF B8B773B7 32A5705F
	v_add_f32_e32 v183, v183, v184                             // 0000000F7EF8: 076F71B7
	v_cvt_i32_f32_e32 v184, v185                               // 0000000F7EFC: 7F7011B9
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 0000000F7F00: 7C3704FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F7F08: BF870293
	v_exp_f32_e32 v183, v183                                   // 0000000F7F0C: 7F6E4BB7
	.long 0xd71c00b7                                           // 0000000F7F10: D71C00B7
	v_cndmask_b32_e32 v1, v183, v184, vcc_lo                   // 0000000F7F14: 020371B7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F7F18: BF870121
	v_cndmask_b32_e32 v183, 0, v183, vcc_lo                    // 0000000F7F1C: 036F6E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 0000000F7F20: 7C3D04FF 42B17218
	v_cndmask_b32_e32 v183, 0x7f800000, v183, vcc_lo           // 0000000F7F28: 036F6EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F7F30: 8C7E017E
	v_add_f32_e32 v130, v132, v131                             // 0000000F7F34: 07050784
	ds_load_b32 v131, v175                                     // 0000000F7F38: D8D80000 830000AF
	v_add_f32_e32 v130, v130, v134                             // 0000000F7F40: 07050D82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7F44: BF870091
	v_add_f32_e32 v130, v130, v133                             // 0000000F7F48: 07050B82
	v_add_f32_e32 v130, v130, v136                             // 0000000F7F4C: 07051182
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7F50: BF870091
	v_add_f32_e32 v130, v130, v135                             // 0000000F7F54: 07050F82
	v_add_f32_e32 v130, v130, v150                             // 0000000F7F58: 07052D82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7F5C: BF870091
	v_add_f32_e32 v130, v130, v149                             // 0000000F7F60: 07052B82
	v_add_f32_e32 v130, v130, v152                             // 0000000F7F64: 07053182
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7F68: BF870091
	v_add_f32_e32 v130, v130, v151                             // 0000000F7F6C: 07052F82
	v_add_f32_e32 v130, v130, v154                             // 0000000F7F70: 07053582
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7F74: BF870091
	v_add_f32_e32 v130, v130, v153                             // 0000000F7F78: 07053382
	v_add_f32_e32 v130, v130, v156                             // 0000000F7F7C: 07053982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F7F80: BF870091
	v_add_f32_e32 v130, v130, v155                             // 0000000F7F84: 07053782
	v_add_f32_e32 v130, v130, v182                             // 0000000F7F88: 07056D82
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F7F8C: BF8700A1
	v_add_f32_e32 v130, v130, v181                             // 0000000F7F90: 07056B82
	s_waitcnt lgkmcnt(0)                                       // 0000000F7F94: BF89FC07
	v_fmac_f32_e32 v130, v183, v131                            // 0000000F7F98: 570507B7
	ds_store_b32 v172, v129                                    // 0000000F7F9C: D8340000 000081AC
	ds_store_b32 v175, v130                                    // 0000000F7FA4: D8340000 000082AF
	ds_store_b32 v176, v183                                    // 0000000F7FAC: D8340000 0000B7B0
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F7FB4: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000F7FB8: BF89FC07
	s_barrier                                                  // 0000000F7FBC: BFBD0000
	buffer_gl0_inv                                             // 0000000F7FC0: E0AC0000 00000000
	ds_load_2addr_b32 v[155:156], v177 offset1:2               // 0000000F7FC8: D8DC0200 9B0000B1
	ds_load_2addr_b32 v[153:154], v177 offset0:4 offset1:6     // 0000000F7FD0: D8DC0604 990000B1
	ds_load_2addr_b32 v[151:152], v177 offset0:8 offset1:10    // 0000000F7FD8: D8DC0A08 970000B1
	ds_load_2addr_b32 v[149:150], v177 offset0:12 offset1:14   // 0000000F7FE0: D8DC0E0C 950000B1
	s_waitcnt lgkmcnt(3)                                       // 0000000F7FE8: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v155                         // 0000000F7FEC: 7C2536F2
	.long 0xd4120001                                           // 0000000F7FF0: D4120001
	v_cndmask_b32_e32 v1, 1.0, v156, vcc_lo                    // 0000000F7FF4: 020338F2
	s_waitcnt lgkmcnt(2)                                       // 0000000F7FF8: BF89FC27
	.long 0xd4120002                                           // 0000000F7FFC: D4120002
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 0000000F8000: 020332F2
	.long 0xd4120004                                           // 0000000F8004: D4120004
	v_cndmask_b32_e32 v1, 1.0, v154, vcc_lo                    // 0000000F8008: 020334F2
	s_and_b32 s1, vcc_lo, s1                                   // 0000000F800C: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 0000000F8010: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v151                         // 0000000F8014: 7C252EF2
	s_and_b32 s2, s1, s2                                       // 0000000F8018: 8B020201
	.long 0xd4120001                                           // 0000000F801C: D4120001
	v_cndmask_b32_e32 v1, 1.0, v152, vcc_lo                    // 0000000F8020: 020330F2
	s_and_b32 s4, s2, s4                                       // 0000000F8024: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 0000000F8028: BF89FC07
	.long 0xd4120002                                           // 0000000F802C: D4120002
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 0000000F8030: 02032AF2
	s_and_b32 s4, s4, vcc_lo                                   // 0000000F8034: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v150                         // 0000000F8038: 7C252CF2
	s_and_b32 s1, s4, s1                                       // 0000000F803C: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000F8040: BF870499
	s_and_b32 s1, s1, s2                                       // 0000000F8044: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 0000000F8048: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F804C: BF870099
	v_cndmask_b32_e64 v129, 0, 1, s1                           // 0000000F8050: D5010081 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v129                           // 0000000F8058: 7C9B0280
	ds_load_b128 v[129:132], v178                              // 0000000F805C: DBFC0000 810000B2
	ds_load_b128 v[133:136], v178 offset:16                    // 0000000F8064: DBFC0010 850000B2
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 0000000F806C: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 0000000F8070: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8074: BF870099
	v_cndmask_b32_e64 v181, 0, 1, s1                           // 0000000F8078: D50100B5 00050280
	v_readfirstlane_b32 s1, v181                               // 0000000F8080: 7E0205B5
	s_bitcmp1_b32 s1, 0                                        // 0000000F8084: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 0000000F8088: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F808C: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 0000000F8090: 8B6A017E
	s_cbranch_vccnz 63624                                      // 0000000F8094: BFA4F888 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b8>
	v_dual_mul_f32 v120, v155, v120 :: v_dual_mul_f32 v121, v156, v121// 0000000F8098: C8C6F19B 7878F39C
	v_dual_mul_f32 v122, v153, v122 :: v_dual_mul_f32 v123, v154, v123// 0000000F80A0: C8C6F599 7A7AF79A
	v_dual_mul_f32 v124, v151, v124 :: v_dual_mul_f32 v125, v152, v125// 0000000F80A8: C8C6F997 7C7CFB98
	v_dual_mul_f32 v126, v149, v126 :: v_dual_mul_f32 v127, v150, v127// 0000000F80B0: C8C6FD95 7E7EFF96
	v_dual_mul_f32 v112, v155, v112 :: v_dual_mul_f32 v113, v156, v113// 0000000F80B8: C8C6E19B 7070E39C
	v_dual_mul_f32 v114, v153, v114 :: v_dual_mul_f32 v115, v154, v115// 0000000F80C0: C8C6E599 7272E79A
	v_dual_mul_f32 v116, v151, v116 :: v_dual_mul_f32 v117, v152, v117// 0000000F80C8: C8C6E997 7474EB98
	v_dual_mul_f32 v118, v149, v118 :: v_dual_mul_f32 v119, v150, v119// 0000000F80D0: C8C6ED95 7676EF96
	v_dual_mul_f32 v104, v155, v104 :: v_dual_mul_f32 v105, v156, v105// 0000000F80D8: C8C6D19B 6868D39C
	v_dual_mul_f32 v106, v153, v106 :: v_dual_mul_f32 v107, v154, v107// 0000000F80E0: C8C6D599 6A6AD79A
	v_dual_mul_f32 v108, v151, v108 :: v_dual_mul_f32 v109, v152, v109// 0000000F80E8: C8C6D997 6C6CDB98
	v_dual_mul_f32 v110, v149, v110 :: v_dual_mul_f32 v111, v150, v111// 0000000F80F0: C8C6DD95 6E6EDF96
	v_dual_mul_f32 v96, v155, v96 :: v_dual_mul_f32 v97, v156, v97// 0000000F80F8: C8C6C19B 6060C39C
	v_dual_mul_f32 v98, v153, v98 :: v_dual_mul_f32 v99, v154, v99// 0000000F8100: C8C6C599 6262C79A
	v_dual_mul_f32 v100, v151, v100 :: v_dual_mul_f32 v101, v152, v101// 0000000F8108: C8C6C997 6464CB98
	v_dual_mul_f32 v102, v149, v102 :: v_dual_mul_f32 v103, v150, v103// 0000000F8110: C8C6CD95 6666CF96
	v_dual_mul_f32 v88, v155, v88 :: v_dual_mul_f32 v89, v156, v89// 0000000F8118: C8C6B19B 5858B39C
	v_dual_mul_f32 v90, v153, v90 :: v_dual_mul_f32 v91, v154, v91// 0000000F8120: C8C6B599 5A5AB79A
	v_dual_mul_f32 v92, v151, v92 :: v_dual_mul_f32 v93, v152, v93// 0000000F8128: C8C6B997 5C5CBB98
	v_dual_mul_f32 v94, v149, v94 :: v_dual_mul_f32 v95, v150, v95// 0000000F8130: C8C6BD95 5E5EBF96
	v_dual_mul_f32 v80, v155, v80 :: v_dual_mul_f32 v81, v156, v81// 0000000F8138: C8C6A19B 5050A39C
	v_dual_mul_f32 v82, v153, v82 :: v_dual_mul_f32 v83, v154, v83// 0000000F8140: C8C6A599 5252A79A
	v_dual_mul_f32 v84, v151, v84 :: v_dual_mul_f32 v85, v152, v85// 0000000F8148: C8C6A997 5454AB98
	v_dual_mul_f32 v86, v149, v86 :: v_dual_mul_f32 v87, v150, v87// 0000000F8150: C8C6AD95 5656AF96
	v_dual_mul_f32 v72, v155, v72 :: v_dual_mul_f32 v73, v156, v73// 0000000F8158: C8C6919B 4848939C
	v_dual_mul_f32 v74, v153, v74 :: v_dual_mul_f32 v75, v154, v75// 0000000F8160: C8C69599 4A4A979A
	v_dual_mul_f32 v76, v151, v76 :: v_dual_mul_f32 v77, v152, v77// 0000000F8168: C8C69997 4C4C9B98
	v_dual_mul_f32 v78, v149, v78 :: v_dual_mul_f32 v79, v150, v79// 0000000F8170: C8C69D95 4E4E9F96
	v_dual_mul_f32 v64, v155, v64 :: v_dual_mul_f32 v65, v156, v65// 0000000F8178: C8C6819B 4040839C
	v_dual_mul_f32 v66, v153, v66 :: v_dual_mul_f32 v67, v154, v67// 0000000F8180: C8C68599 4242879A
	v_dual_mul_f32 v68, v151, v68 :: v_dual_mul_f32 v69, v152, v69// 0000000F8188: C8C68997 44448B98
	v_dual_mul_f32 v70, v149, v70 :: v_dual_mul_f32 v71, v150, v71// 0000000F8190: C8C68D95 46468F96
	v_dual_mul_f32 v56, v155, v56 :: v_dual_mul_f32 v57, v156, v57// 0000000F8198: C8C6719B 3838739C
	v_dual_mul_f32 v58, v153, v58 :: v_dual_mul_f32 v59, v154, v59// 0000000F81A0: C8C67599 3A3A779A
	v_dual_mul_f32 v60, v151, v60 :: v_dual_mul_f32 v61, v152, v61// 0000000F81A8: C8C67997 3C3C7B98
	v_dual_mul_f32 v62, v149, v62 :: v_dual_mul_f32 v63, v150, v63// 0000000F81B0: C8C67D95 3E3E7F96
	v_dual_mul_f32 v48, v155, v48 :: v_dual_mul_f32 v49, v156, v49// 0000000F81B8: C8C6619B 3030639C
	v_dual_mul_f32 v50, v153, v50 :: v_dual_mul_f32 v51, v154, v51// 0000000F81C0: C8C66599 3232679A
	v_dual_mul_f32 v52, v151, v52 :: v_dual_mul_f32 v53, v152, v53// 0000000F81C8: C8C66997 34346B98
	v_dual_mul_f32 v54, v149, v54 :: v_dual_mul_f32 v55, v150, v55// 0000000F81D0: C8C66D95 36366F96
	v_dual_mul_f32 v40, v155, v40 :: v_dual_mul_f32 v41, v156, v41// 0000000F81D8: C8C6519B 2828539C
	v_dual_mul_f32 v42, v153, v42 :: v_dual_mul_f32 v43, v154, v43// 0000000F81E0: C8C65599 2A2A579A
	v_dual_mul_f32 v44, v151, v44 :: v_dual_mul_f32 v45, v152, v45// 0000000F81E8: C8C65997 2C2C5B98
	v_dual_mul_f32 v46, v149, v46 :: v_dual_mul_f32 v47, v150, v47// 0000000F81F0: C8C65D95 2E2E5F96
	v_dual_mul_f32 v32, v155, v32 :: v_dual_mul_f32 v33, v156, v33// 0000000F81F8: C8C6419B 2020439C
	v_dual_mul_f32 v34, v153, v34 :: v_dual_mul_f32 v35, v154, v35// 0000000F8200: C8C64599 2222479A
	v_dual_mul_f32 v36, v151, v36 :: v_dual_mul_f32 v37, v152, v37// 0000000F8208: C8C64997 24244B98
	v_dual_mul_f32 v38, v149, v38 :: v_dual_mul_f32 v39, v150, v39// 0000000F8210: C8C64D95 26264F96
	v_dual_mul_f32 v24, v155, v24 :: v_dual_mul_f32 v25, v156, v25// 0000000F8218: C8C6319B 1818339C
	v_dual_mul_f32 v26, v153, v26 :: v_dual_mul_f32 v27, v154, v27// 0000000F8220: C8C63599 1A1A379A
	v_dual_mul_f32 v28, v151, v28 :: v_dual_mul_f32 v29, v152, v29// 0000000F8228: C8C63997 1C1C3B98
	v_dual_mul_f32 v30, v149, v30 :: v_dual_mul_f32 v31, v150, v31// 0000000F8230: C8C63D95 1E1E3F96
	v_dual_mul_f32 v16, v155, v16 :: v_dual_mul_f32 v17, v156, v17// 0000000F8238: C8C6219B 1010239C
	v_dual_mul_f32 v18, v153, v18 :: v_dual_mul_f32 v19, v154, v19// 0000000F8240: C8C62599 1212279A
	v_dual_mul_f32 v20, v151, v20 :: v_dual_mul_f32 v21, v152, v21// 0000000F8248: C8C62997 14142B98
	v_dual_mul_f32 v22, v149, v22 :: v_dual_mul_f32 v23, v150, v23// 0000000F8250: C8C62D95 16162F96
	v_dual_mul_f32 v8, v155, v8 :: v_dual_mul_f32 v9, v156, v9 // 0000000F8258: C8C6119B 0808139C
	v_dual_mul_f32 v10, v153, v10 :: v_dual_mul_f32 v11, v154, v11// 0000000F8260: C8C61599 0A0A179A
	v_dual_mul_f32 v12, v151, v12 :: v_dual_mul_f32 v13, v152, v13// 0000000F8268: C8C61997 0C0C1B98
	v_dual_mul_f32 v14, v149, v14 :: v_dual_mul_f32 v15, v150, v15// 0000000F8270: C8C61D95 0E0E1F96
	v_dual_mul_f32 v0, v155, v0 :: v_dual_mul_f32 v1, v156, v1 // 0000000F8278: C8C6019B 0000039C
	v_dual_mul_f32 v2, v153, v2 :: v_dual_mul_f32 v3, v154, v3 // 0000000F8280: C8C60599 0202079A
	v_dual_mul_f32 v4, v151, v4 :: v_dual_mul_f32 v5, v152, v5 // 0000000F8288: C8C60997 04040B98
	v_dual_mul_f32 v6, v149, v6 :: v_dual_mul_f32 v7, v150, v7 // 0000000F8290: C8C60D95 06060F96
	s_branch 63495                                             // 0000000F8298: BFA0F807 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b8>
	v_lshlrev_b32_e32 v128, 2, v162                            // 0000000F829C: 31014482
	.long 0xd700008e                                           // 0000000F82A0: D700008E
	v_cndmask_b32_e32 v1, s18, v142, vcc_lo                    // 0000000F82A4: 02031C12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F82A8: BF870191
	v_add_co_ci_u32_e64 v143, null, s19, v143, s0              // 0000000F82AC: D5207C8F 00031E13
	v_lshl_or_b32 v128, v157, 6, v128                          // 0000000F82B4: D6560080 06010D9D
	s_waitcnt vmcnt(0)                                         // 0000000F82BC: BF8903F7
	v_or_b32_e32 v140, v158, v162                              // 0000000F82C0: 3919459E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000F82C4: BF870002
	v_add_nc_u32_e32 v132, 0xf000, v128                        // 0000000F82C8: 4B0900FF 0000F000
	v_lshlrev_b32_e32 v128, 9, v141                            // 0000000F82D0: 31011A89
	ds_load_2addr_b32 v[138:139], v132 offset0:192 offset1:194 // 0000000F82D4: D8DCC2C0 8A000084
	ds_load_2addr_b32 v[136:137], v132 offset0:196 offset1:198 // 0000000F82DC: D8DCC6C4 88000084
	ds_load_2addr_b32 v[134:135], v132 offset0:200 offset1:202 // 0000000F82E4: D8DCCAC8 86000084
	ds_load_2addr_b32 v[132:133], v132 offset0:204 offset1:206 // 0000000F82EC: D8DCCECC 84000084
	s_waitcnt lgkmcnt(3)                                       // 0000000F82F4: BF89FC37
	v_div_scale_f32 v144, null, v138, v138, 1.0                // 0000000F82F8: D6FC7C90 03CB158A
	v_div_scale_f32 v141, vcc_lo, 1.0, v138, 1.0               // 0000000F8300: D6FC6A8D 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F8308: BF870292
	v_rcp_f32_e32 v145, v144                                   // 0000000F830C: 7F225590
	v_fma_f32 v129, -v144, v145, 1.0                           // 0000000F8310: D6130081 23CB2390
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F8318: BF870121
	v_fmac_f32_e32 v145, v129, v145                            // 0000000F831C: 57232381
	v_ashrrev_i32_e32 v129, 31, v128                           // 0000000F8320: 3503009F
	v_mul_f32_e32 v146, v141, v145                             // 0000000F8324: 1125238D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F8328: BF8700A2
	.long 0xd73c0082                                           // 0000000F832C: D73C0082
	v_cndmask_b32_e32 v1, 1, v128, vcc_lo                      // 0000000F8330: 02030081
	.long 0xd7000080                                           // 0000000F8334: D7000080
	v_cndmask_b32_e32 v1, v142, v160, vcc_lo                   // 0000000F8338: 0203418E
	v_add_co_ci_u32_e64 v129, null, 0, v143, s0                // 0000000F833C: D5207C81 00031E80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000F8344: BF870214
	v_fma_f32 v147, -v144, v146, v141                          // 0000000F8348: D6130093 26372590
	.long 0xd7000082                                           // 0000000F8350: D7000082
	v_cndmask_b32_e32 v1, s16, v130, vcc_lo                    // 0000000F8354: 02030410
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F8358: BF870191
	v_add_co_ci_u32_e64 v131, null, s17, v131, s0              // 0000000F835C: D5207C83 00030611
	v_fmac_f32_e32 v146, v147, v145                            // 0000000F8364: 57252393
	.long 0xd4440000                                           // 0000000F8368: D4440000
	v_cndmask_b32_e32 v1, s14, v140, vcc_lo                    // 0000000F836C: 0203180E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8370: BF870092
	v_fma_f32 v141, -v144, v146, v141                          // 0000000F8374: D613008D 26372590
	v_div_fmas_f32 v141, v141, v145, v146                      // 0000000F837C: D637008D 064B238D
	.long 0xd7006a82                                           // 0000000F8384: D7006A82
	v_cndmask_b32_e32 v1, v130, v160, vcc_lo                   // 0000000F8388: 02034182
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F838C: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, vcc_lo            // 0000000F8390: D5207C83 01AB0680
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 0000000F8398: D627008A 03CB158D
	s_and_saveexec_b32 s1, s0                                  // 0000000F83A0: BE812000
	s_cbranch_execz 70                                         // 0000000F83A4: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2ac0>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F83A8: BF870112
	v_mad_i64_i32 v[141:142], null, 0x6000, v140, v[130:131]   // 0000000F83AC: D6FF7C8D 060B18FF 00006000
	v_mul_f32_e32 v120, v138, v120                             // 0000000F83B8: 10F0F18A
	global_load_u16 v141, v[141:142], off offset:512           // 0000000F83BC: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000F83C4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000F83C8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F83CC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000F83D0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000F83D8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000F83E4: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F83E8: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000F83EC: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000F83F0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000F83F8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F8400: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000F8404: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000F8408: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000F840C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8410: BF870095
	.long 0xd71c008e                                           // 0000000F8414: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000F8418: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000F841C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000F8420: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8428: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000F842C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000F8434: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8438: BF870091
	v_div_scale_f32 v142, null, v141, v141, v120               // 0000000F843C: D6FC7C8E 05E31B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000F8444: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8448: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000F844C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000F8454: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v120, v141, v120             // 0000000F8458: D6FC6A90 05E31B78
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8460: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000F8464: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000F8468: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8470: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000F8474: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000F8478: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8480: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000F8484: D637008E 06471F8E
	v_div_fixup_f32 v120, v142, v141, v120                     // 0000000F848C: D6270078 05E31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v140, v[128:129]   // 0000000F8494: D6FF7C8D 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F84A0: BF870092
	v_bfe_u32 v143, v120, 16, 1                                // 0000000F84A4: D610008F 02052178
	v_add3_u32 v120, v120, v143, 0x7fff                        // 0000000F84AC: D6550078 03FF1F78 00007FFF
	global_store_d16_hi_b16 v[141:142], v120, off              // 0000000F84B8: DC960000 007C788D
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000F84C0: 8C7E017E
	v_div_scale_f32 v120, null, v139, v139, 1.0                // 0000000F84C4: D6FC7C78 03CB178B
	v_div_scale_f32 v143, vcc_lo, 1.0, v139, 1.0               // 0000000F84CC: D6FC6A8F 03CB16F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F84D4: BF870292
	v_rcp_f32_e32 v141, v120                                   // 0000000F84D8: 7F1A5578
	v_fma_f32 v142, -v120, v141, 1.0                           // 0000000F84DC: D613008E 23CB1B78
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F84E4: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000F84E8: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000F84EC: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F84F0: BF870091
	v_fma_f32 v144, -v120, v142, v143                          // 0000000F84F4: D6130090 263F1D78
	v_fmac_f32_e32 v142, v144, v141                            // 0000000F84FC: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8500: BF870091
	v_fma_f32 v120, -v120, v142, v143                          // 0000000F8504: D6130078 263F1D78
	v_div_fmas_f32 v141, v120, v141, v142                      // 0000000F850C: D637008D 063B1B78
	v_or_b32_e32 v120, 2, v140                                 // 0000000F8514: 38F11882
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F8518: BF870112
	v_div_fixup_f32 v139, v141, v139, 1.0                      // 0000000F851C: D627008B 03CB178D
	.long 0xd4440001                                           // 0000000F8524: D4440001
	v_cndmask_b32_e32 v1, s14, v120, vcc_lo                    // 0000000F8528: 0202F00E
	s_and_saveexec_b32 s2, s1                                  // 0000000F852C: BE822001
	s_cbranch_execz 69                                         // 0000000F8530: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2c48>
	v_mad_i64_i32 v[141:142], null, 0x6000, v120, v[130:131]   // 0000000F8534: D6FF7C8D 060AF0FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 0000000F8540: 10F2F38B
	global_load_u16 v141, v[141:142], off offset:512           // 0000000F8544: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000F854C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000F8550: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8554: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000F8558: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000F8560: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000F856C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F8570: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000F8574: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000F8578: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000F8580: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F8588: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000F858C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000F8590: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000F8594: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8598: BF870095
	.long 0xd71c008e                                           // 0000000F859C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000F85A0: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000F85A4: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000F85A8: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F85B0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000F85B4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000F85BC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F85C0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v121               // 0000000F85C4: D6FC7C8E 05E71B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000F85CC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F85D0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000F85D4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000F85DC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v141, v121             // 0000000F85E0: D6FC6A90 05E71B79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F85E8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000F85EC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000F85F0: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F85F8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000F85FC: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000F8600: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8608: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000F860C: D637008E 06471F8E
	v_div_fixup_f32 v121, v142, v141, v121                     // 0000000F8614: D6270079 05E71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v120, v[128:129]   // 0000000F861C: D6FF7C8D 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8628: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 0000000F862C: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 0000000F8634: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[141:142], v121, off              // 0000000F8640: DC960000 007C798D
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000F8648: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 0000000F864C: BF89FC27
	v_div_scale_f32 v121, null, v136, v136, 1.0                // 0000000F8650: D6FC7C79 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 0000000F8658: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F8660: BF870292
	v_rcp_f32_e32 v141, v121                                   // 0000000F8664: 7F1A5579
	v_fma_f32 v142, -v121, v141, 1.0                           // 0000000F8668: D613008E 23CB1B79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8670: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000F8674: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000F8678: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F867C: BF870091
	v_fma_f32 v144, -v121, v142, v143                          // 0000000F8680: D6130090 263F1D79
	v_fmac_f32_e32 v142, v144, v141                            // 0000000F8688: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F868C: BF870091
	v_fma_f32 v121, -v121, v142, v143                          // 0000000F8690: D6130079 263F1D79
	v_div_fmas_f32 v141, v121, v141, v142                      // 0000000F8698: D637008D 063B1B79
	v_or_b32_e32 v121, 4, v140                                 // 0000000F86A0: 38F31884
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F86A4: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 0000000F86A8: D6270088 03CB118D
	.long 0xd4440002                                           // 0000000F86B0: D4440002
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 0000000F86B4: 0202F20E
	s_and_saveexec_b32 s3, s2                                  // 0000000F86B8: BE832002
	s_cbranch_execz 69                                         // 0000000F86BC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2dd4>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[130:131]   // 0000000F86C0: D6FF7C8D 060AF2FF 00006000
	v_mul_f32_e32 v122, v136, v122                             // 0000000F86CC: 10F4F588
	global_load_u16 v141, v[141:142], off offset:512           // 0000000F86D0: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000F86D8: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000F86DC: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F86E0: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000F86E4: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000F86EC: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000F86F8: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F86FC: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000F8700: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000F8704: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000F870C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F8714: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000F8718: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000F871C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000F8720: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8724: BF870095
	.long 0xd71c008e                                           // 0000000F8728: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000F872C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000F8730: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000F8734: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F873C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000F8740: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000F8748: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F874C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 0000000F8750: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000F8758: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F875C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000F8760: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000F8768: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 0000000F876C: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8774: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000F8778: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000F877C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8784: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000F8788: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000F878C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8794: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000F8798: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 0000000F87A0: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[128:129]   // 0000000F87A8: D6FF7C8D 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F87B4: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 0000000F87B8: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 0000000F87C0: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 0000000F87CC: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000F87D4: 8C7E037E
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 0000000F87D8: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 0000000F87E0: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F87E8: BF870292
	v_rcp_f32_e32 v141, v122                                   // 0000000F87EC: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 0000000F87F0: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F87F8: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000F87FC: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000F8800: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8804: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 0000000F8808: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 0000000F8810: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8814: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 0000000F8818: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 0000000F8820: D637008D 063B1B7A
	v_or_b32_e32 v122, 6, v140                                 // 0000000F8828: 38F51886
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F882C: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 0000000F8830: D6270089 03CB138D
	.long 0xd4440003                                           // 0000000F8838: D4440003
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 0000000F883C: 0202F40E
	s_and_saveexec_b32 s4, s3                                  // 0000000F8840: BE842003
	s_cbranch_execz 69                                         // 0000000F8844: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2f5c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[130:131]   // 0000000F8848: D6FF7C8D 060AF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 0000000F8854: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 0000000F8858: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000F8860: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000F8864: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8868: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000F886C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000F8874: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000F8880: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F8884: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000F8888: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000F888C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000F8894: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F889C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000F88A0: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000F88A4: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000F88A8: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F88AC: BF870095
	.long 0xd71c008e                                           // 0000000F88B0: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000F88B4: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000F88B8: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000F88BC: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F88C4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000F88C8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000F88D0: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F88D4: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 0000000F88D8: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000F88E0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F88E4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000F88E8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000F88F0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 0000000F88F4: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F88FC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000F8900: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000F8904: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F890C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000F8910: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000F8914: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F891C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000F8920: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 0000000F8928: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[128:129]   // 0000000F8930: D6FF7C8D 0602F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F893C: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 0000000F8940: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 0000000F8948: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 0000000F8954: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F895C: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 0000000F8960: BF89FC17
	v_div_scale_f32 v123, null, v134, v134, 1.0                // 0000000F8964: D6FC7C7B 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 0000000F896C: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F8974: BF870292
	v_rcp_f32_e32 v141, v123                                   // 0000000F8978: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 0000000F897C: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8984: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000F8988: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000F898C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8990: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 0000000F8994: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 0000000F899C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F89A0: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 0000000F89A4: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 0000000F89AC: D637008D 063B1B7B
	v_or_b32_e32 v123, 8, v140                                 // 0000000F89B4: 38F71888
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F89B8: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 0000000F89BC: D6270086 03CB0D8D
	.long 0xd4440004                                           // 0000000F89C4: D4440004
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 0000000F89C8: 0202F60E
	s_and_saveexec_b32 s5, s4                                  // 0000000F89CC: BE852004
	s_cbranch_execz 69                                         // 0000000F89D0: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x30e8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[130:131]   // 0000000F89D4: D6FF7C8D 060AF6FF 00006000
	v_mul_f32_e32 v124, v134, v124                             // 0000000F89E0: 10F8F986
	global_load_u16 v141, v[141:142], off offset:512           // 0000000F89E4: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000F89EC: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000F89F0: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F89F4: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000F89F8: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000F8A00: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000F8A0C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F8A10: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000F8A14: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000F8A18: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000F8A20: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F8A28: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000F8A2C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000F8A30: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000F8A34: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8A38: BF870095
	.long 0xd71c008e                                           // 0000000F8A3C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000F8A40: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000F8A44: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000F8A48: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8A50: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000F8A54: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000F8A5C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8A60: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 0000000F8A64: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000F8A6C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8A70: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000F8A74: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000F8A7C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 0000000F8A80: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8A88: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000F8A8C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000F8A90: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8A98: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000F8A9C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000F8AA0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8AA8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000F8AAC: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 0000000F8AB4: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[128:129]   // 0000000F8ABC: D6FF7C8D 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8AC8: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 0000000F8ACC: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 0000000F8AD4: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 0000000F8AE0: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000F8AE8: 8C7E057E
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 0000000F8AEC: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 0000000F8AF4: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F8AFC: BF870292
	v_rcp_f32_e32 v141, v124                                   // 0000000F8B00: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 0000000F8B04: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8B0C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000F8B10: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000F8B14: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8B18: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 0000000F8B1C: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 0000000F8B24: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8B28: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 0000000F8B2C: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 0000000F8B34: D637008D 063B1B7C
	v_or_b32_e32 v124, 10, v140                                // 0000000F8B3C: 38F9188A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F8B40: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 0000000F8B44: D6270087 03CB0F8D
	.long 0xd4440005                                           // 0000000F8B4C: D4440005
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 0000000F8B50: 0202F80E
	s_and_saveexec_b32 s6, s5                                  // 0000000F8B54: BE862005
	s_cbranch_execz 69                                         // 0000000F8B58: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3270>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[130:131]   // 0000000F8B5C: D6FF7C8D 060AF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 0000000F8B68: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 0000000F8B6C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000F8B74: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000F8B78: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8B7C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000F8B80: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000F8B88: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000F8B94: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F8B98: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000F8B9C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000F8BA0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000F8BA8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F8BB0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000F8BB4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000F8BB8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000F8BBC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8BC0: BF870095
	.long 0xd71c008e                                           // 0000000F8BC4: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000F8BC8: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000F8BCC: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000F8BD0: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8BD8: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000F8BDC: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000F8BE4: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8BE8: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 0000000F8BEC: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000F8BF4: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8BF8: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000F8BFC: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000F8C04: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 0000000F8C08: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8C10: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000F8C14: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000F8C18: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8C20: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000F8C24: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000F8C28: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8C30: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000F8C34: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 0000000F8C3C: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[128:129]   // 0000000F8C44: D6FF7C8D 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8C50: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 0000000F8C54: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 0000000F8C5C: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 0000000F8C68: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000F8C70: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000F8C74: BF89FC07
	v_div_scale_f32 v125, null, v132, v132, 1.0                // 0000000F8C78: D6FC7C7D 03CB0984
	v_div_scale_f32 v143, vcc_lo, 1.0, v132, 1.0               // 0000000F8C80: D6FC6A8F 03CB08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F8C88: BF870292
	v_rcp_f32_e32 v141, v125                                   // 0000000F8C8C: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 0000000F8C90: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8C98: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000F8C9C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000F8CA0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8CA4: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 0000000F8CA8: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 0000000F8CB0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8CB4: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 0000000F8CB8: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 0000000F8CC0: D637008D 063B1B7D
	v_or_b32_e32 v125, 12, v140                                // 0000000F8CC8: 38FB188C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F8CCC: BF870112
	v_div_fixup_f32 v132, v141, v132, 1.0                      // 0000000F8CD0: D6270084 03CB098D
	.long 0xd4440006                                           // 0000000F8CD8: D4440006
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 0000000F8CDC: 0202FA0E
	s_and_saveexec_b32 s7, s6                                  // 0000000F8CE0: BE872006
	s_cbranch_execz 69                                         // 0000000F8CE4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33fc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[130:131]   // 0000000F8CE8: D6FF7C8D 060AFAFF 00006000
	v_mul_f32_e32 v126, v132, v126                             // 0000000F8CF4: 10FCFD84
	global_load_u16 v141, v[141:142], off offset:512           // 0000000F8CF8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000F8D00: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000F8D04: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8D08: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000F8D0C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000F8D14: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000F8D20: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F8D24: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000F8D28: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000F8D2C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000F8D34: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F8D3C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000F8D40: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000F8D44: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000F8D48: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8D4C: BF870095
	.long 0xd71c008e                                           // 0000000F8D50: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000F8D54: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000F8D58: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000F8D5C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8D64: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000F8D68: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000F8D70: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8D74: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 0000000F8D78: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000F8D80: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8D84: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000F8D88: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000F8D90: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 0000000F8D94: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8D9C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000F8DA0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000F8DA4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8DAC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000F8DB0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000F8DB4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8DBC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000F8DC0: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 0000000F8DC8: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[128:129]   // 0000000F8DD0: D6FF7C8D 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8DDC: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 0000000F8DE0: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 0000000F8DE8: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 0000000F8DF4: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000F8DFC: 8C7E077E
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 0000000F8E00: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 0000000F8E08: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F8E10: BF870292
	v_rcp_f32_e32 v141, v126                                   // 0000000F8E14: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 0000000F8E18: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8E20: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000F8E24: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000F8E28: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8E2C: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 0000000F8E30: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 0000000F8E38: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8E3C: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 0000000F8E40: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 0000000F8E48: D637008D 063B1B7E
	v_or_b32_e32 v126, 14, v140                                // 0000000F8E50: 38FD188E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F8E54: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 0000000F8E58: D6270085 03CB0B8D
	.long 0xd4440007                                           // 0000000F8E60: D4440007
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 0000000F8E64: 0202FC0E
	s_and_saveexec_b32 s8, s7                                  // 0000000F8E68: BE882007
	s_cbranch_execnz 361                                       // 0000000F8E6C: BFA60169 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a14>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8E70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F8E74: BE882000
	s_cbranch_execnz 430                                       // 0000000F8E78: BFA601AE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b34>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8E7C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F8E80: BE882001
	s_cbranch_execnz 499                                       // 0000000F8E84: BFA601F3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c54>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8E88: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F8E8C: BE882002
	s_cbranch_execnz 568                                       // 0000000F8E90: BFA60238 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d74>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8E94: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F8E98: BE882003
	s_cbranch_execnz 637                                       // 0000000F8E9C: BFA6027D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e94>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8EA0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F8EA4: BE882004
	s_cbranch_execnz 706                                       // 0000000F8EA8: BFA602C2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fb4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8EAC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F8EB0: BE882005
	s_cbranch_execnz 775                                       // 0000000F8EB4: BFA60307 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8EB8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F8EBC: BE882006
	s_cbranch_execnz 844                                       // 0000000F8EC0: BFA6034C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8EC4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F8EC8: BE882007
	s_cbranch_execnz 913                                       // 0000000F8ECC: BFA60391 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4314>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8ED0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F8ED4: BE882000
	s_cbranch_execnz 982                                       // 0000000F8ED8: BFA603D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4434>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8EDC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F8EE0: BE882001
	s_cbranch_execnz 1051                                      // 0000000F8EE4: BFA6041B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4554>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8EE8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F8EEC: BE882002
	s_cbranch_execnz 1120                                      // 0000000F8EF0: BFA60460 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4674>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8EF4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F8EF8: BE882003
	s_cbranch_execnz 1189                                      // 0000000F8EFC: BFA604A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4794>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8F00: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F8F04: BE882004
	s_cbranch_execnz 1258                                      // 0000000F8F08: BFA604EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x48b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8F0C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F8F10: BE882005
	s_cbranch_execnz 1327                                      // 0000000F8F14: BFA6052F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x49d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8F18: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F8F1C: BE882006
	s_cbranch_execnz 1396                                      // 0000000F8F20: BFA60574 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4af4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8F24: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F8F28: BE882007
	s_cbranch_execnz 1465                                      // 0000000F8F2C: BFA605B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4c14>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8F30: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F8F34: BE882000
	s_cbranch_execnz 1534                                      // 0000000F8F38: BFA605FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4d34>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8F3C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F8F40: BE882001
	s_cbranch_execnz 1603                                      // 0000000F8F44: BFA60643 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4e54>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8F48: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F8F4C: BE882002
	s_cbranch_execnz 1672                                      // 0000000F8F50: BFA60688 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4f74>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8F54: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F8F58: BE882003
	s_cbranch_execnz 1741                                      // 0000000F8F5C: BFA606CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5094>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8F60: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F8F64: BE882004
	s_cbranch_execnz 1810                                      // 0000000F8F68: BFA60712 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x51b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8F6C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F8F70: BE882005
	s_cbranch_execnz 1879                                      // 0000000F8F74: BFA60757 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x52d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8F78: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F8F7C: BE882006
	s_cbranch_execnz 1948                                      // 0000000F8F80: BFA6079C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x53f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8F84: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F8F88: BE882007
	s_cbranch_execnz 2017                                      // 0000000F8F8C: BFA607E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5514>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8F90: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F8F94: BE882000
	s_cbranch_execnz 2086                                      // 0000000F8F98: BFA60826 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5634>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8F9C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F8FA0: BE882001
	s_cbranch_execnz 2155                                      // 0000000F8FA4: BFA6086B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5754>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8FA8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F8FAC: BE882002
	s_cbranch_execnz 2224                                      // 0000000F8FB0: BFA608B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5874>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8FB4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F8FB8: BE882003
	s_cbranch_execnz 2293                                      // 0000000F8FBC: BFA608F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5994>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8FC0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F8FC4: BE882004
	s_cbranch_execnz 2362                                      // 0000000F8FC8: BFA6093A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5ab4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8FCC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F8FD0: BE882005
	s_cbranch_execnz 2431                                      // 0000000F8FD4: BFA6097F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5bd4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8FD8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F8FDC: BE882006
	s_cbranch_execnz 2500                                      // 0000000F8FE0: BFA609C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5cf4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8FE4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F8FE8: BE882007
	s_cbranch_execnz 2569                                      // 0000000F8FEC: BFA60A09 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5e14>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8FF0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F8FF4: BE882000
	s_cbranch_execnz 2638                                      // 0000000F8FF8: BFA60A4E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5f34>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F8FFC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F9000: BE882001
	s_cbranch_execnz 2707                                      // 0000000F9004: BFA60A93 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6054>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9008: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F900C: BE882002
	s_cbranch_execnz 2776                                      // 0000000F9010: BFA60AD8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6174>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9014: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F9018: BE882003
	s_cbranch_execnz 2845                                      // 0000000F901C: BFA60B1D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6294>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9020: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F9024: BE882004
	s_cbranch_execnz 2914                                      // 0000000F9028: BFA60B62 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x63b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F902C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F9030: BE882005
	s_cbranch_execnz 2983                                      // 0000000F9034: BFA60BA7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x64d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9038: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F903C: BE882006
	s_cbranch_execnz 3052                                      // 0000000F9040: BFA60BEC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x65f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9044: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F9048: BE882007
	s_cbranch_execnz 3121                                      // 0000000F904C: BFA60C31 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6714>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9050: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F9054: BE882000
	s_cbranch_execnz 3190                                      // 0000000F9058: BFA60C76 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6834>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F905C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F9060: BE882001
	s_cbranch_execnz 3259                                      // 0000000F9064: BFA60CBB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6954>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9068: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F906C: BE882002
	s_cbranch_execnz 3328                                      // 0000000F9070: BFA60D00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6a74>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9074: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F9078: BE882003
	s_cbranch_execnz 3397                                      // 0000000F907C: BFA60D45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6b94>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9080: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F9084: BE882004
	s_cbranch_execnz 3466                                      // 0000000F9088: BFA60D8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6cb4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F908C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F9090: BE882005
	s_cbranch_execnz 3535                                      // 0000000F9094: BFA60DCF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6dd4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9098: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F909C: BE882006
	s_cbranch_execnz 3604                                      // 0000000F90A0: BFA60E14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6ef4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F90A4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F90A8: BE882007
	s_cbranch_execnz 3673                                      // 0000000F90AC: BFA60E59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7014>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F90B0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F90B4: BE882000
	s_cbranch_execnz 3742                                      // 0000000F90B8: BFA60E9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7134>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F90BC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F90C0: BE882001
	s_cbranch_execnz 3811                                      // 0000000F90C4: BFA60EE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7254>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F90C8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F90CC: BE882002
	s_cbranch_execnz 3880                                      // 0000000F90D0: BFA60F28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7374>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F90D4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F90D8: BE882003
	s_cbranch_execnz 3949                                      // 0000000F90DC: BFA60F6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7494>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F90E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F90E4: BE882004
	s_cbranch_execnz 4018                                      // 0000000F90E8: BFA60FB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x75b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F90EC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F90F0: BE882005
	s_cbranch_execnz 4087                                      // 0000000F90F4: BFA60FF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x76d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F90F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F90FC: BE882006
	s_cbranch_execnz 4156                                      // 0000000F9100: BFA6103C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x77f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9104: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F9108: BE882007
	s_cbranch_execnz 4225                                      // 0000000F910C: BFA61081 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7914>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9110: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F9114: BE882000
	s_cbranch_execnz 4294                                      // 0000000F9118: BFA610C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7a34>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F911C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F9120: BE882001
	s_cbranch_execnz 4363                                      // 0000000F9124: BFA6110B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7b54>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9128: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F912C: BE882002
	s_cbranch_execnz 4432                                      // 0000000F9130: BFA61150 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7c74>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9134: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F9138: BE882003
	s_cbranch_execnz 4501                                      // 0000000F913C: BFA61195 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7d94>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9140: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F9144: BE882004
	s_cbranch_execnz 4570                                      // 0000000F9148: BFA611DA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7eb4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F914C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F9150: BE882005
	s_cbranch_execnz 4639                                      // 0000000F9154: BFA6121F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7fd4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9158: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F915C: BE882006
	s_cbranch_execnz 4708                                      // 0000000F9160: BFA61264 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x80f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9164: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F9168: BE882007
	s_cbranch_execnz 4777                                      // 0000000F916C: BFA612A9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8214>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9170: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F9174: BE882000
	s_cbranch_execnz 4846                                      // 0000000F9178: BFA612EE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8334>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F917C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F9180: BE882001
	s_cbranch_execnz 4915                                      // 0000000F9184: BFA61333 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8454>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9188: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F918C: BE882002
	s_cbranch_execnz 4984                                      // 0000000F9190: BFA61378 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8574>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9194: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F9198: BE882003
	s_cbranch_execnz 5053                                      // 0000000F919C: BFA613BD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8694>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F91A0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F91A4: BE882004
	s_cbranch_execnz 5122                                      // 0000000F91A8: BFA61402 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x87b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F91AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F91B0: BE882005
	s_cbranch_execnz 5191                                      // 0000000F91B4: BFA61447 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x88d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F91B8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F91BC: BE882006
	s_cbranch_execnz 5260                                      // 0000000F91C0: BFA6148C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x89f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F91C4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F91C8: BE882007
	s_cbranch_execnz 5329                                      // 0000000F91CC: BFA614D1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b14>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F91D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F91D4: BE882000
	s_cbranch_execnz 5398                                      // 0000000F91D8: BFA61516 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8c34>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F91DC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F91E0: BE882001
	s_cbranch_execnz 5467                                      // 0000000F91E4: BFA6155B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8d54>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F91E8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F91EC: BE882002
	s_cbranch_execnz 5536                                      // 0000000F91F0: BFA615A0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8e74>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F91F4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F91F8: BE882003
	s_cbranch_execnz 5605                                      // 0000000F91FC: BFA615E5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8f94>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9200: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F9204: BE882004
	s_cbranch_execnz 5674                                      // 0000000F9208: BFA6162A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x90b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F920C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F9210: BE882005
	s_cbranch_execnz 5743                                      // 0000000F9214: BFA6166F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x91d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9218: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F921C: BE882006
	s_cbranch_execnz 5812                                      // 0000000F9220: BFA616B4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x92f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9224: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F9228: BE882007
	s_cbranch_execnz 5881                                      // 0000000F922C: BFA616F9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9414>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9230: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F9234: BE882000
	s_cbranch_execnz 5950                                      // 0000000F9238: BFA6173E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9534>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F923C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F9240: BE882001
	s_cbranch_execnz 6019                                      // 0000000F9244: BFA61783 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9654>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9248: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F924C: BE882002
	s_cbranch_execnz 6088                                      // 0000000F9250: BFA617C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9774>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9254: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F9258: BE882003
	s_cbranch_execnz 6157                                      // 0000000F925C: BFA6180D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9894>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9260: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F9264: BE882004
	s_cbranch_execnz 6226                                      // 0000000F9268: BFA61852 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x99b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F926C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F9270: BE882005
	s_cbranch_execnz 6295                                      // 0000000F9274: BFA61897 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9ad4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9278: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F927C: BE882006
	s_cbranch_execnz 6364                                      // 0000000F9280: BFA618DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9bf4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9284: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F9288: BE882007
	s_cbranch_execnz 6433                                      // 0000000F928C: BFA61921 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9d14>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9290: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F9294: BE882000
	s_cbranch_execnz 6502                                      // 0000000F9298: BFA61966 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9e34>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F929C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F92A0: BE882001
	s_cbranch_execnz 6571                                      // 0000000F92A4: BFA619AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9f54>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F92A8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F92AC: BE882002
	s_cbranch_execnz 6640                                      // 0000000F92B0: BFA619F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa074>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F92B4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F92B8: BE882003
	s_cbranch_execnz 6709                                      // 0000000F92BC: BFA61A35 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa194>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F92C0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F92C4: BE882004
	s_cbranch_execnz 6778                                      // 0000000F92C8: BFA61A7A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa2b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F92CC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F92D0: BE882005
	s_cbranch_execnz 6847                                      // 0000000F92D4: BFA61ABF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa3d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F92D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F92DC: BE882006
	s_cbranch_execnz 6916                                      // 0000000F92E0: BFA61B04 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa4f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F92E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F92E8: BE882007
	s_cbranch_execnz 6985                                      // 0000000F92EC: BFA61B49 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa614>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F92F0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F92F4: BE882000
	s_cbranch_execnz 7054                                      // 0000000F92F8: BFA61B8E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa734>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F92FC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F9300: BE882001
	s_cbranch_execnz 7123                                      // 0000000F9304: BFA61BD3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa854>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9308: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F930C: BE882002
	s_cbranch_execnz 7192                                      // 0000000F9310: BFA61C18 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa974>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9314: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F9318: BE882003
	s_cbranch_execnz 7261                                      // 0000000F931C: BFA61C5D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaa94>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9320: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F9324: BE882004
	s_cbranch_execnz 7330                                      // 0000000F9328: BFA61CA2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xabb4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F932C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F9330: BE882005
	s_cbranch_execnz 7399                                      // 0000000F9334: BFA61CE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xacd4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9338: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F933C: BE882006
	s_cbranch_execnz 7468                                      // 0000000F9340: BFA61D2C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xadf4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9344: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F9348: BE882007
	s_cbranch_execnz 7537                                      // 0000000F934C: BFA61D71 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaf14>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9350: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F9354: BE882000
	s_cbranch_execnz 7606                                      // 0000000F9358: BFA61DB6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb034>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F935C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F9360: BE882001
	s_cbranch_execnz 7675                                      // 0000000F9364: BFA61DFB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb154>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9368: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F936C: BE882002
	s_cbranch_execnz 7744                                      // 0000000F9370: BFA61E40 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb274>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9374: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F9378: BE882003
	s_cbranch_execnz 7813                                      // 0000000F937C: BFA61E85 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb394>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9380: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F9384: BE882004
	s_cbranch_execnz 7882                                      // 0000000F9388: BFA61ECA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb4b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F938C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F9390: BE882005
	s_cbranch_execnz 7951                                      // 0000000F9394: BFA61F0F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb5d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9398: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F939C: BE882006
	s_cbranch_execnz 8020                                      // 0000000F93A0: BFA61F54 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb6f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F93A4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F93A8: BE882007
	s_cbranch_execnz 8089                                      // 0000000F93AC: BFA61F99 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb814>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F93B0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F93B4: BE882000
	s_cbranch_execnz 8158                                      // 0000000F93B8: BFA61FDE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb934>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F93BC: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 0000000F93C0: BE802001
	s_cbranch_execnz 8227                                      // 0000000F93C4: BFA62023 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xba54>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000F93C8: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000F93CC: BE802002
	s_cbranch_execnz 8296                                      // 0000000F93D0: BFA62068 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbb74>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000F93D4: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000F93D8: BE802003
	s_cbranch_execnz 8365                                      // 0000000F93DC: BFA620AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbc94>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000F93E0: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000F93E4: BE802004
	s_cbranch_execnz 8434                                      // 0000000F93E8: BFA620F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbdb4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000F93EC: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000F93F0: BE802005
	s_cbranch_execnz 8503                                      // 0000000F93F4: BFA62137 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbed4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000F93F8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000F93FC: BE802006
	s_cbranch_execnz 8572                                      // 0000000F9400: BFA6217C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbff4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000F9404: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000F9408: BE802007
	s_cbranch_execnz 8641                                      // 0000000F940C: BFA621C1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc114>
	s_endpgm                                                   // 0000000F9410: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[130:131]   // 0000000F9414: D6FF7C8D 060AFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 0000000F9420: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 0000000F9424: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000F942C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000F9430: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9434: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000F9438: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000F9440: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000F944C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F9450: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000F9454: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000F9458: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000F9460: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F9468: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000F946C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000F9470: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000F9474: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9478: BF870095
	.long 0xd71c008e                                           // 0000000F947C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000F9480: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000F9484: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000F9488: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9490: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000F9494: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000F949C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F94A0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 0000000F94A4: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000F94AC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F94B0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000F94B4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000F94BC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 0000000F94C0: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F94C8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000F94CC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000F94D0: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F94D8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000F94DC: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000F94E0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F94E8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000F94EC: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 0000000F94F4: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[128:129]   // 0000000F94FC: D6FF7C8D 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9508: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 0000000F950C: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 0000000F9514: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 0000000F9520: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9528: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F952C: BE882000
	s_cbranch_execz 65106                                      // 0000000F9530: BFA5FE52 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x347c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v140, v[130:131]   // 0000000F9534: D6FF7C8D 060B18FF 00006000
	v_mul_f32_e32 v112, v138, v112                             // 0000000F9540: 10E0E18A
	global_load_u16 v127, v[141:142], off offset:544           // 0000000F9544: DC4A0220 7F7C008D
	s_waitcnt vmcnt(0)                                         // 0000000F954C: BF8903F7
	v_lshlrev_b32_e32 v127, 16, v127                           // 0000000F9550: 30FEFE90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F9554: BF870121
	v_mul_f32_e32 v141, 0xbfb8aa3b, v127                       // 0000000F9558: 111AFEFF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v127                 // 0000000F9560: 7C3CFEFF 42CE8ED0
	v_fma_f32 v142, 0xbfb8aa3b, v127, -v141                    // 0000000F9568: D613008E 8636FEFF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 0000000F9574: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9578: BF870091
	v_dual_fmamk_f32 v142, v127, 0xb2a5705f, v142 :: v_dual_sub_f32 v141, v141, v143// 0000000F957C: C88B1D7F 8E8D1F8D B2A5705F
	v_add_f32_e32 v141, v141, v142                             // 0000000F9588: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 0000000F958C: 7F1C118F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F9590: BF870292
	v_exp_f32_e32 v141, v141                                   // 0000000F9594: 7F1A4B8D
	.long 0xd71c008d                                           // 0000000F9598: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 0000000F959C: 02031D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F95A0: BF870121
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000F95A4: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v127                 // 0000000F95A8: 7C36FEFF C2B17218
	v_cndmask_b32_e32 v127, 0x7f800000, v141, vcc_lo           // 0000000F95B0: 02FF1AFF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F95B8: BF870091
	v_add_f32_e32 v127, 1.0, v127                              // 0000000F95BC: 06FEFEF2
	v_div_scale_f32 v141, null, v127, v127, v112               // 0000000F95C0: D6FC7C8D 05C2FF7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F95C8: BF870291
	v_rcp_f32_e32 v142, v141                                   // 0000000F95CC: 7F1C558D
	v_fma_f32 v143, -v141, v142, 1.0                           // 0000000F95D0: D613008F 23CB1D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F95D8: BF8700A1
	v_fmac_f32_e32 v142, v143, v142                            // 0000000F95DC: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v112, v127, v112             // 0000000F95E0: D6FC6A8F 05C2FF70
	v_mul_f32_e32 v144, v143, v142                             // 0000000F95E8: 11211D8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F95EC: BF870091
	v_fma_f32 v145, -v141, v144, v143                          // 0000000F95F0: D6130091 263F218D
	v_fmac_f32_e32 v144, v145, v142                            // 0000000F95F8: 57211D91
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F95FC: BF870091
	v_fma_f32 v141, -v141, v144, v143                          // 0000000F9600: D613008D 263F218D
	v_div_fmas_f32 v141, v141, v142, v144                      // 0000000F9608: D637008D 06431D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F9610: BF870121
	v_div_fixup_f32 v112, v141, v127, v112                     // 0000000F9614: D6270070 05C2FF8D
	v_mad_i64_i32 v[141:142], null, 0x3000, v140, v[128:129]   // 0000000F961C: D6FF7C8D 060318FF 00003000
	v_bfe_u32 v127, v112, 16, 1                                // 0000000F9628: D610007F 02052170
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F9630: BF870001
	v_add3_u32 v112, v112, v127, 0x7fff                        // 0000000F9634: D6550070 03FEFF70 00007FFF
	global_store_d16_hi_b16 v[141:142], v112, off offset:32    // 0000000F9640: DC960020 007C708D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9648: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F964C: BE882001
	s_cbranch_execz 65037                                      // 0000000F9650: BFA5FE0D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3488>
	v_mad_i64_i32 v[141:142], null, 0x6000, v120, v[130:131]   // 0000000F9654: D6FF7C8D 060AF0FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 0000000F9660: 10E2E38B
	global_load_u16 v112, v[141:142], off offset:544           // 0000000F9664: DC4A0220 707C008D
	s_waitcnt vmcnt(0)                                         // 0000000F966C: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 0000000F9670: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9674: BF870091
	v_mul_f32_e32 v127, 0xbfb8aa3b, v112                       // 0000000F9678: 10FEE0FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v112, -v127                    // 0000000F9680: D613008D 85FEE0FF BFB8AA3B
	v_rndne_f32_e32 v142, v127                                 // 0000000F968C: 7F1C477F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F9690: BF870191
	v_sub_f32_e32 v127, v127, v142                             // 0000000F9694: 08FF1D7F
	v_fmamk_f32 v141, v112, 0xb2a5705f, v141                   // 0000000F9698: 591B1B70 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 0000000F96A0: 7C3CE0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F96A8: BF870122
	v_add_f32_e32 v127, v127, v141                             // 0000000F96AC: 06FF1B7F
	v_cvt_i32_f32_e32 v141, v142                               // 0000000F96B0: 7F1A118E
	v_exp_f32_e32 v127, v127                                   // 0000000F96B4: 7EFE4B7F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F96B8: BF870095
	.long 0xd71c007f                                           // 0000000F96BC: D71C007F
	v_cndmask_b32_e32 v1, v127, v141, vcc_lo                   // 0000000F96C0: 02031B7F
	v_cndmask_b32_e32 v127, 0, v127, vcc_lo                    // 0000000F96C4: 02FEFE80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 0000000F96C8: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F96D0: BF870092
	v_cndmask_b32_e32 v112, 0x7f800000, v127, vcc_lo           // 0000000F96D4: 02E0FEFF 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 0000000F96DC: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F96E0: BF870091
	v_div_scale_f32 v127, null, v112, v112, v113               // 0000000F96E4: D6FC7C7F 05C6E170
	v_rcp_f32_e32 v141, v127                                   // 0000000F96EC: 7F1A557F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F96F0: BF870095
	v_fma_f32 v142, -v127, v141, 1.0                           // 0000000F96F4: D613008E 23CB1B7F
	v_fmac_f32_e32 v141, v142, v141                            // 0000000F96FC: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v113, v112, v113             // 0000000F9700: D6FC6A8E 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9708: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 0000000F970C: 111F1B8E
	v_fma_f32 v144, -v127, v143, v142                          // 0000000F9710: D6130090 263B1F7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9718: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 0000000F971C: 571F1B90
	v_fma_f32 v127, -v127, v143, v142                          // 0000000F9720: D613007F 263B1F7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9728: BF870091
	v_div_fmas_f32 v127, v127, v141, v143                      // 0000000F972C: D637007F 063F1B7F
	v_div_fixup_f32 v127, v127, v112, v113                     // 0000000F9734: D627007F 05C6E17F
	v_mad_i64_i32 v[112:113], null, 0x3000, v120, v[128:129]   // 0000000F973C: D6FF7C70 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9748: BF870092
	v_bfe_u32 v141, v127, 16, 1                                // 0000000F974C: D610008D 0205217F
	v_add3_u32 v127, v127, v141, 0x7fff                        // 0000000F9754: D655007F 03FF1B7F 00007FFF
	global_store_d16_hi_b16 v[112:113], v127, off offset:32    // 0000000F9760: DC960020 007C7F70
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9768: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000F976C: BE882002
	s_cbranch_execz 64968                                      // 0000000F9770: BFA5FDC8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3494>
	v_mad_i64_i32 v[112:113], null, 0x6000, v121, v[130:131]   // 0000000F9774: D6FF7C70 060AF2FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 0000000F9780: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 0000000F9788: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 0000000F978C: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9790: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 0000000F9794: 10E2E0FF BFB8AA3B
	v_fma_f32 v127, 0xbfb8aa3b, v112, -v113                    // 0000000F979C: D613007F 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v141, v113                                 // 0000000F97A8: 7F1A4771
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F97AC: BF870191
	v_sub_f32_e32 v113, v113, v141                             // 0000000F97B0: 08E31B71
	v_fmamk_f32 v127, v112, 0xb2a5705f, v127                   // 0000000F97B4: 58FEFF70 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 0000000F97BC: 7C3CE0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F97C4: BF870122
	v_add_f32_e32 v113, v113, v127                             // 0000000F97C8: 06E2FF71
	v_cvt_i32_f32_e32 v127, v141                               // 0000000F97CC: 7EFE118D
	v_exp_f32_e32 v113, v113                                   // 0000000F97D0: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F97D4: BF870095
	.long 0xd71c0071                                           // 0000000F97D8: D71C0071
	v_cndmask_b32_e32 v1, v113, v127, vcc_lo                   // 0000000F97DC: 0202FF71
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000F97E0: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 0000000F97E4: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F97EC: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v136, v114// 0000000F97F0: CA46E2FF 7070E588 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 0000000F97FC: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9800: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 0000000F9804: D6FC7C72 05C6E170
	v_rcp_f32_e32 v127, v114                                   // 0000000F980C: 7EFE5572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9810: BF870095
	v_fma_f32 v141, -v114, v127, 1.0                           // 0000000F9814: D613008D 23CAFF72
	v_fmac_f32_e32 v127, v141, v127                            // 0000000F981C: 56FEFF8D
	v_div_scale_f32 v141, vcc_lo, v113, v112, v113             // 0000000F9820: D6FC6A8D 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9828: BF870091
	v_mul_f32_e32 v142, v141, v127                             // 0000000F982C: 111CFF8D
	v_fma_f32 v143, -v114, v142, v141                          // 0000000F9830: D613008F 26371D72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9838: BF870091
	v_fmac_f32_e32 v142, v143, v127                            // 0000000F983C: 571CFF8F
	v_fma_f32 v114, -v114, v142, v141                          // 0000000F9840: D6130072 26371D72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9848: BF870091
	v_div_fmas_f32 v114, v114, v127, v142                      // 0000000F984C: D6370072 063AFF72
	v_div_fixup_f32 v114, v114, v112, v113                     // 0000000F9854: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v121, v[128:129]   // 0000000F985C: D6FF7C70 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9868: BF870092
	v_bfe_u32 v127, v114, 16, 1                                // 0000000F986C: D610007F 02052172
	v_add3_u32 v114, v114, v127, 0x7fff                        // 0000000F9874: D6550072 03FEFF72 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 0000000F9880: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9888: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000F988C: BE882003
	s_cbranch_execz 64899                                      // 0000000F9890: BFA5FD83 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34a0>
	v_mad_i64_i32 v[112:113], null, 0x6000, v122, v[130:131]   // 0000000F9894: D6FF7C70 060AF4FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 0000000F98A0: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 0000000F98A8: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 0000000F98AC: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F98B0: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 0000000F98B4: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 0000000F98BC: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v127, v113                                 // 0000000F98C8: 7EFE4771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F98CC: BF870221
	v_sub_f32_e32 v113, v113, v127                             // 0000000F98D0: 08E2FF71
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 0000000F98D4: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 0000000F98DC: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F98E4: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000000F98E8: 06E2E571
	v_cvt_i32_f32_e32 v114, v127                               // 0000000F98EC: 7EE4117F
	v_exp_f32_e32 v113, v113                                   // 0000000F98F0: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F98F4: BF870095
	.long 0xd71c0071                                           // 0000000F98F8: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000000F98FC: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000F9900: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 0000000F9904: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F990C: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v137, v115// 0000000F9910: CA46E2FF 7070E789 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 0000000F991C: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9920: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 0000000F9924: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 0000000F992C: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9930: BF870095
	v_fma_f32 v127, -v114, v115, 1.0                           // 0000000F9934: D613007F 23CAE772
	v_fmac_f32_e32 v115, v127, v115                            // 0000000F993C: 56E6E77F
	v_div_scale_f32 v127, vcc_lo, v113, v112, v113             // 0000000F9940: D6FC6A7F 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9948: BF870091
	v_mul_f32_e32 v141, v127, v115                             // 0000000F994C: 111AE77F
	v_fma_f32 v142, -v114, v141, v127                          // 0000000F9950: D613008E 25FF1B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9958: BF870091
	v_fmac_f32_e32 v141, v142, v115                            // 0000000F995C: 571AE78E
	v_fma_f32 v114, -v114, v141, v127                          // 0000000F9960: D6130072 25FF1B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9968: BF870091
	v_div_fmas_f32 v114, v114, v115, v141                      // 0000000F996C: D6370072 0636E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 0000000F9974: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v122, v[128:129]   // 0000000F997C: D6FF7C70 0602F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9988: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 0000000F998C: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 0000000F9994: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 0000000F99A0: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F99A8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000F99AC: BE882004
	s_cbranch_execz 64830                                      // 0000000F99B0: BFA5FD3E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34ac>
	v_mad_i64_i32 v[112:113], null, 0x6000, v123, v[130:131]   // 0000000F99B4: D6FF7C70 060AF6FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 0000000F99C0: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 0000000F99C8: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 0000000F99CC: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F99D0: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 0000000F99D4: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 0000000F99DC: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000000F99E8: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F99EC: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 0000000F99F0: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 0000000F99F4: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 0000000F99FC: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F9A04: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000000F9A08: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000000F9A0C: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000000F9A10: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9A14: BF870095
	.long 0xd71c0071                                           // 0000000F9A18: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000000F9A1C: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000F9A20: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 0000000F9A24: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9A2C: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v134, v116// 0000000F9A30: CA46E2FF 7070E986 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 0000000F9A3C: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9A40: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 0000000F9A44: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 0000000F9A4C: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9A50: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 0000000F9A54: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 0000000F9A5C: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 0000000F9A60: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9A68: BF870091
	v_mul_f32_e32 v127, v116, v115                             // 0000000F9A6C: 10FEE774
	v_fma_f32 v141, -v114, v127, v116                          // 0000000F9A70: D613008D 25D2FF72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9A78: BF870091
	v_fmac_f32_e32 v127, v141, v115                            // 0000000F9A7C: 56FEE78D
	v_fma_f32 v114, -v114, v127, v116                          // 0000000F9A80: D6130072 25D2FF72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9A88: BF870091
	v_div_fmas_f32 v114, v114, v115, v127                      // 0000000F9A8C: D6370072 05FEE772
	v_div_fixup_f32 v114, v114, v112, v113                     // 0000000F9A94: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v123, v[128:129]   // 0000000F9A9C: D6FF7C70 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9AA8: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 0000000F9AAC: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 0000000F9AB4: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 0000000F9AC0: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9AC8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000F9ACC: BE882005
	s_cbranch_execz 64761                                      // 0000000F9AD0: BFA5FCF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34b8>
	v_mad_i64_i32 v[112:113], null, 0x6000, v124, v[130:131]   // 0000000F9AD4: D6FF7C70 060AF8FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 0000000F9AE0: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 0000000F9AE8: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 0000000F9AEC: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9AF0: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 0000000F9AF4: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 0000000F9AFC: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000000F9B08: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F9B0C: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 0000000F9B10: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 0000000F9B14: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 0000000F9B1C: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F9B24: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000000F9B28: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000000F9B2C: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000000F9B30: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9B34: BF870095
	.long 0xd71c0071                                           // 0000000F9B38: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000000F9B3C: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000F9B40: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 0000000F9B44: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9B4C: BF870092
	v_cndmask_b32_e32 v112, 0x7f800000, v113, vcc_lo           // 0000000F9B50: 02E0E2FF 7F800000
	v_dual_mul_f32 v113, v135, v117 :: v_dual_add_f32 v112, 1.0, v112// 0000000F9B58: C8C8EB87 7170E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9B60: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 0000000F9B64: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 0000000F9B6C: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9B70: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 0000000F9B74: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 0000000F9B7C: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 0000000F9B80: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9B88: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 0000000F9B8C: 10EAE774
	v_fma_f32 v127, -v114, v117, v116                          // 0000000F9B90: D613007F 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9B98: BF870091
	v_fmac_f32_e32 v117, v127, v115                            // 0000000F9B9C: 56EAE77F
	v_fma_f32 v114, -v114, v117, v116                          // 0000000F9BA0: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9BA8: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 0000000F9BAC: D6370072 05D6E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 0000000F9BB4: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v124, v[128:129]   // 0000000F9BBC: D6FF7C70 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9BC8: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 0000000F9BCC: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 0000000F9BD4: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 0000000F9BE0: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9BE8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000F9BEC: BE882006
	s_cbranch_execz 64692                                      // 0000000F9BF0: BFA5FCB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34c4>
	v_mad_i64_i32 v[112:113], null, 0x6000, v125, v[130:131]   // 0000000F9BF4: D6FF7C70 060AFAFF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 0000000F9C00: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 0000000F9C08: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 0000000F9C0C: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9C10: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 0000000F9C14: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 0000000F9C1C: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000000F9C28: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F9C2C: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 0000000F9C30: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 0000000F9C34: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 0000000F9C3C: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F9C44: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000000F9C48: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000000F9C4C: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000000F9C50: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9C54: BF870095
	.long 0xd71c0071                                           // 0000000F9C58: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000000F9C5C: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000F9C60: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 0000000F9C64: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9C6C: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v132, v118// 0000000F9C70: CA46E2FF 7070ED84 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 0000000F9C7C: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9C80: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 0000000F9C84: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 0000000F9C8C: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9C90: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 0000000F9C94: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 0000000F9C9C: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 0000000F9CA0: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9CA8: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 0000000F9CAC: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 0000000F9CB0: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9CB8: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 0000000F9CBC: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 0000000F9CC0: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9CC8: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 0000000F9CCC: D6370072 05D6E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 0000000F9CD4: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v125, v[128:129]   // 0000000F9CDC: D6FF7C70 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9CE8: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 0000000F9CEC: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 0000000F9CF4: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 0000000F9D00: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9D08: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000F9D0C: BE882007
	s_cbranch_execz 64623                                      // 0000000F9D10: BFA5FC6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34d0>
	v_mad_i64_i32 v[112:113], null, 0x6000, v126, v[130:131]   // 0000000F9D14: D6FF7C70 060AFCFF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 0000000F9D20: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 0000000F9D28: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 0000000F9D2C: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9D30: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 0000000F9D34: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 0000000F9D3C: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000000F9D48: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F9D4C: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 0000000F9D50: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 0000000F9D54: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 0000000F9D5C: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F9D64: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000000F9D68: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000000F9D6C: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000000F9D70: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9D74: BF870095
	.long 0xd71c0071                                           // 0000000F9D78: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000000F9D7C: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000F9D80: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 0000000F9D84: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9D8C: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v133, v119// 0000000F9D90: CA46E2FF 7070EF85 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 0000000F9D9C: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9DA0: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 0000000F9DA4: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 0000000F9DAC: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9DB0: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 0000000F9DB4: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 0000000F9DBC: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 0000000F9DC0: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9DC8: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 0000000F9DCC: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 0000000F9DD0: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9DD8: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 0000000F9DDC: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 0000000F9DE0: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9DE8: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 0000000F9DEC: D6370072 05D6E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 0000000F9DF4: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v126, v[128:129]   // 0000000F9DFC: D6FF7C70 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9E08: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 0000000F9E0C: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 0000000F9E14: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 0000000F9E20: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9E28: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000F9E2C: BE882000
	s_cbranch_execz 64554                                      // 0000000F9E30: BFA5FC2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34dc>
	v_mad_i64_i32 v[112:113], null, 0x6000, v140, v[130:131]   // 0000000F9E34: D6FF7C70 060B18FF 00006000
	v_mul_f32_e32 v104, v138, v104                             // 0000000F9E40: 10D0D18A
	global_load_u16 v112, v[112:113], off offset:576           // 0000000F9E44: DC4A0240 707C0070
	s_waitcnt vmcnt(0)                                         // 0000000F9E4C: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 0000000F9E50: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9E54: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 0000000F9E58: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 0000000F9E60: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000000F9E6C: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000F9E70: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 0000000F9E74: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 0000000F9E78: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 0000000F9E80: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F9E88: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000000F9E8C: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000000F9E90: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000000F9E94: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9E98: BF870095
	.long 0xd71c0071                                           // 0000000F9E9C: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000000F9EA0: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000F9EA4: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 0000000F9EA8: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9EB0: BF870092
	v_cndmask_b32_e32 v112, 0x7f800000, v113, vcc_lo           // 0000000F9EB4: 02E0E2FF 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 0000000F9EBC: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9EC0: BF870091
	v_div_scale_f32 v113, null, v112, v112, v104               // 0000000F9EC4: D6FC7C71 05A2E170
	v_rcp_f32_e32 v114, v113                                   // 0000000F9ECC: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9ED0: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 0000000F9ED4: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 0000000F9EDC: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v104, v112, v104             // 0000000F9EE0: D6FC6A73 05A2E168
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9EE8: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 0000000F9EEC: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 0000000F9EF0: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9EF8: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 0000000F9EFC: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 0000000F9F00: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9F08: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 0000000F9F0C: D6370071 05D2E571
	v_div_fixup_f32 v104, v113, v112, v104                     // 0000000F9F14: D6270068 05A2E171
	v_mad_i64_i32 v[112:113], null, 0x3000, v140, v[128:129]   // 0000000F9F1C: D6FF7C70 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9F28: BF870092
	v_bfe_u32 v114, v104, 16, 1                                // 0000000F9F2C: D6100072 02052168
	v_add3_u32 v104, v104, v114, 0x7fff                        // 0000000F9F34: D6550068 03FEE568 00007FFF
	global_store_d16_hi_b16 v[112:113], v104, off offset:64    // 0000000F9F40: DC960040 007C6870
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000F9F48: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000F9F4C: BE882001
	s_cbranch_execz 64485                                      // 0000000F9F50: BFA5FBE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34e8>
	v_mad_i64_i32 v[112:113], null, 0x6000, v120, v[130:131]   // 0000000F9F54: D6FF7C70 060AF0FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 0000000F9F60: 10D2D38B
	global_load_u16 v104, v[112:113], off offset:576           // 0000000F9F64: DC4A0240 687C0070
	s_waitcnt vmcnt(0)                                         // 0000000F9F6C: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 0000000F9F70: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F9F74: BF870121
	v_mul_f32_e32 v112, 0xbfb8aa3b, v104                       // 0000000F9F78: 10E0D0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 0000000F9F80: 7C3CD0FF 42CE8ED0
	v_fma_f32 v113, 0xbfb8aa3b, v104, -v112                    // 0000000F9F88: D6130071 85C2D0FF BFB8AA3B
	v_rndne_f32_e32 v114, v112                                 // 0000000F9F94: 7EE44770
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F9F98: BF870112
	v_fmamk_f32 v113, v104, 0xb2a5705f, v113                   // 0000000F9F9C: 58E2E368 B2A5705F
	v_sub_f32_e32 v112, v112, v114                             // 0000000F9FA4: 08E0E570
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F9FA8: BF870121
	v_add_f32_e32 v112, v112, v113                             // 0000000F9FAC: 06E0E370
	v_cvt_i32_f32_e32 v113, v114                               // 0000000F9FB0: 7EE21172
	v_exp_f32_e32 v112, v112                                   // 0000000F9FB4: 7EE04B70
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9FB8: BF870095
	.long 0xd71c0070                                           // 0000000F9FBC: D71C0070
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                   // 0000000F9FC0: 0202E370
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 0000000F9FC4: 02E0E080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 0000000F9FC8: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9FD0: BF870092
	v_cndmask_b32_e32 v104, 0x7f800000, v112, vcc_lo           // 0000000F9FD4: 02D0E0FF 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 0000000F9FDC: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9FE0: BF870091
	v_div_scale_f32 v112, null, v104, v104, v105               // 0000000F9FE4: D6FC7C70 05A6D168
	v_rcp_f32_e32 v113, v112                                   // 0000000F9FEC: 7EE25570
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9FF0: BF870095
	v_fma_f32 v114, -v112, v113, 1.0                           // 0000000F9FF4: D6130072 23CAE370
	v_fmac_f32_e32 v113, v114, v113                            // 0000000F9FFC: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v105, v104, v105             // 0000000FA000: D6FC6A72 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA008: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 0000000FA00C: 10E6E372
	v_fma_f32 v116, -v112, v115, v114                          // 0000000FA010: D6130074 25CAE770
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA018: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 0000000FA01C: 56E6E374
	v_fma_f32 v112, -v112, v115, v114                          // 0000000FA020: D6130070 25CAE770
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA028: BF870091
	v_div_fmas_f32 v112, v112, v113, v115                      // 0000000FA02C: D6370070 05CEE370
	v_div_fixup_f32 v112, v112, v104, v105                     // 0000000FA034: D6270070 05A6D170
	v_mad_i64_i32 v[104:105], null, 0x3000, v120, v[128:129]   // 0000000FA03C: D6FF7C68 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA048: BF870092
	v_bfe_u32 v113, v112, 16, 1                                // 0000000FA04C: D6100071 02052170
	v_add3_u32 v112, v112, v113, 0x7fff                        // 0000000FA054: D6550070 03FEE370 00007FFF
	global_store_d16_hi_b16 v[104:105], v112, off offset:64    // 0000000FA060: DC960040 007C7068
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FA068: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000FA06C: BE882002
	s_cbranch_execz 64416                                      // 0000000FA070: BFA5FBA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34f4>
	v_mad_i64_i32 v[104:105], null, 0x6000, v121, v[130:131]   // 0000000FA074: D6FF7C68 060AF2FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 0000000FA080: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 0000000FA088: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 0000000FA08C: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA090: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 0000000FA094: 10D2D0FF BFB8AA3B
	v_fma_f32 v112, 0xbfb8aa3b, v104, -v105                    // 0000000FA09C: D6130070 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v113, v105                                 // 0000000FA0A8: 7EE24769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FA0AC: BF870221
	v_sub_f32_e32 v105, v105, v113                             // 0000000FA0B0: 08D2E369
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 0000000FA0B4: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v112, v104, 0xb2a5705f, v112                   // 0000000FA0BC: 58E0E168 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FA0C4: BF870121
	v_add_f32_e32 v105, v105, v112                             // 0000000FA0C8: 06D2E169
	v_cvt_i32_f32_e32 v112, v113                               // 0000000FA0CC: 7EE01171
	v_exp_f32_e32 v105, v105                                   // 0000000FA0D0: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA0D4: BF870095
	.long 0xd71c0069                                           // 0000000FA0D8: D71C0069
	v_cndmask_b32_e32 v1, v105, v112, vcc_lo                   // 0000000FA0DC: 0202E169
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000000FA0E0: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 0000000FA0E4: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA0EC: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v136, v106// 0000000FA0F0: CA46D2FF 6868D588 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 0000000FA0FC: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA100: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 0000000FA104: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v112, v106                                   // 0000000FA10C: 7EE0556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA110: BF870095
	v_fma_f32 v113, -v106, v112, 1.0                           // 0000000FA114: D6130071 23CAE16A
	v_fmac_f32_e32 v112, v113, v112                            // 0000000FA11C: 56E0E171
	v_div_scale_f32 v113, vcc_lo, v105, v104, v105             // 0000000FA120: D6FC6A71 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA128: BF870091
	v_mul_f32_e32 v114, v113, v112                             // 0000000FA12C: 10E4E171
	v_fma_f32 v115, -v106, v114, v113                          // 0000000FA130: D6130073 25C6E56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA138: BF870091
	v_fmac_f32_e32 v114, v115, v112                            // 0000000FA13C: 56E4E173
	v_fma_f32 v106, -v106, v114, v113                          // 0000000FA140: D613006A 25C6E56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA148: BF870091
	v_div_fmas_f32 v106, v106, v112, v114                      // 0000000FA14C: D637006A 05CAE16A
	v_div_fixup_f32 v106, v106, v104, v105                     // 0000000FA154: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v121, v[128:129]   // 0000000FA15C: D6FF7C68 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA168: BF870092
	v_bfe_u32 v112, v106, 16, 1                                // 0000000FA16C: D6100070 0205216A
	v_add3_u32 v106, v106, v112, 0x7fff                        // 0000000FA174: D655006A 03FEE16A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 0000000FA180: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FA188: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000FA18C: BE882003
	s_cbranch_execz 64347                                      // 0000000FA190: BFA5FB5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3500>
	v_mad_i64_i32 v[104:105], null, 0x6000, v122, v[130:131]   // 0000000FA194: D6FF7C68 060AF4FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 0000000FA1A0: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 0000000FA1A8: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 0000000FA1AC: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA1B0: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 0000000FA1B4: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 0000000FA1BC: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v112, v105                                 // 0000000FA1C8: 7EE04769
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA1CC: BF870091
	v_dual_fmamk_f32 v106, v104, 0xb2a5705f, v106 :: v_dual_sub_f32 v105, v105, v112// 0000000FA1D0: C88AD568 6A68E169 B2A5705F
	v_add_f32_e32 v105, v105, v106                             // 0000000FA1DC: 06D2D569
	v_cvt_i32_f32_e32 v106, v112                               // 0000000FA1E0: 7ED41170
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 0000000FA1E4: 7C3CD0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FA1EC: BF870293
	v_exp_f32_e32 v105, v105                                   // 0000000FA1F0: 7ED24B69
	.long 0xd71c0069                                           // 0000000FA1F4: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000000FA1F8: 0202D569
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FA1FC: BF870121
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000000FA200: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 0000000FA204: 7C36D0FF C2B17218
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v137, v107// 0000000FA20C: CA46D2FF 6868D789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA218: BF870091
	v_add_f32_e32 v104, 1.0, v104                              // 0000000FA21C: 06D0D0F2
	v_div_scale_f32 v106, null, v104, v104, v105               // 0000000FA220: D6FC7C6A 05A6D168
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FA228: BF870291
	v_rcp_f32_e32 v107, v106                                   // 0000000FA22C: 7ED6556A
	v_fma_f32 v112, -v106, v107, 1.0                           // 0000000FA230: D6130070 23CAD76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FA238: BF8700A1
	v_fmac_f32_e32 v107, v112, v107                            // 0000000FA23C: 56D6D770
	v_div_scale_f32 v112, vcc_lo, v105, v104, v105             // 0000000FA240: D6FC6A70 05A6D169
	v_mul_f32_e32 v113, v112, v107                             // 0000000FA248: 10E2D770
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA24C: BF870091
	v_fma_f32 v114, -v106, v113, v112                          // 0000000FA250: D6130072 25C2E36A
	v_fmac_f32_e32 v113, v114, v107                            // 0000000FA258: 56E2D772
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA25C: BF870091
	v_fma_f32 v106, -v106, v113, v112                          // 0000000FA260: D613006A 25C2E36A
	v_div_fmas_f32 v106, v106, v107, v113                      // 0000000FA268: D637006A 05C6D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FA270: BF870121
	v_div_fixup_f32 v106, v106, v104, v105                     // 0000000FA274: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v122, v[128:129]   // 0000000FA27C: D6FF7C68 0602F4FF 00003000
	v_bfe_u32 v107, v106, 16, 1                                // 0000000FA288: D610006B 0205216A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FA290: BF870001
	v_add3_u32 v106, v106, v107, 0x7fff                        // 0000000FA294: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 0000000FA2A0: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FA2A8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000FA2AC: BE882004
	s_cbranch_execz 64278                                      // 0000000FA2B0: BFA5FB16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x350c>
	v_mad_i64_i32 v[104:105], null, 0x6000, v123, v[130:131]   // 0000000FA2B4: D6FF7C68 060AF6FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 0000000FA2C0: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 0000000FA2C8: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 0000000FA2CC: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA2D0: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 0000000FA2D4: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 0000000FA2DC: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000000FA2E8: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FA2EC: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 0000000FA2F0: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 0000000FA2F4: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 0000000FA2FC: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FA304: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000000FA308: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000000FA30C: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000000FA310: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA314: BF870095
	.long 0xd71c0069                                           // 0000000FA318: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000000FA31C: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000000FA320: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 0000000FA324: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA32C: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v134, v108// 0000000FA330: CA46D2FF 6868D986 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 0000000FA33C: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA340: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 0000000FA344: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 0000000FA34C: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA350: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 0000000FA354: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 0000000FA35C: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 0000000FA360: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA368: BF870091
	v_mul_f32_e32 v112, v108, v107                             // 0000000FA36C: 10E0D76C
	v_fma_f32 v113, -v106, v112, v108                          // 0000000FA370: D6130071 25B2E16A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA378: BF870091
	v_fmac_f32_e32 v112, v113, v107                            // 0000000FA37C: 56E0D771
	v_fma_f32 v106, -v106, v112, v108                          // 0000000FA380: D613006A 25B2E16A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA388: BF870091
	v_div_fmas_f32 v106, v106, v107, v112                      // 0000000FA38C: D637006A 05C2D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 0000000FA394: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v123, v[128:129]   // 0000000FA39C: D6FF7C68 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA3A8: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 0000000FA3AC: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 0000000FA3B4: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 0000000FA3C0: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FA3C8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000FA3CC: BE882005
	s_cbranch_execz 64209                                      // 0000000FA3D0: BFA5FAD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3518>
	v_mad_i64_i32 v[104:105], null, 0x6000, v124, v[130:131]   // 0000000FA3D4: D6FF7C68 060AF8FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 0000000FA3E0: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 0000000FA3E8: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 0000000FA3EC: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA3F0: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 0000000FA3F4: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 0000000FA3FC: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000000FA408: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FA40C: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 0000000FA410: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 0000000FA414: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 0000000FA41C: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FA424: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000000FA428: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000000FA42C: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000000FA430: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA434: BF870095
	.long 0xd71c0069                                           // 0000000FA438: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000000FA43C: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000000FA440: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 0000000FA444: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA44C: BF870092
	v_cndmask_b32_e32 v104, 0x7f800000, v105, vcc_lo           // 0000000FA450: 02D0D2FF 7F800000
	v_dual_mul_f32 v105, v135, v109 :: v_dual_add_f32 v104, 1.0, v104// 0000000FA458: C8C8DB87 6968D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA460: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 0000000FA464: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 0000000FA46C: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA470: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 0000000FA474: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 0000000FA47C: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 0000000FA480: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA488: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 0000000FA48C: 10DAD76C
	v_fma_f32 v112, -v106, v109, v108                          // 0000000FA490: D6130070 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA498: BF870091
	v_fmac_f32_e32 v109, v112, v107                            // 0000000FA49C: 56DAD770
	v_fma_f32 v106, -v106, v109, v108                          // 0000000FA4A0: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA4A8: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 0000000FA4AC: D637006A 05B6D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 0000000FA4B4: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v124, v[128:129]   // 0000000FA4BC: D6FF7C68 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA4C8: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 0000000FA4CC: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 0000000FA4D4: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 0000000FA4E0: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FA4E8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000FA4EC: BE882006
	s_cbranch_execz 64140                                      // 0000000FA4F0: BFA5FA8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3524>
	v_mad_i64_i32 v[104:105], null, 0x6000, v125, v[130:131]   // 0000000FA4F4: D6FF7C68 060AFAFF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 0000000FA500: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 0000000FA508: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 0000000FA50C: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA510: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 0000000FA514: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 0000000FA51C: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000000FA528: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FA52C: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 0000000FA530: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 0000000FA534: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 0000000FA53C: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FA544: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000000FA548: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000000FA54C: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000000FA550: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA554: BF870095
	.long 0xd71c0069                                           // 0000000FA558: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000000FA55C: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000000FA560: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 0000000FA564: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA56C: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v132, v110// 0000000FA570: CA46D2FF 6868DD84 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 0000000FA57C: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA580: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 0000000FA584: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 0000000FA58C: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA590: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 0000000FA594: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 0000000FA59C: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 0000000FA5A0: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA5A8: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 0000000FA5AC: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 0000000FA5B0: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA5B8: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 0000000FA5BC: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 0000000FA5C0: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA5C8: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 0000000FA5CC: D637006A 05B6D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 0000000FA5D4: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v125, v[128:129]   // 0000000FA5DC: D6FF7C68 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA5E8: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 0000000FA5EC: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 0000000FA5F4: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 0000000FA600: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FA608: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000FA60C: BE882007
	s_cbranch_execz 64071                                      // 0000000FA610: BFA5FA47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3530>
	v_mad_i64_i32 v[104:105], null, 0x6000, v126, v[130:131]   // 0000000FA614: D6FF7C68 060AFCFF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 0000000FA620: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 0000000FA628: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 0000000FA62C: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA630: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 0000000FA634: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 0000000FA63C: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000000FA648: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FA64C: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 0000000FA650: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 0000000FA654: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 0000000FA65C: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FA664: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000000FA668: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000000FA66C: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000000FA670: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA674: BF870095
	.long 0xd71c0069                                           // 0000000FA678: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000000FA67C: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000000FA680: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 0000000FA684: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA68C: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v133, v111// 0000000FA690: CA46D2FF 6868DF85 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 0000000FA69C: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA6A0: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 0000000FA6A4: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 0000000FA6AC: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA6B0: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 0000000FA6B4: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 0000000FA6BC: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 0000000FA6C0: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA6C8: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 0000000FA6CC: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 0000000FA6D0: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA6D8: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 0000000FA6DC: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 0000000FA6E0: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA6E8: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 0000000FA6EC: D637006A 05B6D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 0000000FA6F4: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v126, v[128:129]   // 0000000FA6FC: D6FF7C68 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA708: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 0000000FA70C: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 0000000FA714: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 0000000FA720: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FA728: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000FA72C: BE882000
	s_cbranch_execz 64002                                      // 0000000FA730: BFA5FA02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x353c>
	v_mad_i64_i32 v[104:105], null, 0x6000, v140, v[130:131]   // 0000000FA734: D6FF7C68 060B18FF 00006000
	v_mul_f32_e32 v96, v138, v96                               // 0000000FA740: 10C0C18A
	global_load_u16 v104, v[104:105], off offset:608           // 0000000FA744: DC4A0260 687C0068
	s_waitcnt vmcnt(0)                                         // 0000000FA74C: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 0000000FA750: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA754: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 0000000FA758: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 0000000FA760: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000000FA76C: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FA770: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 0000000FA774: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 0000000FA778: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 0000000FA780: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FA788: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000000FA78C: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000000FA790: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000000FA794: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA798: BF870095
	.long 0xd71c0069                                           // 0000000FA79C: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000000FA7A0: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000000FA7A4: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 0000000FA7A8: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA7B0: BF870092
	v_cndmask_b32_e32 v104, 0x7f800000, v105, vcc_lo           // 0000000FA7B4: 02D0D2FF 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 0000000FA7BC: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA7C0: BF870091
	v_div_scale_f32 v105, null, v104, v104, v96                // 0000000FA7C4: D6FC7C69 0582D168
	v_rcp_f32_e32 v106, v105                                   // 0000000FA7CC: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA7D0: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 0000000FA7D4: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 0000000FA7DC: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v96, v104, v96               // 0000000FA7E0: D6FC6A6B 0582D160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA7E8: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 0000000FA7EC: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 0000000FA7F0: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA7F8: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 0000000FA7FC: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 0000000FA800: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA808: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 0000000FA80C: D6370069 05B2D569
	v_div_fixup_f32 v96, v105, v104, v96                       // 0000000FA814: D6270060 0582D169
	v_mad_i64_i32 v[104:105], null, 0x3000, v140, v[128:129]   // 0000000FA81C: D6FF7C68 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA828: BF870092
	v_bfe_u32 v106, v96, 16, 1                                 // 0000000FA82C: D610006A 02052160
	v_add3_u32 v96, v96, v106, 0x7fff                          // 0000000FA834: D6550060 03FED560 00007FFF
	global_store_d16_hi_b16 v[104:105], v96, off offset:96     // 0000000FA840: DC960060 007C6068
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FA848: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000FA84C: BE882001
	s_cbranch_execz 63933                                      // 0000000FA850: BFA5F9BD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3548>
	v_mad_i64_i32 v[104:105], null, 0x6000, v120, v[130:131]   // 0000000FA854: D6FF7C68 060AF0FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 0000000FA860: 10C2C38B
	global_load_u16 v96, v[104:105], off offset:608            // 0000000FA864: DC4A0260 607C0068
	s_waitcnt vmcnt(0)                                         // 0000000FA86C: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000000FA870: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FA874: BF870121
	v_mul_f32_e32 v104, 0xbfb8aa3b, v96                        // 0000000FA878: 10D0C0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000000FA880: 7C3CC0FF 42CE8ED0
	v_fma_f32 v105, 0xbfb8aa3b, v96, -v104                     // 0000000FA888: D6130069 85A2C0FF BFB8AA3B
	v_rndne_f32_e32 v106, v104                                 // 0000000FA894: 7ED44768
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FA898: BF870112
	v_fmamk_f32 v105, v96, 0xb2a5705f, v105                    // 0000000FA89C: 58D2D360 B2A5705F
	v_sub_f32_e32 v104, v104, v106                             // 0000000FA8A4: 08D0D568
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FA8A8: BF870121
	v_add_f32_e32 v104, v104, v105                             // 0000000FA8AC: 06D0D368
	v_cvt_i32_f32_e32 v105, v106                               // 0000000FA8B0: 7ED2116A
	v_exp_f32_e32 v104, v104                                   // 0000000FA8B4: 7ED04B68
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA8B8: BF870095
	.long 0xd71c0068                                           // 0000000FA8BC: D71C0068
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                   // 0000000FA8C0: 0202D368
	v_cndmask_b32_e32 v104, 0, v104, vcc_lo                    // 0000000FA8C4: 02D0D080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 0000000FA8C8: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA8D0: BF870092
	v_cndmask_b32_e32 v96, 0x7f800000, v104, vcc_lo            // 0000000FA8D4: 02C0D0FF 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 0000000FA8DC: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA8E0: BF870091
	v_div_scale_f32 v104, null, v96, v96, v97                  // 0000000FA8E4: D6FC7C68 0586C160
	v_rcp_f32_e32 v105, v104                                   // 0000000FA8EC: 7ED25568
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA8F0: BF870095
	v_fma_f32 v106, -v104, v105, 1.0                           // 0000000FA8F4: D613006A 23CAD368
	v_fmac_f32_e32 v105, v106, v105                            // 0000000FA8FC: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v97, v96, v97                // 0000000FA900: D6FC6A6A 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA908: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 0000000FA90C: 10D6D36A
	v_fma_f32 v108, -v104, v107, v106                          // 0000000FA910: D613006C 25AAD768
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA918: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 0000000FA91C: 56D6D36C
	v_fma_f32 v104, -v104, v107, v106                          // 0000000FA920: D6130068 25AAD768
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA928: BF870091
	v_div_fmas_f32 v104, v104, v105, v107                      // 0000000FA92C: D6370068 05AED368
	v_div_fixup_f32 v104, v104, v96, v97                       // 0000000FA934: D6270068 0586C168
	v_mad_i64_i32 v[96:97], null, 0x3000, v120, v[128:129]     // 0000000FA93C: D6FF7C60 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA948: BF870092
	v_bfe_u32 v105, v104, 16, 1                                // 0000000FA94C: D6100069 02052168
	v_add3_u32 v104, v104, v105, 0x7fff                        // 0000000FA954: D6550068 03FED368 00007FFF
	global_store_d16_hi_b16 v[96:97], v104, off offset:96      // 0000000FA960: DC960060 007C6860
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FA968: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000FA96C: BE882002
	s_cbranch_execz 63864                                      // 0000000FA970: BFA5F978 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3554>
	v_mad_i64_i32 v[96:97], null, 0x6000, v121, v[130:131]     // 0000000FA974: D6FF7C60 060AF2FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 0000000FA980: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 0000000FA988: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000000FA98C: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA990: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 0000000FA994: 10C2C0FF BFB8AA3B
	v_fma_f32 v104, 0xbfb8aa3b, v96, -v97                      // 0000000FA99C: D6130068 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v105, v97                                  // 0000000FA9A8: 7ED24761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FA9AC: BF870221
	v_sub_f32_e32 v97, v97, v105                               // 0000000FA9B0: 08C2D361
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000000FA9B4: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v104, v96, 0xb2a5705f, v104                    // 0000000FA9BC: 58D0D160 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FA9C4: BF870121
	v_add_f32_e32 v97, v97, v104                               // 0000000FA9C8: 06C2D161
	v_cvt_i32_f32_e32 v104, v105                               // 0000000FA9CC: 7ED01169
	v_exp_f32_e32 v97, v97                                     // 0000000FA9D0: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA9D4: BF870095
	.long 0xd71c0061                                           // 0000000FA9D8: D71C0061
	v_cndmask_b32_e32 v1, v97, v104, vcc_lo                    // 0000000FA9DC: 0202D161
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000FA9E0: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 0000000FA9E4: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA9EC: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v136, v98// 0000000FA9F0: CA46C2FF 6060C588 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 0000000FA9FC: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAA00: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 0000000FAA04: D6FC7C62 0586C160
	v_rcp_f32_e32 v104, v98                                    // 0000000FAA0C: 7ED05562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAA10: BF870095
	v_fma_f32 v105, -v98, v104, 1.0                            // 0000000FAA14: D6130069 23CAD162
	v_fmac_f32_e32 v104, v105, v104                            // 0000000FAA1C: 56D0D169
	v_div_scale_f32 v105, vcc_lo, v97, v96, v97                // 0000000FAA20: D6FC6A69 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAA28: BF870091
	v_mul_f32_e32 v106, v105, v104                             // 0000000FAA2C: 10D4D169
	v_fma_f32 v107, -v98, v106, v105                           // 0000000FAA30: D613006B 25A6D562
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAA38: BF870091
	v_fmac_f32_e32 v106, v107, v104                            // 0000000FAA3C: 56D4D16B
	v_fma_f32 v98, -v98, v106, v105                            // 0000000FAA40: D6130062 25A6D562
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAA48: BF870091
	v_div_fmas_f32 v98, v98, v104, v106                        // 0000000FAA4C: D6370062 05AAD162
	v_div_fixup_f32 v98, v98, v96, v97                         // 0000000FAA54: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v121, v[128:129]     // 0000000FAA5C: D6FF7C60 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAA68: BF870092
	v_bfe_u32 v104, v98, 16, 1                                 // 0000000FAA6C: D6100068 02052162
	v_add3_u32 v98, v98, v104, 0x7fff                          // 0000000FAA74: D6550062 03FED162 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 0000000FAA80: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FAA88: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000FAA8C: BE882003
	s_cbranch_execz 63795                                      // 0000000FAA90: BFA5F933 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3560>
	v_mad_i64_i32 v[96:97], null, 0x6000, v122, v[130:131]     // 0000000FAA94: D6FF7C60 060AF4FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 0000000FAAA0: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 0000000FAAA8: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000000FAAAC: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAAB0: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 0000000FAAB4: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 0000000FAABC: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v104, v97                                  // 0000000FAAC8: 7ED04761
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAACC: BF870091
	v_dual_fmamk_f32 v98, v96, 0xb2a5705f, v98 :: v_dual_sub_f32 v97, v97, v104// 0000000FAAD0: C88AC560 6260D161 B2A5705F
	v_add_f32_e32 v97, v97, v98                                // 0000000FAADC: 06C2C561
	v_cvt_i32_f32_e32 v98, v104                                // 0000000FAAE0: 7EC41168
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000000FAAE4: 7C3CC0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FAAEC: BF870293
	v_exp_f32_e32 v97, v97                                     // 0000000FAAF0: 7EC24B61
	.long 0xd71c0061                                           // 0000000FAAF4: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000000FAAF8: 0202C561
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FAAFC: BF870121
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000FAB00: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 0000000FAB04: 7C36C0FF C2B17218
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v137, v99// 0000000FAB0C: CA46C2FF 6060C789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAB18: BF870091
	v_add_f32_e32 v96, 1.0, v96                                // 0000000FAB1C: 06C0C0F2
	v_div_scale_f32 v98, null, v96, v96, v97                   // 0000000FAB20: D6FC7C62 0586C160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FAB28: BF870291
	v_rcp_f32_e32 v99, v98                                     // 0000000FAB2C: 7EC65562
	v_fma_f32 v104, -v98, v99, 1.0                             // 0000000FAB30: D6130068 23CAC762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FAB38: BF8700A1
	v_fmac_f32_e32 v99, v104, v99                              // 0000000FAB3C: 56C6C768
	v_div_scale_f32 v104, vcc_lo, v97, v96, v97                // 0000000FAB40: D6FC6A68 0586C161
	v_mul_f32_e32 v105, v104, v99                              // 0000000FAB48: 10D2C768
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAB4C: BF870091
	v_fma_f32 v106, -v98, v105, v104                           // 0000000FAB50: D613006A 25A2D362
	v_fmac_f32_e32 v105, v106, v99                             // 0000000FAB58: 56D2C76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAB5C: BF870091
	v_fma_f32 v98, -v98, v105, v104                            // 0000000FAB60: D6130062 25A2D362
	v_div_fmas_f32 v98, v98, v99, v105                         // 0000000FAB68: D6370062 05A6C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FAB70: BF870121
	v_div_fixup_f32 v98, v98, v96, v97                         // 0000000FAB74: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v122, v[128:129]     // 0000000FAB7C: D6FF7C60 0602F4FF 00003000
	v_bfe_u32 v99, v98, 16, 1                                  // 0000000FAB88: D6100063 02052162
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FAB90: BF870001
	v_add3_u32 v98, v98, v99, 0x7fff                           // 0000000FAB94: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 0000000FABA0: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FABA8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000FABAC: BE882004
	s_cbranch_execz 63726                                      // 0000000FABB0: BFA5F8EE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x356c>
	v_mad_i64_i32 v[96:97], null, 0x6000, v123, v[130:131]     // 0000000FABB4: D6FF7C60 060AF6FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 0000000FABC0: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 0000000FABC8: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000000FABCC: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FABD0: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 0000000FABD4: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 0000000FABDC: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000000FABE8: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FABEC: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 0000000FABF0: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000000FABF4: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 0000000FABFC: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FAC04: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000000FAC08: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000000FAC0C: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000000FAC10: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAC14: BF870095
	.long 0xd71c0061                                           // 0000000FAC18: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000000FAC1C: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000FAC20: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 0000000FAC24: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAC2C: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v134, v100// 0000000FAC30: CA46C2FF 6060C986 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 0000000FAC3C: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAC40: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 0000000FAC44: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 0000000FAC4C: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAC50: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000000FAC54: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 0000000FAC5C: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 0000000FAC60: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAC68: BF870091
	v_mul_f32_e32 v104, v100, v99                              // 0000000FAC6C: 10D0C764
	v_fma_f32 v105, -v98, v104, v100                           // 0000000FAC70: D6130069 2592D162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAC78: BF870091
	v_fmac_f32_e32 v104, v105, v99                             // 0000000FAC7C: 56D0C769
	v_fma_f32 v98, -v98, v104, v100                            // 0000000FAC80: D6130062 2592D162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAC88: BF870091
	v_div_fmas_f32 v98, v98, v99, v104                         // 0000000FAC8C: D6370062 05A2C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 0000000FAC94: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v123, v[128:129]     // 0000000FAC9C: D6FF7C60 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FACA8: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 0000000FACAC: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 0000000FACB4: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 0000000FACC0: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FACC8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000FACCC: BE882005
	s_cbranch_execz 63657                                      // 0000000FACD0: BFA5F8A9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3578>
	v_mad_i64_i32 v[96:97], null, 0x6000, v124, v[130:131]     // 0000000FACD4: D6FF7C60 060AF8FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 0000000FACE0: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 0000000FACE8: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000000FACEC: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FACF0: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 0000000FACF4: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 0000000FACFC: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000000FAD08: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FAD0C: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 0000000FAD10: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000000FAD14: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 0000000FAD1C: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FAD24: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000000FAD28: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000000FAD2C: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000000FAD30: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAD34: BF870095
	.long 0xd71c0061                                           // 0000000FAD38: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000000FAD3C: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000FAD40: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 0000000FAD44: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAD4C: BF870092
	v_cndmask_b32_e32 v96, 0x7f800000, v97, vcc_lo             // 0000000FAD50: 02C0C2FF 7F800000
	v_dual_mul_f32 v97, v135, v101 :: v_dual_add_f32 v96, 1.0, v96// 0000000FAD58: C8C8CB87 6160C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAD60: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 0000000FAD64: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 0000000FAD6C: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAD70: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000000FAD74: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 0000000FAD7C: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 0000000FAD80: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAD88: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 0000000FAD8C: 10CAC764
	v_fma_f32 v104, -v98, v101, v100                           // 0000000FAD90: D6130068 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAD98: BF870091
	v_fmac_f32_e32 v101, v104, v99                             // 0000000FAD9C: 56CAC768
	v_fma_f32 v98, -v98, v101, v100                            // 0000000FADA0: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FADA8: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 0000000FADAC: D6370062 0596C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 0000000FADB4: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v124, v[128:129]     // 0000000FADBC: D6FF7C60 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FADC8: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 0000000FADCC: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 0000000FADD4: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 0000000FADE0: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FADE8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000FADEC: BE882006
	s_cbranch_execz 63588                                      // 0000000FADF0: BFA5F864 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3584>
	v_mad_i64_i32 v[96:97], null, 0x6000, v125, v[130:131]     // 0000000FADF4: D6FF7C60 060AFAFF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 0000000FAE00: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 0000000FAE08: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000000FAE0C: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAE10: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 0000000FAE14: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 0000000FAE1C: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000000FAE28: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FAE2C: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 0000000FAE30: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000000FAE34: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 0000000FAE3C: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FAE44: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000000FAE48: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000000FAE4C: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000000FAE50: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAE54: BF870095
	.long 0xd71c0061                                           // 0000000FAE58: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000000FAE5C: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000FAE60: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 0000000FAE64: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAE6C: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v132, v102// 0000000FAE70: CA46C2FF 6060CD84 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 0000000FAE7C: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAE80: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 0000000FAE84: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 0000000FAE8C: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAE90: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000000FAE94: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 0000000FAE9C: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 0000000FAEA0: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAEA8: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 0000000FAEAC: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 0000000FAEB0: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAEB8: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 0000000FAEBC: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 0000000FAEC0: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAEC8: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 0000000FAECC: D6370062 0596C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 0000000FAED4: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v125, v[128:129]     // 0000000FAEDC: D6FF7C60 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAEE8: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 0000000FAEEC: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 0000000FAEF4: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 0000000FAF00: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FAF08: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000FAF0C: BE882007
	s_cbranch_execz 63519                                      // 0000000FAF10: BFA5F81F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3590>
	v_mad_i64_i32 v[96:97], null, 0x6000, v126, v[130:131]     // 0000000FAF14: D6FF7C60 060AFCFF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 0000000FAF20: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 0000000FAF28: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000000FAF2C: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAF30: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 0000000FAF34: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 0000000FAF3C: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000000FAF48: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FAF4C: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 0000000FAF50: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000000FAF54: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 0000000FAF5C: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FAF64: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000000FAF68: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000000FAF6C: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000000FAF70: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAF74: BF870095
	.long 0xd71c0061                                           // 0000000FAF78: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000000FAF7C: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000FAF80: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 0000000FAF84: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAF8C: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v133, v103// 0000000FAF90: CA46C2FF 6060CF85 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 0000000FAF9C: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAFA0: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 0000000FAFA4: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 0000000FAFAC: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAFB0: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000000FAFB4: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 0000000FAFBC: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 0000000FAFC0: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAFC8: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 0000000FAFCC: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 0000000FAFD0: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAFD8: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 0000000FAFDC: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 0000000FAFE0: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAFE8: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 0000000FAFEC: D6370062 0596C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 0000000FAFF4: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v126, v[128:129]     // 0000000FAFFC: D6FF7C60 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB008: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 0000000FB00C: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 0000000FB014: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 0000000FB020: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FB028: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000FB02C: BE882000
	s_cbranch_execz 63450                                      // 0000000FB030: BFA5F7DA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x359c>
	v_mad_i64_i32 v[96:97], null, 0x6000, v140, v[130:131]     // 0000000FB034: D6FF7C60 060B18FF 00006000
	v_mul_f32_e32 v88, v138, v88                               // 0000000FB040: 10B0B18A
	global_load_u16 v96, v[96:97], off offset:640              // 0000000FB044: DC4A0280 607C0060
	s_waitcnt vmcnt(0)                                         // 0000000FB04C: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000000FB050: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB054: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 0000000FB058: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 0000000FB060: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000000FB06C: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FB070: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 0000000FB074: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000000FB078: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 0000000FB080: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FB088: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000000FB08C: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000000FB090: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000000FB094: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB098: BF870095
	.long 0xd71c0061                                           // 0000000FB09C: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000000FB0A0: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000FB0A4: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 0000000FB0A8: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB0B0: BF870092
	v_cndmask_b32_e32 v96, 0x7f800000, v97, vcc_lo             // 0000000FB0B4: 02C0C2FF 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 0000000FB0BC: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB0C0: BF870091
	v_div_scale_f32 v97, null, v96, v96, v88                   // 0000000FB0C4: D6FC7C61 0562C160
	v_rcp_f32_e32 v98, v97                                     // 0000000FB0CC: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB0D0: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 0000000FB0D4: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 0000000FB0DC: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v88, v96, v88                 // 0000000FB0E0: D6FC6A63 0562C158
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB0E8: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 0000000FB0EC: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 0000000FB0F0: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB0F8: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 0000000FB0FC: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 0000000FB100: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB108: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 0000000FB10C: D6370061 0592C561
	v_div_fixup_f32 v88, v97, v96, v88                         // 0000000FB114: D6270058 0562C161
	v_mad_i64_i32 v[96:97], null, 0x3000, v140, v[128:129]     // 0000000FB11C: D6FF7C60 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB128: BF870092
	v_bfe_u32 v98, v88, 16, 1                                  // 0000000FB12C: D6100062 02052158
	v_add3_u32 v88, v88, v98, 0x7fff                           // 0000000FB134: D6550058 03FEC558 00007FFF
	global_store_d16_hi_b16 v[96:97], v88, off offset:128      // 0000000FB140: DC960080 007C5860
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FB148: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000FB14C: BE882001
	s_cbranch_execz 63381                                      // 0000000FB150: BFA5F795 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35a8>
	v_mad_i64_i32 v[96:97], null, 0x6000, v120, v[130:131]     // 0000000FB154: D6FF7C60 060AF0FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 0000000FB160: 10B2B38B
	global_load_u16 v88, v[96:97], off offset:640              // 0000000FB164: DC4A0280 587C0060
	s_waitcnt vmcnt(0)                                         // 0000000FB16C: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 0000000FB170: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FB174: BF870121
	v_mul_f32_e32 v96, 0xbfb8aa3b, v88                         // 0000000FB178: 10C0B0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 0000000FB180: 7C3CB0FF 42CE8ED0
	v_fma_f32 v97, 0xbfb8aa3b, v88, -v96                       // 0000000FB188: D6130061 8582B0FF BFB8AA3B
	v_rndne_f32_e32 v98, v96                                   // 0000000FB194: 7EC44760
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FB198: BF870112
	v_fmamk_f32 v97, v88, 0xb2a5705f, v97                      // 0000000FB19C: 58C2C358 B2A5705F
	v_sub_f32_e32 v96, v96, v98                                // 0000000FB1A4: 08C0C560
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FB1A8: BF870121
	v_add_f32_e32 v96, v96, v97                                // 0000000FB1AC: 06C0C360
	v_cvt_i32_f32_e32 v97, v98                                 // 0000000FB1B0: 7EC21162
	v_exp_f32_e32 v96, v96                                     // 0000000FB1B4: 7EC04B60
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB1B8: BF870095
	.long 0xd71c0060                                           // 0000000FB1BC: D71C0060
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                     // 0000000FB1C0: 0202C360
	v_cndmask_b32_e32 v96, 0, v96, vcc_lo                      // 0000000FB1C4: 02C0C080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 0000000FB1C8: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB1D0: BF870092
	v_cndmask_b32_e32 v88, 0x7f800000, v96, vcc_lo             // 0000000FB1D4: 02B0C0FF 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 0000000FB1DC: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB1E0: BF870091
	v_div_scale_f32 v96, null, v88, v88, v89                   // 0000000FB1E4: D6FC7C60 0566B158
	v_rcp_f32_e32 v97, v96                                     // 0000000FB1EC: 7EC25560
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB1F0: BF870095
	v_fma_f32 v98, -v96, v97, 1.0                              // 0000000FB1F4: D6130062 23CAC360
	v_fmac_f32_e32 v97, v98, v97                               // 0000000FB1FC: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v89, v88, v89                 // 0000000FB200: D6FC6A62 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB208: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 0000000FB20C: 10C6C362
	v_fma_f32 v100, -v96, v99, v98                             // 0000000FB210: D6130064 258AC760
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB218: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 0000000FB21C: 56C6C364
	v_fma_f32 v96, -v96, v99, v98                              // 0000000FB220: D6130060 258AC760
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB228: BF870091
	v_div_fmas_f32 v96, v96, v97, v99                          // 0000000FB22C: D6370060 058EC360
	v_div_fixup_f32 v96, v96, v88, v89                         // 0000000FB234: D6270060 0566B160
	v_mad_i64_i32 v[88:89], null, 0x3000, v120, v[128:129]     // 0000000FB23C: D6FF7C58 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB248: BF870092
	v_bfe_u32 v97, v96, 16, 1                                  // 0000000FB24C: D6100061 02052160
	v_add3_u32 v96, v96, v97, 0x7fff                           // 0000000FB254: D6550060 03FEC360 00007FFF
	global_store_d16_hi_b16 v[88:89], v96, off offset:128      // 0000000FB260: DC960080 007C6058
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FB268: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000FB26C: BE882002
	s_cbranch_execz 63312                                      // 0000000FB270: BFA5F750 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35b4>
	v_mad_i64_i32 v[88:89], null, 0x6000, v121, v[130:131]     // 0000000FB274: D6FF7C58 060AF2FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 0000000FB280: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 0000000FB288: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 0000000FB28C: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB290: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 0000000FB294: 10B2B0FF BFB8AA3B
	v_fma_f32 v96, 0xbfb8aa3b, v88, -v89                       // 0000000FB29C: D6130060 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v97, v89                                   // 0000000FB2A8: 7EC24759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FB2AC: BF870221
	v_sub_f32_e32 v89, v89, v97                                // 0000000FB2B0: 08B2C359
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 0000000FB2B4: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v96, v88, 0xb2a5705f, v96                      // 0000000FB2BC: 58C0C158 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FB2C4: BF870121
	v_add_f32_e32 v89, v89, v96                                // 0000000FB2C8: 06B2C159
	v_cvt_i32_f32_e32 v96, v97                                 // 0000000FB2CC: 7EC01161
	v_exp_f32_e32 v89, v89                                     // 0000000FB2D0: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB2D4: BF870095
	.long 0xd71c0059                                           // 0000000FB2D8: D71C0059
	v_cndmask_b32_e32 v1, v89, v96, vcc_lo                     // 0000000FB2DC: 0202C159
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000FB2E0: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 0000000FB2E4: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB2EC: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v136, v90// 0000000FB2F0: CA46B2FF 5858B588 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 0000000FB2FC: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB300: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 0000000FB304: D6FC7C5A 0566B158
	v_rcp_f32_e32 v96, v90                                     // 0000000FB30C: 7EC0555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB310: BF870095
	v_fma_f32 v97, -v90, v96, 1.0                              // 0000000FB314: D6130061 23CAC15A
	v_fmac_f32_e32 v96, v97, v96                               // 0000000FB31C: 56C0C161
	v_div_scale_f32 v97, vcc_lo, v89, v88, v89                 // 0000000FB320: D6FC6A61 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB328: BF870091
	v_mul_f32_e32 v98, v97, v96                                // 0000000FB32C: 10C4C161
	v_fma_f32 v99, -v90, v98, v97                              // 0000000FB330: D6130063 2586C55A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB338: BF870091
	v_fmac_f32_e32 v98, v99, v96                               // 0000000FB33C: 56C4C163
	v_fma_f32 v90, -v90, v98, v97                              // 0000000FB340: D613005A 2586C55A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB348: BF870091
	v_div_fmas_f32 v90, v90, v96, v98                          // 0000000FB34C: D637005A 058AC15A
	v_div_fixup_f32 v90, v90, v88, v89                         // 0000000FB354: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v121, v[128:129]     // 0000000FB35C: D6FF7C58 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB368: BF870092
	v_bfe_u32 v96, v90, 16, 1                                  // 0000000FB36C: D6100060 0205215A
	v_add3_u32 v90, v90, v96, 0x7fff                           // 0000000FB374: D655005A 03FEC15A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 0000000FB380: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FB388: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000FB38C: BE882003
	s_cbranch_execz 63243                                      // 0000000FB390: BFA5F70B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35c0>
	v_mad_i64_i32 v[88:89], null, 0x6000, v122, v[130:131]     // 0000000FB394: D6FF7C58 060AF4FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 0000000FB3A0: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 0000000FB3A8: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 0000000FB3AC: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB3B0: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 0000000FB3B4: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 0000000FB3BC: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v96, v89                                   // 0000000FB3C8: 7EC04759
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB3CC: BF870091
	v_dual_fmamk_f32 v90, v88, 0xb2a5705f, v90 :: v_dual_sub_f32 v89, v89, v96// 0000000FB3D0: C88AB558 5A58C159 B2A5705F
	v_add_f32_e32 v89, v89, v90                                // 0000000FB3DC: 06B2B559
	v_cvt_i32_f32_e32 v90, v96                                 // 0000000FB3E0: 7EB41160
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 0000000FB3E4: 7C3CB0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FB3EC: BF870293
	v_exp_f32_e32 v89, v89                                     // 0000000FB3F0: 7EB24B59
	.long 0xd71c0059                                           // 0000000FB3F4: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000000FB3F8: 0202B559
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FB3FC: BF870121
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000FB400: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 0000000FB404: 7C36B0FF C2B17218
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v137, v91// 0000000FB40C: CA46B2FF 5858B789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB418: BF870091
	v_add_f32_e32 v88, 1.0, v88                                // 0000000FB41C: 06B0B0F2
	v_div_scale_f32 v90, null, v88, v88, v89                   // 0000000FB420: D6FC7C5A 0566B158
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FB428: BF870291
	v_rcp_f32_e32 v91, v90                                     // 0000000FB42C: 7EB6555A
	v_fma_f32 v96, -v90, v91, 1.0                              // 0000000FB430: D6130060 23CAB75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FB438: BF8700A1
	v_fmac_f32_e32 v91, v96, v91                               // 0000000FB43C: 56B6B760
	v_div_scale_f32 v96, vcc_lo, v89, v88, v89                 // 0000000FB440: D6FC6A60 0566B159
	v_mul_f32_e32 v97, v96, v91                                // 0000000FB448: 10C2B760
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB44C: BF870091
	v_fma_f32 v98, -v90, v97, v96                              // 0000000FB450: D6130062 2582C35A
	v_fmac_f32_e32 v97, v98, v91                               // 0000000FB458: 56C2B762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB45C: BF870091
	v_fma_f32 v90, -v90, v97, v96                              // 0000000FB460: D613005A 2582C35A
	v_div_fmas_f32 v90, v90, v91, v97                          // 0000000FB468: D637005A 0586B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FB470: BF870121
	v_div_fixup_f32 v90, v90, v88, v89                         // 0000000FB474: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v122, v[128:129]     // 0000000FB47C: D6FF7C58 0602F4FF 00003000
	v_bfe_u32 v91, v90, 16, 1                                  // 0000000FB488: D610005B 0205215A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FB490: BF870001
	v_add3_u32 v90, v90, v91, 0x7fff                           // 0000000FB494: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 0000000FB4A0: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FB4A8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000FB4AC: BE882004
	s_cbranch_execz 63174                                      // 0000000FB4B0: BFA5F6C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35cc>
	v_mad_i64_i32 v[88:89], null, 0x6000, v123, v[130:131]     // 0000000FB4B4: D6FF7C58 060AF6FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 0000000FB4C0: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 0000000FB4C8: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 0000000FB4CC: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB4D0: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 0000000FB4D4: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 0000000FB4DC: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000000FB4E8: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FB4EC: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 0000000FB4F0: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 0000000FB4F4: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 0000000FB4FC: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FB504: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000000FB508: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000000FB50C: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000000FB510: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB514: BF870095
	.long 0xd71c0059                                           // 0000000FB518: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000000FB51C: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000FB520: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 0000000FB524: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB52C: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v134, v92// 0000000FB530: CA46B2FF 5858B986 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 0000000FB53C: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB540: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 0000000FB544: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 0000000FB54C: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB550: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 0000000FB554: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 0000000FB55C: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 0000000FB560: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB568: BF870091
	v_mul_f32_e32 v96, v92, v91                                // 0000000FB56C: 10C0B75C
	v_fma_f32 v97, -v90, v96, v92                              // 0000000FB570: D6130061 2572C15A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB578: BF870091
	v_fmac_f32_e32 v96, v97, v91                               // 0000000FB57C: 56C0B761
	v_fma_f32 v90, -v90, v96, v92                              // 0000000FB580: D613005A 2572C15A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB588: BF870091
	v_div_fmas_f32 v90, v90, v91, v96                          // 0000000FB58C: D637005A 0582B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 0000000FB594: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v123, v[128:129]     // 0000000FB59C: D6FF7C58 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB5A8: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 0000000FB5AC: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 0000000FB5B4: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 0000000FB5C0: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FB5C8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000FB5CC: BE882005
	s_cbranch_execz 63105                                      // 0000000FB5D0: BFA5F681 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35d8>
	v_mad_i64_i32 v[88:89], null, 0x6000, v124, v[130:131]     // 0000000FB5D4: D6FF7C58 060AF8FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 0000000FB5E0: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 0000000FB5E8: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 0000000FB5EC: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB5F0: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 0000000FB5F4: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 0000000FB5FC: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000000FB608: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FB60C: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 0000000FB610: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 0000000FB614: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 0000000FB61C: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FB624: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000000FB628: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000000FB62C: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000000FB630: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB634: BF870095
	.long 0xd71c0059                                           // 0000000FB638: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000000FB63C: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000FB640: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 0000000FB644: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB64C: BF870092
	v_cndmask_b32_e32 v88, 0x7f800000, v89, vcc_lo             // 0000000FB650: 02B0B2FF 7F800000
	v_dual_mul_f32 v89, v135, v93 :: v_dual_add_f32 v88, 1.0, v88// 0000000FB658: C8C8BB87 5958B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB660: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 0000000FB664: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 0000000FB66C: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB670: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 0000000FB674: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 0000000FB67C: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 0000000FB680: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB688: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 0000000FB68C: 10BAB75C
	v_fma_f32 v96, -v90, v93, v92                              // 0000000FB690: D6130060 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB698: BF870091
	v_fmac_f32_e32 v93, v96, v91                               // 0000000FB69C: 56BAB760
	v_fma_f32 v90, -v90, v93, v92                              // 0000000FB6A0: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB6A8: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 0000000FB6AC: D637005A 0576B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 0000000FB6B4: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v124, v[128:129]     // 0000000FB6BC: D6FF7C58 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB6C8: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 0000000FB6CC: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 0000000FB6D4: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 0000000FB6E0: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FB6E8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000FB6EC: BE882006
	s_cbranch_execz 63036                                      // 0000000FB6F0: BFA5F63C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35e4>
	v_mad_i64_i32 v[88:89], null, 0x6000, v125, v[130:131]     // 0000000FB6F4: D6FF7C58 060AFAFF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 0000000FB700: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 0000000FB708: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 0000000FB70C: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB710: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 0000000FB714: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 0000000FB71C: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000000FB728: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FB72C: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 0000000FB730: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 0000000FB734: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 0000000FB73C: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FB744: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000000FB748: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000000FB74C: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000000FB750: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB754: BF870095
	.long 0xd71c0059                                           // 0000000FB758: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000000FB75C: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000FB760: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 0000000FB764: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB76C: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v132, v94// 0000000FB770: CA46B2FF 5858BD84 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 0000000FB77C: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB780: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 0000000FB784: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 0000000FB78C: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB790: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 0000000FB794: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 0000000FB79C: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 0000000FB7A0: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB7A8: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 0000000FB7AC: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 0000000FB7B0: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB7B8: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 0000000FB7BC: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 0000000FB7C0: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB7C8: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 0000000FB7CC: D637005A 0576B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 0000000FB7D4: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v125, v[128:129]     // 0000000FB7DC: D6FF7C58 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB7E8: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 0000000FB7EC: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 0000000FB7F4: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 0000000FB800: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FB808: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000FB80C: BE882007
	s_cbranch_execz 62967                                      // 0000000FB810: BFA5F5F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35f0>
	v_mad_i64_i32 v[88:89], null, 0x6000, v126, v[130:131]     // 0000000FB814: D6FF7C58 060AFCFF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 0000000FB820: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 0000000FB828: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 0000000FB82C: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB830: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 0000000FB834: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 0000000FB83C: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000000FB848: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FB84C: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 0000000FB850: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 0000000FB854: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 0000000FB85C: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FB864: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000000FB868: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000000FB86C: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000000FB870: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB874: BF870095
	.long 0xd71c0059                                           // 0000000FB878: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000000FB87C: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000FB880: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 0000000FB884: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB88C: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v133, v95// 0000000FB890: CA46B2FF 5858BF85 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 0000000FB89C: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB8A0: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 0000000FB8A4: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 0000000FB8AC: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB8B0: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 0000000FB8B4: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 0000000FB8BC: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 0000000FB8C0: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB8C8: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 0000000FB8CC: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 0000000FB8D0: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB8D8: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 0000000FB8DC: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 0000000FB8E0: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB8E8: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 0000000FB8EC: D637005A 0576B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 0000000FB8F4: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v126, v[128:129]     // 0000000FB8FC: D6FF7C58 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB908: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 0000000FB90C: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 0000000FB914: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 0000000FB920: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FB928: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000FB92C: BE882000
	s_cbranch_execz 62898                                      // 0000000FB930: BFA5F5B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35fc>
	v_mad_i64_i32 v[88:89], null, 0x6000, v140, v[130:131]     // 0000000FB934: D6FF7C58 060B18FF 00006000
	v_mul_f32_e32 v80, v138, v80                               // 0000000FB940: 10A0A18A
	global_load_u16 v88, v[88:89], off offset:672              // 0000000FB944: DC4A02A0 587C0058
	s_waitcnt vmcnt(0)                                         // 0000000FB94C: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 0000000FB950: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB954: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 0000000FB958: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 0000000FB960: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000000FB96C: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FB970: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 0000000FB974: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 0000000FB978: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 0000000FB980: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FB988: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000000FB98C: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000000FB990: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000000FB994: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB998: BF870095
	.long 0xd71c0059                                           // 0000000FB99C: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000000FB9A0: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000FB9A4: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 0000000FB9A8: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB9B0: BF870092
	v_cndmask_b32_e32 v88, 0x7f800000, v89, vcc_lo             // 0000000FB9B4: 02B0B2FF 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 0000000FB9BC: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB9C0: BF870091
	v_div_scale_f32 v89, null, v88, v88, v80                   // 0000000FB9C4: D6FC7C59 0542B158
	v_rcp_f32_e32 v90, v89                                     // 0000000FB9CC: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB9D0: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 0000000FB9D4: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 0000000FB9DC: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v80, v88, v80                 // 0000000FB9E0: D6FC6A5B 0542B150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB9E8: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 0000000FB9EC: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 0000000FB9F0: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB9F8: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 0000000FB9FC: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 0000000FBA00: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBA08: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 0000000FBA0C: D6370059 0572B559
	v_div_fixup_f32 v80, v89, v88, v80                         // 0000000FBA14: D6270050 0542B159
	v_mad_i64_i32 v[88:89], null, 0x3000, v140, v[128:129]     // 0000000FBA1C: D6FF7C58 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBA28: BF870092
	v_bfe_u32 v90, v80, 16, 1                                  // 0000000FBA2C: D610005A 02052150
	v_add3_u32 v80, v80, v90, 0x7fff                           // 0000000FBA34: D6550050 03FEB550 00007FFF
	global_store_d16_hi_b16 v[88:89], v80, off offset:160      // 0000000FBA40: DC9600A0 007C5058
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FBA48: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000FBA4C: BE882001
	s_cbranch_execz 62829                                      // 0000000FBA50: BFA5F56D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3608>
	v_mad_i64_i32 v[88:89], null, 0x6000, v120, v[130:131]     // 0000000FBA54: D6FF7C58 060AF0FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 0000000FBA60: 10A2A38B
	global_load_u16 v80, v[88:89], off offset:672              // 0000000FBA64: DC4A02A0 507C0058
	s_waitcnt vmcnt(0)                                         // 0000000FBA6C: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 0000000FBA70: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FBA74: BF870121
	v_mul_f32_e32 v88, 0xbfb8aa3b, v80                         // 0000000FBA78: 10B0A0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 0000000FBA80: 7C3CA0FF 42CE8ED0
	v_fma_f32 v89, 0xbfb8aa3b, v80, -v88                       // 0000000FBA88: D6130059 8562A0FF BFB8AA3B
	v_rndne_f32_e32 v90, v88                                   // 0000000FBA94: 7EB44758
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FBA98: BF870112
	v_fmamk_f32 v89, v80, 0xb2a5705f, v89                      // 0000000FBA9C: 58B2B350 B2A5705F
	v_sub_f32_e32 v88, v88, v90                                // 0000000FBAA4: 08B0B558
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FBAA8: BF870121
	v_add_f32_e32 v88, v88, v89                                // 0000000FBAAC: 06B0B358
	v_cvt_i32_f32_e32 v89, v90                                 // 0000000FBAB0: 7EB2115A
	v_exp_f32_e32 v88, v88                                     // 0000000FBAB4: 7EB04B58
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBAB8: BF870095
	.long 0xd71c0058                                           // 0000000FBABC: D71C0058
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                     // 0000000FBAC0: 0202B358
	v_cndmask_b32_e32 v88, 0, v88, vcc_lo                      // 0000000FBAC4: 02B0B080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 0000000FBAC8: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBAD0: BF870092
	v_cndmask_b32_e32 v80, 0x7f800000, v88, vcc_lo             // 0000000FBAD4: 02A0B0FF 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 0000000FBADC: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBAE0: BF870091
	v_div_scale_f32 v88, null, v80, v80, v81                   // 0000000FBAE4: D6FC7C58 0546A150
	v_rcp_f32_e32 v89, v88                                     // 0000000FBAEC: 7EB25558
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBAF0: BF870095
	v_fma_f32 v90, -v88, v89, 1.0                              // 0000000FBAF4: D613005A 23CAB358
	v_fmac_f32_e32 v89, v90, v89                               // 0000000FBAFC: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v81, v80, v81                 // 0000000FBB00: D6FC6A5A 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBB08: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 0000000FBB0C: 10B6B35A
	v_fma_f32 v92, -v88, v91, v90                              // 0000000FBB10: D613005C 256AB758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBB18: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 0000000FBB1C: 56B6B35C
	v_fma_f32 v88, -v88, v91, v90                              // 0000000FBB20: D6130058 256AB758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBB28: BF870091
	v_div_fmas_f32 v88, v88, v89, v91                          // 0000000FBB2C: D6370058 056EB358
	v_div_fixup_f32 v88, v88, v80, v81                         // 0000000FBB34: D6270058 0546A158
	v_mad_i64_i32 v[80:81], null, 0x3000, v120, v[128:129]     // 0000000FBB3C: D6FF7C50 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBB48: BF870092
	v_bfe_u32 v89, v88, 16, 1                                  // 0000000FBB4C: D6100059 02052158
	v_add3_u32 v88, v88, v89, 0x7fff                           // 0000000FBB54: D6550058 03FEB358 00007FFF
	global_store_d16_hi_b16 v[80:81], v88, off offset:160      // 0000000FBB60: DC9600A0 007C5850
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FBB68: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000FBB6C: BE882002
	s_cbranch_execz 62760                                      // 0000000FBB70: BFA5F528 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3614>
	v_mad_i64_i32 v[80:81], null, 0x6000, v121, v[130:131]     // 0000000FBB74: D6FF7C50 060AF2FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 0000000FBB80: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 0000000FBB88: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 0000000FBB8C: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBB90: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 0000000FBB94: 10A2A0FF BFB8AA3B
	v_fma_f32 v88, 0xbfb8aa3b, v80, -v81                       // 0000000FBB9C: D6130058 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v89, v81                                   // 0000000FBBA8: 7EB24751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FBBAC: BF870221
	v_sub_f32_e32 v81, v81, v89                                // 0000000FBBB0: 08A2B351
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 0000000FBBB4: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v88, v80, 0xb2a5705f, v88                      // 0000000FBBBC: 58B0B150 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FBBC4: BF870121
	v_add_f32_e32 v81, v81, v88                                // 0000000FBBC8: 06A2B151
	v_cvt_i32_f32_e32 v88, v89                                 // 0000000FBBCC: 7EB01159
	v_exp_f32_e32 v81, v81                                     // 0000000FBBD0: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBBD4: BF870095
	.long 0xd71c0051                                           // 0000000FBBD8: D71C0051
	v_cndmask_b32_e32 v1, v81, v88, vcc_lo                     // 0000000FBBDC: 0202B151
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000FBBE0: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 0000000FBBE4: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBBEC: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v136, v82// 0000000FBBF0: CA46A2FF 5050A588 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 0000000FBBFC: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBC00: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 0000000FBC04: D6FC7C52 0546A150
	v_rcp_f32_e32 v88, v82                                     // 0000000FBC0C: 7EB05552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBC10: BF870095
	v_fma_f32 v89, -v82, v88, 1.0                              // 0000000FBC14: D6130059 23CAB152
	v_fmac_f32_e32 v88, v89, v88                               // 0000000FBC1C: 56B0B159
	v_div_scale_f32 v89, vcc_lo, v81, v80, v81                 // 0000000FBC20: D6FC6A59 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBC28: BF870091
	v_mul_f32_e32 v90, v89, v88                                // 0000000FBC2C: 10B4B159
	v_fma_f32 v91, -v82, v90, v89                              // 0000000FBC30: D613005B 2566B552
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBC38: BF870091
	v_fmac_f32_e32 v90, v91, v88                               // 0000000FBC3C: 56B4B15B
	v_fma_f32 v82, -v82, v90, v89                              // 0000000FBC40: D6130052 2566B552
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBC48: BF870091
	v_div_fmas_f32 v82, v82, v88, v90                          // 0000000FBC4C: D6370052 056AB152
	v_div_fixup_f32 v82, v82, v80, v81                         // 0000000FBC54: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v121, v[128:129]     // 0000000FBC5C: D6FF7C50 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBC68: BF870092
	v_bfe_u32 v88, v82, 16, 1                                  // 0000000FBC6C: D6100058 02052152
	v_add3_u32 v82, v82, v88, 0x7fff                           // 0000000FBC74: D6550052 03FEB152 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 0000000FBC80: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FBC88: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000FBC8C: BE882003
	s_cbranch_execz 62691                                      // 0000000FBC90: BFA5F4E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3620>
	v_mad_i64_i32 v[80:81], null, 0x6000, v122, v[130:131]     // 0000000FBC94: D6FF7C50 060AF4FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 0000000FBCA0: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 0000000FBCA8: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 0000000FBCAC: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBCB0: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 0000000FBCB4: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 0000000FBCBC: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v88, v81                                   // 0000000FBCC8: 7EB04751
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBCCC: BF870091
	v_dual_fmamk_f32 v82, v80, 0xb2a5705f, v82 :: v_dual_sub_f32 v81, v81, v88// 0000000FBCD0: C88AA550 5250B151 B2A5705F
	v_add_f32_e32 v81, v81, v82                                // 0000000FBCDC: 06A2A551
	v_cvt_i32_f32_e32 v82, v88                                 // 0000000FBCE0: 7EA41158
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 0000000FBCE4: 7C3CA0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FBCEC: BF870293
	v_exp_f32_e32 v81, v81                                     // 0000000FBCF0: 7EA24B51
	.long 0xd71c0051                                           // 0000000FBCF4: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000000FBCF8: 0202A551
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FBCFC: BF870121
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000FBD00: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 0000000FBD04: 7C36A0FF C2B17218
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v137, v83// 0000000FBD0C: CA46A2FF 5050A789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBD18: BF870091
	v_add_f32_e32 v80, 1.0, v80                                // 0000000FBD1C: 06A0A0F2
	v_div_scale_f32 v82, null, v80, v80, v81                   // 0000000FBD20: D6FC7C52 0546A150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FBD28: BF870291
	v_rcp_f32_e32 v83, v82                                     // 0000000FBD2C: 7EA65552
	v_fma_f32 v88, -v82, v83, 1.0                              // 0000000FBD30: D6130058 23CAA752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FBD38: BF8700A1
	v_fmac_f32_e32 v83, v88, v83                               // 0000000FBD3C: 56A6A758
	v_div_scale_f32 v88, vcc_lo, v81, v80, v81                 // 0000000FBD40: D6FC6A58 0546A151
	v_mul_f32_e32 v89, v88, v83                                // 0000000FBD48: 10B2A758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBD4C: BF870091
	v_fma_f32 v90, -v82, v89, v88                              // 0000000FBD50: D613005A 2562B352
	v_fmac_f32_e32 v89, v90, v83                               // 0000000FBD58: 56B2A75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBD5C: BF870091
	v_fma_f32 v82, -v82, v89, v88                              // 0000000FBD60: D6130052 2562B352
	v_div_fmas_f32 v82, v82, v83, v89                          // 0000000FBD68: D6370052 0566A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FBD70: BF870121
	v_div_fixup_f32 v82, v82, v80, v81                         // 0000000FBD74: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v122, v[128:129]     // 0000000FBD7C: D6FF7C50 0602F4FF 00003000
	v_bfe_u32 v83, v82, 16, 1                                  // 0000000FBD88: D6100053 02052152
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FBD90: BF870001
	v_add3_u32 v82, v82, v83, 0x7fff                           // 0000000FBD94: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 0000000FBDA0: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FBDA8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000FBDAC: BE882004
	s_cbranch_execz 62622                                      // 0000000FBDB0: BFA5F49E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x362c>
	v_mad_i64_i32 v[80:81], null, 0x6000, v123, v[130:131]     // 0000000FBDB4: D6FF7C50 060AF6FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 0000000FBDC0: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 0000000FBDC8: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 0000000FBDCC: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBDD0: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 0000000FBDD4: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 0000000FBDDC: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 0000000FBDE8: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FBDEC: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 0000000FBDF0: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 0000000FBDF4: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 0000000FBDFC: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FBE04: BF870121
	v_add_f32_e32 v81, v81, v82                                // 0000000FBE08: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 0000000FBE0C: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 0000000FBE10: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBE14: BF870095
	.long 0xd71c0051                                           // 0000000FBE18: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000000FBE1C: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000FBE20: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 0000000FBE24: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBE2C: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v134, v84// 0000000FBE30: CA46A2FF 5050A986 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 0000000FBE3C: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBE40: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 0000000FBE44: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 0000000FBE4C: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBE50: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 0000000FBE54: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 0000000FBE5C: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 0000000FBE60: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBE68: BF870091
	v_mul_f32_e32 v88, v84, v83                                // 0000000FBE6C: 10B0A754
	v_fma_f32 v89, -v82, v88, v84                              // 0000000FBE70: D6130059 2552B152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBE78: BF870091
	v_fmac_f32_e32 v88, v89, v83                               // 0000000FBE7C: 56B0A759
	v_fma_f32 v82, -v82, v88, v84                              // 0000000FBE80: D6130052 2552B152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBE88: BF870091
	v_div_fmas_f32 v82, v82, v83, v88                          // 0000000FBE8C: D6370052 0562A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 0000000FBE94: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v123, v[128:129]     // 0000000FBE9C: D6FF7C50 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBEA8: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 0000000FBEAC: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 0000000FBEB4: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 0000000FBEC0: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FBEC8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000FBECC: BE882005
	s_cbranch_execz 62553                                      // 0000000FBED0: BFA5F459 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3638>
	v_mad_i64_i32 v[80:81], null, 0x6000, v124, v[130:131]     // 0000000FBED4: D6FF7C50 060AF8FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 0000000FBEE0: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 0000000FBEE8: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 0000000FBEEC: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBEF0: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 0000000FBEF4: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 0000000FBEFC: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 0000000FBF08: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FBF0C: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 0000000FBF10: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 0000000FBF14: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 0000000FBF1C: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FBF24: BF870121
	v_add_f32_e32 v81, v81, v82                                // 0000000FBF28: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 0000000FBF2C: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 0000000FBF30: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBF34: BF870095
	.long 0xd71c0051                                           // 0000000FBF38: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000000FBF3C: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000FBF40: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 0000000FBF44: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBF4C: BF870092
	v_cndmask_b32_e32 v80, 0x7f800000, v81, vcc_lo             // 0000000FBF50: 02A0A2FF 7F800000
	v_dual_mul_f32 v81, v135, v85 :: v_dual_add_f32 v80, 1.0, v80// 0000000FBF58: C8C8AB87 5150A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBF60: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 0000000FBF64: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 0000000FBF6C: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBF70: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 0000000FBF74: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 0000000FBF7C: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 0000000FBF80: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBF88: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 0000000FBF8C: 10AAA754
	v_fma_f32 v88, -v82, v85, v84                              // 0000000FBF90: D6130058 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBF98: BF870091
	v_fmac_f32_e32 v85, v88, v83                               // 0000000FBF9C: 56AAA758
	v_fma_f32 v82, -v82, v85, v84                              // 0000000FBFA0: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBFA8: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 0000000FBFAC: D6370052 0556A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 0000000FBFB4: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v124, v[128:129]     // 0000000FBFBC: D6FF7C50 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBFC8: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 0000000FBFCC: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 0000000FBFD4: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 0000000FBFE0: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FBFE8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000FBFEC: BE882006
	s_cbranch_execz 62484                                      // 0000000FBFF0: BFA5F414 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3644>
	v_mad_i64_i32 v[80:81], null, 0x6000, v125, v[130:131]     // 0000000FBFF4: D6FF7C50 060AFAFF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 0000000FC000: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 0000000FC008: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 0000000FC00C: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC010: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 0000000FC014: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 0000000FC01C: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 0000000FC028: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FC02C: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 0000000FC030: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 0000000FC034: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 0000000FC03C: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC044: BF870121
	v_add_f32_e32 v81, v81, v82                                // 0000000FC048: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 0000000FC04C: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 0000000FC050: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC054: BF870095
	.long 0xd71c0051                                           // 0000000FC058: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000000FC05C: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000FC060: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 0000000FC064: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC06C: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v132, v86// 0000000FC070: CA46A2FF 5050AD84 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 0000000FC07C: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC080: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 0000000FC084: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 0000000FC08C: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC090: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 0000000FC094: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 0000000FC09C: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 0000000FC0A0: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC0A8: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 0000000FC0AC: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 0000000FC0B0: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC0B8: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 0000000FC0BC: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 0000000FC0C0: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC0C8: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 0000000FC0CC: D6370052 0556A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 0000000FC0D4: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v125, v[128:129]     // 0000000FC0DC: D6FF7C50 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC0E8: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 0000000FC0EC: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 0000000FC0F4: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 0000000FC100: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FC108: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000FC10C: BE882007
	s_cbranch_execz 62415                                      // 0000000FC110: BFA5F3CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3650>
	v_mad_i64_i32 v[80:81], null, 0x6000, v126, v[130:131]     // 0000000FC114: D6FF7C50 060AFCFF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 0000000FC120: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 0000000FC128: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 0000000FC12C: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC130: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 0000000FC134: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 0000000FC13C: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 0000000FC148: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FC14C: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 0000000FC150: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 0000000FC154: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 0000000FC15C: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC164: BF870121
	v_add_f32_e32 v81, v81, v82                                // 0000000FC168: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 0000000FC16C: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 0000000FC170: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC174: BF870095
	.long 0xd71c0051                                           // 0000000FC178: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000000FC17C: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000FC180: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 0000000FC184: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC18C: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v133, v87// 0000000FC190: CA46A2FF 5050AF85 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 0000000FC19C: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC1A0: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 0000000FC1A4: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 0000000FC1AC: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC1B0: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 0000000FC1B4: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 0000000FC1BC: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 0000000FC1C0: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC1C8: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 0000000FC1CC: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 0000000FC1D0: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC1D8: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 0000000FC1DC: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 0000000FC1E0: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC1E8: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 0000000FC1EC: D6370052 0556A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 0000000FC1F4: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v126, v[128:129]     // 0000000FC1FC: D6FF7C50 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC208: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 0000000FC20C: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 0000000FC214: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 0000000FC220: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FC228: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000FC22C: BE882000
	s_cbranch_execz 62346                                      // 0000000FC230: BFA5F38A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x365c>
	v_mad_i64_i32 v[80:81], null, 0x6000, v140, v[130:131]     // 0000000FC234: D6FF7C50 060B18FF 00006000
	v_mul_f32_e32 v72, v138, v72                               // 0000000FC240: 1090918A
	global_load_u16 v80, v[80:81], off offset:704              // 0000000FC244: DC4A02C0 507C0050
	s_waitcnt vmcnt(0)                                         // 0000000FC24C: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 0000000FC250: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC254: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 0000000FC258: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 0000000FC260: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 0000000FC26C: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FC270: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 0000000FC274: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 0000000FC278: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 0000000FC280: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC288: BF870121
	v_add_f32_e32 v81, v81, v82                                // 0000000FC28C: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 0000000FC290: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 0000000FC294: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC298: BF870095
	.long 0xd71c0051                                           // 0000000FC29C: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000000FC2A0: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000FC2A4: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 0000000FC2A8: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC2B0: BF870092
	v_cndmask_b32_e32 v80, 0x7f800000, v81, vcc_lo             // 0000000FC2B4: 02A0A2FF 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 0000000FC2BC: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC2C0: BF870091
	v_div_scale_f32 v81, null, v80, v80, v72                   // 0000000FC2C4: D6FC7C51 0522A150
	v_rcp_f32_e32 v82, v81                                     // 0000000FC2CC: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC2D0: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 0000000FC2D4: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 0000000FC2DC: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v72, v80, v72                 // 0000000FC2E0: D6FC6A53 0522A148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC2E8: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 0000000FC2EC: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 0000000FC2F0: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC2F8: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 0000000FC2FC: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 0000000FC300: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC308: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 0000000FC30C: D6370051 0552A551
	v_div_fixup_f32 v72, v81, v80, v72                         // 0000000FC314: D6270048 0522A151
	v_mad_i64_i32 v[80:81], null, 0x3000, v140, v[128:129]     // 0000000FC31C: D6FF7C50 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC328: BF870092
	v_bfe_u32 v82, v72, 16, 1                                  // 0000000FC32C: D6100052 02052148
	v_add3_u32 v72, v72, v82, 0x7fff                           // 0000000FC334: D6550048 03FEA548 00007FFF
	global_store_d16_hi_b16 v[80:81], v72, off offset:192      // 0000000FC340: DC9600C0 007C4850
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FC348: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000FC34C: BE882001
	s_cbranch_execz 62277                                      // 0000000FC350: BFA5F345 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3668>
	v_mad_i64_i32 v[80:81], null, 0x6000, v120, v[130:131]     // 0000000FC354: D6FF7C50 060AF0FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 0000000FC360: 1092938B
	global_load_u16 v72, v[80:81], off offset:704              // 0000000FC364: DC4A02C0 487C0050
	s_waitcnt vmcnt(0)                                         // 0000000FC36C: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 0000000FC370: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC374: BF870121
	v_mul_f32_e32 v80, 0xbfb8aa3b, v72                         // 0000000FC378: 10A090FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000000FC380: 7C3C90FF 42CE8ED0
	v_fma_f32 v81, 0xbfb8aa3b, v72, -v80                       // 0000000FC388: D6130051 854290FF BFB8AA3B
	v_rndne_f32_e32 v82, v80                                   // 0000000FC394: 7EA44750
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FC398: BF870112
	v_fmamk_f32 v81, v72, 0xb2a5705f, v81                      // 0000000FC39C: 58A2A348 B2A5705F
	v_sub_f32_e32 v80, v80, v82                                // 0000000FC3A4: 08A0A550
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC3A8: BF870121
	v_add_f32_e32 v80, v80, v81                                // 0000000FC3AC: 06A0A350
	v_cvt_i32_f32_e32 v81, v82                                 // 0000000FC3B0: 7EA21152
	v_exp_f32_e32 v80, v80                                     // 0000000FC3B4: 7EA04B50
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC3B8: BF870095
	.long 0xd71c0050                                           // 0000000FC3BC: D71C0050
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                     // 0000000FC3C0: 0202A350
	v_cndmask_b32_e32 v80, 0, v80, vcc_lo                      // 0000000FC3C4: 02A0A080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000000FC3C8: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC3D0: BF870092
	v_cndmask_b32_e32 v72, 0x7f800000, v80, vcc_lo             // 0000000FC3D4: 0290A0FF 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 0000000FC3DC: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC3E0: BF870091
	v_div_scale_f32 v80, null, v72, v72, v73                   // 0000000FC3E4: D6FC7C50 05269148
	v_rcp_f32_e32 v81, v80                                     // 0000000FC3EC: 7EA25550
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC3F0: BF870095
	v_fma_f32 v82, -v80, v81, 1.0                              // 0000000FC3F4: D6130052 23CAA350
	v_fmac_f32_e32 v81, v82, v81                               // 0000000FC3FC: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v73, v72, v73                 // 0000000FC400: D6FC6A52 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC408: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 0000000FC40C: 10A6A352
	v_fma_f32 v84, -v80, v83, v82                              // 0000000FC410: D6130054 254AA750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC418: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 0000000FC41C: 56A6A354
	v_fma_f32 v80, -v80, v83, v82                              // 0000000FC420: D6130050 254AA750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC428: BF870091
	v_div_fmas_f32 v80, v80, v81, v83                          // 0000000FC42C: D6370050 054EA350
	v_div_fixup_f32 v80, v80, v72, v73                         // 0000000FC434: D6270050 05269150
	v_mad_i64_i32 v[72:73], null, 0x3000, v120, v[128:129]     // 0000000FC43C: D6FF7C48 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC448: BF870092
	v_bfe_u32 v81, v80, 16, 1                                  // 0000000FC44C: D6100051 02052150
	v_add3_u32 v80, v80, v81, 0x7fff                           // 0000000FC454: D6550050 03FEA350 00007FFF
	global_store_d16_hi_b16 v[72:73], v80, off offset:192      // 0000000FC460: DC9600C0 007C5048
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FC468: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000FC46C: BE882002
	s_cbranch_execz 62208                                      // 0000000FC470: BFA5F300 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3674>
	v_mad_i64_i32 v[72:73], null, 0x6000, v121, v[130:131]     // 0000000FC474: D6FF7C48 060AF2FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 0000000FC480: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 0000000FC488: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 0000000FC48C: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC490: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000000FC494: 109290FF BFB8AA3B
	v_fma_f32 v80, 0xbfb8aa3b, v72, -v73                       // 0000000FC49C: D6130050 852690FF BFB8AA3B
	v_rndne_f32_e32 v81, v73                                   // 0000000FC4A8: 7EA24749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FC4AC: BF870221
	v_sub_f32_e32 v73, v73, v81                                // 0000000FC4B0: 0892A349
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000000FC4B4: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v80, v72, 0xb2a5705f, v80                      // 0000000FC4BC: 58A0A148 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC4C4: BF870121
	v_add_f32_e32 v73, v73, v80                                // 0000000FC4C8: 0692A149
	v_cvt_i32_f32_e32 v80, v81                                 // 0000000FC4CC: 7EA01151
	v_exp_f32_e32 v73, v73                                     // 0000000FC4D0: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC4D4: BF870095
	.long 0xd71c0049                                           // 0000000FC4D8: D71C0049
	v_cndmask_b32_e32 v1, v73, v80, vcc_lo                     // 0000000FC4DC: 0202A149
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000FC4E0: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000000FC4E4: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC4EC: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v136, v74// 0000000FC4F0: CA4692FF 48489588 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 0000000FC4FC: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC500: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 0000000FC504: D6FC7C4A 05269148
	v_rcp_f32_e32 v80, v74                                     // 0000000FC50C: 7EA0554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC510: BF870095
	v_fma_f32 v81, -v74, v80, 1.0                              // 0000000FC514: D6130051 23CAA14A
	v_fmac_f32_e32 v80, v81, v80                               // 0000000FC51C: 56A0A151
	v_div_scale_f32 v81, vcc_lo, v73, v72, v73                 // 0000000FC520: D6FC6A51 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC528: BF870091
	v_mul_f32_e32 v82, v81, v80                                // 0000000FC52C: 10A4A151
	v_fma_f32 v83, -v74, v82, v81                              // 0000000FC530: D6130053 2546A54A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC538: BF870091
	v_fmac_f32_e32 v82, v83, v80                               // 0000000FC53C: 56A4A153
	v_fma_f32 v74, -v74, v82, v81                              // 0000000FC540: D613004A 2546A54A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC548: BF870091
	v_div_fmas_f32 v74, v74, v80, v82                          // 0000000FC54C: D637004A 054AA14A
	v_div_fixup_f32 v74, v74, v72, v73                         // 0000000FC554: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v121, v[128:129]     // 0000000FC55C: D6FF7C48 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC568: BF870092
	v_bfe_u32 v80, v74, 16, 1                                  // 0000000FC56C: D6100050 0205214A
	v_add3_u32 v74, v74, v80, 0x7fff                           // 0000000FC574: D655004A 03FEA14A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 0000000FC580: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FC588: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000FC58C: BE882003
	s_cbranch_execz 62139                                      // 0000000FC590: BFA5F2BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3680>
	v_mad_i64_i32 v[72:73], null, 0x6000, v122, v[130:131]     // 0000000FC594: D6FF7C48 060AF4FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 0000000FC5A0: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 0000000FC5A8: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 0000000FC5AC: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC5B0: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000000FC5B4: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 0000000FC5BC: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v80, v73                                   // 0000000FC5C8: 7EA04749
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC5CC: BF870091
	v_dual_fmamk_f32 v74, v72, 0xb2a5705f, v74 :: v_dual_sub_f32 v73, v73, v80// 0000000FC5D0: C88A9548 4A48A149 B2A5705F
	v_add_f32_e32 v73, v73, v74                                // 0000000FC5DC: 06929549
	v_cvt_i32_f32_e32 v74, v80                                 // 0000000FC5E0: 7E941150
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000000FC5E4: 7C3C90FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FC5EC: BF870293
	v_exp_f32_e32 v73, v73                                     // 0000000FC5F0: 7E924B49
	.long 0xd71c0049                                           // 0000000FC5F4: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000FC5F8: 02029549
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC5FC: BF870121
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000FC600: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000000FC604: 7C3690FF C2B17218
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v137, v75// 0000000FC60C: CA4692FF 48489789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC618: BF870091
	v_add_f32_e32 v72, 1.0, v72                                // 0000000FC61C: 069090F2
	v_div_scale_f32 v74, null, v72, v72, v73                   // 0000000FC620: D6FC7C4A 05269148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FC628: BF870291
	v_rcp_f32_e32 v75, v74                                     // 0000000FC62C: 7E96554A
	v_fma_f32 v80, -v74, v75, 1.0                              // 0000000FC630: D6130050 23CA974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FC638: BF8700A1
	v_fmac_f32_e32 v75, v80, v75                               // 0000000FC63C: 56969750
	v_div_scale_f32 v80, vcc_lo, v73, v72, v73                 // 0000000FC640: D6FC6A50 05269149
	v_mul_f32_e32 v81, v80, v75                                // 0000000FC648: 10A29750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC64C: BF870091
	v_fma_f32 v82, -v74, v81, v80                              // 0000000FC650: D6130052 2542A34A
	v_fmac_f32_e32 v81, v82, v75                               // 0000000FC658: 56A29752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC65C: BF870091
	v_fma_f32 v74, -v74, v81, v80                              // 0000000FC660: D613004A 2542A34A
	v_div_fmas_f32 v74, v74, v75, v81                          // 0000000FC668: D637004A 0546974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC670: BF870121
	v_div_fixup_f32 v74, v74, v72, v73                         // 0000000FC674: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v122, v[128:129]     // 0000000FC67C: D6FF7C48 0602F4FF 00003000
	v_bfe_u32 v75, v74, 16, 1                                  // 0000000FC688: D610004B 0205214A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FC690: BF870001
	v_add3_u32 v74, v74, v75, 0x7fff                           // 0000000FC694: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 0000000FC6A0: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FC6A8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000FC6AC: BE882004
	s_cbranch_execz 62070                                      // 0000000FC6B0: BFA5F276 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x368c>
	v_mad_i64_i32 v[72:73], null, 0x6000, v123, v[130:131]     // 0000000FC6B4: D6FF7C48 060AF6FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 0000000FC6C0: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 0000000FC6C8: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 0000000FC6CC: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC6D0: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000000FC6D4: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 0000000FC6DC: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000000FC6E8: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FC6EC: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 0000000FC6F0: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000000FC6F4: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 0000000FC6FC: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC704: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000000FC708: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000000FC70C: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000000FC710: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC714: BF870095
	.long 0xd71c0049                                           // 0000000FC718: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000FC71C: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000FC720: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000000FC724: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC72C: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v134, v76// 0000000FC730: CA4692FF 48489986 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 0000000FC73C: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC740: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 0000000FC744: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 0000000FC74C: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC750: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000000FC754: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000000FC75C: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 0000000FC760: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC768: BF870091
	v_mul_f32_e32 v80, v76, v75                                // 0000000FC76C: 10A0974C
	v_fma_f32 v81, -v74, v80, v76                              // 0000000FC770: D6130051 2532A14A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC778: BF870091
	v_fmac_f32_e32 v80, v81, v75                               // 0000000FC77C: 56A09751
	v_fma_f32 v74, -v74, v80, v76                              // 0000000FC780: D613004A 2532A14A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC788: BF870091
	v_div_fmas_f32 v74, v74, v75, v80                          // 0000000FC78C: D637004A 0542974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 0000000FC794: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v123, v[128:129]     // 0000000FC79C: D6FF7C48 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC7A8: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 0000000FC7AC: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 0000000FC7B4: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 0000000FC7C0: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FC7C8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000FC7CC: BE882005
	s_cbranch_execz 62001                                      // 0000000FC7D0: BFA5F231 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3698>
	v_mad_i64_i32 v[72:73], null, 0x6000, v124, v[130:131]     // 0000000FC7D4: D6FF7C48 060AF8FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 0000000FC7E0: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 0000000FC7E8: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 0000000FC7EC: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC7F0: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000000FC7F4: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 0000000FC7FC: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000000FC808: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FC80C: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 0000000FC810: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000000FC814: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 0000000FC81C: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC824: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000000FC828: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000000FC82C: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000000FC830: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC834: BF870095
	.long 0xd71c0049                                           // 0000000FC838: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000FC83C: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000FC840: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000000FC844: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC84C: BF870092
	v_cndmask_b32_e32 v72, 0x7f800000, v73, vcc_lo             // 0000000FC850: 029092FF 7F800000
	v_dual_mul_f32 v73, v135, v77 :: v_dual_add_f32 v72, 1.0, v72// 0000000FC858: C8C89B87 494890F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC860: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 0000000FC864: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 0000000FC86C: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC870: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000000FC874: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000000FC87C: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 0000000FC880: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC888: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 0000000FC88C: 109A974C
	v_fma_f32 v80, -v74, v77, v76                              // 0000000FC890: D6130050 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC898: BF870091
	v_fmac_f32_e32 v77, v80, v75                               // 0000000FC89C: 569A9750
	v_fma_f32 v74, -v74, v77, v76                              // 0000000FC8A0: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC8A8: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 0000000FC8AC: D637004A 0536974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 0000000FC8B4: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v124, v[128:129]     // 0000000FC8BC: D6FF7C48 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC8C8: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 0000000FC8CC: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 0000000FC8D4: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 0000000FC8E0: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FC8E8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000FC8EC: BE882006
	s_cbranch_execz 61932                                      // 0000000FC8F0: BFA5F1EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36a4>
	v_mad_i64_i32 v[72:73], null, 0x6000, v125, v[130:131]     // 0000000FC8F4: D6FF7C48 060AFAFF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 0000000FC900: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 0000000FC908: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 0000000FC90C: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC910: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000000FC914: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 0000000FC91C: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000000FC928: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FC92C: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 0000000FC930: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000000FC934: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 0000000FC93C: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC944: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000000FC948: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000000FC94C: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000000FC950: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC954: BF870095
	.long 0xd71c0049                                           // 0000000FC958: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000FC95C: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000FC960: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000000FC964: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC96C: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v132, v78// 0000000FC970: CA4692FF 48489D84 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 0000000FC97C: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC980: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 0000000FC984: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 0000000FC98C: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC990: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000000FC994: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000000FC99C: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 0000000FC9A0: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC9A8: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 0000000FC9AC: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 0000000FC9B0: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC9B8: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 0000000FC9BC: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 0000000FC9C0: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC9C8: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 0000000FC9CC: D637004A 0536974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 0000000FC9D4: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v125, v[128:129]     // 0000000FC9DC: D6FF7C48 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC9E8: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 0000000FC9EC: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 0000000FC9F4: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 0000000FCA00: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FCA08: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000FCA0C: BE882007
	s_cbranch_execz 61863                                      // 0000000FCA10: BFA5F1A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36b0>
	v_mad_i64_i32 v[72:73], null, 0x6000, v126, v[130:131]     // 0000000FCA14: D6FF7C48 060AFCFF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 0000000FCA20: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 0000000FCA28: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 0000000FCA2C: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCA30: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000000FCA34: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 0000000FCA3C: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000000FCA48: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FCA4C: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 0000000FCA50: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000000FCA54: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 0000000FCA5C: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FCA64: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000000FCA68: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000000FCA6C: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000000FCA70: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCA74: BF870095
	.long 0xd71c0049                                           // 0000000FCA78: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000FCA7C: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000FCA80: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000000FCA84: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCA8C: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v133, v79// 0000000FCA90: CA4692FF 48489F85 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 0000000FCA9C: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCAA0: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 0000000FCAA4: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 0000000FCAAC: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCAB0: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000000FCAB4: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000000FCABC: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 0000000FCAC0: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCAC8: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 0000000FCACC: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 0000000FCAD0: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCAD8: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 0000000FCADC: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 0000000FCAE0: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCAE8: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 0000000FCAEC: D637004A 0536974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 0000000FCAF4: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v126, v[128:129]     // 0000000FCAFC: D6FF7C48 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCB08: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 0000000FCB0C: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 0000000FCB14: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 0000000FCB20: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FCB28: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000FCB2C: BE882000
	s_cbranch_execz 61794                                      // 0000000FCB30: BFA5F162 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36bc>
	v_mad_i64_i32 v[72:73], null, 0x6000, v140, v[130:131]     // 0000000FCB34: D6FF7C48 060B18FF 00006000
	v_mul_f32_e32 v64, v138, v64                               // 0000000FCB40: 1080818A
	global_load_u16 v72, v[72:73], off offset:736              // 0000000FCB44: DC4A02E0 487C0048
	s_waitcnt vmcnt(0)                                         // 0000000FCB4C: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 0000000FCB50: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCB54: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000000FCB58: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 0000000FCB60: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000000FCB6C: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FCB70: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 0000000FCB74: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000000FCB78: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 0000000FCB80: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FCB88: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000000FCB8C: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000000FCB90: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000000FCB94: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCB98: BF870095
	.long 0xd71c0049                                           // 0000000FCB9C: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000FCBA0: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000FCBA4: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000000FCBA8: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCBB0: BF870092
	v_cndmask_b32_e32 v72, 0x7f800000, v73, vcc_lo             // 0000000FCBB4: 029092FF 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 0000000FCBBC: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCBC0: BF870091
	v_div_scale_f32 v73, null, v72, v72, v64                   // 0000000FCBC4: D6FC7C49 05029148
	v_rcp_f32_e32 v74, v73                                     // 0000000FCBCC: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCBD0: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 0000000FCBD4: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 0000000FCBDC: 5694954B
	v_div_scale_f32 v75, vcc_lo, v64, v72, v64                 // 0000000FCBE0: D6FC6A4B 05029140
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCBE8: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 0000000FCBEC: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 0000000FCBF0: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCBF8: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 0000000FCBFC: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 0000000FCC00: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCC08: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 0000000FCC0C: D6370049 05329549
	v_div_fixup_f32 v64, v73, v72, v64                         // 0000000FCC14: D6270040 05029149
	v_mad_i64_i32 v[72:73], null, 0x3000, v140, v[128:129]     // 0000000FCC1C: D6FF7C48 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCC28: BF870092
	v_bfe_u32 v74, v64, 16, 1                                  // 0000000FCC2C: D610004A 02052140
	v_add3_u32 v64, v64, v74, 0x7fff                           // 0000000FCC34: D6550040 03FE9540 00007FFF
	global_store_d16_hi_b16 v[72:73], v64, off offset:224      // 0000000FCC40: DC9600E0 007C4048
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FCC48: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000FCC4C: BE882001
	s_cbranch_execz 61725                                      // 0000000FCC50: BFA5F11D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36c8>
	v_mad_i64_i32 v[72:73], null, 0x6000, v120, v[130:131]     // 0000000FCC54: D6FF7C48 060AF0FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 0000000FCC60: 1082838B
	global_load_u16 v64, v[72:73], off offset:736              // 0000000FCC64: DC4A02E0 407C0048
	s_waitcnt vmcnt(0)                                         // 0000000FCC6C: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 0000000FCC70: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FCC74: BF870121
	v_mul_f32_e32 v72, 0xbfb8aa3b, v64                         // 0000000FCC78: 109080FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 0000000FCC80: 7C3C80FF 42CE8ED0
	v_fma_f32 v73, 0xbfb8aa3b, v64, -v72                       // 0000000FCC88: D6130049 852280FF BFB8AA3B
	v_rndne_f32_e32 v74, v72                                   // 0000000FCC94: 7E944748
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FCC98: BF870112
	v_fmamk_f32 v73, v64, 0xb2a5705f, v73                      // 0000000FCC9C: 58929340 B2A5705F
	v_sub_f32_e32 v72, v72, v74                                // 0000000FCCA4: 08909548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FCCA8: BF870121
	v_add_f32_e32 v72, v72, v73                                // 0000000FCCAC: 06909348
	v_cvt_i32_f32_e32 v73, v74                                 // 0000000FCCB0: 7E92114A
	v_exp_f32_e32 v72, v72                                     // 0000000FCCB4: 7E904B48
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCCB8: BF870095
	.long 0xd71c0048                                           // 0000000FCCBC: D71C0048
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                     // 0000000FCCC0: 02029348
	v_cndmask_b32_e32 v72, 0, v72, vcc_lo                      // 0000000FCCC4: 02909080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 0000000FCCC8: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCCD0: BF870092
	v_cndmask_b32_e32 v64, 0x7f800000, v72, vcc_lo             // 0000000FCCD4: 028090FF 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 0000000FCCDC: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCCE0: BF870091
	v_div_scale_f32 v72, null, v64, v64, v65                   // 0000000FCCE4: D6FC7C48 05068140
	v_rcp_f32_e32 v73, v72                                     // 0000000FCCEC: 7E925548
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCCF0: BF870095
	v_fma_f32 v74, -v72, v73, 1.0                              // 0000000FCCF4: D613004A 23CA9348
	v_fmac_f32_e32 v73, v74, v73                               // 0000000FCCFC: 5692934A
	v_div_scale_f32 v74, vcc_lo, v65, v64, v65                 // 0000000FCD00: D6FC6A4A 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCD08: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 0000000FCD0C: 1096934A
	v_fma_f32 v76, -v72, v75, v74                              // 0000000FCD10: D613004C 252A9748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCD18: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 0000000FCD1C: 5696934C
	v_fma_f32 v72, -v72, v75, v74                              // 0000000FCD20: D6130048 252A9748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCD28: BF870091
	v_div_fmas_f32 v72, v72, v73, v75                          // 0000000FCD2C: D6370048 052E9348
	v_div_fixup_f32 v72, v72, v64, v65                         // 0000000FCD34: D6270048 05068148
	v_mad_i64_i32 v[64:65], null, 0x3000, v120, v[128:129]     // 0000000FCD3C: D6FF7C40 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCD48: BF870092
	v_bfe_u32 v73, v72, 16, 1                                  // 0000000FCD4C: D6100049 02052148
	v_add3_u32 v72, v72, v73, 0x7fff                           // 0000000FCD54: D6550048 03FE9348 00007FFF
	global_store_d16_hi_b16 v[64:65], v72, off offset:224      // 0000000FCD60: DC9600E0 007C4840
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FCD68: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000FCD6C: BE882002
	s_cbranch_execz 61656                                      // 0000000FCD70: BFA5F0D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36d4>
	v_mad_i64_i32 v[64:65], null, 0x6000, v121, v[130:131]     // 0000000FCD74: D6FF7C40 060AF2FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 0000000FCD80: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 0000000FCD88: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 0000000FCD8C: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCD90: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 0000000FCD94: 108280FF BFB8AA3B
	v_fma_f32 v72, 0xbfb8aa3b, v64, -v65                       // 0000000FCD9C: D6130048 850680FF BFB8AA3B
	v_rndne_f32_e32 v73, v65                                   // 0000000FCDA8: 7E924741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FCDAC: BF870221
	v_sub_f32_e32 v65, v65, v73                                // 0000000FCDB0: 08829341
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 0000000FCDB4: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v72, v64, 0xb2a5705f, v72                      // 0000000FCDBC: 58909140 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FCDC4: BF870121
	v_add_f32_e32 v65, v65, v72                                // 0000000FCDC8: 06829141
	v_cvt_i32_f32_e32 v72, v73                                 // 0000000FCDCC: 7E901149
	v_exp_f32_e32 v65, v65                                     // 0000000FCDD0: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCDD4: BF870095
	.long 0xd71c0041                                           // 0000000FCDD8: D71C0041
	v_cndmask_b32_e32 v1, v65, v72, vcc_lo                     // 0000000FCDDC: 02029141
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 0000000FCDE0: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 0000000FCDE4: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCDEC: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v136, v66// 0000000FCDF0: CA4682FF 40408588 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 0000000FCDFC: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCE00: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 0000000FCE04: D6FC7C42 05068140
	v_rcp_f32_e32 v72, v66                                     // 0000000FCE0C: 7E905542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCE10: BF870095
	v_fma_f32 v73, -v66, v72, 1.0                              // 0000000FCE14: D6130049 23CA9142
	v_fmac_f32_e32 v72, v73, v72                               // 0000000FCE1C: 56909149
	v_div_scale_f32 v73, vcc_lo, v65, v64, v65                 // 0000000FCE20: D6FC6A49 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCE28: BF870091
	v_mul_f32_e32 v74, v73, v72                                // 0000000FCE2C: 10949149
	v_fma_f32 v75, -v66, v74, v73                              // 0000000FCE30: D613004B 25269542
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCE38: BF870091
	v_fmac_f32_e32 v74, v75, v72                               // 0000000FCE3C: 5694914B
	v_fma_f32 v66, -v66, v74, v73                              // 0000000FCE40: D6130042 25269542
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCE48: BF870091
	v_div_fmas_f32 v66, v66, v72, v74                          // 0000000FCE4C: D6370042 052A9142
	v_div_fixup_f32 v66, v66, v64, v65                         // 0000000FCE54: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v121, v[128:129]     // 0000000FCE5C: D6FF7C40 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCE68: BF870092
	v_bfe_u32 v72, v66, 16, 1                                  // 0000000FCE6C: D6100048 02052142
	v_add3_u32 v66, v66, v72, 0x7fff                           // 0000000FCE74: D6550042 03FE9142 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 0000000FCE80: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FCE88: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000FCE8C: BE882003
	s_cbranch_execz 61587                                      // 0000000FCE90: BFA5F093 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36e0>
	v_mad_i64_i32 v[64:65], null, 0x6000, v122, v[130:131]     // 0000000FCE94: D6FF7C40 060AF4FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 0000000FCEA0: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 0000000FCEA8: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 0000000FCEAC: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCEB0: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 0000000FCEB4: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 0000000FCEBC: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v72, v65                                   // 0000000FCEC8: 7E904741
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCECC: BF870091
	v_dual_fmamk_f32 v66, v64, 0xb2a5705f, v66 :: v_dual_sub_f32 v65, v65, v72// 0000000FCED0: C88A8540 42409141 B2A5705F
	v_add_f32_e32 v65, v65, v66                                // 0000000FCEDC: 06828541
	v_cvt_i32_f32_e32 v66, v72                                 // 0000000FCEE0: 7E841148
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 0000000FCEE4: 7C3C80FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FCEEC: BF870293
	v_exp_f32_e32 v65, v65                                     // 0000000FCEF0: 7E824B41
	.long 0xd71c0041                                           // 0000000FCEF4: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 0000000FCEF8: 02028541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FCEFC: BF870121
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 0000000FCF00: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 0000000FCF04: 7C3680FF C2B17218
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v137, v67// 0000000FCF0C: CA4682FF 40408789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCF18: BF870091
	v_add_f32_e32 v64, 1.0, v64                                // 0000000FCF1C: 068080F2
	v_div_scale_f32 v66, null, v64, v64, v65                   // 0000000FCF20: D6FC7C42 05068140
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FCF28: BF870291
	v_rcp_f32_e32 v67, v66                                     // 0000000FCF2C: 7E865542
	v_fma_f32 v72, -v66, v67, 1.0                              // 0000000FCF30: D6130048 23CA8742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FCF38: BF8700A1
	v_fmac_f32_e32 v67, v72, v67                               // 0000000FCF3C: 56868748
	v_div_scale_f32 v72, vcc_lo, v65, v64, v65                 // 0000000FCF40: D6FC6A48 05068141
	v_mul_f32_e32 v73, v72, v67                                // 0000000FCF48: 10928748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCF4C: BF870091
	v_fma_f32 v74, -v66, v73, v72                              // 0000000FCF50: D613004A 25229342
	v_fmac_f32_e32 v73, v74, v67                               // 0000000FCF58: 5692874A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCF5C: BF870091
	v_fma_f32 v66, -v66, v73, v72                              // 0000000FCF60: D6130042 25229342
	v_div_fmas_f32 v66, v66, v67, v73                          // 0000000FCF68: D6370042 05268742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FCF70: BF870121
	v_div_fixup_f32 v66, v66, v64, v65                         // 0000000FCF74: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v122, v[128:129]     // 0000000FCF7C: D6FF7C40 0602F4FF 00003000
	v_bfe_u32 v67, v66, 16, 1                                  // 0000000FCF88: D6100043 02052142
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FCF90: BF870001
	v_add3_u32 v66, v66, v67, 0x7fff                           // 0000000FCF94: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 0000000FCFA0: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FCFA8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000FCFAC: BE882004
	s_cbranch_execz 61518                                      // 0000000FCFB0: BFA5F04E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36ec>
	v_mad_i64_i32 v[64:65], null, 0x6000, v123, v[130:131]     // 0000000FCFB4: D6FF7C40 060AF6FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 0000000FCFC0: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 0000000FCFC8: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 0000000FCFCC: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FCFD0: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 0000000FCFD4: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 0000000FCFDC: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 0000000FCFE8: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FCFEC: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 0000000FCFF0: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 0000000FCFF4: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 0000000FCFFC: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FD004: BF870121
	v_add_f32_e32 v65, v65, v66                                // 0000000FD008: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 0000000FD00C: 7E841143
	v_exp_f32_e32 v65, v65                                     // 0000000FD010: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD014: BF870095
	.long 0xd71c0041                                           // 0000000FD018: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 0000000FD01C: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 0000000FD020: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 0000000FD024: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD02C: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v134, v68// 0000000FD030: CA4682FF 40408986 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 0000000FD03C: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD040: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 0000000FD044: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 0000000FD04C: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD050: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 0000000FD054: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 0000000FD05C: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 0000000FD060: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD068: BF870091
	v_mul_f32_e32 v72, v68, v67                                // 0000000FD06C: 10908744
	v_fma_f32 v73, -v66, v72, v68                              // 0000000FD070: D6130049 25129142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD078: BF870091
	v_fmac_f32_e32 v72, v73, v67                               // 0000000FD07C: 56908749
	v_fma_f32 v66, -v66, v72, v68                              // 0000000FD080: D6130042 25129142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD088: BF870091
	v_div_fmas_f32 v66, v66, v67, v72                          // 0000000FD08C: D6370042 05228742
	v_div_fixup_f32 v66, v66, v64, v65                         // 0000000FD094: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v123, v[128:129]     // 0000000FD09C: D6FF7C40 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD0A8: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 0000000FD0AC: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 0000000FD0B4: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 0000000FD0C0: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FD0C8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000FD0CC: BE882005
	s_cbranch_execz 61449                                      // 0000000FD0D0: BFA5F009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36f8>
	v_mad_i64_i32 v[64:65], null, 0x6000, v124, v[130:131]     // 0000000FD0D4: D6FF7C40 060AF8FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 0000000FD0E0: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 0000000FD0E8: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 0000000FD0EC: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD0F0: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 0000000FD0F4: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 0000000FD0FC: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 0000000FD108: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FD10C: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 0000000FD110: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 0000000FD114: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 0000000FD11C: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FD124: BF870121
	v_add_f32_e32 v65, v65, v66                                // 0000000FD128: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 0000000FD12C: 7E841143
	v_exp_f32_e32 v65, v65                                     // 0000000FD130: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD134: BF870095
	.long 0xd71c0041                                           // 0000000FD138: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 0000000FD13C: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 0000000FD140: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 0000000FD144: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD14C: BF870092
	v_cndmask_b32_e32 v64, 0x7f800000, v65, vcc_lo             // 0000000FD150: 028082FF 7F800000
	v_dual_mul_f32 v65, v135, v69 :: v_dual_add_f32 v64, 1.0, v64// 0000000FD158: C8C88B87 414080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD160: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 0000000FD164: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 0000000FD16C: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD170: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 0000000FD174: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 0000000FD17C: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 0000000FD180: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD188: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 0000000FD18C: 108A8744
	v_fma_f32 v72, -v66, v69, v68                              // 0000000FD190: D6130048 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD198: BF870091
	v_fmac_f32_e32 v69, v72, v67                               // 0000000FD19C: 568A8748
	v_fma_f32 v66, -v66, v69, v68                              // 0000000FD1A0: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD1A8: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 0000000FD1AC: D6370042 05168742
	v_div_fixup_f32 v66, v66, v64, v65                         // 0000000FD1B4: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v124, v[128:129]     // 0000000FD1BC: D6FF7C40 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD1C8: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 0000000FD1CC: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 0000000FD1D4: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 0000000FD1E0: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FD1E8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000FD1EC: BE882006
	s_cbranch_execz 61380                                      // 0000000FD1F0: BFA5EFC4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3704>
	v_mad_i64_i32 v[64:65], null, 0x6000, v125, v[130:131]     // 0000000FD1F4: D6FF7C40 060AFAFF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 0000000FD200: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 0000000FD208: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 0000000FD20C: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD210: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 0000000FD214: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 0000000FD21C: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 0000000FD228: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FD22C: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 0000000FD230: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 0000000FD234: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 0000000FD23C: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FD244: BF870121
	v_add_f32_e32 v65, v65, v66                                // 0000000FD248: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 0000000FD24C: 7E841143
	v_exp_f32_e32 v65, v65                                     // 0000000FD250: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD254: BF870095
	.long 0xd71c0041                                           // 0000000FD258: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 0000000FD25C: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 0000000FD260: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 0000000FD264: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD26C: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v132, v70// 0000000FD270: CA4682FF 40408D84 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 0000000FD27C: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD280: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 0000000FD284: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 0000000FD28C: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD290: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 0000000FD294: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 0000000FD29C: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 0000000FD2A0: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD2A8: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 0000000FD2AC: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 0000000FD2B0: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD2B8: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 0000000FD2BC: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 0000000FD2C0: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD2C8: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 0000000FD2CC: D6370042 05168742
	v_div_fixup_f32 v66, v66, v64, v65                         // 0000000FD2D4: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v125, v[128:129]     // 0000000FD2DC: D6FF7C40 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD2E8: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 0000000FD2EC: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 0000000FD2F4: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 0000000FD300: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FD308: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000FD30C: BE882007
	s_cbranch_execz 61311                                      // 0000000FD310: BFA5EF7F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3710>
	v_mad_i64_i32 v[64:65], null, 0x6000, v126, v[130:131]     // 0000000FD314: D6FF7C40 060AFCFF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 0000000FD320: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 0000000FD328: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 0000000FD32C: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD330: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 0000000FD334: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 0000000FD33C: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 0000000FD348: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FD34C: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 0000000FD350: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 0000000FD354: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 0000000FD35C: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FD364: BF870121
	v_add_f32_e32 v65, v65, v66                                // 0000000FD368: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 0000000FD36C: 7E841143
	v_exp_f32_e32 v65, v65                                     // 0000000FD370: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD374: BF870095
	.long 0xd71c0041                                           // 0000000FD378: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 0000000FD37C: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 0000000FD380: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 0000000FD384: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD38C: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v133, v71// 0000000FD390: CA4682FF 40408F85 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 0000000FD39C: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD3A0: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 0000000FD3A4: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 0000000FD3AC: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD3B0: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 0000000FD3B4: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 0000000FD3BC: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 0000000FD3C0: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD3C8: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 0000000FD3CC: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 0000000FD3D0: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD3D8: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 0000000FD3DC: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 0000000FD3E0: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD3E8: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 0000000FD3EC: D6370042 05168742
	v_div_fixup_f32 v66, v66, v64, v65                         // 0000000FD3F4: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v126, v[128:129]     // 0000000FD3FC: D6FF7C40 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD408: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 0000000FD40C: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 0000000FD414: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 0000000FD420: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FD428: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000FD42C: BE882000
	s_cbranch_execz 61242                                      // 0000000FD430: BFA5EF3A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x371c>
	v_mad_i64_i32 v[64:65], null, 0x6000, v140, v[130:131]     // 0000000FD434: D6FF7C40 060B18FF 00006000
	v_mul_f32_e32 v56, v138, v56                               // 0000000FD440: 1070718A
	global_load_u16 v64, v[64:65], off offset:768              // 0000000FD444: DC4A0300 407C0040
	s_waitcnt vmcnt(0)                                         // 0000000FD44C: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 0000000FD450: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD454: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 0000000FD458: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 0000000FD460: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 0000000FD46C: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FD470: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 0000000FD474: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 0000000FD478: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 0000000FD480: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FD488: BF870121
	v_add_f32_e32 v65, v65, v66                                // 0000000FD48C: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 0000000FD490: 7E841143
	v_exp_f32_e32 v65, v65                                     // 0000000FD494: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD498: BF870095
	.long 0xd71c0041                                           // 0000000FD49C: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 0000000FD4A0: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 0000000FD4A4: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 0000000FD4A8: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD4B0: BF870092
	v_cndmask_b32_e32 v64, 0x7f800000, v65, vcc_lo             // 0000000FD4B4: 028082FF 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 0000000FD4BC: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD4C0: BF870091
	v_div_scale_f32 v65, null, v64, v64, v56                   // 0000000FD4C4: D6FC7C41 04E28140
	v_rcp_f32_e32 v66, v65                                     // 0000000FD4CC: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD4D0: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 0000000FD4D4: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 0000000FD4DC: 56848543
	v_div_scale_f32 v67, vcc_lo, v56, v64, v56                 // 0000000FD4E0: D6FC6A43 04E28138
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD4E8: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 0000000FD4EC: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 0000000FD4F0: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD4F8: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 0000000FD4FC: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 0000000FD500: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD508: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 0000000FD50C: D6370041 05128541
	v_div_fixup_f32 v56, v65, v64, v56                         // 0000000FD514: D6270038 04E28141
	v_mad_i64_i32 v[64:65], null, 0x3000, v140, v[128:129]     // 0000000FD51C: D6FF7C40 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD528: BF870092
	v_bfe_u32 v66, v56, 16, 1                                  // 0000000FD52C: D6100042 02052138
	v_add3_u32 v56, v56, v66, 0x7fff                           // 0000000FD534: D6550038 03FE8538 00007FFF
	global_store_d16_hi_b16 v[64:65], v56, off offset:256      // 0000000FD540: DC960100 007C3840
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FD548: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000FD54C: BE882001
	s_cbranch_execz 61173                                      // 0000000FD550: BFA5EEF5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3728>
	v_mad_i64_i32 v[64:65], null, 0x6000, v120, v[130:131]     // 0000000FD554: D6FF7C40 060AF0FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 0000000FD560: 1072738B
	global_load_u16 v56, v[64:65], off offset:768              // 0000000FD564: DC4A0300 387C0040
	s_waitcnt vmcnt(0)                                         // 0000000FD56C: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 0000000FD570: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FD574: BF870121
	v_mul_f32_e32 v64, 0xbfb8aa3b, v56                         // 0000000FD578: 108070FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 0000000FD580: 7C3C70FF 42CE8ED0
	v_fma_f32 v65, 0xbfb8aa3b, v56, -v64                       // 0000000FD588: D6130041 850270FF BFB8AA3B
	v_rndne_f32_e32 v66, v64                                   // 0000000FD594: 7E844740
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FD598: BF870112
	v_fmamk_f32 v65, v56, 0xb2a5705f, v65                      // 0000000FD59C: 58828338 B2A5705F
	v_sub_f32_e32 v64, v64, v66                                // 0000000FD5A4: 08808540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FD5A8: BF870121
	v_add_f32_e32 v64, v64, v65                                // 0000000FD5AC: 06808340
	v_cvt_i32_f32_e32 v65, v66                                 // 0000000FD5B0: 7E821142
	v_exp_f32_e32 v64, v64                                     // 0000000FD5B4: 7E804B40
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD5B8: BF870095
	.long 0xd71c0040                                           // 0000000FD5BC: D71C0040
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                     // 0000000FD5C0: 02028340
	v_cndmask_b32_e32 v64, 0, v64, vcc_lo                      // 0000000FD5C4: 02808080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 0000000FD5C8: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD5D0: BF870092
	v_cndmask_b32_e32 v56, 0x7f800000, v64, vcc_lo             // 0000000FD5D4: 027080FF 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 0000000FD5DC: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD5E0: BF870091
	v_div_scale_f32 v64, null, v56, v56, v57                   // 0000000FD5E4: D6FC7C40 04E67138
	v_rcp_f32_e32 v65, v64                                     // 0000000FD5EC: 7E825540
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD5F0: BF870095
	v_fma_f32 v66, -v64, v65, 1.0                              // 0000000FD5F4: D6130042 23CA8340
	v_fmac_f32_e32 v65, v66, v65                               // 0000000FD5FC: 56828342
	v_div_scale_f32 v66, vcc_lo, v57, v56, v57                 // 0000000FD600: D6FC6A42 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD608: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 0000000FD60C: 10868342
	v_fma_f32 v68, -v64, v67, v66                              // 0000000FD610: D6130044 250A8740
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD618: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 0000000FD61C: 56868344
	v_fma_f32 v64, -v64, v67, v66                              // 0000000FD620: D6130040 250A8740
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD628: BF870091
	v_div_fmas_f32 v64, v64, v65, v67                          // 0000000FD62C: D6370040 050E8340
	v_div_fixup_f32 v64, v64, v56, v57                         // 0000000FD634: D6270040 04E67140
	v_mad_i64_i32 v[56:57], null, 0x3000, v120, v[128:129]     // 0000000FD63C: D6FF7C38 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD648: BF870092
	v_bfe_u32 v65, v64, 16, 1                                  // 0000000FD64C: D6100041 02052140
	v_add3_u32 v64, v64, v65, 0x7fff                           // 0000000FD654: D6550040 03FE8340 00007FFF
	global_store_d16_hi_b16 v[56:57], v64, off offset:256      // 0000000FD660: DC960100 007C4038
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FD668: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000FD66C: BE882002
	s_cbranch_execz 61104                                      // 0000000FD670: BFA5EEB0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3734>
	v_mad_i64_i32 v[56:57], null, 0x6000, v121, v[130:131]     // 0000000FD674: D6FF7C38 060AF2FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 0000000FD680: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 0000000FD688: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 0000000FD68C: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD690: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 0000000FD694: 107270FF BFB8AA3B
	v_fma_f32 v64, 0xbfb8aa3b, v56, -v57                       // 0000000FD69C: D6130040 84E670FF BFB8AA3B
	v_rndne_f32_e32 v65, v57                                   // 0000000FD6A8: 7E824739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FD6AC: BF870221
	v_sub_f32_e32 v57, v57, v65                                // 0000000FD6B0: 08728339
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 0000000FD6B4: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v64, v56, 0xb2a5705f, v64                      // 0000000FD6BC: 58808138 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FD6C4: BF870121
	v_add_f32_e32 v57, v57, v64                                // 0000000FD6C8: 06728139
	v_cvt_i32_f32_e32 v64, v65                                 // 0000000FD6CC: 7E801141
	v_exp_f32_e32 v57, v57                                     // 0000000FD6D0: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD6D4: BF870095
	.long 0xd71c0039                                           // 0000000FD6D8: D71C0039
	v_cndmask_b32_e32 v1, v57, v64, vcc_lo                     // 0000000FD6DC: 02028139
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000FD6E0: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 0000000FD6E4: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD6EC: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v136, v58// 0000000FD6F0: CA4672FF 38387588 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 0000000FD6FC: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD700: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 0000000FD704: D6FC7C3A 04E67138
	v_rcp_f32_e32 v64, v58                                     // 0000000FD70C: 7E80553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD710: BF870095
	v_fma_f32 v65, -v58, v64, 1.0                              // 0000000FD714: D6130041 23CA813A
	v_fmac_f32_e32 v64, v65, v64                               // 0000000FD71C: 56808141
	v_div_scale_f32 v65, vcc_lo, v57, v56, v57                 // 0000000FD720: D6FC6A41 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD728: BF870091
	v_mul_f32_e32 v66, v65, v64                                // 0000000FD72C: 10848141
	v_fma_f32 v67, -v58, v66, v65                              // 0000000FD730: D6130043 2506853A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD738: BF870091
	v_fmac_f32_e32 v66, v67, v64                               // 0000000FD73C: 56848143
	v_fma_f32 v58, -v58, v66, v65                              // 0000000FD740: D613003A 2506853A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD748: BF870091
	v_div_fmas_f32 v58, v58, v64, v66                          // 0000000FD74C: D637003A 050A813A
	v_div_fixup_f32 v58, v58, v56, v57                         // 0000000FD754: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v121, v[128:129]     // 0000000FD75C: D6FF7C38 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD768: BF870092
	v_bfe_u32 v64, v58, 16, 1                                  // 0000000FD76C: D6100040 0205213A
	v_add3_u32 v58, v58, v64, 0x7fff                           // 0000000FD774: D655003A 03FE813A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 0000000FD780: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FD788: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000FD78C: BE882003
	s_cbranch_execz 61035                                      // 0000000FD790: BFA5EE6B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3740>
	v_mad_i64_i32 v[56:57], null, 0x6000, v122, v[130:131]     // 0000000FD794: D6FF7C38 060AF4FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 0000000FD7A0: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 0000000FD7A8: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 0000000FD7AC: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD7B0: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 0000000FD7B4: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 0000000FD7BC: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v64, v57                                   // 0000000FD7C8: 7E804739
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD7CC: BF870091
	v_dual_fmamk_f32 v58, v56, 0xb2a5705f, v58 :: v_dual_sub_f32 v57, v57, v64// 0000000FD7D0: C88A7538 3A388139 B2A5705F
	v_add_f32_e32 v57, v57, v58                                // 0000000FD7DC: 06727539
	v_cvt_i32_f32_e32 v58, v64                                 // 0000000FD7E0: 7E741140
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 0000000FD7E4: 7C3C70FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FD7EC: BF870293
	v_exp_f32_e32 v57, v57                                     // 0000000FD7F0: 7E724B39
	.long 0xd71c0039                                           // 0000000FD7F4: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000000FD7F8: 02027539
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FD7FC: BF870121
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000FD800: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 0000000FD804: 7C3670FF C2B17218
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v137, v59// 0000000FD80C: CA4672FF 38387789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD818: BF870091
	v_add_f32_e32 v56, 1.0, v56                                // 0000000FD81C: 067070F2
	v_div_scale_f32 v58, null, v56, v56, v57                   // 0000000FD820: D6FC7C3A 04E67138
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FD828: BF870291
	v_rcp_f32_e32 v59, v58                                     // 0000000FD82C: 7E76553A
	v_fma_f32 v64, -v58, v59, 1.0                              // 0000000FD830: D6130040 23CA773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FD838: BF8700A1
	v_fmac_f32_e32 v59, v64, v59                               // 0000000FD83C: 56767740
	v_div_scale_f32 v64, vcc_lo, v57, v56, v57                 // 0000000FD840: D6FC6A40 04E67139
	v_mul_f32_e32 v65, v64, v59                                // 0000000FD848: 10827740
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD84C: BF870091
	v_fma_f32 v66, -v58, v65, v64                              // 0000000FD850: D6130042 2502833A
	v_fmac_f32_e32 v65, v66, v59                               // 0000000FD858: 56827742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD85C: BF870091
	v_fma_f32 v58, -v58, v65, v64                              // 0000000FD860: D613003A 2502833A
	v_div_fmas_f32 v58, v58, v59, v65                          // 0000000FD868: D637003A 0506773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FD870: BF870121
	v_div_fixup_f32 v58, v58, v56, v57                         // 0000000FD874: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v122, v[128:129]     // 0000000FD87C: D6FF7C38 0602F4FF 00003000
	v_bfe_u32 v59, v58, 16, 1                                  // 0000000FD888: D610003B 0205213A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FD890: BF870001
	v_add3_u32 v58, v58, v59, 0x7fff                           // 0000000FD894: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 0000000FD8A0: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FD8A8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000FD8AC: BE882004
	s_cbranch_execz 60966                                      // 0000000FD8B0: BFA5EE26 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x374c>
	v_mad_i64_i32 v[56:57], null, 0x6000, v123, v[130:131]     // 0000000FD8B4: D6FF7C38 060AF6FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 0000000FD8C0: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 0000000FD8C8: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 0000000FD8CC: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD8D0: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 0000000FD8D4: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 0000000FD8DC: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 0000000FD8E8: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FD8EC: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 0000000FD8F0: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 0000000FD8F4: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 0000000FD8FC: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FD904: BF870121
	v_add_f32_e32 v57, v57, v58                                // 0000000FD908: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 0000000FD90C: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 0000000FD910: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD914: BF870095
	.long 0xd71c0039                                           // 0000000FD918: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000000FD91C: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000FD920: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 0000000FD924: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD92C: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v134, v60// 0000000FD930: CA4672FF 38387986 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 0000000FD93C: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD940: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 0000000FD944: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 0000000FD94C: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD950: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 0000000FD954: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 0000000FD95C: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 0000000FD960: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD968: BF870091
	v_mul_f32_e32 v64, v60, v59                                // 0000000FD96C: 1080773C
	v_fma_f32 v65, -v58, v64, v60                              // 0000000FD970: D6130041 24F2813A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD978: BF870091
	v_fmac_f32_e32 v64, v65, v59                               // 0000000FD97C: 56807741
	v_fma_f32 v58, -v58, v64, v60                              // 0000000FD980: D613003A 24F2813A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD988: BF870091
	v_div_fmas_f32 v58, v58, v59, v64                          // 0000000FD98C: D637003A 0502773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 0000000FD994: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v123, v[128:129]     // 0000000FD99C: D6FF7C38 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD9A8: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 0000000FD9AC: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 0000000FD9B4: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 0000000FD9C0: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FD9C8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000FD9CC: BE882005
	s_cbranch_execz 60897                                      // 0000000FD9D0: BFA5EDE1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3758>
	v_mad_i64_i32 v[56:57], null, 0x6000, v124, v[130:131]     // 0000000FD9D4: D6FF7C38 060AF8FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 0000000FD9E0: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 0000000FD9E8: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 0000000FD9EC: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FD9F0: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 0000000FD9F4: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 0000000FD9FC: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 0000000FDA08: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FDA0C: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 0000000FDA10: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 0000000FDA14: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 0000000FDA1C: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FDA24: BF870121
	v_add_f32_e32 v57, v57, v58                                // 0000000FDA28: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 0000000FDA2C: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 0000000FDA30: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDA34: BF870095
	.long 0xd71c0039                                           // 0000000FDA38: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000000FDA3C: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000FDA40: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 0000000FDA44: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDA4C: BF870092
	v_cndmask_b32_e32 v56, 0x7f800000, v57, vcc_lo             // 0000000FDA50: 027072FF 7F800000
	v_dual_mul_f32 v57, v135, v61 :: v_dual_add_f32 v56, 1.0, v56// 0000000FDA58: C8C87B87 393870F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDA60: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 0000000FDA64: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 0000000FDA6C: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDA70: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 0000000FDA74: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 0000000FDA7C: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 0000000FDA80: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDA88: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 0000000FDA8C: 107A773C
	v_fma_f32 v64, -v58, v61, v60                              // 0000000FDA90: D6130040 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDA98: BF870091
	v_fmac_f32_e32 v61, v64, v59                               // 0000000FDA9C: 567A7740
	v_fma_f32 v58, -v58, v61, v60                              // 0000000FDAA0: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDAA8: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 0000000FDAAC: D637003A 04F6773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 0000000FDAB4: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v124, v[128:129]     // 0000000FDABC: D6FF7C38 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDAC8: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 0000000FDACC: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 0000000FDAD4: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 0000000FDAE0: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FDAE8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000FDAEC: BE882006
	s_cbranch_execz 60828                                      // 0000000FDAF0: BFA5ED9C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3764>
	v_mad_i64_i32 v[56:57], null, 0x6000, v125, v[130:131]     // 0000000FDAF4: D6FF7C38 060AFAFF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 0000000FDB00: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 0000000FDB08: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 0000000FDB0C: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDB10: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 0000000FDB14: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 0000000FDB1C: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 0000000FDB28: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FDB2C: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 0000000FDB30: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 0000000FDB34: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 0000000FDB3C: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FDB44: BF870121
	v_add_f32_e32 v57, v57, v58                                // 0000000FDB48: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 0000000FDB4C: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 0000000FDB50: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDB54: BF870095
	.long 0xd71c0039                                           // 0000000FDB58: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000000FDB5C: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000FDB60: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 0000000FDB64: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDB6C: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v132, v62// 0000000FDB70: CA4672FF 38387D84 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 0000000FDB7C: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDB80: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 0000000FDB84: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 0000000FDB8C: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDB90: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 0000000FDB94: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 0000000FDB9C: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 0000000FDBA0: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDBA8: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 0000000FDBAC: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 0000000FDBB0: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDBB8: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 0000000FDBBC: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 0000000FDBC0: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDBC8: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 0000000FDBCC: D637003A 04F6773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 0000000FDBD4: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v125, v[128:129]     // 0000000FDBDC: D6FF7C38 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDBE8: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 0000000FDBEC: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 0000000FDBF4: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 0000000FDC00: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FDC08: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000FDC0C: BE882007
	s_cbranch_execz 60759                                      // 0000000FDC10: BFA5ED57 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3770>
	v_mad_i64_i32 v[56:57], null, 0x6000, v126, v[130:131]     // 0000000FDC14: D6FF7C38 060AFCFF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 0000000FDC20: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 0000000FDC28: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 0000000FDC2C: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDC30: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 0000000FDC34: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 0000000FDC3C: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 0000000FDC48: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FDC4C: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 0000000FDC50: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 0000000FDC54: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 0000000FDC5C: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FDC64: BF870121
	v_add_f32_e32 v57, v57, v58                                // 0000000FDC68: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 0000000FDC6C: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 0000000FDC70: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDC74: BF870095
	.long 0xd71c0039                                           // 0000000FDC78: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000000FDC7C: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000FDC80: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 0000000FDC84: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDC8C: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v133, v63// 0000000FDC90: CA4672FF 38387F85 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 0000000FDC9C: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDCA0: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 0000000FDCA4: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 0000000FDCAC: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDCB0: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 0000000FDCB4: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 0000000FDCBC: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 0000000FDCC0: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDCC8: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 0000000FDCCC: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 0000000FDCD0: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDCD8: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 0000000FDCDC: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 0000000FDCE0: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDCE8: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 0000000FDCEC: D637003A 04F6773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 0000000FDCF4: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v126, v[128:129]     // 0000000FDCFC: D6FF7C38 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDD08: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 0000000FDD0C: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 0000000FDD14: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 0000000FDD20: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FDD28: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000FDD2C: BE882000
	s_cbranch_execz 60690                                      // 0000000FDD30: BFA5ED12 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x377c>
	v_mad_i64_i32 v[56:57], null, 0x6000, v140, v[130:131]     // 0000000FDD34: D6FF7C38 060B18FF 00006000
	v_mul_f32_e32 v48, v138, v48                               // 0000000FDD40: 1060618A
	global_load_u16 v56, v[56:57], off offset:800              // 0000000FDD44: DC4A0320 387C0038
	s_waitcnt vmcnt(0)                                         // 0000000FDD4C: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 0000000FDD50: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDD54: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 0000000FDD58: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 0000000FDD60: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 0000000FDD6C: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FDD70: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 0000000FDD74: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 0000000FDD78: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 0000000FDD80: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FDD88: BF870121
	v_add_f32_e32 v57, v57, v58                                // 0000000FDD8C: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 0000000FDD90: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 0000000FDD94: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDD98: BF870095
	.long 0xd71c0039                                           // 0000000FDD9C: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000000FDDA0: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000FDDA4: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 0000000FDDA8: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDDB0: BF870092
	v_cndmask_b32_e32 v56, 0x7f800000, v57, vcc_lo             // 0000000FDDB4: 027072FF 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 0000000FDDBC: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDDC0: BF870091
	v_div_scale_f32 v57, null, v56, v56, v48                   // 0000000FDDC4: D6FC7C39 04C27138
	v_rcp_f32_e32 v58, v57                                     // 0000000FDDCC: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDDD0: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 0000000FDDD4: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 0000000FDDDC: 5674753B
	v_div_scale_f32 v59, vcc_lo, v48, v56, v48                 // 0000000FDDE0: D6FC6A3B 04C27130
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDDE8: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 0000000FDDEC: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 0000000FDDF0: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDDF8: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 0000000FDDFC: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 0000000FDE00: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDE08: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 0000000FDE0C: D6370039 04F27539
	v_div_fixup_f32 v48, v57, v56, v48                         // 0000000FDE14: D6270030 04C27139
	v_mad_i64_i32 v[56:57], null, 0x3000, v140, v[128:129]     // 0000000FDE1C: D6FF7C38 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDE28: BF870092
	v_bfe_u32 v58, v48, 16, 1                                  // 0000000FDE2C: D610003A 02052130
	v_add3_u32 v48, v48, v58, 0x7fff                           // 0000000FDE34: D6550030 03FE7530 00007FFF
	global_store_d16_hi_b16 v[56:57], v48, off offset:288      // 0000000FDE40: DC960120 007C3038
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FDE48: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000FDE4C: BE882001
	s_cbranch_execz 60621                                      // 0000000FDE50: BFA5ECCD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3788>
	v_mad_i64_i32 v[56:57], null, 0x6000, v120, v[130:131]     // 0000000FDE54: D6FF7C38 060AF0FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 0000000FDE60: 1062638B
	global_load_u16 v48, v[56:57], off offset:800              // 0000000FDE64: DC4A0320 307C0038
	s_waitcnt vmcnt(0)                                         // 0000000FDE6C: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 0000000FDE70: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FDE74: BF870121
	v_mul_f32_e32 v56, 0xbfb8aa3b, v48                         // 0000000FDE78: 107060FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 0000000FDE80: 7C3C60FF 42CE8ED0
	v_fma_f32 v57, 0xbfb8aa3b, v48, -v56                       // 0000000FDE88: D6130039 84E260FF BFB8AA3B
	v_rndne_f32_e32 v58, v56                                   // 0000000FDE94: 7E744738
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FDE98: BF870112
	v_fmamk_f32 v57, v48, 0xb2a5705f, v57                      // 0000000FDE9C: 58727330 B2A5705F
	v_sub_f32_e32 v56, v56, v58                                // 0000000FDEA4: 08707538
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FDEA8: BF870121
	v_add_f32_e32 v56, v56, v57                                // 0000000FDEAC: 06707338
	v_cvt_i32_f32_e32 v57, v58                                 // 0000000FDEB0: 7E72113A
	v_exp_f32_e32 v56, v56                                     // 0000000FDEB4: 7E704B38
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDEB8: BF870095
	.long 0xd71c0038                                           // 0000000FDEBC: D71C0038
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                     // 0000000FDEC0: 02027338
	v_cndmask_b32_e32 v56, 0, v56, vcc_lo                      // 0000000FDEC4: 02707080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 0000000FDEC8: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDED0: BF870092
	v_cndmask_b32_e32 v48, 0x7f800000, v56, vcc_lo             // 0000000FDED4: 026070FF 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 0000000FDEDC: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDEE0: BF870091
	v_div_scale_f32 v56, null, v48, v48, v49                   // 0000000FDEE4: D6FC7C38 04C66130
	v_rcp_f32_e32 v57, v56                                     // 0000000FDEEC: 7E725538
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDEF0: BF870095
	v_fma_f32 v58, -v56, v57, 1.0                              // 0000000FDEF4: D613003A 23CA7338
	v_fmac_f32_e32 v57, v58, v57                               // 0000000FDEFC: 5672733A
	v_div_scale_f32 v58, vcc_lo, v49, v48, v49                 // 0000000FDF00: D6FC6A3A 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDF08: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 0000000FDF0C: 1076733A
	v_fma_f32 v60, -v56, v59, v58                              // 0000000FDF10: D613003C 24EA7738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDF18: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 0000000FDF1C: 5676733C
	v_fma_f32 v56, -v56, v59, v58                              // 0000000FDF20: D6130038 24EA7738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDF28: BF870091
	v_div_fmas_f32 v56, v56, v57, v59                          // 0000000FDF2C: D6370038 04EE7338
	v_div_fixup_f32 v56, v56, v48, v49                         // 0000000FDF34: D6270038 04C66138
	v_mad_i64_i32 v[48:49], null, 0x3000, v120, v[128:129]     // 0000000FDF3C: D6FF7C30 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDF48: BF870092
	v_bfe_u32 v57, v56, 16, 1                                  // 0000000FDF4C: D6100039 02052138
	v_add3_u32 v56, v56, v57, 0x7fff                           // 0000000FDF54: D6550038 03FE7338 00007FFF
	global_store_d16_hi_b16 v[48:49], v56, off offset:288      // 0000000FDF60: DC960120 007C3830
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FDF68: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000FDF6C: BE882002
	s_cbranch_execz 60552                                      // 0000000FDF70: BFA5EC88 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3794>
	v_mad_i64_i32 v[48:49], null, 0x6000, v121, v[130:131]     // 0000000FDF74: D6FF7C30 060AF2FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 0000000FDF80: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 0000000FDF88: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 0000000FDF8C: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDF90: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 0000000FDF94: 106260FF BFB8AA3B
	v_fma_f32 v56, 0xbfb8aa3b, v48, -v49                       // 0000000FDF9C: D6130038 84C660FF BFB8AA3B
	v_rndne_f32_e32 v57, v49                                   // 0000000FDFA8: 7E724731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FDFAC: BF870221
	v_sub_f32_e32 v49, v49, v57                                // 0000000FDFB0: 08627331
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 0000000FDFB4: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v56, v48, 0xb2a5705f, v56                      // 0000000FDFBC: 58707130 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FDFC4: BF870121
	v_add_f32_e32 v49, v49, v56                                // 0000000FDFC8: 06627131
	v_cvt_i32_f32_e32 v56, v57                                 // 0000000FDFCC: 7E701139
	v_exp_f32_e32 v49, v49                                     // 0000000FDFD0: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDFD4: BF870095
	.long 0xd71c0031                                           // 0000000FDFD8: D71C0031
	v_cndmask_b32_e32 v1, v49, v56, vcc_lo                     // 0000000FDFDC: 02027131
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000000FDFE0: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 0000000FDFE4: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FDFEC: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v136, v50// 0000000FDFF0: CA4662FF 30306588 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 0000000FDFFC: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE000: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 0000000FE004: D6FC7C32 04C66130
	v_rcp_f32_e32 v56, v50                                     // 0000000FE00C: 7E705532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE010: BF870095
	v_fma_f32 v57, -v50, v56, 1.0                              // 0000000FE014: D6130039 23CA7132
	v_fmac_f32_e32 v56, v57, v56                               // 0000000FE01C: 56707139
	v_div_scale_f32 v57, vcc_lo, v49, v48, v49                 // 0000000FE020: D6FC6A39 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE028: BF870091
	v_mul_f32_e32 v58, v57, v56                                // 0000000FE02C: 10747139
	v_fma_f32 v59, -v50, v58, v57                              // 0000000FE030: D613003B 24E67532
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE038: BF870091
	v_fmac_f32_e32 v58, v59, v56                               // 0000000FE03C: 5674713B
	v_fma_f32 v50, -v50, v58, v57                              // 0000000FE040: D6130032 24E67532
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE048: BF870091
	v_div_fmas_f32 v50, v50, v56, v58                          // 0000000FE04C: D6370032 04EA7132
	v_div_fixup_f32 v50, v50, v48, v49                         // 0000000FE054: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v121, v[128:129]     // 0000000FE05C: D6FF7C30 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE068: BF870092
	v_bfe_u32 v56, v50, 16, 1                                  // 0000000FE06C: D6100038 02052132
	v_add3_u32 v50, v50, v56, 0x7fff                           // 0000000FE074: D6550032 03FE7132 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 0000000FE080: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FE088: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000FE08C: BE882003
	s_cbranch_execz 60483                                      // 0000000FE090: BFA5EC43 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37a0>
	v_mad_i64_i32 v[48:49], null, 0x6000, v122, v[130:131]     // 0000000FE094: D6FF7C30 060AF4FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 0000000FE0A0: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 0000000FE0A8: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 0000000FE0AC: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE0B0: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 0000000FE0B4: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 0000000FE0BC: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v56, v49                                   // 0000000FE0C8: 7E704731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE0CC: BF870091
	v_dual_fmamk_f32 v50, v48, 0xb2a5705f, v50 :: v_dual_sub_f32 v49, v49, v56// 0000000FE0D0: C88A6530 32307131 B2A5705F
	v_add_f32_e32 v49, v49, v50                                // 0000000FE0DC: 06626531
	v_cvt_i32_f32_e32 v50, v56                                 // 0000000FE0E0: 7E641138
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 0000000FE0E4: 7C3C60FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FE0EC: BF870293
	v_exp_f32_e32 v49, v49                                     // 0000000FE0F0: 7E624B31
	.long 0xd71c0031                                           // 0000000FE0F4: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 0000000FE0F8: 02026531
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FE0FC: BF870121
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000000FE100: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 0000000FE104: 7C3660FF C2B17218
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v137, v51// 0000000FE10C: CA4662FF 30306789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE118: BF870091
	v_add_f32_e32 v48, 1.0, v48                                // 0000000FE11C: 066060F2
	v_div_scale_f32 v50, null, v48, v48, v49                   // 0000000FE120: D6FC7C32 04C66130
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FE128: BF870291
	v_rcp_f32_e32 v51, v50                                     // 0000000FE12C: 7E665532
	v_fma_f32 v56, -v50, v51, 1.0                              // 0000000FE130: D6130038 23CA6732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FE138: BF8700A1
	v_fmac_f32_e32 v51, v56, v51                               // 0000000FE13C: 56666738
	v_div_scale_f32 v56, vcc_lo, v49, v48, v49                 // 0000000FE140: D6FC6A38 04C66131
	v_mul_f32_e32 v57, v56, v51                                // 0000000FE148: 10726738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE14C: BF870091
	v_fma_f32 v58, -v50, v57, v56                              // 0000000FE150: D613003A 24E27332
	v_fmac_f32_e32 v57, v58, v51                               // 0000000FE158: 5672673A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE15C: BF870091
	v_fma_f32 v50, -v50, v57, v56                              // 0000000FE160: D6130032 24E27332
	v_div_fmas_f32 v50, v50, v51, v57                          // 0000000FE168: D6370032 04E66732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FE170: BF870121
	v_div_fixup_f32 v50, v50, v48, v49                         // 0000000FE174: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v122, v[128:129]     // 0000000FE17C: D6FF7C30 0602F4FF 00003000
	v_bfe_u32 v51, v50, 16, 1                                  // 0000000FE188: D6100033 02052132
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FE190: BF870001
	v_add3_u32 v50, v50, v51, 0x7fff                           // 0000000FE194: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 0000000FE1A0: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FE1A8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000FE1AC: BE882004
	s_cbranch_execz 60414                                      // 0000000FE1B0: BFA5EBFE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37ac>
	v_mad_i64_i32 v[48:49], null, 0x6000, v123, v[130:131]     // 0000000FE1B4: D6FF7C30 060AF6FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 0000000FE1C0: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 0000000FE1C8: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 0000000FE1CC: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE1D0: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 0000000FE1D4: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 0000000FE1DC: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 0000000FE1E8: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FE1EC: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 0000000FE1F0: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 0000000FE1F4: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 0000000FE1FC: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FE204: BF870121
	v_add_f32_e32 v49, v49, v50                                // 0000000FE208: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 0000000FE20C: 7E641133
	v_exp_f32_e32 v49, v49                                     // 0000000FE210: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE214: BF870095
	.long 0xd71c0031                                           // 0000000FE218: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 0000000FE21C: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000000FE220: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 0000000FE224: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE22C: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v134, v52// 0000000FE230: CA4662FF 30306986 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 0000000FE23C: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE240: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 0000000FE244: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 0000000FE24C: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE250: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 0000000FE254: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 0000000FE25C: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 0000000FE260: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE268: BF870091
	v_mul_f32_e32 v56, v52, v51                                // 0000000FE26C: 10706734
	v_fma_f32 v57, -v50, v56, v52                              // 0000000FE270: D6130039 24D27132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE278: BF870091
	v_fmac_f32_e32 v56, v57, v51                               // 0000000FE27C: 56706739
	v_fma_f32 v50, -v50, v56, v52                              // 0000000FE280: D6130032 24D27132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE288: BF870091
	v_div_fmas_f32 v50, v50, v51, v56                          // 0000000FE28C: D6370032 04E26732
	v_div_fixup_f32 v50, v50, v48, v49                         // 0000000FE294: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v123, v[128:129]     // 0000000FE29C: D6FF7C30 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE2A8: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 0000000FE2AC: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 0000000FE2B4: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 0000000FE2C0: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FE2C8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000FE2CC: BE882005
	s_cbranch_execz 60345                                      // 0000000FE2D0: BFA5EBB9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37b8>
	v_mad_i64_i32 v[48:49], null, 0x6000, v124, v[130:131]     // 0000000FE2D4: D6FF7C30 060AF8FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 0000000FE2E0: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 0000000FE2E8: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 0000000FE2EC: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE2F0: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 0000000FE2F4: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 0000000FE2FC: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 0000000FE308: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FE30C: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 0000000FE310: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 0000000FE314: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 0000000FE31C: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FE324: BF870121
	v_add_f32_e32 v49, v49, v50                                // 0000000FE328: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 0000000FE32C: 7E641133
	v_exp_f32_e32 v49, v49                                     // 0000000FE330: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE334: BF870095
	.long 0xd71c0031                                           // 0000000FE338: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 0000000FE33C: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000000FE340: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 0000000FE344: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE34C: BF870092
	v_cndmask_b32_e32 v48, 0x7f800000, v49, vcc_lo             // 0000000FE350: 026062FF 7F800000
	v_dual_mul_f32 v49, v135, v53 :: v_dual_add_f32 v48, 1.0, v48// 0000000FE358: C8C86B87 313060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE360: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 0000000FE364: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 0000000FE36C: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE370: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 0000000FE374: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 0000000FE37C: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 0000000FE380: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE388: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 0000000FE38C: 106A6734
	v_fma_f32 v56, -v50, v53, v52                              // 0000000FE390: D6130038 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE398: BF870091
	v_fmac_f32_e32 v53, v56, v51                               // 0000000FE39C: 566A6738
	v_fma_f32 v50, -v50, v53, v52                              // 0000000FE3A0: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE3A8: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 0000000FE3AC: D6370032 04D66732
	v_div_fixup_f32 v50, v50, v48, v49                         // 0000000FE3B4: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v124, v[128:129]     // 0000000FE3BC: D6FF7C30 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE3C8: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 0000000FE3CC: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 0000000FE3D4: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 0000000FE3E0: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FE3E8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000FE3EC: BE882006
	s_cbranch_execz 60276                                      // 0000000FE3F0: BFA5EB74 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37c4>
	v_mad_i64_i32 v[48:49], null, 0x6000, v125, v[130:131]     // 0000000FE3F4: D6FF7C30 060AFAFF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 0000000FE400: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 0000000FE408: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 0000000FE40C: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE410: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 0000000FE414: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 0000000FE41C: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 0000000FE428: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FE42C: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 0000000FE430: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 0000000FE434: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 0000000FE43C: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FE444: BF870121
	v_add_f32_e32 v49, v49, v50                                // 0000000FE448: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 0000000FE44C: 7E641133
	v_exp_f32_e32 v49, v49                                     // 0000000FE450: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE454: BF870095
	.long 0xd71c0031                                           // 0000000FE458: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 0000000FE45C: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000000FE460: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 0000000FE464: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE46C: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v132, v54// 0000000FE470: CA4662FF 30306D84 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 0000000FE47C: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE480: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 0000000FE484: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 0000000FE48C: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE490: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 0000000FE494: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 0000000FE49C: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 0000000FE4A0: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE4A8: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 0000000FE4AC: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 0000000FE4B0: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE4B8: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 0000000FE4BC: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 0000000FE4C0: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE4C8: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 0000000FE4CC: D6370032 04D66732
	v_div_fixup_f32 v50, v50, v48, v49                         // 0000000FE4D4: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v125, v[128:129]     // 0000000FE4DC: D6FF7C30 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE4E8: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 0000000FE4EC: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 0000000FE4F4: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 0000000FE500: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FE508: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000FE50C: BE882007
	s_cbranch_execz 60207                                      // 0000000FE510: BFA5EB2F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37d0>
	v_mad_i64_i32 v[48:49], null, 0x6000, v126, v[130:131]     // 0000000FE514: D6FF7C30 060AFCFF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 0000000FE520: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 0000000FE528: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 0000000FE52C: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE530: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 0000000FE534: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 0000000FE53C: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 0000000FE548: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FE54C: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 0000000FE550: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 0000000FE554: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 0000000FE55C: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FE564: BF870121
	v_add_f32_e32 v49, v49, v50                                // 0000000FE568: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 0000000FE56C: 7E641133
	v_exp_f32_e32 v49, v49                                     // 0000000FE570: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE574: BF870095
	.long 0xd71c0031                                           // 0000000FE578: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 0000000FE57C: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000000FE580: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 0000000FE584: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE58C: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v133, v55// 0000000FE590: CA4662FF 30306F85 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 0000000FE59C: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE5A0: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 0000000FE5A4: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 0000000FE5AC: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE5B0: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 0000000FE5B4: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 0000000FE5BC: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 0000000FE5C0: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE5C8: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 0000000FE5CC: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 0000000FE5D0: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE5D8: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 0000000FE5DC: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 0000000FE5E0: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE5E8: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 0000000FE5EC: D6370032 04D66732
	v_div_fixup_f32 v50, v50, v48, v49                         // 0000000FE5F4: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v126, v[128:129]     // 0000000FE5FC: D6FF7C30 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE608: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 0000000FE60C: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 0000000FE614: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 0000000FE620: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FE628: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000FE62C: BE882000
	s_cbranch_execz 60138                                      // 0000000FE630: BFA5EAEA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37dc>
	v_mad_i64_i32 v[48:49], null, 0x6000, v140, v[130:131]     // 0000000FE634: D6FF7C30 060B18FF 00006000
	v_mul_f32_e32 v40, v138, v40                               // 0000000FE640: 1050518A
	global_load_u16 v48, v[48:49], off offset:832              // 0000000FE644: DC4A0340 307C0030
	s_waitcnt vmcnt(0)                                         // 0000000FE64C: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 0000000FE650: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE654: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 0000000FE658: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 0000000FE660: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 0000000FE66C: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FE670: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 0000000FE674: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 0000000FE678: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 0000000FE680: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FE688: BF870121
	v_add_f32_e32 v49, v49, v50                                // 0000000FE68C: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 0000000FE690: 7E641133
	v_exp_f32_e32 v49, v49                                     // 0000000FE694: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE698: BF870095
	.long 0xd71c0031                                           // 0000000FE69C: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 0000000FE6A0: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000000FE6A4: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 0000000FE6A8: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE6B0: BF870092
	v_cndmask_b32_e32 v48, 0x7f800000, v49, vcc_lo             // 0000000FE6B4: 026062FF 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 0000000FE6BC: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE6C0: BF870091
	v_div_scale_f32 v49, null, v48, v48, v40                   // 0000000FE6C4: D6FC7C31 04A26130
	v_rcp_f32_e32 v50, v49                                     // 0000000FE6CC: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE6D0: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 0000000FE6D4: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 0000000FE6DC: 56646533
	v_div_scale_f32 v51, vcc_lo, v40, v48, v40                 // 0000000FE6E0: D6FC6A33 04A26128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE6E8: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 0000000FE6EC: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 0000000FE6F0: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE6F8: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 0000000FE6FC: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 0000000FE700: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE708: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 0000000FE70C: D6370031 04D26531
	v_div_fixup_f32 v40, v49, v48, v40                         // 0000000FE714: D6270028 04A26131
	v_mad_i64_i32 v[48:49], null, 0x3000, v140, v[128:129]     // 0000000FE71C: D6FF7C30 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE728: BF870092
	v_bfe_u32 v50, v40, 16, 1                                  // 0000000FE72C: D6100032 02052128
	v_add3_u32 v40, v40, v50, 0x7fff                           // 0000000FE734: D6550028 03FE6528 00007FFF
	global_store_d16_hi_b16 v[48:49], v40, off offset:320      // 0000000FE740: DC960140 007C2830
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FE748: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000FE74C: BE882001
	s_cbranch_execz 60069                                      // 0000000FE750: BFA5EAA5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37e8>
	v_mad_i64_i32 v[48:49], null, 0x6000, v120, v[130:131]     // 0000000FE754: D6FF7C30 060AF0FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 0000000FE760: 1052538B
	global_load_u16 v40, v[48:49], off offset:832              // 0000000FE764: DC4A0340 287C0030
	s_waitcnt vmcnt(0)                                         // 0000000FE76C: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 0000000FE770: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FE774: BF870121
	v_mul_f32_e32 v48, 0xbfb8aa3b, v40                         // 0000000FE778: 106050FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 0000000FE780: 7C3C50FF 42CE8ED0
	v_fma_f32 v49, 0xbfb8aa3b, v40, -v48                       // 0000000FE788: D6130031 84C250FF BFB8AA3B
	v_rndne_f32_e32 v50, v48                                   // 0000000FE794: 7E644730
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FE798: BF870112
	v_fmamk_f32 v49, v40, 0xb2a5705f, v49                      // 0000000FE79C: 58626328 B2A5705F
	v_sub_f32_e32 v48, v48, v50                                // 0000000FE7A4: 08606530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FE7A8: BF870121
	v_add_f32_e32 v48, v48, v49                                // 0000000FE7AC: 06606330
	v_cvt_i32_f32_e32 v49, v50                                 // 0000000FE7B0: 7E621132
	v_exp_f32_e32 v48, v48                                     // 0000000FE7B4: 7E604B30
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE7B8: BF870095
	.long 0xd71c0030                                           // 0000000FE7BC: D71C0030
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                     // 0000000FE7C0: 02026330
	v_cndmask_b32_e32 v48, 0, v48, vcc_lo                      // 0000000FE7C4: 02606080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 0000000FE7C8: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE7D0: BF870092
	v_cndmask_b32_e32 v40, 0x7f800000, v48, vcc_lo             // 0000000FE7D4: 025060FF 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 0000000FE7DC: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE7E0: BF870091
	v_div_scale_f32 v48, null, v40, v40, v41                   // 0000000FE7E4: D6FC7C30 04A65128
	v_rcp_f32_e32 v49, v48                                     // 0000000FE7EC: 7E625530
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE7F0: BF870095
	v_fma_f32 v50, -v48, v49, 1.0                              // 0000000FE7F4: D6130032 23CA6330
	v_fmac_f32_e32 v49, v50, v49                               // 0000000FE7FC: 56626332
	v_div_scale_f32 v50, vcc_lo, v41, v40, v41                 // 0000000FE800: D6FC6A32 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE808: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 0000000FE80C: 10666332
	v_fma_f32 v52, -v48, v51, v50                              // 0000000FE810: D6130034 24CA6730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE818: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 0000000FE81C: 56666334
	v_fma_f32 v48, -v48, v51, v50                              // 0000000FE820: D6130030 24CA6730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE828: BF870091
	v_div_fmas_f32 v48, v48, v49, v51                          // 0000000FE82C: D6370030 04CE6330
	v_div_fixup_f32 v48, v48, v40, v41                         // 0000000FE834: D6270030 04A65130
	v_mad_i64_i32 v[40:41], null, 0x3000, v120, v[128:129]     // 0000000FE83C: D6FF7C28 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE848: BF870092
	v_bfe_u32 v49, v48, 16, 1                                  // 0000000FE84C: D6100031 02052130
	v_add3_u32 v48, v48, v49, 0x7fff                           // 0000000FE854: D6550030 03FE6330 00007FFF
	global_store_d16_hi_b16 v[40:41], v48, off offset:320      // 0000000FE860: DC960140 007C3028
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FE868: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000FE86C: BE882002
	s_cbranch_execz 60000                                      // 0000000FE870: BFA5EA60 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37f4>
	v_mad_i64_i32 v[40:41], null, 0x6000, v121, v[130:131]     // 0000000FE874: D6FF7C28 060AF2FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 0000000FE880: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 0000000FE888: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 0000000FE88C: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE890: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 0000000FE894: 105250FF BFB8AA3B
	v_fma_f32 v48, 0xbfb8aa3b, v40, -v41                       // 0000000FE89C: D6130030 84A650FF BFB8AA3B
	v_rndne_f32_e32 v49, v41                                   // 0000000FE8A8: 7E624729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FE8AC: BF870221
	v_sub_f32_e32 v41, v41, v49                                // 0000000FE8B0: 08526329
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 0000000FE8B4: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v48, v40, 0xb2a5705f, v48                      // 0000000FE8BC: 58606128 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FE8C4: BF870121
	v_add_f32_e32 v41, v41, v48                                // 0000000FE8C8: 06526129
	v_cvt_i32_f32_e32 v48, v49                                 // 0000000FE8CC: 7E601131
	v_exp_f32_e32 v41, v41                                     // 0000000FE8D0: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE8D4: BF870095
	.long 0xd71c0029                                           // 0000000FE8D8: D71C0029
	v_cndmask_b32_e32 v1, v41, v48, vcc_lo                     // 0000000FE8DC: 02026129
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000FE8E0: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 0000000FE8E4: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE8EC: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v136, v42// 0000000FE8F0: CA4652FF 28285588 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 0000000FE8FC: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE900: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 0000000FE904: D6FC7C2A 04A65128
	v_rcp_f32_e32 v48, v42                                     // 0000000FE90C: 7E60552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE910: BF870095
	v_fma_f32 v49, -v42, v48, 1.0                              // 0000000FE914: D6130031 23CA612A
	v_fmac_f32_e32 v48, v49, v48                               // 0000000FE91C: 56606131
	v_div_scale_f32 v49, vcc_lo, v41, v40, v41                 // 0000000FE920: D6FC6A31 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE928: BF870091
	v_mul_f32_e32 v50, v49, v48                                // 0000000FE92C: 10646131
	v_fma_f32 v51, -v42, v50, v49                              // 0000000FE930: D6130033 24C6652A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE938: BF870091
	v_fmac_f32_e32 v50, v51, v48                               // 0000000FE93C: 56646133
	v_fma_f32 v42, -v42, v50, v49                              // 0000000FE940: D613002A 24C6652A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE948: BF870091
	v_div_fmas_f32 v42, v42, v48, v50                          // 0000000FE94C: D637002A 04CA612A
	v_div_fixup_f32 v42, v42, v40, v41                         // 0000000FE954: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v121, v[128:129]     // 0000000FE95C: D6FF7C28 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE968: BF870092
	v_bfe_u32 v48, v42, 16, 1                                  // 0000000FE96C: D6100030 0205212A
	v_add3_u32 v42, v42, v48, 0x7fff                           // 0000000FE974: D655002A 03FE612A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 0000000FE980: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FE988: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000FE98C: BE882003
	s_cbranch_execz 59931                                      // 0000000FE990: BFA5EA1B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3800>
	v_mad_i64_i32 v[40:41], null, 0x6000, v122, v[130:131]     // 0000000FE994: D6FF7C28 060AF4FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 0000000FE9A0: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 0000000FE9A8: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 0000000FE9AC: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE9B0: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 0000000FE9B4: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 0000000FE9BC: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v48, v41                                   // 0000000FE9C8: 7E604729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FE9CC: BF870091
	v_dual_fmamk_f32 v42, v40, 0xb2a5705f, v42 :: v_dual_sub_f32 v41, v41, v48// 0000000FE9D0: C88A5528 2A286129 B2A5705F
	v_add_f32_e32 v41, v41, v42                                // 0000000FE9DC: 06525529
	v_cvt_i32_f32_e32 v42, v48                                 // 0000000FE9E0: 7E541130
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 0000000FE9E4: 7C3C50FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FE9EC: BF870293
	v_exp_f32_e32 v41, v41                                     // 0000000FE9F0: 7E524B29
	.long 0xd71c0029                                           // 0000000FE9F4: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000000FE9F8: 02025529
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FE9FC: BF870121
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000FEA00: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 0000000FEA04: 7C3650FF C2B17218
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v137, v43// 0000000FEA0C: CA4652FF 28285789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEA18: BF870091
	v_add_f32_e32 v40, 1.0, v40                                // 0000000FEA1C: 065050F2
	v_div_scale_f32 v42, null, v40, v40, v41                   // 0000000FEA20: D6FC7C2A 04A65128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FEA28: BF870291
	v_rcp_f32_e32 v43, v42                                     // 0000000FEA2C: 7E56552A
	v_fma_f32 v48, -v42, v43, 1.0                              // 0000000FEA30: D6130030 23CA572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FEA38: BF8700A1
	v_fmac_f32_e32 v43, v48, v43                               // 0000000FEA3C: 56565730
	v_div_scale_f32 v48, vcc_lo, v41, v40, v41                 // 0000000FEA40: D6FC6A30 04A65129
	v_mul_f32_e32 v49, v48, v43                                // 0000000FEA48: 10625730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEA4C: BF870091
	v_fma_f32 v50, -v42, v49, v48                              // 0000000FEA50: D6130032 24C2632A
	v_fmac_f32_e32 v49, v50, v43                               // 0000000FEA58: 56625732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEA5C: BF870091
	v_fma_f32 v42, -v42, v49, v48                              // 0000000FEA60: D613002A 24C2632A
	v_div_fmas_f32 v42, v42, v43, v49                          // 0000000FEA68: D637002A 04C6572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FEA70: BF870121
	v_div_fixup_f32 v42, v42, v40, v41                         // 0000000FEA74: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v122, v[128:129]     // 0000000FEA7C: D6FF7C28 0602F4FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 0000000FEA88: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FEA90: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000000FEA94: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 0000000FEAA0: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FEAA8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000FEAAC: BE882004
	s_cbranch_execz 59862                                      // 0000000FEAB0: BFA5E9D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x380c>
	v_mad_i64_i32 v[40:41], null, 0x6000, v123, v[130:131]     // 0000000FEAB4: D6FF7C28 060AF6FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 0000000FEAC0: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 0000000FEAC8: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 0000000FEACC: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEAD0: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 0000000FEAD4: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 0000000FEADC: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000000FEAE8: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FEAEC: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 0000000FEAF0: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 0000000FEAF4: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 0000000FEAFC: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FEB04: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000000FEB08: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000000FEB0C: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 0000000FEB10: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEB14: BF870095
	.long 0xd71c0029                                           // 0000000FEB18: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000000FEB1C: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000FEB20: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 0000000FEB24: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEB2C: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v134, v44// 0000000FEB30: CA4652FF 28285986 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 0000000FEB3C: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEB40: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 0000000FEB44: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 0000000FEB4C: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEB50: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000000FEB54: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000000FEB5C: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 0000000FEB60: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEB68: BF870091
	v_mul_f32_e32 v48, v44, v43                                // 0000000FEB6C: 1060572C
	v_fma_f32 v49, -v42, v48, v44                              // 0000000FEB70: D6130031 24B2612A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEB78: BF870091
	v_fmac_f32_e32 v48, v49, v43                               // 0000000FEB7C: 56605731
	v_fma_f32 v42, -v42, v48, v44                              // 0000000FEB80: D613002A 24B2612A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEB88: BF870091
	v_div_fmas_f32 v42, v42, v43, v48                          // 0000000FEB8C: D637002A 04C2572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 0000000FEB94: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v123, v[128:129]     // 0000000FEB9C: D6FF7C28 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEBA8: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 0000000FEBAC: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000000FEBB4: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 0000000FEBC0: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FEBC8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000FEBCC: BE882005
	s_cbranch_execz 59793                                      // 0000000FEBD0: BFA5E991 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3818>
	v_mad_i64_i32 v[40:41], null, 0x6000, v124, v[130:131]     // 0000000FEBD4: D6FF7C28 060AF8FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 0000000FEBE0: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 0000000FEBE8: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 0000000FEBEC: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEBF0: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 0000000FEBF4: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 0000000FEBFC: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000000FEC08: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FEC0C: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 0000000FEC10: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 0000000FEC14: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 0000000FEC1C: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FEC24: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000000FEC28: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000000FEC2C: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 0000000FEC30: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEC34: BF870095
	.long 0xd71c0029                                           // 0000000FEC38: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000000FEC3C: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000FEC40: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 0000000FEC44: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEC4C: BF870092
	v_cndmask_b32_e32 v40, 0x7f800000, v41, vcc_lo             // 0000000FEC50: 025052FF 7F800000
	v_dual_mul_f32 v41, v135, v45 :: v_dual_add_f32 v40, 1.0, v40// 0000000FEC58: C8C85B87 292850F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEC60: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 0000000FEC64: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 0000000FEC6C: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEC70: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000000FEC74: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000000FEC7C: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 0000000FEC80: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEC88: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 0000000FEC8C: 105A572C
	v_fma_f32 v48, -v42, v45, v44                              // 0000000FEC90: D6130030 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEC98: BF870091
	v_fmac_f32_e32 v45, v48, v43                               // 0000000FEC9C: 565A5730
	v_fma_f32 v42, -v42, v45, v44                              // 0000000FECA0: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FECA8: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 0000000FECAC: D637002A 04B6572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 0000000FECB4: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v124, v[128:129]     // 0000000FECBC: D6FF7C28 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FECC8: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 0000000FECCC: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000000FECD4: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 0000000FECE0: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FECE8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000FECEC: BE882006
	s_cbranch_execz 59724                                      // 0000000FECF0: BFA5E94C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3824>
	v_mad_i64_i32 v[40:41], null, 0x6000, v125, v[130:131]     // 0000000FECF4: D6FF7C28 060AFAFF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 0000000FED00: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 0000000FED08: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 0000000FED0C: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FED10: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 0000000FED14: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 0000000FED1C: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000000FED28: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FED2C: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 0000000FED30: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 0000000FED34: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 0000000FED3C: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FED44: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000000FED48: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000000FED4C: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 0000000FED50: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FED54: BF870095
	.long 0xd71c0029                                           // 0000000FED58: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000000FED5C: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000FED60: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 0000000FED64: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FED6C: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v132, v46// 0000000FED70: CA4652FF 28285D84 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 0000000FED7C: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FED80: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 0000000FED84: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 0000000FED8C: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FED90: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000000FED94: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000000FED9C: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 0000000FEDA0: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEDA8: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 0000000FEDAC: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 0000000FEDB0: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEDB8: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 0000000FEDBC: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 0000000FEDC0: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEDC8: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 0000000FEDCC: D637002A 04B6572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 0000000FEDD4: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v125, v[128:129]     // 0000000FEDDC: D6FF7C28 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEDE8: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 0000000FEDEC: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000000FEDF4: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 0000000FEE00: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FEE08: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000FEE0C: BE882007
	s_cbranch_execz 59655                                      // 0000000FEE10: BFA5E907 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3830>
	v_mad_i64_i32 v[40:41], null, 0x6000, v126, v[130:131]     // 0000000FEE14: D6FF7C28 060AFCFF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 0000000FEE20: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 0000000FEE28: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 0000000FEE2C: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEE30: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 0000000FEE34: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 0000000FEE3C: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000000FEE48: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FEE4C: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 0000000FEE50: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 0000000FEE54: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 0000000FEE5C: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FEE64: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000000FEE68: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000000FEE6C: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 0000000FEE70: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEE74: BF870095
	.long 0xd71c0029                                           // 0000000FEE78: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000000FEE7C: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000FEE80: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 0000000FEE84: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEE8C: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v133, v47// 0000000FEE90: CA4652FF 28285F85 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 0000000FEE9C: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEEA0: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 0000000FEEA4: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 0000000FEEAC: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEEB0: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000000FEEB4: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000000FEEBC: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 0000000FEEC0: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEEC8: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 0000000FEECC: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 0000000FEED0: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEED8: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 0000000FEEDC: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 0000000FEEE0: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEEE8: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 0000000FEEEC: D637002A 04B6572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 0000000FEEF4: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v126, v[128:129]     // 0000000FEEFC: D6FF7C28 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEF08: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 0000000FEF0C: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000000FEF14: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 0000000FEF20: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FEF28: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000FEF2C: BE882000
	s_cbranch_execz 59586                                      // 0000000FEF30: BFA5E8C2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x383c>
	v_mad_i64_i32 v[40:41], null, 0x6000, v140, v[130:131]     // 0000000FEF34: D6FF7C28 060B18FF 00006000
	v_mul_f32_e32 v32, v138, v32                               // 0000000FEF40: 1040418A
	global_load_u16 v40, v[40:41], off offset:864              // 0000000FEF44: DC4A0360 287C0028
	s_waitcnt vmcnt(0)                                         // 0000000FEF4C: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 0000000FEF50: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEF54: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 0000000FEF58: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 0000000FEF60: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000000FEF6C: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FEF70: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 0000000FEF74: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 0000000FEF78: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 0000000FEF80: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FEF88: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000000FEF8C: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000000FEF90: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 0000000FEF94: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEF98: BF870095
	.long 0xd71c0029                                           // 0000000FEF9C: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000000FEFA0: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000FEFA4: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 0000000FEFA8: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEFB0: BF870092
	v_cndmask_b32_e32 v40, 0x7f800000, v41, vcc_lo             // 0000000FEFB4: 025052FF 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 0000000FEFBC: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEFC0: BF870091
	v_div_scale_f32 v41, null, v40, v40, v32                   // 0000000FEFC4: D6FC7C29 04825128
	v_rcp_f32_e32 v42, v41                                     // 0000000FEFCC: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEFD0: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 0000000FEFD4: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 0000000FEFDC: 5654552B
	v_div_scale_f32 v43, vcc_lo, v32, v40, v32                 // 0000000FEFE0: D6FC6A2B 04825120
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEFE8: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 0000000FEFEC: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 0000000FEFF0: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FEFF8: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 0000000FEFFC: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 0000000FF000: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF008: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 0000000FF00C: D6370029 04B25529
	v_div_fixup_f32 v32, v41, v40, v32                         // 0000000FF014: D6270020 04825129
	v_mad_i64_i32 v[40:41], null, 0x3000, v140, v[128:129]     // 0000000FF01C: D6FF7C28 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF028: BF870092
	v_bfe_u32 v42, v32, 16, 1                                  // 0000000FF02C: D610002A 02052120
	v_add3_u32 v32, v32, v42, 0x7fff                           // 0000000FF034: D6550020 03FE5520 00007FFF
	global_store_d16_hi_b16 v[40:41], v32, off offset:352      // 0000000FF040: DC960160 007C2028
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FF048: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000FF04C: BE882001
	s_cbranch_execz 59517                                      // 0000000FF050: BFA5E87D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3848>
	v_mad_i64_i32 v[40:41], null, 0x6000, v120, v[130:131]     // 0000000FF054: D6FF7C28 060AF0FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 0000000FF060: 1042438B
	global_load_u16 v32, v[40:41], off offset:864              // 0000000FF064: DC4A0360 207C0028
	s_waitcnt vmcnt(0)                                         // 0000000FF06C: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 0000000FF070: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF074: BF870121
	v_mul_f32_e32 v40, 0xbfb8aa3b, v32                         // 0000000FF078: 105040FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 0000000FF080: 7C3C40FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v32, -v40                       // 0000000FF088: D6130029 84A240FF BFB8AA3B
	v_rndne_f32_e32 v42, v40                                   // 0000000FF094: 7E544728
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FF098: BF870112
	v_fmamk_f32 v41, v32, 0xb2a5705f, v41                      // 0000000FF09C: 58525320 B2A5705F
	v_sub_f32_e32 v40, v40, v42                                // 0000000FF0A4: 08505528
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF0A8: BF870121
	v_add_f32_e32 v40, v40, v41                                // 0000000FF0AC: 06505328
	v_cvt_i32_f32_e32 v41, v42                                 // 0000000FF0B0: 7E52112A
	v_exp_f32_e32 v40, v40                                     // 0000000FF0B4: 7E504B28
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF0B8: BF870095
	.long 0xd71c0028                                           // 0000000FF0BC: D71C0028
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                     // 0000000FF0C0: 02025328
	v_cndmask_b32_e32 v40, 0, v40, vcc_lo                      // 0000000FF0C4: 02505080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 0000000FF0C8: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF0D0: BF870092
	v_cndmask_b32_e32 v32, 0x7f800000, v40, vcc_lo             // 0000000FF0D4: 024050FF 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 0000000FF0DC: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF0E0: BF870091
	v_div_scale_f32 v40, null, v32, v32, v33                   // 0000000FF0E4: D6FC7C28 04864120
	v_rcp_f32_e32 v41, v40                                     // 0000000FF0EC: 7E525528
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF0F0: BF870095
	v_fma_f32 v42, -v40, v41, 1.0                              // 0000000FF0F4: D613002A 23CA5328
	v_fmac_f32_e32 v41, v42, v41                               // 0000000FF0FC: 5652532A
	v_div_scale_f32 v42, vcc_lo, v33, v32, v33                 // 0000000FF100: D6FC6A2A 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF108: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 0000000FF10C: 1056532A
	v_fma_f32 v44, -v40, v43, v42                              // 0000000FF110: D613002C 24AA5728
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF118: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 0000000FF11C: 5656532C
	v_fma_f32 v40, -v40, v43, v42                              // 0000000FF120: D6130028 24AA5728
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF128: BF870091
	v_div_fmas_f32 v40, v40, v41, v43                          // 0000000FF12C: D6370028 04AE5328
	v_div_fixup_f32 v40, v40, v32, v33                         // 0000000FF134: D6270028 04864128
	v_mad_i64_i32 v[32:33], null, 0x3000, v120, v[128:129]     // 0000000FF13C: D6FF7C20 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF148: BF870092
	v_bfe_u32 v41, v40, 16, 1                                  // 0000000FF14C: D6100029 02052128
	v_add3_u32 v40, v40, v41, 0x7fff                           // 0000000FF154: D6550028 03FE5328 00007FFF
	global_store_d16_hi_b16 v[32:33], v40, off offset:352      // 0000000FF160: DC960160 007C2820
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FF168: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000FF16C: BE882002
	s_cbranch_execz 59448                                      // 0000000FF170: BFA5E838 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3854>
	v_mad_i64_i32 v[32:33], null, 0x6000, v121, v[130:131]     // 0000000FF174: D6FF7C20 060AF2FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 0000000FF180: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 0000000FF188: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 0000000FF18C: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF190: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 0000000FF194: 104240FF BFB8AA3B
	v_fma_f32 v40, 0xbfb8aa3b, v32, -v33                       // 0000000FF19C: D6130028 848640FF BFB8AA3B
	v_rndne_f32_e32 v41, v33                                   // 0000000FF1A8: 7E524721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FF1AC: BF870221
	v_sub_f32_e32 v33, v33, v41                                // 0000000FF1B0: 08425321
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 0000000FF1B4: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v40, v32, 0xb2a5705f, v40                      // 0000000FF1BC: 58505120 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF1C4: BF870121
	v_add_f32_e32 v33, v33, v40                                // 0000000FF1C8: 06425121
	v_cvt_i32_f32_e32 v40, v41                                 // 0000000FF1CC: 7E501129
	v_exp_f32_e32 v33, v33                                     // 0000000FF1D0: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF1D4: BF870095
	.long 0xd71c0021                                           // 0000000FF1D8: D71C0021
	v_cndmask_b32_e32 v1, v33, v40, vcc_lo                     // 0000000FF1DC: 02025121
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000FF1E0: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 0000000FF1E4: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF1EC: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v136, v34// 0000000FF1F0: CA4642FF 20204588 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 0000000FF1FC: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF200: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 0000000FF204: D6FC7C22 04864120
	v_rcp_f32_e32 v40, v34                                     // 0000000FF20C: 7E505522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF210: BF870095
	v_fma_f32 v41, -v34, v40, 1.0                              // 0000000FF214: D6130029 23CA5122
	v_fmac_f32_e32 v40, v41, v40                               // 0000000FF21C: 56505129
	v_div_scale_f32 v41, vcc_lo, v33, v32, v33                 // 0000000FF220: D6FC6A29 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF228: BF870091
	v_mul_f32_e32 v42, v41, v40                                // 0000000FF22C: 10545129
	v_fma_f32 v43, -v34, v42, v41                              // 0000000FF230: D613002B 24A65522
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF238: BF870091
	v_fmac_f32_e32 v42, v43, v40                               // 0000000FF23C: 5654512B
	v_fma_f32 v34, -v34, v42, v41                              // 0000000FF240: D6130022 24A65522
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF248: BF870091
	v_div_fmas_f32 v34, v34, v40, v42                          // 0000000FF24C: D6370022 04AA5122
	v_div_fixup_f32 v34, v34, v32, v33                         // 0000000FF254: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v121, v[128:129]     // 0000000FF25C: D6FF7C20 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF268: BF870092
	v_bfe_u32 v40, v34, 16, 1                                  // 0000000FF26C: D6100028 02052122
	v_add3_u32 v34, v34, v40, 0x7fff                           // 0000000FF274: D6550022 03FE5122 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 0000000FF280: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FF288: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000FF28C: BE882003
	s_cbranch_execz 59379                                      // 0000000FF290: BFA5E7F3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3860>
	v_mad_i64_i32 v[32:33], null, 0x6000, v122, v[130:131]     // 0000000FF294: D6FF7C20 060AF4FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 0000000FF2A0: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 0000000FF2A8: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 0000000FF2AC: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF2B0: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 0000000FF2B4: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 0000000FF2BC: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v40, v33                                   // 0000000FF2C8: 7E504721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF2CC: BF870091
	v_dual_fmamk_f32 v34, v32, 0xb2a5705f, v34 :: v_dual_sub_f32 v33, v33, v40// 0000000FF2D0: C88A4520 22205121 B2A5705F
	v_add_f32_e32 v33, v33, v34                                // 0000000FF2DC: 06424521
	v_cvt_i32_f32_e32 v34, v40                                 // 0000000FF2E0: 7E441128
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 0000000FF2E4: 7C3C40FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FF2EC: BF870293
	v_exp_f32_e32 v33, v33                                     // 0000000FF2F0: 7E424B21
	.long 0xd71c0021                                           // 0000000FF2F4: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000FF2F8: 02024521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF2FC: BF870121
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000FF300: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 0000000FF304: 7C3640FF C2B17218
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v137, v35// 0000000FF30C: CA4642FF 20204789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF318: BF870091
	v_add_f32_e32 v32, 1.0, v32                                // 0000000FF31C: 064040F2
	v_div_scale_f32 v34, null, v32, v32, v33                   // 0000000FF320: D6FC7C22 04864120
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FF328: BF870291
	v_rcp_f32_e32 v35, v34                                     // 0000000FF32C: 7E465522
	v_fma_f32 v40, -v34, v35, 1.0                              // 0000000FF330: D6130028 23CA4722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FF338: BF8700A1
	v_fmac_f32_e32 v35, v40, v35                               // 0000000FF33C: 56464728
	v_div_scale_f32 v40, vcc_lo, v33, v32, v33                 // 0000000FF340: D6FC6A28 04864121
	v_mul_f32_e32 v41, v40, v35                                // 0000000FF348: 10524728
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF34C: BF870091
	v_fma_f32 v42, -v34, v41, v40                              // 0000000FF350: D613002A 24A25322
	v_fmac_f32_e32 v41, v42, v35                               // 0000000FF358: 5652472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF35C: BF870091
	v_fma_f32 v34, -v34, v41, v40                              // 0000000FF360: D6130022 24A25322
	v_div_fmas_f32 v34, v34, v35, v41                          // 0000000FF368: D6370022 04A64722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF370: BF870121
	v_div_fixup_f32 v34, v34, v32, v33                         // 0000000FF374: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v122, v[128:129]     // 0000000FF37C: D6FF7C20 0602F4FF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 0000000FF388: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FF390: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 0000000FF394: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 0000000FF3A0: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FF3A8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000FF3AC: BE882004
	s_cbranch_execz 59310                                      // 0000000FF3B0: BFA5E7AE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x386c>
	v_mad_i64_i32 v[32:33], null, 0x6000, v123, v[130:131]     // 0000000FF3B4: D6FF7C20 060AF6FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 0000000FF3C0: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 0000000FF3C8: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 0000000FF3CC: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF3D0: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 0000000FF3D4: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 0000000FF3DC: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000000FF3E8: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FF3EC: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 0000000FF3F0: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 0000000FF3F4: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 0000000FF3FC: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF404: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000000FF408: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 0000000FF40C: 7E441123
	v_exp_f32_e32 v33, v33                                     // 0000000FF410: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF414: BF870095
	.long 0xd71c0021                                           // 0000000FF418: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000FF41C: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000FF420: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 0000000FF424: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF42C: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v134, v36// 0000000FF430: CA4642FF 20204986 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 0000000FF43C: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF440: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 0000000FF444: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 0000000FF44C: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF450: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000000FF454: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000000FF45C: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 0000000FF460: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF468: BF870091
	v_mul_f32_e32 v40, v36, v35                                // 0000000FF46C: 10504724
	v_fma_f32 v41, -v34, v40, v36                              // 0000000FF470: D6130029 24925122
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF478: BF870091
	v_fmac_f32_e32 v40, v41, v35                               // 0000000FF47C: 56504729
	v_fma_f32 v34, -v34, v40, v36                              // 0000000FF480: D6130022 24925122
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF488: BF870091
	v_div_fmas_f32 v34, v34, v35, v40                          // 0000000FF48C: D6370022 04A24722
	v_div_fixup_f32 v34, v34, v32, v33                         // 0000000FF494: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v123, v[128:129]     // 0000000FF49C: D6FF7C20 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF4A8: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 0000000FF4AC: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 0000000FF4B4: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 0000000FF4C0: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FF4C8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000FF4CC: BE882005
	s_cbranch_execz 59241                                      // 0000000FF4D0: BFA5E769 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3878>
	v_mad_i64_i32 v[32:33], null, 0x6000, v124, v[130:131]     // 0000000FF4D4: D6FF7C20 060AF8FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 0000000FF4E0: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 0000000FF4E8: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 0000000FF4EC: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF4F0: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 0000000FF4F4: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 0000000FF4FC: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000000FF508: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FF50C: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 0000000FF510: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 0000000FF514: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 0000000FF51C: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF524: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000000FF528: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 0000000FF52C: 7E441123
	v_exp_f32_e32 v33, v33                                     // 0000000FF530: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF534: BF870095
	.long 0xd71c0021                                           // 0000000FF538: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000FF53C: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000FF540: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 0000000FF544: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF54C: BF870092
	v_cndmask_b32_e32 v32, 0x7f800000, v33, vcc_lo             // 0000000FF550: 024042FF 7F800000
	v_dual_mul_f32 v33, v135, v37 :: v_dual_add_f32 v32, 1.0, v32// 0000000FF558: C8C84B87 212040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF560: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 0000000FF564: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 0000000FF56C: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF570: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000000FF574: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000000FF57C: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 0000000FF580: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF588: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 0000000FF58C: 104A4724
	v_fma_f32 v40, -v34, v37, v36                              // 0000000FF590: D6130028 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF598: BF870091
	v_fmac_f32_e32 v37, v40, v35                               // 0000000FF59C: 564A4728
	v_fma_f32 v34, -v34, v37, v36                              // 0000000FF5A0: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF5A8: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 0000000FF5AC: D6370022 04964722
	v_div_fixup_f32 v34, v34, v32, v33                         // 0000000FF5B4: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v124, v[128:129]     // 0000000FF5BC: D6FF7C20 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF5C8: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 0000000FF5CC: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 0000000FF5D4: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 0000000FF5E0: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FF5E8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000FF5EC: BE882006
	s_cbranch_execz 59172                                      // 0000000FF5F0: BFA5E724 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3884>
	v_mad_i64_i32 v[32:33], null, 0x6000, v125, v[130:131]     // 0000000FF5F4: D6FF7C20 060AFAFF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 0000000FF600: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 0000000FF608: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 0000000FF60C: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF610: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 0000000FF614: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 0000000FF61C: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000000FF628: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FF62C: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 0000000FF630: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 0000000FF634: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 0000000FF63C: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF644: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000000FF648: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 0000000FF64C: 7E441123
	v_exp_f32_e32 v33, v33                                     // 0000000FF650: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF654: BF870095
	.long 0xd71c0021                                           // 0000000FF658: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000FF65C: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000FF660: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 0000000FF664: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF66C: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v132, v38// 0000000FF670: CA4642FF 20204D84 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 0000000FF67C: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF680: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 0000000FF684: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 0000000FF68C: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF690: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000000FF694: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000000FF69C: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 0000000FF6A0: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF6A8: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 0000000FF6AC: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 0000000FF6B0: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF6B8: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 0000000FF6BC: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 0000000FF6C0: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF6C8: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 0000000FF6CC: D6370022 04964722
	v_div_fixup_f32 v34, v34, v32, v33                         // 0000000FF6D4: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v125, v[128:129]     // 0000000FF6DC: D6FF7C20 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF6E8: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 0000000FF6EC: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 0000000FF6F4: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 0000000FF700: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FF708: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000FF70C: BE882007
	s_cbranch_execz 59103                                      // 0000000FF710: BFA5E6DF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3890>
	v_mad_i64_i32 v[32:33], null, 0x6000, v126, v[130:131]     // 0000000FF714: D6FF7C20 060AFCFF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 0000000FF720: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 0000000FF728: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 0000000FF72C: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF730: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 0000000FF734: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 0000000FF73C: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000000FF748: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FF74C: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 0000000FF750: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 0000000FF754: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 0000000FF75C: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF764: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000000FF768: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 0000000FF76C: 7E441123
	v_exp_f32_e32 v33, v33                                     // 0000000FF770: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF774: BF870095
	.long 0xd71c0021                                           // 0000000FF778: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000FF77C: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000FF780: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 0000000FF784: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF78C: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v133, v39// 0000000FF790: CA4642FF 20204F85 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 0000000FF79C: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF7A0: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 0000000FF7A4: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 0000000FF7AC: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF7B0: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000000FF7B4: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000000FF7BC: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 0000000FF7C0: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF7C8: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 0000000FF7CC: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 0000000FF7D0: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF7D8: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 0000000FF7DC: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 0000000FF7E0: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF7E8: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 0000000FF7EC: D6370022 04964722
	v_div_fixup_f32 v34, v34, v32, v33                         // 0000000FF7F4: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v126, v[128:129]     // 0000000FF7FC: D6FF7C20 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF808: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 0000000FF80C: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 0000000FF814: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 0000000FF820: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FF828: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000FF82C: BE882000
	s_cbranch_execz 59034                                      // 0000000FF830: BFA5E69A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x389c>
	v_mad_i64_i32 v[32:33], null, 0x6000, v140, v[130:131]     // 0000000FF834: D6FF7C20 060B18FF 00006000
	v_mul_f32_e32 v24, v138, v24                               // 0000000FF840: 1030318A
	global_load_u16 v32, v[32:33], off offset:896              // 0000000FF844: DC4A0380 207C0020
	s_waitcnt vmcnt(0)                                         // 0000000FF84C: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 0000000FF850: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF854: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 0000000FF858: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 0000000FF860: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000000FF86C: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FF870: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 0000000FF874: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 0000000FF878: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 0000000FF880: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF888: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000000FF88C: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 0000000FF890: 7E441123
	v_exp_f32_e32 v33, v33                                     // 0000000FF894: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF898: BF870095
	.long 0xd71c0021                                           // 0000000FF89C: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000FF8A0: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000FF8A4: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 0000000FF8A8: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF8B0: BF870092
	v_cndmask_b32_e32 v32, 0x7f800000, v33, vcc_lo             // 0000000FF8B4: 024042FF 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 0000000FF8BC: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF8C0: BF870091
	v_div_scale_f32 v33, null, v32, v32, v24                   // 0000000FF8C4: D6FC7C21 04624120
	v_rcp_f32_e32 v34, v33                                     // 0000000FF8CC: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF8D0: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 0000000FF8D4: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 0000000FF8DC: 56444523
	v_div_scale_f32 v35, vcc_lo, v24, v32, v24                 // 0000000FF8E0: D6FC6A23 04624118
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF8E8: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 0000000FF8EC: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 0000000FF8F0: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF8F8: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 0000000FF8FC: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 0000000FF900: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF908: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 0000000FF90C: D6370021 04924521
	v_div_fixup_f32 v24, v33, v32, v24                         // 0000000FF914: D6270018 04624121
	v_mad_i64_i32 v[32:33], null, 0x3000, v140, v[128:129]     // 0000000FF91C: D6FF7C20 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF928: BF870092
	v_bfe_u32 v34, v24, 16, 1                                  // 0000000FF92C: D6100022 02052118
	v_add3_u32 v24, v24, v34, 0x7fff                           // 0000000FF934: D6550018 03FE4518 00007FFF
	global_store_d16_hi_b16 v[32:33], v24, off offset:384      // 0000000FF940: DC960180 007C1820
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FF948: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000FF94C: BE882001
	s_cbranch_execz 58965                                      // 0000000FF950: BFA5E655 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38a8>
	v_mad_i64_i32 v[32:33], null, 0x6000, v120, v[130:131]     // 0000000FF954: D6FF7C20 060AF0FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 0000000FF960: 1032338B
	global_load_u16 v24, v[32:33], off offset:896              // 0000000FF964: DC4A0380 187C0020
	s_waitcnt vmcnt(0)                                         // 0000000FF96C: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 0000000FF970: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF974: BF870121
	v_mul_f32_e32 v32, 0xbfb8aa3b, v24                         // 0000000FF978: 104030FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 0000000FF980: 7C3C30FF 42CE8ED0
	v_fma_f32 v33, 0xbfb8aa3b, v24, -v32                       // 0000000FF988: D6130021 848230FF BFB8AA3B
	v_rndne_f32_e32 v34, v32                                   // 0000000FF994: 7E444720
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FF998: BF870112
	v_fmamk_f32 v33, v24, 0xb2a5705f, v33                      // 0000000FF99C: 58424318 B2A5705F
	v_sub_f32_e32 v32, v32, v34                                // 0000000FF9A4: 08404520
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FF9A8: BF870121
	v_add_f32_e32 v32, v32, v33                                // 0000000FF9AC: 06404320
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000FF9B0: 7E421122
	v_exp_f32_e32 v32, v32                                     // 0000000FF9B4: 7E404B20
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF9B8: BF870095
	.long 0xd71c0020                                           // 0000000FF9BC: D71C0020
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                     // 0000000FF9C0: 02024320
	v_cndmask_b32_e32 v32, 0, v32, vcc_lo                      // 0000000FF9C4: 02404080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000000FF9C8: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF9D0: BF870092
	v_cndmask_b32_e32 v24, 0x7f800000, v32, vcc_lo             // 0000000FF9D4: 023040FF 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 0000000FF9DC: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF9E0: BF870091
	v_div_scale_f32 v32, null, v24, v24, v25                   // 0000000FF9E4: D6FC7C20 04663118
	v_rcp_f32_e32 v33, v32                                     // 0000000FF9EC: 7E425520
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FF9F0: BF870095
	v_fma_f32 v34, -v32, v33, 1.0                              // 0000000FF9F4: D6130022 23CA4320
	v_fmac_f32_e32 v33, v34, v33                               // 0000000FF9FC: 56424322
	v_div_scale_f32 v34, vcc_lo, v25, v24, v25                 // 0000000FFA00: D6FC6A22 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFA08: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 0000000FFA0C: 10464322
	v_fma_f32 v36, -v32, v35, v34                              // 0000000FFA10: D6130024 248A4720
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFA18: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 0000000FFA1C: 56464324
	v_fma_f32 v32, -v32, v35, v34                              // 0000000FFA20: D6130020 248A4720
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFA28: BF870091
	v_div_fmas_f32 v32, v32, v33, v35                          // 0000000FFA2C: D6370020 048E4320
	v_div_fixup_f32 v32, v32, v24, v25                         // 0000000FFA34: D6270020 04663120
	v_mad_i64_i32 v[24:25], null, 0x3000, v120, v[128:129]     // 0000000FFA3C: D6FF7C18 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFA48: BF870092
	v_bfe_u32 v33, v32, 16, 1                                  // 0000000FFA4C: D6100021 02052120
	v_add3_u32 v32, v32, v33, 0x7fff                           // 0000000FFA54: D6550020 03FE4320 00007FFF
	global_store_d16_hi_b16 v[24:25], v32, off offset:384      // 0000000FFA60: DC960180 007C2018
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FFA68: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000FFA6C: BE882002
	s_cbranch_execz 58896                                      // 0000000FFA70: BFA5E610 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38b4>
	v_mad_i64_i32 v[24:25], null, 0x6000, v121, v[130:131]     // 0000000FFA74: D6FF7C18 060AF2FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 0000000FFA80: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 0000000FFA88: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 0000000FFA8C: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFA90: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 0000000FFA94: 103230FF BFB8AA3B
	v_fma_f32 v32, 0xbfb8aa3b, v24, -v25                       // 0000000FFA9C: D6130020 846630FF BFB8AA3B
	v_rndne_f32_e32 v33, v25                                   // 0000000FFAA8: 7E424719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FFAAC: BF870221
	v_sub_f32_e32 v25, v25, v33                                // 0000000FFAB0: 08324319
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 0000000FFAB4: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v32, v24, 0xb2a5705f, v32                      // 0000000FFABC: 58404118 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FFAC4: BF870121
	v_add_f32_e32 v25, v25, v32                                // 0000000FFAC8: 06324119
	v_cvt_i32_f32_e32 v32, v33                                 // 0000000FFACC: 7E401121
	v_exp_f32_e32 v25, v25                                     // 0000000FFAD0: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFAD4: BF870095
	.long 0xd71c0019                                           // 0000000FFAD8: D71C0019
	v_cndmask_b32_e32 v1, v25, v32, vcc_lo                     // 0000000FFADC: 02024119
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000000FFAE0: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000000FFAE4: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFAEC: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v136, v26// 0000000FFAF0: CA4632FF 18183588 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 0000000FFAFC: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFB00: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 0000000FFB04: D6FC7C1A 04663118
	v_rcp_f32_e32 v32, v26                                     // 0000000FFB0C: 7E40551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFB10: BF870095
	v_fma_f32 v33, -v26, v32, 1.0                              // 0000000FFB14: D6130021 23CA411A
	v_fmac_f32_e32 v32, v33, v32                               // 0000000FFB1C: 56404121
	v_div_scale_f32 v33, vcc_lo, v25, v24, v25                 // 0000000FFB20: D6FC6A21 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFB28: BF870091
	v_mul_f32_e32 v34, v33, v32                                // 0000000FFB2C: 10444121
	v_fma_f32 v35, -v26, v34, v33                              // 0000000FFB30: D6130023 2486451A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFB38: BF870091
	v_fmac_f32_e32 v34, v35, v32                               // 0000000FFB3C: 56444123
	v_fma_f32 v26, -v26, v34, v33                              // 0000000FFB40: D613001A 2486451A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFB48: BF870091
	v_div_fmas_f32 v26, v26, v32, v34                          // 0000000FFB4C: D637001A 048A411A
	v_div_fixup_f32 v26, v26, v24, v25                         // 0000000FFB54: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v121, v[128:129]     // 0000000FFB5C: D6FF7C18 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFB68: BF870092
	v_bfe_u32 v32, v26, 16, 1                                  // 0000000FFB6C: D6100020 0205211A
	v_add3_u32 v26, v26, v32, 0x7fff                           // 0000000FFB74: D655001A 03FE411A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 0000000FFB80: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FFB88: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000FFB8C: BE882003
	s_cbranch_execz 58827                                      // 0000000FFB90: BFA5E5CB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38c0>
	v_mad_i64_i32 v[24:25], null, 0x6000, v122, v[130:131]     // 0000000FFB94: D6FF7C18 060AF4FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 0000000FFBA0: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 0000000FFBA8: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 0000000FFBAC: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFBB0: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 0000000FFBB4: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 0000000FFBBC: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v32, v25                                   // 0000000FFBC8: 7E404719
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFBCC: BF870091
	v_dual_fmamk_f32 v26, v24, 0xb2a5705f, v26 :: v_dual_sub_f32 v25, v25, v32// 0000000FFBD0: C88A3518 1A184119 B2A5705F
	v_add_f32_e32 v25, v25, v26                                // 0000000FFBDC: 06323519
	v_cvt_i32_f32_e32 v26, v32                                 // 0000000FFBE0: 7E341120
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 0000000FFBE4: 7C3C30FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FFBEC: BF870293
	v_exp_f32_e32 v25, v25                                     // 0000000FFBF0: 7E324B19
	.long 0xd71c0019                                           // 0000000FFBF4: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000000FFBF8: 02023519
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FFBFC: BF870121
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000000FFC00: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000000FFC04: 7C3630FF C2B17218
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v137, v27// 0000000FFC0C: CA4632FF 18183789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFC18: BF870091
	v_add_f32_e32 v24, 1.0, v24                                // 0000000FFC1C: 063030F2
	v_div_scale_f32 v26, null, v24, v24, v25                   // 0000000FFC20: D6FC7C1A 04663118
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000FFC28: BF870291
	v_rcp_f32_e32 v27, v26                                     // 0000000FFC2C: 7E36551A
	v_fma_f32 v32, -v26, v27, 1.0                              // 0000000FFC30: D6130020 23CA371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FFC38: BF8700A1
	v_fmac_f32_e32 v27, v32, v27                               // 0000000FFC3C: 56363720
	v_div_scale_f32 v32, vcc_lo, v25, v24, v25                 // 0000000FFC40: D6FC6A20 04663119
	v_mul_f32_e32 v33, v32, v27                                // 0000000FFC48: 10423720
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFC4C: BF870091
	v_fma_f32 v34, -v26, v33, v32                              // 0000000FFC50: D6130022 2482431A
	v_fmac_f32_e32 v33, v34, v27                               // 0000000FFC58: 56423722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFC5C: BF870091
	v_fma_f32 v26, -v26, v33, v32                              // 0000000FFC60: D613001A 2482431A
	v_div_fmas_f32 v26, v26, v27, v33                          // 0000000FFC68: D637001A 0486371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FFC70: BF870121
	v_div_fixup_f32 v26, v26, v24, v25                         // 0000000FFC74: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v122, v[128:129]     // 0000000FFC7C: D6FF7C18 0602F4FF 00003000
	v_bfe_u32 v27, v26, 16, 1                                  // 0000000FFC88: D610001B 0205211A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FFC90: BF870001
	v_add3_u32 v26, v26, v27, 0x7fff                           // 0000000FFC94: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 0000000FFCA0: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FFCA8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000FFCAC: BE882004
	s_cbranch_execz 58758                                      // 0000000FFCB0: BFA5E586 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38cc>
	v_mad_i64_i32 v[24:25], null, 0x6000, v123, v[130:131]     // 0000000FFCB4: D6FF7C18 060AF6FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 0000000FFCC0: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 0000000FFCC8: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 0000000FFCCC: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFCD0: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 0000000FFCD4: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 0000000FFCDC: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 0000000FFCE8: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FFCEC: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 0000000FFCF0: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 0000000FFCF4: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 0000000FFCFC: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FFD04: BF870121
	v_add_f32_e32 v25, v25, v26                                // 0000000FFD08: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 0000000FFD0C: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 0000000FFD10: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFD14: BF870095
	.long 0xd71c0019                                           // 0000000FFD18: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000000FFD1C: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000000FFD20: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000000FFD24: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFD2C: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v134, v28// 0000000FFD30: CA4632FF 18183986 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 0000000FFD3C: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFD40: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 0000000FFD44: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 0000000FFD4C: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFD50: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 0000000FFD54: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 0000000FFD5C: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 0000000FFD60: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFD68: BF870091
	v_mul_f32_e32 v32, v28, v27                                // 0000000FFD6C: 1040371C
	v_fma_f32 v33, -v26, v32, v28                              // 0000000FFD70: D6130021 2472411A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFD78: BF870091
	v_fmac_f32_e32 v32, v33, v27                               // 0000000FFD7C: 56403721
	v_fma_f32 v26, -v26, v32, v28                              // 0000000FFD80: D613001A 2472411A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFD88: BF870091
	v_div_fmas_f32 v26, v26, v27, v32                          // 0000000FFD8C: D637001A 0482371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 0000000FFD94: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v123, v[128:129]     // 0000000FFD9C: D6FF7C18 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFDA8: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 0000000FFDAC: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 0000000FFDB4: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 0000000FFDC0: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FFDC8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000FFDCC: BE882005
	s_cbranch_execz 58689                                      // 0000000FFDD0: BFA5E541 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38d8>
	v_mad_i64_i32 v[24:25], null, 0x6000, v124, v[130:131]     // 0000000FFDD4: D6FF7C18 060AF8FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 0000000FFDE0: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 0000000FFDE8: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 0000000FFDEC: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFDF0: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 0000000FFDF4: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 0000000FFDFC: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 0000000FFE08: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FFE0C: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 0000000FFE10: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 0000000FFE14: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 0000000FFE1C: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FFE24: BF870121
	v_add_f32_e32 v25, v25, v26                                // 0000000FFE28: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 0000000FFE2C: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 0000000FFE30: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFE34: BF870095
	.long 0xd71c0019                                           // 0000000FFE38: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000000FFE3C: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000000FFE40: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000000FFE44: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFE4C: BF870092
	v_cndmask_b32_e32 v24, 0x7f800000, v25, vcc_lo             // 0000000FFE50: 023032FF 7F800000
	v_dual_mul_f32 v25, v135, v29 :: v_dual_add_f32 v24, 1.0, v24// 0000000FFE58: C8C83B87 191830F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFE60: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 0000000FFE64: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 0000000FFE6C: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFE70: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 0000000FFE74: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 0000000FFE7C: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 0000000FFE80: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFE88: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 0000000FFE8C: 103A371C
	v_fma_f32 v32, -v26, v29, v28                              // 0000000FFE90: D6130020 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFE98: BF870091
	v_fmac_f32_e32 v29, v32, v27                               // 0000000FFE9C: 563A3720
	v_fma_f32 v26, -v26, v29, v28                              // 0000000FFEA0: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFEA8: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 0000000FFEAC: D637001A 0476371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 0000000FFEB4: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v124, v[128:129]     // 0000000FFEBC: D6FF7C18 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFEC8: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 0000000FFECC: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 0000000FFED4: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 0000000FFEE0: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000FFEE8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000FFEEC: BE882006
	s_cbranch_execz 58620                                      // 0000000FFEF0: BFA5E4FC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38e4>
	v_mad_i64_i32 v[24:25], null, 0x6000, v125, v[130:131]     // 0000000FFEF4: D6FF7C18 060AFAFF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 0000000FFF00: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 0000000FFF08: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 0000000FFF0C: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFF10: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 0000000FFF14: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 0000000FFF1C: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 0000000FFF28: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FFF2C: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 0000000FFF30: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 0000000FFF34: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 0000000FFF3C: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FFF44: BF870121
	v_add_f32_e32 v25, v25, v26                                // 0000000FFF48: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 0000000FFF4C: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 0000000FFF50: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFF54: BF870095
	.long 0xd71c0019                                           // 0000000FFF58: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000000FFF5C: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000000FFF60: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000000FFF64: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFF6C: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v132, v30// 0000000FFF70: CA4632FF 18183D84 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 0000000FFF7C: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFF80: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 0000000FFF84: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 0000000FFF8C: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFF90: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 0000000FFF94: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 0000000FFF9C: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 0000000FFFA0: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFFA8: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 0000000FFFAC: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 0000000FFFB0: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFFB8: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 0000000FFFBC: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 0000000FFFC0: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFFC8: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 0000000FFFCC: D637001A 0476371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 0000000FFFD4: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v125, v[128:129]     // 0000000FFFDC: D6FF7C18 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FFFE8: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 0000000FFFEC: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 0000000FFFF4: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 000000100000: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 000000100008: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000010000C: BE882007
	s_cbranch_execz 58551                                      // 000000100010: BFA5E4B7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38f0>
	v_mad_i64_i32 v[24:25], null, 0x6000, v126, v[130:131]     // 000000100014: D6FF7C18 060AFCFF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 000000100020: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 000000100028: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000010002C: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100030: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 000000100034: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 00000010003C: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 000000100048: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010004C: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 000000100050: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 000000100054: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 00000010005C: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100064: BF870121
	v_add_f32_e32 v25, v25, v26                                // 000000100068: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000010006C: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 000000100070: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100074: BF870095
	.long 0xd71c0019                                           // 000000100078: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000010007C: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000100080: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 000000100084: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010008C: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v133, v31// 000000100090: CA4632FF 18183F85 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 00000010009C: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001000A0: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 0000001000A4: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 0000001000AC: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001000B0: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 0000001000B4: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 0000001000BC: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 0000001000C0: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001000C8: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 0000001000CC: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 0000001000D0: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001000D8: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 0000001000DC: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 0000001000E0: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001000E8: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 0000001000EC: D637001A 0476371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 0000001000F4: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v126, v[128:129]     // 0000001000FC: D6FF7C18 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100108: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 00000010010C: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 000000100114: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 000000100120: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 000000100128: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000010012C: BE882000
	s_cbranch_execz 58482                                      // 000000100130: BFA5E472 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38fc>
	v_mad_i64_i32 v[24:25], null, 0x6000, v140, v[130:131]     // 000000100134: D6FF7C18 060B18FF 00006000
	v_mul_f32_e32 v16, v138, v16                               // 000000100140: 1020218A
	global_load_u16 v24, v[24:25], off offset:928              // 000000100144: DC4A03A0 187C0018
	s_waitcnt vmcnt(0)                                         // 00000010014C: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 000000100150: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100154: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 000000100158: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 000000100160: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000010016C: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000100170: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 000000100174: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 000000100178: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 000000100180: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100188: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000010018C: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 000000100190: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 000000100194: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100198: BF870095
	.long 0xd71c0019                                           // 00000010019C: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000001001A0: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000001001A4: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000001001A8: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001001B0: BF870092
	v_cndmask_b32_e32 v24, 0x7f800000, v25, vcc_lo             // 0000001001B4: 023032FF 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 0000001001BC: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001001C0: BF870091
	v_div_scale_f32 v25, null, v24, v24, v16                   // 0000001001C4: D6FC7C19 04423118
	v_rcp_f32_e32 v26, v25                                     // 0000001001CC: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001001D0: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 0000001001D4: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 0000001001DC: 5634351B
	v_div_scale_f32 v27, vcc_lo, v16, v24, v16                 // 0000001001E0: D6FC6A1B 04423110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001001E8: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 0000001001EC: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 0000001001F0: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001001F8: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 0000001001FC: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 000000100200: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100208: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 00000010020C: D6370019 04723519
	v_div_fixup_f32 v16, v25, v24, v16                         // 000000100214: D6270010 04423119
	v_mad_i64_i32 v[24:25], null, 0x3000, v140, v[128:129]     // 00000010021C: D6FF7C18 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100228: BF870092
	v_bfe_u32 v26, v16, 16, 1                                  // 00000010022C: D610001A 02052110
	v_add3_u32 v16, v16, v26, 0x7fff                           // 000000100234: D6550010 03FE3510 00007FFF
	global_store_d16_hi_b16 v[24:25], v16, off offset:416      // 000000100240: DC9601A0 007C1018
	s_or_b32 exec_lo, exec_lo, s8                              // 000000100248: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000010024C: BE882001
	s_cbranch_execz 58413                                      // 000000100250: BFA5E42D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3908>
	v_mad_i64_i32 v[24:25], null, 0x6000, v120, v[130:131]     // 000000100254: D6FF7C18 060AF0FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 000000100260: 1022238B
	global_load_u16 v16, v[24:25], off offset:928              // 000000100264: DC4A03A0 107C0018
	s_waitcnt vmcnt(0)                                         // 00000010026C: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000100270: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100274: BF870121
	v_mul_f32_e32 v24, 0xbfb8aa3b, v16                         // 000000100278: 103020FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 000000100280: 7C3C20FF 42CE8ED0
	v_fma_f32 v25, 0xbfb8aa3b, v16, -v24                       // 000000100288: D6130019 846220FF BFB8AA3B
	v_rndne_f32_e32 v26, v24                                   // 000000100294: 7E344718
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000100298: BF870112
	v_fmamk_f32 v25, v16, 0xb2a5705f, v25                      // 00000010029C: 58323310 B2A5705F
	v_sub_f32_e32 v24, v24, v26                                // 0000001002A4: 08303518
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001002A8: BF870121
	v_add_f32_e32 v24, v24, v25                                // 0000001002AC: 06303318
	v_cvt_i32_f32_e32 v25, v26                                 // 0000001002B0: 7E32111A
	v_exp_f32_e32 v24, v24                                     // 0000001002B4: 7E304B18
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001002B8: BF870095
	.long 0xd71c0018                                           // 0000001002BC: D71C0018
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000001002C0: 02023318
	v_cndmask_b32_e32 v24, 0, v24, vcc_lo                      // 0000001002C4: 02303080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 0000001002C8: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001002D0: BF870092
	v_cndmask_b32_e32 v16, 0x7f800000, v24, vcc_lo             // 0000001002D4: 022030FF 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 0000001002DC: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001002E0: BF870091
	v_div_scale_f32 v24, null, v16, v16, v17                   // 0000001002E4: D6FC7C18 04462110
	v_rcp_f32_e32 v25, v24                                     // 0000001002EC: 7E325518
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001002F0: BF870095
	v_fma_f32 v26, -v24, v25, 1.0                              // 0000001002F4: D613001A 23CA3318
	v_fmac_f32_e32 v25, v26, v25                               // 0000001002FC: 5632331A
	v_div_scale_f32 v26, vcc_lo, v17, v16, v17                 // 000000100300: D6FC6A1A 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100308: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 00000010030C: 1036331A
	v_fma_f32 v28, -v24, v27, v26                              // 000000100310: D613001C 246A3718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100318: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 00000010031C: 5636331C
	v_fma_f32 v24, -v24, v27, v26                              // 000000100320: D6130018 246A3718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100328: BF870091
	v_div_fmas_f32 v24, v24, v25, v27                          // 00000010032C: D6370018 046E3318
	v_div_fixup_f32 v24, v24, v16, v17                         // 000000100334: D6270018 04462118
	v_mad_i64_i32 v[16:17], null, 0x3000, v120, v[128:129]     // 00000010033C: D6FF7C10 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100348: BF870092
	v_bfe_u32 v25, v24, 16, 1                                  // 00000010034C: D6100019 02052118
	v_add3_u32 v24, v24, v25, 0x7fff                           // 000000100354: D6550018 03FE3318 00007FFF
	global_store_d16_hi_b16 v[16:17], v24, off offset:416      // 000000100360: DC9601A0 007C1810
	s_or_b32 exec_lo, exec_lo, s8                              // 000000100368: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000010036C: BE882002
	s_cbranch_execz 58344                                      // 000000100370: BFA5E3E8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3914>
	v_mad_i64_i32 v[16:17], null, 0x6000, v121, v[130:131]     // 000000100374: D6FF7C10 060AF2FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 000000100380: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 000000100388: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000010038C: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100390: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 000000100394: 102220FF BFB8AA3B
	v_fma_f32 v24, 0xbfb8aa3b, v16, -v17                       // 00000010039C: D6130018 844620FF BFB8AA3B
	v_rndne_f32_e32 v25, v17                                   // 0000001003A8: 7E324711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001003AC: BF870221
	v_sub_f32_e32 v17, v17, v25                                // 0000001003B0: 08223311
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 0000001003B4: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v24, v16, 0xb2a5705f, v24                      // 0000001003BC: 58303110 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001003C4: BF870121
	v_add_f32_e32 v17, v17, v24                                // 0000001003C8: 06223111
	v_cvt_i32_f32_e32 v24, v25                                 // 0000001003CC: 7E301119
	v_exp_f32_e32 v17, v17                                     // 0000001003D0: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001003D4: BF870095
	.long 0xd71c0011                                           // 0000001003D8: D71C0011
	v_cndmask_b32_e32 v1, v17, v24, vcc_lo                     // 0000001003DC: 02023111
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000001003E0: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 0000001003E4: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001003EC: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v136, v18// 0000001003F0: CA4622FF 10102588 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 0000001003FC: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100400: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 000000100404: D6FC7C12 04462110
	v_rcp_f32_e32 v24, v18                                     // 00000010040C: 7E305512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100410: BF870095
	v_fma_f32 v25, -v18, v24, 1.0                              // 000000100414: D6130019 23CA3112
	v_fmac_f32_e32 v24, v25, v24                               // 00000010041C: 56303119
	v_div_scale_f32 v25, vcc_lo, v17, v16, v17                 // 000000100420: D6FC6A19 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100428: BF870091
	v_mul_f32_e32 v26, v25, v24                                // 00000010042C: 10343119
	v_fma_f32 v27, -v18, v26, v25                              // 000000100430: D613001B 24663512
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100438: BF870091
	v_fmac_f32_e32 v26, v27, v24                               // 00000010043C: 5634311B
	v_fma_f32 v18, -v18, v26, v25                              // 000000100440: D6130012 24663512
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100448: BF870091
	v_div_fmas_f32 v18, v18, v24, v26                          // 00000010044C: D6370012 046A3112
	v_div_fixup_f32 v18, v18, v16, v17                         // 000000100454: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v121, v[128:129]     // 00000010045C: D6FF7C10 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100468: BF870092
	v_bfe_u32 v24, v18, 16, 1                                  // 00000010046C: D6100018 02052112
	v_add3_u32 v18, v18, v24, 0x7fff                           // 000000100474: D6550012 03FE3112 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 000000100480: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 000000100488: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000010048C: BE882003
	s_cbranch_execz 58275                                      // 000000100490: BFA5E3A3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3920>
	v_mad_i64_i32 v[16:17], null, 0x6000, v122, v[130:131]     // 000000100494: D6FF7C10 060AF4FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 0000001004A0: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 0000001004A8: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 0000001004AC: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001004B0: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 0000001004B4: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 0000001004BC: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v24, v17                                   // 0000001004C8: 7E304711
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001004CC: BF870091
	v_dual_fmamk_f32 v18, v16, 0xb2a5705f, v18 :: v_dual_sub_f32 v17, v17, v24// 0000001004D0: C88A2510 12103111 B2A5705F
	v_add_f32_e32 v17, v17, v18                                // 0000001004DC: 06222511
	v_cvt_i32_f32_e32 v18, v24                                 // 0000001004E0: 7E241118
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 0000001004E4: 7C3C20FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001004EC: BF870293
	v_exp_f32_e32 v17, v17                                     // 0000001004F0: 7E224B11
	.long 0xd71c0011                                           // 0000001004F4: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000001004F8: 02022511
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001004FC: BF870121
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000100500: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 000000100504: 7C3620FF C2B17218
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v137, v19// 00000010050C: CA4622FF 10102789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100518: BF870091
	v_add_f32_e32 v16, 1.0, v16                                // 00000010051C: 062020F2
	v_div_scale_f32 v18, null, v16, v16, v17                   // 000000100520: D6FC7C12 04462110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000100528: BF870291
	v_rcp_f32_e32 v19, v18                                     // 00000010052C: 7E265512
	v_fma_f32 v24, -v18, v19, 1.0                              // 000000100530: D6130018 23CA2712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000100538: BF8700A1
	v_fmac_f32_e32 v19, v24, v19                               // 00000010053C: 56262718
	v_div_scale_f32 v24, vcc_lo, v17, v16, v17                 // 000000100540: D6FC6A18 04462111
	v_mul_f32_e32 v25, v24, v19                                // 000000100548: 10322718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010054C: BF870091
	v_fma_f32 v26, -v18, v25, v24                              // 000000100550: D613001A 24623312
	v_fmac_f32_e32 v25, v26, v19                               // 000000100558: 5632271A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010055C: BF870091
	v_fma_f32 v18, -v18, v25, v24                              // 000000100560: D6130012 24623312
	v_div_fmas_f32 v18, v18, v19, v25                          // 000000100568: D6370012 04662712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100570: BF870121
	v_div_fixup_f32 v18, v18, v16, v17                         // 000000100574: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v122, v[128:129]     // 00000010057C: D6FF7C10 0602F4FF 00003000
	v_bfe_u32 v19, v18, 16, 1                                  // 000000100588: D6100013 02052112
	s_delay_alu instid0(VALU_DEP_1)                            // 000000100590: BF870001
	v_add3_u32 v18, v18, v19, 0x7fff                           // 000000100594: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 0000001005A0: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001005A8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001005AC: BE882004
	s_cbranch_execz 58206                                      // 0000001005B0: BFA5E35E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x392c>
	v_mad_i64_i32 v[16:17], null, 0x6000, v123, v[130:131]     // 0000001005B4: D6FF7C10 060AF6FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 0000001005C0: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 0000001005C8: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 0000001005CC: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001005D0: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 0000001005D4: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 0000001005DC: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 0000001005E8: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001005EC: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 0000001005F0: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 0000001005F4: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 0000001005FC: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100604: BF870121
	v_add_f32_e32 v17, v17, v18                                // 000000100608: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000010060C: 7E241113
	v_exp_f32_e32 v17, v17                                     // 000000100610: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100614: BF870095
	.long 0xd71c0011                                           // 000000100618: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000010061C: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000100620: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 000000100624: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010062C: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v134, v20// 000000100630: CA4622FF 10102986 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000010063C: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100640: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 000000100644: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000010064C: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100650: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 000000100654: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000010065C: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 000000100660: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100668: BF870091
	v_mul_f32_e32 v24, v20, v19                                // 00000010066C: 10302714
	v_fma_f32 v25, -v18, v24, v20                              // 000000100670: D6130019 24523112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100678: BF870091
	v_fmac_f32_e32 v24, v25, v19                               // 00000010067C: 56302719
	v_fma_f32 v18, -v18, v24, v20                              // 000000100680: D6130012 24523112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100688: BF870091
	v_div_fmas_f32 v18, v18, v19, v24                          // 00000010068C: D6370012 04622712
	v_div_fixup_f32 v18, v18, v16, v17                         // 000000100694: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v123, v[128:129]     // 00000010069C: D6FF7C10 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001006A8: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 0000001006AC: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 0000001006B4: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 0000001006C0: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001006C8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001006CC: BE882005
	s_cbranch_execz 58137                                      // 0000001006D0: BFA5E319 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3938>
	v_mad_i64_i32 v[16:17], null, 0x6000, v124, v[130:131]     // 0000001006D4: D6FF7C10 060AF8FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 0000001006E0: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 0000001006E8: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 0000001006EC: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001006F0: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 0000001006F4: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 0000001006FC: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 000000100708: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010070C: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 000000100710: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 000000100714: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000010071C: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100724: BF870121
	v_add_f32_e32 v17, v17, v18                                // 000000100728: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000010072C: 7E241113
	v_exp_f32_e32 v17, v17                                     // 000000100730: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100734: BF870095
	.long 0xd71c0011                                           // 000000100738: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000010073C: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000100740: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 000000100744: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010074C: BF870092
	v_cndmask_b32_e32 v16, 0x7f800000, v17, vcc_lo             // 000000100750: 022022FF 7F800000
	v_dual_mul_f32 v17, v135, v21 :: v_dual_add_f32 v16, 1.0, v16// 000000100758: C8C82B87 111020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100760: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 000000100764: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000010076C: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100770: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 000000100774: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000010077C: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 000000100780: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100788: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 00000010078C: 102A2714
	v_fma_f32 v24, -v18, v21, v20                              // 000000100790: D6130018 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100798: BF870091
	v_fmac_f32_e32 v21, v24, v19                               // 00000010079C: 562A2718
	v_fma_f32 v18, -v18, v21, v20                              // 0000001007A0: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001007A8: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 0000001007AC: D6370012 04562712
	v_div_fixup_f32 v18, v18, v16, v17                         // 0000001007B4: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v124, v[128:129]     // 0000001007BC: D6FF7C10 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001007C8: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 0000001007CC: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 0000001007D4: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 0000001007E0: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001007E8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001007EC: BE882006
	s_cbranch_execz 58068                                      // 0000001007F0: BFA5E2D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3944>
	v_mad_i64_i32 v[16:17], null, 0x6000, v125, v[130:131]     // 0000001007F4: D6FF7C10 060AFAFF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 000000100800: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 000000100808: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000010080C: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100810: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 000000100814: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000010081C: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 000000100828: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010082C: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 000000100830: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 000000100834: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000010083C: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100844: BF870121
	v_add_f32_e32 v17, v17, v18                                // 000000100848: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000010084C: 7E241113
	v_exp_f32_e32 v17, v17                                     // 000000100850: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100854: BF870095
	.long 0xd71c0011                                           // 000000100858: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000010085C: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000100860: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 000000100864: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010086C: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v132, v22// 000000100870: CA4622FF 10102D84 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000010087C: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100880: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 000000100884: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000010088C: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100890: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 000000100894: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000010089C: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 0000001008A0: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001008A8: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 0000001008AC: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 0000001008B0: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001008B8: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 0000001008BC: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 0000001008C0: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001008C8: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 0000001008CC: D6370012 04562712
	v_div_fixup_f32 v18, v18, v16, v17                         // 0000001008D4: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v125, v[128:129]     // 0000001008DC: D6FF7C10 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001008E8: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 0000001008EC: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 0000001008F4: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 000000100900: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 000000100908: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000010090C: BE882007
	s_cbranch_execz 57999                                      // 000000100910: BFA5E28F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3950>
	v_mad_i64_i32 v[16:17], null, 0x6000, v126, v[130:131]     // 000000100914: D6FF7C10 060AFCFF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 000000100920: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 000000100928: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000010092C: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100930: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 000000100934: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000010093C: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 000000100948: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010094C: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 000000100950: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 000000100954: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000010095C: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100964: BF870121
	v_add_f32_e32 v17, v17, v18                                // 000000100968: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000010096C: 7E241113
	v_exp_f32_e32 v17, v17                                     // 000000100970: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100974: BF870095
	.long 0xd71c0011                                           // 000000100978: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000010097C: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000100980: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 000000100984: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010098C: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v133, v23// 000000100990: CA4622FF 10102F85 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000010099C: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001009A0: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 0000001009A4: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 0000001009AC: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001009B0: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000001009B4: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 0000001009BC: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 0000001009C0: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001009C8: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 0000001009CC: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 0000001009D0: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001009D8: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 0000001009DC: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 0000001009E0: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001009E8: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 0000001009EC: D6370012 04562712
	v_div_fixup_f32 v18, v18, v16, v17                         // 0000001009F4: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v126, v[128:129]     // 0000001009FC: D6FF7C10 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100A08: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 000000100A0C: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 000000100A14: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 000000100A20: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 000000100A28: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000100A2C: BE882000
	s_cbranch_execz 57930                                      // 000000100A30: BFA5E24A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x395c>
	v_mad_i64_i32 v[16:17], null, 0x6000, v140, v[130:131]     // 000000100A34: D6FF7C10 060B18FF 00006000
	v_mul_f32_e32 v8, v138, v8                                 // 000000100A40: 1010118A
	global_load_u16 v16, v[16:17], off offset:960              // 000000100A44: DC4A03C0 107C0010
	s_waitcnt vmcnt(0)                                         // 000000100A4C: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000100A50: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100A54: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 000000100A58: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 000000100A60: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 000000100A6C: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000100A70: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 000000100A74: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 000000100A78: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 000000100A80: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100A88: BF870121
	v_add_f32_e32 v17, v17, v18                                // 000000100A8C: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 000000100A90: 7E241113
	v_exp_f32_e32 v17, v17                                     // 000000100A94: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100A98: BF870095
	.long 0xd71c0011                                           // 000000100A9C: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000100AA0: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000100AA4: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 000000100AA8: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100AB0: BF870092
	v_cndmask_b32_e32 v16, 0x7f800000, v17, vcc_lo             // 000000100AB4: 022022FF 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 000000100ABC: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100AC0: BF870091
	v_div_scale_f32 v17, null, v16, v16, v8                    // 000000100AC4: D6FC7C11 04222110
	v_rcp_f32_e32 v18, v17                                     // 000000100ACC: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100AD0: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 000000100AD4: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 000000100ADC: 56242513
	v_div_scale_f32 v19, vcc_lo, v8, v16, v8                   // 000000100AE0: D6FC6A13 04222108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100AE8: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 000000100AEC: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 000000100AF0: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100AF8: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 000000100AFC: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 000000100B00: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100B08: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 000000100B0C: D6370011 04522511
	v_div_fixup_f32 v8, v17, v16, v8                           // 000000100B14: D6270008 04222111
	v_mad_i64_i32 v[16:17], null, 0x3000, v140, v[128:129]     // 000000100B1C: D6FF7C10 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100B28: BF870092
	v_bfe_u32 v18, v8, 16, 1                                   // 000000100B2C: D6100012 02052108
	v_add3_u32 v8, v8, v18, 0x7fff                             // 000000100B34: D6550008 03FE2508 00007FFF
	global_store_d16_hi_b16 v[16:17], v8, off offset:448       // 000000100B40: DC9601C0 007C0810
	s_or_b32 exec_lo, exec_lo, s8                              // 000000100B48: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000100B4C: BE882001
	s_cbranch_execz 57861                                      // 000000100B50: BFA5E205 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3968>
	v_mad_i64_i32 v[16:17], null, 0x6000, v120, v[130:131]     // 000000100B54: D6FF7C10 060AF0FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 000000100B60: 1012138B
	global_load_u16 v8, v[16:17], off offset:960               // 000000100B64: DC4A03C0 087C0010
	s_waitcnt vmcnt(0)                                         // 000000100B6C: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 000000100B70: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100B74: BF870121
	v_mul_f32_e32 v16, 0xbfb8aa3b, v8                          // 000000100B78: 102010FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 000000100B80: 7C3C10FF 42CE8ED0
	v_fma_f32 v17, 0xbfb8aa3b, v8, -v16                        // 000000100B88: D6130011 844210FF BFB8AA3B
	v_rndne_f32_e32 v18, v16                                   // 000000100B94: 7E244710
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000100B98: BF870112
	v_fmamk_f32 v17, v8, 0xb2a5705f, v17                       // 000000100B9C: 58222308 B2A5705F
	v_sub_f32_e32 v16, v16, v18                                // 000000100BA4: 08202510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100BA8: BF870121
	v_add_f32_e32 v16, v16, v17                                // 000000100BAC: 06202310
	v_cvt_i32_f32_e32 v17, v18                                 // 000000100BB0: 7E221112
	v_exp_f32_e32 v16, v16                                     // 000000100BB4: 7E204B10
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100BB8: BF870095
	.long 0xd71c0010                                           // 000000100BBC: D71C0010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                     // 000000100BC0: 02022310
	v_cndmask_b32_e32 v16, 0, v16, vcc_lo                      // 000000100BC4: 02202080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 000000100BC8: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100BD0: BF870092
	v_cndmask_b32_e32 v8, 0x7f800000, v16, vcc_lo              // 000000100BD4: 021020FF 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 000000100BDC: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100BE0: BF870091
	v_div_scale_f32 v16, null, v8, v8, v9                      // 000000100BE4: D6FC7C10 04261108
	v_rcp_f32_e32 v17, v16                                     // 000000100BEC: 7E225510
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100BF0: BF870095
	v_fma_f32 v18, -v16, v17, 1.0                              // 000000100BF4: D6130012 23CA2310
	v_fmac_f32_e32 v17, v18, v17                               // 000000100BFC: 56222312
	v_div_scale_f32 v18, vcc_lo, v9, v8, v9                    // 000000100C00: D6FC6A12 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100C08: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 000000100C0C: 10262312
	v_fma_f32 v20, -v16, v19, v18                              // 000000100C10: D6130014 244A2710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100C18: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 000000100C1C: 56262314
	v_fma_f32 v16, -v16, v19, v18                              // 000000100C20: D6130010 244A2710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100C28: BF870091
	v_div_fmas_f32 v16, v16, v17, v19                          // 000000100C2C: D6370010 044E2310
	v_div_fixup_f32 v16, v16, v8, v9                           // 000000100C34: D6270010 04261110
	v_mad_i64_i32 v[8:9], null, 0x3000, v120, v[128:129]       // 000000100C3C: D6FF7C08 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100C48: BF870092
	v_bfe_u32 v17, v16, 16, 1                                  // 000000100C4C: D6100011 02052110
	v_add3_u32 v16, v16, v17, 0x7fff                           // 000000100C54: D6550010 03FE2310 00007FFF
	global_store_d16_hi_b16 v[8:9], v16, off offset:448        // 000000100C60: DC9601C0 007C1008
	s_or_b32 exec_lo, exec_lo, s8                              // 000000100C68: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000100C6C: BE882002
	s_cbranch_execz 57792                                      // 000000100C70: BFA5E1C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3974>
	v_mad_i64_i32 v[8:9], null, 0x6000, v121, v[130:131]       // 000000100C74: D6FF7C08 060AF2FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 000000100C80: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 000000100C88: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 000000100C8C: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100C90: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 000000100C94: 101210FF BFB8AA3B
	v_fma_f32 v16, 0xbfb8aa3b, v8, -v9                         // 000000100C9C: D6130010 842610FF BFB8AA3B
	v_rndne_f32_e32 v17, v9                                    // 000000100CA8: 7E224709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000100CAC: BF870221
	v_sub_f32_e32 v9, v9, v17                                  // 000000100CB0: 08122309
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 000000100CB4: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v16, v8, 0xb2a5705f, v16                       // 000000100CBC: 58202108 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100CC4: BF870121
	v_add_f32_e32 v9, v9, v16                                  // 000000100CC8: 06122109
	v_cvt_i32_f32_e32 v16, v17                                 // 000000100CCC: 7E201111
	v_exp_f32_e32 v9, v9                                       // 000000100CD0: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100CD4: BF870095
	.long 0xd71c0009                                           // 000000100CD8: D71C0009
	v_cndmask_b32_e32 v1, v9, v16, vcc_lo                      // 000000100CDC: 02022109
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 000000100CE0: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 000000100CE4: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100CEC: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v136, v10// 000000100CF0: CA4612FF 08081588 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 000000100CFC: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100D00: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 000000100D04: D6FC7C0A 04261108
	v_rcp_f32_e32 v16, v10                                     // 000000100D0C: 7E20550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100D10: BF870095
	v_fma_f32 v17, -v10, v16, 1.0                              // 000000100D14: D6130011 23CA210A
	v_fmac_f32_e32 v16, v17, v16                               // 000000100D1C: 56202111
	v_div_scale_f32 v17, vcc_lo, v9, v8, v9                    // 000000100D20: D6FC6A11 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100D28: BF870091
	v_mul_f32_e32 v18, v17, v16                                // 000000100D2C: 10242111
	v_fma_f32 v19, -v10, v18, v17                              // 000000100D30: D6130013 2446250A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100D38: BF870091
	v_fmac_f32_e32 v18, v19, v16                               // 000000100D3C: 56242113
	v_fma_f32 v10, -v10, v18, v17                              // 000000100D40: D613000A 2446250A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100D48: BF870091
	v_div_fmas_f32 v10, v10, v16, v18                          // 000000100D4C: D637000A 044A210A
	v_div_fixup_f32 v10, v10, v8, v9                           // 000000100D54: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v121, v[128:129]       // 000000100D5C: D6FF7C08 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100D68: BF870092
	v_bfe_u32 v16, v10, 16, 1                                  // 000000100D6C: D6100010 0205210A
	v_add3_u32 v10, v10, v16, 0x7fff                           // 000000100D74: D655000A 03FE210A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 000000100D80: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 000000100D88: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000100D8C: BE882003
	s_cbranch_execz 57723                                      // 000000100D90: BFA5E17B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3980>
	v_mad_i64_i32 v[8:9], null, 0x6000, v122, v[130:131]       // 000000100D94: D6FF7C08 060AF4FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 000000100DA0: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 000000100DA8: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 000000100DAC: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100DB0: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 000000100DB4: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 000000100DBC: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v16, v9                                    // 000000100DC8: 7E204709
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100DCC: BF870091
	v_dual_fmamk_f32 v10, v8, 0xb2a5705f, v10 :: v_dual_sub_f32 v9, v9, v16// 000000100DD0: C88A1508 0A082109 B2A5705F
	v_add_f32_e32 v9, v9, v10                                  // 000000100DDC: 06121509
	v_cvt_i32_f32_e32 v10, v16                                 // 000000100DE0: 7E141110
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 000000100DE4: 7C3C10FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000100DEC: BF870293
	v_exp_f32_e32 v9, v9                                       // 000000100DF0: 7E124B09
	.long 0xd71c0009                                           // 000000100DF4: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000100DF8: 02021509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100DFC: BF870121
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 000000100E00: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 000000100E04: 7C3610FF C2B17218
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v137, v11// 000000100E0C: CA4612FF 08081789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100E18: BF870091
	v_add_f32_e32 v8, 1.0, v8                                  // 000000100E1C: 061010F2
	v_div_scale_f32 v10, null, v8, v8, v9                      // 000000100E20: D6FC7C0A 04261108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000100E28: BF870291
	v_rcp_f32_e32 v11, v10                                     // 000000100E2C: 7E16550A
	v_fma_f32 v16, -v10, v11, 1.0                              // 000000100E30: D6130010 23CA170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000100E38: BF8700A1
	v_fmac_f32_e32 v11, v16, v11                               // 000000100E3C: 56161710
	v_div_scale_f32 v16, vcc_lo, v9, v8, v9                    // 000000100E40: D6FC6A10 04261109
	v_mul_f32_e32 v17, v16, v11                                // 000000100E48: 10221710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100E4C: BF870091
	v_fma_f32 v18, -v10, v17, v16                              // 000000100E50: D6130012 2442230A
	v_fmac_f32_e32 v17, v18, v11                               // 000000100E58: 56221712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100E5C: BF870091
	v_fma_f32 v10, -v10, v17, v16                              // 000000100E60: D613000A 2442230A
	v_div_fmas_f32 v10, v10, v11, v17                          // 000000100E68: D637000A 0446170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100E70: BF870121
	v_div_fixup_f32 v10, v10, v8, v9                           // 000000100E74: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v122, v[128:129]       // 000000100E7C: D6FF7C08 0602F4FF 00003000
	v_bfe_u32 v11, v10, 16, 1                                  // 000000100E88: D610000B 0205210A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000100E90: BF870001
	v_add3_u32 v10, v10, v11, 0x7fff                           // 000000100E94: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 000000100EA0: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 000000100EA8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000100EAC: BE882004
	s_cbranch_execz 57654                                      // 000000100EB0: BFA5E136 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x398c>
	v_mad_i64_i32 v[8:9], null, 0x6000, v123, v[130:131]       // 000000100EB4: D6FF7C08 060AF6FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 000000100EC0: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 000000100EC8: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 000000100ECC: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100ED0: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 000000100ED4: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 000000100EDC: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 000000100EE8: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000100EEC: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 000000100EF0: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 000000100EF4: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 000000100EFC: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000100F04: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 000000100F08: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 000000100F0C: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 000000100F10: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100F14: BF870095
	.long 0xd71c0009                                           // 000000100F18: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000100F1C: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 000000100F20: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 000000100F24: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100F2C: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v134, v12// 000000100F30: CA4612FF 08081986 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 000000100F3C: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100F40: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 000000100F44: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 000000100F4C: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100F50: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 000000100F54: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 000000100F5C: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 000000100F60: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100F68: BF870091
	v_mul_f32_e32 v16, v12, v11                                // 000000100F6C: 1020170C
	v_fma_f32 v17, -v10, v16, v12                              // 000000100F70: D6130011 2432210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100F78: BF870091
	v_fmac_f32_e32 v16, v17, v11                               // 000000100F7C: 56201711
	v_fma_f32 v10, -v10, v16, v12                              // 000000100F80: D613000A 2432210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100F88: BF870091
	v_div_fmas_f32 v10, v10, v11, v16                          // 000000100F8C: D637000A 0442170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 000000100F94: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v123, v[128:129]       // 000000100F9C: D6FF7C08 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100FA8: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 000000100FAC: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 000000100FB4: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 000000100FC0: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 000000100FC8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000100FCC: BE882005
	s_cbranch_execz 57585                                      // 000000100FD0: BFA5E0F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3998>
	v_mad_i64_i32 v[8:9], null, 0x6000, v124, v[130:131]       // 000000100FD4: D6FF7C08 060AF8FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 000000100FE0: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 000000100FE8: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 000000100FEC: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000100FF0: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 000000100FF4: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 000000100FFC: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 000000101008: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010100C: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 000000101010: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 000000101014: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 00000010101C: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000101024: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 000000101028: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 00000010102C: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 000000101030: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101034: BF870095
	.long 0xd71c0009                                           // 000000101038: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000010103C: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 000000101040: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 000000101044: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010104C: BF870092
	v_cndmask_b32_e32 v8, 0x7f800000, v9, vcc_lo               // 000000101050: 021012FF 7F800000
	v_dual_mul_f32 v9, v135, v13 :: v_dual_add_f32 v8, 1.0, v8 // 000000101058: C8C81B87 090810F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101060: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 000000101064: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 00000010106C: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101070: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 000000101074: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000010107C: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 000000101080: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101088: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 00000010108C: 101A170C
	v_fma_f32 v16, -v10, v13, v12                              // 000000101090: D6130010 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101098: BF870091
	v_fmac_f32_e32 v13, v16, v11                               // 00000010109C: 561A1710
	v_fma_f32 v10, -v10, v13, v12                              // 0000001010A0: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001010A8: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 0000001010AC: D637000A 0436170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 0000001010B4: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v124, v[128:129]       // 0000001010BC: D6FF7C08 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001010C8: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 0000001010CC: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 0000001010D4: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 0000001010E0: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001010E8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001010EC: BE882006
	s_cbranch_execz 57516                                      // 0000001010F0: BFA5E0AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39a4>
	v_mad_i64_i32 v[8:9], null, 0x6000, v125, v[130:131]       // 0000001010F4: D6FF7C08 060AFAFF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 000000101100: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 000000101108: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000010110C: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101110: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 000000101114: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 00000010111C: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 000000101128: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010112C: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 000000101130: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 000000101134: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 00000010113C: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000101144: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 000000101148: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 00000010114C: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 000000101150: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101154: BF870095
	.long 0xd71c0009                                           // 000000101158: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000010115C: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 000000101160: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 000000101164: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010116C: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v132, v14// 000000101170: CA4612FF 08081D84 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 00000010117C: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101180: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 000000101184: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 00000010118C: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101190: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 000000101194: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000010119C: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 0000001011A0: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001011A8: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 0000001011AC: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 0000001011B0: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001011B8: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 0000001011BC: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 0000001011C0: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001011C8: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 0000001011CC: D637000A 0436170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 0000001011D4: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v125, v[128:129]       // 0000001011DC: D6FF7C08 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001011E8: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 0000001011EC: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 0000001011F4: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 000000101200: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 000000101208: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000010120C: BE882007
	s_cbranch_execz 57447                                      // 000000101210: BFA5E067 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39b0>
	v_mad_i64_i32 v[8:9], null, 0x6000, v126, v[130:131]       // 000000101214: D6FF7C08 060AFCFF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 000000101220: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 000000101228: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000010122C: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101230: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 000000101234: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 00000010123C: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 000000101248: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010124C: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 000000101250: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 000000101254: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 00000010125C: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000101264: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 000000101268: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 00000010126C: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 000000101270: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101274: BF870095
	.long 0xd71c0009                                           // 000000101278: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000010127C: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 000000101280: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 000000101284: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010128C: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v133, v15// 000000101290: CA4612FF 08081F85 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 00000010129C: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001012A0: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 0000001012A4: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 0000001012AC: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001012B0: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 0000001012B4: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 0000001012BC: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 0000001012C0: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001012C8: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 0000001012CC: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 0000001012D0: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001012D8: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 0000001012DC: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 0000001012E0: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001012E8: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 0000001012EC: D637000A 0436170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 0000001012F4: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v126, v[128:129]       // 0000001012FC: D6FF7C08 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101308: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 00000010130C: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 000000101314: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 000000101320: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 000000101328: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000010132C: BE882000
	s_cbranch_execz 57378                                      // 000000101330: BFA5E022 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39bc>
	v_mad_i64_i32 v[8:9], null, 0x6000, v140, v[130:131]       // 000000101334: D6FF7C08 060B18FF 00006000
	v_mul_f32_e32 v0, v138, v0                                 // 000000101340: 1000018A
	global_load_u16 v8, v[8:9], off offset:992                 // 000000101344: DC4A03E0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000010134C: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 000000101350: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101354: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 000000101358: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 000000101360: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 00000010136C: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000101370: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 000000101374: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 000000101378: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 000000101380: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000101388: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 00000010138C: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 000000101390: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 000000101394: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101398: BF870095
	.long 0xd71c0009                                           // 00000010139C: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 0000001013A0: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 0000001013A4: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 0000001013A8: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001013B0: BF870092
	v_cndmask_b32_e32 v8, 0x7f800000, v9, vcc_lo               // 0000001013B4: 021012FF 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 0000001013BC: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001013C0: BF870091
	v_div_scale_f32 v9, null, v8, v8, v0                       // 0000001013C4: D6FC7C09 04021108
	v_rcp_f32_e32 v10, v9                                      // 0000001013CC: 7E145509
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001013D0: BF870095
	v_fma_f32 v11, -v9, v10, 1.0                               // 0000001013D4: D613000B 23CA1509
	v_fmac_f32_e32 v10, v11, v10                               // 0000001013DC: 5614150B
	v_div_scale_f32 v11, vcc_lo, v0, v8, v0                    // 0000001013E0: D6FC6A0B 04021100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001013E8: BF870091
	v_mul_f32_e32 v12, v11, v10                                // 0000001013EC: 1018150B
	v_fma_f32 v13, -v9, v12, v11                               // 0000001013F0: D613000D 242E1909
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001013F8: BF870091
	v_fmac_f32_e32 v12, v13, v10                               // 0000001013FC: 5618150D
	v_fma_f32 v9, -v9, v12, v11                                // 000000101400: D6130009 242E1909
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101408: BF870091
	v_div_fmas_f32 v9, v9, v10, v12                            // 00000010140C: D6370009 04321509
	v_div_fixup_f32 v0, v9, v8, v0                             // 000000101414: D6270000 04021109
	v_mad_i64_i32 v[8:9], null, 0x3000, v140, v[128:129]       // 00000010141C: D6FF7C08 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101428: BF870092
	v_bfe_u32 v10, v0, 16, 1                                   // 00000010142C: D610000A 02052100
	v_add3_u32 v0, v0, v10, 0x7fff                             // 000000101434: D6550000 03FE1500 00007FFF
	global_store_d16_hi_b16 v[8:9], v0, off offset:480         // 000000101440: DC9601E0 007C0008
	s_or_b32 exec_lo, exec_lo, s8                              // 000000101448: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000010144C: BE802001
	s_cbranch_execz 57309                                      // 000000101450: BFA5DFDD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39c8>
	v_mad_i64_i32 v[8:9], null, 0x6000, v120, v[130:131]       // 000000101454: D6FF7C08 060AF0FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 000000101460: 1002038B
	global_load_u16 v0, v[8:9], off offset:992                 // 000000101464: DC4A03E0 007C0008
	s_waitcnt vmcnt(0)                                         // 00000010146C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000101470: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000101474: BF870121
	v_mul_f32_e32 v8, 0xbfb8aa3b, v0                           // 000000101478: 101000FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000101480: 7C3C00FF 42CE8ED0
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v8                          // 000000101488: D6130009 842200FF BFB8AA3B
	v_rndne_f32_e32 v10, v8                                    // 000000101494: 7E144708
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000101498: BF870112
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 00000010149C: 58121300 B2A5705F
	v_sub_f32_e32 v8, v8, v10                                  // 0000001014A4: 08101508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001014A8: BF870121
	v_add_f32_e32 v8, v8, v9                                   // 0000001014AC: 06101308
	v_cvt_i32_f32_e32 v9, v10                                  // 0000001014B0: 7E12110A
	v_exp_f32_e32 v8, v8                                       // 0000001014B4: 7E104B08
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001014B8: BF870095
	.long 0xd71c0008                                           // 0000001014BC: D71C0008
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 0000001014C0: 02021308
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo                        // 0000001014C4: 02101080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000001014C8: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001014D0: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v8, vcc_lo               // 0000001014D4: 020010FF 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000001014DC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001014E0: BF870091
	v_div_scale_f32 v8, null, v0, v0, v1                       // 0000001014E4: D6FC7C08 04060100
	v_rcp_f32_e32 v9, v8                                       // 0000001014EC: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001014F0: BF870095
	v_fma_f32 v10, -v8, v9, 1.0                                // 0000001014F4: D613000A 23CA1308
	v_fmac_f32_e32 v9, v10, v9                                 // 0000001014FC: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 000000101500: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101508: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 00000010150C: 1016130A
	v_fma_f32 v12, -v8, v11, v10                               // 000000101510: D613000C 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101518: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 00000010151C: 5616130C
	v_fma_f32 v8, -v8, v11, v10                                // 000000101520: D6130008 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101528: BF870091
	v_div_fmas_f32 v8, v8, v9, v11                             // 00000010152C: D6370008 042E1308
	v_div_fixup_f32 v8, v8, v0, v1                             // 000000101534: D6270008 04060108
	v_mad_i64_i32 v[0:1], null, 0x3000, v120, v[128:129]       // 00000010153C: D6FF7C00 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101548: BF870092
	v_bfe_u32 v9, v8, 16, 1                                    // 00000010154C: D6100009 02052108
	v_add3_u32 v8, v8, v9, 0x7fff                              // 000000101554: D6550008 03FE1308 00007FFF
	global_store_d16_hi_b16 v[0:1], v8, off offset:480         // 000000101560: DC9601E0 007C0800
	s_or_b32 exec_lo, exec_lo, s0                              // 000000101568: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000010156C: BE802002
	s_cbranch_execz 57240                                      // 000000101570: BFA5DF98 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39d4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[130:131]       // 000000101574: D6FF7C00 060AF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000101580: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000101588: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000010158C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101590: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000101594: 100200FF BFB8AA3B
	v_fma_f32 v8, 0xbfb8aa3b, v0, -v1                          // 00000010159C: D6130008 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 0000001015A8: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001015AC: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 0000001015B0: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000001015B4: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v8, v0, 0xb2a5705f, v8                         // 0000001015BC: 58101100 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001015C4: BF870121
	v_add_f32_e32 v1, v1, v8                                   // 0000001015C8: 06021101
	v_cvt_i32_f32_e32 v8, v9                                   // 0000001015CC: 7E101109
	v_exp_f32_e32 v1, v1                                       // 0000001015D0: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001015D4: BF870095
	.long 0xd71c0001                                           // 0000001015D8: D71C0001
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 0000001015DC: 02021101
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000001015E0: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000001015E4: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001015EC: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v2// 0000001015F0: CA4602FF 00000588 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000001015FC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101600: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000101604: D6FC7C02 04060100
	v_rcp_f32_e32 v8, v2                                       // 00000010160C: 7E105502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101610: BF870095
	v_fma_f32 v9, -v2, v8, 1.0                                 // 000000101614: D6130009 23CA1102
	v_fmac_f32_e32 v8, v9, v8                                  // 00000010161C: 56101109
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 000000101620: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101628: BF870091
	v_mul_f32_e32 v10, v9, v8                                  // 00000010162C: 10141109
	v_fma_f32 v11, -v2, v10, v9                                // 000000101630: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101638: BF870091
	v_fmac_f32_e32 v10, v11, v8                                // 00000010163C: 5614110B
	v_fma_f32 v2, -v2, v10, v9                                 // 000000101640: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101648: BF870091
	v_div_fmas_f32 v2, v2, v8, v10                             // 00000010164C: D6370002 042A1102
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000101654: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[128:129]       // 00000010165C: D6FF7C00 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101668: BF870092
	v_bfe_u32 v8, v2, 16, 1                                    // 00000010166C: D6100008 02052102
	v_add3_u32 v2, v2, v8, 0x7fff                              // 000000101674: D6550002 03FE1102 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000101680: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000101688: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000010168C: BE802003
	s_cbranch_execz 57171                                      // 000000101690: BFA5DF53 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39e0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[130:131]       // 000000101694: D6FF7C00 060AF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000001016A0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000001016A8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000001016AC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001016B0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000001016B4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000001016BC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v8, v1                                     // 0000001016C8: 7E104701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001016CC: BF870091
	v_dual_fmamk_f32 v2, v0, 0xb2a5705f, v2 :: v_dual_sub_f32 v1, v1, v8// 0000001016D0: C88A0500 02001101 B2A5705F
	v_add_f32_e32 v1, v1, v2                                   // 0000001016DC: 06020501
	v_cvt_i32_f32_e32 v2, v8                                   // 0000001016E0: 7E041108
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000001016E4: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001016EC: BF870293
	v_exp_f32_e32 v1, v1                                       // 0000001016F0: 7E024B01
	.long 0xd71c0001                                           // 0000001016F4: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000001016F8: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001016FC: BF870121
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000101700: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000101704: 7C3600FF C2B17218
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 00000010170C: CA4602FF 00000789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101718: BF870091
	v_add_f32_e32 v0, 1.0, v0                                  // 00000010171C: 060000F2
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000101720: D6FC7C02 04060100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000101728: BF870291
	v_rcp_f32_e32 v3, v2                                       // 00000010172C: 7E065502
	v_fma_f32 v8, -v2, v3, 1.0                                 // 000000101730: D6130008 23CA0702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000101738: BF8700A1
	v_fmac_f32_e32 v3, v8, v3                                  // 00000010173C: 56060708
	v_div_scale_f32 v8, vcc_lo, v1, v0, v1                     // 000000101740: D6FC6A08 04060101
	v_mul_f32_e32 v9, v8, v3                                   // 000000101748: 10120708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010174C: BF870091
	v_fma_f32 v10, -v2, v9, v8                                 // 000000101750: D613000A 24221302
	v_fmac_f32_e32 v9, v10, v3                                 // 000000101758: 5612070A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010175C: BF870091
	v_fma_f32 v2, -v2, v9, v8                                  // 000000101760: D6130002 24221302
	v_div_fmas_f32 v2, v2, v3, v9                              // 000000101768: D6370002 04260702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000101770: BF870121
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000101774: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[128:129]       // 00000010177C: D6FF7C00 0602F4FF 00003000
	v_bfe_u32 v3, v2, 16, 1                                    // 000000101788: D6100003 02052102
	s_delay_alu instid0(VALU_DEP_1)                            // 000000101790: BF870001
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000101794: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001017A0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001017A8: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000001017AC: BE802004
	s_cbranch_execz 57102                                      // 0000001017B0: BFA5DF0E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39ec>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[130:131]       // 0000001017B4: D6FF7C00 060AF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000001017C0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000001017C8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000001017CC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001017D0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000001017D4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000001017DC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000001017E8: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001017EC: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000001017F0: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000001017F4: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000001017FC: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000101804: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000101808: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000010180C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000101810: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101814: BF870095
	.long 0xd71c0001                                           // 000000101818: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000010181C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000101820: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000101824: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010182C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v4// 000000101830: CA4602FF 00000986 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000010183C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101840: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000101844: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000010184C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101850: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000101854: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000010185C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000101860: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101868: BF870091
	v_mul_f32_e32 v8, v4, v3                                   // 00000010186C: 10100704
	v_fma_f32 v9, -v2, v8, v4                                  // 000000101870: D6130009 24121102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101878: BF870091
	v_fmac_f32_e32 v8, v9, v3                                  // 00000010187C: 56100709
	v_fma_f32 v2, -v2, v8, v4                                  // 000000101880: D6130002 24121102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101888: BF870091
	v_div_fmas_f32 v2, v2, v3, v8                              // 00000010188C: D6370002 04220702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000101894: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[128:129]       // 00000010189C: D6FF7C00 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001018A8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000001018AC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000001018B4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001018C0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001018C8: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000001018CC: BE802005
	s_cbranch_execz 57033                                      // 0000001018D0: BFA5DEC9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39f8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[130:131]       // 0000001018D4: D6FF7C00 060AF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000001018E0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000001018E8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000001018EC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001018F0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000001018F4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000001018FC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000101908: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010190C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000101910: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000101914: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000010191C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000101924: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000101928: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000010192C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000101930: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101934: BF870095
	.long 0xd71c0001                                           // 000000101938: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000010193C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000101940: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000101944: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010194C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 000000101950: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 000000101958: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101960: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000101964: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000010196C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101970: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000101974: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000010197C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000101980: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101988: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000010198C: 100A0704
	v_fma_f32 v8, -v2, v5, v4                                  // 000000101990: D6130008 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101998: BF870091
	v_fmac_f32_e32 v5, v8, v3                                  // 00000010199C: 560A0708
	v_fma_f32 v2, -v2, v5, v4                                  // 0000001019A0: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001019A8: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000001019AC: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000001019B4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[128:129]       // 0000001019BC: D6FF7C00 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001019C8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000001019CC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000001019D4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001019E0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001019E8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000001019EC: BE802006
	s_cbranch_execz 56964                                      // 0000001019F0: BFA5DE84 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a04>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[130:131]       // 0000001019F4: D6FF7C00 060AFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000101A00: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000101A08: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000101A0C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101A10: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000101A14: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000101A1C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000101A28: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000101A2C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000101A30: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000101A34: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000101A3C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000101A44: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000101A48: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000101A4C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000101A50: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101A54: BF870095
	.long 0xd71c0001                                           // 000000101A58: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000101A5C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000101A60: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000101A64: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101A6C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v132, v6// 000000101A70: CA4602FF 00000D84 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000101A7C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101A80: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000101A84: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000101A8C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101A90: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000101A94: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000101A9C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000101AA0: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101AA8: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000101AAC: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 000000101AB0: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101AB8: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 000000101ABC: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 000000101AC0: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101AC8: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000101ACC: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000101AD4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[128:129]       // 000000101ADC: D6FF7C00 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101AE8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000101AEC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000101AF4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000101B00: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000101B08: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000101B0C: BE802007
	s_cbranch_execz 56895                                      // 000000101B10: BFA5DE3F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a10>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[130:131]       // 000000101B14: D6FF7C00 060AFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000101B20: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000101B28: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000101B2C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101B30: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000101B34: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000101B3C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000101B48: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000101B4C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000101B50: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000101B54: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000101B5C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000101B64: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000101B68: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000101B6C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000101B70: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101B74: BF870095
	.long 0xd71c0001                                           // 000000101B78: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000101B7C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000101B80: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000101B84: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101B8C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 000000101B90: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000101B9C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101BA0: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000101BA4: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000101BAC: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101BB0: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000101BB4: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000101BBC: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000101BC0: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101BC8: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000101BCC: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 000000101BD0: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101BD8: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 000000101BDC: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 000000101BE0: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101BE8: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000101BEC: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000101BF4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[128:129]       // 000000101BFC: D6FF7C00 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101C08: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000101C0C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000101C14: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000101C20: DC9601E0 007C0200
	s_endpgm                                                   // 000000101C28: BFB00000
		...

