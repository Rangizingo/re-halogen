00000000000d0800 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000D0800: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000D0804: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000D080C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000D0814: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000D0818: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000D081C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000D0820: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000D0828: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000D082C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000D0830: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000D0834: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000D083C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000D0840: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000D0844: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000D0848: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000D084C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000D0850: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000D0854: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000D0858: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000D085C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000D0864: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000D086C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000D0870: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000D0874: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000D0878: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000D087C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000D0880: 821E191E
	.long 0xd7001f02                                           // 0000000D0884: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000D0888: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000D088C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000D0894: BE9E0080
	s_nop 0                                                    // 0000000D0898: BF800000
	s_nop 0                                                    // 0000000D089C: BF800000
	s_nop 0                                                    // 0000000D08A0: BF800000
	s_nop 0                                                    // 0000000D08A4: BF800000
	s_nop 0                                                    // 0000000D08A8: BF800000
	s_nop 0                                                    // 0000000D08AC: BF800000
	s_nop 0                                                    // 0000000D08B0: BF800000
	s_nop 0                                                    // 0000000D08B4: BF800000
	s_nop 0                                                    // 0000000D08B8: BF800000
	s_nop 0                                                    // 0000000D08BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000D08C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000D08C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D08CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000D08D0: 300C1089
	.long 0xd7006a06                                           // 0000000D08D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000D08D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D08DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000D08E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000D08E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000D08F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000D08F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000D08FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000D0908: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000D090C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000D0910: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000D0918: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000D091C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000D0920: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000D0924: F4000780 F8000058
	v_or_b32_e32 v36, 0xffffff80, v0                           // 0000000D092C: 384800FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000D0934: 32040084
	s_mov_b32 s0, 0                                            // 0000000D0938: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000D093C: BF89FC07
	s_barrier                                                  // 0000000D0940: BFBD0000
	buffer_gl0_inv                                             // 0000000D0944: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000D094C: BF02801E
	s_cbranch_scc1 12                                          // 0000000D0950: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000D0954: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000D095C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D0964: BF870002
	v_lshl_add_u32 v35, v5, 2, v3                              // 0000000D0968: D6460023 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000D0970: 7E060280
	v_lshlrev_b32_e32 v37, 2, v5                               // 0000000D0974: 304A0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000D0978: 916A007E
	s_cbranch_vccz 2                                           // 0000000D097C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2201                                              // 0000000D0980: BFA00899 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23e8>
	v_lshlrev_b32_e32 v37, 2, v5                               // 0000000D0984: 304A0A82
	s_add_i32 s0, s30, 63                                      // 0000000D0988: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000D098C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000D0994: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000D0998: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000D099C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000D09A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v38, 2, v0      // 0000000D09A4: CA220080 03260082
	s_ashr_i32 s1, s0, 31                                      // 0000000D09AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000D09B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000D09B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000D09B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000D09BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000D09C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000D09C4: 848A811A
	v_mad_u32_u24 v35, 0x44, v2, v37                           // 0000000D09C8: D60B0023 049604FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000D09D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000D09D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000D09DC: B00A0204
	.long 0xd7000b2a                                           // 0000000D09E0: D7000B2A
	v_cndmask_b32_e32 v1, s34, v37, vcc_lo                     // 0000000D09E4: 02024A22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000D09E8: BF8704B1
	v_add_co_ci_u32_e64 v43, null, s35, 0, s11                 // 0000000D09EC: D5207C2B 002D0023
	v_mad_u32_u24 v44, v2, s10, 0x3300                         // 0000000D09F4: D60B002C 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000D0A00: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v39, 0x4320, v38// 0000000D0A04: CA20000B 0C264CFF 00004320
	v_or_b32_e32 v11, s10, v38                                 // 0000000D0A10: 38164C0A
	.long 0xd7000a05                                           // 0000000D0A14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000D0A18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D0A1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000D0A20: D5207C06 00290001
	.long 0xd7000107                                           // 0000000D0A28: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000D0A2C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D0A30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000D0A34: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000D0A3C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000D0A40: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000D0A44: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000D0A4C: 84848E02
	.long 0xd700010b                                           // 0000000D0A50: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000D0A54: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000D0A58: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000D0A5C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000D0A64: 8205050F
	.long 0xd700010d                                           // 0000000D0A68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000D0A6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D0A70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000D0A74: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000D0A7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000D0A80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000D0A88: D5207C10 00061880
	.long 0xd7000111                                           // 0000000D0A90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000D0A94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D0A9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000D0AA0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000D0AA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000D0AAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000D0AB4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000D0ABC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000D0AC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000D0AC8: BF8700D1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000D0ACC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000D0AD4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000D0AD8: 020216FF 000F0000
	v_or_b32_e32 v45, 0x2200, v1                               // 0000000D0AE0: 385A02FF 00002200
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000D0AE8: D5207C18 00061880
	.long 0xd7000119                                           // 0000000D0AF0: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000D0AF4: 020216FF 00120000
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000D0AFC: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000D0B04: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000D0B08: 020216FF 00150000
	v_add_nc_u32_e32 v40, 0x4420, v38                          // 0000000D0B10: 4A504CFF 00004420
	.long 0xd44c0000                                           // 0000000D0B18: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000D0B1C: 020200FF 00000080
	v_add_nc_u32_e32 v41, 1, v2                                // 0000000D0B24: 4A520481
	v_add_nc_u32_e32 v4, 0x2200, v35                           // 0000000D0B28: 4A0846FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000D0B30: D5207C1C 00061880
	v_add_nc_u32_e32 v46, 0x400, v45                           // 0000000D0B38: 4A5C5AFF 00000400
	v_add_nc_u32_e32 v47, 0x600, v45                           // 0000000D0B40: 4A5E5AFF 00000600
	v_add_nc_u32_e32 v48, 0x800, v45                           // 0000000D0B48: 4A605AFF 00000800
	s_mov_b32 s5, 0                                            // 0000000D0B50: BE850080
	s_mov_b32 s6, 0x43800000                                   // 0000000D0B54: BE8600FF 43800000
	s_mov_b32 s7, 0x3b800000                                   // 0000000D0B5C: BE8700FF 3B800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000D0B64: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000D0B68: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000D0B70: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000D0B74: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000D0B78: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000D0B7C: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000D0B80: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000D0B84: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000D0B88: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000D0B8C: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000D0B90: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000D0B98: BE84206A
	s_cbranch_execz 77                                         // 0000000D0B9C: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4d4>
	v_or_b32_e32 v29, s11, v0                                  // 0000000D0BA0: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0BA4: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000D0BA8: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000D0BB0: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0BB4: BF870091
	.long 0xd73c001d                                           // 0000000D0BB8: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000D0BBC: 02023A82
	.long 0xd700011d                                           // 0000000D0BC0: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000D0BC4: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D0BC8: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000D0BCC: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000D0BD4: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D0BDC: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000D0BE0: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000D0BE4: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000D0BF0: BF8701A1
	v_fma_f32 v49, 0x3fb8aa3b, v29, -v32                       // 0000000D0BF4: D6130031 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v50, v32                                   // 0000000D0C00: 7E644720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000D0C04: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000D0C10: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000D0C14: BF870113
	v_dual_fmac_f32 v49, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v50// 0000000D0C18: C80A3AFF 31206520 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000D0C24: 083E451F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D0C28: BF870122
	v_dual_fmac_f32 v33, 0x32a5705f, v30 :: v_dual_add_f32 v32, v32, v49// 0000000D0C2C: C8083CFF 21206320 32A5705F
	.long 0xd41b0001                                           // 0000000D0C38: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000D0C3C: 02023CFF C2CE8ED0
	v_add_f32_e32 v31, v31, v33                                // 0000000D0C44: 063E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000D0C48: 7E421122
	v_cvt_i32_f32_e32 v34, v50                                 // 0000000D0C4C: 7E441132
	v_exp_f32_e32 v32, v32                                     // 0000000D0C50: 7E404B20
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000000D0C54: BF870313
	v_exp_f32_e32 v31, v31                                     // 0000000D0C58: 7E3E4B1F
	.long 0xd71c0020                                           // 0000000D0C5C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000D0C60: 02024520
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0C64: BF870095
	.long 0xd71c001f                                           // 0000000D0C68: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000D0C6C: 0202431F
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000D0C70: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000D0C78: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000D0C7C: 02023AFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D0C84: BF8700A1
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000D0C88: D5010020 00064080
	.long 0xd41e0001                                           // 0000000D0C90: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000D0C94: 02023CFF 42B17218
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000D0C9C: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000D0CA8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000D0CAC: 02023AFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D0CB4: BF870001
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000D0CB8: D501001D 000640FF 7F800000
	ds_store_b32 v39, v30                                      // 0000000D0CC4: D8340000 00001E27
	ds_store_b32 v40, v29                                      // 0000000D0CCC: D8340000 00001D28
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D0CD4: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000D0CD8: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000D0CE0: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D0CE4: BF89FC07
	s_barrier                                                  // 0000000D0CE8: BFBD0000
	buffer_gl0_inv                                             // 0000000D0CEC: E0AC0000 00000000
	s_branch 15                                                // 0000000D0CF4: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D0CF8: 8C7E047E
	.long 0xd700011d                                           // 0000000D0CFC: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000D0D00: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D0D08: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D0D0C: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000D0D14: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000D0D18: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000D0D1C: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000D0D20: BF89FC07
	s_barrier                                                  // 0000000D0D24: BFBD0000
	buffer_gl0_inv                                             // 0000000D0D28: E0AC0000 00000000
	s_cbranch_scc1 185                                         // 0000000D0D30: BFA200B9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x818>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000D0D34: CA10011E 201E011D
	v_dual_mov_b32 v33, v38 :: v_dual_mov_b32 v34, v36         // 0000000D0D3C: CA100126 21220124
	s_mov_b32 s13, 0                                           // 0000000D0D44: BE8D0080
	s_nop 0                                                    // 0000000D0D48: BF800000
	s_nop 0                                                    // 0000000D0D4C: BF800000
	s_nop 0                                                    // 0000000D0D50: BF800000
	s_nop 0                                                    // 0000000D0D54: BF800000
	s_nop 0                                                    // 0000000D0D58: BF800000
	s_nop 0                                                    // 0000000D0D5C: BF800000
	s_nop 0                                                    // 0000000D0D60: BF800000
	s_nop 0                                                    // 0000000D0D64: BF800000
	s_nop 0                                                    // 0000000D0D68: BF800000
	s_nop 0                                                    // 0000000D0D6C: BF800000
	s_nop 0                                                    // 0000000D0D70: BF800000
	s_nop 0                                                    // 0000000D0D74: BF800000
	s_nop 0                                                    // 0000000D0D78: BF800000
	s_nop 0                                                    // 0000000D0D7C: BF800000
	global_load_b32 v49, v[31:32], off                         // 0000000D0D80: DC520000 317C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000D0D88: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000D0D90: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000D0D94: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D0D9C: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000D0DA0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000D0DA8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000D0DAC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000D0DB4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000D0DB8: BF8903F7
	ds_store_b32 v33, v49 offset:13056                         // 0000000D0DBC: D8343300 00003121
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000D0DC4: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000D0DCC: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000D0DD0: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000D0DD4: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D0DD8: BF89FC07
	s_barrier                                                  // 0000000D0DDC: BFBD0000
	buffer_gl0_inv                                             // 0000000D0DE0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000D0DE8: BE842000
	s_cbranch_execz 65474                                      // 0000000D0DEC: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f8>
	v_or3_b32 v31, s12, s11, v2                                // 0000000D0DF0: D658001F 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0DF8: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 0000000D0DFC: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 0000000D0E04: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 0000000D0E08: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0E0C: BF870091
	.long 0xd700011f                                           // 0000000D0E10: D700011F
	v_cndmask_b32_e32 v1, v42, v31, vcc_lo                     // 0000000D0E14: 02023F2A
	v_add_co_ci_u32_e64 v32, null, v43, v32, s1                // 0000000D0E18: D5207C20 0006412B
	s_mov_b32 s1, 0                                            // 0000000D0E20: BE810080
	global_load_b32 v31, v[31:32], off                         // 0000000D0E24: DC520000 1F7C001F
	v_mad_u64_u32 v[32:33], null, 0x44, s1, v[1:2]             // 0000000D0E2C: D6FE7C20 040402FF 00000044
	s_add_i32 s13, s1, 8                                       // 0000000D0E38: 810D8801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000D0E3C: B6810078
	ds_load_2addr_b32 v[33:34], v32 offset1:17                 // 0000000D0E40: D8DC1100 21000020
	ds_load_2addr_b32 v[49:50], v32 offset0:34 offset1:51      // 0000000D0E48: D8DC3322 31000020
	ds_load_2addr_b32 v[51:52], v32 offset0:68 offset1:85      // 0000000D0E50: D8DC5544 33000020
	ds_load_2addr_b32 v[53:54], v32 offset0:102 offset1:119    // 0000000D0E58: D8DC7766 35000020
	v_lshl_add_u32 v32, s1, 2, v44                             // 0000000D0E60: D6460020 04B10401
	s_mov_b32 s1, s13                                          // 0000000D0E68: BE81000D
	ds_load_2addr_b32 v[55:56], v32 offset1:1                  // 0000000D0E6C: D8DC0100 37000020
	ds_load_2addr_b32 v[57:58], v32 offset0:2 offset1:3        // 0000000D0E74: D8DC0302 39000020
	ds_load_2addr_b32 v[59:60], v32 offset0:4 offset1:5        // 0000000D0E7C: D8DC0504 3B000020
	ds_load_2addr_b32 v[61:62], v32 offset0:6 offset1:7        // 0000000D0E84: D8DC0706 3D000020
	s_waitcnt lgkmcnt(7)                                       // 0000000D0E8C: BF89FC77
	v_fma_mixlo_f16 v32, v33, s6, 0                            // 0000000D0E90: CC210020 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000D0E98: CC210022 02000D22
	s_waitcnt lgkmcnt(6)                                       // 0000000D0EA0: BF89FC67
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000D0EA4: CC210031 02000D31
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D0EAC: BF870193
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0EB0: CC200020 8A000F20
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0EB8: CC200022 8A000F22
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000D0EC0: BF870003
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0EC4: CC200031 8A000F31
	s_waitcnt lgkmcnt(3)                                       // 0000000D0ECC: BF89FC37
	v_fma_mixlo_f16 v33, v55, s6, 0                            // 0000000D0ED0: CC210021 02000D37
	v_fma_mixlo_f16 v55, v56, s6, 0                            // 0000000D0ED8: CC210037 02000D38
	s_waitcnt lgkmcnt(2)                                       // 0000000D0EE0: BF89FC27
	v_fma_mixlo_f16 v56, v57, s6, 0                            // 0000000D0EE4: CC210038 02000D39
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D0EEC: BF870193
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0EF0: CC200021 8A000F21
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0EF8: CC200037 8A000F37
	s_waitcnt vmcnt(0)                                         // 0000000D0F00: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000D0F04: BF870242
	v_fma_f32 v31, -v33, v32, v31                              // 0000000D0F08: D613001F 247E4121
	v_fma_mixlo_f16 v32, v50, s6, 0                            // 0000000D0F10: CC210020 02000D32
	v_fma_mixlo_f16 v33, v58, s6, 0                            // 0000000D0F18: CC210021 02000D3A
	v_fma_mix_f32 v50, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0F20: CC200032 8A000F38
	v_fma_f32 v31, -v55, v34, v31                              // 0000000D0F28: D613001F 247E4537
	v_fma_mixlo_f16 v34, v51, s6, 0                            // 0000000D0F30: CC210022 02000D33
	s_waitcnt lgkmcnt(1)                                       // 0000000D0F38: BF89FC17
	v_fma_mixlo_f16 v51, v59, s6, 0                            // 0000000D0F3C: CC210033 02000D3B
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0F44: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0F4C: CC200021 8A000F21
	v_fma_f32 v31, -v50, v49, v31                              // 0000000D0F54: D613001F 247E6332
	v_fma_mixlo_f16 v49, v52, s6, 0                            // 0000000D0F5C: CC210031 02000D34
	v_fma_mixlo_f16 v50, v60, s6, 0                            // 0000000D0F64: CC210032 02000D3C
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0F6C: CC200022 8A000F22
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0F74: CC200033 8A000F33
	v_fma_f32 v31, -v33, v32, v31                              // 0000000D0F7C: D613001F 247E4121
	v_fma_mixlo_f16 v32, v53, s6, 0                            // 0000000D0F84: CC210020 02000D35
	s_waitcnt lgkmcnt(0)                                       // 0000000D0F8C: BF89FC07
	v_fma_mixlo_f16 v33, v61, s6, 0                            // 0000000D0F90: CC210021 02000D3D
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0F98: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0FA0: CC200032 8A000F32
	v_fma_f32 v31, -v51, v34, v31                              // 0000000D0FA8: D613001F 247E4533
	v_fma_mixlo_f16 v34, v54, s6, 0                            // 0000000D0FB0: CC210022 02000D36
	v_fma_mixlo_f16 v51, v62, s6, 0                            // 0000000D0FB8: CC210033 02000D3E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0FC0: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0FC8: CC200021 8A000F21
	v_fma_f32 v31, -v50, v49, v31                              // 0000000D0FD0: D613001F 247E6332
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0FD8: CC200022 8A000F22
	v_fma_mix_f32 v49, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0FE0: CC200031 8A000F33
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0FE8: BF870093
	v_fma_f32 v31, -v33, v32, v31                              // 0000000D0FEC: D613001F 247E4121
	v_fma_f32 v31, -v49, v34, v31                              // 0000000D0FF4: D613001F 247E4531
	s_cbranch_scc1 65419                                       // 0000000D0FFC: BFA2FF8B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x62c>
	v_mad_u64_u32 v[32:33], null, 0x44, s12, v[4:5]            // 0000000D1000: D6FE7C20 041018FF 00000044
	ds_store_b32 v32, v31                                      // 0000000D100C: D8340000 00001F20
	s_branch 65336                                             // 0000000D1014: BFA0FF38 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f8>
	v_mov_b32_e32 v30, v14                                     // 0000000D1018: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000D101C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000D1024: 7E3E0309
	v_mov_b32_e32 v49, v41                                     // 0000000D1028: 7E620329
	s_mov_b32 s12, 0                                           // 0000000D102C: BE8C0080
	s_branch 21                                                // 0000000D1030: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x888>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000D1034: 8C7E0D7E
	.long 0xd700011f                                           // 0000000D1038: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000D103C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D1044: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000D1048: D5207C20 00064080
	.long 0xd700011d                                           // 0000000D1050: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000D1054: 02023AFF 00000800
	v_add_nc_u32_e32 v49, 8, v49                               // 0000000D105C: 4A626288
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D1060: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000D1068: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000D106C: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000D1070: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000D1074: BC7C0000
	s_barrier                                                  // 0000000D1078: BFBD0000
	buffer_gl0_inv                                             // 0000000D107C: E0AC0000 00000000
	s_cbranch_scc1 217                                         // 0000000D1084: BFA200D9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xbec>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D1088: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000D108C: CA100120 2220011F
	v_dual_mov_b32 v50, v38 :: v_dual_mov_b32 v51, v36         // 0000000D1094: CA100126 32320124
	s_mov_b32 s13, 0                                           // 0000000D109C: BE8D0080
	s_nop 0                                                    // 0000000D10A0: BF800000
	s_nop 0                                                    // 0000000D10A4: BF800000
	s_nop 0                                                    // 0000000D10A8: BF800000
	s_nop 0                                                    // 0000000D10AC: BF800000
	s_nop 0                                                    // 0000000D10B0: BF800000
	s_nop 0                                                    // 0000000D10B4: BF800000
	s_nop 0                                                    // 0000000D10B8: BF800000
	s_nop 0                                                    // 0000000D10BC: BF800000
	global_load_b32 v52, v[33:34], off                         // 0000000D10C0: DC520000 347C0021
	v_add_nc_u32_e32 v51, 0x80, v51                            // 0000000D10C8: 4A6666FF 00000080
	.long 0xd7000121                                           // 0000000D10D0: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000D10D4: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D10DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000D10E0: D5207C22 00064480
	.long 0xd4490004                                           // 0000000D10E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v51, vcc_lo                   // 0000000D10EC: 020266FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000D10F4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000D10F8: BF8903F7
	ds_store_b32 v50, v52 offset:13056                         // 0000000D10FC: D8343300 00003432
	v_add_nc_u32_e32 v50, 0x204, v50                           // 0000000D1104: 4A6464FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000D110C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000D1110: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000D1114: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D1118: BF89FC07
	s_barrier                                                  // 0000000D111C: BFBD0000
	buffer_gl0_inv                                             // 0000000D1120: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000D1128: BE8D2000
	s_cbranch_execz 65473                                      // 0000000D112C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	v_or_b32_e32 v33, s12, v2                                  // 0000000D1130: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D1134: BF870091
	v_or_b32_e32 v50, s11, v33                                 // 0000000D1138: 3864420B
	.long 0xd4440001                                           // 0000000D113C: D4440001
	v_cndmask_b32_e32 v1, s30, v50, vcc_lo                     // 0000000D1140: 0202641E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000D1144: 8B7E017E
	s_cbranch_execz 65466                                      // 0000000D1148: BFA5FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	v_mov_b32_e32 v51, 0                                       // 0000000D114C: 7E660280
	s_mov_b32 s1, 0                                            // 0000000D1150: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000D1154: BF870009
	v_lshl_add_u32 v34, s1, 2, v44                             // 0000000D1158: D6460022 04B10401
	s_add_i32 s4, s1, 8                                        // 0000000D1160: 81048801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000D1164: B6810078
	ds_load_2addr_b32 v[61:62], v34 offset1:1                  // 0000000D1168: D8DC0100 3D000022
	ds_load_2addr_b32 v[63:64], v34 offset0:2 offset1:3        // 0000000D1170: D8DC0302 3F000022
	ds_load_2addr_b32 v[65:66], v34 offset0:4 offset1:5        // 0000000D1178: D8DC0504 41000022
	ds_load_2addr_b32 v[67:68], v34 offset0:6 offset1:7        // 0000000D1180: D8DC0706 43000022
	v_mad_u64_u32 v[52:53], null, 0x44, s1, v[1:2]             // 0000000D1188: D6FE7C34 040402FF 00000044
	s_mov_b32 s1, s4                                           // 0000000D1194: BE810004
	ds_load_2addr_b32 v[53:54], v52 offset1:17                 // 0000000D1198: D8DC1100 35000034
	ds_load_2addr_b32 v[55:56], v52 offset0:34 offset1:51      // 0000000D11A0: D8DC3322 37000034
	ds_load_2addr_b32 v[57:58], v52 offset0:68 offset1:85      // 0000000D11A8: D8DC5544 39000034
	ds_load_2addr_b32 v[59:60], v52 offset0:102 offset1:119    // 0000000D11B0: D8DC7766 3B000034
	s_waitcnt lgkmcnt(7)                                       // 0000000D11B8: BF89FC77
	v_fma_mixlo_f16 v52, v61, s6, 0                            // 0000000D11BC: CC210034 02000D3D
	s_waitcnt lgkmcnt(6)                                       // 0000000D11C4: BF89FC67
	v_fma_mixlo_f16 v61, v63, s6, 0                            // 0000000D11C8: CC21003D 02000D3F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D11D0: BF870002
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D11D4: CC200034 8A000F34
	s_waitcnt lgkmcnt(3)                                       // 0000000D11DC: BF89FC37
	v_fma_mixlo_f16 v34, v53, s6, 0                            // 0000000D11E0: CC210022 02000D35
	v_fma_mixlo_f16 v53, v54, s6, 0                            // 0000000D11E8: CC210035 02000D36
	v_fma_mixlo_f16 v54, v62, s6, 0                            // 0000000D11F0: CC210036 02000D3E
	s_waitcnt lgkmcnt(2)                                       // 0000000D11F8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000D11FC: CC210037 02000D37
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1204: CC200022 8A000F22
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D120C: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1214: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000D121C: BF870214
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1220: CC200037 8A000F37
	v_fmac_f32_e32 v51, v52, v34                               // 0000000D1228: 56664534
	v_fma_mixlo_f16 v34, v56, s6, 0                            // 0000000D122C: CC210022 02000D38
	v_fma_mixlo_f16 v52, v64, s6, 0                            // 0000000D1234: CC210034 02000D40
	v_fma_mix_f32 v56, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D123C: CC200038 8A000F3D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D1244: BF870004
	v_fmac_f32_e32 v51, v54, v53                               // 0000000D1248: 56666B36
	s_waitcnt lgkmcnt(1)                                       // 0000000D124C: BF89FC17
	v_fma_mixlo_f16 v53, v57, s6, 0                            // 0000000D1250: CC210035 02000D39
	v_fma_mixlo_f16 v54, v65, s6, 0                            // 0000000D1258: CC210036 02000D41
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1260: CC200022 8A000F22
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1268: CC200034 8A000F34
	v_fmac_f32_e32 v51, v56, v55                               // 0000000D1270: 56666F38
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000D1274: CC210037 02000D3A
	v_fma_mixlo_f16 v56, v66, s6, 0                            // 0000000D127C: CC210038 02000D42
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1284: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D128C: CC200036 8A000F36
	v_fmac_f32_e32 v51, v52, v34                               // 0000000D1294: 56664534
	s_waitcnt lgkmcnt(0)                                       // 0000000D1298: BF89FC07
	v_fma_mixlo_f16 v34, v59, s6, 0                            // 0000000D129C: CC210022 02000D3B
	v_fma_mixlo_f16 v52, v67, s6, 0                            // 0000000D12A4: CC210034 02000D43
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D12AC: CC200037 8A000F37
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D12B4: CC200038 8A000F38
	v_fmac_f32_e32 v51, v54, v53                               // 0000000D12BC: 56666B36
	v_fma_mixlo_f16 v53, v60, s6, 0                            // 0000000D12C0: CC210035 02000D3C
	v_fma_mixlo_f16 v54, v68, s6, 0                            // 0000000D12C8: CC210036 02000D44
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D12D0: CC200022 8A000F22
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D12D8: CC200034 8A000F34
	v_fmac_f32_e32 v51, v56, v55                               // 0000000D12E0: 56666F38
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D12E4: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D12EC: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D12F4: BF870093
	v_fmac_f32_e32 v51, v52, v34                               // 0000000D12F8: 56664534
	v_fmac_f32_e32 v51, v54, v53                               // 0000000D12FC: 56666B36
	s_cbranch_scc1 65428                                       // 0000000D1300: BFA2FF94 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x954>
	v_dual_mov_b32 v52, v1 :: v_dual_lshlrev_b32 v33, 2, v33   // 0000000D1304: CA220101 34204282
	s_mov_b32 s14, 0                                           // 0000000D130C: BE8E0080
	ds_load_b32 v53, v33 offset:17440                          // 0000000D1310: D8D84420 35000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000D1318: CA10011E 2220011D
	s_waitcnt lgkmcnt(0)                                       // 0000000D1320: BF89FC07
	v_mul_f32_e32 v51, v51, v53                                // 0000000D1324: 10666B33
	v_mov_b32_e32 v53, v49                                     // 0000000D1328: 7E6A0331
	s_nop 0                                                    // 0000000D132C: BF800000
	s_nop 0                                                    // 0000000D1330: BF800000
	s_nop 0                                                    // 0000000D1334: BF800000
	s_nop 0                                                    // 0000000D1338: BF800000
	s_nop 0                                                    // 0000000D133C: BF800000
	global_load_b32 v54, v[33:34], off                         // 0000000D1340: DC520000 367C0021
	ds_load_b32 v55, v52 offset:8704                           // 0000000D1348: D8D82200 37000034
	v_add_nc_u32_e32 v53, -1, v53                              // 0000000D1350: 4A6A6AC1
	.long 0xd7000121                                           // 0000000D1354: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000D1358: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D135C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000D1360: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000D1368: D44A0004
	v_cndmask_b32_e32 v1, 0, v53, vcc_lo                       // 0000000D136C: 02026A80
	v_add_nc_u32_e32 v52, 0x44, v52                            // 0000000D1370: 4A6868FF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000D1378: 8C0E0E04
	s_waitcnt lgkmcnt(0)                                       // 0000000D137C: BF89FC07
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000D1380: CC210037 02000D37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000D1388: BF8700B1
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D138C: CC200037 8A000F37
	s_waitcnt vmcnt(0)                                         // 0000000D1394: BF8903F7
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000D1398: CC210036 02000D36
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D13A0: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D13A8: BF870001
	v_fmac_f32_e32 v51, v54, v55                               // 0000000D13AC: 56666F36
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000D13B0: 917E0E7E
	s_cbranch_execnz 65506                                     // 0000000D13B4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb40>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000D13B8: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D13BC: BF870121
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000D13C0: D6100034 02052133
	v_mad_u64_u32 v[33:34], null, 0x3000, v50, v[5:6]          // 0000000D13C8: D6FE7C21 041664FF 00003000
	v_add3_u32 v50, v51, v52, 0x7fff                           // 0000000D13D4: D6550032 03FE6933 00007FFF
	global_store_d16_hi_b16 v[33:34], v50, off                 // 0000000D13E0: DC960000 007C3221
	s_branch 65298                                             // 0000000D13E8: BFA0FF12 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000D13EC: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v36                                     // 0000000D13F4: 7E3E0324
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000D13F8: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000D13FC: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000D1404: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000D1408: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000D1410: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000D1418: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000D141C: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000D1420: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000D1428: A0010401
	s_mov_b32 s4, 0                                            // 0000000D142C: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000D1430: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000D1434: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000D1438: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000D143C: BF870585
	.long 0xd71c001d                                           // 0000000D1440: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000D1444: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000D1448: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000D144C: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000D1454: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000D1458: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000D1460: 980180C1
	v_mov_b32_e32 v29, v35                                     // 0000000D1464: 7E3A0323
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000D1468: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000D1474: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000D147C: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D1484: BF870001
	.long 0xd4490001                                           // 0000000D1488: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000D148C: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000D1494: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000D1498: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000D149C: 1040411E
	ds_store_b32 v29, v32                                      // 0000000D14A0: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000D14A8: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D14B0: 917E047E
	s_cbranch_execnz 65519                                     // 0000000D14B4: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc74>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D14B8: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000D14BC: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v38           // 0000000D14C4: CA100080 1F200126
	v_mov_b32_e32 v33, v36                                     // 0000000D14CC: 7E420324
	s_mov_b32 s10, 0                                           // 0000000D14D0: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D14D4: BF89FC07
	s_barrier                                                  // 0000000D14D8: BFBD0000
	buffer_gl0_inv                                             // 0000000D14DC: E0AC0000 00000000
	s_nop 0                                                    // 0000000D14E4: BF800000
	s_nop 0                                                    // 0000000D14E8: BF800000
	s_nop 0                                                    // 0000000D14EC: BF800000
	s_nop 0                                                    // 0000000D14F0: BF800000
	s_nop 0                                                    // 0000000D14F4: BF800000
	s_nop 0                                                    // 0000000D14F8: BF800000
	s_nop 0                                                    // 0000000D14FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D1500: DC520000 227C001D
	ds_load_b32 v49, v31 offset:17184                          // 0000000D1508: D8D84320 3100001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D1510: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D1518: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D151C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000D1524: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D1528: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D1530: BF870004
	.long 0xd4490004                                           // 0000000D1534: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D1538: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D1540: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D1544: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000D1548: 10446322
	ds_store_b32 v32, v34 offset:13056                         // 0000000D154C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000D1554: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D155C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D1560: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D1564: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D1568: BF89FC07
	s_barrier                                                  // 0000000D156C: BFBD0000
	buffer_gl0_inv                                             // 0000000D1570: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v45 offset1:17                 // 0000000D1578: D8DC1100 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:34 offset1:51      // 0000000D1580: D8DC3322 1F00002D
	ds_load_2addr_b32 v[33:34], v45 offset0:68 offset1:85      // 0000000D1588: D8DC5544 2100002D
	ds_load_2addr_b32 v[49:50], v45 offset0:102 offset1:119    // 0000000D1590: D8DC7766 3100002D
	v_mov_b32_e32 v51, v0                                      // 0000000D1598: 7E660300
	s_mov_b32 s4, 0                                            // 0000000D159C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000D15A0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000D15A4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000D15AC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000D15B4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000D15B8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000D15C0: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000D15C8: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000D15CC: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000D15D4: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000D15DC: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000D15E0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000D15E8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D15F0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D15F8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1600: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1608: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1610: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1618: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1620: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1628: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000D1630: 326C6684
	.long 0xd4490001                                           // 0000000D1634: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000D1638: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D1640: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000D1644: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000D1648: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D1654: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000D1658: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000D1660: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000D1668: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000D1670: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000D1678: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000D1680: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000D1688: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000D1690: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000D1698: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000D169C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000D16A4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000D16A8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000D16B0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000D16B8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000D16C0: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000D16C4: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D16CC: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D16D4: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000D16DC: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D16E4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D16EC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D16F4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000D16FC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D1700: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000D1704: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000D1708: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000D170C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000D1714: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000D1718: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000D171C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000D1720: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1728: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000D1730: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000D1738: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D173C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1740: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1748: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D1750: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000D1754: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000D1758: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000D175C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D1764: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000D1768: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000D1770: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D1778: 917E047E
	s_cbranch_execnz 65452                                     // 0000000D177C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe30>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D1780: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v31, v38         // 0000000D1784: CA100110 1E1E0126
	v_dual_mov_b32 v29, v15 :: v_dual_mov_b32 v32, 0           // 0000000D178C: CA10010F 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000D1794: 7E420324
	s_mov_b32 s10, 0                                           // 0000000D1798: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D179C: BF89FC07
	s_barrier                                                  // 0000000D17A0: BFBD0000
	buffer_gl0_inv                                             // 0000000D17A4: E0AC0000 00000000
	s_nop 0                                                    // 0000000D17AC: BF800000
	s_nop 0                                                    // 0000000D17B0: BF800000
	s_nop 0                                                    // 0000000D17B4: BF800000
	s_nop 0                                                    // 0000000D17B8: BF800000
	s_nop 0                                                    // 0000000D17BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D17C0: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17216                          // 0000000D17C8: D8D84340 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D17D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D17D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D17DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D17E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D17E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D17F0: BF870004
	.long 0xd4490004                                           // 0000000D17F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D17F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D1800: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D1804: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000D1808: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000D180C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D1814: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D181C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D1820: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D1824: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D1828: BF89FC07
	s_barrier                                                  // 0000000D182C: BFBD0000
	buffer_gl0_inv                                             // 0000000D1830: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v45 offset0:136 offset1:153    // 0000000D1838: D8DC9988 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:170 offset1:187    // 0000000D1840: D8DCBBAA 1F00002D
	ds_load_2addr_b32 v[33:34], v45 offset0:204 offset1:221    // 0000000D1848: D8DCDDCC 2100002D
	ds_load_2addr_b32 v[49:50], v45 offset0:238 offset1:255    // 0000000D1850: D8DCFFEE 3100002D
	v_mov_b32_e32 v51, v0                                      // 0000000D1858: 7E660300
	s_mov_b32 s4, 0                                            // 0000000D185C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000D1860: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000D1864: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000D186C: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000D1874: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000D1878: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000D1880: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000D1888: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000D188C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000D1894: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000D189C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000D18A0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000D18A8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D18B0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D18B8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D18C0: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D18C8: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D18D0: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D18D8: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D18E0: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D18E8: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000D18F0: 326C6684
	.long 0xd4490001                                           // 0000000D18F4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000D18F8: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D1900: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000D1904: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000D1908: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D1914: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000D1918: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000D1920: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000D1928: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000D1930: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000D1938: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000D1940: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000D1948: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000D1950: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000D1958: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000D195C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000D1964: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000D1968: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000D1970: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000D1978: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000D1980: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000D1984: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D198C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1994: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000D199C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D19A4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D19AC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D19B4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000D19BC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D19C0: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000D19C4: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000D19C8: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000D19CC: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000D19D4: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000D19D8: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000D19DC: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000D19E0: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D19E8: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000D19F0: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000D19F8: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D19FC: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1A00: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1A08: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D1A10: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000D1A14: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000D1A18: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000D1A1C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D1A24: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000D1A28: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000D1A30: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D1A38: 917E047E
	s_cbranch_execnz 65452                                     // 0000000D1A3C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10f0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D1A40: 8C7E047E
	v_mov_b32_e32 v30, v18                                     // 0000000D1A44: 7E3C0312
	v_mov_b32_e32 v31, v38                                     // 0000000D1A48: 7E3E0326
	v_dual_mov_b32 v29, v17 :: v_dual_mov_b32 v32, 0           // 0000000D1A4C: CA100111 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000D1A54: 7E420324
	s_mov_b32 s10, 0                                           // 0000000D1A58: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D1A5C: BF89FC07
	s_barrier                                                  // 0000000D1A60: BFBD0000
	buffer_gl0_inv                                             // 0000000D1A64: E0AC0000 00000000
	s_nop 0                                                    // 0000000D1A6C: BF800000
	s_nop 0                                                    // 0000000D1A70: BF800000
	s_nop 0                                                    // 0000000D1A74: BF800000
	s_nop 0                                                    // 0000000D1A78: BF800000
	s_nop 0                                                    // 0000000D1A7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D1A80: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17248                          // 0000000D1A88: D8D84360 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D1A90: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D1A98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D1A9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D1AA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D1AA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D1AB0: BF870004
	.long 0xd4490004                                           // 0000000D1AB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D1AB8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D1AC0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D1AC4: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000D1AC8: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000D1ACC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D1AD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D1ADC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D1AE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1280>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D1AE4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D1AE8: BF89FC07
	s_barrier                                                  // 0000000D1AEC: BFBD0000
	buffer_gl0_inv                                             // 0000000D1AF0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v46 offset0:16 offset1:33      // 0000000D1AF8: D8DC2110 1D00002E
	ds_load_2addr_b32 v[31:32], v46 offset0:50 offset1:67      // 0000000D1B00: D8DC4332 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:84 offset1:101     // 0000000D1B08: D8DC6554 2100002E
	ds_load_2addr_b32 v[49:50], v46 offset0:118 offset1:135    // 0000000D1B10: D8DC8776 3100002E
	v_mov_b32_e32 v51, v0                                      // 0000000D1B18: 7E660300
	s_mov_b32 s4, 0                                            // 0000000D1B1C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000D1B20: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000D1B24: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000D1B2C: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000D1B34: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000D1B38: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000D1B40: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000D1B48: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000D1B4C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000D1B54: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000D1B5C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000D1B60: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000D1B68: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1B70: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1B78: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1B80: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1B88: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1B90: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1B98: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1BA0: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1BA8: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000D1BB0: 326C6684
	.long 0xd4490001                                           // 0000000D1BB4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000D1BB8: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D1BC0: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000D1BC4: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000D1BC8: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D1BD4: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000D1BD8: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000D1BE0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000D1BE8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000D1BF0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000D1BF8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000D1C00: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000D1C08: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000D1C10: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000D1C18: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000D1C1C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000D1C24: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000D1C28: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000D1C30: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000D1C38: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000D1C40: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000D1C44: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1C4C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1C54: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000D1C5C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1C64: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1C6C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1C74: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000D1C7C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D1C80: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000D1C84: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000D1C88: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000D1C8C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000D1C94: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000D1C98: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000D1C9C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000D1CA0: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1CA8: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000D1CB0: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000D1CB8: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D1CBC: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1CC0: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1CC8: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D1CD0: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000D1CD4: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000D1CD8: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000D1CDC: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D1CE4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000D1CE8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000D1CF0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D1CF8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000D1CFC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13b0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D1D00: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v31, v38         // 0000000D1D04: CA100114 1E1E0126
	v_dual_mov_b32 v29, v19 :: v_dual_mov_b32 v32, 0           // 0000000D1D0C: CA100113 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000D1D14: 7E420324
	s_mov_b32 s10, 0                                           // 0000000D1D18: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D1D1C: BF89FC07
	s_barrier                                                  // 0000000D1D20: BFBD0000
	buffer_gl0_inv                                             // 0000000D1D24: E0AC0000 00000000
	s_nop 0                                                    // 0000000D1D2C: BF800000
	s_nop 0                                                    // 0000000D1D30: BF800000
	s_nop 0                                                    // 0000000D1D34: BF800000
	s_nop 0                                                    // 0000000D1D38: BF800000
	s_nop 0                                                    // 0000000D1D3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D1D40: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17280                          // 0000000D1D48: D8D84380 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D1D50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D1D58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D1D5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D1D64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D1D68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D1D70: BF870004
	.long 0xd4490004                                           // 0000000D1D74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D1D78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D1D80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D1D84: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000D1D88: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000D1D8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D1D94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D1D9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D1DA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1540>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D1DA4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D1DA8: BF89FC07
	s_barrier                                                  // 0000000D1DAC: BFBD0000
	buffer_gl0_inv                                             // 0000000D1DB0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v46 offset0:152 offset1:169    // 0000000D1DB8: D8DCA998 1D00002E
	ds_load_2addr_b32 v[31:32], v46 offset0:186 offset1:203    // 0000000D1DC0: D8DCCBBA 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:220 offset1:237    // 0000000D1DC8: D8DCEDDC 2100002E
	ds_load_2addr_b32 v[49:50], v47 offset0:126 offset1:143    // 0000000D1DD0: D8DC8F7E 3100002F
	v_mov_b32_e32 v51, v0                                      // 0000000D1DD8: 7E660300
	s_mov_b32 s4, 0                                            // 0000000D1DDC: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000D1DE0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000D1DE4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000D1DEC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000D1DF4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000D1DF8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000D1E00: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000D1E08: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000D1E0C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000D1E14: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000D1E1C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000D1E20: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000D1E28: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1E30: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1E38: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1E40: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1E48: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1E50: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1E58: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1E60: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1E68: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000D1E70: 326C6684
	.long 0xd4490001                                           // 0000000D1E74: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000D1E78: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D1E80: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000D1E84: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000D1E88: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D1E94: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000D1E98: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000D1EA0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000D1EA8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000D1EB0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000D1EB8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000D1EC0: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000D1EC8: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000D1ED0: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000D1ED8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000D1EDC: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000D1EE4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000D1EE8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000D1EF0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000D1EF8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000D1F00: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000D1F04: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1F0C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1F14: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000D1F1C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1F24: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1F2C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1F34: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000D1F3C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D1F40: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000D1F44: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000D1F48: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000D1F4C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000D1F54: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000D1F58: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000D1F5C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000D1F60: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1F68: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000D1F70: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000D1F78: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D1F7C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1F80: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D1F88: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D1F90: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000D1F94: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000D1F98: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000D1F9C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D1FA4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000D1FA8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000D1FB0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D1FB8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000D1FBC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1670>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D1FC0: 8C7E047E
	v_mov_b32_e32 v30, v22                                     // 0000000D1FC4: 7E3C0316
	v_mov_b32_e32 v31, v38                                     // 0000000D1FC8: 7E3E0326
	v_dual_mov_b32 v29, v21 :: v_dual_mov_b32 v32, 0           // 0000000D1FCC: CA100115 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000D1FD4: 7E420324
	s_mov_b32 s10, 0                                           // 0000000D1FD8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D1FDC: BF89FC07
	s_barrier                                                  // 0000000D1FE0: BFBD0000
	buffer_gl0_inv                                             // 0000000D1FE4: E0AC0000 00000000
	s_nop 0                                                    // 0000000D1FEC: BF800000
	s_nop 0                                                    // 0000000D1FF0: BF800000
	s_nop 0                                                    // 0000000D1FF4: BF800000
	s_nop 0                                                    // 0000000D1FF8: BF800000
	s_nop 0                                                    // 0000000D1FFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D2000: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17312                          // 0000000D2008: D8D843A0 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D2010: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D2018: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D201C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D2024: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D2028: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D2030: BF870004
	.long 0xd4490004                                           // 0000000D2034: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D2038: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D2040: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D2044: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000D2048: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000D204C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D2054: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D205C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D2060: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1800>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D2064: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D2068: BF89FC07
	s_barrier                                                  // 0000000D206C: BFBD0000
	buffer_gl0_inv                                             // 0000000D2070: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v48 offset0:32 offset1:49      // 0000000D2078: D8DC3120 1D000030
	ds_load_2addr_b32 v[31:32], v48 offset0:66 offset1:83      // 0000000D2080: D8DC5342 1F000030
	ds_load_2addr_b32 v[33:34], v48 offset0:100 offset1:117    // 0000000D2088: D8DC7564 21000030
	ds_load_2addr_b32 v[49:50], v48 offset0:134 offset1:151    // 0000000D2090: D8DC9786 31000030
	v_mov_b32_e32 v51, v0                                      // 0000000D2098: 7E660300
	s_mov_b32 s4, 0                                            // 0000000D209C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000D20A0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000D20A4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000D20AC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000D20B4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000D20B8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000D20C0: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000D20C8: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000D20CC: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000D20D4: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000D20DC: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000D20E0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000D20E8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D20F0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D20F8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2100: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2108: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2110: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2118: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2120: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2128: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000D2130: 326C6684
	.long 0xd4490001                                           // 0000000D2134: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000D2138: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D2140: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000D2144: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000D2148: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D2154: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000D2158: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000D2160: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000D2168: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000D2170: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000D2178: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000D2180: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000D2188: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000D2190: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000D2198: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000D219C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000D21A4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000D21A8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000D21B0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000D21B8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000D21C0: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000D21C4: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D21CC: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D21D4: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000D21DC: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D21E4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D21EC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D21F4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000D21FC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D2200: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000D2204: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000D2208: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000D220C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000D2214: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000D2218: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000D221C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000D2220: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2228: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000D2230: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000D2238: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D223C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2240: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2248: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D2250: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000D2254: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000D2258: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000D225C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D2264: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000D2268: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000D2270: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D2278: 917E047E
	s_cbranch_execnz 65452                                     // 0000000D227C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1930>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D2280: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v31, v38         // 0000000D2284: CA100118 1E1E0126
	v_dual_mov_b32 v29, v23 :: v_dual_mov_b32 v32, 0           // 0000000D228C: CA100117 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000D2294: 7E420324
	s_mov_b32 s10, 0                                           // 0000000D2298: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D229C: BF89FC07
	s_barrier                                                  // 0000000D22A0: BFBD0000
	buffer_gl0_inv                                             // 0000000D22A4: E0AC0000 00000000
	s_nop 0                                                    // 0000000D22AC: BF800000
	s_nop 0                                                    // 0000000D22B0: BF800000
	s_nop 0                                                    // 0000000D22B4: BF800000
	s_nop 0                                                    // 0000000D22B8: BF800000
	s_nop 0                                                    // 0000000D22BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D22C0: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17344                          // 0000000D22C8: D8D843C0 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D22D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D22D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D22DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D22E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D22E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D22F0: BF870004
	.long 0xd4490004                                           // 0000000D22F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D22F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D2300: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D2304: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000D2308: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000D230C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D2314: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D231C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D2320: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ac0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D2324: 8C7E0A7E
	v_add_nc_u32_e32 v31, 0xc00, v45                           // 0000000D2328: 4A3E5AFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000D2330: BF89FC07
	s_barrier                                                  // 0000000D2334: BFBD0000
	buffer_gl0_inv                                             // 0000000D2338: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v48 offset0:168 offset1:185    // 0000000D2340: D8DCB9A8 1D000030
	ds_load_2addr_b32 v[32:33], v48 offset0:202 offset1:219    // 0000000D2348: D8DCDBCA 20000030
	ds_load_2addr_b32 v[49:50], v48 offset0:236 offset1:253    // 0000000D2350: D8DCFDEC 31000030
	ds_load_2addr_b32 v[51:52], v31 offset0:14 offset1:31      // 0000000D2358: D8DC1F0E 3300001F
	s_mov_b32 s4, 0                                            // 0000000D2360: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000D2364: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000D2368: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000D2370: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000D2378: BF89FC27
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000D237C: CC210020 02000D20
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000D2384: CC210021 02000D21
	s_waitcnt lgkmcnt(1)                                       // 0000000D238C: BF89FC17
	v_fma_mixlo_f16 v34, v49, s6, 0                            // 0000000D2390: CC210022 02000D31
	v_fma_mixlo_f16 v49, v50, s6, 0                            // 0000000D2398: CC210031 02000D32
	s_waitcnt lgkmcnt(0)                                       // 0000000D23A0: BF89FC07
	v_fma_mixlo_f16 v50, v51, s6, 0                            // 0000000D23A4: CC210032 02000D33
	v_fma_mixlo_f16 v51, v52, s6, 0                            // 0000000D23AC: CC210033 02000D34
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D23B4: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D23BC: CC20001E 8A000F1E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D23C4: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D23CC: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D23D4: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D23DC: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D23E4: CC200032 8A000F32
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D23EC: CC200033 8A000F33
	v_mov_b32_e32 v52, v0                                      // 0000000D23F4: 7E680300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D23F8: BF870121
	v_lshrrev_b32_e32 v55, 4, v52                              // 0000000D23FC: 326E6884
	.long 0xd4490001                                           // 0000000D2400: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v52, vcc_lo                   // 0000000D2404: 020268FF 0000077F
	v_lshlrev_b32_e32 v60, 2, v55                              // 0000000D240C: 30786E82
	v_mad_u64_u32 v[55:56], null, 0x44, v55, v[1:2]            // 0000000D2410: D6FE7C37 04066EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D241C: 8C040401
	v_add_nc_u32_e32 v53, 0x3200, v60                          // 0000000D2420: 4A6A78FF 00003200
	v_add_nc_u32_e32 v56, 0x3600, v60                          // 0000000D2428: 4A7078FF 00003600
	v_add_nc_u32_e32 v58, 0x3a00, v60                          // 0000000D2430: 4A7478FF 00003A00
	v_add_nc_u32_e32 v60, 0x3e00, v60                          // 0000000D2438: 4A7878FF 00003E00
	ds_load_b32 v61, v55                                       // 0000000D2440: D8D80000 3D000037
	ds_load_2addr_b32 v[56:57], v56 offset0:66 offset1:195     // 0000000D2448: D8DCC342 38000038
	ds_load_2addr_b32 v[53:54], v53 offset0:64 offset1:193     // 0000000D2450: D8DCC140 35000035
	ds_load_2addr_b32 v[58:59], v58 offset0:68 offset1:197     // 0000000D2458: D8DCC544 3A00003A
	s_waitcnt lgkmcnt(2)                                       // 0000000D2460: BF89FC27
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000D2464: CC210038 02000D38
	s_waitcnt lgkmcnt(1)                                       // 0000000D246C: BF89FC17
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000D2470: CC210035 02000D35
	v_fma_mixlo_f16 v62, v54, s6, 0                            // 0000000D2478: CC21003E 02000D36
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000D2480: CC210039 02000D39
	s_waitcnt lgkmcnt(0)                                       // 0000000D2488: BF89FC07
	v_fma_mixlo_f16 v58, v58, s6, 0                            // 0000000D248C: CC21003A 02000D3A
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2494: CC200038 8A000F38
	v_fma_mix_f32 v63, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D249C: CC20003F 8A000F35
	ds_load_2addr_b32 v[53:54], v60 offset0:70 offset1:199     // 0000000D24A4: D8DCC746 3500003C
	v_fma_mix_f32 v60, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D24AC: CC20003C 8A000F3E
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D24B4: CC200039 8A000F39
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D24BC: CC20003A 8A000F3A
	v_fmac_f32_e32 v61, v63, v29                               // 0000000D24C4: 567A3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D24C8: BF870091
	v_fmac_f32_e32 v61, v60, v30                               // 0000000D24CC: 567A3D3C
	v_fmac_f32_e32 v61, v56, v32                               // 0000000D24D0: 567A4138
	v_fma_mixlo_f16 v56, v59, s6, 0                            // 0000000D24D4: CC210038 02000D3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000D24DC: BF8701B2
	v_fmac_f32_e32 v61, v57, v33                               // 0000000D24E0: 567A4339
	s_waitcnt lgkmcnt(0)                                       // 0000000D24E4: BF89FC07
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000D24E8: CC210035 02000D35
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D24F0: CC200038 8A000F38
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000D24F8: CC210036 02000D36
	v_fmac_f32_e32 v61, v58, v34                               // 0000000D2500: 567A453A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D2504: BF870194
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2508: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2510: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D2518: BF870093
	v_fmac_f32_e32 v61, v56, v49                               // 0000000D251C: 567A6338
	v_fmac_f32_e32 v61, v53, v50                               // 0000000D2520: 567A6535
	v_add_nc_u32_e32 v53, 0x80, v52                            // 0000000D2524: 4A6A68FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D252C: BF870001
	v_dual_fmac_f32 v61, v54, v51 :: v_dual_mov_b32 v52, v53   // 0000000D2530: C8106736 3D340135
	ds_store_b32 v55, v61                                      // 0000000D2538: D8340000 00003D37
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D2540: 917E047E
	s_cbranch_execnz 65452                                     // 0000000D2544: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1bf8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D2548: 8C7E047E
	v_mov_b32_e32 v30, v26                                     // 0000000D254C: 7E3C031A
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v29, v25         // 0000000D2550: CA100126 201C0119
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 0000000D2558: CA100080 21220124
	s_mov_b32 s10, 0                                           // 0000000D2560: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D2564: BF89FC07
	s_barrier                                                  // 0000000D2568: BFBD0000
	buffer_gl0_inv                                             // 0000000D256C: E0AC0000 00000000
	s_nop 0                                                    // 0000000D2574: BF800000
	s_nop 0                                                    // 0000000D2578: BF800000
	s_nop 0                                                    // 0000000D257C: BF800000
	global_load_b32 v49, v[29:30], off                         // 0000000D2580: DC520000 317C001D
	ds_load_b32 v50, v33 offset:17376                          // 0000000D2588: D8D843E0 32000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000D2590: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000D2598: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D259C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000D25A4: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D25A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D25B0: BF870004
	.long 0xd4490004                                           // 0000000D25B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000D25B8: 020244FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D25C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D25C4: BF890007
	v_mul_f32_e32 v49, v49, v50                                // 0000000D25C8: 10626531
	ds_store_b32 v32, v49 offset:13056                         // 0000000D25CC: D8343300 00003120
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000D25D4: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D25DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D25E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D25E4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D25E8: BF89FC07
	s_barrier                                                  // 0000000D25EC: BFBD0000
	buffer_gl0_inv                                             // 0000000D25F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:48 offset1:65      // 0000000D25F8: D8DC4130 1D00001F
	ds_load_2addr_b32 v[32:33], v31 offset0:82 offset1:99      // 0000000D2600: D8DC6352 2000001F
	ds_load_2addr_b32 v[49:50], v31 offset0:116 offset1:133    // 0000000D2608: D8DC8574 3100001F
	ds_load_2addr_b32 v[51:52], v31 offset0:150 offset1:167    // 0000000D2610: D8DCA796 3300001F
	s_mov_b32 s4, 0                                            // 0000000D2618: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000D261C: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000D2620: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000D2628: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000D2630: BF89FC27
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000D2634: CC210020 02000D20
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000D263C: CC210021 02000D21
	s_waitcnt lgkmcnt(1)                                       // 0000000D2644: BF89FC17
	v_fma_mixlo_f16 v34, v49, s6, 0                            // 0000000D2648: CC210022 02000D31
	v_fma_mixlo_f16 v49, v50, s6, 0                            // 0000000D2650: CC210031 02000D32
	s_waitcnt lgkmcnt(0)                                       // 0000000D2658: BF89FC07
	v_fma_mixlo_f16 v50, v51, s6, 0                            // 0000000D265C: CC210032 02000D33
	v_fma_mixlo_f16 v51, v52, s6, 0                            // 0000000D2664: CC210033 02000D34
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D266C: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2674: CC20001E 8A000F1E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D267C: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2684: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D268C: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2694: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D269C: CC200032 8A000F32
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D26A4: CC200033 8A000F33
	v_mov_b32_e32 v52, v0                                      // 0000000D26AC: 7E680300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D26B0: BF870121
	v_lshrrev_b32_e32 v55, 4, v52                              // 0000000D26B4: 326E6884
	.long 0xd4490001                                           // 0000000D26B8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v52, vcc_lo                   // 0000000D26BC: 020268FF 0000077F
	v_lshlrev_b32_e32 v60, 2, v55                              // 0000000D26C4: 30786E82
	v_mad_u64_u32 v[55:56], null, 0x44, v55, v[1:2]            // 0000000D26C8: D6FE7C37 04066EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D26D4: 8C040401
	v_add_nc_u32_e32 v53, 0x3200, v60                          // 0000000D26D8: 4A6A78FF 00003200
	v_add_nc_u32_e32 v56, 0x3600, v60                          // 0000000D26E0: 4A7078FF 00003600
	v_add_nc_u32_e32 v58, 0x3a00, v60                          // 0000000D26E8: 4A7478FF 00003A00
	v_add_nc_u32_e32 v60, 0x3e00, v60                          // 0000000D26F0: 4A7878FF 00003E00
	ds_load_b32 v61, v55                                       // 0000000D26F8: D8D80000 3D000037
	ds_load_2addr_b32 v[56:57], v56 offset0:66 offset1:195     // 0000000D2700: D8DCC342 38000038
	ds_load_2addr_b32 v[53:54], v53 offset0:64 offset1:193     // 0000000D2708: D8DCC140 35000035
	ds_load_2addr_b32 v[58:59], v58 offset0:68 offset1:197     // 0000000D2710: D8DCC544 3A00003A
	s_waitcnt lgkmcnt(2)                                       // 0000000D2718: BF89FC27
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000D271C: CC210038 02000D38
	s_waitcnt lgkmcnt(1)                                       // 0000000D2724: BF89FC17
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000D2728: CC210035 02000D35
	v_fma_mixlo_f16 v62, v54, s6, 0                            // 0000000D2730: CC21003E 02000D36
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000D2738: CC210039 02000D39
	s_waitcnt lgkmcnt(0)                                       // 0000000D2740: BF89FC07
	v_fma_mixlo_f16 v58, v58, s6, 0                            // 0000000D2744: CC21003A 02000D3A
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D274C: CC200038 8A000F38
	v_fma_mix_f32 v63, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2754: CC20003F 8A000F35
	ds_load_2addr_b32 v[53:54], v60 offset0:70 offset1:199     // 0000000D275C: D8DCC746 3500003C
	v_fma_mix_f32 v60, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2764: CC20003C 8A000F3E
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D276C: CC200039 8A000F39
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2774: CC20003A 8A000F3A
	v_fmac_f32_e32 v61, v63, v29                               // 0000000D277C: 567A3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D2780: BF870091
	v_fmac_f32_e32 v61, v60, v30                               // 0000000D2784: 567A3D3C
	v_fmac_f32_e32 v61, v56, v32                               // 0000000D2788: 567A4138
	v_fma_mixlo_f16 v56, v59, s6, 0                            // 0000000D278C: CC210038 02000D3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000D2794: BF8701B2
	v_fmac_f32_e32 v61, v57, v33                               // 0000000D2798: 567A4339
	s_waitcnt lgkmcnt(0)                                       // 0000000D279C: BF89FC07
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000D27A0: CC210035 02000D35
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D27A8: CC200038 8A000F38
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000D27B0: CC210036 02000D36
	v_fmac_f32_e32 v61, v58, v34                               // 0000000D27B8: 567A453A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D27BC: BF870194
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D27C0: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D27C8: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D27D0: BF870093
	v_fmac_f32_e32 v61, v56, v49                               // 0000000D27D4: 567A6338
	v_fmac_f32_e32 v61, v53, v50                               // 0000000D27D8: 567A6535
	v_add_nc_u32_e32 v53, 0x80, v52                            // 0000000D27DC: 4A6A68FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D27E4: BF870001
	v_dual_fmac_f32 v61, v54, v51 :: v_dual_mov_b32 v52, v53   // 0000000D27E8: C8106736 3D340135
	ds_store_b32 v55, v61                                      // 0000000D27F0: D8340000 00003D37
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D27F8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000D27FC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1eb0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D2800: 8C7E047E
	v_mov_b32_e32 v30, v28                                     // 0000000D2804: 7E3C031C
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v29, v27         // 0000000D2808: CA100126 201C011B
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 0000000D2810: CA100080 21220124
	s_mov_b32 s10, 0                                           // 0000000D2818: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D281C: BF89FC07
	s_barrier                                                  // 0000000D2820: BFBD0000
	buffer_gl0_inv                                             // 0000000D2824: E0AC0000 00000000
	s_nop 0                                                    // 0000000D282C: BF800000
	s_nop 0                                                    // 0000000D2830: BF800000
	s_nop 0                                                    // 0000000D2834: BF800000
	s_nop 0                                                    // 0000000D2838: BF800000
	s_nop 0                                                    // 0000000D283C: BF800000
	global_load_b32 v49, v[29:30], off                         // 0000000D2840: DC520000 317C001D
	ds_load_b32 v50, v33 offset:17408                          // 0000000D2848: D8D84400 32000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000D2850: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000D2858: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D285C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000D2864: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D2868: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D2870: BF870004
	.long 0xd4490004                                           // 0000000D2874: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000D2878: 020244FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D2880: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D2884: BF890007
	v_mul_f32_e32 v49, v49, v50                                // 0000000D2888: 10626531
	ds_store_b32 v32, v49 offset:13056                         // 0000000D288C: D8343300 00003120
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000D2894: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D289C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D28A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D28A4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v45                           // 0000000D28A8: 4A425AFF 00000E00
	v_add_nc_u32_e32 v49, 0x1000, v45                          // 0000000D28B0: 4A625AFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000D28B8: BF89FC07
	s_barrier                                                  // 0000000D28BC: BFBD0000
	buffer_gl0_inv                                             // 0000000D28C0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:184 offset1:201    // 0000000D28C8: D8DCC9B8 1D00001F
	ds_load_2addr_b32 v[31:32], v31 offset0:218 offset1:235    // 0000000D28D0: D8DCEBDA 1F00001F
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000D28D8: D8DC8D7C 21000021
	ds_load_2addr_b32 v[49:50], v49 offset0:30 offset1:47      // 0000000D28E0: D8DC2F1E 31000031
	v_mov_b32_e32 v51, v0                                      // 0000000D28E8: 7E660300
	s_mov_b32 s4, 0                                            // 0000000D28EC: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000D28F0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000D28F4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000D28FC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000D2904: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000D2908: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000D2910: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000D2918: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000D291C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000D2924: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000D292C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000D2930: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000D2938: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2940: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2948: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2950: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2958: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2960: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2968: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2970: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2978: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000D2980: 326C6684
	.long 0xd4490001                                           // 0000000D2984: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000D2988: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D2990: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000D2994: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000D2998: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D29A4: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000D29A8: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000D29B0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000D29B8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000D29C0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000D29C8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000D29D0: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000D29D8: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000D29E0: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000D29E8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000D29EC: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000D29F4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000D29F8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000D2A00: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000D2A08: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000D2A10: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000D2A14: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2A1C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2A24: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000D2A2C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2A34: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2A3C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2A44: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000D2A4C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D2A50: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000D2A54: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000D2A58: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000D2A5C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000D2A64: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000D2A68: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000D2A6C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000D2A70: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2A78: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000D2A80: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000D2A88: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D2A8C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2A90: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D2A98: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D2AA0: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000D2AA4: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000D2AA8: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000D2AAC: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D2AB4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000D2AB8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000D2AC0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D2AC8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000D2ACC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D2AD0: 8C7E047E
	.long 0xd7000107                                           // 0000000D2AD4: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000D2AD8: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D2AE0: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000D2AE4: D5207C08 00061080
	.long 0xd7000109                                           // 0000000D2AEC: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000D2AF0: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000D2AF8: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000D2B00: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000D2B04: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D2B0C: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000D2B10: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000D2B18: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000D2B1C: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000D2B24: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000D2B2C: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000D2B30: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D2B38: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000D2B3C: D5207C10 00062080
	.long 0xd7000111                                           // 0000000D2B44: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000D2B48: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000D2B50: D5207C12 00062480
	.long 0xd7000113                                           // 0000000D2B58: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000D2B5C: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D2B64: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000D2B68: D5207C14 00062880
	.long 0xd7000115                                           // 0000000D2B70: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000D2B74: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000D2B7C: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000D2B84: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000D2B88: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D2B90: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000D2B94: D5207C18 00063080
	.long 0xd7000119                                           // 0000000D2B9C: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000D2BA0: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000D2BA8: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000D2BB0: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000D2BB4: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D2BBC: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000D2BC0: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000D2BC8: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000D2BCC: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000D2BD0: BF062105
	s_barrier                                                  // 0000000D2BD4: BFBD0000
	buffer_gl0_inv                                             // 0000000D2BD8: E0AC0000 00000000
	s_cbranch_scc0 63457                                       // 0000000D2BE0: BFA1F7E1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x368>
	v_mov_b32_e32 v4, v36                                      // 0000000D2BE4: 7E080324
	s_add_u32 s0, s28, s20                                     // 0000000D2BE8: 8000141C
	.long 0xd73c0000                                           // 0000000D2BEC: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000D2BF0: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000D2BF4: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000D2BF8: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000D2BFC: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000D2C00: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000D2C04: 82010103
	.long 0xd7006a00                                           // 0000000D2C08: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000D2C0C: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000D2C10: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000D2C14: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000D2C1C: BE810080
	.long 0xd7006a00                                           // 0000000D2C20: D7006A00
	v_cndmask_b32_e32 v1, v0, v37, vcc_lo                      // 0000000D2C24: 02024B00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000D2C28: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D2C30: BF870092
	.long 0xd7006a00                                           // 0000000D2C34: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000D2C38: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000D2C3C: D5207C01 01AA0211
	s_nop 0                                                    // 0000000D2C44: BF800000
	s_nop 0                                                    // 0000000D2C48: BF800000
	s_nop 0                                                    // 0000000D2C4C: BF800000
	s_nop 0                                                    // 0000000D2C50: BF800000
	s_nop 0                                                    // 0000000D2C54: BF800000
	s_nop 0                                                    // 0000000D2C58: BF800000
	s_nop 0                                                    // 0000000D2C5C: BF800000
	s_nop 0                                                    // 0000000D2C60: BF800000
	s_nop 0                                                    // 0000000D2C64: BF800000
	s_nop 0                                                    // 0000000D2C68: BF800000
	s_nop 0                                                    // 0000000D2C6C: BF800000
	s_nop 0                                                    // 0000000D2C70: BF800000
	s_nop 0                                                    // 0000000D2C74: BF800000
	s_nop 0                                                    // 0000000D2C78: BF800000
	s_nop 0                                                    // 0000000D2C7C: BF800000
	ds_load_b32 v2, v35                                        // 0000000D2C80: D8D80000 02000023
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000D2C88: 4A0808FF 00000080
	v_add_nc_u32_e32 v35, 0x220, v35                           // 0000000D2C90: 4A4646FF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000D2C98: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000D2C9C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000D2CA4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000D2CA8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000D2CAC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000D2CB4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000D2CB8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000D2CC0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000D2CC8: 917E017E
	s_cbranch_execnz 65516                                     // 0000000D2CCC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2480>
	s_endpgm                                                   // 0000000D2CD0: BFB00000
		...

