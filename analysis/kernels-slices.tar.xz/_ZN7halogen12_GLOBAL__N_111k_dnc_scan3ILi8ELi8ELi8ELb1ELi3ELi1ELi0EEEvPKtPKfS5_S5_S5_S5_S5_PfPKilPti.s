0000000000085800 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000085800: BF850001
	s_load_b512 s[8:23], s[0:1], 0x8                           // 000000085804: F4100200 F8000008
	s_load_b128 s[4:7], s[0:1], 0x48                           // 00000008580C: F4080100 F8000048
	s_lshl_b32 s28, s3, 4                                      // 000000085814: 841C8403
	s_ashr_i32 s3, s2, 31                                      // 000000085818: 86039F02
	s_ashr_i32 s29, s28, 31                                    // 00000008581C: 861D9F1C
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 000000085820: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000085828: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000008582C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 000000085830: BF89FC07
	s_load_b32 s26, s[22:23], null                             // 000000085834: F400068B F8000000
	s_lshl_b64 s[22:23], s[4:5], 2                             // 00000008583C: 84968204
	s_add_u32 s4, s20, s22                                     // 000000085840: 80041614
	s_addc_u32 s5, s21, s23                                    // 000000085844: 82051715
	s_lshl_b64 s[24:25], s[2:3], 16                            // 000000085848: 84989002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000008584C: BF870009
	s_add_u32 s4, s4, s24                                      // 000000085850: 80041804
	s_addc_u32 s5, s5, s25                                     // 000000085854: 82051905
	s_waitcnt lgkmcnt(0)                                       // 000000085858: BF89FC07
	s_mul_i32 s30, s26, 0x9000000                              // 00000008585C: 961EFF1A 09000000
	s_mul_hi_i32 s31, s26, 0x9000000                           // 000000085864: 971FFF1A 09000000
	s_add_u32 s4, s4, s30                                      // 00000008586C: 80041E04
	s_addc_u32 s5, s5, s31                                     // 000000085870: 82051F05
	s_lshl_b64 s[26:27], s[28:29], 2                           // 000000085874: 849A821C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000085878: BF8700B9
	s_add_u32 s4, s4, s26                                      // 00000008587C: 80041A04
	s_addc_u32 s5, s5, s27                                     // 000000085880: 82051B05
	.long 0xd7000402                                           // 000000085884: D7000402
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000085888: 02020204
	v_add_co_ci_u32_e64 v3, null, s5, 0, s4                    // 00000008588C: D5207C03 00110005
	s_mov_b32 s4, 0                                            // 000000085894: BE840080
	s_nop 0                                                    // 000000085898: BF800000
	s_nop 0                                                    // 00000008589C: BF800000
	s_nop 0                                                    // 0000000858A0: BF800000
	s_nop 0                                                    // 0000000858A4: BF800000
	s_nop 0                                                    // 0000000858A8: BF800000
	s_nop 0                                                    // 0000000858AC: BF800000
	s_nop 0                                                    // 0000000858B0: BF800000
	s_nop 0                                                    // 0000000858B4: BF800000
	s_nop 0                                                    // 0000000858B8: BF800000
	s_nop 0                                                    // 0000000858BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000858C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000858C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000858CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000858D0: 300C1089
	.long 0xd7006a06                                           // 0000000858D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000858D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000858DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000858E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000858E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000858F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000858F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000858FC: D6FE7C06 040610FF 00000044
	s_or_b32 s4, vcc_lo, s4                                    // 000000085908: 8C04046A
	s_waitcnt vmcnt(0)                                         // 00000008590C: BF8903F7
	ds_store_b32 v6, v9                                        // 000000085910: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000085918: 917E047E
	s_cbranch_execnz 65512                                     // 00000008591C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000085920: 8C7E047E
	s_load_b32 s33, s[0:1], 0x58                               // 000000085924: F4000840 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 00000008592C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 000000085934: 32040084
	s_mov_b32 s0, 0                                            // 000000085938: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000008593C: BF89FC07
	s_barrier                                                  // 000000085940: BFBD0000
	buffer_gl0_inv                                             // 000000085944: E0AC0000 00000000
	s_cmp_gt_i32 s33, 0                                        // 00000008594C: BF028021
	s_cbranch_scc1 12                                          // 000000085950: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 000000085954: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000008595C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000085964: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 000000085968: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 000000085970: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 000000085974: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000085978: 916A007E
	s_cbranch_vccz 2                                           // 00000008597C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2200                                              // 000000085980: BFA00898 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23e4>
	v_lshlrev_b32_e32 v39, 2, v5                               // 000000085984: 304E0A82
	s_add_i32 s0, s33, 63                                      // 000000085988: 8100BF21
	s_add_i32 s34, s2, 0xbd0                                   // 00000008598C: 8122FF02 00000BD0
	s_lshr_b32 s35, s0, 6                                      // 000000085994: 85238600
	s_add_u32 s14, s14, s26                                    // 000000085998: 800E1A0E
	s_addc_u32 s15, s15, s27                                   // 00000008599C: 820F1B0F
	s_lshl_b32 s0, s2, 7                                       // 0000000859A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000000859A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000000859AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000859B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000859B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000859B8: 301A0488
	s_add_u32 s6, s6, s0                                       // 0000000859BC: 80060006
	s_addc_u32 s1, s7, s1                                      // 0000000859C0: 82010107
	s_lshl_b64 s[4:5], s[28:29], 1                             // 0000000859C4: 8484811C
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000000859C8: D60B0025 049E04FF 00000044
	s_add_u32 s6, s6, s4                                       // 0000000859D4: 80060406
	s_addc_u32 s1, s1, s5                                      // 0000000859D8: 82010501
	s_movk_i32 s4, 0x204                                       // 0000000859DC: B0040204
	.long 0xd700052c                                           // 0000000859E0: D700052C
	v_cndmask_b32_e32 v1, s14, v39, vcc_lo                     // 0000000859E4: 02024E0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000859E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s15, 0, s5                  // 0000000859EC: D5207C2D 0015000F
	v_mad_u32_u24 v46, v2, s4, 0x3300                          // 0000000859F4: D60B002E 03FC0902 00003300
	s_lshl_b64 s[4:5], s[2:3], 9                               // 000000085A00: 84848902
	v_dual_mov_b32 v12, s5 :: v_dual_add_nc_u32 v41, 0x4320, v40// 000000085A04: CA200005 0C2850FF 00004320
	v_or_b32_e32 v11, s4, v40                                  // 000000085A10: 38165004
	.long 0xd7000405                                           // 000000085A14: D7000405
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000085A18: 02020A06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000085A1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s4                    // 000000085A20: D5207C06 00110001
	.long 0xd7000107                                           // 000000085A28: D7000107
	v_cndmask_b32_e32 v1, s16, v11, vcc_lo                     // 000000085A2C: 02021610
	s_delay_alu instid0(VALU_DEP_1)                            // 000000085A30: BF870001
	v_add_co_ci_u32_e64 v8, null, s17, v12, s1                 // 000000085A34: D5207C08 00061811
	.long 0xd7000109                                           // 000000085A3C: D7000109
	v_cndmask_b32_e32 v1, s8, v11, vcc_lo                      // 000000085A40: 02021608
	s_lshl_b64 s[4:5], s[2:3], 14                              // 000000085A44: 84848E02
	v_add_co_ci_u32_e64 v10, null, s9, v12, s1                 // 000000085A48: D5207C0A 00061809
	.long 0xd700010b                                           // 000000085A50: D700010B
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 000000085A54: 0202160A
	s_add_u32 s4, s18, s4                                      // 000000085A58: 80040412
	v_add_co_ci_u32_e64 v12, null, s11, v12, s1                // 000000085A5C: D5207C0C 0006180B
	s_addc_u32 s5, s19, s5                                     // 000000085A64: 82050513
	.long 0xd700010d                                           // 000000085A68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 000000085A6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000085A70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 000000085A74: D5207C0E 00050005
	.long 0xd700010f                                           // 000000085A7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 000000085A80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 000000085A88: D5207C10 00061880
	.long 0xd7000111                                           // 000000085A90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 000000085A94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000085A9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 000000085AA0: D5207C12 00061880
	.long 0xd7000113                                           // 000000085AA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 000000085AAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 000000085AB4: D5207C14 00061880
	.long 0xd7000115                                           // 000000085ABC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 000000085AC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000085AC8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 000000085ACC: D5207C16 00061880
	.long 0xd7000117                                           // 000000085AD4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 000000085AD8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 000000085AE0: D5207C18 00061880
	.long 0xd7000119                                           // 000000085AE8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 000000085AEC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000085AF4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 000000085AF8: D5207C1A 00061880
	.long 0xd700011b                                           // 000000085B00: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 000000085B04: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 000000085B0C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 000000085B14: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000085B18: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 000000085B20: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 000000085B24: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 000000085B2C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 000000085B34: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 000000085B3C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 000000085B44: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 000000085B4C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 000000085B54: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 000000085B5C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 000000085B64: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 000000085B6C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 000000085B74: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 000000085B7C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 000000085B84: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 000000085B8C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 000000085B94: 4A7602FF 00002000
	s_mov_b32 s11, 0                                           // 000000085B9C: BE8B0080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 000000085BA0: 7C9800C0
	s_mul_i32 s1, s11, 0xc00                                   // 000000085BA4: 9601FF0B 00000C00
	s_lshl_b32 s15, s11, 6                                     // 000000085BAC: 840F860B
	s_add_i32 s4, s34, s1                                      // 000000085BB0: 81040122
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000085BB4: BF870499
	s_ashr_i32 s5, s4, 31                                      // 000000085BB8: 86059F04
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000085BBC: 84848204
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000085BC0: BF870009
	s_add_u32 s4, s12, s4                                      // 000000085BC4: 8004040C
	s_addc_u32 s5, s13, s5                                     // 000000085BC8: 8205050D
	s_load_b32 s14, s[4:5], null                               // 000000085BCC: F4000382 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 000000085BD4: BE84206A
	s_cbranch_execz 77                                         // 000000085BD8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s15, v0                                  // 000000085BDC: 383A000F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085BE0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 000000085BE4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 000000085BEC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085BF0: BF870091
	.long 0xd73c001d                                           // 000000085BF4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 000000085BF8: 02023A82
	.long 0xd700011d                                           // 000000085BFC: D700011D
	v_cndmask_b32_e32 v1, s12, v29, vcc_lo                     // 000000085C00: 02023A0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000085C04: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s13, v30, s1                // 000000085C08: D5207C1E 00063C0D
	global_load_b32 v29, v[29:30], off                         // 000000085C10: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000085C18: BF890007
	v_sub_f32_e32 v30, s14, v29                                // 000000085C1C: 083C3A0E
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 000000085C20: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000085C2C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 000000085C30: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 000000085C3C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 000000085C40: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 000000085C4C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000085C50: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 000000085C54: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 000000085C60: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000085C64: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 000000085C68: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 000000085C70: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 000000085C74: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 000000085C7C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 000000085C84: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 000000085C88: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000085C8C: BF870193
	v_exp_f32_e32 v32, v32                                     // 000000085C90: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 000000085C94: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000085C98: BF870296
	.long 0xd71c0020                                           // 000000085C9C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 000000085CA0: 02024520
	.long 0xd71c001f                                           // 000000085CA4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 000000085CA8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000085CAC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 000000085CB0: D501001F 00063E80
	.long 0xd41b0001                                           // 000000085CB8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 000000085CBC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 000000085CC4: D5010020 00064080
	.long 0xd41e0001                                           // 000000085CCC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 000000085CD0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000085CD8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 000000085CDC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 000000085CE8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 000000085CEC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 000000085CF4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 000000085D00: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 000000085D08: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 000000085D10: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 000000085D14: CA100108 1E1C0107
	s_mov_b32 s16, 0                                           // 000000085D1C: BE900080
	s_waitcnt lgkmcnt(0)                                       // 000000085D20: BF89FC07
	s_barrier                                                  // 000000085D24: BFBD0000
	buffer_gl0_inv                                             // 000000085D28: E0AC0000 00000000
	s_branch 15                                                // 000000085D30: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000085D34: 8C7E117E
	.long 0xd700011d                                           // 000000085D38: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 000000085D3C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000085D44: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000085D48: D5207C1E 00063C80
	s_add_i32 s1, s16, 8                                       // 000000085D50: 81018810
	s_cmp_gt_u32 s16, 55                                       // 000000085D54: BF08B710
	s_mov_b32 s16, s1                                          // 000000085D58: BE900001
	s_waitcnt lgkmcnt(0)                                       // 000000085D5C: BF89FC07
	s_barrier                                                  // 000000085D60: BFBD0000
	buffer_gl0_inv                                             // 000000085D64: E0AC0000 00000000
	s_cbranch_scc1 294                                         // 000000085D6C: BFA20126 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa08>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 000000085D70: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 000000085D78: CA100128 21220126
	s_mov_b32 s5, 0                                            // 000000085D80: BE850080
	s_nop 0                                                    // 000000085D84: BF800000
	s_nop 0                                                    // 000000085D88: BF800000
	s_nop 0                                                    // 000000085D8C: BF800000
	s_nop 0                                                    // 000000085D90: BF800000
	s_nop 0                                                    // 000000085D94: BF800000
	s_nop 0                                                    // 000000085D98: BF800000
	s_nop 0                                                    // 000000085D9C: BF800000
	s_nop 0                                                    // 000000085DA0: BF800000
	s_nop 0                                                    // 000000085DA4: BF800000
	s_nop 0                                                    // 000000085DA8: BF800000
	s_nop 0                                                    // 000000085DAC: BF800000
	s_nop 0                                                    // 000000085DB0: BF800000
	s_nop 0                                                    // 000000085DB4: BF800000
	s_nop 0                                                    // 000000085DB8: BF800000
	s_nop 0                                                    // 000000085DBC: BF800000
	global_load_b32 v35, v[31:32], off                         // 000000085DC0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 000000085DC8: 4A4444FF 00000080
	.long 0xd700011f                                           // 000000085DD0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 000000085DD4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000085DDC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 000000085DE0: D5207C20 00064080
	.long 0xd4490004                                           // 000000085DE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 000000085DEC: 020244FF 0000037F
	s_or_b32 s5, s4, s5                                        // 000000085DF4: 8C050504
	s_waitcnt vmcnt(0)                                         // 000000085DF8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 000000085DFC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 000000085E04: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000085E0C: 917E057E
	s_cbranch_execnz 65515                                     // 000000085E10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000085E14: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 000000085E18: BF89FC07
	s_barrier                                                  // 000000085E1C: BFBD0000
	buffer_gl0_inv                                             // 000000085E20: E0AC0000 00000000
	s_and_saveexec_b32 s17, s0                                 // 000000085E28: BE912000
	s_cbranch_execz 65473                                      // 000000085E2C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_or3_b32 v31, s16, s15, v2                                // 000000085E30: D658001F 04081E10
	s_mov_b32 s18, 0                                           // 000000085E38: BE920080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085E3C: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 000000085E40: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 000000085E48: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 000000085E4C: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085E50: BF870091
	.long 0xd700011f                                           // 000000085E54: D700011F
	v_cndmask_b32_e32 v1, v44, v31, vcc_lo                     // 000000085E58: 02023F2C
	v_add_co_ci_u32_e64 v32, null, v45, v32, s1                // 000000085E5C: D5207C20 0006412D
	global_load_b32 v31, v[31:32], off                         // 000000085E64: DC520000 1F7C001F
	v_mad_u64_u32 v[32:33], null, 0x44, s18, v[1:2]            // 000000085E6C: D6FE7C20 040424FF 00000044
	ds_load_2addr_b32 v[63:64], v32 offset1:17                 // 000000085E78: D8DC1100 3F000020
	ds_load_2addr_b32 v[65:66], v32 offset0:34 offset1:51      // 000000085E80: D8DC3322 41000020
	ds_load_2addr_b32 v[67:68], v32 offset0:68 offset1:85      // 000000085E88: D8DC5544 43000020
	ds_load_2addr_b32 v[69:70], v32 offset0:102 offset1:119    // 000000085E90: D8DC7766 45000020
	v_lshl_add_u32 v32, s18, 2, v46                            // 000000085E98: D6460020 04B90412
	ds_load_2addr_b32 v[71:72], v32 offset1:1                  // 000000085EA0: D8DC0100 47000020
	ds_load_2addr_b32 v[73:74], v32 offset0:2 offset1:3        // 000000085EA8: D8DC0302 49000020
	ds_load_2addr_b32 v[75:76], v32 offset0:4 offset1:5        // 000000085EB0: D8DC0504 4B000020
	ds_load_2addr_b32 v[77:78], v32 offset0:6 offset1:7        // 000000085EB8: D8DC0706 4D000020
	s_waitcnt lgkmcnt(7)                                       // 000000085EC0: BF89FC77
	v_cvt_f16_f32_e32 v32, v63                                 // 000000085EC4: 7E40153F
	.long 0xd4130201                                           // 000000085EC8: D4130201
	v_cndmask_b32_e32 v1, 0x38800006, v63, vcc_lo              // 000000085ECC: 02027EFF 38800006
	.long 0xd4160204                                           // 000000085ED4: D4160204
	v_cndmask_b32_e32 v1, 0x477fe000, v63, vcc_lo              // 000000085ED8: 02027EFF 477FE000
	.long 0xd4130205                                           // 000000085EE0: D4130205
	v_cndmask_b32_e32 v1, 0x38800006, v64, vcc_lo              // 000000085EE4: 020280FF 38800006
	.long 0xd4160206                                           // 000000085EEC: D4160206
	v_cndmask_b32_e32 v1, 0x477fe000, v64, vcc_lo              // 000000085EF0: 020280FF 477FE000
	s_waitcnt lgkmcnt(6)                                       // 000000085EF8: BF89FC67
	.long 0xd4130209                                           // 000000085EFC: D4130209
	v_cndmask_b32_e32 v1, 0x38800006, v66, vcc_lo              // 000000085F00: 020284FF 38800006
	.long 0xd416020a                                           // 000000085F08: D416020A
	v_cndmask_b32_e32 v1, 0x477fe000, v66, vcc_lo              // 000000085F0C: 020284FF 477FE000
	.long 0x7f401540                                           // 000000085F14: 7F401540
	v_cvt_f32_f16_e32 v79, v32                                 // 000000085F18: 7E9E1720
	s_waitcnt lgkmcnt(3)                                       // 000000085F1C: BF89FC37
	v_cvt_f16_f32_e32 v36, v71                                 // 000000085F20: 7E481547
	.long 0xd4130229                                           // 000000085F24: D4130229
	v_cndmask_b32_e32 v1, 0x38800006, v71, vcc_lo              // 000000085F28: 02028EFF 38800006
	.long 0xd416022a                                           // 000000085F30: D416022A
	v_cndmask_b32_e32 v1, 0x477fe000, v71, vcc_lo              // 000000085F34: 02028EFF 477FE000
	.long 0x7f481548                                           // 000000085F3C: 7F481548
	.long 0xd413022b                                           // 000000085F40: D413022B
	v_cndmask_b32_e32 v1, 0x38800006, v72, vcc_lo              // 000000085F44: 020290FF 38800006
	v_cvt_f32_f16_e32 v83, v36                                 // 000000085F4C: 7EA61724
	.long 0xd416022c                                           // 000000085F50: D416022C
	v_cndmask_b32_e32 v1, 0x477fe000, v72, vcc_lo              // 000000085F54: 020290FF 477FE000
	s_and_b32 s1, s1, s4                                       // 000000085F5C: 8B010401
	s_and_b32 s4, s5, s6                                       // 000000085F60: 8B040605
	s_and_b32 s6, s9, s10                                      // 000000085F64: 8B060A09
	s_and_b32 s10, s41, s42                                    // 000000085F68: 8B0A2A29
	v_cvt_f16_f32_e32 v33, v65                                 // 000000085F6C: 7E421541
	s_waitcnt lgkmcnt(2)                                       // 000000085F70: BF89FC27
	v_cvt_f16_f32_e32 v60, v73                                 // 000000085F74: 7E781549
	v_cvt_f32_f16_e32 v32, v160/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000085F78: 7E4017A0
	v_cvt_f32_f16_e32 v36, v164/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000085F7C: 7E4817A4
	v_cndmask_b32_e64 v63, v63, v79, s1                        // 000000085F80: D501003F 00069F3F
	v_cndmask_b32_e64 v71, v71, v83, s10                       // 000000085F88: D5010047 002AA747
	.long 0xd4130207                                           // 000000085F90: D4130207
	v_cndmask_b32_e32 v1, 0x38800006, v65, vcc_lo              // 000000085F94: 020282FF 38800006
	.long 0xd4160208                                           // 000000085F9C: D4160208
	v_cndmask_b32_e32 v1, 0x477fe000, v65, vcc_lo              // 000000085FA0: 020282FF 477FE000
	.long 0xd413022d                                           // 000000085FA8: D413022D
	v_cndmask_b32_e32 v1, 0x38800006, v73, vcc_lo              // 000000085FAC: 020292FF 38800006
	.long 0xd416022e                                           // 000000085FB4: D416022E
	v_cndmask_b32_e32 v1, 0x477fe000, v73, vcc_lo              // 000000085FB8: 020292FF 477FE000
	s_and_b32 s1, s43, s44                                     // 000000085FC0: 8B012C2B
	.long 0x7f421542                                           // 000000085FC4: 7F421542
	.long 0x7f78154a                                           // 000000085FC8: 7F78154A
	v_cvt_f32_f16_e32 v80, v33                                 // 000000085FCC: 7EA01721
	v_cvt_f32_f16_e32 v79, v60                                 // 000000085FD0: 7E9E173C
	v_cndmask_b32_e64 v32, v64, v32, s4                        // 000000085FD4: D5010020 00124140
	v_cndmask_b32_e64 v36, v72, v36, s1                        // 000000085FDC: D5010024 00064948
	s_waitcnt vmcnt(0)                                         // 000000085FE4: BF8903F7
	v_fma_f32 v31, -v71, v63, v31                              // 000000085FE8: D613001F 247E7F47
	.long 0xd413022f                                           // 000000085FF0: D413022F
	v_cndmask_b32_e32 v1, 0x38800006, v74, vcc_lo              // 000000085FF4: 020294FF 38800006
	.long 0xd4160230                                           // 000000085FFC: D4160230
	v_cndmask_b32_e32 v1, 0x477fe000, v74, vcc_lo              // 000000086000: 020294FF 477FE000
	s_and_b32 s5, s7, s8                                       // 000000086008: 8B050807
	s_and_b32 s1, s45, s46                                     // 00000008600C: 8B012E2D
	v_cvt_f16_f32_e32 v34, v67                                 // 000000086010: 7E441543
	s_waitcnt lgkmcnt(1)                                       // 000000086014: BF89FC17
	v_cvt_f16_f32_e32 v61, v75                                 // 000000086018: 7E7A154B
	v_cvt_f32_f16_e32 v33, v161/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000008601C: 7E4217A1
	v_cvt_f32_f16_e32 v60, v188/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000086020: 7E7817BC
	v_cndmask_b32_e64 v63, v65, v80, s5                        // 000000086024: D501003F 0016A141
	v_cndmask_b32_e64 v64, v73, v79, s1                        // 00000008602C: D5010040 00069F49
	v_fma_f32 v31, -v36, v32, v31                              // 000000086034: D613001F 247E4124
	.long 0xd4130213                                           // 00000008603C: D4130213
	v_cndmask_b32_e32 v1, 0x38800006, v67, vcc_lo              // 000000086040: 020286FF 38800006
	.long 0xd416021c                                           // 000000086048: D416021C
	v_cndmask_b32_e32 v1, 0x477fe000, v67, vcc_lo              // 00000008604C: 020286FF 477FE000
	.long 0xd4130231                                           // 000000086054: D4130231
	v_cndmask_b32_e32 v1, 0x38800006, v75, vcc_lo              // 000000086058: 020296FF 38800006
	.long 0xd4160232                                           // 000000086060: D4160232
	v_cndmask_b32_e32 v1, 0x477fe000, v75, vcc_lo              // 000000086064: 020296FF 477FE000
	s_and_b32 s1, s47, s48                                     // 00000008606C: 8B01302F
	.long 0x7f441544                                           // 000000086070: 7F441544
	.long 0x7f7a154c                                           // 000000086074: 7F7A154C
	v_cvt_f32_f16_e32 v81, v34                                 // 000000086078: 7EA21722
	v_cvt_f32_f16_e32 v32, v61                                 // 00000008607C: 7E40173D
	v_cndmask_b32_e64 v33, v66, v33, s6                        // 000000086080: D5010021 001A4342
	v_cndmask_b32_e64 v36, v74, v60, s1                        // 000000086088: D5010024 0006794A
	v_fma_f32 v31, -v64, v63, v31                              // 000000086090: D613001F 247E7F40
	.long 0xd413021d                                           // 000000086098: D413021D
	v_cndmask_b32_e32 v1, 0x38800006, v68, vcc_lo              // 00000008609C: 020288FF 38800006
	.long 0xd4160224                                           // 0000000860A4: D4160224
	v_cndmask_b32_e32 v1, 0x477fe000, v68, vcc_lo              // 0000000860A8: 020288FF 477FE000
	.long 0xd4130233                                           // 0000000860B0: D4130233
	v_cndmask_b32_e32 v1, 0x38800006, v76, vcc_lo              // 0000000860B4: 020298FF 38800006
	.long 0xd4160234                                           // 0000000860BC: D4160234
	v_cndmask_b32_e32 v1, 0x477fe000, v76, vcc_lo              // 0000000860C0: 020298FF 477FE000
	s_and_b32 s7, s19, s28                                     // 0000000860C8: 8B071C13
	s_and_b32 s1, s49, s50                                     // 0000000860CC: 8B013231
	v_cvt_f16_f32_e32 v35, v69                                 // 0000000860D0: 7E461545
	s_waitcnt lgkmcnt(0)                                       // 0000000860D4: BF89FC07
	v_cvt_f16_f32_e32 v62, v77                                 // 0000000860D8: 7E7C154D
	v_cvt_f32_f16_e32 v34, v162/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000000860DC: 7E4417A2
	v_cvt_f32_f16_e32 v60, v189/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000000860E0: 7E7817BD
	v_cndmask_b32_e64 v61, v67, v81, s7                        // 0000000860E4: D501003D 001EA343
	v_cndmask_b32_e64 v32, v75, v32, s1                        // 0000000860EC: D5010020 0006414B
	v_fma_f32 v31, -v36, v33, v31                              // 0000000860F4: D613001F 247E4324
	.long 0xd4130225                                           // 0000000860FC: D4130225
	v_cndmask_b32_e32 v1, 0x38800006, v69, vcc_lo              // 000000086100: 02028AFF 38800006
	.long 0xd4160226                                           // 000000086108: D4160226
	v_cndmask_b32_e32 v1, 0x477fe000, v69, vcc_lo              // 00000008610C: 02028AFF 477FE000
	.long 0xd4130235                                           // 000000086114: D4130235
	v_cndmask_b32_e32 v1, 0x38800006, v77, vcc_lo              // 000000086118: 02029AFF 38800006
	.long 0xd4160236                                           // 000000086120: D4160236
	v_cndmask_b32_e32 v1, 0x477fe000, v77, vcc_lo              // 000000086124: 02029AFF 477FE000
	s_and_b32 s8, s29, s36                                     // 00000008612C: 8B08241D
	s_and_b32 s1, s51, s52                                     // 000000086130: 8B013433
	.long 0x7f461546                                           // 000000086134: 7F461546
	.long 0x7f7c154e                                           // 000000086138: 7F7C154E
	v_cvt_f32_f16_e32 v82, v35                                 // 00000008613C: 7EA41723
	v_cvt_f32_f16_e32 v33, v62                                 // 000000086140: 7E42173E
	v_cndmask_b32_e64 v34, v68, v34, s8                        // 000000086144: D5010022 00224544
	v_cndmask_b32_e64 v36, v76, v60, s1                        // 00000008614C: D5010024 0006794C
	v_fma_f32 v31, -v32, v61, v31                              // 000000086154: D613001F 247E7B20
	.long 0xd4130227                                           // 00000008615C: D4130227
	v_cndmask_b32_e32 v1, 0x38800006, v70, vcc_lo              // 000000086160: 02028CFF 38800006
	.long 0xd4160228                                           // 000000086168: D4160228
	v_cndmask_b32_e32 v1, 0x477fe000, v70, vcc_lo              // 00000008616C: 02028CFF 477FE000
	.long 0xd4130237                                           // 000000086174: D4130237
	v_cndmask_b32_e32 v1, 0x38800006, v78, vcc_lo              // 000000086178: 02029CFF 38800006
	.long 0xd4160238                                           // 000000086180: D4160238
	v_cndmask_b32_e32 v1, 0x477fe000, v78, vcc_lo              // 000000086184: 02029CFF 477FE000
	s_and_b32 s9, s37, s38                                     // 00000008618C: 8B092625
	s_and_b32 s1, s53, s54                                     // 000000086190: 8B013635
	v_cvt_f32_f16_e32 v35, v163/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000086194: 7E4617A3
	v_cvt_f32_f16_e32 v32, v190/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000086198: 7E4017BE
	v_cndmask_b32_e64 v60, v69, v82, s9                        // 00000008619C: D501003C 0026A545
	v_cndmask_b32_e64 v33, v77, v33, s1                        // 0000000861A4: D5010021 0006434D
	v_fma_f32 v31, -v36, v34, v31                              // 0000000861AC: D613001F 247E4524
	s_and_b32 s1, s39, s40                                     // 0000000861B4: 8B012827
	s_and_b32 s4, s55, s56                                     // 0000000861B8: 8B043837
	v_cndmask_b32_e64 v34, v70, v35, s1                        // 0000000861BC: D5010022 00064746
	v_cndmask_b32_e64 v32, v78, v32, s4                        // 0000000861C4: D5010020 0012414E
	v_fma_f32 v31, -v33, v60, v31                              // 0000000861CC: D613001F 247E7921
	s_add_i32 s1, s18, 8                                       // 0000000861D4: 81018812
	s_cmpk_lt_u32 s18, 0x78                                    // 0000000861D8: B6920078
	s_mov_b32 s18, s1                                          // 0000000861DC: BE920001
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000861E0: BF870001
	v_fma_f32 v31, -v32, v34, v31                              // 0000000861E4: D613001F 247E4520
	s_cbranch_scc1 65311                                       // 0000000861EC: BFA2FF1F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x66c>
	v_mad_u64_u32 v[32:33], null, 0x44, s16, v[4:5]            // 0000000861F0: D6FE7C20 041020FF 00000044
	ds_store_b32 v32, v31                                      // 0000000861FC: D8340000 00001F20
	s_branch 65227                                             // 000000086204: BFA0FECB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_mov_b32_e32 v30, v14                                     // 000000086208: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 00000008620C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 000000086214: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 000000086218: 7E46032B
	s_mov_b32 s5, 0                                            // 00000008621C: BE850080
	s_branch 21                                                // 000000086220: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa78>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000086224: 8C7E067E
	.long 0xd700011f                                           // 000000086228: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 00000008622C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000086234: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 000000086238: D5207C20 00064080
	.long 0xd700011d                                           // 000000086240: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 000000086244: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 00000008624C: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000086250: D5207C1E 00063C80
	s_add_i32 s1, s5, 8                                        // 000000086258: 81018805
	s_cmp_gt_u32 s5, 55                                        // 00000008625C: BF08B705
	s_mov_b32 s5, s1                                           // 000000086260: BE850001
	s_waitcnt_vscnt null, 0x0                                  // 000000086264: BC7C0000
	s_barrier                                                  // 000000086268: BFBD0000
	buffer_gl0_inv                                             // 00000008626C: E0AC0000 00000000
	s_cbranch_scc1 610                                         // 000000086274: BFA20262 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1400>
	s_delay_alu instid0(VALU_DEP_2)                            // 000000086278: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 00000008627C: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 000000086284: 7E480328
	v_mov_b32_e32 v60, v38                                     // 000000086288: 7E780326
	s_mov_b32 s6, 0                                            // 00000008628C: BE860080
	s_nop 0                                                    // 000000086290: BF800000
	s_nop 0                                                    // 000000086294: BF800000
	s_nop 0                                                    // 000000086298: BF800000
	s_nop 0                                                    // 00000008629C: BF800000
	s_nop 0                                                    // 0000000862A0: BF800000
	s_nop 0                                                    // 0000000862A4: BF800000
	s_nop 0                                                    // 0000000862A8: BF800000
	s_nop 0                                                    // 0000000862AC: BF800000
	s_nop 0                                                    // 0000000862B0: BF800000
	s_nop 0                                                    // 0000000862B4: BF800000
	s_nop 0                                                    // 0000000862B8: BF800000
	s_nop 0                                                    // 0000000862BC: BF800000
	global_load_b32 v61, v[33:34], off                         // 0000000862C0: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000862C8: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000862D0: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000862D4: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000862DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000862E0: D5207C22 00064480
	.long 0xd4490004                                           // 0000000862E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000862EC: 020278FF 0000037F
	s_or_b32 s6, s4, s6                                        // 0000000862F4: 8C060604
	s_waitcnt vmcnt(0)                                         // 0000000862F8: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000000862FC: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 000000086304: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000008630C: 917E067E
	s_cbranch_execnz 65515                                     // 000000086310: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xac0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000086314: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000086318: BF89FC07
	s_barrier                                                  // 00000008631C: BFBD0000
	buffer_gl0_inv                                             // 000000086320: E0AC0000 00000000
	s_and_saveexec_b32 s6, s0                                  // 000000086328: BE862000
	s_cbranch_execz 65469                                      // 00000008632C: BFA5FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa24>
	v_or_b32_e32 v33, s5, v2                                   // 000000086330: 38420405
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086334: BF870091
	v_or_b32_e32 v36, s15, v33                                 // 000000086338: 3848420F
	.long 0xd4440001                                           // 00000008633C: D4440001
	v_cndmask_b32_e32 v1, s33, v36, vcc_lo                     // 000000086340: 02024821
	s_and_b32 exec_lo, exec_lo, s1                             // 000000086344: 8B7E017E
	s_cbranch_execz 65462                                      // 000000086348: BFA5FFB6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa24>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 00000008634C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 000000086354: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 00000008635C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 000000086364: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 00000008636C: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 000000086374: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 00000008637C: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 000000086384: D8DC7766 4A000001
	s_mov_b32 s7, 0                                            // 00000008638C: BE870080
	s_waitcnt lgkmcnt(6)                                       // 000000086390: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 000000086394: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008639C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000863A0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000863A4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000863A8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000863AC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000863B0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000863B4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000863B8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000863BC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000863C0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000863C4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000863C8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000863CC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000863D0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:8 offset1:9        // 0000000863D4: D8DC0908 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 0000000863DC: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 0000000863E4: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 0000000863EC: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:12 offset1:13      // 0000000863F4: D8DC0D0C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 0000000863FC: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 000000086404: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 00000008640C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 000000086414: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086418: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008641C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000086420: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000086424: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000086428: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008642C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000086430: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000086434: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000086438: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008643C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000086440: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000086444: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000086448: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008644C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000086450: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 000000086454: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 00000008645C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 000000086464: D8DC1312 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 00000008646C: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:20 offset1:21      // 000000086474: D8DC1514 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 00000008647C: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 000000086484: D8DC6554 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 00000008648C: D8DC8776 4A000030
	s_waitcnt lgkmcnt(6)                                       // 000000086494: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086498: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008649C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000864A0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000864A4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000864A8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000864AC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000864B0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000864B4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000864B8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000864BC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000864C0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000864C4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000864C8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000864CC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000864D0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 0000000864D4: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 0000000864DC: D8DCA998 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 0000000864E4: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 0000000864EC: D8DCCBBA 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:28 offset1:29      // 0000000864F4: D8DC1D1C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000864FC: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 000000086504: D8DCEDDC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:126 offset1:143    // 00000008650C: D8DC8F7E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 000000086514: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086518: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008651C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000086520: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000086524: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000086528: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008652C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000086530: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000086534: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000086538: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008653C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000086540: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000086544: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000086548: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008654C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000086550: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 000000086554: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 00000008655C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 000000086564: D8DC2322 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:66 offset1:83      // 00000008656C: D8DC5342 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:36 offset1:37      // 000000086574: D8DC2524 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 00000008657C: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 000000086584: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 00000008658C: D8DC9786 4A000032
	s_waitcnt lgkmcnt(6)                                       // 000000086594: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086598: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008659C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000865A0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000865A4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000865A8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000865AC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000865B0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000865B4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000865B8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000865BC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000865C0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000865C4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000865C8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000865CC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000865D0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:40 offset1:41      // 0000000865D4: D8DC2928 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:168 offset1:185    // 0000000865DC: D8DCB9A8 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 0000000865E4: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:202 offset1:219    // 0000000865EC: D8DCDBCA 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:44 offset1:45      // 0000000865F4: D8DC2D2C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 0000000865FC: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 000000086604: D8DCFDEC 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:14 offset1:31      // 00000008660C: D8DC1F0E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 000000086614: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086618: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008661C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000086620: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000086624: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000086628: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008662C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000086630: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000086634: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000086638: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008663C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000086640: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000086644: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000086648: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008664C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000086650: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 000000086654: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 00000008665C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 000000086664: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 00000008666C: D8DC6352 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:52 offset1:53      // 000000086674: D8DC3534 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 00000008667C: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 000000086684: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 00000008668C: D8DCA796 4A000033
	s_waitcnt lgkmcnt(6)                                       // 000000086694: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086698: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008669C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000866A0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000866A4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000866A8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000866AC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000866B0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000866B4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000866B8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000866BC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000866C0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000866C4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000866C8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000866CC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000866D0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:56 offset1:57      // 0000000866D4: D8DC3938 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:184 offset1:201    // 0000000866DC: D8DCC9B8 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 0000000866E4: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:218 offset1:235    // 0000000866EC: D8DCEBDA 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:60 offset1:61      // 0000000866F4: D8DC3D3C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 0000000866FC: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 000000086704: D8DC8D7C 48000034
	ds_load_2addr_b32 v[74:75], v53 offset0:30 offset1:47      // 00000008670C: D8DC2F1E 4A000035
	s_waitcnt lgkmcnt(6)                                       // 000000086714: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086718: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008671C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000086720: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000086724: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000086728: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008672C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000086730: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000086734: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000086738: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008673C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000086740: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000086744: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000086748: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008674C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000086750: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 000000086754: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 00000008675C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 000000086764: D8DC4342 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:98 offset1:115     // 00000008676C: D8DC7362 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:68 offset1:69      // 000000086774: D8DC4544 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 00000008677C: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 000000086784: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 00000008678C: D8DCB7A6 4A000035
	s_waitcnt lgkmcnt(6)                                       // 000000086794: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086798: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008679C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000867A0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000867A4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000867A8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000867AC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000867B0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000867B4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000867B8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000867BC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000867C0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000867C4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000867C8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000867CC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000867D0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 0000000867D4: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 0000000867DC: D8DCD9C8 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 0000000867E4: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 0000000867EC: D8DCFBEA 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:76 offset1:77      // 0000000867F4: D8DC4D4C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 0000000867FC: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 000000086804: D8DC1D0C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:46 offset1:63      // 00000008680C: D8DC3F2E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 000000086814: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086818: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008681C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000086820: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000086824: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000086828: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008682C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000086830: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000086834: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000086838: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008683C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000086840: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000086844: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000086848: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008684C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000086850: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 000000086854: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 00000008685C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 000000086864: D8DC5352 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:114 offset1:131    // 00000008686C: D8DC8372 42000036
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:85      // 000000086874: D8DC5554 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 00000008687C: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 000000086884: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 00000008688C: D8DCC7B6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 000000086894: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086898: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008689C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000868A0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000868A4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000868A8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000868AC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000868B0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000868B4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000868B8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000868BC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000868C0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000868C4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000868C8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000868CC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000868D0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:88 offset1:89      // 0000000868D4: D8DC5958 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:216 offset1:233    // 0000000868DC: D8DCE9D8 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:90 offset1:91      // 0000000868E4: D8DC5B5A 4000002E
	ds_load_2addr_b32 v[66:67], v55 offset0:122 offset1:139    // 0000000868EC: D8DC8B7A 42000037
	ds_load_2addr_b32 v[68:69], v46 offset0:92 offset1:93      // 0000000868F4: D8DC5D5C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 0000000868FC: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 000000086904: D8DC2D1C 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:62 offset1:79      // 00000008690C: D8DC4F3E 4A000038
	s_waitcnt lgkmcnt(6)                                       // 000000086914: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086918: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008691C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000086920: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000086924: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000086928: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008692C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000086930: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000086934: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000086938: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008693C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000086940: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000086944: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000086948: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008694C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000086950: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 000000086954: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 00000008695C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 000000086964: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 00000008696C: D8DC9382 42000038
	ds_load_2addr_b32 v[68:69], v46 offset0:100 offset1:101    // 000000086974: D8DC6564 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 00000008697C: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 000000086984: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 00000008698C: D8DCD7C6 4A000038
	s_waitcnt lgkmcnt(6)                                       // 000000086994: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086998: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008699C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000869A0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000869A4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000869A8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000869AC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000869B0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000869B4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000869B8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000869BC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000869C0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000869C4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000869C8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000869CC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000869D0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:104 offset1:105    // 0000000869D4: D8DC6968 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:232 offset1:249    // 0000000869DC: D8DCF9E8 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 0000000869E4: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:10 offset1:27      // 0000000869EC: D8DC1B0A 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:108 offset1:109    // 0000000869F4: D8DC6D6C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 0000000869FC: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 000000086A04: D8DC3D2C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:78 offset1:95      // 000000086A0C: D8DC5F4E 4A000039
	s_waitcnt lgkmcnt(6)                                       // 000000086A14: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086A18: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000086A1C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000086A20: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000086A24: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000086A28: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000086A2C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000086A30: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000086A34: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000086A38: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000086A3C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000086A40: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000086A44: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000086A48: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000086A4C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000086A50: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 000000086A54: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 000000086A5C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 000000086A64: D8DC7372 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:146 offset1:163    // 000000086A6C: D8DCA392 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:116 offset1:117    // 000000086A74: D8DC7574 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 000000086A7C: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 000000086A84: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 000000086A8C: D8DCE7D6 4A000039
	s_waitcnt lgkmcnt(6)                                       // 000000086A94: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086A98: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000086A9C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000086AA0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000086AA4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000086AA8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000086AAC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000086AB0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000086AB4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000086AB8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000086ABC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000086AC0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000086AC4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000086AC8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000086ACC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000086AD0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 000000086AD4: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 000000086ADC: D8DC8978 3E00003A
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 000000086AE4: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:26 offset1:43      // 000000086AEC: D8DC2B1A 4200003B
	ds_load_2addr_b32 v[68:69], v46 offset0:124 offset1:125    // 000000086AF4: D8DC7D7C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 000000086AFC: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 000000086B04: D8DC4D3C 4800003B
	ds_load_2addr_b32 v[74:75], v59 offset0:94 offset1:111     // 000000086B0C: D8DC6F5E 4A00003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 000000086B14: 30424282
	s_waitcnt lgkmcnt(6)                                       // 000000086B18: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000086B1C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 000000086B20: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 000000086B28: CA10011E 2220011D
	v_mov_b32_e32 v62, v35                                     // 000000086B30: 7E7C0323
	v_fmac_f32_e32 v76, v61, v63                               // 000000086B34: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 000000086B38: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 000000086B3C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086B40: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 000000086B44: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 000000086B48: 56988741
	s_waitcnt lgkmcnt(2)                                       // 000000086B4C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086B50: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 000000086B54: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 000000086B58: 56989345
	s_waitcnt lgkmcnt(1)                                       // 000000086B5C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086B60: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 000000086B64: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 000000086B68: 56989747
	s_waitcnt lgkmcnt(0)                                       // 000000086B6C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000086B70: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 000000086B74: 1078794C
	s_nop 0                                                    // 000000086B78: BF800000
	s_nop 0                                                    // 000000086B7C: BF800000
	global_load_b32 v63, v[33:34], off                         // 000000086B80: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 000000086B88: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 000000086B90: 4A7C7CC1
	.long 0xd7000121                                           // 000000086B94: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 000000086B98: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000086B9C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 000000086BA0: D5207C22 00064480
	.long 0xd44a0004                                           // 000000086BA8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 000000086BAC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 000000086BB0: 4A7A7AFF 00000044
	s_or_b32 s7, s4, s7                                        // 000000086BB8: 8C070704
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000086BBC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 000000086BC0: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 000000086BC4: 917E077E
	s_cbranch_execnz 65517                                     // 000000086BC8: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1380>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000086BCC: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000086BD0: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 000000086BD4: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 000000086BDC: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 000000086BE8: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 000000086BF4: DC960000 007C2421
	s_branch 64905                                             // 000000086BFC: BFA0FD89 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa24>
	s_mul_f32 s1, s14, 0x3fb8aa3b                              // 000000086C00: A201FF0E 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 000000086C08: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000086C0C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 000000086C10: 8D04FF01 80000000
	s_rndne_f32 s5, s1                                         // 000000086C18: BE856301
	s_fmamk_f32 s4, s14, 0x3fb8aa3b, s4                        // 000000086C1C: A304040E 3FB8AA3B
	s_cmp_nlt_f32 s14, 0xc2ce8ed0                              // 000000086C24: BF4EFF0E C2CE8ED0
	s_sub_f32 s1, s1, s5                                       // 000000086C2C: A0810501
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000086C30: BF870599
	s_fmamk_f32 s4, s14, 0x32a5705f, s4                        // 000000086C34: A304040E 32A5705F
	s_add_f32 s1, s1, s4                                       // 000000086C3C: A0010401
	s_mov_b32 s4, 0                                            // 000000086C40: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 000000086C44: BF87000A
	v_exp_f32_e32 v29, s1                                      // 000000086C48: 7E3A4A01
	s_cvt_i32_f32 s1, s5                                       // 000000086C4C: BE816605
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000086C50: BF870585
	.long 0xd71c001d                                           // 000000086C54: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 000000086C58: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 000000086C5C: 980180C1
	s_cmp_ngt_f32 s14, 0x42b17218                              // 000000086C60: BF4BFF0E 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000086C68: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 000000086C6C: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 000000086C74: 980180C1
	v_mov_b32_e32 v29, v37                                     // 000000086C78: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 000000086C7C: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 000000086C88: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 000000086C90: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000086C98: BF870001
	.long 0xd4490001                                           // 000000086C9C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 000000086CA0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 000000086CA8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 000000086CAC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 000000086CB0: 1040411E
	ds_store_b32 v29, v32                                      // 000000086CB4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 000000086CBC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000086CC4: 917E047E
	s_cbranch_execnz 65519                                     // 000000086CC8: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1488>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000086CCC: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 000000086CD0: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 000000086CD8: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 000000086CE0: 7E420326
	s_mov_b32 s5, 0                                            // 000000086CE4: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000086CE8: BF89FC07
	s_barrier                                                  // 000000086CEC: BFBD0000
	buffer_gl0_inv                                             // 000000086CF0: E0AC0000 00000000
	s_nop 0                                                    // 000000086CF8: BF800000
	s_nop 0                                                    // 000000086CFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000086D00: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 000000086D08: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000086D10: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000086D18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000086D1C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 000000086D24: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000086D28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000086D30: BF870004
	.long 0xd4490004                                           // 000000086D34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000086D38: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 000000086D40: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000086D44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000086D48: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 000000086D4C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 000000086D54: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000086D5C: 917E057E
	s_cbranch_execnz 65511                                     // 000000086D60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1500>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000086D64: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 000000086D68: BF89FC07
	s_barrier                                                  // 000000086D6C: BFBD0000
	buffer_gl0_inv                                             // 000000086D70: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 000000086D78: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 000000086D80: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 000000086D88: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 000000086D90: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 000000086D98: 7E780300
	s_mov_b32 s4, 0                                            // 000000086D9C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000086DA0: BF840001
	s_nop 0                                                    // 000000086DA4: BF800000
	s_nop 0                                                    // 000000086DA8: BF800000
	s_nop 0                                                    // 000000086DAC: BF800000
	s_nop 0                                                    // 000000086DB0: BF800000
	s_nop 0                                                    // 000000086DB4: BF800000
	s_nop 0                                                    // 000000086DB8: BF800000
	s_nop 0                                                    // 000000086DBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000086DC0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000086DC4: 327A7884
	.long 0xd4490001                                           // 000000086DC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000086DCC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000086DD4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000086DD8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000086DE4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000086DE8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000086DF0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000086DF8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000086E00: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000086E08: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000086E10: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000086E18: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000086E20: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000086E24: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000086E30: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000086E34: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000086E38: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000086E40: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000086E44: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000086E48: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 000000086E4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086E50: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000086E54: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000086E58: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 000000086E5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086E60: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000086E64: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000086E70: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000086E78: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000086E80: 917E047E
	s_cbranch_execnz 65486                                     // 000000086E84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_set_inst_prefetch_distance 0x2                           // 000000086E88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000086E8C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 000000086E90: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000086E98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000086EA0: 7E420326
	s_mov_b32 s5, 0                                            // 000000086EA4: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000086EA8: BF89FC07
	s_barrier                                                  // 000000086EAC: BFBD0000
	buffer_gl0_inv                                             // 000000086EB0: E0AC0000 00000000
	s_nop 0                                                    // 000000086EB8: BF800000
	s_nop 0                                                    // 000000086EBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000086EC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 000000086EC8: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000086ED0: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000086ED8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000086EDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000086EE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000086EE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000086EF0: BF870004
	.long 0xd4490004                                           // 000000086EF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000086EF8: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 000000086F00: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000086F04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000086F08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000086F0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000086F14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000086F1C: 917E057E
	s_cbranch_execnz 65511                                     // 000000086F20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16c0>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000086F24: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 000000086F28: BF89FC07
	s_barrier                                                  // 000000086F2C: BFBD0000
	buffer_gl0_inv                                             // 000000086F30: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 000000086F38: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 000000086F40: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 000000086F48: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 000000086F50: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 000000086F58: 7E780300
	s_mov_b32 s4, 0                                            // 000000086F5C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000086F60: BF840001
	s_nop 0                                                    // 000000086F64: BF800000
	s_nop 0                                                    // 000000086F68: BF800000
	s_nop 0                                                    // 000000086F6C: BF800000
	s_nop 0                                                    // 000000086F70: BF800000
	s_nop 0                                                    // 000000086F74: BF800000
	s_nop 0                                                    // 000000086F78: BF800000
	s_nop 0                                                    // 000000086F7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000086F80: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000086F84: 327A7884
	.long 0xd4490001                                           // 000000086F88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000086F8C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000086F94: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000086F98: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000086FA4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000086FA8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000086FB0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000086FB8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000086FC0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000086FC8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000086FD0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000086FD8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000086FE0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000086FE4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000086FF0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000086FF4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000086FF8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000087000: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000087004: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000087008: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000008700C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000087010: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000087014: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000087018: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000008701C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000087020: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000087024: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000087030: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000087038: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000087040: 917E047E
	s_cbranch_execnz 65486                                     // 000000087044: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1780>
	s_set_inst_prefetch_distance 0x2                           // 000000087048: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008704C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 000000087050: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000087058: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000087060: 7E420326
	s_mov_b32 s5, 0                                            // 000000087064: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000087068: BF89FC07
	s_barrier                                                  // 00000008706C: BFBD0000
	buffer_gl0_inv                                             // 000000087070: E0AC0000 00000000
	s_nop 0                                                    // 000000087078: BF800000
	s_nop 0                                                    // 00000008707C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000087080: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 000000087088: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000087090: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000087098: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008709C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000870A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000870A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000870B0: BF870004
	.long 0xd4490004                                           // 0000000870B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000870B8: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 0000000870C0: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000870C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000870C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000870CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000870D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000000870DC: 917E057E
	s_cbranch_execnz 65511                                     // 0000000870E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1880>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000870E4: 8C7E057E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000870E8: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000870F0: BF89FC07
	s_barrier                                                  // 0000000870F4: BFBD0000
	buffer_gl0_inv                                             // 0000000870F8: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 000000087100: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 000000087104: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 00000008710C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 000000087114: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 00000008711C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 000000087124: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000087128: BF840001
	s_nop 0                                                    // 00000008712C: BF800000
	s_nop 0                                                    // 000000087130: BF800000
	s_nop 0                                                    // 000000087134: BF800000
	s_nop 0                                                    // 000000087138: BF800000
	s_nop 0                                                    // 00000008713C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000087140: 327C7A84
	.long 0xd4490001                                           // 000000087144: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000087148: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000087150: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000087154: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000087158: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000087164: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000087168: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000087170: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000087178: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000087180: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000087188: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000087190: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000087198: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000871A0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000871A4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000871A8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000871AC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000871B8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000871C0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000871C4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000871C8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000871CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000871D0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000871D4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000871D8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000871DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000871E0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000871E4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000871F0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000871F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000087200: 917E047E
	s_cbranch_execnz 65486                                     // 000000087204: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_set_inst_prefetch_distance 0x2                           // 000000087208: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008720C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 000000087210: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000087218: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000087220: 7E420326
	s_mov_b32 s5, 0                                            // 000000087224: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000087228: BF89FC07
	s_barrier                                                  // 00000008722C: BFBD0000
	buffer_gl0_inv                                             // 000000087230: E0AC0000 00000000
	s_nop 0                                                    // 000000087238: BF800000
	s_nop 0                                                    // 00000008723C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000087240: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 000000087248: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000087250: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000087258: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008725C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000087264: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000087268: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000087270: BF870004
	.long 0xd4490004                                           // 000000087274: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000087278: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 000000087280: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000087284: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000087288: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008728C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000087294: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000008729C: 917E057E
	s_cbranch_execnz 65511                                     // 0000000872A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000872A4: 8C7E057E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000872A8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000872B0: BF89FC07
	s_barrier                                                  // 0000000872B4: BFBD0000
	buffer_gl0_inv                                             // 0000000872B8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 0000000872C0: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 0000000872C8: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 0000000872D0: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 0000000872D8: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000872E0: 7E780300
	s_mov_b32 s4, 0                                            // 0000000872E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000872E8: BF840001
	s_nop 0                                                    // 0000000872EC: BF800000
	s_nop 0                                                    // 0000000872F0: BF800000
	s_nop 0                                                    // 0000000872F4: BF800000
	s_nop 0                                                    // 0000000872F8: BF800000
	s_nop 0                                                    // 0000000872FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000087300: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000087304: 327A7884
	.long 0xd4490001                                           // 000000087308: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000008730C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000087314: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000087318: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000087324: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000087328: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000087330: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000087338: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000087340: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000087348: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000087350: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000087358: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000087360: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000087364: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000087370: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000087374: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000087378: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000087380: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000087384: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000087388: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000008738C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000087390: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000087394: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000087398: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000008739C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000873A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000873A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000873B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000873B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000873C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000873C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_set_inst_prefetch_distance 0x2                           // 0000000873C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000873CC: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 0000000873D0: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000873D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000873E0: 7E420326
	s_mov_b32 s5, 0                                            // 0000000873E4: BE850080
	s_waitcnt lgkmcnt(0)                                       // 0000000873E8: BF89FC07
	s_barrier                                                  // 0000000873EC: BFBD0000
	buffer_gl0_inv                                             // 0000000873F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000873F8: BF800000
	s_nop 0                                                    // 0000000873FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000087400: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 000000087408: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000087410: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000087418: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008741C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000087424: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000087428: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000087430: BF870004
	.long 0xd4490004                                           // 000000087434: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000087438: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 000000087440: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000087444: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000087448: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008744C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000087454: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000008745C: 917E057E
	s_cbranch_execnz 65511                                     // 000000087460: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000087464: 8C7E057E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 000000087468: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 000000087470: BF89FC07
	s_barrier                                                  // 000000087474: BFBD0000
	buffer_gl0_inv                                             // 000000087478: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 000000087480: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 000000087484: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 00000008748C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 000000087494: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 00000008749C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000874A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000874A8: BF840001
	s_nop 0                                                    // 0000000874AC: BF800000
	s_nop 0                                                    // 0000000874B0: BF800000
	s_nop 0                                                    // 0000000874B4: BF800000
	s_nop 0                                                    // 0000000874B8: BF800000
	s_nop 0                                                    // 0000000874BC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 0000000874C0: 327C7884
	.long 0xd4490001                                           // 0000000874C4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000874C8: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000874D0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000874D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000874D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000874E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000874E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000874F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000874F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000087500: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000087508: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000087510: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000087518: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000087520: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000087524: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000087528: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000008752C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000087538: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000087540: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000087544: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000087548: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000008754C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000087550: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000087554: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000087558: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000008755C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000087560: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 000000087564: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 000000087570: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 000000087574: BF870002
	v_mov_b32_e32 v60, v63                                     // 000000087578: 7E78033F
	ds_store_b32 v62, v70                                      // 00000008757C: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000087584: 917E047E
	s_cbranch_execnz 65485                                     // 000000087588: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_set_inst_prefetch_distance 0x2                           // 00000008758C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000087590: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 000000087594: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000008759C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000875A4: 7E420326
	s_mov_b32 s5, 0                                            // 0000000875A8: BE850080
	s_waitcnt lgkmcnt(0)                                       // 0000000875AC: BF89FC07
	s_barrier                                                  // 0000000875B0: BFBD0000
	buffer_gl0_inv                                             // 0000000875B4: E0AC0000 00000000
	s_nop 0                                                    // 0000000875BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000875C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 0000000875C8: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000875D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000875D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000875DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000875E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000875E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000875F0: BF870004
	.long 0xd4490004                                           // 0000000875F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000875F8: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 000000087600: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000087604: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000087608: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008760C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000087614: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000008761C: 917E057E
	s_cbranch_execnz 65511                                     // 000000087620: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dc0>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000087624: 8C7E057E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 000000087628: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 000000087630: BF89FC07
	s_barrier                                                  // 000000087634: BFBD0000
	buffer_gl0_inv                                             // 000000087638: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 000000087640: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 000000087648: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 000000087650: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 000000087658: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000087660: 7E7A0300
	s_mov_b32 s4, 0                                            // 000000087664: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000087668: BF840001
	s_nop 0                                                    // 00000008766C: BF800000
	s_nop 0                                                    // 000000087670: BF800000
	s_nop 0                                                    // 000000087674: BF800000
	s_nop 0                                                    // 000000087678: BF800000
	s_nop 0                                                    // 00000008767C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000087680: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000087684: 327C7A84
	.long 0xd4490001                                           // 000000087688: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000008768C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000087694: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000087698: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000876A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000876A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000876B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000876B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000876C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000876C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000876D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000876D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000876E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000876E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000876E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000876EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000876F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000087700: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000087704: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000087708: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000008770C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000087710: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000087714: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000087718: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000008771C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000087720: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000087724: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000087730: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000087738: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000087740: 917E047E
	s_cbranch_execnz 65486                                     // 000000087744: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e80>
	s_set_inst_prefetch_distance 0x2                           // 000000087748: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008774C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 000000087750: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000087758: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000087760: 7E420326
	s_mov_b32 s5, 0                                            // 000000087764: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000087768: BF89FC07
	s_barrier                                                  // 00000008776C: BFBD0000
	buffer_gl0_inv                                             // 000000087770: E0AC0000 00000000
	s_nop 0                                                    // 000000087778: BF800000
	s_nop 0                                                    // 00000008777C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000087780: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 000000087788: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000087790: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000087798: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008779C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000877A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000877A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000877B0: BF870004
	.long 0xd4490004                                           // 0000000877B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000877B8: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 0000000877C0: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000877C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000877C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000877CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000877D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000000877DC: 917E057E
	s_cbranch_execnz 65511                                     // 0000000877E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f80>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000877E4: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 0000000877E8: BF89FC07
	s_barrier                                                  // 0000000877EC: BFBD0000
	buffer_gl0_inv                                             // 0000000877F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 0000000877F8: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 000000087800: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 000000087808: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 000000087810: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000087818: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000008781C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000087820: BF840001
	s_nop 0                                                    // 000000087824: BF800000
	s_nop 0                                                    // 000000087828: BF800000
	s_nop 0                                                    // 00000008782C: BF800000
	s_nop 0                                                    // 000000087830: BF800000
	s_nop 0                                                    // 000000087834: BF800000
	s_nop 0                                                    // 000000087838: BF800000
	s_nop 0                                                    // 00000008783C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000087840: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000087844: 327C7A84
	.long 0xd4490001                                           // 000000087848: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000008784C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000087854: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000087858: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000087864: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000087868: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000087870: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000087878: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000087880: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000087888: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000087890: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000087898: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000878A0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000878A4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000878A8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000878AC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000878B8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000878C0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000878C4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000878C8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000878CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000878D0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000878D4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000878D8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000878DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000878E0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000878E4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000878F0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000878F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000087900: 917E047E
	s_cbranch_execnz 65486                                     // 000000087904: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_set_inst_prefetch_distance 0x2                           // 000000087908: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008790C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 000000087910: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000087918: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000087920: 7E420326
	s_mov_b32 s5, 0                                            // 000000087924: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000087928: BF89FC07
	s_barrier                                                  // 00000008792C: BFBD0000
	buffer_gl0_inv                                             // 000000087930: E0AC0000 00000000
	s_nop 0                                                    // 000000087938: BF800000
	s_nop 0                                                    // 00000008793C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000087940: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 000000087948: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000087950: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000087958: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008795C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000087964: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000087968: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000087970: BF870004
	.long 0xd4490004                                           // 000000087974: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000087978: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 000000087980: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000087984: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000087988: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008798C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000087994: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000008799C: 917E057E
	s_cbranch_execnz 65511                                     // 0000000879A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2140>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000879A4: 8C7E057E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000879A8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000879B0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000879B8: BF89FC07
	s_barrier                                                  // 0000000879BC: BFBD0000
	buffer_gl0_inv                                             // 0000000879C0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 0000000879C8: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 0000000879D0: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000879D8: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 0000000879E0: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000879E8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000879EC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000879F0: BF840001
	s_nop 0                                                    // 0000000879F4: BF800000
	s_nop 0                                                    // 0000000879F8: BF800000
	s_nop 0                                                    // 0000000879FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000087A00: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000087A04: 327A7884
	.long 0xd4490001                                           // 000000087A08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000087A0C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000087A14: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000087A18: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000087A24: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000087A28: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000087A30: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000087A38: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000087A40: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000087A48: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000087A50: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000087A58: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000087A60: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000087A64: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000087A70: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000087A74: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000087A78: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000087A80: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000087A84: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000087A88: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 000000087A8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000087A90: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000087A94: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000087A98: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 000000087A9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000087AA0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000087AA4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000087AB0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000087AB8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000087AC0: 917E047E
	s_cbranch_execnz 65486                                     // 000000087AC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2200>
	s_set_inst_prefetch_distance 0x2                           // 000000087AC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000087ACC: 8C7E047E
	.long 0xd7000107                                           // 000000087AD0: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 000000087AD4: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000087ADC: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 000000087AE0: D5207C08 00061080
	.long 0xd7000109                                           // 000000087AE8: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 000000087AEC: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 000000087AF4: D5207C0A 00061480
	.long 0xd700010d                                           // 000000087AFC: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 000000087B00: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000087B08: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 000000087B0C: D5207C0E 00061C80
	.long 0xd700010b                                           // 000000087B14: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 000000087B18: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 000000087B20: D5207C0C 00061880
	.long 0xd700010f                                           // 000000087B28: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 000000087B2C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000087B34: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 000000087B38: D5207C10 00062080
	.long 0xd7000111                                           // 000000087B40: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 000000087B44: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 000000087B4C: D5207C12 00062480
	.long 0xd7000113                                           // 000000087B54: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 000000087B58: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000087B60: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 000000087B64: D5207C14 00062880
	.long 0xd7000115                                           // 000000087B6C: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 000000087B70: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 000000087B78: D5207C16 00062C80
	.long 0xd7000117                                           // 000000087B80: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 000000087B84: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000087B8C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 000000087B90: D5207C18 00063080
	.long 0xd7000119                                           // 000000087B98: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 000000087B9C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 000000087BA4: D5207C1A 00063480
	.long 0xd700011b                                           // 000000087BAC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 000000087BB0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000087BB8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 000000087BBC: D5207C1C 00063880
	s_add_i32 s11, s11, 1                                      // 000000087BC4: 810B810B
	s_waitcnt lgkmcnt(0)                                       // 000000087BC8: BF89FC07
	s_cmp_eq_u32 s11, s35                                      // 000000087BCC: BF06230B
	s_barrier                                                  // 000000087BD0: BFBD0000
	buffer_gl0_inv                                             // 000000087BD4: E0AC0000 00000000
	s_cbranch_scc0 63473                                       // 000000087BDC: BFA1F7F1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 000000087BE0: 7E080326
	s_add_u32 s0, s30, s24                                     // 000000087BE4: 8000181E
	.long 0xd73c0000                                           // 000000087BE8: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 000000087BEC: 02020489
	s_addc_u32 s1, s31, s25                                    // 000000087BF0: 8201191F
	s_add_u32 s2, s26, s22                                     // 000000087BF4: 8002161A
	s_addc_u32 s3, s27, s23                                    // 000000087BF8: 8203171B
	s_add_u32 s0, s2, s0                                       // 000000087BFC: 80000002
	s_addc_u32 s1, s3, s1                                      // 000000087C00: 82010103
	.long 0xd7006a00                                           // 000000087C04: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000087C08: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000087C0C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000087C10: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000087C18: BE810080
	.long 0xd7006a00                                           // 000000087C1C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 000000087C20: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000087C24: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000087C2C: BF870092
	.long 0xd7006a00                                           // 000000087C30: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 000000087C34: 02020014
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 000000087C38: D5207C01 01AA0215
	ds_load_b32 v2, v37                                        // 000000087C40: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000087C48: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 000000087C50: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000087C58: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 000000087C5C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 000000087C64: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 000000087C68: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 000000087C6C: DC6A0000 007C0200
	.long 0xd7000000                                           // 000000087C74: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000087C78: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 000000087C80: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000087C88: 917E017E
	s_cbranch_execnz 65516                                     // 000000087C8C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	s_endpgm                                                   // 000000087C90: BFB00000
		...

